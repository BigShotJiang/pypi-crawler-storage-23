"""Generation endpoints -- CRUD, lineage, and diff."""

from __future__ import annotations

import sqlite3

import shutil
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status

from mygens.core.config import get_outputs_dir, get_thumbnails_dir
from mygens.core.diff import diff_generations
from mygens.core.generation import (
    create_generation,
    delete_generation,
    get_generation,
    list_generations,
    update_generation,
)
from mygens.core.hashing import compute_file_hash
from mygens.core.lineage import get_lineage_tree
from mygens.core.models import (
    Generation,
    GenerationCreate,
    GenerationFilters,
    GenerationUpdate,
    LineageTree,
    OutputCreate,
    Platform,
    PromptDiff,
)
from mygens.core.output import add_output
from mygens.server.deps import get_db

router = APIRouter(prefix="/generations", tags=["generations"])


def _parse_platform(value: str) -> Platform:
    """Safely parse a platform string, defaulting to CUSTOM."""
    try:
        return Platform(value)
    except ValueError:
        return Platform.CUSTOM


@router.post(
    "/",
    response_model=Generation,
    status_code=status.HTTP_201_CREATED,
    summary="Create a generation",
)
def create(
    body: GenerationCreate,
    conn: sqlite3.Connection = Depends(get_db),
) -> Generation:
    """Create a new generation record."""
    return create_generation(conn, body)


@router.post(
    "/upload",
    response_model=Generation,
    status_code=status.HTTP_201_CREATED,
    summary="Create a generation with image or video upload",
)
def create_with_upload(
    prompt_text: str = Form(...),
    platform: str = Form("custom"),
    model: str | None = Form(None),
    tags: str = Form(""),
    notes: str = Form(""),
    image: UploadFile | None = File(None),
    conn: sqlite3.Connection = Depends(get_db),
) -> Generation:
    """Create a generation with optional image/video upload.

    Accepts images (PNG, JPG, WebP) and videos (MP4, WebM, MOV).
    Used by the manual entry panel in the dashboard.
    """
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

    gen = create_generation(conn, GenerationCreate(
        prompt_text=prompt_text,
        platform=_parse_platform(platform),
        model=model or None,
        tags=tag_list,
        notes=notes,
    ))

    # Save uploaded file (image or video)
    if image and image.filename:
        now = datetime.now()
        out_dir = get_outputs_dir() / str(now.year) / f"{now.month:02d}"
        out_dir.mkdir(parents=True, exist_ok=True)

        ext = Path(image.filename).suffix or ".png"
        out_path = out_dir / f"{gen.id}{ext}"

        with open(out_path, "wb") as f:
            shutil.copyfileobj(image.file, f)

        file_hash = compute_file_hash(out_path)
        media_type = image.content_type or "application/octet-stream"

        width, height, duration_ms = None, None, None

        # Image dimensions
        if media_type.startswith("image/"):
            try:
                from PIL import Image
                img = Image.open(out_path)
                width, height = img.size
            except Exception:
                pass

        # Video metadata
        if media_type.startswith("video/"):
            try:
                import struct
                # Quick MP4 duration extraction from moov/mvhd
                with open(out_path, "rb") as vf:
                    data = vf.read()
                # Find 'mvhd' box
                idx = data.find(b"mvhd")
                if idx > 0:
                    version = data[idx + 4]
                    if version == 0:
                        timescale = struct.unpack(">I", data[idx + 16 : idx + 20])[0]
                        duration = struct.unpack(">I", data[idx + 20 : idx + 24])[0]
                        if timescale > 0:
                            duration_ms = int((duration / timescale) * 1000)
                # Find 'tkhd' box for dimensions
                idx = data.find(b"tkhd")
                if idx > 0:
                    version = data[idx + 4]
                    offset = idx + 80 if version == 0 else idx + 92
                    if offset + 8 <= len(data):
                        w = struct.unpack(">I", data[offset : offset + 4])[0] >> 16
                        h = struct.unpack(">I", data[offset + 4 : offset + 8])[0] >> 16
                        if w > 0 and h > 0:
                            width, height = w, h
            except Exception:
                pass

        add_output(conn, gen.id, OutputCreate(
            file_path=str(out_path),
            file_hash=file_hash,
            media_type=media_type,
            width=width,
            height=height,
            duration_ms=duration_ms,
        ))

        # Re-fetch to include the output
        gen = get_generation(conn, gen.id)  # type: ignore[assignment]

    return gen


@router.get("/", response_model=list[Generation], summary="List generations")
def list_all(
    platform: Platform | None = None,
    project_id: str | None = None,
    min_rating: int | None = Query(default=None, ge=0, le=5),
    cursor: str | None = None,
    limit: int = Query(default=50, ge=1, le=200),
    conn: sqlite3.Connection = Depends(get_db),
) -> list[Generation]:
    """List generations with optional filtering and cursor-based pagination."""
    filters = GenerationFilters(
        platform=platform,
        project_id=project_id,
        min_rating=min_rating,
        cursor=cursor,
        limit=limit,
    )
    return list_generations(conn, filters)


@router.get(
    "/{gen_id}",
    response_model=Generation,
    summary="Get a generation",
)
def get_one(
    gen_id: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> Generation:
    """Retrieve a single generation with all its outputs."""
    gen = get_generation(conn, gen_id)
    if gen is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Generation {gen_id} not found",
        )
    return gen


@router.patch(
    "/{gen_id}",
    response_model=Generation,
    summary="Update a generation",
)
def update(
    gen_id: str,
    body: GenerationUpdate,
    conn: sqlite3.Connection = Depends(get_db),
) -> Generation:
    """Update mutable fields of a generation (rating, tags, notes, etc.)."""
    gen = update_generation(conn, gen_id, body)
    if gen is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Generation {gen_id} not found",
        )
    return gen


@router.delete(
    "/{gen_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a generation",
)
def delete(
    gen_id: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> None:
    """Delete a generation and cascade-delete its outputs."""
    deleted = delete_generation(conn, gen_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Generation {gen_id} not found",
        )


@router.get(
    "/{gen_id}/tree",
    response_model=LineageTree,
    summary="Get lineage tree",
)
def tree(
    gen_id: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> LineageTree:
    """Get the full lineage tree (ancestors and descendants) for a generation."""
    result = get_lineage_tree(conn, gen_id)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Generation {gen_id} not found or has no lineage",
        )
    return result


@router.get(
    "/{gen_id}/diff/{other_id}",
    response_model=PromptDiff,
    summary="Diff two generations",
)
def diff(
    gen_id: str,
    other_id: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> PromptDiff:
    """Compute a structured diff between two generations."""
    result = diff_generations(conn, gen_id, other_id)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="One or both generations not found",
        )
    return result
