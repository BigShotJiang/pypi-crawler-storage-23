"""Search endpoint — hybrid keyword + semantic search."""

from __future__ import annotations

import sqlite3

from fastapi import APIRouter, Depends, Query

from mygens.core.models import Generation
from mygens.core.search import hybrid_search
from mygens.server.deps import get_db

router = APIRouter(tags=["search"])


@router.get("/search", response_model=list[Generation], summary="Hybrid search")
def search(
    q: str = Query(..., min_length=1, description="Search query"),
    platform: str | None = None,
    project_id: str | None = None,
    min_rating: int | None = Query(default=None, ge=0, le=5),
    limit: int = Query(default=50, ge=1, le=200),
    conn: sqlite3.Connection = Depends(get_db),
) -> list[Generation]:
    """Search generations using hybrid keyword + semantic search.

    Keyword matches (FTS5) are returned first for exact relevance.
    Semantic matches (embedding similarity) fill in conceptual matches
    that keywords missed — e.g. searching "moody" finds "dark atmospheric shadows".
    """
    return hybrid_search(
        conn,
        query=q,
        platform=platform,
        project_id=project_id,
        min_rating=min_rating,
        limit=limit,
    )
