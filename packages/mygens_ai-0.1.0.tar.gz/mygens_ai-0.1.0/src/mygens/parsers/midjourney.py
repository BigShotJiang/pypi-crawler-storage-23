"""Midjourney metadata parser.

Midjourney stores prompts in EXIF Description/ImageDescription fields.
The prompt includes Midjourney-specific parameters like --ar, --stylize, --v, etc.
"""

from __future__ import annotations

import io

from mygens.parsers.base import ParsedGeneration
from mygens.parsers.png_reader import is_png, read_png_text_chunks


class MidjourneyParser:
    """Parser for Midjourney PNG EXIF metadata."""

    @property
    def name(self) -> str:
        return "Midjourney"

    @property
    def platforms(self) -> list[str]:
        return ["midjourney"]

    def detect(self, buffer: bytes) -> bool:
        """Check if this looks like a Midjourney image."""
        if not is_png(buffer):
            return False

        # Check tEXt chunks first (some MJ images use these)
        try:
            chunks = read_png_text_chunks(buffer)
            desc = chunks.get("Description", "")
            if desc and "--" in desc:
                return True
        except Exception:
            pass

        # Check EXIF via Pillow
        try:
            from PIL import Image
            from PIL.ExifTags import Base as ExifBase

            img = Image.open(io.BytesIO(buffer))
            exif = img.getexif()
            if exif:
                desc = exif.get(ExifBase.ImageDescription, "")
                if isinstance(desc, str) and "--" in desc:
                    return True
        except Exception:
            pass

        return False

    def parse(self, buffer: bytes, file_path: str) -> list[ParsedGeneration]:
        """Extract Midjourney prompt from image metadata."""
        raw_prompt = self._extract_description(buffer)
        if not raw_prompt:
            return []

        return [self._parse_prompt(raw_prompt, file_path)]

    def _extract_description(self, buffer: bytes) -> str | None:
        """Try multiple methods to extract the description."""
        # Method 1: PNG tEXt chunks
        try:
            chunks = read_png_text_chunks(buffer)
            desc = chunks.get("Description", "")
            if desc:
                return desc
        except Exception:
            pass

        # Method 2: EXIF data via Pillow
        try:
            from PIL import Image
            from PIL.ExifTags import Base as ExifBase

            img = Image.open(io.BytesIO(buffer))
            exif = img.getexif()
            if exif:
                desc = exif.get(ExifBase.ImageDescription, "")
                if isinstance(desc, str) and desc:
                    return desc
        except Exception:
            pass

        return None

    def _parse_prompt(self, raw: str, file_path: str) -> ParsedGeneration:
        """Parse a Midjourney prompt string with --parameters."""
        # Split prompt text from parameters
        # MJ params start with -- (e.g., --ar 16:9 --stylize 750 --v 7)
        parts = raw.split(" --")
        prompt_text = parts[0].strip()

        parameters: dict = {}
        seed: int | None = None
        model: str | None = None

        for part in parts[1:]:
            tokens = part.strip().split(None, 1)
            if not tokens:
                continue
            key = tokens[0]
            value = tokens[1] if len(tokens) > 1 else "true"

            parameters[key] = value

            if key == "seed":
                try:
                    seed = int(value)
                except ValueError:
                    pass
            elif key == "v":
                model = f"v{value}"

        return ParsedGeneration(
            prompt_text=prompt_text,
            platform="midjourney",
            model=model,
            seed=seed,
            parameters=parameters,
            source_uri=file_path,
        )
