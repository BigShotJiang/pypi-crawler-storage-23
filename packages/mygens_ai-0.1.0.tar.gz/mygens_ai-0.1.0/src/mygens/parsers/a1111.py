"""Stable Diffusion A1111 WebUI metadata parser.

Parses the `parameters` tEXt chunk embedded in PNG files by Automatic1111.
Format: positive prompt, then "Negative prompt:", then key-value parameters
starting with "Steps:".
"""

from __future__ import annotations

from mygens.parsers.base import ParsedGeneration
from mygens.parsers.png_reader import is_png, read_png_text_chunks


class A1111Parser:
    """Parser for Stable Diffusion A1111 WebUI PNG metadata."""

    @property
    def name(self) -> str:
        return "Stable Diffusion A1111"

    @property
    def platforms(self) -> list[str]:
        return ["sd_a1111"]

    def detect(self, buffer: bytes) -> bool:
        """Check if the PNG has an A1111 `parameters` tEXt chunk."""
        if not is_png(buffer):
            return False
        try:
            chunks = read_png_text_chunks(buffer)
            raw = chunks.get("parameters", "")
            # A1111 metadata always contains "Steps:" in the parameter block
            return "Steps:" in raw
        except Exception:
            return False

    def parse(self, buffer: bytes, file_path: str) -> list[ParsedGeneration]:
        """Extract generation data from A1111 PNG metadata."""
        chunks = read_png_text_chunks(buffer)
        raw = chunks.get("parameters", "")
        if not raw:
            return []

        result = self._parse_raw(raw)
        result.source_uri = file_path
        return [result]

    def _parse_raw(self, raw: str) -> ParsedGeneration:
        """Parse the raw A1111 parameters string.

        Strategy: work bottom-up. Find "Steps:" line first (start of
        parameter block), then identify the negative prompt marker.
        """
        lines = raw.split("\n")

        # Find the parameter block (starts with "Steps:")
        param_start_idx = -1
        for i in range(len(lines) - 1, -1, -1):
            stripped = lines[i].strip()
            if stripped.startswith("Steps:") or stripped.startswith("Steps :"):
                param_start_idx = i
                break

        param_string = ""
        prompt_and_neg = raw

        if param_start_idx != -1:
            param_string = "\n".join(lines[param_start_idx:])
            prompt_and_neg = "\n".join(lines[:param_start_idx]).rstrip()

        # Split positive and negative prompts
        neg_marker = "\nNegative prompt:"
        neg_idx = prompt_and_neg.find(neg_marker)

        prompt_text: str
        negative_prompt: str | None = None

        if neg_idx != -1:
            prompt_text = prompt_and_neg[:neg_idx].strip()
            negative_prompt = prompt_and_neg[neg_idx + len(neg_marker) :].strip()
        else:
            # Try without newline prefix (first line might be the marker)
            if prompt_and_neg.startswith("Negative prompt:"):
                prompt_text = ""
                negative_prompt = prompt_and_neg[len("Negative prompt:") :].strip()
            else:
                prompt_text = prompt_and_neg.strip()

        # Parse key-value parameters
        parameters = self._parse_params(param_string)

        # Extract well-known fields
        seed = None
        if "Seed" in parameters:
            try:
                seed = int(parameters["Seed"])
            except (ValueError, TypeError):
                pass

        model = parameters.get("Model")

        # Build numeric parameters dict
        params_dict: dict = {}
        for key, value in parameters.items():
            # Try to convert numeric values
            try:
                if "." in str(value):
                    params_dict[key] = float(value)
                else:
                    params_dict[key] = int(value)
            except (ValueError, TypeError):
                params_dict[key] = value

        return ParsedGeneration(
            prompt_text=prompt_text,
            negative_prompt=negative_prompt,
            platform="sd_a1111",
            model=model,
            seed=seed,
            parameters=params_dict,
        )

    def _parse_params(self, param_string: str) -> dict[str, str]:
        """Parse comma-separated Key: Value pairs, handling quoted values."""
        result: dict[str, str] = {}
        if not param_string.strip():
            return result

        # Flatten to single line for parsing
        flat = param_string.replace("\n", ", ")

        i = 0
        while i < len(flat):
            # Find next key (word(s) followed by colon)
            colon_idx = flat.find(":", i)
            if colon_idx == -1:
                break

            key = flat[i:colon_idx].strip().lstrip(", ")
            if not key:
                i = colon_idx + 1
                continue

            # Find the value - handle quoted values
            val_start = colon_idx + 1
            while val_start < len(flat) and flat[val_start] == " ":
                val_start += 1

            if val_start < len(flat) and flat[val_start] == '"':
                # Quoted value — find closing quote
                quote_end = flat.find('"', val_start + 1)
                if quote_end == -1:
                    value = flat[val_start + 1 :]
                    i = len(flat)
                else:
                    value = flat[val_start + 1 : quote_end]
                    i = quote_end + 1
            else:
                # Unquoted — find next comma that's followed by a key pattern
                # Look for ", Key:" pattern
                best_end = len(flat)
                search_pos = val_start
                while search_pos < len(flat):
                    comma_idx = flat.find(",", search_pos)
                    if comma_idx == -1:
                        break
                    # Check if what follows the comma looks like a key
                    rest = flat[comma_idx + 1 :].lstrip()
                    next_colon = rest.find(":")
                    if next_colon > 0:
                        potential_key = rest[:next_colon].strip()
                        # A1111 keys are alphanumeric + spaces
                        if potential_key and all(
                            c.isalnum() or c in " _" for c in potential_key
                        ):
                            best_end = comma_idx
                            break
                    search_pos = comma_idx + 1

                value = flat[val_start:best_end].strip()
                i = best_end + 1

            if key:
                result[key] = value

        return result
