"""Parser interface — the contract for all platform parsers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass
class ParsedGeneration:
    """Result of parsing a file — normalized generation data."""

    prompt_text: str
    platform: str
    negative_prompt: str | None = None
    model: str | None = None
    seed: int | None = None
    parameters: dict[str, Any] = field(default_factory=dict)
    source_uri: str | None = None


@runtime_checkable
class Parser(Protocol):
    """Protocol that all platform parsers must implement.

    Community contributors: implement this interface to add support
    for a new platform. See a1111.py for a reference implementation.
    """

    @property
    def name(self) -> str:
        """Human-readable parser name."""
        ...

    @property
    def platforms(self) -> list[str]:
        """Platform identifiers this parser handles."""
        ...

    def detect(self, buffer: bytes) -> bool:
        """Check if this parser can handle the given file data."""
        ...

    def parse(self, buffer: bytes, file_path: str) -> list[ParsedGeneration]:
        """Parse the file and return extracted generation data."""
        ...
