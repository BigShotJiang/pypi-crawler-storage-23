"""Parser registry — auto-detection and lookup."""

from __future__ import annotations

from mygens.parsers.a1111 import A1111Parser
from mygens.parsers.base import ParsedGeneration, Parser
from mygens.parsers.comfyui import ComfyUIParser
from mygens.parsers.midjourney import MidjourneyParser

# All registered parsers, in detection priority order
_PARSERS: list[Parser] = [
    A1111Parser(),
    ComfyUIParser(),
    MidjourneyParser(),
]


def get_parser(name: str) -> Parser | None:
    """Get a parser by name or platform identifier.

    Matches against: parser name, platform IDs, and common aliases.
    """
    name_lower = name.lower().replace(" ", "_").replace("-", "_")
    for parser in _PARSERS:
        # Match full name
        if parser.name.lower().replace(" ", "_") == name_lower:
            return parser
        # Match platform identifiers
        for platform in parser.platforms:
            if platform == name_lower or name_lower in platform or platform in name_lower:
                return parser
    return None


def get_all_parsers() -> list[Parser]:
    """Get all registered parsers."""
    return list(_PARSERS)


def detect_parser(buffer: bytes) -> Parser | None:
    """Auto-detect which parser can handle this file."""
    for parser in _PARSERS:
        try:
            if parser.detect(buffer):
                return parser
        except Exception:
            continue
    return None


def auto_parse(buffer: bytes, file_path: str) -> list[ParsedGeneration]:
    """Auto-detect parser and extract generation data."""
    parser = detect_parser(buffer)
    if parser is None:
        return []
    return parser.parse(buffer, file_path)


def register_parser(parser: Parser) -> None:
    """Register a custom parser (for community extensions)."""
    _PARSERS.append(parser)
