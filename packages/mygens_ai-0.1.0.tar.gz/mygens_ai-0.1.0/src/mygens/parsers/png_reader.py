"""PNG tEXt chunk reader — zero dependencies, pure Python.

Reads tEXt metadata chunks from PNG files. This is how Stable Diffusion (A1111)
and ComfyUI embed generation parameters in images.
"""

from __future__ import annotations

import struct

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def read_png_text_chunks(buffer: bytes) -> dict[str, str]:
    """Extract all tEXt chunks from a PNG file buffer.

    Returns a dict mapping keyword -> text value.
    """
    if not buffer.startswith(PNG_SIGNATURE):
        raise ValueError("Not a valid PNG file")

    chunks: dict[str, str] = {}
    offset = 8  # Skip signature

    while offset < len(buffer):
        if offset + 8 > len(buffer):
            break

        length = struct.unpack(">I", buffer[offset : offset + 4])[0]
        chunk_type = buffer[offset + 4 : offset + 8].decode("ascii", errors="replace")

        if chunk_type == "tEXt":
            data = buffer[offset + 8 : offset + 8 + length]
            null_idx = data.find(0)
            if null_idx != -1:
                keyword = data[:null_idx].decode("latin-1")
                text = data[null_idx + 1 :].decode("latin-1")
                chunks[keyword] = text

        if chunk_type == "IEND":
            break

        # Move to next chunk: length(4) + type(4) + data(length) + crc(4)
        offset += 12 + length

    return chunks


def is_png(buffer: bytes) -> bool:
    """Check if a buffer starts with the PNG signature."""
    return buffer[:8] == PNG_SIGNATURE
