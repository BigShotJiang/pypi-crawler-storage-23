"""ComfyUI workflow metadata parser.

ComfyUI embeds two tEXt chunks in PNG files:
- `prompt`: the execution graph (node IDs → {class_type, inputs})
- `workflow`: the visual graph layout

We walk the execution graph to extract prompt text, model, seed, etc.
"""

from __future__ import annotations

import json
from typing import Any

from mygens.parsers.base import ParsedGeneration
from mygens.parsers.png_reader import is_png, read_png_text_chunks

# Node types we know how to extract data from
SAMPLER_TYPES = {"KSampler", "KSamplerAdvanced", "SamplerCustom"}
TEXT_ENCODE_TYPES = {"CLIPTextEncode"}
CHECKPOINT_TYPES = {"CheckpointLoaderSimple", "CheckpointLoader"}
LORA_TYPES = {"LoraLoader", "LoraLoaderModelOnly"}


class ComfyUIParser:
    """Parser for ComfyUI PNG workflow metadata."""

    @property
    def name(self) -> str:
        return "ComfyUI"

    @property
    def platforms(self) -> list[str]:
        return ["comfyui"]

    def detect(self, buffer: bytes) -> bool:
        """Check if the PNG has ComfyUI metadata."""
        if not is_png(buffer):
            return False
        try:
            chunks = read_png_text_chunks(buffer)
            raw = chunks.get("prompt", "")
            if not raw:
                return False
            data = json.loads(raw)
            # ComfyUI graphs have nodes with class_type
            return any(
                isinstance(v, dict) and "class_type" in v for v in data.values()
            )
        except Exception:
            return False

    def parse(self, buffer: bytes, file_path: str) -> list[ParsedGeneration]:
        """Extract generation data from ComfyUI workflow."""
        chunks = read_png_text_chunks(buffer)
        prompt_raw = chunks.get("prompt", "")
        if not prompt_raw:
            return []

        try:
            graph = json.loads(prompt_raw)
        except json.JSONDecodeError:
            return []

        workflow_raw = chunks.get("workflow")

        result = self._extract_from_graph(graph)
        if result is None:
            return []

        # Store raw workflow data for full fidelity
        result.parameters["_comfyui_prompt"] = graph
        if workflow_raw:
            try:
                result.parameters["_comfyui_workflow"] = json.loads(workflow_raw)
            except json.JSONDecodeError:
                pass

        result.source_uri = file_path
        return [result]

    def _extract_from_graph(
        self, graph: dict[str, Any]
    ) -> ParsedGeneration | None:
        """Walk the ComfyUI execution graph to extract generation params."""
        # Find sampler nodes
        sampler_nodes = [
            (nid, node)
            for nid, node in graph.items()
            if isinstance(node, dict) and node.get("class_type") in SAMPLER_TYPES
        ]

        if not sampler_nodes:
            return None

        # Use the first sampler found
        _sampler_id, sampler = sampler_nodes[0]
        inputs = sampler.get("inputs", {})

        # Extract sampler parameters
        seed = self._get_value(inputs, "seed")
        steps = self._get_value(inputs, "steps")
        cfg = self._get_value(inputs, "cfg")
        sampler_name = self._get_value(inputs, "sampler_name")
        scheduler = self._get_value(inputs, "scheduler")

        # Follow connections to find text prompts
        prompt_text = self._find_text(graph, inputs.get("positive", ""))
        negative_prompt = self._find_text(graph, inputs.get("negative", ""))

        # Follow model chain to find checkpoint name
        model_name = self._find_model(graph, inputs.get("model"))

        params: dict[str, Any] = {}
        if steps is not None:
            params["steps"] = int(steps)
        if cfg is not None:
            params["cfg"] = float(cfg)
        if sampler_name is not None:
            params["sampler_name"] = str(sampler_name)
        if scheduler is not None:
            params["scheduler"] = str(scheduler)

        return ParsedGeneration(
            prompt_text=prompt_text or "",
            negative_prompt=negative_prompt or None,
            platform="comfyui",
            model=str(model_name) if model_name else None,
            seed=int(seed) if seed is not None else None,
            parameters=params,
        )

    def _resolve_node(
        self, graph: dict[str, Any], ref: Any
    ) -> dict[str, Any] | None:
        """Resolve a [nodeId, outputIndex] reference to its node."""
        if isinstance(ref, list) and len(ref) == 2:
            node_id = str(ref[0])
            return graph.get(node_id)
        return None

    def _find_text(self, graph: dict[str, Any], ref: Any) -> str | None:
        """Follow connections to find CLIPTextEncode text."""
        node = self._resolve_node(graph, ref)
        if not node:
            return None

        class_type = node.get("class_type", "")

        if class_type in TEXT_ENCODE_TYPES:
            return str(node.get("inputs", {}).get("text", ""))

        # Recurse through conditioning passthrough nodes
        inputs = node.get("inputs", {})
        for key in ("conditioning", "conditioning1", "positive", "negative"):
            if key in inputs:
                result = self._find_text(graph, inputs[key])
                if result:
                    return result

        return None

    def _find_model(self, graph: dict[str, Any], ref: Any) -> str | None:
        """Follow the model chain to find the checkpoint name."""
        node = self._resolve_node(graph, ref)
        if not node:
            return None

        class_type = node.get("class_type", "")

        if class_type in CHECKPOINT_TYPES:
            name = node.get("inputs", {}).get("ckpt_name", "")
            # Strip .safetensors extension for cleaner display
            if isinstance(name, str) and name.endswith(".safetensors"):
                name = name[: -len(".safetensors")]
            return name

        # LoRA loaders pass through the model
        if class_type in LORA_TYPES:
            return self._find_model(graph, node.get("inputs", {}).get("model"))

        return None

    def _get_value(self, inputs: dict, key: str) -> Any:
        """Get a direct value (not a connection reference) from inputs."""
        val = inputs.get(key)
        if isinstance(val, list):
            return None  # This is a connection, not a value
        return val
