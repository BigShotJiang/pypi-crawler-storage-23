"""Replicate integration — sync predictions into MyGens.

Replicate hosts models like Flux, CogVideoX, LTX-Video, Luma Ray, Minimax.
This pulls your generation history via their API and imports it.

API docs: https://replicate.com/docs/reference/http

IMPORTANT: Replicate removes input/output data after 1 hour for API predictions.
Web predictions (source=web) retain data for 14 days. Sync frequently.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any
from urllib.request import Request, urlopen

from mygens.core.generation import create_generation
from mygens.core.models import GenerationCreate, OutputCreate, Platform
from mygens.core.output import add_output


REPLICATE_API_BASE = "https://api.replicate.com/v1"

# Known video models on Replicate
VIDEO_MODELS = {
    "luma/ray", "minimax/video-01", "tencent/hunyuan-video",
    "lightricks/ltx-video", "genmo/mochi-1-preview",
    "cjwbw/cogvideo", "lucataco/animate-diff",
}


def sync_replicate(
    conn: sqlite3.Connection,
    api_token: str,
    max_pages: int = 5,
    on_progress: callable | None = None,
) -> dict[str, int]:
    """Sync recent predictions from Replicate into MyGens.

    Returns a dict with counts: imported, skipped, failed.
    """
    stats = {"imported": 0, "skipped": 0, "failed": 0, "total_fetched": 0}
    url: str | None = f"{REPLICATE_API_BASE}/predictions"
    page = 0

    while url and page < max_pages:
        data = _api_get(url, api_token)
        predictions = data.get("results", [])
        stats["total_fetched"] += len(predictions)

        for pred in predictions:
            try:
                result = _import_prediction(conn, pred, api_token)
                if result == "imported":
                    stats["imported"] += 1
                elif result == "skipped":
                    stats["skipped"] += 1
            except Exception:
                stats["failed"] += 1

        if on_progress:
            on_progress(stats)

        url = data.get("next")
        page += 1

    return stats


def _import_prediction(
    conn: sqlite3.Connection,
    pred: dict[str, Any],
    api_token: str,
) -> str:
    """Import a single Replicate prediction. Returns 'imported' or 'skipped'."""
    # Skip non-succeeded predictions
    if pred.get("status") != "succeeded":
        return "skipped"

    # Skip if data was removed
    if pred.get("data_removed") or not pred.get("input"):
        return "skipped"

    inp = pred.get("input", {})
    output = pred.get("output")

    # Extract prompt from input — Replicate models use 'prompt' key
    prompt_text = inp.get("prompt", "")
    if not prompt_text:
        # Some models use different keys
        prompt_text = inp.get("text", "") or inp.get("description", "")
    if not prompt_text:
        return "skipped"

    # Determine model info
    model_name = pred.get("model") or ""
    model_version = pred.get("version", "")[:12] if pred.get("version") else ""

    # Determine if this is a video or image model
    is_video = model_name in VIDEO_MODELS

    # Build parameters from input (exclude prompt and image/video inputs)
    params = {}
    skip_keys = {"prompt", "text", "description", "image", "video", "audio"}
    for key, val in inp.items():
        if key not in skip_keys and not isinstance(val, (bytes, bytearray)):
            params[key] = val

    # Add replicate-specific metadata
    params["_replicate_id"] = pred.get("id", "")
    params["_replicate_source"] = pred.get("source", "")
    if pred.get("metrics", {}).get("predict_time"):
        params["_predict_time"] = pred["metrics"]["predict_time"]

    # Determine platform
    platform = Platform.RUNWAY if is_video else Platform.CUSTOM

    # Parse created_at
    created_at = None
    if pred.get("created_at"):
        try:
            created_at = datetime.fromisoformat(pred["created_at"].replace("Z", "+00:00"))
        except Exception:
            pass

    # Create the generation
    gen = create_generation(conn, GenerationCreate(
        prompt_text=prompt_text,
        negative_prompt=inp.get("negative_prompt"),
        platform=platform,
        model=model_name,
        seed=inp.get("seed"),
        parameters=params,
        tags=["replicate", model_name.split("/")[-1]] if model_name else ["replicate"],
        source_uri=f"https://replicate.com/p/{pred.get('id', '')}",
        created_at=created_at,
    ))

    # Store output URLs as references (no download — saves disk)
    if output:
        _store_output_refs(conn, gen.id, output, is_video)

    return "imported"


def _store_output_refs(
    conn: sqlite3.Connection,
    gen_id: str,
    output: Any,
    is_video: bool,
) -> None:
    """Store output URLs as references without downloading."""
    urls: list[str] = []

    if isinstance(output, str) and output.startswith("http"):
        urls.append(output)
    elif isinstance(output, list):
        for item in output:
            if isinstance(item, str) and item.startswith("http"):
                urls.append(item)
    elif isinstance(output, dict):
        for val in output.values():
            if isinstance(val, str) and val.startswith("http"):
                urls.append(val)
            elif isinstance(val, list):
                for item in val:
                    if isinstance(item, str) and item.startswith("http"):
                        urls.append(item)

    for url in urls[:4]:
        media_type = _guess_media_type(url, is_video)
        add_output(conn, gen_id, OutputCreate(
            url=url,
            media_type=media_type,
        ))


def _guess_media_type(url: str, is_video: bool) -> str:
    """Guess media type from URL extension."""
    path = url.split("?")[0].lower()
    if path.endswith(".mp4"):
        return "video/mp4"
    elif path.endswith(".webm"):
        return "video/webm"
    elif path.endswith(".mov"):
        return "video/quicktime"
    elif path.endswith(".png"):
        return "image/png"
    elif path.endswith(".jpg") or path.endswith(".jpeg"):
        return "image/jpeg"
    elif path.endswith(".webp"):
        return "image/webp"
    return "video/mp4" if is_video else "image/png"


def _api_get(url: str, token: str) -> dict:
    """Make a GET request to the Replicate API."""
    req = Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Content-Type", "application/json")
    with urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())
