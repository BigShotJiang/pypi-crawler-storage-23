"""fal.ai integration — sync request history into MyGens.

fal.ai hosts models like Flux, CogVideoX, Kling, AnimateDiff, and more.
This pulls your generation history via their API and imports it.

API docs: https://docs.fal.ai/platform-apis/v1/models/requests/by-endpoint
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any
from urllib.request import Request, urlopen

from mygens.core.generation import create_generation
from mygens.core.models import GenerationCreate, OutputCreate, Platform
from mygens.core.output import add_output


FAL_API_BASE = "https://api.fal.ai/v1"

# Known video endpoints on fal.ai
VIDEO_ENDPOINTS = {
    "fal-ai/cogvideox", "fal-ai/kling-video", "fal-ai/minimax-video",
    "fal-ai/luma-dream-machine", "fal-ai/animate-diff",
    "fal-ai/stable-video-diffusion", "fal-ai/mochi-1",
}

# Map fal endpoint to a readable model name
ENDPOINT_LABELS = {
    "fal-ai/flux/dev": "Flux Dev",
    "fal-ai/flux/pro": "Flux Pro",
    "fal-ai/flux-lora": "Flux LoRA",
    "fal-ai/cogvideox": "CogVideoX",
    "fal-ai/kling-video": "Kling",
    "fal-ai/minimax-video": "Minimax",
    "fal-ai/luma-dream-machine": "Luma",
    "fal-ai/stable-video-diffusion": "SVD",
}


def sync_fal(
    conn: sqlite3.Connection,
    api_key: str,
    endpoint_ids: list[str] | None = None,
    max_requests: int = 100,
    on_progress: callable | None = None,
) -> dict[str, int]:
    """Sync recent requests from fal.ai into MyGens.

    If endpoint_ids is None, syncs common endpoints.
    Returns a dict with counts: imported, skipped, failed.
    """
    if endpoint_ids is None:
        # Default: sync the most popular endpoints
        endpoint_ids = [
            "fal-ai/flux/dev", "fal-ai/flux/pro", "fal-ai/flux-lora",
            "fal-ai/cogvideox", "fal-ai/kling-video",
            "fal-ai/minimax-video", "fal-ai/luma-dream-machine",
        ]

    stats = {"imported": 0, "skipped": 0, "failed": 0, "total_fetched": 0}

    for endpoint_id in endpoint_ids:
        try:
            endpoint_stats = _sync_endpoint(
                conn, api_key, endpoint_id, max_requests
            )
            stats["imported"] += endpoint_stats["imported"]
            stats["skipped"] += endpoint_stats["skipped"]
            stats["failed"] += endpoint_stats["failed"]
            stats["total_fetched"] += endpoint_stats["total_fetched"]
        except Exception:
            stats["failed"] += 1

        if on_progress:
            on_progress(stats, endpoint_id)

    return stats


def _sync_endpoint(
    conn: sqlite3.Connection,
    api_key: str,
    endpoint_id: str,
    max_requests: int,
) -> dict[str, int]:
    """Sync requests from a single fal.ai endpoint."""
    stats = {"imported": 0, "skipped": 0, "failed": 0, "total_fetched": 0}

    url = (
        f"{FAL_API_BASE}/models/requests/by-endpoint"
        f"?endpoint_id={endpoint_id}&expand=payloads&limit={min(max_requests, 100)}"
    )

    data = _api_get(url, api_key)
    requests_list = data if isinstance(data, list) else data.get("items", data.get("results", []))
    stats["total_fetched"] = len(requests_list)

    for req in requests_list:
        try:
            result = _import_request(conn, req, api_key, endpoint_id)
            if result == "imported":
                stats["imported"] += 1
            elif result == "skipped":
                stats["skipped"] += 1
        except Exception:
            stats["failed"] += 1

    return stats


def _import_request(
    conn: sqlite3.Connection,
    req: dict[str, Any],
    api_key: str,
    endpoint_id: str,
) -> str:
    """Import a single fal.ai request. Returns 'imported' or 'skipped'."""
    # Skip non-successful requests
    status = req.get("status_code", 200)
    if status != 200:
        return "skipped"

    inp = req.get("json_input") or {}
    output = req.get("json_output") or {}

    # Extract prompt
    prompt_text = inp.get("prompt", "")
    if not prompt_text:
        prompt_text = inp.get("text", "") or inp.get("description", "")
    if not prompt_text:
        return "skipped"

    # Determine if video
    is_video = endpoint_id in VIDEO_ENDPOINTS

    # Build parameters
    params = {}
    skip_keys = {"prompt", "text", "description", "image", "video", "image_url", "video_url"}
    for key, val in inp.items():
        if key not in skip_keys and not isinstance(val, (bytes, bytearray)):
            params[key] = val

    params["_fal_request_id"] = req.get("request_id", "")
    params["_fal_endpoint"] = endpoint_id
    if req.get("duration"):
        params["_duration"] = req["duration"]

    # Model label
    model_name = ENDPOINT_LABELS.get(endpoint_id, endpoint_id.split("/")[-1])
    short_endpoint = endpoint_id.replace("fal-ai/", "")

    # Platform
    platform = Platform.CUSTOM
    if is_video:
        if "kling" in endpoint_id:
            platform = Platform.KLING
        elif "sora" in endpoint_id:
            platform = Platform.SORA
        else:
            platform = Platform.RUNWAY  # Generic video

    # Parse created_at
    created_at = None
    for time_key in ("started_at", "sent_at", "ended_at"):
        if req.get(time_key):
            try:
                created_at = datetime.fromisoformat(req[time_key].replace("Z", "+00:00"))
                break
            except Exception:
                pass

    gen = create_generation(conn, GenerationCreate(
        prompt_text=prompt_text,
        negative_prompt=inp.get("negative_prompt"),
        platform=platform,
        model=model_name,
        seed=inp.get("seed"),
        parameters=params,
        tags=["fal", short_endpoint],
        source_uri=f"https://fal.ai/models/{endpoint_id}",
        created_at=created_at,
    ))

    # Store output URLs as references (no download)
    _store_output_refs(conn, gen.id, output, is_video)

    return "imported"


def _store_output_refs(
    conn: sqlite3.Connection,
    gen_id: str,
    output: dict[str, Any],
    is_video: bool,
) -> None:
    """Store output URLs as references without downloading."""
    urls: list[str] = []

    for key, val in output.items():
        if isinstance(val, dict) and "url" in val:
            urls.append(val["url"])
        elif isinstance(val, list):
            for item in val:
                if isinstance(item, dict) and "url" in item:
                    urls.append(item["url"])
                elif isinstance(item, str) and item.startswith("http"):
                    urls.append(item)
        elif isinstance(val, str) and val.startswith("http"):
            urls.append(val)

    for url in urls[:4]:
        path = url.split("?")[0].lower()
        if path.endswith(".mp4") or path.endswith(".webm") or path.endswith(".mov"):
            media_type = "video/mp4"
        elif path.endswith(".png"):
            media_type = "image/png"
        elif path.endswith(".jpg") or path.endswith(".jpeg"):
            media_type = "image/jpeg"
        else:
            media_type = "video/mp4" if is_video else "image/png"

        add_output(conn, gen_id, OutputCreate(
            url=url,
            media_type=media_type,
        ))


def _api_get(url: str, api_key: str) -> Any:
    """Make a GET request to the fal.ai API."""
    req = Request(url)
    req.add_header("Authorization", f"Key {api_key}")
    with urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())
