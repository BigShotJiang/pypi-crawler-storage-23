"""Webhook receiver — real-time capture from Replicate and other platforms.

When a user sets up a webhook on Replicate pointing to:
  http://localhost:9753/api/v1/webhooks/replicate

Every completed prediction is automatically imported into MyGens.
"""

from __future__ import annotations

import json
import os
import sqlite3
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status

from mygens.core.generation import create_generation
from mygens.core.models import GenerationCreate, Platform
from mygens.server.deps import get_db

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


def _verify_webhook_auth(request: Request) -> None:
    """Check bearer token if MYGENS_WEBHOOK_SECRET is set."""
    secret = os.environ.get("MYGENS_WEBHOOK_SECRET")
    if not secret:
        return  # No secret configured — allow all (local-only use case)
    auth_header = request.headers.get("Authorization", "")
    if auth_header != f"Bearer {secret}":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing webhook authentication",
        )


@router.post("/replicate", summary="Replicate webhook receiver")
async def replicate_webhook(
    request: Request,
    conn: sqlite3.Connection = Depends(get_db),
) -> dict:
    """Receive a prediction webhook from Replicate.

    Set your Replicate webhook URL to:
      http://localhost:9753/api/v1/webhooks/replicate

    This auto-imports every completed prediction.
    """
    _verify_webhook_auth(request)
    body = await request.json()
    result = _process_replicate_webhook(conn, body)
    return {"status": "ok", "result": result}


@router.post("/generic", summary="Generic webhook receiver")
async def generic_webhook(
    request: Request,
    conn: sqlite3.Connection = Depends(get_db),
) -> dict:
    """Receive a generic webhook with prompt + output data.

    Accepts JSON with at minimum:
      {"prompt": "...", "platform": "...", "output_url": "..."}

    This allows any platform or script to push data into MyGens.
    """
    _verify_webhook_auth(request)
    body = await request.json()
    result = _process_generic_webhook(conn, body)
    return {"status": "ok", "result": result}


def _process_replicate_webhook(conn: sqlite3.Connection, body: dict) -> str:
    """Process a Replicate prediction webhook payload."""
    if body.get("status") != "succeeded":
        return "skipped_not_succeeded"

    inp = body.get("input", {})
    prompt_text = inp.get("prompt", "") or inp.get("text", "")
    if not prompt_text:
        return "skipped_no_prompt"

    model_name = body.get("model", "")

    params: dict[str, Any] = {}
    for key, val in inp.items():
        if key not in ("prompt", "text", "image", "video") and not isinstance(val, (bytes, bytearray)):
            params[key] = val
    params["_replicate_id"] = body.get("id", "")

    create_generation(conn, GenerationCreate(
        prompt_text=prompt_text,
        negative_prompt=inp.get("negative_prompt"),
        platform=Platform.CUSTOM,
        model=model_name,
        seed=inp.get("seed"),
        parameters=params,
        tags=["replicate", "webhook"],
        source_uri=f"https://replicate.com/p/{body.get('id', '')}",
    ))

    return "imported"


def _process_generic_webhook(conn: sqlite3.Connection, body: dict) -> str:
    """Process a generic webhook payload."""
    prompt_text = body.get("prompt", "") or body.get("prompt_text", "")
    if not prompt_text:
        return "skipped_no_prompt"

    platform_str = body.get("platform", "custom")
    try:
        platform = Platform(platform_str)
    except ValueError:
        platform = Platform.CUSTOM

    create_generation(conn, GenerationCreate(
        prompt_text=prompt_text,
        negative_prompt=body.get("negative_prompt"),
        platform=platform,
        model=body.get("model"),
        seed=body.get("seed"),
        parameters=body.get("parameters", {}),
        tags=body.get("tags", ["webhook"]),
        notes=body.get("notes", ""),
    ))

    return "imported"
