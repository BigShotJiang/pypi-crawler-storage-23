"""MyGens CLI — the main entry point."""

from __future__ import annotations

import typer
from rich.console import Console

from mygens import __version__

app = typer.Typer(
    name="mygens",
    help="The lab notebook for generative AI — track, version, and visualize every prompt.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
console = Console()


def version_callback(value: bool) -> None:
    if value:
        console.print(f"mygens {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """MyGens — never lose a prompt again."""


# --- Register commands ---

from mygens.cli.commands.init import init_cmd  # noqa: E402
from mygens.cli.commands.log import log_cmd  # noqa: E402
from mygens.cli.commands.scan import scan_cmd  # noqa: E402
from mygens.cli.commands.search import search_cmd  # noqa: E402
from mygens.cli.commands.list_cmd import list_cmd  # noqa: E402
from mygens.cli.commands.diff import diff_cmd  # noqa: E402
from mygens.cli.commands.tree import tree_cmd  # noqa: E402
from mygens.cli.commands.serve import serve_cmd  # noqa: E402
from mygens.cli.commands.rate import rate_cmd  # noqa: E402
from mygens.cli.commands.tag import tag_cmd  # noqa: E402
from mygens.cli.commands.stats import stats_cmd  # noqa: E402
from mygens.cli.commands.link import link_cmd  # noqa: E402
from mygens.cli.commands.sync import sync_cmd  # noqa: E402

app.command("init")(init_cmd)
app.command("log")(log_cmd)
app.command("scan")(scan_cmd)
app.command("search")(search_cmd)
app.command("list")(list_cmd)
app.command("diff")(diff_cmd)
app.command("tree")(tree_cmd)
app.command("serve")(serve_cmd)
app.command("rate")(rate_cmd)
app.command("tag")(tag_cmd)
app.command("stats")(stats_cmd)
app.command("link")(link_cmd)
app.command("sync")(sync_cmd)


def main() -> None:
    app()
