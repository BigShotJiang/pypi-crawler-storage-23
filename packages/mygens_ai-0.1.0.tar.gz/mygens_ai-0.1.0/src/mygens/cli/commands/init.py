"""Initialize the MyGens home directory and database."""

from __future__ import annotations

import typer
from rich.console import Console

from mygens.core.config import ensure_home_dir, get_db_path, get_home_dir
from mygens.core.db import get_connection, init_db

console = Console()


def init_cmd() -> None:
    """Initialize ~/.mygens with database and directory structure."""
    try:
        home = ensure_home_dir()

        db_path = get_db_path()
        conn = get_connection(db_path)
        init_db(conn)
        conn.close()

        console.print()
        console.print("[bold green]MyGens initialized successfully![/bold green]")
        console.print()
        console.print(f"  Home directory:  [cyan]{home}[/cyan]")
        console.print(f"  Database:        [cyan]{db_path}[/cyan]")
        console.print(f"  Outputs:         [cyan]{home / 'outputs'}[/cyan]")
        console.print(f"  Thumbnails:      [cyan]{home / 'thumbnails'}[/cyan]")
        console.print(f"  Exports:         [cyan]{home / 'exports'}[/cyan]")
        console.print()
        console.print("Run [bold]mygens scan <directory>[/bold] to import your first images.")

    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] Failed to initialize: {e}")
        raise typer.Exit(1)
