"""Hybrid search — keyword + semantic."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.search import full_text_search, hybrid_search

console = Console()


def search_cmd(
    query: str = typer.Argument(..., help="Search query."),
    platform: Optional[str] = typer.Option(
        None, "--platform", "-p", help="Filter by platform."
    ),
    limit: int = typer.Option(
        20, "--limit", "-l", help="Maximum results.", min=1, max=200
    ),
    semantic: bool = typer.Option(
        True, "--semantic/--no-semantic", help="Include semantic (meaning-based) results."
    ),
) -> None:
    """Search prompts — finds both exact keyword matches and semantically similar prompts."""
    try:
        conn = get_connection(get_db_path())

        if semantic:
            results = hybrid_search(
                conn, query=query, platform=platform, limit=limit,
            )
        else:
            results = full_text_search(
                conn, query=query, platform=platform, limit=limit,
            )

        conn.close()

        if not results:
            console.print("No results found.")
            raise typer.Exit(0)

        table = Table(title=f"Search results for: {query}")
        table.add_column("ID", style="cyan", no_wrap=True, max_width=12)
        table.add_column("Platform", style="magenta")
        table.add_column("Model", style="blue")
        table.add_column("Rating", justify="center")
        table.add_column("Prompt", max_width=60)
        table.add_column("Tags", style="green")

        for gen in results:
            prompt_preview = gen.prompt_text[:60] + ("..." if len(gen.prompt_text) > 60 else "")
            rating_str = f"{'*' * gen.rating}{'.' * (5 - gen.rating)}" if gen.rating else "-"
            tags_str = ", ".join(gen.tags) if gen.tags else "-"

            table.add_row(
                gen.id[:12],
                gen.platform.value,
                gen.model or "-",
                rating_str,
                prompt_preview,
                tags_str,
            )

        console.print(table)
        console.print(f"\n[dim]{len(results)} result(s) found.[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
