"""Rate a generation (0-5 stars)."""

from __future__ import annotations

import typer
from rich.console import Console

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.generation import update_generation
from mygens.core.models import GenerationUpdate

console = Console()


def rate_cmd(
    gen_id: str = typer.Argument(..., help="Generation ID to rate."),
    rating: int = typer.Argument(..., help="Rating from 0 to 5.", min=0, max=5),
) -> None:
    """Rate a generation on a 0-5 scale."""
    try:
        conn = get_connection(get_db_path())

        data = GenerationUpdate(rating=rating)
        gen = update_generation(conn, gen_id, data)
        conn.close()

        if gen is None:
            console.print(f"[bold red]Error:[/bold red] Generation not found: {gen_id}")
            raise typer.Exit(1)

        stars = "*" * rating + "." * (5 - rating)
        console.print(f"[bold green]Rated[/bold green] [cyan]{gen_id[:12]}[/cyan] [{stars}] ({rating}/5)")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
