"""Show dashboard statistics for the MyGens database."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from mygens.core.config import get_db_path
from mygens.core.db import get_connection

console = Console()


def stats_cmd() -> None:
    """Display summary statistics for your prompt library."""
    try:
        conn = get_connection(get_db_path())

        # Total generations
        total_generations = conn.execute("SELECT count(*) FROM generations").fetchone()[0]

        # Total outputs
        total_outputs = conn.execute("SELECT count(*) FROM outputs").fetchone()[0]

        # Total projects
        total_projects = conn.execute(
            "SELECT count(*) FROM projects WHERE archived = 0"
        ).fetchone()[0]

        # By platform
        platform_rows = conn.execute(
            "SELECT platform, count(*) as cnt FROM generations GROUP BY platform ORDER BY cnt DESC"
        ).fetchall()

        # By rating
        rating_rows = conn.execute(
            "SELECT rating, count(*) as cnt FROM generations GROUP BY rating ORDER BY rating DESC"
        ).fetchall()

        # Top models
        model_rows = conn.execute(
            "SELECT model, count(*) as cnt FROM generations "
            "WHERE model IS NOT NULL GROUP BY model ORDER BY cnt DESC LIMIT 10"
        ).fetchall()

        # Most used tags
        tag_rows = conn.execute(
            "SELECT value as tag, count(*) as cnt FROM generations, json_each(generations.tags) "
            "GROUP BY value ORDER BY cnt DESC LIMIT 10"
        ).fetchall()

        conn.close()

        # Build the display
        console.print()

        # Overview panel
        overview = Table.grid(padding=(0, 2))
        overview.add_column(style="bold")
        overview.add_column(style="cyan", justify="right")
        overview.add_row("Total generations", str(total_generations))
        overview.add_row("Total outputs", str(total_outputs))
        overview.add_row("Active projects", str(total_projects))
        console.print(Panel(overview, title="[bold]MyGens Dashboard[/bold]", border_style="blue"))

        # Platform breakdown
        if platform_rows:
            platform_table = Table(title="By Platform")
            platform_table.add_column("Platform", style="magenta")
            platform_table.add_column("Count", justify="right", style="cyan")
            for row in platform_rows:
                platform_table.add_row(row["platform"], str(row["cnt"]))
            console.print(platform_table)

        # Rating breakdown
        if rating_rows:
            rating_table = Table(title="By Rating")
            rating_table.add_column("Rating", style="yellow")
            rating_table.add_column("Count", justify="right", style="cyan")
            for row in rating_rows:
                stars = "*" * row["rating"] + "." * (5 - row["rating"])
                rating_table.add_row(f"{stars} ({row['rating']})", str(row["cnt"]))
            console.print(rating_table)

        # Top models
        if model_rows:
            model_table = Table(title="Top Models")
            model_table.add_column("Model", style="blue")
            model_table.add_column("Count", justify="right", style="cyan")
            for row in model_rows:
                model_table.add_row(row["model"], str(row["cnt"]))
            console.print(model_table)

        # Top tags
        if tag_rows:
            tag_table = Table(title="Top Tags")
            tag_table.add_column("Tag", style="green")
            tag_table.add_column("Count", justify="right", style="cyan")
            for row in tag_rows:
                tag_table.add_row(row["tag"], str(row["cnt"]))
            console.print(tag_table)

        if total_generations == 0:
            console.print()
            console.print(
                "[dim]No generations yet. Run [bold]mygens scan <dir>[/bold] "
                "or [bold]mygens log <prompt>[/bold] to get started.[/dim]"
            )

        console.print()

    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
