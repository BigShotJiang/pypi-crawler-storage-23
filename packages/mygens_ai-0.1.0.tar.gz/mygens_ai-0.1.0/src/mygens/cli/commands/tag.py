"""Add tags to a generation."""

from __future__ import annotations

import typer
from rich.console import Console

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.generation import get_generation, update_generation
from mygens.core.models import GenerationUpdate

console = Console()


def tag_cmd(
    gen_id: str = typer.Argument(..., help="Generation ID to tag."),
    tags: str = typer.Argument(..., help="Comma-separated tags to add."),
) -> None:
    """Add tags to a generation (comma-separated)."""
    try:
        conn = get_connection(get_db_path())

        gen = get_generation(conn, gen_id)
        if gen is None:
            console.print(f"[bold red]Error:[/bold red] Generation not found: {gen_id}")
            conn.close()
            raise typer.Exit(1)

        new_tags = [t.strip() for t in tags.split(",") if t.strip()]
        if not new_tags:
            console.print("[bold red]Error:[/bold red] No valid tags provided.")
            conn.close()
            raise typer.Exit(1)

        # Merge with existing tags, dedup while preserving order
        existing = list(gen.tags)
        merged = list(existing)
        added = []
        for tag in new_tags:
            if tag not in merged:
                merged.append(tag)
                added.append(tag)

        data = GenerationUpdate(tags=merged)
        update_generation(conn, gen_id, data)
        conn.close()

        if added:
            console.print(
                f"[bold green]Tagged[/bold green] [cyan]{gen_id[:12]}[/cyan] "
                f"with: [green]{', '.join(added)}[/green]"
            )
        else:
            console.print(
                f"[yellow]All tags already present on[/yellow] [cyan]{gen_id[:12]}[/cyan]"
            )

        console.print(f"[dim]All tags: {', '.join(merged)}[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
