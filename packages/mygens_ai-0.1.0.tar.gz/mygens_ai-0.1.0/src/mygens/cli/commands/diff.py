"""Show a diff between two generations."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.text import Text

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.diff import diff_generations

console = Console()


def diff_cmd(
    id1: str = typer.Argument(..., help="First generation ID (left side)."),
    id2: str = typer.Argument(..., help="Second generation ID (right side)."),
) -> None:
    """Show a word-level diff between two generations."""
    try:
        conn = get_connection(get_db_path())

        result = diff_generations(conn, id1, id2)
        conn.close()

        if result is None:
            console.print("[bold red]Error:[/bold red] One or both generation IDs not found.")
            raise typer.Exit(1)

        # Prompt diff
        console.print()
        console.print("[bold]Prompt diff:[/bold]")
        console.print(f"  [dim]Left:  {id1}[/dim]")
        console.print(f"  [dim]Right: {id2}[/dim]")
        console.print()

        diff_text = Text()
        for segment in result.prompt_diff:
            if segment.type == "equal":
                diff_text.append(segment.text + " ")
            elif segment.type == "insert":
                diff_text.append(segment.text + " ", style="bold green")
            elif segment.type == "delete":
                diff_text.append(segment.text + " ", style="bold red strikethrough")

        console.print(diff_text)

        # Negative prompt diff
        if result.negative_prompt_diff:
            console.print()
            console.print("[bold]Negative prompt diff:[/bold]")
            neg_text = Text()
            for segment in result.negative_prompt_diff:
                if segment.type == "equal":
                    neg_text.append(segment.text + " ")
                elif segment.type == "insert":
                    neg_text.append(segment.text + " ", style="bold green")
                elif segment.type == "delete":
                    neg_text.append(segment.text + " ", style="bold red strikethrough")
            console.print(neg_text)

        # Parameter changes
        changed_params = [p for p in result.parameter_changes if p.change_type != "unchanged"]
        if changed_params:
            console.print()
            console.print("[bold]Parameter changes:[/bold]")
            for param in changed_params:
                if param.change_type == "added":
                    console.print(f"  [green]+ {param.key}: {param.right_value}[/green]")
                elif param.change_type == "removed":
                    console.print(f"  [red]- {param.key}: {param.left_value}[/red]")
                elif param.change_type == "changed":
                    console.print(
                        f"  [yellow]~ {param.key}: {param.left_value} -> {param.right_value}[/yellow]"
                    )

        # Rating delta
        if result.rating_delta is not None:
            console.print()
            delta_str = f"+{result.rating_delta}" if result.rating_delta > 0 else str(result.rating_delta)
            color = "green" if result.rating_delta > 0 else ("red" if result.rating_delta < 0 else "dim")
            console.print(f"[bold]Rating delta:[/bold] [{color}]{delta_str}[/{color}]")

        # Platform change
        if result.platform_changed:
            console.print()
            console.print("[bold yellow]Platform changed between these generations.[/bold yellow]")

        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
