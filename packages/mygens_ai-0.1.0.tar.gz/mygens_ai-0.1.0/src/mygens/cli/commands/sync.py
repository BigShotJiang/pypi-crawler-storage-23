"""Sync generations from external platforms (Replicate, fal.ai)."""

from __future__ import annotations

import os
from typing import Optional

import typer
from rich.console import Console

from mygens.core.config import get_db_path
from mygens.core.db import get_connection, init_db

console = Console()


def sync_cmd(
    platform: str = typer.Argument(
        ...,
        help="Platform to sync from: replicate, fal",
    ),
    token: Optional[str] = typer.Option(
        None, "--token", "-t",
        help="API token. Or set REPLICATE_API_TOKEN / FAL_KEY env var.",
    ),
    max_items: int = typer.Option(
        100, "--max", "-m",
        help="Maximum number of items to sync.",
    ),
) -> None:
    """Import your generation history from Replicate or fal.ai.

    Examples:
        mygens sync replicate --token r8_...
        mygens sync fal --token <your-fal-key>

    Set env vars to avoid passing tokens:
        export REPLICATE_API_TOKEN=r8_...
        export FAL_KEY=...
    """
    platform_lower = platform.lower().strip()

    if platform_lower == "replicate":
        _sync_replicate(token, max_items)
    elif platform_lower == "fal":
        _sync_fal(token, max_items)
    else:
        console.print(f"[bold red]Unknown platform:[/bold red] {platform}")
        console.print("Supported: replicate, fal")
        raise typer.Exit(1)


def _sync_replicate(token: str | None, max_items: int) -> None:
    api_token = token or os.environ.get("REPLICATE_API_TOKEN")
    if not api_token:
        console.print("[bold red]Error:[/bold red] No Replicate API token provided.")
        console.print("  Pass --token or set REPLICATE_API_TOKEN env var.")
        console.print("  Get your token at: [link=https://replicate.com/account/api-tokens]https://replicate.com/account/api-tokens[/link]")
        raise typer.Exit(1)

    console.print()
    console.print("[bold]Syncing from Replicate...[/bold]")
    console.print()

    conn = get_connection(get_db_path())
    init_db(conn)

    from mygens.integrations.replicate import sync_replicate

    def on_progress(stats: dict) -> None:
        console.print(
            f"  Fetched {stats['total_fetched']} predictions, "
            f"imported {stats['imported']}, "
            f"skipped {stats['skipped']}",
            end="\r",
        )

    stats = sync_replicate(
        conn, api_token,
        max_pages=max(1, max_items // 100),
        on_progress=on_progress,
    )
    conn.close()

    console.print()
    console.print()
    console.print(f"  [green]Imported:[/green]  {stats['imported']} generation(s)")
    console.print(f"  [dim]Skipped:[/dim]   {stats['skipped']} (no prompt, already imported, or failed)")
    console.print(f"  [dim]Fetched:[/dim]   {stats['total_fetched']} total predictions checked")
    console.print()


def _sync_fal(token: str | None, max_items: int) -> None:
    api_key = token or os.environ.get("FAL_KEY")
    if not api_key:
        console.print("[bold red]Error:[/bold red] No fal.ai API key provided.")
        console.print("  Pass --token or set FAL_KEY env var.")
        console.print("  Get your key at: [link=https://fal.ai/dashboard/keys]https://fal.ai/dashboard/keys[/link]")
        raise typer.Exit(1)

    console.print()
    console.print("[bold]Syncing from fal.ai...[/bold]")
    console.print()

    conn = get_connection(get_db_path())
    init_db(conn)

    from mygens.integrations.fal import sync_fal

    def on_progress(stats: dict, endpoint: str) -> None:
        console.print(
            f"  [{endpoint}] imported {stats['imported']}, skipped {stats['skipped']}"
        )

    stats = sync_fal(
        conn, api_key,
        max_requests=max_items,
        on_progress=on_progress,
    )
    conn.close()

    console.print()
    console.print(f"  [green]Imported:[/green]  {stats['imported']} generation(s)")
    console.print(f"  [dim]Skipped:[/dim]   {stats['skipped']}")
    console.print(f"  [dim]Fetched:[/dim]   {stats['total_fetched']} total requests checked")
    console.print()
