"""Scan a directory for images and import generation metadata."""

from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.generation import check_duplicate, create_generation
from mygens.core.hashing import compute_file_hash
from mygens.core.models import GenerationCreate, OutputCreate, Platform
from mygens.core.output import add_output
from mygens.parsers.registry import auto_parse, detect_parser, get_parser

console = Console()

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}


def scan_cmd(
    path: Path = typer.Argument(..., help="Directory to scan for images."),
    parser: Optional[str] = typer.Option(
        None, "--parser", "-p", help="Force a specific parser (e.g. 'a1111', 'comfyui', 'midjourney')."
    ),
    recursive: bool = typer.Option(
        True, "--recursive/--no-recursive", "-r/-R", help="Scan subdirectories recursively."
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-d", help="Preview what would be imported without writing to the database."
    ),
    project: Optional[str] = typer.Option(
        None, "--project", help="Project ID to assign imported generations to."
    ),
) -> None:
    """Walk a directory, find image files, parse metadata, and import generations."""
    try:
        if not path.exists():
            console.print(f"[bold red]Error:[/bold red] Path not found: {path}")
            raise typer.Exit(1)

        if not path.is_dir():
            console.print(f"[bold red]Error:[/bold red] Not a directory: {path}")
            raise typer.Exit(1)

        # Collect image files
        if recursive:
            files = [
                f for f in path.rglob("*")
                if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS
            ]
        else:
            files = [
                f for f in path.iterdir()
                if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS
            ]

        if not files:
            console.print("[yellow]No image files found.[/yellow]")
            raise typer.Exit(0)

        console.print(f"Found [bold]{len(files)}[/bold] image file(s) in [cyan]{path}[/cyan]")

        if dry_run:
            console.print("[yellow]Dry run mode -- no changes will be written.[/yellow]")

        conn = get_connection(get_db_path()) if not dry_run else None

        # Optionally resolve parser once
        forced_parser = None
        if parser:
            forced_parser = get_parser(parser)
            if forced_parser is None:
                console.print(f"[bold red]Error:[/bold red] Unknown parser: {parser}")
                raise typer.Exit(1)
            console.print(f"Using parser: [cyan]{forced_parser.name}[/cyan]")

        imported = 0
        skipped = 0
        failed = 0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Scanning...", total=len(files))

            for file_path in files:
                progress.update(task, description=f"Processing {file_path.name}")

                try:
                    file_hash = compute_file_hash(file_path)

                    # Check for duplicates
                    if conn is not None and check_duplicate(conn, file_hash):
                        skipped += 1
                        progress.advance(task)
                        continue

                    # Read file buffer for parsing
                    buffer = file_path.read_bytes()

                    # Parse metadata
                    if forced_parser is not None:
                        parsed_list = forced_parser.parse(buffer, str(file_path))
                    else:
                        parsed_list = auto_parse(buffer, str(file_path))

                    if not parsed_list:
                        failed += 1
                        progress.advance(task)
                        continue

                    if dry_run:
                        for parsed in parsed_list:
                            console.print(
                                f"  [dim]Would import:[/dim] {file_path.name} "
                                f"[dim]({parsed.platform})[/dim]"
                            )
                        imported += len(parsed_list)
                        progress.advance(task)
                        continue

                    # Import each parsed generation
                    for parsed in parsed_list:
                        try:
                            platform = Platform(parsed.platform)
                        except ValueError:
                            platform = Platform.CUSTOM

                        gen_data = GenerationCreate(
                            prompt_text=parsed.prompt_text,
                            negative_prompt=parsed.negative_prompt,
                            platform=platform,
                            model=parsed.model,
                            seed=parsed.seed,
                            parameters=parsed.parameters,
                            project_id=project,
                            source_uri=parsed.source_uri or str(file_path.resolve()),
                        )

                        gen = create_generation(conn, gen_data)  # type: ignore[arg-type]

                        media_type = mimetypes.guess_type(str(file_path))[0] or "image/png"
                        out_data = OutputCreate(
                            file_path=str(file_path.resolve()),
                            file_hash=file_hash,
                            media_type=media_type,
                        )
                        add_output(conn, gen.id, out_data)  # type: ignore[arg-type]

                        imported += 1

                except Exception as e:
                    failed += 1
                    console.print(f"  [red]Error processing {file_path.name}: {e}[/red]")

                progress.advance(task)

        if conn is not None:
            conn.close()

        # Summary
        console.print()
        console.print("[bold]Scan complete.[/bold]")
        console.print(f"  Imported:   [green]{imported}[/green] generation(s)")
        console.print(f"  Skipped:    [yellow]{skipped}[/yellow] duplicate(s)")
        if failed:
            console.print(f"  Failed:     [red]{failed}[/red] file(s)")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
