"""Show the lineage tree for a generation."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.tree import Tree

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.lineage import get_lineage_tree

console = Console()


def tree_cmd(
    gen_id: str = typer.Argument(..., help="Generation ID to show lineage tree for."),
) -> None:
    """Display the full lineage tree (ancestors and descendants) for a generation."""
    try:
        conn = get_connection(get_db_path())

        lineage = get_lineage_tree(conn, gen_id)
        conn.close()

        if lineage is None:
            console.print(f"[bold red]Error:[/bold red] Generation not found: {gen_id}")
            raise typer.Exit(1)

        # Build a lookup from node ID to LineageNode
        node_map = {node.id: node for node in lineage.nodes}

        # Build a children map from edges
        children_map: dict[str, list[str]] = {}
        for edge in lineage.edges:
            children_map.setdefault(edge.source, []).append(edge.target)

        # Build the Rich tree recursively from root
        root_node = node_map[lineage.root_id]
        root_label = _format_node(root_node, highlight_id=gen_id)
        rich_tree = Tree(root_label)

        _build_tree(rich_tree, lineage.root_id, children_map, node_map, gen_id)

        console.print()
        console.print("[bold]Lineage Tree[/bold]")
        console.print(rich_tree)
        console.print()
        console.print(f"[dim]{len(lineage.nodes)} node(s), {len(lineage.edges)} edge(s)[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)


def _build_tree(
    parent_tree: Tree,
    parent_id: str,
    children_map: dict[str, list[str]],
    node_map: dict,
    highlight_id: str,
) -> None:
    """Recursively build the Rich Tree from the lineage data."""
    child_ids = children_map.get(parent_id, [])
    for child_id in child_ids:
        child_node = node_map.get(child_id)
        if child_node is None:
            continue
        label = _format_node(child_node, highlight_id=highlight_id)
        branch = parent_tree.add(label)
        _build_tree(branch, child_id, children_map, node_map, highlight_id)


def _format_node(node, highlight_id: str) -> str:
    """Format a lineage node for display in the tree."""
    short_id = node.id[:12]
    prompt_preview = node.prompt_text[:40] + ("..." if len(node.prompt_text) > 40 else "")
    rating_str = f"{'*' * node.rating}" if node.rating else ""

    derivation = ""
    if node.derivation_type:
        derivation = f" [dim]({node.derivation_type.value})[/dim]"

    model = f" [blue]{node.model}[/blue]" if node.model else ""

    if node.id == highlight_id:
        return f"[bold yellow]>>> {short_id}[/bold yellow]{derivation}{model} {prompt_preview} {rating_str}"
    else:
        return f"[cyan]{short_id}[/cyan]{derivation}{model} {prompt_preview} {rating_str}"
