"""Start the MyGens FastAPI server."""

from __future__ import annotations

import typer
from rich.console import Console

console = Console()


def serve_cmd(
    port: int = typer.Option(
        9753, "--port", "-p", help="Port to listen on."
    ),
    host: str = typer.Option(
        "127.0.0.1", "--host", "-h", help="Host to bind to."
    ),
) -> None:
    """Start the MyGens web server (FastAPI + Uvicorn)."""
    try:
        import uvicorn

        console.print()
        console.print("[bold green]Starting MyGens server...[/bold green]")
        console.print(f"  Host:  [cyan]{host}[/cyan]")
        console.print(f"  Port:  [cyan]{port}[/cyan]")
        console.print(f"  URL:   [link=http://{host}:{port}]http://{host}:{port}[/link]")
        console.print()
        console.print("[dim]Press Ctrl+C to stop.[/dim]")
        console.print()

        from mygens.core.config import ensure_home_dir, get_db_path
        from mygens.core.db import get_connection, init_db
        from mygens.server.app import create_app

        # Ensure DB is initialized
        ensure_home_dir()
        conn = get_connection(get_db_path())
        init_db(conn)
        conn.close()

        app = create_app()
        uvicorn.run(
            app,
            host=host,
            port=port,
            log_level="info",
        )

    except ImportError:
        console.print(
            "[bold red]Error:[/bold red] uvicorn is not installed. "
            "Install it with: [cyan]pip install mygens[server][/cyan]"
        )
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
