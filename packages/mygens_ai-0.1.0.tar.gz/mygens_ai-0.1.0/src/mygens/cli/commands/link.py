"""Link two generations in a parent-child relationship."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.generation import get_generation, update_generation
from mygens.core.models import DerivationType, GenerationUpdate

console = Console()


def link_cmd(
    child_id: str = typer.Argument(..., help="Child generation ID."),
    parent_id: str = typer.Argument(..., help="Parent generation ID."),
    derivation_type: Optional[DerivationType] = typer.Option(
        None,
        "--type",
        "-t",
        help="Derivation type (variation, remix, upscale, edit, img2img, vid2vid, translate).",
    ),
) -> None:
    """Link a child generation to a parent, establishing lineage."""
    try:
        conn = get_connection(get_db_path())

        # Validate both generations exist
        child = get_generation(conn, child_id)
        if child is None:
            console.print(f"[bold red]Error:[/bold red] Child generation not found: {child_id}")
            conn.close()
            raise typer.Exit(1)

        parent = get_generation(conn, parent_id)
        if parent is None:
            console.print(f"[bold red]Error:[/bold red] Parent generation not found: {parent_id}")
            conn.close()
            raise typer.Exit(1)

        # Prevent self-linking
        if child_id == parent_id:
            console.print("[bold red]Error:[/bold red] Cannot link a generation to itself.")
            conn.close()
            raise typer.Exit(1)

        data = GenerationUpdate(
            parent_id=parent_id,
            derivation_type=derivation_type,
        )
        update_generation(conn, child_id, data)
        conn.close()

        type_str = f" as [magenta]{derivation_type.value}[/magenta]" if derivation_type else ""
        console.print(
            f"[bold green]Linked[/bold green] [cyan]{child_id[:12]}[/cyan] "
            f"-> [cyan]{parent_id[:12]}[/cyan]{type_str}"
        )

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
