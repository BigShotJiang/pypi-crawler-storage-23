"""Manually log a generation from the command line."""

from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.generation import create_generation
from mygens.core.hashing import compute_file_hash
from mygens.core.models import (
    DerivationType,
    GenerationCreate,
    OutputCreate,
    Platform,
)
from mygens.core.output import add_output

console = Console()


def log_cmd(
    prompt: str = typer.Argument(..., help="The prompt text to log."),
    platform: Platform = typer.Option(
        Platform.CUSTOM, "--platform", "-p", help="Generation platform."
    ),
    model: Optional[str] = typer.Option(
        None, "--model", "-m", help="Model name (e.g. 'sd_xl_base_1.0')."
    ),
    seed: Optional[int] = typer.Option(None, "--seed", "-s", help="Random seed."),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o", help="Path to output image/video file."
    ),
    tags: Optional[str] = typer.Option(
        None, "--tags", "-t", help="Comma-separated tags."
    ),
    parent: Optional[str] = typer.Option(
        None, "--parent", help="Parent generation ID for lineage tracking."
    ),
    notes: Optional[str] = typer.Option(
        None, "--notes", "-n", help="Free-form notes."
    ),
) -> None:
    """Manually log a generation with all options."""
    try:
        conn = get_connection(get_db_path())

        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

        data = GenerationCreate(
            prompt_text=prompt,
            platform=platform,
            model=model,
            seed=seed,
            parent_id=parent,
            tags=tag_list,
            notes=notes or "",
        )

        gen = create_generation(conn, data)

        if output is not None:
            if not output.exists():
                console.print(f"[bold red]Error:[/bold red] File not found: {output}")
                raise typer.Exit(1)

            file_hash = compute_file_hash(output)
            media_type = mimetypes.guess_type(str(output))[0] or "application/octet-stream"

            out_data = OutputCreate(
                file_path=str(output.resolve()),
                file_hash=file_hash,
                media_type=media_type,
            )
            add_output(conn, gen.id, out_data)

        conn.close()

        console.print()
        console.print(f"[bold green]Logged generation[/bold green] [cyan]{gen.id}[/cyan]")
        console.print(f"  Platform:  {gen.platform.value}")
        if gen.model:
            console.print(f"  Model:     {gen.model}")
        if gen.seed is not None:
            console.print(f"  Seed:      {gen.seed}")
        if tag_list:
            console.print(f"  Tags:      {', '.join(tag_list)}")
        if output is not None:
            console.print(f"  Output:    {output}")
        console.print(f"  Prompt:    {gen.prompt_text[:80]}{'...' if len(gen.prompt_text) > 80 else ''}")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
