"""List generations with filtering."""

from __future__ import annotations

import json as json_module
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from mygens.core.config import get_db_path
from mygens.core.db import get_connection
from mygens.core.generation import list_generations
from mygens.core.models import GenerationFilters, Platform

console = Console()


def list_cmd(
    platform: Optional[Platform] = typer.Option(
        None, "--platform", "-p", help="Filter by platform."
    ),
    project: Optional[str] = typer.Option(
        None, "--project", help="Filter by project ID."
    ),
    min_rating: Optional[int] = typer.Option(
        None, "--min-rating", "-r", help="Minimum rating (0-5).", min=0, max=5
    ),
    limit: int = typer.Option(
        50, "--limit", "-l", help="Maximum number of results.", min=1, max=200
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output as JSON for scripting."
    ),
) -> None:
    """List generations with optional filters."""
    try:
        conn = get_connection(get_db_path())

        filters = GenerationFilters(
            platform=platform,
            project_id=project,
            min_rating=min_rating,
            limit=limit,
        )

        generations = list_generations(conn, filters)
        conn.close()

        if not generations:
            if json_output:
                console.print("[]")
            else:
                console.print("[yellow]No generations found.[/yellow]")
            raise typer.Exit(0)

        if json_output:
            output = [gen.model_dump(mode="json") for gen in generations]
            # Write raw JSON to stdout (not through Rich, which adds ANSI codes)
            print(json_module.dumps(output, indent=2, default=str))
            return

        table = Table(title="Generations")
        table.add_column("ID", style="cyan", no_wrap=True, max_width=12)
        table.add_column("Platform", style="magenta")
        table.add_column("Model", style="blue")
        table.add_column("Rating", justify="center")
        table.add_column("Prompt", style="white", max_width=50)
        table.add_column("Tags", style="green")
        table.add_column("Created", style="dim")

        for gen in generations:
            prompt_preview = gen.prompt_text[:50] + ("..." if len(gen.prompt_text) > 50 else "")
            rating_str = f"{'*' * gen.rating}{'.' * (5 - gen.rating)}" if gen.rating else "-"
            tags_str = ", ".join(gen.tags) if gen.tags else "-"
            model_str = gen.model or "-"
            created_str = gen.created_at.strftime("%Y-%m-%d %H:%M")

            table.add_row(
                gen.id[:12],
                gen.platform.value,
                model_str,
                rating_str,
                prompt_preview,
                tags_str,
                created_str,
            )

        console.print(table)
        console.print(f"\n[dim]{len(generations)} generation(s) shown.[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)
