"""Pydantic models for MyGens — the unified prompt schema."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class Platform(str, Enum):
    """Supported generative AI platforms."""

    MIDJOURNEY = "midjourney"
    DALLE = "dalle"
    SD_A1111 = "sd_a1111"
    COMFYUI = "comfyui"
    FLUX = "flux"
    RUNWAY = "runway"
    KLING = "kling"
    SORA = "sora"
    VEO = "veo"
    CUSTOM = "custom"


class DerivationType(str, Enum):
    """How a generation was derived from its parent."""

    VARIATION = "variation"
    REMIX = "remix"
    UPSCALE = "upscale"
    EDIT = "edit"
    IMG2IMG = "img2img"
    VID2VID = "vid2vid"
    TRANSLATE = "translate"


class FragmentCategory(str, Enum):
    """Semantic categories for prompt fragments."""

    STYLE = "style"
    SUBJECT = "subject"
    COMPOSITION = "composition"
    LIGHTING = "lighting"
    MOOD = "mood"
    TECHNICAL = "technical"
    MODIFIER = "modifier"
    NEGATIVE = "negative"


# --- Core Entities ---


class GenerationCreate(BaseModel):
    """Input model for creating a generation."""

    prompt_text: str
    negative_prompt: str | None = None
    platform: Platform
    model: str | None = None
    seed: int | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)
    parent_id: str | None = None
    derivation_type: DerivationType | None = None
    project_id: str | None = None
    tags: list[str] = Field(default_factory=list)
    rating: int = Field(default=0, ge=0, le=5)
    notes: str = ""
    source_uri: str | None = None
    created_at: datetime | None = None


class GenerationUpdate(BaseModel):
    """Input model for updating a generation."""

    rating: int | None = Field(default=None, ge=0, le=5)
    tags: list[str] | None = None
    notes: str | None = None
    parent_id: str | None = None
    derivation_type: DerivationType | None = None
    project_id: str | None = None


class Generation(BaseModel):
    """Full generation record."""

    id: str
    prompt_text: str
    negative_prompt: str | None = None
    platform: Platform
    model: str | None = None
    seed: int | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)
    parent_id: str | None = None
    derivation_type: DerivationType | None = None
    project_id: str | None = None
    tags: list[str] = Field(default_factory=list)
    rating: int = 0
    notes: str = ""
    created_at: datetime
    captured_at: datetime
    source_uri: str | None = None
    prompt_hash: str
    param_hash: str
    outputs: list[Output] = Field(default_factory=list)


class OutputCreate(BaseModel):
    """Input model for adding an output."""

    file_path: str = ""
    file_hash: str = ""
    url: str | None = None
    media_type: str
    width: int | None = None
    height: int | None = None
    duration_ms: int | None = None
    thumbnail_path: str | None = None
    selected: bool = False
    perceptual_hash: str | None = None


class Output(BaseModel):
    """Full output record."""

    id: str
    generation_id: str
    file_path: str = ""
    file_hash: str = ""
    url: str | None = None
    media_type: str
    width: int | None = None
    height: int | None = None
    duration_ms: int | None = None
    thumbnail_path: str | None = None
    selected: bool = False
    perceptual_hash: str | None = None


class ProjectCreate(BaseModel):
    """Input model for creating a project."""

    name: str
    description: str = ""


class Project(BaseModel):
    """Full project record."""

    id: str
    name: str
    description: str = ""
    created_at: datetime
    archived: bool = False


class PromptFragment(BaseModel):
    """A reusable semantic fragment extracted from prompts."""

    id: str
    text: str
    category: FragmentCategory | None = None
    platform_compat: list[str] = Field(default_factory=list)
    usage_count: int = 0
    avg_rating: float = 0.0


# --- Query/Response Models ---


class GenerationFilters(BaseModel):
    """Filters for listing generations."""

    platform: Platform | None = None
    project_id: str | None = None
    min_rating: int | None = Field(default=None, ge=0, le=5)
    tags: list[str] | None = None
    cursor: str | None = None
    limit: int = Field(default=50, ge=1, le=200)


class LineageNode(BaseModel):
    """A node in the lineage tree."""

    id: str
    prompt_text: str
    platform: Platform
    model: str | None = None
    rating: int = 0
    derivation_type: DerivationType | None = None
    thumbnail_url: str | None = None


class LineageEdge(BaseModel):
    """An edge in the lineage tree."""

    source: str
    target: str
    derivation_type: DerivationType | None = None


class LineageTree(BaseModel):
    """Complete lineage tree for visualization."""

    nodes: list[LineageNode]
    edges: list[LineageEdge]
    root_id: str


class PromptDiff(BaseModel):
    """Structured diff between two generations."""

    left_id: str
    right_id: str
    prompt_diff: list[DiffSegment]
    negative_prompt_diff: list[DiffSegment] | None = None
    parameter_changes: list[ParamChange]
    rating_delta: int | None = None
    platform_changed: bool = False


class DiffSegment(BaseModel):
    """A segment in a text diff."""

    text: str
    type: str  # "equal", "insert", "delete"


class ParamChange(BaseModel):
    """A parameter change between two generations."""

    key: str
    left_value: Any | None = None
    right_value: Any | None = None
    change_type: str  # "added", "removed", "changed", "unchanged"


class DashboardStats(BaseModel):
    """Aggregated statistics for the dashboard."""

    total_generations: int
    total_outputs: int
    total_projects: int
    by_platform: dict[str, int]
    by_rating: dict[int, int]
    top_fragments: list[PromptFragment]
    top_models: list[dict[str, Any]]
