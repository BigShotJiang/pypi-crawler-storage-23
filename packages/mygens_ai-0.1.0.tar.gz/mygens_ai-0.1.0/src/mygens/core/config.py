"""Configuration management for MyGens."""

from __future__ import annotations

import os
from pathlib import Path


def get_home_dir() -> Path:
    """Get the MyGens home directory (~/.mygens)."""
    env_home = os.environ.get("MYGENS_HOME")
    if env_home:
        return Path(env_home)
    return Path.home() / ".mygens"


def get_db_path() -> Path:
    """Get the path to the SQLite database."""
    return get_home_dir() / "mygens.db"


def get_outputs_dir() -> Path:
    """Get the managed outputs directory."""
    return get_home_dir() / "outputs"


def get_thumbnails_dir() -> Path:
    """Get the thumbnails directory."""
    return get_home_dir() / "thumbnails"


def ensure_home_dir() -> Path:
    """Create the home directory structure if it doesn't exist."""
    home = get_home_dir()
    home.mkdir(parents=True, exist_ok=True)
    (home / "outputs").mkdir(exist_ok=True)
    (home / "thumbnails").mkdir(exist_ok=True)
    (home / "exports").mkdir(exist_ok=True)
    return home
