"""Hybrid search — FTS5 keyword + semantic embedding, merged and ranked.

Search flow:
1. FTS5 keyword search (instant, SQLite built-in)
2. Semantic embedding search (5-10ms, cosine similarity)
3. Merge results: semantic matches that FTS5 missed get added
4. Deduplicate, return ordered by relevance

For the user: just type what you're looking for. "neon city" finds exact
matches AND prompts about "cyberpunk metropolis, glowing signs" that share
the same visual concept.
"""

from __future__ import annotations

import sqlite3

from mygens.core.generation import _row_to_generation
from mygens.core.models import Generation


def full_text_search(
    conn: sqlite3.Connection,
    query: str,
    platform: str | None = None,
    project_id: str | None = None,
    min_rating: int | None = None,
    limit: int = 50,
) -> list[Generation]:
    """FTS5 keyword search — fast, exact matching."""
    # Escape FTS5 special characters: quote each word separately for AND semantics
    words = query.split()
    safe_query = " ".join('"' + w.replace('"', '""') + '"' for w in words) if words else query
    conditions = ["generations_fts MATCH ?"]
    params: list[object] = [safe_query]

    if platform:
        conditions.append("g.platform = ?")
        params.append(platform)
    if project_id:
        conditions.append("g.project_id = ?")
        params.append(project_id)
    if min_rating is not None:
        conditions.append("g.rating >= ?")
        params.append(min_rating)

    where = " AND ".join(conditions)
    params.append(limit)

    sql = f"""
        SELECT g.* FROM generations g
        JOIN generations_fts fts ON g.rowid = fts.rowid
        WHERE {where}
        ORDER BY fts.rank
        LIMIT ?
    """

    cur = conn.execute(sql, params)
    return [_row_to_generation(row) for row in cur.fetchall()]


def hybrid_search(
    conn: sqlite3.Connection,
    query: str,
    platform: str | None = None,
    project_id: str | None = None,
    min_rating: int | None = None,
    limit: int = 50,
) -> list[Generation]:
    """Hybrid search: FTS5 keyword + semantic embedding, merged.

    Returns keyword matches first (exact relevance), then semantic
    matches that weren't found by keywords (conceptual relevance).
    """
    # 1. Keyword search (always runs, instant)
    keyword_results = full_text_search(
        conn, query, platform, project_id, min_rating, limit
    )
    keyword_ids = {g.id for g in keyword_results}

    # 2. Semantic search (runs if embeddings are available)
    semantic_additions: list[Generation] = []
    try:
        from mygens.core.embeddings import semantic_search

        semantic_hits = semantic_search(conn, query, limit=limit)

        # Get generations for semantic hits that FTS5 missed
        for gen_id, score in semantic_hits:
            if gen_id in keyword_ids:
                continue  # Already found by keyword search

            # Apply same filters
            gen = _get_and_filter(
                conn, gen_id, platform, project_id, min_rating
            )
            if gen is not None:
                semantic_additions.append(gen)

            if len(keyword_results) + len(semantic_additions) >= limit:
                break

    except ImportError:
        pass  # fastembed not installed — keyword-only mode
    except Exception:
        pass  # Embedding search failed — degrade gracefully to keyword-only

    # 3. Merge: keyword results first, then semantic additions
    return (keyword_results + semantic_additions)[:limit]


def _get_and_filter(
    conn: sqlite3.Connection,
    gen_id: str,
    platform: str | None,
    project_id: str | None,
    min_rating: int | None,
) -> Generation | None:
    """Get a generation and check if it passes the filters."""
    cur = conn.execute("SELECT * FROM generations WHERE id = ?", (gen_id,))
    row = cur.fetchone()
    if not row:
        return None

    if platform and row["platform"] != platform:
        return None
    if project_id and row["project_id"] != project_id:
        return None
    if min_rating is not None and row["rating"] < min_rating:
        return None

    return _row_to_generation(row)
