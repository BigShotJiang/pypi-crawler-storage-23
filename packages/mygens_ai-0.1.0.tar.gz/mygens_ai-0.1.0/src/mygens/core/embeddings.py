"""Semantic embedding search — local, fast, no API calls.

Uses BAAI/bge-small-en-v1.5 via fastembed (ONNX Runtime, NOT PyTorch).
384-dimensional embeddings, ~5ms per query, stored as BLOBs in SQLite.

Architecture:
- Model loads lazily on first search (~3-5s, then cached in memory)
- Embeddings are computed on generation creation (background, non-blocking)
- Search: embed query → cosine similarity against all stored vectors → merge with FTS5 results
- 10K vectors × 384 dims = ~15MB in memory, similarity computed in <5ms via NumPy
"""

from __future__ import annotations

import sqlite3
import struct
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from fastembed import TextEmbedding

# Lazy-loaded singleton
_model: TextEmbedding | None = None
_EMBEDDING_DIM = 384
_MODEL_NAME = "BAAI/bge-small-en-v1.5"


def _get_model() -> TextEmbedding:
    """Lazy-load the embedding model (first call ~3-5s, then instant)."""
    global _model
    if _model is None:
        from fastembed import TextEmbedding
        _model = TextEmbedding(_MODEL_NAME)
    return _model


def embed_text(text: str) -> np.ndarray:
    """Embed a single text string. Returns a 384-dim float32 array."""
    model = _get_model()
    results = list(model.embed([text]))
    return np.array(results[0], dtype=np.float32)


def embed_texts(texts: list[str]) -> np.ndarray:
    """Embed multiple texts. Returns (N, 384) float32 array."""
    if not texts:
        return np.zeros((0, _EMBEDDING_DIM), dtype=np.float32)
    model = _get_model()
    results = list(model.embed(texts))
    return np.array(results, dtype=np.float32)


# --- SQLite BLOB storage ---

def embedding_to_blob(embedding: np.ndarray) -> bytes:
    """Convert a numpy embedding to a compact binary BLOB for SQLite."""
    return embedding.astype(np.float32).tobytes()


def blob_to_embedding(blob: bytes) -> np.ndarray:
    """Convert a SQLite BLOB back to a numpy embedding."""
    return np.frombuffer(blob, dtype=np.float32)


# --- Core search function ---

def semantic_search(
    conn: sqlite3.Connection,
    query: str,
    limit: int = 20,
    min_similarity: float = 0.3,
) -> list[tuple[str, float]]:
    """Search generations by semantic similarity.

    Returns list of (generation_id, similarity_score) sorted by relevance.
    This is FAST: embed query (~5ms) + cosine similarity (~2ms for 10K vectors).
    """
    query_embedding = embed_text(query)

    # Load all embeddings from DB
    cur = conn.execute(
        "SELECT id, embedding FROM generations WHERE embedding IS NOT NULL"
    )
    rows = cur.fetchall()

    if not rows:
        return []

    # Build matrix for vectorized cosine similarity
    ids: list[str] = []
    embeddings: list[np.ndarray] = []

    for row in rows:
        ids.append(row["id"])
        embeddings.append(blob_to_embedding(row["embedding"]))

    matrix = np.array(embeddings, dtype=np.float32)  # (N, 384)

    # Cosine similarity: (N,384) @ (384,) → (N,)
    query_norm = np.linalg.norm(query_embedding)
    if query_norm == 0:
        return []

    row_norms = np.linalg.norm(matrix, axis=1)
    # Avoid division by zero
    row_norms = np.maximum(row_norms, 1e-10)

    similarities = (matrix @ query_embedding) / (row_norms * query_norm)

    # Filter and sort
    results: list[tuple[str, float]] = []
    for idx in np.argsort(similarities)[::-1]:
        score = float(similarities[idx])
        if score < min_similarity:
            break
        results.append((ids[idx], score))
        if len(results) >= limit:
            break

    return results


# --- Embedding lifecycle ---

def compute_and_store_embedding(conn: sqlite3.Connection, gen_id: str) -> None:
    """Compute embedding for a generation and store it in the DB."""
    cur = conn.execute(
        "SELECT prompt_text, negative_prompt, tags FROM generations WHERE id = ?",
        (gen_id,),
    )
    row = cur.fetchone()
    if not row:
        return

    # Combine prompt fields for richer embedding
    parts = [row["prompt_text"]]
    if row["negative_prompt"]:
        parts.append(row["negative_prompt"])
    # Tags add semantic context
    import json
    tags = json.loads(row["tags"]) if row["tags"] else []
    if tags:
        parts.append(", ".join(tags))

    text = " | ".join(parts)
    embedding = embed_text(text)
    blob = embedding_to_blob(embedding)

    conn.execute(
        "UPDATE generations SET embedding = ? WHERE id = ?",
        (blob, gen_id),
    )
    conn.commit()


def backfill_embeddings(
    conn: sqlite3.Connection,
    batch_size: int = 64,
    on_progress: callable | None = None,
) -> int:
    """Compute embeddings for all generations that don't have one yet.

    Returns the number of generations embedded.
    """
    cur = conn.execute(
        "SELECT id, prompt_text, negative_prompt, tags "
        "FROM generations WHERE embedding IS NULL"
    )
    rows = cur.fetchall()

    if not rows:
        return 0

    import json

    total = len(rows)
    embedded = 0

    for i in range(0, total, batch_size):
        batch = rows[i : i + batch_size]
        texts = []
        ids = []

        for row in batch:
            parts = [row["prompt_text"]]
            if row["negative_prompt"]:
                parts.append(row["negative_prompt"])
            tags = json.loads(row["tags"]) if row["tags"] else []
            if tags:
                parts.append(", ".join(tags))
            texts.append(" | ".join(parts))
            ids.append(row["id"])

        embeddings = embed_texts(texts)

        for gen_id, emb in zip(ids, embeddings):
            blob = embedding_to_blob(emb)
            conn.execute(
                "UPDATE generations SET embedding = ? WHERE id = ?",
                (blob, gen_id),
            )

        conn.commit()
        embedded += len(batch)

        if on_progress:
            on_progress(embedded, total)

    return embedded
