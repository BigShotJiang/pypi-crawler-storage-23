"""Project CRUD operations."""

from __future__ import annotations

import sqlite3
from datetime import datetime

from uuid_extensions import uuid7

from mygens.core.models import Project, ProjectCreate


def _row_to_project(row: sqlite3.Row) -> Project:
    return Project(
        id=row["id"],
        name=row["name"],
        description=row["description"] or "",
        created_at=datetime.fromisoformat(row["created_at"]),
        archived=bool(row["archived"]),
    )


def create_project(conn: sqlite3.Connection, data: ProjectCreate) -> Project:
    """Create a new project."""
    project_id = str(uuid7())
    conn.execute(
        "INSERT INTO projects (id, name, description) VALUES (?, ?, ?)",
        (project_id, data.name, data.description),
    )
    conn.commit()
    project = get_project(conn, project_id)
    if project is None:
        raise RuntimeError(f"Failed to read back project {project_id} after insert")
    return project


def get_project(conn: sqlite3.Connection, project_id: str) -> Project | None:
    """Get a single project."""
    cur = conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
    row = cur.fetchone()
    return _row_to_project(row) if row else None


def list_projects(conn: sqlite3.Connection, include_archived: bool = False) -> list[Project]:
    """List all projects."""
    query = "SELECT * FROM projects"
    if not include_archived:
        query += " WHERE archived = 0"
    query += " ORDER BY created_at DESC"
    cur = conn.execute(query)
    return [_row_to_project(row) for row in cur.fetchall()]


def archive_project(conn: sqlite3.Connection, project_id: str) -> bool:
    """Archive a project (soft delete)."""
    cur = conn.execute(
        "UPDATE projects SET archived = 1 WHERE id = ?", (project_id,)
    )
    conn.commit()
    return cur.rowcount > 0
