"""Output CRUD operations — files produced by generations."""

from __future__ import annotations

import sqlite3

from uuid_extensions import uuid7

from mygens.core.generation import _row_to_output
from mygens.core.models import Output, OutputCreate


def add_output(
    conn: sqlite3.Connection, generation_id: str, data: OutputCreate
) -> Output:
    """Add an output file (local or URL reference) to a generation."""
    output_id = str(uuid7())

    conn.execute(
        """INSERT INTO outputs
           (id, generation_id, file_path, file_hash, url, media_type,
            width, height, duration_ms, thumbnail_path, selected, perceptual_hash)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            output_id,
            generation_id,
            data.file_path,
            data.file_hash,
            data.url,
            data.media_type,
            data.width,
            data.height,
            data.duration_ms,
            data.thumbnail_path,
            int(data.selected),
            data.perceptual_hash,
        ),
    )
    conn.commit()

    cur = conn.execute("SELECT * FROM outputs WHERE id = ?", (output_id,))
    return _row_to_output(cur.fetchone())


def get_outputs(conn: sqlite3.Connection, generation_id: str) -> list[Output]:
    """Get all outputs for a generation."""
    cur = conn.execute(
        "SELECT * FROM outputs WHERE generation_id = ?", (generation_id,)
    )
    return [_row_to_output(row) for row in cur.fetchall()]


def delete_output(conn: sqlite3.Connection, output_id: str) -> bool:
    """Delete an output."""
    cur = conn.execute("DELETE FROM outputs WHERE id = ?", (output_id,))
    conn.commit()
    return cur.rowcount > 0
