"""Prompt diff engine — compare two generations."""

from __future__ import annotations

import difflib
import json
import sqlite3

from mygens.core.generation import get_generation
from mygens.core.models import DiffSegment, ParamChange, PromptDiff


def diff_generations(
    conn: sqlite3.Connection, left_id: str, right_id: str
) -> PromptDiff | None:
    """Compute a structured diff between two generations."""
    left = get_generation(conn, left_id)
    right = get_generation(conn, right_id)

    if not left or not right:
        return None

    prompt_diff = _diff_text(left.prompt_text, right.prompt_text)

    neg_diff = None
    if left.negative_prompt or right.negative_prompt:
        neg_diff = _diff_text(
            left.negative_prompt or "", right.negative_prompt or ""
        )

    param_changes = _diff_params(left.parameters, right.parameters)

    rating_delta = right.rating - left.rating if (left.rating is not None and right.rating is not None) else None

    return PromptDiff(
        left_id=left_id,
        right_id=right_id,
        prompt_diff=prompt_diff,
        negative_prompt_diff=neg_diff,
        parameter_changes=param_changes,
        rating_delta=rating_delta,
        platform_changed=left.platform != right.platform,
    )


def _diff_text(left: str, right: str) -> list[DiffSegment]:
    """Word-level diff between two texts."""
    left_words = left.split()
    right_words = right.split()

    segments: list[DiffSegment] = []
    matcher = difflib.SequenceMatcher(None, left_words, right_words)

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            segments.append(
                DiffSegment(text=" ".join(left_words[i1:i2]), type="equal")
            )
        elif tag == "delete":
            segments.append(
                DiffSegment(text=" ".join(left_words[i1:i2]), type="delete")
            )
        elif tag == "insert":
            segments.append(
                DiffSegment(text=" ".join(right_words[j1:j2]), type="insert")
            )
        elif tag == "replace":
            segments.append(
                DiffSegment(text=" ".join(left_words[i1:i2]), type="delete")
            )
            segments.append(
                DiffSegment(text=" ".join(right_words[j1:j2]), type="insert")
            )

    return segments


def _diff_params(
    left: dict, right: dict
) -> list[ParamChange]:
    """Compare parameters between two generations."""
    all_keys = sorted(set(left.keys()) | set(right.keys()))
    changes: list[ParamChange] = []

    for key in all_keys:
        left_val = left.get(key)
        right_val = right.get(key)

        if key not in left:
            change_type = "added"
        elif key not in right:
            change_type = "removed"
        elif left_val != right_val:
            change_type = "changed"
        else:
            change_type = "unchanged"

        changes.append(
            ParamChange(
                key=key,
                left_value=left_val,
                right_value=right_val,
                change_type=change_type,
            )
        )

    return changes
