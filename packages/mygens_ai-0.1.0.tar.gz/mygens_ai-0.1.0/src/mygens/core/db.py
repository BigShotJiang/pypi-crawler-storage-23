"""Database connection, schema, and migrations for MyGens."""

from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA_VERSION = 1

SCHEMA_SQL = """
-- Enable WAL mode for concurrent read/write
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS _schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    archived INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS generations (
    id TEXT PRIMARY KEY,
    prompt_text TEXT NOT NULL,
    negative_prompt TEXT,
    platform TEXT NOT NULL,
    model TEXT,
    seed INTEGER,
    parameters TEXT DEFAULT '{}',
    parent_id TEXT REFERENCES generations(id) ON DELETE SET NULL,
    derivation_type TEXT,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    tags TEXT DEFAULT '[]',
    rating INTEGER DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    captured_at TEXT NOT NULL DEFAULT (datetime('now')),
    source_uri TEXT,
    prompt_hash TEXT NOT NULL,
    param_hash TEXT NOT NULL,
    embedding BLOB
);

CREATE INDEX IF NOT EXISTS idx_gen_platform ON generations(platform);
CREATE INDEX IF NOT EXISTS idx_gen_project ON generations(project_id);
CREATE INDEX IF NOT EXISTS idx_gen_parent ON generations(parent_id);
CREATE INDEX IF NOT EXISTS idx_gen_rating ON generations(rating);
CREATE INDEX IF NOT EXISTS idx_gen_created ON generations(created_at);
CREATE INDEX IF NOT EXISTS idx_gen_prompt_hash ON generations(prompt_hash);
CREATE INDEX IF NOT EXISTS idx_gen_param_hash ON generations(param_hash);

CREATE TABLE IF NOT EXISTS outputs (
    id TEXT PRIMARY KEY,
    generation_id TEXT NOT NULL REFERENCES generations(id) ON DELETE CASCADE,
    file_path TEXT DEFAULT '',
    file_hash TEXT DEFAULT '',
    url TEXT,
    media_type TEXT NOT NULL,
    width INTEGER,
    height INTEGER,
    duration_ms INTEGER,
    thumbnail_path TEXT,
    selected INTEGER NOT NULL DEFAULT 0,
    perceptual_hash TEXT
);

CREATE INDEX IF NOT EXISTS idx_out_gen ON outputs(generation_id);
CREATE INDEX IF NOT EXISTS idx_out_hash ON outputs(file_hash);
CREATE INDEX IF NOT EXISTS idx_out_phash ON outputs(perceptual_hash);

CREATE TABLE IF NOT EXISTS prompt_fragments (
    id TEXT PRIMARY KEY,
    text TEXT NOT NULL UNIQUE,
    category TEXT,
    platform_compat TEXT DEFAULT '[]',
    usage_count INTEGER NOT NULL DEFAULT 0,
    avg_rating REAL DEFAULT 0.0
);

CREATE INDEX IF NOT EXISTS idx_frag_category ON prompt_fragments(category);
CREATE INDEX IF NOT EXISTS idx_frag_usage ON prompt_fragments(usage_count DESC);

CREATE TABLE IF NOT EXISTS fragment_usage (
    generation_id TEXT NOT NULL REFERENCES generations(id) ON DELETE CASCADE,
    fragment_id TEXT NOT NULL REFERENCES prompt_fragments(id) ON DELETE CASCADE,
    position INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (generation_id, fragment_id)
);
"""

FTS_SQL = """
CREATE VIRTUAL TABLE IF NOT EXISTS generations_fts USING fts5(
    prompt_text, negative_prompt, notes, tags,
    content=generations, content_rowid=rowid
);

-- Triggers to keep FTS in sync
CREATE TRIGGER IF NOT EXISTS gen_ai AFTER INSERT ON generations BEGIN
    INSERT INTO generations_fts(rowid, prompt_text, negative_prompt, notes, tags)
    VALUES (new.rowid, new.prompt_text, new.negative_prompt, new.notes, new.tags);
END;

CREATE TRIGGER IF NOT EXISTS gen_ad AFTER DELETE ON generations BEGIN
    INSERT INTO generations_fts(generations_fts, rowid, prompt_text, negative_prompt, notes, tags)
    VALUES ('delete', old.rowid, old.prompt_text, old.negative_prompt, old.notes, old.tags);
END;

CREATE TRIGGER IF NOT EXISTS gen_au AFTER UPDATE ON generations BEGIN
    INSERT INTO generations_fts(generations_fts, rowid, prompt_text, negative_prompt, notes, tags)
    VALUES ('delete', old.rowid, old.prompt_text, old.negative_prompt, old.notes, old.tags);
    INSERT INTO generations_fts(rowid, prompt_text, negative_prompt, notes, tags)
    VALUES (new.rowid, new.prompt_text, new.negative_prompt, new.notes, new.tags);
END;
"""


def get_connection(db_path: str | Path = ":memory:") -> sqlite3.Connection:
    """Create a database connection with optimal settings."""
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    """Initialize the database schema and FTS tables."""
    conn.executescript(SCHEMA_SQL)
    conn.executescript(FTS_SQL)

    # Set schema version
    cur = conn.execute("SELECT count(*) FROM _schema_version")
    if cur.fetchone()[0] == 0:
        conn.execute("INSERT INTO _schema_version (version) VALUES (?)", (SCHEMA_VERSION,))
    conn.commit()


def get_schema_version(conn: sqlite3.Connection) -> int:
    """Get the current schema version."""
    try:
        cur = conn.execute("SELECT version FROM _schema_version LIMIT 1")
        row = cur.fetchone()
        return row[0] if row else 0
    except sqlite3.OperationalError:
        return 0
