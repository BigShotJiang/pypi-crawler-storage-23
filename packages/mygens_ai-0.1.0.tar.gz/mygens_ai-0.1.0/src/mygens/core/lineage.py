"""Lineage tree traversal — the DAG of prompt evolution."""

from __future__ import annotations

import sqlite3

from mygens.core.models import (
    DerivationType,
    LineageEdge,
    LineageNode,
    LineageTree,
)


def get_lineage_tree(conn: sqlite3.Connection, gen_id: str) -> LineageTree | None:
    """Get the full lineage tree (ancestors + descendants) for a generation.

    Uses recursive CTEs to walk the DAG in both directions.
    """
    # Find root by walking up
    root_id = _find_root(conn, gen_id)
    if root_id is None:
        return None

    # Get all descendants from root
    cur = conn.execute(
        """
        WITH RECURSIVE tree AS (
            SELECT id, prompt_text, platform, model, rating, derivation_type, parent_id
            FROM generations WHERE id = ?
            UNION ALL
            SELECT g.id, g.prompt_text, g.platform, g.model, g.rating, g.derivation_type, g.parent_id
            FROM generations g
            JOIN tree t ON g.parent_id = t.id
        )
        SELECT * FROM tree
        """,
        (root_id,),
    )

    nodes: list[LineageNode] = []
    edges: list[LineageEdge] = []
    seen: set[str] = set()

    for row in cur.fetchall():
        node_id = row["id"]
        if node_id in seen:
            continue
        seen.add(node_id)

        nodes.append(
            LineageNode(
                id=node_id,
                prompt_text=row["prompt_text"],
                platform=row["platform"],
                model=row["model"],
                rating=row["rating"],
                derivation_type=row["derivation_type"],
            )
        )

        if row["parent_id"]:
            edges.append(
                LineageEdge(
                    source=row["parent_id"],
                    target=node_id,
                    derivation_type=(
                        DerivationType(row["derivation_type"])
                        if row["derivation_type"]
                        else None
                    ),
                )
            )

    if not nodes:
        return None

    return LineageTree(nodes=nodes, edges=edges, root_id=root_id)


def get_ancestors(conn: sqlite3.Connection, gen_id: str) -> list[str]:
    """Walk parent_id chain to root, returning ordered list of ancestor IDs."""
    ancestors: list[str] = []
    current = gen_id

    while True:
        cur = conn.execute(
            "SELECT parent_id FROM generations WHERE id = ?", (current,)
        )
        row = cur.fetchone()
        if not row or not row["parent_id"]:
            break
        ancestors.append(row["parent_id"])
        current = row["parent_id"]

    return list(reversed(ancestors))


def get_children(conn: sqlite3.Connection, gen_id: str) -> list[str]:
    """Get direct child IDs of a generation."""
    cur = conn.execute(
        "SELECT id FROM generations WHERE parent_id = ?", (gen_id,)
    )
    return [row["id"] for row in cur.fetchall()]


def _find_root(conn: sqlite3.Connection, gen_id: str) -> str | None:
    """Find the root generation (no parent) by walking up the tree."""
    current = gen_id
    visited: set[str] = set()

    while True:
        if current in visited:
            return current  # cycle detected, treat as root
        visited.add(current)

        cur = conn.execute(
            "SELECT id, parent_id FROM generations WHERE id = ?", (current,)
        )
        row = cur.fetchone()
        if not row:
            return None
        if not row["parent_id"]:
            return row["id"]
        current = row["parent_id"]
