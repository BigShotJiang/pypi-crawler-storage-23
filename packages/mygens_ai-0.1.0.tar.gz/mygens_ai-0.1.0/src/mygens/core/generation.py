"""Generation CRUD operations — the atomic unit of MyGens."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from uuid_extensions import uuid7

from mygens.core.hashing import compute_param_hash, compute_prompt_hash
from mygens.core.models import (
    Generation,
    GenerationCreate,
    GenerationFilters,
    GenerationUpdate,
    Output,
)


def _row_to_generation(row: sqlite3.Row) -> Generation:
    """Convert a database row to a Generation model."""
    return Generation(
        id=row["id"],
        prompt_text=row["prompt_text"],
        negative_prompt=row["negative_prompt"],
        platform=row["platform"],
        model=row["model"],
        seed=row["seed"],
        parameters=json.loads(row["parameters"]) if row["parameters"] else {},
        parent_id=row["parent_id"],
        derivation_type=row["derivation_type"],
        project_id=row["project_id"],
        tags=json.loads(row["tags"]) if row["tags"] else [],
        rating=row["rating"],
        notes=row["notes"] or "",
        created_at=datetime.fromisoformat(row["created_at"]),
        captured_at=datetime.fromisoformat(row["captured_at"]),
        source_uri=row["source_uri"],
        prompt_hash=row["prompt_hash"],
        param_hash=row["param_hash"],
    )


def _row_to_output(row: sqlite3.Row) -> Output:
    """Convert a database row to an Output model."""
    return Output(
        id=row["id"],
        generation_id=row["generation_id"],
        file_path=row["file_path"] or "",
        file_hash=row["file_hash"] or "",
        url=row["url"] if "url" in row.keys() else None,
        media_type=row["media_type"],
        width=row["width"],
        height=row["height"],
        duration_ms=row["duration_ms"],
        thumbnail_path=row["thumbnail_path"],
        selected=bool(row["selected"]),
        perceptual_hash=row["perceptual_hash"],
    )


def create_generation(conn: sqlite3.Connection, data: GenerationCreate) -> Generation:
    """Create a new generation record."""
    gen_id = str(uuid7())
    now = datetime.now(timezone.utc).isoformat()

    prompt_hash = compute_prompt_hash(data.prompt_text)
    param_hash = compute_param_hash(
        data.prompt_text, data.platform.value, data.seed, data.model
    )
    created_at = data.created_at.isoformat() if data.created_at else now

    conn.execute(
        """INSERT INTO generations
           (id, prompt_text, negative_prompt, platform, model, seed, parameters,
            parent_id, derivation_type, project_id, tags, rating, notes,
            created_at, captured_at, source_uri, prompt_hash, param_hash)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            gen_id,
            data.prompt_text,
            data.negative_prompt,
            data.platform.value,
            data.model,
            data.seed,
            json.dumps(data.parameters),
            data.parent_id,
            data.derivation_type.value if data.derivation_type else None,
            data.project_id,
            json.dumps(data.tags),
            data.rating,
            data.notes,
            created_at,
            now,
            data.source_uri,
            prompt_hash,
            param_hash,
        ),
    )
    conn.commit()

    # Auto-extract fragments from the prompt
    try:
        from mygens.core.fragment import save_fragments
        save_fragments(conn, gen_id, data.prompt_text, data.platform.value)
    except Exception:
        pass  # Fragment extraction is best-effort

    # Auto-compute embedding for semantic search
    try:
        from mygens.core.embeddings import compute_and_store_embedding
        compute_and_store_embedding(conn, gen_id)
    except Exception:
        pass  # Embedding computation is best-effort (fastembed may not be installed)

    gen = get_generation(conn, gen_id)
    if gen is None:
        raise RuntimeError(f"Failed to read back generation {gen_id} after insert")
    return gen


def get_generation(conn: sqlite3.Connection, gen_id: str) -> Generation | None:
    """Get a single generation with its outputs."""
    cur = conn.execute("SELECT * FROM generations WHERE id = ?", (gen_id,))
    row = cur.fetchone()
    if not row:
        return None

    gen = _row_to_generation(row)

    out_cur = conn.execute(
        "SELECT * FROM outputs WHERE generation_id = ?", (gen_id,)
    )
    gen.outputs = [_row_to_output(r) for r in out_cur.fetchall()]

    return gen


def list_generations(
    conn: sqlite3.Connection, filters: GenerationFilters | None = None
) -> list[Generation]:
    """List generations with optional filtering and cursor pagination."""
    if filters is None:
        filters = GenerationFilters()

    conditions: list[str] = []
    params: list[object] = []

    if filters.platform:
        conditions.append("platform = ?")
        params.append(filters.platform.value)
    if filters.project_id:
        conditions.append("project_id = ?")
        params.append(filters.project_id)
    if filters.min_rating is not None:
        conditions.append("rating >= ?")
        params.append(filters.min_rating)
    if filters.tags:
        placeholders = ",".join("?" * len(filters.tags))
        conditions.append(f"json_each.value IN ({placeholders})")
        params.extend(filters.tags)
    if filters.cursor:
        conditions.append("created_at < ?")
        params.append(filters.cursor)

    where = ""
    join = ""
    if filters.tags:
        join = ", json_each(generations.tags)"
    if conditions:
        where = "WHERE " + " AND ".join(conditions)

    query = f"""
        SELECT DISTINCT generations.* FROM generations {join}
        {where}
        ORDER BY created_at DESC
        LIMIT ?
    """
    params.append(filters.limit)

    cur = conn.execute(query, params)
    return [_row_to_generation(row) for row in cur.fetchall()]


def update_generation(
    conn: sqlite3.Connection, gen_id: str, data: GenerationUpdate
) -> Generation | None:
    """Update a generation (rating, tags, notes, parent_id, etc.)."""
    updates: list[str] = []
    params: list[object] = []

    if data.rating is not None:
        updates.append("rating = ?")
        params.append(data.rating)
    if data.tags is not None:
        updates.append("tags = ?")
        params.append(json.dumps(data.tags))
    if data.notes is not None:
        updates.append("notes = ?")
        params.append(data.notes)
    if data.parent_id is not None:
        updates.append("parent_id = ?")
        params.append(data.parent_id)
    if data.derivation_type is not None:
        updates.append("derivation_type = ?")
        params.append(data.derivation_type.value)
    if data.project_id is not None:
        updates.append("project_id = ?")
        params.append(data.project_id)

    if not updates:
        return get_generation(conn, gen_id)

    params.append(gen_id)
    conn.execute(
        f"UPDATE generations SET {', '.join(updates)} WHERE id = ?", params
    )
    conn.commit()

    return get_generation(conn, gen_id)


def delete_generation(conn: sqlite3.Connection, gen_id: str) -> bool:
    """Delete a generation and its outputs (cascade)."""
    cur = conn.execute("DELETE FROM generations WHERE id = ?", (gen_id,))
    conn.commit()
    return cur.rowcount > 0


def check_duplicate(conn: sqlite3.Connection, file_hash: str) -> bool:
    """Check if a file has already been imported (by file hash)."""
    cur = conn.execute(
        "SELECT 1 FROM outputs WHERE file_hash = ? LIMIT 1", (file_hash,)
    )
    return cur.fetchone() is not None
