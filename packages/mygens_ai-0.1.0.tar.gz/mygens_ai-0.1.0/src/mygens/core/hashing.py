"""Hashing utilities — SHA-256 for dedup, perceptual hashing for similarity."""

from __future__ import annotations

import hashlib
from pathlib import Path


def compute_prompt_hash(prompt_text: str) -> str:
    """SHA-256 of normalized prompt text for deduplication."""
    normalized = " ".join(prompt_text.lower().split())
    return hashlib.sha256(normalized.encode()).hexdigest()


def compute_param_hash(
    prompt_text: str,
    platform: str,
    seed: int | None = None,
    model: str | None = None,
) -> str:
    """Deterministic hash of prompt + key params for exact duplicate detection."""
    parts = [prompt_text.strip(), platform]
    if seed is not None:
        parts.append(str(seed))
    if model is not None:
        parts.append(model)
    combined = "|".join(parts)
    return hashlib.sha256(combined.encode()).hexdigest()


def compute_file_hash(file_path: str | Path) -> str:
    """SHA-256 of file contents (streaming, handles large files)."""
    sha = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(8192):
            sha.update(chunk)
    return sha.hexdigest()


def compute_perceptual_hash(file_path: str | Path) -> str | None:
    """Compute dHash (difference hash) for visual similarity search.

    Returns a hex string or None if the image can't be processed.
    """
    try:
        import imagehash
        from PIL import Image

        img = Image.open(file_path)
        dhash = imagehash.dhash(img, hash_size=8)
        return str(dhash)
    except Exception:
        return None


def hamming_distance(hash1: str, hash2: str) -> int:
    """Compute Hamming distance between two hex hash strings."""
    if len(hash1) != len(hash2):
        return -1
    distance = 0
    for c1, c2 in zip(hash1, hash2):
        xor = int(c1, 16) ^ int(c2, 16)
        distance += bin(xor).count("1")
    return distance
