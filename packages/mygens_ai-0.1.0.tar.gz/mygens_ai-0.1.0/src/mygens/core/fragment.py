"""Prompt fragment extraction and statistics.

Decomposes prompts into reusable semantic fragments. Tracks which fragments
correlate with higher ratings over time.
"""

from __future__ import annotations

import json
import sqlite3

from uuid_extensions import uuid7

from mygens.core.models import FragmentCategory, PromptFragment

# Keywords that suggest a category
_CATEGORY_HINTS: dict[FragmentCategory, set[str]] = {
    FragmentCategory.LIGHTING: {
        "lighting", "light", "shadows", "glow", "rays", "volumetric",
        "backlit", "rim light", "ambient", "golden hour", "sunset",
    },
    FragmentCategory.STYLE: {
        "style", "aesthetic", "art", "painting", "illustration", "anime",
        "photorealistic", "cinematic", "film", "vintage", "retro",
    },
    FragmentCategory.COMPOSITION: {
        "close-up", "wide shot", "aerial", "overhead", "macro", "portrait",
        "landscape", "panoramic", "symmetrical", "rule of thirds",
    },
    FragmentCategory.MOOD: {
        "moody", "dark", "bright", "cheerful", "melancholy", "dramatic",
        "serene", "peaceful", "tense", "eerie", "mysterious",
    },
    FragmentCategory.TECHNICAL: {
        "4k", "8k", "hdr", "raw", "sharp", "detailed", "high resolution",
        "octane", "unreal engine", "ray tracing", "35mm", "50mm",
    },
}


def extract_fragments(
    prompt_text: str,
    platform: str | None = None,
) -> list[tuple[str, FragmentCategory | None]]:
    """Split a prompt into semantic fragments with category guesses.

    Returns list of (fragment_text, category_or_None).
    """
    # Primary split on commas (universal delimiter in AI prompts)
    raw_parts = prompt_text.split(",")
    fragments: list[tuple[str, FragmentCategory | None]] = []

    for part in raw_parts:
        text = part.strip()
        if not text:
            continue

        # Skip Midjourney parameters (handled separately)
        if text.startswith("--"):
            continue

        category = _guess_category(text)
        fragments.append((text, category))

    return fragments


def save_fragments(
    conn: sqlite3.Connection,
    generation_id: str,
    prompt_text: str,
    platform: str | None = None,
) -> None:
    """Extract fragments from a prompt and save to the database."""
    fragments = extract_fragments(prompt_text, platform)

    for position, (text, category) in enumerate(fragments):
        # Upsert fragment
        cur = conn.execute(
            "SELECT id FROM prompt_fragments WHERE text = ?", (text,)
        )
        row = cur.fetchone()

        if row:
            fragment_id = row[0]
            conn.execute(
                "UPDATE prompt_fragments SET usage_count = usage_count + 1 WHERE id = ?",
                (fragment_id,),
            )
        else:
            fragment_id = str(uuid7())
            conn.execute(
                """INSERT INTO prompt_fragments (id, text, category, platform_compat, usage_count)
                   VALUES (?, ?, ?, ?, 1)""",
                (
                    fragment_id,
                    text,
                    category.value if category else None,
                    json.dumps([platform] if platform else []),
                ),
            )

        # Link fragment to generation
        conn.execute(
            """INSERT OR IGNORE INTO fragment_usage (generation_id, fragment_id, position)
               VALUES (?, ?, ?)""",
            (generation_id, fragment_id, position),
        )

    conn.commit()


def get_top_fragments(
    conn: sqlite3.Connection,
    limit: int = 20,
    sort_by: str = "usage_count",
) -> list[PromptFragment]:
    """Get the most-used or highest-rated fragments."""
    order = "usage_count DESC" if sort_by == "usage_count" else "avg_rating DESC"
    cur = conn.execute(
        f"SELECT * FROM prompt_fragments ORDER BY {order} LIMIT ?", (limit,)
    )
    return [
        PromptFragment(
            id=row["id"],
            text=row["text"],
            category=row["category"],
            platform_compat=json.loads(row["platform_compat"]) if row["platform_compat"] else [],
            usage_count=row["usage_count"],
            avg_rating=row["avg_rating"],
        )
        for row in cur.fetchall()
    ]


def update_fragment_ratings(conn: sqlite3.Connection) -> None:
    """Recompute avg_rating for all fragments based on linked generations."""
    conn.execute(
        """UPDATE prompt_fragments SET avg_rating = (
            SELECT COALESCE(AVG(g.rating), 0)
            FROM fragment_usage fu
            JOIN generations g ON fu.generation_id = g.id
            WHERE fu.fragment_id = prompt_fragments.id
            AND g.rating > 0
        )"""
    )
    conn.commit()


def _guess_category(text: str) -> FragmentCategory | None:
    """Heuristic category detection from fragment text."""
    lower = text.lower()
    for category, hints in _CATEGORY_HINTS.items():
        if any(hint in lower for hint in hints):
            return category
    return None
