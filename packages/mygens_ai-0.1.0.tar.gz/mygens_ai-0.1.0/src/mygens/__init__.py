"""MyGens — The lab notebook for generative AI."""

__version__ = "0.1.0"
