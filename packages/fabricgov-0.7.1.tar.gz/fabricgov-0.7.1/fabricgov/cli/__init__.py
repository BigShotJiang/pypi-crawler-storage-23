from fabricgov.cli.main import cli

__all__ = ["cli"]