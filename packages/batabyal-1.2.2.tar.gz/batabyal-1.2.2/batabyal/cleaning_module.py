import pandas as pd
from pathlib import Path

def clean_csv(file:Path, numericData:list[str], charData:list[str], fill:bool, case_sensitivity:bool=False, dummies=None) -> pd.DataFrame :

	"""
    Clean a CSV file by handling missing values, duplicates, and optional dummy replacements
    """
	
	if not file.exists():
		raise FileNotFoundError(file)
	if not file.is_file():
		raise ValueError("Path is not a file")

	df = pd.read_csv(file)
	for i in charData :
		df[i] = df[i].str.strip()
		if not case_sensitivity:
			df[i] = df[i].str.lower()
	df.replace('',pd.NA, inplace=True)
	if dummies :
		df.replace(dummies,pd.NA, inplace=True)
	df.dropna(how='all',inplace=True)
	df = df.drop_duplicates()
	for i in charData :
		df.dropna(subset=[i],inplace=True)
	if fill :
		for i in numericData :
			df[i] = df[i].fillna(df[i].mean())
		return df
	df.dropna(inplace=True)
	return df