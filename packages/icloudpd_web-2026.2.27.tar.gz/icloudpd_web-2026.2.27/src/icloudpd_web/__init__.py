"""
icloudpd-web package.
"""

__version__ = "2026.2.27"
