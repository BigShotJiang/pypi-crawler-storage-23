import logging

from pyicloud_ipd.base import PyiCloudService as PyiCloudService

logging.getLogger(__name__).addHandler(logging.NullHandler())
