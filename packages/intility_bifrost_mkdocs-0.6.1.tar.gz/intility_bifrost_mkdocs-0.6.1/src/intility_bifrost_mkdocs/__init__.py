"""Intility Bifrost theme plugin for MkDocs Material."""
