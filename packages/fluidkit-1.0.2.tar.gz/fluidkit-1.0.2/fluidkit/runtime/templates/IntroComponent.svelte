<section class="hero page">
	<div class="logo-row">
		<!-- Svelte -->
		<div class="logo-cell">
			<div class="logo-wrap">
				<div class="glow glow-svelte"></div>
				<svg class="logo-svg float-1" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
					<path class="svelte-path" d="M27.573 4.229c-2.927-4.25-8.656-5.479-13.068-2.802l-7.464 4.745c-2.042 1.281-3.443 3.365-3.854 5.734-0.365 1.969-0.047 4.005 0.891 5.776-0.641 0.964-1.073 2.052-1.266 3.198-0.427 2.406 0.13 4.885 1.547 6.88 2.932 4.24 8.646 5.474 13.068 2.828l7.469-4.75c2.031-1.281 3.427-3.365 3.839-5.734 0.359-1.964 0.042-3.995-0.896-5.755 1.984-3.115 1.88-7.12-0.266-10.12zM13.76 28.172c-2.401 0.625-4.938-0.318-6.349-2.359-0.865-1.198-1.182-2.677-0.932-4.146l0.146-0.708 0.135-0.438 0.401 0.266c0.88 0.667 1.865 1.146 2.917 1.469l0.271 0.094-0.031 0.266c-0.026 0.37 0.083 0.786 0.297 1.104 0.438 0.63 1.198 0.932 1.932 0.734 0.161-0.052 0.318-0.104 0.453-0.188l7.438-4.745c0.375-0.24 0.615-0.599 0.708-1.026 0.083-0.443-0.026-0.896-0.266-1.255-0.443-0.615-1.198-0.891-1.932-0.708-0.161 0.057-0.333 0.12-0.469 0.203l-2.813 1.786c-2.661 1.583-6.099 0.839-7.865-1.708-0.859-1.198-1.198-2.693-0.938-4.146 0.26-1.438 1.12-2.698 2.365-3.469l7.422-4.745c0.469-0.292 0.974-0.505 1.521-0.667 2.401-0.625 4.932 0.318 6.349 2.349 1 1.406 1.281 3.203 0.76 4.849l-0.135 0.443-0.385-0.266c-0.891-0.651-1.88-1.146-2.932-1.469l-0.266-0.078 0.026-0.266c0.026-0.391-0.083-0.802-0.297-1.12-0.438-0.63-1.198-0.896-1.932-0.708-0.161 0.052-0.318 0.104-0.453 0.188l-7.453 4.786c-0.375 0.25-0.615 0.599-0.693 1.036-0.078 0.427 0.026 0.896 0.266 1.24 0.427 0.63 1.203 0.896 1.922 0.708 0.172-0.052 0.333-0.104 0.464-0.188l2.844-1.813c0.464-0.307 0.984-0.531 1.516-0.677 2.417-0.63 4.938 0.318 6.349 2.359 0.865 1.198 1.198 2.677 0.958 4.13-0.25 1.438-1.099 2.698-2.333 3.469l-7.438 4.734c-0.484 0.292-1.005 0.521-1.547 0.677z"/>
				</svg>
			</div>
			<span class="label label-svelte">SvelteKit</span>
		</div>

		<!-- Left Beam -->
		<div class="beam beam-left">
			<div class="beam-line"></div>
			<div class="beam-glow"></div>
			<div class="beam-particle p1"></div>
			<div class="beam-particle p2"></div>
			<div class="beam-particle p3"></div>
		</div>

		<!-- FluidKit -->
		<div class="logo-cell center-cell">
			<div class="logo-wrap wrap-fk">
				<div class="glow glow-fk"></div>
				<svg class="logo-svg logo-fk float-2" viewBox="0 0 250 250" xmlns="http://www.w3.org/2000/svg">
					<g>
						<rect class="fk-bg" width="250" height="250" rx="38"/>
						<rect id="lg" class="fk-shape" x="65" y="38" width="148" height="82" rx="12"/>
						<rect id="md" class="fk-shape" x="51" y="84" width="105" height="83" rx="12"/>
						<rect id="sm" class="fk-shape" x="38" y="130" width="61" height="82" rx="12"/>
					</g>
				</svg>
			</div>
			<span class="label label-fk">FluidKit</span>
		</div>

		<!-- Right Beam -->
		<div class="beam beam-right">
			<div class="beam-line"></div>
			<div class="beam-glow"></div>
			<div class="beam-particle p1"></div>
			<div class="beam-particle p2"></div>
			<div class="beam-particle p3"></div>
		</div>

		<!-- Python -->
		<div class="logo-cell">
			<div class="logo-wrap">
				<div class="glow glow-python"></div>
				<svg class="logo-svg float-3" viewBox="0 0 110 110" xmlns="http://www.w3.org/2000/svg">
					<path class="py-blue" d="M54.8,3.6c-26.1,0-24.8,11.3-24.8,11.3l0,11.5h25.4v3.6H24.3c0,0-17.5-2.1-17.5,25.4 c0,27.5,15.2,26.4,15.2,26.4h11.1v-12.6c0,0-0.2-14.7,14.6-14.7h15.9c0,0,14.3,0.3,14.3-13.8V21.6c0,0,1.9-18-23.1-18H54.8z M41.8,11.8c2.4,0,4.3,1.9,4.3,4.3c0,2.4-1.9,4.3-4.3,4.3c-2.4,0-4.3-1.9-4.3-4.3C37.5,13.7,39.4,11.8,41.8,11.8z"/>
					<path class="py-yellow" d="M55.4,106.6c26.1,0,24.8-11.3,24.8-11.3l0-11.5H54.8v-3.6h31.1c0,0,17.5,2.1,17.5-25.4 c0-27.5-15.2-26.4-15.2-26.4H77.1v12.6c0,0,0.2,14.7-14.6,14.7H46.6c0,0-14.3-0.3-14.3,13.8v19.1c0,0-1.9,18,23.1,18H55.4z M68.4,98.4c-2.4,0-4.3-1.9-4.3-4.3c0-2.4,1.9-4.3,4.3-4.3c2.4,0,4.3,1.9,4.3,4.3C72.7,96.5,70.8,98.4,68.4,98.4z"/>
				</svg>
			</div>
			<span class="label label-python">Python</span>
		</div>
	</div>

	<!-- Title -->
	<div class="title-block">
		<h1 class="title">FluidKit</h1>
		<p class="tagline">Web development for the Pythonist</p>
		<div class="install">
			<code>pip install fluidkit</code>
		</div>
	</div>

    <div class="links">
		<a href="https://github.com/AswanthManoj/Fluidkit" target="_blank" rel="noopener" class="link-icon" aria-label="GitHub">
			<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>
		</a>
		<a href="https://svelte.dev/docs/kit/remote-functions" target="_blank" rel="noopener" class="link-icon" aria-label="SvelteKit Docs">
			<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 2l5 5h-5V4zM6 20V4h5v7h7v9H6z"/></svg>
		</a>
	</div>

	<div class="scroll-hint">
		<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
			<path d="M7 10l5 5 5-5"/>
		</svg>
	</div>
</section>


<style>
	.hero {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 3.5rem;
		padding: 4rem 2rem 1rem;
	}

	.logo-row {
		display: flex;
		align-items: center;
		gap: 0;
	}

	/* ── Logo Cells ─────────────────────────────── */
	.logo-cell {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 1rem;
	}

	.logo-wrap {
		position: relative;
		width: 90px;
		height: 90px;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.wrap-fk {
		width: 110px;
		height: 110px;
	}

	.logo-svg {
		width: 100%;
		height: 100%;
		position: relative;
		z-index: 2;
	}

	/* ── Floating (staggered) ───────────────────── */
	.float-1 { animation: float 5s ease-in-out infinite; }
	.float-2 { animation: float 5s ease-in-out 0.8s infinite; }
	.float-3 { animation: float 5s ease-in-out 1.6s infinite; }

	@keyframes float {
		0%, 100% { transform: translateY(0); }
		50% { transform: translateY(-10px); }
	}

	/* ── Glow Orbs ──────────────────────────────── */
	.glow {
		position: absolute;
		width: 80%;
		height: 80%;
		border-radius: 50%;
		z-index: 1;
		opacity: 0;
		filter: blur(40px);
		animation: glowIn 1.5s 2s ease-out forwards;
	}

	.glow-svelte  { background: #ff3e00; }
	.glow-fk      { background: linear-gradient(135deg, #45A9EC, #7A60FD); }
	.glow-python   { background: linear-gradient(135deg, #3776AB, #FFD43B); }

	@keyframes glowIn {
		to { opacity: 0.35; }
	}

	/* ── Labels ──────────────────────────────────── */
	.label {
		font-size: 0.7rem;
		font-weight: 500;
		letter-spacing: 0.08em;
		text-transform: uppercase;
		opacity: 0;
		animation: fadeUp 0.8s 3.2s ease-out forwards;
	}

	.label-svelte { color: #ff3e00; }
	.label-fk     { color: #68D7EF; }
	.label-python  { color: #3776AB; }

	/* ── Svelte Logo Anim ───────────────────────── */
	.svelte-path {
		fill: transparent;
		stroke: #ff3e00;
		stroke-width: 0.5;
		stroke-dasharray: 250;
		stroke-dashoffset: 250;
		stroke-linecap: round;
		stroke-linejoin: round;
		animation: draw 2s ease-out forwards, fillSvelte 1s 2s ease-in forwards;
	}

	@keyframes fillSvelte {
		to { fill: #ff3e00; stroke: transparent; }
	}

	/* ── FluidKit Logo Anim ─────────────────────── */
	.fk-bg {
		fill: transparent;
		stroke: rgba(255, 255, 255, 0.12);
		stroke-width: 4;
		stroke-dasharray: 1000;
		stroke-dashoffset: 1000;
		animation: draw 2s ease-out forwards, fillFkBg 1s 2s ease-in forwards;
	}

	@keyframes fillFkBg {
		to { fill: rgba(255, 255, 255, 0.05); stroke: rgba(255, 255, 255, 0.06); }
	}

	.fk-shape {
		fill: transparent;
		stroke-width: 8;
		stroke-dasharray: 600;
		stroke-dashoffset: 600;
		stroke-linejoin: round;
		stroke-linecap: round;
	}

	#lg {
		stroke: #68D7EF;
		animation: draw 2s ease-out forwards, fillShape 1s 2s ease-in forwards;
		--fill: #68D7EF;
	}
	#md {
		stroke: #45A9EC;
		animation: draw 2s ease-out forwards, fillShape 1s 2s ease-in forwards;
		--fill: #45A9EC;
	}
	#sm {
		stroke: #7A60FD;
		animation: draw 2s ease-out forwards, fillShape 1s 2s ease-in forwards;
		--fill: #7A60FD;
	}

	@keyframes fillShape {
		to { fill: var(--fill); stroke: transparent; }
	}

	/* ── Python Logo Anim ───────────────────────── */
	.py-blue, .py-yellow {
		fill: transparent;
		stroke-width: 2;
		stroke-dasharray: 600;
		stroke-dashoffset: 600;
		stroke-linecap: round;
		stroke-linejoin: round;
	}

	.py-blue {
		stroke: #3776AB;
		animation: draw 2s ease-out forwards, fillPyBlue 1s 2s ease-in forwards;
	}
	.py-yellow {
		stroke: #FFD43B;
		animation: draw 2s ease-out forwards, fillPyYellow 1s 2s ease-in forwards;
	}

	@keyframes fillPyBlue  { to { fill: #3776AB;  stroke: transparent; } }
	@keyframes fillPyYellow { to { fill: #FFD43B; stroke: transparent; } }

	/* ── Shared draw ────────────────────────────── */
	@keyframes draw {
		to { stroke-dashoffset: 0; }
	}

	/* ── Beams ───────────────────────────────────── */
	.beam {
		position: relative;
		width: 100px;
		height: 40px;
		display: flex;
		align-items: center;
		flex-shrink: 0;
	}

	.beam-line {
		position: absolute;
		width: 100%;
		height: 1.5px;
		border-radius: 1px;
		opacity: 0;
		animation: fadeIn 1s 2.6s ease-out forwards, beamPulse 3s 3.6s ease-in-out infinite;
	}

	.beam-left .beam-line {
		background: linear-gradient(90deg, #ff3e00, #68D7EF);
	}
	.beam-right .beam-line {
		background: linear-gradient(90deg, #7A60FD, #3776AB);
	}

	.beam-glow {
		position: absolute;
		width: 100%;
		height: 12px;
		border-radius: 6px;
		filter: blur(6px);
		opacity: 0;
		animation: fadeIn 1s 2.6s ease-out forwards;
	}

	.beam-left .beam-glow {
		background: linear-gradient(90deg, rgba(255,62,0,0.15), rgba(104,215,239,0.2));
	}
	.beam-right .beam-glow {
		background: linear-gradient(90deg, rgba(122,96,253,0.2), rgba(55,118,171,0.15));
	}

	@keyframes beamPulse {
		0%, 100% { opacity: 0.6; }
		50% { opacity: 1; }
	}

	/* ── Beam Particles ─────────────────────────── */
	.beam-particle {
		position: absolute;
		width: 6px;
		height: 6px;
		border-radius: 50%;
		top: 50%;
		transform: translateY(-50%);
		opacity: 0;
	}

	/* Left beam — particles converge toward center (move right) */
	.beam-left .beam-particle {
		background: #68D7EF;
		box-shadow: 0 0 6px 2px rgba(104,215,239,0.6), 0 0 16px 4px rgba(104,215,239,0.2);
	}
	.beam-left .p1 { animation: orbRight 2.2s 3s ease-in-out infinite; }
	.beam-left .p2 { animation: orbRight 2.8s 3.6s ease-in-out infinite; width: 4px; height: 4px; }
	.beam-left .p3 { animation: orbRight 1.8s 4.2s ease-in-out infinite; width: 3px; height: 3px; }

	/* Right beam — particles converge toward center (move left) */
	.beam-right .beam-particle {
		background: #7A60FD;
		box-shadow: 0 0 6px 2px rgba(122,96,253,0.6), 0 0 16px 4px rgba(122,96,253,0.2);
	}
	.beam-right .p1 { animation: orbLeft 2.4s 3.2s ease-in-out infinite; }
	.beam-right .p2 { animation: orbLeft 2s 3.8s ease-in-out infinite; width: 4px; height: 4px; }
	.beam-right .p3 { animation: orbLeft 2.6s 4.4s ease-in-out infinite; width: 3px; height: 3px; }

	@keyframes orbRight {
		0%   { left: -6px;  opacity: 0; }
		10%  { opacity: 1; }
		85%  { opacity: 1; }
		100% { left: calc(100% + 6px); opacity: 0; }
	}

	@keyframes orbLeft {
		0%   { left: calc(100% + 6px); opacity: 0; }
		10%  { opacity: 1; }
		85%  { opacity: 1; }
		100% { left: -6px; opacity: 0; }
	}

	/* ── Title Block ─────────────────────────────── */
	.title-block {
		text-align: center;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 0.75rem;
		opacity: 0;
		animation: fadeUp 1s 3s ease-out forwards;
	}

	.title {
		font-size: 2.5rem;
		font-weight: 700;
		margin: 0;
		background: linear-gradient(135deg, #68D7EF, #7A60FD);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		background-clip: text;
		letter-spacing: -0.02em;
	}

	.tagline {
		margin: 0;
		color: #a8a29e;
		font-size: 1.05rem;
		font-weight: 400;
	}

	.install {
		margin-top: 0.5rem;
	}

	.install code {
		font-family: 'JetBrains Mono', 'Fira Code', monospace;
		font-size: 0.85rem;
		color: #d6d3d1;
		background: rgba(255,255,255,0.04);
		border: 1px solid rgba(255,255,255,0.08);
		padding: 0.5rem 1.2rem;
		border-radius: 8px;
		display: inline-block;
	}

	/* ── Shared keyframes ────────────────────────── */
	@keyframes fadeIn {
		to { opacity: 0.5; }
	}

	@keyframes fadeUp {
		from { opacity: 0; transform: translateY(12px); }
		to   { opacity: 1; transform: translateY(0); }
	}

	/* ── Responsive ──────────────────────────────── */
	@media (max-width: 640px) {
		.logo-wrap   { width: 60px; height: 60px; }
		.wrap-fk     { width: 76px; height: 76px; }
		.beam        { width: 50px; }
		.title       { font-size: 1.75rem; }
		.tagline     { font-size: 0.9rem; }
		.label       { font-size: 0.6rem; }
	}

    /* ── Footer Links ────────────────────────────── */
	.links {
		display: flex;
		gap: 1rem;
		margin-top: 1rem;
	}

	.link-icon {
		width: 32px;
		height: 32px;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 8px;
		background: rgba(255, 255, 255, 0.04);
		border: 1px solid rgba(255, 255, 255, 0.08);
		color: rgba(255, 255, 255, 0.4);
		backdrop-filter: blur(8px);
		transition: all 0.3s ease;
		text-decoration: none;
	}

	.link-icon:hover {
		color: rgba(255, 255, 255, 0.9);
		background: rgba(255, 255, 255, 0.08);
		border-color: rgba(255, 255, 255, 0.15);
		box-shadow: 0 0 16px rgba(255, 255, 255, 0.08);
	}

	.link-icon svg {
		width: 16px;
		height: 16px;
	}

	.scroll-hint {
		color: #8f8984;
		animation: bob 2s 4s ease-in-out infinite;
		opacity: 0;
		animation: fadeUp 1s 4s ease-out forwards, bob 2s 5s ease-in-out infinite;
	}

	@keyframes bob {
		0%, 100% { transform: translateY(0); }
		50% { transform: translateY(6px); }
	}
</style>
