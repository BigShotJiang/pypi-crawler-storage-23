"""
Caching utilities for Arshai.
"""

from .decorators import cache_result

__all__ = [
    'cache_result',
]