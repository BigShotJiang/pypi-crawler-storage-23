"""Version information for arshai package."""

__version__ = "1.9.1"
__version_info__ = (1, 9, 1)
__author__ = "Nima Nazarian"
__email__ = "nimunzn@gmail.com"