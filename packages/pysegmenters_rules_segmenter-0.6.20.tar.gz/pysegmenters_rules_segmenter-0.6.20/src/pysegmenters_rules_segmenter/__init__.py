"""Rule-based segmenter"""

__version__ = "0.6.20"
