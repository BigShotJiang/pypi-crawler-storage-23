1. The "Big Four" (The Originals)

These were the first four flows ever created in the original 2012 rulebook (RFC 6749).

    Authorization Code Flow: The "Permission Slip." You get a temporary code and swap it for a badge. (Best for Web Apps).

    Implicit Flow: The "Shortcut." The badge is given directly in the URL. (Now considered Dangerous/Legacy).

    Resource Owner Password Credentials: The "House Keys." You give your password directly to the app. (Now Forbidden/Legacy).

    Client Credentials Flow: The "Robot ID." The app logs in as itself to do its own chores. (Best for Server-to-Server).

2. The "Modern Standard" (The Must-Have)

This is the update that made the internet much safer.

    Authorization Code + PKCE: The "Secret Handshake." It’s the standard Authorization Code flow but adds a scrambled secret word so no one can steal the ticket. (The Gold Standard for everything today).

3. The "Special Devices" Flow

For things that don't have a normal browser or keyboard.

    Device Authorization Grant: The "TV Code." The TV shows a code, you type it into your phone to log in. (RFC 8628). (Best for Smart TVs, CLI tools, and IoT).

4. The "Maintenance" Flow

This isn't for logging in the first time; it's for staying logged in.

    Refresh Token Flow: The "Badge Renewer." When your 1-hour VIP badge expires, you use a special "Refresh Token" to get a new one without typing your password again.

5. The "Assertion" Flows (The Translators)

These are used when you already have one kind of proof and need to swap it for an OAuth badge.

    SAML 2.0 Bearer: The "Enterprise Translator." Swapping an old-school XML "Official Letter" for a modern badge. (RFC 7522).

    JWT Bearer: The "Digital Signature." Swapping a signed digital note for a badge. Used for high-security machine talk. (RFC 7523).

6. The "Upgrade & Swap" Flows

The newest tools for complex systems with many parts.

    Token Exchange: The "Badge Swap." Trading a badge for one building for a badge for a different building. (RFC 8693).

    Token Delegation: (Part of Token Exchange). When an app says, "I'm acting for Bob, give me a token that proves I'm his assistant."

7. The "Rare/Extended" Flows

You might see these in very specific high-level setups.

    Ciba (Client Initiated Backchannel Authentication): The "Ping My Phone." Instead of a redirect, the app pings your phone directly and asks, "Is this you?" You click "Yes" on your phone, and the app logs in. (Common in banking apps).

    OpenID Connect (OIDC): While technically a "layer" on top of OAuth2, it adds the ID Token (The "ID Card") which tells the app exactly who you are (name, email, photo), whereas OAuth2 only tells the app what it is allowed to do.
