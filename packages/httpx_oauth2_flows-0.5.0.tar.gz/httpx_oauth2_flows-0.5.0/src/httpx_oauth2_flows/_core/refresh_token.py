import httpx
import pydantic

from httpx_oauth2_flows._lib import RequestData, Scope, Url, openid

from .grant_type import GrantType
from .token_response import SuccessfulTokenResponse, handle_token_response

# Public Types

GRANT_TYPE = GrantType.REFRESH_TOKEN


class Config(pydantic.BaseModel, frozen=True):
    auth_server: Url
    client_id: str
    refresh_token: str
    scope: Scope | None = None


# Private Impl


class _OpenID(pydantic.BaseModel):
    auth_server: Url
    issuer: str
    token_endpoint: Url


async def _fetch_openid(auth_server: Url, http_client: httpx.AsyncClient) -> _OpenID:
    openid_configuration = await openid.fetch_configuration(
        auth_server, http_client, check_support_grant_type=GRANT_TYPE.value
    )

    if openid_configuration.token_endpoint is None:
        msg = f'{auth_server} does not provide a token endpoint'
        raise RuntimeError(msg)

    return _OpenID(
        auth_server=auth_server,
        issuer=openid_configuration.issuer,
        token_endpoint=openid_configuration.token_endpoint,
    )


#  Public API


async def execute(config: Config, http_client: httpx.AsyncClient) -> SuccessfulTokenResponse:
    openid_info = await _fetch_openid(config.auth_server, http_client)

    data: RequestData = {
        'grant_type': GRANT_TYPE.value,
        'refresh_token': config.refresh_token,
        'client_id': config.client_id,
    }

    if config.scope is not None:
        data['scope'] = config.scope.formated

    response = await http_client.post(openid_info.token_endpoint, data=data)
    return handle_token_response(response)
