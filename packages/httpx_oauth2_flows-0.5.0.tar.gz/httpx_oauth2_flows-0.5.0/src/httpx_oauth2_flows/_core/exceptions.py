import abc
import typing as t

import httpx
import pydantic

from httpx_oauth2_flows._lib import Url, webserver


class BaseError(Exception): ...


# Private


def _format_collection(collection: t.Collection[str]) -> str:
    if len(collection) == 0:
        return ''

    if len(collection) == 1:
        return next(iter(collection))

    *firsts, last = collection
    return f'{", ".join(firsts)} or {last}'


def _format_client(client: tuple[str, int] | None) -> str:
    if client is None:
        return ''
    host, port = client
    return f'{host}:{port}'


class _BaseSupportedOptionsError(BaseError, abc.ABC):
    def __init__(
        self,
        auth_server: Url,
        *,
        needed: t.Collection[str],
        supported: t.Collection[str],
        option_name: str,
    ) -> None:
        self.auth_server = auth_server
        self.needed = needed
        self.supported_by_auth_server = supported
        super().__init__(
            f'{auth_server}'
            f' does not support the {_format_collection(needed)} {option_name}'
            f' only {_format_collection(supported)} is supported'
        )


class _BaseResponseError(BaseError, abc.ABC):
    def __init__(
        self,
        response: httpx.Response,
        *,
        endpoint_name: str,
        body_in_msg: bool,
        errors: t.Mapping[str, object],
    ) -> None:
        self.response = response
        super().__init__(
            f'Invalid response from {endpoint_name} ({response.url})'
            f', status: {response.status_code}'
            f', headers: {dict(response.headers.items())}'
            + (f', body: {response.text}' if body_in_msg else '')
            + ''.join(f', {k}: {v}' for k, v in errors.items())
        )


class _BaseResponseSchemaError(_BaseResponseError, abc.ABC):
    def __init__(
        self,
        response: httpx.Response,
        pydantic_error: pydantic.ValidationError,
        *,
        endpoint_name: str,
    ) -> None:
        self.pydantic_error = pydantic_error
        super().__init__(
            response,
            body_in_msg=True,
            endpoint_name=endpoint_name,
            errors={'.'.join(map(str, e['loc'])): e['msg'] for e in pydantic_error.errors()},
        )


class _BaseResponseLogicError(_BaseResponseError, abc.ABC):
    def __init__(
        self, response: httpx.Response, *, endpoint_name: str, errors: t.Mapping[str, object]
    ) -> None:
        self.response = response
        super().__init__(response, body_in_msg=False, endpoint_name=endpoint_name, errors=errors)


class _BaseInAuthorizeCallbackError(BaseError):
    def __init__(
        self, description: str, request: webserver.Request, *, errors: t.Mapping[str, object]
    ) -> None:
        super().__init__(
            f'{description} in authorize callback'
            f', from: {_format_client(request.client)}'
            f', method: {request.method}'
            f', path: {request.path}'
            f', query params: {request.query}'
            f', ' + ', '.join(f'{k}: {v}' for k, v in errors.items())
        )


# Public


class SupportedAuthMethodError(_BaseSupportedOptionsError):
    def __init__(
        self, auth_server: Url, *, needed: t.Collection[str], supported: t.Collection[str]
    ) -> None:
        super().__init__(auth_server, needed=needed, supported=supported, option_name='auth_method')


class TokenSchemaError(_BaseResponseSchemaError):
    def __init__(self, response: httpx.Response, pydantic_error: pydantic.ValidationError) -> None:
        super().__init__(response, pydantic_error, endpoint_name='token')


class TokenError(_BaseResponseLogicError):
    def __init__(
        self,
        response: httpx.Response,
        error: str,
        error_description: str | None,
        error_uri: Url | None,
    ) -> None:
        self.error = error
        self.error_description = error_description
        self.error_uri = error_uri
        super().__init__(
            response,
            endpoint_name='token',
            errors={'error': error, 'error_description': error_description, 'error_uri': error_uri},
        )


class AuthorizeCallbackWebServerError(BaseError): ...


class AuthorizeCallbackParamsError(_BaseInAuthorizeCallbackError):
    def __init__(self, request: webserver.Request, errors: t.Mapping[str, str]) -> None:
        super().__init__('Invalid params', request, errors=errors)


class AuthorizeCallbackStateError(_BaseInAuthorizeCallbackError):
    def __init__(self, request: webserver.Request) -> None:
        super().__init__(
            'The received state is differant from the generated one', request, errors={}
        )
