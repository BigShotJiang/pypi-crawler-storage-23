import datetime

import httpx
import pydantic

from httpx_oauth2_flows._lib import Url

from .exceptions import TokenError, TokenSchemaError

# Public Types


class SuccessfulTokenResponse(pydantic.BaseModel):
    access_token: str
    token_type: str
    expires_in: datetime.timedelta | None = None
    refresh_token: str | None = None
    scope: str | None = None


class ErrorTokenResponse(pydantic.BaseModel):
    error: str
    error_description: str | None = None
    error_uri: Url | None = None


type TokenResponse = SuccessfulTokenResponse | ErrorTokenResponse

# Private Impl


_TOKEN_RESPONSE_ADAPTER = pydantic.TypeAdapter[TokenResponse](TokenResponse)

# Public Api


def handle_token_response(response: httpx.Response) -> SuccessfulTokenResponse:
    # If the text encoding is invalid, response.text does not fail
    # so it will be handled by pydantic as invalid JSON
    try:
        response_model = _TOKEN_RESPONSE_ADAPTER.validate_json(response.text)
    except pydantic.ValidationError as exc:
        raise TokenSchemaError(response, exc) from exc

    if isinstance(response_model, ErrorTokenResponse):
        raise TokenError(
            response,
            error=response_model.error,
            error_description=response_model.error_description,
            error_uri=response_model.error_uri,
        )

    return response_model
