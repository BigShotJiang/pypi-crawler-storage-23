"""Insert tag plugin, for Markdown-It."""

from .funnel import insert_plugin

__all__ = ("insert_plugin", )

__title__ = "minchin.md-it.insert"
__tagline__ = "Superscript, for Markdown-IT-Py"
__version__ = "1.0.0"
__author__ = "William Minchin"
__email__ = "w_minchin@hotmail.com"
__license__ = "AGPL-3.0 License"
__copyright__ = "Copyright 2026 William Minchin"
__url__ = "https://github.com/MinchinWeb/minchin.md-it.insert"
