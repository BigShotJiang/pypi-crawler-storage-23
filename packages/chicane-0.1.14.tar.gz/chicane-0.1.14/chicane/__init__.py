"""Chicane — When Claude Code can't go straight, take the chicane."""
