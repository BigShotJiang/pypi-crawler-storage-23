# pollyweb-utils

Description...

## Installation

```bash
pip install pollyweb-utils
```

Import path after install:
- Install package name: `pollyweb-utils`
- Preferred import package: `pollyweb.utils`
- Legacy import package (still supported): `PW_UTILS`

## Quick Start

```python
from pollyweb.utils import LOG, FILESYSTEM, UTILS

LOG.Print("hello from pollyweb-utils")

file = FILESYSTEM.FILE("/tmp/example.txt")
file.Touch().WriteText("ok")

yaml_obj = UTILS.FromYaml("a: 1\nb: test")
LOG.Print(yaml_obj)
```

## Public API

Recommended top-level imports:

```python
from PW_UTILS import (
  DIRECTORY,
  FILE,
  FILESYSTEM,
  LOG,
  LOG_BUFFER,
  RUNNER,
  STRUCT,
  TESTS,
  UTILS,
)
```

For advanced usage, individual modules are also available under `PW_UTILS.*`.

Compatibility examples:

```python
from pollyweb.utils import *
LOG.Print("bla")

from pollyweb.utils import LOG
LOG.Print("explicit is better")
```

## Git Push Protection

Enable the repository pre-push hook (blocks pushes when security checks or tests fail):

```bash
./scripts/install-git-hooks.sh
```

What it does:
- Runs `scripts/check-security.sh` on every `git push`.
- `check-security.sh` runs:
  - `pip-audit` to detect vulnerable dependencies.
  - `bandit -q -r src` to detect source security issues.
- Runs `.venv/bin/python -m pytest -q` (or `python3 -m pytest -q` if no venv).
- Rejects the push if any security issues or test failures are found.

Install security tools in your active Python environment:

```bash
python3 -m pip install pip-audit "bandit[toml]"
```

## Publish (safe)

Use the safe publish script to avoid uploading unrelated wheels:

```bash
./scripts/publish-safe.sh --dry-run
./scripts/publish-safe.sh
```

What it does:
- Uses `playbooks/.venv/bin/python` when available.
- Builds artifacts in `dist/`.
- Uploads only files matching the current package name and version from `pyproject.toml`.
