"""Level 1: Linear circuits with analytical solutions."""
