"""
Tracks execution results
Provides live + final report
"""

from collections import defaultdict


class ExecutionTracker:

    def __init__(self):

        self.total = 0

        self.stats = defaultdict(int)

        self.results = []

    # ---------------------------------
    def start(self, total):

        self.total = total

    # ---------------------------------
    def record(
        self,
        phone,
        status,
        error=None
    ):

        self.stats[status] += 1

        self.results.append({
            "phone": phone,
            "status": status,
            "error": str(error) if error else None
        })

    # ---------------------------------
    def summary_text(self):

        return (
            "Execution Report\n\n"
            f"Total: {self.total}\n"
            f"Success: {self.stats['success']}\n"
            f"Flood: {self.stats['flood']}\n"
            f"RPC: {self.stats['rpc']}\n"
            f"Failed: {self.stats['failed']}"
        )
