# remottxrea/core/delay_engine.py

import asyncio
import random
from ..core.logger import get_action_logger

class DelayEngine:

    def __init__(self):
        self.logger = get_action_logger(
        action="delay_engine",
        session="system"
        )


        # بازه امن
        self.min_delay = 2
        self.max_delay = 20

        # دیلی بلند هر چند تسک
        self.long_pause_every = 5
        self.long_pause_range = (60, 120)

        self.counter = 0

    @staticmethod
    async def join_delay():
        await asyncio.sleep(
            random.uniform(8, 25)
        )

    @staticmethod
    async def leave_delay():
        await asyncio.sleep(
            random.uniform(5, 18)
        )
    
    @staticmethod
    async def forward_delay():
        await asyncio.sleep(
            random.uniform(6, 18)
        )

    @staticmethod
    async def change_profile():
        await asyncio.sleep(
            random.uniform(4, 20)
        )
        
    async def wait(self):

        self.counter += 1

        delay = random.uniform(
            self.min_delay,
            self.max_delay
        )

        self.logger.info(f"[Delay] {delay:.2f}s")

        await asyncio.sleep(delay)

        # Long pause
        if self.counter % self.long_pause_every == 0:

            long_delay = random.uniform(
                *self.long_pause_range
            )

            self.logger.info(f"[Long Pause] {long_delay:.2f}s")

            await asyncio.sleep(long_delay)


delay_engine = DelayEngine()
