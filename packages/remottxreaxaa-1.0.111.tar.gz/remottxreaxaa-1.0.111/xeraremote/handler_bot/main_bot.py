"""
Main Bot Entry
Production Ready
Compatible with CommandRegistry Architecture
"""

import asyncio
import logging
import signal
from contextlib import suppress

from pyrogram import Client, filters, idle
from pyrogram.types import Message

from ..config import main_config
from .command_registry import CommandRegistry


# ==========================================================
# LOGGING CONFIG
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

logger = logging.getLogger("REMOTTXREA_BOT")


# ==========================================================
# CREATE REGISTRY
# ==========================================================

registry = CommandRegistry()


# ==========================================================
# APP FACTORY
# ==========================================================

def create_app() -> Client:
    """
    Create and validate Pyrogram Client
    """

    if not main_config.BOT_TOKEN:
        raise ValueError("BOT_TOKEN is not set")

    if not main_config.API_ID:
        raise ValueError("API_ID is not set")

    if not main_config.API_HASH:
        raise ValueError("API_HASH is not set")

    logger.info("Creating bot client...")

    return Client(
        name="remottxrea_bot",
        bot_token=main_config.BOT_TOKEN,
        api_id=main_config.API_ID,
        api_hash=main_config.API_HASH,
        workers=10,
        in_memory=True,
    )


# ==========================================================
# ADMIN CHECK
# ==========================================================
from ..config.main_config import is_admin

# ==========================================================
# STARTUP
# ==========================================================

async def startup():
    """
    Load multi-session runner and other services
    """

    logger.info("Loading session pool...")
    await registry.runner.load_all()

    logger.info("Startup completed.")


# ==========================================================
# SHUTDOWN
# ==========================================================

async def shutdown(app: Client):
    """
    Graceful shutdown
    """

    logger.info("Stopping bot...")

    with suppress(Exception):
        await registry.runner.stop_all()

    with suppress(Exception):
        await app.stop()

    logger.info("Bot stopped cleanly.")


# ==========================================================
# MAIN RUN
# ==========================================================

def run():

    app = create_app()

    # ------------------------------------------------------
    # MESSAGE HANDLER
    # ------------------------------------------------------

    @app.on_message(filters.private)
    async def on_message(client: Client, message: Message):

        if not message.from_user:
            return

        if not is_admin(message.from_user.id):
            logger.warning(
                f"Unauthorized access attempt: {message.from_user.id}"
            )
            return

        handler = registry.resolve(message)

        if not handler:
            return

        try:
            await handler.handle(message)
        except Exception as e:
            logger.exception(f"Handler error: {e}")
            await message.reply("⚠️ Internal error occurred.")

    # ------------------------------------------------------
    # START SEQUENCE
    # ------------------------------------------------------

    async def main():
        await startup()
        await app.start()
        logger.info("Bot is running...")
        await idle()

    loop = asyncio.get_event_loop()

    # Graceful signal handling
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            sig,
            lambda: asyncio.create_task(shutdown(app))
        )

    try:
        loop.run_until_complete(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Exit signal received.")
    finally:
        loop.run_until_complete(shutdown(app))
        loop.close()


# ==========================================================
# ENTRY
# ==========================================================

if __name__ == "main":
    run()