"""
Command Registry
Production Ready Version
State Priority + MultiSessionRunner Integrated
"""

from typing import Optional

# ==============================
# Core Handlers
# ==============================

from .handlers.add_account import AddAccountHandler
from .handlers.change_name import ChangeNameHandler
from .handlers.change_photo import ChangePhotoHandler
from .handlers.join_leave import JoinLeaveHandler
from .handlers.list_account import AccountOverviewHandler
from .handlers.start import Start

# ==============================
# Sender / Spammer
# ==============================

from .handlers.sender_handler import SenderHandlers
from .handlers.target_spammer_handler import TargetSpammerHandler

# ==============================
# Text Handlers (Function Based)
# ==============================

from .handlers.text_handler import (
    handle_add_multi,
    handle_add_text,
    handle_clear,
    handle_list_text,
    handle_remove_text,
)

# ==============================
# Runner
# ==============================

from ..runner.multi_session_runner import MultiSessionRunner


# ==========================================================
# FUNCTION WRAPPER
# ==========================================================

class FunctionHandler:
    """
    Wrap async function(client, message)
    into object with .handle(message)
    to match router architecture
    """

    def __init__(self, func):
        self.func = func

    async def handle(self, message):
        await self.func(message._client, message)


# ==========================================================
# COMMAND REGISTRY
# ==========================================================

class CommandRegistry:

    def __init__(self):

        # --------------------------------------
        # Runner (Core Engine)
        # --------------------------------------
        self.runner = MultiSessionRunner()

        # --------------------------------------
        # Class-Based Handlers
        # --------------------------------------
        self.add_account = AddAccountHandler()
        self.change_name = ChangeNameHandler(self.runner)
        self.change_photo = ChangePhotoHandler(self.runner)
        self.join_leave = JoinLeaveHandler(self.runner)
        self.list_accounts = AccountOverviewHandler(self.runner)
        self.start_bot = Start()

        # Sender Systems
        self.sender = SenderHandlers(self.runner)
        self.target_spammer = TargetSpammerHandler(self.runner)

        # --------------------------------------
        # Function-Based Handlers
        # --------------------------------------
        self.text_add = FunctionHandler(handle_add_text)
        self.text_remove = FunctionHandler(handle_remove_text)
        self.text_multi = FunctionHandler(handle_add_multi)
        self.text_list = FunctionHandler(handle_list_text)
        self.text_clear = FunctionHandler(handle_clear)

        # --------------------------------------
        # Command Map
        # --------------------------------------
        self.command_map = {

            # ========================
            # Base Commands
            # ========================
            "start": self.start_bot,
            "addaccount": self.add_account,
            "listacc": self.list_accounts,
            "changefname": self.change_name,
            "changename": self.change_name,
            "changephoto": self.change_photo,
            "join": self.join_leave,
            "leave": self.join_leave,

            # ========================
            # Text System
            # ========================
            "text": self.text_add,
            "deltext": self.text_remove,
            "textmulti": self.text_multi,
            "listtext": self.text_list,
            "cleartext": self.text_clear,

            # ========================
            # Sender (Manual Mode)
            # ========================
            "sender_start": self.sender,
            "sender_stop": self.sender,
            "sender_status": self.sender,
            "sender_help": self.sender,

            # ========================
            # Target Spammer Mode
            # ========================
            "set_target": self.target_spammer,
            "show_target": self.target_spammer,
            "clear_target": self.target_spammer,
            "spam_start": self.target_spammer,
            "spam_stop": self.target_spammer,
            "spam_status": self.target_spammer,
            "spam_help": self.target_spammer,
        }

    # ======================================================
    # RESOLVE HANDLER
    # ======================================================

    def resolve(self, message) -> Optional[object]:

        if not message or not message.text:
            return None

        if not message.from_user:
            return None

        text = message.text.strip()
        user_id = message.from_user.id

        # ============================================
        # 1️⃣ AddAccount State Priority
        # ============================================

        if user_id in getattr(self.add_account, "states", {}):
            return self.add_account

        # ============================================
        # 2️⃣ Extract Command
        # ============================================

        command = text.split(" ", 1)[0].lower()

        # Remove /
        if command.startswith("/"):
            command = command[1:]

        # Remove @