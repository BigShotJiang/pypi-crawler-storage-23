"""
Spammer Config Handlers
Full Integration with SpammerConfig
Production Ready
"""

from xeraremote.config.spammer_config import SpammerConfig


class SpammerConfigHandlers:

    async def handle(self, message):

        if not message.text:
            return

        parts = message.text.strip().split()
        command = parts[0].lower()

        # =========================
        # TARGETS
        # =========================

        if command == "add_target":
            await self._add_target(message, parts)

        elif command == "remove_target":
            await self._remove_target(message, parts)

        elif command == "list_targets":
            await self._list_targets(message)

        elif command == "clear_targets":
            await self._clear_targets(message)

        # =========================
        # TEXTS
        # =========================

        elif command == "add_text":
            await self._add_text(message)

        elif command == "remove_text":
            await self._remove_text(message)

        elif command == "list_texts":
            await self._list_texts(message)

        elif command == "clear_texts":
            await self._clear_texts(message)

        # =========================
        # DELAY
        # =========================

        elif command == "set_speed":
            await self._set_speed(message, parts)

        elif command == "current_speed":
            await self._current_speed(message)

        # =========================
        # ANTI BAN
        # =========================

        elif command == "anti_ban_on":
            await self._anti_ban_on(message)

        elif command == "anti_ban_off":
            await self._anti_ban_off(message)

        elif command == "anti_ban_status":
            await self._anti_ban_status(message)

    # ======================================================
    # TARGETS
    # ======================================================

    async def _add_target(self, message, parts):
        await message.reply("Use target_manager for adding validated targets.")

    async def _remove_target(self, message, parts):
        if len(parts) < 2:
            await message.reply("Usage: remove_target <chat_id>")
            return

        try:
            chat_id = int(parts[1])
        except ValueError:
            await message.reply("chat_id must be numeric.")
            return

        SpammerConfig.remove_target(chat_id)
        await message.reply("Target removed.")

    async def _list_targets(self, message):
        targets = SpammerConfig.get_targets()

        if not targets:
            await message.reply("No targets configured.")
            return

        text = "Targets:\n"
        for t in targets:
            text += f"- {t['chat_id']} | {t.get('username')}\n"

        await message.reply(text)

    async def _clear_targets(self, message):
        SpammerConfig.clear_targets()
        await message.reply("All targets cleared.")

    # ======================================================
    # TEXTS
    # ======================================================

    async def _add_text(self, message):
        if len(message.text.split()) < 2:
            await message.reply("Usage: add_text <your message>")
            return

        text_content = message.text.split(maxsplit=1)[1]
        SpammerConfig.add_text(text_content)

        await message.reply("Text added.")

    async def _remove_text(self, message):
        if len(message.text.split()) < 2:
            await message.reply("Usage: remove_text <exact text>")
            return

        text_content = message.text.split(maxsplit=1)[1]
        SpammerConfig.remove_text(text_content)

        await message.reply("Text removed if existed.")

    async def _list_texts(self, message):
        texts = SpammerConfig.get_texts()

        if not texts:
            await message.reply("No texts configured.")
            return

        text = "Texts:\n"
        for i, t in enumerate(texts, 1):
            text += f"{i}. {t}\n"

        await message.reply(text)

    async def _clear_texts(self, message):
        config = SpammerConfig._load()
        config["texts"] = []
        SpammerConfig._save(config)
        await message.reply("All texts cleared.")

    # ======================================================
    # DELAY
    # ======================================================

    async def _set_speed(self, message, parts):
        if len(parts) < 2:
            await message.reply("Usage: set_speed <fast|medium|slow>")
            return

        mode = parts[1].lower()

        try:
            SpammerConfig.set_delay_mode(mode)
            await message.reply(f"Speed set to {mode}.")
        except ValueError:
            await message.reply("Invalid speed. Use fast, medium, slow.")

    async def _current_speed(self, message):
        mode = SpammerConfig.get_delay_mode()
        await message.reply(f"Current speed: {mode}")

    # ======================================================
    # ANTI BAN
    # ======================================================

    async def _anti_ban_on(self, message):
        SpammerConfig.enable_anti_ban()
        await message.reply("Anti-Ban mode enabled.")

    async def _anti_ban_off(self, message):
        SpammerConfig.disable_anti_ban()
        await message.reply("Anti-Ban mode disabled.")

    async def _anti_ban_status(self, message):
        status = SpammerConfig.is_anti_ban_enabled()
        await message.reply(f"Anti-Ban status: {'ON' if status else 'OFF'}")