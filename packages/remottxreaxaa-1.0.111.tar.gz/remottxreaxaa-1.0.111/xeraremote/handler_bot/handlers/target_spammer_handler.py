# remottxrea/handler_bot/handlers/target_spammer_handler.py

"""
Target Spammer Handler
مدیریت تارگت ذخیره شده و اسپمر
دستورات:
set_target [LINK/ID/USERNAME]  - تنظیم تارگت
show_target                    - نمایش تارگت فعلی
clear_target                   - پاک کردن تارگت
spam_start [message] [delay] [counter] - شروع اسپم با تارگت ذخیره شده
spam_stop                      - توقف اسپم
spam_status                    - وضعیت اسپم
spam_help                      - راهنما
"""

import asyncio
from typing import Dict, Optional

from pyrogram.types import Message

from ...actions.target_spammer import TargetManager
from ...config.spammer_config import (
    set_target, get_target, clear_target, 
    is_target_active, TARGET_TYPE, TARGET_RAW
)
from ...core.logger import get_action_logger


class TargetSpammerHandler:
    """
    هندلر مدیریت و اجرای اسپم به تارگت ذخیره شده
    """

    def __init__(self, runner):
        self.runner = runner
        self.logger = get_action_logger("handler", "target_spammer")
        
        # اسپمرها و تسک‌ها
        self.spammers: Dict[str, TargetManager] = {}
        self.running_tasks: Dict[str, asyncio.Task] = {}

    # ==================================================
    # تشخیص نوع تارگت (برای نمایش)
    # ==================================================

    def detect_target_type(self, target: str) -> str:
        """تشخیص نوع تارگت برای نمایش"""
        target = str(target).strip()

        if 't.me/+' in target or 'joinchat' in target:
            return "private_link"
        if 't.me/' in target:
            return "public_link"
        if target.startswith('@') or target.replace('_', '').isalnum():
            return "username"
        if target.lstrip('-').isdigit():
            return "numeric_id"
        return "unknown"

    # ==================================================
    # نمایش تارگت
    # ==================================================

    async def show_target(self, message: Message):
        """نمایش تارگت فعلی"""
        target = get_target()
        
        if not target:
            await message.reply_text("❌ هیچ تارگتی تنظیم نشده است")
            return

        type_names = {
            "private_link": "🔒 لینک خصوصی",
            "public_link": "🌐 لینک عمومی",
            "username": "👤 یوزرنیم",
            "numeric_id": "🔢 آیدی عددی",
            "unknown": "❓ ناشناخته"
        }

        target_type_display = type_names.get(TARGET_TYPE, "نامشخص")
        raw_display = TARGET_RAW or str(target)

        await message.reply_text(
            f"🎯 **تارگت فعلی**\n\n"
            f"📌 **آیدی نهایی:** `{target}`\n"
            f"🔍 **نوع:** {target_type_display}\n"
            f"📝 **ورودی خام:** `{raw_display}`\n"
            f"✅ **وضعیت:** فعال\n\n"
            f"➡️ برای شروع: `spam_start [message] [delay] [counter]`"
        )

    # ==================================================
    # توقف همه
    # ==================================================

    async def stop_all(self, message: Optional[Message] = None):
        """توقف همه اسپمرها"""
        if not self.spammers:
            if message:
                await message.reply_text("❌ هیچ اسپمی فعال نیست")
            return

        count = len(self.spammers)

        # توقف اسپمرها
        for phone, spammer in self.spammers.items():
            try:
                spammer.stop()
                self.logger.info(f"Stop signal sent to {phone}")
            except Exception as e:
                self.logger.error(f"Error stopping {phone}: {e}")

        # کنسل کردن تسک‌ها
        for phone, task in self.running_tasks.items():
            if not task.done():
                task.cancel()
                self.logger.info(f"Task cancelled for {phone}")

        self.spammers.clear()
        self.running_tasks.clear()

        if message:
            await message.reply_text(f"✅ اسپم برای {count} اکانت متوقف شد")

    # ==================================================
    # نمایش وضعیت
    # ==================================================

    async def show_status(self, message: Message):
        """نمایش وضعیت اسپمرها"""
        if not self.spammers:
            await message.reply_text("❌ هیچ اسپمی فعال نیست")
            return

        target = get_target() or "نامشخص"
        status_text = f"📊 **وضعیت اسپمر** (تارگت: `{target}`)\n\n"

        for phone, spammer in self.spammers.items():
            stats = spammer.stats
            running = "🟢 فعال" if spammer.is_running else "🔴 غیرفعال"

            status_text += (
                f"**اکانت:** `{phone}`\n"
                f"وضعیت: {running}\n"
                f"ارسال‌ها: {stats['total_sent']}\n"
                f"خطاها: {stats['total_failed']}\n"
                f"آخرین شمارنده: {stats['last_counter']}\n"
                f"----------------\n"
            )

        await message.reply_text(status_text)

    # ==================================================
    # راهنما
    # ==================================================

    async def show_help(self, message: Message):
        """نمایش راهنما"""
        await message.reply_text(
            "📚 **راهنمای اسپمر**\n\n"
            "**مراحل کار:**\n"
            "1️⃣ `set_target [LINK/ID]` - تنظیم تارگت\n"
            "2️⃣ `spam_start [message] [delay] [counter]` - شروع اسپم\n"
            "3️⃣ `spam_stop` - توقف اسپم\n\n"
            "**سایر دستورات:**\n"
            "• `show_target` - نمایش تارگت فعلی\n"
            "• `clear_target` - پاک کردن تارگت\n"
            "• `spam_status` - نمایش وضعیت\n"
            "• `spam_help` - راهنما\n\n"
            "**پارامترها:**\n"
            "• message: متن پیام\n"
            "• delay: دیلی پایه (پیشفرض 200)\n"
            "• counter: شمارنده شروع (پیشفرض 1)\n\n"
            "**مثال:**\n"
            "`set_target @mygroup`\n"
            "`spam_start سلام 200 1`\n"
            "`spam_stop`\n\n"
            "**نحوه کار:**\n"
            "• دیلی = delay × counter\n"
            "• بعد از هر ارسال موفق counter ++\n"
            "• تارگت در فایل ذخیره میشه و همیشه می‌تونی استفاده کنی"
        )

    # ==================================================
    # هندلر اصلی
    # ==================================================

    async def handle(self, message: Message) -> bool:
        text = message.text.strip()
        
        # ==============================================
        # راهنما
        # ==============================================
        if text.lower() in ["spam_help", "/spam_help"]:
            await self.show_help(message)
            return True

        # ==============================================
        # تنظیم تارگت
        # ==============================================
        if text.lower().startswith(("set_target", "/set_target")):
            parts = text.split(maxsplit=1)
            
            if len(parts) < 2:
                await message.reply_text(
                    "❌ لطفاً تارگت رو وارد کن:\n"
                    "`set_target [LINK/ID/USERNAME]`\n\n"
                    "برای راهنما: `spam_help`"
                )
                return True

            target_input = parts[1].strip()
            
            # تشخیص نوع (فقط برای نمایش)
            target_type = self.detect_target_type(target_input)
            
            # ذخیره تارگت
            success = set_target(target_input, target_type, target_input)
            
            if success:
                type_names = {
                    "private_link": "لینک خصوصی",
                    "public_link": "لینک عمومی",
                    "username": "یوزرنیم",
                    "numeric_id": "آیدی عددی",
                    "unknown": "نامشخص"
                }
                await message.reply_text(
                    f"✅ **تارگت با موفقیت تنظیم شد**\n\n"
                    f"📌 مقدار: `{target_input}`\n"
                    f"🔍 نوع: {type_names.get(target_type, 'نامشخص')}\n\n"
                    f"➡️ حالا می‌تونی با `spam_start` شروع کنی"
                )
            else:
                await message.reply_text("❌ خطا در تنظیم تارگت")
            
            return True

        # ==============================================
        # نمایش تارگت
        # ==============================================
        if text.lower() in ["show_target", "/show_target"]:
            await self.show_target(message)
            return True

        # ==============================================
        # پاک کردن تارگت
        # ==============================================
        if text.lower() in ["clear_target", "/clear_target"]:
            if clear_target():
                await message.reply_text("✅ تارگت با موفقیت پاک شد")
            else:
                await message.reply_text("❌ خطا در پاک کردن تارگت")
            return True

        # ==============================================
        # توقف اسپم
        # ==============================================
        if text.lower() in ["spam_stop", "/spam_stop"]:
            await self.stop_all(message)
            return True

        # ==============================================
        # وضعیت اسپم
        # ==============================================
        if text.lower() in ["spam_status", "/spam_status"]:
            await self.show_status(message)
            return True

        # ==============================================
        # شروع اسپم
        # ==============================================
        if text.lower().startswith(("spam_start", "/spam_start")):
            
            # چک کردن ارسال فعال
            if self.spammers:
                await message.reply_text(
                    "❌ یک اسپم فعال وجود دارد.\n"
                    "اول با `spam_stop` اون رو متوقف کن."
                )
                return True

            # چک کردن تارگت
            if not is_target_active():
                await message.reply_text(
                    "❌ هیچ تارگتی تنظیم نشده.\n"
                    "اول با `set_target` تارگت رو تنظیم کن."
                )
                return True

            # دریافت پارامترها
            parts = text.split(maxsplit=3)
            
            if len(parts) < 2:
                await message.reply_text(
                    "❌ فرمت:\n"
                    "`spam_start [message] [delay] [counter]`\n\n"
                    "برای راهنما: `spam_help`"
                )
                return True

            message_text = parts[1]

            delay_base = 200
            if len(parts) >= 3:
                try:
                    delay_base = int(parts[2])
                except ValueError:
                    await message.reply_text("❌ DELAY باید عدد باشد")
                    return True

            start_counter = 1
            if len(parts) >= 4:
                try:
                    start_counter = int(parts[3])
                except ValueError:
                    await message.reply_text("❌ COUNTER باید عدد باشد")
                    return True

            # نمایش تارگت فعلی
            target = get_target()
            target_display = TARGET_RAW or str(target)

            # پیام وضعیت
            status_msg = await message.reply_text(
                f"🚀 **شروع اسپمر**\n\n"
                f"🎯 **تارگت:** `{target_display}`\n"
                f"📝 **پیام:** {message_text[:50]}{'...' if len(message_text) > 50 else ''}\n"
                f"⏱️ **دیلی پایه:** {delay_base} ثانیه\n"
                f"🔢 **شمارنده شروع:** {start_counter}\n"
                f"👥 **تعداد اکانت‌ها:** {len(self.runner.clients)}\n\n"
                f"🔄 **حلقه بینهایت فعال...**\n"
                f"⏹️ **برای توقف:** `spam_stop`"
            )

            # ==========================================
            # اکشن برای هر اکانت
            # ==========================================
            async def action(phone, app):
                spammer = TargetManager(app, phone)
                self.spammers[phone] = spammer

                # کالبک برای هر ارسال
                async def on_send(result):
                    if result.get("success"):
                        self.logger.info(f"[{phone}] Sent #{result['total_sent']}")
                    else:
                        self.logger.debug(f"[{phone}] Failed: {result.get('error')}")

                # شروع اسپم
                final_result = await spammer.start_spam(
                    message=message_text,
                    delay_base=delay_base,
                    start_counter=start_counter,
                    use_delay_engine=True,
                    on_each_send=on_send
                )

                return final_result

            # ==========================================
            # اجرا
            # ==========================================
            try:
                # استارت همه اکانت‌ها
                for phone, managed in self.runner.clients.items():
                    await managed.start()
                    await managed.ensure_connected()

                # ساخت تسک برای هر اکانت
                tasks = []
                for phone, managed in self.runner.clients.items():
                    task = asyncio.create_task(
                        action(phone, managed.client),
                        name=f"target_spam_{phone}"
                    )
                    self.running_tasks[phone] = task
                    tasks.append(task)

                # آپدیت وضعیت
                await status_msg.edit_text(
                    f"✅ **اسپمر شروع شد**\n\n"
                    f"🎯 تارگت: `{target_display}`\n"
                    f"👥 تعداد اکانت‌ها: {len(tasks)}\n"
                    f"🔄 در حال اجرا...\n"
                    f"⏹️ توقف: `spam_stop`\n"
                    f"📊 وضعیت: `spam_status`"
                )

                # منتظر موندن
                await asyncio.gather(*tasks, return_exceptions=True)

            except asyncio.CancelledError:
                self.logger.info("Tasks cancelled")
                await self.stop_all()

            except Exception as e:
                self.logger.error(f"Error: {e}")
                await message.reply_text(f"❌ خطا: {e}")

            finally:
                self.spammers.clear()
                self.running_tasks.clear()

            return True

        return False