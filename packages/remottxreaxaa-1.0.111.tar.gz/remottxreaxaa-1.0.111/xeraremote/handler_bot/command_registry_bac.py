# remottxrea/bot/command_registry.py

from .handlers.add_account import AddAccountHandler
from .handlers.change_name import ChangeNameHandler
from .handlers.change_photo import ChangePhotoHandler
from .handlers.join_leave import JoinLeaveHandler
from .handlers.list_account import AccountOverviewHandler
from .handlers.start import Start

from .handlers.text_handler import (
    handle_add_multi,
    handle_add_text,
    handle_clear,
    handle_list_text,
    handle_remove_text,
)

from ..runner.multi_session_runner import MultiSessionRunner


# ==========================================================
# WRAPPER HANDLER FOR FUNCTION-BASED HANDLERS
# ==========================================================

class FunctionHandler:
    """
    Wrap async function(client, message)
    into object with .handle(message)
    to match router architecture
    """

    def __init__(self, func):
        self.func = func

    async def handle(self, message):
        await self.func(message._client, message)


# ==========================================================
# COMMAND REGISTRY
# ==========================================================

class CommandRegistry:

    def __init__(self):

        self.runner = MultiSessionRunner()

        # ----------------------
        # class-based handlers
        # ----------------------
        self.add_account = AddAccountHandler()
        self.change_name = ChangeNameHandler(self.runner)
        self.change_photo = ChangePhotoHandler(self.runner)
        self.join_leave = JoinLeaveHandler(self.runner)
        self.list_accounts = AccountOverviewHandler(self.runner)
        self.start_bot = Start()

        # ----------------------
        # function-based handlers
        # ----------------------
        self.text_add = FunctionHandler(handle_add_text)
        self.text_remove = FunctionHandler(handle_remove_text)
        self.text_multi = FunctionHandler(handle_add_multi)
        self.text_list = FunctionHandler(handle_list_text)
        self.text_clear = FunctionHandler(handle_clear)

        # ----------------------
        # command map
        # ----------------------
        self.command_map = {
            "start": self.start_bot,
            "addaccount": self.add_account,
            "listacc": self.list_accounts,
            "changefname": self.change_name,
            "changename": self.change_name,
            "changephoto": self.change_photo,
            "join": self.join_leave,
            "leave": self.join_leave,

            # text system
            "text": self.text_add,
            "deltext": self.text_remove,
            "textmulti": self.text_multi,
            "listtext": self.text_list,
            "cleartext": self.text_clear,
        }

    # --------------------------------------------------
    def resolve(self, message):

        if not message or not message.text:
            return None

        text = message.text.strip()
        user_id = message.from_user.id

        # ============================================
        # 1️⃣ addaccount state priority
        # ============================================
        if user_id in self.add_account.states:
            return self.add_account

        # ============================================
        # 2️⃣ resolve command
        # ============================================
        command = text.split(" ", 1)[0].lower()

        if command.startswith("/"):
            command = command[1:]

        if "@" in command:
            command = command.split("@", 1)[0]

        return self.command_map.get(command)