
## Bug Fixes

- *(ci)* Enable OpenSSF Scorecard public result publishing

- *(ci)* Split scorecard into analysis + badge jobs

- *(ci)* Pin Semgrep container image to digest

- Audit hardening — 7 confirmed findings + debt tracking (#19)


## Documentation

- Add Codecov badge to README


## Miscellaneous

- Bump version to 0.1.2


## Ci

- *(deps)* Bump the github-actions group with 11 updates (#16)

