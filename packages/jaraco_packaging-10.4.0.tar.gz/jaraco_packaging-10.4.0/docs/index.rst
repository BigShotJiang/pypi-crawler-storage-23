Welcome to |project| documentation!
===================================

.. sidebar-links::
   :home:
   :pypi:

.. toctree::
   :maxdepth: 1

   history


.. automodule:: jaraco.packaging
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: jaraco.packaging.sphinx
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

