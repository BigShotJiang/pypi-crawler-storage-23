# Phaxor — Engineering Calculator Library

**74 engineering solvers + visualizations + material database + studio tools**
for Python and Jupyter notebooks. Zero required dependencies.

> **Need full power?** The [Phaxor Cloud API](https://phaxor.com/api) provides 1,550+ materials, 15 interactive studios, 83 graph renderers, real-time computation, and full access to every feature — with API key authentication.

---

## Install

```bash
pip install phaxor               # Core (74 solvers, zero deps)
pip install phaxor[plot]          # + Matplotlib visualizations
pip install phaxor[all]           # + Jupyter display + plots
```

---

## Quick Start

```python
import phaxor

# ─── Ideal Gas Law ───────────────────────────────────────────
result = phaxor.compute('ideal-gas', {
    'solveFor': 'pressure',
    'volume': 0.02241, 'moles': 1, 'temperature': 273.15
})
print(f"Pressure = {result['P']:.0f} Pa")  # 101325 Pa

# ─── Ohm's Law ──────────────────────────────────────────────
result = phaxor.compute('ohms-law', {
    'solveFor': 'I', 'voltage': 12, 'resistance': 100
})
print(f"Current = {result['I']} A")  # 0.12 A

# ─── Mohr's Circle ──────────────────────────────────────────
result = phaxor.compute('mohrs-circle', {
    'sigmaX': 80, 'sigmaY': -40, 'tauXY': 30
})
print(f"σ₁ = {result['sigma1']:.1f} MPa")

# ─── Unit Conversion ────────────────────────────────────────
km = phaxor.convert('length', 1, 'mi', 'km')
print(f"1 mile = {km:.6f} km")

# ─── List all calculators ───────────────────────────────────
for calc in phaxor.list_calculators():
    print(f"  {calc['id']:24s} {calc['name']}")
```

---

## Visualizations (`phaxor.plot`)

Requires `pip install phaxor[plot]` (matplotlib).

```python
import phaxor

# Mohr's Circle plot
phaxor.plot.mohrs_circle(sigma_x=80, sigma_y=-40, tau_xy=30)

# Stress-strain curve for a material
phaxor.plot.stress_strain_curve('aluminum-6061')

# Beam SFD/BMD diagrams
phaxor.plot.beam_diagram(
    length=6000,
    point_loads=[
        {'position': 2000, 'magnitude': 15, 'direction': 'down'},
        {'position': 4000, 'magnitude': 10, 'direction': 'down'},
    ]
)

# Column buckling curves
phaxor.plot.column_buckling(length=3000, E=200, I=1e6, area=1000)

# Impedance phasor diagram
phaxor.plot.impedance_phasor(resistance=50, reactance=30)

# Rankine cycle T-s diagram
phaxor.plot.rankine_ts(boiler_pressure=10000, condenser_pressure=10)

# Vibration frequency response
phaxor.plot.vibration_response(mass=10, stiffness=1000, damping=5)

# Gear train speed cascade
phaxor.plot.gear_train(
    stages=[{'driverTeeth': 20, 'drivenTeeth': 60}, {'driverTeeth': 15, 'drivenTeeth': 45}],
    input_speed=1800
)

# Compare any calculator across scenarios
phaxor.plot.compare('ohms-law',
    [{'solveFor': 'P', 'voltage': 12, 'resistance': r} for r in [10, 50, 100, 500]],
    'P', labels=['10Ω', '50Ω', '100Ω', '500Ω']
)
```

---

## Materials Database (`phaxor.materials`)

Basic edition includes 20 curated materials. For the full 1,550+ material database, use the [Cloud API](https://phaxor.com/api).

```python
import phaxor

# Look up a material
mat = phaxor.materials.get_material('steel-a36')
print(f"E = {mat['E']} GPa, σy = {mat['sigmaY']} MPa")

# List all available materials
for m in phaxor.materials.list_materials():
    print(f"  {m['id']:20s} {m['name']:30s} [{m['category']}]")

# Filter by category
metals = phaxor.materials.list_materials('metals')

# Compare materials side-by-side
comparison = phaxor.materials.compare_materials('steel-a36', 'aluminum-6061', 'titanium-ti6al4v')
```

**Available materials (free library):**

| Category | Count | Materials |
|----------|-------|-----------|
| **Metals** | 10 | A36, A572, SS304, SS316, Al-6061, Al-7075, Copper, Ti-6Al-4V, Cast Iron, Inconel 625 |
| **Polymers** | 5 | ABS, Nylon 6, HDPE, PVC, PEEK |
| **Concrete** | 3 | M20, M30, M40 |
| **Fluids** | 2 | Water (20°C), Air (20°C) |

> **Via API:** 525 metals, 339 polymers, 190 ceramics, 167 fluids, 137 conductors, 127 concrete/masonry, 39 semiconductors, 26 magnetic materials = **1,550 total**

---

## Studio Tools (`phaxor.studio`)

Simplified engineering tools for learning. For the full interactive studios, use the [Cloud API](https://phaxor.com/api).

```python
import phaxor

# Failure analysis against multiple theories
result = phaxor.studio.check_failure(
    sigma_x=180, sigma_y=-60, tau_xy=45,
    sigma_yield=250, theory='all'
)
for name, theory in result['theories'].items():
    print(f"  {name}: FoS = {theory['factorOfSafety']:.2f} — {theory['status']}")

# Manufacturing cost estimation
cost = phaxor.studio.estimate_cost(
    material='aluminum-6061', volume_m3=0.0005,
    process='machining', quantity=100
)
print(f"Unit cost: ${cost['unitCost']} → Total: ${cost['totalCost']}")

# Find materials matching requirements
matches = phaxor.studio.find_material(min_yield=300, max_density=5000)
for m in matches:
    print(f"  {m['name']:25s} σy={m['sigmaY']} MPa, ρ={m['density']} kg/m³")

# Section properties
props = phaxor.studio.section_properties('i-beam', bf=200, tf=15, hw=300, tw=10)
print(f"Area = {props['area']} mm², Ix = {props['Ix']} mm⁴")

# Quick design check
check = phaxor.studio.design_check(load=50000, area=500, material='steel-a36')
print(check['statusText'])
```

---

## All 74 Calculators

| Category | Engines |
|----------|---------|
| **Structural** (17) | beam-deflection, bearing-capacity, column-buckling, concrete-volume, development-length, earth-pressure, failure-theory, isolated-footing, mohrs-circle, rcc-beam, rcc-column, rcc-slab, reinforcement-qty, settlement, soil-properties, steel-weight, stress-strain |
| **Mechanical** (19) | beam, bearing-life, belt-drive, bolt-analysis, cop, flywheel, gear-ratio, heat-exchanger, heat-transfer, ideal-gas, pipe-flow, pressure-force, pump-power, rankine-cycle, shaft-design, spring-design, torque-power, vibration, weld-strength |
| **Electrical** (17) | battery-ups, cable-sizing, circuit-breaker, dc-motor, earthing, electrical-efficiency, energy-consumption, impedance, induction-motor, ohms-law, power, pf-correction, rectifier, resonance, short-circuit, solar-sizing, transformer |
| **Chemical** (9) | arrhenius, cstr, chem-equilibrium, distillation, gibbs, pfr, packed-bed, stoichiometry, vle |
| **Hydraulics** (4) | open-channel, pavement-thickness, sight-distance, weir-orifice |
| **Materials** (5) | apf, corrosion, fatigue-life, hardness-conversion, rule-of-mixtures |
| **General** (3) | geometry, matrix, unit-converter |

---

## Jupyter Notebooks

In Jupyter, `compute()` automatically renders styled HTML tables:

```python
import phaxor

phaxor.compute('ideal-gas', {
    'solveFor': 'pressure',
    'volume': 0.02241, 'moles': 1, 'temperature': 273.15
})
# → Renders a styled table with results
```

---

## Python vs Cloud API

| Feature | Python (Free) | Cloud API (Paid) |
|---------|:---:|:---:|
| 74 Engineering Solvers | ✅ | ✅ |
| Basic Matplotlib Plots | ✅ (9 plots) | ✅ (83 renderers) |
| Materials Database | 20 materials | **1,550 materials** |
| Studio Tools | 5 basic | **15 interactive studios** |
| Unit Conversion | ✅ | ✅ |
| Interactive SVG Graphs | ❌ | ✅ |
| 3D Visualization | ❌ | ✅ |
| Monte Carlo Simulation | ❌ | ✅ |
| Parametric Optimization | ❌ | ✅ |
| AI-Powered Analysis | ❌ | ✅ |
| Material Cost Data | Basic | **Full supply chain** |
| Embeddable Widgets | ❌ | ✅ |
| Rate Limit | — | 10K–∞ req/month |
| Price | **Free** | From $9/month |

→ **[Get API Access](https://phaxor.com/api)**

---

## API

```python
# Core
phaxor.compute(calculator_type, inputs)      # Run any calculator
phaxor.convert(category, value, from, to)    # Unit conversion
phaxor.list_calculators()                     # List all 74 calculators

# Visualization
phaxor.plot.mohrs_circle(...)                # Mohr's Circle
phaxor.plot.stress_strain_curve(material)    # Stress-strain curve
phaxor.plot.beam_diagram(...)                # SFD/BMD
phaxor.plot.column_buckling(...)             # Euler buckling
phaxor.plot.impedance_phasor(R, X)           # Impedance phasor
phaxor.plot.rankine_ts(...)                  # Rankine cycle T-s
phaxor.plot.vibration_response(...)          # Frequency response
phaxor.plot.gear_train(stages)               # Gear train
phaxor.plot.compare(calc, cases, key)        # Comparison chart

# Materials
phaxor.materials.get_material(id)            # Look up material
phaxor.materials.list_materials(category)    # List materials
phaxor.materials.compare_materials(...)      # Compare side-by-side

# Studio
phaxor.studio.check_failure(...)             # Failure theory check
phaxor.studio.estimate_cost(...)             # Cost estimation
phaxor.studio.find_material(...)             # Material finder
phaxor.studio.section_properties(...)        # Section properties
phaxor.studio.design_check(...)              # Quick design check
```

---

## License

MIT — [Seddique Abbasi](https://github.com/seddiquea)

**Full API** → [phaxor.com/api](https://phaxor.com/api)
