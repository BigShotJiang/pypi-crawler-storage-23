"""
Phaxor — Basic Matplotlib Visualizations for Engineering Calculations.

Provides quick plotting helpers for Jupyter notebooks and scripts.
These are basic learning-oriented visualizations.

For advanced interactive graphs, real-time 3D rendering, and
publication-quality SVG diagrams, use the Phaxor Cloud API.
→  https://phaxor.com/api
"""

import math

_HAS_MPL = False
try:
    import matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.patches as patches
    _HAS_MPL = True
except ImportError:
    pass


def _require_mpl():
    if not _HAS_MPL:
        raise ImportError(
            "matplotlib is required for plotting.\n"
            "Install with: pip install phaxor[plot]\n\n"
            "For advanced interactive graphs without matplotlib,\n"
            "use the Phaxor Cloud API → https://phaxor.com/api"
        )


# ─── Mohr's Circle ──────────────────────────────────────────────────────────

def mohrs_circle(sigma_x: float, sigma_y: float, tau_xy: float, theta: float = 0, **kwargs):
    """
    Plot Mohr's Circle for 2D plane stress.

    Parameters
    ----------
    sigma_x : float — Normal stress in x direction (MPa)
    sigma_y : float — Normal stress in y direction (MPa)
    tau_xy : float — Shear stress (MPa)
    theta : float — Rotation angle in degrees (default 0)

    Returns
    -------
    dict — Computed results (sigma1, sigma2, tauMax, center, radius, etc.)

    Example
    -------
    >>> import phaxor
    >>> phaxor.plot.mohrs_circle(80, -40, 30)
    """
    _require_mpl()
    from .engines.mohrs_circle import solve_mohrs_circle

    result = solve_mohrs_circle({'sigmaX': sigma_x, 'sigmaY': sigma_y, 'tauXY': tau_xy, 'theta': theta})

    fig, ax = plt.subplots(1, 1, figsize=(7, 7))
    c = result['center']
    r = result['radius']

    circle = plt.Circle((c, 0), r, fill=False, color='#22d3ee', linewidth=2)
    ax.add_patch(circle)

    ax.plot(sigma_x, tau_xy, 'o', color='#f97316', markersize=8, label=f'X ({sigma_x}, {tau_xy})')
    ax.plot(sigma_y, -tau_xy, 's', color='#a855f7', markersize=8, label=f'Y ({sigma_y}, {-tau_xy})')
    ax.plot([sigma_x, sigma_y], [tau_xy, -tau_xy], '--', color='#565f89', linewidth=1)
    ax.plot(result['sigma1'], 0, 'D', color='#22c55e', markersize=8, label=f'σ₁ = {result["sigma1"]:.1f}')
    ax.plot(result['sigma2'], 0, 'D', color='#ef4444', markersize=8, label=f'σ₂ = {result["sigma2"]:.1f}')
    ax.plot(c, 0, '+', color='#facc15', markersize=12, markeredgewidth=2, label=f'C = {c:.1f}')

    ax.axhline(0, color='#444', linewidth=0.5)
    ax.axvline(0, color='#444', linewidth=0.5)
    ax.set_aspect('equal')
    ax.set_xlabel('Normal Stress σ (MPa)')
    ax.set_ylabel('Shear Stress τ (MPa)')
    ax.set_title("Mohr's Circle — Phaxor", fontweight='bold')
    ax.legend(fontsize=8, loc='upper right')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

    return result


# ─── Stress-Strain Curve ────────────────────────────────────────────────────

def stress_strain_curve(material: str = 'steel-a36', **kwargs):
    """
    Plot a simplified stress-strain curve for a material.

    Parameters
    ----------
    material : str — Material key (e.g., 'steel-a36', 'aluminum-6061')

    Available materials: steel-a36, steel-a572, stainless-304,
                        aluminum-6061, copper, titanium-ti6al4v, cast-iron

    For 1,550+ materials with full property data, use the Phaxor Cloud API.

    Returns
    -------
    dict — Material properties
    """
    _require_mpl()
    from .engines.stress_strain import MATERIALS

    mat = MATERIALS.get(material)
    if not mat:
        avail = ', '.join(MATERIALS.keys())
        raise ValueError(f"Unknown material '{material}'. Available: {avail}\n"
                         f"For 1,550+ materials, use Phaxor Cloud API → https://phaxor.com/api")

    E = mat['E'] * 1000  # GPa -> MPa
    sy = mat['sigmaY']
    su = mat['sigmaUlt']
    elong = mat['elongation'] / 100

    strain_y = sy / E
    strain_u = elong * 0.6
    strain_f = elong

    strains = [0, strain_y]
    stresses = [0, sy]

    steps = 30
    for i in range(1, steps + 1):
        t = i / steps
        s = strain_y + t * (strain_u - strain_y)
        sig = sy + (su - sy) * (1 - (1 - t) ** 2)
        strains.append(s)
        stresses.append(sig)

    for i in range(1, 10):
        t = i / 9
        s = strain_u + t * (strain_f - strain_u)
        sig = su - (su - sy * 0.8) * t ** 2
        strains.append(s)
        stresses.append(sig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(strains, stresses, color='#22d3ee', linewidth=2)
    ax.axhline(sy, color='#facc15', linestyle='--', alpha=0.6, label=f'σy = {sy} MPa')
    ax.axhline(su, color='#ef4444', linestyle='--', alpha=0.6, label=f'σu = {su} MPa')
    ax.fill_between([0, strain_y], 0, sy, alpha=0.1, color='#22c55e', label='Elastic region')
    ax.set_xlabel('Strain (mm/mm)')
    ax.set_ylabel('Stress (MPa)')
    ax.set_title(f'Stress-Strain Curve — {mat["name"]} — Phaxor', fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0)
    ax.set_ylim(0)
    plt.tight_layout()
    plt.show()

    return mat


# ─── Beam SFD/BMD ───────────────────────────────────────────────────────────

def beam_diagram(length: float, point_loads: list = None, supports: list = None, E: float = 200, I: float = 1e6, **kwargs):
    """
    Plot Shear Force and Bending Moment diagrams for a simply-supported beam.

    Parameters
    ----------
    length : float — Beam span (mm)
    point_loads : list — [{'position': x, 'magnitude': F, 'direction': 'down'}]
    supports : list — [{'position': x}] (default: ends)
    E : float — Young's modulus (GPa, default 200)
    I : float — Moment of inertia (mm⁴, default 1e6)

    For interactive SFD/BMD with distributed loads, continuous beams,
    and deflection curves, use the Phaxor Cloud API.

    Returns
    -------
    dict — Beam analysis results
    """
    _require_mpl()
    from .engines.beam import solve_beam

    if supports is None:
        supports = [{'position': 0}, {'position': length}]
    if point_loads is None:
        point_loads = [{'position': length / 2, 'magnitude': 10, 'direction': 'down'}]

    result = solve_beam({
        'length': length, 'E': E, 'I': I,
        'supports': supports, 'pointLoads': point_loads,
        'distributedLoads': [], 'moments': []
    })

    if result is None:
        print("Invalid beam configuration.")
        return None

    sfd = result.get('shearData', [])
    bmd = result.get('momentData', [])

    if not sfd:
        print("No diagram data returned.")
        return result

    x_s = [p['x'] for p in sfd]
    v_s = [p['V'] for p in sfd]
    x_m = [p['x'] for p in bmd]
    m_s = [p['M'] for p in bmd]

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6), sharex=True)

    ax1.fill_between(x_s, v_s, alpha=0.3, color='#22d3ee')
    ax1.plot(x_s, v_s, color='#22d3ee', linewidth=2)
    ax1.axhline(0, color='#666', linewidth=0.5)
    ax1.set_ylabel('Shear Force (kN)')
    ax1.set_title('Shear Force Diagram — Phaxor', fontweight='bold')
    ax1.grid(True, alpha=0.3)

    ax2.fill_between(x_m, m_s, alpha=0.3, color='#a855f7')
    ax2.plot(x_m, m_s, color='#a855f7', linewidth=2)
    ax2.axhline(0, color='#666', linewidth=0.5)
    ax2.set_xlabel('Position (mm)')
    ax2.set_ylabel('Bending Moment (kN·mm)')
    ax2.set_title('Bending Moment Diagram — Phaxor', fontweight='bold')
    ax2.grid(True, alpha=0.3)

    for s in supports:
        for a in (ax1, ax2):
            a.axvline(s['position'], color='#facc15', linestyle=':', alpha=0.5)

    plt.tight_layout()
    plt.show()

    return result


# ─── Column Buckling ────────────────────────────────────────────────────────

def column_buckling(length: float, E: float = 200, I: float = 1e6, area: float = 1000,
                    applied_load: float = 50000, yield_strength: float = 250, **kwargs):
    """
    Plot column buckling analysis with load vs slenderness ratio.

    Parameters
    ----------
    length : float — Column height (mm)
    E, I, area : float — Material and section properties
    applied_load : float — Applied axial load (N)
    yield_strength : float — Yield strength (MPa)

    Returns
    -------
    dict — Buckling analysis results
    """
    _require_mpl()
    from .engines.column_buckling import solve_column_buckling

    conditions = ['fixed-fixed', 'fixed-pinned', 'pinned-pinned', 'fixed-free']
    k_map = {'fixed-fixed': 0.5, 'fixed-pinned': 0.7, 'pinned-pinned': 1.0, 'fixed-free': 2.0}
    colors = ['#22c55e', '#22d3ee', '#a855f7', '#ef4444']

    r = math.sqrt(I / area)

    fig, ax = plt.subplots(figsize=(8, 5))
    result = None

    for cond, color in zip(conditions, colors):
        K = k_map[cond]
        Le = K * length
        sr = Le / r
        ratios = list(range(10, 250, 5))
        stresses = []
        for ratio in ratios:
            pcr = (math.pi ** 2 * E * 1000) / (ratio ** 2)
            stresses.append(min(pcr, yield_strength))

        ax.plot(ratios, stresses, color=color, linewidth=2, label=f'{cond} (K={K})')

        if cond == 'pinned-pinned':
            result = solve_column_buckling({
                'length': length, 'E': E, 'I': I, 'area': area,
                'endCondition': cond, 'appliedLoad': applied_load,
                'yieldStrength': yield_strength
            })
            if result:
                ax.plot(sr, min(result['criticalStress'], yield_strength), 'o',
                        color='white', markersize=10, markeredgewidth=2, markeredgecolor=color)

    ax.axhline(yield_strength, color='#facc15', linestyle='--', alpha=0.6, label=f'σy = {yield_strength} MPa')
    ax.set_xlabel('Slenderness Ratio (L/r)')
    ax.set_ylabel('Critical Stress (MPa)')
    ax.set_title('Euler Buckling Curves — Phaxor', fontweight='bold')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

    return result


# ─── Impedance Phasor ───────────────────────────────────────────────────────

def impedance_phasor(resistance: float, reactance: float, **kwargs):
    """
    Plot an impedance phasor diagram.

    Parameters
    ----------
    resistance : float — Resistance R (Ω)
    reactance : float — Reactance X (Ω), positive = inductive, negative = capacitive

    Returns
    -------
    dict — Impedance results (magnitude, phase angle)
    """
    _require_mpl()

    Z = math.sqrt(resistance ** 2 + reactance ** 2)
    angle = math.degrees(math.atan2(reactance, resistance))

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.annotate('', xy=(resistance, reactance), xytext=(0, 0),
                arrowprops=dict(arrowstyle='->', color='#22d3ee', lw=2.5))
    ax.annotate('', xy=(resistance, 0), xytext=(0, 0),
                arrowprops=dict(arrowstyle='->', color='#22c55e', lw=2))
    ax.annotate('', xy=(resistance, reactance), xytext=(resistance, 0),
                arrowprops=dict(arrowstyle='->', color='#a855f7', lw=2))

    pad = max(Z * 0.15, 5)
    ax.text(resistance / 2, -pad, f'R = {resistance} Ω', ha='center', color='#22c55e', fontsize=10)
    ax.text(resistance + pad, reactance / 2, f'X = {reactance} Ω', ha='left', color='#a855f7', fontsize=10)
    ax.text(resistance / 2 - pad, reactance / 2 + pad, f'|Z| = {Z:.1f} Ω\n∠{angle:.1f}°',
            ha='center', color='#22d3ee', fontsize=10, fontweight='bold')

    lim = Z * 1.3
    ax.set_xlim(-lim * 0.1, lim)
    ax.set_ylim(-lim if reactance < 0 else -lim * 0.3, lim if reactance > 0 else lim * 0.3)
    ax.set_aspect('equal')
    ax.axhline(0, color='#666', linewidth=0.5)
    ax.axvline(0, color='#666', linewidth=0.5)
    ax.set_xlabel('Real (Ω)')
    ax.set_ylabel('Imaginary (Ω)')
    ax.set_title('Impedance Phasor — Phaxor', fontweight='bold')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

    return {'impedance': Z, 'angle': angle, 'resistance': resistance, 'reactance': reactance}


# ─── Rankine Cycle T-s Diagram ──────────────────────────────────────────────

def rankine_ts(boiler_pressure: float = 10000, condenser_pressure: float = 10,
               turbine_efficiency: float = 0.85, pump_efficiency: float = 0.8, **kwargs):
    """
    Plot a simplified Rankine cycle T-s diagram.

    Parameters
    ----------
    boiler_pressure : float — Boiler pressure (kPa)
    condenser_pressure : float — Condenser pressure (kPa)
    turbine_efficiency : float — Turbine isentropic efficiency
    pump_efficiency : float — Pump isentropic efficiency

    For detailed cycle analysis with reheat, regeneration,
    and cogeneration, use the Phaxor Cloud API.

    Returns
    -------
    dict — Cycle efficiency results
    """
    _require_mpl()
    from .engines.rankine_cycle import solve_rankine_cycle

    result = solve_rankine_cycle({
        'boilerPressure': boiler_pressure,
        'condenserPressure': condenser_pressure,
        'turbineEfficiency': turbine_efficiency,
        'pumpEfficiency': pump_efficiency
    })

    # Simplified T-s diagram
    T_cond = 45.8  # approximate condensation temp
    T_boil = 311  # approximate for 10 MPa
    T_super = 550

    s_vals = [0, 1.3, 3.5, 6.5, 8.2, 1.3, 0]
    T_vals = [T_cond, T_cond, T_boil, T_boil, T_cond, T_cond, T_cond]

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.fill(s_vals, T_vals, alpha=0.15, color='#22d3ee')
    ax.plot(s_vals, T_vals, color='#22d3ee', linewidth=2, marker='o', markersize=5)

    labels = ['1', '2', '3', '4', "4'"]
    pts_s = [1.3, 1.3, 3.5, 8.2, 6.5]
    pts_T = [T_cond, T_boil, T_boil, T_cond, T_boil]
    for lbl, s, T in zip(labels, pts_s, pts_T):
        ax.annotate(lbl, (s, T), textcoords='offset points', xytext=(8, 8),
                    fontsize=11, fontweight='bold', color='#c0caf5')

    eff = result.get('thermalEfficiency', 0) if result else 0
    ax.text(4, T_boil * 0.6, f'η = {eff:.1f}%', fontsize=14, fontweight='bold',
            color='#22c55e', ha='center')

    ax.set_xlabel('Entropy s (kJ/kg·K)')
    ax.set_ylabel('Temperature T (°C)')
    ax.set_title('Rankine Cycle T-s Diagram — Phaxor', fontweight='bold')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

    return result


# ─── Vibration Response ─────────────────────────────────────────────────────

def vibration_response(mass: float = 10, stiffness: float = 1000, damping: float = 5,
                       force: float = 100, **kwargs):
    """
    Plot vibration frequency response (amplitude vs frequency ratio).

    Parameters
    ----------
    mass : float — Mass (kg)
    stiffness : float — Stiffness (N/m)
    damping : float — Damping coefficient (N·s/m)
    force : float — Force amplitude (N)

    Returns
    -------
    dict — Natural frequency, damping ratio, amplitude
    """
    _require_mpl()

    wn = math.sqrt(stiffness / mass)
    zeta = damping / (2 * math.sqrt(stiffness * mass))
    x_static = force / stiffness

    ratios = [i / 100 for i in range(1, 350)]
    amplitudes = []
    phases = []

    for r in ratios:
        denom = math.sqrt((1 - r ** 2) ** 2 + (2 * zeta * r) ** 2)
        amplitudes.append(1 / denom if denom > 0 else 0)
        phases.append(math.degrees(math.atan2(2 * zeta * r, 1 - r ** 2)))

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 6), sharex=True)

    ax1.plot(ratios, amplitudes, color='#22d3ee', linewidth=2)
    ax1.axvline(1.0, color='#ef4444', linestyle='--', alpha=0.5, label='Resonance')
    ax1.set_ylabel('Amplitude Ratio |X/Xst|')
    ax1.set_title(f'Frequency Response — ζ = {zeta:.3f} — Phaxor', fontweight='bold')
    ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.3)
    ax1.set_yscale('log')

    ax2.plot(ratios, phases, color='#a855f7', linewidth=2)
    ax2.axvline(1.0, color='#ef4444', linestyle='--', alpha=0.5)
    ax2.set_xlabel('Frequency Ratio (ω/ωn)')
    ax2.set_ylabel('Phase Angle (°)')
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    return {
        'naturalFrequency': wn, 'dampingRatio': zeta,
        'staticDeflection': x_static,
        'frequencyHz': wn / (2 * math.pi)
    }


# ─── Quick Bar Chart Helper ─────────────────────────────────────────────────

def compare(calculator_type: str, cases: list, output_key: str, labels: list = None, **kwargs):
    """
    Compare multiple input scenarios side-by-side as a bar chart.

    Parameters
    ----------
    calculator_type : str — Calculator ID (e.g., 'ohms-law')
    cases : list — List of input dicts
    output_key : str — Key to compare from results
    labels : list — Optional labels for each case

    Example
    -------
    >>> phaxor.plot.compare('ohms-law',
    ...     [{'solveFor':'P','voltage':12,'resistance':r} for r in [10,50,100,500]],
    ...     'P', labels=['10Ω','50Ω','100Ω','500Ω'])
    """
    _require_mpl()
    from . import CALCULATORS

    calc = CALCULATORS.get(calculator_type)
    if not calc:
        raise ValueError(f"Unknown calculator: '{calculator_type}'")

    values = []
    for case in cases:
        r = calc['solver'](case)
        values.append(r.get(output_key, 0) if r else 0)

    if labels is None:
        labels = [f'Case {i + 1}' for i in range(len(cases))]

    colors = ['#22d3ee', '#a855f7', '#22c55e', '#f97316', '#ef4444', '#facc15'] * 5
    fig, ax = plt.subplots(figsize=(max(6, len(cases)), 4))
    ax.bar(labels, values, color=colors[:len(cases)], edgecolor='#2f334d')
    ax.set_ylabel(output_key)
    ax.set_title(f'{calc["name"]} — Comparison — Phaxor', fontweight='bold')
    ax.grid(True, axis='y', alpha=0.3)
    plt.tight_layout()
    plt.show()

    return values


# ─── Gear Train Diagram ─────────────────────────────────────────────────────

def gear_train(stages: list, input_speed: float = 1800, **kwargs):
    """
    Plot a simple gear train speed/torque cascade.

    Parameters
    ----------
    stages : list — [{'driverTeeth': int, 'drivenTeeth': int}]
    input_speed : float — Input RPM

    Returns
    -------
    dict — Speed and torque at each stage
    """
    _require_mpl()

    speeds = [input_speed]
    ratios = []
    for stage in stages:
        r = stage['drivenTeeth'] / stage['driverTeeth']
        ratios.append(r)
        speeds.append(speeds[-1] / r)

    stage_labels = ['Input'] + [f'Stage {i + 1}' for i in range(len(stages))]

    fig, ax = plt.subplots(figsize=(max(6, len(stages) * 2), 4))
    colors = ['#22d3ee'] + ['#a855f7'] * len(stages)
    ax.bar(stage_labels, speeds, color=colors, edgecolor='#2f334d')

    for i, (lbl, spd) in enumerate(zip(stage_labels, speeds)):
        ax.text(i, spd + max(speeds) * 0.02, f'{spd:.0f} RPM', ha='center', fontsize=9, fontweight='bold')

    ax.set_ylabel('Speed (RPM)')
    ax.set_title(f'Gear Train — Overall Ratio {math.prod(ratios):.2f}:1 — Phaxor', fontweight='bold')
    ax.grid(True, axis='y', alpha=0.3)
    plt.tight_layout()
    plt.show()

    return {'speeds': speeds, 'ratios': ratios, 'overallRatio': math.prod(ratios)}
