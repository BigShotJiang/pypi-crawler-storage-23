"""
Phaxor — Engineering Calculator Library for Python.

Free open-source library with 74 solvers, basic visualizations,
and 20 common materials.

For full access to 1,550+ materials, 15 interactive studios,
83 graph renderers, and real-time computation API, visit:
→  https://phaxor.com/api
"""

__version__ = "2.0.0"

# Submodules (lazy-loadable)
from . import plot
from . import materials
from . import studio

from .engines.arrhenius import solve_arrhenius
from .engines.cstr import solve_cstr
from .engines.chem_equilibrium import solve_chem_equilibrium
from .engines.distillation import solve_distillation
from .engines.gibbs import solve_gibbs
from .engines.pfr import solve_pfr
from .engines.packed_bed import solve_packed_bed
from .engines.stoichiometry import solve_stoichiometry
from .engines.vle import solve_vle
from .engines.battery_ups import solve_battery_ups
from .engines.cable_sizing import solve_cable_sizing
from .engines.circuit_breaker import solve_circuit_breaker
from .engines.dc_motor import solve_dc_motor
from .engines.earthing import solve_earthing
from .engines.electrical_efficiency import solve_electrical_efficiency
from .engines.energy_consumption import solve_energy_consumption
from .engines.impedance import solve_impedance
from .engines.induction_motor import solve_induction_motor
from .engines.ohms_law import solve_ohms_law
from .engines.power import solve_ac_power
from .engines.pf_correction import solve_pf_correction
from .engines.rectifier import solve_rectifier
from .engines.resonance import solve_resonance
from .engines.short_circuit import solve_short_circuit
from .engines.solar_sizing import solve_solar_sizing
from .engines.transformer import solve_transformer
from .engines.geometry import solve_geometry
from .engines.matrix import solve_matrix
from .engines.unit_converter import convert_unit, get_categories, get_units
from .engines.open_channel import solve_open_channel
from .engines.pavement_thickness import solve_pavement_thickness
from .engines.sight_distance import solve_sight_distance
from .engines.weir_orifice import solve_weir_orifice
from .engines.apf import solve_apf
from .engines.corrosion import solve_corrosion
from .engines.fatigue_life import solve_fatigue_life
from .engines.hardness_conversion import solve_hardness_conversion
from .engines.rule_of_mixtures import solve_rule_of_mixtures
from .engines.beam import solve_beam
from .engines.bearing_life import solve_bearing_life
from .engines.belt_drive import solve_belt_drive
from .engines.bolt_analysis import solve_bolt_analysis
from .engines.cop import solve_cop
from .engines.flywheel import solve_flywheel
from .engines.gear_ratio import solve_gear_ratio
from .engines.heat_exchanger import solve_heat_exchanger
from .engines.heat_transfer import solve_heat_transfer
from .engines.ideal_gas import solve_ideal_gas, GASES, R_UNIVERSAL
from .engines.pipe_flow import solve_pipe_flow
from .engines.pressure_force import solve_pressure_force
from .engines.pump_power import solve_pump_power
from .engines.rankine_cycle import solve_rankine_cycle
from .engines.shaft_design import solve_shaft_design
from .engines.spring_design import solve_spring_design
from .engines.torque_power import solve_torque_power
from .engines.vibration import solve_vibration
from .engines.weld_strength import solve_weld_strength
from .engines.beam_deflection import solve_beam_deflection
from .engines.bearing_capacity import solve_bearing_capacity
from .engines.column_buckling import solve_column_buckling, calc_column_section
from .engines.concrete_volume import solve_concrete_volume
from .engines.development_length import solve_development_length
from .engines.earth_pressure import solve_earth_pressure
from .engines.failure_theory import solve_failure_theory
from .engines.isolated_footing import solve_isolated_footing
from .engines.mohrs_circle import solve_mohrs_circle
from .engines.rcc_beam import solve_rcc_beam
from .engines.rcc_column import solve_rcc_column
from .engines.rcc_slab import solve_rcc_slab
from .engines.reinforcement_qty import solve_reinforcement_qty
from .engines.settlement import solve_settlement
from .engines.soil_properties import solve_soil_properties
from .engines.steel_weight import solve_steel_weight
from .engines.stress_strain import solve_stress_strain, calc_area, MATERIALS as STRESS_MATERIALS
from .display import display_result

CALCULATORS = {
    'arrhenius': {'name': 'Arrhenius', 'category': 'Chemical', 'solver': solve_arrhenius},
    'cstr': {'name': 'CSTR Design', 'category': 'Chemical', 'solver': solve_cstr},
    'chem-equilibrium': {'name': 'Chem Equilibrium', 'category': 'Chemical', 'solver': solve_chem_equilibrium},
    'distillation': {'name': 'Distillation', 'category': 'Chemical', 'solver': solve_distillation},
    'gibbs': {'name': 'Gibbs', 'category': 'Chemical', 'solver': solve_gibbs},
    'pfr': {'name': 'PFR Design', 'category': 'Chemical', 'solver': solve_pfr},
    'packed-bed': {'name': 'Packed Bed', 'category': 'Chemical', 'solver': solve_packed_bed},
    'stoichiometry': {'name': 'Stoichiometry', 'category': 'Chemical', 'solver': solve_stoichiometry},
    'vle': {'name': 'VLE / Phase Equilibrium', 'category': 'Chemical', 'solver': solve_vle},
    'battery-ups': {'name': 'Battery Ups', 'category': 'Electrical', 'solver': solve_battery_ups},
    'cable-sizing': {'name': 'Cable Sizing', 'category': 'Electrical', 'solver': solve_cable_sizing},
    'circuit-breaker': {'name': 'Circuit Breaker', 'category': 'Electrical', 'solver': solve_circuit_breaker},
    'dc-motor': {'name': 'DC Motor', 'category': 'Electrical', 'solver': solve_dc_motor},
    'earthing': {'name': 'Earthing', 'category': 'Electrical', 'solver': solve_earthing},
    'electrical-efficiency': {'name': 'Electrical Efficiency', 'category': 'Electrical', 'solver': solve_electrical_efficiency},
    'energy-consumption': {'name': 'Energy Consumption', 'category': 'Electrical', 'solver': solve_energy_consumption},
    'impedance': {'name': 'Impedance', 'category': 'Electrical', 'solver': solve_impedance},
    'induction-motor': {'name': 'Induction Motor', 'category': 'Electrical', 'solver': solve_induction_motor},
    'ohms-law': {'name': 'Ohm\'s Law', 'category': 'Electrical', 'solver': solve_ohms_law},
    'power': {'name': 'Power', 'category': 'Electrical', 'solver': solve_ac_power},
    'pf-correction': {'name': 'Power Factor Correction', 'category': 'Electrical', 'solver': solve_pf_correction},
    'rectifier': {'name': 'Rectifier', 'category': 'Electrical', 'solver': solve_rectifier},
    'resonance': {'name': 'Resonance', 'category': 'Electrical', 'solver': solve_resonance},
    'short-circuit': {'name': 'Short Circuit', 'category': 'Electrical', 'solver': solve_short_circuit},
    'solar-sizing': {'name': 'Solar Sizing', 'category': 'Electrical', 'solver': solve_solar_sizing},
    'transformer': {'name': 'Transformer', 'category': 'Electrical', 'solver': solve_transformer},
    'geometry': {'name': 'Geometry', 'category': 'General', 'solver': solve_geometry},
    'matrix': {'name': 'Matrix', 'category': 'General', 'solver': solve_matrix},
    'unit-converter': {'name': 'Unit Converter', 'category': 'General', 'solver': convert_unit},
    'open-channel': {'name': 'Open Channel Flow', 'category': 'Hydraulics', 'solver': solve_open_channel},
    'pavement-thickness': {'name': 'Pavement Thickness', 'category': 'Hydraulics', 'solver': solve_pavement_thickness},
    'sight-distance': {'name': 'Sight Distance', 'category': 'Hydraulics', 'solver': solve_sight_distance},
    'weir-orifice': {'name': 'Weir & Orifice', 'category': 'Hydraulics', 'solver': solve_weir_orifice},
    'apf': {'name': 'Atomic Packing Factor', 'category': 'Materials', 'solver': solve_apf},
    'corrosion': {'name': 'Corrosion', 'category': 'Materials', 'solver': solve_corrosion},
    'fatigue-life': {'name': 'Fatigue Life', 'category': 'Materials', 'solver': solve_fatigue_life},
    'hardness-conversion': {'name': 'Hardness Conversion', 'category': 'Materials', 'solver': solve_hardness_conversion},
    'rule-of-mixtures': {'name': 'Rule of Mixtures', 'category': 'Materials', 'solver': solve_rule_of_mixtures},
    'beam': {'name': 'Beam', 'category': 'Mechanical', 'solver': solve_beam},
    'bearing-life': {'name': 'Bearing Life', 'category': 'Mechanical', 'solver': solve_bearing_life},
    'belt-drive': {'name': 'Belt Drive', 'category': 'Mechanical', 'solver': solve_belt_drive},
    'bolt-analysis': {'name': 'Bolt Analysis', 'category': 'Mechanical', 'solver': solve_bolt_analysis},
    'cop': {'name': 'Coefficient of Performance', 'category': 'Mechanical', 'solver': solve_cop},
    'flywheel': {'name': 'Flywheel', 'category': 'Mechanical', 'solver': solve_flywheel},
    'gear-ratio': {'name': 'Gear Ratio', 'category': 'Mechanical', 'solver': solve_gear_ratio},
    'heat-exchanger': {'name': 'Heat Exchanger', 'category': 'Mechanical', 'solver': solve_heat_exchanger},
    'heat-transfer': {'name': 'Heat Transfer', 'category': 'Mechanical', 'solver': solve_heat_transfer},
    'ideal-gas': {'name': 'Ideal Gas Law', 'category': 'Mechanical', 'solver': solve_ideal_gas},
    'pipe-flow': {'name': 'Pipe Flow', 'category': 'Mechanical', 'solver': solve_pipe_flow},
    'pressure-force': {'name': 'Pressure Force', 'category': 'Mechanical', 'solver': solve_pressure_force},
    'pump-power': {'name': 'Pump Power', 'category': 'Mechanical', 'solver': solve_pump_power},
    'rankine-cycle': {'name': 'Rankine Cycle', 'category': 'Mechanical', 'solver': solve_rankine_cycle},
    'shaft-design': {'name': 'Shaft Design', 'category': 'Mechanical', 'solver': solve_shaft_design},
    'spring-design': {'name': 'Spring Design', 'category': 'Mechanical', 'solver': solve_spring_design},
    'torque-power': {'name': 'Torque Power', 'category': 'Mechanical', 'solver': solve_torque_power},
    'vibration': {'name': 'Vibration', 'category': 'Mechanical', 'solver': solve_vibration},
    'weld-strength': {'name': 'Weld Strength', 'category': 'Mechanical', 'solver': solve_weld_strength},
    'beam-deflection': {'name': 'Beam Deflection', 'category': 'Structural', 'solver': solve_beam_deflection},
    'bearing-capacity': {'name': 'Bearing Capacity', 'category': 'Structural', 'solver': solve_bearing_capacity},
    'column-buckling': {'name': 'Column Buckling', 'category': 'Structural', 'solver': solve_column_buckling},
    'concrete-volume': {'name': 'Concrete Volume', 'category': 'Structural', 'solver': solve_concrete_volume},
    'development-length': {'name': 'Development Length', 'category': 'Structural', 'solver': solve_development_length},
    'earth-pressure': {'name': 'Earth Pressure', 'category': 'Structural', 'solver': solve_earth_pressure},
    'failure-theory': {'name': 'Failure Theory', 'category': 'Structural', 'solver': solve_failure_theory},
    'isolated-footing': {'name': 'Isolated Footing', 'category': 'Structural', 'solver': solve_isolated_footing},
    'mohrs-circle': {'name': 'Mohr\'s Circle', 'category': 'Structural', 'solver': solve_mohrs_circle},
    'rcc-beam': {'name': 'RCC Beam Design', 'category': 'Structural', 'solver': solve_rcc_beam},
    'rcc-column': {'name': 'RCC Column Design', 'category': 'Structural', 'solver': solve_rcc_column},
    'rcc-slab': {'name': 'RCC Slab Design', 'category': 'Structural', 'solver': solve_rcc_slab},
    'reinforcement-qty': {'name': 'Reinforcement Qty', 'category': 'Structural', 'solver': solve_reinforcement_qty},
    'settlement': {'name': 'Settlement', 'category': 'Structural', 'solver': solve_settlement},
    'soil-properties': {'name': 'Soil Properties', 'category': 'Structural', 'solver': solve_soil_properties},
    'steel-weight': {'name': 'Steel Weight', 'category': 'Structural', 'solver': solve_steel_weight},
    'stress-strain': {'name': 'Stress Strain', 'category': 'Structural', 'solver': solve_stress_strain},
}

def compute(calculator_type: str, inputs: dict) -> dict:
    """Run a calculator engine and return results."""
    calc = CALCULATORS.get(calculator_type)
    if not calc:
        available = ', '.join(CALCULATORS.keys())
        raise ValueError(f"Unknown calculator: '{calculator_type}'. Available: {available}")
    result = calc['solver'](inputs)
    try:
        display_result(calculator_type, calc['name'], inputs, result)
    except Exception:
        pass
    return result

def convert(category: str, value: float, from_unit: str, to_unit: str) -> float:
    """Convert a value between units."""
    result = convert_unit({
        'category': category,
        'value': value,
        'fromUnit': from_unit,
        'toUnit': to_unit,
    })
    if result is None:
        raise ValueError(f"Cannot convert {from_unit} -> {to_unit} in category '{category}'")
    return result['value']

def list_calculators() -> list:
    """List all available calculators."""
    return [
        {'id': k, 'name': v['name'], 'category': v['category']}
        for k, v in CALCULATORS.items()
    ]
