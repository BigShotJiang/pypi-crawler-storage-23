"""
Phaxor — Engineering Materials Database (Basic Edition)

Contains a curated subset of common engineering materials for learning.
- 10 structural metals
- 5 polymers
- 3 concrete grades
- 2 fluids

For the full library of 1,550+ materials across 8 categories
(structural metals, polymers, ceramics, fluids, conductors,
concrete & masonry, semiconductors, magnetic materials), use
the Phaxor Cloud API → https://phaxor.com/api
"""


# ─── Structural Metals (10 of 525 available via API) ────────────────────────

STRUCTURAL_METALS = {
    'steel-a36': {
        'name': 'ASTM A36 Steel',
        'E': 200, 'sigmaY': 250, 'sigmaUlt': 400, 'nu': 0.26,
        'density': 7850, 'elongation': 20,
        'thermalConductivity': 50, 'specificHeat': 490,
        'thermalExpansion': 12e-6,
    },
    'steel-a572': {
        'name': 'ASTM A572 Gr.50',
        'E': 200, 'sigmaY': 345, 'sigmaUlt': 450, 'nu': 0.27,
        'density': 7850, 'elongation': 18,
        'thermalConductivity': 50, 'specificHeat': 486,
        'thermalExpansion': 12e-6,
    },
    'stainless-304': {
        'name': 'Stainless Steel 304',
        'E': 193, 'sigmaY': 215, 'sigmaUlt': 505, 'nu': 0.29,
        'density': 7900, 'elongation': 40,
        'thermalConductivity': 16.2, 'specificHeat': 500,
        'thermalExpansion': 17.3e-6,
    },
    'stainless-316': {
        'name': 'Stainless Steel 316',
        'E': 193, 'sigmaY': 205, 'sigmaUlt': 515, 'nu': 0.30,
        'density': 8000, 'elongation': 40,
        'thermalConductivity': 16.3, 'specificHeat': 500,
        'thermalExpansion': 16e-6,
    },
    'aluminum-6061': {
        'name': 'Aluminum 6061-T6',
        'E': 68.9, 'sigmaY': 276, 'sigmaUlt': 310, 'nu': 0.33,
        'density': 2700, 'elongation': 12,
        'thermalConductivity': 167, 'specificHeat': 896,
        'thermalExpansion': 23.6e-6,
    },
    'aluminum-7075': {
        'name': 'Aluminum 7075-T6',
        'E': 71.7, 'sigmaY': 503, 'sigmaUlt': 572, 'nu': 0.33,
        'density': 2810, 'elongation': 11,
        'thermalConductivity': 130, 'specificHeat': 960,
        'thermalExpansion': 23.4e-6,
    },
    'copper-c11000': {
        'name': 'Copper C11000',
        'E': 117, 'sigmaY': 69, 'sigmaUlt': 220, 'nu': 0.34,
        'density': 8960, 'elongation': 42,
        'thermalConductivity': 385, 'specificHeat': 385,
        'thermalExpansion': 16.5e-6,
    },
    'titanium-ti6al4v': {
        'name': 'Ti-6Al-4V',
        'E': 114, 'sigmaY': 880, 'sigmaUlt': 950, 'nu': 0.34,
        'density': 4430, 'elongation': 14,
        'thermalConductivity': 6.7, 'specificHeat': 526,
        'thermalExpansion': 8.6e-6,
    },
    'cast-iron-gray': {
        'name': 'Gray Cast Iron',
        'E': 100, 'sigmaY': 130, 'sigmaUlt': 200, 'nu': 0.26,
        'density': 7200, 'elongation': 0.5,
        'thermalConductivity': 46, 'specificHeat': 490,
        'thermalExpansion': 10.8e-6,
    },
    'inconel-625': {
        'name': 'Inconel 625',
        'E': 205, 'sigmaY': 460, 'sigmaUlt': 830, 'nu': 0.31,
        'density': 8440, 'elongation': 30,
        'thermalConductivity': 9.8, 'specificHeat': 410,
        'thermalExpansion': 12.8e-6,
    },
}

# ─── Polymers (5 of 339 available via API) ──────────────────────────────────

POLYMERS = {
    'abs': {
        'name': 'ABS',
        'E': 2.3, 'sigmaY': 40, 'sigmaUlt': 45, 'nu': 0.35,
        'density': 1050, 'elongation': 10,
        'thermalConductivity': 0.17, 'maxServiceTemp': 80,
    },
    'nylon-6': {
        'name': 'Nylon 6',
        'E': 2.8, 'sigmaY': 70, 'sigmaUlt': 85, 'nu': 0.39,
        'density': 1140, 'elongation': 60,
        'thermalConductivity': 0.25, 'maxServiceTemp': 120,
    },
    'hdpe': {
        'name': 'HDPE',
        'E': 1.1, 'sigmaY': 26, 'sigmaUlt': 37, 'nu': 0.42,
        'density': 960, 'elongation': 500,
        'thermalConductivity': 0.49, 'maxServiceTemp': 82,
    },
    'pvc-rigid': {
        'name': 'PVC (Rigid)',
        'E': 3.3, 'sigmaY': 45, 'sigmaUlt': 52, 'nu': 0.38,
        'density': 1400, 'elongation': 30,
        'thermalConductivity': 0.16, 'maxServiceTemp': 60,
    },
    'peek': {
        'name': 'PEEK',
        'E': 4.0, 'sigmaY': 91, 'sigmaUlt': 100, 'nu': 0.38,
        'density': 1300, 'elongation': 50,
        'thermalConductivity': 0.25, 'maxServiceTemp': 250,
    },
}

# ─── Concrete (3 of 127 available via API) ──────────────────────────────────

CONCRETE = {
    'm20': {
        'name': 'M20 Concrete',
        'fck': 20, 'density': 2400, 'E': 22.4,
        'nu': 0.2, 'thermalExpansion': 10e-6,
    },
    'm30': {
        'name': 'M30 Concrete',
        'fck': 30, 'density': 2400, 'E': 27.4,
        'nu': 0.2, 'thermalExpansion': 10e-6,
    },
    'm40': {
        'name': 'M40 Concrete',
        'fck': 40, 'density': 2400, 'E': 31.6,
        'nu': 0.2, 'thermalExpansion': 10e-6,
    },
}

# ─── Fluids (2 of 167 available via API) ─────────────────────────────────────

FLUIDS = {
    'water-20c': {
        'name': 'Water (20°C)',
        'density': 998, 'viscosity': 0.001002,
        'specificHeat': 4182, 'thermalConductivity': 0.598,
        'prandtl': 7.01,
    },
    'air-20c': {
        'name': 'Air (20°C, 1 atm)',
        'density': 1.204, 'viscosity': 1.825e-5,
        'specificHeat': 1006, 'thermalConductivity': 0.0257,
        'prandtl': 0.713,
    },
}

# ─── Unified Lookup ─────────────────────────────────────────────────────────

ALL_MATERIALS = {}
ALL_MATERIALS.update(STRUCTURAL_METALS)
ALL_MATERIALS.update(POLYMERS)
ALL_MATERIALS.update(CONCRETE)
ALL_MATERIALS.update(FLUIDS)


def get_material(material_id: str) -> dict:
    """
    Look up a material by ID.

    Parameters
    ----------
    material_id : str — Material key (e.g., 'steel-a36', 'abs', 'm20')

    Returns
    -------
    dict — Material properties

    Note
    ----
    This free library contains 20 materials. For the full database of
    1,550+ materials with advanced filtering, comparison, and cost data,
    use the Phaxor Cloud API → https://phaxor.com/api
    """
    mat = ALL_MATERIALS.get(material_id)
    if not mat:
        avail = ', '.join(ALL_MATERIALS.keys())
        raise ValueError(
            f"Material '{material_id}' not found in free library.\n"
            f"Available: {avail}\n\n"
            f"For 1,550+ materials, use the Phaxor Cloud API → https://phaxor.com/api"
        )
    return mat


def list_materials(category: str = None) -> list:
    """
    List available materials, optionally filtered by category.

    Parameters
    ----------
    category : str — 'metals', 'polymers', 'concrete', 'fluids', or None for all

    Returns
    -------
    list of dict — [{'id': str, 'name': str, 'category': str}]
    """
    cats = {
        'metals': STRUCTURAL_METALS,
        'polymers': POLYMERS,
        'concrete': CONCRETE,
        'fluids': FLUIDS,
    }

    if category:
        src = cats.get(category, {})
        return [{'id': k, 'name': v['name'], 'category': category} for k, v in src.items()]

    result = []
    for cat_name, cat_data in cats.items():
        for k, v in cat_data.items():
            result.append({'id': k, 'name': v['name'], 'category': cat_name})
    return result


def compare_materials(*material_ids: str) -> dict:
    """
    Compare multiple materials side-by-side.

    Parameters
    ----------
    *material_ids : str — Material keys to compare

    Returns
    -------
    dict — {'materials': [...], 'comparison': {...}}

    Example
    -------
    >>> phaxor.materials.compare_materials('steel-a36', 'aluminum-6061', 'titanium-ti6al4v')
    """
    mats = []
    for mid in material_ids:
        m = ALL_MATERIALS.get(mid)
        if m:
            mats.append({'id': mid, **m})

    if not mats:
        return {'materials': [], 'comparison': {}}

    # Build comparison
    common_keys = ['E', 'sigmaY', 'sigmaUlt', 'density']
    comparison = {}
    for key in common_keys:
        vals = [(m['id'], m.get(key)) for m in mats if key in m]
        if vals:
            comparison[key] = {
                'values': {v[0]: v[1] for v in vals},
                'best': max(vals, key=lambda x: x[1] if x[1] else 0)[0],
                'unit': _get_unit(key),
            }

    return {'materials': mats, 'comparison': comparison}


def _get_unit(key: str) -> str:
    units = {
        'E': 'GPa', 'sigmaY': 'MPa', 'sigmaUlt': 'MPa',
        'density': 'kg/m³', 'elongation': '%', 'nu': '-',
        'thermalConductivity': 'W/m·K', 'specificHeat': 'J/kg·K',
        'thermalExpansion': '1/°C', 'fck': 'MPa',
        'viscosity': 'Pa·s', 'prandtl': '-',
    }
    return units.get(key, '')
