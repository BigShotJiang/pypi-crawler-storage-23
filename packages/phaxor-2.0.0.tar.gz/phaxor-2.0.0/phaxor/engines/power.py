"""Phaxor — AC Power Engine (Python port)"""
import math

def solve_ac_power(inputs: dict) -> dict | None:
    """AC Power Calculator (1-phase / 3-phase)."""
    v = float(inputs.get('voltage', 0))
    i = float(inputs.get('current', 0))
    pf = float(inputs.get('powerFactor', 0.85))
    phase = inputs.get('phase', '1-phase')

    if v <= 0 or i <= 0:
        return None

    pf = max(0.01, min(1.0, pf))
    phi = math.acos(pf)
    multiplier = math.sqrt(3) if phase == '3-phase' else 1.0

    s = v * i * multiplier
    p = s * pf
    q = s * math.sin(phi)

    # PF Correction to 0.95
    target_pf = 0.95
    cap_needed = 0.0
    if pf < target_pf:
        phi_target = math.acos(target_pf)
        qc = p * (math.tan(phi) - math.tan(phi_target))
        cap_needed = qc / 1000.0

    hp = (p / 1000.0) / 0.746
    monthly_kwh = (p / 1000.0) * 8 * 30

    return {
        'S': float(f"{s:.2f}"),
        'P': float(f"{p:.2f}"),
        'Q': float(f"{q:.2f}"),
        'phi': float(f"{phi:.4f}"),
        'PF': pf,
        'capNeeded': float(f"{cap_needed:.3f}"),
        'hp': float(f"{hp:.2f}"),
        'monthlyKWh': float(f"{monthly_kwh:.2f}")
    }
