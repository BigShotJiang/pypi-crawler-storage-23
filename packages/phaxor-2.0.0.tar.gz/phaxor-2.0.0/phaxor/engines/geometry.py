"""Phaxor — Geometry Engine (Python port)"""
import math

def solve_geometry(inputs: dict) -> dict | None:
    """Geometry Calculator."""
    shape = inputs.get('shape', '')
    points = inputs.get('points', [])

    if not points: return None

    def dist(p1, p2):
        return math.sqrt((p1['x'] - p2['x'])**2 + (p1['y'] - p2['y'])**2)

    if shape == 'triangle' and len(points) == 3:
        a, b, c = points[0], points[1], points[2]
        ab = dist(a, b)
        bc = dist(b, c)
        ca = dist(c, a)
        s = (ab + bc + ca) / 2
        area = math.sqrt(max(0, s * (s - ab) * (s - bc) * (s - ca)))
        peri = ab + bc + ca
        cx = (a['x'] + b['x'] + c['x']) / 3
        cy = (a['y'] + b['y'] + c['y']) / 3
        
        return {
            'area': float(f"{area:.2f}"),
            'perimeter': float(f"{peri:.2f}"),
            'centroid': {'x': cx, 'y': cy}
        }

    if shape == 'circle' and len(points) == 2:
        r = dist(points[0], points[1])
        area = math.pi * r * r
        peri = 2 * math.pi * r
        return {
            'area': float(f"{area:.2f}"),
            'perimeter': float(f"{peri:.2f}"),
            'centroid': points[0],
            'details': {'radius': float(f"{r:.2f}")}
        }
    
    if shape == 'rectangle' and len(points) == 4:
        # Shoelace
        area = 0.0
        peri = 0.0
        for i in range(4):
            j = (i + 1) % 4
            area += points[i]['x'] * points[j]['y'] - points[j]['x'] * points[i]['y']
            peri += dist(points[i], points[j])
        
        area = abs(area) / 2
        cx = sum(p['x'] for p in points) / 4
        cy = sum(p['y'] for p in points) / 4
        
        return {
            'area': float(f"{area:.2f}"),
            'perimeter': float(f"{peri:.2f}"),
            'centroid': {'x': cx, 'y': cy}
        }
    
    return None
