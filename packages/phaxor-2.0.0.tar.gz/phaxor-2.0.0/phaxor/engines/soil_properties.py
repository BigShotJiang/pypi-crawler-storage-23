import math

def solve_soil_properties(inputs):
    try:
        GsV = float(inputs.get('Gs', 0))
        wV = float(inputs.get('w', 0)) / 100
        SeV = float(inputs.get('Se', 0)) / 100
        gammaBV = float(inputs.get('gammaB', 0))
        inputMode = inputs.get('inputMode', 'from-w-Se')
        gammaW = 9.81

        if GsV == 0:
            return {'error': 'Specific Gravity (Gs) is required'}

        e = 0
        if inputMode == 'from-w-Se':
            e = (wV * GsV) / SeV if SeV > 0 else wV * GsV
        else:
            if gammaBV == 0: return {'error': 'Bulk Unit Weight is required'}
            e = (GsV * gammaW * (1 + wV)) / gammaBV - 1

        if e < 0: e = 0
        n = e / (1 + e)

        S = (wV * GsV) / e if e > 0 else 0
        Vv = e
        Vs = 1
        Vw = S * e
        Va = e - Vw
        Vt = 1 + e

        gammaDry = (GsV * gammaW) / (1 + e)
        gammaSat = ((GsV + e) * gammaW) / (1 + e)
        gammaBulk = (GsV * (1 + wV) * gammaW) / (1 + e)
        gammaSub = gammaSat - gammaW

        Ws = GsV * gammaW
        Ww = wV * Ws
        v = 1 + e
        ac = Va / Vt

        return {
            'result': {
                'e': e, 'n': n, 'S': S * 100, 'wPct': wV * 100,
                'gammaDry': gammaDry, 'gammaSat': gammaSat,
                'gammaBulk': gammaBulk, 'gammaSub': gammaSub,
                'Vs': Vs, 'Vw': Vw, 'Va': Va, 'Vv': Vv, 'Vt': Vt,
                'Ws': Ws, 'Ww': Ww, 'v': v, 'ac': ac * 100, 'GsV': GsV
            }
        }
    except Exception as e:
        return {'error': str(e)}
