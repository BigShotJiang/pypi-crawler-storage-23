import math

def solve_rcc_column(inputs):
    try:
        shape = inputs.get('shape', 'rectangular')
        bv = float(inputs.get('b', 0))
        Dv = float(inputs.get('D', 0))
        Puv = float(inputs.get('Pu', 0)) * 1000 # kN -> N
        Lv = float(inputs.get('L', 0))
        fck = float(inputs.get('fck', 0))
        fy = float(inputs.get('fy', 0))
        barDia = float(inputs.get('barDia', 16))

        if bv == 0 or (shape == 'rectangular' and Dv == 0) or Puv == 0 or fck == 0 or fy == 0:
            return {'error': 'Invalid input parameters'}

        # Gross area
        Ag = math.pi * bv**2 / 4 if shape == 'circular' else bv * Dv

        # Slenderness
        Dmin = bv if shape == 'circular' else min(bv, Dv)
        slenderness = Lv / Dmin if Dmin > 0 else 0
        isShort = slenderness <= 12

        # Required Asc
        ptMin = 0.8
        ptMax = 4.0

        # Puv = 0.4 * fck * Ag + Asc * (0.67 * fy - 0.4 * fck)
        denom = (0.67 * fy - 0.4 * fck)
        if denom == 0: return {'error': 'Denominator zero in Asc calc'}
        
        Asc = (Puv - 0.4 * fck * Ag) / denom
        if Asc < 0: Asc = 0

        AscMin = ptMin / 100 * Ag
        AscMax = ptMax / 100 * Ag

        if Asc < AscMin: Asc = AscMin
        
        pt = (Asc / Ag) * 100
        isSafe = Asc <= AscMax

        # Number of bars
        areaOneBar = math.pi * barDia**2 / 4
        numBars = math.ceil(Asc / areaOneBar)

        if shape == 'circular' and numBars < 6: numBars = 6
        if shape == 'rectangular' and numBars < 4: numBars = 4
        
        if shape == 'rectangular' and numBars > 4 and numBars % 2 != 0:
            numBars += 1
        
        AscProvided = numBars * areaOneBar

        # Capacity
        Ac = Ag - AscProvided
        PuCapacity = (0.4 * fck * Ac + 0.67 * fy * AscProvided) / 1000 # N -> kN

        # Tie spacing
        tieSpacing = min(Dmin, 16 * barDia, 300)

        capacityRatio = PuCapacity / (Puv / 1000) if Puv > 0 else 0

        return {
            'result': {
                'Ag': Ag,
                'Asc': Asc,
                'AscProvided': AscProvided,
                'numBars': numBars,
                'pt': pt,
                'isSafe': isSafe,
                'isShort': isShort,
                'slenderness': slenderness,
                'PuCapacity': PuCapacity,
                'capacityRatio': capacityRatio,
                'tieSpacing': tieSpacing,
                'AscMin': AscMin,
                'AscMax': AscMax,
                'areaOneBar': areaOneBar
            }
        }

    except Exception as e:
        return {'error': str(e)}
