"""Phaxor — Corrosion Rate Engine (Python port)"""

def solve_corrosion(inputs: dict) -> dict | None:
    """Corrosion Rate Calculator."""
    mass_loss = float(inputs.get('massLoss', 0))
    area = float(inputs.get('area', 0))
    time = float(inputs.get('time', 0))
    density = float(inputs.get('density', 0))

    if mass_loss <= 0 or area <= 0 or time <= 0 or density <= 0:
        return None

    # ASTM G1 Formula
    k_mmy = 87600
    cr_mmy = (k_mmy * mass_loss) / (area * time * density)

    cr_mpy = cr_mmy * 39.37
    cr_umy = cr_mmy * 1000.0
    cr_mmday = cr_mmy / 365.25

    severity = ""
    severity_color = ""
    if cr_mmy < 0.025:
        severity = 'Excellent'
        severity_color = '#22c55e'
    elif cr_mmy < 0.12:
        severity = 'Good'
        severity_color = '#84cc16'
    elif cr_mmy < 0.25:
        severity = 'Fair'
        severity_color = '#f59e0b'
    elif cr_mmy < 0.50:
        severity = 'Poor'
        severity_color = '#f97316'
    else:
        severity = 'Unacceptable'
        severity_color = '#ef4444'

    time_data = []
    for yr in range(0, 26, 5):
        time_data.append({'year': yr, 'loss': float(f"{cr_mmy * yr:.3f}")})

    wall_thickness = 10.0
    life_years = wall_thickness / cr_mmy if cr_mmy > 0 else 999.0

    return {
        'CR_mmy': float(f"{cr_mmy:.4f}"),
        'CR_mpy': float(f"{cr_mpy:.2f}"),
        'CR_umy': float(f"{cr_umy:.1f}"),
        'CR_mmday': float(f"{cr_mmday:.5f}"),
        'severity': severity,
        'severityColor': severity_color,
        'lifeYears': float(f"{life_years:.1f}"),
        'timeData': time_data
    }
