"""Phaxor — Ohm's Law Engine (Python port)"""


def solve_ohms_law(inputs: dict) -> dict | None:
    """Solve V = IR for any unknown variable."""
    V = inputs.get('voltage', 0)
    I = inputs.get('current', 0)
    R = inputs.get('resistance', 0)
    solve_for = inputs.get('solveFor', '')

    if solve_for == 'V' and I and R:
        V = I * R
    elif solve_for == 'I' and V and R:
        I = V / R
    elif solve_for == 'R' and V and I:
        R = V / I
    else:
        if not V and I and R: V = I * R
        elif V and not I and R: I = V / R
        elif V and I and not R: R = V / I
        elif V and R: I = V / R

    if V <= 0 and I <= 0 and R <= 0:
        return None

    P = V * I
    vi_data = [{'V': round(v, 2), 'I': round(v / R, 4) if R > 0 else 0}
               for v in [V * 2 * i / 20 for i in range(21)]]
    
    power_wheel = [
        {'formula': 'V×I', 'value': round(V * I, 2)},
        {'formula': 'V²/R', 'value': round(V * V / R, 2) if R > 0 else 0},
        {'formula': 'I²×R', 'value': round(I * I * R, 2)},
    ]

    rating = 'High Power' if P > 1000 else 'Medium' if P > 100 else 'Low' if P > 10 else 'Micro'

    return {
        'V': V, 'I': I, 'R': R, 'P': P,
        'kWh': P / 1000,
        'conductance': 1 / R if R > 0 else 0,
        'rating': rating,
        'viData': vi_data,
        'powerWheel': power_wheel,
    }
