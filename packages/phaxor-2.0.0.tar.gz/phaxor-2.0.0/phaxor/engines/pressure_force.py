"""Phaxor — Pressure, Force & Area Engine (Python port)"""
import math

def solve_pressure_force(inputs: dict) -> dict | None:
    """Solve for pressure, force, or area."""
    mode = inputs.get('mode', 'find-pressure')
    shape = inputs.get('shape', 'circle')
    dims = inputs.get('dims', {})
    force = float(inputs.get('force', 0))
    pressure = float(inputs.get('pressure', 0))

    # Calculate Area
    area_mm2 = 0
    if shape == 'circle':
        d = float(dims.get('d', 0))
        area_mm2 = math.pi * (d / 2) ** 2
    elif shape == 'rectangle':
        w = float(dims.get('w', 0))
        h = float(dims.get('h', 0))
        area_mm2 = w * h
    elif shape == 'ring':
        od = float(dims.get('od', 0))
        id_val = float(dims.get('id', 0))
        area_mm2 = math.pi * ((od / 2) ** 2 - (id_val / 2) ** 2)
    elif shape == 'custom':
        area_mm2 = float(dims.get('area', 0))

    area_m2 = area_mm2 / 1e6

    calc_f = force
    calc_p_pa = pressure
    calc_a_mm2 = area_mm2
    calc_a_m2 = area_m2

    if mode == 'find-pressure':
        if calc_a_m2 > 0:
            calc_p_pa = calc_f / calc_a_m2
        else:
            calc_p_pa = 0

    elif mode == 'find-force':
        calc_f = calc_p_pa * calc_a_m2

    elif mode == 'find-area':
        if calc_p_pa > 0:
            calc_a_m2 = calc_f / calc_p_pa
            calc_a_mm2 = calc_a_m2 * 1e6
        else:
            calc_a_m2 = 0
            calc_a_mm2 = 0

    p_mpa = calc_p_pa / 1e6
    atm = calc_p_pa / 101325

    context = 'Normal'
    if p_mpa < 0.001: context = 'Near vacuum / very low'
    elif p_mpa < 0.1: context = 'Low pressure (pneumatic)'
    elif p_mpa < 1: context = 'Moderate (hydraulic / pneumatic)'
    elif p_mpa < 10: context = 'High pressure (hydraulic)'
    elif p_mpa < 100: context = 'Very high pressure (industrial)'
    else: context = 'Extreme pressure (special equipment)'

    return {
        'force': float(f"{calc_f:.2f}"),
        'pressurePa': float(f"{calc_p_pa:.2f}"),
        'pressureMPa': float(f"{p_mpa:.4f}"),
        'areaMM2': float(f"{calc_a_mm2:.2f}"),
        'areaM2': calc_a_m2,
        'atm': float(f"{atm:.3f}"),
        'context': context
    }
