import math

def solve_development_length(inputs):
    try:
        fck = float(inputs.get('fck', 20))
        fy = float(inputs.get('fy', 415))
        phi = float(inputs.get('phi', 16))
        barType = inputs.get('barType', 'deformed')
        intension = inputs.get('intension', True)
        if isinstance(intension, str):
            intension = intension.lower() == 'true'

        tauBd = 1.0
        if fck <= 15: tauBd = 1.0
        elif fck <= 20: tauBd = 1.2
        elif fck <= 25: tauBd = 1.4
        elif fck <= 30: tauBd = 1.5
        elif fck <= 35: tauBd = 1.7
        else: tauBd = 1.9

        if barType == 'deformed': tauBd *= 1.6
        if not intension: tauBd *= 1.25

        sigmaS = 0.87 * fy
        Ld = (phi * sigmaS) / (4 * tauBd)

        hookLen = 16 * phi if barType == 'plain' else 0
        LdEffective = Ld - hookLen * 0.75 if barType == 'plain' else Ld

        spliceTension = Ld
        spliceCompression = Ld

        return {
            'result': {
                'tauBd': tauBd, 'sigmaS': sigmaS, 'Ld': Ld,
                'LdEffective': LdEffective, 'hookLen': hookLen,
                'spliceTension': spliceTension, 'spliceCompression': spliceCompression,
                'LdPhiRatio': Ld / phi if phi > 0 else 0
            }
        }
    except Exception as e:
        return {'error': str(e)}
