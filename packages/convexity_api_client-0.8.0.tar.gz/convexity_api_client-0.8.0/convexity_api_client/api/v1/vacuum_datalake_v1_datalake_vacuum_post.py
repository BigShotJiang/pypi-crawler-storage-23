from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.worker_task_response import WorkerTaskResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    retention_hours: int | Unset = 168,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["retention_hours"] = retention_hours

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/datalake-vacuum",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkerTaskResponse | None:
    if response.status_code == 200:
        response_200 = WorkerTaskResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    retention_hours: int | Unset = 168,
    project_id: str,
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    """Vacuum Datalake

     Enqueue a VACUUM task to clean up unreferenced Parquet files.

    The vacuum operation is offloaded to a background worker to avoid
    blocking the API event loop. Removes orphaned data files that are no
    longer referenced by the catalog (e.g. after table drops or overwrites).
    Files newer than `retention_hours` are preserved.

    Requires admin role.

    Args:
        retention_hours (int | Unset): Keep files newer than this many hours (default: 7 days)
            Default: 168.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkerTaskResponse]
    """

    kwargs = _get_kwargs(
        retention_hours=retention_hours,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    retention_hours: int | Unset = 168,
    project_id: str,
) -> HTTPValidationError | WorkerTaskResponse | None:
    """Vacuum Datalake

     Enqueue a VACUUM task to clean up unreferenced Parquet files.

    The vacuum operation is offloaded to a background worker to avoid
    blocking the API event loop. Removes orphaned data files that are no
    longer referenced by the catalog (e.g. after table drops or overwrites).
    Files newer than `retention_hours` are preserved.

    Requires admin role.

    Args:
        retention_hours (int | Unset): Keep files newer than this many hours (default: 7 days)
            Default: 168.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkerTaskResponse
    """

    return sync_detailed(
        client=client,
        retention_hours=retention_hours,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    retention_hours: int | Unset = 168,
    project_id: str,
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    """Vacuum Datalake

     Enqueue a VACUUM task to clean up unreferenced Parquet files.

    The vacuum operation is offloaded to a background worker to avoid
    blocking the API event loop. Removes orphaned data files that are no
    longer referenced by the catalog (e.g. after table drops or overwrites).
    Files newer than `retention_hours` are preserved.

    Requires admin role.

    Args:
        retention_hours (int | Unset): Keep files newer than this many hours (default: 7 days)
            Default: 168.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkerTaskResponse]
    """

    kwargs = _get_kwargs(
        retention_hours=retention_hours,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    retention_hours: int | Unset = 168,
    project_id: str,
) -> HTTPValidationError | WorkerTaskResponse | None:
    """Vacuum Datalake

     Enqueue a VACUUM task to clean up unreferenced Parquet files.

    The vacuum operation is offloaded to a background worker to avoid
    blocking the API event loop. Removes orphaned data files that are no
    longer referenced by the catalog (e.g. after table drops or overwrites).
    Files newer than `retention_hours` are preserved.

    Requires admin role.

    Args:
        retention_hours (int | Unset): Keep files newer than this many hours (default: 7 days)
            Default: 168.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkerTaskResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            retention_hours=retention_hours,
            project_id=project_id,
        )
    ).parsed
