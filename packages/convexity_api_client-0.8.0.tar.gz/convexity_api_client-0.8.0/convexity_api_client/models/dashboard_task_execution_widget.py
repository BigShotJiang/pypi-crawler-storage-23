from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.task_execution_parameter_override import TaskExecutionParameterOverride


T = TypeVar("T", bound="DashboardTaskExecutionWidget")


@_attrs_define
class DashboardTaskExecutionWidget:
    """Task execution control widget. Acts as a filter widget that publishes run_id.

    Attributes:
        id (str): Unique widget identifier
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['task_execution'] | Unset):  Default: 'task_execution'.
        is_filter (bool | Unset): Indicates this acts as a filter widget Default: True.
        column_name (str | Unset): Column name to filter on (default: run_id) Default: 'run_id'.
        dataset_ids (list[str] | None | Unset): Dataset IDs this filter applies to
        task_id (None | str | Unset): ID of the task to execute
        parameter_overrides (list[TaskExecutionParameterOverride] | None | Unset): Overrides for task parameter form
            fields
        default_value (None | str | Unset): Default run_id filter value
    """

    id: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["task_execution"] | Unset = "task_execution"
    is_filter: bool | Unset = True
    column_name: str | Unset = "run_id"
    dataset_ids: list[str] | None | Unset = UNSET
    task_id: None | str | Unset = UNSET
    parameter_overrides: list[TaskExecutionParameterOverride] | None | Unset = UNSET
    default_value: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        is_filter = self.is_filter

        column_name = self.column_name

        dataset_ids: list[str] | None | Unset
        if isinstance(self.dataset_ids, Unset):
            dataset_ids = UNSET
        elif isinstance(self.dataset_ids, list):
            dataset_ids = self.dataset_ids

        else:
            dataset_ids = self.dataset_ids

        task_id: None | str | Unset
        if isinstance(self.task_id, Unset):
            task_id = UNSET
        else:
            task_id = self.task_id

        parameter_overrides: list[dict[str, Any]] | None | Unset
        if isinstance(self.parameter_overrides, Unset):
            parameter_overrides = UNSET
        elif isinstance(self.parameter_overrides, list):
            parameter_overrides = []
            for parameter_overrides_type_0_item_data in self.parameter_overrides:
                parameter_overrides_type_0_item = parameter_overrides_type_0_item_data.to_dict()
                parameter_overrides.append(parameter_overrides_type_0_item)

        else:
            parameter_overrides = self.parameter_overrides

        default_value: None | str | Unset
        if isinstance(self.default_value, Unset):
            default_value = UNSET
        else:
            default_value = self.default_value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if is_filter is not UNSET:
            field_dict["isFilter"] = is_filter
        if column_name is not UNSET:
            field_dict["columnName"] = column_name
        if dataset_ids is not UNSET:
            field_dict["datasetIds"] = dataset_ids
        if task_id is not UNSET:
            field_dict["taskId"] = task_id
        if parameter_overrides is not UNSET:
            field_dict["parameterOverrides"] = parameter_overrides
        if default_value is not UNSET:
            field_dict["defaultValue"] = default_value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.task_execution_parameter_override import TaskExecutionParameterOverride

        d = dict(src_dict)
        id = d.pop("id")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["task_execution"] | Unset, d.pop("type", UNSET))
        if type_ != "task_execution" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'task_execution', got '{type_}'")

        is_filter = d.pop("isFilter", UNSET)

        column_name = d.pop("columnName", UNSET)

        def _parse_dataset_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_ids_type_0 = cast(list[str], data)

                return dataset_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        dataset_ids = _parse_dataset_ids(d.pop("datasetIds", UNSET))

        def _parse_task_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        task_id = _parse_task_id(d.pop("taskId", UNSET))

        def _parse_parameter_overrides(data: object) -> list[TaskExecutionParameterOverride] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                parameter_overrides_type_0 = []
                _parameter_overrides_type_0 = data
                for parameter_overrides_type_0_item_data in _parameter_overrides_type_0:
                    parameter_overrides_type_0_item = TaskExecutionParameterOverride.from_dict(
                        parameter_overrides_type_0_item_data
                    )

                    parameter_overrides_type_0.append(parameter_overrides_type_0_item)

                return parameter_overrides_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TaskExecutionParameterOverride] | None | Unset, data)

        parameter_overrides = _parse_parameter_overrides(d.pop("parameterOverrides", UNSET))

        def _parse_default_value(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        default_value = _parse_default_value(d.pop("defaultValue", UNSET))

        dashboard_task_execution_widget = cls(
            id=id,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            is_filter=is_filter,
            column_name=column_name,
            dataset_ids=dataset_ids,
            task_id=task_id,
            parameter_overrides=parameter_overrides,
            default_value=default_value,
        )

        dashboard_task_execution_widget.additional_properties = d
        return dashboard_task_execution_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
