from enum import Enum


class CellExecutionStatus(str, Enum):
    COMPLETED = "completed"
    ERROR = "error"
    IDLE = "idle"
    RUNNING = "running"

    def __str__(self) -> str:
        return str(self.value)
