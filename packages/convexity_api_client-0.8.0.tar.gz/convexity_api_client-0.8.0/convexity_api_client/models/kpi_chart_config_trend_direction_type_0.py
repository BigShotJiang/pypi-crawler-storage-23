from enum import Enum


class KpiChartConfigTrendDirectionType0(str, Enum):
    DOWN_GOOD = "down_good"
    UP_GOOD = "up_good"

    def __str__(self) -> str:
        return str(self.value)
