from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.profile import Profile
    from ..models.task_dto import TaskDTO


T = TypeVar("T", bound="Run")


@_attrs_define
class Run:
    """Represents a Run record

    Attributes:
        id (str):
        user_id (str):
        code (str):
        status (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        task_id (None | str | Unset):
        output (None | str | Unset):
        error_message (None | str | Unset):
        progress (float | None | Unset):
        started_at (datetime.datetime | None | Unset):
        completed_at (datetime.datetime | None | Unset):
        cancelled_at (datetime.datetime | None | Unset):
        execution_time_ms (int | None | Unset):
        parameter_input (None | str | Unset):
        workspace_id (None | str | Unset):
        profiles (None | Profile | Unset):
        task (None | TaskDTO | Unset):
    """

    id: str
    user_id: str
    code: str
    status: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    task_id: None | str | Unset = UNSET
    output: None | str | Unset = UNSET
    error_message: None | str | Unset = UNSET
    progress: float | None | Unset = UNSET
    started_at: datetime.datetime | None | Unset = UNSET
    completed_at: datetime.datetime | None | Unset = UNSET
    cancelled_at: datetime.datetime | None | Unset = UNSET
    execution_time_ms: int | None | Unset = UNSET
    parameter_input: None | str | Unset = UNSET
    workspace_id: None | str | Unset = UNSET
    profiles: None | Profile | Unset = UNSET
    task: None | TaskDTO | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.profile import Profile
        from ..models.task_dto import TaskDTO

        id = self.id

        user_id = self.user_id

        code = self.code

        status = self.status

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        task_id: None | str | Unset
        if isinstance(self.task_id, Unset):
            task_id = UNSET
        else:
            task_id = self.task_id

        output: None | str | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        else:
            output = self.output

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        progress: float | None | Unset
        if isinstance(self.progress, Unset):
            progress = UNSET
        else:
            progress = self.progress

        started_at: None | str | Unset
        if isinstance(self.started_at, Unset):
            started_at = UNSET
        elif isinstance(self.started_at, datetime.datetime):
            started_at = self.started_at.isoformat()
        else:
            started_at = self.started_at

        completed_at: None | str | Unset
        if isinstance(self.completed_at, Unset):
            completed_at = UNSET
        elif isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at

        cancelled_at: None | str | Unset
        if isinstance(self.cancelled_at, Unset):
            cancelled_at = UNSET
        elif isinstance(self.cancelled_at, datetime.datetime):
            cancelled_at = self.cancelled_at.isoformat()
        else:
            cancelled_at = self.cancelled_at

        execution_time_ms: int | None | Unset
        if isinstance(self.execution_time_ms, Unset):
            execution_time_ms = UNSET
        else:
            execution_time_ms = self.execution_time_ms

        parameter_input: None | str | Unset
        if isinstance(self.parameter_input, Unset):
            parameter_input = UNSET
        else:
            parameter_input = self.parameter_input

        workspace_id: None | str | Unset
        if isinstance(self.workspace_id, Unset):
            workspace_id = UNSET
        else:
            workspace_id = self.workspace_id

        profiles: dict[str, Any] | None | Unset
        if isinstance(self.profiles, Unset):
            profiles = UNSET
        elif isinstance(self.profiles, Profile):
            profiles = self.profiles.to_dict()
        else:
            profiles = self.profiles

        task: dict[str, Any] | None | Unset
        if isinstance(self.task, Unset):
            task = UNSET
        elif isinstance(self.task, TaskDTO):
            task = self.task.to_dict()
        else:
            task = self.task

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "code": code,
                "status": status,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if task_id is not UNSET:
            field_dict["task_id"] = task_id
        if output is not UNSET:
            field_dict["output"] = output
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if progress is not UNSET:
            field_dict["progress"] = progress
        if started_at is not UNSET:
            field_dict["started_at"] = started_at
        if completed_at is not UNSET:
            field_dict["completed_at"] = completed_at
        if cancelled_at is not UNSET:
            field_dict["cancelled_at"] = cancelled_at
        if execution_time_ms is not UNSET:
            field_dict["execution_time_ms"] = execution_time_ms
        if parameter_input is not UNSET:
            field_dict["parameter_input"] = parameter_input
        if workspace_id is not UNSET:
            field_dict["workspace_id"] = workspace_id
        if profiles is not UNSET:
            field_dict["profiles"] = profiles
        if task is not UNSET:
            field_dict["task"] = task

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.profile import Profile
        from ..models.task_dto import TaskDTO

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        code = d.pop("code")

        status = d.pop("status")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_task_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        task_id = _parse_task_id(d.pop("task_id", UNSET))

        def _parse_output(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        def _parse_progress(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        progress = _parse_progress(d.pop("progress", UNSET))

        def _parse_started_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                started_at_type_0 = isoparse(data)

                return started_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        started_at = _parse_started_at(d.pop("started_at", UNSET))

        def _parse_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = isoparse(data)

                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        completed_at = _parse_completed_at(d.pop("completed_at", UNSET))

        def _parse_cancelled_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                cancelled_at_type_0 = isoparse(data)

                return cancelled_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        cancelled_at = _parse_cancelled_at(d.pop("cancelled_at", UNSET))

        def _parse_execution_time_ms(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        execution_time_ms = _parse_execution_time_ms(d.pop("execution_time_ms", UNSET))

        def _parse_parameter_input(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parameter_input = _parse_parameter_input(d.pop("parameter_input", UNSET))

        def _parse_workspace_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        workspace_id = _parse_workspace_id(d.pop("workspace_id", UNSET))

        def _parse_profiles(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                profiles_type_0 = Profile.from_dict(data)

                return profiles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        profiles = _parse_profiles(d.pop("profiles", UNSET))

        def _parse_task(data: object) -> None | TaskDTO | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                task_type_0 = TaskDTO.from_dict(data)

                return task_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TaskDTO | Unset, data)

        task = _parse_task(d.pop("task", UNSET))

        run = cls(
            id=id,
            user_id=user_id,
            code=code,
            status=status,
            created_at=created_at,
            updated_at=updated_at,
            task_id=task_id,
            output=output,
            error_message=error_message,
            progress=progress,
            started_at=started_at,
            completed_at=completed_at,
            cancelled_at=cancelled_at,
            execution_time_ms=execution_time_ms,
            parameter_input=parameter_input,
            workspace_id=workspace_id,
            profiles=profiles,
            task=task,
        )

        run.additional_properties = d
        return run

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
