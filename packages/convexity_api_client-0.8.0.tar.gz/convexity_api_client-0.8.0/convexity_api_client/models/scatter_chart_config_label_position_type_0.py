from enum import Enum


class ScatterChartConfigLabelPositionType0(str, Enum):
    INSIDE = "inside"
    OUTSIDE = "outside"
    RIGHT = "right"
    TOP = "top"

    def __str__(self) -> str:
        return str(self.value)
