from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.refresh_ended_payload_status import RefreshEndedPayloadStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="RefreshEndedPayload")


@_attrs_define
class RefreshEndedPayload:
    """
    Attributes:
        dataset_id (str):
        task_id (str):
        status (RefreshEndedPayloadStatus):
        error (None | str | Unset):
    """

    dataset_id: str
    task_id: str
    status: RefreshEndedPayloadStatus
    error: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        dataset_id = self.dataset_id

        task_id = self.task_id

        status = self.status.value

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dataset_id": dataset_id,
                "task_id": task_id,
                "status": status,
            }
        )
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        dataset_id = d.pop("dataset_id")

        task_id = d.pop("task_id")

        status = RefreshEndedPayloadStatus(d.pop("status"))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        refresh_ended_payload = cls(
            dataset_id=dataset_id,
            task_id=task_id,
            status=status,
            error=error,
        )

        refresh_ended_payload.additional_properties = d
        return refresh_ended_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
