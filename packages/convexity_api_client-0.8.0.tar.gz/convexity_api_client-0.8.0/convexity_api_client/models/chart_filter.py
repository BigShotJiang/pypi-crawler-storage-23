from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.chart_filter_aggregation_function_type_0 import ChartFilterAggregationFunctionType0
from ..models.chart_filter_applies_to_type_0 import ChartFilterAppliesToType0
from ..models.chart_filter_filtertype import ChartFilterFiltertype
from ..models.chart_filter_logic_operator_type_0 import ChartFilterLogicOperatorType0
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chart_filter_config import ChartFilterConfig
    from ..models.chart_filter_value_type_5 import ChartFilterValueType5


T = TypeVar("T", bound="ChartFilter")


@_attrs_define
class ChartFilter:
    """Filter configuration for chart widgets.

    Chart filters are static (builder-configured) and apply before dashboard filters.

        Attributes:
            id (str): Unique filter identifier
            column_name (str): Column name to filter on
            filter_type (ChartFilterFiltertype): Filter type
            type_ (Literal['chart_filter'] | Unset):  Default: 'chart_filter'.
            value (bool | ChartFilterValueType5 | float | int | list[bool | float | int | str] | None | str | Unset): Filter
                value
            config (ChartFilterConfig | None | Unset): Filter configuration
            applies_to (ChartFilterAppliesToType0 | None | Unset): When to apply this filter Default:
                ChartFilterAppliesToType0.RAW_DATA.
            aggregation_field (None | str | Unset): Which Y field to filter on (for multi-Y charts)
            aggregation_function (ChartFilterAggregationFunctionType0 | None | Unset): Aggregation function (must match
                chart's aggregation)
            label (None | str | Unset): Custom label for the filter
            enabled (bool | None | Unset): Whether the filter is enabled Default: True.
            logic_operator (ChartFilterLogicOperatorType0 | None | Unset): How this filter combines with previous filters
                Default: ChartFilterLogicOperatorType0.AND.
    """

    id: str
    column_name: str
    filter_type: ChartFilterFiltertype
    type_: Literal["chart_filter"] | Unset = "chart_filter"
    value: bool | ChartFilterValueType5 | float | int | list[bool | float | int | str] | None | str | Unset = UNSET
    config: ChartFilterConfig | None | Unset = UNSET
    applies_to: ChartFilterAppliesToType0 | None | Unset = ChartFilterAppliesToType0.RAW_DATA
    aggregation_field: None | str | Unset = UNSET
    aggregation_function: ChartFilterAggregationFunctionType0 | None | Unset = UNSET
    label: None | str | Unset = UNSET
    enabled: bool | None | Unset = True
    logic_operator: ChartFilterLogicOperatorType0 | None | Unset = ChartFilterLogicOperatorType0.AND
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chart_filter_config import ChartFilterConfig
        from ..models.chart_filter_value_type_5 import ChartFilterValueType5

        id = self.id

        column_name = self.column_name

        filter_type = self.filter_type.value

        type_ = self.type_

        value: bool | dict[str, Any] | float | int | list[bool | float | int | str] | None | str | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        elif isinstance(self.value, list):
            value = []
            for value_type_4_item_data in self.value:
                value_type_4_item: bool | float | int | str
                value_type_4_item = value_type_4_item_data
                value.append(value_type_4_item)

        elif isinstance(self.value, ChartFilterValueType5):
            value = self.value.to_dict()
        else:
            value = self.value

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, ChartFilterConfig):
            config = self.config.to_dict()
        else:
            config = self.config

        applies_to: None | str | Unset
        if isinstance(self.applies_to, Unset):
            applies_to = UNSET
        elif isinstance(self.applies_to, ChartFilterAppliesToType0):
            applies_to = self.applies_to.value
        else:
            applies_to = self.applies_to

        aggregation_field: None | str | Unset
        if isinstance(self.aggregation_field, Unset):
            aggregation_field = UNSET
        else:
            aggregation_field = self.aggregation_field

        aggregation_function: None | str | Unset
        if isinstance(self.aggregation_function, Unset):
            aggregation_function = UNSET
        elif isinstance(self.aggregation_function, ChartFilterAggregationFunctionType0):
            aggregation_function = self.aggregation_function.value
        else:
            aggregation_function = self.aggregation_function

        label: None | str | Unset
        if isinstance(self.label, Unset):
            label = UNSET
        else:
            label = self.label

        enabled: bool | None | Unset
        if isinstance(self.enabled, Unset):
            enabled = UNSET
        else:
            enabled = self.enabled

        logic_operator: None | str | Unset
        if isinstance(self.logic_operator, Unset):
            logic_operator = UNSET
        elif isinstance(self.logic_operator, ChartFilterLogicOperatorType0):
            logic_operator = self.logic_operator.value
        else:
            logic_operator = self.logic_operator

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "columnName": column_name,
                "filterType": filter_type,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if value is not UNSET:
            field_dict["value"] = value
        if config is not UNSET:
            field_dict["config"] = config
        if applies_to is not UNSET:
            field_dict["appliesTo"] = applies_to
        if aggregation_field is not UNSET:
            field_dict["aggregationField"] = aggregation_field
        if aggregation_function is not UNSET:
            field_dict["aggregationFunction"] = aggregation_function
        if label is not UNSET:
            field_dict["label"] = label
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if logic_operator is not UNSET:
            field_dict["logicOperator"] = logic_operator

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chart_filter_config import ChartFilterConfig
        from ..models.chart_filter_value_type_5 import ChartFilterValueType5

        d = dict(src_dict)
        id = d.pop("id")

        column_name = d.pop("columnName")

        filter_type = ChartFilterFiltertype(d.pop("filterType"))

        type_ = cast(Literal["chart_filter"] | Unset, d.pop("type", UNSET))
        if type_ != "chart_filter" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'chart_filter', got '{type_}'")

        def _parse_value(
            data: object,
        ) -> bool | ChartFilterValueType5 | float | int | list[bool | float | int | str] | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                value_type_4 = []
                _value_type_4 = data
                for value_type_4_item_data in _value_type_4:

                    def _parse_value_type_4_item(data: object) -> bool | float | int | str:
                        return cast(bool | float | int | str, data)

                    value_type_4_item = _parse_value_type_4_item(value_type_4_item_data)

                    value_type_4.append(value_type_4_item)

                return value_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                value_type_5 = ChartFilterValueType5.from_dict(data)

                return value_type_5
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                bool | ChartFilterValueType5 | float | int | list[bool | float | int | str] | None | str | Unset, data
            )

        value = _parse_value(d.pop("value", UNSET))

        def _parse_config(data: object) -> ChartFilterConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = ChartFilterConfig.from_dict(data)

                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFilterConfig | None | Unset, data)

        config = _parse_config(d.pop("config", UNSET))

        def _parse_applies_to(data: object) -> ChartFilterAppliesToType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                applies_to_type_0 = ChartFilterAppliesToType0(data)

                return applies_to_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFilterAppliesToType0 | None | Unset, data)

        applies_to = _parse_applies_to(d.pop("appliesTo", UNSET))

        def _parse_aggregation_field(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        aggregation_field = _parse_aggregation_field(d.pop("aggregationField", UNSET))

        def _parse_aggregation_function(data: object) -> ChartFilterAggregationFunctionType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                aggregation_function_type_0 = ChartFilterAggregationFunctionType0(data)

                return aggregation_function_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFilterAggregationFunctionType0 | None | Unset, data)

        aggregation_function = _parse_aggregation_function(d.pop("aggregationFunction", UNSET))

        def _parse_label(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        label = _parse_label(d.pop("label", UNSET))

        def _parse_enabled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enabled = _parse_enabled(d.pop("enabled", UNSET))

        def _parse_logic_operator(data: object) -> ChartFilterLogicOperatorType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                logic_operator_type_0 = ChartFilterLogicOperatorType0(data)

                return logic_operator_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFilterLogicOperatorType0 | None | Unset, data)

        logic_operator = _parse_logic_operator(d.pop("logicOperator", UNSET))

        chart_filter = cls(
            id=id,
            column_name=column_name,
            filter_type=filter_type,
            type_=type_,
            value=value,
            config=config,
            applies_to=applies_to,
            aggregation_field=aggregation_field,
            aggregation_function=aggregation_function,
            label=label,
            enabled=enabled,
            logic_operator=logic_operator,
        )

        chart_filter.additional_properties = d
        return chart_filter

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
