from enum import Enum


class ConnectionStatus(str, Enum):
    CONNECTED = "CONNECTED"
    DISCONNECTED = "DISCONNECTED"
    ERROR = "ERROR"
    PENDING = "PENDING"

    def __str__(self) -> str:
        return str(self.value)
