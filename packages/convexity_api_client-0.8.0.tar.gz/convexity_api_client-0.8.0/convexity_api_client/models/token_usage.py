from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.profile import Profile


T = TypeVar("T", bound="TokenUsage")


@_attrs_define
class TokenUsage:
    """Represents a TokenUsage record

    Attributes:
        id (str):
        user_id (str):
        tokens_consumed (int):
        created_at (datetime.datetime):
        model_name (None | str | Unset):
        prompt_tokens (int | None | Unset):
        completion_tokens (int | None | Unset):
        cache_creation_input_tokens (int | None | Unset):
        cache_read_input_tokens (int | None | Unset):
        profiles (None | Profile | Unset):
    """

    id: str
    user_id: str
    tokens_consumed: int
    created_at: datetime.datetime
    model_name: None | str | Unset = UNSET
    prompt_tokens: int | None | Unset = UNSET
    completion_tokens: int | None | Unset = UNSET
    cache_creation_input_tokens: int | None | Unset = UNSET
    cache_read_input_tokens: int | None | Unset = UNSET
    profiles: None | Profile | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.profile import Profile

        id = self.id

        user_id = self.user_id

        tokens_consumed = self.tokens_consumed

        created_at = self.created_at.isoformat()

        model_name: None | str | Unset
        if isinstance(self.model_name, Unset):
            model_name = UNSET
        else:
            model_name = self.model_name

        prompt_tokens: int | None | Unset
        if isinstance(self.prompt_tokens, Unset):
            prompt_tokens = UNSET
        else:
            prompt_tokens = self.prompt_tokens

        completion_tokens: int | None | Unset
        if isinstance(self.completion_tokens, Unset):
            completion_tokens = UNSET
        else:
            completion_tokens = self.completion_tokens

        cache_creation_input_tokens: int | None | Unset
        if isinstance(self.cache_creation_input_tokens, Unset):
            cache_creation_input_tokens = UNSET
        else:
            cache_creation_input_tokens = self.cache_creation_input_tokens

        cache_read_input_tokens: int | None | Unset
        if isinstance(self.cache_read_input_tokens, Unset):
            cache_read_input_tokens = UNSET
        else:
            cache_read_input_tokens = self.cache_read_input_tokens

        profiles: dict[str, Any] | None | Unset
        if isinstance(self.profiles, Unset):
            profiles = UNSET
        elif isinstance(self.profiles, Profile):
            profiles = self.profiles.to_dict()
        else:
            profiles = self.profiles

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "tokens_consumed": tokens_consumed,
                "created_at": created_at,
            }
        )
        if model_name is not UNSET:
            field_dict["model_name"] = model_name
        if prompt_tokens is not UNSET:
            field_dict["prompt_tokens"] = prompt_tokens
        if completion_tokens is not UNSET:
            field_dict["completion_tokens"] = completion_tokens
        if cache_creation_input_tokens is not UNSET:
            field_dict["cache_creation_input_tokens"] = cache_creation_input_tokens
        if cache_read_input_tokens is not UNSET:
            field_dict["cache_read_input_tokens"] = cache_read_input_tokens
        if profiles is not UNSET:
            field_dict["profiles"] = profiles

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.profile import Profile

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        tokens_consumed = d.pop("tokens_consumed")

        created_at = isoparse(d.pop("created_at"))

        def _parse_model_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_name = _parse_model_name(d.pop("model_name", UNSET))

        def _parse_prompt_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        prompt_tokens = _parse_prompt_tokens(d.pop("prompt_tokens", UNSET))

        def _parse_completion_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        completion_tokens = _parse_completion_tokens(d.pop("completion_tokens", UNSET))

        def _parse_cache_creation_input_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cache_creation_input_tokens = _parse_cache_creation_input_tokens(d.pop("cache_creation_input_tokens", UNSET))

        def _parse_cache_read_input_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cache_read_input_tokens = _parse_cache_read_input_tokens(d.pop("cache_read_input_tokens", UNSET))

        def _parse_profiles(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                profiles_type_0 = Profile.from_dict(data)

                return profiles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        profiles = _parse_profiles(d.pop("profiles", UNSET))

        token_usage = cls(
            id=id,
            user_id=user_id,
            tokens_consumed=tokens_consumed,
            created_at=created_at,
            model_name=model_name,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cache_creation_input_tokens=cache_creation_input_tokens,
            cache_read_input_tokens=cache_read_input_tokens,
            profiles=profiles,
        )

        token_usage.additional_properties = d
        return token_usage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
