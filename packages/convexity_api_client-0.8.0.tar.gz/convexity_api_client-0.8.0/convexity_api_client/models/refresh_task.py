from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.refresh_task_status import RefreshTaskStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dataset import Dataset


T = TypeVar("T", bound="RefreshTask")


@_attrs_define
class RefreshTask:
    """Represents a RefreshTask record

    Attributes:
        id (str):
        dataset_id (str):
        user_id (str):
        status (RefreshTaskStatus):
        progress_pct (float):
        rows_processed (int):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        total_rows (int | None | Unset):
        current_phase (None | str | Unset):
        error (None | str | Unset):
        dataset (Dataset | None | Unset):
    """

    id: str
    dataset_id: str
    user_id: str
    status: RefreshTaskStatus
    progress_pct: float
    rows_processed: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    total_rows: int | None | Unset = UNSET
    current_phase: None | str | Unset = UNSET
    error: None | str | Unset = UNSET
    dataset: Dataset | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset import Dataset

        id = self.id

        dataset_id = self.dataset_id

        user_id = self.user_id

        status = self.status.value

        progress_pct = self.progress_pct

        rows_processed = self.rows_processed

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        total_rows: int | None | Unset
        if isinstance(self.total_rows, Unset):
            total_rows = UNSET
        else:
            total_rows = self.total_rows

        current_phase: None | str | Unset
        if isinstance(self.current_phase, Unset):
            current_phase = UNSET
        else:
            current_phase = self.current_phase

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        dataset: dict[str, Any] | None | Unset
        if isinstance(self.dataset, Unset):
            dataset = UNSET
        elif isinstance(self.dataset, Dataset):
            dataset = self.dataset.to_dict()
        else:
            dataset = self.dataset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "dataset_id": dataset_id,
                "user_id": user_id,
                "status": status,
                "progress_pct": progress_pct,
                "rows_processed": rows_processed,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if total_rows is not UNSET:
            field_dict["total_rows"] = total_rows
        if current_phase is not UNSET:
            field_dict["current_phase"] = current_phase
        if error is not UNSET:
            field_dict["error"] = error
        if dataset is not UNSET:
            field_dict["dataset"] = dataset

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset import Dataset

        d = dict(src_dict)
        id = d.pop("id")

        dataset_id = d.pop("dataset_id")

        user_id = d.pop("user_id")

        status = RefreshTaskStatus(d.pop("status"))

        progress_pct = d.pop("progress_pct")

        rows_processed = d.pop("rows_processed")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_total_rows(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_rows = _parse_total_rows(d.pop("total_rows", UNSET))

        def _parse_current_phase(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        current_phase = _parse_current_phase(d.pop("current_phase", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_dataset(data: object) -> Dataset | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                dataset_type_0 = Dataset.from_dict(data)

                return dataset_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Dataset | None | Unset, data)

        dataset = _parse_dataset(d.pop("dataset", UNSET))

        refresh_task = cls(
            id=id,
            dataset_id=dataset_id,
            user_id=user_id,
            status=status,
            progress_pct=progress_pct,
            rows_processed=rows_processed,
            created_at=created_at,
            updated_at=updated_at,
            total_rows=total_rows,
            current_phase=current_phase,
            error=error,
            dataset=dataset,
        )

        refresh_task.additional_properties = d
        return refresh_task

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
