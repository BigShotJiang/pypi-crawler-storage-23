from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dashboard_dataset import DashboardDataset
    from ..models.dashboard_share import DashboardShare
    from ..models.project import Project


T = TypeVar("T", bound="Dashboard")


@_attrs_define
class Dashboard:
    """Represents a Dashboard record

    Attributes:
        id (str):
        user_id (str):
        project_id (str):
        name (str):
        tags (list[str]):
        widgets (str):
        filters (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        layout (None | str | Unset):
        filter_values (None | str | Unset):
        last_refreshed_at (datetime.datetime | None | Unset):
        project (None | Project | Unset):
        dataset_links (list[DashboardDataset] | None | Unset):
        shares (list[DashboardShare] | None | Unset):
    """

    id: str
    user_id: str
    project_id: str
    name: str
    tags: list[str]
    widgets: str
    filters: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    layout: None | str | Unset = UNSET
    filter_values: None | str | Unset = UNSET
    last_refreshed_at: datetime.datetime | None | Unset = UNSET
    project: None | Project | Unset = UNSET
    dataset_links: list[DashboardDataset] | None | Unset = UNSET
    shares: list[DashboardShare] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.project import Project

        id = self.id

        user_id = self.user_id

        project_id = self.project_id

        name = self.name

        tags = self.tags

        widgets = self.widgets

        filters = self.filters

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        layout: None | str | Unset
        if isinstance(self.layout, Unset):
            layout = UNSET
        else:
            layout = self.layout

        filter_values: None | str | Unset
        if isinstance(self.filter_values, Unset):
            filter_values = UNSET
        else:
            filter_values = self.filter_values

        last_refreshed_at: None | str | Unset
        if isinstance(self.last_refreshed_at, Unset):
            last_refreshed_at = UNSET
        elif isinstance(self.last_refreshed_at, datetime.datetime):
            last_refreshed_at = self.last_refreshed_at.isoformat()
        else:
            last_refreshed_at = self.last_refreshed_at

        project: dict[str, Any] | None | Unset
        if isinstance(self.project, Unset):
            project = UNSET
        elif isinstance(self.project, Project):
            project = self.project.to_dict()
        else:
            project = self.project

        dataset_links: list[dict[str, Any]] | None | Unset
        if isinstance(self.dataset_links, Unset):
            dataset_links = UNSET
        elif isinstance(self.dataset_links, list):
            dataset_links = []
            for dataset_links_type_0_item_data in self.dataset_links:
                dataset_links_type_0_item = dataset_links_type_0_item_data.to_dict()
                dataset_links.append(dataset_links_type_0_item)

        else:
            dataset_links = self.dataset_links

        shares: list[dict[str, Any]] | None | Unset
        if isinstance(self.shares, Unset):
            shares = UNSET
        elif isinstance(self.shares, list):
            shares = []
            for shares_type_0_item_data in self.shares:
                shares_type_0_item = shares_type_0_item_data.to_dict()
                shares.append(shares_type_0_item)

        else:
            shares = self.shares

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "project_id": project_id,
                "name": name,
                "tags": tags,
                "widgets": widgets,
                "filters": filters,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if layout is not UNSET:
            field_dict["layout"] = layout
        if filter_values is not UNSET:
            field_dict["filter_values"] = filter_values
        if last_refreshed_at is not UNSET:
            field_dict["last_refreshed_at"] = last_refreshed_at
        if project is not UNSET:
            field_dict["project"] = project
        if dataset_links is not UNSET:
            field_dict["datasetLinks"] = dataset_links
        if shares is not UNSET:
            field_dict["shares"] = shares

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard_dataset import DashboardDataset
        from ..models.dashboard_share import DashboardShare
        from ..models.project import Project

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        project_id = d.pop("project_id")

        name = d.pop("name")

        tags = cast(list[str], d.pop("tags"))

        widgets = d.pop("widgets")

        filters = d.pop("filters")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_layout(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        layout = _parse_layout(d.pop("layout", UNSET))

        def _parse_filter_values(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        filter_values = _parse_filter_values(d.pop("filter_values", UNSET))

        def _parse_last_refreshed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_refreshed_at_type_0 = isoparse(data)

                return last_refreshed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_refreshed_at = _parse_last_refreshed_at(d.pop("last_refreshed_at", UNSET))

        def _parse_project(data: object) -> None | Project | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                project_type_0 = Project.from_dict(data)

                return project_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Project | Unset, data)

        project = _parse_project(d.pop("project", UNSET))

        def _parse_dataset_links(data: object) -> list[DashboardDataset] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_links_type_0 = []
                _dataset_links_type_0 = data
                for dataset_links_type_0_item_data in _dataset_links_type_0:
                    dataset_links_type_0_item = DashboardDataset.from_dict(dataset_links_type_0_item_data)

                    dataset_links_type_0.append(dataset_links_type_0_item)

                return dataset_links_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DashboardDataset] | None | Unset, data)

        dataset_links = _parse_dataset_links(d.pop("datasetLinks", UNSET))

        def _parse_shares(data: object) -> list[DashboardShare] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                shares_type_0 = []
                _shares_type_0 = data
                for shares_type_0_item_data in _shares_type_0:
                    shares_type_0_item = DashboardShare.from_dict(shares_type_0_item_data)

                    shares_type_0.append(shares_type_0_item)

                return shares_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DashboardShare] | None | Unset, data)

        shares = _parse_shares(d.pop("shares", UNSET))

        dashboard = cls(
            id=id,
            user_id=user_id,
            project_id=project_id,
            name=name,
            tags=tags,
            widgets=widgets,
            filters=filters,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            layout=layout,
            filter_values=filter_values,
            last_refreshed_at=last_refreshed_at,
            project=project,
            dataset_links=dataset_links,
            shares=shares,
        )

        dashboard.additional_properties = d
        return dashboard

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
