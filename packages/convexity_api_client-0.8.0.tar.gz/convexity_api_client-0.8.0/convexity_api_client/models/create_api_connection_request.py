from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_api_connection_request_headers_type_0 import CreateApiConnectionRequestHeadersType0


T = TypeVar("T", bound="CreateApiConnectionRequest")


@_attrs_define
class CreateApiConnectionRequest:
    """
    Attributes:
        name (str): Connection name
        project_id (str): Project this connection belongs to
        endpoint (str): API endpoint URL
        type_ (Literal['API'] | Unset):  Default: 'API'.
        description (None | str | Unset): Connection description
        method (str | Unset): HTTP method Default: 'GET'.
        auth_type (str | Unset): Auth type Default: 'none'.
        api_key (None | str | Unset): API key
        api_key_header (None | str | Unset):  Default: 'X-API-Key'.
        bearer_token (None | str | Unset):
        basic_username (None | str | Unset):
        basic_password (None | str | Unset):
        headers (CreateApiConnectionRequestHeadersType0 | None | Unset): Additional headers
    """

    name: str
    project_id: str
    endpoint: str
    type_: Literal["API"] | Unset = "API"
    description: None | str | Unset = UNSET
    method: str | Unset = "GET"
    auth_type: str | Unset = "none"
    api_key: None | str | Unset = UNSET
    api_key_header: None | str | Unset = "X-API-Key"
    bearer_token: None | str | Unset = UNSET
    basic_username: None | str | Unset = UNSET
    basic_password: None | str | Unset = UNSET
    headers: CreateApiConnectionRequestHeadersType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.create_api_connection_request_headers_type_0 import CreateApiConnectionRequestHeadersType0

        name = self.name

        project_id = self.project_id

        endpoint = self.endpoint

        type_ = self.type_

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        method = self.method

        auth_type = self.auth_type

        api_key: None | str | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        else:
            api_key = self.api_key

        api_key_header: None | str | Unset
        if isinstance(self.api_key_header, Unset):
            api_key_header = UNSET
        else:
            api_key_header = self.api_key_header

        bearer_token: None | str | Unset
        if isinstance(self.bearer_token, Unset):
            bearer_token = UNSET
        else:
            bearer_token = self.bearer_token

        basic_username: None | str | Unset
        if isinstance(self.basic_username, Unset):
            basic_username = UNSET
        else:
            basic_username = self.basic_username

        basic_password: None | str | Unset
        if isinstance(self.basic_password, Unset):
            basic_password = UNSET
        else:
            basic_password = self.basic_password

        headers: dict[str, Any] | None | Unset
        if isinstance(self.headers, Unset):
            headers = UNSET
        elif isinstance(self.headers, CreateApiConnectionRequestHeadersType0):
            headers = self.headers.to_dict()
        else:
            headers = self.headers

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "projectId": project_id,
                "endpoint": endpoint,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if description is not UNSET:
            field_dict["description"] = description
        if method is not UNSET:
            field_dict["method"] = method
        if auth_type is not UNSET:
            field_dict["authType"] = auth_type
        if api_key is not UNSET:
            field_dict["apiKey"] = api_key
        if api_key_header is not UNSET:
            field_dict["apiKeyHeader"] = api_key_header
        if bearer_token is not UNSET:
            field_dict["bearerToken"] = bearer_token
        if basic_username is not UNSET:
            field_dict["basicUsername"] = basic_username
        if basic_password is not UNSET:
            field_dict["basicPassword"] = basic_password
        if headers is not UNSET:
            field_dict["headers"] = headers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_api_connection_request_headers_type_0 import CreateApiConnectionRequestHeadersType0

        d = dict(src_dict)
        name = d.pop("name")

        project_id = d.pop("projectId")

        endpoint = d.pop("endpoint")

        type_ = cast(Literal["API"] | Unset, d.pop("type", UNSET))
        if type_ != "API" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'API', got '{type_}'")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        method = d.pop("method", UNSET)

        auth_type = d.pop("authType", UNSET)

        def _parse_api_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key = _parse_api_key(d.pop("apiKey", UNSET))

        def _parse_api_key_header(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key_header = _parse_api_key_header(d.pop("apiKeyHeader", UNSET))

        def _parse_bearer_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        bearer_token = _parse_bearer_token(d.pop("bearerToken", UNSET))

        def _parse_basic_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        basic_username = _parse_basic_username(d.pop("basicUsername", UNSET))

        def _parse_basic_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        basic_password = _parse_basic_password(d.pop("basicPassword", UNSET))

        def _parse_headers(data: object) -> CreateApiConnectionRequestHeadersType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                headers_type_0 = CreateApiConnectionRequestHeadersType0.from_dict(data)

                return headers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateApiConnectionRequestHeadersType0 | None | Unset, data)

        headers = _parse_headers(d.pop("headers", UNSET))

        create_api_connection_request = cls(
            name=name,
            project_id=project_id,
            endpoint=endpoint,
            type_=type_,
            description=description,
            method=method,
            auth_type=auth_type,
            api_key=api_key,
            api_key_header=api_key_header,
            bearer_token=bearer_token,
            basic_username=basic_username,
            basic_password=basic_password,
            headers=headers,
        )

        create_api_connection_request.additional_properties = d
        return create_api_connection_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
