from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="SessionInfo")


@_attrs_define
class SessionInfo:
    """Information about a session.

    Attributes:
        session_id (str):
        model_id (str):
        created_at (str):
        last_accessed (str):
        execution_count (int):
    """

    session_id: str
    model_id: str
    created_at: str
    last_accessed: str
    execution_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        session_id = self.session_id

        model_id = self.model_id

        created_at = self.created_at

        last_accessed = self.last_accessed

        execution_count = self.execution_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "session_id": session_id,
                "model_id": model_id,
                "created_at": created_at,
                "last_accessed": last_accessed,
                "execution_count": execution_count,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        session_id = d.pop("session_id")

        model_id = d.pop("model_id")

        created_at = d.pop("created_at")

        last_accessed = d.pop("last_accessed")

        execution_count = d.pop("execution_count")

        session_info = cls(
            session_id=session_id,
            model_id=model_id,
            created_at=created_at,
            last_accessed=last_accessed,
            execution_count=execution_count,
        )

        session_info.additional_properties = d
        return session_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
