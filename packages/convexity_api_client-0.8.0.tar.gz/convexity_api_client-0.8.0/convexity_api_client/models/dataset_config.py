from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_dataset_config import ApiDatasetConfig
    from ..models.csv_dataset_config import CsvDatasetConfig
    from ..models.derived_dataset_config import DerivedDatasetConfig
    from ..models.json_dataset_config import JsonDatasetConfig
    from ..models.sql_dataset_config import SqlDatasetConfig
    from ..models.static_dataset_config import StaticDatasetConfig


T = TypeVar("T", bound="DatasetConfig")


@_attrs_define
class DatasetConfig:
    """Union of all dataset config types.

    Attributes:
        sql (None | SqlDatasetConfig | Unset): SQL dataset configuration
        json (JsonDatasetConfig | None | Unset): JSON dataset configuration
        csv (CsvDatasetConfig | None | Unset): CSV dataset configuration
        api (ApiDatasetConfig | None | Unset): API dataset configuration
        static (None | StaticDatasetConfig | Unset): Static dataset configuration
        derived (DerivedDatasetConfig | None | Unset): Derived dataset configuration
    """

    sql: None | SqlDatasetConfig | Unset = UNSET
    json: JsonDatasetConfig | None | Unset = UNSET
    csv: CsvDatasetConfig | None | Unset = UNSET
    api: ApiDatasetConfig | None | Unset = UNSET
    static: None | StaticDatasetConfig | Unset = UNSET
    derived: DerivedDatasetConfig | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_dataset_config import ApiDatasetConfig
        from ..models.csv_dataset_config import CsvDatasetConfig
        from ..models.derived_dataset_config import DerivedDatasetConfig
        from ..models.json_dataset_config import JsonDatasetConfig
        from ..models.sql_dataset_config import SqlDatasetConfig
        from ..models.static_dataset_config import StaticDatasetConfig

        sql: dict[str, Any] | None | Unset
        if isinstance(self.sql, Unset):
            sql = UNSET
        elif isinstance(self.sql, SqlDatasetConfig):
            sql = self.sql.to_dict()
        else:
            sql = self.sql

        json: dict[str, Any] | None | Unset
        if isinstance(self.json, Unset):
            json = UNSET
        elif isinstance(self.json, JsonDatasetConfig):
            json = self.json.to_dict()
        else:
            json = self.json

        csv: dict[str, Any] | None | Unset
        if isinstance(self.csv, Unset):
            csv = UNSET
        elif isinstance(self.csv, CsvDatasetConfig):
            csv = self.csv.to_dict()
        else:
            csv = self.csv

        api: dict[str, Any] | None | Unset
        if isinstance(self.api, Unset):
            api = UNSET
        elif isinstance(self.api, ApiDatasetConfig):
            api = self.api.to_dict()
        else:
            api = self.api

        static: dict[str, Any] | None | Unset
        if isinstance(self.static, Unset):
            static = UNSET
        elif isinstance(self.static, StaticDatasetConfig):
            static = self.static.to_dict()
        else:
            static = self.static

        derived: dict[str, Any] | None | Unset
        if isinstance(self.derived, Unset):
            derived = UNSET
        elif isinstance(self.derived, DerivedDatasetConfig):
            derived = self.derived.to_dict()
        else:
            derived = self.derived

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if sql is not UNSET:
            field_dict["sql"] = sql
        if json is not UNSET:
            field_dict["json"] = json
        if csv is not UNSET:
            field_dict["csv"] = csv
        if api is not UNSET:
            field_dict["api"] = api
        if static is not UNSET:
            field_dict["static"] = static
        if derived is not UNSET:
            field_dict["derived"] = derived

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_dataset_config import ApiDatasetConfig
        from ..models.csv_dataset_config import CsvDatasetConfig
        from ..models.derived_dataset_config import DerivedDatasetConfig
        from ..models.json_dataset_config import JsonDatasetConfig
        from ..models.sql_dataset_config import SqlDatasetConfig
        from ..models.static_dataset_config import StaticDatasetConfig

        d = dict(src_dict)

        def _parse_sql(data: object) -> None | SqlDatasetConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                sql_type_0 = SqlDatasetConfig.from_dict(data)

                return sql_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SqlDatasetConfig | Unset, data)

        sql = _parse_sql(d.pop("sql", UNSET))

        def _parse_json(data: object) -> JsonDatasetConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                json_type_0 = JsonDatasetConfig.from_dict(data)

                return json_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(JsonDatasetConfig | None | Unset, data)

        json = _parse_json(d.pop("json", UNSET))

        def _parse_csv(data: object) -> CsvDatasetConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                csv_type_0 = CsvDatasetConfig.from_dict(data)

                return csv_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CsvDatasetConfig | None | Unset, data)

        csv = _parse_csv(d.pop("csv", UNSET))

        def _parse_api(data: object) -> ApiDatasetConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                api_type_0 = ApiDatasetConfig.from_dict(data)

                return api_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiDatasetConfig | None | Unset, data)

        api = _parse_api(d.pop("api", UNSET))

        def _parse_static(data: object) -> None | StaticDatasetConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                static_type_0 = StaticDatasetConfig.from_dict(data)

                return static_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | StaticDatasetConfig | Unset, data)

        static = _parse_static(d.pop("static", UNSET))

        def _parse_derived(data: object) -> DerivedDatasetConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                derived_type_0 = DerivedDatasetConfig.from_dict(data)

                return derived_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DerivedDatasetConfig | None | Unset, data)

        derived = _parse_derived(d.pop("derived", UNSET))

        dataset_config = cls(
            sql=sql,
            json=json,
            csv=csv,
            api=api,
            static=static,
            derived=derived,
        )

        dataset_config.additional_properties = d
        return dataset_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
