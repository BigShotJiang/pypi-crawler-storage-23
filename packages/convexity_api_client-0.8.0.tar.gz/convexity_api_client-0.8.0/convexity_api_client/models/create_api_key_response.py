from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.api_key_permission import ApiKeyPermission
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_key_scope_roles import ApiKeyScopeRoles


T = TypeVar("T", bound="CreateApiKeyResponse")


@_attrs_define
class CreateApiKeyResponse:
    """Response after creating an API key (includes the full key - shown only once).

    Attributes:
        id (str):
        name (str):
        key (str):
        key_prefix (str):
        permission (ApiKeyPermission):
        scopes (ApiKeyScopeRoles): Role buckets for user-scoped API tokens.
        created_at (datetime.datetime):
        api_key (None | str | Unset):
        tenant_id (None | str | Unset):
        expires_at (datetime.datetime | None | Unset):
    """

    id: str
    name: str
    key: str
    key_prefix: str
    permission: ApiKeyPermission
    scopes: ApiKeyScopeRoles
    created_at: datetime.datetime
    api_key: None | str | Unset = UNSET
    tenant_id: None | str | Unset = UNSET
    expires_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        key = self.key

        key_prefix = self.key_prefix

        permission = self.permission.value

        scopes = self.scopes.to_dict()

        created_at = self.created_at.isoformat()

        api_key: None | str | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        else:
            api_key = self.api_key

        tenant_id: None | str | Unset
        if isinstance(self.tenant_id, Unset):
            tenant_id = UNSET
        else:
            tenant_id = self.tenant_id

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "key": key,
                "keyPrefix": key_prefix,
                "permission": permission,
                "scopes": scopes,
                "createdAt": created_at,
            }
        )
        if api_key is not UNSET:
            field_dict["apiKey"] = api_key
        if tenant_id is not UNSET:
            field_dict["tenantId"] = tenant_id
        if expires_at is not UNSET:
            field_dict["expiresAt"] = expires_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_scope_roles import ApiKeyScopeRoles

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        key = d.pop("key")

        key_prefix = d.pop("keyPrefix")

        permission = ApiKeyPermission(d.pop("permission"))

        scopes = ApiKeyScopeRoles.from_dict(d.pop("scopes"))

        created_at = isoparse(d.pop("createdAt"))

        def _parse_api_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key = _parse_api_key(d.pop("apiKey", UNSET))

        def _parse_tenant_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tenant_id = _parse_tenant_id(d.pop("tenantId", UNSET))

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expiresAt", UNSET))

        create_api_key_response = cls(
            id=id,
            name=name,
            key=key,
            key_prefix=key_prefix,
            permission=permission,
            scopes=scopes,
            created_at=created_at,
            api_key=api_key,
            tenant_id=tenant_id,
            expires_at=expires_at,
        )

        create_api_key_response.additional_properties = d
        return create_api_key_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
