from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.profile import Profile


T = TypeVar("T", bound="TokenBalance")


@_attrs_define
class TokenBalance:
    """Represents a TokenBalance record

    Attributes:
        id (str):
        user_id (str):
        balance (int):
        lifetime_tokens (int):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        profiles (None | Profile | Unset):
    """

    id: str
    user_id: str
    balance: int
    lifetime_tokens: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    profiles: None | Profile | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.profile import Profile

        id = self.id

        user_id = self.user_id

        balance = self.balance

        lifetime_tokens = self.lifetime_tokens

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        profiles: dict[str, Any] | None | Unset
        if isinstance(self.profiles, Unset):
            profiles = UNSET
        elif isinstance(self.profiles, Profile):
            profiles = self.profiles.to_dict()
        else:
            profiles = self.profiles

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "balance": balance,
                "lifetime_tokens": lifetime_tokens,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if profiles is not UNSET:
            field_dict["profiles"] = profiles

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.profile import Profile

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        balance = d.pop("balance")

        lifetime_tokens = d.pop("lifetime_tokens")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_profiles(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                profiles_type_0 = Profile.from_dict(data)

                return profiles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        profiles = _parse_profiles(d.pop("profiles", UNSET))

        token_balance = cls(
            id=id,
            user_id=user_id,
            balance=balance,
            lifetime_tokens=lifetime_tokens,
            created_at=created_at,
            updated_at=updated_at,
            profiles=profiles,
        )

        token_balance.additional_properties = d
        return token_balance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
