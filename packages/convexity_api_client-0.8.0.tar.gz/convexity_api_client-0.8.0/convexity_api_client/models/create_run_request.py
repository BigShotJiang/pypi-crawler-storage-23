from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_run_request_parameter_input_type_0 import CreateRunRequestParameterInputType0
    from ..models.create_run_request_parameter_type_0 import CreateRunRequestParameterType0
    from ..models.create_run_task_payload import CreateRunTaskPayload


T = TypeVar("T", bound="CreateRunRequest")


@_attrs_define
class CreateRunRequest:
    """Request model for creating a new run.

    Attributes:
        code (str):
        formulation_id (None | str | Unset):
        forecasting_id (None | str | Unset):
        task (CreateRunTaskPayload | None | Unset):
        parameter (CreateRunRequestParameterType0 | None | Unset):
        parameter_input (CreateRunRequestParameterInputType0 | None | Unset):
    """

    code: str
    formulation_id: None | str | Unset = UNSET
    forecasting_id: None | str | Unset = UNSET
    task: CreateRunTaskPayload | None | Unset = UNSET
    parameter: CreateRunRequestParameterType0 | None | Unset = UNSET
    parameter_input: CreateRunRequestParameterInputType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.create_run_request_parameter_input_type_0 import CreateRunRequestParameterInputType0
        from ..models.create_run_request_parameter_type_0 import CreateRunRequestParameterType0
        from ..models.create_run_task_payload import CreateRunTaskPayload

        code = self.code

        formulation_id: None | str | Unset
        if isinstance(self.formulation_id, Unset):
            formulation_id = UNSET
        else:
            formulation_id = self.formulation_id

        forecasting_id: None | str | Unset
        if isinstance(self.forecasting_id, Unset):
            forecasting_id = UNSET
        else:
            forecasting_id = self.forecasting_id

        task: dict[str, Any] | None | Unset
        if isinstance(self.task, Unset):
            task = UNSET
        elif isinstance(self.task, CreateRunTaskPayload):
            task = self.task.to_dict()
        else:
            task = self.task

        parameter: dict[str, Any] | None | Unset
        if isinstance(self.parameter, Unset):
            parameter = UNSET
        elif isinstance(self.parameter, CreateRunRequestParameterType0):
            parameter = self.parameter.to_dict()
        else:
            parameter = self.parameter

        parameter_input: dict[str, Any] | None | Unset
        if isinstance(self.parameter_input, Unset):
            parameter_input = UNSET
        elif isinstance(self.parameter_input, CreateRunRequestParameterInputType0):
            parameter_input = self.parameter_input.to_dict()
        else:
            parameter_input = self.parameter_input

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "code": code,
            }
        )
        if formulation_id is not UNSET:
            field_dict["formulation_id"] = formulation_id
        if forecasting_id is not UNSET:
            field_dict["forecasting_id"] = forecasting_id
        if task is not UNSET:
            field_dict["task"] = task
        if parameter is not UNSET:
            field_dict["parameter"] = parameter
        if parameter_input is not UNSET:
            field_dict["parameter_input"] = parameter_input

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_run_request_parameter_input_type_0 import CreateRunRequestParameterInputType0
        from ..models.create_run_request_parameter_type_0 import CreateRunRequestParameterType0
        from ..models.create_run_task_payload import CreateRunTaskPayload

        d = dict(src_dict)
        code = d.pop("code")

        def _parse_formulation_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        formulation_id = _parse_formulation_id(d.pop("formulation_id", UNSET))

        def _parse_forecasting_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        forecasting_id = _parse_forecasting_id(d.pop("forecasting_id", UNSET))

        def _parse_task(data: object) -> CreateRunTaskPayload | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                task_type_0 = CreateRunTaskPayload.from_dict(data)

                return task_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateRunTaskPayload | None | Unset, data)

        task = _parse_task(d.pop("task", UNSET))

        def _parse_parameter(data: object) -> CreateRunRequestParameterType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameter_type_0 = CreateRunRequestParameterType0.from_dict(data)

                return parameter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateRunRequestParameterType0 | None | Unset, data)

        parameter = _parse_parameter(d.pop("parameter", UNSET))

        def _parse_parameter_input(data: object) -> CreateRunRequestParameterInputType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameter_input_type_0 = CreateRunRequestParameterInputType0.from_dict(data)

                return parameter_input_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateRunRequestParameterInputType0 | None | Unset, data)

        parameter_input = _parse_parameter_input(d.pop("parameter_input", UNSET))

        create_run_request = cls(
            code=code,
            formulation_id=formulation_id,
            forecasting_id=forecasting_id,
            task=task,
            parameter=parameter,
            parameter_input=parameter_input,
        )

        create_run_request.additional_properties = d
        return create_run_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
