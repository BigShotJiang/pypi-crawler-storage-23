from enum import Enum


class ChartFilterFiltertype(str, Enum):
    DATE = "date"
    DATE_RANGE = "date_range"
    MULTI_SELECT = "multi_select"
    NUMBER = "number"
    NUMBER_RANGE = "number_range"
    SELECT = "select"
    TEXT = "text"

    def __str__(self) -> str:
        return str(self.value)
