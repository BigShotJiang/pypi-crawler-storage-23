from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.organization_role import OrganizationRole
from ..types import UNSET, Unset

T = TypeVar("T", bound="OrganizationMemberResponse")


@_attrs_define
class OrganizationMemberResponse:
    """Response model for an organization member.

    Attributes:
        id (str):
        user_id (str):
        role (OrganizationRole):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        user_name (None | str | Unset):
        user_email (None | str | Unset):
        user_profile_picture (None | str | Unset):
    """

    id: str
    user_id: str
    role: OrganizationRole
    created_at: datetime.datetime
    updated_at: datetime.datetime
    user_name: None | str | Unset = UNSET
    user_email: None | str | Unset = UNSET
    user_profile_picture: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        user_id = self.user_id

        role = self.role.value

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        user_name: None | str | Unset
        if isinstance(self.user_name, Unset):
            user_name = UNSET
        else:
            user_name = self.user_name

        user_email: None | str | Unset
        if isinstance(self.user_email, Unset):
            user_email = UNSET
        else:
            user_email = self.user_email

        user_profile_picture: None | str | Unset
        if isinstance(self.user_profile_picture, Unset):
            user_profile_picture = UNSET
        else:
            user_profile_picture = self.user_profile_picture

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "userId": user_id,
                "role": role,
                "createdAt": created_at,
                "updatedAt": updated_at,
            }
        )
        if user_name is not UNSET:
            field_dict["userName"] = user_name
        if user_email is not UNSET:
            field_dict["userEmail"] = user_email
        if user_profile_picture is not UNSET:
            field_dict["userProfilePicture"] = user_profile_picture

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("userId")

        role = OrganizationRole(d.pop("role"))

        created_at = isoparse(d.pop("createdAt"))

        updated_at = isoparse(d.pop("updatedAt"))

        def _parse_user_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_name = _parse_user_name(d.pop("userName", UNSET))

        def _parse_user_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_email = _parse_user_email(d.pop("userEmail", UNSET))

        def _parse_user_profile_picture(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_profile_picture = _parse_user_profile_picture(d.pop("userProfilePicture", UNSET))

        organization_member_response = cls(
            id=id,
            user_id=user_id,
            role=role,
            created_at=created_at,
            updated_at=updated_at,
            user_name=user_name,
            user_email=user_email,
            user_profile_picture=user_profile_picture,
        )

        organization_member_response.additional_properties = d
        return organization_member_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
