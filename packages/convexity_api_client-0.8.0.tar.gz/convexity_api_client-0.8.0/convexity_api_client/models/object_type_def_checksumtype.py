from enum import Enum


class ObjectTypeDefChecksumtype(str, Enum):
    COMPOSITE = "COMPOSITE"
    FULL_OBJECT = "FULL_OBJECT"

    def __str__(self) -> str:
        return str(self.value)
