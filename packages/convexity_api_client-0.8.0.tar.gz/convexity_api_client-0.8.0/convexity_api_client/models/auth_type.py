from enum import Enum


class AuthType(str, Enum):
    API_KEY = "api-key"
    BASIC = "basic"
    BEARER = "bearer"
    NONE = "none"

    def __str__(self) -> str:
        return str(self.value)
