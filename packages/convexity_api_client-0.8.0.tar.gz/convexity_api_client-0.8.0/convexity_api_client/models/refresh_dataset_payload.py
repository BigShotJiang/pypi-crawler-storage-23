from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.refresh_dataset_payload_parameters_type_0 import RefreshDatasetPayloadParametersType0


T = TypeVar("T", bound="RefreshDatasetPayload")


@_attrs_define
class RefreshDatasetPayload:
    """Payload for a dataset refresh task.

    Extracts data from the dataset's connection and writes it into the
    DuckLake table, using either overwrite or upsert mode depending on
    whether primary_keys are configured.

        Attributes:
            dataset_id (str): ID of the dataset to refresh
            project_id (str): Project the dataset belongs to
            user_id (str): User who initiated the refresh
            type_ (Literal['refresh_dataset'] | Unset):  Default: 'refresh_dataset'.
            parameters (None | RefreshDatasetPayloadParametersType0 | Unset): Optional query parameters for parameterized
                datasets
            dataset_name (None | str | Unset): Display name of the dataset being refreshed
            row_count (int | None | Unset): Number of rows written during refresh
            progress_message (None | str | Unset): Human-readable progress message
    """

    dataset_id: str
    project_id: str
    user_id: str
    type_: Literal["refresh_dataset"] | Unset = "refresh_dataset"
    parameters: None | RefreshDatasetPayloadParametersType0 | Unset = UNSET
    dataset_name: None | str | Unset = UNSET
    row_count: int | None | Unset = UNSET
    progress_message: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.refresh_dataset_payload_parameters_type_0 import RefreshDatasetPayloadParametersType0

        dataset_id = self.dataset_id

        project_id = self.project_id

        user_id = self.user_id

        type_ = self.type_

        parameters: dict[str, Any] | None | Unset
        if isinstance(self.parameters, Unset):
            parameters = UNSET
        elif isinstance(self.parameters, RefreshDatasetPayloadParametersType0):
            parameters = self.parameters.to_dict()
        else:
            parameters = self.parameters

        dataset_name: None | str | Unset
        if isinstance(self.dataset_name, Unset):
            dataset_name = UNSET
        else:
            dataset_name = self.dataset_name

        row_count: int | None | Unset
        if isinstance(self.row_count, Unset):
            row_count = UNSET
        else:
            row_count = self.row_count

        progress_message: None | str | Unset
        if isinstance(self.progress_message, Unset):
            progress_message = UNSET
        else:
            progress_message = self.progress_message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "datasetId": dataset_id,
                "projectId": project_id,
                "userId": user_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if parameters is not UNSET:
            field_dict["parameters"] = parameters
        if dataset_name is not UNSET:
            field_dict["datasetName"] = dataset_name
        if row_count is not UNSET:
            field_dict["rowCount"] = row_count
        if progress_message is not UNSET:
            field_dict["progressMessage"] = progress_message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.refresh_dataset_payload_parameters_type_0 import RefreshDatasetPayloadParametersType0

        d = dict(src_dict)
        dataset_id = d.pop("datasetId")

        project_id = d.pop("projectId")

        user_id = d.pop("userId")

        type_ = cast(Literal["refresh_dataset"] | Unset, d.pop("type", UNSET))
        if type_ != "refresh_dataset" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'refresh_dataset', got '{type_}'")

        def _parse_parameters(data: object) -> None | RefreshDatasetPayloadParametersType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameters_type_0 = RefreshDatasetPayloadParametersType0.from_dict(data)

                return parameters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RefreshDatasetPayloadParametersType0 | Unset, data)

        parameters = _parse_parameters(d.pop("parameters", UNSET))

        def _parse_dataset_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset_name = _parse_dataset_name(d.pop("datasetName", UNSET))

        def _parse_row_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        row_count = _parse_row_count(d.pop("rowCount", UNSET))

        def _parse_progress_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        progress_message = _parse_progress_message(d.pop("progressMessage", UNSET))

        refresh_dataset_payload = cls(
            dataset_id=dataset_id,
            project_id=project_id,
            user_id=user_id,
            type_=type_,
            parameters=parameters,
            dataset_name=dataset_name,
            row_count=row_count,
            progress_message=progress_message,
        )

        refresh_dataset_payload.additional_properties = d
        return refresh_dataset_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
