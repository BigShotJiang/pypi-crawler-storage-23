from enum import Enum


class TaskExecutionParameterOverrideInputtype(str, Enum):
    BOOLEAN = "boolean"
    DATE = "date"
    MULTISELECT = "multiselect"
    NUMBER = "number"
    SELECT = "select"
    TEXT = "text"

    def __str__(self) -> str:
        return str(self.value)
