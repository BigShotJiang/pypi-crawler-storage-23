from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.api_key_permission import ApiKeyPermission
from ..types import UNSET, Unset

T = TypeVar("T", bound="ApiKeyScopeRoles")


@_attrs_define
class ApiKeyScopeRoles:
    """Role buckets for user-scoped API tokens.

    Attributes:
        org (ApiKeyPermission | Unset):
        project (ApiKeyPermission | Unset):
    """

    org: ApiKeyPermission | Unset = UNSET
    project: ApiKeyPermission | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        org: str | Unset = UNSET
        if not isinstance(self.org, Unset):
            org = self.org.value

        project: str | Unset = UNSET
        if not isinstance(self.project, Unset):
            project = self.project.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if org is not UNSET:
            field_dict["org"] = org
        if project is not UNSET:
            field_dict["project"] = project

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _org = d.pop("org", UNSET)
        org: ApiKeyPermission | Unset
        if isinstance(_org, Unset):
            org = UNSET
        else:
            org = ApiKeyPermission(_org)

        _project = d.pop("project", UNSET)
        project: ApiKeyPermission | Unset
        if isinstance(_project, Unset):
            project = UNSET
        else:
            project = ApiKeyPermission(_project)

        api_key_scope_roles = cls(
            org=org,
            project=project,
        )

        api_key_scope_roles.additional_properties = d
        return api_key_scope_roles

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
