from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.filter_option import FilterOption


T = TypeVar("T", bound="DashboardMultiSelectFilterWidget")


@_attrs_define
class DashboardMultiSelectFilterWidget:
    """Multi-select filter widget with checkboxes.

    Attributes:
        id (str): Unique widget identifier
        column_name (str): Name of the column in dataset rows to filter on
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['multi_filter'] | Unset):  Default: 'multi_filter'.
        is_filter (bool | Unset): Indicates this is a filter widget Default: True.
        dataset_ids (list[str] | None | Unset): Dataset IDs this filter applies to (default: all datasets)
        required (bool | Unset): Whether a value is required Default: False.
        options (list[FilterOption] | None | Unset): Static options for the dropdown
        options_dataset_id (None | str | Unset): Dataset to load dynamic options from
        options_label_column (None | str | Unset): Column to use as option label
        options_value_column (None | str | Unset): Column to use as option value
        default_value (list[bool | float | int | None | str] | None | Unset): Default selected values
    """

    id: str
    column_name: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["multi_filter"] | Unset = "multi_filter"
    is_filter: bool | Unset = True
    dataset_ids: list[str] | None | Unset = UNSET
    required: bool | Unset = False
    options: list[FilterOption] | None | Unset = UNSET
    options_dataset_id: None | str | Unset = UNSET
    options_label_column: None | str | Unset = UNSET
    options_value_column: None | str | Unset = UNSET
    default_value: list[bool | float | int | None | str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        column_name = self.column_name

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        is_filter = self.is_filter

        dataset_ids: list[str] | None | Unset
        if isinstance(self.dataset_ids, Unset):
            dataset_ids = UNSET
        elif isinstance(self.dataset_ids, list):
            dataset_ids = self.dataset_ids

        else:
            dataset_ids = self.dataset_ids

        required = self.required

        options: list[dict[str, Any]] | None | Unset
        if isinstance(self.options, Unset):
            options = UNSET
        elif isinstance(self.options, list):
            options = []
            for options_type_0_item_data in self.options:
                options_type_0_item = options_type_0_item_data.to_dict()
                options.append(options_type_0_item)

        else:
            options = self.options

        options_dataset_id: None | str | Unset
        if isinstance(self.options_dataset_id, Unset):
            options_dataset_id = UNSET
        else:
            options_dataset_id = self.options_dataset_id

        options_label_column: None | str | Unset
        if isinstance(self.options_label_column, Unset):
            options_label_column = UNSET
        else:
            options_label_column = self.options_label_column

        options_value_column: None | str | Unset
        if isinstance(self.options_value_column, Unset):
            options_value_column = UNSET
        else:
            options_value_column = self.options_value_column

        default_value: list[bool | float | int | None | str] | None | Unset
        if isinstance(self.default_value, Unset):
            default_value = UNSET
        elif isinstance(self.default_value, list):
            default_value = []
            for default_value_type_0_item_data in self.default_value:
                default_value_type_0_item: bool | float | int | None | str
                default_value_type_0_item = default_value_type_0_item_data
                default_value.append(default_value_type_0_item)

        else:
            default_value = self.default_value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "columnName": column_name,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if is_filter is not UNSET:
            field_dict["isFilter"] = is_filter
        if dataset_ids is not UNSET:
            field_dict["datasetIds"] = dataset_ids
        if required is not UNSET:
            field_dict["required"] = required
        if options is not UNSET:
            field_dict["options"] = options
        if options_dataset_id is not UNSET:
            field_dict["optionsDatasetId"] = options_dataset_id
        if options_label_column is not UNSET:
            field_dict["optionsLabelColumn"] = options_label_column
        if options_value_column is not UNSET:
            field_dict["optionsValueColumn"] = options_value_column
        if default_value is not UNSET:
            field_dict["defaultValue"] = default_value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.filter_option import FilterOption

        d = dict(src_dict)
        id = d.pop("id")

        column_name = d.pop("columnName")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["multi_filter"] | Unset, d.pop("type", UNSET))
        if type_ != "multi_filter" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'multi_filter', got '{type_}'")

        is_filter = d.pop("isFilter", UNSET)

        def _parse_dataset_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_ids_type_0 = cast(list[str], data)

                return dataset_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        dataset_ids = _parse_dataset_ids(d.pop("datasetIds", UNSET))

        required = d.pop("required", UNSET)

        def _parse_options(data: object) -> list[FilterOption] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                options_type_0 = []
                _options_type_0 = data
                for options_type_0_item_data in _options_type_0:
                    options_type_0_item = FilterOption.from_dict(options_type_0_item_data)

                    options_type_0.append(options_type_0_item)

                return options_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[FilterOption] | None | Unset, data)

        options = _parse_options(d.pop("options", UNSET))

        def _parse_options_dataset_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        options_dataset_id = _parse_options_dataset_id(d.pop("optionsDatasetId", UNSET))

        def _parse_options_label_column(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        options_label_column = _parse_options_label_column(d.pop("optionsLabelColumn", UNSET))

        def _parse_options_value_column(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        options_value_column = _parse_options_value_column(d.pop("optionsValueColumn", UNSET))

        def _parse_default_value(data: object) -> list[bool | float | int | None | str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                default_value_type_0 = []
                _default_value_type_0 = data
                for default_value_type_0_item_data in _default_value_type_0:

                    def _parse_default_value_type_0_item(data: object) -> bool | float | int | None | str:
                        if data is None:
                            return data
                        return cast(bool | float | int | None | str, data)

                    default_value_type_0_item = _parse_default_value_type_0_item(default_value_type_0_item_data)

                    default_value_type_0.append(default_value_type_0_item)

                return default_value_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[bool | float | int | None | str] | None | Unset, data)

        default_value = _parse_default_value(d.pop("defaultValue", UNSET))

        dashboard_multi_select_filter_widget = cls(
            id=id,
            column_name=column_name,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            is_filter=is_filter,
            dataset_ids=dataset_ids,
            required=required,
            options=options,
            options_dataset_id=options_dataset_id,
            options_label_column=options_label_column,
            options_value_column=options_value_column,
            default_value=default_value,
        )

        dashboard_multi_select_filter_widget.additional_properties = d
        return dashboard_multi_select_filter_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
