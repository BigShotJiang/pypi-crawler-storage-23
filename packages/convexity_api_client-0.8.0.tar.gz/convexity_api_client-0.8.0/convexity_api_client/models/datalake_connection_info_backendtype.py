from enum import Enum


class DatalakeConnectionInfoBackendtype(str, Enum):
    DELTALAKE = "deltalake"
    DUCKLAKE = "ducklake"
    PARQUET = "parquet"

    def __str__(self) -> str:
        return str(self.value)
