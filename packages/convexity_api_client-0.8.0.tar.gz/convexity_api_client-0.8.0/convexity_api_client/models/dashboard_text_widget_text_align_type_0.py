from enum import Enum


class DashboardTextWidgetTextAlignType0(str, Enum):
    CENTER = "center"
    LEFT = "left"
    RIGHT = "right"

    def __str__(self) -> str:
        return str(self.value)
