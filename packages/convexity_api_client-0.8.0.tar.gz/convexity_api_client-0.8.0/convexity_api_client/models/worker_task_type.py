from enum import Enum


class WorkerTaskType(str, Enum):
    DELETE_DATASET = "delete_dataset"
    EXECUTE_RUN = "execute_run"
    REFRESH_DATASET = "refresh_dataset"
    SYNC_CATALOG_TO_S3 = "sync_catalog_to_s3"
    VACUUM_DUCKLAKE = "vacuum_ducklake"

    def __str__(self) -> str:
        return str(self.value)
