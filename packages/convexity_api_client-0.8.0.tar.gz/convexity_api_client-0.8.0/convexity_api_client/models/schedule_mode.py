from enum import Enum


class ScheduleMode(str, Enum):
    MANUAL = "MANUAL"
    SCHEDULED = "SCHEDULED"

    def __str__(self) -> str:
        return str(self.value)
