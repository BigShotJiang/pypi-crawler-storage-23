from enum import Enum


class ScatterChartConfigLegendPositionType0(str, Enum):
    BOTTOM = "bottom"
    LEFT = "left"
    RIGHT = "right"
    TOP = "top"

    def __str__(self) -> str:
        return str(self.value)
