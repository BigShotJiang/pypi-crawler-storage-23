from enum import Enum


class DatasetParameterType(str, Enum):
    DATE = "date"
    LIST = "list"
    NUMBER = "number"
    STRING = "string"

    def __str__(self) -> str:
        return str(self.value)
