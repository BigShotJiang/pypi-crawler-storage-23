from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.api_connection import ApiConnection
    from ..models.database_connection import DatabaseConnection
    from ..models.databricks_connection import DatabricksConnection
    from ..models.file_connection import FileConnection
    from ..models.s3_connection import S3Connection
    from ..models.webhook_connection import WebhookConnection


T = TypeVar("T", bound="ConnectionListResponse")


@_attrs_define
class ConnectionListResponse:
    """
    Attributes:
        connections (list[ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection |
            WebhookConnection]):
    """

    connections: list[
        ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection
    ]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_connection import ApiConnection
        from ..models.database_connection import DatabaseConnection
        from ..models.file_connection import FileConnection
        from ..models.s3_connection import S3Connection
        from ..models.webhook_connection import WebhookConnection

        connections = []
        for connections_item_data in self.connections:
            connections_item: dict[str, Any]
            if isinstance(connections_item_data, DatabaseConnection):
                connections_item = connections_item_data.to_dict()
            elif isinstance(connections_item_data, S3Connection):
                connections_item = connections_item_data.to_dict()
            elif isinstance(connections_item_data, ApiConnection):
                connections_item = connections_item_data.to_dict()
            elif isinstance(connections_item_data, WebhookConnection):
                connections_item = connections_item_data.to_dict()
            elif isinstance(connections_item_data, FileConnection):
                connections_item = connections_item_data.to_dict()
            else:
                connections_item = connections_item_data.to_dict()

            connections.append(connections_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "connections": connections,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_connection import ApiConnection
        from ..models.database_connection import DatabaseConnection
        from ..models.databricks_connection import DatabricksConnection
        from ..models.file_connection import FileConnection
        from ..models.s3_connection import S3Connection
        from ..models.webhook_connection import WebhookConnection

        d = dict(src_dict)
        connections = []
        _connections = d.pop("connections")
        for connections_item_data in _connections:

            def _parse_connections_item(
                data: object,
            ) -> (
                ApiConnection
                | DatabaseConnection
                | DatabricksConnection
                | FileConnection
                | S3Connection
                | WebhookConnection
            ):
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    connections_item_type_0 = DatabaseConnection.from_dict(data)

                    return connections_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    connections_item_type_1 = S3Connection.from_dict(data)

                    return connections_item_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    connections_item_type_2 = ApiConnection.from_dict(data)

                    return connections_item_type_2
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    connections_item_type_3 = WebhookConnection.from_dict(data)

                    return connections_item_type_3
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    connections_item_type_4 = FileConnection.from_dict(data)

                    return connections_item_type_4
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                connections_item_type_5 = DatabricksConnection.from_dict(data)

                return connections_item_type_5

            connections_item = _parse_connections_item(connections_item_data)

            connections.append(connections_item)

        connection_list_response = cls(
            connections=connections,
        )

        connection_list_response.additional_properties = d
        return connection_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
