from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.execute_run_payload_extra_env_type_0 import ExecuteRunPayloadExtraEnvType0


T = TypeVar("T", bound="ExecuteRunPayload")


@_attrs_define
class ExecuteRunPayload:
    """Payload for executing a task run.

    Executes the code associated with a run in a background worker process,
    supporting long-running and CPU-intensive operations.

        Attributes:
            run_id (str): ID of the run to execute
            user_id (str): User who initiated the run
            type_ (Literal['execute_run'] | Unset):  Default: 'execute_run'.
            extra_env (ExecuteRunPayloadExtraEnvType0 | None | Unset): Additional environment variables for run execution
    """

    run_id: str
    user_id: str
    type_: Literal["execute_run"] | Unset = "execute_run"
    extra_env: ExecuteRunPayloadExtraEnvType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.execute_run_payload_extra_env_type_0 import ExecuteRunPayloadExtraEnvType0

        run_id = self.run_id

        user_id = self.user_id

        type_ = self.type_

        extra_env: dict[str, Any] | None | Unset
        if isinstance(self.extra_env, Unset):
            extra_env = UNSET
        elif isinstance(self.extra_env, ExecuteRunPayloadExtraEnvType0):
            extra_env = self.extra_env.to_dict()
        else:
            extra_env = self.extra_env

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "runId": run_id,
                "userId": user_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if extra_env is not UNSET:
            field_dict["extraEnv"] = extra_env

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.execute_run_payload_extra_env_type_0 import ExecuteRunPayloadExtraEnvType0

        d = dict(src_dict)
        run_id = d.pop("runId")

        user_id = d.pop("userId")

        type_ = cast(Literal["execute_run"] | Unset, d.pop("type", UNSET))
        if type_ != "execute_run" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'execute_run', got '{type_}'")

        def _parse_extra_env(data: object) -> ExecuteRunPayloadExtraEnvType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                extra_env_type_0 = ExecuteRunPayloadExtraEnvType0.from_dict(data)

                return extra_env_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ExecuteRunPayloadExtraEnvType0 | None | Unset, data)

        extra_env = _parse_extra_env(d.pop("extraEnv", UNSET))

        execute_run_payload = cls(
            run_id=run_id,
            user_id=user_id,
            type_=type_,
            extra_env=extra_env,
        )

        execute_run_payload.additional_properties = d
        return execute_run_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
