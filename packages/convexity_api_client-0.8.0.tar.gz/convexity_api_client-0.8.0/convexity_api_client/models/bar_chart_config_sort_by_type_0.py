from enum import Enum


class BarChartConfigSortByType0(str, Enum):
    CATEGORY_ASC = "category_asc"
    CATEGORY_DESC = "category_desc"
    VALUE_ASC = "value_asc"
    VALUE_DESC = "value_desc"

    def __str__(self) -> str:
        return str(self.value)
