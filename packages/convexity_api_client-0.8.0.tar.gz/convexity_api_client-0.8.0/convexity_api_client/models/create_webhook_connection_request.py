from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateWebhookConnectionRequest")


@_attrs_define
class CreateWebhookConnectionRequest:
    """
    Attributes:
        name (str): Connection name
        project_id (str): Project this connection belongs to
        endpoint (str): Webhook endpoint URL
        type_ (Literal['WEBHOOK'] | Unset):  Default: 'WEBHOOK'.
        description (None | str | Unset): Connection description
        secret (None | str | Unset): Webhook secret
        secret_header (None | str | Unset):  Default: 'X-Webhook-Secret'.
    """

    name: str
    project_id: str
    endpoint: str
    type_: Literal["WEBHOOK"] | Unset = "WEBHOOK"
    description: None | str | Unset = UNSET
    secret: None | str | Unset = UNSET
    secret_header: None | str | Unset = "X-Webhook-Secret"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        project_id = self.project_id

        endpoint = self.endpoint

        type_ = self.type_

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        secret: None | str | Unset
        if isinstance(self.secret, Unset):
            secret = UNSET
        else:
            secret = self.secret

        secret_header: None | str | Unset
        if isinstance(self.secret_header, Unset):
            secret_header = UNSET
        else:
            secret_header = self.secret_header

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "projectId": project_id,
                "endpoint": endpoint,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if description is not UNSET:
            field_dict["description"] = description
        if secret is not UNSET:
            field_dict["secret"] = secret
        if secret_header is not UNSET:
            field_dict["secretHeader"] = secret_header

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        project_id = d.pop("projectId")

        endpoint = d.pop("endpoint")

        type_ = cast(Literal["WEBHOOK"] | Unset, d.pop("type", UNSET))
        if type_ != "WEBHOOK" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'WEBHOOK', got '{type_}'")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_secret(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        secret = _parse_secret(d.pop("secret", UNSET))

        def _parse_secret_header(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        secret_header = _parse_secret_header(d.pop("secretHeader", UNSET))

        create_webhook_connection_request = cls(
            name=name,
            project_id=project_id,
            endpoint=endpoint,
            type_=type_,
            description=description,
            secret=secret,
            secret_header=secret_header,
        )

        create_webhook_connection_request.additional_properties = d
        return create_webhook_connection_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
