from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.organization_role import OrganizationRole
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.organization import Organization
    from ..models.profile import Profile


T = TypeVar("T", bound="OrganizationMember")


@_attrs_define
class OrganizationMember:
    """Represents a OrganizationMember record

    Attributes:
        id (str):
        organization_id (str):
        user_id (str):
        role (OrganizationRole):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        organization (None | Organization | Unset):
        profile (None | Profile | Unset):
    """

    id: str
    organization_id: str
    user_id: str
    role: OrganizationRole
    created_at: datetime.datetime
    updated_at: datetime.datetime
    organization: None | Organization | Unset = UNSET
    profile: None | Profile | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.organization import Organization
        from ..models.profile import Profile

        id = self.id

        organization_id = self.organization_id

        user_id = self.user_id

        role = self.role.value

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        organization: dict[str, Any] | None | Unset
        if isinstance(self.organization, Unset):
            organization = UNSET
        elif isinstance(self.organization, Organization):
            organization = self.organization.to_dict()
        else:
            organization = self.organization

        profile: dict[str, Any] | None | Unset
        if isinstance(self.profile, Unset):
            profile = UNSET
        elif isinstance(self.profile, Profile):
            profile = self.profile.to_dict()
        else:
            profile = self.profile

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "organization_id": organization_id,
                "user_id": user_id,
                "role": role,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if organization is not UNSET:
            field_dict["organization"] = organization
        if profile is not UNSET:
            field_dict["profile"] = profile

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.organization import Organization
        from ..models.profile import Profile

        d = dict(src_dict)
        id = d.pop("id")

        organization_id = d.pop("organization_id")

        user_id = d.pop("user_id")

        role = OrganizationRole(d.pop("role"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_organization(data: object) -> None | Organization | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                organization_type_0 = Organization.from_dict(data)

                return organization_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Organization | Unset, data)

        organization = _parse_organization(d.pop("organization", UNSET))

        def _parse_profile(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                profile_type_0 = Profile.from_dict(data)

                return profile_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        profile = _parse_profile(d.pop("profile", UNSET))

        organization_member = cls(
            id=id,
            organization_id=organization_id,
            user_id=user_id,
            role=role,
            created_at=created_at,
            updated_at=updated_at,
            organization=organization,
            profile=profile,
        )

        organization_member.additional_properties = d
        return organization_member

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
