#pragma once
#include "Options.h"
#include "VBMManager.h"

void initFromCommandLine(Options *opts, VBMManager *manager);
