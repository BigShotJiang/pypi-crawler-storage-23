from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

from .pool import PoolEngine


class ProcessEngine(PoolEngine):
    """
    The processes engine for foxes calculations.

    :group: engines

    """

    def _create_pool(self):
        """Creates the pool"""
        self._pool = ProcessPoolExecutor(max_workers=self.n_workers, **self.pool_args)

    def submit(self, f, *args, **kwargs):
        """
        Submits a job to worker, obtaining a future

        Parameters
        ----------
        f: Callable
            The function f(*args, **kwargs) to be
            submitted
        args: tuple, optional
            Arguments for the function
        kwargs: dict, optional
            Arguments for the function

        Returns
        -------
        future: object
            The future object

        """
        return self._pool.submit(f, *args, **kwargs)

    def future_is_done(self, future):
        """
        Checks if a future is done

        Parameters
        ----------
        future: object
            The future

        Returns
        -------
        is_done: bool
            True if the future is done

        """
        return future.done()

    def await_result(self, future):
        """
        Waits for result from a future

        Parameters
        ----------
        future: object
            The future

        Returns
        -------
        result: object
            The calculation result

        """
        return future.result()

    def _shutdown_pool(self):
        """Shuts down the pool"""
        self._pool.shutdown()


class ThreadsEngine(ProcessEngine):
    """
    The threads engine for foxes calculations.

    :group: engines

    """

    def __init__(self, *args, **kwargs):
        """
        Constructor
        """
        super().__init__(*args, share_cstore=True, **kwargs)

    def _create_pool(self):
        """Creates the pool"""
        self._pool = ThreadPoolExecutor(max_workers=self.n_workers, **self.pool_args)
