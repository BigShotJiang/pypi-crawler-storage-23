from .conf import Config as Config
from .conf import config as config
from .conf import get_path as get_path
from .conf import get_input_path as get_input_path
from .conf import get_output_path as get_output_path
