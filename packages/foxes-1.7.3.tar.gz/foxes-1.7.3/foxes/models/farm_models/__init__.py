"""
Farm models.
"""

from .turbine2farm import Turbine2FarmModel as Turbine2FarmModel
