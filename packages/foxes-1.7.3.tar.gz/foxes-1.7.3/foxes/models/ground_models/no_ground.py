from foxes.core import GroundModel


class NoGround(GroundModel):
    """
    No ground effects

    :group: models.ground_models

    """

    pass
