from __future__ import annotations

import json as _json
import os
import types
from pathlib import Path
from typing import Optional

import requests

from ..config import LoginConfig, save_config_raw


def _is_debug() -> bool:
    """Return True when GLADIATOR_DEBUG=1 is set in the environment."""
    return bool(int(os.environ.get("GLADIATOR_DEBUG", "0")))


class ArenaError(RuntimeError):
    """Domain-specific error raised for Arena client operations."""


class BaseArenaClient:
    """Base class that configures the HTTP session and shared helpers."""

    def __init__(
        self,
        cfg: LoginConfig,
        *,
        session: Optional[requests.Session] = None,
    ) -> None:
        self.cfg = cfg
        self.session = session or requests.Session()
        self.session.verify = cfg.verify_tls
        self._apply_default_headers()
        self._debug = _is_debug()
        self._install_debug_hooks()

    def _apply_default_headers(self) -> None:
        defaults = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "gladiator-arena/0.1",
            "Arena-Usage-Reason": self.cfg.reason or "gladiator/cli",
        }
        for key, value in defaults.items():
            self.session.headers[key] = value
        if self.cfg.arena_session_id:
            self.session.headers["arena_session_id"] = self.cfg.arena_session_id

    def _api_base(self) -> str:
        return self.cfg.base_url.rstrip("/")

    def _log(self, msg: str) -> None:
        if self._debug:
            print(f"[gladiator debug] {msg}")

    def _install_debug_hooks(self) -> None:
        """Wrap session.request so every HTTP call and response is logged."""
        if not self._debug:
            return
        if getattr(self.session, "_glad_logged", False):
            return

        orig_request = self.session.request

        def _logged_request(sess, method, url, **kwargs):
            # --- request ---
            hdrs = dict(self.session.headers)
            hdrs.update(kwargs.get("headers") or {})
            params = kwargs.get("params")
            json_body = kwargs.get("json")
            data = kwargs.get("data")
            files = kwargs.get("files")

            json_preview = None
            if json_body is not None:
                try:
                    json_preview = _json.dumps(json_body)[:400]
                except Exception:
                    json_preview = "<unserializable>"

            self._log(
                f">>> {method.upper()} {url}\n"
                f"    headers={hdrs}\n"
                f"    params={params!r} "
                f"json={json_preview if json_preview is not None else 'no'} "
                f"data={'yes' if data else 'no'} "
                f"files={'yes' if files else 'no'}"
            )

            resp = orig_request(method, url, **kwargs)

            # --- response ---
            body_preview = resp.text[:800] if resp.text else "(empty)"
            self._log(
                f"<<< {resp.status_code} {resp.reason}\n"
                f"    headers={dict(resp.headers)}\n"
                f"    body={body_preview}"
            )
            return resp

        self.session.request = types.MethodType(_logged_request, self.session)
        self.session._glad_logged = True

    def _ensure_json(self, resp: requests.Response):
        ctype = resp.headers.get("Content-Type", "").lower()
        if "application/json" not in ctype:
            snippet = resp.text[:400].replace("", " ")
            raise ArenaError(
                f"Expected JSON but got '{ctype or 'unknown'}' from {resp.url}. "
                f"Status {resp.status_code}. Body starts with: {snippet}"
            )
        try:
            return resp.json()
        except Exception as exc:  # pragma: no cover - defensive catch
            raise ArenaError(f"Failed to parse JSON from {resp.url}: {exc}") from exc

    def _try_json(self, resp: requests.Response) -> Optional[dict]:
        """Best-effort JSON parse. Returns None if not JSON or parse fails."""
        ctype = resp.headers.get("Content-Type", "").lower()
        if "application/json" not in ctype:
            return None
        try:
            data = resp.json()
            return data if isinstance(data, dict) else {"data": data}
        except Exception:
            return None

    def check_status(self) -> dict:
        """
        Check connectivity to the Arena backend.
        Returns a dict with status information.
        Uses the change categories endpoint as a lightweight connectivity check.
        """
        url = f"{self._api_base()}/settings/changes/categories"
        try:
            resp = self.session.get(url, timeout=10)
            resp.raise_for_status()
            # Convert elapsed time to milliseconds
            response_time_ms = None
            if hasattr(resp, "elapsed") and resp.elapsed:
                response_time_ms = int(resp.elapsed.total_seconds() * 1000)
            # Store response metadata
            return {
                "connected": True,
                "base_url": self.cfg.base_url,
                "status_code": resp.status_code,
                "response_time_ms": response_time_ms,
            }
        except requests.ConnectionError as e:
            return {
                "connected": False,
                "base_url": self.cfg.base_url,
                "error": f"Connection error: {str(e)}",
            }
        except requests.Timeout as e:
            return {
                "connected": False,
                "base_url": self.cfg.base_url,
                "error": f"Request timeout: {str(e)}",
            }
        except requests.HTTPError as e:
            return {
                "connected": False,
                "base_url": self.cfg.base_url,
                "status_code": getattr(e.response, "status_code", None),
                "error": f"HTTP error: {str(e)}",
            }
        except Exception as e:
            return {
                "connected": False,
                "base_url": self.cfg.base_url,
                "error": f"Error: {str(e)}",
            }


__all__ = ["ArenaError", "BaseArenaClient", "arena_login"]


def arena_login(
    username: str,
    password: str,
    *,
    base_url: str = "https://api.arenasolutions.com/v1",
    verify_tls: bool = True,
    reason: Optional[str] = None,
    save_to_disk: bool = True,
    config_path: Optional[Path] = None,
) -> LoginConfig:
    """
    Authenticate with the Arena API and create a LoginConfig.

    Args:
        username: Email/username for authentication
        password: Password for authentication
        base_url: Arena API base URL
        verify_tls: Whether to verify TLS certificates
        reason: Arena-Usage-Reason header value (defaults to "gladiator/api")
        save_to_disk: Whether to save the config to disk
        config_path: Custom path for config file (uses default if None)

    Returns:
        LoginConfig object with authentication details

    Raises:
        ArenaError: If authentication fails
    """
    if not username or not password:
        raise ArenaError("Username and password are required")

    # Perform login request
    session = requests.Session()
    session.verify = verify_tls
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Arena-Usage-Reason": reason or "gladiator/api",
        "User-Agent": "gladiator-arena/0.1",
    }
    url = f"{base_url.rstrip('/')}/login"

    debug = _is_debug()
    if debug:
        print(
            f"[gladiator debug] >>> POST {url}\n"
            f"    headers={headers}\n"
            f'    json={{"email": "{username}", "password": "***"}}'
        )

    try:
        resp = session.post(
            url, headers=headers, json={"email": username, "password": password}
        )
        if debug:
            body_preview = resp.text[:800] if resp.text else "(empty)"
            print(
                f"[gladiator debug] <<< {resp.status_code} {resp.reason}\n"
                f"    headers={dict(resp.headers)}\n"
                f"    body={body_preview}"
            )
        resp.raise_for_status()
    except Exception as exc:
        error_body = getattr(resp, "text", "")[:400]
        raise ArenaError(f"Login failed: {exc} Body: {error_body}") from exc

    # Parse response and create config
    data = resp.json()
    data.update({"base_url": base_url, "verify_tls": verify_tls, "reason": reason})

    # Save the raw response data directly (preserves all Arena fields)
    if save_to_disk:
        if config_path is not None:
            save_config_raw(data, path=config_path)
        else:
            save_config_raw(data)

    config = LoginConfig.model_validate(data)
    return config
