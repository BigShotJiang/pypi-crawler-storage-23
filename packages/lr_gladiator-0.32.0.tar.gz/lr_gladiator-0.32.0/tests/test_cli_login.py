#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_login.py
"""Tests for the login command, spinner, and error formatting utilities."""

from contextlib import contextmanager
from types import SimpleNamespace

import pytest
import requests
from typer.testing import CliRunner

from gladiator.cli import app
import gladiator.cli as cli_module


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# spinner
# ---------------------------------------------------------------------------


def test_spinner_uses_console_when_tty(monkeypatch):
    events = []

    class DummyCtx:
        def __enter__(self):
            events.append("enter")
            return self

        def __exit__(self, exc_type, exc, tb):
            events.append("exit")

    def fake_status(message, spinner="dots"):
        events.append((message, spinner))
        return DummyCtx()

    monkeypatch.setattr(cli_module, "console", SimpleNamespace(status=fake_status))
    monkeypatch.setattr(
        cli_module, "sys", SimpleNamespace(stdout=SimpleNamespace(isatty=lambda: True))
    )

    with cli_module.spinner("Working"):
        events.append("body")

    assert events == [("Working", "dots"), "enter", "body", "exit"]


# ---------------------------------------------------------------------------
# _format_http_error
# ---------------------------------------------------------------------------


def test_format_http_error_from_json(monkeypatch):
    class DummyResponse:
        def __init__(self, payload):
            self._payload = payload
            self.text = ""

        def json(self):
            return self._payload

    err = requests.HTTPError("Boom")
    err.response = DummyResponse({"message": "It failed"})

    formatted = cli_module._format_http_error(err)
    assert "It failed" in formatted


def test_format_http_error_plain_text(monkeypatch):
    class DummyResponse:
        def __init__(self, text):
            self.text = text

        def json(self):
            raise ValueError("no json")

    err = requests.HTTPError("Boom")
    err.response = DummyResponse("Some failure")

    formatted = cli_module._format_http_error(err)
    assert "Some failure" in formatted


# ---------------------------------------------------------------------------
# login CLI
# ---------------------------------------------------------------------------


def test_login_cli_success(monkeypatch, tmp_path):
    from gladiator.config import LoginConfig

    runner = CliRunner()

    # Mock arena_login to track calls and return a LoginConfig
    login_calls = []

    def fake_arena_login(*args, **kwargs):
        login_calls.append({"args": args, "kwargs": kwargs})
        return LoginConfig(
            base_url=kwargs.get("base_url", "https://api.arenasolutions.com/v1"),
            verify_tls=kwargs.get("verify_tls", True),
            arena_session_id="SESSION",
            reason=kwargs.get("reason"),
        )

    monkeypatch.setattr(cli_module, "spinner", _noop_spinner)
    monkeypatch.setattr(cli_module, "arena_login", fake_arena_login)
    monkeypatch.setattr(
        cli_module, "CONFIG_PATH", tmp_path / "login.json", raising=False
    )

    result = runner.invoke(
        app,
        [
            "login",
            "--username",
            "user@example.com",
            "--password",
            "secret",
            "--base-url",
            "https://arena.test/api",
            "--no-verify-tls",
            "--reason",
            "Unit Test",
        ],
    )

    assert result.exit_code == 0
    assert login_calls
    call = login_calls[0]
    assert call["args"][0] == "user@example.com"
    assert call["args"][1] == "secret"
    assert call["kwargs"]["base_url"] == "https://arena.test/api"
    assert call["kwargs"]["verify_tls"] is False
    assert call["kwargs"]["reason"] == "Unit Test"


def test_login_cli_http_error(monkeypatch):
    from gladiator.arena import ArenaError

    runner = CliRunner()

    def fake_arena_login(*args, **kwargs):
        raise ArenaError("Login failed: 401 Unauthorized")

    monkeypatch.setattr(cli_module, "spinner", _noop_spinner)
    monkeypatch.setattr(cli_module, "arena_login", fake_arena_login)

    result = runner.invoke(
        app,
        [
            "login",
            "--username",
            "user@example.com",
            "--password",
            "bad",
        ],
    )

    assert result.exit_code == 2
    assert "Login failed" in result.stderr


def test_login_cli_requires_credentials_for_ci(monkeypatch):
    runner = CliRunner()
    monkeypatch.setattr(cli_module, "spinner", _noop_spinner)

    result = runner.invoke(app, ["login", "--ci", "--username", "user@example.com"])

    assert result.exit_code == 2
    assert "Provide --username and --password" in result.stderr


def test_login_function_success(monkeypatch, tmp_path):
    from gladiator.config import LoginConfig

    # Mock arena_login to track calls
    login_calls = []

    def fake_arena_login(*args, **kwargs):
        login_calls.append({"args": args, "kwargs": kwargs})
        return LoginConfig(
            base_url=kwargs.get("base_url", "https://api.arenasolutions.com/v1"),
            verify_tls=kwargs.get("verify_tls", True),
            arena_session_id="SESSION",
            reason=kwargs.get("reason"),
        )

    monkeypatch.setattr(cli_module, "spinner", _noop_spinner)
    monkeypatch.setattr(cli_module, "arena_login", fake_arena_login)
    monkeypatch.setattr(
        cli_module, "CONFIG_PATH", tmp_path / "login.json", raising=False
    )

    cli_module.login(
        username="user@example.com",
        password="secret",
        base_url="https://arena.test/api",
        verify_tls=False,
        non_interactive=True,
        reason="Unit Test",
    )

    assert login_calls
    call = login_calls[0]
    assert call["args"][0] == "user@example.com"
    assert call["args"][1] == "secret"
    assert call["kwargs"]["base_url"] == "https://arena.test/api"
    assert call["kwargs"]["verify_tls"] is False


def test_login_success(monkeypatch):
    from gladiator.config import LoginConfig

    runner = CliRunner()
    login_calls = []

    def fake_arena_login(username, password, **kwargs):
        login_calls.append(
            {"username": username, "password": password, "kwargs": kwargs}
        )
        return LoginConfig(
            base_url=kwargs.get("base_url", "https://api.arenasolutions.com/v1"),
            verify_tls=kwargs.get("verify_tls", True),
            arena_session_id="ABC123",
            reason=kwargs.get("reason"),
        )

    monkeypatch.setattr("gladiator.cli.arena_login", fake_arena_login)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "login",
            "--username",
            "user@example.com",
            "--password",
            "s3cr3t",
            "--base-url",
            "https://arena.test/api",
            "--reason",
            "CI",
        ],
    )

    assert result.exit_code == 0
    assert login_calls
    call = login_calls[0]
    assert call["username"] == "user@example.com"
    assert call["password"] == "s3cr3t"
    assert call["kwargs"]["base_url"] == "https://arena.test/api"
    assert call["kwargs"]["reason"] == "CI"
    assert call["kwargs"]["verify_tls"] is True
    assert "Saved session" in result.stdout


def test_login_ci_requires_credentials(monkeypatch):
    runner = CliRunner()

    class DummySession:
        def __init__(self):
            self.post_calls = []

        def post(self, *_args, **_kwargs):
            self.post_calls.append((_args, _kwargs))
            raise AssertionError("POST should not be called when credentials missing")

    dummy_session = DummySession()

    session_calls = []

    def _session_factory():
        session_calls.append(True)
        return dummy_session

    monkeypatch.setattr("gladiator.cli.requests.Session", _session_factory)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["login", "--ci", "--password", "secret"])

    assert result.exit_code == 2
    assert "Provide --username and --password" in result.stderr
    assert not session_calls


def test_login_http_failure(monkeypatch):
    runner = CliRunner()
    saved = {}

    class DummyResponse:
        def __init__(self):
            self.text = "boom"

        def raise_for_status(self):
            raise requests.HTTPError("bad request")

        def json(self):
            return {}

    class DummySession:
        def __init__(self):
            self.verify = None
            self.post_calls = []

        def post(self, url, headers=None, json=None):
            self.post_calls.append({"url": url, "headers": headers, "json": json})
            return DummyResponse()

    monkeypatch.setattr("gladiator.cli.requests.Session", lambda: DummySession())
    monkeypatch.setattr(
        "gladiator.config.save_config_raw", lambda data, path=None: saved.update(data)
    )
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "login",
            "--username",
            "user@example.com",
            "--password",
            "s3cr3t",
        ],
    )

    assert result.exit_code == 2
    assert "Login failed" in result.stderr
    assert saved == {}
