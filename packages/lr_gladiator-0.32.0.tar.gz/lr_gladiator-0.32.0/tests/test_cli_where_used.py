#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_where_used.py
"""CLI tests for the where-used command."""

import json
from contextlib import contextmanager

import pytest
import requests
from typer.testing import CliRunner

from gladiator.arena import ArenaError
from gladiator.cli import app


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# where-used CLI
# ---------------------------------------------------------------------------


def test_where_used_cli_table(monkeypatch):
    """where-used prints a Rich table by default."""
    runner = CliRunner()

    class DummyClient:
        def get_where_used(self, item_number, *, recursive=False, all_revisions=False):
            return [
                {
                    "number": "890-1001",
                    "name": "Assembly A",
                    "revisionNumber": "B",
                    "lifecyclePhase": "In Production",
                    "level": 0,
                },
            ]

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["where-used", "510-0001"])

    assert result.exit_code == 0
    assert "890-1001" in result.stdout
    assert "Assembly A" in result.stdout


def test_where_used_cli_json(monkeypatch):
    """--format json produces valid JSON output."""
    runner = CliRunner()

    class DummyClient:
        def get_where_used(self, item_number, *, recursive=False, all_revisions=False):
            return [
                {
                    "number": "890-1001",
                    "name": "Assembly A",
                    "revisionNumber": "B",
                    "lifecyclePhase": "In Production",
                    "level": 0,
                },
            ]

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["where-used", "510-0001", "--format", "json"])

    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["count"] == 1
    assert data["results"][0]["number"] == "890-1001"


def test_where_used_cli_recursive(monkeypatch):
    """--recursive is forwarded to the client and Level column appears."""
    runner = CliRunner()
    captured_kwargs = {}

    class DummyClient:
        def get_where_used(self, item_number, *, recursive=False, all_revisions=False):
            captured_kwargs["recursive"] = recursive
            return [
                {
                    "number": "890-1001",
                    "name": "Assembly A",
                    "revisionNumber": "B",
                    "lifecyclePhase": "In Production",
                    "level": 0,
                },
                {
                    "number": "890-2000",
                    "name": "Top Assembly",
                    "revisionNumber": "A",
                    "lifecyclePhase": "In Production",
                    "level": 1,
                },
            ]

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["where-used", "510-0001", "--recursive"])

    assert result.exit_code == 0
    assert captured_kwargs["recursive"] is True
    assert "890-1001" in result.stdout
    assert "890-2000" in result.stdout
    assert "Level" in result.stdout


def test_where_used_cli_all_revisions(monkeypatch):
    """--all-revisions passes the flag through to the client."""
    runner = CliRunner()
    captured_kwargs = {}

    class DummyClient:
        def get_where_used(self, item_number, *, recursive=False, all_revisions=False):
            captured_kwargs["all_revisions"] = all_revisions
            return [
                {
                    "number": "840-2220",
                    "name": "W-BACnet DIN rail",
                    "revisionNumber": "B1",
                    "lifecyclePhase": None,
                    "level": 0,
                },
                {
                    "number": "840-2220",
                    "name": "W-BACnet DIN rail",
                    "revisionNumber": "C",
                    "lifecyclePhase": "In Production",
                    "level": 0,
                },
            ]

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["where-used", "510-0001", "--all-revisions"])

    assert result.exit_code == 0
    assert captured_kwargs["all_revisions"] is True
    assert "B1" in result.stdout
    assert "C" in result.stdout


def test_where_used_cli_empty(monkeypatch):
    """Prints a message when no parents are found."""
    runner = CliRunner()

    class DummyClient:
        def get_where_used(self, item_number, *, recursive=False, all_revisions=False):
            return []

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["where-used", "510-9999"])

    assert result.exit_code == 0
    assert "No items found" in result.stdout


def test_where_used_cli_http_error(monkeypatch):
    """HTTP errors are handled gracefully."""
    runner = CliRunner()

    class DummyClient:
        def get_where_used(self, item_number, *, recursive=False, all_revisions=False):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["where-used", "510-0001"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_where_used_cli_arena_error(monkeypatch):
    """ArenaError is handled gracefully."""
    runner = CliRunner()

    class DummyClient:
        def get_where_used(self, item_number, *, recursive=False, all_revisions=False):
            raise ArenaError("item not found")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["where-used", "510-0001"])

    assert result.exit_code == 2
    assert "item not found" in result.stderr
