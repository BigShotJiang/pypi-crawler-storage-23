#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_info.py
"""Tests for the info and latest-approved commands."""

from contextlib import contextmanager
from pathlib import Path

import pytest
import requests
from typer.testing import CliRunner

from gladiator.cli import app


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------


def test_info_cli_success(monkeypatch):
    runner = CliRunner()
    captured = {}

    class DummyClient:
        def get_item_summary(self, item, revision):
            captured["args"] = (item, revision)
            return {
                "number": item,
                "revision": "C",
                "name": "Widget",
                "description": "Widget description",
                "category": "Assembly",
                "lifecyclePhase": "Production",
                "revisionStatus": "EFFECTIVE",
                "appUrl": "https://app.test/items/510-0100",
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["info", "510-0100"])

    assert result.exit_code == 0
    assert captured["args"] == ("510-0100", None)
    assert "Widget" in result.stdout
    assert "Lifecycle Phase" in result.stdout
    assert "Item URL" in result.stdout
    assert "https://app.test/items/510-0100" in result.stdout


def test_info_cli_json_format(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_item_summary(self, item, revision):
            return {
                "number": item,
                "revision": "B",
                "name": "Widget",
                "category": "Electronics",
                "appUrl": "https://app.test/items/510-0101",
            }

    client = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: client)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["info", "--rev", "b2", "--format", "json", "510-0101"],
    )

    assert result.exit_code == 0
    assert '"number": "510-0101"' in result.stdout
    assert '"selector": "b2"' in result.stdout
    assert '"appUrl": "https://app.test/items/510-0101"' in result.stdout


def test_info_cli_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_item_summary(self, *_args, **_kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("item missing")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["info", "510-0102"])

    assert result.exit_code == 2
    assert "item missing" in result.stderr


def test_info_cli_picture_downloads_file(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.summary_calls = []
            self.picture_calls = []

        def get_item_summary(self, item, revision):
            self.summary_calls.append((item, revision))
            return {
                "number": item,
                "revision": "D",
                "name": "Widget",
                "category": "Assembly",
            }

        def download_item_picture(self, item, revision, dest_dir=None):
            self.picture_calls.append((item, revision, dest_dir))
            out = Path(dest_dir or ".") / f"{item}.png"
            out.write_bytes(b"img")
            return out

    client = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: client)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    with runner.isolated_filesystem():
        result = runner.invoke(app, ["info", "--picture", "510-0103"])

        assert result.exit_code == 0
        assert client.summary_calls == [("510-0103", None)]
        assert client.picture_calls and client.picture_calls[0][0] == "510-0103"
        assert Path("510-0103.png").exists()
        assert "Picture Path" in result.stdout


def test_info_cli_picture_json_handles_null(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_item_summary(self, item, revision):
            return {
                "number": item,
                "revision": "E",
                "name": "Widget",
                "category": "Electronics",
            }

        def download_item_picture(self, *_args, **_kwargs):
            return None

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["info", "--picture", "--format", "json", "510-0104"],
    )

    assert result.exit_code == 0
    assert '"picturePath": null' in result.stdout


# ---------------------------------------------------------------------------
# latest-approved
# ---------------------------------------------------------------------------


def test_latest_approved_success(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.calls = []

        def get_latest_approved_revision(self, item):
            self.calls.append(item)
            return "B"

    client = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: client)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["latest-approved", "510-0001"])

    assert result.exit_code == 0
    assert client.calls == ["510-0001"]
    assert result.stdout.strip() == "B"


def test_latest_approved_json_output(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_latest_approved_revision(self, item):
            return "C"

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["latest-approved", "510-0002", "--format", "json"],
    )

    assert result.exit_code == 0
    assert result.stdout.strip() == '{\n  "article": "510-0002",\n  "revision": "C"\n}'


def test_latest_approved_json_missing_revision(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_latest_approved_revision(self, item):
            from gladiator.arena import ArenaError

            raise ArenaError(f"No approved/released revisions for item {item}")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["latest-approved", "510-0005", "--format", "json"],
    )

    assert result.exit_code == 0
    assert (
        result.stdout.strip()
        == '{\n  "article": "510-0005",\n  "revision": null,\n  "status": "missing"\n}'
    )
    assert "No approved/released revisions for item 510-0005" in result.stderr


def test_latest_approved_http_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_latest_approved_revision(self, item):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["latest-approved", "510-0003"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_latest_approved_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_latest_approved_revision(self, item):
            from gladiator.arena import ArenaError

            raise ArenaError("no revision")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["latest-approved", "510-0004"])

    assert result.exit_code == 2
    assert "no revision" in result.stderr


def test_latest_approved_missing_revision_text(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_latest_approved_revision(self, item):
            from gladiator.arena import ArenaError

            raise ArenaError(f"No approved/released revisions for item {item}")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["latest-approved", "510-0006"])

    assert result.exit_code == 0
    assert "No approved/released revisions for item 510-0006" in result.stdout
