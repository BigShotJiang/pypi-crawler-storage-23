from typing import Union, Optional

from pydantic import Field, BaseModel


class RequestJsonLogSchema(BaseModel):
    """
    Схема части запросов-ответов лога в формате JSON
    """

    request_uri: str
    request_referer: str
    request_protocol: str
    request_method: str
    request_path: str
    request_host: str
    request_size: int
    request_content_type: str
    request_headers: dict
    request_body: Union[str, dict, list]
    request_direction: str
    remote_ip: str
    remote_port: int
    response_status_code: int
    response_size: int
    response_headers: dict
    response_body: Optional[Union[str, dict, list]] = Field(default=None)
    duration: int
