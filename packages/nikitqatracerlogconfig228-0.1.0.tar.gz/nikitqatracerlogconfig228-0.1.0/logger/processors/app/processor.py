from structlog.typing import WrappedLogger, EventDict


class ApplicationProcessor:
    def __init__(self, app_name: str, app_version: str):
        self.app_name = app_name
        self.app_version = app_version
        
    def __call__(self, logger: WrappedLogger, name: str, event_dict: EventDict) -> EventDict:
        event_dict["application"] = self.app_name
        event_dict["version"] = self.app_version
        return event_dict
