import logging

from structlog.typing import EventDict


class OTELRenamer:
    def __init__(
        self,
        service_name: str = "service_name",
        span_id_name: str = "span_id",
        trace_id_name: str = "trace_id",
        trace_flags_name: str = "trace_flags",
    ) -> None:
        self.service_name = service_name
        self.span_id_name = span_id_name
        self.trace_id_name = trace_id_name
        self.trace_flags_name = trace_flags_name

    def __call__(self, logger: logging.Logger, method_name: str, event_dict: EventDict) -> EventDict:
        event_dict[self.service_name] = event_dict.pop("otelServiceName", "unknown")
        event_dict[self.trace_id_name] = event_dict.pop("otelTraceID", "0")
        event_dict[self.span_id_name] = event_dict.pop("otelSpanID", "0")
        event_dict[self.trace_flags_name] = int(event_dict.pop("otelTraceSampled", False))
        return event_dict
