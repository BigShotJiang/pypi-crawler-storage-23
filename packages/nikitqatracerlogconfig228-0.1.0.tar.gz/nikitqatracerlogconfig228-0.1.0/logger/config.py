from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal


@dataclass
class SensitivityConfig:
    keys: set[str] = field(default_factory=lambda: ["password", "email", "token", "authorization"])
    replacement: str = "***"


@dataclass
class LoggingFileConfig:
    path: str | Path = "logs.log"


@dataclass
class ApplicationConfig:
    name: str
    version: str


@dataclass
class LoggingConfig:
    application: ApplicationConfig
    format: Literal["json", "console", "console_colored"] = "json"
    level: str = "DEBUG"
    file: LoggingFileConfig | None = None
    sensitivity: SensitivityConfig | None = None
    custom_loggers: dict[str, str] = field(default_factory=dict)

    def _validate_format(self) -> None:
        if self.format == "console_colored" and self.file:
            raise ValueError("Cannot use colored console and file logging at the same time")
        return None
    
    @property
    def get_format(self) -> str:
        self._validate_format()
        return self.format
    