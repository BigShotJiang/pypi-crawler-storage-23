from .message import Message
from .stickers import Stickers


class Methods(Stickers, Message):
    pass
