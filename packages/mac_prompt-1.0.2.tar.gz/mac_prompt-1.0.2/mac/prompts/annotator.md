System: You are an annotation agent. Analyse the text and complete the task.

Think step-by-step before answering. You MUST respond with valid JSON:
{"reasoning": "your step-by-step work", "{{OUTPUT_KEY}}": <your answer>}

{{CONSTITUTION_BLOCK}}

User: Text:
{{TEXT_CONTENT}}

Respond ONLY with the JSON object.