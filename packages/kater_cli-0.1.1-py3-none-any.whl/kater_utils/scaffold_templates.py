"""Scaffold template content for Kater CLI project initialization."""

from __future__ import annotations

import uuid

SCAFFOLDED_README_TEMPLATE = """\
# {repository_name}

> Your Kater semantic layer repository. This repo contains your data model \
definitions, governance policies, and configuration — all managed as code.

## Quick Start

### 1. Clone and Initialize

```bash
git clone <repo-url>
cd {repository_name}
git submodule update --init --recursive
```

### 2. Explore the Sample Repository

Browse `__sample_client_repo/` for a complete working example of a Kater \
semantic layer with models, queries, dashboards, and governance.

### 3. Continue Onboarding

Return to Kater to complete the remaining setup steps:
- Connect your data warehouse
- Run schema sync to import your tables
- Start building your semantic layer

Visit [kater.ai/docs](https://kater.ai/docs) for complete documentation.

## Repository Structure

| Directory | Purpose |
| --- | --- |
| `_admin/` | Governance configuration (query policies, access grants) |
| `__sample_client_repo/` | Reference implementation (git submodule) |
| `kater.config.yaml` | Project-level configuration |

### Directories NOT in This Repo

| Directory | Reason |
| --- | --- |
| `_admin/tenants/` | Generated at runtime by Kater. Read-only, stored locally. |

## Developer Workflow

### Making Changes

1. Create a feature branch
2. Edit model files (views, queries, measures, dimensions)
3. Push your branch and open a PR
4. Kater validates your changes automatically via webhooks
5. Merge to main — Kater syncs the updated configuration

## Governance (`_admin/`)

- `_admin/query_policy.yaml` — Controls query execution rules and limits
- `_admin/integrations.yaml` — External integration configuration
- `_admin/grants/` — Access control (filters, grants, attributes)

## Runtime Directories

The `_admin/tenants/` directory is generated at runtime by the Kater platform. \
It is stored locally, not committed to the repository, and is read-only from \
the client's perspective. It contains tenant configuration and tenant group \
definitions.

## Sample Repository

The `__sample_client_repo/` directory is a git submodule pointing to Kater's \
public sample repository. Use it as a reference for how to structure your \
semantic layer.

To initialize or update:

```bash
git submodule update --init --recursive
```

## Links / Documentation

- [Kater Documentation](https://kater.ai/docs)
- [Getting Started Guide](https://kater.ai/docs/getting-started)
- [Semantic Layer Reference](https://kater.ai/docs/semantic-layer)
- [Governance Guide](https://kater.ai/docs/governance)

## Support

Questions? Visit [kater.ai/docs](https://kater.ai/docs) or contact support.
"""

QUERY_POLICY_TEMPLATE = """\
kater_id: {kater_id}

# What can the AI do by default? (can be overridden per tenant group)
#   strict  — AI answers from pre-built queries/playbooks only
#   guided  — AI can also request reports and dashboards on behalf of the user (recommended)
#   free    — All guided capabilities, plus custom SQL and Python
default_mode: guided

modes:
  strict:
    description: 'AI answers from pre-built queries and playbooks only'
    llm_capabilities:
      write_custom_sql: false
      write_custom_python: false
      request_reports_on_behalf_of_user: false
      request_dashboards_on_behalf_of_user: false
      create_alert_on_behalf_of_user: false
      schedule_delivery_for_user: false

  guided:
    description: 'AI can request reports, dashboards, alerts, and deliveries on behalf of the user'
    llm_capabilities:
      write_custom_sql: false
      write_custom_python: false
      request_reports_on_behalf_of_user: true
      request_dashboards_on_behalf_of_user: true
      create_alert_on_behalf_of_user: true
      schedule_delivery_for_user: true

  free:
    description: 'Full capabilities including custom SQL and Python'
    llm_capabilities:
      write_custom_sql: true
      write_custom_python: true
      request_reports_on_behalf_of_user: true
      request_dashboards_on_behalf_of_user: true
      create_alert_on_behalf_of_user: true
      schedule_delivery_for_user: true

# Give different customer segments different AI freedom levels.
# Assign tenants to these groups in your tenant config.
# group_overrides:
#   - group: free_tier
#     mode: strict
#   - group: enterprise
#     mode: free

# Hard limits that apply to ALL modes — protects against runaway queries.
global_guardrails:
  max_query_rows: 100000
  max_query_timeout_seconds: 300

# Audit log retention (all query/event logging is on by default).
audit:
  retention_days: 90
"""

INTEGRATIONS_PLACEHOLDER = """\
# Integrations Configuration
# Define external integrations and data source connections.
# See: https://kater.ai/docs/governance/integrations
"""

GRANTS_ACCESS_FILTERS_PLACEHOLDER = """\
# Access Filters
# Define row-level security filters for tenant data isolation.
# See: https://kater.ai/docs/governance/access-filters
"""

GRANTS_ACCESS_GRANTS_PLACEHOLDER = """\
# Access Grants
# Define permission grants for users and roles.
# See: https://kater.ai/docs/governance/access-grants
"""

GRANTS_ATTRIBUTES_PLACEHOLDER = """\
# Attributes
# Define user and tenant attributes used in access policies.
# See: https://kater.ai/docs/governance/attributes
"""

# Pre-generated from packages/components_core/src/theme/default-theme.json
# via serializeThemeConfigToCss(). The default theme is stable so this is
# safe to store as a static constant.
DEFAULT_KATER_GLOBALS_CSS = """\
:root {
  --background: hsl(0 0% 100%);
  --foreground: hsl(0 0% 3.9%);
  --primary: hsl(0 0% 9%);
  --primary-foreground: hsl(0 0% 98%);
  --secondary: hsl(0 0% 96.1%);
  --secondary-foreground: hsl(0 0% 9%);
  --accent: hsl(0 0% 96.1%);
  --accent-foreground: hsl(0 0% 9%);
  --destructive: hsl(0 84.2% 60.2%);
  --border: hsl(0 0% 89.8%);
  --input: hsl(0 0% 89.8%);
  --ring: hsl(0 0% 63.9%);
  --muted: hsl(0 0% 96.1%);
  --muted-foreground: hsl(0 0% 45.1%);
  --card: hsl(0 0% 100%);
  --card-foreground: hsl(0 0% 3.9%);
  --popover: hsl(0 0% 100%);
  --popover-foreground: hsl(0 0% 3.9%);
  --sidebar: hsl(0 0% 98%);
  --sidebar-foreground: hsl(0 0% 3.9%);
  --sidebar-primary: hsl(0 0% 9%);
  --sidebar-primary-foreground: hsl(0 0% 98%);
  --sidebar-accent: hsl(0 0% 96.1%);
  --sidebar-accent-foreground: hsl(0 0% 9%);
  --sidebar-border: hsl(0 0% 89.8%);
  --sidebar-ring: hsl(0 0% 63.9%);
  --positive: hsl(142 76% 36%);
  --negative: hsl(0 84.2% 60.2%);
  --chart-1: hsl(221 83% 53%);
  --chart-2: hsl(163 72% 41%);
  --chart-3: hsl(258 58% 56%);
  --chart-4: hsl(38 92% 50%);
  --chart-5: hsl(346 77% 50%);
  --font-family: Inter, system-ui, sans-serif;
  --font-size-base: 14px;
  --radius: 0.5rem;
}

.dark {
  --background: hsl(0 0% 3.9%);
  --foreground: hsl(0 0% 98%);
  --primary: hsl(0 0% 89.8%);
  --primary-foreground: hsl(0 0% 9%);
  --secondary: hsl(0 0% 14.9%);
  --secondary-foreground: hsl(0 0% 98%);
  --accent: hsl(0 0% 27.1%);
  --accent-foreground: hsl(0 0% 98%);
  --destructive: hsl(0 72.2% 50.6%);
  --border: hsl(0 0% 14.9%);
  --input: hsl(0 0% 14.9%);
  --ring: hsl(0 0% 45.1%);
  --muted: hsl(0 0% 14.9%);
  --muted-foreground: hsl(0 0% 63.1%);
  --card: hsl(0 0% 9%);
  --card-foreground: hsl(0 0% 98%);
  --popover: hsl(0 0% 14.9%);
  --popover-foreground: hsl(0 0% 98%);
  --sidebar: hsl(0 0% 9%);
  --sidebar-foreground: hsl(0 0% 98%);
  --sidebar-primary: hsl(225.4 84% 49%);
  --sidebar-primary-foreground: hsl(0 0% 98%);
  --sidebar-accent: hsl(0 0% 14.9%);
  --sidebar-accent-foreground: hsl(0 0% 98%);
  --sidebar-border: hsl(0 0% 14.9%);
  --sidebar-ring: hsl(0 0% 45.1%);
  --positive: hsl(142 70% 45%);
  --negative: hsl(0 72.2% 50.6%);
  --chart-1: hsl(217 91% 60%);
  --chart-2: hsl(163 64% 52%);
  --chart-3: hsl(258 52% 66%);
  --chart-4: hsl(38 88% 58%);
  --chart-5: hsl(346 70% 60%);
}
"""

# Copied from packages/components_core/src/theme/kater-chart-theme.yaml
DEFAULT_KATER_CHART_THEME_YAML = """\
# Kater Chart Theme — Tier 1 styling cascade defaults.
#
# Defines chart rendering behavior (no colors — those come from CSS vars).
# Values must match valid StyleConfig types exactly.
# See: widget-react-tech-spec.md L572-613

axis:
  label:
    truncation: auto
    rotation: auto
    show: true

legend:
  position: bottom
  show: auto
  max_height: auto
  truncation: auto

tooltip:
  show: true
  format: auto
  include_x: true

grid:
  x:
    show: false
  y:
    show: true
  style: dashed
  opacity: 0.3

line:
  width: 2
  curve: monotone
  show_points: auto
  point_radius: 3

area:
  opacity: 0.3

bar:
  border_radius: 4
  gap: 0.2
  group_gap: 0.1
"""

# Generated from LayoutConfig() Pydantic model defaults.
# See: packages/core/src/kater_core/schemas/layout_config.py
DEFAULT_LAYOUT_YAML = """\
# Kater Layout Configuration
# Controls app-level layout, branding, and feature toggles.

schema_version: '1'
integration_mode: default

branding:
  app_name: ''
  logo: null
  favicon: null

home:
  layout: gallery_cards
  default_dashboard: null

chat:
  enabled: true
  position: popup
  welcome_message: Ask a question about your data
  suggested_questions: []

dashboard_display:
  show_description: true
  show_widget_count: true
  show_last_modified: false
  thumbnail_style: preview
"""

GITIGNORE_CONTENT = """\
# Kater runtime directories (auto-generated, not version controlled)
_admin/tenants/

# Kater compiled output (auto-generated, check in manifest and dependency-graph only)
.kater/compiled/
.kater/resolved/
!.kater/manifest.yaml
!.kater/dependency-graph.yaml
"""


def build_root_scaffold_items(project_name: str) -> list[tuple[str, str]]:
    """Build (path, content) pairs for root-level Kater scaffold files.

    Returns all files that belong at the repository root during initial setup,
    excluding git submodule entries (.gitmodules / __sample_client_repo).

    Args:
        project_name: The project name used in kater.config.yaml and README.md.

    Returns:
        List of (relative_path, file_content) tuples.
    """
    kater_config = f'''# Kater Configuration
# Generated by Kater scaffolding

version: "1.0"

# Project settings
project:
  name: "{project_name}"
  description: "Kater semantic layer configuration"

# Database connection (configured in Kater dashboard)
# database:
#   type: snowflake
#   default_schema: public

# Feature flags
features:
  # Enable AI-assisted query generation
  ai_assist: true
  # Enable semantic search
  semantic_search: true
'''

    return [
        ("kater.config.yaml", kater_config),
        ("README.md", SCAFFOLDED_README_TEMPLATE.format(repository_name=project_name)),
        ("_admin/query_policy.yaml", QUERY_POLICY_TEMPLATE.format(kater_id=str(uuid.uuid4()))),
        ("_admin/integrations.yaml", INTEGRATIONS_PLACEHOLDER),
        ("_admin/grants/access_filters.yaml", GRANTS_ACCESS_FILTERS_PLACEHOLDER),
        ("_admin/grants/access_grants.yaml", GRANTS_ACCESS_GRANTS_PLACEHOLDER),
        ("_admin/grants/attributes.yaml", GRANTS_ATTRIBUTES_PLACEHOLDER),
        (".gitignore", GITIGNORE_CONTENT),
        ("kater-globals.css", DEFAULT_KATER_GLOBALS_CSS),
        ("kater-chart-theme.yaml", DEFAULT_KATER_CHART_THEME_YAML),
        ("layout.yaml", DEFAULT_LAYOUT_YAML),
    ]
