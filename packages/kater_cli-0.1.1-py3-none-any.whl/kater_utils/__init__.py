"""Shared lightweight utilities for Kater CLI and server."""

from kater_utils.file_utils import (
    BUILTIN_EXCLUSIONS,
    hash_file,
    load_ignore_patterns,
)
from kater_utils.logging import (
    configure_logging,
    configure_logging_from_settings,
    get_logger,
)
from kater_utils.repo import (
    CONFIG_FILENAME,
    detect_kater_folder,
    find_kater_root_scanning_down,
    find_repo_root,
)
from kater_utils.scaffold_templates import build_root_scaffold_items

__all__ = [
    # Logging
    "configure_logging",
    "configure_logging_from_settings",
    "get_logger",
    # File utilities
    "BUILTIN_EXCLUSIONS",
    "hash_file",
    "load_ignore_patterns",
    # Repo detection
    "CONFIG_FILENAME",
    "detect_kater_folder",
    "find_kater_root_scanning_down",
    "find_repo_root",
    # Scaffold templates
    "build_root_scaffold_items",
]
