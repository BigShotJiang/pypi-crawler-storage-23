"""User preferences management using system keyring for secure storage."""

import json
from typing import Any

import keyring

from kater_cli.config import get_settings


class PreferenceManager:
    """Manages user preferences with secure keyring storage."""

    KEYRING_USERNAME = "user_preferences"

    def __init__(self) -> None:
        self._settings = get_settings()
        self._service = self._settings.keyring_service

    def _get_stored_preferences(self) -> dict[str, Any] | None:
        """Retrieve preferences from keyring."""
        data = keyring.get_password(self._service, self.KEYRING_USERNAME)
        if not data:
            return None
        try:
            result: dict[str, Any] = json.loads(data)
            return result
        except json.JSONDecodeError:
            return None

    def _save_preferences(self, preferences: dict[str, Any]) -> None:
        """Save preferences to keyring."""
        keyring.set_password(self._service, self.KEYRING_USERNAME, json.dumps(preferences))

    def get_default_connection_id(self) -> str | None:
        """Get the default connection ID.

        Returns:
            The default connection ID if set, None otherwise.
        """
        preferences = self._get_stored_preferences()
        if not preferences:
            return None
        return preferences.get("default_connection_id")

    def set_default_connection_id(self, connection_id: str) -> None:
        """Set the default connection ID.

        Args:
            connection_id: The connection ID to set as default.
        """
        preferences = self._get_stored_preferences() or {}
        preferences["default_connection_id"] = connection_id
        self._save_preferences(preferences)

    def clear_default_connection(self) -> bool:
        """Remove the default connection preference.

        Returns:
            True if a default was cleared, False if none was set.
        """
        preferences = self._get_stored_preferences()
        if not preferences or "default_connection_id" not in preferences:
            return False

        del preferences["default_connection_id"]
        if preferences:
            self._save_preferences(preferences)
        else:
            # If no preferences left, delete the entire entry
            try:
                keyring.delete_password(self._service, self.KEYRING_USERNAME)
            except Exception:
                pass
        return True
