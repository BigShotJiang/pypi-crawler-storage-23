"""Kater repository root detection (CLI wrapper).

Delegates to kater_core.services.repo.find_repo_root() and adds CLI-specific
error handling (Rich console output + typer.Exit).
"""

from pathlib import Path
from typing import Any, cast

import typer
import yaml
from rich.console import Console

from kater_utils.repo import (
    CONFIG_FILENAME,
    find_kater_root_scanning_down,
    find_repo_root as _find_repo_root,
)

console = Console()


def find_repo_root(start: Path | None = None) -> Path:
    """Walk up from start (or cwd) to find kater.config.yaml.

    Args:
        start: Directory to start searching from. Defaults to cwd.

    Returns:
        Path to the repo root directory containing kater.config.yaml.

    Raises:
        typer.Exit: If kater.config.yaml is not found in any parent directory.
    """
    result = _find_repo_root(start)
    if result is None:
        result = find_kater_root_scanning_down(start or Path.cwd())
    if result is None:
        console.print(
            "[red]Not in a Kater repository. "
            f"Could not find {CONFIG_FILENAME} in any parent directory.[/red]"
        )
        raise typer.Exit(1)
    return result


def find_connection_folder_local(repo_root: Path, connection_name: str) -> Path:
    """Scan repo root for a dir containing connection.yaml with matching name field.

    Args:
        repo_root: Repository root directory (contains kater.config.yaml).
        connection_name: The logical connection name to match.

    Returns:
        Path to the connection folder.

    Raises:
        FileNotFoundError: If no connection folder is found for the given name.
    """
    for child in sorted(repo_root.iterdir()):
        if not child.is_dir():
            continue
        yaml_path = child / "connection.yaml"
        if yaml_path.exists():
            try:
                data = cast(dict[str, Any] | None, yaml.safe_load(yaml_path.read_text()))
                if isinstance(data, dict) and data.get("name") == connection_name:
                    return child
            except yaml.YAMLError:
                pass
    raise FileNotFoundError(f"No connection folder found for '{connection_name}' in {repo_root}")


def find_topic_folder_local(connection_path: Path, topic_name: str) -> Path:
    """Scan connection_path/topics/ for a dir containing topic.yaml with matching name.

    Args:
        connection_path: The connection folder path.
        topic_name: The logical topic name to match.

    Returns:
        Path to the topic folder.

    Raises:
        FileNotFoundError: If the topics/ directory doesn't exist or no topic is found.
    """
    topics_dir = connection_path / "topics"
    if not topics_dir.is_dir():
        raise FileNotFoundError(f"No topics/ directory at {topics_dir}")
    for child in sorted(topics_dir.iterdir()):
        if not child.is_dir():
            continue
        yaml_path = child / "topic.yaml"
        if yaml_path.exists():
            try:
                data = cast(dict[str, Any] | None, yaml.safe_load(yaml_path.read_text()))
                if isinstance(data, dict) and data.get("name") == topic_name:
                    return child
            except yaml.YAMLError:
                pass
    raise FileNotFoundError(f"No topic folder found for '{topic_name}' in {topics_dir}")
