"""Config command group for Kater CLI."""

import typer

from kater_cli.commands.config.default_connection import (
    clear_default,
    set_default,
    show_default,
)

config_app = typer.Typer(
    name="config",
    help="Configure Kater CLI settings and preferences.",
    no_args_is_help=True,
)

# Create the default-connection subcommand group
default_connection_app = typer.Typer(
    name="default-connection",
    help="Manage the default warehouse connection.",
    no_args_is_help=True,
)

default_connection_app.command(
    name="set",
    help="Set the default warehouse connection.",
)(set_default)

default_connection_app.command(
    name="show",
    help="Show the current default warehouse connection.",
)(show_default)

default_connection_app.command(
    name="clear",
    help="Clear the default warehouse connection.",
)(clear_default)

# Add the nested subcommand group
config_app.add_typer(default_connection_app, name="default-connection")
