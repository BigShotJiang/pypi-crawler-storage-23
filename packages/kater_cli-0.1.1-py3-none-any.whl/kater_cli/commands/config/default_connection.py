"""Commands for managing the default warehouse connection."""

import kater
import typer
from kater.types.v1 import Connection
from rich.console import Console

from kater_cli.client import get_authenticated_client, require_auth
from kater_cli.prompts import prompt_selection
from kater_cli.preferences import PreferenceManager

console = Console()


def fetch_connections(client: kater.Kater) -> list[Connection]:
    """Fetch all connections from the API.

    Args:
        client: Authenticated API client

    Returns:
        List of Connection objects
    """
    try:
        return list(client.v1.connections.list_connections())
    except kater.AuthenticationError:
        console.print("[red]Session expired. Run `kater login` to re-authenticate.[/red]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        console.print(f"[red]Error fetching connections: {e.message}[/red]")
        raise typer.Exit(1)


@require_auth
def set_default(
    connection: str = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection name to set as default (skips interactive prompt).",
    ),
) -> None:
    """Set the default warehouse connection.

    When called without flags, lists available connections and prompts
    for selection. When --connection is provided, sets the default directly.

    Examples:

        # Interactive mode
        kater config default-connection set

        # Direct mode
        kater config default-connection set --connection "my-connection"
    """
    try:
        client = get_authenticated_client()
        connections = fetch_connections(client)

        if not connections:
            console.print("[red]No connections found. Run `kater create connection` first.[/red]")
            raise typer.Exit(1)

        # Flag-based mode: lookup by name
        if connection:
            selected_conn = _find_connection_by_name(connections, connection)
        else:
            # Interactive mode: prompt for selection
            selected_conn = _prompt_for_connection(connections)

        # Store the preference
        pref_manager = PreferenceManager()
        pref_manager.set_default_connection_id(str(selected_conn.id))

        console.print(f"\n[green]Default connection set to: {selected_conn.name}[/green]")

    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error setting default connection: {e}[/red]")
        raise typer.Exit(1)


def _find_connection_by_name(connections: list[Connection], name: str) -> Connection:
    """Find a connection by name.

    Args:
        connections: List of available connections
        name: Connection name to search for

    Returns:
        The matching Connection

    Raises:
        typer.Exit: If connection not found
    """
    for conn in connections:
        if conn.name == name:
            return conn

    # Connection not found - show helpful error
    available = ", ".join(f'"{c.name}"' for c in connections)
    console.print(f"[red]Connection not found: {name}[/red]")
    console.print(f"[dim]Available connections: {available}[/dim]")
    raise typer.Exit(1)


def _prompt_for_connection(connections: list[Connection]) -> Connection:
    """Prompt user to select a connection interactively.

    Args:
        connections: List of available connections

    Returns:
        The selected Connection

    Raises:
        typer.Exit: If selection fails
    """
    options = [
        (conn.name, conn.description or conn.label or "No description") for conn in connections
    ]

    selected_name = prompt_selection(
        "Select a connection to set as default",
        options,
        prompt_text="Connection number",
    )

    for conn in connections:
        if conn.name == selected_name:
            return conn

    console.print("[red]Failed to find selected connection.[/red]")
    raise typer.Exit(1)


@require_auth
def show_default() -> None:
    """Show the current default warehouse connection.

    Displays the stored default connection and validates it
    still exists on the server.
    """
    pref_manager = PreferenceManager()
    default_id = pref_manager.get_default_connection_id()

    if not default_id:
        console.print("[yellow]No default connection is currently set.[/yellow]")
        console.print("[dim]Use `kater config default-connection set` to set one.[/dim]")
        return

    # Try to validate the connection exists
    try:
        client = get_authenticated_client()
        connections = fetch_connections(client)

        # Find the connection
        for conn in connections:
            if str(conn.id) == default_id:
                console.print(f"[bold]Default connection:[/bold] {conn.name}")
                if conn.description:
                    console.print(f"[dim]Description:[/dim] {conn.description}")
                console.print(f"[dim]ID:[/dim] {default_id}")
                return

        # Connection not found - it was deleted
        console.print(f"[yellow]Default connection ID:[/yellow] {default_id}")
        console.print("[yellow]Warning: This connection no longer exists on the server.[/yellow]")
        console.print(
            "[dim]Run `kater config default-connection set` to choose a new default.[/dim]"
        )

    except typer.Exit:
        raise
    except (kater.APIConnectionError, kater.APITimeoutError):
        # API unreachable - show stored ID with warning
        console.print(f"[bold]Default connection ID:[/bold] {default_id}")
        console.print("[yellow](could not verify - API unreachable)[/yellow]")


def clear_default() -> None:
    """Clear the default warehouse connection.

    Removes the stored default connection preference.
    This command does not require authentication.
    """
    pref_manager = PreferenceManager()
    was_cleared = pref_manager.clear_default_connection()

    if was_cleared:
        console.print("[green]Default connection cleared.[/green]")
    else:
        console.print("[yellow]No default connection is currently set.[/yellow]")
