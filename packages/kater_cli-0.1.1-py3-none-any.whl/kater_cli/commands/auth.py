"""Authentication commands for the Kater CLI."""

import datetime

import typer
from rich.console import Console

from kater_cli.auth.oauth import run_oauth_flow
from kater_cli.auth.token_manager import TokenManager

console = Console()


def login() -> None:
    """Log in to Kater via browser-based OAuth."""
    token_manager = TokenManager()

    if token_manager.has_tokens():
        console.print("[yellow]You are already logged in.[/yellow]")
        console.print("Run `kater logout` first if you want to re-authenticate.")
        return

    success = run_oauth_flow()
    if not success:
        raise typer.Exit(1)


def logout() -> None:
    """Log out and clear stored credentials."""
    token_manager = TokenManager()

    if not token_manager.has_tokens():
        console.print("[yellow]You are not logged in.[/yellow]")
        return

    token_manager.clear_tokens()
    console.print("[green]Successfully logged out.[/green]")


def status() -> None:
    """Check authentication status without making an API call."""
    token_manager = TokenManager()
    is_authenticated, expires_at = token_manager.get_token_status()

    if not is_authenticated:
        console.print("[yellow]Not logged in.[/yellow]")
        console.print("Run `kater login` to authenticate.")
        return

    console.print("[green]Logged in.[/green]")

    if expires_at:
        expires_dt = datetime.datetime.fromtimestamp(expires_at, tz=datetime.UTC)
        now = datetime.datetime.now(tz=datetime.UTC)

        if expires_dt <= now:
            console.print("[yellow]Token expired. Will refresh on next API call.[/yellow]")
        else:
            delta = expires_dt - now
            if delta.total_seconds() < 300:
                console.print(f"[yellow]Token expires soon ({_format_timedelta(delta)}).[/yellow]")
            else:
                console.print(f"Token expires in {_format_timedelta(delta)}.")


def _format_timedelta(delta: datetime.timedelta) -> str:
    """Format a timedelta for display."""
    total_seconds = int(delta.total_seconds())
    if total_seconds < 60:
        return f"{total_seconds}s"
    minutes = total_seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    remaining_minutes = minutes % 60
    if remaining_minutes:
        return f"{hours}h {remaining_minutes}m"
    return f"{hours}h"
