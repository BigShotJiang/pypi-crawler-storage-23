"""kater dev command - syncs local files to Kater platform.

Story: 3-5-kater-dev-command-entry-point
Orchestrates file sync, WebSocket connection, and file watching.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from pathlib import Path

import typer
from rich.console import Console

from kater_cli.auth.token_manager import TokenManager, get_or_create_cli_id
from kater_cli.client import require_auth
from kater_cli.config import get_settings
from kater_cli.repo import find_repo_root
from kater_cli.services.dev_file_watcher import DevFileWatcher
from kater_cli.services.file_sync import FileEntry, FileSyncService
from kater_cli.services.ws_dev_client import AuthenticationError, WsDevClient

console = Console()


@require_auth
def dev(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
) -> None:
    """Sync your local files to the Kater platform.

    Establishes a WebSocket connection to sync repository files,
    then watches for changes and syncs them in real-time.
    """
    base_path = find_repo_root()

    # Get or create CLI identity
    cli_id = get_or_create_cli_id()
    console.print(f"[green]✓[/green] CLI ID: [bold]{cli_id}[/bold]")

    # Run the async event loop
    try:
        asyncio.run(_run_dev_session(base_path, cli_id, verbose))
    except AuthenticationError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        console.print("\n[yellow]Disconnected from Kater[/yellow]")


async def _run_dev_session(
    base_path: Path,
    cli_id: str,
    verbose: bool,
) -> None:
    """Main async loop for dev session.

    Args:
        base_path: Repository root directory.
        cli_id: CLI identity string.
        verbose: Whether to enable debug logging.
    """
    settings = get_settings()

    # Single TokenManager instance for both initial token and background refresh.
    # require_auth already verified a token exists before this is called.
    token_manager = TokenManager()
    access_token = token_manager.get_access_token()
    if not access_token:
        raise AuthenticationError("Session expired. Run `kater login` to re-authenticate.")

    file_sync = FileSyncService(base_path)
    ws_client = WsDevClient(
        settings.api_url, access_token, cli_id, token_provider=token_manager.get_access_token
    )
    file_watcher = DevFileWatcher(base_path, file_sync)

    # State for sync orchestration
    sync_state = {
        "connected": False,
        "cached_file_count": 0,
    }

    # Wire up callbacks
    def on_session_ready(received_cli_id: str, cached_count: int) -> None:
        sync_state["connected"] = True
        sync_state["cached_file_count"] = cached_count
        console.print("[green]✓[/green] Connected to Kater server")
        # Trigger sync decision in main loop
        asyncio.create_task(_perform_initial_sync(file_sync, ws_client, cached_count, verbose))

    def on_need_files(paths: list[str]) -> None:
        asyncio.create_task(_send_requested_files(file_sync, ws_client, paths))

    def on_sync_ack(status: str, path: str | None, file_count: int | None) -> None:
        if file_count is not None:
            _print_sync_summary(file_count, sync_state["cached_file_count"])

    def on_error(code: str, message: str) -> None:
        console.print(f"[red]Error ({code}): {message}[/red]")

    def on_file_changed(path: str, content: bytes, hash_: str) -> None:
        asyncio.create_task(_handle_file_change(ws_client, path, content, hash_, verbose))

    def on_file_deleted(path: str) -> None:
        asyncio.create_task(_handle_file_delete(ws_client, path, verbose))

    def on_branch_switched() -> None:
        asyncio.create_task(_handle_branch_switch(file_sync, ws_client, verbose))

    def on_write_back(
        request_id: str,
        connection_folder: str,
        files: list[dict[str, str]],
    ) -> None:
        asyncio.create_task(
            _handle_write_back(ws_client, base_path, request_id, connection_folder, files, verbose)
        )

    def on_reconnected() -> None:
        asyncio.create_task(_handle_branch_switch(file_sync, ws_client, verbose))

    # Set callbacks
    ws_client.on_session_ready = on_session_ready
    ws_client.on_need_files = on_need_files
    ws_client.on_sync_ack = on_sync_ack
    ws_client.on_error = on_error
    ws_client.on_write_back = on_write_back
    ws_client.on_reconnected = on_reconnected

    file_watcher.on_file_changed = on_file_changed
    file_watcher.on_file_deleted = on_file_deleted
    file_watcher.on_branch_switched = on_branch_switched

    # Start background token refresh to keep the token fresh for reconnections
    token_manager.start_background_refresh()

    try:
        # Connect and start receiving
        await ws_client.connect()
        await ws_client.send_connect()
        await ws_client.start()

        # Start file watcher
        await file_watcher.start()

        # Keep running until interrupted
        while True:
            await asyncio.sleep(1)

    finally:
        token_manager.stop_background_refresh()
        await file_watcher.stop()
        await ws_client.stop()


async def _perform_initial_sync(
    file_sync: FileSyncService,
    ws_client: WsDevClient,
    cached_count: int,
    verbose: bool = False,
) -> None:
    """Perform initial sync based on cached file count.

    Args:
        file_sync: File sync service.
        ws_client: WebSocket client.
        cached_count: Number of files cached on server.
        verbose: Whether to enable debug logging.
    """
    if verbose:
        console.print("[dim]Performing initial sync...[/dim]")

    if cached_count == 0:
        # Full sync - send all files
        files = file_sync.scan_repo()
        total_bytes = sum(len(f["content"]) for f in files)
        console.print(f"[green]✓[/green] Synced {len(files)} files ({_format_bytes(total_bytes)})")
        await ws_client.send_full_sync(files)
    else:
        # Delta sync - send manifest only
        manifest = file_sync.get_file_manifest()
        await ws_client.send_delta_sync(manifest)

    # Print banner
    console.print()
    console.print("  Your local files are now live on Kater.")
    console.print("  Any local changes will sync automatically.")
    console.print()
    console.print("  Press Ctrl+C to disconnect (your files will stay cached on the server).")
    console.print()
    console.print("Watching for changes...")


async def _send_requested_files(
    file_sync: FileSyncService,
    ws_client: WsDevClient,
    paths: list[str],
) -> None:
    """Send files requested by server after delta sync.

    Args:
        file_sync: File sync service.
        ws_client: WebSocket client.
        paths: File paths requested by server.
    """
    for path in paths:
        try:
            entry = file_sync.read_and_hash_file(path)
            await ws_client.send_file_sync(entry)
        except FileNotFoundError:
            # File may have been deleted since manifest was sent
            pass


async def _handle_file_change(
    ws_client: WsDevClient,
    path: str,
    content: bytes,
    hash_: str,
    verbose: bool = False,
) -> None:
    """Handle file change from watcher.

    Args:
        ws_client: WebSocket client.
        path: Relative file path.
        content: File content.
        hash_: SHA-256 hash.
        verbose: Whether to enable debug logging.
    """
    if verbose:
        console.print(f"[dim]Sending file sync: {path} ({len(content)} bytes)[/dim]")
    entry: FileEntry = {"path": path, "content": content, "hash": hash_}
    await ws_client.send_file_sync(entry)
    _print_file_change(path, "Changed")


async def _handle_file_delete(
    ws_client: WsDevClient,
    path: str,
    verbose: bool = False,
) -> None:
    """Handle file deletion from watcher.

    Args:
        ws_client: WebSocket client.
        path: Relative file path.
        verbose: Whether to enable debug logging.
    """
    if verbose:
        console.print(f"[dim]Sending file delete: {path}[/dim]")
    await ws_client.send_file_delete(path)
    _print_file_change(path, "Deleted")


async def _handle_write_back(
    ws_client: WsDevClient,
    base_path: Path,
    request_id: str,
    connection_folder: str,
    files: list[dict[str, str]],
    verbose: bool = False,
) -> None:
    """Handle write_back message by writing files to local filesystem.

    Args:
        ws_client: WebSocket client (for sending ack).
        base_path: Repository root directory.
        request_id: Write-back request ID for correlation.
        connection_folder: Connection folder prefix for file paths.
        files: List of dicts with 'path' and 'content' keys.
        verbose: Whether to enable debug logging.
    """
    files_written = 0
    success = True

    for file_info in files:
        file_path = file_info.get("path", "")
        content = file_info.get("content", "")

        if not file_path:
            continue

        # Build full path: base_path / connection_folder / file path
        if connection_folder:
            full_path = base_path / connection_folder / file_path
        else:
            full_path = base_path / file_path

        # Validate path doesn't escape repo root
        try:
            resolved = full_path.resolve()
            resolved.relative_to(base_path.resolve())
        except ValueError:
            console.print(f"[red]Write-back path traversal rejected: {file_path}[/red]")
            success = False
            continue

        try:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.write_text(content)
            files_written += 1
            if verbose:
                console.print(f"[dim]Write-back: {resolved.relative_to(base_path)}[/dim]")
        except OSError as e:
            console.print(f"[red]Write-back failed for {file_path}: {e}[/red]")
            success = False

    # Send acknowledgment
    await ws_client.send_write_ack(request_id, success, files_written)

    if verbose or files_written > 0:
        timestamp = datetime.now().strftime("%H:%M:%S")
        console.print(
            f"  [{timestamp}] Write-back: {files_written} file(s) written "
            f"(request_id={request_id[:8]}...)"
        )


async def _handle_branch_switch(
    file_sync: FileSyncService,
    ws_client: WsDevClient,
    verbose: bool = False,
) -> None:
    """Handle branch switch by triggering delta sync.

    Args:
        file_sync: File sync service.
        ws_client: WebSocket client.
        verbose: Whether to enable debug logging.
    """
    console.print("[dim]Branch switch detected, syncing...[/dim]")
    manifest = file_sync.get_file_manifest()
    if verbose:
        console.print(f"[dim]Sending delta sync with {len(manifest)} files[/dim]")
    await ws_client.send_delta_sync(manifest)


def _print_file_change(path: str, action: str) -> None:
    """Print file change with timestamp.

    Args:
        path: Relative file path.
        action: Action type (Changed, Deleted).
    """
    timestamp = datetime.now().strftime("%H:%M:%S")
    console.print(f"  [{timestamp}] {action}: {path} — synced")


def _print_sync_summary(file_count: int, cached_count: int) -> None:
    """Print sync summary for delta sync.

    Args:
        file_count: Number of files synced.
        cached_count: Number of files that were already cached.
    """
    if cached_count > 0:
        # Ensure unchanged count is never negative (more files synced than cached = new files added)
        unchanged = max(0, cached_count - file_count)
        console.print(
            f"[green]✓[/green] Resuming session — synced {file_count} changed files, "
            f"{unchanged} unchanged"
        )


def _format_bytes(size: int) -> str:
    """Format byte size for display.

    Args:
        size: Size in bytes.

    Returns:
        Human-readable size string.
    """
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    else:
        return f"{size / (1024 * 1024):.1f} MB"
