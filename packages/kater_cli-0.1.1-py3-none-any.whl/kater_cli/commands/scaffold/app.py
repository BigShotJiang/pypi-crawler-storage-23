"""Scaffold subcommand group for creating Kater project structures."""

from __future__ import annotations

import typer

from kater_cli.commands.scaffold.topic import scaffold_topic

scaffold_app = typer.Typer(
    name="scaffold",
    help="Scaffold Kater project structures.",
    no_args_is_help=True,
)

scaffold_app.command(
    name="topic", help="Create a new topic directory with standard subdirectories."
)(scaffold_topic)
