"""Command for scaffolding a new topic directory."""

from __future__ import annotations

import uuid

import typer
from rich.console import Console

from kater_cli.repo import find_connection_folder_local, find_repo_root

console = Console()

_TOPIC_SUBDIRS = ("queries", "query_views", "dashboards", "reportflows")

_TOPIC_YAML_TEMPLATE = """\
kater_id: {kater_id}
name: {topic_name}
description: ''

join_graph:
  views: []
  joins: []
"""


def scaffold_topic(
    name: str = typer.Argument(
        help="Topic name (e.g. 'compliance' or 'hr_analytics').",
    ),
    connection: str = typer.Option(
        ...,
        "--connection",
        "-c",
        help="Connection name (matches the 'name' field in connection.yaml).",
    ),
) -> None:
    """Create a new topic directory with topic.yaml and empty subdirectories.

    Creates the following structure under {connection}/topics/{name}/
    (where {connection} is the folder whose connection.yaml has name={connection}):
      - topic.yaml (with generated kater_id)
      - queries/
      - query_views/
      - dashboards/
      - reportflows/

    Examples:

        kater scaffold topic compliance -c snowflake_prod
        kater scaffold topic hr_analytics -c demo
    """
    repo_root = find_repo_root()

    try:
        connection_path = find_connection_folder_local(repo_root, connection)
    except FileNotFoundError:
        console.print(f"[red]No connection folder found for '{connection}' in {repo_root}.[/red]")
        raise typer.Exit(1)

    topic_path = connection_path / "topics" / name
    if topic_path.exists():
        console.print(f"[red]Topic '{name}' already exists at {topic_path}.[/red]")
        raise typer.Exit(1)

    # Create topic directory
    topic_path.mkdir(parents=True, exist_ok=True)

    # Create topic.yaml
    topic_yaml = _TOPIC_YAML_TEMPLATE.format(
        kater_id=str(uuid.uuid4()),
        topic_name=name,
    )
    (topic_path / "topic.yaml").write_text(topic_yaml)

    # Create empty subdirectories with .gitkeep
    for subdir in _TOPIC_SUBDIRS:
        subdir_path = topic_path / subdir
        subdir_path.mkdir(parents=True, exist_ok=True)
        (subdir_path / ".gitkeep").write_text("")

    console.print(f"\n[green]✓[/green] Topic '{name}' scaffolded at {topic_path}")
    console.print("  [green]✓[/green] topic.yaml")
    for subdir in _TOPIC_SUBDIRS:
        console.print(f"  [green]✓[/green] {subdir}/")
