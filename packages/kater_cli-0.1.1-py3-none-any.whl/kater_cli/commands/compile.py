"""Command for compiling a query template to SQL."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import kater
import typer
import yaml
from rich.console import Console

from kater_cli.client import get_authenticated_client, require_auth
from kater_cli.commands._shared import (
    bare_query_name,
    display_compile_errors,
    display_ref_fixes,
    get_cli_id,
    handle_compile_api_error,
    normalize_query_ref,
    resolve_single_connection,
)
from kater_cli.repo import find_connection_folder_local, find_topic_folder_local, find_repo_root

console = Console()


def _discover_topic_queries(repo_root: Path, connection_name: str, topic_name: str) -> list[str]:
    """Discover all query names within a topic's queries/ directory.

    Returns a list of query names extracted from the 'name' field in each YAML file.
    """
    try:
        connection_path = find_connection_folder_local(repo_root, connection_name)
    except FileNotFoundError:
        console.print(
            f"[red]No connection folder found for '{connection_name}' in {repo_root}.[/red]"
        )
        raise typer.Exit(1)

    try:
        topic_path = find_topic_folder_local(connection_path, topic_name)
    except FileNotFoundError:
        console.print(
            f"[red]No topic folder found for '{topic_name}' under {connection_path}.[/red]"
        )
        raise typer.Exit(1)

    queries_dir = topic_path / "queries"

    if not queries_dir.is_dir():
        console.print(f"[red]No queries directory found at {queries_dir}[/red]")
        raise typer.Exit(1)

    query_names: list[str] = []
    for yaml_file in sorted(queries_dir.rglob("*.yaml")):
        try:
            data = yaml.safe_load(yaml_file.read_text())
            if isinstance(data, dict) and "name" in data:
                query_names.append(str(data["name"]))  # type: ignore[reportUnknownArgumentType]
        except yaml.YAMLError:
            console.print(f"[yellow]Warning: Could not parse {yaml_file}[/yellow]")

    if not query_names:
        console.print(f"[red]No queries found in topic '{topic_name}'[/red]")
        raise typer.Exit(1)

    return query_names


def _discover_folder_queries(repo_root: Path, folder_path: str) -> list[str]:
    """Discover query names from YAML files under a folder path.

    Lists all .yaml files recursively, filters to files that parse as
    query schemas (have a 'name' field), and returns query names.

    Args:
        repo_root: Repository root directory.
        folder_path: Relative folder path (e.g., 'topics/compliance/queries/').

    Returns:
        List of query names found.
    """
    target_dir = repo_root / folder_path

    if not target_dir.is_dir():
        console.print(f"[red]Directory not found: {target_dir}[/red]")
        raise typer.Exit(1)

    query_names: list[str] = []
    for yaml_file in sorted(target_dir.rglob("*.yaml")):
        try:
            data = yaml.safe_load(yaml_file.read_text())
            if isinstance(data, dict) and "name" in data:
                query_names.append(str(data["name"]))  # type: ignore[reportUnknownArgumentType]
        except yaml.YAMLError:
            console.print(f"[yellow]Warning: Could not parse {yaml_file}[/yellow]")

    if not query_names:
        console.print(f"[red]No queries found under '{folder_path}'[/red]")
        raise typer.Exit(1)

    return query_names


def resolve_query_args(
    repo_root: Path,
    queries: list[str] | None,
    topic: str | None,
    connection_name: str,
) -> list[str]:
    """Resolve query arguments into a flat list of query names.

    Handles: single names, multiple names, folder paths, and --topic flag.
    """
    if topic:
        return _discover_topic_queries(repo_root, connection_name, topic)

    if not queries:
        console.print(
            "[red]Provide a query name, folder path, or use --topic to compile all queries in a topic.[/red]"
        )
        raise typer.Exit(1)

    all_names: list[str] = []
    for arg in queries:
        # Check if it's a folder path (ends with / or is an existing directory)
        if arg.endswith("/") or (repo_root / arg).is_dir():
            all_names.extend(_discover_folder_queries(repo_root, arg))
        else:
            all_names.append(arg)

    return all_names


@require_auth
def compile_query(
    query: Optional[list[str]] = typer.Argument(
        None,
        help=(
            "Query name(s) or folder path(s). "
            "Examples: COMPLIANCE_OVERVIEW, topics/compliance/queries/"
        ),
    ),
    connection: str | None = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection name. Auto-selected if only one exists.",
    ),
    topic: str | None = typer.Option(
        None,
        "--topic",
        help="Topic name. Compiles all queries within the specified topic.",
    ),
    branch: str | None = typer.Option(
        None,
        "--branch",
        "-b",
        help="Git branch to compile from (alternative to running kater dev).",
    ),
    tenant: str | None = typer.Option(
        None,
        "--tenant",
        "-t",
        help="Tenant key for multi-tenant compilation.",
    ),
    combination: str | None = typer.Option(
        None,
        "--combination",
        help=(
            "Comma-separated slot selections and variable assignments. "
            "Reserved keys: measure, dimension, filter, calculation. "
            "Example: 'measure=Compliance Rate,dimension=Department,breakdown=region'"
        ),
    ),
    sample: int | None = typer.Option(
        None,
        "--sample",
        help="Auto-select N combinations per query via enumerate. Ignored if --combination is set.",
    ),
    no_auto_fix: bool = typer.Option(
        False,
        "--no-auto-fix",
        help="Disable automatic ref fixing on renames.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
) -> None:
    """Compile a query template to SQL.

    Resolves a query template and compiles it to SQL. Output files
    are dispatched via the write-back protocol to the kater-dev session.

    Accepts multiple query names, folder paths, or --topic for batch compilation.

    Examples:

        # Compile with active dev session
        kater compile COMPLIANCE_OVERVIEW

        # Compile multiple queries
        kater compile COMPLIANCE_OVERVIEW COMPLIANCE_TREND

        # Compile all queries in a folder
        kater compile topics/compliance/queries/

        # Compile all queries in a topic
        kater compile --topic compliance -c snowflake_prod

        # Compile from a git branch
        kater compile COMPLIANCE_OVERVIEW --branch main

        # Compile with auto-selected combinations
        kater compile COMPLIANCE_OVERVIEW --sample=1

        # Compile with specific measures and dimensions
        kater compile COMPLIANCE_OVERVIEW --combination 'measure=total_count,dimension=department'
    """
    repo_root = find_repo_root()

    if verbose:
        console.print(f"[dim]Repository root: {repo_root}[/dim]")

    try:
        client = get_authenticated_client()

        # Resolve file source
        cli_id: str | None = None
        if branch:
            if verbose:
                console.print(f"[dim]Using branch: {branch}[/dim]")
        else:
            cli_id = get_cli_id()
            if cli_id is None:
                console.print(
                    "[red]No active dev session. Run `kater dev` or use `--branch <branch>`.[/red]"
                )
                raise typer.Exit(1)
            if verbose:
                console.print(f"[dim]Using dev session: {cli_id}[/dim]")

        # Resolve single connection
        conn = resolve_single_connection(client, connection)
        if verbose:
            console.print(f"[dim]Using connection: {conn.name}[/dim]")

        # Resolve query arguments into flat list
        query_names = resolve_query_args(repo_root, query, topic, conn.name)

        if verbose:
            console.print(f"[dim]Compiling {len(query_names)} query(ies)[/dim]")

        # Build shared SDK kwargs for file source
        source_kwargs: dict[str, Any] = {}
        if branch:
            source_kwargs["source"] = branch
        if cli_id:
            source_kwargs["x_kater_cli_id"] = cli_id

        failed_queries: list[str] = []

        for current_query in query_names:
            # Normalize query ref
            query_ref = normalize_query_ref(current_query)
            q_name = bare_query_name(current_query)

            if len(query_names) > 1:
                console.print(f"\n[bold]Compiling {current_query}...[/bold]")

            # Determine combinations to compile
            combinations_to_compile: list[str | None] = [combination]

            if sample and not combination:
                # Enumerate combinations and select first N
                if verbose:
                    console.print(f"[dim]Enumerating combinations (sample={sample})...[/dim]")
                enum_result = client.v1.compiler.enumerate(
                    connection_id=conn.id,
                    query_refs=[query_ref],
                    **source_kwargs,
                )
                combos = enum_result.combinations or []
                selected = combos[:sample]
                if selected:
                    combinations_to_compile = []
                    for combo in selected:
                        # Build combination string from selected fields
                        parts: list[str] = []
                        for dim in combo.selected_dimensions or []:
                            parts.append(f"dimension={dim}")
                        for meas in combo.selected_measures or []:
                            parts.append(f"measure={meas}")
                        for calc in combo.selected_calculations or []:
                            parts.append(f"calculation={calc}")
                        for filt in combo.selected_filters or []:
                            parts.append(f"filter={filt}")
                        for var_name, var_val in (combo.variable_assignments or {}).items():
                            parts.append(f"{var_name}={var_val}")
                        combinations_to_compile.append(",".join(parts) if parts else None)
                    if verbose:
                        console.print(
                            f"[dim]Selected {len(combinations_to_compile)} combination(s)[/dim]"
                        )

            for combo_str in combinations_to_compile:
                # Build resolve kwargs
                resolve_kwargs: dict[str, Any] = {}
                if combo_str:
                    resolve_kwargs["combination"] = combo_str
                resolve_kwargs["auto_fix"] = not no_auto_fix

                # Step 1: Resolve query template
                if verbose:
                    console.print("[dim]Resolving query template...[/dim]")

                resolve_result = client.v1.compiler.resolve(
                    connection_id=conn.id,
                    query_ref=query_ref,
                    **resolve_kwargs,
                    **source_kwargs,
                )

                # Display auto-fixed refs from resolve (write-back handles file writes)
                ref_fixes = getattr(resolve_result, "ref_fixes", None)
                if ref_fixes:
                    display_ref_fixes(ref_fixes)

                # Step 2: Compile to SQL
                if verbose:
                    console.print("[dim]Compiling to SQL...[/dim]")

                compile_kwargs: dict[str, Any] = {
                    "connection_id": conn.id,
                    "resolved_query": resolve_result.resolved_query,
                    **source_kwargs,
                }
                if tenant:
                    compile_kwargs["tenant_key"] = tenant

                compile_result = client.v1.compiler.compile(**compile_kwargs)

                if compile_result.success:
                    request_id = getattr(compile_result, "request_id", None)
                    combo_label = f" [{combo_str}]" if combo_str else ""
                    console.print(
                        f"\n[green]✓[/green] Compilation succeeded ({q_name}{combo_label})"
                    )
                    if request_id:
                        console.print("  [dim]Output files dispatched via write-back[/dim]")
                    if verbose and compile_result.sql:
                        console.print(f"  [dim]SQL length: {len(compile_result.sql)} chars[/dim]")
                else:
                    display_compile_errors(compile_result.errors or [])
                    failed_queries.append(current_query)

        if failed_queries:
            console.print(
                f"\n[red]✗[/red] {len(failed_queries)} query(ies) failed to compile: "
                + ", ".join(failed_queries)
            )
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        handle_compile_api_error(e)
    except TypeError as e:
        if "authentication" in str(e).lower():
            console.print("[red]Authentication failed. Run `kater login` to re-authenticate.[/red]")
            raise typer.Exit(1)
        raise
