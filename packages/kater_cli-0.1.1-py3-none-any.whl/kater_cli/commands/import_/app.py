"""Import command group for Kater CLI."""

import typer

from kater_cli.commands.import_.tenants import tenants

import_app = typer.Typer(
    name="import",
    help="Import data into Kater (tenants, etc.).",
    no_args_is_help=True,
)

import_app.command(
    name="tenants",
    help="Import tenants from a warehouse table or CSV file.",
)(tenants)
