"""Command for initializing a Kater project in a local directory."""

import webbrowser
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from kater_cli.config import get_settings
from kater_utils.scaffold_templates import build_root_scaffold_items

console = Console()

_BANNER = """\

            #####
          #########
     ###################
   #######################
  #########################
  #########  ###  #########
   ########  ###  ########
    #######  ###  #######
      #####  ###  #####
      #################
      #################
      #################
       ###############
                          """

_FILE_DESCRIPTIONS: dict[str, str] = {
    "kater.config.yaml": "Project configuration",
    "README.md": "Getting started guide",
    ".gitignore": "Runtime directory exclusions",
    "kater-globals.css": "Default CSS theme variables",
    "kater-chart-theme.yaml": "Chart rendering defaults",
    "layout.yaml": "App layout & branding config",
    "_admin/query_policy.yaml": "AI query modes & global limits",
    "_admin/integrations.yaml": "External integration config",
    "_admin/grants/access_filters.yaml": "Row-level security filters",
    "_admin/grants/access_grants.yaml": "Permission grants",
    "_admin/grants/attributes.yaml": "User & tenant attributes",
}


def _print_banner() -> None:
    content = Text.assemble(
        Text("  Welcome to ", style="#DF644A"),
        Text("Kater!\n", style="bold #DF644A"),
        Text(_BANNER, style="bold white"),
    )
    console.print(Panel(content, border_style="#DF644A", padding=(0, 2), expand=False))
    console.print()


def _print_file_preview(items: list[tuple[str, str]], target_dir: Path) -> None:
    table = Table(
        show_header=True,
        header_style="bold dim",
        border_style="dim",
        box=None,
        padding=(0, 2, 0, 0),
    )
    table.add_column("File", no_wrap=True, min_width=38)
    table.add_column("Description", style="dim")
    table.add_column("", justify="right", no_wrap=True, min_width=14)

    for rel_path, _ in items:
        desc = _FILE_DESCRIPTIONS.get(rel_path, "")
        if (target_dir / rel_path).exists():
            table.add_row(
                f"[dim]{rel_path}[/dim]",
                f"[dim]{desc}[/dim]",
                "[yellow]already exists[/yellow]",
            )
        else:
            table.add_row(
                f"[green]{rel_path}[/green]",
                desc,
                "[dim green]will create[/dim green]",
            )

    console.print(table)


def install(
    path: str | None = typer.Option(
        None,
        "--path",
        "-p",
        help="Target directory. Defaults to current working directory.",
    ),
) -> None:
    """Initialize a Kater project in the current (or specified) directory."""
    settings = get_settings()

    # ── Banner ────────────────────────────────────────────────────────────────
    _print_banner()

    # ── Resolve target directory ──────────────────────────────────────────────
    target_dir = Path(path).resolve() if path else Path.cwd()

    console.print(f"  [dim]Directory:[/dim] [bold]{target_dir}[/bold]")
    console.print()

    confirmed = typer.confirm("Initialize Kater here?", default=True)
    if not confirmed:
        override = typer.prompt("Enter path")
        target_dir = Path(override).resolve()
        console.print()

    if not target_dir.exists():
        create = typer.confirm(f"Directory does not exist. Create {target_dir}?", default=True)
        if not create:
            raise typer.Exit(0)
        target_dir.mkdir(parents=True, exist_ok=True)

    if not target_dir.is_dir():
        console.print(f"\n[red]Error:[/red] Not a directory: {target_dir}")
        raise typer.Exit(1)

    if (target_dir / "kater.config.yaml").exists():
        console.print(
            f"\n[red]Error:[/red] [bold]{target_dir.name}[/bold] is already a Kater project "
            "(kater.config.yaml already exists)."
        )
        raise typer.Exit(1)

    # ── File preview ──────────────────────────────────────────────────────────
    items = build_root_scaffold_items(target_dir.name)
    new_items = [(p, c) for p, c in items if not (target_dir / p).exists()]

    console.print()
    console.print(Rule("[dim]Files to create[/dim]"))
    console.print()
    _print_file_preview(items, target_dir)
    console.print()

    if not new_items:
        console.print("[yellow]All files already exist — nothing to do.[/yellow]")
        raise typer.Exit(0)

    count = len(new_items)
    typer.confirm(
        f"Create {count} file{'s' if count != 1 else ''}?",
        default=True,
        abort=True,
    )
    console.print()

    # ── Scaffold with animated progress ───────────────────────────────────────
    created: list[str] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=False,
        console=console,
    ) as progress:
        task = progress.add_task("Installing...", total=len(new_items))

        for rel_path, content in new_items:
            progress.update(task, description=f"Creating [bold]{rel_path}[/bold]")
            dest = target_dir / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(content, encoding="utf-8")
            created.append(rel_path)
            progress.advance(task)
            progress.print(f"  [green]✓[/green] {rel_path}")

        progress.update(task, description="[green bold]Done![/green bold]")

    # ── Success panel ─────────────────────────────────────────────────────────
    console.print()
    console.print(
        Panel(
            Text.assemble(
                Text("  Project:  ", style="dim"),
                Text(target_dir.name, style="bold"),
                "\n",
                Text("  Location: ", style="dim"),
                Text(str(target_dir), style=""),
                "\n\n",
                Text("  Next steps:\n", style="bold"),
                Text("  1. ", style="dim"),
                Text("Complete signup at kater.ai\n"),
                Text("  2. ", style="dim"),
                Text("Connect your data warehouse\n"),
                Text("  3. ", style="dim"),
                Text("Run "),
                Text("kater dev", style="bold cyan"),
                Text(" to sync your files"),
            ),
            title="[bold green]✓  Project ready![/bold green]",
            border_style="green",
            padding=(1, 2),
        )
    )

    # ── Browser prompt ────────────────────────────────────────────────────────
    console.print()
    open_browser = typer.confirm("Open browser to complete signup on kater.ai?", default=True)
    if open_browser:
        console.print("[dim]Opening browser...[/dim]")
        webbrowser.open(settings.signup_url)
    else:
        console.print(f"[dim]Sign up later at:[/dim] {settings.signup_url}")
