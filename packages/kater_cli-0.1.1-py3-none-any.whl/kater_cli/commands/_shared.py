"""Shared utilities for CLI commands."""

from __future__ import annotations

import sys
from collections.abc import Sequence
from typing import Any, cast

import kater
import typer
from kater.types.v1 import Connection
from rich.console import Console

import keyring

from kater_cli.auth.token_manager import CLI_ID_KEY
from kater_cli.config import get_settings
from kater_cli.preferences.preference_manager import PreferenceManager
from kater_cli.prompts import prompt_selection

console = Console()


def get_cli_id() -> str | None:
    """Get CLI ID from keyring without creating a new one."""
    settings = get_settings()
    return keyring.get_password(settings.keyring_service, CLI_ID_KEY)


def fetch_connections(client: kater.Kater) -> list[Connection]:
    """Fetch all connections from the API."""
    try:
        return list(client.v1.connections.list_connections())
    except kater.AuthenticationError:
        console.print("[red]Session expired. Run `kater login` to re-authenticate.[/red]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        console.print(f"[red]Error fetching connections: {e.message}[/red]")
        raise typer.Exit(1)


def resolve_connection_ids(
    client: kater.Kater,
    connection_names: list[str] | None,
) -> list[str] | None:
    """Resolve --connection names to connection IDs.

    Returns None if all connections should be validated.
    """
    if not connection_names:
        connections = fetch_connections(client)
        if not connections:
            console.print("[red]No connections found.[/red]")
            raise typer.Exit(1)

        if len(connections) == 1:
            return [connections[0].id]

        # Interactive mode: prompt user to select
        if sys.stdout.isatty():
            options: list[tuple[str, str]] = [
                ("__all__", "Validate all connections"),
            ]
            for conn in connections:
                options.append((conn.id, conn.description or conn.name))

            selected = prompt_selection(
                "Select connections to validate",
                options,
                prompt_text="Selection",
            )
            if selected == "__all__":
                return None
            return [selected]

        # Non-interactive: validate all
        return None

    # Resolve names to IDs
    connections = fetch_connections(client)
    conn_by_name = {c.name.lower(): c for c in connections}
    resolved_ids: list[str] = []

    for name in connection_names:
        conn = conn_by_name.get(name.lower())
        if conn is None:
            available = ", ".join(c.name for c in connections)
            console.print(
                f"[red]Connection '{name}' not found. Available connections: {available}[/red]"
            )
            raise typer.Exit(1)
        resolved_ids.append(conn.id)

    return resolved_ids


def resolve_single_connection(
    client: kater.Kater,
    connection_name: str | None,
) -> Connection:
    """Resolve a single connection for commands that operate on one connection.

    Priority order:
    1. --connection flag (explicit name)
    2. Only 1 connection exists -> auto-select
    3. Default connection via PreferenceManager
    4. Interactive prompt (if TTY)
    5. Error with available names (non-interactive, no default)
    """
    connections = fetch_connections(client)
    if not connections:
        console.print("[red]No connections found.[/red]")
        raise typer.Exit(1)

    conn_by_name = {c.name.lower(): c for c in connections}

    # 1. Explicit --connection flag
    if connection_name:
        conn = conn_by_name.get(connection_name.lower())
        if conn is None:
            available = ", ".join(c.name for c in connections)
            console.print(
                f"[red]Connection '{connection_name}' not found. "
                f"Available connections: {available}[/red]"
            )
            raise typer.Exit(1)
        return conn

    # 2. Only one connection -> auto-select
    if len(connections) == 1:
        return connections[0]

    # 3. Default connection from preferences
    prefs = PreferenceManager()
    default_id = prefs.get_default_connection_id()
    if default_id:
        for conn in connections:
            if conn.id == default_id:
                return conn

    # 4. Interactive prompt (if TTY)
    if sys.stdout.isatty():
        options: list[tuple[str, str]] = []
        for conn in connections:
            options.append((conn.id, conn.description or conn.name))

        selected_id = prompt_selection(
            "Select a connection",
            options,
            prompt_text="Selection",
        )
        for conn in connections:
            if conn.id == selected_id:
                return conn

    # 5. Non-interactive, no default -> error
    available = ", ".join(c.name for c in connections)
    console.print(
        f"[red]Multiple connections available: {available}. Use --connection to specify one.[/red]"
    )
    raise typer.Exit(1)


def parse_error_body(e: kater.BadRequestError) -> tuple[str | None, str | None]:
    """Extract the error code and message from a BadRequestError body."""
    raw_body: object | None = e.body
    body = cast(dict[str, Any], raw_body) if isinstance(raw_body, dict) else None
    if body is not None:
        return cast(str | None, body.get("code")), cast(str | None, body.get("message"))
    return None, None


def handle_api_error(e: kater.APIStatusError, *, context: str = "operation") -> None:
    """Handle common API errors with a configurable context label."""
    if isinstance(e, kater.AuthenticationError):
        console.print("[red]Session expired. Run `kater login` to re-authenticate.[/red]")
        raise typer.Exit(1)

    if isinstance(e, kater.BadRequestError):
        code, _ = parse_error_body(e)
        if code == "DEV_SESSION_NOT_FOUND":
            console.print(
                "[red]Dev session not found. Run `kater dev` first or use `--branch`.[/red]"
            )
            raise typer.Exit(1)
        if code == "FILE_SOURCE_CONFLICT":
            console.print(
                "[red]Cannot use both dev session and --branch. "
                "Stop `kater dev` or omit --branch.[/red]"
            )
            raise typer.Exit(1)

    if isinstance(e, kater.NotFoundError):
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    console.print(f"[red]Unexpected error during {context}: {e.message}[/red]")
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Query-ref helpers
# ---------------------------------------------------------------------------


def normalize_query_ref(query: str) -> str:
    """Ensure the query reference has the q: prefix."""
    if query.startswith("q:"):
        return query
    return f"q:{query}"


def bare_query_name(query: str) -> str:
    """Strip the q: prefix for file naming."""
    if query.startswith("q:"):
        return query[2:]
    return query


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def display_ref_fixes(ref_fixes: Sequence[Any]) -> None:
    """Display auto-fix summary using Rich output."""
    total_replacements = sum(len(fix.replacements) for fix in ref_fixes)
    total_files = len(ref_fixes)

    console.print(
        f"\n[green]✓[/green] Auto-fixed {total_replacements} ref(s) "
        f"across {total_files} file(s) due to renames:\n"
    )
    for fix in ref_fixes:
        for replacement in fix.replacements:
            console.print(
                f"  {replacement.file_path}:{replacement.line_number} "
                f"[red]{replacement.old_ref}[/red] → [green]{replacement.new_ref}[/green]"
            )


def display_compile_errors(errors: Sequence[Any]) -> None:
    """Display compilation errors in a formatted output."""
    count = len(errors)
    label = "error" if count == 1 else "errors"
    console.print(f"\n[red]✗[/red] Compilation failed ({count} {label})\n")

    for error in errors:
        location = ""
        file_val = getattr(error, "file", None)
        if file_val:
            location = f" {file_val}"
            line_val = getattr(error, "line", None)
            if line_val is not None:
                location += f":{line_val}"
                col_val = getattr(error, "column", None)
                if col_val is not None:
                    location += f":{col_val}"

        code = getattr(error, "code", "UNKNOWN")
        message = getattr(error, "message", str(error))
        remediation = getattr(error, "remediation", None)

        console.print(f"    [red][{code}]{location}[/red]")
        console.print(f"      {message}")
        if remediation:
            console.print(f"      [dim]→ {remediation}[/dim]")


def handle_compile_api_error(e: kater.APIStatusError) -> None:
    """Handle API errors for compile/run commands.

    Catches SCHEMA_PARSE_ERROR for custom display, then delegates to shared handler.
    """
    if isinstance(e, kater.BadRequestError):
        code, message = parse_error_body(e)
        if code == "SCHEMA_PARSE_ERROR" and message:
            console.print(f"\n[red]✗[/red] Schema parse error: {message}")
            raise typer.Exit(1)

    handle_api_error(e, context="compilation")
