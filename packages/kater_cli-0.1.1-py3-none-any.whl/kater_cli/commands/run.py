"""Command for executing a compiled query and displaying results."""

from __future__ import annotations

from typing import Any, Optional

import kater
import typer
from kater.types.v1 import CompilerExecuteResponse
from rich.console import Console
from rich.table import Table

from kater_cli.client import get_authenticated_client, require_auth
from kater_cli.commands._shared import (
    bare_query_name,
    display_compile_errors,
    display_ref_fixes,
    get_cli_id,
    handle_compile_api_error,
    normalize_query_ref,
    resolve_single_connection,
)
from kater_cli.commands.compile import resolve_query_args
from kater_cli.repo import find_repo_root

console = Console()


def _display_execute_results(
    result: CompilerExecuteResponse,
    *,
    limit: int | None = None,
) -> None:
    """Display query execution results as a Rich table."""
    data = result.data or []
    column_map = result.column_map or []
    row_count = result.row_count or len(data)
    execution_time = result.execution_time_ms
    cache_hit = result.cache_hit

    if not data:
        console.print("\n[dim]No rows returned.[/dim]")
        _display_summary(row_count=0, execution_time=execution_time, cache_hit=cache_hit)
        return

    # Build a mapping from kater_id → human-readable name
    id_to_name: dict[str, str] = {}
    for col in column_map:
        id_to_name[col.kater_id] = col.label or col.name

    # Determine column order from the first data row
    raw_columns = list(data[0].keys())
    display_columns = [id_to_name.get(col, col) for col in raw_columns]

    table = Table(show_header=True, header_style="bold")
    for col_name in display_columns:
        table.add_column(col_name or "")

    # Apply limit for display
    display_data = data
    truncated = False
    if limit is not None and limit < len(data):
        display_data = data[:limit]
        truncated = True

    for row in display_data:
        table.add_row(*[str(v) if v is not None else "" for v in row.values()])

    console.print()
    console.print(table)

    if truncated:
        console.print(f"\n[dim]Showing {limit} of {row_count} rows (use --limit to adjust)[/dim]")

    _display_summary(row_count=row_count, execution_time=execution_time, cache_hit=cache_hit)


def _display_summary(
    *,
    row_count: int,
    execution_time: float | None,
    cache_hit: bool | None,
) -> None:
    """Display execution summary line."""
    parts: list[str] = []
    row_label = "row" if row_count == 1 else "rows"
    parts.append(f"{row_count} {row_label}")
    if execution_time is not None:
        parts.append(f"{execution_time:.0f}ms")
    if cache_hit is not None:
        parts.append("cache hit" if cache_hit else "cache miss")
    console.print(f"\n[dim]{' · '.join(parts)}[/dim]")


@require_auth
def run_query(
    query: Optional[list[str]] = typer.Argument(
        None,
        help=(
            "Query name(s) or folder path(s). "
            "Examples: COMPLIANCE_OVERVIEW, topics/compliance/queries/"
        ),
    ),
    connection: str | None = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection name. Auto-selected if only one exists.",
    ),
    topic: str | None = typer.Option(
        None,
        "--topic",
        help="Topic name. Runs all queries within the specified topic.",
    ),
    branch: str | None = typer.Option(
        None,
        "--branch",
        "-b",
        help="Git branch to run from (alternative to running kater dev).",
    ),
    tenant: str | None = typer.Option(
        None,
        "--tenant",
        "-t",
        help="Tenant key for multi-tenant execution.",
    ),
    combination: str | None = typer.Option(
        None,
        "--combination",
        help=(
            "Comma-separated slot selections and variable assignments. "
            "Reserved keys: measure, dimension, filter, calculation. "
            "Example: 'measure=Compliance Rate,dimension=Department,breakdown=region'"
        ),
    ),
    sample: int | None = typer.Option(
        None,
        "--sample",
        help="Auto-select N combinations per query via enumerate. Ignored if --combination is set.",
    ),
    no_auto_fix: bool = typer.Option(
        False,
        "--no-auto-fix",
        help="Disable automatic ref fixing on renames.",
    ),
    limit: int | None = typer.Option(
        None,
        "--limit",
        "-n",
        help="Limit the number of rows displayed.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
) -> None:
    """Execute a query template and display results.

    Resolves, compiles, and executes a query template, then displays
    the results as a table. Output files are dispatched via write-back.

    Accepts multiple query names, folder paths, or --topic for batch execution.

    Examples:

        # Run with active dev session
        kater run COMPLIANCE_OVERVIEW

        # Run multiple queries
        kater run COMPLIANCE_OVERVIEW COMPLIANCE_TREND

        # Run all queries in a folder with sampling
        kater run topics/compliance/queries/ --sample=1

        # Run with a specific connection
        kater run COMPLIANCE_OVERVIEW -c snowflake_prod

        # Run from a git branch
        kater run COMPLIANCE_OVERVIEW --branch main

        # Run with tenant key
        kater run COMPLIANCE_OVERVIEW --tenant acme_corp

        # Limit displayed rows
        kater run COMPLIANCE_OVERVIEW --limit 10

        # Run with specific measures and dimensions
        kater run COMPLIANCE_OVERVIEW --combination 'measure=total_count,dimension=department'
    """
    repo_root = find_repo_root()

    if verbose:
        console.print(f"[dim]Repository root: {repo_root}[/dim]")

    try:
        client = get_authenticated_client()

        # Resolve file source
        cli_id: str | None = None
        if branch:
            if verbose:
                console.print(f"[dim]Using branch: {branch}[/dim]")
        else:
            cli_id = get_cli_id()
            if cli_id is None:
                console.print(
                    "[red]No active dev session. Run `kater dev` or use `--branch <branch>`.[/red]"
                )
                raise typer.Exit(1)
            if verbose:
                console.print(f"[dim]Using dev session: {cli_id}[/dim]")

        # Resolve single connection
        conn = resolve_single_connection(client, connection)
        if verbose:
            console.print(f"[dim]Using connection: {conn.name}[/dim]")

        # Resolve query arguments into flat list
        query_names = resolve_query_args(repo_root, query, topic, conn.name)

        if verbose:
            console.print(f"[dim]Running {len(query_names)} query(ies)[/dim]")

        # Build shared SDK kwargs for file source
        source_kwargs: dict[str, Any] = {}
        if branch:
            source_kwargs["source"] = branch
        if cli_id:
            source_kwargs["x_kater_cli_id"] = cli_id

        failed_queries: list[str] = []

        for current_query in query_names:
            query_ref = normalize_query_ref(current_query)
            q_name = bare_query_name(current_query)

            if len(query_names) > 1:
                console.print(f"\n[bold]Running {current_query}...[/bold]")

            # Determine combinations to run
            combinations_to_run: list[str | None] = [combination]

            if sample and not combination:
                if verbose:
                    console.print(f"[dim]Enumerating combinations (sample={sample})...[/dim]")
                enum_result = client.v1.compiler.enumerate(
                    connection_id=conn.id,
                    query_refs=[query_ref],
                    **source_kwargs,
                )
                combos = enum_result.combinations or []
                selected = combos[:sample]
                if selected:
                    combinations_to_run = []
                    for combo in selected:
                        parts: list[str] = []
                        for dim in combo.selected_dimensions or []:
                            parts.append(f"dimension={dim}")
                        for meas in combo.selected_measures or []:
                            parts.append(f"measure={meas}")
                        for calc in combo.selected_calculations or []:
                            parts.append(f"calculation={calc}")
                        for filt in combo.selected_filters or []:
                            parts.append(f"filter={filt}")
                        for var_name, var_val in (combo.variable_assignments or {}).items():
                            parts.append(f"{var_name}={var_val}")
                        combinations_to_run.append(",".join(parts) if parts else None)

            for combo_str in combinations_to_run:
                # Build resolve kwargs
                resolve_kwargs: dict[str, Any] = {}
                if combo_str:
                    resolve_kwargs["combination"] = combo_str
                resolve_kwargs["auto_fix"] = not no_auto_fix

                # Step 1: Resolve query template
                if verbose:
                    console.print("[dim]Resolving query template...[/dim]")

                resolve_result = client.v1.compiler.resolve(
                    connection_id=conn.id,
                    query_ref=query_ref,
                    **resolve_kwargs,
                    **source_kwargs,
                )

                # Display auto-fixed refs (write-back handles file writes)
                ref_fixes = getattr(resolve_result, "ref_fixes", None)
                if ref_fixes:
                    display_ref_fixes(ref_fixes)

                # Step 2: Execute query
                if verbose:
                    console.print("[dim]Executing query...[/dim]")

                execute_kwargs: dict[str, Any] = {
                    "connection_id": conn.id,
                    "resolved_query": resolve_result.resolved_query,
                    **source_kwargs,
                }
                if tenant:
                    execute_kwargs["tenant_key"] = tenant

                execute_result = client.v1.compiler.execute(**execute_kwargs)

                if execute_result.success:
                    combo_label = f" [{combo_str}]" if combo_str else ""
                    if len(query_names) > 1:
                        console.print(f"[green]✓[/green] {q_name}{combo_label}")
                    _display_execute_results(execute_result, limit=limit)
                else:
                    display_compile_errors(execute_result.errors or [])
                    failed_queries.append(current_query)

        if failed_queries:
            console.print(
                f"\n[red]✗[/red] {len(failed_queries)} query(ies) failed: "
                + ", ".join(failed_queries)
            )
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        handle_compile_api_error(e)
    except TypeError as e:
        if "authentication" in str(e).lower():
            console.print("[red]Authentication failed. Run `kater login` to re-authenticate.[/red]")
            raise typer.Exit(1)
        raise
