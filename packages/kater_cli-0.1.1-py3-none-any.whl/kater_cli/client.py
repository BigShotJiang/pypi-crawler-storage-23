"""Authenticated API client factory for the Kater CLI."""

from collections.abc import Callable
from functools import wraps
from typing import ParamSpec, TypeVar

import typer
from kater import DefaultHttpxClient, Kater
from rich.console import Console

from kater_cli.auth.token_manager import TokenManager, TokenRefreshAuth
from kater_cli.config import get_settings

console = Console()

P = ParamSpec("P")
R = TypeVar("R")


def get_authenticated_client() -> Kater:
    """Get an authenticated API client.

    Retrieves a valid access token (refreshing if needed) and creates
    a Kater client configured for the API with automatic token
    refresh on 401 responses.

    Raises:
        typer.Exit: If not logged in or token refresh failed.

    Returns:
        Configured Kater client instance.
    """
    token_manager = TokenManager()

    # Check if we have any tokens before creating the client
    if not token_manager.has_tokens():
        console.print("[red]Not logged in. Run `kater login` to authenticate.[/red]")
        raise typer.Exit(1)

    settings = get_settings()

    # Get the current access token for SDK header validation.
    # TokenRefreshAuth also sets the header at the httpx layer and
    # automatically refreshes the token on 401 responses.
    access_token = token_manager.get_access_token()
    if not access_token:
        console.print("[red]Session expired. Run `kater login` to re-authenticate.[/red]")
        raise typer.Exit(1)

    return Kater(
        base_url=settings.api_url,
        auth_token=access_token,
        http_client=DefaultHttpxClient(auth=TokenRefreshAuth(token_manager)),
    )


def require_auth(func: Callable[P, R]) -> Callable[P, R]:
    """Decorator for commands that require authentication.

    Checks for a valid token before running the command. If the token
    is missing or invalid, displays an error and exits.

    Usage:
        @app.command()
        @require_auth
        def my_command():
            client = get_authenticated_client()
            ...
    """

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        token_manager = TokenManager()
        token = token_manager.get_access_token()

        if not token:
            console.print("[red]Not logged in. Run `kater login` to authenticate.[/red]")
            raise typer.Exit(1)

        return func(*args, **kwargs)

    return wrapper
