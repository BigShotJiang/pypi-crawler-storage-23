"""File watcher for kater dev file sync.

Story: 3-4-file-watcher
Watches for file changes and branch switches to trigger sync.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable

import watchfiles
from watchfiles import Change

from kater_utils import get_logger

if TYPE_CHECKING:
    from kater_cli.services.file_sync import FileSyncService

logger = get_logger(__name__)

# Debounce time in milliseconds
DEBOUNCE_MS = 100


class DevFileWatcher:
    """Watches repository for file changes and branch switches.

    Handles:
    - File create/modify/delete events with debouncing
    - Hash comparison to suppress no-op events
    - .gitignore/.katerignore filtering
    - .git/HEAD monitoring for branch switches
    """

    def __init__(self, root_path: Path, file_sync: FileSyncService) -> None:
        """Initialize file watcher.

        Args:
            root_path: Repository root directory.
            file_sync: FileSyncService for ignore patterns and hashing.
        """
        self._root_path = root_path.resolve()
        self._file_sync = file_sync

        # State
        self._running = False
        self._watch_task: asyncio.Task[None] | None = None
        self._last_hashes: dict[str, str] = {}
        self._last_event_times: dict[str, float] = {}
        self._last_git_head: str | None = None

        # Cleanup threshold: prune event times older than 1 hour (in ms)
        self._event_time_ttl_ms: float = 60 * 60 * 1000

        # Callbacks - set by command layer
        self.on_file_changed: Callable[[str, bytes, str], None] | None = None
        self.on_file_deleted: Callable[[str], None] | None = None
        self.on_branch_switched: Callable[[], None] | None = None

    def _read_git_head(self) -> str | None:
        """Read current .git/HEAD ref.

        Returns:
            The contents of .git/HEAD (e.g., 'ref: refs/heads/main'),
            or None if the file doesn't exist or can't be read.
        """
        git_head = self._root_path / ".git" / "HEAD"
        if not git_head.exists():
            return None
        try:
            return git_head.read_text().strip()
        except OSError as e:
            logger.debug("git_head_read_failed", error=str(e))
            return None

    def _check_branch_switch(self) -> bool:
        """Check if branch has changed since last check.

        Returns:
            True if the branch changed, False otherwise.
        """
        current_head = self._read_git_head()
        if current_head != self._last_git_head:
            self._last_git_head = current_head
            return True
        return False

    def _should_process(self, path: str) -> bool:
        """Check if event should be processed based on debounce timing.

        Args:
            path: Relative file path.

        Returns:
            True if event should be processed (past debounce window).
        """
        now = time.monotonic() * 1000  # Convert to ms
        last_time = self._last_event_times.get(path, 0)

        if now - last_time < DEBOUNCE_MS:
            return False  # Skip, too soon

        self._last_event_times[path] = now

        # Periodic cleanup: remove stale entries older than TTL
        # Only run cleanup occasionally to avoid overhead on every event
        if len(self._last_event_times) > 1000:
            self._prune_stale_event_times(now)

        return True

    def _prune_stale_event_times(self, now: float) -> None:
        """Remove event time entries older than TTL to prevent memory leaks."""
        stale_keys = [
            k for k, v in self._last_event_times.items() if now - v > self._event_time_ttl_ms
        ]
        for k in stale_keys:
            del self._last_event_times[k]

    def _hash_changed(self, relative_path: str) -> tuple[bool, bytes | None, str | None]:
        """Check if file content has changed since last sync.

        Args:
            relative_path: Path relative to repo root.

        Returns:
            Tuple of (changed: bool, content: bytes | None, hash: str | None).
            If changed is False, content and hash will be None.
        """
        try:
            entry = self._file_sync.read_and_hash_file(relative_path)
            new_hash = entry["hash"]
            old_hash = self._last_hashes.get(relative_path)

            if new_hash == old_hash:
                return (False, None, None)  # No change

            self._last_hashes[relative_path] = new_hash
            return (True, entry["content"], new_hash)

        except FileNotFoundError:
            # File was deleted between event and read
            return (False, None, None)
        except OSError as e:
            # Permission denied, I/O errors, etc.
            logger.warning("hash_check_failed", path=relative_path, error=str(e))
            return (False, None, None)

    async def _process_change(self, change_type: Change, path_str: str) -> None:
        """Process a single file change event.

        Args:
            change_type: The type of change (added, modified, deleted).
            path_str: Absolute path to the changed file.
        """
        path = Path(path_str)

        # Check for .git/HEAD change (branch switch detection)
        if path.name == "HEAD" and ".git" in path.parts:
            if self._check_branch_switch() and self.on_branch_switched:
                self.on_branch_switched()
            return

        # Get relative path
        try:
            relative_path = path.relative_to(self._root_path).as_posix()
        except ValueError:
            # Path outside repo, skip
            return

        # Filter ignored files (using FileSyncService's ignore patterns)
        if self._file_sync.is_ignored(relative_path):
            return

        # Debounce
        if not self._should_process(relative_path):
            return

        if change_type == Change.deleted:
            if self.on_file_deleted:
                self.on_file_deleted(relative_path)
            # Clean up both caches to prevent memory leaks
            self._last_hashes.pop(relative_path, None)
            self._last_event_times.pop(relative_path, None)
            return

        # For added/modified, check hash
        changed, content, file_hash = self._hash_changed(relative_path)
        if changed and self.on_file_changed and content is not None and file_hash is not None:
            self.on_file_changed(relative_path, content, file_hash)

    async def _watch_loop(self) -> None:
        """Main watch loop processing file changes."""
        try:
            async for changes in watchfiles.awatch(  # pyright: ignore[reportUnknownMemberType]
                self._root_path,
                rust_timeout=100,  # Check every 100ms
                debounce=50,  # Internal debounce (we add more)
            ):
                if not self._running:
                    break
                for change_type, path_str in changes:
                    await self._process_change(change_type, path_str)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error("watch_loop_error", error=str(e))

    async def start(self) -> None:
        """Start the file watcher."""
        if self._watch_task is not None:
            return  # Already running

        self._running = True
        self._last_git_head = self._read_git_head()
        self._watch_task = asyncio.create_task(self._watch_loop())
        logger.info("dev_file_watcher_started", path=str(self._root_path))

    async def stop(self) -> None:
        """Stop the file watcher."""
        self._running = False
        if self._watch_task:
            self._watch_task.cancel()
            try:
                await self._watch_task
            except asyncio.CancelledError:
                pass
            self._watch_task = None
        logger.info("dev_file_watcher_stopped")
