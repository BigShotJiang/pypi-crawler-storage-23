"""WebSocket client for kater dev file sync.

Story: 3-3-websocket-dev-client
Handles WebSocket communication with the dev session endpoint.
"""

from __future__ import annotations

import asyncio
import base64
import json
from typing import TYPE_CHECKING, Any, Callable

import websockets
from websockets.asyncio.client import ClientConnection
from websockets.protocol import State
from websockets.exceptions import ConnectionClosed, InvalidStatus

from kater_utils import get_logger

if TYPE_CHECKING:
    from kater_cli.services.file_sync import FileEntry, FileManifestEntry

logger = get_logger(__name__)


class AuthenticationError(Exception):
    """Raised when the server rejects the client's auth token."""


# Message types - Client → Server
MSG_CONNECT = "connect"
MSG_FULL_SYNC = "full_sync"
MSG_DELTA_SYNC = "delta_sync"
MSG_FILE_SYNC = "file_sync"
MSG_FILE_DELETE = "file_delete"
MSG_PING = "ping"

# Message types - Client → Server (write-back protocol)
MSG_WRITE_ACK = "write_ack"

# Message types - Server → Client
MSG_SESSION_READY = "session_ready"
MSG_NEED_FILES = "need_files"
MSG_SYNC_ACK = "sync_ack"
MSG_WRITE_BACK = "write_back"
MSG_ERROR = "error"
MSG_PONG = "pong"

# Reconnection settings
INITIAL_RECONNECT_DELAY = 1.0  # seconds
MAX_RECONNECT_DELAY = 30.0  # seconds


class WsDevClient:
    """WebSocket client for dev session file sync.

    Handles:
    - Authenticated WebSocket connections
    - File sync protocol messages
    - Automatic reconnection with exponential backoff
    - Callback-based message dispatching
    """

    def __init__(
        self,
        api_url: str,
        token: str,
        cli_id: str,
        token_provider: Callable[[], str | None] | None = None,
    ) -> None:
        """Initialize WebSocket dev client.

        Args:
            api_url: API base URL (e.g., "https://app.kater.ai").
            token: Bearer token for authentication (used as fallback).
            cli_id: CLI identity for session.
            token_provider: Optional callable that returns a fresh token.
                If provided, called on each connect to get the latest token.
        """
        self.api_url = api_url
        self.token = token
        self.cli_id = cli_id
        self._token_provider = token_provider

        # Construct WebSocket URL
        self._ws_url = self._build_ws_url(api_url)

        # Connection state
        self._ws: ClientConnection | None = None
        self._reconnect_delay = INITIAL_RECONNECT_DELAY
        self._running = False
        self._receive_task: asyncio.Task[None] | None = None

        # Callbacks - set by command layer
        self.on_session_ready: Callable[[str, int], None] | None = None
        self.on_need_files: Callable[[list[str]], None] | None = None
        self.on_sync_ack: Callable[[str, str | None, int | None], None] | None = None
        self.on_error: Callable[[str, str], None] | None = None
        self.on_pong: Callable[[], None] | None = None
        self.on_write_back: Callable[[str, str, list[dict[str, str]]], None] | None = None
        self.on_reconnected: Callable[[], None] | None = None

    @staticmethod
    def _build_ws_url(api_url: str) -> str:
        """Build WebSocket URL from API URL.

        Args:
            api_url: HTTP(S) API URL.

        Returns:
            WebSocket URL for dev-session endpoint.
        """
        ws_url = api_url.replace("https://", "wss://").replace("http://", "ws://")
        return f"{ws_url.rstrip('/')}/ws/dev-session"

    @property
    def is_connected(self) -> bool:
        """Check if WebSocket is connected."""
        return self._ws is not None and self._ws.state == State.OPEN

    async def connect(self, timeout: float = 30.0) -> None:
        """Establish WebSocket connection with authorization.

        Args:
            timeout: Connection timeout in seconds (default 30s).

        Raises:
            AuthenticationError: If server rejects the token (403).
            ConnectionError: If connection fails for other reasons.
        """
        # Get a fresh token from the provider if available
        token = self.token
        if self._token_provider is not None:
            fresh = self._token_provider()
            if fresh:
                token = fresh
                self.token = fresh

        try:
            self._ws = await websockets.connect(
                self._ws_url,
                additional_headers={"Authorization": f"Bearer {token}"},
                open_timeout=timeout,
            )
        except InvalidStatus as exc:
            if exc.response.status_code == 403:
                raise AuthenticationError(
                    "Session expired. Run `kater login` to re-authenticate."
                ) from None
            raise ConnectionError(
                f"Failed to connect to Kater server ({exc.response.status_code})"
            ) from exc
        self._reconnect_delay = INITIAL_RECONNECT_DELAY
        logger.info("ws_dev_client_connected", url=self._ws_url)

    async def disconnect(self, print_message: bool = True) -> None:
        """Close WebSocket connection cleanly.

        Args:
            print_message: If True, print disconnect message to console (AC5).
        """
        if self._ws:
            await self._ws.close(code=1000, reason="Client disconnect")
            self._ws = None
        logger.info("ws_dev_client_disconnected")
        if print_message:
            from rich.console import Console

            Console().print("Disconnected. Your files are still cached on the server.")

    async def start(self) -> None:
        """Start the receive loop as a background task."""
        self._running = True
        self._receive_task = asyncio.create_task(self._receive_loop())

    async def stop(self, print_message: bool = True) -> None:
        """Stop the receive loop and disconnect.

        Args:
            print_message: If True, print disconnect message to console.
        """
        self._running = False
        if self._receive_task:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass
            self._receive_task = None
        await self.disconnect(print_message=print_message)

    async def _send_json(self, data: dict[str, Any]) -> None:
        """Send JSON message over WebSocket.

        Args:
            data: Data to send as JSON.

        Raises:
            ConnectionError: If not connected or connection is not open.
        """
        if not self.is_connected:
            raise ConnectionError("WebSocket not connected")
        # _ws is guaranteed non-None here due to is_connected check
        await self._ws.send(json.dumps(data))  # type: ignore[union-attr]

    async def send_connect(self) -> None:
        """Send connect message with cli_id."""
        await self._send_json({"type": MSG_CONNECT, "cli_id": self.cli_id})
        logger.debug("ws_dev_client_sent_connect", cli_id=self.cli_id)

    async def send_full_sync(self, files: list[FileEntry]) -> None:
        """Send full_sync message with all files.

        Args:
            files: List of FileEntry dicts with path, content, hash.
        """
        encoded_files = [
            {
                "path": f["path"],
                "content": base64.b64encode(f["content"]).decode("utf-8"),
                "hash": f["hash"],
            }
            for f in files
        ]
        await self._send_json({"type": MSG_FULL_SYNC, "files": encoded_files})
        logger.info("ws_dev_client_sent_full_sync", file_count=len(files))

    async def send_delta_sync(self, manifest: list[FileManifestEntry]) -> None:
        """Send delta_sync message with file manifest.

        Args:
            manifest: List of FileManifestEntry dicts with path, hash.
        """
        await self._send_json({"type": MSG_DELTA_SYNC, "manifest": manifest})
        logger.info("ws_dev_client_sent_delta_sync", file_count=len(manifest))

    async def send_file_sync(self, entry: FileEntry) -> None:
        """Send file_sync message for single file update.

        Args:
            entry: FileEntry with path, content, hash.
        """
        await self._send_json(
            {
                "type": MSG_FILE_SYNC,
                "path": entry["path"],
                "content": base64.b64encode(entry["content"]).decode("utf-8"),
                "hash": entry["hash"],
            }
        )
        logger.debug("ws_dev_client_sent_file_sync", path=entry["path"])

    async def send_file_delete(self, path: str) -> None:
        """Send file_delete message.

        Args:
            path: Relative path of deleted file.
        """
        await self._send_json({"type": MSG_FILE_DELETE, "path": path})
        logger.debug("ws_dev_client_sent_file_delete", path=path)

    async def send_write_ack(
        self,
        request_id: str,
        success: bool,
        files_written: int,
    ) -> None:
        """Send write_ack message confirming files were written.

        Args:
            request_id: The request_id from the write_back message.
            success: Whether all files were written successfully.
            files_written: Number of files successfully written.
        """
        await self._send_json(
            {
                "type": MSG_WRITE_ACK,
                "request_id": request_id,
                "success": success,
                "files_written": files_written,
            }
        )
        logger.debug(
            "ws_dev_client_sent_write_ack",
            request_id=request_id,
            success=success,
            files_written=files_written,
        )

    async def send_ping(self) -> None:
        """Send ping message for keepalive."""
        await self._send_json({"type": MSG_PING})

    async def _receive_loop(self) -> None:
        """Async loop for receiving and dispatching messages."""
        while self._running:
            try:
                if not self._ws:
                    await self._reconnect_with_backoff()
                    continue

                raw = await self._ws.recv()
                data = json.loads(raw)
                await self._dispatch_message(data)

            except ConnectionClosed:
                logger.warning("ws_dev_client_connection_closed")
                self._ws = None
                if self._running:
                    await self._reconnect_with_backoff()

            except json.JSONDecodeError:
                logger.warning("ws_dev_client_invalid_json")
                continue

            except asyncio.CancelledError:
                break

            except Exception:
                logger.exception("ws_dev_client_receive_error")
                if self._running:
                    await self._reconnect_with_backoff()

    async def _dispatch_message(self, data: dict[str, Any]) -> None:
        """Dispatch message to appropriate callback.

        Args:
            data: Parsed JSON message.
        """
        msg_type = data.get("type")

        if msg_type == MSG_SESSION_READY:
            if self.on_session_ready:
                self.on_session_ready(
                    data.get("cli_id", ""),
                    data.get("cached_file_count", 0),
                )

        elif msg_type == MSG_NEED_FILES:
            if self.on_need_files:
                self.on_need_files(data.get("paths", []))

        elif msg_type == MSG_SYNC_ACK:
            if self.on_sync_ack:
                self.on_sync_ack(
                    data.get("status", ""),
                    data.get("path"),
                    data.get("file_count"),
                )

        elif msg_type == MSG_ERROR:
            if self.on_error:
                self.on_error(
                    data.get("code", "unknown"),
                    data.get("message", "Unknown error"),
                )

        elif msg_type == MSG_WRITE_BACK:
            if self.on_write_back:
                self.on_write_back(
                    data.get("request_id", ""),
                    data.get("connection_folder", ""),
                    data.get("files", []),
                )

        elif msg_type == MSG_PONG:
            if self.on_pong:
                self.on_pong()

        else:
            logger.warning("ws_dev_client_unknown_message_type", type=msg_type)

    async def _reconnect_with_backoff(self) -> bool:
        """Attempt reconnection with exponential backoff.

        Returns:
            True if reconnection succeeded, False otherwise.
        """
        from rich.console import Console

        console = Console(stderr=True)
        console.print("[yellow]Connection lost. Reconnecting...[/yellow]")
        logger.warning("ws_dev_client_reconnecting", delay=self._reconnect_delay)

        while self._running:
            await asyncio.sleep(self._reconnect_delay)

            try:
                await self.connect()
                await self.send_connect()
                console.print("[green]Reconnected to Kater[/green]")

                if self.on_reconnected:
                    self.on_reconnected()

                return True

            except Exception:
                logger.warning(
                    "ws_dev_client_reconnect_failed",
                    delay=self._reconnect_delay,
                )
                # Exponential backoff with cap
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    MAX_RECONNECT_DELAY,
                )

        return False
