"""OAuth 2.0 Authorization Code flow with PKCE for CLI authentication."""

import base64
import hashlib
import secrets
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from urllib.parse import parse_qs, urlencode, urlparse

import httpx
from rich.console import Console

from kater_cli.auth.token_manager import TokenManager
from kater_cli.config import get_settings

console = Console()


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler for OAuth callback."""

    authorization_code: str | None = None
    state: str | None = None
    error: str | None = None

    def log_message(self, format: str, *args: object) -> None:
        """Suppress server logs."""
        pass

    def do_GET(self) -> None:
        """Handle GET request from OAuth callback."""
        parsed = urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return

        params = parse_qs(parsed.query)

        if "error" in params:
            OAuthCallbackHandler.error = params["error"][0]
            self._send_error_response(params.get("error_description", ["Unknown error"])[0])
            return

        if "code" not in params or "state" not in params:
            OAuthCallbackHandler.error = "missing_params"
            self._send_error_response("Missing authorization code or state")
            return

        OAuthCallbackHandler.authorization_code = params["code"][0]
        OAuthCallbackHandler.state = params["state"][0]
        self._send_success_response()

    def _send_success_response(self) -> None:
        """Send success HTML response."""
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        html = """
        <!DOCTYPE html>
        <html>
        <head><title>Login Successful</title></head>
        <body style="font-family: system-ui; text-align: center; padding: 50px;">
            <h1>Login Successful!</h1>
            <p>You can close this window and return to the terminal.</p>
        </body>
        </html>
        """
        self.wfile.write(html.encode())

    def _send_error_response(self, message: str) -> None:
        """Send error HTML response."""
        self.send_response(400)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        html = f"""
        <!DOCTYPE html>
        <html>
        <head><title>Login Failed</title></head>
        <body style="font-family: system-ui; text-align: center; padding: 50px;">
            <h1>Login Failed</h1>
            <p>{message}</p>
            <p>Please try again from the terminal.</p>
        </body>
        </html>
        """
        self.wfile.write(html.encode())


def _generate_pkce_pair() -> tuple[str, str]:
    """Generate PKCE code verifier and challenge.

    Returns:
        Tuple of (code_verifier, code_challenge)
    """
    code_verifier = secrets.token_urlsafe(32)
    code_challenge_bytes = hashlib.sha256(code_verifier.encode()).digest()
    code_challenge = base64.urlsafe_b64encode(code_challenge_bytes).rstrip(b"=").decode()
    return code_verifier, code_challenge


def _generate_state() -> str:
    """Generate random state parameter for CSRF protection."""
    return secrets.token_urlsafe(16)


def run_oauth_flow() -> bool:
    """Run the OAuth 2.0 authorization code flow with PKCE.

    Opens browser for user authentication and captures the callback.

    Returns:
        True if login successful, False otherwise.
    """
    settings = get_settings()

    if not settings.oauth_client_id:
        console.print("[red]Error: KATER_OAUTH_CLIENT_ID environment variable is not set.[/red]")
        console.print("Please set it to your PropelAuth OAuth client ID.")
        return False

    # Reset handler state
    OAuthCallbackHandler.authorization_code = None
    OAuthCallbackHandler.state = None
    OAuthCallbackHandler.error = None

    # Generate PKCE pair and state
    code_verifier, code_challenge = _generate_pkce_pair()
    state = _generate_state()

    # Build authorization URL
    redirect_uri = f"http://localhost:{settings.oauth_callback_port}/callback"
    auth_params = {
        "client_id": settings.oauth_client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "scope": "openid email profile",
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }
    auth_url = f"{settings.oauth_auth_url}?{urlencode(auth_params)}"

    # Start local callback server
    server = HTTPServer(("localhost", settings.oauth_callback_port), OAuthCallbackHandler)

    def handle_request() -> None:
        server.handle_request()

    server_thread = Thread(target=handle_request)
    server_thread.start()

    # Open browser for authentication
    console.print("Opening browser for authentication...")
    console.print(f"[dim]If browser doesn't open, visit: {auth_url}[/dim]")
    webbrowser.open(auth_url)

    # Wait for callback
    console.print("Waiting for authentication...")
    server_thread.join(timeout=120)
    server.server_close()

    # Check for errors
    if OAuthCallbackHandler.error:
        console.print(f"[red]Authentication failed: {OAuthCallbackHandler.error}[/red]")
        return False

    if not OAuthCallbackHandler.authorization_code:
        console.print("[red]Authentication timed out. Please try again.[/red]")
        return False

    received_state = OAuthCallbackHandler.state
    if received_state is None or received_state != state:
        console.print("[red]Invalid state parameter. Possible CSRF attack.[/red]")
        return False

    # Exchange code for tokens
    try:
        response = httpx.post(
            settings.oauth_token_url,
            data={
                "grant_type": "authorization_code",
                "code": OAuthCallbackHandler.authorization_code,
                "redirect_uri": redirect_uri,
                "client_id": settings.oauth_client_id,
                "code_verifier": code_verifier,
            },
            timeout=30.0,
        )

        if response.status_code != 200:
            console.print(f"[red]Token exchange failed: {response.text}[/red]")
            return False

        data = response.json()

        # Store tokens
        token_manager = TokenManager()
        token_manager.store_tokens(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
            expires_in=data["expires_in"],
        )

        console.print("[green]Successfully logged in![/green]")
        return True

    except httpx.RequestError as e:
        console.print(f"[red]Network error during token exchange: {e}[/red]")
        return False
