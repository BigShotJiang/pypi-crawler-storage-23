"""Token management using system keyring for secure storage."""

from __future__ import annotations

import asyncio
import json
import secrets
import time
from collections.abc import Callable, Generator
from dataclasses import dataclass

import httpx
import keyring

from kater_cli.config import get_settings


class _TokenRefreshRejected(Exception):
    """Auth server definitively rejected the refresh token (401/403)."""


# CLI Identity key for keyring storage
CLI_ID_KEY = "cli_id"


def get_or_create_cli_id() -> str:
    """Get existing cli_id from keyring or generate a new one.

    The cli_id is a persistent identifier stored in the system keyring
    that uniquely identifies a developer's machine. It is used as the
    HTTP header X-Kater-CLI-ID to route API requests to the correct
    Virtual Filesystem (VFS).

    Returns:
        The cli_id string (format: cli_ + 12-char hex)
    """
    settings = get_settings()

    # Try to get existing cli_id
    cli_id = keyring.get_password(settings.keyring_service, CLI_ID_KEY)
    if cli_id is not None:
        return cli_id

    # Generate new cli_id: cli_ prefix + 12 hex characters
    cli_id = f"cli_{secrets.token_hex(6)}"
    keyring.set_password(settings.keyring_service, CLI_ID_KEY, cli_id)
    return cli_id


@dataclass
class TokenData:
    """Stored token data."""

    access_token: str
    refresh_token: str
    expires_at: float  # Unix timestamp


class TokenManager:
    """Manages OAuth tokens with secure keyring storage and automatic refresh."""

    KEYRING_USERNAME = "oauth_tokens"
    REFRESH_BUFFER_SECONDS = 300  # Refresh 5 minutes before expiration

    def __init__(self) -> None:
        self._settings = get_settings()
        self._service = self._settings.keyring_service
        self._background_task: asyncio.Task[None] | None = None
        self._cached_tokens: TokenData | None = None
        self._cache_loaded: bool = False

    def _get_stored_tokens(self) -> TokenData | None:
        """Retrieve tokens, using in-memory cache to avoid repeated keyring prompts."""
        if self._cache_loaded:
            return self._cached_tokens
        data = keyring.get_password(self._service, self.KEYRING_USERNAME)
        if not data:
            self._cached_tokens = None
            self._cache_loaded = True
            return None
        try:
            parsed = json.loads(data)
            self._cached_tokens = TokenData(
                access_token=parsed["access_token"],
                refresh_token=parsed["refresh_token"],
                expires_at=parsed["expires_at"],
            )
        except (json.JSONDecodeError, KeyError):
            self._cached_tokens = None
        self._cache_loaded = True
        return self._cached_tokens

    def store_tokens(
        self,
        access_token: str,
        refresh_token: str,
        expires_in: int,
    ) -> None:
        """Store tokens in keyring.

        Args:
            access_token: The OAuth access token
            refresh_token: The OAuth refresh token
            expires_in: Token lifetime in seconds
        """
        expires_at = time.time() + expires_in
        data = json.dumps(
            {
                "access_token": access_token,
                "refresh_token": refresh_token,
                "expires_at": expires_at,
            }
        )
        keyring.set_password(self._service, self.KEYRING_USERNAME, data)
        # Update in-memory cache so subsequent reads skip the keyring
        self._cached_tokens = TokenData(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at,
        )
        self._cache_loaded = True

    def clear_tokens(self) -> None:
        """Remove tokens from keyring."""
        self._cached_tokens = None
        self._cache_loaded = True
        try:
            keyring.delete_password(self._service, self.KEYRING_USERNAME)
        except Exception:
            # Password may not exist, which is fine
            pass

    def _is_token_expired(self, token_data: TokenData) -> bool:
        """Check if token is expired or will expire soon."""
        return time.time() >= (token_data.expires_at - self.REFRESH_BUFFER_SECONDS)

    def _refresh_tokens(self, refresh_token: str) -> TokenData | None:
        """Exchange refresh token for new access token.

        Returns:
            TokenData on success, None on failure.

        Raises:
            _TokenRefreshRejected: When the auth server definitively rejects the
                refresh token (401/403), meaning the token is permanently invalid.
        """
        try:
            response = httpx.post(
                self._settings.oauth_token_url,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": self._settings.oauth_client_id,
                },
                timeout=30.0,
            )

            if response.status_code in (401, 403):
                raise _TokenRefreshRejected
            if response.status_code != 200:
                return None

            data = response.json()
            self.store_tokens(
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token", refresh_token),
                expires_in=data["expires_in"],
            )
            return self._cached_tokens
        except httpx.RequestError:
            return None

    def get_access_token(self) -> str | None:
        """Get a valid access token, refreshing if needed.

        Returns:
            The access token if valid/refreshable, None if not authenticated.
        """
        token_data = self._get_stored_tokens()
        if not token_data:
            return None

        if self._is_token_expired(token_data):
            try:
                refreshed = self._refresh_tokens(token_data.refresh_token)
            except _TokenRefreshRejected:
                # Refresh token is permanently invalid — clear and require re-login
                self.clear_tokens()
                return None
            if not refreshed:
                # Transient failure (network, 500, etc.) — return the expired
                # token rather than nuking the keyring. The caller or background
                # refresh can retry later.
                return token_data.access_token
            token_data = refreshed

        return token_data.access_token

    def has_tokens(self) -> bool:
        """Check if tokens are stored (may be expired)."""
        return self._get_stored_tokens() is not None

    def get_token_status(self) -> tuple[bool, float | None]:
        """Get authentication status.

        Returns:
            Tuple of (is_authenticated, expires_at_timestamp or None)
        """
        token_data = self._get_stored_tokens()
        if not token_data:
            return False, None
        return True, token_data.expires_at

    def get_token_data(self) -> TokenData | None:
        """Get current token data (for auth flow use).

        Returns:
            TokenData if tokens are stored, None otherwise.
        """
        return self._get_stored_tokens()

    def refresh_tokens(self, refresh_token: str) -> TokenData | None:
        """Attempt to refresh tokens using the provided refresh token.

        This is the public interface for token refresh, used by
        TokenRefreshAuth for 401 retry flow.

        Args:
            refresh_token: The refresh token to exchange for new tokens.

        Returns:
            TokenData with new tokens if successful, None if refresh failed.
        """
        return self._refresh_tokens(refresh_token)

    def start_background_refresh(
        self, callback: Callable[[], None] | None = None
    ) -> asyncio.Task[None]:
        """Start background token refresh timer.

        Proactively refreshes tokens before they expire to ensure
        uninterrupted WebSocket connections.

        Args:
            callback: Optional callback invoked after successful refresh.

        Returns:
            The asyncio Task running the refresh loop.
        """
        self._background_task = asyncio.create_task(self._refresh_loop(callback))
        return self._background_task

    def stop_background_refresh(self) -> None:
        """Stop the background refresh timer."""
        if self._background_task is not None:
            self._background_task.cancel()
            self._background_task = None

    async def _refresh_loop(self, callback: Callable[[], None] | None = None) -> None:
        """Background loop that checks and refreshes tokens before expiry.

        Args:
            callback: Optional callback invoked after successful refresh.
        """
        check_interval = 60  # Check every 60 seconds

        try:
            while True:
                token_data = self._get_stored_tokens()
                if token_data and self._is_token_expired(token_data):
                    try:
                        # Run the blocking HTTP call in a thread to avoid freezing the event loop
                        refreshed = await asyncio.to_thread(
                            self._refresh_tokens, token_data.refresh_token
                        )
                    except _TokenRefreshRejected:
                        # Auth server definitively rejected the refresh token — clear and stop
                        self.clear_tokens()
                        return
                    if refreshed and callback:
                        callback()
                    # None means transient failure; will retry next interval

                await asyncio.sleep(check_interval)
        except asyncio.CancelledError:
            # Clean shutdown
            pass


class TokenRefreshAuth(httpx.Auth):
    """httpx Auth class that handles automatic token refresh on 401.

    This auth class:
    1. Sets the Authorization header with the current access token
    2. If a 401 response is received, attempts to refresh the token
    3. If refresh succeeds, retries the request with the new token
    4. If refresh fails, clears tokens and returns the 401 response
    """

    def __init__(self, token_manager: TokenManager) -> None:
        """Initialize with a TokenManager instance.

        Args:
            token_manager: The TokenManager to use for token operations.
        """
        self._token_manager = token_manager

    def auth_flow(self, request: httpx.Request) -> Generator[httpx.Request, httpx.Response, None]:
        """Implement the httpx auth flow with 401 retry.

        Args:
            request: The outgoing request.

        Yields:
            The request (possibly retried with new token).
        """
        # Get current token and set auth header
        token = self._token_manager.get_access_token()
        if token:
            request.headers["Authorization"] = f"Bearer {token}"

        # Send the request
        response = yield request

        # Handle 401 - attempt refresh and retry
        if response.status_code == 401:
            token_data = self._token_manager.get_token_data()
            if token_data:
                try:
                    refreshed = self._token_manager.refresh_tokens(token_data.refresh_token)
                except _TokenRefreshRejected:
                    self._token_manager.clear_tokens()
                    return
                if refreshed:
                    # Update header with new token and retry
                    request.headers["Authorization"] = f"Bearer {refreshed.access_token}"
                    yield request
                # Transient failure — don't clear tokens
