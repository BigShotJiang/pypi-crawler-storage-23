"""CLI configuration settings."""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class CliSettings(BaseSettings):
    """Settings for the Kater CLI."""

    model_config = SettingsConfigDict(
        env_prefix="KATER_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # API configuration
    api_url: str = "https://api.kater.ai"

    # OAuth configuration (PropelAuth)
    oauth_auth_url: str = "https://auth.kater.ai/propelauth/oauth/authorize"
    oauth_token_url: str = "https://auth.kater.ai/propelauth/oauth/token"
    oauth_client_id: str = "35376b3c98499de36ad94ac575b5e38a"

    # Local callback server port
    oauth_callback_port: int = 9876

    # Keyring service name
    keyring_service: str = "kater-cli"

    # Signup URL (opened by `kater install` after scaffolding)
    signup_url: str = "https://landing-dev.kater.ai/signup?plan=pro&billing=yearly"


@lru_cache
def get_settings() -> CliSettings:
    """Get cached CLI settings singleton."""
    return CliSettings()
