# Make sure to update pyproject.toml too
__version__ = "3.7.2"
