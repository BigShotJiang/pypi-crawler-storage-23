# Rename `--allow-dir` to `--add-dir`

The CLI flag `--allow-dir` should be renamed to `--add-dir` to match the existing REPL command `/add-dir`.

## Backward compatibility

Hard break. `--allow-dir` is removed outright — no deprecated alias. Per project conventions, backward compatibility is not a concern. No existing config files break (the TOML key `allowed_dirs` is unchanged).

## Source files to change

### 1. `swival/agent.py`

- **Line 782**: Change `"--allow-dir"` to `"--add-dir"` in `build_parser()`. The argparse dest becomes `add_dir` automatically.
- **Line 786**: Update help text if needed (currently fine as-is).
- **Lines 1234–1241**: Update comments and error messages from `--allow-dir` to `--add-dir`. Change `args.allow_dir` to `args.add_dir`.

### 2. `swival/config.py`

- **Line 48**: `_LIST_OF_STR_KEYS` — no change needed (config key stays `allowed_dirs`).
- **Line 52**: `_CONFIG_TO_ARGPARSE` — change `"allowed_dirs": "allow_dir"` to `"allowed_dirs": "add_dir"`.
- **Line 71**: `_ARGPARSE_DEFAULTS` — change key `"allow_dir"` to `"add_dir"`.
- **Line 248**: `_NONE_SENTINEL_DESTS` — change `"allow_dir"` to `"add_dir"`.

### 3. `swival/session.py`

- **Line 126**: Update comment from `--allow-dir` to `--add-dir`.

### 4. `swival/tools.py`

- **Line 458**: Update comment from `--allow-dir` to `--add-dir`.

## Documentation files to change

### 5. `CLAUDE.md`

- Update all `--allow-dir` references in the architecture section to `--add-dir`.

### 6. `docs.md/usage.md`

- Line 98: Update `--allow-dir` reference.

### 7. `docs.md/safety-and-sandboxing.md`

- Lines 22, 25: Update `--allow-dir` references and the example command.

### 8. Rebuild HTML docs

- Run `uv run --group website python build.py` to regenerate `docs/pages/*.html` from the updated markdown.

## Test files to change

### 9. `tests/test_allow_dir.py`

- Rename file to `tests/test_add_dir.py`.
- Update all `--allow-dir` strings in CLI args to `--add-dir`.
- Update `args.allow_dir` references to `args.add_dir`.
- Rename test methods: `test_allow_dir_*` → `test_add_dir_*`.

### 10. `tests/test_config.py`

- **Line 48**: Change `"allow_dir"` to `"add_dir"`.
- **Line 330**: Rename test `test_allowed_dirs_maps_to_allow_dir` → `test_allowed_dirs_maps_to_add_dir`.
- **Lines 333, 336, 338**: Change `args.allow_dir` to `args.add_dir`, and `allow_dir=[...]` kwargs to `add_dir=[...]`.
- **Line 351**: Update docstring reference.
- **Line 354**: Change `args.allow_dir` to `args.add_dir`.

### 11. `tests/test_yolo.py`

- **Lines 301, 308, 341**: Update comments and test names referencing `--allow-dir`.

### 12. `tests/test_delete.py`

- **Line 184**: Rename `test_delete_allow_dir_absolute_path` → `test_delete_add_dir_absolute_path`.
- **Line 185**: Update docstring from `--allow-dir` to `--add-dir`.
- **Line 490**: Change `allow_dir=[]` to `add_dir=[]`.

### 13. Other test files with `allow_dir=[]` in mock args

These files pass `allow_dir=[]` when constructing argparse namespaces or similar fixtures. Update to `add_dir=[]`:

- `tests/test_empty_assistant.py` (line 45)
- `tests/test_reviewer.py` (line 47)
- `tests/test_report.py` (line 496)
- `tests/test_history.py` (line 268)
- `tests/test_todo.py` (line 556)
- `tests/test_logging.py` (line 53)
- `tests/test_guardrails.py` (line 46)

## Not changing

- **Config file key `allowed_dirs`**: The TOML key in config files stays `allowed_dirs`. This is the user-facing config name and doesn't need to match the CLI flag exactly (the mapping in `_CONFIG_TO_ARGPARSE` handles the translation).
- **Session API `allowed_dirs` parameter**: The Python API stays as-is. It's a separate interface from the CLI.
- **Plan files in `plans/`**: These are historical design docs. No updates needed.
- **REPL `/add-dir` command**: Already named correctly — this is what we're aligning with.

## Verification

1. `uv run ruff check swival/ tests/` — no lint errors.
2. `uv run python -m pytest tests/test_add_dir.py -v` — focused run on the renamed test file.
3. `uv run python -m pytest tests/ -v` — full suite passes.
4. `uv run --group website python build.py` — docs build cleanly.
5. `uv run swival --help` — confirm `--add-dir` appears instead of `--allow-dir`.
6. Stale reference sweep — use precise patterns to avoid `allowed_dirs` noise:
   - `--allow-dir` (literal) across `swival/`, `tests/`, `docs.md/`, `CLAUDE.md`
   - `\ballow_dir\b` (word-boundary) across the same paths

   The only remaining hits should be in `plans/` (historical).
