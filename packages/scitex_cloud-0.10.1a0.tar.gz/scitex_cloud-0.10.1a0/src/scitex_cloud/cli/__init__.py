#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File: src/scitex_cloud/cli/__init__.py

"""CLI module for scitex-cloud."""

from .main import main

__all__ = ["main"]

# EOF
