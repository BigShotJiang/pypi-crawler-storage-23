"""
Miscaleneous collection of small tools somehow extending standard Python's
capabilities.
"""

#: No automatic export
__all__ = []

__tocinfoline__ = "VORTEX generic utility classes and methods"
