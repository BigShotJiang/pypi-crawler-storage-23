"""
Fake module to be populated dynamically, eg. by footprints shortcuts to catalogs.
"""

#: No automatic export
__all__ = []
