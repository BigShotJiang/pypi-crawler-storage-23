"""
Module needed to interact with subdirectories of AEARP's rawfiles.

:warning: Do not use this module. It is deprecated
"""

# Backward compatibility...
from . import folder

RawFilesShell = folder.RawFilesShell
