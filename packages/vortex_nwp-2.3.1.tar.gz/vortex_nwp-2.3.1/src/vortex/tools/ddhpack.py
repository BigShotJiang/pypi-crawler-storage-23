"""
Module needed to interact with subdirectories of DDH files.

:warning: Do not use this module. It is deprecated
"""

# Backward compatibility...
from . import folder

DdhPackShell = folder.DdhPackShell
