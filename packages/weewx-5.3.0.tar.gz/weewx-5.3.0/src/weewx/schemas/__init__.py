#
#    Copyright (c) 2009-2015 Tom Keffer <tkeffer@gmail.com>
#
#    See the file LICENSE.txt for your full rights.
#
"""
Package of schemas used by weewx.

This package consists of a set of modules, each containing a schema.
"""
