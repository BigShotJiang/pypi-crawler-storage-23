# The weewx_data package contains package resources for WeeWX.
