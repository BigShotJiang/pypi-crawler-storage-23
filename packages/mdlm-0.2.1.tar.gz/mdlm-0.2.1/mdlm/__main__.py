"""Entry point for `python -m mdlm`."""

from mdlm.cli import main

main()
