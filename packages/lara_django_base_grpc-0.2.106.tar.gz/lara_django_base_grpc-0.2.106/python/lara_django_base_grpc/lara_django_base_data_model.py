from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_base',
     'imports': ['linkml:types'],
     'name': 'lara_django_base',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_base_schema.yaml',
     'types': {'FileField': {'base': 'str',
                             'description': 'A file field',
                             'from_schema': 'https://w3id.org/lara/lara_django_base',
                             'name': 'FileField',
                             'uri': 'https://w3id.org/lara/FileField'},
               'ImageField': {'base': 'str',
                              'description': 'An image field',
                              'from_schema': 'https://w3id.org/lara/lara_django_base',
                              'name': 'ImageField',
                              'uri': 'https://w3id.org/lara/ImageField'},
               'JSON': {'base': 'string',
                        'description': 'A JSON object',
                        'from_schema': 'https://w3id.org/lara/lara_django_base',
                        'name': 'JSON',
                        'repr': 'dict',
                        'uri': 'https://json.org'},
               'UUID': {'base': 'str',
                        'description': 'A UUID',
                        'from_schema': 'https://w3id.org/lara/lara_django_base',
                        'name': 'UUID',
                        'pattern': '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                        'uri': 'https://datatracker.ietf.org/doc/html/rfc9562'}}} )


class MediaType(ConfiguredBaseModel):
    """
    \" generic media Type (IANA = new MIMEsystem, see https://www.iana.org/assignments/media-types/media-types.xhtml): for media files, like e.g. svg, JSON, png, mp3, pdf, ... Format:
     type / subtype *(; parameter) application/x-animl, application/json
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/MediaType',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    mediatype_id: Optional[str] = Field(default=None, description="""MediaType - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'mediatype_id',
         'domain_of': ['MediaType'],
         'slot_uri': 'lara:base/MediaType/mediatype_id'} })
    name: str = Field(default=..., description="""name of the IANA application""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/MediaType/name'} })
    media_type: str = Field(default=..., description="""name of IANA/MIME media type in the format: type '/' [tree '.'] subtype ['+' suffix] *[';' parameter]""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['MediaType', 'DataType', 'ExtraData'],
         'slot_uri': 'lara:base/MediaType/media_type'} })
    def_filename_extension_regex: Optional[str] = Field(default=None, description="""default filename extension regular expression, e.g. ^.* .(jpg|JPG)$ ,  ^.* .(gif|GIF|doc|DOC|pdf|PDF)$""", json_schema_extra = { "linkml_meta": {'alias': 'def_filename_extension_regex',
         'domain_of': ['MediaType'],
         'slot_uri': 'lara:base/MediaType/def_filename_extension_regex'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation""", json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/MediaType/iri'} })
    description: Optional[str] = Field(default=None, description="""description of file type""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/MediaType/description'} })


class DataType(ConfiguredBaseModel):
    """
    \" Generic DataType that can be used to classify ExtraData (s. below) e.g. email_home, email_lab, telephone_number_home1, company_x_customer_number, sequence data, absorption data ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/DataType',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    datatype_id: Optional[str] = Field(default=None, description="""DataType - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'datatype_id',
         'domain_of': ['DataType'],
         'slot_uri': 'lara:base/DataType/datatype_id'} })
    name: str = Field(default=..., description="""name of the data type""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/DataType/name'} })
    media_type: Optional[str] = Field(default=None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['MediaType', 'DataType', 'ExtraData'],
         'slot_uri': 'lara:base/MediaType'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/DataType/iri'} })
    description: Optional[str] = Field(default=None, description="""description of extra data type""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/DataType/description'} })


class Namespace(ConfiguredBaseModel):
    """
    \" generic namespace model: Namespaces can be used to specify the scope or provenience of data, entities, etc. and helps to make them unique. \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/Namespace',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    namespace_id: Optional[str] = Field(default=None, description="""Namespace - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'namespace_id',
         'domain_of': ['Namespace'],
         'slot_uri': 'lara:base/Namespace/namespace_id'} })
    uri: str = Field(default=..., description="""Universal Resource Identifier - A unique namespace for identifying data, https://de.unigreifswald/biochem/akb""", json_schema_extra = { "linkml_meta": {'alias': 'uri',
         'domain_of': ['Namespace'],
         'slot_uri': 'lara:base/Namespace/uri'} })
    description: Optional[str] = Field(default=None, description="""description of this Namespace""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Namespace/description'} })


class Tag(ConfiguredBaseModel):
    """
    \" generic tags and keywords model: Tags and keywords can be used to group related information or make objects findable. \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/Tag',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    tag_id: Optional[str] = Field(default=None, description="""Tag - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'tag_id', 'domain_of': ['Tag'], 'slot_uri': 'lara:base/Tag/tag_id'} })
    tag: str = Field(default=..., description="""a tag, can be used for tagging items, like 'reviewed', 'interesting', but also for keywords, like 'python', 'evolution'""", json_schema_extra = { "linkml_meta": {'alias': 'tag', 'domain_of': ['Tag'], 'slot_uri': 'lara:base/Tag/tag'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/Tag/iri'} })


class ItemRole(ConfiguredBaseModel):
    """
    \" generic item role, can be used for indicating the role of LARA items, like a containers or processes: sample, reference, standard, control, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/ItemRole',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    itemrole_id: Optional[str] = Field(default=None, description="""ItemRole - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'itemrole_id',
         'domain_of': ['ItemRole'],
         'slot_uri': 'lara:base/ItemRole/itemrole_id'} })
    role: str = Field(default=..., description="""item role, like sample, reference, standard, control, ..""", json_schema_extra = { "linkml_meta": {'alias': 'role',
         'domain_of': ['ItemRole'],
         'slot_uri': 'lara:base/ItemRole/role'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/ItemRole/iri'} })
    description: Optional[str] = Field(default=None, description="""A short description of the item role""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ItemRole/description'} })


class ItemStatus(ConfiguredBaseModel):
    """
    \" generic item status/state, can be used for indicating the status of LARA items, like a containers or processes: planned, started, evaluating or order states, like to_order, pending, ordered, received ...\" hint: please do not use tags for this - separating tag and status makes processing clearer (hopefully :) \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/ItemStatus',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    itemstatus_id: Optional[str] = Field(default=None, description="""ItemStatus - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'itemstatus_id',
         'domain_of': ['ItemStatus'],
         'slot_uri': 'lara:base/ItemStatus/itemstatus_id'} })
    status: str = Field(default=..., description="""item status, like planned, started, evaluating, .. finished""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['ItemStatus'],
         'slot_uri': 'lara:base/ItemStatus/status'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/ItemStatus/iri'} })
    color: Optional[str] = Field(default=None, description="""colour scheme indicating the status of the item""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['ItemStatus'],
         'slot_uri': 'lara:base/ItemStatus/color'} })
    value: Optional[float] = Field(default=None, description="""relative value between 0 and 1, indicating the status of the item""", json_schema_extra = { "linkml_meta": {'alias': 'value',
         'domain_of': ['ItemStatus', 'ScientificConstant'],
         'slot_uri': 'lara:base/ItemStatus/value'} })
    description: Optional[str] = Field(default=None, description="""A short description of the item status""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ItemStatus/description'} })
    tags: Optional[list[str]] = Field(default=None, description="""tags for item status""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['ItemStatus', 'ExternalResource', 'LARASyncServer', 'Container'],
         'slot_uri': 'lara:base/Tag'} })


class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend data, by extra information, e.g., more telephone numbers, customer numbers, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/ExtraData',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    extradata_id: Optional[str] = Field(default=None, description="""ExtraData - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'extradata_id',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/ExtraData/extradata_id'} })
    data_type: Optional[str] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/DataType'} })
    namespace: str = Field(default=..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'ExternalResource', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(default=None, description="""Human readable display name or title of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData', 'ExternalResource'],
         'slot_uri': 'lara:base/ExtraData/name_display'} })
    name: Optional[str] = Field(default=None, description="""name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ExtraData/name'} })
    name_full: Optional[str] = Field(default=None, description="""full name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/ExtraData/name_full'} })
    version: Optional[str] = Field(default=None, description="""version of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/ExtraData/version'} })
    hash_sha256: Optional[str] = Field(default=None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/ExtraData/hash_sha256'} })
    data_json: Optional[dict] = Field(default=None, description="""generic JSON field""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData', 'ScientificConstant'],
         'slot_uri': 'lara:base/ExtraData/data_json'} })
    media_type: Optional[str] = Field(default=None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['MediaType', 'DataType', 'ExtraData'],
         'slot_uri': 'lara:base/MediaType'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/ExtraData/iri'} })
    url: Optional[str] = Field(default=None, description="""Universal Resource Locator - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'LARAExtension',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ExtraData/url'} })
    datetime_created: Optional[str] = Field(default=None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/ExtraData/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(default=None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/ExtraData/datetime_last_modified'} })
    description: Optional[str] = Field(default=None, description="""description of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ExtraData/description'} })
    file: Optional[str] = Field(default=None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'file',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/ExtraData/file'} })
    image: Optional[str] = Field(default=None, description="""location room map rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/ExtraData/image'} })


class ExternalResource(ConfiguredBaseModel):
    """
    \" generic external resource class: External resources can be used to link to external resources, like, e.g., literature, pdf, a website, a file, a database, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/ExternalResource',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    externalresource_id: Optional[str] = Field(default=None, description="""ExternalResource - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'externalresource_id',
         'domain_of': ['ExternalResource'],
         'slot_uri': 'lara:base/ExternalResource/externalresource_id'} })
    namespace: Optional[str] = Field(default=None, description="""namespace of external resource""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'ExternalResource', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(default=None, description="""Human readable display name or title of external resource""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData', 'ExternalResource'],
         'slot_uri': 'lara:base/ExternalResource/name_display'} })
    name: Optional[str] = Field(default=None, description="""name of the external resource""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ExternalResource/name'} })
    resource_type: Optional[str] = Field(default=None, description="""type of external resource, like pdf, website, handle, DOI, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resource_type',
         'domain_of': ['ExternalResource'],
         'slot_uri': 'lara:base/DataType'} })
    url: Optional[str] = Field(default=None, description="""Universal Resource Locator - URL - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'LARAExtension',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ExternalResource/url'} })
    iri: Optional[str] = Field(default=None, description="""Universal Resource Name - URI - this can be used to uniquely identify the external resource""", json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/ExternalResource/iri'} })
    prefix: Optional[str] = Field(default=None, description="""prefix for compact URIs (CURI), e.g. 'skos' for 'http://www.w3.org/2004/02/skos/core#'""", json_schema_extra = { "linkml_meta": {'alias': 'prefix',
         'domain_of': ['ExternalResource'],
         'slot_uri': 'lara:base/ExternalResource/prefix'} })
    description: Optional[str] = Field(default=None, description="""description of the external resource""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ExternalResource/description'} })
    datetime_last_modified: Optional[str] = Field(default=None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/ExternalResource/datetime_last_modified'} })
    tags: Optional[list[str]] = Field(default=None, description="""tags for external resource""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['ItemStatus', 'ExternalResource', 'LARASyncServer', 'Container'],
         'slot_uri': 'lara:base/Tag'} })


class PhysicalUnit(ConfiguredBaseModel):
    """
    \" Physical units, like, meter, kilogram, ..., preferably SI units \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/PhysicalUnit',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    physicalunit_id: Optional[str] = Field(default=None, description="""PhysicalUnit - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'physicalunit_id',
         'domain_of': ['PhysicalUnit'],
         'slot_uri': 'lara:base/PhysicalUnit/physicalunit_id'} })
    name: str = Field(default=..., description="""physical unit, like meter, kilogram, ...""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/PhysicalUnit/name'} })
    symbol: Optional[str] = Field(default=None, description="""symbol of the physical unit, like m, kg, ...""", json_schema_extra = { "linkml_meta": {'alias': 'symbol',
         'domain_of': ['PhysicalUnit', 'ScientificConstant', 'Currency'],
         'slot_uri': 'lara:base/PhysicalUnit/symbol'} })
    dimension: Optional[str] = Field(default=None, description="""physical dimension, like length, mass, ...""", json_schema_extra = { "linkml_meta": {'alias': 'dimension',
         'domain_of': ['PhysicalUnit'],
         'slot_uri': 'lara:base/PhysicalUnit/dimension'} })
    transformation_si: Optional[dict] = Field(default=None, description="""transformation formula to SI unit, in machine readable form (e.g. python code), like: x * 1000.0""", json_schema_extra = { "linkml_meta": {'alias': 'transformation_si',
         'domain_of': ['PhysicalUnit'],
         'slot_uri': 'lara:base/PhysicalUnit/transformation_si'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/PhysicalUnit/iri'} })
    description: Optional[str] = Field(default=None, description="""A short description of the physical unit""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/PhysicalUnit/description'} })


class PhysicalStateMatter(ConfiguredBaseModel):
    """
    \" Physical state of matter, like solid, liquid, gas, plasma, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/PhysicalStateMatter',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    physicalstatematter_id: Optional[str] = Field(default=None, description="""PhysicalStateMatter - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'physicalstatematter_id',
         'domain_of': ['PhysicalStateMatter'],
         'slot_uri': 'lara:base/PhysicalStateMatter/physicalstatematter_id'} })
    name: str = Field(default=..., description="""physical state of matter, like solid, liquid, gas, plasma, ...""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/PhysicalStateMatter/name'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/PhysicalStateMatter/iri'} })
    description: Optional[str] = Field(default=None, description="""A short description of the physical state of matter""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/PhysicalStateMatter/description'} })


class ScientificConstant(ConfiguredBaseModel):
    """
    \" Mathematical and Physical constants \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/ScientificConstant',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    scientificconstant_id: Optional[str] = Field(default=None, description="""ScientificConstant - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'scientificconstant_id',
         'domain_of': ['ScientificConstant'],
         'slot_uri': 'lara:base/ScientificConstant/scientificconstant_id'} })
    name: Optional[str] = Field(default=None, description="""generic text field""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ScientificConstant/name'} })
    symbol: Optional[str] = Field(default=None, description="""symbol of the constant""", json_schema_extra = { "linkml_meta": {'alias': 'symbol',
         'domain_of': ['PhysicalUnit', 'ScientificConstant', 'Currency'],
         'slot_uri': 'lara:base/ScientificConstant/symbol'} })
    value: Optional[float] = Field(default=None, description="""Float value of the """, json_schema_extra = { "linkml_meta": {'alias': 'value',
         'domain_of': ['ItemStatus', 'ScientificConstant'],
         'slot_uri': 'lara:base/ScientificConstant/value'} })
    uncertainty: Optional[float] = Field(default=None, description="""uncertainty of the value +/-""", json_schema_extra = { "linkml_meta": {'alias': 'uncertainty',
         'domain_of': ['ScientificConstant'],
         'slot_uri': 'lara:base/ScientificConstant/uncertainty'} })
    unit: Optional[str] = Field(default=None, description="""physical unit""", json_schema_extra = { "linkml_meta": {'alias': 'unit',
         'domain_of': ['ScientificConstant'],
         'slot_uri': 'lara:base/PhysicalUnit'} })
    data_json: Optional[dict] = Field(default=None, description="""complex content""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData', 'ScientificConstant'],
         'slot_uri': 'lara:base/ScientificConstant/data_json'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/ScientificConstant/iri'} })
    url_source: Optional[str] = Field(default=None, description="""Universal Resource Locator - URL - source, e.g. in literature""", json_schema_extra = { "linkml_meta": {'alias': 'url_source',
         'domain_of': ['ScientificConstant'],
         'slot_uri': 'lara:base/ScientificConstant/url_source'} })
    url_definition: Optional[str] = Field(default=None, description="""Universal Resource Locator - URL - definition""", json_schema_extra = { "linkml_meta": {'alias': 'url_definition',
         'domain_of': ['ScientificConstant'],
         'slot_uri': 'lara:base/ScientificConstant/url_definition'} })
    description: Optional[str] = Field(default=None, description="""description of the constant""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/ScientificConstant/description'} })
    datetime_last_modified: Optional[str] = Field(default=None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/ScientificConstant/datetime_last_modified'} })


class Currency(ConfiguredBaseModel):
    """
    \" generic currency class hint: s. also Money class from django-shop \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/Currency',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    currency_id: Optional[str] = Field(default=None, description="""Currency - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'currency_id',
         'domain_of': ['Currency'],
         'slot_uri': 'lara:base/Currency/currency_id'} })
    name: str = Field(default=..., description="""currency name""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Currency/name'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/Currency/iri'} })
    alpha3code: Optional[str] = Field(default=None, description="""acronym, e.g. EUR, USD, ..""", json_schema_extra = { "linkml_meta": {'alias': 'alpha3code',
         'domain_of': ['Currency', 'Country'],
         'slot_uri': 'lara:base/Currency/alpha3code'} })
    numeric_code: Optional[int] = Field(default=None, description="""International 3 number code, like 978 (for EUR) """, json_schema_extra = { "linkml_meta": {'alias': 'numeric_code',
         'domain_of': ['Currency', 'Country'],
         'slot_uri': 'lara:base/Currency/numeric_code'} })
    symbol: Optional[str] = Field(default=None, description="""currency symbol, e.g. €, $, ...""", json_schema_extra = { "linkml_meta": {'alias': 'symbol',
         'domain_of': ['PhysicalUnit', 'ScientificConstant', 'Currency'],
         'slot_uri': 'lara:base/Currency/symbol'} })
    exchange_rate_eur: Optional[float] = Field(default=None, description="""currency exchange rate to Euro """, json_schema_extra = { "linkml_meta": {'alias': 'exchange_rate_eur',
         'domain_of': ['Currency'],
         'slot_uri': 'lara:base/Currency/exchange_rate_eur'} })
    datetime_last_modified: str = Field(default=..., description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/Currency/datetime_last_modified'} })
    description: Optional[str] = Field(default=None, description="""description of the currency""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Currency/description'} })


class LARAExtension(ConfiguredBaseModel):
    """
    \" To enable extensions to the LARA web UI, e.g., for adding new apps, features, or modules as IFrame or as a new page, this class can be used to store the information about the extension and its route in the extension menu structure. An (external) URL can be provided to point to an external resource / microservice or a Django app can be added. The extension can be added to the main menu or to a sub-menu. \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/LARAExtension',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    laraextension_id: Optional[str] = Field(default=None, description="""LARAExtension - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'laraextension_id',
         'domain_of': ['LARAExtension'],
         'slot_uri': 'lara:base/LARAExtension/laraextension_id'} })
    name: str = Field(default=..., description="""name of the extension""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LARAExtension/name'} })
    url: Optional[str] = Field(default=None, description="""External URL of the extension""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'LARAExtension',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LARAExtension/url'} })
    icon: Optional[str] = Field(default=None, description="""SVG icon of the extension""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['LARAExtension', 'Country'],
         'slot_uri': 'lara:base/LARAExtension/icon'} })
    parent: Optional[str] = Field(default=None, description="""parent extension for building a route / menu hierarchy""", json_schema_extra = { "linkml_meta": {'alias': 'parent',
         'domain_of': ['LARAExtension', 'Location'],
         'slot_uri': 'lara:base/LARAExtension'} })
    new_tab: bool = Field(default=..., description="""open in new tab""", json_schema_extra = { "linkml_meta": {'alias': 'new_tab',
         'domain_of': ['LARAExtension'],
         'slot_uri': 'lara:base/LARAExtension/new_tab'} })
    target_element: Optional[str] = Field(default=None, description="""target HTML element of the extension""", json_schema_extra = { "linkml_meta": {'alias': 'target_element',
         'domain_of': ['LARAExtension'],
         'slot_uri': 'lara:base/LARAExtension/target_element'} })
    components: Optional[dict] = Field(default=None, description="""components / templates of the extension""", json_schema_extra = { "linkml_meta": {'alias': 'components',
         'domain_of': ['LARAExtension'],
         'slot_uri': 'lara:base/LARAExtension/components'} })
    description: Optional[str] = Field(default=None, description="""description of the extension""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LARAExtension/description'} })


class GeoLocation(ConfiguredBaseModel):
    """
    \" Generic geo location information class to store geo location data.
    Like Decimal Degrees of the location of, e.g. a building, a sample, etc. ...

     .. todo:: accept only one input format, add converters to common formats
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/GeoLocation',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    geolocation_id: Optional[str] = Field(default=None, description="""GeoLocation - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'geolocation_id',
         'domain_of': ['GeoLocation'],
         'slot_uri': 'lara:base/GeoLocation/geolocation_id'} })
    name: str = Field(default=..., description="""Unique location name""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/GeoLocation/name'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/GeoLocation/iri'} })
    coordinates_dd_lat: float = Field(default=..., description="""in Decimal degrees (DD) - latitude, e.g., 54.0915068""", json_schema_extra = { "linkml_meta": {'alias': 'coordinates_dd_lat',
         'domain_of': ['GeoLocation'],
         'slot_uri': 'lara:base/GeoLocation/coordinates_dd_lat'} })
    coordinates_dd_long: float = Field(default=..., description="""in Decimal degrees (DD) - longitude, e.g., 13.4029247""", json_schema_extra = { "linkml_meta": {'alias': 'coordinates_dd_long',
         'domain_of': ['GeoLocation'],
         'slot_uri': 'lara:base/GeoLocation/coordinates_dd_long'} })
    elevation: Optional[int] = Field(default=None, description="""elevation in m above sea level""", json_schema_extra = { "linkml_meta": {'alias': 'elevation',
         'domain_of': ['GeoLocation'],
         'slot_uri': 'lara:base/GeoLocation/elevation'} })
    openstreetmap: Optional[str] = Field(default=None, description="""OpenStreetMap (www.openstreetmap.org) link to address""", json_schema_extra = { "linkml_meta": {'alias': 'openstreetmap',
         'domain_of': ['GeoLocation'],
         'slot_uri': 'lara:base/GeoLocation/openstreetmap'} })
    googlemap: Optional[str] = Field(default=None, description="""google maps link to address""", json_schema_extra = { "linkml_meta": {'alias': 'googlemap',
         'domain_of': ['GeoLocation'],
         'slot_uri': 'lara:base/GeoLocation/googlemap'} })
    datetime_last_modified: Optional[str] = Field(default=None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/GeoLocation/datetime_last_modified'} })
    description: Optional[str] = Field(default=None, description="""description of the geo location""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/GeoLocation/description'} })
    data_extra: Optional[list[str]] = Field(default=None, description="""this can be used to extend the geo location: like maps to location etc.""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['GeoLocation', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/ExtraData'} })


class Country(ConfiguredBaseModel):
    """
    \" generic country representation class \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/Country',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    country_id: Optional[str] = Field(default=None, description="""Country - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'country_id',
         'domain_of': ['Country'],
         'slot_uri': 'lara:base/Country/country_id'} })
    name: str = Field(default=..., description="""international name of the country""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Country/name'} })
    name_local: Optional[str] = Field(default=None, description="""local name of the country, e.g. Deutschland""", json_schema_extra = { "linkml_meta": {'alias': 'name_local',
         'domain_of': ['Country', 'CountrySubdivision', 'City'],
         'slot_uri': 'lara:base/Country/name_local'} })
    alpha2code: Optional[str] = Field(default=None, description="""International 2-letter code, like DE, SE, DK ...""", json_schema_extra = { "linkml_meta": {'alias': 'alpha2code',
         'domain_of': ['Country', 'CountrySubdivision'],
         'slot_uri': 'lara:base/Country/alpha2code'} })
    alpha3code: str = Field(default=..., description="""International 3-letter code, like DEU, USA, HEL ...""", json_schema_extra = { "linkml_meta": {'alias': 'alpha3code',
         'domain_of': ['Currency', 'Country'],
         'slot_uri': 'lara:base/Country/alpha3code'} })
    numeric_code: Optional[int] = Field(default=None, description="""International 3 number code, like 276 (for DEU)""", json_schema_extra = { "linkml_meta": {'alias': 'numeric_code',
         'domain_of': ['Currency', 'Country'],
         'slot_uri': 'lara:base/Country/numeric_code'} })
    phone_code: Optional[int] = Field(default=None, description="""International telephone code, like 49, 45, ...""", json_schema_extra = { "linkml_meta": {'alias': 'phone_code',
         'domain_of': ['Country'],
         'slot_uri': 'lara:base/Country/phone_code'} })
    icon: Optional[str] = Field(default=None, description="""XML/SVG icon / symbol / flag of the country""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['LARAExtension', 'Country'],
         'slot_uri': 'lara:base/Country/icon'} })
    currency: Optional[str] = Field(default=None, description="""currency""", json_schema_extra = { "linkml_meta": {'alias': 'currency',
         'domain_of': ['Country'],
         'slot_uri': 'lara:base/Currency'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/Country/iri'} })
    timezone: Optional[int] = Field(default=None, description="""time zone offset from UTC, e.g. 5, -3 """, json_schema_extra = { "linkml_meta": {'alias': 'timezone',
         'domain_of': ['Country', 'CountrySubdivision', 'City'],
         'slot_uri': 'lara:base/Country/timezone'} })
    description: Optional[str] = Field(default=None, description="""description of the country""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Country/description'} })


class SubdivisionType(ConfiguredBaseModel):
    """
    \" Country Subdivision Type: e.g. State, Province, Emirate, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/SubdivisionType',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    subdivisiontype_id: Optional[str] = Field(default=None, description="""SubdivisionType - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'subdivisiontype_id',
         'domain_of': ['SubdivisionType'],
         'slot_uri': 'lara:base/SubdivisionType/subdivisiontype_id'} })
    name: str = Field(default=..., description="""subdivision type, e.g. State, Province, Emirate, ... """, json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/SubdivisionType/name'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/SubdivisionType/iri'} })
    description: Optional[str] = Field(default=None, description="""description of subdivision type""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/SubdivisionType/description'} })


class CountrySubdivision(ConfiguredBaseModel):
    """
    \" Generic country subdivision  to fit federal states, provinces, counties etc. into the same concept Not limited to US federal states - also Germany and many other countries have them, s. pypi iso3166 and pycountry \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/CountrySubdivision',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    countrysubdivision_id: Optional[str] = Field(default=None, description="""CountrySubdivision - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'countrysubdivision_id',
         'domain_of': ['CountrySubdivision'],
         'slot_uri': 'lara:base/CountrySubdivision/countrysubdivision_id'} })
    name: Optional[str] = Field(default=None, description="""international name of the subdivision/federal state, Hessia, Thuringia, Baveria, ...""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/CountrySubdivision/name'} })
    name_local: Optional[str] = Field(default=None, description="""local name of the state, e.g. Hessen, Thüringen""", json_schema_extra = { "linkml_meta": {'alias': 'name_local',
         'domain_of': ['Country', 'CountrySubdivision', 'City'],
         'slot_uri': 'lara:base/CountrySubdivision/name_local'} })
    code: Optional[str] = Field(default=None, description="""multi-letter code, like US-MA, DE-TH ,  ...""", json_schema_extra = { "linkml_meta": {'alias': 'code',
         'domain_of': ['CountrySubdivision'],
         'slot_uri': 'lara:base/CountrySubdivision/code'} })
    alpha2code: Optional[str] = Field(default=None, description="""2-letter code, like MA, BY, DK ...""", json_schema_extra = { "linkml_meta": {'alias': 'alpha2code',
         'domain_of': ['Country', 'CountrySubdivision'],
         'slot_uri': 'lara:base/CountrySubdivision/alpha2code'} })
    subdivision_type: Optional[str] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'subdivision_type',
         'domain_of': ['CountrySubdivision'],
         'slot_uri': 'lara:base/SubdivisionType'} })
    country: str = Field(default=..., description="""country""", json_schema_extra = { "linkml_meta": {'alias': 'country',
         'domain_of': ['CountrySubdivision', 'City', 'Address'],
         'slot_uri': 'lara:base/Country'} })
    timezone: Optional[int] = Field(default=None, description="""time zone offset from UTC, e.g. 5, -3 """, json_schema_extra = { "linkml_meta": {'alias': 'timezone',
         'domain_of': ['Country', 'CountrySubdivision', 'City'],
         'slot_uri': 'lara:base/CountrySubdivision/timezone'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/CountrySubdivision/iri'} })
    description: Optional[str] = Field(default=None, description="""description of the country subdivision""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/CountrySubdivision/description'} })


class City(ConfiguredBaseModel):
    """
    \" Generic city representation class \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/City',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    city_id: Optional[str] = Field(default=None, description="""City - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'city_id',
         'domain_of': ['City'],
         'slot_uri': 'lara:base/City/city_id'} })
    name: str = Field(default=..., description="""international name of the city, e.g. Munich""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/City/name'} })
    name_local: Optional[str] = Field(default=None, description="""local name of the city, e.g. München""", json_schema_extra = { "linkml_meta": {'alias': 'name_local',
         'domain_of': ['Country', 'CountrySubdivision', 'City'],
         'slot_uri': 'lara:base/City/name_local'} })
    country: str = Field(default=..., description="""country""", json_schema_extra = { "linkml_meta": {'alias': 'country',
         'domain_of': ['CountrySubdivision', 'City', 'Address'],
         'slot_uri': 'lara:base/Country'} })
    subdivision: Optional[str] = Field(default=None, description="""country subdivision where the city is loacted""", json_schema_extra = { "linkml_meta": {'alias': 'subdivision',
         'domain_of': ['City', 'Address'],
         'slot_uri': 'lara:base/CountrySubdivision'} })
    timezone: Optional[int] = Field(default=None, description="""time zone offset from UTC, e.g. 5, -3 """, json_schema_extra = { "linkml_meta": {'alias': 'timezone',
         'domain_of': ['Country', 'CountrySubdivision', 'City'],
         'slot_uri': 'lara:base/City/timezone'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/City/iri'} })
    description: Optional[str] = Field(default=None, description="""description of the city""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/City/description'} })


class Address(ConfiguredBaseModel):
    """
    \" generic Address class: this class can be used to store all kind of Addresses \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/Address',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    address_id: Optional[str] = Field(default=None, description="""Address - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'address_id',
         'domain_of': ['Address'],
         'slot_uri': 'lara:base/Address/address_id'} })
    namespace: str = Field(default=..., description="""namespace of address""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'ExternalResource', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/Namespace'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/Address/iri'} })
    building: Optional[str] = Field(default=None, description="""in case the institution is within a bigger complex/campus""", json_schema_extra = { "linkml_meta": {'alias': 'building',
         'domain_of': ['Address'],
         'slot_uri': 'lara:base/Address/building'} })
    street: Optional[str] = Field(default=None, description="""street, excluding house number""", json_schema_extra = { "linkml_meta": {'alias': 'street',
         'domain_of': ['Address'],
         'slot_uri': 'lara:base/Address/street'} })
    house_number: Optional[str] = Field(default=None, description="""house number""", json_schema_extra = { "linkml_meta": {'alias': 'house_number',
         'domain_of': ['Address'],
         'slot_uri': 'lara:base/Address/house_number'} })
    supplement: Optional[str] = Field(default=None, description="""address supplement info to make it unique, like c/o, room/floor""", json_schema_extra = { "linkml_meta": {'alias': 'supplement',
         'domain_of': ['Address'],
         'slot_uri': 'lara:base/Address/supplement'} })
    city: Optional[str] = Field(default=None, description="""city""", json_schema_extra = { "linkml_meta": {'alias': 'city', 'domain_of': ['Address'], 'slot_uri': 'lara:base/City'} })
    subdivision: Optional[str] = Field(default=None, description="""e.g. federal state, like Thuringia or Alaska""", json_schema_extra = { "linkml_meta": {'alias': 'subdivision',
         'domain_of': ['City', 'Address'],
         'slot_uri': 'lara:base/CountrySubdivision'} })
    country: Optional[str] = Field(default=None, description="""country""", json_schema_extra = { "linkml_meta": {'alias': 'country',
         'domain_of': ['CountrySubdivision', 'City', 'Address'],
         'slot_uri': 'lara:base/Country'} })
    postal_code: Optional[str] = Field(default=None, description="""postal code / ZIP""", json_schema_extra = { "linkml_meta": {'alias': 'postal_code',
         'domain_of': ['Address'],
         'slot_uri': 'lara:base/Address/postal_code'} })
    geolocation: Optional[str] = Field(default=None, description="""Geographical location""", json_schema_extra = { "linkml_meta": {'alias': 'geolocation',
         'domain_of': ['Address', 'Location'],
         'slot_uri': 'lara:base/GeoLocation'} })
    datetime_last_modified: Optional[str] = Field(default=None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/Address/datetime_last_modified'} })
    description: Optional[str] = Field(default=None, description="""description of the address""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Address/description'} })
    data_extra: Optional[list[str]] = Field(default=None, description="""extra information to addresses""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['GeoLocation', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/ExtraData'} })


class RoomCategory(ConfiguredBaseModel):
    """
    \" room category: office, lab, lab_S1, lab_S2, ... seminar room \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/RoomCategory',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    roomcategory_id: Optional[str] = Field(default=None, description="""RoomCategory - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'roomcategory_id',
         'domain_of': ['RoomCategory'],
         'slot_uri': 'lara:base/RoomCategory/roomcategory_id'} })
    category: str = Field(default=..., description="""room category""", json_schema_extra = { "linkml_meta": {'alias': 'category',
         'domain_of': ['RoomCategory', 'Room'],
         'slot_uri': 'lara:base/RoomCategory/category'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/RoomCategory/iri'} })
    description: Optional[str] = Field(default=None, description="""room category description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/RoomCategory/description'} })


class Room(ConfiguredBaseModel):
    """
    \" Rooms and laboratories \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/Room',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    room_id: Optional[str] = Field(default=None, description="""Room - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'room_id',
         'domain_of': ['Room'],
         'slot_uri': 'lara:base/Room/room_id'} })
    namespace: Optional[str] = Field(default=None, description="""namespace of room""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'ExternalResource', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/Namespace'} })
    name: Optional[str] = Field(default=None, description="""name of the room - some rooms have names""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Room/name'} })
    category: Optional[str] = Field(default=None, description="""room category""", json_schema_extra = { "linkml_meta": {'alias': 'category',
         'domain_of': ['RoomCategory', 'Room'],
         'slot_uri': 'lara:base/RoomCategory'} })
    number: Optional[str] = Field(default=None, description="""room number""", json_schema_extra = { "linkml_meta": {'alias': 'number', 'domain_of': ['Room'], 'slot_uri': 'lara:base/Room/number'} })
    floor: Optional[str] = Field(default=None, description="""Floor""", json_schema_extra = { "linkml_meta": {'alias': 'floor', 'domain_of': ['Room'], 'slot_uri': 'lara:base/Room/floor'} })
    phone_number: Optional[str] = Field(default=None, description="""room phone number, if possible add the +Country code notation, e.g., +44 3834 420 4411""", json_schema_extra = { "linkml_meta": {'alias': 'phone_number',
         'domain_of': ['Room'],
         'slot_uri': 'lara:base/Room/phone_number'} })
    room_map: Optional[str] = Field(default=None, description="""location room map rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'room_map',
         'domain_of': ['Room'],
         'slot_uri': 'lara:base/Room/room_map'} })
    max_people: Optional[int] = Field(default=None, description="""max number of people for this room""", json_schema_extra = { "linkml_meta": {'alias': 'max_people',
         'domain_of': ['Room'],
         'slot_uri': 'lara:base/Room/max_people'} })
    area: Optional[float] = Field(default=None, description="""room area in square meters""", json_schema_extra = { "linkml_meta": {'alias': 'area', 'domain_of': ['Room'], 'slot_uri': 'lara:base/Room/area'} })
    volume: Optional[float] = Field(default=None, description="""room volume in cubic meters""", json_schema_extra = { "linkml_meta": {'alias': 'volume', 'domain_of': ['Room'], 'slot_uri': 'lara:base/Room/volume'} })
    features: Optional[dict] = Field(default=None, description="""features of this room, like sockets, lights, gas, furniture, infrastructure,...""", json_schema_extra = { "linkml_meta": {'alias': 'features',
         'domain_of': ['Room'],
         'slot_uri': 'lara:base/Room/features'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/Room/iri'} })
    description: Optional[str] = Field(default=None, description="""room description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Room/description'} })
    datetime_last_modified: Optional[str] = Field(default=None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/Room/datetime_last_modified'} })
    data_extra: Optional[list[str]] = Field(default=None, description="""extra information for this room""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['GeoLocation', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/ExtraData'} })


class LocationType(ConfiguredBaseModel):
    """
    \" Location type: e.g. shelf, drawer, box, container, device, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/LocationType',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    locationtype_id: Optional[str] = Field(default=None, description="""LocationType - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'locationtype_id',
         'domain_of': ['LocationType'],
         'slot_uri': 'lara:base/LocationType/locationtype_id'} })
    name: str = Field(default=..., description="""location type name""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LocationType/name'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/LocationType/iri'} })
    description: Optional[str] = Field(default=None, description="""description of the location type""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LocationType/description'} })


class Location(ConfiguredBaseModel):
    """
    \" Physical location of objects like device, substances, organisms, containers etc., at concrete place, e.g., in shelf or drawer in a lab or room. .. todo: a foreign key to a device for modelling a location in a device could be considered,
             but generates an additional dependency.....
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/Location',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    location_id: Optional[str] = Field(default=None, description="""Location - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'location_id',
         'domain_of': ['Location'],
         'slot_uri': 'lara:base/Location/location_id'} })
    namespace: Optional[str] = Field(default=None, description="""namespace of location""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'ExternalResource', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/Namespace'} })
    name: str = Field(default=..., description="""Unique location name""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Location/name'} })
    location_type: Optional[str] = Field(default=None, description="""location type, e.g. shelf, drawer, box, container, device, ...""", json_schema_extra = { "linkml_meta": {'alias': 'location_type',
         'domain_of': ['Location'],
         'slot_uri': 'lara:base/LocationType'} })
    parent: Optional[str] = Field(default=None, description="""mptt - parent projects""", json_schema_extra = { "linkml_meta": {'alias': 'parent',
         'domain_of': ['LARAExtension', 'Location'],
         'slot_uri': 'lara:base/Location'} })
    barcode: Optional[str] = Field(default=None, description="""text representation of a barcode of the location.""", json_schema_extra = { "linkml_meta": {'alias': 'barcode',
         'domain_of': ['Location'],
         'slot_uri': 'lara:base/Location/barcode'} })
    barcode_json: Optional[dict] = Field(default=None, description="""Advanced barcodes in JSON for multiple barcode representations, like QR codes etc.""", json_schema_extra = { "linkml_meta": {'alias': 'barcode_json',
         'domain_of': ['Location'],
         'slot_uri': 'lara:base/Location/barcode_json'} })
    geolocation: Optional[str] = Field(default=None, description="""geo location""", json_schema_extra = { "linkml_meta": {'alias': 'geolocation',
         'domain_of': ['Address', 'Location'],
         'slot_uri': 'lara:base/GeoLocation'} })
    address: Optional[str] = Field(default=None, description="""reference to an address""", json_schema_extra = { "linkml_meta": {'alias': 'address', 'domain_of': ['Location'], 'slot_uri': 'lara:base/Address'} })
    location_json: Optional[dict] = Field(default=None, description="""JSON field for advanced location specification - can be used to store, e.g. locations in a device""", json_schema_extra = { "linkml_meta": {'alias': 'location_json',
         'domain_of': ['Location'],
         'slot_uri': 'lara:base/Location/location_json'} })
    iri: Optional[str] = Field(default=None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['MediaType',
                       'DataType',
                       'Tag',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location'],
         'slot_uri': 'lara:base/Location/iri'} })
    url: Optional[str] = Field(default=None, description="""Universal Resource Locator - this can be used to link this location to an external location""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'LARAExtension',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Location/url'} })
    datetime_last_modified: Optional[str] = Field(default=None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'ScientificConstant',
                       'Currency',
                       'GeoLocation',
                       'Address',
                       'Room',
                       'Location'],
         'slot_uri': 'lara:base/Location/datetime_last_modified'} })
    description: Optional[str] = Field(default=None, description="""location description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/Location/description'} })
#     lft: Optional[int] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'lft',
#          'domain_of': ['Location'],
#          'slot_uri': 'lara:base/Location/lft'} })
#     rght: Optional[int] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'rght',
#          'domain_of': ['Location'],
#          'slot_uri': 'lara:base/Location/rght'} })
#     tree_id: Optional[int] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'tree_id',
#          'domain_of': ['Location'],
#          'slot_uri': 'lara:base/Location/tree_id'} })
#     level: Optional[int] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'level',
#          'domain_of': ['Location'],
#          'slot_uri': 'lara:base/Location/level'} })
    data_extra: Optional[list[str]] = Field(default=None, description="""like maps to location etc.""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['GeoLocation', 'Address', 'Room', 'Location'],
         'slot_uri': 'lara:base/ExtraData'} })


class LARASyncServer(ConfiguredBaseModel):
    """
    \" LARA synchronisation Server description, e.g., for synchronisation between two LARA instances or other server types. \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:base/LARASyncServer',
         'from_schema': 'https://w3id.org/lara/lara_django_base'})

    laraserver_id: Optional[str] = Field(default=None, description="""LARASyncServer - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'laraserver_id',
         'domain_of': ['LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/laraserver_id'} })
    name: Optional[str] = Field(default=None, description="""human readable name of the Sync server""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['MediaType',
                       'DataType',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/name'} })
    url: Optional[str] = Field(default=None, description="""Universal Resource Locator - URL of the LARA server""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData',
                       'ExternalResource',
                       'LARAExtension',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/url'} })
    port: Optional[int] = Field(default=None, description="""port of the LARA server""", json_schema_extra = { "linkml_meta": {'alias': 'port',
         'domain_of': ['LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/port'} })
    server_type: str = Field(default=..., description="""type of server to be synchronised with""", json_schema_extra = { "linkml_meta": {'alias': 'server_type',
         'domain_of': ['LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/server_type'} })
    connection_json: Optional[dict] = Field(default=None, description="""JSON field for more advanced connection information,e.g., advanced routing, ports, ..., could be even encrypted.""", json_schema_extra = { "linkml_meta": {'alias': 'connection_json',
         'domain_of': ['LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/connection_json'} })
    auth_json: Optional[dict] = Field(default=None, description="""JSON field for authentication information, e.g. username, password, token, ..., could be even encrypted""", json_schema_extra = { "linkml_meta": {'alias': 'auth_json',
         'domain_of': ['LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/auth_json'} })
    cert_pub: Optional[str] = Field(default=None, description="""server public certificate""", json_schema_extra = { "linkml_meta": {'alias': 'cert_pub',
         'domain_of': ['LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/cert_pub'} })
    description: Optional[str] = Field(default=None, description="""server description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['MediaType',
                       'DataType',
                       'Namespace',
                       'ItemRole',
                       'ItemStatus',
                       'ExtraData',
                       'ExternalResource',
                       'PhysicalUnit',
                       'PhysicalStateMatter',
                       'ScientificConstant',
                       'Currency',
                       'LARAExtension',
                       'GeoLocation',
                       'Country',
                       'SubdivisionType',
                       'CountrySubdivision',
                       'City',
                       'Address',
                       'RoomCategory',
                       'Room',
                       'LocationType',
                       'Location',
                       'LARASyncServer'],
         'slot_uri': 'lara:base/LARASyncServer/description'} })
    tags: Optional[list[str]] = Field(default=None, description="""tags LARA server""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['ItemStatus', 'ExternalResource', 'LARASyncServer', 'Container'],
         'slot_uri': 'lara:base/Tag'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_base', 'tree_root': True})

    mediatypes: Optional[list[MediaType]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'mediatypes', 'domain_of': ['Container']} })
    datatypes: Optional[list[DataType]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'datatypes', 'domain_of': ['Container']} })
    namespaces: Optional[list[Namespace]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'namespaces', 'domain_of': ['Container']} })
    tags: Optional[list[Tag]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['ItemStatus', 'ExternalResource', 'LARASyncServer', 'Container']} })
    itemroles: Optional[list[ItemRole]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'itemroles', 'domain_of': ['Container']} })
    itemstatuss: Optional[list[ItemStatus]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'itemstatuss', 'domain_of': ['Container']} })
    extradatas: Optional[list[ExtraData]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'extradatas', 'domain_of': ['Container']} })
    externalresources: Optional[list[ExternalResource]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'externalresources', 'domain_of': ['Container']} })
    physicalunits: Optional[list[PhysicalUnit]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'physicalunits', 'domain_of': ['Container']} })
    physicalstatematters: Optional[list[PhysicalStateMatter]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'physicalstatematters', 'domain_of': ['Container']} })
    scientificconstants: Optional[list[ScientificConstant]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'scientificconstants', 'domain_of': ['Container']} })
    currencys: Optional[list[Currency]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'currencys', 'domain_of': ['Container']} })
    laraextensions: Optional[list[LARAExtension]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'laraextensions', 'domain_of': ['Container']} })
    geolocations: Optional[list[GeoLocation]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'geolocations', 'domain_of': ['Container']} })
    countrys: Optional[list[Country]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'countrys', 'domain_of': ['Container']} })
    subdivisiontypes: Optional[list[SubdivisionType]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'subdivisiontypes', 'domain_of': ['Container']} })
    countrysubdivisions: Optional[list[CountrySubdivision]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'countrysubdivisions', 'domain_of': ['Container']} })
    citys: Optional[list[City]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'citys', 'domain_of': ['Container']} })
    addresss: Optional[list[Address]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'addresss', 'domain_of': ['Container']} })
    roomcategorys: Optional[list[RoomCategory]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'roomcategorys', 'domain_of': ['Container']} })
    rooms: Optional[list[Room]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'rooms', 'domain_of': ['Container']} })
    locationtypes: Optional[list[LocationType]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'locationtypes', 'domain_of': ['Container']} })
    locations: Optional[list[Location]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'locations', 'domain_of': ['Container']} })
    larasyncservers: Optional[list[LARASyncServer]] = Field(default=None, json_schema_extra = { "linkml_meta": {'alias': 'larasyncservers', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
MediaType.model_rebuild()
DataType.model_rebuild()
Namespace.model_rebuild()
Tag.model_rebuild()
ItemRole.model_rebuild()
ItemStatus.model_rebuild()
ExtraData.model_rebuild()
ExternalResource.model_rebuild()
PhysicalUnit.model_rebuild()
PhysicalStateMatter.model_rebuild()
ScientificConstant.model_rebuild()
Currency.model_rebuild()
LARAExtension.model_rebuild()
GeoLocation.model_rebuild()
Country.model_rebuild()
SubdivisionType.model_rebuild()
CountrySubdivision.model_rebuild()
City.model_rebuild()
Address.model_rebuild()
RoomCategory.model_rebuild()
Room.model_rebuild()
LocationType.model_rebuild()
Location.model_rebuild()
LARASyncServer.model_rebuild()
Container.model_rebuild()

