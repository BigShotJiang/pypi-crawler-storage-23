"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django  relation resolver interface *

:details: The relation resolver is used to resolve foreign keys, e.g. by name or IRI instead of an id.
           The resolver takes the datamodel and checks, if it has valid UUIDs for the foreign keys and many-to-many fields.
           If not, it tries to resolve the foreign keys by name or IRI.
           It can use the slot-uri to import the right LARA high-level interface,
           queries the corresponding field and returns the UUIDs.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - fix: LinkML model to have ForeignKey and ManyToManyField types
            - fix slot-urls have info about the high-level interface
            - add class_URI
________________________________________________________________________
"""

import typing
from abc import ABCMeta
from abc import abstractmethod
from uuid import UUID
import grpc
import logging
from collections import namedtuple

# Define a named tuple for the retrieval method and parameters
RetrMethod = namedtuple('RetrMethod', ['method', 'params'])

logger = logging.getLogger(__name__)


class RelationResolverInterface(metaclass=ABCMeta):
    """RelationResolverInterface formal Interface
    TODO:
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, "resolve") and callable(subclass.resolve)) or NotImplemented

    @abstractmethod
    async def resolve(self, **kwargs):
        """resolve a relation"""
        raise NotImplementedError

class RelationResolverBase(RelationResolverInterface):
    """Relation Resolver for LARA base models"""

    def _prepare_parameters(self, data_model, key: str = None, parameters: dict = {}) -> dict:
        """
        Prepare the parameters for the resolver. This helper function detects
        if 'key' is used as an attribute in the 'data_model' and replaces it with the value.
        """
        parameter_dict = {}
        for param_name, attribute in parameters.items():
            if attribute == key:
                parameter_dict[param_name] = getattr(data_model, attribute)
            else:
                parameter_dict[param_name] = attribute
        return parameter_dict

    async def resolve(self, data_model=None):
        """
        Resolve all relations, like foreign keys, many-to-many, etc. Uses local variable
        'data_model' instead of storing it on 'self' to avoid overwriting shared state.
        """

        for key, retr_methods in self.relation_finder_dict.items():
            try:
                if not is_valid_uuid(getattr(data_model, key)):
                    for retr_method in retr_methods:
                        try:
                            params = self._prepare_parameters(data_model, key=key, parameters=retr_method.params)
                            item = await retr_method.method(**params)
                            if item:
                                setattr(data_model, key, item)
                                break
                        except Exception as e:
                            logger.exception(f"Error resolving {key}")
            except Exception as e:
                logger.exception(f"Error resolving {key}")

        return data_model


def is_valid_uuid(uuid: str) -> bool:
    r"""check if a string is a valid UUID
    To check, whether a string is a valid UUID, we can use the UUID class from the uuid module
    or a regular expression:
        # Regular expression pattern for a UUID
        uuid_regex = re.compile(
            r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\Z', re.I
        )
        def is_valid_uuid_regex(uuid: str) -> bool:
            # Check if a string is a valid UUID using a regular expression.
            return bool(uuid_regex.match(uuid))
    """
    try:
        UUID(uuid)  # could also use a regular expression
        return True
    except ValueError:
        return False


def resolve_foreign_key(foreign_key: str) -> str:
    """resolve a foreign key by name or IRI
    To resolve a foreign key, we can use the slot-uri to import the right LARA high-level interface,
    query the corresponding field and return the UUID.
    """
    # import the right LARA high-level interface
    # query the corresponding field
    # return the UUID


def resolve_many_to_many_field(many_to_many_field: str) -> str:
    """resolve a many-to-many field by name or IRI
    To resolve a many-to-many field, we can use the slot-uri to import the right LARA high-level interface,
    query the corresponding field and return the UUID.
    """
    # import the right LARA high-level interface
    # query the corresponding field
    # return the UUID


def resolve(data_model_instance=None):
    """resolve a relation, e.g. by name or IRI. It takes a LARA data model (=pydantic base model)
    and iterates over the fields to check if the foreign keys are valid UUIDs.
      If not, it tries to resolve the foreign keys by name or IRI.
         It can use the slot-uri to import the right LARA high-level interface,
         queries the corresponding field and returns the UUIDs.
    """

    # get types of the data model instance
    # this will return a dictionary with the field names and their types
    field_types_dict = typing.get_type_hints(data_model_instance)

    for field_name, field_type in field_types_dict.items():
        # check if the field is a foreign key
        if field_type.__class__.__name__ == "ForeignKey":
            # get the foreign key field
            foreign_key_field = getattr(data_model_instance, field_name)
            # check if the foreign key is a valid UUID
            if not is_valid_uuid(foreign_key_field):
                # if not, resolve the foreign key
                resolved_foreign_key = resolve_foreign_key(foreign_key_field)
                # set the resolved foreign key
                setattr(data_model_instance, field_name, resolved_foreign_key)
        # check if the field is a many-to-many field
        if field_type.__class__.__name__ == "ManyToManyField":
            # get the many-to-many field
            many_to_many_field = getattr(data_model_instance, field_name)
            # check if the many-to-many field is a valid UUID
            if not is_valid_uuid(many_to_many_field):
                # if not, resolve the many-to-many field
                resolved_many_to_many_field = resolve_many_to_many_field(many_to_many_field)
                # set the resolved many-to-many field
                setattr(data_model_instance, field_name, resolved_many_to_many_field)

    # iterate over the data model instance

    for field_name, value in data_model_instance:
        print(field_name, value)
        # check if the field is a foreign key
