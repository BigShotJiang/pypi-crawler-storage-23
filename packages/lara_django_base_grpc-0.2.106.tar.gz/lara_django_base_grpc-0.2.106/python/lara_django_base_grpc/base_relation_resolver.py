"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django base relation resolver *

:details: The relation resolver is used to resolve foreign keys, e.g. by name or IRI instead of an id.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import logging
import grpc

from lara_django_base_grpc.relation_resolver_interface import (
    RetrMethod,
    RelationResolverBase,
    is_valid_uuid,
)

from typing import Any, Union, List, Dict, Tuple, Optional

import lara_django_base_grpc.lara_django_base_data_model as base_dm
import lara_django_base_grpc.lara_django_base_interface as base_if

logger = logging.getLogger(__name__)

class CityRelationResolver(RelationResolverBase):
    """Relation Resolver for LARA city models"""

    def __init__(self, channel: grpc.Channel = None):
        try:
            self.country_if = base_if.CountryInterface(channel=channel)
        except Exception as e:
            logger.error(f"Error creating interfaces: {e}")

        self.relation_finder_dict = {
            "country": [
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"name": "country"}
                ),
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"name_local": "country"}
                ),
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"alpha2code": "country"}
                ),
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"alpha3code": "country"}
                ),
            ],
        }

class AddressRelationResolver(RelationResolverBase):
    """Relation Resolver for LARA address models"""

    def __init__(self, channel: grpc.Channel = None):
        try:
            self.city_if = base_if.CityInterface(channel=channel)
            self.subdivision_if = base_if.CountrySubdivisionInterface(channel=channel)
            self.country_if = base_if.CountryInterface(channel=channel)
            self.geolocation_if = base_if.GeoLocationInterface(channel=channel)

        except Exception as e:
            logger.error(f"Error creating interfaces: {e}")

        self.relation_finder_dict = {
            "city": [
                RetrMethod(method=self.city_if.retrieve_id, params={"name": "city"}),
                RetrMethod(
                    method=self.city_if.retrieve_id, params={"name_local": "city"}
                ),
            ],
            "subdivision": [
                RetrMethod(
                    method=self.subdivision_if.retrieve_id,
                    params={"name": "subdivision"},
                ),
            ],
            "country": [
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"name": "country"}
                ),
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"name_local": "country"}
                ),
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"alpha2code": "country"}
                ),
                RetrMethod(
                    method=self.country_if.retrieve_id, params={"alpha3code": "country"}
                ),
            ],
            "geolocation": [
                RetrMethod(
                    method=self.geolocation_if.retrieve_id, params={"name": "geolocation"}
                ),
            ],
        }

class RoomRelationResolver(RelationResolverBase):
    """Relation Resolver for LARA room models"""

    def __init__(self, channel: grpc.Channel = None):
        try:
            self.category_if = base_if.RoomCategoryInterface(channel=channel)
        except Exception as e:
            logger.error(f"Error creating interfaces: {e}")

        self.relation_finder_dict = {
            "category": [
                RetrMethod(
                    method=self.category_if.retrieve_id, params={"name": "category"}
                ),
            ],
        }

class LocationRelationResolver(RelationResolverBase):
    """Relation Resolver for LARA location models"""

    def __init__(self, channel: grpc.Channel = None):
        try:
            self.geolocation_if = base_if.GeoLocationInterface(channel=channel)
            self.address_if = base_if.AddressInterface(channel=channel)
            self.room_if = base_if.RoomInterface(channel=channel)
        except Exception as e:
            logger.error(f"Error creating interfaces: {e}")

        self.relation_finder_dict = {
            "geolocation": [
                RetrMethod(
                    method=self.geolocation_if.retrieve_id, params={"name": "geolocation"}
                ),
            ],
            "address": [
                RetrMethod(
                    method=self.address_if.retrieve_id, params={"name": "address"}
                ),
            ]
        }