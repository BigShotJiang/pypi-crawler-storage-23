"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django  abstract high-level LARA interface definition for remote access of the LARA database via gRPC *

:details: 
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""
from os import environ
from abc import ABCMeta, abstractmethod
from typing import Any, Union, List, Dict, Tuple, Optional
import functools
import json
import yaml
import asyncio
import grpc.aio
import io

from logging import getLogger

logger = getLogger(__name__)

class LARAInterface(metaclass=ABCMeta):
    """LARA formal Interface
    TODO:
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, "create")
            and callable(subclass.create)
            and hasattr(subclass, "retrieve")
            and callable(subclass.retrieve)
            and hasattr(subclass, "retrieve_id")
            and callable(subclass.retrieve_id)
            and hasattr(subclass, "list")
            and callable(subclass.list)
            and hasattr(subclass, "update")
            and callable(subclass.update)
            and hasattr(subclass, "delete")
            and callable(subclass.delete)
            or NotImplemented
        )

    @abstractmethod
    async def create(self, **kwargs):
        """create a new object"""
        raise NotImplementedError

    @abstractmethod
    async def retrieve(self, **kwargs):
        """retrieve an object"""
        raise NotImplementedError

    @abstractmethod
    async def retrieve_id(self, **kwargs):
        """retrieve an object"""
        raise NotImplementedError

    @abstractmethod
    async def list(self, **kwargs):
        """list objects"""
        raise NotImplementedError

    @abstractmethod
    async def update(self, **kwargs):
        """update an object"""
        raise NotImplementedError

    @abstractmethod
    async def delete(self, **kwargs):
        """delete an object"""
        raise NotImplementedError

class GRPCChannelSingleton(object):
    """
    Singleton for gRPC channel
    creates a secure channel, if possible, otherwise an insecure channel
    the gRPC channel is created with the environment variables LARA_GRPC_SERVER_HOST and LARA_GRPC_SERVER_PORT
    and stored in the instance variable 'channel'
    s. https://python-patterns.guide/gang-of-four/singleton/
    """
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(GRPCChannelSingleton, cls).__new__(cls)

            # try to create a secure gRPC channel
            try:
                # TODO: add correct secure channel creation
                cls._instance = grpc.aio.secure_channel(f"{environ['LARA_GRPC_SERVER_HOST']}:{environ['LARA_GRPC_SERVER_PORT']}", grpc.ssl_channel_credentials())
            except Exception as e:
                logger.exception(f"Secure channel creation failed with error - check, if environment variables are set correctly: {e}")

            # if secure channel creation failed, create an insecure channel
            try:
                cls._instance.channel = grpc.aio.insecure_channel(f"{environ['LARA_GRPC_SERVER_HOST']}:{environ['LARA_GRPC_SERVER_PORT']}")
            except Exception as e:
                logger.exception(f"Insecure channel creation failed with error - check, if environment variables are set correctly:: {e}")

                cls._instance.channel = None

        return cls._instance


# id_cache decorator
def id_cache(func):
    """
    id_cache decorator caches the id of a model instance, if the instance id has been retrieved
    """

    @functools.wraps(func)
    async def wrapper_id_cache(*args, **kwargs):
        if args[0] not in wrapper_id_cache.cache:
            wrapper_id_cache.cache[args[0]] = await func(*args, **kwargs)
            return wrapper_id_cache.cache[args[0]]
        else:
            return wrapper_id_cache.cache[args[0]]

    wrapper_id_cache.cache = dict()
    return wrapper_id_cache


# JSON / YAML import decorator
def import_model_instance_from_file(relation_resolver=None):
    """
    Import data model from file (json or YAML) decorator
    :param format: format of the file, e.g. 'json' or 'yaml'
    :param import_filename_source: name of the JSON or YAML file to import
    :param relation_resolver: function to resolve relations, e.g. resolve foreign keys by name
    """

    def decorator_import_from_file(func):
        """Import from file"""

        @functools.wraps(func)
        async def wrapper(self, *args, data_model=None, 
                          format=None, import_filename_source=None, 
                          **kwargs):
            nonlocal relation_resolver
            res = None
            if 'relation_resolver' in kwargs:
                relation_resolver = kwargs.pop('relation_resolver')
            print(f"------ relation_resolver: {relation_resolver}")
            data_models_resolved = []
            res_list = []
            if format is None:
                # determine the format from the file extension
                if import_filename_source is not None:
                    if import_filename_source.endswith(".json"):
                        format = "json"
                    elif import_filename_source.endswith(".yaml"):
                        format = "yaml"
                else:
                    if relation_resolver is not None:
                        print(f"-*---- args: {args[0]}")
                        data_models_resolved = [relation_resolver.resolve(data_model=item) for item in args[0]]
                        res = await asyncio.gather(*data_models_resolved)
                        print(f"------ res: {res}")
                        return await func(self, res, *args, **kwargs)
                    

                    print(f"------ calling func args: {args[0]}")
                    return await func(self, *args, **kwargs)
            if format.lower() == "json":
                if import_filename_source is not None:
                    with open(import_filename_source, "r") as f:
                        data_json = json.load(f)
                else:
                    data_json = json.loads(args[0])

                if data_model is not None:
                    if relation_resolver is not None:
                        data_models_resolved = [relation_resolver.resolve(data_model=data_model(**item)) for item in data_json]
                        res = await asyncio.gather(*data_models_resolved)
                    else:
                        res= [data_model(**item) for item in data_json]

                return func(self, res, *args, **kwargs)

            if format.lower() == "yaml":
                if import_filename_source is not None:
                    with open(import_filename_source) as f:
                        data_yaml = yaml.safe_load(f)
                else:
                    data_yaml = yaml.safe_load(args[0])

                if data_model is None:
                    raise ValueError("data_model must be provided")
                
                print(f"------ data_yaml: {data_yaml}")
                if relation_resolver is not None:
                    data_models_resolved = [relation_resolver.resolve(data_model=data_model(**item)) for item in data_yaml]
                    res = await asyncio.gather(*data_models_resolved)
                else:
                    res = [data_model(**item) for item in data_yaml]


                print(f"------ res: {res}")

                return await func(self, res, *args, **kwargs)
            return None
        return wrapper
    return decorator_import_from_file


# JSON / YAML export decorator
def export_model_instance_to_file(func):
    """Export to file or string decorator"""

    @functools.wraps(func)
    async def wrapper(*args, format=None, indent=None, filename_target=None, **kwargs):
        if format is None:
            # determine the format from the file extension
            if filename_target is not None:
                if filename_target.endswith(".json"):
                    format = "json"
                elif filename_target.endswith(".yaml"):
                    format = "yaml"
            else:
                return await func(*args, **kwargs)
        if format.lower() == "json":
            res = await func(*args, **kwargs)

            if filename_target is not None:
                with open(filename_target, "w") as f:
                    f.write("[" + ",\n".join([item.model_dump_json(indent=indent) for item in res]) + "]")

            else:
                return "[" + ",\n".join([item.model_dump_json(indent=indent) for item in res]) + "]"

        elif format.lower() == "yaml":
            res = await func(*args, **kwargs)

            res_json = "[" + ",\n".join([item.model_dump_json() for item in res]) + "]"

            if filename_target is not None:
                with open(filename_target, "w") as f:
                    yaml.dump(yaml.safe_load(res_json), f, indent=indent)
            else:
                return yaml.dump(yaml.safe_load(res_json), indent=indent)
    return wrapper


def _read_in_chunks(file=None, chunk_size=64 * 1024, file_chunk=None, filename_target=None, update_item_id=None):
    while True:
        # print(f"reading chunk - {chunk_size} bytes")
        data = file.read(chunk_size)
        if not data:
            break
        yield file_chunk(filename=filename_target, update_item_id=update_item_id, data=data)


# Performs a client-streaming call
def upload_file(func):
    """
    file upload decorator - loads a file from the file system and uploads it in chunks
    to the gRPC server
    """

    # def decorator_update_image(func):
    #     """Update image inner decorator method"""

    @functools.wraps(func)
    async def wrapper(
        self,
        *args,
        filename_source : str = None,
        filename_target : str = None,
        byte_string : bytes = None,
        chunk_size : int = 64 * 1024,
        **kwargs,
    ):
        # first update the data
        # print(f"###### --- file create ")
        # print(f"sf: {filename_source}")
        # print(f"tf: {filename_target}")
        # print(f"cs: {chunk_size}")

        if filename_source is None:
            if byte_string is not None:
                items = await func(self, *args, ids_only=True, **kwargs)
            
                print(f"update_item_id: {self.update_item_id} - {items}")
                if len(items) > 1:
                    raise ValueError("Only one item with a file can be created at a time")
                print(f"###### --- file create - byte string", byte_string)
                
                with io.BytesIO(byte_string) as _file:
                    chunk_iterator = _read_in_chunks(
                        file=_file, chunk_size=chunk_size, file_chunk=self.file_upload_chunk, filename_target=filename_target
                    )
                    try:
                        print(f"###### --- create file decorator - upload file {filename_target}]")
                        response = await self.stub.UploadFile(chunk_iterator)
                    except grpc.aio.AioRpcError as error:
                        print(f"Uploading file {filename_source}/{filename_target} failed with error: {error}")
                        logger.exception(f"Uploading file {filename_source}/{filename_target} failed with error: {error}")
                    else:
                        print(f"Create status: {response.success}")
                        logger.info(f"Create status: {response.success}")
                        return items

            items = await func(self, *args, **kwargs)
            return items
        else :
            items = await func(self, *args, ids_only=True, **kwargs)
            # print(f"update_item_id: {self.update_item_id} - {items}")
            if len(items) > 1:
                raise ValueError("Only one item with a file can be created at a time")
            
            # print("###### --- create file decorator - open file")
            # TODO: use aiofiles
            with open(filename_source, "rb") as file:
                chunk_iterator = _read_in_chunks(
                    file=file, chunk_size=chunk_size, file_chunk=self.file_upload_chunk, filename_target=filename_target, update_item_id=items[0]
                )
                try:
                    # print(f"###### --- create file decorator - upload file {filename_target}]")
                    response = await self.stub.UploadFile(chunk_iterator)
                except grpc.aio.AioRpcError as error:
                    #print(f"Uploading file {filename_source}/{filename_target} failed with error: {error}")
                    logger.exception(f"Uploading file {filename_source}/{filename_target} failed with error: {error}")
                else:
                    # print(f"Create status: {response.success}")
                    logger.info(f"Create status: {response.success}")
                    return items
    return wrapper

# Performs a client-streaming call
def download_file(func):
    """
    file download decorator - downloads a file in chunks from the gRPC server and writes it to the file system
    """
    @functools.wraps(func)
    async def wrapper(
        self,
        *args,
        #item_id : str = None,
        filename_target : str = None,
        chunk_size : int = 64 * 1024,
        as_byte_str : bool = False,
        as_byte_stream : bool = False,
        get_file : bool = False,
        id_only : bool = False,
        **kwargs,
    ):
        _file = None

        item = await func(self, *args, **kwargs, id_only=id_only)

        if id_only:
            return item
        
        if as_byte_str is True:
            with io.BytesIO() as _file:
                try:
                    async for chunk in self.stub.DownloadFile(self.file_download_info(item_id=self.item_id, chunk_size=chunk_size)):
                        _file.write(chunk.data)
                except grpc.aio.AioRpcError as error:
                    logger.exception(f"Downloading file as byte stream failed with error: {error}")
                _file.seek(0)
                byte_str =_file.getvalue()

            if item is None:
                return byte_str
            else:
                return item, byte_str
        elif as_byte_stream is True:
            async for chunk in self.stub.DownloadFile(self.file_download_info(item_id=self.item_id, chunk_size=chunk_size)):
                pass #yield chunk.data
        elif get_file is True or filename_target is not None:
            try:
                dl_info = self.file_download_info(item_id=self.item_id, chunk_size=chunk_size)
                async for chunk in self.stub.DownloadFile(dl_info):
                    if filename_target is None:
                        filename_target = chunk.filename
                    if _file is None:
                        _file = open(filename_target, "wb")
                    if _file is not None:
                        _file.write(chunk.data)
                _file.close()
            except grpc.aio.AioRpcError as error:
                    logger.exception(f"Downloading file {filename_target} failed with error: {error}")
            return item
        else:
            return item
    return wrapper


# Performs a client-streaming call
def update_file(func):
    """
    update file decorator - loads a file from the file system and uploads it in chunks to the gRPC server
    the model instance id is retrieved from the decorated method and is updated with the new filename
    """

    @functools.wraps(func)
    async def wrapper(
        self,
        *args,
        filename_source : str = None,
        filename_target : str = None,
        chunk_size : int = 64 * 1024,
        **kwargs,
    ):
        # first update the data
        print(f"###### --- update ")
        print(f"sf: {filename_source}")
        print(f"tf: {filename_target}")
        print(f"cs: {chunk_size}")

        res = await func(self, *args, **kwargs)
        
        if filename_source is not None:
            # print(f"update_item_id: {self.update_item_id}")
            update_item_id =  getattr(args[0],  self.update_item_id)
            
            # print("###### --- update file decorator - open file")
            with open(filename_source, "rb") as file:
                chunk_iterator = _read_in_chunks(
                    file=file, chunk_size=chunk_size, file_chunk=self.file_upload_chunk, filename_target=filename_target, update_item_id=update_item_id
                )
                try:
                    # print(f"###### --- update file decorator - upload file {filename_target}]")
                    response = await self.stub.UploadFile(chunk_iterator)
                except grpc.aio.AioRpcError as error:
                    print(f"Updating file {filename_source}/{filename_target} failed with error: {error}")

                else:
                    # print(f"Update status: {response.success}")
                    logger.info(f"Update status: {response.success}")
                    #return response.success
        return res
    return wrapper


# Performs a client-streaming call
def upload_image(func):
    """
    upload image decorator - loads an image file from the file system and uploads it in chunks to the gRPC server
    """

    # def decorator_update_image(func):
    #     """Update image inner decorator method"""

    @functools.wraps(func)
    async def wrapper(
        self,
        *args,
        image_filename_source : str = None,
        image_filename_target : str = None,
        chunk_size : int = 64 * 1024,
        **kwargs,
    ):
        # first update the data
        print(f"###### --- file create ")
        print(f"sf: {image_filename_source}")
        print(f"tf: {image_filename_target}")
        print(f"cs: {chunk_size}")

        if image_filename_source is None:
            items = await func(self, *args, **kwargs)
            return items
        else :
            items = await func(self, *args, ids_only=True, **kwargs)
            # print(f"update_item_id: {self.update_item_id} - {items}")
            if len(items) > 1:
                raise ValueError("Only one item with a file can be created at a time")
            
            print("###### --- create image decorator - open file", image_filename_source)
            # TODO: use aiofiles
            with open(image_filename_source, "rb") as file:
                chunk_iterator = _read_in_chunks(
                    file=file, chunk_size=chunk_size, file_chunk=self.image_upload_chunk, filename_target=image_filename_target, update_item_id=items[0]
                )
                try:
                    print(f"###### --- upload image decorator: {image_filename_target}]")
                    response = await self.stub.UploadImage(chunk_iterator)
                except grpc.aio.AioRpcError as error:
                    print(f"Uploading image {image_filename_source}/{image_filename_target} failed with error: {error}")
                else:
                    # print(f"Create status: {response.success}")
                    logger.info(f"Create image status: {response.success}")
                    return items
    return wrapper

# Performs a client-streaming call
def update_image(func):
    """
    update image decorator
    """

    # def decorator_update_image(func):
    #     """Update image inner decorator method"""

    @functools.wraps(func)
    async def wrapper(
        self,
        *args,
        image_filename_source : str = None,
        image_filename_target : str = None,
        chunk_size : int = 64 * 1024,
        **kwargs,
    ):
        res = await func(self, *args, **kwargs)

        if image_filename_source is not None:
         
            update_item_id =  getattr(args[0],  self.update_item_id)
            
            with open(image_filename_source, "rb") as file:
                chunk_iterator = _read_in_chunks(
                    file=file, chunk_size=chunk_size, file_chunk=self.image_upload_chunk, filename_target=image_filename_target, update_item_id=update_item_id
                )
                try:
                    response = await self.stub.UploadImage(chunk_iterator)
                    
                except grpc.aio.AioRpcError as error:
                    #print(f"Updating image {image_filename_source}/{image_filename_target} failed with error: {error}")
                    logger.exception(f"Updating image {image_filename_source}/{image_filename_target} failed with error: {error}")
                else:
                    logger.info(f"Update image status: {response.success}")
                    return res
    return wrapper
    # return decorator_update_image

# Performs a client-streaming call
def download_image(func):
    """
    file download decorator - downloads a file in chunks from the gRPC server and writes it to the file system
    """

    # def decorator_update_image(func):
    #     """Update image inner decorator method"""

    @functools.wraps(func)
    async def wrapper(
        self,
        *args,
        #image_id : str = None,
        image_filename_source : str = None,
        image_filename_target : str = None,
        chunk_size : int = 64 * 1024,
        as_byte_string : bool = False,
        id_only : bool = False,
        **kwargs,
    ):
        
        # first update the data
        print(f"###### --- file read ")
        print(f"sf: {image_filename_source}")
        print(f"tf: {image_filename_target}")
        print(f"cs: {chunk_size}")
        
        _file = None

        item = await func(self, *args, **kwargs, id_only=id_only)

        if id_only:
            return item

        if image_filename_target is None:
            items = await func(self, *args, **kwargs)
        else :
            # retrieve the item id
            item_data = {}
            items = await func(self, *args, ids_only=True, **kwargs)
            # print(f"update_item_id: {self.update_item_id} - {items}")
            
            for item in items:
                if as_byte_string:
                    print("###### --- download file decorator - open bytestring")
                    with io.BytesIO() as file:
                        try:
                            # print(f"###### --- download file decorator - download file {filename_source}]")
                            async for chunk in self.stub.DownloadImage(self.download_info(item_id=self.item_id, chunk_size=chunk_size)):
                                    file.write(chunk.data)
                                    # print(f"Read status: {response.success}")
                        except grpc.aio.AioRpcError as error:
                            # print(f"Downloading image {image_filename_source}/{image_filename_target} as byte string failed with error: {error}")
                            logger.exception(f"Downloading image {image_filename_source}/{image_filename_target} as byte string failed with error: {error}")

                    file.seek(0)
                    item_data[item] = file.getvalue()
                else:
                    print("###### --- download file decorator - open file {filename_target}")
                    with open(image_filename_target, "wb") as file:
                        try:
                            # print(f"###### --- download file decorator - download file {filename_source}]")
                            # self.download_info(item_id=item, chunk_size=chunk_size)
                            async for chunk in self.stub.DownloadImage(item_id=self.item_id, chunk_size=chunk_size):
                                    file.write(chunk.data)
                        except grpc.aio.AioRpcError as error:
                            # print(f"Downloading image {image_filename_source}/{image_filename_target} failed with error: {error}")
                            logger.exception(f"Downloading image {image_filename_source}/{image_filename_target} failed with error: {error}")
                        item_data[item] = None
            return item_data
    return wrapper