

$CONFIG_ROOT = "$HOME\.config\machineconfig"

function Add-ToPathIfNotAlready {
    param (
        [Parameter(Mandatory=$true)]
        [string[]]$Directories
    )
    foreach ($dir in $Directories) {
        if ($env:Path -notlike "*$dir*") {
            $env:Path += ";$dir"
        }
    }
}

# Use bun as node if available
if (Test-Path "$HOME\.bun\bin\bun.exe") {
    Set-Alias -Name node -Value "$HOME\.bun\bin\bun.exe" -Option AllScope
}

Add-ToPathIfNotAlready -Directories @(
    "$HOME\.local\bin",
    "$HOME\.bun\bin",
    "$CONFIG_ROOT\scripts",
    "$HOME\dotfiles\scripts\windows",
    "C:\Program Files (x86)\GnuWin32\bin",
    "C:\Program Files\CodeBlocks\MinGW\bin",
    "C:\Program Files\nu\bin",
    "C:\Program Files\Graphviz\bin",
    "C:\Program Files\7-Zip"
)

# sources  ================================================================
if (Test-Path "$CONFIG_ROOT\scripts\wrap_mcfg.ps1") {
    . $CONFIG_ROOT\settings\broot\brootcd.ps1
    . $CONFIG_ROOT\settings\lf\windows\lfcd.ps1
    . $CONFIG_ROOT\settings\tere\terecd.ps1
    . $CONFIG_ROOT\settings\yazi\shell\yazi_cd.ps1
    . $CONFIG_ROOT\scripts\wrap_mcfg.ps1

    function lsdla { lsd -la }
    Set-Alias -Name l -Value lsdla -Option AllScope

    function d { wrap_in_shell_script devops $args }
    function c { wrap_in_shell_script cloud $args }
    function a { wrap_in_shell_script agents $args }
    function fx { wrap_in_shell_script ftpx $args }
    function s { wrap_in_shell_script sessions $args }
    function f { wrap_in_shell_script fire $args }
    function rr { wrap_in_shell_script croshell $args }
    function u { wrap_in_shell_script utils $args }
    function ms { wrap_in_shell_script msearch $args }

}
else {
    Write-Host "Missing config files: $CONFIG_ROOT"
    function lsdla { lsd -la }
    Set-Alias -Name l -Value lsdla -Option AllScope
    function d { devops $args }
    function c { cloud $args }
    function a { agents $args }
    function s { sessions $args }
    function fx { ftpx $args }
    function f { fire $args }
    function rr { croshell $args }
    function u { utils $args }
    function ms { msearch $args }
}



# sources end

# try {
#     Set-Alias -Name gcs -Value {gh copilot suggest -t shell}
#     Set-Alias -Name gcg -Value {gh copilot suggest -t git}
#     Set-Alias -Name gce -Value {gh copilot explain}
#     # Check for conflicts
#     # Get-Command gcs -ErrorAction SilentlyContinue
#     # Get-Command gcg -ErrorAction SilentlyContinue
#     # Get-Command gce -ErrorAction SilentlyContinue
# }
# catch {
#     # Do nothing
# }


# patches ===========================================================

try {
    # patched by machineconfig from https://github.com/ajeetdsouza/zoxide
    Invoke-Expression (& {
        $hook = if ($PSVersionTable.PSVersion.Major -lt 6) { 'prompt' } else { 'pwd' }
        (zoxide init --hook $hook powershell | Out-String)
    })
}
catch {
    # Do nothing
}

try {
    # Initialize Starship prompt
    Invoke-Expression (&starship init powershell)
}
catch {
    # Do nothing
}


# history search =====================================================

if (Get-Command atuin -ErrorAction SilentlyContinue) {
    try {
        # Invoke-Expression (& atuin init powershell | Out-String)
        atuin init powershell --disable-up-arrow | Out-String | Invoke-Expression
    }
    catch {
        # Do nothing
    }
}
elseif (Get-Command mcfly -ErrorAction SilentlyContinue) {
    try {
        Invoke-Expression (& mcfly init powershell | Out-String)
    }
    catch {
        # Do nothing
    }
}
else {
    try {
        Import-Module PSReadLine -ErrorAction Stop | Out-Null
        Set-PSReadLineKeyHandler -Chord Ctrl+r -ScriptBlock {
            param($key, $arg)

            $buffer = $null
            $cursor = 0
            try { [Microsoft.PowerShell.PSConsoleReadLine]::GetBufferState([ref]$buffer, [ref]$cursor) } catch { }

            $selected = $null
            try {
                [Console]::WriteLine()
                $selected = (& tv pwsh-history 2>$null | Select-Object -First 1)
            }
            catch {
                $selected = $null
            }

            if ([string]::IsNullOrWhiteSpace($selected)) {
                return
            }

            $selected = $selected.TrimEnd("`r", "`n")

            try {
                $existingLen = if ($null -eq $buffer) { 0 } else { $buffer.Length }
                [Microsoft.PowerShell.PSConsoleReadLine]::Replace(0, $existingLen, $selected)
                try { [Microsoft.PowerShell.PSConsoleReadLine]::SetCursorPosition($selected.Length) } catch { }
            }
            catch {
                try { [Microsoft.PowerShell.PSConsoleReadLine]::Insert($selected) } catch { }
            }
        }
    }
    catch {
        # Do nothing
    }
}

