

from pathlib import Path
from typing import Annotated

import typer


def tree(
    show_help: Annotated[bool, typer.Option("--show-help/--no-show-help", help="Include help text in labels")] = True,
    show_aliases: Annotated[bool, typer.Option("--show-aliases/--no-show-aliases", help="Include aliases in labels")] = False,
    max_depth: Annotated[int | None, typer.Option("--max-depth", "-d", help="Limit depth of the tree")] = None,
) -> None:
    """Render a rich tree view in the terminal."""
    def func(show_help: bool, show_aliases: bool, max_depth: int | None) -> None:
        from machineconfig.scripts.python.graph.visualize.rich_tree import render_tree

        render_tree(show_help=show_help, show_aliases=show_aliases, max_depth=max_depth)

    from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
    from machineconfig.utils.code import get_shell_script_running_lambda_function, exit_then_run_shell_script

    if Path.home().joinpath("code", "machineconfig").exists():
        uv_with: list[str] = ["plotly", "kaleido"]
        uv_project_dir = str(Path.home().joinpath("code", "machineconfig"))
    else:
        uv_with = [MACHINECONFIG_VERSION, "plotly", "kaleido"]
        uv_project_dir = None

    shell_script, _pyfile = get_shell_script_running_lambda_function(
        lambda: func(
            show_help=show_help,
            show_aliases=show_aliases,
            max_depth=max_depth,
        ),
        uv_with=uv_with,
        uv_project_dir=uv_project_dir,
    )
    exit_then_run_shell_script(str(shell_script), strict=False)


def dot(
    output: Annotated[Path | None, typer.Option("--output", "-o", help="Write DOT output to a file")] = None,
    include_help: Annotated[bool, typer.Option("--include-help/--no-include-help", help="Include help text in labels")] = True,
    max_depth: Annotated[int | None, typer.Option("--max-depth", "-d", help="Limit depth of the graph")] = None,
) -> None:
    """Export the graph as Graphviz DOT."""
    def func(output_str: str | None, include_help: bool, max_depth: int | None) -> None:
        from pathlib import Path
        from machineconfig.scripts.python.graph.visualize.dot_export import render_dot

        output_path = Path(output_str) if output_str else None
        dot_text = render_dot(max_depth=max_depth, include_help=include_help)

        if output_path is None:
            print(dot_text)
        else:
            output_path.write_text(dot_text, encoding="utf-8")
            print(f"Wrote {output_path}")

    from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
    from machineconfig.utils.code import get_shell_script_running_lambda_function, exit_then_run_shell_script

    if Path.home().joinpath("code", "machineconfig").exists():
        uv_with: list[str] = ["plotly", "kaleido"]
        uv_project_dir = str(Path.home().joinpath("code", "machineconfig"))
    else:
        uv_with = [MACHINECONFIG_VERSION]
        uv_project_dir = None

    shell_script, _pyfile = get_shell_script_running_lambda_function(
        lambda: func(
            output_str=str(output) if output else None,
            include_help=include_help,
            max_depth=max_depth,
        ),
        uv_with=uv_with,
        uv_project_dir=uv_project_dir,
    )
    exit_then_run_shell_script(str(shell_script), strict=False)


def sunburst(
    output: Annotated[Path | None, typer.Option("--output", "-o", help="Write HTML or image output")] = None,
    max_depth: Annotated[int | None, typer.Option("--max-depth", "-d", help="Limit depth of the graph")] = None,
    template: Annotated[str, typer.Option("--template", help="Plotly template name")] = "plotly_dark",
    height: Annotated[int, typer.Option("--height", help="Image height (for static output)")] = 900,
    width: Annotated[int, typer.Option("--width", help="Image width (for static output)")] = 1200,
) -> None:
    """Render a Plotly sunburst view."""
    def func(
        output_str: str | None,
        max_depth: int | None,
        template: str,
        height: int,
        width: int,
    ) -> None:
        from pathlib import Path
        from machineconfig.scripts.python.graph.visualize.plotly_views import render_plotly

        output_path = Path(output_str) if output_str else None
        render_plotly(
            view="sunburst",
            output=output_path,
            height=height,
            width=width,
            template=template,
            max_depth=max_depth,
        )

    from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
    from machineconfig.utils.code import get_shell_script_running_lambda_function, exit_then_run_shell_script

    if Path.home().joinpath("code", "machineconfig").exists():
        uv_with = ["plotly", "kaleido"]
        uv_project_dir = str(Path.home().joinpath("code", "machineconfig"))
    else:
        uv_with = [MACHINECONFIG_VERSION, "plotly", "kaleido"]
        uv_project_dir = None

    shell_script, _pyfile = get_shell_script_running_lambda_function(
        lambda: func(
            output_str=str(output) if output else None,
            max_depth=max_depth,
            template=template,
            height=height,
            width=width,
        ),
        uv_with=uv_with,
        uv_project_dir=uv_project_dir,
    )
    exit_then_run_shell_script(str(shell_script), strict=False)


def treemap(
    output: Annotated[Path | None, typer.Option("--output", "-o", help="Write HTML or image output")] = None,
    max_depth: Annotated[int | None, typer.Option("--max-depth", "-d", help="Limit depth of the graph")] = None,
    template: Annotated[str, typer.Option("--template", help="Plotly template name")] = "plotly_dark",
    height: Annotated[int, typer.Option("--height", help="Image height (for static output)")] = 900,
    width: Annotated[int, typer.Option("--width", help="Image width (for static output)")] = 1200,
) -> None:
    """Render a Plotly treemap view."""
    def func(
        output_str: str | None,
        max_depth: int | None,
        template: str,
        height: int,
        width: int,
    ) -> None:
        from pathlib import Path
        from machineconfig.scripts.python.graph.visualize.plotly_views import render_plotly

        output_path = Path(output_str) if output_str else None
        render_plotly(
            view="treemap",
            output=output_path,
            height=height,
            width=width,
            template=template,
            max_depth=max_depth,
        )

    from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
    from machineconfig.utils.code import get_shell_script_running_lambda_function, exit_then_run_shell_script

    if Path.home().joinpath("code", "machineconfig").exists():
        uv_with = ["plotly", "kaleido"]
        uv_project_dir = str(Path.home().joinpath("code", "machineconfig"))
    else:
        uv_with = [MACHINECONFIG_VERSION, "plotly", "kaleido"]
        uv_project_dir = None

    shell_script, _pyfile = get_shell_script_running_lambda_function(
        lambda: func(
            output_str=str(output) if output else None,
            max_depth=max_depth,
            template=template,
            height=height,
            width=width,
        ),
        uv_with=uv_with,
        uv_project_dir=uv_project_dir,
    )
    exit_then_run_shell_script(str(shell_script), strict=False)


def icicle(
    output: Annotated[Path | None, typer.Option("--output", "-o", help="Write HTML or image output")] = None,
    max_depth: Annotated[int | None, typer.Option("--max-depth", "-d", help="Limit depth of the graph")] = None,
    template: Annotated[str, typer.Option("--template", help="Plotly template name")] = "plotly_dark",
    height: Annotated[int, typer.Option("--height", help="Image height (for static output)")] = 900,
    width: Annotated[int, typer.Option("--width", help="Image width (for static output)")] = 1200,
) -> None:
    """Render a Plotly icicle view."""
    def func(
        output_str: str | None,
        max_depth: int | None,
        template: str,
        height: int,
        width: int,
    ) -> None:
        from pathlib import Path
        from machineconfig.scripts.python.graph.visualize.plotly_views import render_plotly

        output_path = Path(output_str) if output_str else None
        render_plotly(
            view="icicle",
            output=output_path,
            height=height,
            width=width,
            template=template,
            max_depth=max_depth,
        )

    from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
    from machineconfig.utils.code import get_shell_script_running_lambda_function, exit_then_run_shell_script

    if Path.home().joinpath("code", "machineconfig").exists():
        uv_with = ["plotly", "kaleido"]
        uv_project_dir = str(Path.home().joinpath("code", "machineconfig"))
    else:
        uv_with = [MACHINECONFIG_VERSION, "plotly", "kaleido"]
        uv_project_dir = None

    shell_script, _pyfile = get_shell_script_running_lambda_function(
        lambda: func(
            output_str=str(output) if output else None,
            max_depth=max_depth,
            template=template,
            height=height,
            width=width,
        ),
        uv_with=uv_with,
        uv_project_dir=uv_project_dir,
    )
    exit_then_run_shell_script(str(shell_script), strict=False)


def navigate():
    """📚 NAVIGATE command structure with TUI"""
    from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
    # import machineconfig.scripts.python.graph.visualize.helpers_navigator as navigator
    # path = Path(navigator.__file__).resolve().parent.joinpath("devops_navigator.py")
    # from machineconfig.utils.code import exit_then_run_shell_script
    # if Path.home().joinpath("code", "machineconfig").exists():
    #     executable = f"""--project "{str(Path.home().joinpath("code/machineconfig"))}" --with textual"""
    # else:
    #     executable = f"""--with "{MACHINECONFIG_VERSION},textual" """
    # exit_then_run_shell_script(f"""uv run {executable} {path}""")
    def func():
        from machineconfig.scripts.python.graph.visualize.helpers_navigator.devops_navigator import main as main_devops_navigator
        main_devops_navigator()
    from machineconfig.utils.code import get_shell_script_running_lambda_function, exit_then_run_shell_script
    if Path.home().joinpath("code", "machineconfig").exists():
        uv_with = ["textual"]
        uv_project_dir = str(Path.home().joinpath("code/machineconfig"))
    else:
        uv_with = [MACHINECONFIG_VERSION, "textual"]
        uv_project_dir = None
    shell_script, _pyfile = get_shell_script_running_lambda_function(lambda: func(),
            uv_with=uv_with, uv_project_dir=uv_project_dir)
    exit_then_run_shell_script(str(shell_script), strict=False)


def search(
    graph_path: Annotated[Path | None, typer.Option("--graph-path", "-g", help="Path to cli_graph.json")] = None,
) -> None:
    """🔎 Search cli_graph.json entries and print the full selected entry."""
    def func(graph_path_str: str | None) -> None:
        import json
        from rich.console import Console
        from rich.panel import Panel
        from rich.syntax import Syntax
        from machineconfig.scripts.python.graph.visualize.graph_paths import DEFAULT_GRAPH_PATH
        from machineconfig.utils.options_utils.tv_options import choose_from_dict_with_preview
        from machineconfig.utils.installer_utils.installer_cli import install_if_missing
        install_if_missing(which="tv")
        graph_file = Path(graph_path_str) if graph_path_str else DEFAULT_GRAPH_PATH
        graph_data = json.loads(graph_file.read_text(encoding="utf-8"))
        root = graph_data.get("root")
        if not isinstance(root, dict):
            raise ValueError(f"Invalid graph root in {graph_file}")

        entries: list[tuple[str, str, dict[str, object]]] = []

        def walk(node: dict[str, object], parent_tokens: list[str]) -> None:
            node_name = node.get("name")
            node_name_str = node_name if isinstance(node_name, str) else ""
            tokens = parent_tokens + ([node_name_str] if node_name_str else [])
            source = node.get("source")
            if node.get("kind") == "command" and isinstance(source, dict):
                source_file = source.get("file")
                if isinstance(source_file, str) and source_file.endswith(".py"):
                    command_path = " ".join(tokens).strip() or source_file
                    entries.append((source_file, command_path, node))
            children = node.get("children")
            if isinstance(children, list):
                for child in children:
                    if isinstance(child, dict):
                        walk(child, tokens)

        walk(root, [])
        if not entries:
            raise ValueError(f"No .py command entries found in {graph_file}")

        entries.sort(key=lambda item: (item[0], item[1]))
        entry_preview_mapping: dict[str, str] = {}
        entry_lookup: dict[str, tuple[str, str, dict[str, object]]] = {}
        for source_file, command_path, entry in entries:
            summary = str(entry.get("short_help") or entry.get("help") or entry.get("doc") or "").strip()
            display_command = command_path if command_path else str(entry.get("name", "command"))
            option_key = f"{display_command}    [{source_file}]"
            entry_lookup[option_key] = (source_file, display_command, entry)
            if summary:
                entry_preview_mapping[option_key] = f"Source: {source_file}\nSummary: {summary}\n\n" + json.dumps(entry, ensure_ascii=False, indent=2)
            else:
                entry_preview_mapping[option_key] = f"Source: {source_file}\n\n" + json.dumps(entry, ensure_ascii=False, indent=2)

        selected_entry_key = choose_from_dict_with_preview(
            options_to_preview_mapping=entry_preview_mapping,
            extension="json",
            multi=False,
            preview_size_percent=70,
        )
        if selected_entry_key is not None:
            selected_file, selected_command, selected_entry = entry_lookup[selected_entry_key]
            console = Console()
            console.print(
                Panel(
                    f"[bold]Source file:[/bold] {selected_file}\n[bold]Command:[/bold] {selected_command}",
                    title="🔎 CLI Graph Search Result",
                    border_style="green",
                )
            )
            console.print(
                Panel(
                    Syntax(json.dumps(selected_entry, ensure_ascii=False, indent=2), "json", line_numbers=True),
                    title="📦 Full cli_graph.json Entry",
                    border_style="cyan",
                )
            )
            

    from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
    from machineconfig.utils.code import get_shell_script_running_lambda_function, exit_then_run_shell_script

    if Path.home().joinpath("code", "machineconfig").exists():
        uv_with = []
        uv_project_dir = str(Path.home().joinpath("code/machineconfig"))
    else:
        uv_with = [MACHINECONFIG_VERSION]
        uv_project_dir = None
    shell_script, _pyfile = get_shell_script_running_lambda_function(
        lambda: func(graph_path_str=str(graph_path) if graph_path else None),
        uv_with=uv_with,
        uv_project_dir=uv_project_dir,
    )
    exit_then_run_shell_script(str(shell_script), strict=False)


def get_app() -> typer.Typer:
    cli_app = typer.Typer(
        help="🧭 <g> Visualize the MachineConfig CLI graph in multiple formats.",
        no_args_is_help=True,
        add_help_option=True,
        add_completion=False,
    )
    cli_app.command(name="search", no_args_is_help=False, help="🔎 <s> Search all cli_graph.json command entries.")(search)
    cli_app.command(name="s", no_args_is_help=False, help="Search all cli_graph.json command entries.", hidden=True)(search)
    cli_app.command(name="tree", no_args_is_help=False, help="🌳 <t> Render a rich tree view in the terminal.")(tree)
    cli_app.command(name="t", no_args_is_help=False, help="Render a rich tree view in the terminal.", hidden=True)(tree)
    cli_app.command(name="dot", no_args_is_help=False, help="🧩 <d> Export the graph as Graphviz DOT.")(dot)
    cli_app.command(name="d", no_args_is_help=False, help="Export the graph as Graphviz DOT.", hidden=True)(dot)
    cli_app.command(name="sunburst", no_args_is_help=False, help="☀ <b> Render a Plotly sunburst view.")(sunburst)
    cli_app.command(name="b", no_args_is_help=False, help="Render a Plotly sunburst view.", hidden=True)(sunburst)
    cli_app.command(name="treemap", no_args_is_help=False, help="🧱 <m> Render a Plotly treemap view.")(treemap)
    cli_app.command(name="m", no_args_is_help=False, help="Render a Plotly treemap view.", hidden=True)(treemap)
    cli_app.command(name="icicle", no_args_is_help=False, help="🧊 <i> Render a Plotly icicle view.")(icicle)
    cli_app.command(name="i", no_args_is_help=False, help="Render a Plotly icicle view.", hidden=True)(icicle)
    cli_app.command(name="tui", no_args_is_help=False, help="📚 <u> NAVIGATE command structure with TUI")(navigate)
    cli_app.command(name="u", no_args_is_help=False, help="NAVIGATE command structure with TUI", hidden=True)(navigate)
    return cli_app


def main() -> None:
    app = get_app()
    app()


if __name__ == "__main__":
    main()
