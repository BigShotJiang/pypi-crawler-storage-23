from pathlib import Path

DEFAULT_GRAPH_PATH = Path(__file__).resolve().parents[1] / "cli_graph.json"
