
docs don't mention at all anything about user code privacy, data collection or telemetry or any reporting.
