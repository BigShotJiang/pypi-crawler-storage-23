# Use in Agent

Stata-MCP was designed with agents in mind from the outset. I believe the three core elements of an agent are tools, knowledge, and foundation models. The Stata manipulation capabilities provided by Stata-MCP serve as a core tool in our exploration of AI for social science.

