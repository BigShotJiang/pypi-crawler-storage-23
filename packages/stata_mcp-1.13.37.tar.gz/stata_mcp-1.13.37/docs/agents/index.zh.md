# 智能体使用

Stata-MCP 从设计之初就考虑了智能体的使用场景。我认为智能体的三个核心要素是工具、知识和基础模型。Stata-MCP 提供的 Stata 操作能力是我们探索 AI for Social Science 的核心工具。
