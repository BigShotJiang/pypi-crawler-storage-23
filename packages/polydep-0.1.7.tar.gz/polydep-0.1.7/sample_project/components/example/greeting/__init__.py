from example.greeting.core import hello_world

__all__ = ["hello_world"]
