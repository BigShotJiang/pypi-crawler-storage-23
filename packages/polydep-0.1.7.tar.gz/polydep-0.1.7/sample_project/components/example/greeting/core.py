def hello_world() -> str:
    return "HELLO WORLD"
