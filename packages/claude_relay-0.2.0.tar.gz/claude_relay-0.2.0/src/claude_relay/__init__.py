"""claude-relay: OpenAI- and Anthropic-compatible API server that routes through Claude Code."""

__version__ = "0.2.0"
