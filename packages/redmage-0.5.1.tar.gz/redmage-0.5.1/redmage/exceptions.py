class RedmageError(Exception):
    pass
