"""Allow running as `python -m apecode`."""

from apecode.cli import app

app()
