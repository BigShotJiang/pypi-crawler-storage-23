"""ApeCode - A terminal code agent powered by AI."""

__version__ = "0.0.2"
