# Copyright 2024 Remy Blank <remy@c-space.org>
# SPDX-License-Identifier: MIT

import argparse
import contextlib
import datetime
import errno
import functools
from http import HTTPMethod, HTTPStatus
import itertools
import mimetypes
import os
import pathlib
import posixpath
import re
import shlex
import shutil
import socket
import socketserver
import stat
import subprocess
import sys
import tempfile
import threading
import time
from urllib import parse
import webbrowser
from wsgiref import simple_server, util as wsgiutil

from . import __project__, __version__, api, config, console, deps, logs, \
              store, util, wsgi

# TODO: Split groups of sub-commands into separate modules

log = logs.logger(__name__)
default_port = 8000
local_config = pathlib.Path('local.toml')


@console.main
def main(argv, stdin, stdout, stderr):
    """Run the command."""
    threading.current_thread().name = 'main'
    parser = console.get_arg_parser(stdin, stdout, stderr)(
        prog=pathlib.Path(argv[0]).name, description="Manage a t-doc book.")
    root = parser.add_subparsers(title='Sub-commands')
    root.required = True

    p = root.add_parser('build', help="Build a book.")
    p.set_defaults(handler=cmd_build)
    arg = p.add_argument
    arg('target', metavar='TARGET', nargs='+', help="The build targets to run.")
    add_options(p, sphinx=True)

    p = root.add_parser('clean', help="Clean the build products of a book.")
    p.set_defaults(handler=cmd_clean)
    add_options(p, sphinx=True)

    add_group_commands(root)
    add_log_commands(root)
    add_repo_commands(root)

    p = root.add_parser('serve', help="Serve a book locally.")
    p.set_defaults(handler=cmd_serve)
    arg = p.add_argument
    arg('--bind', metavar='ADDRESS', dest='bind', default='localhost',
        help="The address to bind the server to (default: %(default)s). "
             "Specify ALL to bind to all interfaces.")
    arg('--cache', metavar='PATH', dest='cache', type='path', default='_cache',
        help="The path to the cache directory (default: %(default)s).")
    arg('--delay', metavar='DURATION', dest='delay', type=float, default=1.0,
        help="The delay in seconds between detecting a source change and "
             "triggering a build (default: %(default)s).")
    arg('--exit-on-failure', action='store_true', dest='exit_on_failure',
        help="Terminate the server on build failure.")
    arg('--exit-on-idle', metavar='DURATION', dest='exit_on_idle', type=float,
        default=0.0,
        help="The time in seconds after the last connection closes when the "
             "server terminates (default: %(default)s).")
    arg('--ignore', metavar='REGEXP', dest='ignore', type='regexp',
        default=f'(^|{re.escape(os.sep)})__pycache__$',
        help="A regexp matching files and directories to ignore from watching "
             "(default: %(default)s).")
    arg('--full-builds', action='store_true', dest='full_builds',
        help="Perform full builds on source changes.")
    arg('--interval', metavar='DURATION', dest='interval', type=float,
        default=1.0,
        help="The interval in seconds at which to check for source changes "
             "(default: %(default)s).")
    arg('--open', action='store_true', dest='open',
        help="Open the site in a browser tab after the first build completes.")
    arg('--port', metavar='PORT', dest='port', type=int, default=0,
        help="The port to bind the server to (default: first unused port "
             f"starting at {default_port}).")
    arg('--restart-on-change', action='store_true', dest='restart_on_change',
        help="Restart the server on changes.")
    arg('--watch', metavar='PATH', dest='watch', type='path', action='append',
        default=[],
        help="Additional directories to watch for changes.")
    add_options(p, sphinx=True)

    add_store_commands(root)
    add_token_commands(root)
    add_user_commands(root)

    p = root.add_parser('version', help="Display version information.")
    p.set_defaults(handler=cmd_version)
    add_options(p)

    opts = parser.parse_args(argv[1:])
    if opts.config is None and (lc := local_config.resolve()).is_file():
        opts.config = lc
    opts.cfg = config.Config.load(opts.config)
    with logs.configure(config=opts.cfg.sub('logging'), stderr=stderr,
                        level=logs.WARNING, stream=True, raise_exc=opts.debug,
                        on_upgrade=functools.partial(on_upgrade, opts),
                        db_logs=not getattr(opts.handler, '_disable_db_logs',
                                            False)):
        log.info("CLI: %(cmd)s", cmd=' '.join(shlex.quote(a) for a in argv),
                 argv=argv)
        return opts.handler(opts)


def disable_db_logs(fn):
    fn._disable_db_logs = True
    return fn


def add_options(parser, sphinx=False):
    if sphinx: add_sphinx_options(parser)
    arg = parser.add_argument_group("Common options").add_argument
    arg('--color', dest='color', choices=['auto', 'false', 'true'],
        default='auto',
        help="Control the use of colors in output (default: %(default)s).")
    arg('--config', metavar='PATH', dest='config', type='path',
        default=os.environ.get('TDOC_CONFIG'),
        help="The path to the config file.")
    arg('--debug', action='store_true', dest='debug',
        help="Enable debug functionality.")
    arg('--dev', action='store_true', dest='dev',
        help="Create databases for dev mode.")


def add_sphinx_options(parser):
    arg = parser.add_argument_group("Sphinx options").add_argument
    arg('--build', metavar='PATH', dest='build', type='path', default='_build',
        help="The path to the build directory (default: %(default)s).")
    arg('--source', metavar='PATH', dest='source', type='path', default='docs',
        help="The path to the source files (default: %(default)s).")
    arg('--sphinx-opt', metavar='OPT', action='append', dest='sphinx_opts',
        default=[], help="Additional options to pass to sphinx-build.")


def on_upgrade(opts, st, db, version, latest):
    o = opts.stdout
    if db is None:
        o.write(f"""\
{o.LYELLOW}A database needs to be created:{o.NORM} dev={opts.dev}
  {st.path}
Would you like to create it (y/n)? """)
    elif latest < version:
        o.write(f"""\
{o.LYELLOW}A database needs to be downgraded:{o.NORM} version\
 {o.CYAN}{version}{o.NORM} => {o.CYAN}{latest}{o.NORM}
  {st.path}
This cannot be done automatically. Please downgrade manually or restore from a
backup.
""")
        raise Exception("Aborting to prevent data loss")
    else:
        o.write(f"""\
{o.LYELLOW}A database needs to be upgraded:{o.NORM} version\
 {o.CYAN}{version}{o.NORM} => {o.CYAN}{latest}{o.NORM}
  {st.path}
Would you like to perform the upgrade (y/n)? """)
    o.flush()
    resp = input().lower()
    o.write("\n")
    if resp not in ('y', 'yes', 'o', 'oui', 'j', 'ja'): return
    if db is None:
        st.create(dev=opts.dev)
    else:
        upgrade_database(opts, st, db, version, latest)
    return True


def get_store(opts, allow_mem=False):
    st = store.Store(opts.cfg.sub('store'),
                     mem_name='store' if allow_mem else None)
    st.check_version(functools.partial(on_upgrade, opts))
    return st


@contextlib.contextmanager
def get_db(opts, mode):
    with get_store(opts) as st, \
            contextlib.closing(st.connect(mode=mode)) as db, db:
        yield db


def read_db(opts): return get_db(opts, 'ro')
def write_db(opts): return get_db(opts, 'rw')


def backup_path(st):
    suffix = datetime.datetime.now() \
                .isoformat('.', 'microseconds').replace(':', '-')
    return st.path.with_name(f'{st.path.name}.{suffix}')


def upgrade_database(opts, database, db, version, to_version, indent=""):
    o = opts.stdout
    backup = backup_path(database)
    o.write(f"{indent}Backing up database to: {backup}\n")
    database.backup(db, backup)
    def on_version(v): o.write(f"{indent}Upgrading database to version {v}\n")
    database.upgrade(version=to_version, on_version=on_version)
    o.write(f"{indent}Database upgraded successfully\n")


def comma_separated(s):
    if s is None: return []
    return s.split(',')


def cmd_build(opts):
    for target in opts.target:
        res = sphinx_build(opts, target, build=opts.build)
        if res.returncode != 0: return res.returncode


def cmd_clean(opts):
    return sphinx_build(opts, 'clean', build=opts.build).returncode


def add_group_commands(parser):
    p = parser.add_parser('group', help="Group-related commands.")
    sp = p.add_subparsers(title="Sub-commands")
    sp.required = True

    def add_groups(arg):
        for name in ('group', 'groups'):
            arg(f'--{name}', metavar="GROUP,...", dest='groups',
                help="A comma-separated list of groups.")

    def add_users(arg):
        for name in ('user', 'users'):
            arg(f'--{name}', metavar="USER,...", dest='users',
                help="A comma-separated list of users.")

    def add_groups_re(arg):
        arg('groups', metavar='REGEXP', nargs='?', default='.*',
            help="A regexp to limit the groups to consider.")

    p = sp.add_parser('add', help="Add members to one or more groups.")
    p.set_defaults(handler=cmd_group_add)
    arg = p.add_argument
    add_groups(arg)
    add_origin_option(arg)
    add_users(arg)
    arg('group', metavar='GROUP', nargs='+', help="The group to add to.")
    add_options(p)

    p = sp.add_parser('list', help="List groups.")
    p.set_defaults(handler=cmd_group_list)
    arg = p.add_argument
    add_groups_re(arg)
    add_options(p)

    p = sp.add_parser('members', help="List members of a group.")
    p.set_defaults(handler=cmd_group_members)
    arg = p.add_argument
    add_origin_option(arg)
    arg('--direct', action='store_true', dest='direct',
        help="List only direct memberships.")
    add_groups_re(arg)
    add_options(p)

    p = sp.add_parser('memberships', help="List group memberships for a group.")
    p.set_defaults(handler=cmd_group_memberships)
    arg = p.add_argument
    add_origin_option(arg)
    add_groups_re(arg)
    add_options(p)

    p = sp.add_parser('remove', help="Remove members from one or more groups.")
    p.set_defaults(handler=cmd_group_remove)
    arg = p.add_argument
    add_groups(arg)
    add_origin_option(arg)
    add_users(arg)
    arg('group', metavar='GROUP', nargs='+', help="The group to remove from.")
    add_options(p)


def cmd_group_add(opts):
    with write_db(opts) as db:
        db.groups.modify(opts.origin, opts.group,
                         add_users=comma_separated(opts.users),
                         add_groups=comma_separated(opts.groups))


def cmd_group_list(opts):
    with read_db(opts) as db:
        groups = db.groups.list(opts.groups)
    groups.sort()
    o = opts.stdout
    for group in groups: opts.stdout.write(f"{o.CYAN}{group}{o.NORM}\n")


def cmd_group_members(opts):
    with read_db(opts) as db:
        members = db.groups.members(opts.origin, opts.groups,
                                    transitive=not opts.direct)
    members.sort()
    wgroup = max((len(r[0]) for r in members), default=0)
    wname = max((len(r[2]) for r in members), default=0)
    o = opts.stdout
    prev = None
    for group, typ, name, transitive in members:
        prefix = f"{o.CYAN}{group:{wgroup}}{o.NORM}" if group != prev \
                 else f"{'':{wgroup}}"
        if transitive:
            opts.stdout.write(
                f"{prefix}  {typ:5} {o.LWHITE}{name:{wname}}{o.NORM}  "
                "(transitive)\n")
        else:
            opts.stdout.write(f"{prefix}  {typ:5} {o.LWHITE}{name}{o.NORM}\n")
        prev = group


def cmd_group_memberships(opts):
    with read_db(opts) as db:
        memberships = db.groups.memberships(opts.origin, opts.groups)
    memberships.sort()
    wmember = max((len(r[0]) for r in memberships), default=0)
    o = opts.stdout
    prev = None
    for member, group in memberships:
        prefix = f"{o.CYAN}{member:{wmember}}{o.NORM}" if member != prev \
                 else f"{'':{wmember}}"
        opts.stdout.write(f"{prefix}  {o.LWHITE}{group}{o.NORM}\n")
        prev = member


def cmd_group_remove(opts):
    with write_db(opts) as db:
        db.groups.modify(opts.origin, opts.group,
                         remove_users=comma_separated(opts.users),
                         remove_groups=comma_separated(opts.groups))


def add_log_commands(parser):
    p = parser.add_parser('log', help="Log-related commands.")
    sp = p.add_subparsers(title="Sub-commands")
    sp.required = True

    p = sp.add_parser('backup', help="Backup log databases.")
    p.set_defaults(handler=cmd_log_backup)
    add_options(p)

    p = sp.add_parser('create', help="Create log databases.")
    p.set_defaults(handler=cmd_log_create)
    arg = p.add_argument
    arg('--version', metavar='VERSION', dest='version', type=int, default=None,
        help="The version at which to create the log databases (default: "
             "latest).")
    add_options(p)

    p = sp.add_parser('query', help="Query a log database.")
    p.set_defaults(handler=cmd_log_query)
    arg = p.add_argument
    arg('--begin', metavar='TIME', dest='begin', type='opt_nrel_timestamp',
        default='1h',
        help="Output entries logged at or after the given relative or absolute "
             "time (default: %(default)s).")
    arg('--end', metavar='TIME', dest='end', type='opt_nrel_timestamp',
        default=None,
        help="Output entries logged before the given relative or absolute "
             "time.")
    arg('--format', metavar='FORMAT', dest='format',
        default=logs.default_file_format,
        help="The format to use for log entries (default: %(default)r).")
    arg('--index', metavar='N', dest='index', type=int, default=0,
        help="The index of the database handler in the config (default: "
             "%(default)s).")
    arg('--level', metavar='LEVEL', dest='level', type=logs.to_level,
        default=None,
        help="Output entries with a log level equal to or above the given "
             "level.")
    arg('--utc', action='store_true', dest='utc',
        help="Format times in UTC instead of local time.")
    arg('--watch', action='store_true', dest='watch',
        help="Output new log entries as they appear.")
    arg('--where', metavar='EXPR', dest='where', default=None,
        help="An additional SQL expression to add to the WHERE clause of the "
             "database query.")
    add_options(p)

    p = sp.add_parser('upgrade', help="Upgrade log databases.")
    p.set_defaults(handler=cmd_log_upgrade)
    arg = p.add_argument
    arg('--version', metavar='VERSION', dest='version', type=int, default=None,
        help="The version to which to upgrade the log databases (default: "
             "latest).")
    add_options(p)


@disable_db_logs
def cmd_log_backup(opts):
    for c in opts.cfg.subs('logging.databases'):
        lst = logs.LogStore(c)
        dest = backup_path(lst)
        with contextlib.closing(lst.connect(mode='ro')) as db, db:
            opts.stdout.write(f"Backing up to: {dest}\n")
            lst.backup(db, dest)


@disable_db_logs
def cmd_log_create(opts):
    for c in opts.cfg.subs('logging.databases'):
        lst = logs.LogStore(c)
        if lst.exists:
            opts.stdout.write(f"Already exists: {lst.path}\n")
            continue
        version = lst.create(version=opts.version, dev=opts.dev)
        opts.stdout.write(f"Created (version: {version}): {lst.path}\n")


@disable_db_logs
def cmd_log_query(opts):
    fmt = logs.Formatter(opts.format, utc=opts.utc)
    for i, c in enumerate(opts.cfg.subs('logging.databases')):
        if i == opts.index: break
    else:
        raise Exception("Invalid log database index")
    lst = logs.LogStore(c)
    lst.check_version(functools.partial(on_upgrade, opts))
    with contextlib.closing(lst.connect(mode='ro')) as db:
        rid = None
        while True:
            with db:
                for rec, rid in db.query(row_id=rid, level=opts.level,
                                         begin=opts.begin, end=opts.end,
                                         where=opts.where):
                    opts.stdout.write(f"{fmt.format(rec)}\n")
            if not opts.watch: break
            time.sleep(1)


@disable_db_logs
def cmd_log_upgrade(opts):
    for c in opts.cfg.subs('logging.databases'):
        lst = logs.LogStore(c)
        with contextlib.closing(lst.connect(mode='rw')) as db:
            with db: version, latest = lst.version(db)
            if version == latest:
                opts.stdout.write(
                    f"Already up-to-date (version: {version}): {lst.path}\n")
                continue
            opts.stdout.write(f"Upgrading (version: {version}): {lst.path}\n")
            to_version = opts.version if opts.version is not None else latest
            upgrade_database(opts, lst, db, version, to_version, indent="  ")


def add_repo_commands(parser):
    p = parser.add_parser('repo', help="Repository-related commands.")
    sp = p.add_subparsers(title="Sub-commands")
    sp.required = True

    p = sp.add_parser('auth', help="Modify repository authentication.")
    p.set_defaults(handler=cmd_repo_auth)
    arg = p.add_argument
    arg('--disable', action='store_false', dest='enable', default=None,
        help="Disable repository access.")
    arg('--enable', action='store_true', dest='enable', default=None,
        help="Enable repository access.")
    arg('--reset', action='store_true', dest='reset',
        help="Reset the password.")
    arg('user', metavar='USER', nargs='+',
        help="The users for whom to modify repository authentication.")
    add_options(p)

    p = sp.add_parser('list-users', help="List repository users.")
    p.set_defaults(handler=cmd_repo_list_users)
    arg = p.add_argument
    arg('users', metavar='REGEXP', nargs='?', default='.*',
        help="A regexp to limit the users to consider.")
    add_options(p)


def cmd_repo_auth(opts):
    with write_db(opts) as db:
        for u in opts.user:
            if (v := opts.enable) is not None:
                db.repo.enable_auth(db.users.uid(u), v)
            if opts.reset: db.repo.reset_password(db.users.uid(u))


def cmd_repo_list_users(opts):
    with read_db(opts) as db:
        infos = db.repo.list_users(opts.users)
    infos.sort(key=lambda r: (r[1], r[0]))
    wuser = max((len(r[1]) for r in infos), default=0)
    o = opts.stdout
    for uid, name, enabled, prefix in infos:
        opts.stdout.write(
            f"{o.CYAN}{name:{wuser}}{o.NORM} ({uid:19d})  "
            f"access: {"enabled " if enabled else "disabled"}  "
            f"password: {"[none]" if prefix is None else prefix + "****"}\n")


def cmd_serve(opts):
    opts.dev = True
    addr = (opts.bind if opts.bind != 'ALL' else '', opts.port)
    families = {info[0] for info in socket.getaddrinfo(
                    addr[0] or None, opts.port, type=socket.SOCK_STREAM,
                    flags=socket.AI_PASSIVE)}

    class Server(ServerBase):
        address_family = socket.AF_INET6 if socket.AF_INET6 in families \
                         else socket.AF_INET

    with Server(addr, RequestHandler) as srv, \
            get_store(opts, allow_mem=True) as st, \
            api.Api(config=opts.cfg, store=st) as api_, \
            Application(opts, srv, api_) as app:
        srv.set_app(app)
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            opts.restart_on_change = False
            opts.stderr.write("Interrupted, exiting\n")

    if opts.restart_on_change:
        opts.stdout.flush()
        opts.stderr.flush()
        os.execv(sys.argv[0], sys.argv)
    return app.returncode


def add_store_commands(parser):
    p = parser.add_parser('store', help="Store-related commands.")
    sp = p.add_subparsers(title="Sub-commands")
    sp.required = True

    p = sp.add_parser('backup', help="Backup the store database.")
    p.set_defaults(handler=cmd_store_backup)
    arg = p.add_argument
    arg('destination', metavar='PATH', nargs='?', type='path', default=None,
        help="The path to the backup copy. Defaults to the source database "
             "file with a date + time suffix.")
    add_options(p)

    p = sp.add_parser('create', help="Create the store database.")
    p.set_defaults(handler=cmd_store_create)
    arg = p.add_argument
    arg('--version', metavar='VERSION', dest='version', type=int, default=None,
        help="The version at which to create the store database (default: "
             "latest).")
    add_options(p)

    p = sp.add_parser('upgrade', help="Upgrade the store database.")
    p.set_defaults(handler=cmd_store_upgrade)
    arg = p.add_argument
    arg('--version', metavar='VERSION', dest='version', type=int, default=None,
        help="The version to which to upgrade the store database (default: "
             "latest).")
    add_options(p)


def cmd_store_backup(opts):
    st = store.Store(opts.cfg.sub('store'))
    if opts.destination is None: opts.destination = backup_path(st)
    with contextlib.closing(st.connect(mode='ro')) as db, db:
        opts.stdout.write(f"Backing up to: {opts.destination}\n")
        st.backup(db, opts.destination)


def cmd_store_create(opts):
    st = store.Store(opts.cfg.sub('store'))
    version = st.create(version=opts.version, dev=opts.dev)
    opts.stdout.write(f"Created (version: {version}): {st.path}\n")


def cmd_store_upgrade(opts):
    st = store.Store(opts.cfg.sub('store'))
    with contextlib.closing(st.connect(mode='rw')) as db:
        with db: version, latest = st.version(db)
        if version == latest:
            opts.stdout.write(
                f"Already up-to-date (version: {version}): {st.path}\n")
            return
        opts.stdout.write(f"Upgrading (version: {version}): {st.path}\n")
        to_version = opts.version if opts.version is not None else latest
        upgrade_database(opts, st, db, version, to_version, indent="  ")


def add_token_commands(parser):
    p = parser.add_parser('token', help="Token-related commands.")
    sp = p.add_subparsers(title="Sub-commands")
    sp.required = True

    p = sp.add_parser('create', help="Create tokens.")
    p.set_defaults(handler=cmd_token_create)
    arg = p.add_argument
    arg('--expire', metavar='TIME', dest='expire', type='opt_rel_timestamp',
        help="Expire the token at the given relative or absolute time.")
    add_origin_option(arg)
    arg('user', metavar='USER', nargs='+',
        help="The users for whom to create tokens.")
    add_options(p)

    p = sp.add_parser('expire', help="Expire tokens.")
    p.set_defaults(handler=cmd_token_expire)
    arg = p.add_argument
    arg('--time', metavar='TIME', dest='time', type='opt_rel_timestamp',
        default='0s',
        help="The time when the tokens should expire (default: now). An empty "
             "value removes the expiry time.")
    arg('--users', action='store_true', dest='users',
        help="Expire all tokens for the users passed as arguments.")
    arg('arg', metavar='ARG', nargs='+',
        help="The tokens to expire, or the users for whom to expire tokens.")
    add_options(p)

    p = sp.add_parser('list', help="List tokens.")
    p.set_defaults(handler=cmd_token_list)
    arg = p.add_argument
    arg('--expired', action='store_true', dest='expired',
        help="Include expired tokens.")
    add_origin_option(arg)
    arg('users', metavar='REGEXP', nargs='?', default='.*',
        help="A regexp to limit the users to consider.")
    add_options(p)


def add_origin_option(arg):
    arg('--origin', metavar='URL', dest='origin', default='',
        help="The origin on which to operate.")


def cmd_token_create(opts):
    with write_db(opts) as db:
        uids = [db.users.uid(u) for u in opts.user]
        tokens = db.tokens.create(uids, opts.expire)
    width = max((len(u) for u in opts.user), default=0)
    o = opts.stdout
    for uid, user, token in zip(uids, opts.user, tokens):
        opts.stdout.write(
            f"{o.CYAN}{user:{width}}{o.NORM}  ({uid:19d})  "
            f"{o.LBLUE}{opts.origin}#?token={token}{o.NORM}\n")


def cmd_token_expire(opts):
    with write_db(opts) as db:
        if opts.users:
            db.tokens.expire(uids=[db.users.uid(u) for u in opts.arg],
                             expires=opts.time)
        else:
            db.tokens.expire(tokens=opts.arg, expires=opts.time)


def cmd_token_list(opts):
    with read_db(opts) as db:
        tokens = db.tokens.list(opts.users, expired=opts.expired)
    epoch = datetime.datetime.fromtimestamp(0, datetime.UTC)
    tokens.sort(key=lambda r: (r[1], r[3], r[4] or epoch, r[2]))
    wuser = max((len(t[1]) for t in tokens), default=0)
    o = opts.stdout
    for uid, user, token, created, expires in tokens:
        if expires: expires = f", expires: {util.local_time(expires)}"
        opts.stdout.write(
            f"{o.CYAN}{user:{wuser}}{o.NORM} ({uid:19d})  "
            f"{o.LBLUE}{opts.origin}#?token={token}{o.NORM}\n"
            f"  created: {util.local_time(created)}{expires or ""}\n")


def add_user_commands(parser):
    p = parser.add_parser('user', help="User-related commands.")
    sp = p.add_subparsers(title="Sub-commands")
    sp.required = True

    def add_users_re(arg):
        arg('users', metavar='REGEXP', nargs='?', default='.*',
            help="A regexp to limit the users to consider.")

    p = sp.add_parser('create', help="Create users.")
    p.set_defaults(handler=cmd_user_create)
    arg = p.add_argument
    add_origin_option(arg)
    arg('--token-expire', metavar='TIME', dest='token_expire',
        type='opt_rel_timestamp',
        help="Expire the users' token at the given relative or absolute time.")
    arg('user', metavar='USER', nargs='+',
        help="The names of the users to create.")
    add_options(p)

    p = sp.add_parser('list', help="List users.")
    p.set_defaults(handler=cmd_user_list)
    arg = p.add_argument
    add_users_re(arg)
    add_options(p)

    p = sp.add_parser('memberships', help="List group memberships for a user.")
    p.set_defaults(handler=cmd_user_memberships)
    arg = p.add_argument
    add_origin_option(arg)
    arg('--direct', action='store_true', dest='direct',
        help="List only direct memberships.")
    add_users_re(arg)
    add_options(p)


def cmd_user_create(opts):
    with write_db(opts) as db:
        uids = db.users.create(opts.user)
        tokens = db.tokens.create(uids, opts.token_expire)
    wuser = max((len(u) for u in opts.user), default=0)
    o = opts.stdout
    for uid, user, token in zip(uids, opts.user, tokens):
        opts.stdout.write(f"{o.CYAN}{user:{wuser}}{o.NORM} ({uid:19})  "
                         f"{o.LBLUE}{opts.origin}#?token={token}{o.NORM}\n")


def cmd_user_list(opts):
    with read_db(opts) as db:
        users = db.users.list(opts.users)
    users.sort(key=lambda r: r[1])
    wuser = max((len(r[1]) for r in users), default=0)
    o = opts.stdout
    for uid, user, created in users:
        opts.stdout.write(
            f"{o.CYAN}{user:{wuser}}{o.NORM} ({uid:19d})  "
            f"created: {util.local_time(created)}\n")


def cmd_user_memberships(opts):
    with read_db(opts) as db:
        memberships = db.users.memberships(opts.origin, opts.users,
                                           transitive=not opts.direct)
    memberships.sort()
    wuser = max((len(r[1]) for r in memberships), default=0)
    wgroup = max((len(r[2]) for r in memberships), default=0)
    o = opts.stdout
    prev = None
    for uid, user, group, transitive in memberships:
        prefix = f"{o.CYAN}{user:{wuser}}{o.NORM} ({uid:19d})  " \
                 if user != prev else f"{'':{wuser + 19 + 5}}"
        if transitive:
            opts.stdout.write(f"{prefix}  {o.LWHITE}{group:{wgroup}}{o.NORM}  "
                             "(transitive)\n")
        else:
            opts.stdout.write(f"{prefix}  {o.LWHITE}{group}{o.NORM}\n")
        prev = user


def cmd_version(opts):
    opts.stdout.write(f"{__project__}-{__version__}\n")


def sphinx_build(opts, target, *, build, tags=(), **kwargs):
    argv = [sys.executable, '-P', '-m', 'sphinx', 'build', '-M', target,
            opts.source, build, '--fail-on-warning', '--jobs=auto']
    argv += [f'--tag={tag}' for tag in tags]
    if opts.debug: argv += ['--show-traceback']
    argv += opts.sphinx_opts
    return subprocess.run(argv, stdin=opts.stdin, stdout=opts.stdout,
                          stderr=opts.stderr, **kwargs)


class ServerBase(socketserver.ThreadingMixIn, simple_server.WSGIServer):
    daemon_threads = True

    # SO_REUSEADDR is enabled on POSIX platforms to work around the TIME_WAIT
    # issue after the process terminates. On these platforms, the option still
    # doesn't allow multiple processes to listen on the exact same address
    # simultaneously. Windows does, though, and this interferes with automatic
    # port selection. But Windows doesn't have the TIME_WAIT issue, so
    # SO_REUSEADDR is disabled there.
    # https://stackoverflow.com/questions/14388706/how-do-so-reuseaddr-and-so-reuseport-differ/14388707#14388707
    allow_reuse_address = os.name not in ('nt', 'cygwin')

    @property
    def host_port(self): return self.bind_address[:2]

    def server_bind(self):
        with contextlib.suppress(Exception):
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        addr = self.server_address
        port = addr[1]
        if auto_port := port == 0: port = default_port
        while True:
            # server_bind() sets server_address to the socket's name.
            self.server_address = self.bind_address = addr = \
                addr[:1] + (port,) + addr[2:]
            try:
                return super().server_bind()
            except OSError as e:
                if not auto_port or e.errno != errno.EADDRINUSE: raise
                if (port := port + 1) > 65535: raise


class RequestHandler(simple_server.WSGIRequestHandler):
    def log_request(self, code='-', size='-'): pass

    def log_message(self, format, *args):
        log.debug((format % args).translate(self._control_char_table))


def try_stat(path):
    with contextlib.suppress(OSError):
        return path.stat()


def prefix_read(fname):
    return (pathlib.Path(sys.prefix) / fname).read_text()


version_re = re.compile(f'(?m)^{re.escape(__project__)}==([^\\s;]+)(?:\\s|$)')

def project_version(reqs):
    if (m := version_re.search(reqs)) is not None: return m.group(1)
    return 'unknown'


class Application(wsgi.Dispatcher):
    def __init__(self, opts, server, api_):
        super().__init__()
        self.opts = opts
        self.server = server
        self.lock = threading.Condition(threading.Lock())
        self.directory = self.build_dir(0) / 'html'
        self.stop = False
        self.min_mtime = time.time_ns()
        self.returncode = 0
        self.api = self.add_endpoint('_api', api_)
        self.api.add_endpoint('terminate', self.handle_terminate)
        self.opened = False
        self.build_mtime = None
        self.build_obs = api.ValueObservable('build', self.build_mtime)
        self.api.events.add_observable(self.build_obs)
        self.builder = threading.Thread(target=self.watch_and_build,
                                        name='builder')
        self.builder.start()

    def __enter__(self): return self

    def __exit__(self, typ, value, tb):
        with self.lock:
            self.stop = True
            self.lock.notify()
        self.builder.join()

    def watch_and_build(self):
        self.remove_all()
        interval = self.opts.interval * 1_000_000_000
        delay = self.opts.delay * 1_000_000_000
        idle = self.opts.exit_on_idle * 1_000_000_000
        prev, prev_mtime, build_mtime = 0, 0, None
        build_next = self.build_dir('next')
        # TODO: Use monotonic clock for delays
        # TODO: Avoid looping at 10Hz
        while True:
            with self.lock:
                if prev != 0: self.lock.wait_for(lambda: self.stop, timeout=0.1)
                if self.stop: break
            now = time.time_ns()
            if (idle > 0 and (lw := self.api.events.last_watcher) is not None
                    and now > lw + idle):
                self.server.shutdown()
                break
            if now < prev + interval: continue
            mtime = self.latest_mtime()
            if mtime <= prev_mtime:
                prev = now
                continue
            if now < mtime + delay and prev_mtime != 0:
                prev = mtime + delay - interval
                continue
            if prev_mtime != 0:
                if self.opts.restart_on_change:
                    self.opts.stdout.write(
                        "\nSource change detected, restarting\n")
                    self.server.shutdown()
                    break
                self.opts.stdout.write(
                    "\nSource change detected, rebuilding\n")
            prev_mtime = mtime
            if self.build(build_next):
                build = self.build_dir(mtime)
                os.rename(build_next, build)
                with self.lock:
                    self.build_mtime = mtime
                    self.directory = build / 'html'
                self.build_obs.set(str(mtime))
                self.print_serving()
                if build_mtime is not None:
                    self.remove(self.build_dir(build_mtime))
                build_mtime = mtime
            else:
                self.remove(build_next)
            if not self.opts.full_builds and build_mtime is not None:
                shutil.copytree(self.build_dir(build_mtime), build_next,
                                symlinks=True)
            self.print_upgrade()
            prev = time.time_ns()
        if build_mtime is not None: self.remove(self.build_dir(build_mtime))
        self.remove(build_next)

    def latest_mtime(self):
        def on_error(e): log.error("Scan: %(exc)s", exc=e)
        mtime = self.min_mtime
        for path in itertools.chain([self.opts.source], self.opts.watch):
            for base, dirs, files in path.walk(on_error=on_error):
                for file in files:
                    p = base / file
                    if self.opts.ignore.search(str(p)) is not None: continue
                    try:
                        st = p.stat()
                        if stat.S_ISREG(st.st_mode):
                            mtime = max(mtime, st.st_mtime_ns)
                    except Exception as e:
                        on_error(e)
                dirs[:] = [d for d in dirs
                           if self.opts.ignore.search(str(base / d)) is None]
        return mtime

    def build_dir(self, mtime):
        return self.opts.build / f'serve-{self.server.host_port[1]}-{mtime}'

    def build(self, build):
        try:
            res = sphinx_build(self.opts, 'html', build=build,
                               tags=['tdoc-dev'])
            if res.returncode == 0: return True
        except Exception as e:
            log.error("Build: %(exc)s", exc=e)
        if self.opts.exit_on_failure:
            self.returncode = 1
            self.server.shutdown()
        return False

    def remove(self, build):
        build.relative_to(self.opts.build)  # Ensure we're below the build dir
        if not build.exists(): return
        def on_error(fn, path, e):
            log.error("Remove: %(func)s: %(path)s: %(exc)s", func=fn, path=path,
                      exc=e)
        shutil.rmtree(build, onexc=on_error)

    def remove_all(self):
        for build in self.opts.build.glob(
                f'serve-{self.server.host_port[1]}-*'):
            self.remove(build)

    def print_serving(self):
        host, port = self.server.host_port
        if host in ('', '::', '0.0.0.0'): host = socket.getfqdn()
        if ':' in host: host = f'[{host}]'
        o = self.opts.stdout
        o.write(f"Serving at <{o.LBLUE}http://{host}:{port}/{o.NORM}>\n")
        o.flush()
        if self.opts.open and not self.opened:
            self.opened = True
            webbrowser.open_new_tab(f'http://{host}:{port}/')

    def print_upgrade(self):
        if sys.prefix == sys.base_prefix: return  # Not running in a venv
        o = self.opts.stdout
        with contextlib.suppress(Exception):
            reqs = prefix_read('requirements.txt')
            reqs_up = prefix_read('requirements-upgrade.txt')
            if reqs_up == reqs: return
            cur, new = project_version(reqs), project_version(reqs_up)
            o.write(f"""\
{o.LYELLOW}An upgrade is available:{o.NORM} {__project__}\
 {o.CYAN}{cur}{o.NORM} => {o.CYAN}{new}{o.NORM}
Release notes: <{o.LBLUE}https://common.t-doc.org/release-notes.html\
#release-{new.replace('.', '-')}{o.NORM}>
{o.LWHITE}Restart the server to upgrade.{o.NORM}
""")

    def handle_request(self, handler, wr):
        wr.env['wsgi.multithread'] = True
        wr.dev = True
        return handler(wr.env, wr.respond, wr)

    @wsgi.endpoint('_cache', methods=(HTTPMethod.GET, HTTPMethod.HEAD),
                   final=False, log_level=logs.DEBUG)
    def handle_cache(self, wr):
        yield from self.handle_file(wr, self.opts.cache,
                                    self.on_cache_not_found)

    def on_cache_not_found(self, path_info, path):
        url = ''
        try:
            parts = path_info.split('/', 3)
            if parts[0] != '' or len(parts) < 4: return
            if (d := deps.info.get(parts[1])) is None: return
            url = f'{d['url'](d['name'], parts[2])}/{parts[3]}'
            log.debug("Caching: %(url)s", url=url)
            with util.urlopen(url) as f: data = f.read()
            path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(
                    dir=path.parent, prefix=path.name + '.',
                    delete_on_close=False) as f:
                f.write(data)
                f.close()
                pathlib.Path(f.name).replace(path)
        except Exception as e:
            log.error("Cache [%(url)s]: %(exc)s", url=url, exc=e)

    @wsgi.endpoint('/', methods=(HTTPMethod.GET, HTTPMethod.HEAD), final=False,
                   log_level=logs.DEBUG)
    def handle_default(self, wr):
        with self.lock: base = self.directory
        yield from self.handle_file(wr, base)

    def handle_file(self, wr, base, on_not_found=None):
        method = wr.method
        path_info = wr.path
        path = self.file_path(path_info, base)
        path.relative_to(base)  # Ensure we're below base
        if (st := try_stat(path)) is None:
            if on_not_found is None: raise wsgi.Error(HTTPStatus.NOT_FOUND)
            on_not_found(path_info, path)
            if (st := try_stat(path)) is None:
                raise wsgi.Error(HTTPStatus.NOT_FOUND)

        if stat.S_ISDIR(st.st_mode):
            parts = parse.urlsplit(path_info)
            if not parts.path.endswith('/'):
                location = parse.urlunsplit(
                    (parts[:2] + (parts[2] + '/',) + parts[3:]))
                wr.respond(wsgi.http_status(HTTPStatus.MOVED_PERMANENTLY), [
                    ('Location', location),
                    ('Content-Length', '0'),
                ])
                return
            path = path / 'index.html'
            if (st := try_stat(path)) is None:
                raise wsgi.Error(HTTPStatus.NOT_FOUND)

        if not stat.S_ISREG(st.st_mode):
            raise wsgi.Error(HTTPStatus.NOT_FOUND)
        mime_type = mimetypes.guess_type(path)[0] or 'application/octet-stream'
        wr.respond(wsgi.http_status(HTTPStatus.OK), [
            ('Content-Type', mime_type),
            ('Content-Length', str(st.st_size)),
            ('Access-Control-Allow-Origin', '*'),
            ('Access-Control-Expose-Headers', '*'),
        ])
        if method == HTTPMethod.HEAD: return
        yield from wr.file_wrapper(open(path, 'rb'))

    def file_path(self, path, base):
        trailing = path.rstrip().endswith('/')
        try:
            path = parse.unquote(path, errors='surrogatepass')
        except UnicodeDecodeError:
            path = parse.unquote(path)
        res = base
        for part in filter(None, posixpath.normpath(path).split('/')):
            if pathlib.Path(part).parent.name or part in (os.curdir, os.pardir):
                continue
            res = res / part
        return res / '' if trailing else res

    @wsgi.endpoint(None, methods=(HTTPMethod.POST,))
    def handle_terminate(self, wr):
        rc = wr.json.get('rc', 0)
        yield from wr.respond_json({})
        try:
            self.returncode = int(rc)
        except ValueError:
            self.returncode = 1
        self.server.shutdown()


if __name__ == '__main__':
    main()
