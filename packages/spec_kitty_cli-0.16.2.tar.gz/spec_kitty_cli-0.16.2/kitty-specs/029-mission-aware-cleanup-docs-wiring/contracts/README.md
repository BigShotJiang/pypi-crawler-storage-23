# Contracts

No external API contracts are required for this cleanup feature. Mission-aware wiring is internal to the CLI.
