#!/usr/bin/env bash
#
# Familiar Installer
#
# One line install:
#   curl -fsSL https://get.familiarai.ai | bash
#
set -e

FAMILIAR_HOME="$HOME/.familiar"
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; PURPLE='\033[0;35m'; NC='\033[0m'

echo -e "${PURPLE}"
cat << 'EOF'
   ███████╗ ██████╗██╗  ██╗██╗██████╗ ███╗   ██╗ █████╗ 
   ██╔════╝██╔════╝██║  ██║██║██╔══██╗████╗  ██║██╔══██╗
   █████╗  ██║     ███████║██║██║  ██║██╔██╗ ██║███████║
   ██╔══╝  ██║     ██╔══██║██║██║  ██║██║╚██╗██║██╔══██║
   ███████╗╚██████╗██║  ██║██║██████╔╝██║ ╚████║██║  ██║
   ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝
EOF
echo -e "${NC}"
echo -e "   ${BLUE}Signal-grade encryption • HIPAA-ready • Self-hosted AI${NC}\n"

info() { echo -e "${BLUE}→${NC} $1"; }
ok() { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; exit 1; }

# Detect OS
OS="linux"
[[ "$OSTYPE" == "darwin"* ]] && OS="macos"
[[ -f /proc/device-tree/model ]] && grep -q "Raspberry" /proc/device-tree/model 2>/dev/null && OS="pi"
info "Detected: $OS ($(uname -m))"

# Check Python
PYTHON=""
for p in python3.12 python3.11 python3.10 python3; do
    command -v $p &>/dev/null && PYTHON=$p && break
done
[[ -z "$PYTHON" ]] && fail "Python 3.10+ required. Install it first."
PY_VER=$($PYTHON -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PY_MINOR=$($PYTHON -c 'import sys; print(sys.version_info.minor)')
if [[ $($PYTHON -c 'import sys; print(sys.version_info.major)') -lt 3 ]] || [[ $PY_MINOR -lt 10 ]]; then
  fail "Python 3.10+ required, found $PY_VER. Install Python 3.10 or newer."
fi
ok "Python $PY_VER"

# Install deps
info "Installing dependencies..."
if [[ "$OS" == "pi" ]] || [[ -f /etc/debian_version ]]; then
    sudo apt-get update -qq && sudo apt-get install -y -qq python3-venv python3-pip libffi-dev >/dev/null
elif [[ "$OS" == "macos" ]] && command -v brew &>/dev/null; then
    brew install openssl 2>/dev/null || true
fi
ok "Dependencies ready"

# Setup directories
info "Setting up $FAMILIAR_HOME..."
mkdir -p "$FAMILIAR_HOME"/{app,data,logs,secure,bin}
chmod 700 "$FAMILIAR_HOME/secure" "$FAMILIAR_HOME/data"

# Copy from extracted directory (or zip if provided)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -n "$FAMILIAR_ZIP" ]] && [[ -f "$FAMILIAR_ZIP" ]]; then
    info "Installing from $FAMILIAR_ZIP..."
    unzip -qo "$FAMILIAR_ZIP" -d "$FAMILIAR_HOME/app"
    [[ -d "$FAMILIAR_HOME/app/familiar" ]] && mv "$FAMILIAR_HOME/app/familiar"/* "$FAMILIAR_HOME/app/" && rmdir "$FAMILIAR_HOME/app/familiar" 2>/dev/null
elif [[ -f "$SCRIPT_DIR/__main__.py" ]] && [[ -d "$SCRIPT_DIR/core" ]]; then
    info "Installing from extracted directory..."
    rsync -a --exclude='.git' --exclude='__pycache__' --exclude='*.pyc' \
          "$SCRIPT_DIR/" "$FAMILIAR_HOME/app/" 2>/dev/null \
    || cp -r "$SCRIPT_DIR"/* "$FAMILIAR_HOME/app/"
else
    fail "Run this script from inside the familiar directory, or set FAMILIAR_ZIP=/path/to/familiar.zip"
fi
ok "Files installed"

# Virtual environment
info "Creating Python environment..."
$PYTHON -m venv "$FAMILIAR_HOME/venv"
source "$FAMILIAR_HOME/venv/bin/activate"
pip install -q --upgrade pip
pip install -q -r "$FAMILIAR_HOME/app/requirements.txt"
ok "Python packages installed"

# Config
if [[ ! -f "$FAMILIAR_HOME/config.yaml" ]]; then
    cat > "$FAMILIAR_HOME/config.yaml" << 'YAML'
llm:
  default_provider: anthropic
  anthropic_model: claude-sonnet-4-20250514
  max_tokens: 4096

agent:
  name: Familiar
  memory_enabled: true
  skills_enabled: true

security:
  encrypt_sessions: true
  encrypt_memory: true

mesh:
  enabled: false
  gateway_port: 18789
YAML
    ok "Config created"
fi

# CLI wrapper
cat > "$FAMILIAR_HOME/bin/familiar" << 'EOF'
#!/usr/bin/env bash
source "$HOME/.familiar/venv/bin/activate"
[[ -f "$HOME/.familiar/.env" ]] && set -a && source "$HOME/.familiar/.env" && set +a
cd "$HOME/.familiar/app" && exec python -m familiar "$@"
EOF
chmod +x "$FAMILIAR_HOME/bin/familiar"

# Add to PATH
SHELL_RC="$HOME/.bashrc"
[[ -f "$HOME/.zshrc" ]] && SHELL_RC="$HOME/.zshrc"
grep -q "/.familiar/bin" "$SHELL_RC" 2>/dev/null || echo 'export PATH="$HOME/.familiar/bin:$PATH"' >> "$SHELL_RC"
ok "CLI ready"

# Systemd service (Linux only)
if [[ "$OS" != "macos" ]] && command -v systemctl &>/dev/null; then
    sudo tee /etc/systemd/system/familiar.service >/dev/null << EOF
[Unit]
Description=Familiar AI Agent
After=network.target
[Service]
Type=simple
User=$USER
WorkingDirectory=$FAMILIAR_HOME/app
ExecStart=$FAMILIAR_HOME/venv/bin/python -m familiar
Restart=always
[Install]
WantedBy=multi-user.target
EOF
    sudo systemctl daemon-reload
    sudo systemctl enable familiar 2>/dev/null
    ok "Systemd service installed"
fi

# Done!
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}                  Installation complete!                     ${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "1. Set API key:  ${YELLOW}export ANTHROPIC_API_KEY=\"sk-...\"${NC}"
echo -e "   Or use free local AI: ${YELLOW}ollama pull llama3.2${NC}"
echo ""
echo -e "2. Start:        ${YELLOW}~/.familiar/bin/familiar${NC}"
echo -e "   Or service:   ${YELLOW}sudo systemctl start familiar${NC}"
echo ""
echo -e "3. Config:       ${YELLOW}~/.familiar/config.yaml${NC}"
echo ""
echo -e "${PURPLE}Restart your shell or run: source $SHELL_RC${NC}"
echo ""
