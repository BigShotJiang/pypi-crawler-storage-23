#!/bin/bash
#
# Familiar - Raspberry Pi Installation Script
# 
# Installs Familiar as a self-hosted AI agent on Raspberry Pi 4/5
# Your AI runs at home. Your data stays at home.
#
# Usage:
#   curl -fsSL https://raw.githubusercontent.com/you/familiar/main/install-pi.sh | bash
#
# Or with options:
#   ./install-pi.sh --with-ollama --channel telegram
#
# Requirements:
#   - Raspberry Pi 4 (4GB+) or Pi 5
#   - Raspberry Pi OS (64-bit recommended)
#   - Internet connection
#   - ~2GB free disk space (more if using Ollama)
#

set -e

# ============================================================
# CONFIGURATION
# ============================================================

FAMILIAR_VERSION="1.3.0"
FAMILIAR_USER="familiar"
FAMILIAR_HOME="/opt/familiar"
FAMILIAR_DATA="/var/lib/familiar"
FAMILIAR_LOG="/var/log/familiar"
FAMILIAR_REPO="https://github.com/georgescottfoley/familiar.git"

# Ollama models sized for Pi
OLLAMA_MODEL_SMALL="llama3.2:3b"      # ~2GB, runs on Pi 4 4GB
OLLAMA_MODEL_MEDIUM="llama3.2:8b-q4"  # ~4GB, needs Pi 5 8GB
OLLAMA_MODEL_TINY="phi3:mini"          # ~1.5GB, fastest on Pi

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ============================================================
# HELPER FUNCTIONS
# ============================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "Please run as root (sudo ./install-pi.sh)"
        exit 1
    fi
}

# ============================================================
# SYSTEM DETECTION
# ============================================================

detect_pi_model() {
    if [ -f /proc/device-tree/model ]; then
        PI_MODEL=$(cat /proc/device-tree/model | tr -d '\0')
        log_info "Detected: $PI_MODEL"
        
        if [[ "$PI_MODEL" == *"Pi 5"* ]]; then
            PI_VERSION=5
            RECOMMENDED_RAM=8
        elif [[ "$PI_MODEL" == *"Pi 4"* ]]; then
            PI_VERSION=4
            RECOMMENDED_RAM=4
        elif [[ "$PI_MODEL" == *"Pi 3"* ]]; then
            log_warn "Pi 3 detected - performance will be limited"
            PI_VERSION=3
            RECOMMENDED_RAM=1
        else
            log_warn "Unknown Pi model - assuming Pi 4 compatibility"
            PI_VERSION=4
            RECOMMENDED_RAM=4
        fi
    else
        log_warn "Not running on Raspberry Pi - some features may not work"
        PI_VERSION=0
        RECOMMENDED_RAM=4
    fi
}

check_memory() {
    TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    TOTAL_RAM_GB=$((TOTAL_RAM_KB / 1024 / 1024))
    
    log_info "System RAM: ${TOTAL_RAM_GB}GB"
    
    if [ "$TOTAL_RAM_GB" -lt 2 ]; then
        log_error "Insufficient RAM. Minimum 2GB required, ${TOTAL_RAM_GB}GB detected."
        exit 1
    elif [ "$TOTAL_RAM_GB" -lt 4 ]; then
        log_warn "Limited RAM (${TOTAL_RAM_GB}GB). Local LLM inference will be slow."
        CAN_RUN_OLLAMA=false
    elif [ "$TOTAL_RAM_GB" -lt 8 ]; then
        log_info "Adequate RAM for small local models"
        CAN_RUN_OLLAMA=true
        OLLAMA_MODEL="$OLLAMA_MODEL_SMALL"
    else
        log_info "Excellent RAM - can run larger local models"
        CAN_RUN_OLLAMA=true
        OLLAMA_MODEL="$OLLAMA_MODEL_MEDIUM"
    fi
}

check_disk_space() {
    FREE_SPACE_GB=$(df -BG / | tail -1 | awk '{print $4}' | tr -d 'G')
    
    log_info "Free disk space: ${FREE_SPACE_GB}GB"
    
    if [ "$FREE_SPACE_GB" -lt 2 ]; then
        log_error "Insufficient disk space. Minimum 2GB required."
        exit 1
    elif [ "$FREE_SPACE_GB" -lt 10 ] && [ "$INSTALL_OLLAMA" = true ]; then
        log_warn "Limited disk space for Ollama models. Consider using external storage."
    fi
}

check_architecture() {
    ARCH=$(uname -m)
    log_info "Architecture: $ARCH"
    
    if [[ "$ARCH" != "aarch64" && "$ARCH" != "arm64" ]]; then
        if [[ "$ARCH" == "armv7l" ]]; then
            log_warn "32-bit ARM detected. 64-bit OS recommended for better performance."
        else
            log_warn "Non-ARM architecture. This script is optimized for Raspberry Pi."
        fi
    fi
}

# ============================================================
# INSTALLATION FUNCTIONS
# ============================================================

install_system_deps() {
    log_info "Installing system dependencies..."
    
    apt-get update -qq
    
    apt-get install -y -qq \
        python3 \
        python3-pip \
        python3-venv \
        python3-dev \
        git \
        curl \
        wget \
        jq \
        sqlite3 \
        libffi-dev \
        libssl-dev \
        build-essential \
        ufw \
        fail2ban
    
    # Optional: for voice features
    if [ "$INSTALL_VOICE" = true ]; then
        apt-get install -y -qq \
            portaudio19-dev \
            espeak \
            ffmpeg
    fi
    
    log_success "System dependencies installed"
}

create_familiar_user() {
    log_info "Creating familiar system user..."
    
    if id "$FAMILIAR_USER" &>/dev/null; then
        log_info "User $FAMILIAR_USER already exists"
    else
        useradd --system --shell /bin/bash --home-dir "$FAMILIAR_HOME" --create-home "$FAMILIAR_USER"
        log_success "Created user: $FAMILIAR_USER"
    fi
    
    # Create directories
    mkdir -p "$FAMILIAR_DATA"
    mkdir -p "$FAMILIAR_LOG"
    mkdir -p "$FAMILIAR_HOME/.familiar"
    
    chown -R "$FAMILIAR_USER:$FAMILIAR_USER" "$FAMILIAR_DATA"
    chown -R "$FAMILIAR_USER:$FAMILIAR_USER" "$FAMILIAR_LOG"
    chown -R "$FAMILIAR_USER:$FAMILIAR_USER" "$FAMILIAR_HOME"
    
    log_success "Directories created"
}

install_familiar() {
    log_info "Installing Familiar..."
    
    # Clone or update repository
    if [ -d "$FAMILIAR_HOME/familiar" ]; then
        log_info "Updating existing installation..."
        cd "$FAMILIAR_HOME/familiar"
        sudo -u "$FAMILIAR_USER" git pull
    else
        log_info "Cloning repository..."
        sudo -u "$FAMILIAR_USER" git clone "$FAMILIAR_REPO" "$FAMILIAR_HOME/familiar"
        cd "$FAMILIAR_HOME/familiar"
    fi
    
    # Create virtual environment
    log_info "Creating Python virtual environment..."
    sudo -u "$FAMILIAR_USER" python3 -m venv "$FAMILIAR_HOME/venv"
    
    # Install Python dependencies
    log_info "Installing Python dependencies (this may take a few minutes)..."
    sudo -u "$FAMILIAR_USER" "$FAMILIAR_HOME/venv/bin/pip" install --upgrade pip wheel
    sudo -u "$FAMILIAR_USER" "$FAMILIAR_HOME/venv/bin/pip" install -r "$FAMILIAR_HOME/familiar/requirements.txt"
    
    # Install optional dependencies based on flags
    if [ "$INSTALL_VOICE" = true ]; then
        log_info "Installing voice dependencies..."
        sudo -u "$FAMILIAR_USER" "$FAMILIAR_HOME/venv/bin/pip" install faster-whisper pyaudio edge-tts
    fi
    
    log_success "Familiar installed"
}

install_ollama() {
    if [ "$INSTALL_OLLAMA" != true ]; then
        log_info "Skipping Ollama installation (use --with-ollama to install)"
        return
    fi
    
    if ! $CAN_RUN_OLLAMA; then
        log_warn "Insufficient RAM for local LLM. Skipping Ollama."
        return
    fi
    
    log_info "Installing Ollama..."
    
    # Install Ollama
    curl -fsSL https://ollama.com/install.sh | sh
    
    # Enable and start Ollama service
    systemctl enable ollama
    systemctl start ollama
    
    # Wait for Ollama to be ready
    log_info "Waiting for Ollama to start..."
    sleep 5
    
    # Pull the appropriate model for this Pi's RAM
    log_info "Pulling model: $OLLAMA_MODEL (this may take 10-30 minutes)..."
    ollama pull "$OLLAMA_MODEL"
    
    log_success "Ollama installed with model: $OLLAMA_MODEL"
}

configure_familiar() {
    log_info "Configuring Familiar..."
    
    CONFIG_FILE="$FAMILIAR_HOME/.familiar/config.yaml"
    
    # Start with sample config
    if [ -f "$FAMILIAR_HOME/familiar/config.sample.yaml" ]; then
        cp "$FAMILIAR_HOME/familiar/config.sample.yaml" "$CONFIG_FILE"
    fi
    
    # Create Pi-optimized config
    cat > "$CONFIG_FILE" << EOF
# Familiar Configuration - Raspberry Pi Optimized
# Generated by install-pi.sh on $(date)

llm:
  # Primary provider - set your API key in .env
  default_provider: ${DEFAULT_PROVIDER:-anthropic}
  
  # Models
  anthropic_model: claude-sonnet-4-20250514
  openai_model: gpt-4o-mini  # Cheaper for Pi usage
  ollama_model: ${OLLAMA_MODEL:-llama3.2:3b}
  ollama_base_url: http://localhost:11434
  
  # Pi-friendly limits
  max_tokens: 2048  # Lower to reduce memory pressure
  temperature: 0.7

agent:
  name: Familiar
  persona: a helpful AI assistant running on your Raspberry Pi
  
  # Memory settings (Pi-optimized)
  memory_enabled: true
  max_conversation_history: 20  # Lower for Pi RAM
  
  # Skills
  skills_enabled: true
  skills_dirs:
    - ${FAMILIAR_HOME}/familiar/skills
  
  # Security
  security_mode: balanced
  sandboxed_directories:
    - ${FAMILIAR_DATA}
    - /tmp/familiar

  # Scheduler (for reminders, etc.)
  scheduler_enabled: true

channels:
  cli_enabled: true
  telegram_enabled: ${ENABLE_TELEGRAM:-false}
  discord_enabled: ${ENABLE_DISCORD:-false}
  signal_enabled: ${ENABLE_SIGNAL:-false}

observability:
  tracing_enabled: true
  log_traces: true
  log_level: INFO
  log_file: ${FAMILIAR_LOG}/familiar.log

resilience:
  enabled: true
  max_attempts: 3
  base_delay: 1.0
  max_delay: 30.0

# Pi-specific settings
pi:
  # Monitor CPU temperature
  monitor_temp: true
  temp_warn_threshold: 70  # Celsius
  temp_critical_threshold: 80
  
  # Throttle inference if overheating
  auto_throttle: true
EOF

    chown "$FAMILIAR_USER:$FAMILIAR_USER" "$CONFIG_FILE"
    
    # Create .env template for secrets
    ENV_FILE="$FAMILIAR_HOME/.familiar/.env"
    if [ ! -f "$ENV_FILE" ]; then
        cat > "$ENV_FILE" << EOF
# Familiar Environment Variables
# Add your API keys here - this file is not tracked by git

# LLM Provider API Keys (at least one required unless using Ollama only)
ANTHROPIC_API_KEY=
OPENAI_API_KEY=

# Channel Tokens (optional - enable in config.yaml)
TELEGRAM_BOT_TOKEN=
DISCORD_BOT_TOKEN=

# Webhook Security (auto-generated if empty)
FAMILIAR_WEBHOOK_SECRET=$(openssl rand -hex 32)
EOF
        chmod 600 "$ENV_FILE"
        chown "$FAMILIAR_USER:$FAMILIAR_USER" "$ENV_FILE"
    fi
    
    # Nonprofit preset: override skills and add cost notice
    if [ "$NONPROFIT_MODE" = true ]; then
        cat >> "$CONFIG_FILE" << 'NPEOF'

# Nonprofit Assistant Preset
# Focused skills for nonprofit operations
skills:
  enabled:
    - email
    - calendar
    - triage
    - gdrive
    - tasks
    - nonprofit
    - knowledge
    - proactive
NPEOF
        log_info "Nonprofit preset applied (email, calendar, triage, gdrive, tasks, nonprofit, knowledge, proactive)"
        log_info "Estimated cost: ~\$3-10/month for typical nonprofit use with Claude"
    fi

    log_success "Configuration created at $CONFIG_FILE"
    log_warn "Edit $ENV_FILE to add your API keys"
}

create_systemd_service() {
    log_info "Creating systemd service..."
    
    cat > /etc/systemd/system/familiar.service << EOF
[Unit]
Description=Familiar AI Agent
Documentation=https://github.com/georgescottfoley/familiar
After=network-online.target
Wants=network-online.target
${INSTALL_OLLAMA:+After=ollama.service}

[Service]
Type=simple
User=${FAMILIAR_USER}
Group=${FAMILIAR_USER}
WorkingDirectory=${FAMILIAR_HOME}/familiar

# Environment
Environment="HOME=${FAMILIAR_HOME}"
Environment="PATH=${FAMILIAR_HOME}/venv/bin:/usr/local/bin:/usr/bin:/bin"
EnvironmentFile=${FAMILIAR_HOME}/.familiar/.env

# Run Familiar
ExecStart=${FAMILIAR_HOME}/venv/bin/python -m familiar

# Restart policy
Restart=on-failure
RestartSec=10
StartLimitInterval=60
StartLimitBurst=3

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=${FAMILIAR_DATA} ${FAMILIAR_LOG} ${FAMILIAR_HOME}/.familiar

# Resource limits (Pi-friendly)
MemoryMax=1G
CPUQuota=80%

# Logging
StandardOutput=append:${FAMILIAR_LOG}/familiar.log
StandardError=append:${FAMILIAR_LOG}/familiar.log

[Install]
WantedBy=multi-user.target
EOF

    # Create log rotation
    cat > /etc/logrotate.d/familiar << EOF
${FAMILIAR_LOG}/*.log {
    daily
    missingok
    rotate 7
    compress
    delaycompress
    notifempty
    create 0640 ${FAMILIAR_USER} ${FAMILIAR_USER}
    sharedscripts
    postrotate
        systemctl reload familiar > /dev/null 2>&1 || true
    endscript
}
EOF

    systemctl daemon-reload
    
    log_success "Systemd service created"
}

configure_firewall() {
    log_info "Configuring firewall..."
    
    # Enable UFW
    ufw --force enable
    
    # Allow SSH
    ufw allow ssh
    
    # Allow local network access to dashboard (optional)
    if [ "$ENABLE_DASHBOARD" = true ]; then
        ufw allow from 192.168.0.0/16 to any port 8080 comment 'Familiar Dashboard'
        ufw allow from 10.0.0.0/8 to any port 8080 comment 'Familiar Dashboard'
    fi
    
    # Deny everything else by default
    ufw default deny incoming
    ufw default allow outgoing
    
    log_success "Firewall configured"
}

configure_fail2ban() {
    log_info "Configuring fail2ban..."
    
    # Basic fail2ban config for SSH
    cat > /etc/fail2ban/jail.local << EOF
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 3600
EOF

    systemctl enable fail2ban
    systemctl restart fail2ban
    
    log_success "fail2ban configured"
}

print_banner() {
    echo ""
    echo -e "${GREEN}"
    echo "  ███████╗ ██████╗██╗  ██╗██╗██████╗ ███╗   ██╗ █████╗ "
    echo "  ██╔════╝██╔════╝██║  ██║██║██╔══██╗████╗  ██║██╔══██╗"
    echo "  █████╗  ██║     ███████║██║██║  ██║██╔██╗ ██║███████║"
    echo "  ██╔══╝  ██║     ██╔══██║██║██║  ██║██║╚██╗██║██╔══██║"
    echo "  ███████╗╚██████╗██║  ██║██║██████╔╝██║ ╚████║██║  ██║"
    echo "  ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝"
    echo -e "${NC}"
    echo "  Your AI runs at home. Your data stays at home."
    echo "  Version: $FAMILIAR_VERSION"
    echo ""
}

print_completion() {
    LOCAL_IP=$(hostname -I | awk '{print $1}')
    
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}  Installation Complete!${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "  Next steps:"
    echo ""
    echo "  1. Add your API key:"
    echo -e "     ${YELLOW}sudo nano $FAMILIAR_HOME/.familiar/.env${NC}"
    echo "     Add: ANTHROPIC_API_KEY=sk-ant-..."
    echo ""
    echo "  2. Start Familiar:"
    echo -e "     ${YELLOW}sudo systemctl start familiar${NC}"
    echo ""
    echo "  3. Check status:"
    echo -e "     ${YELLOW}sudo systemctl status familiar${NC}"
    echo ""
    echo "  4. View logs:"
    echo -e "     ${YELLOW}tail -f $FAMILIAR_LOG/familiar.log${NC}"
    echo ""
    echo "  5. Test with CLI:"
    echo -e "     ${YELLOW}sudo -u familiar $FAMILIAR_HOME/venv/bin/python -m familiar.channels.cli${NC}"
    echo ""
    
    if [ "$INSTALL_OLLAMA" = true ] && $CAN_RUN_OLLAMA; then
        echo "  Local LLM (Ollama):"
        echo "     Model: $OLLAMA_MODEL"
        echo "     Test: ollama run $OLLAMA_MODEL 'Hello!'"
        echo ""
    fi
    
    if [ "$ENABLE_DASHBOARD" = true ]; then
        echo "  Dashboard:"
        echo "     http://${LOCAL_IP}:8080"
        echo ""
    fi
    
    echo "  Useful commands:"
    echo "     sudo systemctl enable familiar  # Start on boot"
    echo "     sudo systemctl restart familiar # Restart"
    echo "     sudo journalctl -u familiar -f  # Live logs"
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# ============================================================
# ARGUMENT PARSING
# ============================================================

INSTALL_OLLAMA=false
INSTALL_VOICE=false
ENABLE_DASHBOARD=false
ENABLE_TELEGRAM=false
ENABLE_DISCORD=false
ENABLE_SIGNAL=false
NONPROFIT_MODE=false
DEFAULT_PROVIDER="anthropic"

while [[ $# -gt 0 ]]; do
    case $1 in
        --nonprofit)
            NONPROFIT_MODE=true
            ENABLE_TELEGRAM=true
            shift
            ;;
        --with-ollama)
            INSTALL_OLLAMA=true
            DEFAULT_PROVIDER="ollama"
            shift
            ;;
        --with-voice)
            INSTALL_VOICE=true
            shift
            ;;
        --with-dashboard)
            ENABLE_DASHBOARD=true
            shift
            ;;
        --channel)
            case $2 in
                telegram) ENABLE_TELEGRAM=true ;;
                discord) ENABLE_DISCORD=true ;;
                signal) ENABLE_SIGNAL=true ;;
                *) log_error "Unknown channel: $2"; exit 1 ;;
            esac
            shift 2
            ;;
        --provider)
            DEFAULT_PROVIDER="$2"
            shift 2
            ;;
        --help|-h)
            echo "Familiar Pi Installation Script"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --nonprofit        Nonprofit assistant preset (email, calendar, tasks)"
            echo "  --with-ollama      Install Ollama for local LLM inference"
            echo "  --with-voice       Install voice/speech dependencies"
            echo "  --with-dashboard   Enable web dashboard"
            echo "  --channel NAME     Enable channel (telegram, discord, signal)"
            echo "  --provider NAME    Default LLM provider (anthropic, openai, ollama)"
            echo "  --help, -h         Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 --with-ollama"
            echo "  $0 --channel telegram --provider anthropic"
            echo "  $0 --with-ollama --with-voice --with-dashboard"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# ============================================================
# MAIN
# ============================================================

main() {
    print_banner
    check_root
    
    log_info "Starting Familiar installation..."
    echo ""
    
    # System checks
    detect_pi_model
    check_memory
    check_disk_space
    check_architecture
    echo ""
    
    # Confirm installation
    log_info "Installation settings:"
    echo "  - Nonprofit mode: $NONPROFIT_MODE"
    echo "  - Ollama: $INSTALL_OLLAMA"
    echo "  - Voice: $INSTALL_VOICE"
    echo "  - Dashboard: $ENABLE_DASHBOARD"
    echo "  - Default provider: $DEFAULT_PROVIDER"
    echo ""
    
    read -p "Continue with installation? [Y/n] " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]] && [[ -n $REPLY ]]; then
        log_info "Installation cancelled"
        exit 0
    fi
    
    echo ""
    
    # Installation steps
    install_system_deps
    create_familiar_user
    install_familiar
    install_ollama
    configure_familiar
    create_systemd_service
    configure_firewall
    configure_fail2ban
    
    print_completion
}

# Run main function
main "$@"
