#!/bin/bash
#
# Familiar Security Verification Script
#
# Validates that security hardening has been properly applied.
# Run after installation or periodically to verify security posture.
#
# Usage:
#   ./verify-security.sh           # Run all checks
#   ./verify-security.sh --quick   # Run essential checks only
#   ./verify-security.sh --json    # Output as JSON
#
# Exit codes:
#   0 - All checks passed
#   1 - One or more checks failed
#   2 - Script error
#

set -e

# Configuration
FAMILIAR_USER="${FAMILIAR_USER:-familiar}"
FAMILIAR_HOME="${FAMILIAR_HOME:-/opt/familiar}"
FAMILIAR_DATA="${FAMILIAR_DATA:-/var/lib/familiar}"
FAMILIAR_LOG="${FAMILIAR_LOG:-/var/log/familiar}"
SERVICE_NAME="familiar"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Counters
PASSED=0
FAILED=0
WARNINGS=0

# Output mode
JSON_OUTPUT=false
QUICK_MODE=false

# Results array for JSON output
declare -a RESULTS

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --json)
            JSON_OUTPUT=true
            shift
            ;;
        --quick)
            QUICK_MODE=true
            shift
            ;;
        --help|-h)
            echo "Familiar Security Verification Script"
            echo ""
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --quick    Run essential checks only"
            echo "  --json     Output results as JSON"
            echo "  --help     Show this help"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 2
            ;;
    esac
done

# Logging functions
log_pass() {
    local check="$1"
    local detail="$2"
    PASSED=$((PASSED + 1))
    
    if $JSON_OUTPUT; then
        RESULTS+=("{\"check\": \"$check\", \"status\": \"pass\", \"detail\": \"$detail\"}")
    else
        echo -e "${GREEN}[PASS]${NC} $check"
        [[ -n "$detail" ]] && echo "       $detail"
    fi
}

log_fail() {
    local check="$1"
    local detail="$2"
    FAILED=$((FAILED + 1))
    
    if $JSON_OUTPUT; then
        RESULTS+=("{\"check\": \"$check\", \"status\": \"fail\", \"detail\": \"$detail\"}")
    else
        echo -e "${RED}[FAIL]${NC} $check"
        [[ -n "$detail" ]] && echo "       $detail"
    fi
}

log_warn() {
    local check="$1"
    local detail="$2"
    WARNINGS=$((WARNINGS + 1))
    
    if $JSON_OUTPUT; then
        RESULTS+=("{\"check\": \"$check\", \"status\": \"warn\", \"detail\": \"$detail\"}")
    else
        echo -e "${YELLOW}[WARN]${NC} $check"
        [[ -n "$detail" ]] && echo "       $detail"
    fi
}

log_skip() {
    local check="$1"
    local reason="$2"
    
    if $JSON_OUTPUT; then
        RESULTS+=("{\"check\": \"$check\", \"status\": \"skip\", \"detail\": \"$reason\"}")
    else
        echo -e "${BLUE}[SKIP]${NC} $check"
        [[ -n "$reason" ]] && echo "       $reason"
    fi
}

section() {
    if ! $JSON_OUTPUT; then
        echo ""
        echo -e "${BLUE}=== $1 ===${NC}"
        echo ""
    fi
}

# ============================================================
# CHECK FUNCTIONS
# ============================================================

check_running_as_non_root() {
    local check="Service runs as non-root user"
    
    if ! systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
        log_skip "$check" "Service not running"
        return
    fi
    
    local pid=$(pgrep -f "python.*familiar" | head -1)
    if [[ -z "$pid" ]]; then
        log_skip "$check" "Could not find process"
        return
    fi
    
    local proc_user=$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')
    
    if [[ "$proc_user" == "root" ]]; then
        log_fail "$check" "Running as root (should be $FAMILIAR_USER)"
    elif [[ "$proc_user" == "$FAMILIAR_USER" ]]; then
        log_pass "$check" "Running as $proc_user"
    else
        log_warn "$check" "Running as $proc_user (expected $FAMILIAR_USER)"
    fi
}

check_env_file_permissions() {
    local check=".env file permissions"
    local env_file="$FAMILIAR_HOME/.familiar/.env"
    
    if [[ ! -f "$env_file" ]]; then
        log_warn "$check" "File not found: $env_file"
        return
    fi
    
    local perms=$(stat -c %a "$env_file" 2>/dev/null)
    local owner=$(stat -c %U "$env_file" 2>/dev/null)
    
    if [[ "$perms" == "600" ]]; then
        log_pass "$check" "Permissions: $perms, Owner: $owner"
    elif [[ "$perms" == "640" ]]; then
        log_warn "$check" "Permissions: $perms (should be 600)"
    else
        log_fail "$check" "Permissions: $perms (should be 600)"
    fi
}

check_no_secrets_in_config() {
    local check="No secrets in config.yaml"
    local config_file="$FAMILIAR_HOME/.familiar/config.yaml"
    
    if [[ ! -f "$config_file" ]]; then
        log_skip "$check" "Config file not found"
        return
    fi
    
    # Check for common secret patterns
    if grep -qiE "(sk-ant-|sk-[a-z]{20,}|api_key\s*[:=]\s*['\"][^'\"]+['\"])" "$config_file" 2>/dev/null; then
        log_fail "$check" "Found potential API key in config.yaml"
    elif grep -qiE "(token\s*[:=]\s*['\"][0-9]+:[^'\"]+['\"])" "$config_file" 2>/dev/null; then
        log_fail "$check" "Found potential bot token in config.yaml"
    else
        log_pass "$check" "No hardcoded secrets detected"
    fi
}

check_firewall_enabled() {
    local check="Firewall enabled"
    
    if ! command -v ufw &>/dev/null; then
        log_skip "$check" "ufw not installed"
        return
    fi
    
    if sudo ufw status 2>/dev/null | grep -q "Status: active"; then
        log_pass "$check" "UFW is active"
    else
        log_fail "$check" "UFW is not active"
    fi
}

check_firewall_rules() {
    local check="Firewall restricts incoming"
    
    if ! command -v ufw &>/dev/null; then
        log_skip "$check" "ufw not installed"
        return
    fi
    
    local default_incoming=$(sudo ufw status verbose 2>/dev/null | grep "Default:" | grep -o "deny (incoming)" || echo "")
    
    if [[ -n "$default_incoming" ]]; then
        log_pass "$check" "Default policy: deny incoming"
    else
        log_warn "$check" "Default incoming not set to deny"
    fi
}

check_ssh_password_auth() {
    local check="SSH password authentication disabled"
    
    if grep -qE "^PasswordAuthentication\s+no" /etc/ssh/sshd_config 2>/dev/null; then
        log_pass "$check" "Password auth disabled in sshd_config"
    elif grep -qE "^PasswordAuthentication\s+yes" /etc/ssh/sshd_config 2>/dev/null; then
        log_warn "$check" "Password auth is enabled"
    else
        log_warn "$check" "PasswordAuthentication not explicitly set"
    fi
}

check_systemd_security() {
    local check="Systemd security directives"
    local service_file="/etc/systemd/system/$SERVICE_NAME.service"
    
    if [[ ! -f "$service_file" ]]; then
        log_skip "$check" "Service file not found"
        return
    fi
    
    local issues=""
    
    if ! grep -q "NoNewPrivileges=true" "$service_file"; then
        issues="$issues NoNewPrivileges"
    fi
    
    if ! grep -q "ProtectSystem=" "$service_file"; then
        issues="$issues ProtectSystem"
    fi
    
    if ! grep -q "PrivateTmp=true" "$service_file"; then
        issues="$issues PrivateTmp"
    fi
    
    if [[ -z "$issues" ]]; then
        log_pass "$check" "Key directives present"
    else
        log_fail "$check" "Missing:$issues"
    fi
}

check_log_rotation() {
    local check="Log rotation configured"
    
    if [[ -f "/etc/logrotate.d/familiar" ]]; then
        log_pass "$check" "Logrotate config exists"
    elif [[ -d "$FAMILIAR_LOG" ]]; then
        log_warn "$check" "Log directory exists but no rotation config"
    else
        log_skip "$check" "Logging not configured"
    fi
}

check_encryption_key() {
    local check="Encryption key configured"
    
    # Check environment
    if [[ -n "$FAMILIAR_ENCRYPTION_KEY" ]]; then
        log_pass "$check" "Set in environment"
        return
    fi
    
    # Check .env file
    local env_file="$FAMILIAR_HOME/.familiar/.env"
    if [[ -f "$env_file" ]] && grep -q "FAMILIAR_ENCRYPTION_KEY=" "$env_file"; then
        local key_value=$(grep "FAMILIAR_ENCRYPTION_KEY=" "$env_file" | cut -d= -f2)
        if [[ -n "$key_value" && "$key_value" != "" ]]; then
            log_pass "$check" "Set in .env file"
        else
            log_warn "$check" "Variable exists but empty"
        fi
    else
        log_warn "$check" "Not configured (encryption at rest disabled)"
    fi
}

check_encryption_enabled() {
    local check="Encryption at rest enabled"
    local config_file="$FAMILIAR_HOME/.familiar/config.yaml"
    
    if [[ ! -f "$config_file" ]]; then
        log_skip "$check" "Config file not found"
        return
    fi
    
    if grep -qE "encrypt_(sessions|memory|history):\s*true" "$config_file" 2>/dev/null; then
        log_pass "$check" "Encryption enabled in config"
    else
        log_warn "$check" "Encryption not enabled in config"
    fi
}

check_fail2ban() {
    local check="Fail2ban installed and active"
    
    if ! command -v fail2ban-client &>/dev/null; then
        log_warn "$check" "fail2ban not installed"
        return
    fi
    
    if systemctl is-active --quiet fail2ban 2>/dev/null; then
        log_pass "$check" "fail2ban is running"
    else
        log_warn "$check" "fail2ban installed but not running"
    fi
}

check_auto_updates() {
    local check="Automatic security updates"
    
    if [[ -f "/etc/apt/apt.conf.d/20auto-upgrades" ]]; then
        if grep -q 'Unattended-Upgrade "1"' /etc/apt/apt.conf.d/20auto-upgrades 2>/dev/null; then
            log_pass "$check" "Unattended upgrades enabled"
        else
            log_warn "$check" "Unattended upgrades not enabled"
        fi
    else
        log_warn "$check" "Auto-updates not configured"
    fi
}

check_data_directory_permissions() {
    local check="Data directory permissions"
    
    if [[ ! -d "$FAMILIAR_DATA" ]]; then
        log_skip "$check" "Data directory not found: $FAMILIAR_DATA"
        return
    fi
    
    local perms=$(stat -c %a "$FAMILIAR_DATA" 2>/dev/null)
    local owner=$(stat -c %U "$FAMILIAR_DATA" 2>/dev/null)
    
    if [[ "$owner" == "$FAMILIAR_USER" ]]; then
        if [[ "$perms" == "700" || "$perms" == "750" ]]; then
            log_pass "$check" "Owner: $owner, Permissions: $perms"
        else
            log_warn "$check" "Permissions: $perms (recommended: 700 or 750)"
        fi
    else
        log_fail "$check" "Wrong owner: $owner (expected: $FAMILIAR_USER)"
    fi
}

check_backup_exists() {
    local check="Backup files exist"
    local backup_dir="/var/backups/familiar"
    
    if [[ -d "$backup_dir" ]]; then
        local backup_count=$(ls -1 "$backup_dir"/*.tar.gz 2>/dev/null | wc -l)
        if [[ "$backup_count" -gt 0 ]]; then
            local latest=$(ls -t "$backup_dir"/*.tar.gz 2>/dev/null | head -1)
            local age_days=$(( ($(date +%s) - $(stat -c %Y "$latest")) / 86400 ))
            if [[ "$age_days" -lt 7 ]]; then
                log_pass "$check" "$backup_count backups, latest: ${age_days}d old"
            else
                log_warn "$check" "Latest backup is ${age_days} days old"
            fi
        else
            log_warn "$check" "Backup directory empty"
        fi
    else
        log_warn "$check" "No backup directory found"
    fi
}

check_listening_ports() {
    local check="Minimal listening ports"
    
    if ! command -v ss &>/dev/null; then
        log_skip "$check" "ss command not available"
        return
    fi
    
    # Get ports listening on all interfaces (0.0.0.0 or ::)
    local public_ports=$(ss -tlnp 2>/dev/null | grep -E "0\.0\.0\.0|:::" | awk '{print $4}' | grep -oE '[0-9]+$' | sort -u | tr '\n' ' ')
    
    if [[ -z "$public_ports" ]]; then
        log_pass "$check" "No public listening ports"
    else
        # Check if only SSH
        if [[ "$public_ports" == "22 " || "$public_ports" == "22" ]]; then
            log_pass "$check" "Only SSH (22) exposed"
        else
            log_warn "$check" "Exposed ports: $public_ports"
        fi
    fi
}

check_disk_encryption() {
    local check="Disk encryption (LUKS)"
    
    if command -v cryptsetup &>/dev/null; then
        if lsblk -o NAME,TYPE,FSTYPE 2>/dev/null | grep -q "crypt"; then
            log_pass "$check" "LUKS encryption detected"
        else
            log_warn "$check" "No encrypted volumes detected"
        fi
    else
        log_skip "$check" "cryptsetup not installed"
    fi
}

check_service_status() {
    local check="Service running and enabled"
    
    if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then
        if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
            log_pass "$check" "Running and enabled at boot"
        else
            log_warn "$check" "Enabled but not running"
        fi
    else
        log_warn "$check" "Not enabled at boot"
    fi
}

check_audit_logging() {
    local check="Audit logging enabled"
    local config_file="$FAMILIAR_HOME/.familiar/config.yaml"
    
    if [[ ! -f "$config_file" ]]; then
        log_skip "$check" "Config file not found"
        return
    fi
    
    if grep -qE "audit_logging:\s*true" "$config_file" 2>/dev/null; then
        log_pass "$check" "Audit logging enabled in config"
    else
        log_warn "$check" "Audit logging not enabled"
    fi
}

check_pii_redaction() {
    local check="PII redaction in logs"
    local config_file="$FAMILIAR_HOME/.familiar/config.yaml"
    
    if [[ ! -f "$config_file" ]]; then
        log_skip "$check" "Config file not found"
        return
    fi
    
    if grep -qE "pii_redaction:\s*true" "$config_file" 2>/dev/null; then
        log_pass "$check" "PII redaction enabled"
    else
        log_warn "$check" "PII redaction not enabled"
    fi
}

check_api_keys_in_logs() {
    local check="No API keys in logs"
    local log_file="$FAMILIAR_LOG/familiar.log"
    
    if [[ ! -f "$log_file" ]]; then
        log_skip "$check" "Log file not found"
        return
    fi
    
    # Check last 1000 lines for API key patterns
    if tail -n 1000 "$log_file" 2>/dev/null | grep -qE "sk-ant-[a-zA-Z0-9-]{20,}|sk-[a-zA-Z0-9]{40,}"; then
        log_fail "$check" "Found potential API key in logs!"
    else
        log_pass "$check" "No API keys detected in recent logs"
    fi
}

# ============================================================
# MAIN
# ============================================================

main() {
    if ! $JSON_OUTPUT; then
        echo ""
        echo "╔════════════════════════════════════════════════════════════╗"
        echo "║          Familiar Security Verification Report              ║"
        echo "╚════════════════════════════════════════════════════════════╝"
        echo ""
        echo "Target: $FAMILIAR_HOME"
        echo "User: $FAMILIAR_USER"
        echo "Date: $(date)"
    fi
    
    # Essential checks (always run)
    section "Essential Security Checks"
    check_running_as_non_root
    check_env_file_permissions
    check_no_secrets_in_config
    check_firewall_enabled
    check_systemd_security
    check_log_rotation
    
    if ! $QUICK_MODE; then
        # Recommended checks
        section "Recommended Security Checks"
        check_encryption_key
        check_encryption_enabled
        check_fail2ban
        check_ssh_password_auth
        check_auto_updates
        check_backup_exists
        
        # Advanced checks
        section "Advanced Security Checks"
        check_firewall_rules
        check_data_directory_permissions
        check_listening_ports
        check_disk_encryption
        check_audit_logging
        check_pii_redaction
        check_api_keys_in_logs
        
        # Operational checks
        section "Operational Checks"
        check_service_status
    fi
    
    # Output results
    if $JSON_OUTPUT; then
        echo "{"
        echo "  \"timestamp\": \"$(date -Iseconds)\","
        echo "  \"target\": \"$FAMILIAR_HOME\","
        echo "  \"passed\": $PASSED,"
        echo "  \"failed\": $FAILED,"
        echo "  \"warnings\": $WARNINGS,"
        echo "  \"checks\": ["
        local first=true
        for result in "${RESULTS[@]}"; do
            if $first; then
                first=false
            else
                echo ","
            fi
            echo -n "    $result"
        done
        echo ""
        echo "  ]"
        echo "}"
    else
        echo ""
        echo "════════════════════════════════════════════════════════════"
        echo ""
        echo -e "Results: ${GREEN}$PASSED passed${NC}, ${RED}$FAILED failed${NC}, ${YELLOW}$WARNINGS warnings${NC}"
        echo ""
        
        if [[ $FAILED -gt 0 ]]; then
            echo -e "${RED}⚠ Security issues detected! Review failed checks above.${NC}"
            echo ""
        elif [[ $WARNINGS -gt 0 ]]; then
            echo -e "${YELLOW}✓ Essential security in place, but improvements recommended.${NC}"
            echo ""
        else
            echo -e "${GREEN}✓ All security checks passed!${NC}"
            echo ""
        fi
    fi
    
    # Exit code
    if [[ $FAILED -gt 0 ]]; then
        exit 1
    fi
    exit 0
}

# Run main
main
