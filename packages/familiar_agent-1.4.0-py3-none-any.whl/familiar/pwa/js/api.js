/**
 * Familiar - Self-hosted AI Agent
 * Copyright (c) 2026 George Scott Foley
 * 
 * Licensed under the MIT License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://familiar.ai/license
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * For commercial licensing, contact: licensing@familiar.ai
 */

/**
 * Familiar API Client
 * Handles REST API and WebSocket communication
 */

class FamiliarAPI {
  constructor(baseUrl = '') {
    this.baseUrl = baseUrl || window.location.origin;
    this.token = localStorage.getItem('familiar_token');
    this.ws = null;
    this.wsReconnectTimer = null;
    this.wsReconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
    this.listeners = new Map();
  }

  // ═══════════════════════════════════════════════════════════════
  // REST API
  // ═══════════════════════════════════════════════════════════════

  async request(endpoint, options = {}) {
    const url = this.baseUrl + endpoint;
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  }

  async post(endpoint, data) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Chat
  async chat(message, conversationId = null) {
    return this.post('/api/chat', {
      message,
      conversation_id: conversationId,
    });
  }

  // Conversations
  async getConversations() {
    return this.get('/api/conversations');
  }

  async getConversation(id) {
    return this.get(`/api/conversations/${id}`);
  }

  // Skills
  async getSkills() {
    return this.get('/api/skills');
  }

  async invokeSkill(skillName, action, params = {}) {
    return this.post(`/api/skills/${skillName}/${action}`, params);
  }

  // Status
  async ping() {
    return this.get('/api/ping');
  }

  async getStatus() {
    return this.get('/api/status');
  }

  // ═══════════════════════════════════════════════════════════════
  // WebSocket
  // ═══════════════════════════════════════════════════════════════

  connectWebSocket() {
    if (this.ws?.readyState === WebSocket.OPEN) {
      return;
    }

    const wsUrl = this.baseUrl.replace(/^http/, 'ws') + '/ws';
    
    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[WS] Connected');
        this.wsReconnectAttempts = 0;
        
        // Authenticate
        if (this.token) {
          this.ws.send(JSON.stringify({
            type: 'auth',
            token: this.token,
          }));
        }
        
        this.emit('connected');
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleMessage(data);
        } catch (e) {
          console.error('[WS] Invalid message:', e);
        }
      };

      this.ws.onclose = () => {
        console.log('[WS] Disconnected');
        this.emit('disconnected');
        this.scheduleReconnect();
      };

      this.ws.onerror = (error) => {
        console.error('[WS] Error:', error);
        this.emit('error', error);
      };
    } catch (e) {
      console.error('[WS] Connection failed:', e);
      this.scheduleReconnect();
    }
  }

  scheduleReconnect() {
    if (this.wsReconnectAttempts >= this.maxReconnectAttempts) {
      console.log('[WS] Max reconnect attempts reached');
      return;
    }

    const delay = Math.min(1000 * Math.pow(2, this.wsReconnectAttempts), 30000);
    this.wsReconnectAttempts++;

    console.log(`[WS] Reconnecting in ${delay}ms (attempt ${this.wsReconnectAttempts})`);

    this.wsReconnectTimer = setTimeout(() => {
      if (navigator.onLine) {
        this.connectWebSocket();
      }
    }, delay);
  }

  disconnectWebSocket() {
    if (this.wsReconnectTimer) {
      clearTimeout(this.wsReconnectTimer);
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  handleMessage(data) {
    switch (data.type) {
      case 'auth_success':
        this.emit('authenticated', data);
        break;
      case 'auth_failed':
        this.emit('auth_error', data);
        break;
      case 'response':
        this.emit('response', data);
        break;
      case 'typing':
        this.emit('typing', data);
        break;
      case 'error':
        this.emit('error', data);
        break;
      default:
        console.log('[WS] Unknown message type:', data.type);
    }
  }

  sendWS(data) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
      return true;
    }
    return false;
  }

  sendChat(message, conversationId = null) {
    return this.sendWS({
      type: 'chat',
      content: message,
      conversationId,
      timestamp: Date.now(),
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // Event Emitter
  // ═══════════════════════════════════════════════════════════════

  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event).add(callback);
  }

  off(event, callback) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).delete(callback);
    }
  }

  emit(event, data) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (e) {
          console.error(`[Event] Error in ${event} handler:`, e);
        }
      });
    }
  }
}

// Export
window.FamiliarAPI = FamiliarAPI;
