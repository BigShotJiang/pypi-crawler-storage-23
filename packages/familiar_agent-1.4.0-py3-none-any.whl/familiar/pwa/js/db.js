/**
 * Familiar - Self-hosted AI Agent
 * Copyright (c) 2026 George Scott Foley
 * 
 * Licensed under the MIT License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://familiar.ai/license
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * For commercial licensing, contact: licensing@familiar.ai
 */

/**
 * Familiar IndexedDB Wrapper
 * Local storage for offline support
 */

class FamiliarDB {
  constructor(dbName = 'familiar', version = 1) {
    this.dbName = dbName;
    this.version = version;
    this.db = null;
  }

  // ═══════════════════════════════════════════════════════════════
  // Database Setup
  // ═══════════════════════════════════════════════════════════════

  async open() {
    if (this.db) return this.db;

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // Message outbox (offline queue)
        if (!db.objectStoreNames.contains('outbox')) {
          const outbox = db.createObjectStore('outbox', { 
            keyPath: 'id', 
            autoIncrement: true 
          });
          outbox.createIndex('timestamp', 'timestamp');
        }

        // Cached messages
        if (!db.objectStoreNames.contains('messages')) {
          const messages = db.createObjectStore('messages', { keyPath: 'id' });
          messages.createIndex('conversationId', 'conversationId');
          messages.createIndex('timestamp', 'timestamp');
        }

        // Cached conversations
        if (!db.objectStoreNames.contains('conversations')) {
          const conversations = db.createObjectStore('conversations', { keyPath: 'id' });
          conversations.createIndex('updatedAt', 'updatedAt');
        }

        // Settings
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };
    });
  }

  async close() {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // Generic Operations
  // ═══════════════════════════════════════════════════════════════

  async getStore(storeName, mode = 'readonly') {
    const db = await this.open();
    const tx = db.transaction(storeName, mode);
    return tx.objectStore(storeName);
  }

  async get(storeName, key) {
    const store = await this.getStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getAll(storeName, query = null, count = null) {
    const store = await this.getStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.getAll(query, count);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async put(storeName, item) {
    const store = await this.getStore(storeName, 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.put(item);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async add(storeName, item) {
    const store = await this.getStore(storeName, 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.add(item);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async delete(storeName, key) {
    const store = await this.getStore(storeName, 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.delete(key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async clear(storeName) {
    const store = await this.getStore(storeName, 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async count(storeName) {
    const store = await this.getStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.count();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // Outbox (Offline Message Queue)
  // ═══════════════════════════════════════════════════════════════

  async queueMessage(message) {
    const item = {
      ...message,
      id: message.id || `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: message.timestamp || Date.now(),
      status: 'pending',
    };
    await this.add('outbox', item);
    return item.id;
  }

  async getQueuedMessages() {
    return this.getAll('outbox');
  }

  async removeFromQueue(id) {
    return this.delete('outbox', id);
  }

  async clearQueue() {
    return this.clear('outbox');
  }

  async getQueueCount() {
    return this.count('outbox');
  }

  // ═══════════════════════════════════════════════════════════════
  // Messages Cache
  // ═══════════════════════════════════════════════════════════════

  async cacheMessage(message) {
    return this.put('messages', {
      ...message,
      cachedAt: Date.now(),
    });
  }

  async getCachedMessages(conversationId) {
    const db = await this.open();
    const tx = db.transaction('messages', 'readonly');
    const store = tx.objectStore('messages');
    const index = store.index('conversationId');
    
    return new Promise((resolve, reject) => {
      const request = index.getAll(conversationId);
      request.onsuccess = () => {
        // Sort by timestamp
        const messages = request.result.sort((a, b) => a.timestamp - b.timestamp);
        resolve(messages);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async clearMessageCache() {
    return this.clear('messages');
  }

  // ═══════════════════════════════════════════════════════════════
  // Conversations Cache
  // ═══════════════════════════════════════════════════════════════

  async cacheConversation(conversation) {
    return this.put('conversations', {
      ...conversation,
      cachedAt: Date.now(),
    });
  }

  async getCachedConversations() {
    const conversations = await this.getAll('conversations');
    // Sort by updatedAt descending
    return conversations.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  }

  async getCachedConversation(id) {
    return this.get('conversations', id);
  }

  // ═══════════════════════════════════════════════════════════════
  // Settings
  // ═══════════════════════════════════════════════════════════════

  async getSetting(key, defaultValue = null) {
    const item = await this.get('settings', key);
    return item ? item.value : defaultValue;
  }

  async setSetting(key, value) {
    return this.put('settings', { key, value });
  }

  async deleteSetting(key) {
    return this.delete('settings', key);
  }

  // ═══════════════════════════════════════════════════════════════
  // Utility
  // ═══════════════════════════════════════════════════════════════

  async getStorageEstimate() {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      return {
        usage: estimate.usage,
        quota: estimate.quota,
        usagePercent: ((estimate.usage / estimate.quota) * 100).toFixed(2),
      };
    }
    return null;
  }

  async clearAllData() {
    await this.clear('outbox');
    await this.clear('messages');
    await this.clear('conversations');
    await this.clear('settings');
  }
}

// Export
window.FamiliarDB = FamiliarDB;
