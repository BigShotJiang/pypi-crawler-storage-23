/**
 * Familiar - Self-hosted AI Agent
 * Copyright (c) 2026 George Scott Foley
 * 
 * Licensed under the MIT License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://familiar.ai/license
 *
 * For commercial licensing, contact: licensing@familiar.ai
 */

/**
 * Familiar Private Browser UI Component
 * 
 * Embedded browser with privacy features:
 * - All requests proxied through Familiar
 * - Tracker/ad blocking
 * - Reader mode
 * - AI assistance
 * - Page archiving
 */

class FamiliarBrowser {
  constructor(api, containerId) {
    this.api = api;
    this.container = document.getElementById(containerId);
    this.history = [];
    this.historyIndex = -1;
    this.currentResult = null;
    this.settings = {
      privacyMode: 'standard',
      readerMode: false,
      autoSummarize: false,
    };
    
    this.init();
  }
  
  init() {
    this.render();
    this.bindEvents();
    this.showStartPage();
  }
  
  render() {
    this.container.innerHTML = `
      <div class="browser-container">
        <!-- Toolbar -->
        <div class="browser-toolbar">
          <div class="browser-nav">
            <button class="browser-btn" id="browser-back" disabled title="Back">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
              </svg>
            </button>
            <button class="browser-btn" id="browser-forward" disabled title="Forward">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </button>
            <button class="browser-btn" id="browser-refresh" title="Refresh">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M23 4v6h-6M1 20v-6h6"/>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
              </svg>
            </button>
          </div>
          
          <div class="browser-url-bar">
            <span class="browser-security" id="browser-security" title="Privacy status">🔒</span>
            <input type="text" id="browser-url" placeholder="Enter URL or search..." autocomplete="off">
            <button class="browser-btn browser-go" id="browser-go">Go</button>
          </div>
          
          <div class="browser-actions">
            <button class="browser-btn" id="browser-reader" title="Reader Mode">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
              </svg>
            </button>
            <button class="browser-btn" id="browser-ai" title="Ask AI">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                <line x1="12" y1="17" x2="12.01" y2="17"/>
              </svg>
            </button>
            <button class="browser-btn" id="browser-save" title="Save Page">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                <polyline points="17 21 17 13 7 13 7 21"/>
                <polyline points="7 3 7 8 15 8"/>
              </svg>
            </button>
            <button class="browser-btn" id="browser-menu" title="Menu">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="1"/>
                <circle cx="19" cy="12" r="1"/>
                <circle cx="5" cy="12" r="1"/>
              </svg>
            </button>
          </div>
        </div>
        
        <!-- Status Bar -->
        <div class="browser-status" id="browser-status">
          <span class="status-text" id="status-text">Ready</span>
          <span class="status-blocked" id="status-blocked"></span>
        </div>
        
        <!-- Content Frame -->
        <div class="browser-content" id="browser-content">
          <!-- Page content will be rendered here -->
        </div>
        
        <!-- AI Panel (hidden by default) -->
        <div class="browser-ai-panel" id="browser-ai-panel" style="display: none;">
          <div class="ai-panel-header">
            <span>🤖 Ask about this page</span>
            <button class="browser-btn" id="ai-panel-close">×</button>
          </div>
          <div class="ai-panel-summary" id="ai-summary"></div>
          <div class="ai-panel-input">
            <input type="text" id="ai-question" placeholder="Ask a question...">
            <button class="browser-btn" id="ai-ask">Ask</button>
          </div>
          <div class="ai-panel-response" id="ai-response"></div>
        </div>
        
        <!-- Menu Panel (hidden by default) -->
        <div class="browser-menu-panel" id="browser-menu-panel" style="display: none;">
          <div class="menu-item" id="menu-history">📜 History</div>
          <div class="menu-item" id="menu-archive">📁 Saved Pages</div>
          <div class="menu-item" id="menu-settings">⚙️ Privacy Settings</div>
          <hr>
          <div class="menu-item" id="menu-extract">📊 Extract Data</div>
          <div class="menu-item" id="menu-compare">⚖️ Compare Products</div>
        </div>
      </div>
    `;
    
    this.addStyles();
  }
  
  addStyles() {
    if (document.getElementById('browser-styles')) return;
    
    const styles = document.createElement('style');
    styles.id = 'browser-styles';
    styles.textContent = `
      .browser-container {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--color-bg, #fff);
        border-radius: 8px;
        overflow: hidden;
      }
      
      .browser-toolbar {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px;
        background: var(--color-bg-secondary, #f5f5f5);
        border-bottom: 1px solid var(--color-border, #e0e0e0);
      }
      
      .browser-nav {
        display: flex;
        gap: 4px;
      }
      
      .browser-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border: none;
        background: transparent;
        border-radius: 6px;
        cursor: pointer;
        color: var(--color-text, #333);
        transition: background 0.15s;
      }
      
      .browser-btn:hover:not(:disabled) {
        background: var(--color-bg-tertiary, #e5e5e5);
      }
      
      .browser-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      
      .browser-btn.active {
        background: var(--color-primary, #7c3aed);
        color: white;
      }
      
      .browser-url-bar {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 0 12px;
        background: var(--color-bg, #fff);
        border-radius: 20px;
        border: 1px solid var(--color-border, #e0e0e0);
      }
      
      .browser-security {
        font-size: 14px;
      }
      
      .browser-security.secure { color: #22c55e; }
      .browser-security.warning { color: #f59e0b; }
      .browser-security.danger { color: #ef4444; }
      
      #browser-url {
        flex: 1;
        border: none;
        background: transparent;
        padding: 8px 0;
        font-size: 14px;
        outline: none;
        color: var(--color-text, #333);
      }
      
      .browser-go {
        width: auto !important;
        padding: 0 12px;
        font-weight: 500;
        background: var(--color-primary, #7c3aed);
        color: white;
        border-radius: 16px;
      }
      
      .browser-actions {
        display: flex;
        gap: 4px;
      }
      
      .browser-status {
        display: flex;
        justify-content: space-between;
        padding: 4px 12px;
        font-size: 12px;
        color: var(--color-text-secondary, #666);
        background: var(--color-bg-secondary, #f5f5f5);
        border-bottom: 1px solid var(--color-border, #e0e0e0);
      }
      
      .status-blocked {
        color: var(--color-primary, #7c3aed);
      }
      
      .browser-content {
        flex: 1;
        overflow: auto;
        padding: 16px;
        background: var(--color-bg, #fff);
      }
      
      .browser-content.reader-mode {
        max-width: 700px;
        margin: 0 auto;
        font-family: Georgia, serif;
        font-size: 18px;
        line-height: 1.7;
      }
      
      .browser-ai-panel {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: var(--color-bg, #fff);
        border-top: 1px solid var(--color-border, #e0e0e0);
        box-shadow: 0 -4px 12px rgba(0,0,0,0.1);
        max-height: 50%;
        overflow: auto;
      }
      
      .ai-panel-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        font-weight: 600;
        border-bottom: 1px solid var(--color-border, #e0e0e0);
      }
      
      .ai-panel-summary {
        padding: 12px 16px;
        font-size: 14px;
        color: var(--color-text-secondary, #666);
        border-bottom: 1px solid var(--color-border, #e0e0e0);
      }
      
      .ai-panel-input {
        display: flex;
        gap: 8px;
        padding: 12px 16px;
      }
      
      #ai-question {
        flex: 1;
        padding: 8px 12px;
        border: 1px solid var(--color-border, #e0e0e0);
        border-radius: 20px;
        font-size: 14px;
        outline: none;
      }
      
      #ai-ask {
        width: auto !important;
        padding: 0 16px;
        background: var(--color-primary, #7c3aed);
        color: white;
        border-radius: 20px;
      }
      
      .ai-panel-response {
        padding: 12px 16px;
        font-size: 14px;
        white-space: pre-wrap;
      }
      
      .browser-menu-panel {
        position: absolute;
        top: 56px;
        right: 8px;
        background: var(--color-bg, #fff);
        border: 1px solid var(--color-border, #e0e0e0);
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        min-width: 180px;
        z-index: 100;
      }
      
      .menu-item {
        padding: 12px 16px;
        cursor: pointer;
        transition: background 0.15s;
      }
      
      .menu-item:hover {
        background: var(--color-bg-secondary, #f5f5f5);
      }
      
      /* Start Page */
      .browser-start-page {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        text-align: center;
        padding: 24px;
      }
      
      .browser-start-page h2 {
        margin: 0 0 8px 0;
        font-size: 24px;
      }
      
      .browser-start-page p {
        color: var(--color-text-secondary, #666);
        margin: 0 0 24px 0;
      }
      
      .quick-links {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        justify-content: center;
        max-width: 500px;
      }
      
      .quick-link {
        padding: 12px 20px;
        background: var(--color-bg-secondary, #f5f5f5);
        border-radius: 20px;
        cursor: pointer;
        transition: background 0.15s;
      }
      
      .quick-link:hover {
        background: var(--color-bg-tertiary, #e5e5e5);
      }
      
      /* Loading */
      .browser-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
      }
      
      .loading-spinner {
        width: 40px;
        height: 40px;
        border: 3px solid var(--color-border, #e0e0e0);
        border-top-color: var(--color-primary, #7c3aed);
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }
      
      @keyframes spin {
        to { transform: rotate(360deg); }
      }
      
      /* Error */
      .browser-error {
        padding: 24px;
        text-align: center;
        color: var(--color-error, #ef4444);
      }
    `;
    document.head.appendChild(styles);
  }
  
  bindEvents() {
    // Navigation
    document.getElementById('browser-back').addEventListener('click', () => this.goBack());
    document.getElementById('browser-forward').addEventListener('click', () => this.goForward());
    document.getElementById('browser-refresh').addEventListener('click', () => this.refresh());
    
    // URL bar
    document.getElementById('browser-url').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.navigate();
    });
    document.getElementById('browser-go').addEventListener('click', () => this.navigate());
    
    // Actions
    document.getElementById('browser-reader').addEventListener('click', () => this.toggleReaderMode());
    document.getElementById('browser-ai').addEventListener('click', () => this.toggleAIPanel());
    document.getElementById('browser-save').addEventListener('click', () => this.savePage());
    document.getElementById('browser-menu').addEventListener('click', () => this.toggleMenu());
    
    // AI Panel
    document.getElementById('ai-panel-close').addEventListener('click', () => this.toggleAIPanel());
    document.getElementById('ai-ask').addEventListener('click', () => this.askAI());
    document.getElementById('ai-question').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.askAI();
    });
    
    // Menu items
    document.getElementById('menu-history').addEventListener('click', () => this.showHistory());
    document.getElementById('menu-archive').addEventListener('click', () => this.showArchive());
    document.getElementById('menu-settings').addEventListener('click', () => this.showSettings());
    document.getElementById('menu-extract').addEventListener('click', () => this.extractData());
    
    // Close menu on outside click
    document.addEventListener('click', (e) => {
      const menu = document.getElementById('browser-menu-panel');
      const menuBtn = document.getElementById('browser-menu');
      if (menu.style.display !== 'none' && !menu.contains(e.target) && e.target !== menuBtn) {
        menu.style.display = 'none';
      }
    });
    
    // Handle link clicks in content
    document.getElementById('browser-content').addEventListener('click', (e) => {
      const link = e.target.closest('a');
      if (link && link.href) {
        e.preventDefault();
        const url = link.getAttribute('href');
        if (url && !url.startsWith('javascript:')) {
          document.getElementById('browser-url').value = url;
          this.navigate();
        }
      }
    });
  }
  
  showStartPage() {
    const content = document.getElementById('browser-content');
    content.innerHTML = `
      <div class="browser-start-page">
        <h2>🔒 Private Browser</h2>
        <p>Browse the web through Familiar. Your IP stays hidden.</p>
        <div class="quick-links">
          <div class="quick-link" data-url="https://duckduckgo.com">🔍 DuckDuckGo</div>
          <div class="quick-link" data-url="https://wikipedia.org">📚 Wikipedia</div>
          <div class="quick-link" data-url="https://news.ycombinator.com">📰 Hacker News</div>
          <div class="quick-link" data-url="https://reddit.com">💬 Reddit</div>
        </div>
      </div>
    `;
    
    // Bind quick links
    content.querySelectorAll('.quick-link').forEach(link => {
      link.addEventListener('click', () => {
        document.getElementById('browser-url').value = link.dataset.url;
        this.navigate();
      });
    });
  }
  
  async navigate() {
    let url = document.getElementById('browser-url').value.trim();
    
    if (!url) return;
    
    // Add protocol if missing
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      // Check if it looks like a URL
      if (url.includes('.') && !url.includes(' ')) {
        url = 'https://' + url;
      } else {
        // Treat as search
        url = `https://duckduckgo.com/?q=${encodeURIComponent(url)}`;
      }
    }
    
    document.getElementById('browser-url').value = url;
    
    // Show loading
    this.showLoading();
    this.setStatus('Loading...');
    
    try {
      // Fetch through proxy
      const result = await this.api.request('/api/browser/browse', {
        method: 'POST',
        body: JSON.stringify({
          url: url,
          reader_mode: this.settings.readerMode,
          summarize: this.settings.autoSummarize,
        }),
      });
      
      if (result.error) {
        this.showError(result.error);
        return;
      }
      
      // Store result
      this.currentResult = result;
      
      // Add to history
      if (this.historyIndex < this.history.length - 1) {
        this.history = this.history.slice(0, this.historyIndex + 1);
      }
      this.history.push(result);
      this.historyIndex = this.history.length - 1;
      
      // Update UI
      this.displayResult(result);
      this.updateNavButtons();
      this.updateSecurityIndicator(result);
      this.updateBlockedCount(result.blocked);
      this.setStatus(`Loaded in ${result.load_time_ms}ms`);
      
      // Update URL bar with final URL
      document.getElementById('browser-url').value = result.final_url;
      
    } catch (error) {
      this.showError(error.message);
    }
  }
  
  displayResult(result) {
    const content = document.getElementById('browser-content');

    if (this.settings.readerMode && result.reader_html) {
      // reader_html is server-sanitized; render in sandboxed iframe for safety
      const iframe = document.createElement('iframe');
      iframe.sandbox = 'allow-same-origin';
      iframe.srcdoc = result.reader_html;
      iframe.style.cssText = 'width:100%;border:none;min-height:80vh;';
      content.innerHTML = '';
      content.appendChild(iframe);
      content.classList.add('reader-mode');
    } else {
      // Render server-provided HTML in sandboxed iframe
      const iframe = document.createElement('iframe');
      iframe.sandbox = 'allow-same-origin';
      iframe.srcdoc = result.content_html || '';
      iframe.style.cssText = 'width:100%;border:none;min-height:80vh;';
      content.innerHTML = '';
      content.appendChild(iframe);
      content.classList.remove('reader-mode');
    }
    
    // Update AI summary if available
    if (result.summary) {
      document.getElementById('ai-summary').textContent = result.summary;
    }
  }
  
  showLoading() {
    document.getElementById('browser-content').innerHTML = `
      <div class="browser-loading">
        <div class="loading-spinner"></div>
      </div>
    `;
  }
  
  showError(message) {
    const escaped = message.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    document.getElementById('browser-content').innerHTML = `
      <div class="browser-error">
        <h3>Failed to load page</h3>
        <p>${escaped}</p>
      </div>
    `;
    this.setStatus('Error');
  }
  
  setStatus(text) {
    document.getElementById('status-text').textContent = text;
  }
  
  updateSecurityIndicator(result) {
    const indicator = document.getElementById('browser-security');
    
    if (result.final_url.startsWith('https://')) {
      indicator.textContent = '🔒';
      indicator.className = 'browser-security secure';
      indicator.title = 'Secure connection + proxied through Familiar';
    } else {
      indicator.textContent = '⚠️';
      indicator.className = 'browser-security warning';
      indicator.title = 'Insecure connection (proxied through Familiar)';
    }
  }
  
  updateBlockedCount(blocked) {
    const el = document.getElementById('status-blocked');
    
    const total = (blocked.ads || 0) + (blocked.trackers || 0) + (blocked.scripts || 0);
    
    if (total > 0) {
      el.textContent = `🛡️ Blocked: ${total} (${blocked.ads || 0} ads, ${blocked.trackers || 0} trackers)`;
    } else {
      el.textContent = '';
    }
  }
  
  updateNavButtons() {
    document.getElementById('browser-back').disabled = this.historyIndex <= 0;
    document.getElementById('browser-forward').disabled = this.historyIndex >= this.history.length - 1;
  }
  
  goBack() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      const result = this.history[this.historyIndex];
      document.getElementById('browser-url').value = result.final_url;
      this.currentResult = result;
      this.displayResult(result);
      this.updateNavButtons();
    }
  }
  
  goForward() {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      const result = this.history[this.historyIndex];
      document.getElementById('browser-url').value = result.final_url;
      this.currentResult = result;
      this.displayResult(result);
      this.updateNavButtons();
    }
  }
  
  refresh() {
    this.navigate();
  }
  
  toggleReaderMode() {
    this.settings.readerMode = !this.settings.readerMode;
    
    const btn = document.getElementById('browser-reader');
    btn.classList.toggle('active', this.settings.readerMode);
    
    if (this.currentResult) {
      this.displayResult(this.currentResult);
    }
  }
  
  toggleAIPanel() {
    const panel = document.getElementById('browser-ai-panel');
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    
    document.getElementById('browser-ai').classList.toggle('active', panel.style.display !== 'none');
  }
  
  async askAI() {
    const question = document.getElementById('ai-question').value.trim();
    if (!question || !this.currentResult) return;
    
    const responseEl = document.getElementById('ai-response');
    responseEl.textContent = 'Thinking...';
    
    try {
      const result = await this.api.request('/api/browser/ask', {
        method: 'POST',
        body: JSON.stringify({
          question: question,
          url: this.currentResult.final_url,
        }),
      });
      
      responseEl.textContent = result.answer || result.error || 'No response';
    } catch (error) {
      responseEl.textContent = `Error: ${error.message}`;
    }
  }
  
  async savePage() {
    if (!this.currentResult) return;
    
    try {
      const result = await this.api.request('/api/browser/save', {
        method: 'POST',
        body: JSON.stringify({
          url: this.currentResult.final_url,
        }),
      });
      
      if (result.archive_id) {
        this.setStatus(`Saved! ID: ${result.archive_id.slice(0, 8)}...`);
      }
    } catch (error) {
      this.setStatus(`Save failed: ${error.message}`);
    }
  }
  
  toggleMenu() {
    const menu = document.getElementById('browser-menu-panel');
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
  }
  
  async showHistory() {
    this.toggleMenu();
    // Show history in content area
    const content = document.getElementById('browser-content');
    
    const esc = s => (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const historyHtml = this.history.map((item, i) => `
      <div class="history-item" data-index="${i}">
        <strong>${esc(item.title)}</strong><br>
        <small>${esc(item.final_url)}</small>
      </div>
    `).reverse().join('');
    
    content.innerHTML = `
      <h2>📜 History</h2>
      <div class="history-list">${historyHtml || '<p>No history yet</p>'}</div>
    `;
    
    // Bind click handlers
    content.querySelectorAll('.history-item').forEach(item => {
      item.addEventListener('click', () => {
        this.historyIndex = parseInt(item.dataset.index);
        const result = this.history[this.historyIndex];
        document.getElementById('browser-url').value = result.final_url;
        this.currentResult = result;
        this.displayResult(result);
        this.updateNavButtons();
      });
    });
  }
  
  async showArchive() {
    this.toggleMenu();
    this.showLoading();
    
    try {
      const result = await this.api.request('/api/browser/archive');
      
      const content = document.getElementById('browser-content');
      
      if (!result.pages || result.pages.length === 0) {
        content.innerHTML = '<h2>📁 Saved Pages</h2><p>No saved pages yet</p>';
        return;
      }
      
      const esc = s => (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      const pagesHtml = result.pages.map(page => `
        <div class="archive-item" data-id="${esc(page.id)}">
          <strong>${esc(page.title)}</strong><br>
          <small>${esc(page.url)}</small><br>
          <small>${esc(page.timestamp)}</small>
        </div>
      `).join('');
      
      content.innerHTML = `
        <h2>📁 Saved Pages</h2>
        <div class="archive-list">${pagesHtml}</div>
      `;
      
      // Bind click handlers
      content.querySelectorAll('.archive-item').forEach(item => {
        item.addEventListener('click', async () => {
          const page = await this.api.request(`/api/browser/archive/${item.dataset.id}`);
          if (page) {
            this.currentResult = page;
            document.getElementById('browser-url').value = page.url;
            this.displayResult(page);
          }
        });
      });
      
    } catch (error) {
      this.showError(error.message);
    }
  }
  
  showSettings() {
    this.toggleMenu();
    const content = document.getElementById('browser-content');
    
    content.innerHTML = `
      <h2>⚙️ Privacy Settings</h2>
      <div class="settings-list">
        <div class="setting-item">
          <label>
            <input type="radio" name="privacy" value="standard" ${this.settings.privacyMode === 'standard' ? 'checked' : ''}>
            <strong>Standard</strong> - Block ads and trackers
          </label>
        </div>
        <div class="setting-item">
          <label>
            <input type="radio" name="privacy" value="strict" ${this.settings.privacyMode === 'strict' ? 'checked' : ''}>
            <strong>Strict</strong> - Also block external scripts
          </label>
        </div>
        <div class="setting-item">
          <label>
            <input type="radio" name="privacy" value="paranoid" ${this.settings.privacyMode === 'paranoid' ? 'checked' : ''}>
            <strong>Paranoid</strong> - Block everything, route through Tor
          </label>
        </div>
        <hr>
        <div class="setting-item">
          <label>
            <input type="checkbox" id="setting-reader" ${this.settings.readerMode ? 'checked' : ''}>
            Default to Reader Mode
          </label>
        </div>
        <div class="setting-item">
          <label>
            <input type="checkbox" id="setting-summarize" ${this.settings.autoSummarize ? 'checked' : ''}>
            Auto-summarize pages
          </label>
        </div>
      </div>
    `;
    
    // Bind change handlers
    content.querySelectorAll('input[name="privacy"]').forEach(input => {
      input.addEventListener('change', () => {
        this.settings.privacyMode = input.value;
      });
    });
    
    document.getElementById('setting-reader').addEventListener('change', (e) => {
      this.settings.readerMode = e.target.checked;
    });
    
    document.getElementById('setting-summarize').addEventListener('change', (e) => {
      this.settings.autoSummarize = e.target.checked;
    });
  }
  
  async extractData() {
    this.toggleMenu();
    
    if (!this.currentResult) {
      this.setStatus('No page loaded');
      return;
    }
    
    try {
      const result = await this.api.request('/api/browser/extract', {
        method: 'POST',
        body: JSON.stringify({
          url: this.currentResult.final_url,
          data_type: 'auto',
        }),
      });
      
      const content = document.getElementById('browser-content');
      const escJson = JSON.stringify(result, null, 2).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      content.innerHTML = `
        <h2>📊 Extracted Data</h2>
        <pre>${escJson}</pre>
      `;
      
    } catch (error) {
      this.showError(error.message);
    }
  }
}

// Export for use
if (typeof module !== 'undefined') {
  module.exports = { FamiliarBrowser };
}
