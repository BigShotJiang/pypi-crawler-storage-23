/**
 * Familiar - Self-hosted AI Agent
 * Copyright (c) 2026 George Scott Foley
 * 
 * Licensed under the MIT License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://familiar.ai/license
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * For commercial licensing, contact: licensing@familiar.ai
 */

/**
 * Familiar PWA Main Application
 */

class FamiliarApp {
  constructor() {
    this.api = new FamiliarAPI();
    this.db = new FamiliarDB();
    this.currentConversation = null;
    this.isOnline = navigator.onLine;
    this.isTyping = false;
    
    // Touch gesture state
    this.touch = {
      startX: 0,
      startY: 0,
      startTime: 0,
      isDragging: false,
      isScrolling: null,
    };
    
    this.init();
  }

  // ═══════════════════════════════════════════════════════════════
  // Initialization
  // ═══════════════════════════════════════════════════════════════

  async init() {
    // Initialize database
    await this.db.open();
    
    // Setup event listeners
    this.setupEventListeners();
    
    // Setup API event handlers
    this.setupAPIHandlers();
    
    // Check online status
    this.updateOnlineStatus();
    
    // Connect WebSocket if online
    if (this.isOnline) {
      this.api.connectWebSocket();
    }
    
    // Register service worker
    this.registerServiceWorker();
    
    // Setup install prompt
    this.setupInstallPrompt();
    
    // Load initial state
    await this.loadInitialState();
    
    console.log('Familiar PWA initialized');
  }

  setupEventListeners() {
    // Online/offline events
    window.addEventListener('online', () => this.handleOnline());
    window.addEventListener('offline', () => this.handleOffline());
    
    // ═══════════════════════════════════════════════════════════════
    // Touch Gestures
    // ═══════════════════════════════════════════════════════════════
    
    // Swipe to open/close sidebar
    document.addEventListener('touchstart', (e) => this.handleTouchStart(e), { passive: true });
    document.addEventListener('touchmove', (e) => this.handleTouchMove(e), { passive: false });
    document.addEventListener('touchend', (e) => this.handleTouchEnd(e), { passive: true });
    
    // Pull to refresh on messages
    const messagesEl = document.getElementById('messages');
    if (messagesEl) {
      messagesEl.addEventListener('touchstart', (e) => this.handlePullStart(e), { passive: true });
      messagesEl.addEventListener('touchmove', (e) => this.handlePullMove(e), { passive: false });
      messagesEl.addEventListener('touchend', (e) => this.handlePullEnd(e), { passive: true });
    }
    
    // Long press on messages for context menu
    document.addEventListener('contextmenu', (e) => {
      const message = e.target.closest('.message');
      if (message) {
        e.preventDefault();
        this.showMessageContextMenu(message, e);
      }
    });
    
    // Haptic feedback for buttons (if supported)
    document.querySelectorAll('.btn, .icon-btn, .quick-action').forEach(btn => {
      btn.addEventListener('touchstart', () => this.hapticFeedback('light'));
    });
    
    // ═══════════════════════════════════════════════════════════════
    // Standard Event Listeners
    // ═══════════════════════════════════════════════════════════════
    
    // Input handling
    const input = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    
    input?.addEventListener('input', (e) => this.handleInputChange(e));
    input?.addEventListener('keydown', (e) => this.handleKeydown(e));
    sendBtn?.addEventListener('click', () => this.sendMessage());
    
    // Menu button
    document.getElementById('menu-btn')?.addEventListener('click', () => this.toggleSidebar());
    
    // Settings button
    document.getElementById('settings-btn')?.addEventListener('click', () => this.showSettings());
    
    // New chat button
    document.getElementById('new-chat-btn')?.addEventListener('click', () => this.newConversation());
    
    // Modal close
    document.querySelectorAll('.close-btn').forEach(btn => {
      btn.addEventListener('click', () => this.closeModal());
    });
    
    // Quick actions
    document.querySelectorAll('.quick-action').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const prompt = e.target.dataset.prompt;
        if (prompt) {
          document.getElementById('message-input').value = prompt;
          document.getElementById('message-input').focus();
        }
      });
    });
    
    // File attachment
    document.getElementById('attach-btn')?.addEventListener('click', () => {
      document.getElementById('file-input')?.click();
    });
    
    document.getElementById('file-input')?.addEventListener('change', (e) => {
      this.handleFileAttachment(e.target.files);
    });
    
    // Sidebar overlay
    document.getElementById('sidebar-overlay')?.addEventListener('click', () => {
      this.closeSidebar();
    });
    
    // Settings toggles
    document.getElementById('theme-select')?.addEventListener('change', (e) => {
      this.setTheme(e.target.value);
    });
    
    document.getElementById('notifications-toggle')?.addEventListener('change', (e) => {
      this.toggleNotifications(e.target.checked);
    });
  }

  setupAPIHandlers() {
    this.api.on('connected', () => {
      this.updateConnectionStatus('connected');
      this.syncQueuedMessages();
    });
    
    this.api.on('disconnected', () => {
      this.updateConnectionStatus('disconnected');
    });
    
    this.api.on('response', (data) => {
      this.hideTypingIndicator();
      this.addMessage(data.content, 'assistant', data.id);
      this.currentConversation = data.conversationId;
      
      // Cache the message
      this.db.cacheMessage({
        id: data.id,
        conversationId: data.conversationId,
        content: data.content,
        role: 'assistant',
        timestamp: Date.now(),
      });
    });
    
    this.api.on('typing', () => {
      this.showTypingIndicator();
    });
    
    this.api.on('error', (error) => {
      console.error('API error:', error);
      this.hideTypingIndicator();
      this.showToast('An error occurred. Please try again.', 'error');
    });
  }

  async registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        console.log('Service Worker registered:', registration.scope);
        
        // Listen for updates
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              this.showUpdateNotification();
            }
          });
        });
      } catch (error) {
        console.error('Service Worker registration failed:', error);
      }
    }
  }

  setupInstallPrompt() {
    let deferredPrompt;
    
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      
      // Show install prompt
      const prompt = document.getElementById('install-prompt');
      if (prompt) {
        prompt.classList.remove('hidden');
      }
    });
    
    document.getElementById('install-btn')?.addEventListener('click', async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        const result = await deferredPrompt.userChoice;
        console.log('Install result:', result.outcome);
        deferredPrompt = null;
      }
      document.getElementById('install-prompt')?.classList.add('hidden');
    });
    
    document.getElementById('dismiss-install')?.addEventListener('click', () => {
      document.getElementById('install-prompt')?.classList.add('hidden');
    });
  }

  async loadInitialState() {
    // Load theme preference
    const theme = await this.db.getSetting('theme', 'system');
    this.setTheme(theme);
    
    // Load cached conversations for sidebar
    const conversations = await this.db.getCachedConversations();
    this.renderConversationsList(conversations);
    
    // Add welcome message
    this.addWelcomeMessage();
  }

  // ═══════════════════════════════════════════════════════════════
  // Online/Offline Handling
  // ═══════════════════════════════════════════════════════════════

  handleOnline() {
    this.isOnline = true;
    this.updateOnlineStatus();
    this.api.connectWebSocket();
    this.syncQueuedMessages();
    this.showToast('Back online', 'success');
  }

  handleOffline() {
    this.isOnline = false;
    this.updateOnlineStatus();
    this.showToast('You\'re offline. Messages will be sent when you reconnect.', 'warning');
  }

  updateOnlineStatus() {
    const indicator = document.getElementById('status-indicator');
    const banner = document.getElementById('offline-banner');
    
    if (this.isOnline) {
      indicator?.classList.remove('offline');
      indicator?.classList.add('online');
      indicator?.setAttribute('title', 'Online');
      banner?.classList.add('hidden');
    } else {
      indicator?.classList.remove('online');
      indicator?.classList.add('offline');
      indicator?.setAttribute('title', 'Offline');
      banner?.classList.remove('hidden');
    }
  }

  updateConnectionStatus(status) {
    const statusEl = document.getElementById('connection-status');
    if (statusEl) {
      statusEl.textContent = status === 'connected' ? 'Connected' : 'Disconnected';
      statusEl.className = status === 'connected' ? 'status-connected' : 'status-disconnected';
    }
  }

  async syncQueuedMessages() {
    const queued = await this.db.getQueuedMessages();
    
    for (const msg of queued) {
      try {
        const sent = this.api.sendChat(msg.content, msg.conversationId);
        if (sent) {
          await this.db.removeFromQueue(msg.id);
          
          // Update UI to remove pending state
          const msgEl = document.querySelector(`[data-message-id="${msg.id}"]`);
          if (msgEl) {
            msgEl.classList.remove('pending');
          }
        }
      } catch (e) {
        console.error('Failed to sync message:', e);
        break;
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // Messaging
  // ═══════════════════════════════════════════════════════════════

  async sendMessage() {
    const input = document.getElementById('message-input');
    const content = input?.value.trim();
    
    if (!content) return;
    
    // Clear input
    input.value = '';
    this.updateSendButton();
    this.autoResizeInput();
    
    // Generate message ID
    const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Add to UI
    this.addMessage(content, 'user', messageId, !this.isOnline);
    
    // Remove welcome message if present
    document.querySelector('.welcome-message')?.remove();
    
    if (this.isOnline && this.api.ws?.readyState === WebSocket.OPEN) {
      // Send via WebSocket
      this.showTypingIndicator();
      this.api.sendChat(content, this.currentConversation);
    } else {
      // Queue for later
      await this.db.queueMessage({
        id: messageId,
        content,
        conversationId: this.currentConversation,
        role: 'user',
      });
      
      // Request background sync
      if ('serviceWorker' in navigator && 'sync' in window.SyncManager) {
        const registration = await navigator.serviceWorker.ready;
        await registration.sync.register('sync-messages');
      }
    }
    
    // Cache the message
    await this.db.cacheMessage({
      id: messageId,
      conversationId: this.currentConversation,
      content,
      role: 'user',
      timestamp: Date.now(),
    });
  }

  addMessage(content, role, id = null, pending = false) {
    const messagesEl = document.getElementById('messages');
    if (!messagesEl) return;
    
    const messageEl = document.createElement('div');
    messageEl.className = `message ${role}${pending ? ' pending' : ''}`;
    if (id) {
      messageEl.dataset.messageId = id;
    }
    
    const bubbleEl = document.createElement('div');
    bubbleEl.className = 'message-bubble';
    bubbleEl.innerHTML = this.formatMessageContent(content);
    
    const timeEl = document.createElement('div');
    timeEl.className = 'message-time';
    timeEl.textContent = this.formatTime(new Date());
    
    messageEl.appendChild(bubbleEl);
    messageEl.appendChild(timeEl);
    
    messagesEl.appendChild(messageEl);
    
    // Scroll to bottom
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  addWelcomeMessage() {
    const messagesEl = document.getElementById('messages');
    if (!messagesEl) return;
    
    // Don't add if there are already messages
    if (messagesEl.querySelector('.message')) return;
    
    const welcome = document.createElement('div');
    welcome.className = 'welcome-message';
    welcome.innerHTML = `
      <div class="welcome-icon">🐍</div>
      <h2>Welcome to Familiar</h2>
      <p>Your self-hosted AI assistant with Signal-grade encryption.</p>
      <div class="quick-actions">
        <button class="quick-action" data-prompt="What's on my calendar today?">
          📅 Calendar
        </button>
        <button class="quick-action" data-prompt="Check my email">
          📧 Email
        </button>
        <button class="quick-action" data-prompt="Show my tasks">
          📋 Tasks
        </button>
        <button class="quick-action" data-prompt="Help me with">
          💡 Help
        </button>
      </div>
    `;
    
    // Add click handlers for quick actions
    welcome.querySelectorAll('.quick-action').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const prompt = e.target.dataset.prompt;
        if (prompt) {
          const input = document.getElementById('message-input');
          input.value = prompt;
          input.focus();
          this.updateSendButton();
        }
      });
    });
    
    messagesEl.appendChild(welcome);
  }

  formatMessageContent(content) {
    // Basic markdown-like formatting
    let formatted = content
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/\*([^*]+)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // Code blocks
    formatted = formatted.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    
    return formatted;
  }

  formatTime(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  showTypingIndicator() {
    if (this.isTyping) return;
    this.isTyping = true;
    
    const messagesEl = document.getElementById('messages');
    const indicator = document.getElementById('typing-indicator');
    
    if (indicator) {
      indicator.classList.remove('hidden');
    }
    
    messagesEl?.scrollTo({ top: messagesEl.scrollHeight, behavior: 'smooth' });
  }

  hideTypingIndicator() {
    this.isTyping = false;
    document.getElementById('typing-indicator')?.classList.add('hidden');
  }

  // ═══════════════════════════════════════════════════════════════
  // Input Handling
  // ═══════════════════════════════════════════════════════════════

  handleInputChange(e) {
    this.updateSendButton();
    this.autoResizeInput();
  }

  handleKeydown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.sendMessage();
    }
  }

  updateSendButton() {
    const input = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    
    if (sendBtn) {
      sendBtn.disabled = !input?.value.trim();
    }
  }

  autoResizeInput() {
    const input = document.getElementById('message-input');
    if (input) {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    }
  }

  handleFileAttachment(files) {
    if (!files || files.length === 0) return;
    
    // For now, just show a message
    this.showToast('File attachments coming soon!', 'info');
    
    // TODO: Implement file upload
  }

  // ═══════════════════════════════════════════════════════════════
  // Sidebar & Navigation
  // ═══════════════════════════════════════════════════════════════

  toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    
    sidebar?.classList.toggle('open');
    
    if (!overlay) {
      const newOverlay = document.createElement('div');
      newOverlay.id = 'sidebar-overlay';
      newOverlay.className = 'sidebar-overlay';
      newOverlay.addEventListener('click', () => this.closeSidebar());
      document.body.appendChild(newOverlay);
    }
    
    document.getElementById('sidebar-overlay')?.classList.toggle('visible');
  }

  closeSidebar() {
    document.getElementById('sidebar')?.classList.remove('open');
    document.getElementById('sidebar-overlay')?.classList.remove('visible');
  }

  renderConversationsList(conversations) {
    const list = document.getElementById('conversations-list');
    if (!list) return;
    
    list.innerHTML = '';
    
    if (conversations.length === 0) {
      list.innerHTML = '<div class="empty-state">No conversations yet</div>';
      return;
    }
    
    conversations.forEach(conv => {
      const item = document.createElement('div');
      item.className = 'conversation-item';
      if (conv.id === this.currentConversation) {
        item.classList.add('active');
      }
      
      const escTitle = (conv.title || 'New Conversation').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      const escPreview = (conv.preview || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      item.innerHTML = `
        <div class="conversation-title">${escTitle}</div>
        <div class="conversation-preview">${escPreview}</div>
        <div class="conversation-time">${this.formatRelativeTime(conv.updatedAt)}</div>
      `;
      
      item.addEventListener('click', () => this.loadConversation(conv.id));
      
      list.appendChild(item);
    });
  }

  formatRelativeTime(timestamp) {
    if (!timestamp) return '';
    
    const now = Date.now();
    const diff = now - timestamp;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    
    return new Date(timestamp).toLocaleDateString();
  }

  async loadConversation(conversationId) {
    this.currentConversation = conversationId;
    this.closeSidebar();
    
    // Clear messages
    const messagesEl = document.getElementById('messages');
    if (messagesEl) {
      messagesEl.innerHTML = '';
    }
    
    // Load cached messages
    const messages = await this.db.getCachedMessages(conversationId);
    messages.forEach(msg => {
      this.addMessage(msg.content, msg.role, msg.id);
    });
    
    // Update sidebar
    document.querySelectorAll('.conversation-item').forEach(item => {
      item.classList.remove('active');
    });
  }

  newConversation() {
    this.currentConversation = null;
    this.closeSidebar();
    
    const messagesEl = document.getElementById('messages');
    if (messagesEl) {
      messagesEl.innerHTML = '';
    }
    
    this.addWelcomeMessage();
  }

  // ═══════════════════════════════════════════════════════════════
  // Settings & Modals
  // ═══════════════════════════════════════════════════════════════

  showSettings() {
    document.getElementById('settings-modal')?.classList.remove('hidden');
  }

  closeModal() {
    document.querySelectorAll('.modal').forEach(modal => {
      modal.classList.add('hidden');
    });
  }

  async setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    await this.db.setSetting('theme', theme);
    
    const select = document.getElementById('theme-select');
    if (select) {
      select.value = theme;
    }
  }

  async toggleNotifications(enabled) {
    if (enabled) {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        document.getElementById('notifications-toggle').checked = false;
        this.showToast('Notification permission denied', 'error');
        return;
      }
      
      await this.db.setSetting('notifications', true);
      this.showToast('Notifications enabled', 'success');
    } else {
      await this.db.setSetting('notifications', false);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // Touch Gestures
  // ═══════════════════════════════════════════════════════════════

  handleTouchStart(e) {
    if (e.touches.length !== 1) return;
    
    const touch = e.touches[0];
    this.touch.startX = touch.clientX;
    this.touch.startY = touch.clientY;
    this.touch.startTime = Date.now();
    this.touch.isDragging = false;
    this.touch.isScrolling = null;
  }

  handleTouchMove(e) {
    if (e.touches.length !== 1) return;
    
    const touch = e.touches[0];
    const deltaX = touch.clientX - this.touch.startX;
    const deltaY = touch.clientY - this.touch.startY;
    
    // Determine if scrolling or swiping (only once per gesture)
    if (this.touch.isScrolling === null) {
      this.touch.isScrolling = Math.abs(deltaY) > Math.abs(deltaX);
    }
    
    // If scrolling vertically, don't interfere
    if (this.touch.isScrolling) return;
    
    const sidebar = document.getElementById('sidebar');
    const sidebarOpen = sidebar?.classList.contains('open');
    
    // Swipe from left edge to open sidebar
    if (!sidebarOpen && this.touch.startX < 30 && deltaX > 0) {
      e.preventDefault();
      this.touch.isDragging = true;
      const progress = Math.min(deltaX / 280, 1);
      sidebar.style.transform = `translateX(${-100 + (progress * 100)}%)`;
      sidebar.style.transition = 'none';
    }
    
    // Swipe left to close sidebar
    if (sidebarOpen && deltaX < 0) {
      e.preventDefault();
      this.touch.isDragging = true;
      const progress = Math.max(deltaX / 280, -1);
      sidebar.style.transform = `translateX(${progress * 100}%)`;
      sidebar.style.transition = 'none';
    }
  }

  handleTouchEnd(e) {
    const sidebar = document.getElementById('sidebar');
    
    if (!this.touch.isDragging) {
      // Check for tap vs swipe
      const duration = Date.now() - this.touch.startTime;
      const touch = e.changedTouches[0];
      const deltaX = touch.clientX - this.touch.startX;
      
      // Quick swipe from edge
      if (duration < 300 && this.touch.startX < 30 && deltaX > 50) {
        this.toggleSidebar();
        this.hapticFeedback('medium');
      }
      return;
    }
    
    // Finish drag animation
    sidebar.style.transition = '';
    
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - this.touch.startX;
    const velocity = deltaX / (Date.now() - this.touch.startTime);
    
    const sidebarOpen = sidebar?.classList.contains('open');
    
    // Determine if should open or close based on position and velocity
    if (!sidebarOpen) {
      if (deltaX > 140 || velocity > 0.5) {
        sidebar.classList.add('open');
        document.getElementById('sidebar-overlay')?.classList.add('visible');
        this.hapticFeedback('medium');
      }
    } else {
      if (deltaX < -140 || velocity < -0.5) {
        sidebar.classList.remove('open');
        document.getElementById('sidebar-overlay')?.classList.remove('visible');
        this.hapticFeedback('light');
      }
    }
    
    sidebar.style.transform = '';
    this.touch.isDragging = false;
  }

  // Pull to refresh
  handlePullStart(e) {
    const messagesEl = document.getElementById('messages');
    if (messagesEl.scrollTop === 0) {
      this.touch.pullStartY = e.touches[0].clientY;
      this.touch.isPulling = false;
    }
  }

  handlePullMove(e) {
    if (this.touch.pullStartY === undefined) return;
    
    const messagesEl = document.getElementById('messages');
    if (messagesEl.scrollTop > 0) {
      this.touch.pullStartY = undefined;
      return;
    }
    
    const deltaY = e.touches[0].clientY - this.touch.pullStartY;
    
    if (deltaY > 0) {
      e.preventDefault();
      this.touch.isPulling = true;
      
      // Show pull indicator
      const pullProgress = Math.min(deltaY / 100, 1);
      this.showPullIndicator(pullProgress);
    }
  }

  handlePullEnd(e) {
    if (!this.touch.isPulling) return;
    
    const deltaY = e.changedTouches[0].clientY - this.touch.pullStartY;
    
    if (deltaY > 80) {
      this.hapticFeedback('medium');
      this.refreshMessages();
    }
    
    this.hidePullIndicator();
    this.touch.pullStartY = undefined;
    this.touch.isPulling = false;
  }

  showPullIndicator(progress) {
    let indicator = document.getElementById('pull-indicator');
    if (!indicator) {
      indicator = document.createElement('div');
      indicator.id = 'pull-indicator';
      indicator.innerHTML = '↓ Pull to refresh';
      indicator.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        text-align: center;
        padding: 12px;
        color: var(--color-primary);
        font-size: 14px;
        transform: translateY(-100%);
        transition: transform 0.2s;
        z-index: 10;
      `;
      document.getElementById('messages')?.prepend(indicator);
    }
    
    indicator.style.transform = `translateY(${progress * 100 - 100}%)`;
    indicator.style.opacity = progress;
    
    if (progress >= 1) {
      indicator.innerHTML = '↑ Release to refresh';
    } else {
      indicator.innerHTML = '↓ Pull to refresh';
    }
  }

  hidePullIndicator() {
    const indicator = document.getElementById('pull-indicator');
    if (indicator) {
      indicator.style.transform = 'translateY(-100%)';
      indicator.style.opacity = '0';
    }
  }

  async refreshMessages() {
    this.showToast('Refreshing...', 'info');
    
    if (this.currentConversation) {
      // Reload current conversation
      await this.loadConversation(this.currentConversation);
    }
    
    // Sync any queued messages
    if (this.isOnline) {
      await this.syncQueuedMessages();
    }
  }

  // Long press context menu for messages
  showMessageContextMenu(messageEl, event) {
    this.hapticFeedback('medium');
    
    // Remove any existing menu
    document.getElementById('context-menu')?.remove();
    
    const menu = document.createElement('div');
    menu.id = 'context-menu';
    menu.style.cssText = `
      position: fixed;
      top: ${event.clientY}px;
      left: ${event.clientX}px;
      background: var(--color-bg-secondary);
      border: 1px solid var(--color-border);
      border-radius: 12px;
      padding: 8px 0;
      min-width: 160px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      z-index: 1000;
      animation: fadeIn 0.15s ease;
    `;
    
    const isUserMessage = messageEl.classList.contains('user');
    const messageText = messageEl.querySelector('.message-bubble')?.textContent || '';
    
    const actions = [
      { icon: '📋', label: 'Copy', action: () => this.copyToClipboard(messageText) },
      { icon: '🔄', label: 'Retry', action: () => this.retryMessage(messageEl), show: isUserMessage },
      { icon: '🗑️', label: 'Delete', action: () => this.deleteMessage(messageEl) },
    ];
    
    actions.filter(a => a.show !== false).forEach(action => {
      const item = document.createElement('button');
      item.className = 'context-menu-item';
      item.innerHTML = `${action.icon} ${action.label}`;
      item.style.cssText = `
        display: flex;
        align-items: center;
        gap: 8px;
        width: 100%;
        padding: 10px 16px;
        border: none;
        background: transparent;
        color: var(--color-text);
        font-size: 14px;
        text-align: left;
        cursor: pointer;
      `;
      item.addEventListener('click', () => {
        action.action();
        menu.remove();
      });
      item.addEventListener('touchstart', () => this.hapticFeedback('light'));
      menu.appendChild(item);
    });
    
    document.body.appendChild(menu);
    
    // Close on tap outside
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('touchstart', closeMenu);
        document.removeEventListener('click', closeMenu);
      }
    };
    
    setTimeout(() => {
      document.addEventListener('touchstart', closeMenu);
      document.addEventListener('click', closeMenu);
    }, 100);
  }

  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      this.hapticFeedback('light');
      this.showToast('Copied to clipboard', 'success');
    } catch (e) {
      this.showToast('Failed to copy', 'error');
    }
  }

  retryMessage(messageEl) {
    const text = messageEl.querySelector('.message-bubble')?.textContent;
    if (text) {
      messageEl.remove();
      document.getElementById('message-input').value = text;
      this.sendMessage();
    }
  }

  deleteMessage(messageEl) {
    this.hapticFeedback('medium');
    messageEl.style.animation = 'fadeOut 0.2s ease forwards';
    setTimeout(() => messageEl.remove(), 200);
  }

  // Haptic feedback (if supported)
  hapticFeedback(style = 'light') {
    if ('vibrate' in navigator) {
      const patterns = {
        light: [10],
        medium: [20],
        heavy: [30],
        success: [10, 50, 10],
        error: [50, 30, 50],
      };
      navigator.vibrate(patterns[style] || patterns.light);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // Notifications & Toasts
  // ═══════════════════════════════════════════════════════════════

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container') || this.createToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = `
      position: fixed;
      bottom: 80px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
      display: flex;
      flex-direction: column;
      gap: 8px;
    `;
    document.body.appendChild(container);
    return container;
  }

  showUpdateNotification() {
    this.showToast('New version available. Refresh to update.', 'info');
  }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.familiarApp = new FamiliarApp();
});
