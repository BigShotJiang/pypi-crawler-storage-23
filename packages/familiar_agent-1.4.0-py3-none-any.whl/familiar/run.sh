#!/usr/bin/env bash
# Familiar v1.3.9 — Quick Start
# Just run: ./run.sh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PARENT_DIR="$(dirname "$SCRIPT_DIR")"
FOLDER_NAME="$(basename "$SCRIPT_DIR")"
cd "$SCRIPT_DIR"

VERSION="1.3.9"
echo "🤝 Familiar v${VERSION}"
echo "========================"
echo "   Self-Hosted AI Companion"
echo ""

# ── Find Python ──────────────────────────────────────────────
PYTHON=""
for p in python3.12 python3.11 python3.10 python3.9 python3; do
    if command -v "$p" &>/dev/null; then
        ver=$($p -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null)
        major=$(echo "$ver" | cut -d. -f1)
        minor=$(echo "$ver" | cut -d. -f2)
        if [ "$major" -ge 3 ] && [ "$minor" -ge 10 ]; then
            PYTHON="$p"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "❌ Python 3.10+ not found"
    echo "   macOS:     brew install python@3.12"
    echo "   Ubuntu:    sudo apt install python3"
    echo "   Pi:        sudo apt install python3"
    exit 1
fi
echo "✓ Python: $($PYTHON --version 2>&1)"

# ── Activate venv if it exists ────────────────────────────────
if [ -d ".venv" ]; then
    source .venv/bin/activate
    echo "✓ Virtual environment active"
elif [ -d "venv" ]; then
    source venv/bin/activate
    echo "✓ Virtual environment active"
fi

# ── Load .env (project dir first, then ~/.familiar/) ──────────
# Loaded BEFORE dep check so tokens are available for extras detection.
if [ -f ".env" ]; then
    set -a
    source .env 2>/dev/null || true
    set +a
    echo "✓ Loaded .env"
elif [ -f "$HOME/.familiar/.env" ]; then
    set -a
    source "$HOME/.familiar/.env" 2>/dev/null || true
    set +a
    echo "✓ Loaded ~/.familiar/.env"
else
    if [ -f "env.sample" ]; then
        echo "💡 No .env found. Copy the sample:"
        echo "   cp env.sample ~/.familiar/.env && nano ~/.familiar/.env"
    fi
fi

# ── Install deps if needed ────────────────────────────────────
# Only gate on true core dep (pyyaml). Channel/provider packages are extras.
DEPS_OK=true
$PYTHON -c "import yaml" 2>/dev/null || DEPS_OK=false
if [ "$DEPS_OK" = "false" ]; then
    echo ""
    echo "Installing dependencies..."

    # Build extras list based on environment tokens
    EXTRAS=""
    [ -n "$TELEGRAM_BOT_TOKEN" ]                                      && EXTRAS="${EXTRAS:+$EXTRAS,}telegram"
    [ -n "$DISCORD_BOT_TOKEN" ]                                       && EXTRAS="${EXTRAS:+$EXTRAS,}discord"
    [ -n "$ANTHROPIC_API_KEY" ] || [ -n "$OPENAI_API_KEY" ]           && EXTRAS="${EXTRAS:+$EXTRAS,}llm"

    if [ -n "$EXTRAS" ]; then
        INSTALL_SPEC="-e \"$PARENT_DIR[$EXTRAS]\""
    else
        INSTALL_SPEC="-e \"$PARENT_DIR\""
    fi

    if [ -d ".venv" ] || [ -d "venv" ]; then
        eval pip install $INSTALL_SPEC -q 2>/dev/null || eval pip install $INSTALL_SPEC --break-system-packages -q
    else
        echo "Creating virtual environment..."
        $PYTHON -m venv .venv
        source .venv/bin/activate
        pip install --upgrade pip -q
        eval pip install $INSTALL_SPEC -q 2>&1 | grep -i "error\|failed" || true
    fi

    # ── Post-install verification: retry critical packages individually ──
    RETRY_PKGS="pyyaml"
    [ -n "$TELEGRAM_BOT_TOKEN" ] && RETRY_PKGS="$RETRY_PKGS python-telegram-bot"
    for pkg in $RETRY_PKGS; do
        mod_name=$(echo "$pkg" | sed 's/python-telegram-bot/telegram/' | sed 's/pyyaml/yaml/')
        if ! $PYTHON -c "import $mod_name" 2>/dev/null; then
            echo "   Retrying: pip install $pkg"
            pip install "$pkg" -q 2>/dev/null || pip install "$pkg" --break-system-packages -q 2>/dev/null || true
        fi
    done
    echo "✓ Dependencies installed"
fi

# ── Detect LLM provider ──────────────────────────────────────
PROVIDER=""
if [ -n "$DEFAULT_PROVIDER" ]; then
    PROVIDER="$DEFAULT_PROVIDER"
elif [ -n "$LLM_DEFAULT_PROVIDER" ]; then
    PROVIDER="$LLM_DEFAULT_PROVIDER"
elif [ -n "$ANTHROPIC_API_KEY" ]; then
    PROVIDER="anthropic"
elif [ -n "$OPENAI_API_KEY" ]; then
    PROVIDER="openai"
elif command -v ollama &>/dev/null; then
    PROVIDER="ollama"
fi

if [ -n "$PROVIDER" ]; then
    echo "✓ Provider: $PROVIDER"
fi

# ── Detect Ollama models ──────────────────────────────────────
if [ "$PROVIDER" = "ollama" ] || ([ -z "$PROVIDER" ] && command -v ollama &>/dev/null); then
    INSTALLED_MODELS=$(ollama list 2>/dev/null | tail -n +2)
    MODEL_COUNT=$(echo "$INSTALLED_MODELS" | grep -c . 2>/dev/null || echo "0")
    
    if [ "$MODEL_COUNT" -eq 0 ]; then
        echo ""
        echo "Ollama detected but no models downloaded."
        if [ -f "scripts/model_setup.sh" ]; then
            bash scripts/model_setup.sh
        fi
    else
        echo "✓ Ollama: $MODEL_COUNT model(s) installed:"
        echo "$INSTALLED_MODELS" | awk '{printf "    %-24s %s\n", $1, $2}'
        echo ""
        
        # Offer to manage models (skip if FAMILIAR_SKIP_MODEL_SETUP=1)
        if [ "${FAMILIAR_SKIP_MODEL_SETUP:-0}" != "1" ] && [ -t 0 ]; then
            read -p "  Manage Ollama models? [y/N] " -t 10 MANAGE_MODELS 2>/dev/null || MANAGE_MODELS=""
            if [[ "$MANAGE_MODELS" =~ ^[Yy] ]]; then
                if [ -f "scripts/model_setup.sh" ]; then
                    bash scripts/model_setup.sh
                fi
            fi
        fi
    fi
fi

if [ -z "$PROVIDER" ]; then
    echo ""
    echo "⚠ No LLM provider detected."
    echo "  Set ANTHROPIC_API_KEY or OPENAI_API_KEY in .env"
    echo "  Or install Ollama: https://ollama.ai"
    echo ""
fi

# ── Determine channel ─────────────────────────────────────────
CHANNEL_FLAG=""
if [ -n "$TELEGRAM_BOT_TOKEN" ]; then
    CHANNEL_FLAG="--telegram"
    echo "✓ Channel: Telegram"
elif [ -n "$DISCORD_BOT_TOKEN" ]; then
    CHANNEL_FLAG="--discord"
    echo "✓ Channel: Discord"
else
    echo "✓ Channel: CLI"
fi

# ── Start Familiar ────────────────────────────────────────────
echo ""
echo "Starting Familiar..."
echo "─────────────────────"
cd "$PARENT_DIR"
exec $PYTHON -m "$FOLDER_NAME" $CHANNEL_FLAG "$@"
