# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Web Search Skill

Search the internet, retrieve web pages, extract content.
Enables grant research, organization lookup, regulatory checks.

Search backends (in order of preference):
  1. Self-hosted SearXNG (HIPAA-safe, configurable)
  2. DuckDuckGo HTML lite (no API key, queries leave network)

Dependencies:
  - beautifulsoup4 (HTML content extraction) -- optional but recommended
  - urllib (HTTP) -- stdlib, always available
"""

import json
import logging
import re
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    from bs4 import BeautifulSoup

    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False
    logger.info(
        "beautifulsoup4 not installed. HTML extraction will use basic parser. "
        "Install with: pip install beautifulsoup4"
    )

_CONFIG = {
    "backend": "duckduckgo",
    "searxng_url": "http://localhost:8888",
    "max_results": 8,
    "timeout": 15,
    "user_agent": "Familiar/2.6.3 (AI Agent; +https://familiar.ai)",
}


def _load_config():
    config_file = Path.home() / ".familiar" / "config.yaml"
    if config_file.exists():
        try:
            import yaml

            with open(config_file) as f:
                data = yaml.safe_load(f) or {}
            search_conf = data.get("websearch", {})
            _CONFIG.update({k: v for k, v in search_conf.items() if k in _CONFIG})
        except Exception:
            pass


def _http_get(url: str, timeout: int = None) -> str:
    # SSRF protection: block requests to private/internal networks
    from familiar.core.sanitization import check_ssrf

    is_safe, ssrf_msg = check_ssrf(url)
    if not is_safe:
        raise ValueError(f"Blocked by SSRF protection: {ssrf_msg}")

    timeout = timeout or _CONFIG["timeout"]
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": _CONFIG["user_agent"],
            "Accept": "text/html,application/xhtml+xml,application/json",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        charset = resp.headers.get_content_charset() or "utf-8"
        return resp.read().decode(charset, errors="replace")


# --- DuckDuckGo HTML Lite Backend ---


class _DDGHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.results = []
        self._current = None
        self._in_result_link = False
        self._in_snippet = False
        self._capture = ""

    def handle_starttag(self, tag, attrs):
        ad = dict(attrs)
        if tag == "a" and ad.get("class") == "result__a":
            self._in_result_link = True
            href = ad.get("href", "")
            if "uddg=" in href:
                parsed = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
                href = parsed.get("uddg", [href])[0]
            self._current = {"title": "", "url": href, "snippet": ""}
            self._capture = ""
        elif tag == "td" and ad.get("class") == "result__snippet":
            self._in_snippet = True
            self._capture = ""

    def handle_endtag(self, tag):
        if tag == "a" and self._in_result_link:
            self._in_result_link = False
            if self._current:
                self._current["title"] = self._capture.strip()
            self._capture = ""
        elif tag == "td" and self._in_snippet:
            self._in_snippet = False
            if self._current:
                self._current["snippet"] = self._capture.strip()
                self.results.append(self._current)
                self._current = None
            self._capture = ""

    def handle_data(self, data):
        if self._in_result_link or self._in_snippet:
            self._capture += data


def _search_duckduckgo(query: str, max_results: int = 8) -> list:
    encoded = urllib.parse.urlencode({"q": query})
    url = f"https://html.duckduckgo.com/html/?{encoded}"
    try:
        html = _http_get(url)
    except Exception as e:
        return [{"title": "Search Error", "url": "", "snippet": str(e)}]
    parser = _DDGHTMLParser()
    parser.feed(html)
    return parser.results[:max_results]


# --- SearXNG Backend ---


def _search_searxng(query: str, max_results: int = 8) -> list:
    base_url = _CONFIG["searxng_url"].rstrip("/")
    params = urllib.parse.urlencode(
        {
            "q": query,
            "format": "json",
            "engines": "google,duckduckgo,brave",
        }
    )
    url = f"{base_url}/search?{params}"
    try:
        body = _http_get(url)
        data = json.loads(body)
        return [
            {"title": r.get("title", ""), "url": r.get("url", ""), "snippet": r.get("content", "")}
            for r in data.get("results", [])[:max_results]
        ]
    except Exception as e:
        logger.warning(f"SearXNG search failed: {e}, falling back to DuckDuckGo")
        return _search_duckduckgo(query, max_results)


# --- Content Extraction ---


def _extract_readable_text(html: str, max_chars: int = 8000) -> str:
    if BS4_AVAILABLE:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup.find_all(
            ["script", "style", "nav", "footer", "header", "aside", "iframe", "noscript", "form"]
        ):
            tag.decompose()
        article = soup.find("article") or soup.find("main") or soup.find(role="main")
        if article:
            text = article.get_text(separator="\n", strip=True)
        else:
            body = soup.find("body")
            text = (
                body.get_text(separator="\n", strip=True)
                if body
                else soup.get_text(separator="\n", strip=True)
            )
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        return "\n".join(lines)[:max_chars]

    # Fallback: regex
    text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = (
        text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
    )
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_chars]


# === Tool Handlers ===


def web_search(data: dict) -> str:
    """Search the web and return top results with titles, snippets, URLs."""
    _load_config()
    query = data.get("query", "").strip()
    if not query:
        return "Please provide a search query."

    max_results = min(data.get("max_results", _CONFIG["max_results"]), 15)

    if _CONFIG["backend"] == "searxng":
        results = _search_searxng(query, max_results)
    else:
        results = _search_duckduckgo(query, max_results)

    if not results:
        return f"No results found for: {query}"

    lines = [f"🔍 Search: {query}\n"]
    for i, r in enumerate(results, 1):
        lines.append(f"  {i}. {r['title']}")
        if r.get("url"):
            lines.append(f"     {r['url']}")
        if r.get("snippet"):
            lines.append(f"     {r['snippet'][:200]}")
        lines.append("")
    return "\n".join(lines)


def web_read(data: dict) -> str:
    """Fetch a URL and extract readable text content."""
    url = data.get("url", "").strip()
    if not url:
        return "Please provide a URL to read."
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        html = _http_get(url)
    except Exception as e:
        logger.warning(f"Fetch failed for {url}: {e}")
        return f"Failed to fetch {url}: connection error"

    text = _extract_readable_text(html)
    if not text or len(text) < 50:
        return f"Could not extract meaningful content from {url}"

    max_len = int(data.get("max_chars", 6000))
    if len(text) > max_len:
        text = text[:max_len] + "\n\n[Content truncated]"
    return f"📄 Content from {url}:\n\n{text}"


def web_summarize(data: dict) -> str:
    """Fetch a URL and return extracted text for LLM summarization."""
    url = data.get("url", "").strip()
    if not url:
        return "Please provide a URL to summarize."
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        html = _http_get(url)
    except Exception as e:
        logger.warning(f"Fetch failed for {url}: {e}")
        return f"Failed to fetch {url}: connection error"

    text = _extract_readable_text(html, max_chars=10000)
    if not text or len(text) < 50:
        return f"Could not extract meaningful content from {url}"

    return f"📄 Extracted content from {url} ({len(text)} chars). Please summarize:\n\n{text}"


def search_grants(data: dict) -> str:
    """Search for grant opportunities using web search."""
    _load_config()
    query = data.get("query", "").strip()
    if not query:
        return "Please provide a grant search query."

    eligibility = data.get("eligibility", "nonprofit")
    web_query = f"grants {query} {eligibility} site:grants.gov OR site:foundationcenter.org"
    web_results = _search_duckduckgo(web_query, max_results=8)

    lines = [f"🔍 Grant Search: {query}\n"]
    if web_results:
        for i, r in enumerate(web_results, 1):
            lines.append(f"  {i}. {r['title']}")
            if r.get("url"):
                lines.append(f"     {r['url']}")
            if r.get("snippet"):
                lines.append(f"     {r['snippet'][:200]}")
            lines.append("")
    else:
        lines.append("  No grant results found. Try broadening your search terms.")
    lines.append("  💡 Tip: Also check foundationcenter.org and your state's grant portal.")
    return "\n".join(lines)


def search_nonprofit(data: dict) -> str:
    """Look up an organization by name or EIN on ProPublica Nonprofit Explorer API."""
    query = data.get("query", "").strip()
    ein = data.get("ein", "").strip().replace("-", "")

    if not query and not ein:
        return "Please provide an organization name or EIN."

    results = []

    if ein:
        url = f"https://projects.propublica.org/nonprofits/api/v2/organizations/{ein}.json"
        try:
            body = _http_get(url)
            resp = json.loads(body)
            org = resp.get("organization", {})
            if org:
                results.append(
                    {
                        "name": org.get("name", ""),
                        "ein": org.get("ein", ""),
                        "city": org.get("city", ""),
                        "state": org.get("state", ""),
                        "ntee_code": org.get("ntee_code", ""),
                        "income": org.get("income_amount"),
                        "revenue": org.get("revenue_amount"),
                    }
                )
        except Exception as e:
            logger.warning(f"ProPublica EIN lookup failed: {e}")

    if query and not results:
        encoded = urllib.parse.urlencode({"q": query})
        url = f"https://projects.propublica.org/nonprofits/api/v2/search.json?{encoded}"
        try:
            body = _http_get(url)
            resp = json.loads(body)
            for org in resp.get("organizations", [])[:8]:
                results.append(
                    {
                        "name": org.get("name", ""),
                        "ein": org.get("ein", ""),
                        "city": org.get("city", ""),
                        "state": org.get("state", ""),
                        "ntee_code": org.get("ntee_code", ""),
                        "income": org.get("income_amount"),
                        "revenue": org.get("revenue_amount"),
                    }
                )
        except Exception as e:
            logger.warning(f"ProPublica search failed: {e}")
            web_results = _search_duckduckgo(
                f"nonprofit {query} site:guidestar.org OR site:propublica.org"
            )
            lines = [
                f"🔍 Nonprofit Search: {query}\n",
                "  (ProPublica API unavailable, web results):\n",
            ]
            for i, r in enumerate(web_results[:5], 1):
                lines.append(f"  {i}. {r['title']}")
                if r.get("url"):
                    lines.append(f"     {r['url']}")
            return "\n".join(lines)

    if not results:
        return f"No nonprofit organizations found matching: {query or ein}"

    lines = ["🏛️ Nonprofit Search Results:\n"]
    for org in results:
        lines.append(f"  {org['name']}")
        lines.append(f"    EIN: {org['ein']}")
        location = ", ".join(filter(None, [org.get("city"), org.get("state")]))
        if location:
            lines.append(f"    Location: {location}")
        if org.get("ntee_code"):
            lines.append(f"    NTEE Code: {org['ntee_code']}")
        if org.get("income"):
            lines.append(f"    Income: ${org['income']:,.0f}")
        if org.get("revenue"):
            lines.append(f"    Revenue: ${org['revenue']:,.0f}")
        lines.append("")
    return "\n".join(lines)


# === Tool Definitions ===

TOOLS = [
    {
        "name": "web_search",
        "description": "Search the web via DuckDuckGo or SearXNG. Returns top results with titles, snippets, and URLs.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "max_results": {
                    "type": "integer",
                    "default": 8,
                    "description": "Max results (up to 15)",
                },
            },
            "required": ["query"],
        },
        "handler": web_search,
        "category": "websearch",
    },
    {
        "name": "web_read",
        "description": "Fetch a URL and extract readable text content (article extraction, not raw HTML)",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch and read"},
                "max_chars": {
                    "type": "integer",
                    "default": 6000,
                    "description": "Max characters to return",
                },
            },
            "required": ["url"],
        },
        "handler": web_read,
        "category": "websearch",
    },
    {
        "name": "web_summarize",
        "description": "Fetch a URL and return extracted text for the LLM to summarize in its response",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string", "description": "URL to fetch and summarize"}},
            "required": ["url"],
        },
        "handler": web_summarize,
        "category": "websearch",
    },
    {
        "name": "search_grants",
        "description": "Search for grant opportunities using grants.gov and foundation directories",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Grant search terms (topic, program area)",
                },
                "eligibility": {
                    "type": "string",
                    "default": "nonprofit",
                    "description": "Eligibility type",
                },
            },
            "required": ["query"],
        },
        "handler": search_grants,
        "category": "websearch",
    },
    {
        "name": "search_nonprofit",
        "description": "Look up an organization by name or EIN on ProPublica Nonprofit Explorer (GuideStar/IRS data)",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Organization name to search"},
                "ein": {"type": "string", "description": "EIN (e.g. 12-3456789 or 123456789)"},
            },
        },
        "handler": search_nonprofit,
        "category": "websearch",
    },
]
