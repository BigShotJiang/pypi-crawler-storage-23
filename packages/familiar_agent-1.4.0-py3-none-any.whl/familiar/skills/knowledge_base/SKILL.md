# Knowledge Base Skill

Lightweight, tagged knowledge store for quick-save snippets, notes,
references, and imported documents. Complements the vector-based
knowledge skill with fast tag/title/full-text search.

## Usage

- Save snippets, notes, and references with tags
- Full-text search across all entries
- Import web pages, files, and meeting notes into knowledge base
- Tag-based organization (e.g. grants, donors, policies, recipes)
- Cross-reference with other skills

## Relationship to Existing Knowledge Skill

The existing skills/knowledge/ provides vector-embedding-based semantic
search over large document collections. This skill provides:
- Simpler tag-and-title organization for quick daily use
- JSON-based storage (no embedding model required)
- Import pipeline from web_search, filereader, meetings
- Faster for small collections (<10K entries)

Use existing knowledge skill for large corpus semantic search.
Use this skill for quick notes, bookmarks, and reference snippets.
