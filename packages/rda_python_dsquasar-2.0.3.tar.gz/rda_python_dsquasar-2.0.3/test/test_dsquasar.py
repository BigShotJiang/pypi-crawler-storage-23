# test

import pytest

def test_dsquasar():
    import rda_python_dsquasar.dsquasar
    import rda_python_dsquasar.tacctar
    import rda_python_dsquasar.taccrec
