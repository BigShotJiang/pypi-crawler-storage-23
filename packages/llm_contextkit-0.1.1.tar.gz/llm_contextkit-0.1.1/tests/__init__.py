"""Tests for ContextKit."""
