# log21.levels.py
# CodeWriter21

import logging as _logging

__all__ = [
    'CRITICAL', 'FATAL', 'ERROR', 'WARNING', 'WARN', 'INFO', 'DEBUG', 'NOTSET', 'INPUT',
    'PRINT'
]

INPUT = 70
PRINT = 60
CRITICAL = _logging.CRITICAL
FATAL = CRITICAL
ERROR = _logging.ERROR
WARNING = _logging.WARNING
WARN = WARNING
INFO = _logging.INFO
DEBUG = _logging.DEBUG
NOTSET = _logging.NOTSET
