# [[file:../../demands.org::test_demands][test_demands]]
# Tangled on Thu Feb 26 13:30:51 2026
"""Tests for the CFE demand system (frischian, marshallian, hicksian, core)."""
import pytest
import numpy as np
from numpy.testing import assert_allclose
from numpy import array

from consumerdemands import lambdavalue, marshallian, hicksian, derivative
from consumerdemands import frischian
from consumerdemands.demands import utility, marginal_utilities

# ---------------------------------------------------------------------------
# Parameter sets used across tests
# ---------------------------------------------------------------------------

CASES = [
    pytest.param(
        dict(y=3., p=[1.], alpha=[1.], beta=[1.], phi=[-2.]),
        id="1good-CD"),
    pytest.param(
        dict(y=3., p=[1., 1.], alpha=[1., 1.], beta=[1., 1.], phi=[0., 0.]),
        id="2good-symmetric-CD"),
    pytest.param(
        dict(y=6., p=[10., 15.], alpha=[0.25, 0.75], beta=[0.5, 2.],
             phi=[-0.1, 0.]),
        id="2good-asymmetric"),
    pytest.param(
        dict(y=5., p=[1., 2., 3.], alpha=[1., 1., 1.], beta=[2., 2., 2.],
             phi=[0., 0., 0.]),
        id="3good-equal-beta"),
]


def _unpack(case):
    """Convenience: return (y, p, parms) from a flat dict."""
    y = case['y']
    p = array(case['p'])
    parms = {k: case[k] for k in ('alpha', 'beta', 'phi')}
    return y, p, parms


# ---------------------------------------------------------------------------
# Budget constraint
# ---------------------------------------------------------------------------

class TestBudgetConstraint:
    @pytest.mark.parametrize("case", CASES)
    def test_marshallian_exhausts_budget(self, case):
        """Marshallian demands times prices must equal income."""
        y, p, parms = _unpack(case)
        x = marshallian.demands(y, p, parms)
        assert_allclose(sum(p * array(x)), y, atol=1e-6)

    @pytest.mark.parametrize("case", CASES)
    def test_budget_shares_sum_to_one(self, case):
        y, p, parms = _unpack(case)
        w = marshallian.budgetshares(y, p, parms)
        assert_allclose(sum(w), 1.0, atol=1e-6)


# ---------------------------------------------------------------------------
# Marshallian-Hicksian duality
# ---------------------------------------------------------------------------

class TestDuality:
    @pytest.mark.parametrize("case", CASES)
    def test_expenditure_inverts_indirect_utility(self, case):
        """e(V(y,p), p) should equal y."""
        y, p, parms = _unpack(case)
        V = marshallian.indirect_utility(y, p, parms)
        e = hicksian.expenditurefunction(V, p, parms)
        assert_allclose(e, y, atol=1e-6)


# ---------------------------------------------------------------------------
# Envelope theorem:  dV/dy = lambda
# ---------------------------------------------------------------------------

class TestEnvelopeTheorem:
    @pytest.mark.parametrize("case", CASES)
    def test_dVdy_equals_lambda(self, case):
        y, p, parms = _unpack(case)
        lbda = lambdavalue(y, p, parms)
        Vfunc = lambda yy: marshallian.indirect_utility(yy, p, parms)
        dV = derivative(Vfunc)
        assert_allclose(dV(y), lbda, rtol=1e-4)


# ---------------------------------------------------------------------------
# Frischian / Marshallian consistency
# ---------------------------------------------------------------------------

class TestFrischianMarshallian:
    @pytest.mark.parametrize("case", CASES)
    def test_same_demands(self, case):
        """Frischian demands at lambda(y,p) must equal Marshallian demands."""
        y, p, parms = _unpack(case)
        lbda = lambdavalue(y, p, parms)
        x_f = frischian.demands(lbda, p, parms)
        x_m = marshallian.demands(y, p, parms)
        assert_allclose(x_f, x_m, atol=1e-8)


# ---------------------------------------------------------------------------
# Income elasticity = share income elasticity + 1
# ---------------------------------------------------------------------------

class TestElasticities:
    @pytest.mark.parametrize("case", CASES)
    def test_income_elasticity_relation(self, case):
        y, p, parms = _unpack(case)
        sie = array(marshallian.share_income_elasticity(y, p, parms))
        ie = array(marshallian.income_elasticity(y, p, parms))
        assert_allclose(ie, sie + 1., atol=1e-6)


# ---------------------------------------------------------------------------
# Utility and marginal utilities
# ---------------------------------------------------------------------------

class TestUtility:
    @pytest.mark.parametrize("case", CASES)
    def test_marginal_utilities_positive(self, case):
        """At interior Marshallian demands, all marginal utilities are positive."""
        y, p, parms = _unpack(case)
        x = marshallian.demands(y, p, parms)
        mu = marginal_utilities(x, **parms)
        for i, m in enumerate(mu):
            assert m > 0, f"MU[{i}] = {m} is not positive"


# ---------------------------------------------------------------------------
# NegativeDemands flag
# ---------------------------------------------------------------------------

class TestNegativeDemands:
    def test_demands_clipped_when_false(self):
        """With NegativeDemands=False, demands should be >= 0."""
        parms = {'alpha': [1., 1.], 'beta': [1., 1.], 'phi': [2., -2.]}
        p = [1., 1.]
        y = 3.
        x = marshallian.demands(y, p, parms, NegativeDemands=False)
        for xi in x:
            assert xi >= 0.0
# test_demands ends here
