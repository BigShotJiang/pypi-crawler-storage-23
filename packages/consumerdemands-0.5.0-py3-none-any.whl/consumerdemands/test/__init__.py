# [[file:../../demands.org::*Test package init][Test package init:1]]
# Tangled on Thu Feb 26 13:30:51 2026
# Test package init:1 ends here
