# [[file:../../demands.org::test_utils][test_utils]]
# Tangled on Thu Feb 26 13:30:51 2026
"""Tests for consumerdemands._utils (check_args, derivative)."""
import pytest
import numpy as np
from numpy.testing import assert_allclose
from consumerdemands._utils import check_args, derivative


# --- check_args -----------------------------------------------------------

class TestCheckArgs:
    def test_returns_n_and_dict(self):
        n, parms = check_args(alpha=[1., 2.], beta=[1., 1.], phi=[0., 0.])
        assert n == 2
        assert set(parms.keys()) == {'alpha', 'beta', 'phi'}

    def test_scalar_broadcast(self):
        """Scalar alpha/beta/phi should broadcast to match longest arg."""
        n, parms = check_args(p=[1., 2., 3.], alpha=1., beta=2., phi=0.)
        assert n == 3
        assert len(parms['alpha']) == 3
        assert len(parms['beta']) == 3
        assert len(parms['phi']) == 3

    def test_price_determines_n(self):
        n, parms = check_args(p=[5., 10.], alpha=1., beta=1., phi=0.)
        assert n == 2

    def test_non_finite_prices_raise(self):
        with pytest.raises(AssertionError):
            check_args(p=[1., np.nan], alpha=1., beta=1., phi=0.)

    def test_arrays_are_float(self):
        n, parms = check_args(alpha=[1, 2], beta=[1, 1], phi=[0, 0])
        assert parms['alpha'].dtype == float


# --- derivative ------------------------------------------------------------

class TestDerivative:
    def test_linear(self):
        """d/dx (3x) = 3."""
        f = lambda x: 3 * x
        df = derivative(f)
        assert_allclose(df(5.0), 3.0, atol=1e-6)

    def test_quadratic(self):
        """d/dx (x^2) = 2x."""
        f = lambda x: x ** 2
        df = derivative(f)
        assert_allclose(df(3.0), 6.0, atol=1e-4)

    def test_sin(self):
        """d/dx sin(x) = cos(x)."""
        df = derivative(np.sin)
        assert_allclose(df(1.0), np.cos(1.0), atol=1e-6)

    def test_exp(self):
        """d/dx exp(x) = exp(x)."""
        df = derivative(np.exp)
        assert_allclose(df(0.0), 1.0, atol=1e-6)
        assert_allclose(df(2.0), np.exp(2.0), atol=1e-4)
# test_utils ends here
