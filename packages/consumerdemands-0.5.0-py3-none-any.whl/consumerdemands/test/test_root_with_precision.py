# [[file:../../monotone_function_solver.org::test_root_with_precision][test_root_with_precision]]
# Tangled on Thu Feb 26 13:30:52 2026
"""Tests for root_with_precision (monotone root finder)."""
import pytest
from numpy import inf
from numpy.testing import assert_allclose
from consumerdemands.root_with_precision import root_with_precision


class TestClosedInterval:
    def test_linear(self):
        """Root of (x - 1) in [0, 2] is 1."""
        f = lambda x: x - 1
        r = root_with_precision(f, [0, 1, 2], tol=1e-12)
        assert_allclose(r, 1.0, atol=1e-11)

    def test_cubic(self):
        """Root of (x^3 - 8) in [0, 3] is 2."""
        f = lambda x: x ** 3 - 8
        r = root_with_precision(f, [0, 1, 3], tol=1e-10)
        assert_allclose(r, 2.0, atol=1e-9)

    def test_respects_tolerance(self):
        f = lambda x: x - 0.7
        for tol in [1e-6, 1e-9, 1e-12]:
            r = root_with_precision(f, [0, 0.5, 1], tol=tol)
            assert abs(r - 0.7) < tol * 10  # small safety margin


class TestOpenInterval:
    def test_hyperbolic(self):
        """Root of (1/x - 1) in (0, inf) is 1."""
        f = lambda x: 1.0 / x - 1
        r = root_with_precision(f, [0, 10, inf], tol=1e-12,
                                open_interval=True)
        assert_allclose(r, 1.0, atol=1e-10)

    def test_log(self):
        """Root of log(x) in (0, inf) is 1."""
        from numpy import log
        f = lambda x: log(x)
        r = root_with_precision(f, [0, 2, inf], tol=1e-12,
                                open_interval=True)
        assert_allclose(r, 1.0, atol=1e-10)


class TestEdgeCases:
    def test_no_root_raises(self):
        """Function with no sign change in interval should raise."""
        f = lambda x: x + 1  # always positive on [0, 2]
        with pytest.raises(ValueError):
            root_with_precision(f, [0, 1, 2], tol=1e-12)

    def test_root_at_endpoint(self):
        """Root exactly at an endpoint."""
        f = lambda x: x
        r = root_with_precision(f, [-1, 0, 1], tol=1e-12)
        assert_allclose(r, 0.0, atol=1e-12)
# test_root_with_precision ends here
