"""Output format generators for `agentmesh scan`."""
