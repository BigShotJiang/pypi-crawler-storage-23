from deep_variable.core import DeepVariable

# This allows: from deep_variable import DeepVariable
__all__ = ["DeepVariable"]
