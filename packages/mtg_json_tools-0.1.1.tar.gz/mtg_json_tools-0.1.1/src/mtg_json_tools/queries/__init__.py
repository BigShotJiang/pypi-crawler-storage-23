"""Query modules for mtg-json-tools."""
