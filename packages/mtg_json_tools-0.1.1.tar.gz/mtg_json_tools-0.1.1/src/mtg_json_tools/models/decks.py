"""MTGJSON deck models (vendored, standalone)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from .cards import CardDeck, CardToken


class DeckList(BaseModel):
    """Deck list summary (without cards)."""

    model_config = {"populate_by_name": True}

    code: str = Field(description="The printing deck code.")
    name: str = Field(description="The name of the deck.")
    file_name: str = Field(alias="fileName")
    type: str = Field(description="The type of the deck.")
    release_date: str | None = Field(default=None, alias="releaseDate")


class Deck(BaseModel):
    """Full deck with expanded cards."""

    model_config = {"populate_by_name": True}

    code: str = Field(description="The printing set code for the deck.")
    name: str = Field(description="The name of the deck.")
    type: str = Field(description="The type of deck.")
    release_date: str | None = Field(default=None, alias="releaseDate")
    sealed_product_uuids: list[str] | None = Field(
        default=None, alias="sealedProductUuids"
    )
    main_board: list[CardDeck] = Field(default_factory=list, alias="mainBoard")
    side_board: list[CardDeck] = Field(default_factory=list, alias="sideBoard")
    commander: list[CardDeck] | None = Field(default=None)
    display_commander: list[CardDeck] | None = Field(
        default=None, alias="displayCommander"
    )
    planes: list[CardDeck] | None = None
    schemes: list[CardDeck] | None = None
    tokens: list[CardToken] | None = Field(default=None)
    source_set_codes: list[str] | None = Field(default=None, alias="sourceSetCodes")
