# API reference

::: redsun.containers.components
    options:
      members:
        - device
        - presenter
        - view

::: redsun.containers.container.AppContainerMeta

::: redsun.containers.container.AppContainer

::: redsun.qt.QtAppContainer
