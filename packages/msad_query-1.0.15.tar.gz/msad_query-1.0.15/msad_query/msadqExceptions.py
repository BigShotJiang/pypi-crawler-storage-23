class MSADQueryException(Exception):
    pass
