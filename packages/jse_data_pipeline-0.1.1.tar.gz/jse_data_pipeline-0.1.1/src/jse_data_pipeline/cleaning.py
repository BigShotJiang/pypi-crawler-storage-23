import pandas as pd
import numpy as np
from scipy import stats

def remove_outliers(df: pd.DataFrame) -> pd.DataFrame:
    price_cols = ["open", "high", "low", "close", "volume"]
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    df.set_index("date", inplace=True)

    cleaned = []
    for symbol, group in df.groupby("symbol"):
        prices = group[price_cols]
        z = np.abs(stats.zscore(prices, nan_policy="omit"))
        filtered = group[(z < 3).all(axis=1)]
        cleaned.append(filtered)

    return pd.concat(cleaned)
