import argparse
from pathlib import Path
from .config import PipelineConfig
from .pipeline import run_pipeline
from .logging_config import configure_logging

def main():
    configure_logging()

    parser = argparse.ArgumentParser(description="JSE Data Pipeline")
    parser.add_argument("--start", required=True)
    parser.add_argument("--end", required=True)
    parser.add_argument("--api-key", required=True)
    parser.add_argument("--output-dir", default="jse_data")

    args = parser.parse_args()

    config = PipelineConfig(
        start=args.start,
        end=args.end,
        api_key=args.api_key,
        output_dir=Path(args.output_dir),
    )

    run_pipeline(config)
