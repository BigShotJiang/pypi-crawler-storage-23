from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class PipelineConfig:
    start: str
    end: str
    api_key: str
    output_dir: Path = Path.cwd() / "jse_data"
    index_symbol: str = "STXCAP.JO"
