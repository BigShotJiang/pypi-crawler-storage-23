import pandas as pd
import yfinance as yf
import logging

logger = logging.getLogger(__name__)

def download_index(symbol: str, start: str, end: str) -> pd.DataFrame:
    logger.info("Downloading index: %s", symbol)
    ticker = yf.Ticker(symbol)
    df = ticker.history(start=start, end=end)

    if df.empty:
        raise ValueError("Index download returned empty dataframe")

    df = (
        df.reset_index()
        .assign(Date=lambda x: pd.to_datetime(x["Date"]).dt.strftime("%Y-%m-%d"))
        .drop(columns=["Open", "High", "Low", "Volume", "Dividends", "Stock Splits"])
        .set_index("Date")
    )

    return df
