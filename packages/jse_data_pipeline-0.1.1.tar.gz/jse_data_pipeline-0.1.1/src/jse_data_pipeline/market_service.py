from yahooquery import Ticker
import pandas as pd
import logging

logger = logging.getLogger(__name__)

def download_market_data(symbols: list[str], start: str, end: str) -> pd.DataFrame:
    logger.info("Downloading %d symbols", len(symbols))
    tickers = Ticker(symbols, asynchronous=True)
    df = tickers.history(start=start, end=end, interval="1d")

    if df.empty:
        raise ValueError("Market data download returned empty dataframe")

    df = df.drop(columns=["adjclose", "dividends", "splits"], errors="ignore")
    df.reset_index(inplace=True)
    return df
