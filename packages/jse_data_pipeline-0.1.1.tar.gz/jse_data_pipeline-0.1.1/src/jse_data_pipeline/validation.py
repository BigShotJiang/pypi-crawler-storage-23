from datetime import datetime

def validate_dates(start: str, end: str) -> None:
    if datetime.fromisoformat(start) >= datetime.fromisoformat(end):
        raise ValueError("Start date must be before end date")
