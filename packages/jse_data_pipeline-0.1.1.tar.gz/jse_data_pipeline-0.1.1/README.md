# JSE Data Pipeline

Production-grade JSE financial data ingestion pipeline.
