# This file makes `scripts/` a Python package so the console script
# `openwebgoggles = "scripts.mcp_server:main"` resolves correctly
# after `pip install .` or `pip install -e .`.
