# cc-logger

Claude Code trajectory exporter + analytics tool. PyPI: `claude-code-logger`

## Workflow

- Always commit and push changes when done
- Always deploy to PyPI after pushing (bump version in pyproject.toml, `uv build && uv publish`)
- PyPI token is in `~/.pypirc`

## Structure

- `src/cc_logger/cli.py` — Typer CLI (list, export, stats, view)
- `src/cc_logger/discovery/` — session discovery + filtering
- `src/cc_logger/parser/` — JSONL parsing + reassembly
- `src/cc_logger/mapper/` — ATIF trajectory mapping
- `tests/` — pytest tests with JSONL fixtures

## Commands

- `uv run pytest tests/ -q` — run tests
- `uv build && uv publish dist/* --token <token>` — deploy
