## ADDED Requirements

### Requirement: Produce valid ATIF v1.6 root structure
The system SHALL produce a JSON object conforming to Harbor ATIF v1.6 with required fields: `schema_version`, `session_id`, `agent`, and `steps`.

#### Scenario: Complete trajectory export
- **WHEN** a CC session is exported
- **THEN** the output JSON SHALL have `schema_version: "ATIF-v1.6"`, `session_id` set to the CC session UUID, `agent` with name/version/model_name, and `steps` as a non-empty array

#### Scenario: Agent configuration
- **WHEN** populating the `agent` field
- **THEN** `agent.name` SHALL be `"claude-code"`, `agent.version` SHALL be taken from the first message's `version` field, and `agent.model_name` SHALL be taken from the first non-synthetic assistant message's `message.model` field

### Requirement: Map external user messages to user steps
The system SHALL convert external user messages (human input) to ATIF steps with `source: "user"`.

#### Scenario: Plain text user message
- **WHEN** a CC user message has string content
- **THEN** the ATIF step SHALL have `source: "user"`, `message` set to the string content, a sequential `step_id`, and `timestamp` from the CC message

### Requirement: Map reassembled assistant responses to agent steps
The system SHALL convert reassembled assistant responses to ATIF steps with `source: "agent"`.

#### Scenario: Text-only response
- **WHEN** a reassembled response contains only `text` content blocks
- **THEN** the ATIF step SHALL have `source: "agent"` and `message` set to the concatenated text

#### Scenario: Response with thinking and text
- **WHEN** a reassembled response contains `thinking` and `text` blocks
- **THEN** the ATIF step SHALL have `reasoning_content` set to the thinking text and `message` set to the text block content

#### Scenario: Response with tool calls
- **WHEN** a reassembled response contains `tool_use` blocks
- **THEN** the ATIF step SHALL have `tool_calls` array where each entry has `tool_call_id` (from `id`), `function_name` (from `name`), and `arguments` (from `input`)

#### Scenario: Response with mixed content
- **WHEN** a reassembled response contains thinking, text, and tool_use blocks
- **THEN** the ATIF step SHALL have `reasoning_content` from thinking, `message` from text, and `tool_calls` from tool_use blocks

#### Scenario: Model name per step
- **WHEN** an assistant response uses a specific model
- **THEN** the ATIF step SHALL include `model_name` from `message.model` (excluding synthetic messages where model is `"<synthetic>"`)

### Requirement: Map tool results to observations on agent steps
The system SHALL attach tool results as `observation` objects on the preceding agent step, not as separate steps.

#### Scenario: Single tool result
- **WHEN** an agent step has one tool_call and a corresponding tool_result follows
- **THEN** the agent step's `observation` SHALL have `results` array with one entry containing `source_call_id` matching the `tool_call_id` and `content` set to the tool result text

#### Scenario: Multiple tool results
- **WHEN** an agent step has multiple tool_calls and corresponding tool_results follow
- **THEN** the `observation.results` SHALL contain one entry per tool result, each matched to its tool_call via `source_call_id` (matched by `tool_use_id`)

#### Scenario: Error tool result
- **WHEN** a tool_result has `is_error: true`
- **THEN** the observation result `content` SHALL include the error text, prefixed with `"ERROR: "`

### Requirement: Map system events to system steps
The system SHALL convert relevant CC system messages to ATIF steps with `source: "system"`.

#### Scenario: Context compaction event
- **WHEN** a CC system message has `subtype: "compact_boundary"`
- **THEN** the ATIF step SHALL have `source: "system"` and `message` describing the compaction including trigger type and pre-compaction token count

#### Scenario: Microcompaction event
- **WHEN** a CC system message has `subtype: "microcompact_boundary"`
- **THEN** the ATIF step SHALL have `source: "system"` and `message` describing the microcompaction including tokens saved and number of compacted tool results

#### Scenario: API error event
- **WHEN** a CC system message has `subtype: "api_error"`
- **THEN** the ATIF step SHALL have `source: "system"` and `message` describing the error status and retry information

#### Scenario: Compaction summary as system step
- **WHEN** a CC user message has `isCompactSummary: true`
- **THEN** the ATIF step SHALL have `source: "system"` and `message` set to the compaction summary text

### Requirement: Skip non-conversation message types
The system SHALL skip CC message types that are not part of the conversation flow.

#### Scenario: Progress messages
- **WHEN** a CC message has `type: "progress"`
- **THEN** the system SHALL NOT create an ATIF step for it

#### Scenario: File history snapshots
- **WHEN** a CC message has `type: "file-history-snapshot"`
- **THEN** the system SHALL NOT create an ATIF step for it

#### Scenario: Queue operations
- **WHEN** a CC message has `type: "queue-operation"`
- **THEN** the system SHALL NOT create an ATIF step for it

#### Scenario: Turn duration system messages
- **WHEN** a CC system message has `subtype: "turn_duration"`
- **THEN** the system SHALL NOT create an ATIF step for it

### Requirement: Compute per-step metrics from usage data
The system SHALL populate ATIF `metrics` on agent steps using CC's `message.usage` fields.

#### Scenario: Standard metrics mapping
- **WHEN** an agent step's reassembled response has usage data
- **THEN** `metrics.prompt_tokens` SHALL equal `usage.input_tokens`, `metrics.completion_tokens` SHALL equal `usage.output_tokens`, and `metrics.cached_tokens` SHALL equal `usage.cache_read_input_tokens`

#### Scenario: Metrics from last chunk
- **WHEN** an assistant response spans multiple JSONL lines
- **THEN** the system SHALL use the `usage` from the **last** line in the group (which contains the most complete token counts)

### Requirement: Compute final trajectory metrics
The system SHALL populate `final_metrics` by aggregating all per-step metrics.

#### Scenario: Aggregate totals
- **WHEN** a trajectory has multiple agent steps with metrics
- **THEN** `final_metrics` SHALL have `total_prompt_tokens` (sum of all `prompt_tokens`), `total_completion_tokens` (sum of all `completion_tokens`), `total_cached_tokens` (sum of all `cached_tokens`), and `total_steps` (count of all steps)

### Requirement: Export subagent trajectories with references
The system SHALL export subagent JSONL files as separate ATIF files and link them from the parent trajectory.

#### Scenario: Agent step with subagent
- **WHEN** an agent step contains a `Task` tool_call and the corresponding subagent JSONL file exists
- **THEN** the subagent SHALL be exported as a separate ATIF file, and the parent step's observation result SHALL include `subagent_trajectory_ref` with `session_id` set to the subagent's session ID and `trajectory_path` set to the relative file path

#### Scenario: Subagent file not found
- **WHEN** a `Task` tool_call's result references a subagent but no matching JSONL file exists
- **THEN** the system SHALL log a warning and omit the `subagent_trajectory_ref` (the observation content is still included)

### Requirement: Sequential step IDs
The system SHALL assign sequential integer `step_id` values starting from 1.

#### Scenario: Step ID ordering
- **WHEN** a trajectory has N steps
- **THEN** step IDs SHALL be integers from 1 to N in chronological order
