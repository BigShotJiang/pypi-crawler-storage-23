## ADDED Requirements

### Requirement: Discover sessions from Claude Code project directories
The system SHALL scan `~/.claude/projects/` to discover all project directories. Each project directory is named with the absolute path of the working directory using hyphens instead of `/` (e.g., `-Users-joan-my-project`). The system SHALL read the `sessions-index.json` file within each project directory to enumerate available sessions.

#### Scenario: List all sessions across all projects
- **WHEN** the system scans `~/.claude/projects/` with no filters
- **THEN** it SHALL return a list of all sessions from all `sessions-index.json` files, each containing: session ID, project path, creation date, modification date, first prompt text, message count, and git branch

#### Scenario: Project directory without sessions-index.json
- **WHEN** a project directory exists but contains no `sessions-index.json`
- **THEN** the system SHALL fall back to scanning for `*.jsonl` files directly in that directory and extract session metadata from the first message in each file

#### Scenario: Corrupted or unreadable sessions-index.json
- **WHEN** `sessions-index.json` exists but cannot be parsed as valid JSON
- **THEN** the system SHALL log a warning and fall back to JSONL file scanning for that project directory

### Requirement: Filter sessions by project path
The system SHALL support filtering sessions to a specific project by matching against the original project path (not the slugified directory name).

#### Scenario: Filter by exact project path
- **WHEN** the user specifies `--project /Users/joan/my-project`
- **THEN** the system SHALL only return sessions from the project directory whose `originalPath` matches the specified path

#### Scenario: Filter by partial project path
- **WHEN** the user specifies `--project my-project`
- **THEN** the system SHALL return sessions from all project directories whose path contains the specified substring

### Requirement: Filter sessions by date
The system SHALL support filtering sessions by creation or modification date.

#### Scenario: Filter by since date
- **WHEN** the user specifies `--since 2026-01-15`
- **THEN** the system SHALL only return sessions whose modification date is on or after the specified date

### Requirement: Filter sessions by session ID
The system SHALL support selecting a single session by its UUID.

#### Scenario: Select specific session
- **WHEN** the user specifies `--session f4fb8948-ddbd-4360-a2d6-ce1dfd394502`
- **THEN** the system SHALL locate and return only that session, searching across all project directories

#### Scenario: Session ID not found
- **WHEN** the specified session ID does not exist in any project directory
- **THEN** the system SHALL exit with a non-zero code and print an error message indicating the session was not found

### Requirement: Discover subagent sessions
The system SHALL discover subagent JSONL files for a given session. Subagent files are stored at `<session-dir>/subagents/agent-*.jsonl` where `<session-dir>` is a directory with the same name as the session ID.

#### Scenario: Session with subagents
- **WHEN** a session has a directory `<session-id>/subagents/` containing `agent-*.jsonl` files
- **THEN** the system SHALL return the list of subagent files with their agent IDs (extracted from the filename pattern `agent-<id>.jsonl`)

#### Scenario: Session without subagents
- **WHEN** no `<session-id>/subagents/` directory exists for a session
- **THEN** the system SHALL return an empty list of subagents
