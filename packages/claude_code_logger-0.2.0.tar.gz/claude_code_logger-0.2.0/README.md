# cc-logger

Export and analyse [Claude Code](https://docs.anthropic.com/en/docs/claude-code) sessions.

Reads the JSONL trajectories Claude Code stores in `~/.claude/` and converts them to [Harbor ATIF](https://github.com/codegenresearch/harbor) format for viewing and analysis.

## Install

```
pip install claude-code-logger
```

## Usage

```bash
# List sessions
cc-logger list

# Export all sessions to Harbor format
cc-logger export /tmp/cc-export --harbor

# View exported sessions in the browser
cc-logger view /tmp/cc-export

# Show token/session analytics
cc-logger stats /tmp/cc-export
cc-logger stats /tmp/cc-export --json
cc-logger stats /tmp/cc-export --project myproject
```
