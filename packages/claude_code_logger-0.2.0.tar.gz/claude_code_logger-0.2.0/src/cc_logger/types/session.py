"""Internal types for session discovery and management."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SessionInfo:
    session_id: str
    jsonl_path: Path
    project_path: str  # original project path (not slugified)
    project_slug: str  # directory name under ~/.claude/projects/
    created: str | None = None
    modified: str | None = None
    first_prompt: str | None = None
    message_count: int = 0
    git_branch: str | None = None


@dataclass
class ProjectInfo:
    slug: str  # directory name
    original_path: str  # from sessions-index.json originalPath
    directory: Path  # full path to the project dir
    sessions: list[SessionInfo] = field(default_factory=list)


@dataclass
class SubagentInfo:
    agent_id: str
    jsonl_path: Path
