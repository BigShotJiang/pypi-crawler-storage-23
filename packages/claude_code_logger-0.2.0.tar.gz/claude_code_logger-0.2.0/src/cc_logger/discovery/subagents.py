"""Discover subagent JSONL files for a session."""

from __future__ import annotations

from pathlib import Path

from cc_logger.types.session import SubagentInfo


def discover_subagents(session_id: str, project_dir: Path) -> list[SubagentInfo]:
    """Find all subagent JSONL files for a given session.

    Subagent files are at <project_dir>/<session_id>/subagents/agent-*.jsonl
    """
    subagents_dir = project_dir / session_id / "subagents"
    if not subagents_dir.is_dir():
        return []

    results: list[SubagentInfo] = []
    for path in sorted(subagents_dir.glob("agent-*.jsonl")):
        # Extract agent ID from filename: agent-abc1234.jsonl -> abc1234
        agent_id = path.stem.removeprefix("agent-")
        results.append(SubagentInfo(agent_id=agent_id, jsonl_path=path))
    return results
