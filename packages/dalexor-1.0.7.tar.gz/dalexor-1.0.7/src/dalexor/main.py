import os
import sys
import logging
import json
import time
import math
import hashlib
import zlib
import re
import difflib
import threading
import argparse
import subprocess
import ast
import base64
import secrets
from datetime import datetime
# VERSION: E2EE_NEURAL_VAULT_V18
from threading import Timer
from collections import Counter, deque
from typing import Any, List, Dict, Optional

# Multi-Language AST Support
try:
    from tree_sitter_languages import get_language, get_parser
    TREE_SITTER_AVAILABLE = True
except ImportError:
    TREE_SITTER_AVAILABLE = False

# MCP & Web Imports
from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv
from supabase import create_client, Client
from groq import Groq
import uvicorn
from starlette.responses import JSONResponse
from starlette.requests import Request
import httpx

# Configure logging to strictly use stderr to prevent polluting the JSON-RPC stdout stream
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger("DalexorBridge")
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from fastapi.middleware.cors import CORSMiddleware

# Load local environment if it exists (Priority: Local .env > Shell Env)
load_dotenv(override=True)

# --- CONFIGURATION & AUTH (STATELESS) ---

def load_global_config():
    """Load configuration from global user config file."""
    import json
    config_file = os.path.join(os.path.expanduser("~/.dalexor"), "config.json")
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"[!] Warning: Failed to load global config: {e}")
    return {}



# Load Global Config
GLOBAL_CONFIG = load_global_config()

# Try to load API KEY from Env -> Global Config
DX_API_KEY = os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY") or GLOBAL_CONFIG.get("api_key")

CLOUD_URL = os.getenv("DALEXORMI_URL", "https://api.dalexor.com")
DX_SOVEREIGN = os.getenv("DX_SOVEREIGN", GLOBAL_CONFIG.get("sovereign", "false")).lower() == "true"
DX_TEAM_SECRET = (os.getenv("DX_TEAM_SECRET") or GLOBAL_CONFIG.get("team_secret") or "").strip()

# Set globals for project context if available
if not os.getenv("DX_PROJECT_ID") and GLOBAL_CONFIG.get("project_id"):
    os.environ["DX_PROJECT_ID"] = GLOBAL_CONFIG.get("project_id")
    
if not os.getenv("DX_PROJECT_NAME") and GLOBAL_CONFIG.get("project_name"):
    os.environ["DX_PROJECT_NAME"] = GLOBAL_CONFIG.get("project_name")


# --- NEURAL VAULT (E2EE) ---
class NeuralVault:
    @staticmethod
    def get_key(secret: str):
        import hashlib, base64
        hasher = hashlib.sha256()
        hasher.update(secret.encode())
        return base64.urlsafe_b64encode(hasher.digest())

# Removed NeuralVault.lock: Encryption is now handled by the Cloud Brain.

    @staticmethod
    def unlock(blob: str, secret: str) -> str:
        if not blob or not secret: return blob
        if not str(blob).startswith("vault_v1:"): return blob
        try:
            from cryptography.fernet import Fernet
            import base64
            cipher_text = blob.replace("vault_v1:", "").strip()
            
            # 🛡️ NOVEL BASE64 RECOVERY: Repair padding
            while len(cipher_text) % 4 != 0:
                cipher_text += "="
                
            f = Fernet(NeuralVault.get_key(secret))
            return f.decrypt(cipher_text.encode()).decode()
        except:
            return "[Neural Vault: Decryption Failed (Check DX_TEAM_SECRET)]"

# ... (Supabase/Groq init logic remains same) ...
# These are used by the CLOUD BRAIN (Railway) to talk to the DB/AI
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SERVICE_ROLE = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Detection: Are we running on Railway?
IS_CLOUD = os.getenv("RAILWAY_ENVIRONMENT") == "true" or os.getenv("RAILWAY_STATIC_URL") is not None or os.getenv("VPS_MODE") == "true"

# Shared Constants
IGNORE_LIST = {'.git', 'node_modules', '__pycache__', '.env', 'dist', 'build', '.next', '.dalexor', '.vscode', '.idea', 'venv', '.pyc', '.egg-info', '.pytest_cache', '.mypy_cache', '.key', '.pem', '.crt', '.bak', '.swp', 'data.sqlite', 'db.sqlite3'}


# --- INITIALIZE DATABASE ONLY IF IN CLOUD ---
supabase_admin: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE) if (IS_CLOUD and SUPABASE_URL and SUPABASE_SERVICE_ROLE) else None
groq_client = Groq(api_key=GROQ_API_KEY) if (IS_CLOUD and GROQ_API_KEY) else None

# --- ENTROPY ENGINE ---
class SovereignEntropyEngine:
    @staticmethod
    def calculate(content, file_path=""):
        if not content or len(content) < 10: return 0.0
        
        # Layer 1: Token-based Shannon Entropy (Semantic Density)
        tokens = re.findall(r'[a-zA-Z_][a-zA-Z0-9_]*', content)
        if not tokens: return 0.5
        
        counts = Counter(tokens)
        total_tokens = len(tokens)
        shannon = -sum((count/total_tokens) * math.log2(count/total_tokens) for count in counts.values())
        
        # Layer 2: Autonomous Gravity (Structural Signature Analysis)
        gravity = 1.0
        
        # A. Identity Affinity: If tokens match the file name, the file is describing ITSELF (High Signal).
        if file_path:
            file_name = os.path.basename(file_path).split('.')[0].lower()
            if len(file_name) > 2:
                token_set = {t.lower() for t in tokens}
                if file_name in token_set:
                    gravity = max(gravity, 3.5)
        
        # B. Symbol Complexity Boost: Any token that looks like a Class, Function, or Constant.
        # PascalCase, camelCase, or UPPER_SNAKE
        complex_symbols = [t for t in tokens if re.search(r'[a-z][A-Z]', t) or re.match(r'^[A-Z][a-z]+[A-Z]', t) or (re.match(r'^[A-Z_]{4,}$', t))]
        symbol_density = len(complex_symbols) / total_tokens
        gravity += (symbol_density * 5.0)
        
        # Layer 3: Structural Multiplier (Logic density check)
        structure_multiplier = 1.0
        logic_patterns = [
            r'def\s+\w+', r'async\s+def', r'class\s+\w+',
            r'return\s+', r'if\s+.*:', r'import\s+', r'@\w+\(',
            r'\{[\s\S]*\}', r'supabase'
        ]
        
        for pattern in logic_patterns:
            matches = re.findall(pattern, content)
            if matches:
                structure_multiplier += (len(matches) * 0.20)
        
        # Layer 4: Noise Penalty (Repetitive boilerplate reduction)
        unique_tokens = len(counts)
        lexical_diversity = unique_tokens / total_tokens
        if lexical_diversity < 0.2 and total_tokens > 30:
            structure_multiplier *= 0.4
            
        # Final Sovereign Calculation
        score = (shannon * gravity * structure_multiplier) / 1.5
        return round(min(score, 10.0), 2)

# --- TRANSACTION MEMORY ---
class TransactionMemory:
    def __init__(self, cloud_callback):
        self.buffer = deque(maxlen=50)
        self.cloud_callback = cloud_callback
        self.lock = threading.Lock()
        self.flush_timer = None

    def add(self, file_path, diff, entropy, synapses, symbols, force_seal=False, full_state=None):
        with self.lock:
            # Check if this file already in buffer. If so, update it.
            # This is "Edge Coalescence"
            self.buffer.append({"file": file_path, "diff": diff, "entropy": entropy, "synapses": synapses, "symbols": symbols, "ts": time.time(), "seal": force_seal, "full_state": full_state})
            
            if force_seal or len(self.buffer) >= 5:
                self._flush()
            else:
                if self.flush_timer: self.flush_timer.cancel()
                self.flush_timer = Timer(10.0, self._flush)
                self.flush_timer.start()

    def flush_all(self):
        """Force immediate flush of all pending items, marking them as seals."""
        with self.lock:
            if not self.buffer:
                print("[!] No pending evolution detected. (Use 'dx seal' for full project snapshot)")
                return
            
            # Mark all pending items as seals
            for item in self.buffer:
                item['seal'] = True
                
            print(f"[!] Sealing Milestone: Transmitting {len(self.buffer)} pending evolutionary atoms...")
        self._flush()

    def _flush(self):
        with self.lock:
            if not self.buffer: return
            batch = list(self.buffer)
            self.buffer.clear()
            
            for item in batch:
                content = item['diff']
                file_path = item['file']
                entropy = item['entropy']
                is_seal = item.get('seal', False)
                
                payload = {
                    "content": scrub_secrets(content[:400000000]) if not content.startswith("vault_") else content,
                    "entropy_score": 10.0 if is_seal else round(entropy, 2),
                    "atom_type": "evolution_event", # Always use evolution_event for proper rendering
                    "source": "sentinel",
                    "synapses": item.get('synapses', []),
                    "symbols": item.get('symbols', []),
                    "is_sovereign": DX_SOVEREIGN,
                    "request_server_encryption": DX_SOVEREIGN,
                    "metadata": {
                        "file_path": file_path.replace("\\", "/"),
                        "file_name": os.path.basename(file_path),
                        "content_hash": hashlib.sha256(content.encode()).hexdigest(),
                        "summary": f"MILESTONE: {os.path.basename(file_path)} Sealed" if is_seal else f"Evolutionary Shift in {os.path.basename(file_path)}",
                        "synapses": item.get('synapses', []),
                        "symbols": item.get('symbols', []),
                        "dx_seal": is_seal,
                        "sovereign_full_state": scrub_secrets(item.get('full_state')) if item.get('full_state') else None
                    }
                }
                threading.Thread(target=self.cloud_callback, args=(payload,), daemon=True).start()

# --- UTILITY FUNCTIONS ---
def scrub_secrets(text):
    """Remove potential secrets from text before uploading."""
    patterns = [
        (r'(api[_-]?key|token|secret|password|access[_-]?key|private[_-]?key|database[_-]?url|conn[_-]?str)\s*[=:]\s*[\'"]?([^\s\'"]+)', r'\1=***REDACTED***'),
        (r'Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Bearer ***REDACTED***'),
        (r'sb_publishable_[a-zA-Z0-9]{20,}', r'sb_publishable_***REDACTED***'),
        (r'gsk_[a-zA-Z0-9]{20,}', r'gsk_***REDACTED***'),
    ]
    for pattern, replacement in patterns:
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
    return text

def print_banner(email="Sovereign", plan="Identity Verified"):
    """Print welcome banner with user info."""
    print("\n" + "="*60)
    print(" DALEXOR MI : NEURAL INTELLIGENCE")
    print("="*60)
    print(f" User: {email}")
    print(f" Plan: {plan}")
    print("="*60 + "\n")


def interactive_verification(force_prompt=False):
    """Verify identity with the Global Brain using environment or interactive prompt."""
    global DX_API_KEY, DX_TEAM_SECRET
    if not sys.stdin.isatty(): return (DX_API_KEY, "System", "Automated")
    
    current_key = DX_API_KEY
    if not current_key or force_prompt:
        print("\n" + "="*60)
        print(" DALEXOR MI : SECURE HANDSHAKE")
        print("="*60)
        current_key = input("\n[*] Enter Sovereign API Key: ").strip()
        if not current_key: sys.exit(1)
        DX_API_KEY = current_key

    print("\n[*] Connecting to Global Brain...")
    try:
        import requests
        headers = {"X-DX-Key": current_key}
        response = requests.get(f"{CLOUD_URL}/validate", headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            user_data = data.get("user", {})
            email = user_data.get('email', 'Sovereign')
            display_plan = data.get("subscription", {}).get("display", "Identity Verified")
            
            # CRITICAL: Use personal_plan (user's own subscription) for vault gating.
            # access_tier (org-aware effective plan) is for feature flags only.
            personal_plan = (
                user_data.get("personal_plan")
                or data.get("subscription", {}).get("personal_plan")
                or user_data.get("plan", "free")
            ).lower()
            
            print(f"[+] Identity Confirmed: {email}")
            print(f"[*] Subscription: {display_plan}")

            # 🛡️ SOVEREIGN MODE ACTIVATION — strictly based on PERSONAL plan only.
            # DB internal plan codes: free/personal, users/hobby, standard(=Pro display), pro(=Expert display), enterprise(=Startup display), sovereign
            # Vault-eligible: pro (Expert), enterprise (Startup), sovereign — NOT standard (Pro display)
            sovereign_codes = ["pro", "professional", "expert", "enterprise", "startup", "sovereign"]
            restricted_codes = ["free", "personal", "users", "hobby", "standard"]
            
            is_sovereign_plan = any(c in personal_plan for c in sovereign_codes) and not any(c in personal_plan for c in restricted_codes)
            
            global DX_SOVEREIGN
            if is_sovereign_plan:
                DX_SOVEREIGN = True
                print(f"[*] Privacy Mode: ACTIVATED (End-to-End Encryption Enabled)")
                
                # 🔐 Prompt for Team Secret if not already set
                if not DX_TEAM_SECRET or force_prompt:
                    print("\n" + "="*60)
                    print(" NEURAL VAULT : E2EE TEAM SECRET")
                    print("="*60)
                    team_secret_input = input("\n[*] Enter Team Secret (E2EE Key): ").strip()
                    if team_secret_input:
                        DX_TEAM_SECRET = team_secret_input
                        print("[+] Team Secret configured for Neural Vault encryption.")
            else:
                DX_SOVEREIGN = False
            
            # Return personal_plan as the 3rd element so select_project gates vault correctly
            return (current_key, email, personal_plan)
        else:
            print(f"[!] Verification Failed: {response.json().get('error', 'Invalid Key')}")
            sys.exit(1)
    except Exception as e:
        print(f"[!] Error: {e}")
        sys.exit(1)

def save_to_env(key, project_id=None, project_name=None, team_secret=None):
    """Save configuration to global config file."""
    import json
    
    # Use global config directory
    config_dir = os.path.expanduser("~/.dalexor")
    config_file = os.path.join(config_dir, "config.json")
    
    # Create directory if it doesn't exist
    os.makedirs(config_dir, exist_ok=True)
    
    # Read existing config
    config = {}
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
        except:
            pass
    
    # Update with new values
    config['api_key'] = key
    if project_id:
        config['project_id'] = project_id
        config['last_project_id'] = project_id
    if project_name:
        config['project_name'] = project_name
    if team_secret:
        config['team_secret'] = team_secret
    
    # Save Sovereign status
    config['sovereign'] = str(DX_SOVEREIGN).lower()
    
    config['cloud_url'] = CLOUD_URL
    
    # Save config
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    print(f"[+] Configuration saved to {config_file}")

def select_project(key, plan="free"):
    """Fetch and select a project, pinning it on the server for stateless sessions."""
    import requests
    
    # Update global API key to match the one used in dx init
    global DX_API_KEY
    DX_API_KEY = key
    
    headers = {"X-DX-Key": key}
    print("\n[*] Fetching project blueprints...")
    try:
        proj_res = requests.get(f"{CLOUD_URL}/projects", headers=headers, timeout=10)
        project_id = None
        project_name = "Default"
        
        if proj_res.status_code == 200:
            projects = proj_res.json().get("projects", [])
            if projects:
                print(f"\n[?] Found {len(projects)} existing project universes:")
                for idx, p in enumerate(projects):
                    print(f"   {idx + 1}. {p['name']} ({p.get('status', 'active')})")
                print(f"   {len(projects) + 1}. [Create New Project]")
                
                choice = input("\n[>] Select Project: ").strip()
                try:
                    c_idx = int(choice) - 1
                    if 0 <= c_idx < len(projects):
                        project_id = projects[c_idx]["id"]
                        project_name = projects[c_idx]["name"]
                    else:
                        project_name = input("[>] Enter New Project Name: ").strip()
                except:
                    project_id = None 
                    project_name = input("[>] Enter New Project Name: ").strip()
            else:
                project_name = input("[>] No projects found. Enter Project Name: ").strip()
        
        if not project_id:
            create_res = requests.post(f"{CLOUD_URL}/projects", json={"name": project_name}, headers=headers, timeout=10)
            if create_res.status_code == 200:
                project_id = create_res.json().get("project", {}).get("id")
                print(f"[+] Project '{project_name}' created and assigned.")
        
        # 🌩️ PIN PROJECT ON SERVER (No local files!)
        requests.post(f"{CLOUD_URL}/select-project", json={"project_id": project_id}, headers=headers, timeout=10)
        os.environ["DX_PROJECT_ID"] = project_id
        os.environ["DX_PROJECT_NAME"] = project_name
        print(f"[+] Context Pinned to Cloud: {project_name}")

        # --- E2EE NEURAL VAULT KEY MANAGEMENT ---
        print("\n" + "-"*60)
        print(" NEURAL VAULT : END-TO-END ENCRYPTION")
        print("-"*60)
        
        # Vault-eligible internal DB codes: pro (Expert), enterprise (Startup), sovereign
        # NOT eligible: free, personal, users, hobby, standard (which displays as 'Pro')
        vault_codes = ["pro", "professional", "expert", "enterprise", "startup", "sovereign"]
        is_vault_eligible = any(p in plan.lower() for p in vault_codes) and not any(
            r in plan.lower() for r in ["free", "personal", "users", "hobby", "standard"]
        )
        is_restricted_plan = not is_vault_eligible
        if is_restricted_plan:
            print("[!] PLAN RESTRICTION: Neural Vault (E2EE) is an Expert/Sovereign feature.")
            print(f"[!] Your '{plan}' plan uses Standard Encryption (TLS/AES).")
        else:
            # Prioritize user-entered team secret, then fall back to server
            global DX_TEAM_SECRET
            if not DX_TEAM_SECRET:
                # Secrets come from server only if not manually entered
                all_proj_res = requests.get(f"{CLOUD_URL}/projects", headers=headers, timeout=10).json()
                selected_p = next((p for p in all_proj_res.get("projects", []) if p['id'] == project_id), {})
                team_secret = selected_p.get("team_secret")
                if team_secret:
                    DX_TEAM_SECRET = team_secret
                    os.environ["DX_TEAM_SECRET"] = team_secret
            else:
                # User manually entered the secret
                os.environ["DX_TEAM_SECRET"] = DX_TEAM_SECRET
            
            if DX_TEAM_SECRET:
                print(f"[*] Neural Vault Key active for this project (Cloud Sync).")
                
                # 🌩️ UPLOAD SECRET TO GLOBAL BRAIN (E2EE Handshake)
                try:
                    requests.post(f"{CLOUD_URL}/projects/{project_id}/secret", json={"secret": DX_TEAM_SECRET}, headers=headers, timeout=10)
                    print("[+] Neural Vault Handshake Complete: Cloud Sync Enabled.")
                except Exception as e:
                    print(f"[*] Warning: Key Sync delayed: {e}")
        
        print(f"[+] Project {project_name} Ready. CLI is operating in Stateless Cloud Mode.")
        
        # Save to .env file
        save_to_env(key, project_id, project_name, os.environ.get("DX_TEAM_SECRET"))

        return project_id, project_name
    except Exception as e:
        print(f"[!] Project Selection Error: {e}")
        return None, "Default"

# --- SENTINEL HANDLERS ---
class CodeChangeHandler(FileSystemEventHandler):
    def __init__(self, tx_memory):
        self.tx_memory = tx_memory
        self.last_hashes = self.load_hashes()
        self.content_cache = {}

    def load_hashes(self):
        """Load known file hashes to prevent redundant syncs."""
        path = os.path.join(".dalexor", "states.json")
        try:
            if os.path.exists(path):
                with open(path, 'r') as f:
                    return json.load(f).get("hashes", {})
        except: pass
        return {}

    def save_hashes(self):
        """Persist hashes to disk for future session continuity."""
        if not os.path.exists(".dalexor"):
            try: os.makedirs(".dalexor")
            except: pass
        path = os.path.join(".dalexor", "states.json")
        try:
            with open(path, 'w') as f:
                json.dump({"hashes": self.last_hashes, "ts": time.time()}, f)
        except: pass

    def on_modified(self, event): self._handle_event(event)
    def on_created(self, event): self._handle_event(event)

    def _handle_event(self, event):
        if event.is_directory or any(x in event.src_path for x in IGNORE_LIST): return
        
        # Normalize Windows paths to Forward Slashes for Lineage Parity
        src_path = event.src_path.replace('\\', '/')
        
        # Neural Pulse Feedback
        print(f"[*] Neural Pulse: {os.path.basename(src_path)} detected.")
        
        # Windows Grace Period: Let the IDE finish writing the file
        time.sleep(0.2)
        
        # Instant Presence report (Presence Parity)
        self.report_presence(src_path)
        # Debounce/Throttle at Sentinel level too
        self.process_change(src_path)

    def report_presence(self, file_path):
        import requests
        try:
            # Dynamically fetch key to ensure validity
            key = os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY") or DX_API_KEY
            project_id = os.getenv("DX_PROJECT_ID")
            if not key: return
            headers = {"X-DX-Key": key}
            # Silent fire-and-forget presence pulse
            requests.post(f"{CLOUD_URL}/presence", json={"file_path": file_path, "project_id": project_id}, headers=headers, timeout=1.0)
        except Exception as e:
            # Presence pulse is non-critical, but we log the debug signal
            logger.debug(f"Presence pulse failed: {e}")
            pass

    def extract_synapses(self, content, current_file_name="", project_catalog=None):
        """Atomic Synapse Engine V7: Tree-Sitter & Greedy Dispatcher."""
        if not content: return []
        found = set()
        ext = os.path.splitext(current_file_name)[1].lower()

        # 0. NATIVE PYTHON AST (Built-in)
        if ext == '.py':
            try:
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names: found.add(alias.name.split('.')[0])
                    elif isinstance(node, ast.ImportFrom):
                        if node.module: found.add(node.module.split('.')[0])
            except: pass

        # 1. TREE-SITTER RECOVERY (For other languages)
        elif TREE_SITTER_AVAILABLE:
            lang_map = {
                '.js': 'javascript', '.jsx': 'javascript',
                '.ts': 'typescript', '.tsx': 'tsx',
                '.go': 'go', '.rs': 'rust', '.rb': 'ruby',
                '.cpp': 'cpp', '.h': 'cpp', '.cs': 'c_sharp',
                '.java': 'java', '.php': 'php'
            }
            lang_name = lang_map.get(ext)
            if lang_name:
                try:
                    parser = get_parser(lang_name)
                    tree = parser.parse(bytes(content, "utf8"))
                    
                    # Custom Query for Imports/Requires
                    query_map = {
                        'javascript': '(import_statement source: (string) @src) (call_expression function: (identifier) @func arguments: (arguments (string) @src) (#eq? @func "require"))',
                        'typescript': '(import_statement source: (string) @src) (call_expression function: (identifier) @func arguments: (arguments (string) @src) (#eq? @func "require"))',
                        'tsx': '(import_statement source: (string) @src)',
                        'go': '(import_spec path: (string) @src)',
                        'rust': '(use_declaration argument: (use_path) @src)',
                        'php': '(include_expression path: (string) @src) (require_expression path: (string) @src)',
                    }
                    
                    query_str = query_map.get(lang_name)
                    if query_str:
                        language = get_language(lang_name)
                        query = language.query(query_str)
                        captures = query.captures(tree.root_node)
                        for node, tag in captures:
                            if tag == 'src':
                                name = node.text.decode('utf8').strip('\'"`').split('/')[-1]
                                if name: found.add(name)
                except Exception as e:
                    logger.debug(f"Tree-Sitter Parse Error for {current_file_name}: {e}")

        # 2. FALLBACK/REFINED REGEX (If Tree-Sitter failed or not available)
        if not found and ext in ['.js', '.ts', '.jsx', '.tsx', '.cs', '.cpp', '.h', '.java', '.go', '.rs', '.rb']:
            patterns = [
                r'import\s+.*?\s+from\s+[\'"](.*?)[\'"]',
                r'require\([\'"](.*?)[\'"]\)',
                r'export\s+.*?\s+from\s+[\'"](.*?)[\'"]',
                r'using\s+([\w\.]+);',
                r'#include\s+[<"](.*)[>"]',
                r'use\s+([\w:]+);'
            ]
            for p in patterns:
                for match in re.findall(p, content):
                    name = match.split('/')[-1].split('\\')[-1].split(':')[-1]
                    if name: found.add(name)

        # 3. HTML/WEB ANALYZER (New Sovereign Layer)
        elif ext == '.html':
            html_patterns = [
                r'src=["\'](.*?)["\']',
                r'href=["\'](.*?)["\']',
                r'action=["\'](.*?)["\']',
            ]
            for p in html_patterns:
                for match in re.findall(p, content):
                    # Robust path handling: Remove query params & hashes
                    clean_match = match.split('?')[0].split('#')[0]
                    # Get basename for catalog matching
                    name = clean_match.split('/')[-1].split('\\')[-1]
                    if name and '.' in name and len(name) > 2: 
                        found.add(name)

        # 4. UNIFIED CATALOG CROSS-CHECK (The Intelligence Layer)
        if project_catalog:
            # Strip comments before catalog matching to avoid "Comment Ghosts"
            clean_content = re.sub(r'//.*|/\*[\s\S]*?\*/|#.*|"""[\s\S]*?"""', '', content)
            tokens = set(re.findall(r'[A-Z][a-zA-Z0-9_]*|\b[a-zA-Z_]\w*\.[a-zA-Z0-9]+\b', clean_content))
            for t in tokens:
                if t in project_catalog and t != current_file_name:
                    found.add(t)

        system_exclude = {'os', 'sys', 'json', 'math', 'hashlib', 'time', 're', 'datetime', 'threading', 'logging', 'subprocess', 'ast', 'base64', 'secrets', 'react', 'vue', 'fs', 'path', 'http', 'https'}
        return [f for f in found if f.lower() not in system_exclude and f != current_file_name]

    def extract_symbols(self, content, file_path=""):
        """Sovereign Symbol Extraction: Multi-language semantic indexing."""
        if not content: return []
        symbols = set()
        ext = os.path.splitext(file_path)[1].lower()

        # 1. PYTHON NATIVE AST
        if ext == '.py':
            try:
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)): symbols.add(node.name)
            except: pass

        # 2. TREE-SITTER SYBMOL MINING
        elif TREE_SITTER_AVAILABLE:
            lang_map = {
                '.js': 'javascript', '.ts': 'typescript', '.go': 'go', 
                '.rs': 'rust', '.cpp': 'cpp', '.cs': 'c_sharp'
            }
            lang_name = lang_map.get(ext)
            if lang_name:
                try:
                    parser = get_parser(lang_name)
                    tree = parser.parse(bytes(content, "utf8"))
                    query_map = {
                        'javascript': '(function_declaration name: (identifier) @name) (class_declaration name: (identifier) @name)',
                        'typescript': '(function_declaration name: (identifier) @name) (class_declaration name: (identifier) @name) (interface_declaration name: (type_identifier) @name)',
                        'go': '(function_declaration name: (identifier) @name) (type_spec name: (type_identifier) @name)',
                        'rust': '(function_item name: (identifier) @name) (struct_item name: (type_identifier) @name) (trait_item name: (identifier) @name)',
                    }
                    query_str = query_map.get(lang_name)
                    if query_str:
                        language = get_language(lang_name)
                        query = language.query(query_str)
                        captures = query.captures(tree.root_node)
                        for node, tag in captures:
                            symbols.add(node.text.decode('utf8'))
                except: pass

        # 3. FALLBACK REGEX SUITE (Includes language-specific patterns)
        if not symbols:
            patterns = {
                '.js': r'(?:function|class|const|let|var)\s+([a-zA-Z_]\w*)',
                '.ts': r'(?:function|class|interface|type|enum|const)\s+([a-zA-Z_]\w*)',
                '.go': r'(?:func|type|struct|interface)\s+(?:\([^\)]+\)\s+)?([a-zA-Z_]\w*)',
                '.rs': r'(?:fn|mod|struct|enum|trait|type)\s+([a-zA-Z_]\w*)',
                '.cpp': r'(?:class|struct|void|[\w<>]+)\s+([a-zA-Z_]\w*)(?:\s*\(|\s*\{)'
            }
            p = patterns.get(ext)
            if p: symbols.update(re.findall(p, content))
            else: symbols.update(re.findall(r'(?:def|class|function|func|fn)\s+([a-zA-Z_]\w*)', content))
            
        return list(symbols)

    def process_change(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            curr_hash = hashlib.sha256(content.encode()).hexdigest()
            if self.last_hashes.get(file_path) == curr_hash: return
            
            prev_content = self.content_cache.get(file_path, "")
            diff_lines = []
            for line in difflib.unified_diff(prev_content.splitlines(), content.splitlines(), lineterm=''):
                if (line.startswith('+') or line.startswith('-')) and not (line.startswith('+++') or line.startswith('---')):
                    diff_lines.append(line)
            
            diff_text = "\n".join(diff_lines)
            # Entropy is based on INFO GAIN (the diff), but we capture the STATE (the content)
            entropy = SovereignEntropyEngine.calculate(diff_text if prev_content else content, file_path)
            
            self.last_hashes[file_path] = curr_hash
            self.content_cache[file_path] = content 
            self.save_hashes()            
            
            if entropy >= 0.1:
                synapses = self.extract_synapses(content, os.path.basename(file_path))
                symbols = self.extract_symbols(content, file_path)
                print(f"[+] Significant evolution in {os.path.basename(file_path)} (Entropy: {entropy})")
                # Visual Dashboard: Send the DIFF as 'content'
                # Sovereign Restore: Send the FULL FILE in metadata['sovereign_full_state']
                self.tx_memory.add(file_path, diff_text, entropy, synapses, symbols, full_state=content[:400000000])
            else:
                # Provide feedback even for low-value changes so user knows it's working
                print(f"[-] Filtered {os.path.basename(file_path)}: Significance {entropy} < 0.1 thresh.")
        except Exception as e:
            print(f"[!] Engine Error in {os.path.basename(file_path)}: {e}")

    def warm_up(self, root_dir):
        """Silently index all existing files to prevent 'Ghost Changes' on startup."""
        print("[*] Warming up Sentinel Cache...")
        count = 0
        for root, dirs, files in os.walk(root_dir):
            # Prune ignored directories
            dirs[:] = [d for d in dirs if d not in IGNORE_LIST and not d.startswith('.')]
            for file in files:
                if any(x in file for x in IGNORE_LIST) or file.startswith('.'): continue
                path = os.path.join(root, file).replace("\\", "/")
                try:
                    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    curr_hash = hashlib.sha256(content.encode()).hexdigest()
                    self.last_hashes[path] = curr_hash
                    self.content_cache[path] = content
                    count += 1
                except Exception as e:
                    print(f"[*] Warning: Skipping unreadable artifact {path}: {e}")
        print(f"[+] Indexed {count} existing artifacts.")

class DummyMCP:
    def tool(self): return lambda f: f
    def resource(self, path): return lambda f: f
    def prompt(self): return lambda f: f
    def run(self, transport): raise RuntimeError("FastMCP not initialized")

# --- MCP SERVER INITIALIZATION ---
try:
    from mcp.server.fastmcp import FastMCP
    mcp = FastMCP("DalexorGlobal")
except Exception as e:
    sys.stderr.write(f"[Dalexor MCP] FastMCP Init Failed: {e}\n")
    mcp = DummyMCP()

async def cloud_call(endpoint: str, payload: dict, timeout: int = 15):
    """Secure Async Handshake with Cloud Brain."""
    # Hot-reload config to stay in sync with CLI dx init
    cfg = load_global_config()
    api_key = os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY") or cfg.get("api_key")
    project_id = os.getenv("DX_PROJECT_ID") or cfg.get("project_id")
    team_secret = os.getenv("DX_TEAM_SECRET") or cfg.get("team_secret")

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            headers = {"X-DX-Key": api_key}
            payload["project_id"] = project_id
            res = await client.post(f"{CLOUD_URL}/tools/{endpoint}", json=payload, headers=headers)
            if res.status_code == 200:
                data = res.json()
                result = data.get("result", "No result returned.")
                # Auto-Decrypt if E2EE is active
                if isinstance(result, str) and "vault_" in result:
                    result = NeuralVault.unlock(result, DX_TEAM_SECRET)
                return result
            if res.status_code == 429:
                return f"⛔ LIMIT REACHED: Global Brain is resting. Wait an hour or upgrade for higher velocity."
            return f"Brain Error ({res.status_code}): {res.text[:200]}"
    except Exception as e:
        return f"Neural Disconnect: {e}"

@mcp.tool()
async def mcp_health_check() -> str:
    """Returns local agent status and connectivity to Global Brain."""
    # Hot-reload config to stay in sync with CLI dx init
    cfg = load_global_config()
    api_key = cfg.get("api_key") or os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY")
    project_id = cfg.get("project_id") or os.getenv("DX_PROJECT_ID")
    
    error_msg = ""
    usage_str = ""
    cloud_url = os.getenv("DALEXORMI_URL") or CLOUD_URL # CLOUD_URL is the default
    
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            res = await client.get(f"{cloud_url}/", headers={"X-DX-Key": api_key})
            cloud_status = "ONLINE" if res.status_code == 200 else f"ERROR ({res.status_code})"
            if res.status_code == 200:
                data = res.json()
                stats = data.get("usage_stats", {})
                if stats:
                    usage_str = f"\nAPI Usage: {stats.get('usage', 0)}/{stats.get('limit', 0)} requests this hour"
                    
                    # IP Limit Display
                    ip_data = stats.get("ip_usage", {})
                    if ip_data:
                        usage_str += f"\nIP Sharing: {ip_data.get('count', 1)}/{ip_data.get('limit', 1)} unique devices"

                    plan_name = stats.get("plan", "free").lower()
                    is_sovereign = any(p in plan_name for p in ["sovereign", "enterprise", "startup", "expert"])
                else:
                    is_sovereign = False
            else:
                error_msg = f" | Error: {res.text[:100]}"
                is_sovereign = False
    except Exception as e:
        cloud_status = "OFFLINE"
        error_msg = f" | Exception: {str(e)}"
        is_sovereign = False
    
    return f"Dalexor Local Agent: ACTIVE\nGlobal Brain: {cloud_status}{error_msg}\nURL: {cloud_url}\nAPI Key: {'Set' if api_key else 'Missing'}\nProject: {project_id}\nSovereign: {is_sovereign}{usage_str}"



@mcp.tool()
async def trace_dependency(symbol: str) -> str:
    """Impact Analysis: Find all files that import or call a specific symbol (function, class, variable)."""
    # Prefer Local Search first for speed
    local_files = []
    try:
        # Use '--' to stop flag parsing and treat sym as literal search string
        cmd = ["rg", "-l", "--", symbol, "."]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if proc.stdout:
            local_files = [f.strip() for f in proc.stdout.split('\n') if f.strip() and not any(x in f for x in IGNORE_LIST)]
    except Exception as e:
        print(f"[*] Local dependency trace restricted: {e}")

    cloud_data = await cloud_call("trace_dependency", {"symbol": symbol})
    if local_files:
        return f"**Local Workspace Mentions:**\n" + "\n".join(local_files) + f"\n\n**Cloud Synaptic Context:**\n{cloud_data}"
    return cloud_data






@mcp.tool()
async def find_definition(symbol: str) -> str:
    """Global Symbol Provenance: Find where a function, class, or variable is defined."""
    # Try local search first
    patterns = [rf"(async\s+)?def\s+{re.escape(symbol)}\b", rf"class\s+{re.escape(symbol)}\b", rf"function\s+{re.escape(symbol)}\b"]
    for p in patterns:
        try:
            # Use '--' to prevent flag injection
            cmd = ["rg", "-n", "--column", "-e", p, "--", "."]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
            if proc.stdout: return f"**Local Match:**\n{proc.stdout}"
        except Exception as e:
            logger.debug(f"Local ripgrep search failed for {symbol}: {e}")
            continue
    return await cloud_call("find_definition", {"symbol": symbol})

@mcp.tool()
async def get_atomic_diff(file_path: str) -> str:
    """Atomic Diffing: Replay exact code changes between last two versions of a file."""
    return await cloud_call("atomic_diff", {"file_path": file_path})

@mcp.tool()
async def get_dependency_topology(file_path: str) -> str:
    """Dependency Topology: Map structural relationships (imports/calls) for the target file."""
    return await cloud_call("dependency_topology", {"file_path": file_path})

@mcp.tool()
async def predict_conflicts(file_path: str) -> str:
    """Predictive Risk Analysis: Detect if a file was edited recently and analyze cross-team collision risks."""
    return await cloud_call("predict_conflicts", {"file_path": file_path})









# --- CLI COMMANDS ---

def dx_init():
    print("[*] Initializing Dalexor Project Memory...")
    # Stateless Init: Link to cloud project without writing local files
    key_tuple = interactive_verification(force_prompt=True)
    if key_tuple and key_tuple[0]:
        select_project(key_tuple[0], plan=key_tuple[2])
    
    print("[+] Project Initialized. CLI is linked to Cloud Session.")

def dx_sync(args=None, is_seal=False, message=None):
    """Deep Project Analysis: Ingest the current state of all files and map synapses."""
    global DX_API_KEY
    
    # Force fresh project lookup from server instead of stale env vars
    import requests
    headers = {"X-DX-Key": DX_API_KEY}
    project_id = None
    
    try:
        user_res = requests.get(f"{CLOUD_URL}/validate", headers=headers, timeout=10)
        if user_res.status_code == 200:
            last_project = user_res.json().get("user", {}).get("last_project_id")
            if last_project:
                project_id = last_project
                print(f"[+] Resumed Context: Project {project_id}")
            else:
                print("[!] No active project. Run 'dx init' first.")
                return
        else:
            print("[!] Authentication failed.")
            return
    except Exception as e:
        print(f"[!] Connection error: {e}")
        return

    print(f"[*] Analyzing files line-by-line for neural mapping into Project: {project_id}...")
    
    # Pre-calculate project catalog for greedy synapse matching
    PROJECT_CATALOG = set()
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in IGNORE_LIST and not d.startswith('.')]
        for f in files:
            if not any(x in f for x in IGNORE_LIST) and not f.startswith('.'):
                PROJECT_CATALOG.add(f)
                # Also index base names for languages like Python or Rust
                if '.' in f:
                    PROJECT_CATALOG.add(f.split('.')[0])
    
    def cloud_callback(payload):
        import requests
        import time
        
        # Auto-enable encryption if plan allows (Double check global flag)
        if DX_SOVEREIGN:
            payload["is_sovereign"] = True
            payload["request_server_encryption"] = True

        retries = 3
        for attempt in range(retries):
            try:
                res = requests.post(f"{CLOUD_URL}/ingest", json=payload, headers={"X-DX-Key": DX_API_KEY, "Content-Type": "application/json"}, timeout=30)
                if res.status_code == 429:
                    print(f"\n[!] Rate Limit Exceeded: Sync paused. Wait an hour or upgrade for higher velocity.")
                    sys.exit(0) # Stop sync immediately
                if res.status_code == 402:
                    print(f"\n[!] Quota Full: Sync aborted. You have reached your atom limit. Manage atoms at dalexor.com")
                    sys.exit(0)
                if res.status_code != 200:
                    print(f"[!] Server returned {res.status_code}: {res.text[:200]}")
                    return None
                return res.json()
            except requests.exceptions.Timeout:
                print(f"[!] Upload timed out after 30s (skipping file, continuing sync...)")
                return None
            except requests.exceptions.RequestException as e:
                if attempt < retries - 1:
                    wait_time = 2 * (attempt + 1)
                    print(f"[!] Connection glitch. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    print(f"[!] Upload failed after {retries} attempts: {str(e)}")
                    return None
            except Exception as e:
                print(f"[!] Critical Error: {str(e)}")
                return None

    def generate_smart_summary(content, filename):
        """Extract meaningful summary from content header or docstrings."""
        # 1. Try Local AI if available (Rich Summary)
        groq_key = os.getenv("GROQ_API_KEY")
        if groq_key:
            try:
                from groq import Groq
                client = Groq(api_key=groq_key)
                completion = client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=[
                        {"role": "system", "content": "You are Dalexor, a Sovereign Intelligence Detective. Analyze this evidence. Output a RICH, STRUCTURED summary using these tags: [LOGIC], [SYSTEM], [SECURITY]. Explain exactly WHAT THIS FILE IS FOR. Use sections 'NARRATIVE:' and 'SYMBOLS:'. Example: '[LOGIC] Core Logic NARRATIVE: This file provides the central authentication logic...'. Keep it precise but visually consistent with the dashboard."},
                        {"role": "user", "content": f"Explain what this file is for and analyze its purpose:\nFilename: {filename}\nContent:\n{content[:2500]}"}
                    ],
                    temperature=0.1
                )
                return completion.choices[0].message.content.strip()
            except Exception as e:
                # Log to stderr to avoid corrupting command output
                sys.stderr.write(f"[*] Intelligence Insight restricted: {e}\n")

        # 2. Heuristic Extraction (Fast & Private)
        ext = os.path.splitext(filename)[1].lower()
        
        # Python Docstrings
        if ext == '.py':
            match = re.search(r'^"""(.*?)"""', content, re.DOTALL)
            if match:
                return match.group(1).strip().split('\n')[0][:80]
            match = re.search(r"^'''(.*?)'''", content, re.DOTALL)
            if match:
                return match.group(1).strip().split('\n')[0][:80]
                
        # JS/TS Comments
        if ext in ['.js', '.ts', '.jsx', '.tsx']:
            match = re.search(r'/\*\*(.*?)\*/', content, re.DOTALL)
            if match:
                clean = re.sub(r'\s*\*\s*', ' ', match.group(1)).strip()
                return clean.split('.')[0][:80]
            # Single line comment at top
            match = re.search(r'^//\s*(.*)', content)
            if match:
                return match.group(1).strip()[:80]

        # HTML Title
        if ext == '.html':
            match = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE)
            if match:
                return f"Page: {match.group(1).strip()}"

        # Markdown Header
        if ext == '.md':
            match = re.search(r'^#\s+(.*)', content)
            if match:
                return f"Doc: {match.group(1).strip()}"

        # 3. Fallback Heuristics for Config/Scripts
        try:
            if filename == 'requirements.txt':
                lines = [l.strip() for l in content.splitlines() if l.strip() and not l.startswith('#')]
                if len(lines) > 3:
                     return f"[SYSTEM] Neural Evidence NARRATIVE: 12 core dependencies detected including {', '.join(lines[:3])}..."
                return f"[SYSTEM] Dependency Manifest NARRATIVE: {', '.join(lines)}"
                
            if filename == 'package.json':
                import json
                try:
                    pkg = json.loads(content)
                    deps = list(pkg.get('dependencies', {}).keys())
                    if deps:
                        return f"[SYSTEM] Sovereign Manifest NARRATIVE: Node Configuration for {pkg.get('name', 'Project')}. Deps: {', '.join(deps[:3])}"
                    return f"[SYSTEM] Node Config NARRATIVE: {pkg.get('name', 'Project')}"
                except Exception as e:
                    sys.stderr.write(f"[*] Heuristic Parse restricted for {filename}: {e}\n")

            if ext in ['.bat', '.sh']:
                # Extract first non-comment echo that isn't just "off" or "on"
                # Find all echos
                echos = re.findall(r'echo\s+(.*)', content, re.IGNORECASE)
                for e in echos:
                    clean = e.strip().strip('"').strip("'")
                    if clean.lower() not in ['off', 'on', '']:
                        return f"[LOGIC] Tactical Script NARRATIVE: {clean}"

            if ext == '.json':
                # Generic JSON summary
                return f"[SYSTEM] Secure Artifact NARRATIVE: Configuration data."
        except Exception as e:
            logger.debug(f"Smart summary generation failed for {filename}: {e}")
            pass

        return f"[SYSTEM] Sovereign Sync NARRATIVE: {filename}"

    tx = TransactionMemory(cloud_callback)
    handler = CodeChangeHandler(tx)
    
    EXTENSION_MAP = {
        '.md': 'document',
        '.txt': 'document',
        '.json': 'artifact',
        '.yaml': 'artifact',
        '.yml': 'artifact',
        '.py': 'code',
        '.js': 'code',
        '.ts': 'code',
        '.html': 'code',
        '.css': 'code',
        '.sh': 'code',
        '.bat': 'code',
        '.ps1': 'code'
    }

    count = 0
    synapse_count = 0
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in IGNORE_LIST and not d.startswith('.')]
        for file in files:
            if any(x in file for x in IGNORE_LIST) or file.startswith('.'): continue
            path = os.path.relpath(os.path.join(root, file), ".").replace("\\", "/")
            ext = os.path.splitext(file)[1].lower()
            atom_type = EXTENSION_MAP.get(ext, 'code')

            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Zero-Trust Deduplication: Check if content changed since last sync
                # We blend the secret into the hash so if the key changes, we force a re-upload!
                content_hash_input = content + (DX_TEAM_SECRET or "")
                curr_hash = hashlib.sha256(content_hash_input.encode()).hexdigest()
                
                # Check for FORCE flag or changed content
                force_sync = (args and hasattr(args, 'extra') and args.extra == "force")
                
                if not force_sync and handler.last_hashes.get(path) == curr_hash:
                    continue

                entropy = SovereignEntropyEngine.calculate(content, path)
                synapses = handler.extract_synapses(content, os.path.basename(path), PROJECT_CATALOG)
                symbols = handler.extract_symbols(content, path)
                synapse_count += len(synapses)
                
                # Direct upload for sync mode
                smart_summary = generate_smart_summary(content, os.path.basename(path))
                
                # Generate stable UUID for source_id based on file path to avoid duplicates on re-sync
                import uuid
                source_id_seed = f"{os.getenv('DX_PROJECT_ID') or 'NONE'}:{path}"
                source_id = str(uuid.uuid5(uuid.NAMESPACE_URL, source_id_seed))

                payload = {
                    "content": content[:400000000], 
                    "entropy_score": round(entropy, 2),
                    "atom_type": "evolution_event",
                    "source": "api",
                    "file_path": path, # Universal forward slashes
                    "file_name": os.path.basename(path),
                    "source_id": source_id,
                    "content_hash": curr_hash,
                    "synapses": synapses,
                    "symbols": symbols,
                    "is_sovereign": DX_SOVEREIGN,
                    "request_server_encryption": DX_SOVEREIGN, 
                    "is_encrypted": False, 
                    "project_id": os.getenv("DX_PROJECT_ID"), 
                    "project_name": os.getenv("DX_PROJECT_NAME") or "Default", 
                    "metadata": {
                        "file_path": path,
                        "file_name": os.path.basename(path),
                        "summary": smart_summary,
                        "synapses": synapses,
                        "content_hash": curr_hash,
                        "force": force_sync
                    }
                }
                
 
                api_res = cloud_callback(payload)
                if api_res:
                    handler.last_hashes[path] = curr_hash
                    handler.content_cache[path] = content
                    count += 1
                    
                    status = api_res.get("status")
                    if status == "skipped":
                        print(f"[-] Unchanged: {path}")
                    else:
                        print(f"[+] Indexed {atom_type}: {path} ({len(synapses)} synapses)")
                else:
                    print(f"[!] Failed: {path}")
                    
            except Exception as e:
                print(f"[!] Error syncing {path}: {e}")
                
    handler.save_hashes()
    if is_seal and count == 0:
        print("\n[!] No modifications detected since last sync. (Nothing to seal)")
    else:
        print(f"\n[+] Sync Complete! {count} artifacts analyzed. {synapse_count} synapses mapped.")




def dx_chat():
    global DX_API_KEY
    print("Ask anything about your project's memory.")
    print("Type 'exit' to quit.")
    print("="*60 + "\n")

    import requests

    def read_local_file(rel_path, cwd, max_chars=5000):
        """Read a file from disk using a relative path, strictly scoped to CWD."""
        # 🛡️ Resolve absolute paths and check bounds to prevent Path Traversal/LFI
        abs_cwd = os.path.abspath(cwd)
        # Normalize slashes cross-platform
        safe_path = os.path.abspath(os.path.join(cwd, *rel_path.split('/')))
        
        # 🚔 Block if the path is OUTSIDE the project directory
        if not safe_path.startswith(abs_cwd):
            logger.warning(f"Sovereign Shield: Blocked attempt to read outside workspace: {rel_path}")
            return None

        try:
            with open(safe_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read(max_chars)
        except (FileNotFoundError, PermissionError, IsADirectoryError):
            return None

    while True:
        try:
            p = input("[>] You: ").strip()
            if not p:
                continue
            if p.lower() in ['exit', 'quit', 'bye']:
                break

            headers = {"X-DX-Key": DX_API_KEY}
            project_id = os.getenv("DX_PROJECT_ID")
            cwd = os.getcwd()

            # --- PHASE 1: Cloud retrieval — find which files are relevant ---
            try:
                res1 = requests.post(
                    f"{CLOUD_URL}/query",
                    json={"query": p, "project_id": project_id},
                    headers=headers,
                    timeout=60
                )
            except requests.exceptions.Timeout:
                print("[!] Query timed out. Try again.\n")
                continue

            if res1.status_code == 401:
                print("[!] Error (401): Unauthorized. Your API Key might be invalid.\n")
                DX_API_KEY, _, _ = interactive_verification()
                continue
            if res1.status_code != 200:
                print(f"[!] Brain Error ({res1.status_code}): {res1.text}\n")
                continue

            data1 = res1.json()
            intel = data1.get("intelligence", {})
            signals = intel.get("signals", [])
            neighbors = intel.get("synaptic_neighborhood", [])
            all_sources = signals + neighbors

            # --- PHASE 2: Read actual local file content for top signals ---
            file_contexts = []
            for src in all_sources[:6]:  # Top 6 sources to stay within cloud token limits
                path = src.get("path", "")
                if not path:
                    continue
                raw = read_local_file(path, cwd)
                if raw:
                    file_contexts.append(f"=== FILE: {path} ===\n{raw}")

            if file_contexts:
                # Re-query cloud with actual file content embedded.
                # The cloud LLM answers from this real content — no hallucination possible.
                embedded_content = "\n\n".join(file_contexts)
                grounded_query = (
                    f"[ACTUAL FILE CONTENTS FROM PROJECT — USE ONLY THIS, DO NOT GUESS]\n"
                    f"{embedded_content}\n\n"
                    f"[QUESTION] {p}\n\n"
                    f"Answer strictly and only from the file contents above. "
                    f"If the answer is not present, say so clearly."
                )
                try:
                    res2 = requests.post(
                        f"{CLOUD_URL}/query",
                        json={"query": grounded_query, "project_id": project_id},
                        headers=headers,
                        timeout=60
                    )
                    if res2.status_code == 200:
                        answer = res2.json().get("context", "")
                        if answer:
                            print(f"[*] Brain: {answer}\n")
                        else:
                            print(f"[*] Brain: {data1.get('context', '...')}\n")
                    else:
                        # Phase 2 failed — fall back to phase 1 answer
                        print(f"[*] Brain: {data1.get('context', '...')}\n")
                except requests.exceptions.Timeout:
                    print(f"[*] Brain: {data1.get('context', '...')}\n")
            else:
                # No local files found — show original cloud answer
                print(f"[*] Brain: {data1.get('context', '...')}\n")

            # Show sources (file paths only, no verbose summaries)
            if all_sources:
                print("-" * 60)
                print(f"[*] Sources ({len(signals)} signals, {len(neighbors)} neural neighbors):")
                for s in signals:
                    print(f"  [SIGNAL] {s['path']}")
                for n in neighbors:
                    print(f"  [NEURAL] {n['path']}")
                print("-" * 60 + "\n")

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"[!] Connection Error: {e}\n")
            break


def dx_restore(intent: str):
    """Intent-Based Restore: Search for a conceptual state and apply the code locally."""
    print(f"[*] Navigating through Neural History for intent: '{intent}'...")
    
    # We call the MCP bridge tool mcp_restore_by_intent
    import asyncio
    res_json = asyncio.run(cloud_call("restore_by_intent", {"intent": intent}))
    
    try:
        import json
        res = json.loads(res_json)
        if not res.get("success"):
            print(f"[!] Restore Failed: {res.get('error')}")
            return

        file_path = res.get("file_path")
        content = res.get("content")
        summary = res.get("match_summary")

        if not file_path or not content:
            print("[!] Evolution state found, but data is incomplete.")
            return

        print(f"[+] Match Found: {summary}")
        
        # --- SMART PATH RESOLUTION ---
        target_file = file_path
        if not os.path.exists(target_file):
            base_name = os.path.basename(file_path)
            # Search for matching filename in current directory subtree
            print(f"[*] Original path '{file_path}' not found. Searching workspace...")
            found_paths = []
            for root, dirs, files in os.walk("."):
                # Filter out ignore list
                dirs[:] = [d for d in dirs if d not in [".git", "__pycache__", "venv", "node_modules"]]
                if base_name in files:
                    found_paths.append(os.path.join(root, base_name))
            
            if found_paths:
                if len(found_paths) == 1:
                    print(f"[*] Found matching local file: {found_paths[0]}")
                    target_file = found_paths[0]
                else:
                    print(f"[*] Multiple candidates found for '{base_name}':")
                    for i, p in enumerate(found_paths):
                        print(f"  {i+1}. {p}")
                    choice = input(f"[?] Select target file index (1-{len(found_paths)}) or 'n' to use original: ").strip()
                    if choice.isdigit() and 1 <= int(choice) <= len(found_paths):
                        target_file = found_paths[int(choice)-1]
        
        # --- CONTENT PREVIEW ---
        lines = content.splitlines()
        preview_len = min(len(lines), 5)
        print("\n" + "-"*40)
        print(f" CONTENT PREVIEW ({target_file}):")
        print("-"*40)
        for i in range(preview_len):
            print(f" {i+1} | {lines[i]}")
        if len(lines) > preview_len:
            print(f" ... ({len(lines) - preview_len} more lines)")
        print("-"*40 + "\n")

        if any(line.startswith(('+', '-')) for line in lines[:20]) and len(lines) < 50:
             print("⚠️  WARNING: The detected content looks like a DIFF or a SNIPPET rather than a full file.")

        confirm = input(f"[?] Apply restoration to '{target_file}'? (y/N): ").lower()
        if confirm == 'y':
            try:
                # Ensure directory exists
                os.makedirs(os.path.dirname(os.path.abspath(target_file)), exist_ok=True)
                with open(target_file, "w", encoding="utf-8") as f:
                    f.write(content)
                print(f"[+] Time Travel Successful: {target_file} has been restored to its conceptual state.")
            except Exception as e:
                print(f"[!] Disk Write Error: {e}")
        else:
            print("[*] Restoration aborted.")

    except Exception as e:
        print(f"[!] Neural Parsing Error: {e}")
        if 'res_json' in locals():
            print(f"[*] Raw Result: {res_json[:500]}...")

def run_agent():
    global DX_API_KEY
    import sys
    # Universal Case-Insensitivity fix
    if len(sys.argv) > 1:
        valid_cmds = ["init", "watch", "chat", "sync", "restore", "mcp", "tail"]
        if sys.argv[1].lower() in valid_cmds:
            sys.argv[1] = sys.argv[1].lower()

    parser = argparse.ArgumentParser(description="Dalexor MI Sovereign CLI")
    parser.add_argument("command", nargs="?", default="init")
    parser.add_argument("extra", nargs="?") # For file paths or messages
    args = parser.parse_args()

    # Manual Choice Validation (Advertised: init, watch, chat, sync, restore)
    advertised = ["init", "watch", "chat", "sync", "restore"]
    hidden = ["mcp", "tail"]
    if args.command not in advertised + hidden:
        parser.error(f"argument command: invalid choice: '{args.command}' (choose from {', '.join([repr(c) for c in advertised])})")


    # Step 1: Handle Initialization separately (forces prompt)
    if args.command == "init": 
        dx_init()
        return

    # Step 2: Ensure Auth & Get Plan (for non-init commands)
    if args.command == "mcp" and not sys.stdin.isatty():
        # Non-blocking auth check for headless MCP
        cfg = load_global_config()
        DX_API_KEY = os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY") or cfg.get("api_key")
        key_tuple = (DX_API_KEY, "Sovereign Agent", "Headless")
    else:
        # Normal Auth for interactive commands
        key_tuple = interactive_verification()
        if not key_tuple or not key_tuple[0]:
            print("[!] Error: Valid API Key required.")
            sys.exit(1)
        DX_API_KEY = key_tuple[0]
        # Only print banner for interactive commands (not MCP)
        if args.command != "mcp":
            print_banner(key_tuple[1], key_tuple[2])

    # Team Tail Handler (SSE Stream)
    if args.command == "tail":
        print(f"[*] Navigating through Neural Streams for Project Universe...")
        import requests, json
        my_email = key_tuple[1]
        try:
            res = requests.get(f"{CLOUD_URL}/tail", headers={"X-DX-Key": DX_API_KEY}, stream=True, timeout=None)
            if res.status_code == 200:
                print("[+] Connection Established. Monitoring project collisions...")
                for line in res.iter_lines():
                    if not line: continue
                    decoded = line.decode('utf-8')
                    if decoded.startswith('data: '):
                        event = json.loads(decoded[6:])
                        if event.get('type') == 'presence':
                            e_data = event.get('data', {})
                            if e_data.get('user') != my_email:
                                print(f" \033[93m⚡ [TEAM ACTIVITY]\033[0m {e_data.get('user')} is touching \033[1m{e_data.get('file')}\033[0m")
            else:
                print(f"[!] Stream Error: {res.status_code} - {res.text}")
        except KeyboardInterrupt:
            print("\n[*] Monitoring Stopped.")
        except Exception as e:
            print(f"[!] Transmission Error: {e}")
        return

    if args.command == "chat": dx_chat(); return
    if args.command == "restore":
        if not args.extra:
            print("[!] Error: You must provide an intent description. (e.g. dx restore 'error handling')")
            return
        dx_restore(args.extra); return

    # Pass args to dx_sync implicitly by making it global or passing it (easier to use global args in this structure)
    if args.command == "sync": dx_sync(args); return

    # Watchdog & Sentinel
    def push_to_cloud(payload):
        import requests
        try:
            summary = payload.get('metadata', {}).get('summary', 'Evolution')
            
            # Inject Project Metadata
            project_id = os.getenv("DX_PROJECT_ID")
            if not project_id:
                print(f"[!] Critical Alert: Intelligence push aborted. No project context active. Run 'dx init'.")
                return

            payload["project_id"] = project_id
            payload["project_name"] = os.getenv("DX_PROJECT_NAME") or "Unnamed Project"
            payload["is_sovereign"] = DX_SOVEREIGN
            
            # 🔐 Preserve is_encrypted flag if already set (e.g., by dx seal)
            # Don't overwrite it - the content is already encrypted
            if "is_encrypted" not in payload:
                payload["is_encrypted"] = False
            
            print(f"[*] Uploading '{summary}' to Project '{payload['project_name']}'...")
            res = requests.post(f"{CLOUD_URL}/ingest", json=payload, headers={"X-DX-Key": DX_API_KEY}, timeout=60)
            if res.status_code == 200:
                print(f"[+] Synced: {res.json().get('ai_insight', 'Indexed')}")
            elif res.status_code == 429:
                print(f"[!] Rate Limit Exceeded: Your plan is currently throttled. Upgrade to Sovereign for near-unlimited velocity.")
            elif res.status_code == 402:
                print(f"[!] Quota Full: You have reached your Intelligence Atom limit. Please upgrade or manage your atoms at 'dalexor.com'")
            else:
                print(f"[!] Handshake Refused: {res.status_code} - {res.text}")
        except Exception as e: 
            print(f"[!] Transmission Error: {e}")

    tx = TransactionMemory(push_to_cloud)
    handler = CodeChangeHandler(tx)
    handler.warm_up(".")
    observer = Observer()
    observer.schedule(handler, ".", recursive=True)
    observer.start()

    if args.command == "watch":
        print(f"[*] Telescope Sentinel Active in {os.getcwd()}. Press Ctrl+C to stop.")
        print("\n" + "-"*60)
        print(" MANUAL TRIGGER: THE 'S' KEY")
        print("-"*60)
        print(" While dx watch is running, you have a 'tactical trigger':")
        print("\n [Press S] (or k): Immediately flush all pending changes and")
        print(" tag them with Maximum Entropy (10.0), signaling a milestone.")
        print("\n [Bypass Coalescence]: A manual seal bypasses the 20-minute")
        print(" window, forcing the creation of a fresh, stable version.")
        print("-"*60 + "\n")
        
        # Keyboard Listener for sealing milestones
        def kbd_loop():
            try:
                if os.name == 'nt':
                    import msvcrt
                    while True:
                        if msvcrt.kbhit():
                            ch = msvcrt.getch().decode('utf-8').lower()
                            if ch in ['s', 'k', '\x10']: # S, K, or Ctrl+P (approx)
                                tx.flush_all()
                        time.sleep(0.1)
                else:
                    import select
                    import termios
                    import tty
                    def getch():
                        fd = sys.stdin.fileno()
                        old_settings = termios.tcgetattr(fd)
                        try:
                            tty.setraw(sys.stdin.fileno())
                            ch = sys.stdin.read(1)
                        finally:
                            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                        return ch
                    while True:
                        if select.select([sys.stdin], [], [], 0.1)[0]:
                            ch = getch().lower()
                            if ch in ['s', 'k', '\x10']:
                                tx.flush_all()
                        time.sleep(0.1)
            except Exception as e:
                print(f"[!] Keyboard Sentinel Activation Error: {e}")

        if sys.stdin.isatty():
            threading.Thread(target=kbd_loop, daemon=True).start()

        # Team Presence Monitor (Real-time Collision Awareness)
        def team_monitor():
            import requests, json
            my_email = key_tuple[1]
            project_id = os.getenv("DX_PROJECT_ID")
            try:
                # Use stream=True to keep connection open (SSE)
                res = requests.get(f"{CLOUD_URL}/tail", headers={"X-DX-Key": DX_API_KEY}, stream=True, timeout=None)
                if res.status_code == 200:
                    for line in res.iter_lines():
                        if not line: continue
                        decoded = line.decode('utf-8')
                        if decoded.startswith('data: '):
                            event = json.loads(decoded[6:])
                            if event.get('type') == 'presence':
                                e_data = event.get('data', {})
                                # Filter for same project, different user
                                if e_data.get('project_id') == project_id and e_data.get('user') != my_email:
                                    print(f" \033[93m⚡ [TEAM ACTIVITY]\033[0m {e_data.get('user')} is touching \033[1m{e_data.get('file')}\033[0m")
            except: pass

        threading.Thread(target=team_monitor, daemon=True).start()

        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            print("[*] Watcher Stopped by User.")
        finally:
            observer.stop()
            observer.join()

    if args.command == "mcp":
        # Start MCP server - this will block until the process is killed
        # transport='stdio' is used for IDE integrations (Cursor, etc.)
        mcp.run(transport='stdio')
        # Ensure we cleanup observer if mcp.run ever returns
        observer.stop()
        observer.join()


def extract_outline(content: str, file_path: str) -> str:
    """Extracts a skeletal outline of a file (Imports, Classes, Functions, Decorators) to save tokens."""
    import ast, os, re
    ext = os.path.splitext(file_path)[1].lower()
    
    # 🐍 Python (AST Based - Precise)
    if ext == '.py':
        try:
            tree = ast.parse(content)
            lines = []
            for node in ast.iter_child_nodes(tree):
                # Imports
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    try: lines.append(ast.unparse(node))
                    except: pass
                # Classes
                elif isinstance(node, ast.ClassDef):
                    # Class Decorators
                    for dec in node.decorator_list:
                        try: lines.append(f"@{ast.unparse(dec)}")
                        except: pass
                    # Class Definition
                    bases = f"({', '.join([ast.unparse(b) for b in node.bases])})" if node.bases else ""
                    lines.append(f"class {node.name}{bases}:")
                    # Scan class body for methods
                    for sub in node.body:
                        if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            for sdec in sub.decorator_list:
                                try: lines.append(f"    @{ast.unparse(sdec)}")
                                except: pass
                            prefix = "async " if isinstance(sub, ast.AsyncFunctionDef) else ""
                            # Extract arguments safely
                            args = ast.unparse(sub.args) if hasattr(ast, 'unparse') else "..."
                            lines.append(f"    {prefix}def {sub.name}({args}): ...")
                # Top-level Functions
                elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    for dec in node.decorator_list:
                        try: lines.append(f"@{ast.unparse(dec)}")
                        except: pass
                    prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
                    args = ast.unparse(node.args) if hasattr(ast, 'unparse') else "..."
                    lines.append(f"{prefix}def {node.name}({args}): ...")
            return "\n".join(lines) if lines else "[Empty or No Structural Nodes found]"
        except Exception as e:
            return f"[AST Parsing Failed: {e}]"

    # 🌐 Generic Fallback (Regex based for JS, TS, Go, etc.)
    patterns = [
        (r'import\s+.*', 'import'),
        (r'export\s+(?:async\s+)?(?:function|class|const|let|var)\s+\w+', 'export'),
        (r'(?:async\s+)?function\s+(\w+)\s*\(', 'function'),
        (r'class\s+(\w+)\s*', 'class'),
        (r'type\s+(\w+)\s*=', 'type'),
        (r'interface\s+(\w+)\s*', 'interface')
    ]
    
    extracted = []
    lines = content.splitlines()
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith(('//', '#', '/*')): continue
        for p, label in patterns:
            if re.search(p, stripped):
                extracted.append(stripped)
                break
    
    return "\n".join(extracted) if extracted else "[No distinct structural patterns detected]"


@mcp.tool()
async def get_structural_outline(file_path: str):
    """Returns a 'skeleton' of a file (Imports, Class names, Function signatures, and Decorators) to save context tokens."""
    # 1. Try Local First for speed and privacy
    full_path = os.path.abspath(file_path).replace("\\", "/")
    if os.path.exists(full_path):
        try:
            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            outline = extract_outline(content, file_path)
            return json.dumps({
                "success": True,
                "file_path": file_path,
                "source": "local",
                "outline": outline
            })
        except Exception as e:
            pass

    # 2. Fallback to Cloud if local file missing or unreadable
    # The Brain contains the atoms/synapses ingested during sync!
    return await cloud_call("get_structural_outline", {"file_path": file_path})


@mcp.tool()
async def diff_evolution_snapshots(file_path: str, limit: int = 5):
    """Provides a list of historical snapshots and conceptual shifts for a file (Database Query)."""
    return await cloud_call("diff_evolution_snapshots", {"file_path": file_path, "limit": limit})


@mcp.tool()
async def neural_search(query: str):
    """Semantic Search: Find relevant code or architecture patterns based on meaning."""
    return await cloud_call("neural_search", {"query": query})

@mcp.tool()
async def trace_logic_heritage(file_path: str):
    """Ancestry Shield: Trace the historical development and reasoning of a code artifact."""
    return await cloud_call("trace_logic_heritage", {"file_path": file_path})



if __name__ == "__main__":
    run_agent()

