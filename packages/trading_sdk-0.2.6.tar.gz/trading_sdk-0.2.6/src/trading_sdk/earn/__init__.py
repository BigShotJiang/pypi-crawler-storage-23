from .instruments import Instruments

class Earn(Instruments):
  ...