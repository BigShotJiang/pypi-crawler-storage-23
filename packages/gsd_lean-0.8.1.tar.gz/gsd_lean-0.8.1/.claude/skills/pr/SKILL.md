---
description: Create a GitHub PR with pre-computed context
argument-hint: [additional context]
disable-model-invocation: true
allowed-tools: Bash(git:*), Bash(gh:*)
---

## Current Context

**Branch:** !`git branch --show-current`

**Remote tracking:**
```
!`git status -sb | head -1`
```

**Remote branches not merged into main:**
```
!`git branch -r --no-merged origin/main 2>/dev/null | grep -v HEAD`
```

**Commits since main:**
```
!`git log main..HEAD --oneline 2>/dev/null || git log origin/main..HEAD --oneline 2>/dev/null || echo "Could not determine commits since main"`
```

**Files changed vs main:**
```
!`git diff main...HEAD --stat 2>/dev/null || git diff origin/main...HEAD --stat 2>/dev/null || echo "Could not determine diff"`
```

**Unpushed commits:**
```
!`git log @{upstream}..HEAD --oneline 2>/dev/null || echo "Branch not tracking remote"`
```

## Instructions

Based on the context above:

1. **Check branch**: If on `main`, warn user and ask to create feature branch first.
2. **Determine base branch**:
   - Check "Remote branches not merged into main" above for potential base branches
   - For each candidate (strip `origin/` prefix), check if it's an ancestor of HEAD:
     `git merge-base --is-ancestor origin/<branch> HEAD && echo "is ancestor"`
   - If a branch IS an ancestor and exists on remote, use it as `--base <branch>`
   - Otherwise default to `main`
3. If there are unpushed commits, push to remote first: `git push -u origin <branch>`
4. **Read the PR template** at `.github/pull_request_template.md` and create the PR body following its structure exactly
5. If provided, take the additional context from user into account. Provided context: "$ARGUMENTS"
6. Create the PR: `gh pr create --base <base-branch> --title "..." --body "..."`
7. Return the PR URL when done
