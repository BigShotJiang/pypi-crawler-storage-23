---
description: Squash merge a GitHub PR and clean up local branch
argument-hint: <PR-number>
disable-model-invocation: true
allowed-tools: Bash(git:*), Bash(gh:*)
---

## Current Context

**Current branch:** !`git branch --show-current`

**All worktrees:**
```
!`git worktree list`
```

**PR details:**
```
!`gh pr view $1 --json title,body,baseRefName,headRefName,commits,state`
```

**CI status:**
```
!`gh pr checks $1 --json name,state,description`
```

## Instructions

Based on the context above:

0. **Detect worktree context**:
   - If PR's headRefName matches current branch → proceed normally
   - If headRefName exists in another worktree → merge remotely, skip local checkout/cleanup, inform user
   - If headRefName doesn't exist locally → merge via `gh pr merge`, skip local branch deletion

1. **Verify PR state**: Ensure PR #$1 is open and mergeable
   - If the PR has actions that have failed, inform the user about this and ask for verification before proceeding
2. **Handle dependent PRs**: Before merging, find any open PRs targeting the branch being merged
   - Run: `gh pr list --base <headRefName> --state open --json number,title`
   - If dependent PRs exist:
     - Inform user which PRs will be re-targeted
     - Re-target each to baseRefName: `gh pr edit <number> --base <baseRefName>`
   - This prevents GitHub from auto-closing them when the branch is deleted
3. **Squash merge**: Use `gh pr merge $1 --squash --delete-branch` with an appropriate commit message
   - Title: Use PR title
   - Body: Summarize the PR changes concisely (from PR body/commits)
   - End with the standard Claude Code footer
4. **On successful merge**:
   - Checkout the target branch (baseRefName from PR)
   - Pull latest changes
   - Delete the local branch if it still exists (headRefName from PR)
5. **Report**: Confirm merge success and cleanup

If the PR is not mergeable (failed checks, conflicts, already merged), inform the user.
