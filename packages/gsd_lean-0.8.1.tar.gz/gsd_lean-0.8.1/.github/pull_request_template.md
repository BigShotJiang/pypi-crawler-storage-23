# Description

Please provide a clear description of the changes in this PR.

## Type of Change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Refactoring (no functional changes)
- [ ] Configuration/tooling change

# Testing

How have these changes been tested?

- [ ] Manual testing performed
- [ ] Automated tests added/updated

# Code Quality Checklist

- [ ] `make pre-commit` passes (ruff, mypy, file checks)
- [ ] `make run-tests` passes (90% coverage required)
- [ ] Updated documentation (if applicable)

# CI Status

All CI checks must pass before merging:
- Lint (pre-commit on Python 3.14)
- Tests (pytest on Python 3.12–3.14)
- Coverage (combined, minimum 90%)

# Additional Notes

<!-- Any additional context, breaking changes, migration notes, or related issues/PRs -->
