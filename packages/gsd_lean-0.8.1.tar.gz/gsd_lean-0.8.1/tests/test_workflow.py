"""Tests for the workflow engine module."""

import re
from unittest.mock import patch

import pytest

from gsd_lean.state.planning import CYCLE_ARCHIVE_DIR, CYCLE_DIR, CYCLE_FILES, PHASES, PLANNING_DIR, init_planning, write_state
from gsd_lean.workflow.engine import (
    VALID_TRANSITIONS,
    PreconditionError,
    check_all_tasks_done,
    check_not_on_default_branch,
    check_plan_verified,
    check_requirements_populated,
    transition,
)

_POPULATED_REQUIREMENTS = """\
# Requirements

> Captured during the discuss phase. Handed to /plan for task decomposition.
> This document must be self-contained — a fresh session reads only this + DECISIONS.md + PROJECT.md.

## User Intent

Build a widget system for managing reusable UI components.

## Motivation

Users need a way to compose and reuse UI elements across pages.

## Goals

- Support CRUD operations for widgets
- Provide a CLI for widget management

## Non-Goals

- No drag-and-drop editor
- No widget marketplace

## Functional Requirements

- Widget CRUD operations
- Widget versioning

## Affected Files

| File | Action | Description |
|------|--------|-------------|
| `src/widget.py` | Create | Core widget module |
| `tests/test_widget.py` | Create | Widget tests |

## Key Interfaces

WidgetManager class with create/read/update/delete methods.

## Edge Cases & Error Handling

- Duplicate widget names return an error
- Deleting a widget in use raises a warning

## Testing Strategy

Unit tests for all CRUD operations. Integration test for CLI commands.

## Non-Functional Requirements

- 90% test coverage
- Sub-100ms response time for CRUD operations
"""

_VERIFIED_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 1
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create widget module | `src/widget.py` | unit tests pass |
| T-002 | 1 | done | Add widget CLI | `src/cli.py` | CLI tests pass |

## Task Details

### T-001: Create widget module
...
"""

_DRAFT_PLAN = """\
# Plan

> **Status:** draft
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 1
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | pending | Create widget module | `src/widget.py` | unit tests pass |

## Task Details

### T-001: Create widget module
...
"""

_PARTIAL_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 2
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create widget module | `src/widget.py` | unit tests pass |
| T-002 | 2 | pending | Add widget CLI | `src/cli.py` | CLI tests pass |
| T-003 | 2 | in-progress | Add widget tests | `tests/test_widget.py` | tests pass |

## Task Details

### T-001: Create widget module
...
"""


def _setup_project(tmp_path, phase='discuss'):
    """Initialize .planning/ and optionally set a specific phase."""
    init_planning(tmp_path)
    if phase != 'discuss':
        write_state(tmp_path, phase)


def _populate_requirements(tmp_path):
    """Write a REQUIREMENTS.md with no template markers."""
    (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').write_text(_POPULATED_REQUIREMENTS)


def _write_plan(tmp_path, content):
    """Write a PLAN.md to the cycle/ directory."""
    (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').write_text(content)


class TestTransitionHappyPaths:
    """Tests for valid phase transitions."""

    def test_discuss_to_plan(self, tmp_path):
        """Test happy path: discuss -> plan transition works."""
        _setup_project(tmp_path, 'discuss')
        _populate_requirements(tmp_path)
        result = transition(tmp_path, 'plan')
        assert result == 'plan'
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`plan`' in content

    def test_plan_to_execute(self, tmp_path):
        """Test happy path: plan -> execute with verified plan."""
        _setup_project(tmp_path, 'plan')
        _write_plan(tmp_path, _VERIFIED_PLAN)
        result = transition(tmp_path, 'execute')
        assert result == 'execute'

    def test_execute_to_verify(self, tmp_path):
        """Test happy path: execute -> verify."""
        _setup_project(tmp_path, 'execute')
        result = transition(tmp_path, 'verify')
        assert result == 'verify'

    def test_verify_to_execute(self, tmp_path):
        """Test back to execute when tasks remain."""
        _setup_project(tmp_path, 'verify')
        _write_plan(tmp_path, _VERIFIED_PLAN)
        result = transition(tmp_path, 'execute')
        assert result == 'execute'

    def test_verify_to_complete(self, tmp_path):
        """Test complete when all tasks done."""
        _setup_project(tmp_path, 'verify')
        _write_plan(tmp_path, _VERIFIED_PLAN)
        result = transition(tmp_path, 'complete')
        assert result == 'complete'

    def test_complete_to_discuss(self, tmp_path):
        """Test new cycle via complete -> discuss."""
        _setup_project(tmp_path, 'complete')
        result = transition(tmp_path, 'discuss')
        assert result == 'discuss'

    def test_plan_to_discuss(self, tmp_path):
        """Test back to discuss (rejected plan)."""
        _setup_project(tmp_path, 'plan')
        result = transition(tmp_path, 'discuss')
        assert result == 'discuss'


class TestTransitionValidation:
    """Tests for transition validation and error handling."""

    def test_invalid_transition(self, tmp_path):
        """Test that discuss -> execute raises ValueError."""
        _setup_project(tmp_path, 'discuss')
        with pytest.raises(ValueError, match='Cannot transition'):
            transition(tmp_path, 'execute')

    def test_invalid_phase_name(self, tmp_path):
        """Test that 'foo' raises ValueError."""
        _setup_project(tmp_path)
        with pytest.raises(ValueError, match='Invalid phase'):
            transition(tmp_path, 'foo')

    def test_missing_state_file(self, tmp_path):
        """Test FileNotFoundError if STATE.md absent."""
        with pytest.raises(FileNotFoundError, match='not found'):
            transition(tmp_path, 'discuss')


class TestTransitionIdempotent:
    """Tests for self-transitions (idempotent no-ops)."""

    def test_discuss_to_discuss(self, tmp_path):
        """Test discuss -> discuss is a no-op (no error)."""
        _setup_project(tmp_path, 'discuss')
        result = transition(tmp_path, 'discuss')
        assert result == 'discuss'

    def test_plan_to_plan(self, tmp_path):
        """Test plan -> plan is a no-op (no error)."""
        _setup_project(tmp_path, 'plan')
        result = transition(tmp_path, 'plan')
        assert result == 'plan'


class TestTransitionStateUpdates:
    """Tests for STATE.md updates after transition."""

    def test_updates_state_md(self, tmp_path):
        """Test STATE.md phase line updated after transition."""
        _setup_project(tmp_path, 'discuss')
        _populate_requirements(tmp_path)
        transition(tmp_path, 'plan')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`plan`' in content
        assert '`discuss`' not in content

    def test_appends_history(self, tmp_path):
        """Test history table gets new row with timestamp."""
        _setup_project(tmp_path, 'discuss')
        _populate_requirements(tmp_path)
        transition(tmp_path, 'plan', note='Starting planning')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '| plan | Starting planning |' in content
        assert re.search(r'\| \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z \|', content)

    def test_idempotent_no_state_change(self, tmp_path):
        """Test self-transition does not modify STATE.md."""
        _setup_project(tmp_path, 'discuss')
        content_before = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        transition(tmp_path, 'discuss')
        content_after = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert content_before == content_after


class TestTransitionForce:
    """Tests for --force flag behavior."""

    def test_force_bypasses_precondition(self, tmp_path):
        """Test --force skips precondition checks."""
        _setup_project(tmp_path, 'discuss')
        # Even without populated requirements, --force should succeed
        result = transition(tmp_path, 'plan', force=True)
        assert result == 'plan'

    def test_force_invalid_transition_still_fails(self, tmp_path):
        """Test that --force does NOT bypass invalid transition validation."""
        _setup_project(tmp_path, 'discuss')
        with pytest.raises(ValueError, match='Cannot transition'):
            transition(tmp_path, 'execute', force=True)


class TestValidTransitions:
    """Tests for the VALID_TRANSITIONS constant."""

    def test_all_phases_have_transitions(self):
        """Test that every phase has an entry in VALID_TRANSITIONS."""
        for phase in PHASES:
            assert phase in VALID_TRANSITIONS

    def test_self_transitions_allowed(self):
        """Test that every phase allows self-transition."""
        for phase, targets in VALID_TRANSITIONS.items():
            assert phase in targets, f'{phase} does not allow self-transition'


class TestPreconditionRequirementsPopulated:
    """Tests for check_requirements_populated precondition."""

    def test_pass_when_populated(self, tmp_path):
        """Test that populated REQUIREMENTS.md passes the check."""
        _setup_project(tmp_path)
        _populate_requirements(tmp_path)
        assert check_requirements_populated(tmp_path) is None

    def test_fail_user_intent_marker(self, tmp_path):
        """Test that template '(not yet defined)' in User Intent fails."""
        _setup_project(tmp_path)
        # Default template has '(not yet defined)' — no changes needed
        error = check_requirements_populated(tmp_path)
        assert error is not None
        assert 'template placeholders' in error

    def test_fail_functional_marker(self, tmp_path):
        """Test that template '(none yet)' in Functional Requirements fails."""
        _setup_project(tmp_path)
        content = (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').read_text()
        # Remove the User Intent marker but keep the functional one
        content = content.replace('(not yet defined)', 'Build a widget')
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').write_text(content)
        error = check_requirements_populated(tmp_path)
        assert error is not None
        assert 'template placeholders' in error

    def test_fail_affected_files_marker(self, tmp_path):
        """Test that Affected Files table marker '| (none yet) | | |' fails."""
        _setup_project(tmp_path)
        # Write content with text markers cleared but table marker remaining
        content = _POPULATED_REQUIREMENTS.replace(
            '| `src/widget.py` | Create | Core widget module |\n| `tests/test_widget.py` | Create | Widget tests |',
            '| (none yet) | | |',
        )
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').write_text(content)
        error = check_requirements_populated(tmp_path)
        assert error is not None
        assert 'template placeholders' in error

    def test_transition_blocked_by_precondition(self, tmp_path):
        """Test that discuss -> plan is blocked when requirements have markers."""
        _setup_project(tmp_path, 'discuss')
        with pytest.raises(PreconditionError, match='template placeholders'):
            transition(tmp_path, 'plan')


class TestPreconditionPlanVerified:
    """Tests for check_plan_verified precondition."""

    def test_pass_when_verified(self, tmp_path):
        """Test that PLAN.md with status=verified passes."""
        _setup_project(tmp_path)
        _write_plan(tmp_path, _VERIFIED_PLAN)
        assert check_plan_verified(tmp_path) is None

    def test_fail_missing_plan(self, tmp_path):
        """Test that missing PLAN.md fails."""
        _setup_project(tmp_path)
        error = check_plan_verified(tmp_path)
        assert error is not None
        assert 'PLAN.md missing' in error

    def test_fail_draft_plan(self, tmp_path):
        """Test that PLAN.md with status=draft fails."""
        _setup_project(tmp_path)
        _write_plan(tmp_path, _DRAFT_PLAN)
        error = check_plan_verified(tmp_path)
        assert error is not None
        assert 'not verified' in error

    def test_transition_blocked_by_precondition(self, tmp_path):
        """Test that plan -> execute is blocked when plan is not verified."""
        _setup_project(tmp_path, 'plan')
        with pytest.raises(PreconditionError, match='PLAN.md missing'):
            transition(tmp_path, 'execute')


class TestPreconditionAllTasksDone:
    """Tests for check_all_tasks_done precondition."""

    def test_pass_when_all_done(self, tmp_path):
        """Test that all tasks with status 'done' passes."""
        _setup_project(tmp_path)
        _write_plan(tmp_path, _VERIFIED_PLAN)
        assert check_all_tasks_done(tmp_path) is None

    def test_fail_with_pending_tasks(self, tmp_path):
        """Test that some tasks pending/in-progress fails with count."""
        _setup_project(tmp_path)
        _write_plan(tmp_path, _PARTIAL_PLAN)
        error = check_all_tasks_done(tmp_path)
        assert error is not None
        assert '2 task(s)' in error

    def test_fail_missing_plan(self, tmp_path):
        """Test that missing PLAN.md fails."""
        _setup_project(tmp_path)
        error = check_all_tasks_done(tmp_path)
        assert error is not None
        assert 'PLAN.md missing' in error

    def test_transition_blocked_by_precondition(self, tmp_path):
        """Test that verify -> complete is blocked when tasks remain."""
        _setup_project(tmp_path, 'verify')
        _write_plan(tmp_path, _PARTIAL_PLAN)
        with pytest.raises(PreconditionError, match='2 task\\(s\\)'):
            transition(tmp_path, 'complete')


class TestTransitionCompleteToDiscussResetsycle:
    """Tests for auto-reset on complete → discuss transition."""

    def test_cycle_files_archived_and_reset(self, tmp_path):
        """Test that complete→discuss archives cycle/ and scaffolds fresh templates."""
        _setup_project(tmp_path, 'complete')
        cycle_dir = tmp_path / PLANNING_DIR / CYCLE_DIR

        # Write custom content to cycle files so we can detect the reset
        (cycle_dir / 'REQUIREMENTS.md').write_text('# Old requirements')
        (cycle_dir / 'DECISIONS.md').write_text('# Old decisions')
        _write_plan(tmp_path, _VERIFIED_PLAN)

        transition(tmp_path, 'discuss')

        # Cycle files should be fresh templates (not old content)
        req_content = (cycle_dir / 'REQUIREMENTS.md').read_text()
        assert '# Old requirements' not in req_content
        assert req_content == CYCLE_FILES['REQUIREMENTS.md']

        dec_content = (cycle_dir / 'DECISIONS.md').read_text()
        assert '# Old decisions' not in dec_content
        assert dec_content == CYCLE_FILES['DECISIONS.md']

        # PLAN.md should no longer exist (it's not a cycle template)
        assert not (cycle_dir / 'PLAN.md').exists()

        # Archive should exist with old files
        archive_dir = tmp_path / PLANNING_DIR / CYCLE_ARCHIVE_DIR
        assert archive_dir.exists()
        archives = list(archive_dir.iterdir())
        assert len(archives) == 1
        archived = archives[0]
        assert (archived / 'REQUIREMENTS.md').read_text() == '# Old requirements'
        assert (archived / 'PLAN.md').read_text() == _VERIFIED_PLAN

    def test_state_phase_reset_to_discuss(self, tmp_path):
        """Test that STATE.md phase is discuss after complete→discuss."""
        _setup_project(tmp_path, 'complete')
        transition(tmp_path, 'discuss')

        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`discuss`' in content


class TestPreconditionNotOnDefaultBranch:
    """Tests for check_not_on_default_branch precondition."""

    def test_pass_on_feature_branch(self, tmp_path):
        """Test passes when on a feature branch."""
        with (
            patch('gsd_lean.workflow.engine.get_current_branch', return_value='feature/foo'),
            patch('gsd_lean.workflow.engine.get_default_branch', return_value='main'),
        ):
            assert check_not_on_default_branch(tmp_path) is None

    def test_fail_on_main(self, tmp_path):
        """Test fails when on default branch 'main'."""
        with (
            patch('gsd_lean.workflow.engine.get_current_branch', return_value='main'),
            patch('gsd_lean.workflow.engine.get_default_branch', return_value='main'),
        ):
            error = check_not_on_default_branch(tmp_path)
            assert error is not None
            assert "default branch 'main'" in error

    def test_fail_on_master(self, tmp_path):
        """Test fails when on default branch 'master'."""
        with (
            patch('gsd_lean.workflow.engine.get_current_branch', return_value='master'),
            patch('gsd_lean.workflow.engine.get_default_branch', return_value='master'),
        ):
            error = check_not_on_default_branch(tmp_path)
            assert error is not None
            assert "default branch 'master'" in error

    def test_pass_non_git_repo(self, tmp_path):
        """Test passes when not in a git repo."""
        with patch('gsd_lean.workflow.engine.get_current_branch', return_value=None):
            assert check_not_on_default_branch(tmp_path) is None

    def test_pass_detached_head(self, tmp_path):
        """Test passes on detached HEAD (current_branch is None)."""
        with patch('gsd_lean.workflow.engine.get_current_branch', return_value=None):
            assert check_not_on_default_branch(tmp_path) is None

    def test_transition_blocked(self, tmp_path):
        """Test plan→execute blocked when on default branch."""
        _setup_project(tmp_path, 'plan')
        _write_plan(tmp_path, _VERIFIED_PLAN)
        with (
            patch('gsd_lean.workflow.engine.get_current_branch', return_value='main'),
            patch('gsd_lean.workflow.engine.get_default_branch', return_value='main'),
            pytest.raises(PreconditionError, match='default branch'),
        ):
            transition(tmp_path, 'execute')

    def test_force_bypasses(self, tmp_path):
        """Test --force bypasses branch check."""
        _setup_project(tmp_path, 'plan')
        _write_plan(tmp_path, _VERIFIED_PLAN)
        with (
            patch('gsd_lean.workflow.engine.get_current_branch', return_value='main'),
            patch('gsd_lean.workflow.engine.get_default_branch', return_value='main'),
        ):
            result = transition(tmp_path, 'execute', force=True)
            assert result == 'execute'
