"""Integration tests for CLI subcommands."""

import json

from click.testing import CliRunner

from gsd_lean.cli.app import cli
from gsd_lean.state.planning import CYCLE_ARCHIVE_DIR, CYCLE_DIR, CYCLE_FILES, PLANNING_DIR, STATIC_FILES


class TestInitCommand:
    """Tests for the gsd-lean init subcommand."""

    def test_init_creates_files(self, tmp_path):
        """Test that init creates all planning files and prints output."""
        runner = CliRunner()
        result = runner.invoke(cli, ['init', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Initialized .planning/' in result.output
        assert '7 file(s)' in result.output

        for filename in STATIC_FILES:
            assert (tmp_path / PLANNING_DIR / filename).exists()
        for filename in CYCLE_FILES:
            assert (tmp_path / PLANNING_DIR / CYCLE_DIR / filename).exists()

    def test_init_fails_if_exists(self, tmp_path):
        """Test that init fails when .planning/ already has all files."""
        runner = CliRunner()
        # First init
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        # Second init should fail
        result = runner.invoke(cli, ['init', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'already exists' in result.output

    def test_init_force_overwrites(self, tmp_path):
        """Test that init --force overwrites existing files."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['init', '--force', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert '7 file(s)' in result.output


class TestStatusCommand:
    """Tests for the gsd-lean status subcommand."""

    def test_status_shows_state(self, tmp_path):
        """Test that status displays STATE.md content."""
        runner = CliRunner()
        # Init first
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        # Then status
        result = runner.invoke(cli, ['status', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert '# Workflow State' in result.output
        assert '`discuss`' in result.output

    def test_status_fails_without_init(self, tmp_path):
        """Test that status fails when .planning/ does not exist."""
        runner = CliRunner()
        result = runner.invoke(cli, ['status', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'not found' in result.output


_POPULATED_REQUIREMENTS = """\
# Requirements

> Captured during the discuss phase. Updated as understanding evolves.

## User Intent

- Build a widget system

## Functional Requirements

- Widget CRUD operations

## Non-Functional Requirements

- 90% test coverage
"""

_VERIFIED_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 1
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create widget module | `src/widget.py` | unit tests pass |

## Task Details

### T-001: Create widget module
...
"""

_MULTI_WAVE_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 3
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create workflow module | `src/workflow.py` | unit tests pass |
| T-002 | 1 | done | Add state functions | `src/state.py` | unit tests pass |
| T-003 | 2 | done | Add preconditions | `src/workflow.py` | tests pass |
| T-004 | 2 | done | Add transition CLI | `src/cli.py` | tests pass |
| T-005 | 2 | in-progress | Add plan-status CLI | `src/cli.py` | tests pass |
| T-006 | 3 | pending | Create discuss skill | `skills/discuss/SKILL.md` | skill loads |
| T-007 | 3 | pending | Create plan skill | `skills/plan/SKILL.md` | skill loads |
| T-008 | 3 | blocked | Update CLAUDE.md | `CLAUDE.md` | table updated |
"""


class TestTransitionCommand:
    """Tests for the gsd-lean transition subcommand."""

    def test_transition_happy_path(self, tmp_path):
        """Test happy path: exit 0, 'Transitioned to: plan' output."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        # Populate requirements to satisfy precondition
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').write_text(_POPULATED_REQUIREMENTS)

        result = runner.invoke(cli, ['transition', 'plan', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Transitioned to: plan' in result.output

    def test_transition_invalid_phase(self, tmp_path):
        """Test that an invalid phase name produces an error."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['transition', 'foo', '--path', str(tmp_path)])
        assert result.exit_code != 0

    def test_transition_precondition_fail(self, tmp_path):
        """Test exit 1 and precondition error message when requirements unpopulated."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['transition', 'plan', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'template placeholders' in result.output

    def test_transition_force(self, tmp_path):
        """Test exit 0 despite failed precondition when --force is used."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['transition', 'plan', '--force', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Transitioned to: plan' in result.output

    def test_transition_with_note(self, tmp_path):
        """Test that --note adds text to the history row."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').write_text(_POPULATED_REQUIREMENTS)

        result = runner.invoke(cli, ['transition', 'plan', '--note', 'Starting planning', '--path', str(tmp_path)])
        assert result.exit_code == 0

        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert 'Starting planning' in content


class TestPlanStatusCommand:
    """Tests for the gsd-lean plan-status subcommand."""

    def test_plan_status_human(self, tmp_path):
        """Test human-readable output format."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').write_text(_MULTI_WAVE_PLAN)

        result = runner.invoke(cli, ['plan-status', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Plan: verified' in result.output
        assert 'Wave: 2/3' in result.output
        assert 'Tasks: 4/8 done' in result.output
        assert 'Next: T-006' in result.output

    def test_plan_status_json(self, tmp_path):
        """Test JSON output contains all expected fields."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').write_text(_MULTI_WAVE_PLAN)

        result = runner.invoke(cli, ['plan-status', '--json', '--path', str(tmp_path)])
        assert result.exit_code == 0

        data = json.loads(result.output)
        assert data['status'] == 'verified'
        assert data['total'] == 8
        assert data['done'] == 4
        assert data['pending'] == 2
        assert data['in_progress'] == 1
        assert data['blocked'] == 1
        assert data['current_wave'] == 2
        assert data['total_waves'] == 3
        assert data['next_task'] == 'T-006'

    def test_plan_status_no_plan(self, tmp_path):
        """Test exit 1 when PLAN.md does not exist."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['plan-status', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'not found' in result.output


_VALID_CONFIG = """\
defaults:
  max_turns: 25
skills:
  execute:
    subagents:
      executor:
        model: sonnet
        max_turns: 40
      auto-debug:
        model: haiku
        max_turns: 20
"""

_INVALID_CONFIG = """\
defaults:
  model: gpt-4
  max_turns: -1
"""


class TestConfigCommand:
    """Tests for the gsd-lean config subcommand."""

    def test_config_show(self, tmp_path):
        """Test that config dumps parsed YAML."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'config.yaml').write_text(_VALID_CONFIG)

        result = runner.invoke(cli, ['config', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'max_turns' in result.output
        assert 'execute' in result.output

    def test_config_validate_clean(self, tmp_path):
        """Test exit 0 for valid config."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'config.yaml').write_text(_VALID_CONFIG)

        result = runner.invoke(cli, ['config', '--validate', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Config is valid' in result.output

    def test_config_validate_errors(self, tmp_path):
        """Test exit 1 for invalid config."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'config.yaml').write_text(_INVALID_CONFIG)

        result = runner.invoke(cli, ['config', '--validate', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'gpt-4' in result.output

    def test_config_resolve(self, tmp_path):
        """Test that --skill + --subagent outputs resolved model and max_turns."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'config.yaml').write_text(_VALID_CONFIG)

        result = runner.invoke(cli, ['config', '--skill', 'execute', '--subagent', 'executor', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'model: sonnet' in result.output
        assert 'max_turns: 40' in result.output

    def test_config_missing_file(self, tmp_path):
        """Test graceful handling when no config.yaml exists."""
        runner = CliRunner()
        # Create .planning/ dir without config.yaml (don't use init, which scaffolds it)
        (tmp_path / PLANNING_DIR).mkdir()

        result = runner.invoke(cli, ['config', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'No config found' in result.output

    def test_config_subagent_requires_skill(self, tmp_path):
        """Test exit 1 when --subagent is given without --skill."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['config', '--subagent', 'executor', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert '--subagent requires --skill' in result.output

    def test_config_skill_only(self, tmp_path):
        """Test that --skill without --subagent shows all subagents for that skill."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / 'config.yaml').write_text(_VALID_CONFIG)

        result = runner.invoke(cli, ['config', '--skill', 'execute', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'executor:' in result.output
        assert 'auto-debug:' in result.output


class TestNewCycleCommand:
    """Tests for the gsd-lean new-cycle subcommand."""

    def test_new_cycle_archives_and_scaffolds(self, tmp_path):
        """Test that new-cycle archives existing cycle and creates fresh templates."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        # Write content into cycle files so there's something to archive
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').write_text(_POPULATED_REQUIREMENTS)

        result = runner.invoke(cli, ['new-cycle', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'New cycle started' in result.output
        assert '2 file(s)' in result.output

        # Verify archive was created
        archive_dir = tmp_path / PLANNING_DIR / CYCLE_ARCHIVE_DIR
        assert archive_dir.exists()
        archives = list(archive_dir.iterdir())
        assert len(archives) == 1
        assert (archives[0] / 'REQUIREMENTS.md').exists()

        # Verify fresh templates exist
        for filename in CYCLE_FILES:
            assert (tmp_path / PLANNING_DIR / CYCLE_DIR / filename).exists()

    def test_new_cycle_no_archive(self, tmp_path):
        """Test that --no-archive skips archiving."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])
        (tmp_path / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md').write_text(_POPULATED_REQUIREMENTS)

        result = runner.invoke(cli, ['new-cycle', '--no-archive', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'New cycle started' in result.output

        # Verify NO archive was created
        archive_dir = tmp_path / PLANNING_DIR / CYCLE_ARCHIVE_DIR
        assert not archive_dir.exists()

    def test_new_cycle_fails_without_planning(self, tmp_path):
        """Test that new-cycle fails when .planning/ does not exist."""
        runner = CliRunner()
        result = runner.invoke(cli, ['new-cycle', '--path', str(tmp_path)])
        assert result.exit_code == 1
        assert 'not found' in result.output


class TestMigrateCommand:
    """Tests for the gsd-lean migrate subcommand."""

    def test_migrate_v1_layout(self, tmp_path):
        """Test that migrate converts v1 layout to v2."""
        runner = CliRunner()
        # Create v1 layout: flat .planning/ with REQUIREMENTS.md at root
        planning_dir = tmp_path / PLANNING_DIR
        planning_dir.mkdir()
        (planning_dir / 'REQUIREMENTS.md').write_text('# Requirements\n')
        (planning_dir / 'DECISIONS.md').write_text('# Decisions\n\n## Style & Preferences\n\n- dark mode\n')
        (planning_dir / 'ROADMAP.md').write_text('# Roadmap\n')

        result = runner.invoke(cli, ['migrate', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'Migrated' in result.output

        # Verify v2 structure
        assert (planning_dir / CYCLE_DIR / 'REQUIREMENTS.md').exists()
        assert not (planning_dir / 'REQUIREMENTS.md').exists()
        assert not (planning_dir / 'ROADMAP.md').exists()

    def test_migrate_already_v2(self, tmp_path):
        """Test that migrate reports no migration needed for v2 layout."""
        runner = CliRunner()
        runner.invoke(cli, ['init', '--path', str(tmp_path)])

        result = runner.invoke(cli, ['migrate', '--path', str(tmp_path)])
        assert result.exit_code == 0
        assert 'No migration needed' in result.output
