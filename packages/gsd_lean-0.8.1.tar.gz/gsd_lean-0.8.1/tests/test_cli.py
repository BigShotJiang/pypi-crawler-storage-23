"""Tests for the CLI application."""

import subprocess
import sys

from click.testing import CliRunner

from gsd_lean.cli.app import cli


def test_main_no_args():
    """Test CLI with no arguments prints help and exits 0."""
    runner = CliRunner()
    result = runner.invoke(cli)
    assert result.exit_code == 0
    assert 'GSD-Lean' in result.output


def test_main_help():
    """Test CLI --help flag."""
    runner = CliRunner()
    result = runner.invoke(cli, ['--help'])
    assert result.exit_code == 0
    assert 'init' in result.output
    assert 'status' in result.output
    assert 'version' in result.output


def test_version_command():
    """Test version command prints a non-empty version string."""
    runner = CliRunner()
    result = runner.invoke(cli, ['version'])
    assert result.exit_code == 0
    assert result.output.strip()


def test_version_flag():
    """Test --version flag prints version and exits 0."""
    runner = CliRunner()
    result = runner.invoke(cli, ['--version'])
    assert result.exit_code == 0
    assert 'gsd-lean' in result.output


def test_entry_point():
    """Test that gsd-lean entry point is installed and callable."""
    result = subprocess.run(
        [sys.executable, '-m', 'gsd_lean.cli'],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert 'GSD-Lean' in result.stdout
