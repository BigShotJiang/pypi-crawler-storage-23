"""MCP server and plugin detection."""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

logger = logging.getLogger(__name__)


@dataclass
class McpPluginInfo:
    """Detected MCP servers and plugins."""

    mcp_servers: list[str] = field(default_factory=list[str])
    plugins: list[str] = field(default_factory=list[str])


def detect_mcp_plugins(root: Path) -> McpPluginInfo:
    """Detect MCP servers from .mcp.json and plugins from .claude/settings.json.

    Args:
        root: Project root directory.

    Returns:
        McpPluginInfo with detected server names and plugin identifiers.
    """
    info = McpPluginInfo()

    # MCP servers from .mcp.json
    mcp_file = root / '.mcp.json'
    if mcp_file.exists():
        try:
            data: dict[str, Any] = json.loads(mcp_file.read_text())
            servers = data.get('mcpServers', {})
            if isinstance(servers, dict):
                info.mcp_servers = sorted(cast(dict[str, Any], servers).keys())
        except (json.JSONDecodeError, OSError):
            logger.warning('Failed to parse .mcp.json — skipping MCP detection.')

    # Plugins from .claude/settings.json
    settings_file = root / '.claude' / 'settings.json'
    if settings_file.exists():
        try:
            settings_data: dict[str, Any] = json.loads(settings_file.read_text())
            plugins = settings_data.get('enabledPlugins', {})
            if isinstance(plugins, dict):
                typed_plugins = cast(dict[str, Any], plugins)
                info.plugins = sorted(str(k) for k, v in typed_plugins.items() if v)
        except (json.JSONDecodeError, OSError):
            logger.warning('Failed to parse .claude/settings.json — skipping plugin detection.')

    return info


def format_mcp_plugin_summary(info: McpPluginInfo) -> str:
    """Format MCP/plugin info as markdown for CONTEXT.md.

    Args:
        info: Detected MCP servers and plugins.

    Returns:
        Markdown-formatted string, or empty string if nothing detected.
    """
    lines: list[str] = []
    if info.mcp_servers:
        lines.append(f'- **MCP servers:** {", ".join(info.mcp_servers)}')
    if info.plugins:
        lines.append(f'- **Plugins:** {", ".join(info.plugins)}')
    return '\n'.join(lines) if lines else ''


def merge_into_context_md(root: Path, mcp_info: McpPluginInfo) -> bool:
    """Merge detected MCP/plugin info into CONTEXT.md Tooling section.

    Only fills in the Tooling section if it still contains the template
    placeholder. Does not overwrite user-edited content.

    Args:
        root: Project root containing .planning/.
        mcp_info: Detected MCP servers and plugins.

    Returns:
        True if any changes were made.

    Raises:
        FileNotFoundError: If .planning/CONTEXT.md does not exist.
    """
    context_file = root / '.planning' / 'CONTEXT.md'
    if not context_file.exists():
        raise FileNotFoundError('.planning/CONTEXT.md not found. Run `gsd-lean init` first.')

    summary = format_mcp_plugin_summary(mcp_info)
    if not summary:
        return False

    content = context_file.read_text()

    # Only replace the placeholder line under ## Tooling
    new_content, count = re.subn(
        r'(## Tooling\n\n)- \(none yet\)',
        rf'\1{summary}',
        content,
        count=1,
    )
    if count == 0:
        return False

    context_file.write_text(new_content)
    return True
