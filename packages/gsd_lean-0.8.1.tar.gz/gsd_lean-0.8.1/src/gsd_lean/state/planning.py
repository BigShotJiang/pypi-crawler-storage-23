"""Planning state management for the .planning/ directory."""

import re
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

PLANNING_DIR = '.planning'
CYCLE_DIR = 'cycle'
CYCLE_ARCHIVE_DIR = 'cycle-archive'

PHASES = ('discuss', 'plan', 'execute', 'verify', 'complete')

STATIC_FILES: dict[str, str] = {
    'PROJECT.md': """\
# Project Overview

> Fill in project details during the discuss phase.

## Stack

- **Language:**
- **Framework:**
- **Key dependencies:**
- **Runtime manager:**

## Constraints

- (none yet)

## Notes

- (none yet)
""",
    'CONTEXT.md': """\
# Project Context

> Static project-level context. Persists across development cycles.
> Updated by /init (auto-detection) and manually by the user.

## Architecture

- (none yet)

## Tooling

- (none yet)

## Skills

- (none yet)

## Commands

- (none yet)

## Gotchas

- (none yet)
""",
    'STATE.md': """\
# Workflow State

## Current Phase

`discuss`

## Active Task

(none)

## Blockers

(none)

## History

| Timestamp | Phase | Note |
|-----------|-------|------|
""",
    '.gitignore': """\
# GSD-Lean — ephemeral cycle documents (regenerated each workflow cycle)
cycle/
cycle-archive/
STATE.md
""",
    'config.yaml': """\
# GSD-Lean Subagent Configuration
# Controls model and max_turns for subagents spawned by workflow skills.
# Resolution: skill-specific -> defaults -> inherit from session.
# Valid models: opus, sonnet, haiku

defaults:
  # model: sonnet
  max_turns: 25

# Uncomment and customize per-skill subagent settings:
# skills:
#   init:
#     subagents:
#       explore:
#         model: haiku
#         max_turns: 15
#   discuss:
#     subagents:
#       explore:
#         model: sonnet
#         max_turns: 20
#       verify:
#         model: haiku
#         max_turns: 10
#   plan:
#     subagents:
#       plan-review:
#         model: sonnet
#         max_turns: 25
#   execute:
#     subagents:
#       executor:
#         model: sonnet
#         max_turns: 40
#       verify:
#         model: haiku
#         max_turns: 15
#       auto-debug:
#         model: sonnet
#         max_turns: 20
""",
}

CYCLE_FILES: dict[str, str] = {
    'REQUIREMENTS.md': """\
# Requirements

> Captured during the discuss phase. Handed to /plan for task decomposition.
> This document must be self-contained — a fresh session reads only this + DECISIONS.md + PROJECT.md + CONTEXT.md.

## User Intent

(not yet defined)

## Motivation

(not yet defined)

## Goals

- (none yet)

## Non-Goals

- (none yet)

## Functional Requirements

- (none yet)

## Affected Files

| File | Action | Description |
|------|--------|-------------|
| (none yet) | | |

## Key Interfaces

(none yet)

## Edge Cases & Error Handling

- (none yet)

## Testing Strategy

(not yet defined)

## Non-Functional Requirements

- (none yet)
""",
    'DECISIONS.md': """\
# Decisions

> Cycle-specific decisions captured during /discuss.
> For static project context (Architecture, Tooling, Skills), see ../CONTEXT.md.

## Style & Preferences

- (none yet)

## Constraints

- (none yet)

## Dependencies

- (none yet)
""",
}

# Backwards-compat alias: union of both dicts, keyed by filename.
# Cycle files are stored under cycle/ on disk, but this flat dict is used
# for any code that still references PLANNING_FILES by name.
PLANNING_FILES: dict[str, str] = {**STATIC_FILES, **CYCLE_FILES}


@dataclass(frozen=True)
class PlanTask:
    """A single task parsed from PLAN.md."""

    id: str
    wave: int
    status: str
    title: str
    files: str
    verification: str


PLAN_TEMPLATE = """\
# Plan

> **Status:** draft
> **Created:** {created}
> **Waves:** 0
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|

## Task Details

(No tasks yet. Run /plan to generate.)
"""

_VALID_PLAN_STATUSES = frozenset({'draft', 'verified', 'in-progress', 'complete'})
_VALID_TASK_STATUSES = frozenset({'pending', 'in-progress', 'done', 'blocked'})


def init_planning(root: Path, *, force: bool = False) -> list[Path]:
    """Scaffold the .planning/ directory with template files.

    Creates a two-tier structure: static files at .planning/ root and
    ephemeral cycle files at .planning/cycle/.

    Args:
        root: Project root directory where .planning/ will be created.
        force: If True, overwrite existing files. If False, skip files that already exist.

    Returns:
        List of file paths that were created or overwritten.

    Raises:
        FileExistsError: If .planning/ exists and force is False and all files already exist.
    """
    planning_dir = root / PLANNING_DIR

    # Auto-migrate v1 layout before scaffolding v2 structure
    if not force and _is_v1_layout(root) and migrate_v1_to_v2(root):
        return [planning_dir]  # signal migration happened

    planning_dir.mkdir(parents=True, exist_ok=True)
    cycle_dir = planning_dir / CYCLE_DIR
    cycle_dir.mkdir(exist_ok=True)

    created: list[Path] = []
    skipped: list[Path] = []

    # Static files at .planning/ root
    for filename, content in STATIC_FILES.items():
        filepath = planning_dir / filename
        if filepath.exists() and not force:
            skipped.append(filepath)
            continue
        filepath.write_text(content)
        created.append(filepath)

    # Cycle files at .planning/cycle/
    for filename, content in CYCLE_FILES.items():
        filepath = cycle_dir / filename
        if filepath.exists() and not force:
            skipped.append(filepath)
            continue
        filepath.write_text(content)
        created.append(filepath)

    if not created and skipped:
        raise FileExistsError(f'{PLANNING_DIR}/ already exists with all files. Use --force to overwrite.')

    return created


def reset_cycle(root: Path, *, archive: bool = True) -> list[Path]:
    """Archive current cycle/ and scaffold fresh templates.

    Args:
        root: Project root.
        archive: If True, copy cycle/ to cycle-archive/<timestamp>/ before reset.

    Returns:
        List of created file paths.

    Raises:
        FileNotFoundError: If .planning/ directory does not exist.
    """
    planning_dir = root / PLANNING_DIR
    if not planning_dir.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/ not found. Run `gsd-lean init` first.')

    cycle_dir = planning_dir / CYCLE_DIR

    if archive and cycle_dir.exists() and any(cycle_dir.iterdir()):
        timestamp = datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
        archive_dir = planning_dir / CYCLE_ARCHIVE_DIR / timestamp
        archive_dir.mkdir(parents=True, exist_ok=True)
        shutil.copytree(cycle_dir, archive_dir, dirs_exist_ok=True)

    # Remove all files in cycle/
    if cycle_dir.exists():
        shutil.rmtree(cycle_dir)
    cycle_dir.mkdir(exist_ok=True)

    # Re-scaffold cycle templates
    created: list[Path] = []
    for filename, content in CYCLE_FILES.items():
        filepath = cycle_dir / filename
        filepath.write_text(content)
        created.append(filepath)

    # Reset STATE.md phase to discuss (preserve history)
    _reset_state_phase(root)

    return created


def _reset_state_phase(root: Path) -> None:
    """Reset STATE.md phase to discuss, preserving history table."""
    state_file = root / PLANNING_DIR / 'STATE.md'
    if not state_file.exists():
        return  # nothing to reset

    content = state_file.read_text()

    # Reset phase to discuss
    content = re.sub(
        r'(## Current Phase\s*\n\s*)`\w+`',
        r'\1`discuss`',
        content,
        count=1,
    )

    # Reset active task
    content = re.sub(
        r'(## Active Task\s*\n\s*)\S.*',
        r'\1(none)',
        content,
        count=1,
    )

    state_file.write_text(content)


def _is_v1_layout(root: Path) -> bool:
    """Detect whether .planning/ uses the old flat (v1) layout.

    V1 layout: REQUIREMENTS.md at .planning/ root, no cycle/ subdirectory.
    """
    planning_dir = root / PLANNING_DIR
    return (planning_dir / 'REQUIREMENTS.md').exists() and not (planning_dir / CYCLE_DIR).exists()


def _split_decisions(content: str, static_dir: Path, cycle_dir: Path) -> None:
    """Split old DECISIONS.md into CONTEXT.md (static) + cycle/DECISIONS.md (ephemeral).

    Parses the markdown by ``## `` headers and routes sections:
    - Architecture, Tooling, Skills → CONTEXT.md
    - Style & Preferences, Constraints, Dependencies → cycle/DECISIONS.md
    - Unrecognised sections → cycle/DECISIONS.md
    """
    static_headers = {'Architecture', 'Tooling', 'Skills', 'Commands', 'Gotchas'}
    static_sections: list[str] = []
    cycle_sections: list[str] = []

    # Split content into sections by ## headers
    parts = re.split(r'^(## .+)$', content, flags=re.MULTILINE)
    # parts[0] is preamble (before first ## header), then alternating header/body pairs

    for i in range(1, len(parts), 2):
        header = parts[i]
        body = parts[i + 1] if i + 1 < len(parts) else ''
        section_name = header.removeprefix('## ').strip()
        if section_name in static_headers:
            static_sections.append(header + body)
        else:
            cycle_sections.append(header + body)

    # Write CONTEXT.md
    context_file = static_dir / 'CONTEXT.md'
    if not context_file.exists():
        context_lines = [
            '# Project Context\n',
            '\n',
            '> Static project-level context. Persists across development cycles.\n',
            '> Updated by /init (auto-detection) and manually by the user.\n',
            '\n',
        ]
        if static_sections:
            context_lines.append(''.join(static_sections))
        else:
            context_lines.append(STATIC_FILES['CONTEXT.md'].split('\n', 5)[-1])
        context_file.write_text(''.join(context_lines))

    # Write cycle/DECISIONS.md
    cycle_decisions = cycle_dir / 'DECISIONS.md'
    cycle_lines = [
        '# Decisions\n',
        '\n',
        '> Cycle-specific decisions captured during /discuss.\n',
        '> For static project context (Architecture, Tooling, Skills), see ../CONTEXT.md.\n',
        '\n',
    ]
    if cycle_sections:
        cycle_lines.append(''.join(cycle_sections))
    else:
        # Use the template body for the 3 sections
        cycle_lines.append(CYCLE_FILES['DECISIONS.md'].split('\n', 5)[-1])
    cycle_decisions.write_text(''.join(cycle_lines))


def migrate_v1_to_v2(root: Path) -> bool:
    """Migrate flat .planning/ layout to static/cycle structure.

    Detection: .planning/REQUIREMENTS.md exists AND .planning/cycle/ does not.

    Returns:
        True if migration was performed, False if already v2 or no .planning/.
    """
    planning_dir = root / PLANNING_DIR
    if not _is_v1_layout(root):
        return False

    cycle_dir = planning_dir / CYCLE_DIR
    cycle_dir.mkdir(exist_ok=True)

    # Move ephemeral files to cycle/
    for filename in ('REQUIREMENTS.md', 'PLAN.md'):
        src = planning_dir / filename
        if src.exists():
            shutil.move(str(src), str(cycle_dir / filename))

    # Split DECISIONS.md
    decisions_file = planning_dir / 'DECISIONS.md'
    if decisions_file.exists():
        content = decisions_file.read_text()
        _split_decisions(content, planning_dir, cycle_dir)
        decisions_file.unlink()
    else:
        # No DECISIONS.md — write fresh CONTEXT.md template and cycle/DECISIONS.md template
        context_file = planning_dir / 'CONTEXT.md'
        if not context_file.exists():
            context_file.write_text(STATIC_FILES['CONTEXT.md'])
        cycle_decisions = cycle_dir / 'DECISIONS.md'
        if not cycle_decisions.exists():
            cycle_decisions.write_text(CYCLE_FILES['DECISIONS.md'])

    # Delete ROADMAP.md
    roadmap = planning_dir / 'ROADMAP.md'
    if roadmap.exists():
        roadmap.unlink()

    # Update .gitignore
    gitignore = planning_dir / '.gitignore'
    gitignore.write_text(STATIC_FILES['.gitignore'])

    return True


def read_state(root: Path) -> str:
    """Read and return the contents of STATE.md.

    Args:
        root: Project root directory containing .planning/.

    Returns:
        Contents of STATE.md as a string.

    Raises:
        FileNotFoundError: If .planning/STATE.md does not exist.
    """
    state_file = root / PLANNING_DIR / 'STATE.md'
    if not state_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/STATE.md not found. Run `gsd-lean init` first.')
    return state_file.read_text()


def write_state(root: Path, phase: str, note: str = '') -> None:
    """Update STATE.md with a new phase and append a history row.

    Args:
        root: Project root containing .planning/.
        phase: New phase name (must be one of PHASES).
        note: Optional note for the history table row.

    Raises:
        FileNotFoundError: If .planning/STATE.md does not exist.
        ValueError: If phase is not a valid phase name or STATE.md format is unexpected.
    """
    if phase not in PHASES:
        raise ValueError(f'Invalid phase: {phase!r}. Must be one of {PHASES}.')

    state_file = root / PLANNING_DIR / 'STATE.md'
    if not state_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/STATE.md not found. Run `gsd-lean init` first.')

    content = state_file.read_text()

    # Replace the phase line (first backtick-wrapped word after ## Current Phase)
    new_content, count = re.subn(
        r'(## Current Phase\s*\n\s*)`\w+`',
        rf'\1`{phase}`',
        content,
        count=1,
    )
    if count == 0:
        raise ValueError('STATE.md has unexpected format: could not find phase line under ## Current Phase.')

    # Append history row
    timestamp = datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    history_row = f'| {timestamp} | {phase} | {note} |\n'
    new_content = new_content.rstrip('\n') + '\n' + history_row

    state_file.write_text(new_content)


def read_plan(root: Path) -> str:
    """Read and return contents of PLAN.md.

    Args:
        root: Project root containing .planning/.

    Returns:
        Contents of PLAN.md as a string.

    Raises:
        FileNotFoundError: If .planning/PLAN.md does not exist.
    """
    plan_file = root / PLANNING_DIR / CYCLE_DIR / 'PLAN.md'
    if not plan_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/{CYCLE_DIR}/PLAN.md not found. Run `/plan` to generate a plan.')
    return plan_file.read_text()


def parse_plan_tasks(content: str) -> list[PlanTask]:
    """Parse the task table from PLAN.md content.

    Args:
        content: Raw PLAN.md file content.

    Returns:
        List of PlanTask dataclasses. Returns empty list if no tasks found.
        Malformed rows are skipped with no error.
    """
    tasks: list[PlanTask] = []
    for match in re.finditer(
        r'^\|\s*(T-\d{3})\s*\|\s*(\d+)\s*\|\s*(\S+)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|',
        content,
        re.MULTILINE,
    ):
        task_id, wave_str, status, title, files, verification = match.groups()
        if status not in _VALID_TASK_STATUSES:
            continue
        try:
            wave = int(wave_str)
        except ValueError:
            continue
        tasks.append(
            PlanTask(
                id=task_id,
                wave=wave,
                status=status,
                title=title.strip(),
                files=files.strip(),
                verification=verification.strip(),
            )
        )
    return tasks


def get_plan_status(content: str) -> str:
    """Extract the Status header value from PLAN.md content.

    Args:
        content: Raw PLAN.md file content.

    Returns:
        Status string ('draft', 'verified', 'in-progress', 'complete').

    Raises:
        ValueError: If Status header is missing or has invalid value.
    """
    match = re.search(r'>\s*\*\*Status:\*\*\s*(\S+)', content)
    if not match:
        raise ValueError('PLAN.md is missing the Status header.')
    status = match.group(1).strip()
    if status not in _VALID_PLAN_STATUSES:
        raise ValueError(f'Invalid plan status: {status!r}. Must be one of {sorted(_VALID_PLAN_STATUSES)}.')
    return status


def update_task_status(root: Path, task_id: str, new_status: str) -> None:
    """Update a task's status in PLAN.md task table.

    Finds the task row matching ``task_id`` (e.g. 'T-001') in the summary table
    and replaces its status column value with ``new_status``.

    Args:
        root: Project root containing .planning/.
        task_id: Task ID (e.g. 'T-001').
        new_status: New status value (must be one of _VALID_TASK_STATUSES).

    Raises:
        FileNotFoundError: If PLAN.md does not exist.
        ValueError: If task_id not found or new_status is invalid.
    """
    if new_status not in _VALID_TASK_STATUSES:
        raise ValueError(f'Invalid task status: {new_status!r}. Must be one of {sorted(_VALID_TASK_STATUSES)}.')

    plan_file = root / PLANNING_DIR / CYCLE_DIR / 'PLAN.md'
    if not plan_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/{CYCLE_DIR}/PLAN.md not found. Run `/plan` to generate a plan.')

    content = plan_file.read_text()

    pattern = rf'(\|\s*{re.escape(task_id)}\s*\|\s*\d+\s*\|)\s*\S+\s*(\|)'
    new_content, count = re.subn(pattern, rf'\1 {new_status} \2', content, count=1)
    if count == 0:
        raise ValueError(f'Task {task_id} not found in PLAN.md task table.')

    plan_file.write_text(new_content)


def get_next_pending_task(root: Path) -> PlanTask | None:
    """Return first pending task in wave order.

    Reads PLAN.md, parses tasks, returns the first task with status 'pending'
    ordered by wave number then task ID.

    Args:
        root: Project root containing .planning/.

    Returns:
        First pending PlanTask, or None if no pending tasks.

    Raises:
        FileNotFoundError: If PLAN.md does not exist.
    """
    content = read_plan(root)
    tasks = parse_plan_tasks(content)
    pending = [t for t in tasks if t.status == 'pending']
    if not pending:
        return None
    # Already sorted by wave then ID due to parse order (table is sequential)
    return pending[0]


def get_in_progress_task(root: Path) -> PlanTask | None:
    """Return task currently in-progress, if any.

    Args:
        root: Project root containing .planning/.

    Returns:
        In-progress PlanTask, or None if no task is in-progress.

    Raises:
        FileNotFoundError: If PLAN.md does not exist.
    """
    content = read_plan(root)
    tasks = parse_plan_tasks(content)
    in_progress = [t for t in tasks if t.status == 'in-progress']
    return in_progress[0] if in_progress else None


def update_plan_status(root: Path, new_status: str) -> None:
    """Update PLAN.md Status header value.

    Replaces the Status value in the PLAN.md header block
    (e.g. 'verified' → 'in-progress' or 'in-progress' → 'complete').

    Args:
        root: Project root containing .planning/.
        new_status: New plan status (must be one of _VALID_PLAN_STATUSES).

    Raises:
        FileNotFoundError: If PLAN.md does not exist.
        ValueError: If Status header not found or new_status is invalid.
    """
    if new_status not in _VALID_PLAN_STATUSES:
        raise ValueError(f'Invalid plan status: {new_status!r}. Must be one of {sorted(_VALID_PLAN_STATUSES)}.')

    plan_file = root / PLANNING_DIR / CYCLE_DIR / 'PLAN.md'
    if not plan_file.exists():
        raise FileNotFoundError(f'{PLANNING_DIR}/{CYCLE_DIR}/PLAN.md not found. Run `/plan` to generate a plan.')

    content = plan_file.read_text()

    new_content, count = re.subn(
        r'(>\s*\*\*Status:\*\*)\s*\S+',
        rf'\1 {new_status}',
        content,
        count=1,
    )
    if count == 0:
        raise ValueError('PLAN.md is missing the Status header.')

    plan_file.write_text(new_content)
