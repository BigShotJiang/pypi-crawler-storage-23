"""Allow running gsd_lean.cli as a module: python -m gsd_lean.cli."""

from gsd_lean.cli.app import main

main()
