# Claude AI Assistant Guide

> **Documentation Structure**: This guide covers operational commands and AI workflows. For architecture details, see [PROJECT_KNOWLEDGE.md](./PROJECT_KNOWLEDGE.md). For debugging, see [TROUBLESHOOTING.md](./TROUBLESHOOTING.md).

---

## Project

GSD-Lean — lightweight Python reimplementation of [Get-Shit-Done](https://github.com/glittercowboy/get-shit-done), a meta-prompting and spec-driven development system for Claude Code.

---

## Quick Start

**First-time setup**:
```bash
make setup-venv   # clean + sync + pre-commit-install
```

**Daily workflow**: See [Make Commands](#make-commands). Key: `make ruff` (lint+fix), `make pyright` (types), `make run-tests` (tests).

**Troubleshooting**:
- CI failing? → See [TROUBLESHOOTING.md → CI/CD Debugging](./TROUBLESHOOTING.md#cicd-debugging)
- Type errors? → `uv run pyright`
- Lint errors? → `uv run ruff check` then `uv run ruff check --fix` then `uv run ruff format`

---

## Make Commands

```bash
make sync                               # Install all deps (dev + lint)
make pre-commit-install                 # Install pre-commit hooks
make pre-commit                         # Run all pre-commit checks
make ruff                               # Lint + format (auto-fix)
make ruff path=src/gsd_lean/cli         # Lint specific path
make pyright                             # Type check src/
make pyright path=src/gsd_lean/cli      # Type check specific path
make run-tests                          # Run tests
make run-tests path=tests/test_foo.py   # Run single test file
make run-tests-cov                      # Run tests with coverage
make changelog                          # Regenerate CHANGELOG.md via git-cliff
make clean                              # Remove generated files
make setup-venv                         # clean + sync + pre-commit-install
```

All commands use `uv run` under the hood. Never invoke pytest/ruff/pyright directly — always go through `make` or `uv run`.

---

## Tech Stack

- Python 3.12+
- [uv](https://github.com/astral-sh/uv) — package management
- [ruff](https://github.com/astral-sh/ruff) — linting & formatting
- [pyright](https://github.com/microsoft/pyright) — type checking
- [pytest](https://github.com/pytest-dev/pytest) — testing

---

## Uv

### Managing Dependencies

Always manage packages via uv (`uv add/remove`), **NEVER DIRECTLY MODIFY** `pyproject.toml`.

```bash
# Add new package to dependencies
uv add <package-name>

# Add new package to dev dependency group
uv add --dev <package-name>

# Add new package to lint dependency group
uv add --group lint <package-name>
```

---

## MCP Servers: How to Use

Use MCP servers to fetch up-to-date documentation **just-in-time** when working with specific technologies.

### Tech Stack Documentation Reference

| Technology | Purpose | MCP Command |
|------------|---------|-------------|
| **uv** | Runtime & package manager | Context7 MCP |

**Context7 Workflow**: Call `mcp__context7__resolve-library-id` first, then `mcp__context7__query-docs` with the returned ID.

---

## Claude Code Infrastructure

Custom infrastructure is implemented in order to streamline different workflows.

### Subagents

| Subagent | Purpose |
|----------|---------|
| `code-simplifier` | Simplify recent changes (installed via plugin, see `.claude/settings.json`) |

### Skills

Custom agent skills are implemented under `.claude/skills/<custom-skill-name>/`. These can be triggered manually by user, automatically by agent, or by the help of custom hooks.

Some useful skills that can be invoked through slash-command (i.e. `/<skill-name>`) are:

| Slash Command | Purpose |
|---------------|---------|
| `/commit` | Used for commiting recent changes |
| `/merge` | Used for merging a PR on GitHub |
| `/pr` | Used for create a PR on GitHub |
| `/prd` | Used for create a new PRD |
| `/pre-release` | Used for create a pre-release (alpha/beta/RC) of GSD-Lean |
| `/release` | Used for generate a new release of GSD-Lean |
| `/verify` | Used for automatic verification (lint, typecheck, tests) of recent changes |
| `/agent-development` | Guidance on creating Claude Code agents |
| `/claude-md-improver` | Audit and improve CLAUDE.md files |
| `/skill-development` | Guidance on creating Claude Code skills |

> **NOTE**: These skills (i.e. `.claude/skills/`) are only used for internal development. Skills related to GSD-Lean plugin resides in the `$REPO_ROOT/skills/`

---

## GSD-Lean Plugin

### Workflow Skills

GSD-Lean workflow skills reside in `skills/` at the repo root. These guide the agent through the 5-phase development cycle:

| Skill | Purpose |
|-------|---------|
| `/init` | Guided project initialization — scaffold, auto-detect stack, onboard |
| `/discuss` | Research subagent + user preference probing → populates REQUIREMENTS.md and DECISIONS.md |
| `/plan` | Decomposes requirements into T-NNN tasks, writes PLAN.md, verifies via subagent |
| `/execute` | Executes next task — spawns executor subagent, verifies, auto-debugs, commits |
| `/verify` | Runs project checks (lint, typecheck, tests) against task verification criteria |
| `/complete` | Transitions to complete phase, generates summary of work done |

### GSD-Lean CLI Commands

The `gsd-lean` CLI provides commands for programmatic state management:

| Command | Description |
|---------|-------------|
| `uvx gsd-lean init` | Initialize `.planning/` directory with state files |
| `uvx gsd-lean status` | Show current phase and project state |
| `uvx gsd-lean transition <phase>` | Transition to a new phase (discuss, plan, execute, verify, complete) |
| `uvx gsd-lean new-cycle` | Archive current cycle and start fresh (scaffold new cycle/ templates) |
| `uvx gsd-lean migrate` | Migrate v1 `.planning/` layout to v2 (static/cycle split) |
| `uvx gsd-lean plan-status` | Display plan progress summary (tasks done/total, current wave, next task) |

**Transition options:**
- `--force` — Bypass precondition checks
- `--note <text>` — Add note to history table
- `--path <dir>` — Project root (default: current directory)

**New-cycle options:**
- `--no-archive` — Delete old cycle files instead of archiving
- `--path <dir>` — Project root (default: current directory)

**Plan-status options:**
- `--json` — Output as JSON for scripting/ralph
- `--path <dir>` — Project root (default: current directory)

### Marketplace

Bifurcate-Loops have a centralized marketplace for Claude Code plugins (`Bifurcate-Loops/bifurcate-plugins`) on GitHub. All plugins developed by Bifurcate are referenced in the `.claude-plugin/marketplace.json` in `bifurcate-plugins`.

---

## Code Style

- **Ruff** for linting + formatting. Line length: 130. Single quotes for code, double quotes for docstrings.
- **Google-style docstrings** (pydocstyle convention). Module/package docstrings not required (`D100`, `D104` ignored).
- **Pyright** strict type checking.
- Lint rules: pycodestyle, pyflakes, pyupgrade, flake8-bugbear, flake8-simplify, isort, pydocstyle, pylint.
- **Markdown**: when a fenced code block contains inner fences, use 4-backtick (` ```` `) outer fences so inner ` ``` ` won't close them.

---

## CI

GitHub Actions runs on push/PR to `main`:
1. **lint** — pre-commit (ruff, pyright, yamllint, file checks) on Python 3.14
2. **test** — pytest + coverage on Python 3.12, 3.13, 3.14
3. **coverage** — combined report, minimum 90% required
4. **check** — all-green gate (lint + test + coverage must pass)
5. **github-release** — triggered by `v*` tag push; creates GitHub release

---

## Release Management

Tag-based releases: `git tag -a v0.1.X -m "Release v0.1.X" && git push origin v0.1.X`. See `RELEASE.md`.

---

## AI Assistant Operating Guidelines

### 1. CRITICAL - LSP Tool Usage
- **Prefer LSP over Grep** for code navigation tasks (finding definitions, references, implementations)
- **Available operations**: `goToDefinition`, `findReferences`, `hover`, `documentSymbol`, `workspaceSymbol`, `goToImplementation`, `incomingCalls`, `outgoingCalls`
- **Use cases**:
  - Finding where a function/class is defined → `goToDefinition`
  - Finding all usages of a symbol → `findReferences`
  - Understanding a symbol's type/docs → `hover`
  - Listing all symbols in a file → `documentSymbol`
  - Impact analysis before refactoring → `findReferences`
- **Supported languages**: TypeScript/JavaScript (typescript-lsp), Python (pyright-lsp)
- **Note**: Requires `ENABLE_LSP_TOOL=1` in `.claude/settings.json` env section

---

## Further Reading

- **[PROJECT_KNOWLEDGE.md](./PROJECT_KNOWLEDGE.md)**: System architecture, tech stack rationale, data flow, deployment
- **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)**: Common issues, CI/CD debugging, environment problems, performance
- **[RELEASE.md](./RELEASE.md)**: Release management
