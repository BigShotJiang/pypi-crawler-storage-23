# CONTEXT.md Quality Criteria

> Adapted from the internal `/claude-md-improver` rubric. Evaluates seeded `.planning/CONTEXT.md` quality across 4 dimensions (25 points each, 100 total).

## Scoring Rubric

### 1. Architecture Clarity (25 points)

**25 points**: Clear codebase map
- Entry points identified (main, CLI, request handler)
- Module relationships documented
- Key data flow described
- Not just directory listing — explains *how things connect*

**20 points**: Good structure, minor gaps (e.g., data flow missing)

**15 points**: Entry points + directories but no relationships

**10 points**: Basic directory listing only

**5 points**: Vague or incomplete

**0 points**: `(none yet)` placeholder or empty

### 2. Commands/Workflows (25 points)

**25 points**: All essential dev commands documented
- Build, test, lint, deploy present
- Copy-paste ready (backtick-wrapped, with flags)
- Brief purpose for each command
- Common failure modes noted where relevant

**20 points**: Most commands present, some missing context/flags

**15 points**: Key commands present but not copy-paste ready

**10 points**: Basic commands only, no workflow context

**5 points**: Few commands, many missing

**0 points**: `(none yet)` placeholder or empty

### 3. Non-Obvious Patterns (25 points)

**25 points**: Gotchas and quirks captured
- Ordering dependencies (init-before-use)
- Shared state / test isolation requirements
- Env vars required at build or test time
- "Why we do it this way" for unusual patterns
- Workarounds for known issues

**20 points**: Most gotchas captured, minor omissions

**15 points**: Some patterns documented

**10 points**: One or two gotchas only

**5 points**: Minimal, generic advice

**0 points**: `(none yet)` placeholder or empty

### 4. Actionability (25 points)

**25 points**: Content is project-specific and executable
- No `(none yet)` placeholders remaining
- Every entry is project-specific, not generic
- Commands reference real scripts/targets
- A fresh agent session would find this immediately useful

**20 points**: Mostly actionable, one or two generic entries

**15 points**: Mix of actionable and placeholder content

**10 points**: Mostly generic advice

**5 points**: Mostly placeholders

**0 points**: All sections still `(none yet)`

## Grading Scale

| Grade | Score | Interpretation |
|-------|-------|----------------|
| A | 90-100 | Excellent — rich, project-specific context |
| B | 70-89 | Good — useful but has gaps |
| C | 50-69 | Adequate — basics present, needs enrichment |
| D | 30-49 | Poor — mostly placeholders or generic |
| F | 0-29 | Insufficient — no meaningful content seeded |

## Assessment Process

1. Read `.planning/CONTEXT.md` after seeding
2. Score each dimension using the rubric above
3. Calculate total and assign grade
4. List specific issues found
5. If score < 50: suggest user manually enrich CONTEXT.md

## Red Flags

- `(none yet)` placeholders still present after seeding
- Generic advice not specific to the project ("write tests", "use meaningful names")
- Commands referencing nonexistent scripts or targets
- Obvious-from-code info restated (class names, directory purposes clear from naming)
- Info already in CLAUDE.md duplicated instead of referenced
- Verbose explanations where one-liners suffice
