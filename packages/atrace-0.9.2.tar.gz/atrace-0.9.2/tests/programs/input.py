import atrace  # noqa

x = input("your name")
print("hello", x)
