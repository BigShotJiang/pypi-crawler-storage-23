import atrace  # noqa

if True:  # Just to prevent reordering of inputs by the ide
    import math

print(math.pi)
