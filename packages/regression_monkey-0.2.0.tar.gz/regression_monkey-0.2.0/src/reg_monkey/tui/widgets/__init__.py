"""
TUI 组件模块
"""

from .regression_table import RegressionTableWidget

__all__ = ["RegressionTableWidget"]
