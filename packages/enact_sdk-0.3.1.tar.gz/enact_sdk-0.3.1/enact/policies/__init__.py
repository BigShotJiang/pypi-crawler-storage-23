"""Built-in reusable policy functions."""
