"""Deezer lyrics plugin for LibreLyrics.

Provides lyrics from Deezer's GraphQL API with word-level sync support.
Requires ARL cookie for authentication.

Install: pip install librelyrics-deezer
"""
from deezer.module import DeezerModule

__all__ = ['DeezerModule']
