# librelyrics-deezer

Deezer lyrics provider plugin for [LibreLyrics](https://github.com/libre-lyrics/librelyrics).

## Features

- Fetch plain, synced, and rich synced (word-level) lyrics from Deezer
- Word-by-word karaoke-style lyrics via GraphQL API
- Support for track and album URLs

## Installation

```bash
pip install librelyrics-deezer
```

## Configuration

Requires a Deezer `arl` cookie. Set it up via:

```bash
librelyrics config edit
```

Or set it directly:

```bash
librelyrics config set plugins.Deezer.arl "YOUR_ARL_COOKIE"
```

### Getting your `arl` cookie

1. Open [Deezer Web Player](https://www.deezer.com) in your browser
2. Log in to your account
3. Open Developer Tools (F12) → Application → Cookies
4. Find the `arl` cookie and copy its value

## Supported URLs

- `https://www.deezer.com/track/<id>`
- `https://www.deezer.com/album/<id>`

## Usage

Once installed, the plugin is automatically discovered by LibreLyrics:

```bash
librelyrics "https://www.deezer.com/track/123456789"
```

## License

GPL-3.0-or-later
