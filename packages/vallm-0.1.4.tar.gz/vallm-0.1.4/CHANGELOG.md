## [0.1.4] - 2026-03-01

### Summary

feat(examples): code analysis engine

### Docs

- docs: update README
- docs: update README
- docs: update README
- docs: update README
- docs: update README
- docs: update README
- docs: update README
- docs: update README

### Other

- update examples/01_basic_validation/main.py
- update examples/02_ast_comparison/main.py
- update examples/03_security_check/main.py
- update examples/04_graph_analysis.py
- update examples/04_graph_analysis/main.py
- update examples/05_llm_semantic_review/main.py
- update examples/05_llm_semantic_review/main_template.py
- update examples/06_multilang_validation/main.py
- update examples/06_multilang_validation/main_template.py
- scripts: update run.sh


## [0.1.3] - 2026-03-01

### Summary

fix(tests): code analysis engine

### Core

- update src/vallm/__init__.py
- update src/vallm/cli.py
- update src/vallm/config.py
- update src/vallm/core/graph_diff.py
- update src/vallm/sandbox/__init__.py
- update src/vallm/sandbox/runner.py
- update src/vallm/scoring.py
- update src/vallm/validators/__init__.py
- update src/vallm/validators/base.py
- update src/vallm/validators/complexity.py
- ... and 4 more

### Docs

- docs: update README
- docs: update README
- docs: update context.md

### Test

- update tests/__init__.py
- update tests/test_ast_compare.py
- update tests/test_complexity.py
- update tests/test_graph.py
- update tests/test_imports.py
- update tests/test_pipeline.py
- update tests/test_scoring.py
- update tests/test_security.py
- update tests/test_syntax.py

### Build

- update pyproject.toml

### Config

- config: update goal.yaml

### Other

- update examples/01_basic_validation.py
- update examples/02_ast_comparison.py
- update examples/03_security_check.py
- update examples/04_graph_analysis.py
- update examples/05_llm_semantic_review.py
- update examples/06_multilang_validation.py
- scripts: update project.sh
- update project.toon
- update project/analysis.toon
- update project/evolution.toon


## [0.1.1] - 2026-03-01

### Summary

refactor(docs): configuration management system

### Core

- update src/vallm/__init__.py
- update src/vallm/__main__.py
- update src/vallm/config.py
- update src/vallm/core/__init__.py
- update src/vallm/core/ast_compare.py
- update src/vallm/core/graph_builder.py
- update src/vallm/core/proposal.py
- update src/vallm/hookspecs.py

### Docs

- docs: update TODO.md

### Test

- update tests/test_vallm.py

### Build

- update pyproject.toml

### Config

- config: update goal.yaml

### Other

- update .gitignore
- build: update Makefile
- update TICKET


# CHANGELOG

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project setup

### Changed

### Fixed

### Removed

---

Last updated: 2026-03-01