from setuptools import setup

setup(
    name="fasttgbot",
    version="37.0.0",
    description="простая библиотека для создания простого бота",
    long_description="библиотека не расчитана на большие проэкты с кучей функций, она так чисто для прикола",
    author="mawwki",
    author_email="igrok.lui@gmail.com",
    py_modules=["fasttgbot"],
    install_requires=["pytelegrambotapi"],
)