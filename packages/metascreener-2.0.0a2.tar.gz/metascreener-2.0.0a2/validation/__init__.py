"""MetaScreener validation experiments for Lancet Digital Health submission."""
