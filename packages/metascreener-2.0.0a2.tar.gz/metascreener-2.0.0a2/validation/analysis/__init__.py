"""Paper output generators (tables and figures)."""
