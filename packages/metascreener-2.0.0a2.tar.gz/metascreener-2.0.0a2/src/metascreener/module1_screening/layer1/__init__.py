"""MetaScreener Layer 1 — Parallel LLM Inference with framework-specific prompts."""
