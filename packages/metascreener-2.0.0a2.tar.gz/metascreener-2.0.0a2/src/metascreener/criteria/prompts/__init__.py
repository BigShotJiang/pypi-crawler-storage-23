"""Prompt templates for the criteria wizard (version-locked)."""
