"""Extraction prompt templates."""
