"""
Main PyMetabase client
"""

import logging
import re
import time
import json
import math
import requests
import sqlglot
from pathlib import Path
from urllib.parse import urlencode
from typing import Optional, Union, List, Dict, Any, Callable
from dataclasses import dataclass

from .auth import MetabaseAuth
from .config import MetabaseConfig, load_config
from .exceptions import (
    AuthenticationError,
    QueryError,
    ExportError,
    ChunkError,
    DatabaseNotFoundError,
    APIError,
    NotFoundError,
)
from .formats import get_format_handler
from .remotes import RemoteManager

logger = logging.getLogger(__name__)


@dataclass
class ExportResult:
    """Result of an export operation"""
    total_rows: int
    chunks: int
    duration_seconds: float
    output_file: str
    rate_per_second: float
    format: str


class Metabase:
    """
    PyMetabase client for exporting data from Metabase.

    Example:
        ```python
        from pymetabase import Metabase

        # Connect to Metabase
        mb = Metabase(
            url="https://metabase.example.com",
            username="user@example.com",
            password="password"
        )

        # Export query results
        result = mb.export(
            database="MyDatabase",
            query="SELECT * FROM users",
            output="users.jsonl"
        )

        print(f"Exported {result.total_rows} rows")
        ```
    """

    def __init__(
        self,
        url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        config_file: Optional[str] = None,
        credentials_file: Optional[str] = None,
        remote_name: Optional[str] = None,
        persist_token: bool = True,
        **kwargs
    ):
        """
        Initialize PyMetabase client.

        Args:
            url: Metabase server URL
            username: Login username/email
            password: Login password
            config_file: Path to config file (YAML/JSON)
            credentials_file: Path to credentials file
            remote_name: Name of the remote (for token persistence)
            persist_token: Whether to persist session tokens for reuse (default: True)
            **kwargs: Additional config overrides
        """
        # Load configuration
        self.config = load_config(
            config_file=config_file,
            credentials_file=credentials_file,
            url=url,
            username=username,
            password=password,
            **kwargs
        )

        # Setup logging
        self._setup_logging()

        # Setup remote manager for token persistence
        self._remote_name = remote_name
        self._persist_token = persist_token
        self._remote_manager = RemoteManager() if persist_token else None

        # Initialize auth
        self._auth = MetabaseAuth(
            url=self.config.url,
            username=self.config.username,
            password=self.config.password,
            timeout=self.config.timeout,
            remote_name=remote_name,
            remote_manager=self._remote_manager,
        )

        # Cache for databases
        self._databases: Optional[List[Dict]] = None

        logger.debug(f"Initialized PyMetabase client for {self.config.url}")

    def _setup_logging(self):
        """Setup logging based on config"""
        log_level = getattr(logging, self.config.log_level.upper(), logging.INFO)
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        if self.config.log_file:
            handler = logging.FileHandler(self.config.log_file)
            handler.setLevel(log_level)
            logging.getLogger().addHandler(handler)

    def __enter__(self):
        """Context manager entry"""
        self._auth.login()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - preserves stored token by default"""
        # Don't clear stored token on context exit so it can be reused
        self._auth.logout(clear_stored_token=False)

    def connect(self) -> "Metabase":
        """Connect and authenticate with Metabase"""
        self._auth.login()
        logger.info("Connected to Metabase")
        return self

    def disconnect(self, clear_stored_token: bool = False):
        """
        Disconnect from Metabase.

        Args:
            clear_stored_token: Whether to clear the stored token (default: False)
        """
        self._auth.logout(clear_stored_token=clear_stored_token)
        logger.info("Disconnected from Metabase")

    def _ensure_connected(self):
        """Ensure we're connected"""
        self._auth.ensure_authenticated()

    def _get_headers(self) -> Dict[str, str]:
        """Get API headers"""
        return self._auth.get_headers()

    # ==================== Database Operations ====================

    def list_databases(self, refresh: bool = False) -> List[Dict]:
        """
        List all available databases.

        Args:
            refresh: Force refresh the cache

        Returns:
            List of database info dicts
        """
        self._ensure_connected()

        if self._databases is None or refresh:
            try:
                response = requests.get(
                    f"{self.config.url}/api/database",
                    headers=self._get_headers(),
                    timeout=self.config.timeout
                )
                response.raise_for_status()
            except requests.exceptions.RequestException as e:
                raise QueryError(f"Failed to list databases: {e}")
            self._databases = response.json().get('data', [])
            logger.debug(f"Found {len(self._databases)} databases")

        return self._databases

    def get_database_id(self, database: Union[str, int]) -> int:
        """
        Get database ID from name or ID.

        Args:
            database: Database name or ID

        Returns:
            Database ID

        Raises:
            DatabaseNotFoundError: If database name cannot be resolved
            ValueError: If database is None
        """
        if database is None:
            raise ValueError("database parameter is required")
        if isinstance(database, int):
            return database

        databases = self.list_databases()
        for db in databases:
            if db.get('name', '').lower() == database.lower():
                return db['id']

        raise DatabaseNotFoundError(f"Database not found: {database}")

    def list_tables(self, database: Union[str, int]) -> List[Dict]:
        """
        List tables in a database.

        Args:
            database: Database name or ID

        Returns:
            List of table info dicts
        """
        self._ensure_connected()
        db_id = self.get_database_id(database)

        try:
            response = requests.get(
                f"{self.config.url}/api/database/{db_id}/metadata",
                headers=self._get_headers(),
                timeout=self.config.timeout
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise QueryError(f"Failed to list tables for database {database}: {e}")

        tables = response.json().get('tables', [])
        logger.debug(f"Found {len(tables)} tables in database {database}")
        return tables

    # ==================== Export Operations ====================

    def export(
        self,
        query: str,
        output: str,
        database: Union[str, int] = None,
        format: str = None,
        chunk_size: int = None,
        auto_chunk_threshold: int = None,
        progress_callback: Callable[[int, int, float], None] = None,
        checkpoint_file: str = None,
        csv_field_size_limit: int = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> ExportResult:
        """
        Export query results to file with automatic chunking for large datasets.

        Args:
            query: SQL query string (use {{param}} for parameterized queries)
            output: Output file path
            database: Database name or ID
            format: Output format (jsonl, json, csv) - auto-detected from extension if not specified
            chunk_size: Rows per chunk (default from config)
            auto_chunk_threshold: Threshold to trigger chunking (default from config)
            progress_callback: Callback function(current_rows, total_rows, rate)
            checkpoint_file: File to save progress for resume
            csv_field_size_limit: Maximum field size for CSV format (default: 10MB for large fields)
            parameters: Dict of parameter name -> value for parameterized queries

        Returns:
            ExportResult with export statistics
        """
        self._ensure_connected()

        # Resolve parameters
        db_id = self.get_database_id(database)
        chunk_size = chunk_size or self.config.chunk_size
        auto_chunk_threshold = auto_chunk_threshold or self.config.auto_chunk_threshold

        # Auto-detect format from extension
        if format is None:
            ext = Path(output).suffix.lower()
            format_map = {'.jsonl': 'jsonl', '.json': 'json', '.csv': 'csv'}
            format = format_map.get(ext, self.config.output_format)

        logger.info(f"Starting export to {output} (format: {format})")

        # Get row count
        total_rows = self._get_row_count(db_id, query)
        if total_rows is None:
            logger.warning("Could not determine row count, using bulk export")
            return self._bulk_export(db_id, query, output, format, parameters=parameters)

        logger.info(f"Total rows: {total_rows:,}")

        # Set default CSV field size limit if not specified (10MB for large fields)
        if csv_field_size_limit is None:
            csv_field_size_limit = 10 * 1024 * 1024  # 10MB default

        # Decide if chunking is needed
        if total_rows <= auto_chunk_threshold:
            logger.info(f"Row count below threshold ({auto_chunk_threshold:,}), using bulk export")
            return self._bulk_export(db_id, query, output, format, csv_field_size_limit=csv_field_size_limit, parameters=parameters)

        # Chunked export
        num_chunks = math.ceil(total_rows / chunk_size)
        logger.info(f"Splitting into {num_chunks} chunks of ~{chunk_size:,} rows")

        return self._chunked_export(
            db_id=db_id,
            query=query,
            output=output,
            format=format,
            total_rows=total_rows,
            chunk_size=chunk_size,
            progress_callback=progress_callback,
            checkpoint_file=checkpoint_file,
            csv_field_size_limit=csv_field_size_limit,
            parameters=parameters,
        )

    def _get_row_count(self, db_id: int, query: str) -> Optional[int]:
        """Get row count for a query"""
        try:
            parsed = sqlglot.parse_one(query)
            count_query = sqlglot.select("COUNT(*) AS cnt").from_(
                parsed.subquery("_count_subq")
            ).sql()
        except Exception as e:
            logger.warning(f"SQL parsing failed: {e}")
            count_query = f"SELECT COUNT(*) AS cnt FROM ({query}) AS _count_subq"

        try:
            response = requests.post(
                f"{self.config.url}/api/dataset",
                headers=self._get_headers(),
                json={
                    "database": db_id,
                    "type": "native",
                    "native": {"query": count_query},
                    "parameters": []
                },
                timeout=self.config.timeout
            )
            response.raise_for_status()
            result = response.json()
            if result.get('status') == 'failed':
                logger.warning(f"Count query failed: {result.get('error', 'Unknown error')}")
                return None
            data = result.get('data', {})
            rows = data.get('rows', [])
            return rows[0][0] if rows else None
        except Exception as e:
            logger.error(f"Count query failed: {e}")
            return None

    def _bulk_export(
        self,
        db_id: int,
        query: str,
        output: str,
        format: str,
        csv_field_size_limit: int = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> ExportResult:
        """Export entire result set in one request"""
        start_time = time.time()

        # Use CSV endpoint for bulk download
        api_url = f"{self.config.url}/api/dataset/csv"
        headers = {
            "X-Metabase-Session": self._auth.session_token,
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        }

        query_payload = self._build_query_payload(db_id, query, parameters)

        form_data = {
            "query": json.dumps(query_payload, ensure_ascii=False),
        }

        try:
            response = requests.post(
                api_url,
                headers=headers,
                data=urlencode(form_data, encoding='utf-8'),
                timeout=self.config.timeout
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise ExportError(f"Bulk export failed: {e}")

        # Write to output file
        format_kwargs = {}
        if format == 'csv' and csv_field_size_limit is not None:
            format_kwargs['field_size_limit'] = csv_field_size_limit

        with open(output, 'w', encoding='utf-8') as f:
            formatter = get_format_handler(format, f, **format_kwargs)
            row_count = formatter.write_csv_response(response.text)
            formatter.finalize()

        duration = time.time() - start_time
        rate = row_count / duration if duration > 0 else 0

        logger.info(f"Exported {row_count:,} rows in {duration:.1f}s ({rate:.0f} rows/sec)")

        return ExportResult(
            total_rows=row_count,
            chunks=1,
            duration_seconds=duration,
            output_file=output,
            rate_per_second=rate,
            format=format
        )

    def _chunked_export(
        self,
        db_id: int,
        query: str,
        output: str,
        format: str,
        total_rows: int,
        chunk_size: int,
        progress_callback: Callable = None,
        checkpoint_file: str = None,
        csv_field_size_limit: int = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> ExportResult:
        """Export using ROW_NUMBER() chunking"""
        start_time = time.time()
        total_count = 0
        num_chunks = math.ceil(total_rows / chunk_size)

        # Load checkpoint if resuming
        start_chunk = 1
        if checkpoint_file and Path(checkpoint_file).exists():
            with open(checkpoint_file, 'r') as f:
                checkpoint = json.load(f)
                start_chunk = checkpoint.get('next_chunk', 1)
                total_count = checkpoint.get('total_count', 0)
                logger.info(f"Resuming from chunk {start_chunk}")

        format_kwargs = {}
        if format == 'csv' and csv_field_size_limit is not None:
            format_kwargs['field_size_limit'] = csv_field_size_limit

        with open(output, 'a' if start_chunk > 1 else 'w', encoding='utf-8') as f:
            formatter = get_format_handler(format, f, **format_kwargs)

            for chunk_num in range(start_chunk, num_chunks + 1):
                start_row = (chunk_num - 1) * chunk_size + 1
                end_row = min(chunk_num * chunk_size, total_rows)

                logger.info(f"Chunk {chunk_num}/{num_chunks}: rows {start_row:,} to {end_row:,}")

                # Build query with ROW_NUMBER
                chunk_query = f"""
                    WITH _numbered AS (
                        SELECT *, ROW_NUMBER() OVER () AS _row_num
                        FROM ({query}) AS _base
                    )
                    SELECT * FROM _numbered
                    WHERE _row_num >= {start_row} AND _row_num <= {end_row}
                """

                # Export with retry
                chunk_count = self._export_chunk_with_retry(
                    db_id, chunk_query, formatter
                )
                total_count += chunk_count

                # Progress callback
                elapsed = time.time() - start_time
                rate = total_count / elapsed if elapsed > 0 else 0

                if progress_callback:
                    progress_callback(total_count, total_rows, rate)

                # Save checkpoint
                if checkpoint_file:
                    with open(checkpoint_file, 'w') as cp:
                        json.dump({
                            'next_chunk': chunk_num + 1,
                            'total_count': total_count,
                            'total_rows': total_rows,
                        }, cp)

                logger.info(f"  Exported {chunk_count:,} rows | Total: {total_count:,} | Rate: {rate:.0f}/sec")

            formatter.finalize()

        # Remove checkpoint on success
        if checkpoint_file and Path(checkpoint_file).exists():
            Path(checkpoint_file).unlink()

        duration = time.time() - start_time
        rate = total_count / duration if duration > 0 else 0

        logger.info(f"Export complete: {total_count:,} rows in {duration:.1f}s ({rate:.0f} rows/sec)")

        return ExportResult(
            total_rows=total_count,
            chunks=num_chunks,
            duration_seconds=duration,
            output_file=output,
            rate_per_second=rate,
            format=format
        )

    def _export_chunk_with_retry(
        self,
        db_id: int,
        query: str,
        formatter
    ) -> int:
        """Export a single chunk with retry logic"""
        api_url = f"{self.config.url}/api/dataset/csv"
        headers = {
            "X-Metabase-Session": self._auth.session_token,
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        }

        query_payload = {
            "database": db_id,
            "type": "native",
            "native": {"query": query, "template-tags": {}},
        }

        form_data = {
            "query": json.dumps(query_payload, ensure_ascii=False),
        }

        for attempt in range(self.config.max_retries):
            try:
                response = requests.post(
                    api_url,
                    headers=headers,
                    data=urlencode(form_data, encoding='utf-8'),
                    timeout=self.config.timeout
                )
                response.raise_for_status()
                return formatter.write_csv_response(response.text)

            except requests.exceptions.RequestException as e:
                if attempt < self.config.max_retries - 1:
                    wait_time = self.config.retry_delay * (2 ** attempt)
                    logger.warning(f"Chunk failed (attempt {attempt + 1}): {e}")
                    logger.info(f"Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Chunk failed after {self.config.max_retries} attempts")
                    raise ChunkError(f"Failed to export chunk: {e}")

    # ==================== Generic API Methods ====================

    def _api_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """
        Make an authenticated API request to Metabase.

        Args:
            method: HTTP method (get, post, put, delete)
            endpoint: API endpoint path (e.g., '/api/card')
            **kwargs: Passed to requests (json, params, data, etc.)

        Returns:
            requests.Response

        Raises:
            NotFoundError: If endpoint returns 404
            APIError: If request fails
        """
        self._ensure_connected()

        if not endpoint.startswith('/'):
            endpoint = f'/{endpoint}'
        url = f"{self.config.url}{endpoint}"
        headers = self._get_headers()

        # For form-data requests, override Content-Type
        if 'data' in kwargs:
            headers = {k: v for k, v in headers.items() if k != 'Content-Type'}

        timeout = kwargs.pop('timeout', self.config.timeout)

        try:
            response = requests.request(
                method,
                url,
                headers=headers,
                timeout=timeout,
                **kwargs
            )
        except requests.exceptions.RequestException as e:
            raise APIError(f"{method.upper()} {endpoint} failed: {e}")

        if response.status_code == 404:
            raise NotFoundError(f"{method.upper()} {endpoint}: Not found", response=response)

        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            raise APIError(f"{method.upper()} {endpoint} failed: {e}", response=response)

        return response

    def get(self, endpoint: str, **kwargs) -> Any:
        """
        Make an authenticated GET request.

        Args:
            endpoint: API endpoint (e.g., '/api/card', '/api/user/current')
            **kwargs: Additional arguments (params, timeout, etc.)

        Returns:
            Parsed JSON response
        """
        response = self._api_request('get', endpoint, **kwargs)
        return response.json() if response.content else None

    def post(self, endpoint: str, **kwargs) -> Any:
        """
        Make an authenticated POST request.

        Args:
            endpoint: API endpoint
            **kwargs: Additional arguments (json, data, params, etc.)

        Returns:
            Parsed JSON response
        """
        response = self._api_request('post', endpoint, **kwargs)
        return response.json() if response.content else None

    def put(self, endpoint: str, **kwargs) -> Any:
        """
        Make an authenticated PUT request.

        Args:
            endpoint: API endpoint
            **kwargs: Additional arguments (json, data, params, etc.)

        Returns:
            Parsed JSON response
        """
        response = self._api_request('put', endpoint, **kwargs)
        return response.json() if response.content else None

    def delete_resource(self, endpoint: str, **kwargs) -> Any:
        """
        Make an authenticated DELETE request.

        Args:
            endpoint: API endpoint
            **kwargs: Additional arguments

        Returns:
            Parsed JSON response or None
        """
        response = self._api_request('delete', endpoint, **kwargs)
        return response.json() if response.content else None

    # ==================== Cards/Questions API ====================

    def list_cards(self) -> List[Dict]:
        """
        List all saved questions/cards.

        Returns:
            List of card objects
        """
        return self.get('/api/card')

    def get_card(self, card_id: int) -> Dict:
        """
        Get a specific card/saved question.

        Args:
            card_id: Card ID

        Returns:
            Card object
        """
        return self.get(f'/api/card/{card_id}')

    def create_card(
        self,
        name: str,
        dataset_query: Dict,
        display: str = "table",
        visualization_settings: Optional[Dict] = None,
        collection_id: Optional[int] = None,
        description: Optional[str] = None,
    ) -> Dict:
        """
        Create a new card/saved question.

        Args:
            name: Card name
            dataset_query: Query definition dict
            display: Display type (table, bar, line, etc.)
            visualization_settings: Visualization config
            collection_id: Target collection ID
            description: Card description

        Returns:
            Created card object
        """
        payload = {
            "name": name,
            "dataset_query": dataset_query,
            "display": display,
            "visualization_settings": visualization_settings or {},
        }
        if collection_id is not None:
            payload["collection_id"] = collection_id
        if description is not None:
            payload["description"] = description

        return self.post('/api/card', json=payload)

    def update_card(self, card_id: int, **kwargs) -> Dict:
        """
        Update a card/saved question.

        Args:
            card_id: Card ID
            **kwargs: Fields to update (name, description, dataset_query, etc.)

        Returns:
            Updated card object
        """
        return self.put(f'/api/card/{card_id}', json=kwargs)

    def delete_card(self, card_id: int) -> None:
        """
        Delete (archive) a card/saved question.

        Args:
            card_id: Card ID
        """
        self.put(f'/api/card/{card_id}', json={"archived": True})

    def execute_card(self, card_id: int, parameters: Optional[Dict] = None) -> Dict:
        """
        Execute a saved question/card and return results.

        Args:
            card_id: Card ID
            parameters: Optional parameter values for parameterized questions

        Returns:
            Query result data
        """
        if parameters:
            return self.post(f'/api/card/{card_id}/query', json={"parameters": parameters})
        return self.post(f'/api/card/{card_id}/query')

    # ==================== Dashboards API ====================

    def list_dashboards(self) -> List[Dict]:
        """
        List all dashboards.

        Returns:
            List of dashboard objects
        """
        return self.get('/api/dashboard')

    def get_dashboard(self, dashboard_id: int) -> Dict:
        """
        Get a specific dashboard.

        Args:
            dashboard_id: Dashboard ID

        Returns:
            Dashboard object with cards
        """
        return self.get(f'/api/dashboard/{dashboard_id}')

    def create_dashboard(
        self,
        name: str,
        collection_id: Optional[int] = None,
        description: Optional[str] = None,
        parameters: Optional[List[Dict]] = None,
    ) -> Dict:
        """
        Create a new dashboard.

        Args:
            name: Dashboard name
            collection_id: Target collection ID
            description: Dashboard description
            parameters: Dashboard filter parameters

        Returns:
            Created dashboard object
        """
        payload = {"name": name}
        if collection_id is not None:
            payload["collection_id"] = collection_id
        if description is not None:
            payload["description"] = description
        if parameters is not None:
            payload["parameters"] = parameters
        return self.post('/api/dashboard', json=payload)

    def update_dashboard(self, dashboard_id: int, **kwargs) -> Dict:
        """
        Update a dashboard.

        Args:
            dashboard_id: Dashboard ID
            **kwargs: Fields to update (name, description, etc.)

        Returns:
            Updated dashboard object
        """
        return self.put(f'/api/dashboard/{dashboard_id}', json=kwargs)

    def delete_dashboard(self, dashboard_id: int) -> None:
        """
        Delete (archive) a dashboard.

        Args:
            dashboard_id: Dashboard ID
        """
        self.put(f'/api/dashboard/{dashboard_id}', json={"archived": True})

    # ==================== Collections API ====================

    def list_collections(self) -> List[Dict]:
        """
        List all collections.

        Returns:
            List of collection objects
        """
        return self.get('/api/collection')

    def get_collection(self, collection_id: Union[int, str]) -> Dict:
        """
        Get a specific collection.

        Args:
            collection_id: Collection ID or 'root' for the root collection

        Returns:
            Collection object
        """
        return self.get(f'/api/collection/{collection_id}')

    def get_collection_items(
        self,
        collection_id: Union[int, str],
        models: Optional[List[str]] = None,
    ) -> List[Dict]:
        """
        Get items in a collection.

        Args:
            collection_id: Collection ID or 'root'
            models: Filter by model types (e.g., ['card', 'dashboard'])

        Returns:
            List of collection items
        """
        params = {}
        if models:
            params['models'] = models
        result = self.get(f'/api/collection/{collection_id}/items', params=params)
        return result.get('data', result) if isinstance(result, dict) else result

    def create_collection(
        self,
        name: str,
        parent_id: Optional[int] = None,
        description: Optional[str] = None,
        color: Optional[str] = None,
    ) -> Dict:
        """
        Create a new collection.

        Args:
            name: Collection name
            parent_id: Parent collection ID (None for root)
            description: Collection description
            color: Collection color hex code

        Returns:
            Created collection object
        """
        payload = {"name": name}
        if parent_id is not None:
            payload["parent_id"] = parent_id
        if description is not None:
            payload["description"] = description
        if color is not None:
            payload["color"] = color
        return self.post('/api/collection', json=payload)

    # ==================== Search API ====================

    def search(
        self,
        query: str,
        models: Optional[List[str]] = None,
        limit: Optional[int] = None,
    ) -> List[Dict]:
        """
        Search across Metabase resources.

        Args:
            query: Search query string
            models: Filter by model types (e.g., ['card', 'dashboard', 'collection'])
            limit: Maximum results to return

        Returns:
            List of matching resources
        """
        params = {"q": query}
        if models:
            for model in models:
                params.setdefault('models', [])
            params['models'] = models
        if limit is not None:
            params['limit'] = limit
        result = self.get('/api/search', params=params)
        return result.get('data', result) if isinstance(result, dict) else result

    # ==================== Users API ====================

    def get_current_user(self) -> Dict:
        """
        Get the currently authenticated user.

        Returns:
            User object
        """
        return self.get('/api/user/current')

    def list_users(self) -> List[Dict]:
        """
        List all users (admin only).

        Returns:
            List of user objects
        """
        result = self.get('/api/user')
        return result.get('data', result) if isinstance(result, dict) else result

    def get_user(self, user_id: int) -> Dict:
        """
        Get a specific user.

        Args:
            user_id: User ID

        Returns:
            User object
        """
        return self.get(f'/api/user/{user_id}')

    # ==================== Tables/Fields API ====================

    def get_table(self, table_id: int) -> Dict:
        """
        Get table metadata.

        Args:
            table_id: Table ID

        Returns:
            Table metadata object
        """
        return self.get(f'/api/table/{table_id}')

    def get_table_metadata(self, table_id: int) -> Dict:
        """
        Get detailed table metadata including fields.

        Args:
            table_id: Table ID

        Returns:
            Table metadata with fields
        """
        return self.get(f'/api/table/{table_id}/query_metadata')

    def get_field(self, field_id: int) -> Dict:
        """
        Get field metadata.

        Args:
            field_id: Field ID

        Returns:
            Field metadata object
        """
        return self.get(f'/api/field/{field_id}')

    def get_field_values(self, field_id: int) -> Dict:
        """
        Get possible values for a field.

        Args:
            field_id: Field ID

        Returns:
            Field values object
        """
        return self.get(f'/api/field/{field_id}/values')

    # ==================== Query Helpers ====================

    def _build_query_payload(
        self,
        db_id: int,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Dict:
        """
        Build a Metabase native query payload with optional parameters.

        Args:
            db_id: Database ID
            query: SQL query (use {{param_name}} for parameters)
            parameters: Dict of parameter name -> value

        Returns:
            Query payload dict
        """
        template_tags = {}
        params_array = []

        if parameters:
            tags = re.findall(r'\{\{(\w+)\}\}', query)
            for tag in tags:
                if tag in parameters:
                    value = parameters[tag]
                    if isinstance(value, (int, float)):
                        tag_type = "number"
                    elif isinstance(value, str):
                        tag_type = "text"
                    else:
                        tag_type = "text"
                        value = str(value)

                    template_tags[tag] = {
                        "id": tag,
                        "name": tag,
                        "display-name": tag.replace("_", " ").title(),
                        "type": tag_type,
                    }
                    params_array.append({
                        "type": tag_type,
                        "value": value,
                        "target": ["variable", ["template-tag", tag]],
                    })

        return {
            "database": db_id,
            "type": "native",
            "native": {
                "query": query,
                "template-tags": template_tags,
            },
            "parameters": params_array,
        }

    def query(
        self,
        query: str,
        database: Union[str, int] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Dict:
        """
        Execute a native SQL query and return results.

        Args:
            query: SQL query string (use {{param}} for parameters)
            database: Database name or ID
            parameters: Dict of parameter name -> value for parameterized queries

        Returns:
            Query result dict with 'data' containing 'rows' and 'cols'
        """
        self._ensure_connected()
        db_id = self.get_database_id(database)
        payload = self._build_query_payload(db_id, query, parameters)

        try:
            response = requests.post(
                f"{self.config.url}/api/dataset",
                headers=self._get_headers(),
                json=payload,
                timeout=self.config.timeout,
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise QueryError(f"Query failed: {e}")

        result = response.json()

        # Metabase returns HTTP 200 even for query errors — check the response status
        if result.get('status') == 'failed':
            error_msg = result.get('error', 'Unknown query error')
            raise QueryError(f"Query failed: {error_msg}")

        return result

    # ==================== Convenience Methods ====================

    def export_table(
        self,
        table: str,
        output: str,
        database: Union[str, int] = None,
        columns: List[str] = None,
        where: str = None,
        order_by: str = None,
        limit: int = None,
        **kwargs
    ) -> ExportResult:
        """
        Export an entire table with optional filtering.

        Args:
            table: Table name
            output: Output file path
            database: Database name or ID
            columns: List of columns to select (default: all)
            where: WHERE clause (without 'WHERE' keyword)
            order_by: ORDER BY clause (without 'ORDER BY' keyword)
            limit: Maximum rows to export
            **kwargs: Additional export options

        Returns:
            ExportResult
        """
        # Build query
        cols = ', '.join(columns) if columns else '*'
        query = f"SELECT {cols} FROM {table}"

        if where:
            query += f" WHERE {where}"
        if order_by:
            query += f" ORDER BY {order_by}"
        if limit:
            query += f" LIMIT {limit}"

        return self.export(query=query, output=output, database=database, **kwargs)
