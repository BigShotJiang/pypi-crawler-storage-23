"""
Configuration management for PyMetabase
"""

import os
import json
import yaml
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, Dict, Any

from .exceptions import ConfigurationError


@dataclass
class MetabaseConfig:
    """Configuration for Metabase connection and export settings"""

    # Connection settings
    url: str = ""
    username: str = ""
    password: str = ""

    # Export defaults
    chunk_size: int = 500000
    auto_chunk_threshold: int = 1000000
    output_format: str = "jsonl"

    # Retry settings
    max_retries: int = 3
    retry_delay: float = 1.0
    timeout: int = 600

    # Logging
    log_level: str = "INFO"
    log_file: Optional[str] = None

    @classmethod
    def from_file(cls, filepath: str) -> "MetabaseConfig":
        """Load configuration from YAML or JSON file"""
        path = Path(filepath)

        if not path.exists():
            raise ConfigurationError(f"Configuration file not found: {filepath}")

        with open(path, 'r') as f:
            if path.suffix in ['.yaml', '.yml']:
                data = yaml.safe_load(f)
            elif path.suffix == '.json':
                data = json.load(f)
            else:
                raise ConfigurationError(f"Unsupported config format: {path.suffix}")

        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetabaseConfig":
        """Create config from dictionary"""
        config = cls()

        # Flatten nested structure
        if 'metabase' in data:
            mb = data['metabase']
            config.url = mb.get('url', config.url)
            config.username = mb.get('username', config.username)
            config.password = mb.get('password', config.password)

        if 'defaults' in data:
            defaults = data['defaults']
            config.chunk_size = defaults.get('chunk_size', config.chunk_size)
            config.auto_chunk_threshold = defaults.get('auto_chunk_threshold', config.auto_chunk_threshold)
            config.output_format = defaults.get('format', config.output_format)

        if 'retry' in data:
            retry = data['retry']
            config.max_retries = retry.get('max_retries', config.max_retries)
            config.retry_delay = retry.get('delay', config.retry_delay)
            config.timeout = retry.get('timeout', config.timeout)

        if 'logging' in data:
            log = data['logging']
            config.log_level = log.get('level', config.log_level)
            config.log_file = log.get('file', config.log_file)

        return config

    @classmethod
    def from_env(cls) -> "MetabaseConfig":
        """Load configuration from environment variables"""
        config = cls()

        config.url = os.getenv('METABASE_URL', config.url)
        config.username = os.getenv('METABASE_USERNAME', config.username)
        config.password = os.getenv('METABASE_PASSWORD', config.password)
        config.chunk_size = int(os.getenv('METABASE_CHUNK_SIZE', config.chunk_size))
        config.log_level = os.getenv('METABASE_LOG_LEVEL', config.log_level)

        return config

    @classmethod
    def from_credentials_file(cls, filepath: str) -> "MetabaseConfig":
        """Load from legacy credentials.json format"""
        path = Path(filepath)

        if not path.exists():
            raise ConfigurationError(f"Credentials file not found: {filepath}")

        with open(path, 'r') as f:
            data = json.load(f)

        config = cls()

        # Handle array format
        if isinstance(data, list) and len(data) > 0:
            cred = data[0]
            config.url = cred.get('SERVER_NAME', '')
            config.username = cred.get('USERNAME', '')
            config.password = cred.get('PASSWORD', '')
        elif isinstance(data, dict):
            config.url = data.get('url', data.get('SERVER_NAME', ''))
            config.username = data.get('username', data.get('USERNAME', ''))
            config.password = data.get('password', data.get('PASSWORD', ''))

        return config


def load_config(
    config_file: Optional[str] = None,
    credentials_file: Optional[str] = None,
    **kwargs
) -> MetabaseConfig:
    """
    Load configuration from various sources.

    Priority: kwargs > config_file > credentials_file > environment
    """
    # Start with environment
    config = MetabaseConfig.from_env()

    # Load from credentials file
    if credentials_file:
        cred_config = MetabaseConfig.from_credentials_file(credentials_file)
        if cred_config.url:
            config.url = cred_config.url
        if cred_config.username:
            config.username = cred_config.username
        if cred_config.password:
            config.password = cred_config.password

    # Load from config file
    if config_file:
        file_config = MetabaseConfig.from_file(config_file)
        for attr in ['url', 'username', 'password', 'chunk_size',
                     'auto_chunk_threshold', 'output_format', 'max_retries',
                     'retry_delay', 'timeout', 'log_level', 'log_file']:
            value = getattr(file_config, attr)
            if value:
                setattr(config, attr, value)

    # Override with kwargs
    for key, value in kwargs.items():
        if hasattr(config, key) and value is not None:
            setattr(config, key, value)

    return config
