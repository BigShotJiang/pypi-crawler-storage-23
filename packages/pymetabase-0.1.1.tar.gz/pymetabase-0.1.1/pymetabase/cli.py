"""
Command-line interface for PyMetabase
"""

import argparse
import sys
import logging
from pathlib import Path

from . import __version__
from .client import Metabase
from .config import load_config
from .remotes import (
    RemoteManager,
    prompt_for_remote,
    prompt_yes_no,
    select_remote_interactive,
    config_menu_interactive,
)


def _parse_params(param_list):
    """Parse --param name=value arguments into a dict."""
    if not param_list:
        return None
    params = {}
    for p in param_list:
        if '=' not in p:
            print(f"Error: Invalid parameter format '{p}'. Use name=value.")
            sys.exit(1)
        name, value = p.split('=', 1)
        # Try to parse as number
        try:
            value = int(value)
        except ValueError:
            try:
                value = float(value)
            except ValueError:
                pass
        params[name.strip()] = value
    return params


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="PyMetabase - Export data from Metabase",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Export a query to JSONL
  pymetabase export --database Club --query "SELECT * FROM users" -o users.jsonl

  # Export with SQL from file (supports multi-line queries)
  pymetabase export --database Club --query-file query.sql -o results.jsonl

  # Export with custom chunk size
  pymetabase export --database Club -q "SELECT * FROM users" -o users.jsonl --chunk-size 100000

  # Export with credentials file
  pymetabase -c credentials.json export --database Club --query "SELECT * FROM users" -o users.json

  # Export using a configured remote
  pymetabase -r production export --database Club --query "SELECT * FROM users" -o users.jsonl

  # Configure a new remote
  pymetabase config

  # List configured remotes
  pymetabase listremotes

  # Select default remote
  pymetabase selectremote

  # Test remote connection
  pymetabase testremote production

  # Export a table with filtering and custom chunk size
  pymetabase export-table --database Club --table users --where "active = true" -o active_users.csv --chunk-size 100000

  # List databases
  pymetabase list-databases

  # List tables in a database
  pymetabase list-tables --database Club
        """
    )

    # Global arguments
    parser.add_argument('-c', '--credentials', help='Path to credentials file')
    parser.add_argument('--config', help='Path to config file')
    parser.add_argument('-r', '--remote', help='Use configured remote by name')
    parser.add_argument('--url', help='Metabase URL')
    parser.add_argument('--username', help='Metabase username')
    parser.add_argument('--password', help='Metabase password')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export query results')
    export_parser.add_argument('--database', '-d', required=True, help='Database name or ID')
    query_group = export_parser.add_mutually_exclusive_group(required=True)
    query_group.add_argument('--query', '-q', help='SQL query')
    query_group.add_argument('--query-file', '-Q', help='Path to SQL file (.sql or .txt)')
    export_parser.add_argument('--output', '-o', required=True, help='Output file path')
    export_parser.add_argument('--format', '-f', choices=['jsonl', 'json', 'csv'], help='Output format')
    export_parser.add_argument('--chunk-size', type=int, default=500000, help='Rows per chunk')
    export_parser.add_argument('--checkpoint', help='Checkpoint file for resume')
    export_parser.add_argument('--csv-field-size-limit', type=int, help='CSV field size limit in bytes (default: 10MB for large fields)')
    export_parser.add_argument('--param', '-p', action='append', help='Query parameter (name=value, e.g., -p min_age=30)')

    # Export table command
    table_parser = subparsers.add_parser('export-table', help='Export entire table')
    table_parser.add_argument('--database', '-d', required=True, help='Database name or ID')
    table_parser.add_argument('--table', '-t', required=True, help='Table name')
    table_parser.add_argument('--output', '-o', required=True, help='Output file path')
    table_parser.add_argument('--columns', help='Comma-separated column names')
    table_parser.add_argument('--where', help='WHERE clause')
    table_parser.add_argument('--order-by', help='ORDER BY clause')
    table_parser.add_argument('--limit', type=int, help='Maximum rows')
    table_parser.add_argument('--format', '-f', choices=['jsonl', 'json', 'csv'], help='Output format')
    table_parser.add_argument('--chunk-size', type=int, default=500000, help='Rows per chunk')

    # List databases command
    subparsers.add_parser('list-databases', help='List available databases')

    # List tables command
    tables_parser = subparsers.add_parser('list-tables', help='List tables in database')
    tables_parser.add_argument('--database', '-d', required=True, help='Database name or ID')

    # Remote management commands
    subparsers.add_parser('config', help='Configure remotes (add/edit/delete)')
    subparsers.add_parser('listremotes', help='List configured remotes')
    subparsers.add_parser('selectremote', help='Select default remote')

    # Show remote command
    show_parser = subparsers.add_parser('showremote', help='Show remote configuration')
    show_parser.add_argument('name', help='Remote name')

    # Delete remote command
    delete_parser = subparsers.add_parser('deleteremote', help='Delete a remote')
    delete_parser.add_argument('name', help='Remote name to delete')

    # Test remote command
    test_parser = subparsers.add_parser('testremote', help='Test remote connection')
    test_parser.add_argument('name', nargs='?', help='Remote name (uses default if not specified)')

    # Cards/Questions command
    subparsers.add_parser('cards', help='List saved questions/cards')

    # Get card command
    card_parser = subparsers.add_parser('card', help='Show card details')
    card_parser.add_argument('id', type=int, help='Card ID')

    # Execute card command
    exec_card_parser = subparsers.add_parser('execute-card', help='Execute a saved question')
    exec_card_parser.add_argument('id', type=int, help='Card ID')
    exec_card_parser.add_argument('--output', '-o', help='Output file (prints to stdout if not specified)')
    exec_card_parser.add_argument('--format', '-f', choices=['jsonl', 'json', 'csv'], default='json', help='Output format')

    # Dashboards command
    subparsers.add_parser('dashboards', help='List dashboards')

    # Get dashboard command
    dash_parser = subparsers.add_parser('dashboard', help='Show dashboard details')
    dash_parser.add_argument('id', type=int, help='Dashboard ID')

    # Collections command
    subparsers.add_parser('collections', help='List collections')

    # Collection items command
    coll_parser = subparsers.add_parser('collection', help='Show collection items')
    coll_parser.add_argument('id', help='Collection ID or "root"')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search Metabase resources')
    search_parser.add_argument('query', help='Search query')
    search_parser.add_argument('--models', help='Filter by model types (comma-separated: card,dashboard,collection)')

    # Users command
    subparsers.add_parser('users', help='List users')
    subparsers.add_parser('whoami', help='Show current user')

    # Query command (execute SQL and print results)
    query_parser = subparsers.add_parser('query', help='Execute SQL query and print results')
    query_parser.add_argument('--database', '-d', required=True, help='Database name or ID')
    query_group_q = query_parser.add_mutually_exclusive_group(required=True)
    query_group_q.add_argument('--query', '-q', help='SQL query')
    query_group_q.add_argument('--query-file', '-Q', help='Path to SQL file')
    query_parser.add_argument('--param', '-p', action='append', help='Query parameter (name=value)')
    query_parser.add_argument('--format', '-f', choices=['table', 'json', 'csv', 'jsonl'], default='table', help='Output format (default: table)')
    query_parser.add_argument('--limit', type=int, help='Limit rows displayed')

    # Generic API command
    api_parser = subparsers.add_parser('api', help='Make a raw API request')
    api_parser.add_argument('method', choices=['get', 'post', 'put', 'delete'], help='HTTP method')
    api_parser.add_argument('endpoint', help='API endpoint (e.g., /api/card)')
    api_parser.add_argument('--json-body', help='JSON request body')

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format='%(message)s'
    )

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Remote management commands (don't need credentials)
    manager = RemoteManager()

    if args.command == 'config':
        config_menu_interactive(manager)
        return

    if args.command == 'listremotes':
        remotes = manager.list_remotes()
        default = manager.get_default_remote_name()

        if not remotes:
            print("No remotes configured. Run 'pymetabase config' to add one.")
        else:
            print(f"\nConfigured remotes ({len(remotes)}):")
            for name in remotes:
                marker = " (default)" if name == default else ""
                remote = manager.get_remote(name)
                print(f"  - {name}{marker}: {remote.url}")
        return

    if args.command == 'selectremote':
        selected = select_remote_interactive(manager)
        if selected:
            manager.set_default(selected)
            print(f"Default remote set to '{selected}'.")
        return

    if args.command == 'showremote':
        remote = manager.get_remote(args.name)
        if not remote:
            print(f"Remote '{args.name}' not found.")
            sys.exit(1)

        default = manager.get_default_remote_name()
        is_default = " (default)" if args.name == default else ""

        print(f"\nRemote: {args.name}{is_default}")
        print(f"  URL: {remote.url}")
        print(f"  Username: {remote.username}")
        print(f"  Password: ********")
        return

    if args.command == 'deleteremote':
        if not manager.remote_exists(args.name):
            print(f"Remote '{args.name}' not found.")
            sys.exit(1)

        if prompt_yes_no(f"Delete remote '{args.name}'?", default=False):
            manager.delete_remote(args.name)
            print(f"Remote '{args.name}' deleted.")
        else:
            print("Cancelled.")
        return

    if args.command == 'testremote':
        remote_name = args.name
        if not remote_name:
            remote_name = manager.get_default_remote_name()
            if not remote_name:
                print("No default remote configured. Specify a remote name or run 'pymetabase config'.")
                sys.exit(1)

        remote = manager.get_remote(remote_name)
        if not remote:
            print(f"Remote '{remote_name}' not found.")
            sys.exit(1)

        print(f"Testing connection to '{remote_name}' ({remote.url})...")

        try:
            mb = Metabase(
                url=remote.url,
                username=remote.username,
                password=remote.password,
                remote_name=remote_name,
            )
            with mb:
                databases = mb.list_databases()
                print(f"Connection successful! Found {len(databases)} database(s).")
        except Exception as e:
            print(f"Connection failed: {e}")
            sys.exit(1)
        return

    # Commands that need credentials
    try:
        # Resolve credentials
        url = args.url
        username = args.username
        password = args.password
        remote_name = None  # Track remote name for token persistence

        # Priority: -r/--remote > -c/--credentials > --url/--username/--password > prompt
        if args.remote:
            # Use configured remote
            remote = manager.get_remote(args.remote)
            if not remote:
                # Remote not found, prompt to create
                if prompt_yes_no(f"Remote '{args.remote}' not found. Create it?"):
                    new_remote = prompt_for_remote(name=args.remote)
                    set_default = prompt_yes_no("Set as default?")
                    manager.add_remote(new_remote, set_as_default=set_default)
                    remote = new_remote
                    print(f"Remote '{args.remote}' created.")
                else:
                    sys.exit(1)

            url = remote.url
            username = remote.username
            password = remote.password
            remote_name = args.remote

        elif args.credentials:
            # Use credentials file
            pass  # Will be handled by load_config

        elif not (url and username and password):
            # Check for default remote
            default_remote = manager.get_default_remote()
            if default_remote:
                url = default_remote.url
                username = default_remote.username
                password = default_remote.password
                remote_name = manager.get_default_remote_name()
            elif not manager.has_remotes():
                # No remotes configured, prompt to set up
                if prompt_yes_no("No remotes configured. Set up now?"):
                    new_remote = prompt_for_remote()
                    manager.add_remote(new_remote, set_as_default=True)
                    url = new_remote.url
                    username = new_remote.username
                    password = new_remote.password
                    remote_name = new_remote.name
                    print(f"Remote '{new_remote.name}' created and set as default.\n")
                else:
                    print("No credentials provided. Use -r, -c, or --url/--username/--password.")
                    sys.exit(1)
            else:
                print("No credentials provided. Use -r <remote>, -c <file>, or --url/--username/--password.")
                sys.exit(1)

        # Create client (with token persistence if remote_name is set)
        mb = Metabase(
            url=url,
            username=username,
            password=password,
            config_file=args.config,
            credentials_file=args.credentials,
            remote_name=remote_name,
        )

        with mb:
            if args.command == 'export':
                # Get query from argument or file
                if args.query_file:
                    query_path = Path(args.query_file)
                    if not query_path.exists():
                        print(f"Error: Query file not found: {args.query_file}")
                        sys.exit(1)
                    query = query_path.read_text(encoding='utf-8').strip()
                    if not query:
                        print(f"Error: Query file is empty: {args.query_file}")
                        sys.exit(1)
                else:
                    query = args.query

                parameters = _parse_params(getattr(args, 'param', None))
                result = mb.export(
                    database=args.database,
                    query=query,
                    output=args.output,
                    format=args.format,
                    chunk_size=args.chunk_size,
                    checkpoint_file=args.checkpoint,
                    csv_field_size_limit=args.csv_field_size_limit,
                    parameters=parameters,
                )
                print(f"\nExport complete!")
                print(f"  Rows: {result.total_rows:,}")
                print(f"  Chunks: {result.chunks}")
                print(f"  Duration: {result.duration_seconds:.1f}s")
                print(f"  Rate: {result.rate_per_second:.0f} rows/sec")
                print(f"  Output: {result.output_file}")

            elif args.command == 'export-table':
                columns = args.columns.split(',') if args.columns else None
                result = mb.export_table(
                    database=args.database,
                    table=args.table,
                    output=args.output,
                    columns=columns,
                    where=args.where,
                    order_by=args.order_by,
                    limit=args.limit,
                    format=args.format,
                    chunk_size=args.chunk_size,
                )
                print(f"\nExport complete!")
                print(f"  Rows: {result.total_rows:,}")
                print(f"  Chunks: {result.chunks}")
                print(f"  Duration: {result.duration_seconds:.1f}s")
                print(f"  Rate: {result.rate_per_second:.0f} rows/sec")
                print(f"  Output: {result.output_file}")

            elif args.command == 'list-databases':
                databases = mb.list_databases()
                print(f"\nDatabases ({len(databases)}):")
                for db in databases:
                    engine = db.get('engine', 'unknown')
                    print(f"  [{db['id']}] {db['name']} ({engine})")

            elif args.command == 'list-tables':
                tables = mb.list_tables(args.database)
                print(f"\nTables in {args.database} ({len(tables)}):")
                for table in tables:
                    rows = table.get('rows', 'unknown')
                    print(f"  - {table['name']} ({rows} rows)")

            elif args.command == 'cards':
                cards = mb.list_cards()
                print(f"\nSaved questions ({len(cards)}):")
                for card in cards:
                    collection = card.get('collection', {}) or {}
                    coll_name = collection.get('name', 'No collection')
                    print(f"  [{card['id']}] {card['name']} ({coll_name})")

            elif args.command == 'card':
                card = mb.get_card(args.id)
                print(f"\nCard: {card['name']}")
                print(f"  ID: {card['id']}")
                print(f"  Display: {card.get('display', 'unknown')}")
                print(f"  Description: {card.get('description', 'None')}")
                collection = card.get('collection', {}) or {}
                print(f"  Collection: {collection.get('name', 'None')}")
                if card.get('dataset_query', {}).get('native'):
                    print(f"  Query: {card['dataset_query']['native'].get('query', 'N/A')[:100]}")

            elif args.command == 'execute-card':
                result = mb.execute_card(args.id)
                data = result.get('data', {})
                rows = data.get('rows', [])
                cols = [c['name'] for c in data.get('cols', [])]

                if args.output:
                    import json as json_mod
                    with open(args.output, 'w') as f:
                        for row in rows:
                            row_dict = dict(zip(cols, row))
                            f.write(json_mod.dumps(row_dict) + '\n')
                    print(f"Exported {len(rows)} rows to {args.output}")
                else:
                    print(f"\nResults ({len(rows)} rows):")
                    if cols:
                        print("  " + " | ".join(cols))
                        print("  " + "-" * (sum(len(c) for c in cols) + 3 * (len(cols) - 1)))
                    for row in rows[:50]:
                        print("  " + " | ".join(str(v) for v in row))
                    if len(rows) > 50:
                        print(f"  ... and {len(rows) - 50} more rows")

            elif args.command == 'dashboards':
                dashboards = mb.list_dashboards()
                print(f"\nDashboards ({len(dashboards)}):")
                for dash in dashboards:
                    collection = dash.get('collection', {}) or {}
                    coll_name = collection.get('name', 'No collection')
                    print(f"  [{dash['id']}] {dash['name']} ({coll_name})")

            elif args.command == 'dashboard':
                dash = mb.get_dashboard(args.id)
                cards = dash.get('dashcards', dash.get('ordered_cards', []))
                print(f"\nDashboard: {dash['name']}")
                print(f"  ID: {dash['id']}")
                print(f"  Description: {dash.get('description', 'None')}")
                print(f"  Cards: {len(cards)}")
                for dc in cards:
                    card = dc.get('card', {})
                    if card:
                        print(f"    [{card.get('id', '?')}] {card.get('name', 'Unnamed')}")

            elif args.command == 'collections':
                collections = mb.list_collections()
                print(f"\nCollections ({len(collections)}):")
                for coll in collections:
                    parent = f" (in {coll.get('location', '/')})" if coll.get('location') else ""
                    print(f"  [{coll['id']}] {coll['name']}{parent}")

            elif args.command == 'collection':
                coll_id = args.id if args.id == 'root' else int(args.id)
                items = mb.get_collection_items(coll_id)
                label = 'Root' if args.id == 'root' else f'Collection {args.id}'
                print(f"\n{label} items ({len(items)}):")
                for item in items:
                    model = item.get('model', 'unknown')
                    print(f"  [{item.get('id', '?')}] ({model}) {item.get('name', 'Unnamed')}")

            elif args.command == 'search':
                models = args.models.split(',') if args.models else None
                results = mb.search(args.query, models=models)
                print(f"\nSearch results for '{args.query}' ({len(results)}):")
                for item in results:
                    model = item.get('model', 'unknown')
                    print(f"  [{item.get('id', '?')}] ({model}) {item.get('name', 'Unnamed')}")

            elif args.command == 'users':
                users = mb.list_users()
                print(f"\nUsers ({len(users)}):")
                for user in users:
                    admin = " (admin)" if user.get('is_superuser') else ""
                    print(f"  [{user['id']}] {user.get('common_name', user.get('email', '?'))}{admin}")

            elif args.command == 'whoami':
                user = mb.get_current_user()
                print(f"\nCurrent user:")
                print(f"  Name: {user.get('common_name', 'N/A')}")
                print(f"  Email: {user.get('email', 'N/A')}")
                print(f"  ID: {user.get('id', 'N/A')}")
                print(f"  Admin: {user.get('is_superuser', False)}")

            elif args.command == 'query':
                if args.query_file:
                    query_path = Path(args.query_file)
                    if not query_path.exists():
                        print(f"Error: Query file not found: {args.query_file}")
                        sys.exit(1)
                    sql = query_path.read_text(encoding='utf-8').strip()
                else:
                    sql = args.query

                parameters = _parse_params(getattr(args, 'param', None))
                result = mb.query(sql, database=args.database, parameters=parameters)
                data = result.get('data', {})
                rows = data.get('rows', [])
                cols = [c['name'] for c in data.get('cols', [])]

                output_format = getattr(args, 'format', 'table') or 'table'

                if output_format == 'json':
                    import json as json_mod
                    row_dicts = [dict(zip(cols, row)) for row in rows]
                    print(json_mod.dumps(row_dicts, indent=2, default=str))

                elif output_format == 'jsonl':
                    import json as json_mod
                    for row in rows:
                        print(json_mod.dumps(dict(zip(cols, row)), default=str))

                elif output_format == 'csv':
                    import csv as csv_mod
                    import io
                    buf = io.StringIO()
                    writer = csv_mod.writer(buf)
                    writer.writerow(cols)
                    writer.writerows(rows)
                    print(buf.getvalue(), end='')

                else:  # table (default)
                    limit = args.limit or 100
                    print(f"\nResults ({len(rows)} rows):")
                    if cols:
                        # Calculate column widths
                        col_widths = [len(c) for c in cols]
                        for row in rows[:limit]:
                            for i, v in enumerate(row):
                                col_widths[i] = max(col_widths[i], len(str(v)))
                        # Cap column widths at 40
                        col_widths = [min(w, 40) for w in col_widths]

                        # Header
                        header = " | ".join(c.ljust(col_widths[i]) for i, c in enumerate(cols))
                        print(f"  {header}")
                        print(f"  {'-+-'.join('-' * w for w in col_widths)}")

                        # Rows
                        for row in rows[:limit]:
                            formatted = " | ".join(
                                str(v)[:40].ljust(col_widths[i]) for i, v in enumerate(row)
                            )
                            print(f"  {formatted}")
                    if len(rows) > limit:
                        print(f"  ... and {len(rows) - limit} more rows (use --limit to show more)")

            elif args.command == 'api':
                import json as json_mod
                body = json_mod.loads(args.json_body) if args.json_body else None
                method = args.method.lower()

                if method == 'get':
                    result = mb.get(args.endpoint)
                elif method == 'post':
                    result = mb.post(args.endpoint, json=body)
                elif method == 'put':
                    result = mb.put(args.endpoint, json=body)
                elif method == 'delete':
                    result = mb.delete_resource(args.endpoint)

                if result is not None:
                    print(json_mod.dumps(result, indent=2))

    except KeyboardInterrupt:
        print("\nCancelled.")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Error: {e}")
        if args.verbose:
            raise
        sys.exit(1)


if __name__ == '__main__':
    main()
