"""
PyMetabase - A Python library for exporting data from Metabase

Example:
    ```python
    from pymetabase import Metabase

    # Connect to Metabase
    mb = Metabase(
        url="https://metabase.example.com",
        username="user@example.com",
        password="password"
    )

    # Export query results
    with mb:
        result = mb.export(
            database="MyDatabase",
            query="SELECT * FROM users",
            output="users.jsonl"
        )

    print(f"Exported {result.total_rows} rows")
    ```
"""

__version__ = "0.1.1"
__author__ = "PyMetabase Contributors"
__license__ = "MIT"

from .client import Metabase, ExportResult
from .config import MetabaseConfig, load_config
from .remotes import RemoteManager, Remote
from .exceptions import (
    PyMetabaseError,
    AuthenticationError,
    ConnectionError,
    QueryError,
    ExportError,
    ChunkError,
    ConfigurationError,
    DatabaseNotFoundError,
    ValidationError,
    APIError,
    NotFoundError,
)

__all__ = [
    # Main client
    "Metabase",
    "ExportResult",

    # Configuration
    "MetabaseConfig",
    "load_config",

    # Remotes
    "RemoteManager",
    "Remote",

    # Exceptions
    "PyMetabaseError",
    "AuthenticationError",
    "ConnectionError",
    "QueryError",
    "ExportError",
    "ChunkError",
    "ConfigurationError",
    "DatabaseNotFoundError",
    "ValidationError",
    "APIError",
    "NotFoundError",
]
