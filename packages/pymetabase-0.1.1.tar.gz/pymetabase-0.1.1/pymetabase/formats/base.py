"""
Base class for output format handlers
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Iterator, TextIO, BinaryIO, Union
import csv
import io


class OutputFormat(ABC):
    """Abstract base class for output format handlers"""

    def __init__(self, file_handle: Union[TextIO, BinaryIO]):
        self.file_handle = file_handle
        self._row_count = 0
        self._initialized = False

    @abstractmethod
    def write_row(self, row: Dict[str, Any]) -> None:
        """Write a single row to the output"""
        pass

    @abstractmethod
    def write_rows(self, rows: Iterator[Dict[str, Any]]) -> int:
        """Write multiple rows to the output, return count"""
        pass

    @abstractmethod
    def finalize(self) -> None:
        """Finalize the output (close arrays, etc.)"""
        pass

    @property
    def row_count(self) -> int:
        """Get the number of rows written"""
        return self._row_count

    def write_csv_response(self, csv_content: str) -> int:
        """
        Write CSV response content to output.
        Returns number of rows written.
        """
        reader = csv.DictReader(io.StringIO(csv_content))
        count = 0
        for row in reader:
            self.write_row(row)
            count += 1
        return count


def get_format_handler(format_name: str, file_handle: Union[TextIO, BinaryIO], **kwargs) -> OutputFormat:
    """
    Get the appropriate format handler for the given format name.

    Args:
        format_name: One of 'jsonl', 'json', 'csv'
        file_handle: Open file handle to write to
        **kwargs: Additional arguments passed to the format handler (e.g., field_size_limit for CSV)

    Returns:
        OutputFormat instance
    """
    from .jsonl import JSONLFormat
    from .csv_format import CSVFormat
    from .json_format import JSONFormat

    handlers = {
        'jsonl': JSONLFormat,
        'json': JSONFormat,
        'csv': CSVFormat,
    }

    format_name = format_name.lower()
    if format_name not in handlers:
        raise ValueError(f"Unknown format: {format_name}. Supported: {list(handlers.keys())}")

    return handlers[format_name](file_handle, **kwargs)
