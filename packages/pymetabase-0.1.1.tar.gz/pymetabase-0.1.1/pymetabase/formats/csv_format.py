"""
CSV output format handler
"""

import csv
from typing import Dict, Any, Iterator, TextIO, Optional, List

from .base import OutputFormat


class CSVFormat(OutputFormat):
    """Handler for CSV output format"""

    def __init__(self, file_handle: TextIO, field_size_limit: Optional[int] = None):
        super().__init__(file_handle)
        self._writer: Optional[csv.DictWriter] = None
        self._fieldnames: Optional[List[str]] = None

        # Set CSV field size limit (default is 128KB, can be increased for large fields)
        if field_size_limit is not None:
            csv.field_size_limit(field_size_limit)

    def write_row(self, row: Dict[str, Any]) -> None:
        """Write a single row to CSV"""
        # Remove _row_num column if present
        if '_row_num' in row:
            row = {k: v for k, v in row.items() if k != '_row_num'}

        # Initialize writer on first row
        if self._writer is None:
            self._fieldnames = list(row.keys())
            self._writer = csv.DictWriter(
                self.file_handle,
                fieldnames=self._fieldnames,
                extrasaction='ignore'
            )
            self._writer.writeheader()

        self._writer.writerow(row)
        self._row_count += 1

    def write_rows(self, rows: Iterator[Dict[str, Any]]) -> int:
        """Write multiple rows to CSV"""
        count = 0
        for row in rows:
            self.write_row(row)
            count += 1
        return count

    def finalize(self) -> None:
        """No finalization needed for CSV"""
        pass
