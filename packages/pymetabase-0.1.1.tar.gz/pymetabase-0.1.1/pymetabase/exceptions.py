"""
Custom exceptions for PyMetabase
"""


class PyMetabaseError(Exception):
    """Base exception for all PyMetabase errors"""
    pass


class AuthenticationError(PyMetabaseError):
    """Failed to authenticate with Metabase"""
    pass


class ConnectionError(PyMetabaseError):
    """Failed to connect to Metabase server"""
    pass


class QueryError(PyMetabaseError):
    """Error executing query"""
    pass


class ExportError(PyMetabaseError):
    """Error during export operation"""
    pass


class ChunkError(ExportError):
    """Error during chunk export"""
    pass


class ConfigurationError(PyMetabaseError):
    """Invalid configuration"""
    pass


class DatabaseNotFoundError(PyMetabaseError):
    """Database not found"""
    pass


class ValidationError(PyMetabaseError):
    """Data validation failed"""
    pass


class APIError(PyMetabaseError):
    """API request failed"""

    def __init__(self, message, response=None):
        super().__init__(message)
        self.response = response
        self.status_code = response.status_code if response else None


class NotFoundError(APIError):
    """Resource not found (404)"""
    pass
