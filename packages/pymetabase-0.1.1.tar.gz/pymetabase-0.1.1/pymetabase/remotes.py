"""
Remote configuration management for PyMetabase

Provides rclone-style remote configuration with cached credentials.
"""

import json
import os
import stat
import getpass
import re
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict

from .exceptions import ConfigurationError


@dataclass
class Remote:
    """A configured remote Metabase server"""
    name: str
    url: str
    username: str
    password: str

    def to_dict(self) -> Dict[str, str]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> "Remote":
        return cls(
            name=data["name"],
            url=data["url"],
            username=data["username"],
            password=data["password"]
        )


class RemoteManager:
    """Manages remote configurations stored in config file"""

    # Valid remote name pattern: alphanumeric, underscore, hyphen
    NAME_PATTERN = re.compile(r'^[a-zA-Z0-9_-]+$')

    def __init__(self, config_dir: Optional[str] = None):
        """
        Initialize RemoteManager.

        Args:
            config_dir: Custom config directory. If None, uses platform default.
        """
        if config_dir:
            self.config_dir = Path(config_dir)
        else:
            self.config_dir = self._get_default_config_dir()

        self.config_file = self.config_dir / "config.json"
        self.tokens_file = self.config_dir / "tokens.json"
        self._config: Optional[Dict[str, Any]] = None
        self._tokens: Optional[Dict[str, str]] = None

    @staticmethod
    def _get_default_config_dir() -> Path:
        """Get platform-specific config directory"""
        if os.name == 'nt':  # Windows
            base = os.environ.get('APPDATA', os.path.expanduser('~'))
            return Path(base) / 'pymetabase'
        else:  # macOS, Linux
            xdg_config = os.environ.get('XDG_CONFIG_HOME', os.path.expanduser('~/.config'))
            return Path(xdg_config) / 'pymetabase'

    def _ensure_config_dir(self) -> None:
        """Create config directory if it doesn't exist"""
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if self._config is not None:
            return self._config

        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    self._config = json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                raise ConfigurationError(f"Failed to load config: {e}")
        else:
            self._config = {
                "remotes": {},
                "default": None
            }

        return self._config

    def _save_config(self) -> None:
        """Save configuration to file"""
        self._ensure_config_dir()
        config = self._load_config()

        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            # Restrict file permissions (owner read/write only)
            os.chmod(self.config_file, stat.S_IRUSR | stat.S_IWUSR)
        except IOError as e:
            raise ConfigurationError(f"Failed to save config: {e}")

    def _load_tokens(self) -> Dict[str, str]:
        """Load tokens from file"""
        if self._tokens is not None:
            return self._tokens

        if self.tokens_file.exists():
            try:
                with open(self.tokens_file, 'r') as f:
                    self._tokens = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._tokens = {}
        else:
            self._tokens = {}

        return self._tokens

    def _save_tokens(self) -> None:
        """Save tokens to file"""
        self._ensure_config_dir()
        tokens = self._load_tokens()

        try:
            with open(self.tokens_file, 'w') as f:
                json.dump(tokens, f, indent=2)
            # Restrict file permissions (owner read/write only)
            os.chmod(self.tokens_file, stat.S_IRUSR | stat.S_IWUSR)
        except IOError as e:
            raise ConfigurationError(f"Failed to save tokens: {e}")

    def get_token(self, remote_name: str) -> Optional[str]:
        """
        Get stored session token for a remote.

        Args:
            remote_name: Name of the remote

        Returns:
            Session token if exists, None otherwise
        """
        tokens = self._load_tokens()
        return tokens.get(remote_name)

    def save_token(self, remote_name: str, token: str) -> None:
        """
        Save session token for a remote.

        Args:
            remote_name: Name of the remote
            token: Session token to save
        """
        tokens = self._load_tokens()
        tokens[remote_name] = token
        self._save_tokens()

    def clear_token(self, remote_name: str) -> None:
        """
        Clear stored session token for a remote.

        Args:
            remote_name: Name of the remote
        """
        tokens = self._load_tokens()
        if remote_name in tokens:
            del tokens[remote_name]
            self._save_tokens()

    def clear_all_tokens(self) -> None:
        """Clear all stored session tokens"""
        self._tokens = {}
        self._save_tokens()

    def validate_name(self, name: str) -> bool:
        """Check if remote name is valid"""
        return bool(self.NAME_PATTERN.match(name))

    def list_remotes(self) -> List[str]:
        """List all configured remote names"""
        config = self._load_config()
        return list(config.get("remotes", {}).keys())

    def get_remote(self, name: str) -> Optional[Remote]:
        """Get a remote by name"""
        config = self._load_config()
        remotes = config.get("remotes", {})

        if name in remotes:
            data = remotes[name].copy()
            data["name"] = name
            return Remote.from_dict(data)

        return None

    def get_default_remote(self) -> Optional[Remote]:
        """Get the default remote"""
        config = self._load_config()
        default_name = config.get("default")

        if default_name:
            return self.get_remote(default_name)

        return None

    def get_default_remote_name(self) -> Optional[str]:
        """Get the name of the default remote"""
        config = self._load_config()
        return config.get("default")

    def add_remote(self, remote: Remote, set_as_default: bool = False) -> None:
        """
        Add or update a remote.

        Args:
            remote: Remote configuration
            set_as_default: Whether to set this as the default remote
        """
        if not self.validate_name(remote.name):
            raise ConfigurationError(
                f"Invalid remote name '{remote.name}'. "
                "Use only alphanumeric characters, underscores, and hyphens."
            )

        config = self._load_config()

        if "remotes" not in config:
            config["remotes"] = {}

        config["remotes"][remote.name] = {
            "url": remote.url,
            "username": remote.username,
            "password": remote.password
        }

        # Set as default if requested or if it's the first remote
        if set_as_default or config.get("default") is None:
            config["default"] = remote.name

        self._save_config()

    def delete_remote(self, name: str) -> bool:
        """
        Delete a remote.

        Args:
            name: Remote name to delete

        Returns:
            True if deleted, False if not found
        """
        config = self._load_config()
        remotes = config.get("remotes", {})

        if name not in remotes:
            return False

        del remotes[name]

        # Update default if we deleted it
        if config.get("default") == name:
            if remotes:
                # Set first available as default
                config["default"] = next(iter(remotes.keys()))
            else:
                config["default"] = None

        self._save_config()
        # Also clear any stored token for this remote
        self.clear_token(name)
        return True

    def set_default(self, name: str) -> bool:
        """
        Set the default remote.

        Args:
            name: Remote name to set as default

        Returns:
            True if successful, False if remote not found
        """
        config = self._load_config()

        if name not in config.get("remotes", {}):
            return False

        config["default"] = name
        self._save_config()
        return True

    def remote_exists(self, name: str) -> bool:
        """Check if a remote exists"""
        config = self._load_config()
        return name in config.get("remotes", {})

    def has_remotes(self) -> bool:
        """Check if any remotes are configured"""
        config = self._load_config()
        return bool(config.get("remotes"))


def prompt_for_remote(
    name: Optional[str] = None,
    url: Optional[str] = None,
    username: Optional[str] = None
) -> Remote:
    """
    Interactively prompt user for remote configuration.

    Args:
        name: Pre-filled remote name (or None to prompt)
        url: Pre-filled URL (or None to prompt)
        username: Pre-filled username (or None to prompt)

    Returns:
        Configured Remote object
    """
    print()

    if name is None:
        name = input("Remote name: ").strip()
        if not name:
            raise ConfigurationError("Remote name cannot be empty")

    if url is None:
        url = input("Server URL: ").strip()
        if not url:
            raise ConfigurationError("Server URL cannot be empty")

    # Ensure URL has scheme
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url

    if username is None:
        username = input("Username: ").strip()
        if not username:
            raise ConfigurationError("Username cannot be empty")

    password = getpass.getpass("Password: ")
    if not password:
        raise ConfigurationError("Password cannot be empty")

    return Remote(
        name=name,
        url=url.rstrip('/'),
        username=username,
        password=password
    )


def prompt_yes_no(question: str, default: bool = True) -> bool:
    """
    Prompt for yes/no answer.

    Args:
        question: Question to ask
        default: Default answer if user just presses Enter

    Returns:
        True for yes, False for no
    """
    suffix = " [Y/n] " if default else " [y/N] "
    answer = input(question + suffix).strip().lower()

    if not answer:
        return default

    return answer in ('y', 'yes')


def select_remote_interactive(manager: RemoteManager) -> Optional[str]:
    """
    Interactive remote selection.

    Args:
        manager: RemoteManager instance

    Returns:
        Selected remote name, or None if cancelled
    """
    remotes = manager.list_remotes()
    if not remotes:
        print("No remotes configured.")
        return None

    default = manager.get_default_remote_name()

    print("\nSelect default remote:")
    for i, name in enumerate(remotes, 1):
        marker = " (current)" if name == default else ""
        print(f"  {i}) {name}{marker}")

    print()
    try:
        choice = input("Enter number: ").strip()
        if not choice:
            return None

        index = int(choice) - 1
        if 0 <= index < len(remotes):
            return remotes[index]
        else:
            print("Invalid selection.")
            return None
    except ValueError:
        print("Invalid input.")
        return None


def config_menu_interactive(manager: RemoteManager) -> None:
    """
    Interactive configuration menu.

    Args:
        manager: RemoteManager instance
    """
    print("\nConfiguration:")
    print("  1) Add new remote")
    print("  2) Edit existing remote")
    print("  3) Delete remote")
    print()

    try:
        choice = input("Enter number: ").strip()

        if choice == "1":
            # Add new remote
            remote = prompt_for_remote()

            if manager.remote_exists(remote.name):
                if not prompt_yes_no(f"Remote '{remote.name}' exists. Overwrite?", default=False):
                    print("Cancelled.")
                    return

            set_default = prompt_yes_no("Set as default?")
            manager.add_remote(remote, set_as_default=set_default)
            print(f"Remote '{remote.name}' added successfully.")

        elif choice == "2":
            # Edit existing
            remotes = manager.list_remotes()
            if not remotes:
                print("No remotes to edit.")
                return

            print("\nSelect remote to edit:")
            for i, name in enumerate(remotes, 1):
                print(f"  {i}) {name}")

            edit_choice = input("\nEnter number: ").strip()
            try:
                index = int(edit_choice) - 1
                if 0 <= index < len(remotes):
                    old_name = remotes[index]
                    old_remote = manager.get_remote(old_name)

                    print(f"\nEditing '{old_name}' (press Enter to keep current value)")
                    print(f"Current URL: {old_remote.url}")
                    print(f"Current username: {old_remote.username}")
                    print()

                    new_url = input(f"New URL [{old_remote.url}]: ").strip()
                    new_username = input(f"New username [{old_remote.username}]: ").strip()
                    new_password = getpass.getpass("New password (leave empty to keep): ")

                    # Use old values if not provided
                    url = new_url if new_url else old_remote.url
                    username = new_username if new_username else old_remote.username
                    password = new_password if new_password else old_remote.password

                    new_remote = Remote(
                        name=old_name,
                        url=url.rstrip('/'),
                        username=username,
                        password=password
                    )

                    manager.add_remote(new_remote)
                    print(f"Remote '{old_name}' updated.")
                else:
                    print("Invalid selection.")
            except ValueError:
                print("Invalid input.")

        elif choice == "3":
            # Delete
            remotes = manager.list_remotes()
            if not remotes:
                print("No remotes to delete.")
                return

            print("\nSelect remote to delete:")
            for i, name in enumerate(remotes, 1):
                print(f"  {i}) {name}")

            del_choice = input("\nEnter number: ").strip()
            try:
                index = int(del_choice) - 1
                if 0 <= index < len(remotes):
                    name = remotes[index]
                    if prompt_yes_no(f"Delete remote '{name}'?", default=False):
                        manager.delete_remote(name)
                        print(f"Remote '{name}' deleted.")
                    else:
                        print("Cancelled.")
                else:
                    print("Invalid selection.")
            except ValueError:
                print("Invalid input.")

        else:
            print("Invalid choice.")

    except KeyboardInterrupt:
        print("\nCancelled.")
