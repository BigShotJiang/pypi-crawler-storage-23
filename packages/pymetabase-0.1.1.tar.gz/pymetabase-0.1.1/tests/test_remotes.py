"""
Tests for remote management module
"""

import pytest
import json
import tempfile
import os
from pathlib import Path

from pymetabase.remotes import Remote, RemoteManager
from pymetabase.exceptions import ConfigurationError


class TestRemote:
    """Tests for Remote dataclass"""

    def test_remote_creation(self):
        """Test creating a remote"""
        remote = Remote(
            name="production",
            url="https://metabase.example.com",
            username="user@example.com",
            password="secret123"
        )

        assert remote.name == "production"
        assert remote.url == "https://metabase.example.com"
        assert remote.username == "user@example.com"
        assert remote.password == "secret123"

    def test_to_dict(self):
        """Test converting remote to dictionary"""
        remote = Remote(
            name="test",
            url="https://test.com",
            username="user",
            password="pass"
        )

        data = remote.to_dict()

        assert data == {
            "name": "test",
            "url": "https://test.com",
            "username": "user",
            "password": "pass"
        }

    def test_from_dict(self):
        """Test creating remote from dictionary"""
        data = {
            "name": "staging",
            "url": "https://staging.com",
            "username": "stageuser",
            "password": "stagepass"
        }

        remote = Remote.from_dict(data)

        assert remote.name == "staging"
        assert remote.url == "https://staging.com"


class TestRemoteManager:
    """Tests for RemoteManager class"""

    def test_default_config_dir(self):
        """Test default config directory detection"""
        manager = RemoteManager()
        assert "pymetabase" in str(manager.config_dir)

    def test_custom_config_dir(self):
        """Test custom config directory"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            assert manager.config_dir == Path(tmpdir)

    def test_add_and_get_remote(self):
        """Test adding and retrieving a remote"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            remote = Remote(
                name="test",
                url="https://test.com",
                username="user",
                password="pass"
            )
            manager.add_remote(remote)

            retrieved = manager.get_remote("test")
            assert retrieved is not None
            assert retrieved.name == "test"
            assert retrieved.url == "https://test.com"

    def test_list_remotes(self):
        """Test listing all remotes"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            # Add multiple remotes
            for name in ["prod", "staging", "dev"]:
                manager.add_remote(Remote(
                    name=name,
                    url=f"https://{name}.com",
                    username="user",
                    password="pass"
                ))

            remotes = manager.list_remotes()
            assert len(remotes) == 3
            assert "prod" in remotes
            assert "staging" in remotes
            assert "dev" in remotes

    def test_delete_remote(self):
        """Test deleting a remote"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.add_remote(Remote(
                name="test",
                url="https://test.com",
                username="user",
                password="pass"
            ))

            assert manager.remote_exists("test")
            result = manager.delete_remote("test")
            assert result is True
            assert not manager.remote_exists("test")

    def test_delete_nonexistent_remote(self):
        """Test deleting a remote that doesn't exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            result = manager.delete_remote("nonexistent")
            assert result is False

    def test_default_remote(self):
        """Test default remote functionality"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            # First remote becomes default automatically
            manager.add_remote(Remote(
                name="first",
                url="https://first.com",
                username="user",
                password="pass"
            ))

            assert manager.get_default_remote_name() == "first"

            # Add second remote, not default
            manager.add_remote(Remote(
                name="second",
                url="https://second.com",
                username="user",
                password="pass"
            ))

            assert manager.get_default_remote_name() == "first"

    def test_set_default(self):
        """Test setting default remote"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.add_remote(Remote("prod", "https://prod.com", "u", "p"))
            manager.add_remote(Remote("staging", "https://staging.com", "u", "p"))

            manager.set_default("staging")
            assert manager.get_default_remote_name() == "staging"

    def test_set_default_nonexistent(self):
        """Test setting default to nonexistent remote"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            result = manager.set_default("nonexistent")
            assert result is False

    def test_delete_default_updates(self):
        """Test that deleting default remote updates default"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.add_remote(Remote("first", "https://first.com", "u", "p"))
            manager.add_remote(Remote("second", "https://second.com", "u", "p"))

            assert manager.get_default_remote_name() == "first"
            manager.delete_remote("first")

            # Should auto-select another
            assert manager.get_default_remote_name() == "second"

    def test_validate_name_valid(self):
        """Test valid remote names"""
        manager = RemoteManager()

        assert manager.validate_name("production")
        assert manager.validate_name("prod-01")
        assert manager.validate_name("my_remote")
        assert manager.validate_name("Remote123")

    def test_validate_name_invalid(self):
        """Test invalid remote names"""
        manager = RemoteManager()

        assert not manager.validate_name("has space")
        assert not manager.validate_name("special@char")
        assert not manager.validate_name("dot.name")
        assert not manager.validate_name("")

    def test_add_remote_invalid_name(self):
        """Test adding remote with invalid name"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            with pytest.raises(ConfigurationError):
                manager.add_remote(Remote(
                    name="invalid name",
                    url="https://test.com",
                    username="user",
                    password="pass"
                ))

    def test_update_existing_remote(self):
        """Test updating an existing remote"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            # Add initial
            manager.add_remote(Remote(
                name="test",
                url="https://old.com",
                username="olduser",
                password="oldpass"
            ))

            # Update
            manager.add_remote(Remote(
                name="test",
                url="https://new.com",
                username="newuser",
                password="newpass"
            ))

            remote = manager.get_remote("test")
            assert remote.url == "https://new.com"
            assert remote.username == "newuser"

    def test_has_remotes(self):
        """Test has_remotes check"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            assert not manager.has_remotes()

            manager.add_remote(Remote("test", "https://test.com", "u", "p"))
            assert manager.has_remotes()

    def test_get_nonexistent_remote(self):
        """Test getting a remote that doesn't exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            result = manager.get_remote("nonexistent")
            assert result is None

    def test_persistence(self):
        """Test that config persists across manager instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # First manager
            manager1 = RemoteManager(config_dir=tmpdir)
            manager1.add_remote(Remote("test", "https://test.com", "u", "p"))

            # New manager instance
            manager2 = RemoteManager(config_dir=tmpdir)
            remote = manager2.get_remote("test")

            assert remote is not None
            assert remote.name == "test"

    def test_config_file_format(self):
        """Test that config file is valid JSON"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.add_remote(Remote("test", "https://test.com", "u", "p"))

            # Read and verify config file
            with open(manager.config_file, 'r') as f:
                config = json.load(f)

            assert "remotes" in config
            assert "default" in config
            assert "test" in config["remotes"]

    def test_set_as_default_on_add(self):
        """Test setting as default when adding"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.add_remote(Remote("first", "https://first.com", "u", "p"))
            manager.add_remote(
                Remote("second", "https://second.com", "u", "p"),
                set_as_default=True
            )

            assert manager.get_default_remote_name() == "second"


class TestRemoteManagerEdgeCases:
    """Edge case tests for RemoteManager"""

    def test_empty_config_file(self):
        """Test handling empty config file"""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"
            config_file.write_text("")

            manager = RemoteManager(config_dir=tmpdir)

            with pytest.raises(ConfigurationError):
                manager.list_remotes()

    def test_corrupted_config_file(self):
        """Test handling corrupted config file"""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"
            config_file.write_text("not valid json {")

            manager = RemoteManager(config_dir=tmpdir)

            with pytest.raises(ConfigurationError):
                manager.list_remotes()

    def test_delete_last_remote_clears_default(self):
        """Test deleting last remote clears default"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.add_remote(Remote("only", "https://only.com", "u", "p"))

            manager.delete_remote("only")

            assert manager.get_default_remote_name() is None
            assert not manager.has_remotes()


class TestTokenPersistence:
    """Tests for session token persistence functionality"""

    def test_save_and_get_token(self):
        """Test saving and retrieving a token"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.save_token("myremote", "test-session-token-123")
            retrieved = manager.get_token("myremote")

            assert retrieved == "test-session-token-123"

    def test_get_nonexistent_token(self):
        """Test getting a token that doesn't exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            result = manager.get_token("nonexistent")
            assert result is None

    def test_clear_token(self):
        """Test clearing a stored token"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.save_token("myremote", "test-token")
            assert manager.get_token("myremote") is not None

            manager.clear_token("myremote")
            assert manager.get_token("myremote") is None

    def test_clear_nonexistent_token(self):
        """Test clearing a token that doesn't exist (should not raise)"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.clear_token("nonexistent")  # Should not raise

    def test_clear_all_tokens(self):
        """Test clearing all stored tokens"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.save_token("remote1", "token1")
            manager.save_token("remote2", "token2")
            manager.save_token("remote3", "token3")

            manager.clear_all_tokens()

            assert manager.get_token("remote1") is None
            assert manager.get_token("remote2") is None
            assert manager.get_token("remote3") is None

    def test_token_persistence_across_instances(self):
        """Test that tokens persist across manager instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # First manager saves token
            manager1 = RemoteManager(config_dir=tmpdir)
            manager1.save_token("myremote", "persistent-token")

            # New manager instance should see the token
            manager2 = RemoteManager(config_dir=tmpdir)
            assert manager2.get_token("myremote") == "persistent-token"

    def test_token_file_format(self):
        """Test that token file is valid JSON"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.save_token("test", "test-token")

            # Read and verify token file
            with open(manager.tokens_file, 'r') as f:
                tokens = json.load(f)

            assert "test" in tokens
            assert tokens["test"] == "test-token"

    def test_tokens_separate_from_config(self):
        """Test that tokens are stored separately from config"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            # Add remote and token
            manager.add_remote(Remote("myremote", "https://test.com", "u", "p"))
            manager.save_token("myremote", "secret-token")

            # Verify they're in separate files
            assert manager.config_file.exists()
            assert manager.tokens_file.exists()
            assert manager.config_file != manager.tokens_file

            # Config should not contain the token
            with open(manager.config_file, 'r') as f:
                config = json.load(f)
            assert "secret-token" not in str(config)

    def test_delete_remote_clears_token(self):
        """Test that deleting a remote also clears its token"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.add_remote(Remote("myremote", "https://test.com", "u", "p"))
            manager.save_token("myremote", "session-token")

            assert manager.get_token("myremote") == "session-token"

            manager.delete_remote("myremote")

            assert manager.get_token("myremote") is None

    def test_update_token(self):
        """Test updating an existing token"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.save_token("myremote", "old-token")
            assert manager.get_token("myremote") == "old-token"

            manager.save_token("myremote", "new-token")
            assert manager.get_token("myremote") == "new-token"

    def test_multiple_remotes_different_tokens(self):
        """Test multiple remotes with different tokens"""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            manager.save_token("prod", "prod-token")
            manager.save_token("staging", "staging-token")
            manager.save_token("dev", "dev-token")

            assert manager.get_token("prod") == "prod-token"
            assert manager.get_token("staging") == "staging-token"
            assert manager.get_token("dev") == "dev-token"
