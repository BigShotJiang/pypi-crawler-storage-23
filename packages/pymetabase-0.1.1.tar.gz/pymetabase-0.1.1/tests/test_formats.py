"""
Tests for output format handlers
"""

import pytest
import json
import csv
import io
from typing import Dict, Any

from pymetabase.formats.base import OutputFormat, get_format_handler
from pymetabase.formats.jsonl import JSONLFormat
from pymetabase.formats.csv_format import CSVFormat
from pymetabase.formats.json_format import JSONFormat


class TestJSONLFormat:
    """Tests for JSONL output format"""

    def test_write_row(self):
        """Test writing a single row"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        formatter.write_row({"id": 1, "name": "Alice"})

        output.seek(0)
        line = output.readline()
        data = json.loads(line)

        assert data == {"id": 1, "name": "Alice"}
        assert formatter.row_count == 1

    def test_write_multiple_rows(self):
        """Test writing multiple rows"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        rows = [
            {"id": 1, "name": "Alice"},
            {"id": 2, "name": "Bob"},
            {"id": 3, "name": "Charlie"}
        ]

        count = formatter.write_rows(iter(rows))

        assert count == 3
        assert formatter.row_count == 3

        output.seek(0)
        lines = output.readlines()
        assert len(lines) == 3

        for i, line in enumerate(lines):
            data = json.loads(line)
            assert data == rows[i]

    def test_removes_row_num_column(self):
        """Test that _row_num column is removed"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        formatter.write_row({"id": 1, "name": "Alice", "_row_num": 1})

        output.seek(0)
        data = json.loads(output.readline())

        assert "_row_num" not in data
        assert data == {"id": 1, "name": "Alice"}

    def test_unicode_handling(self):
        """Test unicode characters are handled correctly"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        formatter.write_row({"name": "Ñoño", "city": "北京"})

        output.seek(0)
        data = json.loads(output.readline())

        assert data == {"name": "Ñoño", "city": "北京"}

    def test_finalize(self):
        """Test finalize does nothing for JSONL"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        formatter.write_row({"id": 1})
        formatter.finalize()  # Should not raise or add content


class TestCSVFormat:
    """Tests for CSV output format"""

    def test_write_row(self):
        """Test writing a single row"""
        output = io.StringIO()
        formatter = CSVFormat(output)

        formatter.write_row({"id": "1", "name": "Alice"})
        formatter.finalize()

        output.seek(0)
        reader = csv.DictReader(output)
        rows = list(reader)

        assert len(rows) == 1
        assert rows[0]["id"] == "1"
        assert rows[0]["name"] == "Alice"

    def test_write_multiple_rows(self):
        """Test writing multiple rows"""
        output = io.StringIO()
        formatter = CSVFormat(output)

        rows = [
            {"id": "1", "name": "Alice"},
            {"id": "2", "name": "Bob"},
        ]

        count = formatter.write_rows(iter(rows))

        assert count == 2

        output.seek(0)
        reader = csv.DictReader(output)
        result = list(reader)

        assert len(result) == 2
        assert result[0]["name"] == "Alice"
        assert result[1]["name"] == "Bob"

    def test_removes_row_num_column(self):
        """Test that _row_num column is removed"""
        output = io.StringIO()
        formatter = CSVFormat(output)

        formatter.write_row({"id": "1", "name": "Alice", "_row_num": "1"})

        output.seek(0)
        reader = csv.DictReader(output)
        row = next(reader)

        assert "_row_num" not in row
        assert row["id"] == "1"
        assert row["name"] == "Alice"

    def test_header_written_once(self):
        """Test that header is only written once"""
        output = io.StringIO()
        formatter = CSVFormat(output)

        formatter.write_row({"id": "1", "name": "Alice"})
        formatter.write_row({"id": "2", "name": "Bob"})

        output.seek(0)
        lines = output.readlines()

        # First line should be header
        assert "id,name" in lines[0] or "name,id" in lines[0]
        # Only 3 lines total (header + 2 data rows)
        assert len(lines) == 3


class TestJSONFormat:
    """Tests for JSON array output format"""

    def test_write_single_row(self):
        """Test writing a single row"""
        output = io.StringIO()
        formatter = JSONFormat(output)

        formatter.write_row({"id": 1, "name": "Alice"})
        formatter.finalize()

        output.seek(0)
        data = json.load(output)

        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0] == {"id": 1, "name": "Alice"}

    def test_write_multiple_rows(self):
        """Test writing multiple rows"""
        output = io.StringIO()
        formatter = JSONFormat(output)

        rows = [
            {"id": 1, "name": "Alice"},
            {"id": 2, "name": "Bob"},
            {"id": 3, "name": "Charlie"}
        ]

        formatter.write_rows(iter(rows))
        formatter.finalize()

        output.seek(0)
        data = json.load(output)

        assert len(data) == 3
        assert data == rows

    def test_empty_array_when_no_rows(self):
        """Test that finalize writes empty array when no rows"""
        output = io.StringIO()
        formatter = JSONFormat(output)

        formatter.finalize()

        output.seek(0)
        data = json.load(output)

        assert data == []

    def test_removes_row_num_column(self):
        """Test that _row_num column is removed"""
        output = io.StringIO()
        formatter = JSONFormat(output)

        formatter.write_row({"id": 1, "name": "Alice", "_row_num": 1})
        formatter.finalize()

        output.seek(0)
        data = json.load(output)

        assert "_row_num" not in data[0]

    def test_valid_json_output(self):
        """Test that output is valid JSON"""
        output = io.StringIO()
        formatter = JSONFormat(output)

        formatter.write_row({"a": 1})
        formatter.write_row({"b": 2})
        formatter.finalize()

        output.seek(0)
        content = output.read()

        # Should not raise
        data = json.loads(content)
        assert len(data) == 2


class TestGetFormatHandler:
    """Tests for get_format_handler function"""

    def test_get_jsonl_handler(self):
        """Test getting JSONL handler"""
        output = io.StringIO()
        handler = get_format_handler('jsonl', output)

        assert isinstance(handler, JSONLFormat)

    def test_get_json_handler(self):
        """Test getting JSON handler"""
        output = io.StringIO()
        handler = get_format_handler('json', output)

        assert isinstance(handler, JSONFormat)

    def test_get_csv_handler(self):
        """Test getting CSV handler"""
        output = io.StringIO()
        handler = get_format_handler('csv', output)

        assert isinstance(handler, CSVFormat)

    def test_case_insensitive(self):
        """Test that format name is case insensitive"""
        output = io.StringIO()

        handler1 = get_format_handler('JSONL', output)
        handler2 = get_format_handler('Jsonl', output)
        handler3 = get_format_handler('jsonl', output)

        assert all(isinstance(h, JSONLFormat) for h in [handler1, handler2, handler3])

    def test_unknown_format_raises(self):
        """Test that unknown format raises ValueError"""
        output = io.StringIO()

        with pytest.raises(ValueError) as exc_info:
            get_format_handler('xml', output)

        assert "Unknown format" in str(exc_info.value)
        assert "xml" in str(exc_info.value)


class TestWriteCsvResponse:
    """Tests for write_csv_response method"""

    def test_write_csv_response_to_jsonl(self):
        """Test converting CSV response to JSONL"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        csv_content = "id,name\n1,Alice\n2,Bob\n"
        count = formatter.write_csv_response(csv_content)

        assert count == 2

        output.seek(0)
        lines = output.readlines()

        data1 = json.loads(lines[0])
        data2 = json.loads(lines[1])

        assert data1 == {"id": "1", "name": "Alice"}
        assert data2 == {"id": "2", "name": "Bob"}

    def test_write_csv_response_to_csv(self):
        """Test converting CSV response to CSV"""
        output = io.StringIO()
        formatter = CSVFormat(output)

        csv_content = "id,name\n1,Alice\n2,Bob\n"
        count = formatter.write_csv_response(csv_content)

        assert count == 2

    def test_write_csv_response_empty(self):
        """Test converting empty CSV response"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        csv_content = "id,name\n"
        count = formatter.write_csv_response(csv_content)

        assert count == 0


class TestOutputFormatBase:
    """Tests for base OutputFormat class"""

    def test_row_count_property(self):
        """Test row_count property"""
        output = io.StringIO()
        formatter = JSONLFormat(output)

        assert formatter.row_count == 0

        formatter.write_row({"id": 1})
        assert formatter.row_count == 1

        formatter.write_row({"id": 2})
        assert formatter.row_count == 2
