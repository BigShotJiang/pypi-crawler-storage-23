"""
Tests for PyMetabase
"""
