"""
Tests for exception module
"""

import pytest

from pymetabase.exceptions import (
    PyMetabaseError,
    AuthenticationError,
    ConnectionError,
    QueryError,
    ExportError,
    ChunkError,
    ConfigurationError,
    DatabaseNotFoundError,
    ValidationError,
)


class TestExceptionHierarchy:
    """Tests for exception class hierarchy"""

    def test_base_exception(self):
        """Test PyMetabaseError is base for all exceptions"""
        assert issubclass(AuthenticationError, PyMetabaseError)
        assert issubclass(ConnectionError, PyMetabaseError)
        assert issubclass(QueryError, PyMetabaseError)
        assert issubclass(ExportError, PyMetabaseError)
        assert issubclass(ConfigurationError, PyMetabaseError)
        assert issubclass(DatabaseNotFoundError, PyMetabaseError)
        assert issubclass(ValidationError, PyMetabaseError)

    def test_chunk_error_is_export_error(self):
        """Test ChunkError inherits from ExportError"""
        assert issubclass(ChunkError, ExportError)
        assert issubclass(ChunkError, PyMetabaseError)

    def test_all_inherit_from_exception(self):
        """Test all custom exceptions inherit from Exception"""
        exceptions = [
            PyMetabaseError,
            AuthenticationError,
            ConnectionError,
            QueryError,
            ExportError,
            ChunkError,
            ConfigurationError,
            DatabaseNotFoundError,
            ValidationError,
        ]

        for exc in exceptions:
            assert issubclass(exc, Exception)


class TestExceptionUsage:
    """Tests for exception message handling"""

    def test_exception_message(self):
        """Test exception preserves message"""
        msg = "Test error message"
        exc = PyMetabaseError(msg)

        assert str(exc) == msg

    def test_authentication_error_message(self):
        """Test AuthenticationError preserves message"""
        exc = AuthenticationError("Invalid credentials")
        assert "Invalid credentials" in str(exc)

    def test_connection_error_message(self):
        """Test ConnectionError preserves message"""
        exc = ConnectionError("Cannot connect to server")
        assert "Cannot connect to server" in str(exc)

    def test_database_not_found_error(self):
        """Test DatabaseNotFoundError with database name"""
        exc = DatabaseNotFoundError("Database 'TestDB' not found")
        assert "TestDB" in str(exc)

    def test_configuration_error(self):
        """Test ConfigurationError preserves message"""
        exc = ConfigurationError("Missing required field: url")
        assert "url" in str(exc)

    def test_query_error(self):
        """Test QueryError preserves message"""
        exc = QueryError("Syntax error in query")
        assert "Syntax error" in str(exc)

    def test_chunk_error(self):
        """Test ChunkError preserves message"""
        exc = ChunkError("Failed to export chunk 3")
        assert "chunk 3" in str(exc)


class TestExceptionCatching:
    """Tests for exception catching behavior"""

    def test_catch_specific_exception(self):
        """Test catching specific exception type"""
        def raise_auth_error():
            raise AuthenticationError("Auth failed")

        with pytest.raises(AuthenticationError):
            raise_auth_error()

    def test_catch_base_exception(self):
        """Test catching base exception catches all subtypes"""
        def raise_db_error():
            raise DatabaseNotFoundError("Not found")

        with pytest.raises(PyMetabaseError):
            raise_db_error()

    def test_catch_export_catches_chunk(self):
        """Test catching ExportError catches ChunkError"""
        def raise_chunk_error():
            raise ChunkError("Chunk failed")

        with pytest.raises(ExportError):
            raise_chunk_error()

    def test_exception_in_except_block(self):
        """Test exception instance in except block"""
        try:
            raise ValidationError("Invalid value")
        except ValidationError as e:
            assert str(e) == "Invalid value"
            assert isinstance(e, PyMetabaseError)
