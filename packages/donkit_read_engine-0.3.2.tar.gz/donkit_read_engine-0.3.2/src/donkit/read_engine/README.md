# Donkit Read Engine

Document extraction library for Donkit RagOps. Reads documents in 20+ formats and exports structured content as JSON, preserving page-level structure, tables, headings, and optionally describing images via LLM.

## Package Info

- **Package:** `donkit-read-engine` (PyPI)
- **Version:** 0.3.1
- **Python:** >=3.12, <3.14
- **License:** MIT

## Architecture

```
DonkitReader (orchestrator)
├── reading_pipeline="docling_llm"  →  DoclingReader + LLM image descriptions
├── reading_pipeline="llm"          →  LlmPDFReader (PDF) / DoclingReader (other)
└── reading_pipeline="docling"      →  DoclingReader only (no LLM)

Fallback readers:
├── .json  →  json_document_read_handler
└── .xls   →  sheet_read_handler
```

### Pipelines

| Pipeline | Description | Requires `llm_model` |
|----------|-------------|---------------------|
| `docling_llm` | Docling extracts text/tables, LLM describes images | Yes |
| `llm` | PDF pages rasterized and sent entirely to LLM vision; other formats via Docling | Yes |
| `docling` | Docling only, uses built-in VLM for image descriptions | No |

## Installation

```bash
cd ragops-agent/shared/read-engine
poetry install
```

## Quick Start

### Without LLM (text-only)

```python
from donkit.read_engine.read_engine import DonkitReader

reader = DonkitReader(reading_pipeline="docling")
result = reader.read_document("report.pdf")
print(result.output_path)   # ./processed/report.json
print(result.page_count)    # 42
```

### With LLM (image descriptions)

```python
from donkit.llm import ModelFactory
from donkit.read_engine.read_engine import DonkitReader

# Create LLM model externally
llm_model = ModelFactory.create_model("openai", "gpt-4.1-mini", {
    "api_key": "sk-...",
})

reader = DonkitReader(
    llm_model=llm_model,
    reading_pipeline="docling_llm",  # default
    output_format="json",
)

result = reader.read_document("report.pdf", output_dir="./output")
print(result.output_path)
print(result.total_llm_requests)
print(result.total_prompt_tokens)
```

### Async Usage

```python
import asyncio
from donkit.read_engine.read_engine import DonkitReader

reader = DonkitReader(reading_pipeline="docling")
result = asyncio.run(reader.aread_document("report.pdf"))
```

### With Progress Callback

```python
def on_progress(current: int, total: int, message: str | None) -> None:
    print(f"[{current}/{total}] {message}")

reader = DonkitReader(
    llm_model=llm_model,
    reading_pipeline="llm",
    progress_callback=on_progress,
)
result = reader.read_document("large_report.pdf")
```

## CLI

```bash
# Process single file (uses "docling" pipeline, no LLM)
donkit-read-engine report.pdf

# Process directory recursively
donkit-read-engine ./documents/

# With OCR settings
donkit-read-engine scan.pdf --pdf-strategy hi_res --ocr-lang rus+eng
```

**CLI Arguments:**

| Argument | Values | Default | Description |
|----------|--------|---------|-------------|
| `file_path` | path | required | File or directory to process |
| `--output-type` | text, json, markdown | json | Output format |
| `--pdf-strategy` | fast, hi_res, ocr_only, auto | hi_res | Unstructured PDF strategy |
| `--ocr-lang` | e.g. `rus+eng` | rus+eng | OCR language codes |

## Supported Formats

### Via Docling (primary engine)

| Extension | Format |
|-----------|--------|
| `.pdf` | PDF documents |
| `.docx` | Microsoft Word |
| `.pptx` | Microsoft PowerPoint |
| `.xlsx` | Microsoft Excel |
| `.csv` | Comma-separated values |
| `.html` | HTML pages |
| `.md`, `.txt` | Text / Markdown |
| `.asciidoc` | AsciiDoc |
| `.tex` | LaTeX |
| `.vtt` | WebVTT subtitles |
| `.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`, `.tiff` | Images |

### Via Legacy Readers

| Extension | Format | Handler |
|-----------|--------|---------|
| `.json` | JSON files | `json_document_read_handler` |
| `.xls` | Legacy Excel | `sheet_read_handler` |

## API Reference

### DonkitReader

Main orchestrator class.

```python
class DonkitReader:
    def __init__(
        self,
        output_format: Literal["json", "text", "md"] = "json",
        progress_callback: Callable[[int, int, str | None], None] | None = None,
        llm_model: LLMModelAbstract | None = None,
        reading_pipeline: str = "docling_llm",
    ) -> None
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `output_format` | `"json"` / `"text"` / `"md"` | `"json"` | Output content format |
| `progress_callback` | `Callable` or `None` | `None` | Progress reporting callback |
| `llm_model` | `LLMModelAbstract` or `None` | `None` | LLM model for image analysis. Required for `docling_llm` and `llm` pipelines |
| `reading_pipeline` | `str` | `"docling_llm"` | Pipeline selection: `"docling_llm"`, `"llm"`, `"docling"` |

**Methods:**

| Method | Returns | Description |
|--------|---------|-------------|
| `read_document(file_path, output_dir=None)` | `ReadDocumentResult` | Sync: read document and extract content |
| `aread_document(file_path, output_dir=None)` | `ReadDocumentResult` | Async: read document and extract content |
| `supported_extensions()` | `frozenset[str]` | All supported file extensions |

### ReadDocumentResult

```python
@dataclass
class ReadDocumentResult:
    output_path: str                          # Path to output JSON file
    page_count: int = 0                       # Number of pages extracted
    page_split_duration_ms: int | None = None # PDF split timing (llm pipeline)
    reading_duration_ms: int | None = None    # Total reading timing
    gc_duration_ms: int | None = None         # Garbage collection timing
    json_serialize_duration_ms: int | None = None
    rasterize_duration_ms: int | None = None  # PDF→image timing (llm pipeline)
    total_llm_requests: int = 0               # Number of LLM API calls
    total_prompt_tokens: int = 0              # Total input tokens
    total_completion_tokens: int = 0          # Total output tokens
```

### ImageAnalysisService (ABC)

Interface for image analysis. Implementations must provide sync, async, and text-only methods.

```python
class ImageAnalysisService(ABC):
    def analyze_image(self, encoded_image: str, prompt: str, context: str | None) -> ImageAnalysisResult
    async def aanalyze_image(self, encoded_image: str, prompt: str, context: str | None) -> ImageAnalysisResult
    def call_text_only(self, prompt: str) -> ImageAnalysisResult
```

### LLMImageAnalysisService

Concrete implementation using `donkit.llm`.

```python
class LLMImageAnalysisService(ImageAnalysisService):
    def __init__(
        self,
        llm_model: LLMModelAbstract,          # Required — LLM model instance
        cache_service: FileBasedImageCache | None = None,
        *,
        output_format: Literal["json", "text", "md"] = "json",
        max_tokens: int = 16384,
    )
```

Features:
- Automatic retry with exponential backoff (3 retries, 1-10s wait)
- File-based image cache (MD5 hash keys, composite keys for format+prompt)
- Format-specific prompt generation (JSON schema, markdown, plain text)

### get_image_analysis_service (factory)

```python
def get_image_analysis_service(
    llm_model: LLMModelAbstract,
    cache_service: FileBasedImageCache | None = None,
    *,
    output_format: Literal["json", "text", "md"] = "json",
    max_tokens: int = 16384,
) -> LLMImageAnalysisService
```

### ImageAnalysisResult

```python
@dataclass
class ImageAnalysisResult:
    content: str                                    # Extracted text/description
    usage: dict[str, int | None] | None = None     # {prompt_tokens, completion_tokens}
```

### LLMUsageMetrics

```python
@dataclass
class LLMUsageMetrics:
    total_llm_requests: int = 0
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0

    def add_usage(self, usage: dict[str, int | None] | None) -> None
```

### DoclingReader

Primary document reader using the Docling library.

```python
class DoclingReader:
    def __init__(self, image_service=None, skip_pictures: bool = False) -> None
    def supports(file_path: str) -> bool                                      # static
    def read(file_path: str) -> list[dict[str, Any]]                          # sync
    async def aread(file_path: str) -> tuple[list[dict], LLMUsageMetrics]     # async
```

Configuration:
- Uses `StandardPdfPipeline` with `DOCLING_LAYOUT_EGRET_LARGE` layout model
- `ThreadedPdfPipelineOptions` for parallel processing
- Picture description concurrency: 15 simultaneous LLM calls
- Text formatting: headings (H1-H6), lists, code blocks, formulas, captions, footnotes, references

### LlmPDFReader

Pure LLM-based PDF reader. Each page is rasterized to grayscale PNG (85 DPI) and sent to LLM.

```python
class LlmPDFReader:
    def __init__(
        self,
        image_service: ImageAnalysisService,
        progress_interval: int = 1,
        progress_callback: Callable[[int, int, str | None], None] | None = None,
        max_ahead: int = 50,       # Max pages scheduled ahead
        concurrency: int = 20,     # Max concurrent LLM calls
    )

    async def aread(pdf_path: str, output_path: str | None = None) -> ReadResult | list[dict]
```

Features:
- Sliding window for memory-efficient streaming output
- Concurrent page processing with semaphore control
- Periodic garbage collection (every 5/20 pages)
- JSON repair for malformed LLM output

### PageProcessor

Processes individual PDF pages.

```python
class PageProcessor:
    def __init__(self, image_service: ImageAnalysisService)
    async def aprocess(page_path: str, page_num: int) -> tuple[PageContent, float, float, dict | None]
```

### FileBasedImageCache

Persistent file-based cache for image analysis results.

```python
class FileBasedImageCache:
    def __init__(self, cache_file: Path = Path("image_cache.json"))
    def get_hash(self, image_bytes: bytes) -> str      # MD5
    def get(self, image_hash: str) -> str | None
    def set(self, image_hash: str, content: str) -> None
```

### Handler Functions

| Function | Location | Input | Output |
|----------|----------|-------|--------|
| `json_document_read_handler(path)` | json_document_format | `.json` | `str \| list[dict] \| None` |
| `sheet_read_handler(path)` | microsoft_office_sheet | `.xls`, `.xlsx` | `str` (markdown table) |
| `text_document_read_handler(path)` | text_document_format | `.txt` | `str` |
| `document_read_handler(path)` | microsoft_office_document | `.docx` | `list[dict]` |
| `image_read_handler(path, image_service)` | static_visual_format | images | `dict` |
| `presentation_read_handler(path, pdf_handler, output_path)` | microsoft_office_presentation | `.pptx` | `list[dict] \| str` |

### LlmDocumentReader

DOCX reader with LLM-based image analysis (used separately from DoclingReader).

```python
class LlmDocumentReader:
    def __init__(self, image_service: ImageAnalysisService)
    def read(path: str, output_path: str | None = None) -> list[dict] | str
```

## Output Format

All pipelines produce the same JSON structure:

```json
{
  "content": [
    {
      "page": 1,
      "type": "Text",
      "content": "# Document Title\n\nParagraph text...\n\n| Col1 | Col2 |\n|------|------|\n| A    | B    |"
    },
    {
      "page": 2,
      "type": "Text",
      "content": "More text with **formatting**..."
    }
  ]
}
```

Content within each page is markdown-formatted:
- `# Title`, `## Section`, `### Subsection` — headings
- `- item` — list items
- Markdown tables from Docling
- `*caption*` — image captions
- Code blocks, formulas, footnotes preserved

## Performance

### Concurrency Settings

| Component | Default | Description |
|-----------|---------|-------------|
| DoclingReader picture descriptions | 15 | Concurrent LLM calls for images in Docling output |
| LlmPDFReader page processing | 20 | Concurrent page-level LLM calls |
| LlmPDFReader max_ahead | 50 | Max pages scheduled ahead of last written |

### Image Rasterization (LLM pipeline)

- Resolution: 85 DPI
- Color space: Grayscale
- Format: PNG, base64-encoded
- Periodic GC: every 5 pages (in-memory), every 20 pages (streaming)

### Caching

`FileBasedImageCache` persists results to `image_cache.json`:
- Key: MD5 hash of `image_bytes + "|" + output_format + "|" + prompt`
- Eliminates duplicate LLM calls for identical images

## Environment Variables

| Variable | Used By | Default | Description |
|----------|---------|---------|-------------|
| `UNSTRUCTURED_STRATEGY` | pdf_parser | `hi_res` | PDF OCR strategy |
| `UNSTRUCTURED_OCR_LANG` | pdf_parser | `rus+eng` | OCR languages |
| `RAGOPS_LOG_LEVEL` | logging | `ERROR` | Log level |
| `LOG_LEVEL` | logging (fallback) | `ERROR` | Fallback log level |

**Note:** LLM configuration (API keys, providers, models) is no longer read from environment variables. The `llm_model` must be created externally and passed to `DonkitReader`.

## Consumer Examples

### Enterprise (ragops-agent service)

```python
from donkit.read_engine.read_engine import DonkitReader

reader = DonkitReader(
    output_format="json",
    llm_model=llm_gate_model,  # LLMGateModel from service DI
)
result = await reader.aread_document(str(local_path), output_dir=temp_dir)
# Upload result.output_path to S3
```

### CLI (ragops MCP server)

```python
reader = DonkitReader(
    llm_model=llm_model,
    reading_pipeline=reading_pipeline,
    output_format=reading_format,
)
result = await reader.aread_document(file_path, output_dir=output_dir)
```

## Project Structure

```
read-engine/
├── pyproject.toml
└── src/donkit/read_engine/
    ├── __init__.py
    ├── read_engine.py                              # DonkitReader, ReadDocumentResult, CLI
    └── readers/
        ├── docling_backend/handler.py              # DoclingReader
        ├── portable_document_format/
        │   ├── handler.py                          # LlmPDFReader, PageProcessor, PDFSplitter
        │   └── pdf_parser.py                       # StructuredPDFProcessor, unstructured
        ├── static_visual_format/
        │   ├── handler.py                          # image_read_handler
        │   └── models.py                           # ImageAnalysisService, LLMImageAnalysisService, cache
        ├── microsoft_office_document/
        │   ├── handler.py                          # document_read_handler, LlmDocumentReader
        │   └── parser.py                           # DocumentParser (DOCX internals)
        ├── microsoft_office_presentation/handler.py # PPTX→PDF→read
        ├── microsoft_office_sheet/handler.py        # Excel/pandas
        ├── json_document_format/handler.py          # JSON with multi-encoding
        └── text_document_format/handler.py          # Plain text with multi-encoding
```

## Dependencies

### Core

| Package | Version | Purpose |
|---------|---------|---------|
| `docling` | ^2.75.0 | Primary document conversion engine |
| `pymupdf` | ^1.26.4 | PDF rasterization and text extraction |
| `unstructured[pdf]` | ^0.18.15 | PDF OCR with Tesseract |
| `pypdf` | ^6.1.3 | PDF utilities |
| `python-docx` | ^1.1.0 | DOCX parsing |
| `python-pptx` | ^1.0.2 | PPTX parsing |
| `pandas` | ^2.2.3 | Excel/CSV processing |
| `pillow` | ^10.2.0 | Image processing |
| `donkit-llm` | ^0.1.4 | LLM abstraction layer |
| `json-repair` | ^0.52.3 | Repair malformed JSON from LLM |
| `loguru` | ^0.7.2 | Structured logging |
| `python-dotenv` | ^1.1.0 | Environment variable loading |

### Dev

| Package | Purpose |
|---------|---------|
| `pytest` | Testing |
| `ruff` | Linting/formatting |
| `httpx` | HTTP testing |
| `testcontainers` | Integration tests |
