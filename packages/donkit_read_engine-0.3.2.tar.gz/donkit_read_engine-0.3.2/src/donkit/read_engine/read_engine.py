import argparse
import asyncio
import json
import os
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from typing import Literal

from donkit.llm import LLMModelAbstract
from donkit.read_engine.readers.static_visual_format.models import (
    get_image_analysis_service,
)
from loguru import logger

from .readers.json_document_format.handler import json_document_read_handler
from .readers.microsoft_office_sheet.handler import sheet_read_handler


@dataclass
class ReadDocumentResult:
    output_path: str
    page_count: int = 0
    page_split_duration_ms: int | None = None
    reading_duration_ms: int | None = None
    gc_duration_ms: int | None = None
    json_serialize_duration_ms: int | None = None
    rasterize_duration_ms: int | None = None
    total_llm_requests: int = 0
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0


class DonkitReader:
    """Main document reader orchestrator.

    Manages initialization of all services and delegates to specific readers.
    """

    def __init__(
        self,
        output_format: Literal["json", "text", "md"] = "json",
        progress_callback: Callable[[int, int, str | None], None] | None = None,
        llm_model: LLMModelAbstract | None = None,
        reading_pipeline: str = "docling_llm",
    ) -> None:
        """Initialize DonkitReader with appropriate services.

        Uses Docling StandardPdfPipeline for all supported formats.
        If an LLM model is provided, uses it to describe images found in documents.
        Otherwise falls back to Docling's built-in VLM for image descriptions.

        Args:
            output_format: Output format for content extraction.
            progress_callback: Optional callback for progress reporting.
                               Signature: (current: int, total: int, message: str | None) -> None
            llm_model: LLM model instance for image description.
                       Required for "docling_llm" and "llm" pipelines.
            reading_pipeline: Pipeline selection:
                - "docling_llm" (default): Docling + LLM for image descriptions
                - "llm": Pure LLM — every PDF page rasterized and sent to LLM vision
                - "docling": Docling only, no LLM (built-in VLM for images)
        """
        self.output_format = output_format
        self._progress_callback = progress_callback
        self._llm_model = llm_model
        self._reading_pipeline = reading_pipeline

        # Determine whether to initialize image service based on pipeline
        need_image_service = reading_pipeline in ("docling_llm", "llm")

        if need_image_service:
            self._image_service = self._initialize_image_service(output_format)
        else:
            self._image_service = None

        # Docling handles all supported formats (used for docling_llm, docling, and non-PDF in llm mode)
        from .readers.docling_backend.handler import DoclingReader

        docling_image_service = (
            self._image_service if reading_pipeline == "docling_llm" else None
        )
        skip_pictures = reading_pipeline == "docling"
        self._docling_reader = DoclingReader(
            image_service=docling_image_service,
            skip_pictures=skip_pictures,
        )

        # LlmPDFReader for pure LLM pipeline (PDF only)
        self._llm_pdf_reader = None
        if reading_pipeline == "llm" and self._image_service:
            from .readers.portable_document_format.handler import LlmPDFReader

            self._llm_pdf_reader = LlmPDFReader(
                image_service=self._image_service,
                progress_callback=progress_callback,
            )

        # Fallback readers for formats not supported by Docling
        self.readers = {
            ".json": json_document_read_handler,
            ".xls": sheet_read_handler,
        }

    def _initialize_image_service(
        self,
        output_format: Literal["json", "text", "md"] = "json",
    ):
        """Initialize image analysis service using the provided LLM model."""
        if not self._llm_model:
            logger.debug("No LLM model provided, image analysis disabled")
            return None

        logger.debug("Image service available (using provided LLM model)")
        return get_image_analysis_service(
            llm_model=self._llm_model,
            output_format=output_format,
        )

    def supported_extensions(self) -> frozenset[str]:
        """Return all supported file extensions across Docling and legacy readers."""
        from .readers.docling_backend.handler import (
            SUPPORTED_EXTENSIONS as _DOCLING_EXTS,
        )

        return _DOCLING_EXTS | frozenset(self.readers.keys())

    def read_document(
        self,
        file_path: str,
        output_dir: str | None = None,
    ) -> ReadDocumentResult:
        """Main method. Delegates to async aread_document to avoid sync LLM paths."""
        return asyncio.run(self.aread_document(file_path, output_dir))

    def __extract_content_sync(
        self, file_path: str, file_extension: str
    ) -> str | list[dict[str, Any]]:
        """Synchronous content extraction (runs in thread pool).
        Args:
            file_path: Path to the local file
            file_extension: File extension (including the dot)
        Returns:
            Content extracted from the document (either text or structured data)
        """
        try:
            if file_extension in self.readers:
                return self.readers[file_extension](file_path)
            else:
                msg = (
                    f"Unsupported file extension: {file_extension}"
                    f"Supported extensions: {list(self.readers.keys())}"
                )
                raise ValueError(msg)
        except Exception:
            raise

    @staticmethod
    def _process_output(
        content: str | list[dict[str, Any]],
        file_path: str,
        output_dir: str | None = None,
    ) -> str:
        """Process extracted content and always write a JSON file.

        Args:
            content: Extracted content (text or structured data)
            file_path: Original path to the file
            output_dir: Optional custom output directory
        """
        path = Path(file_path)
        file_name = path.stem

        # Determine output directory
        if output_dir is None:
            output_dir = str(path.parent / Path("processed"))
        else:
            output_dir = str(Path(output_dir))

        # Build the JSON payload with a consistent top-level shape: list of pages
        # output_format only affects how upstream produced each page's "content" (str or object).
        if isinstance(content, list):
            payload_content: list[dict[str, Any]] = content
        else:
            payload_content = [{"page": 1, "type": "Text", "content": content}]

        # Always write JSON with a top-level {"content": ...}
        output_file_name = f"{file_name}.json"
        processed_content = json.dumps(
            {"content": payload_content}, ensure_ascii=False, indent=2
        )

        output_path = Path(output_dir) / output_file_name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(processed_content, encoding="utf-8")
        return output_path.as_posix()

    async def aread_document(
        self,
        file_path: str,
        output_dir: str | None = None,
    ) -> ReadDocumentResult:
        """Async: Main method to read a document and extract its content.

        Routing logic depends on reading_pipeline:
        - "docling_llm": Docling + LLM for image descriptions (default)
        - "llm": Pure LLM for PDF files (each page → LLM vision), Docling for other formats
        - "docling": Docling only, no LLM
        - Legacy formats (.xls, .json) → specialized readers (all pipelines)

        Args:
            file_path: Path to the file
            output_dir: Optional custom output directory. If not provided,
                       creates 'processed/' subdirectory next to the source file.

        Returns:
            ReadDocumentResult with output_path and timing details
        """
        file_extension = Path(file_path).suffix.lower()

        # Pure LLM pipeline: route PDF files to LlmPDFReader
        if (
            self._reading_pipeline == "llm"
            and file_extension == ".pdf"
            and self._llm_pdf_reader
        ):
            # Determine output path for LlmPDFReader
            path = Path(file_path)
            if output_dir is None:
                out_dir = str(path.parent / "processed")
            else:
                out_dir = str(Path(output_dir))
            Path(out_dir).mkdir(parents=True, exist_ok=True)
            out_file = Path(out_dir) / f"{path.stem}.json"

            read_result = await self._llm_pdf_reader.aread(
                file_path, output_path=str(out_file)
            )
            return ReadDocumentResult(
                output_path=read_result.output_path,
                page_count=read_result.page_count,
                page_split_duration_ms=read_result.page_split_duration_ms,
                reading_duration_ms=read_result.reading_duration_ms,
                gc_duration_ms=read_result.gc_duration_ms,
                json_serialize_duration_ms=read_result.json_serialize_duration_ms,
                rasterize_duration_ms=read_result.rasterize_duration_ms,
                total_llm_requests=read_result.total_llm_requests,
                total_prompt_tokens=read_result.total_prompt_tokens,
                total_completion_tokens=read_result.total_completion_tokens,
            )

        # Docling: all supported formats (PDF, PPTX, DOCX, images, etc.)
        if self._docling_reader.supports(file_path):
            content, metrics = await self._docling_reader.aread(file_path)
            output_file_path_str = await asyncio.to_thread(
                self._process_output, content, file_path, output_dir
            )
            if metrics.total_llm_requests > 0:
                logger.info(
                    f"Read {file_path}: "
                    f"{metrics.total_llm_requests} LLM requests, "
                    f"{metrics.total_prompt_tokens} prompt tokens, "
                    f"{metrics.total_completion_tokens} completion tokens"
                )
            return ReadDocumentResult(
                output_path=output_file_path_str,
                page_count=self._count_pages(output_file_path_str),
                total_llm_requests=metrics.total_llm_requests,
                total_prompt_tokens=metrics.total_prompt_tokens,
                total_completion_tokens=metrics.total_completion_tokens,
            )

        # Legacy readers for formats not supported by Docling (.xls, .json, etc.)
        content = await asyncio.to_thread(
            self.__extract_content_sync, file_path, file_extension
        )
        output_file_path_str = await asyncio.to_thread(
            self._process_output, content, file_path, output_dir
        )
        return ReadDocumentResult(
            output_path=output_file_path_str,
            page_count=self._count_pages(output_file_path_str),
        )

    @staticmethod
    def _count_pages(output_path: str) -> int:
        try:
            content = json.loads(Path(output_path).read_text(encoding="utf-8"))
            pages = content.get("content", [])
            return len({p.get("page", 0) for p in pages})
        except Exception:
            return 0


def main() -> None:
    """CLI entry point for Donkit read engine.

    Usage:
        donkit-read-engine <file_path> [--output-type text|json|markdown]
    """
    parser = argparse.ArgumentParser(
        prog="donkit-read-engine",
        description="Read a document and export extracted content to text/json/markdown",
    )
    parser.add_argument(
        "file_path",
        nargs="?",
        default="/Users/romanlosev/donkit/platform/ragops-agent/shared/read-engine/src/files",
        help="Path to a local file or directory to read (directory will be processed recursively)",
    )
    parser.add_argument(
        "--output-type",
        choices=["text", "json", "markdown"],
        default="json",
        help="Output format (default: json)",
    )
    parser.add_argument(
        "--pdf-strategy",
        choices=["fast", "hi_res", "ocr_only", "auto"],
        default=None,
        help="unstructured parsing strategy (overrides UNSTRUCTURED_STRATEGY)",
    )
    parser.add_argument(
        "--ocr-lang",
        default=None,
        help="OCR languages for unstructured (e.g., 'rus+eng') (overrides UNSTRUCTURED_OCR_LANG)",
    )
    args = parser.parse_args()

    # Apply optional strategy settings for unstructured before constructing reader
    if args.pdf_strategy:
        os.environ["UNSTRUCTURED_STRATEGY"] = args.pdf_strategy
    if args.ocr_lang:
        os.environ["UNSTRUCTURED_OCR_LANG"] = args.ocr_lang

    reader = DonkitReader(reading_pipeline="docling")
    input_path = Path(args.file_path)
    if input_path.is_dir():
        exts = set(reader.supported_extensions())
        files: list[Path] = [
            f for f in input_path.rglob("*") if f.is_file() and f.suffix.lower() in exts
        ]
        for f in sorted(files):
            try:
                result = reader.read_document(f.as_posix(), args.output_type)  # type: ignore[arg-type]
                print(result.output_path)
            except Exception as e:
                print(f"ERROR processing {f}: {e}")
    else:
        result = reader.read_document(input_path.as_posix(), args.output_type)  # type: ignore[arg-type]
        print(result.output_path)


if __name__ == "__main__":
    main()
