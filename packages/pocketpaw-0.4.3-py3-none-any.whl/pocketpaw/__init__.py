"""PocketPaw - The AI agent that runs on your laptop, not a datacenter."""

__version__ = "0.4.2"
