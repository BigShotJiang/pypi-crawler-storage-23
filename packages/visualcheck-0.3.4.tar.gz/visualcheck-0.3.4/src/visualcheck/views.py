from __future__ import annotations

from typing import Dict, List, Tuple


DESKTOP_PROFILES: Dict[str, Dict] = {
    "desktop_1440x900": {"viewport": {"width": 1440, "height": 900}, "device_scale_factor": 1},
    "desktop_1920x1080": {"viewport": {"width": 1920, "height": 1080}, "device_scale_factor": 1},
    # "macbook" preset: match common MacBook Air logical res
    "macbook_1440x900": {
        "viewport": {"width": 1440, "height": 900},
        "device_scale_factor": 2,
        "is_mobile": False,
        "has_touch": False,
        "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
    },
}


def resolve_view_configs(cfg: dict, playwright_devices: Dict[str, Dict]) -> List[Tuple[str, Dict]]:
    """Return list of (view_id, playwright_context_kwargs)."""
    views = cfg["views"]
    out: List[Tuple[str, Dict]] = []

    for profile in views.get("desktop_profiles", []):
        if profile not in DESKTOP_PROFILES:
            raise ValueError(
                f"Unknown desktop profile '{profile}'. Known: {sorted(DESKTOP_PROFILES.keys())}"
            )
        out.append((profile, dict(DESKTOP_PROFILES[profile])))

    aliases = {
        "iPhone 15 Pro Max": "iPhone 14 Pro Max",
        "iPhone 15 Pro": "iPhone 14 Pro",
        "iPhone 13 mini": "iPhone 13",
    }

    for dev in views.get("mobile_devices", []):
        resolved = dev
        if resolved not in playwright_devices and dev in aliases:
            resolved = aliases[dev]
        if resolved not in playwright_devices:
            known = sorted([d for d in playwright_devices.keys() if "iPhone" in d or "Pixel" in d])
            raise ValueError(
                f"Unknown Playwright device '{dev}'. Install newer Playwright or use an available device name. "
                f"Example known devices: {known[:15]}"
            )
        out.append((dev, dict(playwright_devices[resolved])))

    return out
