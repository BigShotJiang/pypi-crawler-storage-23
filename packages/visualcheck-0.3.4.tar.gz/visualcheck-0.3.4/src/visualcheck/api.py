from __future__ import annotations

import datetime as dt
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from PIL import Image, ImageDraw

from .baseline import ensure_runtime_baseline, resolve_baseline, run_root
from .diff_engine import diff_images
from .report import write_report
from .utils import ensure_dir, now_run_id, slug


def _mask_png(png_path: Path, rects: List[Tuple[float, float, float, float]]) -> None:
    if not rects:
        return
    img = Image.open(png_path).convert("RGBA")
    draw = ImageDraw.Draw(img)
    for x, y, w, h in rects:
        draw.rectangle([x, y, x + w, y + h], fill=(255, 0, 255, 255))
    img.save(png_path)


def _rects_from_playwright(page: Any, selectors: Sequence[str]) -> List[Tuple[float, float, float, float]]:
    rects: List[Tuple[float, float, float, float]] = []
    for sel in selectors:
        try:
            for el in page.query_selector_all(sel)[:10]:
                bb = el.bounding_box()
                if bb:
                    rects.append((bb["x"], bb["y"], bb["width"], bb["height"]))
        except Exception:
            continue
    return rects


def _rects_from_selenium(driver: Any, selectors: Sequence[str]) -> List[Tuple[float, float, float, float]]:
    rects: List[Tuple[float, float, float, float]] = []
    js = """
const sel = arguments[0];
return Array.from(document.querySelectorAll(sel)).slice(0, 10).map(el => {
  const r = el.getBoundingClientRect();
  return {x: r.x, y: r.y, width: r.width, height: r.height};
});
"""
    for sel in selectors:
        try:
            rows = driver.execute_script(js, sel) or []
            for r in rows:
                rects.append((float(r["x"]), float(r["y"]), float(r["width"]), float(r["height"])))
        except Exception:
            continue
    return rects


class VisualCheck:
    """Programmatic API for capture + baseline + diff + report.

    This class is intended for frameworks that already drive navigation (Playwright/Selenium)
    and only need visual baseline and reporting logic.
    """

    def __init__(
        self,
        project: str,
        suite: str,
        env: str,
        base_url: str,
        view_id: str,
        baseline_priority: Optional[Sequence[str]] = None,
        create_if_missing: bool = True,
        ignore_selectors: Optional[Sequence[str]] = None,
        *,
        max_pixel_diff_pct: float = 0.10,
        min_ssim: float = 0.995,
        resize_on_mismatch: bool = True,
        mismatch_level: str = "WARN",
        on_created: str = "INFO",
        never_overwrite: bool = True,
        figma_authoritative: bool = False,
        run_id: Optional[str] = None,
        root_dir: Optional[Path] = None,
    ) -> None:
        self.project = project
        self.suite = suite
        self.env = env
        self.base_url = base_url
        self.view_id = view_id
        self.run_id = run_id or now_run_id()
        self.ignore_selectors = list(ignore_selectors or [])

        base_root = (root_dir or Path.cwd()).resolve()
        self.cfg: Dict[str, Any] = {
            "project": project,
            "suite": suite,
            "envs": {env: base_url},
            "views": {"desktop_profiles": [], "mobile_devices": []},
            "pages": [],
            "baseline": {
                "priority": list(baseline_priority or ["figma", "runtime"]),
                "create_if_missing": bool(create_if_missing),
                "never_overwrite": bool(never_overwrite),
                "on_created": on_created,
                "figma_authoritative": bool(figma_authoritative),
            },
            "compare": {
                "resize_on_mismatch": bool(resize_on_mismatch),
                "mismatch_level": mismatch_level,
                "thresholds": {
                    "max_pixel_diff_pct": float(max_pixel_diff_pct),
                    "min_ssim": float(min_ssim),
                },
            },
            "ignore_regions": {"global": {"selectors": self.ignore_selectors}},
            "__path__": str(base_root / "visualcheck.api"),
            "__root__": str(base_root),
        }

        self._rr = run_root(self.cfg, self.run_id)
        self._current_dir = ensure_dir(self._rr / "current" / slug(self.view_id))
        self._diff_dir = ensure_dir(self._rr / "diff")
        self._report_dir = ensure_dir(self._rr / "report")
        self._results: List[dict] = []

        self.report_json: Optional[str] = None
        self.report_html: Optional[str] = None

    def check(
        self,
        snapshot_id: str,
        *,
        page: Any = None,
        selenium_driver: Any = None,
        full_page: bool = True,
        ignore_selectors: Optional[Sequence[str]] = None,
        ignore_rects: Optional[Sequence[Dict[str, float]]] = None,
    ) -> dict:
        if page is None and selenium_driver is None:
            raise ValueError("Provide either page=<Playwright page> or selenium_driver=<WebDriver>.")
        if page is not None and selenium_driver is not None:
            raise ValueError("Provide only one input: page or selenium_driver.")

        current_png = self._current_dir / f"{slug(snapshot_id)}.png"
        if page is not None:
            page.screenshot(path=str(current_png), full_page=bool(full_page))
            page_url = page.url
            dynamic_rects = _rects_from_playwright(page, list(ignore_selectors or self.ignore_selectors))
        else:
            selenium_driver.save_screenshot(str(current_png))
            page_url = selenium_driver.current_url
            dynamic_rects = _rects_from_selenium(selenium_driver, list(ignore_selectors or self.ignore_selectors))

        for r in ignore_rects or []:
            dynamic_rects.append((float(r["x"]), float(r["y"]), float(r["width"]), float(r["height"])))
        _mask_png(current_png, dynamic_rects)

        thresholds = self.cfg["compare"]["thresholds"]
        resize_on_mismatch = bool(self.cfg["compare"]["resize_on_mismatch"])
        mismatch_level = self.cfg["compare"]["mismatch_level"]

        baseline_png, baseline_kind = resolve_baseline(self.cfg, self.view_id, snapshot_id)
        created = False
        if baseline_png is None:
            baseline_png, created_kind = ensure_runtime_baseline(self.cfg, self.view_id, snapshot_id, current_png)
            if created_kind == "runtime_created":
                created = True
                baseline_kind = "runtime_created"

        if baseline_png is None:
            result = {
                "snapshot_id": snapshot_id,
                "view_id": self.view_id,
                "status": "NO_BASELINE",
                "baseline_kind": "none",
                "baseline": None,
                "current": str(current_png),
                "diff": None,
                "pixel_diff_pct": None,
                "ssim": None,
                "warnings": ["BASELINE_MISSING"],
                "url": page_url,
            }
            self._results.append(result)
            return result

        diff_png = self._diff_dir / slug(self.view_id) / f"{slug(snapshot_id)}.png"
        metrics = diff_images(
            baseline_png=baseline_png,
            current_png=current_png,
            diff_png=diff_png,
            resize_on_mismatch=resize_on_mismatch,
        )

        mismatch = (metrics["pixel_diff_pct"] > thresholds["max_pixel_diff_pct"]) or (
            metrics["ssim"] < thresholds["min_ssim"]
        )
        status = "PASS"
        if mismatch:
            status = mismatch_level

        if created:
            created_level = self.cfg["baseline"].get("on_created", "INFO")
            metrics["warnings"].append("BASELINE_CREATED")
            if created_level == "WARN" and status == "PASS":
                status = "WARN"
            if created_level == "FAIL":
                status = "FAIL"

        result = {
            "snapshot_id": snapshot_id,
            "view_id": self.view_id,
            "status": status,
            "baseline_kind": baseline_kind,
            "baseline": str(baseline_png),
            "current": str(current_png),
            "diff": str(diff_png),
            "url": page_url,
            **metrics,
        }
        self._results.append(result)
        return result

    def finalize(self) -> dict:
        overall = "PASS"
        for r in self._results:
            if r["status"] in {"FAIL", "NO_BASELINE"}:
                overall = "FAIL"
                break
            if r["status"] == "WARN" and overall == "PASS":
                overall = "WARN"

        for r in self._results:
            cur_src = Path(r["current"])
            cur_rel = Path("assets") / "current" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
            ensure_dir((self._report_dir / cur_rel).parent)
            shutil.copy2(cur_src, self._report_dir / cur_rel)
            r["current_rel"] = cur_rel.as_posix()

            if r.get("baseline"):
                base_src = Path(r["baseline"])
                base_rel = Path("assets") / "baseline" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
                ensure_dir((self._report_dir / base_rel).parent)
                shutil.copy2(base_src, self._report_dir / base_rel)
                r["baseline_rel"] = base_rel.as_posix()
            else:
                r["baseline_rel"] = None

            if r.get("diff"):
                diff_src = Path(r["diff"])
                diff_rel = Path("assets") / "diff" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
                ensure_dir((self._report_dir / diff_rel).parent)
                shutil.copy2(diff_src, self._report_dir / diff_rel)
                r["diff_rel"] = diff_rel.as_posix()
            else:
                r["diff_rel"] = None

        report = {
            "project": self.cfg["project"],
            "suite": self.cfg["suite"],
            "env": self.env,
            "run_id": self.run_id,
            "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
            "status": overall,
            "config": self.cfg.get("__path__"),
            "thresholds": self.cfg["compare"]["thresholds"],
            "results": self._results,
        }
        paths = write_report(self._report_dir, report)
        report.update(paths)
        self.report_json = paths["report_json"]
        self.report_html = paths["report_html"]
        return report
