from __future__ import annotations

import datetime as _dt
import re
from pathlib import Path
from typing import Iterable


def now_run_id() -> str:
    return _dt.datetime.now().strftime("%Y%m%d_%H%M%S")


_slug_re = re.compile(r"[^a-zA-Z0-9._-]+")


def slug(s: str) -> str:
    s = s.strip()
    s = _slug_re.sub("_", s)
    return s.strip("_")


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def iter_pngs(root: Path) -> Iterable[Path]:
    for p in root.rglob("*.png"):
        if p.is_file():
            yield p
