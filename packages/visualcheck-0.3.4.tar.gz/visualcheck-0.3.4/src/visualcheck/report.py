from __future__ import annotations

import json
from pathlib import Path
from xml.etree import ElementTree as ET

from jinja2 import Environment, FileSystemLoader, select_autoescape

from .utils import ensure_dir


def _env() -> Environment:
    tpl_dir = Path(__file__).parent / "templates"
    return Environment(
        loader=FileSystemLoader(str(tpl_dir)),
        autoescape=select_autoescape(["html"]),
    )


def write_junit(out_dir: Path, report: dict) -> str:
    results = report.get("results") or []
    failures = sum(1 for r in results if r.get("status") in {"FAIL", "NO_BASELINE"})
    warnings = sum(1 for r in results if r.get("status") in {"WARN", "QUARANTINED"})

    suite = ET.Element(
        "testsuite",
        name=f"{report.get('project', 'visualcheck')}.{report.get('suite', 'suite')}",
        tests=str(len(results)),
        failures=str(failures),
        errors="0",
    )
    if warnings:
        suite.set("skipped", str(warnings))

    for r in results:
        case = ET.SubElement(
            suite,
            "testcase",
            classname=f"{report.get('project', 'visualcheck')}.{r.get('view_id', 'view')}",
            name=str(r.get("snapshot_id", "snapshot")),
        )
        if r.get("status") in {"FAIL", "NO_BASELINE"}:
            msg = f"status={r.get('status')} pixel_diff_pct={r.get('pixel_diff_pct')} ssim={r.get('ssim')}"
            fail = ET.SubElement(case, "failure", message=msg)
            fail.text = f"baseline={r.get('baseline')} current={r.get('current')} diff={r.get('diff')}"
        elif r.get("status") in {"WARN", "QUARANTINED"}:
            ET.SubElement(case, "skipped", message="warning-threshold-breach")

    xml_path = out_dir / "report.junit.xml"
    ET.ElementTree(suite).write(xml_path, encoding="utf-8", xml_declaration=True)
    return str(xml_path)


def write_report(out_dir: Path, report: dict) -> dict:
    ensure_dir(out_dir)
    (out_dir / "report.json").write_text(json.dumps(report, indent=2))

    env = _env()
    tpl = env.get_template("report.html")

    html = tpl.render(**report)
    html_path = out_dir / "report.html"
    html_path.write_text(html, encoding="utf-8")
    junit_path = write_junit(out_dir, report)
    return {
        "report_json": str(out_dir / "report.json"),
        "report_html": str(html_path),
        "report_junit_xml": junit_path,
    }
