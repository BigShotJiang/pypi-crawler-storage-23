"""ArtBox app to be called from `python -m`."""

from artbox.cli import app

if __name__ == "__main__":
    app()
