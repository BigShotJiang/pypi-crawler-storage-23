"""Minimal setup.py for backwards compatibility.

All configuration is in pyproject.toml.
This file exists only for editable installs with older pip versions.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
