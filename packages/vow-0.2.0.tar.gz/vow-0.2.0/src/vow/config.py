
"""
vow makes self-signed certs minty fresh.

Copyright (C) 2026  Brian Farrell

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

Contact: brian.farrell@me.com
"""


import os
from pathlib import Path
from textwrap import dedent
import tomllib
from typing import override

from loguru import logger

from vow.exceptions import ConfigError


class Config(object):
    config_file_name: str = 'vow.toml'

    @classmethod
    def get_config_file(cls, config_file_path: str) -> Path:
        """
        Order of precedence:
            1. command-line argument
            2. environment variable
            3. cwd
        """
        if config_file_path:
            config_file = Path(config_file_path)
        elif not (config_file := os.getenv("VOW_CONFIG_FILE")):
            config_file = Path(Path.cwd(), Config.config_file_name)
        else:
            config_file = Path(config_file)
        logger.info(f"Using config file: {config_file}")

        if not config_file.exists():
            raise ConfigError(f"No config file found at {config_file}")

        return config_file

    @classmethod
    def get_config_data(cls, config_file_path: str) -> dict[str, dict[str, str | int | list[str]]]:

        config_file = cls.get_config_file(config_file_path)

        with open(config_file, 'rb') as config_file:
            config_data = tomllib.load(config_file)

        return config_data


    def __init__(
        self,
        project: dict[str, str],
        paths: dict[str, str],
        privkey: dict[str, str | int | None],
        cert: dict[str, str | int | list[str]]
    ):
        self.project: ProjectConfig = ProjectConfig(**project)
        self.privkey: PrivkeyConfig = PrivkeyConfig(**privkey)  # pyright: ignore[reportArgumentType]
        self.cert: CertConfig = CertConfig(**cert)  # pyright: ignore[reportArgumentType]

        # PathsConfig must be created last, as it requires the CertConfig instance
        self.paths: PathsConfig = PathsConfig(self.cert, **paths)

    @override
    def __str__(self) -> str:
        cs = f"""
            {str(self.project)}
            {str(self.paths)}
            {str(self.privkey)}
            {str(self.cert)}
        """

        return dedent(cs)


class ProjectConfig(object):

    def __init__(self, name: str):
        self.name: str = name

    @override
    def __str__(self) -> str:
        cs = f"""
            Project Config
            --------------
            name: {self.name}
        """

        return dedent(cs)


class PrivkeyConfig(object):

    def __init__(self, algo: str, public_exponent: int | None = None, key_size: int | None = None):
        self.algo: str = algo.lower()
        self.public_exponent: int | None = public_exponent
        self.key_size: int | None = key_size

        if self.algo == 'rsa' and (self.public_exponent is None or self.key_size is None):
            raise ConfigError("If key algorithm is 'rsa', you must also specify public_exponent and key_size")


    @override
    def __str__(self) -> str:
        cs = f"""
            Privkey Config
            --------------
            algo: {self.algo}
            public_exponent: {self.public_exponent}
            key_size: {self.key_size}
        """

        return dedent(cs)


class CertConfig(object):

    def __init__(
        self,
        country_name: str,
        state_or_province_name: str,
        locality_name: str,
        organization_name: str,
        common_name: str,
        days_valid: int,
        alt_names: list[str],
    ):
        self.country_name: str = country_name
        self.state_or_province_name: str = state_or_province_name
        self.locality_name: str = locality_name
        self.organization_name: str = organization_name
        self.common_name: str = common_name
        self.days_valid: int = days_valid
        self.alt_names: list[str] = alt_names


    @override
    def __str__(self) -> str:
        cs = f"""
            Cert Config
            -----------
            country_name: {self.country_name}
            state_or_province_name: {self.state_or_province_name}
            locality_name: {self.locality_name}
            organization_name: {self.organization_name}
            common_name: {self.common_name}
            days_valid: {self.days_valid}
            alt_names: {self.alt_names}
        """

        return dedent(cs)


class PathsConfig(object):

    def __init__(self, cert_config: CertConfig, base_path: str):
        self.cert_config: CertConfig = cert_config
        self.base_path: Path = Path(base_path).resolve()
        self.vow_dir: Path = Path(base_path, 'vow')
        self.conf_dir: Path = Path(self.vow_dir, 'conf')

        self.archive_dir: Path = Path(self.vow_dir, 'archive')
        self.archive_dir_ca: Path = Path(self.archive_dir, 'ca')
        self.archive_dir_inter: Path = Path(self.archive_dir, 'inter')
        self.archive_dir_domain: Path = Path(self.archive_dir, self.cert_config.common_name)

        self.live_dir: Path = Path(self.vow_dir, 'live')
        self.live_dir_ca: Path = Path(self.live_dir, 'ca')
        self.live_dir_inter: Path = Path(self.live_dir, 'inter')
        self.live_dir_domain: Path = Path(self.live_dir, self.cert_config.common_name)


    @override
    def __str__(self) -> str:
        cs = f"""
            Paths Config
            ------------
            base_path: {self.base_path}
            vow_dir: {self.vow_dir}
            conf_dir: {self.conf_dir}

            archive_dir: {self.archive_dir}
            archive_dir_ca: {self.archive_dir_ca}
            archive_dir_inter: {self.archive_dir_inter}
            archive_dir_domain: {self.archive_dir_domain}

            live_dir: {self.live_dir}
            live_dir_ca: {self.live_dir_ca}
            live_dir_inter: {self.live_dir_inter}
            live_dir_domain: {self.live_dir_domain}
        """

        return dedent(cs)
