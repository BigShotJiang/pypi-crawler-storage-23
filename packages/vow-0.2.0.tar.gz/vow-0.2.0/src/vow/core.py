
"""
vow makes self-signed certs minty fresh.

Copyright (C) 2026  Brian Farrell

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

Contact: brian.farrell@me.com
"""


from datetime import date, datetime, timedelta, UTC
import os
from pathlib import Path

from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from loguru import logger

from vow.config import Config


type PrivateKey = rsa.RSAPrivateKey | Ed25519PrivateKey

# Date/Time
START = datetime.now(UTC)
START_DATE = date(START.year, START.month, START.day)


class CertManager(object):
    """docstring for CertManager"""

    def __init__(self, config: Config):
        self._config: Config = config
        self._user: str = os.getlogin()
        self._uid: int = os.getuid()
        self._key: PrivateKey  # value set in _gen_key()

        # logger.warning(f"User is: {type(self._user)}")
        # logger.warning(f"UID is: {type(self._uid)}")

    @property
    def config(self):
        return self._config

    def show_config(self):
        print(self.config)

    def build(self):
        logger.info("GOIN' TO MAKE A CERT...")
        self._gen_key()
        self._save_private_key()
        self._sign_cert()

    def _gen_key(self):
        # Generate our key
        if self.config.privkey.algo == 'ed25519':
            self._key = Ed25519PrivateKey.generate()
        else:
            self._key = rsa.generate_private_key(
                public_exponent=self.config.privkey.public_exponent,  # pyright: ignore[reportArgumentType]
                key_size=self.config.privkey.key_size  # pyright: ignore[reportArgumentType]
            )

        logger.info(f"GENERATED KEY: {self.config.privkey.algo}")

    def _save_private_key(self):
        private_key_path = Path(self.config.paths.archive_dir_domain, START_DATE.isoformat(), 'privkey.pem')

        with open(private_key_path.resolve(), "wb") as f:
            _ = f.write(
                    self._key.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.PKCS8,
                        encryption_algorithm=serialization.NoEncryption(),
                    )
                )
            os.fchmod(f.fileno(), 0o440)

        logger.info(f"SAVED KEY: {private_key_path.resolve()}")

    def _sign_cert(self):
        cert_path = Path(self.config.paths.archive_dir_domain, START_DATE.isoformat(), 'cert.pem')

        # Various details about who we are. For a self-signed certificate the
        # subject and issuer are always the same.
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, self.config.cert.country_name),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, self.config.cert.state_or_province_name),
            x509.NameAttribute(NameOID.LOCALITY_NAME, self.config.cert.locality_name),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, self.config.cert.organization_name),
            x509.NameAttribute(NameOID.COMMON_NAME, self.config.cert.common_name),
        ])

        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            self._key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            START
        ).not_valid_after(
            START + timedelta(days=self.config.cert.days_valid)
        ).add_extension(
            x509.SubjectAlternativeName([x509.DNSName(f"{name}") for name in self.config.cert.alt_names]),
            critical=False,
        ).sign(self._key, hashes.SHA256() if self.config.privkey.algo == 'rsa' else None)

        # Write our certificate out to disk.
        with open(cert_path.resolve(), "wb") as f:
            _ = f.write(cert.public_bytes(serialization.Encoding.PEM))
            os.fchmod(f.fileno(), 0o444)

        logger.info(f"GENERATED CERT: {cert_path.resolve()}")
