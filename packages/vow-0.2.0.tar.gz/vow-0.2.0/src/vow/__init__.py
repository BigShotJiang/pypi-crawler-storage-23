
"""
vow makes self-signed certs minty fresh.

Copyright (C) 2026  Brian Farrell

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

Contact: brian.farrell@me.com
"""

import argparse
from dataclasses import dataclass, fields as vow_fields
import sys
from typing import Callable, Self

from loguru import logger

from vow.config import Config
from vow.core import *
from vow.exceptions import VowError, ExitCode


@dataclass
class VowArgs(argparse.Namespace):
    """
    We use this class to allow us to type hint command line args
    See: https://dnmtechs.com/python-3-typehints-for-argparse-namespace-objects/
    """
    func: Callable[[CertManager, Self], ExitCode] | None = None
    config_file: str = ''
    new_object: str = ''
    show_object: str = ''

    def __iter__(self):
        for field in vow_fields(self):
            yield field.name if getattr(self, field.name) else ''


def new(manager: CertManager, args: VowArgs):
    if args.new_object == 'cert':
        manager.build()
    return ExitCode.EX_SUCCESS


def revoke(manager: CertManager, args: VowArgs):
    return ExitCode.EX_SUCCESS


def show(manager: CertManager, args: VowArgs):
    if args.show_object == 'config':
        manager.show_config()
    return ExitCode.EX_SUCCESS


parser = argparse.ArgumentParser(
    prog='vow',
    argument_default=argparse.SUPPRESS,
    description='vow makes self-signed certs minty fresh.',
    conflict_handler='resolve',
    formatter_class=argparse.RawTextHelpFormatter,
    epilog='\n \n',
)

_ = parser.add_argument(
    '-c', '--config-file',
    action='store',
    default='',
    dest='config_file',
    help='path to config file',
)


# Add subparser below for each vow command
subparsers = parser.add_subparsers(
    title='vow commands',
)

############### New ################

parser_new = subparsers.add_parser(
    'new',
    help='create a new certificate or configuration file'
)

_ = parser_new.add_argument(
    'new_object',
    action='store',
    choices=['cert', 'config'],
    help='the type of object to create'
)

parser_new.set_defaults(func=new)


############### Revoke #############

parser_revoke = subparsers.add_parser(
    'revoke',
    help='revoke a certificate'
)

parser_revoke.set_defaults(func=revoke)


############### Show ###############

parser_config = subparsers.add_parser(
    'show',
    help='display the designated object'
)

_ = parser_config.add_argument(
    'show_object',
    action='store',
    choices=['cert', 'config'],
    help='show the certificate or the configuration from the config file'
)

parser_config.set_defaults(func=show)


def main():
    args: VowArgs = parser.parse_args(namespace=VowArgs())
    logger.info(f"ARGS: {args}")

    if args.func:
        cmd = ' '.join(arg for arg in sys.argv)
        logger.info(f"VOW COMMAND: {cmd}")

        try:
            config_data = Config.get_config_data(args.config_file)
            config = Config(**config_data)  # pyright: ignore[reportArgumentType]
        except VowError as e:
            logger.error(e)
            sys.exit(e.exit_code)

        try:
            manager = CertManager(config)
            result = args.func(manager, args)
        except VowError as e:
            logger.error(e)
            sys.exit(e.exit_code)
        else:
            return result
    else:
        parser.print_help()
        sys.exit(ExitCode.EX_USAGE)
