"""Utility functions for parsing and text processing."""
