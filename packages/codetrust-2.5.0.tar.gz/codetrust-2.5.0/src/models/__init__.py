"""Pydantic models for requests, responses, and enums."""
