"""Async database service for users, API keys, scan logs, usage, and telemetry."""

import datetime
import hashlib
import secrets

import structlog
from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from src.models.database import (
    ApiKeyRecord,
    Base,
    MetricsCounter,
    ScanLog,
    TelemetryEvent,
    TelemetryEventRaw,
    UsageDay,
    User,
)

logger = structlog.get_logger()

API_KEY_PREFIX = "ct_live_"
API_KEY_BYTES = 32


def _hash_key(raw_key: str) -> str:
    """SHA-256 hash an API key for storage."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _generate_api_key() -> str:
    """Generate a new random API key with prefix."""
    token = secrets.token_hex(API_KEY_BYTES)
    return f"{API_KEY_PREFIX}{token}"


POOL_TIMEOUT_SECS: int = 30


def _build_db_engine(database_url: str, echo: bool) -> AsyncEngine:
    """Create an async engine with pool timeout for production databases."""
    if "sqlite" in database_url:
        # SQLite/StaticPool: pool_timeout not supported
        return create_async_engine(
            database_url, echo=echo, pool_pre_ping=True,
        )
    return create_async_engine(
        database_url, echo=echo, pool_pre_ping=True,
        pool_timeout=POOL_TIMEOUT_SECS,
    )


class DatabaseService:
    """Async CRUD operations for CodeTrust database."""

    def __init__(self, database_url: str, echo: bool = False) -> None:
        """Initialize with database URL. Includes pool_timeout for non-SQLite."""
        self._engine = _build_db_engine(database_url, echo)
        self._session_factory: async_sessionmaker[AsyncSession] = async_sessionmaker(
            self._engine, expire_on_commit=False,
        )

    async def create_tables(self) -> None:
        """Create all tables if they don't exist."""
        async with self._engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("database_tables_created")

    async def close(self) -> None:
        """Dispose of the engine connection pool."""
        await self._engine.dispose()
        logger.info("database_closed")

    # --- User operations ---

    async def create_user(
        self,
        github_id: str,
        email: str = "",
        name: str = "",
        avatar_url: str = "",
    ) -> User:
        """Create a new user from GitHub OAuth data."""
        async with self._session_factory() as session:
            user = User(
                github_id=github_id,
                email=email,
                name=name,
                avatar_url=avatar_url,
            )
            session.add(user)
            await session.commit()
            await session.refresh(user)
            logger.info("user_created", user_id=user.id, github_id=github_id)
            return user

    async def get_user(self, user_id: str) -> User | None:
        """Get a user by ID."""
        async with self._session_factory() as session:
            return await session.get(User, user_id)

    async def get_user_by_github_id(self, github_id: str) -> User | None:
        """Get a user by GitHub ID."""
        async with self._session_factory() as session:
            stmt = select(User).where(User.github_id == github_id)
            result = await session.execute(stmt)
            return result.scalar_one_or_none()

    async def get_user_by_stripe_customer_id(
        self, stripe_customer_id: str,
    ) -> User | None:
        """Get a user by their Stripe customer ID."""
        async with self._session_factory() as session:
            stmt = select(User).where(
                User.stripe_customer_id == stripe_customer_id,
            )
            result = await session.execute(stmt)
            return result.scalar_one_or_none()

    async def get_or_create_user(
        self,
        github_id: str,
        email: str = "",
        name: str = "",
        avatar_url: str = "",
    ) -> User:
        """Get existing user or create new one from GitHub OAuth data."""
        existing = await self.get_user_by_github_id(github_id)
        if existing is not None:
            return existing
        return await self.create_user(github_id, email, name, avatar_url)

    async def update_user_plan(
        self,
        user_id: str,
        plan: str,
        stripe_customer_id: str = "",
        stripe_subscription_id: str = "",
    ) -> User | None:
        """Update a user's plan and Stripe IDs."""
        async with self._session_factory() as session:
            user = await session.get(User, user_id)
            if user is None:
                return None
            user.plan = plan
            if stripe_customer_id:
                user.stripe_customer_id = stripe_customer_id
            if stripe_subscription_id:
                user.stripe_subscription_id = stripe_subscription_id
            await session.commit()
            await session.refresh(user)
            logger.info("user_plan_updated", user_id=user_id, plan=plan)
            return user

    # --- API Key operations ---

    async def create_api_key(
        self, user_id: str, name: str = "Default",
    ) -> tuple[str, ApiKeyRecord]:
        """Create a new API key. Returns (raw_key, record)."""
        raw_key = _generate_api_key()
        key_hash = _hash_key(raw_key)
        prefix = raw_key[:16]

        async with self._session_factory() as session:
            record = ApiKeyRecord(
                user_id=user_id,
                key_hash=key_hash,
                prefix=prefix,
                name=name,
            )
            session.add(record)
            await session.commit()
            await session.refresh(record)
            logger.info("api_key_created", user_id=user_id, key_id=record.id)
            return raw_key, record

    async def list_api_keys(self, user_id: str) -> list[ApiKeyRecord]:
        """List all API keys for a user (active and revoked)."""
        async with self._session_factory() as session:
            stmt = (
                select(ApiKeyRecord)
                .where(ApiKeyRecord.user_id == user_id)
                .order_by(ApiKeyRecord.created_at.desc())
            )
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def revoke_api_key(
        self, key_id: str, user_id: str,
    ) -> bool:
        """Revoke an API key. Returns True if found and revoked."""
        async with self._session_factory() as session:
            stmt = select(ApiKeyRecord).where(
                ApiKeyRecord.id == key_id,
                ApiKeyRecord.user_id == user_id,
            )
            result = await session.execute(stmt)
            record = result.scalar_one_or_none()
            if record is None:
                return False
            record.is_revoked = True
            record.revoked_at = datetime.datetime.now(datetime.UTC)
            await session.commit()
            logger.info("api_key_revoked", key_id=key_id, user_id=user_id)
            return True

    async def verify_api_key_hash(
        self, raw_key: str,
    ) -> ApiKeyRecord | None:
        """Look up an API key by its hash. Returns None if not found or revoked."""
        key_hash = _hash_key(raw_key)
        async with self._session_factory() as session:
            stmt = select(ApiKeyRecord).where(
                ApiKeyRecord.key_hash == key_hash,
                ApiKeyRecord.is_revoked.is_(False),
            )
            result = await session.execute(stmt)
            record = result.scalar_one_or_none()
            if record is not None:
                record.last_used_at = datetime.datetime.now(datetime.UTC)
                await session.commit()
            return record

    # --- Scan Log operations ---

    async def log_scan(
        self,
        user_id: str,
        scan_type: str,
        verdict: str,
        findings_count: int,
        latency_ms: int,
        language: str = "",
        filename: str = "",
        input_size: int = 0,
        api_key_id: str | None = None,
    ) -> ScanLog:
        """Record a scan execution."""
        async with self._session_factory() as session:
            log = ScanLog(
                user_id=user_id,
                api_key_id=api_key_id,
                scan_type=scan_type,
                verdict=verdict,
                findings_count=findings_count,
                latency_ms=latency_ms,
                language=language,
                filename=filename,
                input_size=input_size,
            )
            session.add(log)
            await session.commit()
            await session.refresh(log)
            return log

    async def get_scan_history(
        self,
        user_id: str,
        page: int = 1,
        per_page: int = 20,
        scan_type: str | None = None,
    ) -> list[ScanLog]:
        """Get paginated scan history for a user."""
        async with self._session_factory() as session:
            stmt = (
                select(ScanLog)
                .where(ScanLog.user_id == user_id)
                .order_by(ScanLog.created_at.desc())
            )
            if scan_type is not None:
                stmt = stmt.where(ScanLog.scan_type == scan_type)
            stmt = stmt.offset((page - 1) * per_page).limit(per_page)
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def count_scans(
        self, user_id: str, scan_type: str | None = None,
    ) -> int:
        """Count total scans for a user."""
        async with self._session_factory() as session:
            stmt = select(func.count()).select_from(ScanLog).where(
                ScanLog.user_id == user_id,
            )
            if scan_type is not None:
                stmt = stmt.where(ScanLog.scan_type == scan_type)
            result = await session.execute(stmt)
            return result.scalar_one()

    # --- Usage tracking ---

    async def increment_daily_usage(
        self,
        user_id: str,
        findings_count: int = 0,
        latency_ms: int = 0,
    ) -> UsageDay:
        """Increment today's usage counter for a user."""
        today = datetime.date.today()
        async with self._session_factory() as session:
            stmt = select(UsageDay).where(
                UsageDay.user_id == user_id,
                UsageDay.date == today,
            )
            result = await session.execute(stmt)
            usage = result.scalar_one_or_none()

            if usage is None:
                usage = UsageDay(
                    user_id=user_id,
                    date=today,
                    scan_count=1,
                    findings_total=findings_count,
                    avg_latency_ms=float(latency_ms),
                )
                session.add(usage)
            else:
                old_total = usage.avg_latency_ms * usage.scan_count
                usage.scan_count += 1
                usage.findings_total += findings_count
                usage.avg_latency_ms = (
                    (old_total + latency_ms) / usage.scan_count
                )

            await session.commit()
            await session.refresh(usage)
            return usage

    async def get_daily_usage(
        self, user_id: str, date: datetime.date | None = None,
    ) -> int:
        """Get scan count for a specific day (default: today)."""
        target = date or datetime.date.today()
        async with self._session_factory() as session:
            stmt = select(UsageDay).where(
                UsageDay.user_id == user_id,
                UsageDay.date == target,
            )
            result = await session.execute(stmt)
            usage = result.scalar_one_or_none()
            return usage.scan_count if usage is not None else 0

    async def get_usage_stats(
        self, user_id: str, days: int = 30,
    ) -> list[UsageDay]:
        """Get usage stats for the last N days."""
        since = datetime.date.today() - datetime.timedelta(days=days)
        async with self._session_factory() as session:
            stmt = (
                select(UsageDay)
                .where(
                    UsageDay.user_id == user_id,
                    UsageDay.date >= since,
                )
                .order_by(UsageDay.date.desc())
            )
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def get_public_stats(self) -> dict[str, int]:
        """Get aggregate public stats across all users (no auth required)."""
        async with self._session_factory() as session:
            # Total scans
            total_scans_stmt = select(func.count()).select_from(ScanLog)
            total_scans = (await session.execute(total_scans_stmt)).scalar_one()

            # Hallucinated packages prevented (imports scans with BLOCK verdict)
            hallucinated_stmt = (
                select(func.count())
                .select_from(ScanLog)
                .where(ScanLog.scan_type == "imports", ScanLog.verdict == "BLOCK")
            )
            hallucinated = (await session.execute(hallucinated_stmt)).scalar_one()

            # Destructive commands blocked (gateway blocks from audit)
            # Count all scans with BLOCK verdict across gateway-related types
            blocked_stmt = (
                select(func.count())
                .select_from(ScanLog)
                .where(
                    ScanLog.verdict == "BLOCK",
                    ScanLog.scan_type.notin_(["imports", "dockerfile"]),
                )
            )
            blocked = (await session.execute(blocked_stmt)).scalar_one()

            return {
                "total_scans": total_scans or 0,
                "hallucinated_packages_prevented": hallucinated or 0,
                "destructive_commands_blocked": blocked or 0,
            }

    async def get_redis_warmup_counters(self) -> dict[str, int]:
        """Return aggregate counters needed to warm up Redis after a restart.

        Queries the persisted telemetry rows so Redis counters are restored
        to their correct values rather than starting from zero.
        """
        today_utc = datetime.datetime.combine(
            datetime.date.today(), datetime.time.min, tzinfo=datetime.UTC,
        )
        async with self._session_factory() as session:
            total_stmt = (
                select(func.count())
                .select_from(TelemetryEventRaw)
                .where(TelemetryEventRaw.event_type == "scan_completed")
            )
            total_scans: int = (await session.execute(total_stmt)).scalar_one() or 0

            today_stmt = (
                select(func.count())
                .select_from(TelemetryEventRaw)
                .where(
                    TelemetryEventRaw.event_type == "scan_completed",
                    TelemetryEventRaw.created_at >= today_utc,
                )
            )
            scans_today: int = (await session.execute(today_stmt)).scalar_one() or 0

            sources = ("cli", "vscode", "mcp", "github_action", "cloud_api")
            by_source: dict[str, int] = {}
            for source in sources:
                src_stmt = (
                    select(func.count())
                    .select_from(TelemetryEventRaw)
                    .where(
                        TelemetryEventRaw.event_type == "scan_completed",
                        TelemetryEventRaw.source == source,
                    )
                )
                by_source[source] = (await session.execute(src_stmt)).scalar_one() or 0

        counters: dict[str, int] = {
            "ct:total_scans": total_scans,
            "ct:scans_today": scans_today,
        }
        counters.update({f"ct:scans_by_source:{src}": cnt for src, cnt in by_source.items()})
        return counters

    # --- Anonymous telemetry (public aggregates) ---

    async def insert_telemetry_event(
        self,
        *,
        instance_id: str,
        client: str,
        client_version: str,
        schema_version: int,
        event_type: str,
        scan_type: str = "",
        verdict: str = "",
        language: str = "",
        delta_scans: int = 0,
        delta_findings_total: int = 0,
        delta_hallucinated_packages_prevented: int = 0,
        delta_destructive_commands_blocked: int = 0,
    ) -> None:
        """Insert a single anonymous telemetry event.

        Must never store code, filenames, repo URLs, or user identifiers.
        """

        async with self._session_factory() as session:
            event = TelemetryEvent(
                instance_id=instance_id,
                client=client,
                client_version=client_version,
                schema_version=schema_version,
                event_type=event_type,
                scan_type=scan_type,
                verdict=verdict,
                language=language,
                delta_scans=delta_scans,
                delta_findings_total=delta_findings_total,
                delta_hallucinated_packages_prevented=delta_hallucinated_packages_prevented,
                delta_destructive_commands_blocked=delta_destructive_commands_blocked,
            )
            session.add(event)
            await session.commit()

    @staticmethod
    async def _sum_telemetry_column(
        session: AsyncSession,
        column: object,
    ) -> int:
        """Execute a coalesce(sum(column), 0) query."""
        result = (
            await session.execute(
                select(func.coalesce(func.sum(column), 0))
            )
        ).scalar_one() or 0
        return int(result)

    @staticmethod
    async def _query_telemetry_aggregates(
        session: AsyncSession,
    ) -> dict[str, int]:
        """Execute telemetry aggregate queries within a session."""
        events_total = (
            await session.execute(select(func.count()).select_from(TelemetryEvent))
        ).scalar_one() or 0

        unique_instances = (
            await session.execute(
                select(func.count(func.distinct(TelemetryEvent.instance_id)))
            )
        ).scalar_one() or 0

        _sum = DatabaseService._sum_telemetry_column
        scans = await _sum(session, TelemetryEvent.delta_scans)
        findings = await _sum(session, TelemetryEvent.delta_findings_total)
        hallucinated = await _sum(session, TelemetryEvent.delta_hallucinated_packages_prevented)
        blocked = await _sum(session, TelemetryEvent.delta_destructive_commands_blocked)

        return {
            "telemetry_events_total": int(events_total),
            "telemetry_unique_instances": int(unique_instances),
            "telemetry_scans_total": scans,
            "telemetry_findings_total": findings,
            "telemetry_hallucinated_packages_prevented": hallucinated,
            "telemetry_destructive_commands_blocked": blocked,
        }

    async def get_public_telemetry_stats(self) -> dict[str, int]:
        """Return anonymous telemetry aggregates for public display.

        If the telemetry table doesn't exist (older deployments), callers should
        catch database errors and fall back to zeros.
        """
        async with self._session_factory() as session:
            return await self._query_telemetry_aggregates(session)

    async def insert_telemetry_raw_batch(self, events: list[dict[str, object]]) -> None:
        """Bulk insert raw telemetry events.

        Each dict must include: event_type, source, installation_id, version, payload.
        """

        if not events:
            return

        async with self._session_factory() as session:
            rows: list[TelemetryEventRaw] = []
            for e in events:
                event_type = str(e.get("event_type", ""))
                source = str(e.get("source", ""))
                installation_id = str(e.get("installation_id", "") or "")
                version = str(e.get("version", "") or "")
                payload = e.get("payload")
                payload_dict: dict[str, object] = payload if isinstance(payload, dict) else {}
                rows.append(
                    TelemetryEventRaw(
                        event_type=event_type,
                        source=source,
                        installation_id=installation_id,
                        version=version,
                        payload=payload_dict,
                    )
                )
            session.add_all(rows)
            await session.commit()

    async def upsert_metrics_counters(self, counters: dict[str, int]) -> None:
        """Upsert metric counters for durability.

        Uses PostgreSQL ON CONFLICT when available; falls back to per-row merge on other DBs.
        """

        if not counters:
            return

        async with self._session_factory() as session:
            try:
                stmt = pg_insert(MetricsCounter).values(
                    [
                        {"metric_name": name, "metric_value": int(value)}
                        for name, value in counters.items()
                    ]
                )
                stmt = stmt.on_conflict_do_update(
                    index_elements=[MetricsCounter.metric_name],
                    set_={
                        "metric_value": stmt.excluded.metric_value,
                        "updated_at": func.now(),
                    },
                )
                await session.execute(stmt)
                await session.commit()
            except Exception:
                # SQLite / non-Postgres fallback
                for name, value in counters.items():
                    existing = await session.get(MetricsCounter, name)
                    if existing is None:
                        session.add(MetricsCounter(metric_name=name, metric_value=int(value)))
                    else:
                        existing.metric_value = int(value)
                await session.commit()
