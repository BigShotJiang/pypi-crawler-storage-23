"""Anti-pattern rules and enterprise structure checks."""
