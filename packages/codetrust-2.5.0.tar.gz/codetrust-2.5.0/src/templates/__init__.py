# Templates package — product files installed by `codetrust init`.
