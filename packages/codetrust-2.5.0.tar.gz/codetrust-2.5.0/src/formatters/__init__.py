"""Output formatters for CodeTrust scan results."""
