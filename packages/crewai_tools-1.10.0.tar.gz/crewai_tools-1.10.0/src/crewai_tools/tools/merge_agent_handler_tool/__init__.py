"""Merge Agent Handler tool for CrewAI."""

from crewai_tools.tools.merge_agent_handler_tool.merge_agent_handler_tool import (
    MergeAgentHandlerTool,
)


__all__ = ["MergeAgentHandlerTool"]
