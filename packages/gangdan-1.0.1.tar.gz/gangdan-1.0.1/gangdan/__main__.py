"""Allow running as `python -m gangdan`."""

from gangdan.cli import main

main()
