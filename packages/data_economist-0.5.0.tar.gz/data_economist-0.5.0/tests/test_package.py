"""Testes básicos do pacote data_economist."""

import pytest


def test_import_package():
    """O pacote data_economist pode ser importado."""
    import data_economist
    assert data_economist is not None


def test_version_exists():
    """O pacote expõe __version__."""
    import data_economist
    assert hasattr(data_economist, "__version__")
    assert isinstance(data_economist.__version__, str)
    assert len(data_economist.__version__) >= 5  # e.g. "0.1.0"


def test_import_ibge():
    """from data_economist import ibge expõe o módulo ibge com .url() e .get()."""
    import data_economist
    assert hasattr(data_economist, "ibge")
    assert hasattr(data_economist.ibge, "url")
    assert hasattr(data_economist.ibge, "get")


def test_import_bcb_sgs():
    """from data_economist import bcb_sgs expõe o módulo bcb_sgs com .get()."""
    import data_economist
    assert hasattr(data_economist, "bcb_sgs")
    assert hasattr(data_economist.bcb_sgs, "get")


def test_import_comexstat():
    """from data_economist import comexstat expõe o módulo comexstat com .get(body)."""
    import data_economist
    assert hasattr(data_economist, "comexstat")
    assert hasattr(data_economist.comexstat, "get")


def test_import_eia():
    """from data_economist import eia expõe .get(), .get_data(), .get_steo(), .get_petroleum(), .get_by_landing()."""
    import data_economist
    assert hasattr(data_economist, "eia")
    assert hasattr(data_economist.eia, "get")
    assert hasattr(data_economist.eia, "get_data")
    assert hasattr(data_economist.eia, "get_steo")
    assert hasattr(data_economist.eia, "get_petroleum")
    assert hasattr(data_economist.eia, "get_by_landing")
