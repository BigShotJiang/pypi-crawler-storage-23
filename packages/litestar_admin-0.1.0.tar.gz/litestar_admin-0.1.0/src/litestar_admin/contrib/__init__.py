"""Integration modules for external libraries.

Available sub-packages:
    - providers: Example data providers for CustomView (InMemoryView, JSONFileView, HTTPAPIView)
    - oauth: OAuth authentication backends
    - sqladmin: SQLAdmin bridge for migrations
    - vite: Vite development server integration
"""

from __future__ import annotations

__all__: list[str] = []
