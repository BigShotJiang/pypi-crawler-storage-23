"""Vite integration for frontend development."""

from __future__ import annotations

__all__: list[str] = []
