"""Build information - auto-generated during install, do not edit."""

# Populated by setuptools hook during pip install or CI/CD build
COMMIT_HASH = ""
COMMIT_SHORT = ""
COMMIT_MESSAGE = ""
BUILD_TIME = ""
MODIFIED = None
