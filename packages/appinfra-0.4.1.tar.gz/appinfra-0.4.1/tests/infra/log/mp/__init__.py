"""Tests for multiprocessing logging support."""
