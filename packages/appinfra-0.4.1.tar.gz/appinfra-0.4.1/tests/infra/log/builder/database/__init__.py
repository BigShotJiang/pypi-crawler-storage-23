"""Tests for database logging package."""
