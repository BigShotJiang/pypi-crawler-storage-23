"""Tests for appinfra.ui module."""
