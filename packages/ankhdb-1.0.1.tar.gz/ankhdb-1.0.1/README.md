# ankhdb

The official Python SDK for AnkhDB - A real-time, multi-tenant Backend-as-a-Service.

## Installation

```bash
pip install ankhdb
```

## Usage

### Initialize the Client

You'll need your **Project API Key** from the AnkhDB Dashboard.

```python
from ankhdb import AnkhDB

db = AnkhDB(api_key="YOUR_API_KEY", base_url="http://localhost:5000")
```

### Authentication

Manage your app's end-users seamlessly.

```python
# Register
response = db.register("user@example.com", "securepassword")

# Login
db.login("user@example.com", "securepassword")

# Logout
db.logout()
```

### Database Operations

AnkhDB uses a flexible NoSQL-on-SQL structure.

```python
# Insert a document into 'posts' collection
new_post = db.from_collection("posts").insert({
    "title": "Hello from Python",
    "content": "AnkhDB is great!"
})

# Fetch all posts
posts = db.from_collection("posts").select()

# Get by ID
my_post = db.from_collection("posts").get("doc-id")
```

## License

MIT
