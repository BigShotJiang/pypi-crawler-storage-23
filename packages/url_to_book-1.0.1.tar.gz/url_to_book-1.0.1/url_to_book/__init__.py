"""URL to PDF converter - extract article content and save as PDF."""

__version__ = "1.0.1"
