---
name: discovery-python-sdk
description: Integrates with the Discovery Engine Python SDK for programmatic data analysis. Use when the user mentions "discovery", "discovery engine", "discovery-engine-api", "pattern discovery", "leap labs", or wants to analyze datasets to find novel patterns.
---

# Discovery Engine Python SDK

## Installation

```bash
pip install discovery-engine-api
```

## Quick Start

```python
from discovery import Engine

engine = Engine(api_key: str)

result = engine.run(
    file: str | Path | pd.DataFrame,  # Dataset to analyze
    target_column: str,                 # Column to predict/analyze
    wait: bool = False,                 # Wait for completion
    wait_timeout: float | None = None,  # Timeout in seconds
    depth_iterations: int = 1,           # Analysis depth (1 = fast, higher = deeper, max = num_columns - 2)
    title: str | None = None,           # Dataset title
    description: str | None = None,     # Dataset description
    column_descriptions: dict[str, str] | None = None,  # Column descriptions
    excluded_columns: list[str] | None = None,          # Columns to exclude
    visibility: str = "public",         # "public" (free, always depth 1) or "private" (requires credits, supports higher depth)
    author: str | None = None,          # Dataset author attribution
    source_url: str | None = None,      # Source URL attribution
)
```

## Public vs Private Runs

- **Public** (`visibility="public"`): Free. Results appear in public gallery. Use for open research and demos.
- **Private** (`visibility="private"`): Requires credits. Only you can see results. Use for proprietary data.

If you don't have enough credits for a private run, you'll get a `ValueError` with message "Insufficient credits".

## Getting an API Key

1. Go to https://disco.leap-labs.com
2. Sign up or log in
3. Navigate to **Developers** page
4. Click **Create API Key**
5. Copy and save the key (shown only once)

## Purchasing Credits for Private Runs

1. Go to https://disco.leap-labs.com/account
2. Choose a subscription plan or purchase credits
3. Credits are automatically used for private runs

## Result Structure

```python
@dataclass
class EngineResult:
    run_id: str                                    # Unique run identifier
    report_id: str | None                          # Report ID for dashboard
    status: str                                    # "pending", "processing", "completed", "failed"
    
    # Dataset metadata
    dataset_title: str | None
    dataset_description: str | None
    total_rows: int | None
    target_column: str | None
    task: str | None                               # "regression", "binary_classification", "multiclass_classification"
    
    # Analysis results
    summary: Summary | None                        # LLM-generated insights
    patterns: list[Pattern]                        # Discovered patterns
    columns: list[Column]                          # Feature info and statistics
    correlation_matrix: list[CorrelationEntry]     # Feature correlations
    feature_importance: FeatureImportance | None   # Global importance scores
    
    # Job tracking
    job_id: str | None
    job_status: str | None
    error_message: str | None

@dataclass
class Pattern:
    id: str
    task: str                           # "regression", "binary_classification", "multiclass_classification"
    target_column: str
    target_change_direction: str        # "max" (increases target) or "min" (decreases target)
    p_value: float                      # FDR-adjusted p-value (lower = more significant)
    conditions: list[dict]              # Conditions defining the pattern
    abs_target_change: float            # Absolute change in target (always positive)
    support_count: int                  # Number of rows matching pattern
    support_percentage: float           # Percentage of dataset
    novelty_type: str                   # "novel" or "confirmatory"
    target_score: float
    description: str                    # Human-readable description
    novelty_explanation: str
    target_class: str | None            # For classification tasks
    target_mean: float | None           # For regression tasks
    target_std: float | None
    citations: list[dict]               # Academic citations if available
    p_value_raw: float | None           # Raw p-value before FDR adjustment

@dataclass
class Summary:
    overview: str                       # High-level summary
    key_insights: list[str]             # Main takeaways
    novel_patterns: PatternGroup        # Novel pattern IDs and explanation
    # data_insights and statistically_significant removed in v0.2.0
    selected_pattern_id: str | None

@dataclass
class Column:
    id: str
    name: str
    display_name: str
    type: str                           # "continuous" or "categorical"
    data_type: str                      # "int", "float", "string", "boolean", "datetime"
    enabled: bool
    description: str | None
    # Statistics (for numeric columns)
    mean: float | None
    median: float | None
    std: float | None
    min: float | None
    max: float | None
    iqr_min: float | None
    iqr_max: float | None
    mode: str | None
    approx_unique: int | None
    null_percentage: float | None
    feature_importance_score: float | None

@dataclass
class FeatureImportance:
    kind: str                           # "global"
    baseline: float                     # Baseline model output
    scores: list[FeatureImportanceScore]

@dataclass
class FeatureImportanceScore:
    feature: str
    score: float

@dataclass
class CorrelationEntry:
    feature_x: str
    feature_y: str
    value: float                        # -1 to 1
```

## Async Usage

```python
# In Jupyter or async context
result = await engine.run_async(file="data.csv", target_column="target", wait=True)

# Context manager for automatic cleanup
async with Engine(api_key="key") as engine:
    result = await engine.run_async(...)
```

## Common Operations

```python
# Filter patterns
significant = [p for p in result.patterns if p.p_value < 0.05]
novel = [p for p in result.patterns if p.novelty_type == "novel"]

# Check status without waiting
result = engine.run(file="data.csv", target_column="target", wait=False)
full_result = await engine.wait_for_completion(result.run_id, timeout=3600)

# Batch processing
async with Engine(api_key="key") as engine:
    tasks = [engine.run_async(file=f, target_column="target", wait=True) for f in files]
    results = await asyncio.gather(*tasks)
```

## Error Handling

```python
try:
    result = engine.run(file="data.csv", target_column="target", wait=True)
except FileNotFoundError:
    # File doesn't exist
except ValueError as e:
    # API error - check e for "Insufficient credits" message
except TimeoutError:
    # Analysis didn't complete in time
except RuntimeError:
    # Run failed (check result.error_message)
```

## Jupyter Notebooks

Use `await engine.run_async(...)` directly, or install `nest-asyncio` to use `engine.run()`.
