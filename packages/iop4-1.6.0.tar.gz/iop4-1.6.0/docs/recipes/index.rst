Examples
========

Here you can find some examples on how to use IOP4

.. nbgallery::

   01_notebook_configuration
   02_database_queries
   03_manual_reduction
   04_details_on_astrometric_calibration
   05_quad_matching_dipol_polarimetry_images