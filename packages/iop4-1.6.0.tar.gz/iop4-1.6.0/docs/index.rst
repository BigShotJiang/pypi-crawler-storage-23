.. IOP4 documentation master file, created by
   sphinx-quickstart on Fri Mar 17 20:13:01 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

About IOP4
=======================

.. include:: ../README.md
  :parser: myst_parser.sphinx_
  
#######################

Table of Contents
=======================

.. toctree::
   :maxdepth: 2

   iop4_concepts

   data_reduction_details

   recipes/index

   iop4lib

   serving_iop4_in_production