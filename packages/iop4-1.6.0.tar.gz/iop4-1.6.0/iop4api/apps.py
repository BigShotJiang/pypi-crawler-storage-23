from django.apps import AppConfig


class IOP4APIConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "iop4api"
    verbose_name = "IOP4API"
    