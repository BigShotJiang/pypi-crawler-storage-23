from multiprocessing import Pool
from pathlib import Path

import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
import rasterio as rio
from rasterio.io import MemoryFile
from rasterio.mask import mask
from rasterio.plot import show

from tree_registration_and_matching.register_MEE import align_plot
from tree_registration_and_matching.utils import ensure_projected_CRS


def compute_shift(
    field_trees,
    CHMs_or_detected_trees,
    plot_bounds,
    dataset_id,
    alignment_algorithm,
    CHM_approach,
    crop_to_plot_bounds,
    plot_buffer_distance,
    vis_plots,
):
    """Contains the per-plot logic to support parrellization"""
    # Read the field trees and ensure that a projected CRS is used
    plot_bounds.to_crs(field_trees.crs, inplace=True)

    if CHM_approach:
        content_to_register_to = rio.open(CHMs_or_detected_trees)
        if not content_to_register_to.crs.is_projected:
            raise ValueError(
                "Raster does not have a projected CRS. This may cause errors in registration algorithms."
            )
        # Ensure the plot bounds and field trees are in the same CRS as the raster, since the
        # raster cannot be reprojected without data loss.
        # TODO all shifts reported by the registration algorithm will be relative to the CRS of
        # the raster data, which should be addressed at some point for consistency.
        plot_bounds.to_crs(content_to_register_to.crs, inplace=True)
        field_trees.to_crs(content_to_register_to.crs, inplace=True)

        # Mask CHM outside plot bounds if requested
        if crop_to_plot_bounds:
            # Create a buffered geometry from plot bounds to include areas slightly outside
            # the exact plot boundaries, based on the specified buffer_distance
            buffered_geom = plot_bounds.buffer(plot_buffer_distance).union_all()

            # Use rasterio's mask function to set all pixels outside the buffered geometry
            # to the raster's nodata value, effectively masking irrelevant terrain data.
            # Note that this may make the dimensions of the raster smaller, which is why the
            # new transform must be recorded.
            masked_data, masked_transform = mask(
                content_to_register_to,
                [buffered_geom],
                crop=True,
                nodata=content_to_register_to.nodata,
            )

            # Get the original raster's profile and update it with the new dimensions
            # and transform from the masking operation
            profile = content_to_register_to.profile
            profile.update(
                height=masked_data.shape[1],
                width=masked_data.shape[2],
                transform=masked_transform,
            )

            # Close the original raster file handler to prevent memory leaks
            content_to_register_to.close()

            # Create an in-memory raster file to hold the masked data
            memfile = MemoryFile()
            content_to_register_to = memfile.open(**profile)

            # Write the masked data to the in-memory raster
            content_to_register_to.write(masked_data)

        if vis_plots:
            _, ax = plt.subplots()
            # Read and show the first band of the raster. If we want to support approaches for
            # multiband rasters, this would need to be updated.
            cb = show(content_to_register_to.read(1), ax=ax, cmap="viridis")
            plt.colorbar(cb, ax=ax, label="Height (m)")
            # Show the plot bounds
            # The rasterio visualization is in pixel coordinates, so we must transform the
            # geospatial data of the plot bounds to match it.
            transform = content_to_register_to.transform.__invert__().to_shapely()
            plot_bounds.affine_transform(transform).plot(
                ax=ax, facecolor="none", edgecolor="cyan", linewidth=3
            )
            ax.set_title(f"CHM for dataset_ID {dataset_id}")
            plt.show()
    else:
        # Ensure that the field trees are in a projected (meters-based) CRS
        field_trees = ensure_projected_CRS(field_trees)
        # The data is already read
        content_to_register_to = CHMs_or_detected_trees
        content_to_register_to.to_crs(field_trees.crs, inplace=True)

        # Crop to plot bounds if requested
        if crop_to_plot_bounds:
            buffered_bounds = plot_bounds.copy()
            buffered_bounds.geometry = buffered_bounds.buffer(plot_buffer_distance)
            content_to_register_to = gpd.clip(content_to_register_to, buffered_bounds)

        # Visualize the three datasets if requested
        if vis_plots:
            f, ax = plt.subplots()
            plot_bounds.boundary.plot(
                ax=ax, color="k", markersize=2, label="plot bounds"
            )
            content_to_register_to.plot(
                ax=ax, c="b", markersize=2, label="detected trees"
            )
            field_trees.plot(ax=ax, c="r", markersize=2, label="surveyed trees")
            plt.title(f"Visualization for {dataset_id}")
            plt.legend()
            plt.show()

    # Run aligment
    # TODO determine if this should get the plot bounds anymore since cropping already happens
    # in this driver code.
    alignment_results = alignment_algorithm(
        field_trees,
        content_to_register_to,
        plot_bounds,
    )
    # The algorithm should return the (x, y) shift as the first of potentially-many arguments
    estimated_shift = alignment_results[0]

    if CHM_approach:
        # In this case, content_to_register_to is an open file handler for a raster. Close it to
        # avoid a memory leak.
        content_to_register_to.close()

    return estimated_shift


def score_approach(
    field_trees_file: str,
    CHMs_or_detected_trees: str,
    plots_file: str,
    shifts: dict,
    shift_CRS,
    alignment_algorithm=align_plot,
    CHM_approach: bool = False,
    vis_plots: bool = False,
    vis_results: bool = True,
    crop_to_plot_bounds: bool = False,
    plot_buffer_distance: float = 0.0,
    n_workers=1,
) -> np.array:
    """Assess the quality of the shift on a set of plots.

    Args:
        field_tree_file (str):
            The file for geospatial files representing the surveyed trees. The `dataset_id` column
            in this data should correspond to the filenames in `CHMs_or_detected_trees_folder`.
        CHMs_or_detected_trees (str):
            Either:
                * A folder of canopy height models, one per plot. This data will be in a raster format
                  (e.g. .tif)
                * A file corresponding to detected tree tops, with `dataset_id` identifying the dataset.
                  This data will be in a vector format (e.g. gpkg)
        plots_file (str):
            A path to a geopackage file with geometry representing the surveyed area. The 'plot_id'
            field represents which dataset (field trees plus CHMs or detected trees) files it
            corresponds to. Note that the plot_id field will not contain file extension.
        shifts (dict):
            A dictionary mapping from dataset to a (x, y) shift to apply to the field trees and
            plot bounds.
        shifts_CRS (CRS):
            The data should be converted this CRS prior to translation.
        alignment_algorithm (function, optional):
            A function which aligns the field and detected trees. The second return argument should
            be the (x, y) shift. Defaults to align_plot.
        CHM_approach(bool, optional):
            Whether the approach acts on CHM data, rather than detected trees. Defaults to False.
        vis_plots (bool, optional):
            Should each plot be shown. Defaults to False.
        vis_results (bool, optional):
            Should the offset from true shifts be visualized. Defaults to True.
        crop_to_plot_bounds (bool, optional):
            Whether the content to register to should be cropped to a buffered version of the plot
            bounds. The buffer distance is defined by `plot_buffer_distance`. In the case of using
            tree locations as input, all trees outside of the area are removed prior to registration.
            If using a CHM input, all regions of the CHM outside the crop are set to the datasets'
            nadata attribute.
        plot_buffer_distance (float, optional):
            Buffer distance around the plot bounds to include when cropping. Defaults to 0.0.
        n_workers (int, optional):
            Number of multiprocessing workers to use. Defaults to 1.

    Raises:
        ValueError:
            If the detected and field tree folders do not have the same number of files with the
            same names.

    Returns:
        np.array: The error for each plot, ordered by the sorted plot IDs.
    """

    # Read all the plot bounds and trees
    all_plot_bounds = gpd.read_file(plots_file).to_crs(shift_CRS)
    all_field_trees = gpd.read_file(field_trees_file).to_crs(shift_CRS)

    # Unique dataset IDs
    dataset_IDs = sorted(all_field_trees.dataset_id.unique())

    # List all the files in both input folders
    # TODO this needs to be updated
    if CHM_approach:
        CHMs_or_detected_trees_elements = sorted(CHMs_or_detected_trees.glob("*"))
        if set(all_field_trees.dataset_id.unique()) != set(
            [f.stem for f in CHMs_or_detected_trees_elements]
        ):
            raise ValueError(
                "Different filenames between CHMs and field tree dataset IDs"
            )
    else:
        detected_trees = gpd.read_file(CHMs_or_detected_trees)
        CHMs_or_detected_trees_elements = [
            detected_trees.query("dataset_id==dataset_id") for dataset_id in dataset_IDs
        ]

    # Ensure there are the same number of files
    if len(dataset_IDs) != len(CHMs_or_detected_trees_elements):
        raise ValueError("Different number of files")

    field_trees_list = []
    plot_bounds_list = []
    # Iterate over files to extract plot bounds corresponding to each
    for dataset_id in dataset_IDs:
        # Find the corresponding shift
        shift = shifts[dataset_id][0]

        # Subset to the specified dataset
        plot_bounds = all_plot_bounds.query("dataset_id == @dataset_id")
        field_trees = all_field_trees.query("dataset_id == @dataset_id")

        # Apply the translation
        plot_bounds.geometry = plot_bounds.translate(xoff=shift[0], yoff=shift[1])
        field_trees.geometry = field_trees.translate(xoff=shift[0], yoff=shift[1])

        # Read the plot name and extract the plot bounds for this dataset
        # TODO, make optional to provide plot bounds
        plot_bounds_list.append(plot_bounds)
        field_trees_list.append(field_trees)

    # Compute the results with multiprocessing
    with Pool(n_workers) as p:
        # The lists below are a bit of a hack because they just repeat the same values
        n_files = len(dataset_IDs)
        all_shifts = p.starmap(
            compute_shift,
            list(
                zip(
                    field_trees_list,
                    CHMs_or_detected_trees_elements,
                    plot_bounds_list,
                    dataset_IDs,
                    [alignment_algorithm] * n_files,
                    [CHM_approach] * n_files,
                    [crop_to_plot_bounds] * n_files,
                    [plot_buffer_distance] * n_files,
                    [vis_plots] * n_files,
                )
            ),
            chunksize=1,
        )

    all_shifts = np.array(list(all_shifts))
    if vis_results:
        # Plot the x,y errors
        plt.title("Scatter plot of the errors")
        plt.scatter(all_shifts[:, 0], all_shifts[:, 1])
        plt.xlim([-12, 12])
        plt.ylim([-12, 12])
        plt.show()

        # Plot the distribution of error magnitudes
        magnitudes = np.linalg.norm(all_shifts, axis=1)
        plt.title("Magnitudes of errors")
        plt.hist(magnitudes)

    return all_shifts
