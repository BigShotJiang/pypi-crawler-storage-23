from email.mime.application import MIMEApplication

from emailify.models import Column
from emailify.renderers.core import _render_mjml_template
from emailify.renderers.registry import RenderRegistry
from emailify.renderers.services.component_service import render_inner_html
from emailify.renderers.style import render_style


@RenderRegistry.register(Column)
def render_column(column: Column) -> tuple[str, list[MIMEApplication]]:
    children_parts = []
    attachments = []
    for child in column.children:
        html, child_attachments = render_inner_html(child)
        children_parts.append(html)
        attachments.extend(child_attachments)
    children_html = "\n".join(children_parts)
    body = _render_mjml_template(
        "column",
        style_str=render_style(column.style),
        children_html=children_html,
    )
    return body, attachments
