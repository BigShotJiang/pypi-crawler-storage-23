from email.mime.application import MIMEApplication

from emailify.models import BulletList, Text
from emailify.renderers.core import _render_mjml_template
from emailify.renderers.registry import RenderRegistry
from emailify.renderers.style import render_mjml_obj_props


@RenderRegistry.register(BulletList)
def render_bullet_list(bullet_list: BulletList) -> tuple[str, list[MIMEApplication]]:
    items_text = [
        item.text if isinstance(item, Text) else str(item)
        for item in bullet_list.items
    ]
    body = _render_mjml_template(
        "bullet_list",
        bullet_list=bullet_list,
        items_text=items_text,
        extra_props=render_mjml_obj_props("bullet_list", bullet_list.style),
    )
    return body, []
