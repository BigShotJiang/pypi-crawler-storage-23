from email.mime.application import MIMEApplication

from emailify.models import Text
from emailify.renderers.core import _render_mjml_template
from emailify.renderers.registry import RenderRegistry
from emailify.renderers.style import render_mjml_obj_props


@RenderRegistry.register(Text)
def render_text(text: Text) -> tuple[str, list[MIMEApplication]]:
    body = _render_mjml_template(
        "text",
        text=text,
        extra_props=render_mjml_obj_props("text", text.style),
    )
    return body, []
