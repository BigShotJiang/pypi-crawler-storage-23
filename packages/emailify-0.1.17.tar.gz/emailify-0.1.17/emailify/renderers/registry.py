import importlib
from importlib.resources import files
from typing import Type, Dict, Callable

from emailify.models import Component


class RenderRegistry:
    _render_map: Dict[Type[Component], Callable] = dict()

    @classmethod
    def register_component(cls, component_type: Type[Component], render_func: Callable):
        cls._render_map[component_type] = render_func

    @classmethod
    def register(cls, component_type: Type[Component]):
        def func_wrapper(render_func: Callable):
            cls.register_component(component_type, render_func)
            return render_func

        return func_wrapper

    # noinspection PyUnresolvedReferences
    @classmethod
    def get_render_map(cls) -> Dict[Type[Component], Callable]:
        components_pkg = importlib.import_module(f"{__package__}.components")
        for file in files(components_pkg).iterdir():
            if file.suffix == ".py" and file.name != "__init__.py":
                importlib.import_module(f"{components_pkg.__name__}.{file.stem}")
        return cls._render_map
