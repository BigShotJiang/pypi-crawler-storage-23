from email.mime.application import MIMEApplication

from emailify.models import Component
from emailify.renderers.core import _render_mjml_template
from emailify.renderers.services.component_service import render_mjml
from emailify.renderers.services.mjml_service import mjml2html


def render(
        *components: Component,
        max_width: str = "900px",
) -> tuple[str, list[MIMEApplication]]:
    parts: list[str] = []
    attachments: list[MIMEApplication] = []
    for component in components:
        body, cur_attachments = render_mjml(component)
        parts.append(body)
        attachments.extend(cur_attachments)
    body_str = _render_mjml_template(
        "index",
        content="".join(parts),
        max_width=max_width,
    )
    html = mjml2html(body_str)
    return html, attachments
