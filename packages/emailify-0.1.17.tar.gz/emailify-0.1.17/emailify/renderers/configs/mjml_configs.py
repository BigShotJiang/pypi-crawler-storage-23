from functools import lru_cache
from importlib.resources import files
from pathlib import Path

from quickjs import Context


def read_bundle_text() -> str:
    return (Path(str(files("emailify"))) / "resources" / "js" / "mjml-browser.js").read_text(encoding="utf-8")


def read_js_text(name: str) -> str:
    return (Path(str(files("emailify"))) / "resources" / "js" / name).read_text(encoding="utf-8")


def build_ctx() -> Context:
    ctx = Context()
    ctx.eval(read_js_text("setup_shim.js"))
    bundle_js = read_bundle_text()
    ctx.eval(bundle_js)
    ctx.eval(read_js_text("capture_export.js"))
    return ctx


@lru_cache(maxsize=1)
def get_ctx() -> Context:
    return build_ctx()
