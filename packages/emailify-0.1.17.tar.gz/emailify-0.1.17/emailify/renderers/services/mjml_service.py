import json
import traceback

from emailify.renderers.configs.mjml_configs import read_js_text, get_ctx


def mjml2html(
        mjml: str,
        **options,
) -> str:
    template = read_js_text("call_mjml.js")
    js = template.replace("__MJML__", json.dumps(mjml)).replace(
        "__OPTIONS__", json.dumps(options or {})
    )
    try:
        return get_ctx().eval(js)
    except Exception as e:
        raise RuntimeError(f"{e}\n{traceback.format_exc()}") from None
