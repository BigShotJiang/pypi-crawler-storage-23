import re
from email.mime.application import MIMEApplication
from typing import Any, Optional, Type
from typing import Dict

from emailify.models import Component
from emailify.renderers.core import _render_mjml_template
from emailify.renderers.registry import RenderRegistry
from emailify.renderers.services.mjml_service import mjml2html

EXTRACT_RE = re.compile(r"__BEG__.*?(<div\b[^>]*>(.*?)<\/div>).*?__END__", re.DOTALL)


def render_mjml(
        component: Component,
        render_map: Optional[Dict[Type[Component], Any]] = None,
) -> tuple[str, list[MIMEApplication]]:
    render_map = render_map or RenderRegistry.get_render_map()
    return render_map[type(component)](component)


def render_inner_html(
        component: Component,
        render_map: Optional[Dict[Type[Component], Any]] = None,
        keep_container: bool = True,
) -> tuple[str, list[MIMEApplication]]:
    render_map = render_map or RenderRegistry.get_render_map()
    mjml_fragment, attachments = render_map[type(component)](component)
    content_str = f"<mj-raw>__BEG__</mj-raw>{mjml_fragment}<mj-raw>__END__</mj-raw>"
    full_mjml = _render_mjml_template("index", content=content_str)
    html = mjml2html(full_mjml)
    match = EXTRACT_RE.search(html)
    inner_html = match.group(2).strip() if match else ""
    if keep_container:
        inner_html = match.group(1).strip() if match else ""
    return inner_html, attachments
