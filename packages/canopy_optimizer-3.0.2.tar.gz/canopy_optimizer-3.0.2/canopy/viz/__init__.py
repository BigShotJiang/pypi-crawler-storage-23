"""
Canopy Viz — Institutional Visualization Engine
Copyright © 2026 Anagatam Technologies. All rights reserved.

This package contains the 9-chart Plotly visualization suite.
"""
from canopy.viz.ChartEngine import CanopyVisualizer
