"""
Canopy — Institutional-Grade Hierarchical Portfolio Optimization
═══════════════════════════════════════════════════════════════════
Copyright © 2026 Anagatam Technologies. All rights reserved.
Licensed under the Apache License, Version 2.0.

https://github.com/Anagatam/Canopy
https://canopy-institutional-hierarchical-optimization-engine.readthedocs.io
https://pypi.org/project/canopy-optimizer

DISCLAIMER: This library provides mathematical algorithms for
educational and research purposes only. It does NOT constitute
investment advice. See DISCLAIMER.md for full legal notice.
"""

from canopy.MasterCanopy import MasterCanopy

__version__ = '3.0.2'
__author__ = 'Anagatam Technologies'
__license__ = 'Apache-2.0'

__all__ = ['MasterCanopy']
