"""
Canopy Backtest — Walk-Forward Portfolio Rebalancing Engine
═══════════════════════════════════════════════════════════════
Copyright © 2026 Anagatam Technologies. All rights reserved.

Provides a production-grade walk-forward backtesting engine that
simulates periodic portfolio rebalancing using any Canopy optimizer.

Architecture
────────────
    BacktestEngine follows the Strategy pattern — it accepts any
    MasterCanopy instance as the optimizer and rolls it forward
    through time with configurable rebalance frequency and lookback.

    Math (return computation, drawdowns) is separated from
    orchestration logic (windowing, rebalancing schedule).

Usage
─────
    >>> from canopy.backtest import BacktestEngine
    >>> from canopy.MasterCanopy import MasterCanopy
    >>>
    >>> engine = BacktestEngine(
    ...     optimizer=MasterCanopy(method='HRP'),
    ...     frequency='monthly',
    ...     lookback=252,
    ... )
    >>> result = engine.run(returns)
    >>> print(result.summary())
"""

import pandas as pd
import numpy as np
from typing import Optional
from datetime import datetime, timezone


class BacktestResult:
    """
    Container for backtest results with built-in analytics.

    Attributes:
        equity: Equity curve (cumulative NAV).
        weights: Historical weight allocations (T × N).
        turnover: Turnover at each rebalance.
        rebalances: Number of rebalance events.
    """

    def __init__(
        self,
        equity: pd.Series,
        weights: pd.DataFrame,
        turnover: pd.Series,
        rebalances: int,
        method: str,
    ):
        self.equity = equity
        self.weights = weights
        self.turnover = turnover
        self.rebalances = rebalances
        self.method = method

    @property
    def returns(self) -> pd.Series:
        """Daily portfolio returns from the equity curve."""
        return self.equity.pct_change().dropna()

    @property
    def totalreturn(self) -> float:
        """Total cumulative return."""
        return float(self.equity.iloc[-1] / self.equity.iloc[0] - 1)

    @property
    def maxdrawdown(self) -> float:
        """Maximum peak-to-trough drawdown."""
        running = self.equity.cummax()
        dd = self.equity / running - 1
        return float(dd.min())

    @property
    def sharpe(self) -> float:
        """Annualized Sharpe Ratio."""
        r = self.returns
        if r.std() == 0:
            return 0.0
        return float(r.mean() / r.std() * np.sqrt(252))

    def summary(self) -> str:
        """Human-readable backtest report."""
        lines = [
            "╔══════════════════════════════════════════════════╗",
            "║         Canopy — Backtest Report                 ║",
            "╚══════════════════════════════════════════════════╝",
            "",
            f"  Method            : {self.method}",
            f"  Period            : {self.equity.index[0].date()} → {self.equity.index[-1].date()}",
            f"  Rebalances        : {self.rebalances}",
            f"  Total Return      : {self.totalreturn:>10.2%}",
            f"  Sharpe Ratio      : {self.sharpe:>10.3f}",
            f"  Max Drawdown      : {self.maxdrawdown:>10.2%}",
            f"  Avg Turnover      : {self.turnover.mean():>10.2%}",
            "",
        ]
        return "\n".join(lines)


class BacktestEngine:
    """
    Walk-forward backtesting engine for Canopy optimizers.

    Simulates periodic portfolio rebalancing by:
    1. Looking back `lookback` trading days
    2. Running the optimizer on that window
    3. Holding the resulting weights until next rebalance
    4. Recording the equity curve and turnover

    Args:
        optimizer: A configured MasterCanopy instance.
        frequency: Rebalance frequency — 'monthly', 'quarterly', 'weekly'.
        lookback: Number of trading days in the estimation window.

    Example:
        >>> engine = BacktestEngine(
        ...     optimizer=MasterCanopy(method='HRP'),
        ...     frequency='monthly',
        ... )
        >>> result = engine.run(returns)
        >>> print(result.summary())
    """

    FREQ_MAP = {
        'daily': 1,
        'weekly': 5,
        'biweekly': 10,
        'monthly': 21,
        'quarterly': 63,
        'semiannual': 126,
        'annual': 252,
    }

    def __init__(
        self,
        optimizer,
        frequency: str = 'monthly',
        lookback: int = 252,
    ):
        if frequency not in self.FREQ_MAP:
            raise ValueError(
                f"Unknown frequency '{frequency}'. "
                f"Choose from: {list(self.FREQ_MAP.keys())}"
            )

        self.optimizer = optimizer
        self.frequency = frequency
        self.lookback = lookback
        self.step = self.FREQ_MAP[frequency]

    def run(self, returns: pd.DataFrame) -> BacktestResult:
        """
        Execute walk-forward backtest.

        Args:
            returns: Full asset returns DataFrame (T × N).

        Returns:
            BacktestResult with equity curve, weights, and analytics.
        """
        T, N = returns.shape
        if T < self.lookback + self.step:
            raise ValueError(
                f"Insufficient data: {T} rows, need at least {self.lookback + self.step} "
                f"(lookback={self.lookback} + step={self.step})."
            )

        nav = [1.0]
        dates = [returns.index[self.lookback]]
        all_weights = []
        turnovers = []
        prev_weights = pd.Series(0.0, index=returns.columns)
        rebalances = 0

        t = self.lookback
        while t < T:
            # Estimation window
            window = returns.iloc[t - self.lookback:t]

            # Optimize
            try:
                self.optimizer.cluster(window)
                weights = self.optimizer.allocate()
            except Exception:
                weights = prev_weights  # Hold previous if optimization fails

            # Turnover
            turn = float((weights - prev_weights).abs().sum() / 2)
            turnovers.append(turn)
            rebalances += 1

            # Forward returns until next rebalance
            end = min(t + self.step, T)
            for day in range(t, end):
                daily = float((returns.iloc[day] * weights).sum())
                nav.append(nav[-1] * (1 + daily))
                dates.append(returns.index[day])

            all_weights.append(weights)
            prev_weights = weights
            t += self.step

        equity = pd.Series(nav, index=dates, name='NAV')
        weight_df = pd.DataFrame(all_weights)
        turnover_series = pd.Series(turnovers, name='Turnover')

        method = getattr(self.optimizer, 'method', 'Unknown')

        return BacktestResult(
            equity=equity,
            weights=weight_df,
            turnover=turnover_series,
            rebalances=rebalances,
            method=method,
        )
