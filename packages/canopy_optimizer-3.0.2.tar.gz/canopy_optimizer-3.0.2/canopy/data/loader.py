"""
Canopy DataLoader — Institutional-Grade Market Data Pipeline
═══════════════════════════════════════════════════════════════
Copyright © 2026 Anagatam Technologies. All rights reserved.

Provides a unified interface for fetching, cleaning, and transforming
market data from multiple sources into analysis-ready return matrices.

Architecture
────────────
    DataLoader follows the Factory Method pattern — each source
    (yfinance, CSV, Parquet, DataFrame) has a dedicated classmethod
    that returns a cleaned, validated pandas DataFrame of returns.

    The pipeline: Raw Prices → Forward Fill → Returns → NaN Drop → Validation

References
──────────
    [1] Ledoit, O. & Wolf, M. (2004). "Honey, I Shrunk the Sample Covariance."
    [2] Lopez de Prado, M. (2018). "Advances in Financial Machine Learning."

Usage
─────
    >>> from canopy.data import DataLoader
    >>>
    >>> # From Yahoo Finance (most common)
    >>> returns = DataLoader.yfinance(['AAPL', 'MSFT', 'GOOGL'], start='2020-01-01')
    >>>
    >>> # With benchmark for comparison
    >>> returns, bench = DataLoader.yfinance(
    ...     ['RELIANCE.NS', 'TCS.NS', 'INFY.NS'],
    ...     start='2021-01-01',
    ...     benchmark='^NSEI'
    ... )
    >>>
    >>> # From local files
    >>> returns = DataLoader.csv('prices.csv')
    >>> returns = DataLoader.parquet('institutional_feed.parquet')
"""

import pandas as pd
import numpy as np
from typing import Union, List, Optional, Tuple
import warnings


class DataLoader:
    """
    Unified market data loader for Canopy portfolio optimization.

    All methods are classmethods — no instantiation needed.
    Every method returns a clean DataFrame of log or arithmetic returns,
    ready for direct input to MasterCanopy.

    Design: Google-style factory classmethods with zero boilerplate.
    """

    @classmethod
    def yfinance(
        cls,
        tickers: List[str],
        start: str = '2020-01-01',
        end: Optional[str] = None,
        benchmark: Optional[str] = None,
        log: bool = False,
    ) -> Union[pd.DataFrame, Tuple[pd.DataFrame, pd.Series]]:
        """
        Fetch adjusted close prices from Yahoo Finance and compute returns.

        Args:
            tickers: List of ticker symbols (e.g., ['AAPL', 'MSFT']).
            start: Start date in 'YYYY-MM-DD' format.
            end: End date (defaults to today).
            benchmark: Optional benchmark ticker (e.g., '^GSPC', '^NSEI').
                       If provided, returns a tuple (asset_returns, benchmark_returns).
            log: If True, compute log returns. Default: arithmetic returns.

        Returns:
            pd.DataFrame of returns (T × N), or tuple (returns, benchmark_series)
            if benchmark is specified.

        Raises:
            ImportError: If yfinance is not installed.
            ValueError: If no valid data is returned for the given tickers.

        Example:
            >>> returns = DataLoader.yfinance(['AAPL', 'MSFT'], start='2022-01-01')
            >>> returns.shape
            (750, 2)
        """
        try:
            import yfinance as yf
        except ImportError:
            raise ImportError(
                "yfinance is required for DataLoader.yfinance(). "
                "Install it with: pip install yfinance"
            )

        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            data = yf.download(tickers, start=start, end=end, progress=False)

        if data.empty:
            raise ValueError(f"No data returned for tickers: {tickers}")

        closes = data['Close'] if isinstance(data.columns, pd.MultiIndex) else data
        # Drop only fully-empty columns, then forward/backward fill calendar gaps
        closes = closes.dropna(how='all', axis=1).ffill().bfill().dropna(axis=1, how='any')

        if closes.shape[1] == 0:
            raise ValueError("All tickers returned empty data after cleaning.")

        returns = cls._compute_returns(closes, log=log)

        if benchmark is not None:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                bench_data = yf.download(benchmark, start=start, end=end, progress=False)
            bench_close = bench_data['Close'] if isinstance(bench_data.columns, pd.MultiIndex) else bench_data
            # yfinance may return DataFrame or Series depending on version
            if isinstance(bench_close, pd.Series):
                bench_close = bench_close.to_frame(name=benchmark)
            elif isinstance(bench_close, pd.DataFrame) and bench_close.shape[1] == 1:
                bench_close.columns = [benchmark]
            bench_returns = cls._compute_returns(bench_close, log=log).iloc[:, 0]
            bench_returns.name = benchmark
            return returns, bench_returns

        return returns

    @classmethod
    def csv(
        cls,
        filepath: str,
        price_column: Optional[str] = None,
        date_column: Optional[str] = None,
        log: bool = False,
    ) -> pd.DataFrame:
        """
        Load prices from a CSV file and compute returns.

        Args:
            filepath: Path to CSV file.
            price_column: If CSV has multiple column groups, specify (e.g., 'Close').
            date_column: Column to use as DatetimeIndex. Default: first column.
            log: If True, compute log returns.

        Returns:
            pd.DataFrame of returns (T × N).
        """
        idx = date_column or 0
        df = pd.read_csv(filepath, index_col=idx, parse_dates=True)
        df = df.select_dtypes(include=[np.number]).ffill().dropna(axis=1)
        return cls._compute_returns(df, log=log)

    @classmethod
    def parquet(cls, filepath: str, log: bool = False) -> pd.DataFrame:
        """
        Load prices from a Parquet file and compute returns.

        Args:
            filepath: Path to Parquet file.
            log: If True, compute log returns.

        Returns:
            pd.DataFrame of returns (T × N).
        """
        df = pd.read_parquet(filepath)
        df = df.select_dtypes(include=[np.number]).ffill().dropna(axis=1)
        return cls._compute_returns(df, log=log)

    @classmethod
    def dataframe(
        cls,
        prices: pd.DataFrame,
        log: bool = False,
    ) -> pd.DataFrame:
        """
        Convert a prices DataFrame directly to returns.

        Args:
            prices: DataFrame of asset prices (T × N).
            log: If True, compute log returns.

        Returns:
            pd.DataFrame of returns (T-1 × N).
        """
        if not isinstance(prices, pd.DataFrame):
            raise TypeError(f"Expected pd.DataFrame, got {type(prices).__name__}")
        cleaned = prices.select_dtypes(include=[np.number]).ffill().dropna(axis=1)
        return cls._compute_returns(cleaned, log=log)

    # ─── Internal ────────────────────────────────────────────────────────

    @staticmethod
    def _compute_returns(prices: pd.DataFrame, log: bool = False) -> pd.DataFrame:
        """Compute arithmetic or log returns from price series."""
        if log:
            returns = np.log(prices / prices.shift(1))
        else:
            returns = prices.pct_change()
        return returns.dropna()
