from lakelogic.cli.main import app

__all__ = ["app"]

if __name__ == "__main__":
    app()
