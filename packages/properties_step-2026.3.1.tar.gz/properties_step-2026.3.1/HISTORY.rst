=======
History
=======
2026.3.1 -- Internal: switching from deprecated library pkg_resources to importlib

2023.7.31 -- Bugfix: random error creating the tables of properties.

2023.7.30 -- Initial release
    * Initial version, which can export the properties in the database to a table.
