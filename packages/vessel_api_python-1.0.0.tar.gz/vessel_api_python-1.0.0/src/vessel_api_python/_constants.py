"""Constants for the Vessel API Python SDK."""

VERSION = "1.0.0"
DEFAULT_BASE_URL = "https://api.vesselapi.com/v1"
DEFAULT_USER_AGENT = f"vesselapi-python/{VERSION}"
DEFAULT_MAX_RETRIES = 3
DEFAULT_TIMEOUT = 30.0
MAX_BACKOFF = 30.0  # seconds
