"""Classifier modules for Snaffler Linux"""
