#!/bin/sh

. .hooks/colors.sh

JIRA_KEY_REGEX='^(RDFT|SUG|RD|LOAN)-[0-9]{1,5}'

commit_msg_file="$1"
commit_msg="$(head -n1 "$commit_msg_file")"

if ! echo "$commit_msg" | grep -qE "$JIRA_KEY_REGEX"; then
  echo ""
  echo "${RED}${BOLD}❌ Invalid commit message${NC}"
  echo ""
  echo "${BOLD}Expected Jira key at start:${NC}"
  echo ""
  echo "  ${GREEN}RDFT-123: fix bug${NC}"
  echo "  ${GREEN}SUG-4: add validation${NC}"
  echo ""
  echo "${BOLD}Your message:${NC}"
  echo "  ${YELLOW}$commit_msg${NC}"
  echo ""

  exit 1
fi
