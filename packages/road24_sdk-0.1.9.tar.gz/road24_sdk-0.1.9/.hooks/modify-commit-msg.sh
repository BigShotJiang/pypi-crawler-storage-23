#!/bin/sh

commit_msg_file=$1
commit_msg=$(head -n1 "$commit_msg_file")

if ! echo "$commit_msg" | grep -qE '\[\+\]$'; then
  new_msg="${commit_msg} [+]"
  echo "$new_msg" > "$commit_msg_file"
fi
