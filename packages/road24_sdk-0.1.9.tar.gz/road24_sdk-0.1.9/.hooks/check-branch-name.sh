#!/bin/sh

. .hooks/colors.sh

BRANCH=$(git symbolic-ref --short HEAD)

BRANCH_REGEX='^(RDFT|SUG|RD|LOAN)-[0-9]{1,5}/[a-z0-9_-]+$'

if ! echo "$BRANCH" | grep -qE "$BRANCH_REGEX"; then
  echo ""
  echo "${RED}${BOLD}❌ Invalid branch name:${NC} ${YELLOW}$BRANCH${NC}"
  echo ""
  echo "${BOLD}Expected format:${NC}"
  echo ""
  echo "  ${GREEN}RDFT-123/implement_something${NC}"
  echo "  ${GREEN}SUG-4/fix_bug${NC}"
  echo "  ${GREEN}RD-999/refactor${NC}"
  echo "  ${GREEN}LOAN-42/add_flow${NC}"
  echo ""
  echo "${BOLD}✔ Fix it with:${NC}"
  echo ""
  echo "  ${BLUE}git branch -m RDFT-XXX/your_task${NC}"
  echo ""

  exit 1
fi

exit 0
