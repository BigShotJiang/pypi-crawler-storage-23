#!/bin/sh

# Disable colors in non-TTY (CI, pipes, etc)
if [ ! -t 1 ]; then
  RED='' GREEN='' YELLOW='' BLUE='' BOLD='' NC=''
  return 0
fi

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'
