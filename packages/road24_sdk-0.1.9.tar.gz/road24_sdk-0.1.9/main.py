def main():
    print("Hello from road24-sdk!")


if __name__ == "__main__":
    main()
