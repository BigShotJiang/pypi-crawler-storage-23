import logging

from road24_sdk._sanitizer import sanitize_body
from road24_sdk._schemas import FastStreamAttributes
from road24_sdk._types import BrokerType, FastStreamDirection, LogType

logger = logging.getLogger(__name__)


class FastStreamLogger:
    def __init__(self, *, record_metrics: bool = True) -> None:
        self._record_metrics = record_metrics

    def log(
        self,
        direction: FastStreamDirection,
        broker: BrokerType,
        queue: str,
        duration_seconds: float,
        message_body: str = "",
        exchange: str = "",
        routing_key: str = "",
        exc: Exception | None = None,
    ) -> None:
        if self._record_metrics:
            from road24_sdk.metrics.faststream import record_faststream_message

            record_faststream_message(
                direction=direction,
                broker=broker,
                queue=queue,
                duration_seconds=duration_seconds,
            )

        attrs = FastStreamAttributes(
            direction=direction,
            broker=broker,
            queue=queue,
            duration_seconds=duration_seconds,
            message_body=sanitize_body(message_body) if message_body else "",
            exchange=exchange,
            routing_key=routing_key,
            error_class=type(exc).__name__ if exc else "",
            error_message=str(exc) if exc else "",
        )

        log_level = "error" if exc else "info"
        getattr(logger, log_level)(
            LogType.MESSAGE,
            exc_info=exc if exc else None,
            extra=attrs.as_dict(),
        )
