import logging
from http import HTTPStatus
from typing import TYPE_CHECKING

from road24_sdk._sanitizer import (
    BINARY_MASK,
    is_loggable_content_type,
    sanitize_body,
    sanitize_dict,
)
from road24_sdk._schemas import HttpAttributes
from road24_sdk._types import HttpDirection, LogType

if TYPE_CHECKING:
    from starlette.types import Scope

logger = logging.getLogger(__name__)


class HttpInputLogger:
    def log(
        self,
        scope: "Scope",
        status_code: int,
        duration_seconds: float,
        record_metrics: bool = True,
        exc: Exception | None = None,
        request_body: str = "",
        response_body: str = "",
        response_content_type: str = "",
    ) -> None:
        method = scope.get("method", "")
        path = scope.get("path", "")
        scheme = scope.get("scheme", "http")
        headers = sanitize_dict(
            {k.decode(): v.decode() for k, v in scope.get("headers", [])}
        )
        host = headers.get("host", "")
        url = f"{scheme}://{host}{path}" if host else path

        if record_metrics:
            from road24_sdk.metrics.http import record_http_request

            record_http_request(
                method=method,
                url=url,
                status_code=status_code,
                duration_seconds=duration_seconds,
                direction=HttpDirection.INPUT,
            )

        req_ct = headers.get("content-type", "")
        resp_ct = response_content_type or req_ct

        http_attrs = HttpAttributes(
            direction=HttpDirection.INPUT,
            method=method,
            url=url,
            target=path,
            status_code=status_code,
            duration_seconds=duration_seconds,
            headers=headers,
            request_body=sanitize_body(request_body)
            if is_loggable_content_type(req_ct)
            else (BINARY_MASK if req_ct else ""),
            response_body=sanitize_body(response_body)
            if is_loggable_content_type(resp_ct)
            else (BINARY_MASK if resp_ct else ""),
            error_class=type(exc).__name__ if exc else "",
            error_message=str(exc) if exc else "",
        )

        log_level = self._get_log_level(status_code)
        getattr(logger, log_level)(
            LogType.HTTP_REQUEST,
            exc_info=exc if exc else None,
            extra=http_attrs.as_dict(),
        )

    def _get_log_level(self, status_code: int) -> str:
        if status_code < HTTPStatus.BAD_REQUEST:
            return "info"
        if status_code < HTTPStatus.INTERNAL_SERVER_ERROR:
            return "warning"
        return "error"
