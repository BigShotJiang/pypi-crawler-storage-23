import logging
import re
import time
from typing import Any

from road24_sdk._schemas import DbAttributes
from road24_sdk._types import DbDirection, DbOperation, LogType

logger = logging.getLogger(__name__)

_START_TIME_KEY = "_query_start_time"


class DbLogger:
    MAX_STATEMENT_LENGTH = 500

    TABLE_PATTERNS = [
        r"FROM\s+([\"']?[\w\.]+[\"']?)",
        r"INTO\s+([\"']?[\w\.]+[\"']?)",
        r"UPDATE\s+([\"']?[\w\.]+[\"']?)",
        r"DELETE\s+FROM\s+([\"']?[\w\.]+[\"']?)",
    ]

    def log_query(
        self,
        operation: DbOperation,
        table: str,
        duration_seconds: float,
        statement: str = "",
        record_metrics: bool = True,
    ) -> None:
        if record_metrics:
            from road24_sdk.metrics.db import record_db_query

            record_db_query(
                operation=operation,
                duration_seconds=duration_seconds,
                direction=DbDirection.SQLALCHEMY,
            )

        db_attrs = DbAttributes(
            direction=DbDirection.SQLALCHEMY,
            operation=operation,
            table=table,
            duration_seconds=duration_seconds,
            statement=statement[: self.MAX_STATEMENT_LENGTH],
        )

        logger.info(LogType.DB_QUERY, extra=db_attrs.as_dict())

    def before_execute(
        self,
        conn: Any,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
    ) -> None:
        conn.info[_START_TIME_KEY] = time.perf_counter()

    def after_execute(
        self,
        conn: Any,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
        record_metrics: bool = True,
    ) -> None:
        start_time = conn.info.pop(_START_TIME_KEY, None)
        duration_seconds = time.perf_counter() - start_time if start_time else 0.0
        operation = self.extract_operation(statement)
        table = self.extract_table(statement)

        self.log_query(
            operation=operation,
            table=table,
            duration_seconds=duration_seconds,
            statement=statement,
            record_metrics=record_metrics,
        )

    def extract_operation(self, statement: str) -> DbOperation:
        statement_upper = statement.strip().upper()

        if statement_upper.startswith("SELECT"):
            return DbOperation.SELECT
        if statement_upper.startswith("INSERT"):
            return DbOperation.INSERT
        if statement_upper.startswith("UPDATE"):
            return DbOperation.UPDATE
        if statement_upper.startswith("DELETE"):
            return DbOperation.DELETE

        return DbOperation.OTHER

    def extract_table(self, statement: str) -> str:
        statement_upper = statement.strip().upper()

        for pattern in self.TABLE_PATTERNS:
            if match := re.search(pattern, statement_upper):
                table = match.group(1).strip("\"'").lower()
                return table.split(".")[-1]

        return "unknown"
