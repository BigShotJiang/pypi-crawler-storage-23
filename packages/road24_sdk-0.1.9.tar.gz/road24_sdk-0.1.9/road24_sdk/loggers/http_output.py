import logging
import time
from http import HTTPStatus
from typing import TYPE_CHECKING
from urllib.parse import urlparse

from road24_sdk._sanitizer import (
    BINARY_MASK,
    is_loggable_content_type,
    sanitize_body,
    sanitize_dict,
)
from road24_sdk._schemas import HttpAttributes
from road24_sdk._types import HttpDirection, LogType

if TYPE_CHECKING:
    from httpx import Request, Response

logger = logging.getLogger(__name__)


class HttpOutputLogger:
    async def log_request_hook(self, request: "Request") -> None:
        request.extensions["start_time"] = time.perf_counter()

    async def log_response_hook(self, response: "Response") -> None:
        await response.aread()
        start_time = response.request.extensions.get("start_time")
        duration_seconds = time.perf_counter() - start_time if start_time else 0.0
        self.log(response.request, response, duration_seconds)

    def log(
        self,
        request: "Request",
        response: "Response",
        duration_seconds: float,
        record_metrics: bool = True,
    ) -> None:
        parsed = urlparse(str(request.url))
        url = str(request.url)
        headers = sanitize_dict(dict(request.headers))

        if record_metrics:
            from road24_sdk.metrics.http import record_http_request

            record_http_request(
                method=request.method,
                url=url,
                status_code=response.status_code,
                duration_seconds=duration_seconds,
                direction=HttpDirection.OUTPUT,
            )

        req_content_type = headers.get("content-type", "")
        resp_content_type = response.headers.get("content-type", "")

        if is_loggable_content_type(req_content_type):
            request_body = sanitize_body(
                request.content.decode(errors="replace") if request.content else ""
            )
        else:
            request_body = BINARY_MASK if req_content_type else ""

        if is_loggable_content_type(resp_content_type):
            response_body = sanitize_body(self._read_response_body(response))
        else:
            response_body = BINARY_MASK if resp_content_type else ""

        http_attrs = HttpAttributes(
            direction=HttpDirection.OUTPUT,
            method=request.method,
            url=url,
            target=parsed.path,
            status_code=response.status_code,
            duration_seconds=duration_seconds,
            headers=headers,
            request_body=request_body,
            response_body=response_body,
        )

        log_level = self._get_log_level(response.status_code)
        getattr(logger, log_level)(LogType.HTTP_REQUEST, extra=http_attrs.as_dict())

    @staticmethod
    def _read_response_body(response: "Response") -> str:
        try:
            return response.content.decode(errors="replace") if response.content else ""
        except RuntimeError:
            return ""

    def _get_log_level(self, status_code: int) -> str:
        if status_code < HTTPStatus.BAD_REQUEST:
            return "info"
        if status_code < HTTPStatus.INTERNAL_SERVER_ERROR:
            return "warning"
        return "error"
