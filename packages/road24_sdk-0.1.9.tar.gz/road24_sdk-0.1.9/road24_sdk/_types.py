from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


@dataclass(slots=True)
class Road24Config:
    service_name: str = "unknown"
    log_level: str = "INFO"
    debug: bool = False
    log_format: str = "json"
    integrations: list[Any] = field(default_factory=list)


class LogType(StrEnum):
    HTTP_REQUEST = "http_request"
    DB_QUERY = "db_query"
    REDIS_COMMAND = "redis_command"
    MESSAGE = "message"


class HttpDirection(StrEnum):
    INPUT = "input"
    OUTPUT = "output"


class DbDirection(StrEnum):
    SQLALCHEMY = "sqlalchemy"


class RedisDirection(StrEnum):
    REDIS = "redis"


class DbOperation(StrEnum):
    SELECT = "select"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    OTHER = "other"


class FastStreamDirection(StrEnum):
    CONSUME = "consume"
    PUBLISH = "publish"


class BrokerType(StrEnum):
    RABBITMQ = "rabbitmq"
    KAFKA = "kafka"
    NATS = "nats"
    REDIS = "redis"


class RedisOperation(StrEnum):
    GET = "get"
    SET = "set"
    DELETE = "delete"
    EXPIRE = "expire"
    HGET = "hget"
    HSET = "hset"
    LPUSH = "lpush"
    RPUSH = "rpush"
    LPOP = "lpop"
    RPOP = "rpop"
    PUBLISH = "publish"
    SUBSCRIBE = "subscribe"
    OTHER = "other"
