from prometheus_client import Counter, Histogram

from road24_sdk._types import DbDirection, DbOperation

DB_QUERY_DURATION = Histogram(
    name="db_query_duration_seconds",
    documentation="Database query duration in seconds",
    labelnames=["operation", "direction"],
    buckets=(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5),
)

DB_QUERY_TOTAL = Counter(
    name="db_queries_total",
    documentation="Total number of database queries",
    labelnames=["operation", "direction"],
)


def record_db_query(
    operation: DbOperation,
    duration_seconds: float,
    direction: DbDirection = DbDirection.SQLALCHEMY,
) -> None:
    labels = {
        "operation": operation.value,
        "direction": direction.value,
    }
    DB_QUERY_TOTAL.labels(**labels).inc()
    DB_QUERY_DURATION.labels(**labels).observe(duration_seconds)
