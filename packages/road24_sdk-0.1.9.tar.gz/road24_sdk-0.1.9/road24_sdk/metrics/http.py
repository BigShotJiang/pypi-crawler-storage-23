from urllib.parse import urlparse

from prometheus_client import Counter, Histogram

from road24_sdk._types import HttpDirection

HTTP_REQUEST_DURATION = Histogram(
    name="http_request_duration_seconds",
    documentation="HTTP request duration in seconds",
    labelnames=["method", "domain", "status_code", "direction"],
    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
)

HTTP_REQUEST_TOTAL = Counter(
    name="http_requests_total",
    documentation="Total number of HTTP requests",
    labelnames=["method", "domain", "status_code", "direction"],
)


def _extract_domain(url: str) -> str:
    parsed = urlparse(url)
    return parsed.hostname or "unknown"


def record_http_request(
    method: str,
    url: str,
    status_code: int,
    duration_seconds: float,
    direction: HttpDirection,
) -> None:
    labels = {
        "method": method,
        "domain": _extract_domain(url),
        "status_code": str(status_code),
        "direction": direction.value,
    }
    HTTP_REQUEST_TOTAL.labels(**labels).inc()
    HTTP_REQUEST_DURATION.labels(**labels).observe(duration_seconds)
