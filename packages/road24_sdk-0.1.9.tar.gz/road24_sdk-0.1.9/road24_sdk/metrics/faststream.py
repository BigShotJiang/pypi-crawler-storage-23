from prometheus_client import Counter, Histogram

from road24_sdk._types import BrokerType, FastStreamDirection

FASTSTREAM_MESSAGE_DURATION = Histogram(
    name="faststream_message_duration_seconds",
    documentation="FastStream message processing duration in seconds",
    labelnames=["direction", "broker", "queue"],
    buckets=(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5),
)

FASTSTREAM_MESSAGE_TOTAL = Counter(
    name="faststream_messages_total",
    documentation="Total number of FastStream messages",
    labelnames=["direction", "broker", "queue"],
)


def record_faststream_message(
    direction: FastStreamDirection,
    broker: BrokerType,
    queue: str,
    duration_seconds: float,
) -> None:
    labels = {
        "direction": direction.value,
        "broker": broker.value,
        "queue": queue,
    }
    FASTSTREAM_MESSAGE_TOTAL.labels(**labels).inc()
    FASTSTREAM_MESSAGE_DURATION.labels(**labels).observe(duration_seconds)
