import re
from urllib.parse import urlparse

_UUID_PATTERN = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)
_NUMERIC_SEGMENT_PATTERN = re.compile(r"^\d+$")
_HEX_ID_PATTERN = re.compile(r"^[0-9a-fA-F]{16,}$")

_ID_PLACEHOLDER = "{id}"


def normalize_url(url: str) -> str:
    parsed = urlparse(url)
    path = parsed.path or "/"
    normalized_path = _normalize_path(path)
    return normalized_path


def _normalize_path(path: str) -> str:
    if not path or path == "/":
        return "/"

    segments = path.split("/")
    normalized = []
    for segment in segments:
        if not segment:
            normalized.append(segment)
            continue
        if _is_dynamic_segment(segment):
            normalized.append(_ID_PLACEHOLDER)
        else:
            normalized.append(segment)
    return "/".join(normalized)


def _is_dynamic_segment(segment: str) -> bool:
    if _NUMERIC_SEGMENT_PATTERN.match(segment):
        return True
    if _UUID_PATTERN.match(segment):
        return True
    if _HEX_ID_PATTERN.match(segment):
        return True
    return False


def normalize_redis_key(key: str) -> str:
    if not key:
        return key

    parts = key.split(":")
    normalized = []
    for part in parts:
        if _is_dynamic_segment(part):
            normalized.append(_ID_PLACEHOLDER)
        else:
            normalized.append(part)
    return ":".join(normalized)
