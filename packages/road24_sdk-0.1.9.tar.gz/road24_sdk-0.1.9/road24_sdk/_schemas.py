from dataclasses import dataclass, field
from typing import Any

from road24_sdk._types import (
    BrokerType,
    DbDirection,
    DbOperation,
    FastStreamDirection,
    HttpDirection,
    RedisDirection,
    RedisOperation,
)


@dataclass(slots=True)
class LogRecord:
    timestamp: str
    log_level: str
    type: str
    service_name: str
    attributes: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "log_level": self.log_level,
            "type": self.type,
            "service_name": self.service_name,
            "attributes": self.attributes,
        }


@dataclass(slots=True)
class HttpAttributes:
    direction: HttpDirection
    method: str
    url: str
    target: str
    status_code: int
    duration_seconds: float
    headers: dict[str, str] = field(default_factory=dict)
    request_body: str = ""
    response_body: str = ""
    error_class: str = ""
    error_message: str = ""

    def as_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "direction": self.direction.value,
            "method": self.method,
            "url": self.url,
            "target": self.target,
            "status_code": self.status_code,
            "duration_seconds": self.duration_seconds,
            "headers": self.headers,
            "request_body": self.request_body,
            "response_body": self.response_body,
        }
        if self.error_class:
            result["error_class"] = self.error_class
            result["error_message"] = self.error_message
        return result


@dataclass(slots=True)
class DbAttributes:
    direction: DbDirection
    operation: DbOperation
    table: str
    duration_seconds: float
    statement: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "direction": self.direction.value,
            "operation": self.operation.value,
            "table": self.table,
            "duration_seconds": self.duration_seconds,
            "statement": self.statement,
        }


@dataclass(slots=True)
class FastStreamAttributes:
    direction: FastStreamDirection
    broker: BrokerType
    queue: str
    duration_seconds: float
    message_body: str = ""
    exchange: str = ""
    routing_key: str = ""
    error_class: str = ""
    error_message: str = ""

    def as_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "direction": self.direction.value,
            "broker": self.broker.value,
            "queue": self.queue,
            "duration_seconds": self.duration_seconds,
            "message_body": self.message_body,
        }
        if self.exchange:
            result["exchange"] = self.exchange
        if self.routing_key:
            result["routing_key"] = self.routing_key
        if self.error_class:
            result["error_class"] = self.error_class
            result["error_message"] = self.error_message
        return result


@dataclass(slots=True)
class RedisAttributes:
    direction: RedisDirection
    operation: RedisOperation
    key: str
    duration_seconds: float
    command_args: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "direction": self.direction.value,
            "operation": self.operation.value,
            "key": self.key,
            "duration_seconds": self.duration_seconds,
            "command_args": self.command_args,
        }
