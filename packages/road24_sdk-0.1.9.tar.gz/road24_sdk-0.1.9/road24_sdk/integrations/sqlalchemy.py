from typing import Any

from road24_sdk.integrations._base import Integration
from road24_sdk.loggers.db import DbLogger


class SqlalchemyLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics
        self._db_logger = DbLogger()

    def setup_once(self) -> None:
        if self._mark_setup_once():
            return
        from sqlalchemy import event
        from sqlalchemy.engine import Engine

        event.listen(Engine, "before_cursor_execute", self._db_logger.before_execute)

        if self._enable_logging:
            enable_metrics = self._enable_metrics
            db_logger = self._db_logger

            event.listen(
                Engine,
                "after_cursor_execute",
                lambda conn, cursor, stmt, params, ctx, many: (
                    db_logger.after_execute(
                        conn,
                        cursor,
                        stmt,
                        params,
                        ctx,
                        many,
                        record_metrics=enable_metrics,
                    )
                ),
            )

    def setup(self, engine: Any) -> None:
        from sqlalchemy import event

        sync_engine = getattr(engine, "sync_engine", engine)

        event.listen(
            sync_engine,
            "before_cursor_execute",
            self._db_logger.before_execute,
        )

        if self._enable_logging:
            event.listen(
                sync_engine,
                "after_cursor_execute",
                lambda conn, cursor, stmt, params, ctx, many: (
                    self._db_logger.after_execute(
                        conn,
                        cursor,
                        stmt,
                        params,
                        ctx,
                        many,
                        record_metrics=self._enable_metrics,
                    )
                ),
            )
