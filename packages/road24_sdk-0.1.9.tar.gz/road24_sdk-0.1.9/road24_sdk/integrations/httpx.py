from typing import TYPE_CHECKING, Any

from road24_sdk.integrations._base import Integration
from road24_sdk.loggers.http_output import HttpOutputLogger

if TYPE_CHECKING:
    from httpx import AsyncClient

logger = None


class HttpxLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics
        self._output_logger = HttpOutputLogger()

    def setup_once(self) -> None:
        if self._mark_setup_once():
            return
        from httpx import AsyncClient

        original_init = AsyncClient.__init__
        output_logger = self._output_logger
        enable_logging = self._enable_logging

        def _patched_init(
            self_client: "AsyncClient", *args: Any, **kwargs: Any
        ) -> None:
            original_init(self_client, *args, **kwargs)
            if enable_logging:
                hooks = self_client.event_hooks
                hooks["request"].append(output_logger.log_request_hook)
                hooks["response"].append(output_logger.log_response_hook)

        AsyncClient.__init__ = _patched_init  # type: ignore[method-assign]

    def setup(self, client: "AsyncClient") -> None:
        if self._enable_logging:
            hooks = client.event_hooks
            hooks["request"].append(self._output_logger.log_request_hook)
            hooks["response"].append(self._output_logger.log_response_hook)

    def create_client(self, **kwargs: Any) -> "AsyncClient":
        from httpx import AsyncClient

        event_hooks: dict[str, list[Any]] = kwargs.pop(
            "event_hooks", {"request": [], "response": []}
        )

        if self._enable_logging:
            event_hooks["request"].append(self._output_logger.log_request_hook)
            event_hooks["response"].append(self._output_logger.log_response_hook)

        return AsyncClient(event_hooks=event_hooks, **kwargs)
