import json
import logging
import time
from contextvars import ContextVar
from http import HTTPStatus
from typing import TYPE_CHECKING, Any

from road24_sdk.integrations._base import Integration
from road24_sdk.loggers.http_input import HttpInputLogger

if TYPE_CHECKING:
    from starlette.types import ASGIApp, Message, Receive, Scope, Send

logger = logging.getLogger(__name__)

_request_exception: ContextVar[Exception | None] = ContextVar(
    "request_exception", default=None
)


async def _http_exception_handler(request: Any, exc: Any) -> Any:
    from fastapi.responses import JSONResponse

    if exc.status_code >= HTTPStatus.INTERNAL_SERVER_ERROR:
        _request_exception.set(exc)

    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
        headers=getattr(exc, "headers", None),
    )


async def _validation_exception_handler(request: Any, exc: Any) -> Any:
    from fastapi.responses import JSONResponse

    _request_exception.set(exc)

    errors = exc.errors()
    for error in errors:
        if "input" in error and isinstance(error["input"], bytes):
            error["input"] = error["input"].decode(errors="replace")

    return JSONResponse(
        status_code=HTTPStatus.UNPROCESSABLE_ENTITY.value,
        content={"detail": errors},
    )


async def _general_exception_handler(request: Any, exc: Exception) -> Any:
    from fastapi.responses import JSONResponse

    _request_exception.set(exc)

    return JSONResponse(
        status_code=HTTPStatus.INTERNAL_SERVER_ERROR.value,
        content={
            "detail": "Internal server error",
            "error_type": type(exc).__name__,
        },
    )


class _LogMiddleware:
    def __init__(
        self,
        app: "ASGIApp",
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
    ) -> None:
        self.app = app
        self._http_logger = HttpInputLogger()
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics

    async def __call__(
        self,
        scope: "Scope",
        receive: "Receive",
        send: "Send",
    ) -> None:
        path = scope.get("path", "")
        if scope["type"] != "http" or any(
            s in path for s in ("/metrics", "/redoc", "/docs", "/openapi.json")
        ):
            await self.app(scope, receive, send)
            return

        status_code = 500
        start_time = time.perf_counter()
        request_body_chunks: list[bytes] = []
        response_body_chunks: list[bytes] = []
        response_content_type = ""

        async def receive_wrapper() -> "Message":
            message = await receive()
            if message.get("type") == "http.request":
                request_body_chunks.append(message.get("body", b""))
            return message

        async def send_wrapper(message: "Message") -> None:
            nonlocal status_code, response_content_type
            if message["type"] == "http.response.start":
                status_code = message["status"]
                resp_headers = {
                    k.decode(): v.decode() for k, v in message.get("headers", [])
                }
                response_content_type = resp_headers.get("content-type", "")
            elif message["type"] == "http.response.body":
                response_body_chunks.append(message.get("body", b""))
            await send(message)

        try:
            await self.app(scope, receive_wrapper, send_wrapper)
        except Exception as e:
            _request_exception.set(e)
            status_code = HTTPStatus.INTERNAL_SERVER_ERROR
            error_body = json.dumps(
                {
                    "detail": "Internal server error",
                    "error_type": type(e).__name__,
                }
            ).encode()
            await send(
                {
                    "type": "http.response.start",
                    "status": status_code,
                    "headers": [
                        (b"content-type", b"application/json"),
                    ],
                }
            )
            await send({"type": "http.response.body", "body": error_body})
            response_body_chunks.append(error_body)
            response_content_type = "application/json"
        finally:
            exc = _request_exception.get()
            _request_exception.set(None)
            duration_seconds = time.perf_counter() - start_time
            if self._enable_logging:
                self._http_logger.log(
                    scope=scope,
                    status_code=status_code,
                    duration_seconds=duration_seconds,
                    record_metrics=self._enable_metrics,
                    exc=exc,
                    request_body=b"".join(request_body_chunks).decode(errors="replace"),
                    response_body=b"".join(response_body_chunks).decode(
                        errors="replace"
                    ),
                    response_content_type=response_content_type,
                )


class FastApiLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
        enable_exception_handlers: bool = True,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics
        self._enable_exception_handlers = enable_exception_handlers

    def setup_once(self) -> None:
        pass

    def setup(self, app: "ASGIApp") -> None:
        if self._enable_exception_handlers and self._is_fastapi_app(app):
            self._register_exception_handlers(app)

        app.add_middleware(
            _LogMiddleware,
            enable_logging=self._enable_logging,
            enable_metrics=self._enable_metrics,
        )

    @staticmethod
    def _is_fastapi_app(app: Any) -> bool:
        try:
            from starlette.applications import Starlette
        except ImportError:
            return False
        return isinstance(app, Starlette)

    def _register_exception_handlers(self, app: Any) -> None:
        from fastapi import HTTPException
        from fastapi.exceptions import RequestValidationError

        app.add_exception_handler(HTTPException, _http_exception_handler)
        app.add_exception_handler(RequestValidationError, _validation_exception_handler)
        app.add_exception_handler(Exception, _general_exception_handler)
