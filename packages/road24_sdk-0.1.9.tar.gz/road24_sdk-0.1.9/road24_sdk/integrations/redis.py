import time
from typing import TYPE_CHECKING, Any

from road24_sdk._types import RedisOperation
from road24_sdk.integrations._base import Integration
from road24_sdk.loggers.redis import OPERATION_MAP, LoggedRedis, RedisLogger

if TYPE_CHECKING:
    from redis.asyncio import Redis


class RedisLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics

    def setup_once(self) -> None:
        if self._mark_setup_once():
            return
        from redis.asyncio import Redis

        original_execute = Redis.execute_command
        redis_logger = RedisLogger(record_metrics=self._enable_metrics)
        enable_logging = self._enable_logging

        async def _patched_execute(
            self_client: "Redis",
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            command = str(args[0]).lower() if args else "unknown"
            key = str(args[1]) if len(args) > 1 else ""
            operation = OPERATION_MAP.get(command, RedisOperation.OTHER)
            start_time = time.perf_counter()
            try:
                return await original_execute(self_client, *args, **kwargs)
            finally:
                duration = time.perf_counter() - start_time
                if enable_logging:
                    redis_logger.log(
                        operation=operation,
                        key=key,
                        duration_seconds=duration,
                    )

        Redis.execute_command = _patched_execute  # type: ignore[method-assign]

    def setup(self, client: "Redis") -> None:
        original_execute = client.execute_command
        redis_logger = RedisLogger(record_metrics=self._enable_metrics)
        enable_logging = self._enable_logging

        async def _patched_execute(*args: Any, **kwargs: Any) -> Any:
            command = str(args[0]).lower() if args else "unknown"
            key = str(args[1]) if len(args) > 1 else ""
            operation = OPERATION_MAP.get(command, RedisOperation.OTHER)
            start_time = time.perf_counter()
            try:
                return await original_execute(*args, **kwargs)
            finally:
                duration = time.perf_counter() - start_time
                if enable_logging:
                    redis_logger.log(
                        operation=operation,
                        key=key,
                        duration_seconds=duration,
                    )

        client.execute_command = _patched_execute  # type: ignore[method-assign]

    def instrument(self, client: "Redis") -> LoggedRedis:
        return LoggedRedis(
            client,
            record_metrics=self._enable_metrics,
        )
