import json
import logging
import time
from typing import Any

from road24_sdk._types import BrokerType, FastStreamDirection
from road24_sdk.integrations._base import Integration
from road24_sdk.loggers.faststream import FastStreamLogger

logger = logging.getLogger(__name__)


def _detect_broker_type(broker: Any) -> BrokerType:
    class_name = type(broker).__name__.lower()
    if "rabbit" in class_name:
        return BrokerType.RABBITMQ
    if "kafka" in class_name:
        return BrokerType.KAFKA
    if "nats" in class_name:
        return BrokerType.NATS
    if "redis" in class_name:
        return BrokerType.REDIS
    return BrokerType.RABBITMQ


def _extract_queue(msg: Any) -> str:
    if hasattr(msg, "raw_message"):
        raw = msg.raw_message
        if hasattr(raw, "routing_key"):
            return str(raw.routing_key)
        if hasattr(raw, "topic"):
            return str(raw.topic)
        if hasattr(raw, "subject"):
            return str(raw.subject)
        if hasattr(raw, "channel"):
            return str(raw.channel)
    if hasattr(msg, "path") and hasattr(msg.path, "name"):
        return str(msg.path.name)
    return "unknown"


def _extract_exchange(msg: Any) -> str:
    if hasattr(msg, "raw_message"):
        raw = msg.raw_message
        if hasattr(raw, "exchange"):
            return str(raw.exchange)
    return ""


def _extract_routing_key(msg: Any) -> str:
    if hasattr(msg, "raw_message"):
        raw = msg.raw_message
        if hasattr(raw, "routing_key"):
            return str(raw.routing_key)
    return ""


def _decode_body(msg: Any) -> str:
    try:
        if hasattr(msg, "body"):
            body = msg.body
            if isinstance(body, bytes):
                return body.decode(errors="replace")
            if isinstance(body, dict | list):
                return json.dumps(body, ensure_ascii=False, default=str)
            return str(body)
        if hasattr(msg, "decoded_body"):
            decoded = msg.decoded_body
            if isinstance(decoded, dict | list):
                return json.dumps(decoded, ensure_ascii=False, default=str)
            return str(decoded)
    except Exception:
        logger.debug("Failed to decode message body", exc_info=True)
    return ""


class FastStreamLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
        broker_type: BrokerType | None = None,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics
        self._broker_type = broker_type
        self._faststream_logger = FastStreamLogger(record_metrics=enable_metrics)

    def setup_once(self) -> None:
        pass

    def setup(self, broker: Any) -> None:
        broker.middlewares = (
            *broker.middlewares,
            _LogMiddlewareFactory(
                faststream_logger=self._faststream_logger,
                broker_type=self._broker_type or _detect_broker_type(broker),
                enable_logging=self._enable_logging,
            ),
        )


class _LogMiddlewareFactory:
    def __init__(
        self,
        *,
        faststream_logger: FastStreamLogger,
        broker_type: BrokerType,
        enable_logging: bool,
    ) -> None:
        self._faststream_logger = faststream_logger
        self._broker_type = broker_type
        self._enable_logging = enable_logging

    def __call__(self, msg: Any) -> "_LogMiddleware":
        return _LogMiddleware(
            msg,
            faststream_logger=self._faststream_logger,
            broker_type=self._broker_type,
            enable_logging=self._enable_logging,
        )


class _LogMiddleware:
    def __init__(
        self,
        msg: Any,
        *,
        faststream_logger: FastStreamLogger,
        broker_type: BrokerType,
        enable_logging: bool,
    ) -> None:
        self.msg = msg
        self._faststream_logger = faststream_logger
        self._broker_type = broker_type
        self._enable_logging = enable_logging

    async def on_consume(self, msg: Any) -> Any:
        self._start_time = time.perf_counter()
        return msg

    async def after_consume(self, err: Exception | None) -> None:
        if not self._enable_logging:
            return

        duration = time.perf_counter() - getattr(
            self, "_start_time", time.perf_counter()
        )
        self._faststream_logger.log(
            direction=FastStreamDirection.CONSUME,
            broker=self._broker_type,
            queue=_extract_queue(self.msg),
            duration_seconds=duration,
            message_body=_decode_body(self.msg),
            exchange=_extract_exchange(self.msg),
            routing_key=_extract_routing_key(self.msg),
            exc=err,
        )

    async def on_publish(self, msg: Any, *args: Any, **kwargs: Any) -> Any:
        self._publish_start = time.perf_counter()
        return msg

    async def after_publish(self, err: Exception | None) -> None:
        if not self._enable_logging:
            return

        duration = time.perf_counter() - getattr(
            self, "_publish_start", time.perf_counter()
        )
        queue = ""
        if hasattr(self.msg, "raw_message"):
            queue = _extract_queue(self.msg)

        self._faststream_logger.log(
            direction=FastStreamDirection.PUBLISH,
            broker=self._broker_type,
            queue=queue,
            duration_seconds=duration,
            exc=err,
        )
