import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

from road24_sdk._schemas import LogRecord

STANDARD_RECORD_ATTRS = {
    "name",
    "msg",
    "args",
    "created",
    "filename",
    "funcName",
    "levelname",
    "levelno",
    "lineno",
    "module",
    "msecs",
    "pathname",
    "process",
    "processName",
    "relativeCreated",
    "stack_info",
    "exc_info",
    "exc_text",
    "thread",
    "threadName",
    "taskName",
    "message",
}

_service_name: str = "unknown"

SILENT_LOGGERS_DEBUG = [
    "uvicorn.access",
    "asyncio",
]

SILENT_LOGGERS_PROD = [
    "uvicorn",
    "uvicorn.access",
    "uvicorn.error",
    "uvicorn.asgi",
    "sqlalchemy",
    "sqlalchemy.engine",
    "sqlalchemy.pool",
    "httpx",
    "httpcore",
    "asyncio",
]


class LogFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_record = LogRecord(
            timestamp=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
            log_level=record.levelname,
            type=record.getMessage(),
            service_name=_service_name,
            attributes=self._build_attributes(record),
        )
        return json.dumps(log_record.as_dict(), ensure_ascii=False, default=str)

    def _build_attributes(self, record: logging.LogRecord) -> dict[str, Any]:
        attrs: dict[str, Any] = {
            "logger_name": record.name,
            "code_module": record.module,
            "code_function": record.funcName,
            "code_lineno": record.lineno,
        }

        attrs.update(
            {
                k: v
                for k, v in record.__dict__.items()
                if k not in STANDARD_RECORD_ATTRS and not k.startswith("_")
            }
        )

        if record.exc_info and (exc_type := record.exc_info[0]):
            attrs.update(
                {
                    "exception_type": exc_type.__name__,
                    "exception_message": str(record.exc_info[1]),
                    "exception_stacktrace": self.formatException(record.exc_info),
                }
            )

        return attrs


def setup_logging(
    level: str = "INFO",
    service_name: str = "unknown",
    debug: bool = False,
) -> None:
    global _service_name
    _service_name = service_name

    log_level = getattr(logging, level.upper(), logging.INFO)

    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(LogFormatter())
    handler.setLevel(log_level)
    root_logger.addHandler(handler)

    sdk_logger = logging.getLogger("road24_sdk")
    sdk_logger.setLevel(log_level)

    _silence_libraries(debug, level)


def _silence_libraries(debug: bool, level: str) -> None:
    is_debug = debug or level.upper() == "DEBUG"

    if is_debug:
        loggers = SILENT_LOGGERS_DEBUG
        silence_level = logging.WARNING
    else:
        loggers = SILENT_LOGGERS_PROD
        silence_level = logging.CRITICAL

    for name in loggers:
        lib_logger = logging.getLogger(name)
        lib_logger.setLevel(silence_level)
        lib_logger.propagate = False
