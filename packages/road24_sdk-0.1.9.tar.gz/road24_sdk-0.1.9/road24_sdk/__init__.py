import logging

from road24_sdk._formatter import setup_logging
from road24_sdk._types import (
    BrokerType,
    DbDirection,
    DbOperation,
    FastStreamDirection,
    HttpDirection,
    LogType,
    RedisDirection,
    RedisOperation,
    Road24Config,
)
from road24_sdk.integrations._base import Integration

_config: Road24Config | None = None
_logger = logging.getLogger(__name__)


def init(
    service_name: str = "unknown",
    log_level: str = "INFO",
    debug: bool = False,
    log_format: str = "json",
    integrations: list[Integration] | None = None,
) -> None:
    global _config
    resolved = integrations or []
    _config = Road24Config(
        service_name=service_name,
        log_level=log_level,
        debug=debug,
        log_format=log_format,
        integrations=resolved,
    )
    setup_logging(
        level=log_level,
        service_name=service_name,
        debug=debug,
    )
    for integration in resolved:
        try:
            integration.setup_once()
        except Exception:
            _logger.warning(
                "Failed to setup integration %s",
                type(integration).__name__,
                exc_info=True,
            )


def configure() -> Road24Config:
    if _config is None:
        return Road24Config()
    return _config


__all__ = [
    "FastStreamDirection",
    "BrokerType",
    "Road24Config",
    "DbDirection",
    "DbOperation",
    "HttpDirection",
    "LogType",
    "RedisDirection",
    "RedisOperation",
    "configure",
    "init",
]
