# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**road24-sdk** is a shared Python SDK providing logging and metrics utilities for Road24 microservices. It follows a Sentry SDK-like pattern with framework-specific integrations.

**Stack:** Python 3.12+, dataclasses, prometheus_client

**Dependencies:**
- `prometheus-client` - For Prometheus metrics
- `httpx` - For HTTPX client integration
- `redis` - For Redis client integration
- `sqlalchemy` - For SQLAlchemy database integration

## Architecture

### Module Structure

```
road24_sdk/                   # Main package
├── __init__.py               # Public API: init(), configure(), enums
├── _types.py                 # Road24Config + StrEnum definitions (internal)
├── _schemas.py               # Dataclass schemas for log attributes (internal)
├── _formatter.py             # LogFormatter, setup_logging(), trace context (internal)
├── _sanitizer.py             # Body sanitization utilities (internal)
├── metrics/                  # Prometheus metrics utilities
│   ├── __init__.py           # Public exports
│   ├── http.py               # HTTP request metrics
│   ├── db.py                 # Database query metrics
│   └── redis.py              # Redis command metrics
└── integrations/             # Framework-specific integrations (logging + metrics)
    ├── __init__.py            # Exports all integrations + Integration base
    ├── _base.py              # Integration ABC with setup_once() pattern
    ├── fastapi.py            # FastApiLoggingIntegration + HttpInputLogger
    ├── httpx.py              # HttpxLoggingIntegration + HttpOutputLogger
    ├── sqlalchemy.py         # SqlalchemyLoggingIntegration + DbLogger
    └── redis.py              # RedisLoggingIntegration + RedisLogger + LoggedRedis
```

### Key Patterns

**SDK-like Initialization:** Uses `init()` function similar to Sentry SDK with `integrations=[]` for auto-instrumentation:
```python
import road24_sdk
from road24_sdk.integrations.httpx import HttpxLoggingIntegration
from road24_sdk.integrations.redis import RedisLoggingIntegration

road24_sdk.init(
    service_name="my-service",
    log_level="INFO",
    integrations=[
        HttpxLoggingIntegration(),
        RedisLoggingIntegration(),
    ],
)
```

**Integration Pattern:** All integrations inherit from `Integration` ABC and implement `setup_once()` for class-level patching (called via `init()`) and `.setup(client)` for instance-level patching.
- `setup_once()` patches at class level so all new instances are auto-instrumented.
- `.setup(client)` patches a specific client instance (backwards compatible).
- `FastApiLoggingIntegration` requires `.setup(app)` since it needs the app instance.

**When adding new integrations**, implement both `setup_once()` (class-level patching) and `.setup(client)` (instance-level patching). Inherit from `Integration` ABC.

**Trace Context Propagation:** Uses `ContextVar` for thread-safe trace ID propagation across async operations.

**Metrics Recording:** All operations record both duration (Histogram) and count (Counter) with normalized labels.

## Code Style Requirements

- Full type hints on all functions (Python 3.12+ syntax)
- Use `StrEnum` for all enum definitions
- Use `ContextVar` for request-scoped state (not global variables)
- Use dataclasses with `slots=True` for schemas
- Guard clauses (early returns) over nested conditionals
- Async/await for all async utilities
- No comments except for complex logic
- Keep functions under 20 lines
- Use `TYPE_CHECKING` for optional dependencies

## Testing Guidelines

- All tests must be async (`@pytest.mark.asyncio`)
- Mock all external dependencies (AsyncMock for async, Mock for sync)
- Use fixtures for test data in `tests/conftest.py`
- Use `@pytest.mark.parametrize` with dataclasses for multiple scenarios
- Follow AAA pattern (Arrange-Act-Assert)
- Target >90% coverage
- Test file structure mirrors source structure
