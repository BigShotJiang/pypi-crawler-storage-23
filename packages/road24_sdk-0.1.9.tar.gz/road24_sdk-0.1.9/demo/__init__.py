"""
Shared demo utilities — SDK init, FastAPI app builder, HTTPX client, helpers.

Import these in demo submodules instead of duplicating setup code.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import road24_sdk
from road24_sdk.integrations.fastapi import FastApiLoggingIntegration
from road24_sdk.integrations.httpx import HttpxLoggingIntegration

from starlette.requests import Request

if TYPE_CHECKING:
    from fastapi import FastAPI
    from httpx import AsyncClient


def init_sdk(
    service_name: str = "demo-service",
    log_level: str = "DEBUG",
    *,
    with_httpx: bool = False,
) -> None:
    integrations = []
    if with_httpx:
        integrations.append(HttpxLoggingIntegration(enable_metrics=True))
    road24_sdk.init(
        service_name=service_name,
        log_level=log_level,
        integrations=integrations,
    )


def build_app(*, enable_logging: bool = True, enable_metrics: bool = True) -> "FastAPI":
    from fastapi import FastAPI

    app = FastAPI()
    FastApiLoggingIntegration(
        enable_logging=enable_logging,
        enable_metrics=enable_metrics,
    ).setup(app)

    @app.get("/api/v1/health")
    async def health():
        return {"status": "ok"}

    @app.post("/api/v1/users")
    async def create_user(body: dict):
        return {"id": 1, **body}

    @app.post("/api/v1/upload")
    async def upload(request: Request):
        return {"received_bytes": len(await request.body())}

    @app.get("/api/v1/error")
    async def error_route():
        raise RuntimeError("Something went wrong")

    return app


def make_client(app: "FastAPI") -> "AsyncClient":
    from httpx import ASGITransport, AsyncClient

    return AsyncClient(transport=ASGITransport(app=app), base_url="http://demo")


def sep(title: str) -> None:
    print(f"\n{'=' * 60}\n  {title}\n{'=' * 60}\n")


def dump_metrics(filter_key: str) -> None:
    from prometheus_client import generate_latest

    sep("Prometheus metrics")
    output = generate_latest().decode()
    for line in output.splitlines():
        if filter_key in line and not line.startswith("#"):
            print(line)
