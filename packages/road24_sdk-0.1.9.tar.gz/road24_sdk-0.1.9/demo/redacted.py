"""
Demo: Redacted cases — sensitive fields/headers sanitized across all modules.

Run: python -m demo.redacted
"""

from __future__ import annotations

import asyncio

from demo import build_app, dump_metrics, init_sdk, make_client, sep
from road24_sdk._types import FastStreamDirection, BrokerType
from road24_sdk.integrations.httpx import HttpxLoggingIntegration
from road24_sdk.loggers.faststream import FastStreamLogger


async def main() -> None:
    init_sdk(service_name="demo-redacted")
    app = build_app()
    input_client = make_client(app)

    output_app = build_app(enable_logging=False)
    output_client = make_client(output_app)
    HttpxLoggingIntegration(enable_metrics=True).setup(output_client)

    sep("HTTP INPUT — sensitive body fields redacted")
    await input_client.post(
        "/api/v1/users",
        json={"name": "Alice", "password": "s3cret", "api_key": "key-123", "token": "abc"},
    )

    sep("HTTP INPUT — sensitive headers redacted")
    await input_client.post(
        "/api/v1/users",
        json={"name": "Bob"},
        headers={"authorization": "Bearer my-token", "x-api-key": "secret-key"},
    )

    sep("HTTP INPUT — large body truncated")
    await input_client.post("/api/v1/users", json={"payload": "x" * 15_000})

    sep("HTTP OUTPUT — sensitive body fields redacted")
    await output_client.post(
        "/api/v1/users",
        json={"name": "Alice", "password": "s3cret", "api_key": "key-123", "token": "abc"},
    )

    sep("HTTP OUTPUT — sensitive headers redacted")
    await output_client.post(
        "/api/v1/users",
        json={"name": "Bob"},
        headers={"authorization": "Bearer my-token", "x-api-key": "secret-key"},
    )

    sep("HTTP OUTPUT — large body truncated")
    await output_client.post("/api/v1/users", json={"payload": "x" * 15_000})

    faststream_logger = FastStreamLogger(record_metrics=True)

    sep("FASTSTREAM — sensitive fields in message body redacted")
    faststream_logger.log(
        direction=FastStreamDirection.CONSUME,
        broker=BrokerType.RABBITMQ,
        queue="users.created",
        duration_seconds=0.030,
        message_body='{"user_id": 1, "name": "Alice", "password": "s3cret", "token": "abc-123"}',
        exchange="users",
        routing_key="users.created",
    )

    await input_client.aclose()
    await output_client.aclose()

    dump_metrics("http_request")
    dump_metrics("faststream_message")


if __name__ == "__main__":
    asyncio.run(main())
