"""
Demo: Binary redacted cases — binary content-type bodies masked across all modules.

Run: python -m demo.binary_redacted
"""

from __future__ import annotations

import asyncio

from demo import build_app, dump_metrics, init_sdk, make_client, sep
from road24_sdk.integrations.httpx import HttpxLoggingIntegration


async def main() -> None:
    init_sdk(service_name="demo-binary-redacted")
    app = build_app()
    input_client = make_client(app)

    output_app = build_app(enable_logging=False)
    output_client = make_client(output_app)
    HttpxLoggingIntegration(enable_metrics=True).setup(output_client)

    sep("HTTP INPUT — binary content-type (request body redacted)")
    await input_client.post(
        "/api/v1/upload",
        content=b"\x89PNG\r\n\x1a\n",
        headers={"content-type": "image/png"},
    )

    sep("HTTP OUTPUT — binary content-type (request body redacted)")
    await output_client.post(
        "/api/v1/upload",
        content=b"\x89PNG\r\n\x1a\n",
        headers={"content-type": "image/png"},
    )

    await input_client.aclose()
    await output_client.aclose()

    dump_metrics("http_request")


if __name__ == "__main__":
    asyncio.run(main())
