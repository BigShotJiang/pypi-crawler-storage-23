"""
Demo: OK cases — successful requests across all modules.

Run: python -m demo.ok
"""

from __future__ import annotations

import asyncio

from demo import build_app, dump_metrics, init_sdk, make_client, sep
from road24_sdk._types import FastStreamDirection, BrokerType, DbOperation, RedisOperation
from road24_sdk.integrations.httpx import HttpxLoggingIntegration
from road24_sdk.loggers.faststream import FastStreamLogger
from road24_sdk.loggers.db import DbLogger
from road24_sdk.loggers.redis import RedisLogger


async def main() -> None:
    init_sdk(service_name="demo-ok")
    app = build_app()
    input_client = make_client(app)

    output_app = build_app(enable_logging=False)
    output_client = make_client(output_app)
    HttpxLoggingIntegration(enable_metrics=True).setup(output_client)

    db_logger = DbLogger()
    redis_logger = RedisLogger(record_metrics=True)
    faststream_logger = FastStreamLogger(record_metrics=True)

    sep("HTTP INPUT — GET 200")
    await input_client.get("/api/v1/health")

    sep("HTTP INPUT — POST 200")
    await input_client.post("/api/v1/users", json={"name": "Alice"})

    sep("HTTP OUTPUT — GET 200")
    await output_client.get("/api/v1/health")

    sep("HTTP OUTPUT — POST 200")
    await output_client.post("/api/v1/users", json={"name": "Bob"})

    sep("DB — SELECT")
    db_logger.log_query(
        operation=DbOperation.SELECT,
        table="users",
        duration_seconds=0.023,
        statement="SELECT id, name, email FROM users WHERE id = 42",
    )

    sep("DB — INSERT")
    db_logger.log_query(
        operation=DbOperation.INSERT,
        table="orders",
        duration_seconds=0.008,
        statement="INSERT INTO orders (user_id, amount) VALUES (42, 100.50)",
    )

    sep("REDIS — GET")
    redis_logger.log(operation=RedisOperation.GET, key="user:42:profile", duration_seconds=0.001)

    sep("REDIS — SET")
    redis_logger.log(
        operation=RedisOperation.SET,
        key="session:abc123",
        duration_seconds=0.002,
        args="value=<data>, ex=3600",
    )

    sep("FASTSTREAM — CONSUME")
    faststream_logger.log(
        direction=FastStreamDirection.CONSUME,
        broker=BrokerType.RABBITMQ,
        queue="orders.created",
        duration_seconds=0.045,
        message_body='{"order_id": 42, "amount": 100.50}',
        exchange="orders",
        routing_key="orders.created",
    )

    sep("FASTSTREAM — PUBLISH")
    faststream_logger.log(
        direction=FastStreamDirection.PUBLISH,
        broker=BrokerType.RABBITMQ,
        queue="notifications.send",
        duration_seconds=0.012,
        message_body='{"user_id": 42, "type": "order_confirmed"}',
    )

    await input_client.aclose()
    await output_client.aclose()

    dump_metrics("http_request")
    dump_metrics("db_query")
    dump_metrics("redis_command")
    dump_metrics("faststream_message")


if __name__ == "__main__":
    asyncio.run(main())
