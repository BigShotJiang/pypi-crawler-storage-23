"""
Demo: Error cases — exceptions and error responses across all modules.

Run: python -m demo.error
"""

from __future__ import annotations

import asyncio

from demo import build_app, dump_metrics, init_sdk, make_client, sep
from road24_sdk._types import FastStreamDirection, BrokerType
from road24_sdk.integrations.httpx import HttpxLoggingIntegration
from road24_sdk.loggers.faststream import FastStreamLogger


async def main() -> None:
    init_sdk(service_name="demo-error")
    app = build_app()
    input_client = make_client(app)

    output_app = build_app(enable_logging=False)
    output_client = make_client(output_app)
    HttpxLoggingIntegration(enable_metrics=True).setup(output_client)

    sep("HTTP INPUT — 500 unhandled exception")
    await input_client.get("/api/v1/error")

    sep("HTTP INPUT — 422 validation error (binary to JSON endpoint)")
    await input_client.post(
        "/api/v1/users",
        content=b"not-json",
        headers={"content-type": "application/json"},
    )

    sep("HTTP OUTPUT — 500 from upstream")
    await output_client.get("/api/v1/error")

    faststream_logger = FastStreamLogger(record_metrics=True)

    sep("FASTSTREAM — error during message processing")
    faststream_logger.log(
        direction=FastStreamDirection.CONSUME,
        broker=BrokerType.RABBITMQ,
        queue="orders.created",
        duration_seconds=0.150,
        message_body='{"order_id": 99}',
        exchange="orders",
        routing_key="orders.created",
        exc=RuntimeError("Database connection failed"),
    )

    await input_client.aclose()
    await output_client.aclose()

    dump_metrics("http_request")
    dump_metrics("faststream_message")


if __name__ == "__main__":
    asyncio.run(main())
