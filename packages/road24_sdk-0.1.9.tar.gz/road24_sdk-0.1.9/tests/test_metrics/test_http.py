from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import Mock, patch

import pytest

from road24_sdk._types import HttpDirection
from road24_sdk.metrics.http import (
    record_http_request,
)


@dataclass
class HttpMetricTestCase:
    test_id: str
    method: str
    url: str
    expected_domain: str
    status_code: int
    duration_seconds: float
    direction: HttpDirection


HTTP_METRIC_CASES = [
    HttpMetricTestCase(
        test_id="get_200_input",
        method="GET",
        url="https://example.com/api/v1/users",
        expected_domain="example.com",
        status_code=200,
        duration_seconds=0.05,
        direction=HttpDirection.INPUT,
    ),
    HttpMetricTestCase(
        test_id="post_201_output",
        method="POST",
        url="https://orders.svc/api/v1/orders",
        expected_domain="orders.svc",
        status_code=201,
        duration_seconds=0.15,
        direction=HttpDirection.OUTPUT,
    ),
    HttpMetricTestCase(
        test_id="delete_404_input",
        method="DELETE",
        url="https://items.local/api/v1/items/999",
        expected_domain="items.local",
        status_code=404,
        duration_seconds=0.02,
        direction=HttpDirection.INPUT,
    ),
    HttpMetricTestCase(
        test_id="put_500_output",
        method="PUT",
        url="https://settings.svc/api/v1/settings",
        expected_domain="settings.svc",
        status_code=500,
        duration_seconds=1.5,
        direction=HttpDirection.OUTPUT,
    ),
]


@pytest.mark.parametrize(
    "test_case",
    HTTP_METRIC_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_record_http_request_updates_counter(
    test_case: HttpMetricTestCase,
) -> None:
    """Test that record_http_request increments the counter metric."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()

    # Act
    with patch("road24_sdk.metrics.http.HTTP_REQUEST_TOTAL", mock_counter):
        record_http_request(
            method=test_case.method,
            url=test_case.url,
            status_code=test_case.status_code,
            duration_seconds=test_case.duration_seconds,
            direction=test_case.direction,
        )

    # Assert
    expected_labels = {
        "method": test_case.method,
        "domain": test_case.expected_domain,
        "status_code": str(test_case.status_code),
        "direction": test_case.direction.value,
    }
    (
        mock_counter.labels.assert_called_once_with(**expected_labels),
        "Counter should be called with correct labels",
    )
    (
        mock_counter.labels.return_value.inc.assert_called_once(),
        ("Counter inc() should be called exactly once"),
    )


@pytest.mark.parametrize(
    "test_case",
    HTTP_METRIC_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_record_http_request_updates_histogram(
    test_case: HttpMetricTestCase,
) -> None:
    """Test that record_http_request observes the histogram metric."""
    # Arrange
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with patch("road24_sdk.metrics.http.HTTP_REQUEST_DURATION", mock_histogram):
        record_http_request(
            method=test_case.method,
            url=test_case.url,
            status_code=test_case.status_code,
            duration_seconds=test_case.duration_seconds,
            direction=test_case.direction,
        )

    # Assert
    expected_labels = {
        "method": test_case.method,
        "domain": test_case.expected_domain,
        "status_code": str(test_case.status_code),
        "direction": test_case.direction.value,
    }
    (
        mock_histogram.labels.assert_called_once_with(**expected_labels),
        "Histogram should be called with correct labels",
    )
    (
        mock_histogram.labels.return_value.observe.assert_called_once_with(
            test_case.duration_seconds
        ),
        "Histogram observe() should be called with duration",
    )


async def test_record_http_request_status_code_converted_to_string() -> None:
    """Test that status_code is converted to string in labels."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with (
        patch("road24_sdk.metrics.http.HTTP_REQUEST_TOTAL", mock_counter),
        patch("road24_sdk.metrics.http.HTTP_REQUEST_DURATION", mock_histogram),
    ):
        record_http_request(
            method="GET",
            url="https://example.com/test",
            status_code=200,
            duration_seconds=0.1,
            direction=HttpDirection.INPUT,
        )

    # Assert
    counter_call_kwargs = mock_counter.labels.call_args.kwargs
    assert counter_call_kwargs["status_code"] == "200", (
        "status_code label should be a string"
    )
    histogram_call_kwargs = mock_histogram.labels.call_args.kwargs
    assert histogram_call_kwargs["status_code"] == "200", (
        "status_code label should be a string in histogram"
    )


async def test_record_http_request_direction_uses_enum_value() -> None:
    """Test that direction label uses the enum .value string."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with (
        patch("road24_sdk.metrics.http.HTTP_REQUEST_TOTAL", mock_counter),
        patch("road24_sdk.metrics.http.HTTP_REQUEST_DURATION", mock_histogram),
    ):
        record_http_request(
            method="POST",
            url="https://api.example.com/api",
            status_code=201,
            duration_seconds=0.5,
            direction=HttpDirection.OUTPUT,
        )

    # Assert
    counter_call_kwargs = mock_counter.labels.call_args.kwargs
    assert counter_call_kwargs["direction"] == "output", (
        "Direction label should use enum value string"
    )


async def test_record_http_request_extracts_domain() -> None:
    """Test that domain is extracted from the URL."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()

    # Act
    with patch("road24_sdk.metrics.http.HTTP_REQUEST_TOTAL", mock_counter):
        record_http_request(
            method="GET",
            url="https://my-service.local/api/v1/data",
            status_code=200,
            duration_seconds=0.1,
            direction=HttpDirection.INPUT,
        )

    # Assert
    counter_call_kwargs = mock_counter.labels.call_args.kwargs
    assert counter_call_kwargs["domain"] == "my-service.local"


async def test_record_http_request_unknown_domain_for_path_only() -> None:
    """Test that domain is 'unknown' when URL has no host."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()

    # Act
    with patch("road24_sdk.metrics.http.HTTP_REQUEST_TOTAL", mock_counter):
        record_http_request(
            method="GET",
            url="/api/v1/data",
            status_code=200,
            duration_seconds=0.1,
            direction=HttpDirection.INPUT,
        )

    # Assert
    counter_call_kwargs = mock_counter.labels.call_args.kwargs
    assert counter_call_kwargs["domain"] == "unknown"
