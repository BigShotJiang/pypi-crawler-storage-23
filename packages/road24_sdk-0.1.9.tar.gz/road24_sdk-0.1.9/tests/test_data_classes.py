from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


@dataclass
class EnumTestCase:
    test_id: str
    enum_class: type[StrEnum]
    expected_values: set[str]


@dataclass
class EnumMemberTestCase:
    test_id: str
    enum_class: type[StrEnum]
    member_name: str
    expected_value: str


@dataclass
class ConfigTestCase:
    test_id: str
    description: str
    kwargs: dict[str, object]
    expected_service_name: str
    expected_log_level: str
    expected_debug: bool
    expected_log_format: str


@dataclass
class SensitiveKeyTestCase:
    test_id: str
    key: str
    expected_sensitive: bool


@dataclass
class SanitizeDictTestCase:
    test_id: str
    description: str
    input_data: dict[str, object]
    expected_output: dict[str, object]


@dataclass
class SanitizeBodyTestCase:
    test_id: str
    description: str
    input_body: str
    expected_output: str


@dataclass
class DbOperationTestCase:
    test_id: str
    statement: str
    expected_operation: str


@dataclass
class DbTableTestCase:
    test_id: str
    statement: str
    expected_table: str


@dataclass
class HttpLogLevelTestCase:
    test_id: str
    status_code: int
    expected_level: str


@dataclass
class RedisOperationMapTestCase:
    test_id: str
    command: str
    expected_operation: str
