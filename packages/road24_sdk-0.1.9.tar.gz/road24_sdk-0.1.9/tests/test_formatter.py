from __future__ import annotations

import json
import logging
from typing import Any

import pytest

from road24_sdk._formatter import (
    SILENT_LOGGERS_DEBUG,
    SILENT_LOGGERS_PROD,
    LogFormatter,
    setup_logging,
)


class TestLogFormatter:
    async def test_format_produces_valid_json(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=10,
            msg="test message",
            args=None,
            exc_info=None,
        )

        # Act
        result = formatter.format(record)

        # Assert
        parsed = json.loads(result)
        assert isinstance(parsed, dict), "Format output should be valid JSON"

    async def test_format_contains_expected_fields(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test.logger",
            level=logging.WARNING,
            pathname="test.py",
            lineno=42,
            msg="warning message",
            args=None,
            exc_info=None,
        )

        # Act
        result = formatter.format(record)
        parsed = json.loads(result)

        # Assert
        assert "timestamp" in parsed, "Should contain timestamp"
        assert "trace_id" not in parsed, "Should not contain trace_id"
        assert parsed["log_level"] == "WARNING", "Log level should be WARNING"
        assert parsed["type"] == "warning message", "Type should be the message"

    async def test_build_attributes_includes_standard_info(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="my.logger",
            level=logging.INFO,
            pathname="mymodule.py",
            lineno=99,
            msg="msg",
            args=None,
            exc_info=None,
        )

        # Act
        attrs = formatter._build_attributes(record)

        # Assert
        assert attrs["logger_name"] == "my.logger", "Should include logger name"
        assert attrs["code_lineno"] == 99, "Should include line number"
        assert "code_function" in attrs, "Should include function name key"

    async def test_build_attributes_includes_extra_fields(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="msg",
            args=None,
            exc_info=None,
        )
        record.custom_field = "custom_value"

        # Act
        attrs = formatter._build_attributes(record)

        # Assert
        assert attrs["custom_field"] == "custom_value", (
            "Should include extra fields from log record"
        )

    async def test_build_attributes_includes_exception_info(self) -> None:
        # Arrange
        formatter = LogFormatter()
        try:
            raise ValueError("test error")
        except ValueError:
            import sys

            exc_info = sys.exc_info()

        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=1,
            msg="error",
            args=None,
            exc_info=exc_info,
        )

        # Act
        attrs = formatter._build_attributes(record)

        # Assert
        assert attrs["exception_type"] == "ValueError", "Should include exception type"
        assert attrs["exception_message"] == "test error", (
            "Should include exception message"
        )
        assert "exception_stacktrace" in attrs, "Should include exception stacktrace"

    async def test_format_timestamp_format(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="msg",
            args=None,
            exc_info=None,
        )

        # Act
        result = formatter.format(record)
        parsed = json.loads(result)

        # Assert
        ts = parsed["timestamp"]
        assert ts.endswith("Z"), "Timestamp should end with Z"
        assert "T" in ts, "Timestamp should contain T separator"


class TestSetupLogging:
    async def test_setup_logging_sets_service_name(self) -> None:
        # Arrange & Act
        setup_logging(level="INFO", service_name="test-service")

        # Assert
        from road24_sdk import _formatter as formatter_mod

        assert formatter_mod._service_name == "test-service", "Service name should be set"

    async def test_setup_logging_sets_root_handler(self) -> None:
        # Arrange & Act
        setup_logging(level="INFO", service_name="test-service")

        # Assert
        root_logger = logging.getLogger()
        assert len(root_logger.handlers) == 1, "Should have exactly one handler"
        assert isinstance(root_logger.handlers[0].formatter, LogFormatter), (
            "Handler should use LogFormatter"
        )

    @pytest.mark.parametrize(
        "level,expected_level",
        [
            ("DEBUG", logging.DEBUG),
            ("INFO", logging.INFO),
            ("WARNING", logging.WARNING),
            ("ERROR", logging.ERROR),
        ],
        ids=["debug", "info", "warning", "error"],
    )
    async def test_setup_logging_sets_level(
        self, level: str, expected_level: int
    ) -> None:
        # Arrange & Act
        setup_logging(level=level, service_name="test")

        # Assert
        root_logger = logging.getLogger()
        assert root_logger.level == expected_level, f"Root logger level should be {level}"

    async def test_setup_logging_debug_silences_fewer_loggers(self) -> None:
        # Arrange & Act
        setup_logging(level="DEBUG", service_name="test", debug=True)

        # Assert
        for name in SILENT_LOGGERS_DEBUG:
            lib_logger = logging.getLogger(name)
            assert lib_logger.level == logging.WARNING, (
                f"Logger '{name}' should be silenced to WARNING in debug mode"
            )

    async def test_setup_logging_prod_silences_more_loggers(self) -> None:
        # Arrange & Act
        setup_logging(level="INFO", service_name="test", debug=False)

        # Assert
        for name in SILENT_LOGGERS_PROD:
            lib_logger = logging.getLogger(name)
            assert lib_logger.level == logging.CRITICAL, (
                f"Logger '{name}' should be silenced to CRITICAL in prod mode"
            )

    async def test_setup_logging_clears_existing_handlers(self) -> None:
        # Arrange
        root_logger = logging.getLogger()
        root_logger.addHandler(logging.StreamHandler())
        root_logger.addHandler(logging.StreamHandler())

        # Act
        setup_logging(level="INFO", service_name="test")

        # Assert
        assert len(root_logger.handlers) == 1, (
            "Should clear existing handlers and add one"
        )
