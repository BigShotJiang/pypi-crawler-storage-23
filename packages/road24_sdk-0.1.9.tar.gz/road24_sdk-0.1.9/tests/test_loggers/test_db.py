from __future__ import annotations

from unittest.mock import Mock, patch

import pytest

from road24_sdk._types import DbDirection, DbOperation, LogType
from road24_sdk.loggers.db import DbLogger
from tests.test_data_classes import DbOperationTestCase, DbTableTestCase

OPERATION_CASES = [
    DbOperationTestCase(
        test_id="select", statement="SELECT * FROM users", expected_operation="select"
    ),
    DbOperationTestCase(
        test_id="insert",
        statement="INSERT INTO users (name) VALUES ('test')",
        expected_operation="insert",
    ),
    DbOperationTestCase(
        test_id="update",
        statement="UPDATE users SET name='test'",
        expected_operation="update",
    ),
    DbOperationTestCase(
        test_id="delete",
        statement="DELETE FROM users WHERE id=1",
        expected_operation="delete",
    ),
    DbOperationTestCase(
        test_id="other_create",
        statement="CREATE TABLE users (id INT)",
        expected_operation="other",
    ),
    DbOperationTestCase(
        test_id="select_lowercase",
        statement="select * from users",
        expected_operation="select",
    ),
    DbOperationTestCase(
        test_id="select_with_whitespace",
        statement="  SELECT * FROM users",
        expected_operation="select",
    ),
]

TABLE_CASES = [
    DbTableTestCase(
        test_id="select_from",
        statement="SELECT * FROM users WHERE id=1",
        expected_table="users",
    ),
    DbTableTestCase(
        test_id="insert_into",
        statement="INSERT INTO orders (user_id) VALUES (1)",
        expected_table="orders",
    ),
    DbTableTestCase(
        test_id="update_table",
        statement="UPDATE products SET price=10",
        expected_table="products",
    ),
    DbTableTestCase(
        test_id="delete_from",
        statement="DELETE FROM sessions WHERE expired=true",
        expected_table="sessions",
    ),
    DbTableTestCase(
        test_id="schema_qualified",
        statement="SELECT * FROM public.users",
        expected_table="users",
    ),
    DbTableTestCase(
        test_id="quoted_table", statement='SELECT * FROM "Users"', expected_table="users"
    ),
    DbTableTestCase(
        test_id="unknown_table",
        statement="CREATE INDEX idx ON users (name)",
        expected_table="unknown",
    ),
]


class TestDbLoggerExtractOperation:
    @pytest.mark.parametrize("test_case", OPERATION_CASES, ids=lambda tc: tc.test_id)
    async def test_extract_operation(self, test_case: DbOperationTestCase) -> None:
        db_logger = DbLogger()
        result = db_logger.extract_operation(test_case.statement)
        assert result.value == test_case.expected_operation


class TestDbLoggerExtractTable:
    @pytest.mark.parametrize("test_case", TABLE_CASES, ids=lambda tc: tc.test_id)
    async def test_extract_table(self, test_case: DbTableTestCase) -> None:
        db_logger = DbLogger()
        result = db_logger.extract_table(test_case.statement)
        assert result == test_case.expected_table


class TestDbLoggerLogQuery:
    async def test_log_query_records_metrics(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.loggers.db.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query") as mock_record,
        ):
            db_logger.log_query(
                operation=DbOperation.SELECT,
                table="users",
                duration_seconds=0.05,
                statement="SELECT * FROM users",
            )
            mock_record.assert_called_once_with(
                operation=DbOperation.SELECT,
                duration_seconds=0.05,
                direction=DbDirection.SQLALCHEMY,
            )

    async def test_log_query_skips_metrics_when_disabled(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.loggers.db.logger"),
            patch("road24_sdk.metrics.db.record_db_query") as mock_record,
        ):
            db_logger.log_query(
                operation=DbOperation.SELECT,
                table="users",
                duration_seconds=0.05,
                record_metrics=False,
            )
            mock_record.assert_not_called()

    async def test_log_query_logs_info(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.loggers.db.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            db_logger.log_query(
                operation=DbOperation.INSERT,
                table="orders",
                duration_seconds=0.1,
                statement="INSERT INTO orders (id) VALUES (1)",
            )
            mock_logger.info.assert_called_once()
            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.DB_QUERY

    async def test_log_query_includes_attributes(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.loggers.db.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            db_logger.log_query(
                operation=DbOperation.UPDATE,
                table="products",
                duration_seconds=0.2,
                statement="UPDATE products SET price=10",
            )
            extra = mock_logger.info.call_args[1]["extra"]
            assert extra["direction"] == "sqlalchemy"
            assert extra["operation"] == "update"
            assert extra["table"] == "products"
            assert extra["duration_seconds"] == 0.2

    async def test_log_query_truncates_long_statements(self) -> None:
        db_logger = DbLogger()
        long_statement = "SELECT " + "x" * 600
        with (
            patch("road24_sdk.loggers.db.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            db_logger.log_query(
                operation=DbOperation.SELECT,
                table="users",
                duration_seconds=0.01,
                statement=long_statement,
            )
            extra = mock_logger.info.call_args[1]["extra"]
            assert len(extra["statement"]) <= DbLogger.MAX_STATEMENT_LENGTH


class TestDbLoggerBeforeExecute:
    async def test_before_execute_stores_start_time(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {}
        db_logger.before_execute(
            conn=conn,
            cursor=Mock(),
            statement="SELECT 1",
            parameters=None,
            context=None,
            executemany=False,
        )
        assert "_query_start_time" in conn.info
        assert isinstance(conn.info["_query_start_time"], float)


class TestDbLoggerAfterExecute:
    async def test_after_execute_calls_log_query(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {"_query_start_time": 100.0}
        with (
            patch.object(db_logger, "log_query") as mock_log_query,
            patch("time.perf_counter", return_value=100.5),
        ):
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT * FROM users",
                parameters=None,
                context=None,
                executemany=False,
            )
            mock_log_query.assert_called_once()
            call_kwargs = mock_log_query.call_args[1]
            assert call_kwargs["operation"] == DbOperation.SELECT
            assert call_kwargs["table"] == "users"
            assert abs(call_kwargs["duration_seconds"] - 0.5) < 0.01

    async def test_after_execute_zero_duration_when_no_start_time(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {}
        with patch.object(db_logger, "log_query") as mock_log_query:
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT 1",
                parameters=None,
                context=None,
                executemany=False,
            )
            call_kwargs = mock_log_query.call_args[1]
            assert call_kwargs["duration_seconds"] == 0.0

    async def test_after_execute_removes_start_time_from_conn(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {"_query_start_time": 100.0}
        with patch.object(db_logger, "log_query"):
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT 1",
                parameters=None,
                context=None,
                executemany=False,
            )
            assert "_query_start_time" not in conn.info

    async def test_after_execute_passes_record_metrics(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {}
        with patch.object(db_logger, "log_query") as mock_log_query:
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT 1",
                parameters=None,
                context=None,
                executemany=False,
                record_metrics=False,
            )
            call_kwargs = mock_log_query.call_args[1]
            assert call_kwargs["record_metrics"] is False
