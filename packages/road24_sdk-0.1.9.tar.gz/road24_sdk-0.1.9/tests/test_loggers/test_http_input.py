from __future__ import annotations

from typing import Any
from unittest.mock import patch

import pytest

from road24_sdk._types import HttpDirection, LogType
from road24_sdk.loggers.http_input import HttpInputLogger
from tests.test_data_classes import HttpLogLevelTestCase

LOG_LEVEL_CASES = [
    HttpLogLevelTestCase(test_id="info_200", status_code=200, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_201", status_code=201, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_301", status_code=301, expected_level="info"),
    HttpLogLevelTestCase(
        test_id="warning_400", status_code=400, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_404", status_code=404, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_422", status_code=422, expected_level="warning"
    ),
    HttpLogLevelTestCase(test_id="error_500", status_code=500, expected_level="error"),
    HttpLogLevelTestCase(test_id="error_503", status_code=503, expected_level="error"),
]


class TestHttpInputLogger:
    async def test_log_records_metrics(self, mock_scope: dict[str, Any]) -> None:
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
            )

            mock_record.assert_called_once_with(
                method="GET",
                url="https://example.com/api/v1/test",
                status_code=200,
                duration_seconds=0.1,
                direction=HttpDirection.INPUT,
            )

    async def test_log_skips_metrics_when_disabled(
        self, mock_scope: dict[str, Any]
    ) -> None:
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
                record_metrics=False,
            )

            mock_record.assert_not_called()

    async def test_log_server_error_without_exception(
        self, mock_scope: dict[str, Any]
    ) -> None:
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            input_logger.log(
                scope=mock_scope,
                status_code=500,
                duration_seconds=0.1,
            )

            mock_logger.error.assert_called_once()
            call_args = mock_logger.error.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST
            extra = call_args[1]["extra"]
            assert extra["status_code"] == 500
            assert "error_class" not in extra
            assert "error_message" not in extra

    async def test_log_server_error_with_exception(
        self, mock_scope: dict[str, Any]
    ) -> None:
        input_logger = HttpInputLogger()
        exc = ValueError("something broke")

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            input_logger.log(
                scope=mock_scope,
                status_code=500,
                duration_seconds=0.1,
                exc=exc,
            )

            mock_logger.error.assert_called_once()
            call_args = mock_logger.error.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST
            assert call_args[1]["exc_info"] is exc
            extra = call_args[1]["extra"]
            assert extra["status_code"] == 500
            assert extra["error_class"] == "ValueError"
            assert extra["error_message"] == "something broke"

    async def test_log_success_does_not_include_error_fields(
        self, mock_scope: dict[str, Any]
    ) -> None:
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
            )

            extra = mock_logger.info.call_args[1]["extra"]
            assert "error_class" not in extra
            assert "error_message" not in extra

    async def test_log_success_logs_info(self, mock_scope: dict[str, Any]) -> None:
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
            )

            mock_logger.info.assert_called_once()
            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST

    async def test_log_client_error_logs_warning(
        self, mock_scope: dict[str, Any]
    ) -> None:
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            input_logger.log(
                scope=mock_scope,
                status_code=404,
                duration_seconds=0.1,
            )

            mock_logger.warning.assert_called_once()

    async def test_log_constructs_url_from_scope(self) -> None:
        input_logger = HttpInputLogger()
        scope = {
            "method": "POST",
            "path": "/api/v1/items",
            "scheme": "http",
            "headers": [(b"host", b"localhost:8000")],
        }

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            input_logger.log(
                scope=scope,
                status_code=201,
                duration_seconds=0.05,
            )

            call_args = mock_logger.info.call_args
            extra = call_args[1]["extra"]
            assert extra["url"] == "http://localhost:8000/api/v1/items"

    async def test_log_url_fallback_to_path_when_no_host(self) -> None:
        input_logger = HttpInputLogger()
        scope = {
            "method": "GET",
            "path": "/health",
            "scheme": "http",
            "headers": [],
        }

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            input_logger.log(
                scope=scope,
                status_code=200,
                duration_seconds=0.01,
            )

            call_args = mock_logger.info.call_args
            extra = call_args[1]["extra"]
            assert extra["url"] == "/health"

    @pytest.mark.parametrize(
        "test_case",
        LOG_LEVEL_CASES,
        ids=lambda tc: tc.test_id,
    )
    async def test_get_log_level(self, test_case: HttpLogLevelTestCase) -> None:
        input_logger = HttpInputLogger()
        result = input_logger._get_log_level(test_case.status_code)
        assert result == test_case.expected_level
