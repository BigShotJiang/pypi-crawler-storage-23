from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from road24_sdk._types import LogType, RedisDirection, RedisOperation
from road24_sdk.loggers.redis import OPERATION_MAP, LoggedRedis, RedisLogger
from tests.test_data_classes import RedisOperationMapTestCase

OPERATION_MAP_CASES = [
    RedisOperationMapTestCase(test_id="get", command="get", expected_operation="get"),
    RedisOperationMapTestCase(test_id="set", command="set", expected_operation="set"),
    RedisOperationMapTestCase(
        test_id="delete", command="delete", expected_operation="delete"
    ),
    RedisOperationMapTestCase(test_id="del", command="del", expected_operation="delete"),
    RedisOperationMapTestCase(
        test_id="expire", command="expire", expected_operation="expire"
    ),
    RedisOperationMapTestCase(test_id="hget", command="hget", expected_operation="hget"),
    RedisOperationMapTestCase(test_id="hset", command="hset", expected_operation="hset"),
    RedisOperationMapTestCase(
        test_id="lpush", command="lpush", expected_operation="lpush"
    ),
    RedisOperationMapTestCase(
        test_id="rpush", command="rpush", expected_operation="rpush"
    ),
    RedisOperationMapTestCase(test_id="lpop", command="lpop", expected_operation="lpop"),
    RedisOperationMapTestCase(test_id="rpop", command="rpop", expected_operation="rpop"),
    RedisOperationMapTestCase(
        test_id="publish", command="publish", expected_operation="publish"
    ),
    RedisOperationMapTestCase(
        test_id="subscribe", command="subscribe", expected_operation="subscribe"
    ),
]


class TestOperationMap:
    @pytest.mark.parametrize("test_case", OPERATION_MAP_CASES, ids=lambda tc: tc.test_id)
    async def test_operation_map_values(
        self, test_case: RedisOperationMapTestCase
    ) -> None:
        result = OPERATION_MAP[test_case.command]
        assert result.value == test_case.expected_operation

    async def test_operation_map_completeness(self) -> None:
        expected_commands = {
            "get",
            "set",
            "delete",
            "del",
            "expire",
            "hget",
            "hset",
            "lpush",
            "rpush",
            "lpop",
            "rpop",
            "publish",
            "subscribe",
        }
        actual_commands = set(OPERATION_MAP.keys())
        assert actual_commands == expected_commands


class TestRedisLogger:
    async def test_log_records_metrics(self, faker: Any) -> None:
        redis_logger = RedisLogger(record_metrics=True)
        key = faker.pystr(min_chars=5, max_chars=15)
        with (
            patch("road24_sdk.loggers.redis.logger") as mock_logger,
            patch("road24_sdk.metrics.redis.record_redis_command") as mock_record,
        ):
            redis_logger.log(operation=RedisOperation.GET, key=key, duration_seconds=0.01)
            mock_record.assert_called_once_with(
                operation=RedisOperation.GET,
                duration_seconds=0.01,
                direction=RedisDirection.REDIS,
            )

    async def test_log_skips_metrics_when_disabled(self, faker: Any) -> None:
        redis_logger = RedisLogger(record_metrics=False)
        with (
            patch("road24_sdk.loggers.redis.logger"),
            patch("road24_sdk.metrics.redis.record_redis_command") as mock_record,
        ):
            redis_logger.log(
                operation=RedisOperation.GET, key="test:key", duration_seconds=0.01
            )
            mock_record.assert_not_called()

    async def test_log_logs_info(self) -> None:
        redis_logger = RedisLogger(record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger") as mock_logger:
            redis_logger.log(
                operation=RedisOperation.SET,
                key="test:key",
                duration_seconds=0.02,
                args="value=hello",
            )
            mock_logger.info.assert_called_once()
            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.REDIS_COMMAND

    async def test_log_includes_attributes(self) -> None:
        redis_logger = RedisLogger(record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger") as mock_logger:
            redis_logger.log(
                operation=RedisOperation.HSET,
                key="user:123",
                duration_seconds=0.03,
                args="field=name",
            )
            extra = mock_logger.info.call_args[1]["extra"]
            assert extra["direction"] == "redis"
            assert extra["operation"] == "hset"
            assert extra["key"] == "user:123"
            assert extra["command_args"] == "field=name"


class TestLoggedRedis:
    async def test_get(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.get("test:key")
            mock_redis_client.get.assert_awaited_once_with("test:key")
            assert result == b"value"

    async def test_set_basic(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.set("test:key", "hello")
            mock_redis_client.set.assert_awaited_once_with("test:key", "hello")
            assert result is True

    async def test_set_with_expiry(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.set("test:key", "hello", ex=300)
            mock_redis_client.set.assert_awaited_once_with("test:key", "hello", ex=300)

    async def test_set_with_nx(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.set("test:key", "hello", nx=True)
            mock_redis_client.set.assert_awaited_once_with("test:key", "hello", nx=True)

    async def test_set_with_px(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.set("test:key", "val", px=5000)
            mock_redis_client.set.assert_awaited_once_with("test:key", "val", px=5000)

    async def test_set_with_xx(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.set("test:key", "val", xx=True)
            mock_redis_client.set.assert_awaited_once_with("test:key", "val", xx=True)

    async def test_delete(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.delete("key1")
            mock_redis_client.delete.assert_awaited_once_with("key1", "key1")
            assert result == 1

    async def test_delete_multiple_keys(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.delete("key1", "key2", "key3")
            mock_redis_client.delete.assert_awaited_once_with(
                "key1", "key1", "key2", "key3"
            )

    async def test_expire(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.expire("test:key", 300)
            mock_redis_client.expire.assert_awaited_once_with("test:key", 300)
            assert result is True

    async def test_hget(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.hget("hash:key", "field1")
            mock_redis_client.hget.assert_awaited_once_with("hash:key", "field1")

    async def test_hset_with_key_value(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.hset("hash:key", "field1", "value1")
            mock_redis_client.hset.assert_awaited_once_with(
                "hash:key", "field1", "value1", mapping=None
            )

    async def test_hset_with_mapping(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        mapping = {"f1": "v1", "f2": "v2"}
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.hset("hash:key", mapping=mapping)
            mock_redis_client.hset.assert_awaited_once_with(
                "hash:key", None, None, mapping=mapping
            )

    async def test_lpush(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.lpush("list:key", "a", "b")
            mock_redis_client.lpush.assert_awaited_once_with("list:key", "a", "b")

    async def test_rpush(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.rpush("list:key", "x")
            mock_redis_client.rpush.assert_awaited_once_with("list:key", "x")

    async def test_lpop(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.lpop("list:key")
            mock_redis_client.lpop.assert_awaited_once_with("list:key", count=None)

    async def test_lpop_with_count(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.lpop("list:key", count=5)
            mock_redis_client.lpop.assert_awaited_once_with("list:key", count=5)

    async def test_rpop(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.rpop("list:key")
            mock_redis_client.rpop.assert_awaited_once_with("list:key", count=None)

    async def test_ping(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        result = await logged.ping()
        mock_redis_client.ping.assert_awaited_once()
        assert result is True

    async def test_aclose(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        await logged.aclose()
        mock_redis_client.aclose.assert_awaited_once()

    async def test_execute_logs_after_command(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger") as mock_logger:
            await logged.get("test:key")
            mock_logger.info.assert_called_once()
            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.REDIS_COMMAND
            extra = call_args[1]["extra"]
            assert extra["operation"] == "get"
            assert extra["key"] == "test:key"

    async def test_execute_logs_even_on_error(self, mock_redis_client: AsyncMock) -> None:
        mock_redis_client.get = AsyncMock(side_effect=ConnectionError("connection lost"))
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger") as mock_logger:
            with pytest.raises(ConnectionError, match="connection lost"):
                await logged.get("test:key")
            mock_logger.info.assert_called_once()

    async def test_execute_records_metrics_when_enabled(
        self, mock_redis_client: AsyncMock
    ) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=True)
        with (
            patch("road24_sdk.loggers.redis.logger"),
            patch("road24_sdk.metrics.redis.record_redis_command") as mock_record,
        ):
            await logged.get("test:key")
            mock_record.assert_called_once()
            call_kwargs = mock_record.call_args[1]
            assert call_kwargs["operation"] == RedisOperation.GET

    async def test_execute_unknown_command_maps_to_other(
        self, mock_redis_client: AsyncMock
    ) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        mock_redis_client.unknown_cmd = AsyncMock(return_value="ok")
        with patch("road24_sdk.loggers.redis.logger") as mock_logger:
            await logged._execute("unknown_cmd", "key")
            extra = mock_logger.info.call_args[1]["extra"]
            assert extra["operation"] == "other"

    async def test_delete_with_no_keys(self, mock_redis_client: AsyncMock) -> None:
        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        with patch("road24_sdk.loggers.redis.logger"):
            await logged.delete()
            mock_redis_client.delete.assert_awaited_once_with("unknown")
