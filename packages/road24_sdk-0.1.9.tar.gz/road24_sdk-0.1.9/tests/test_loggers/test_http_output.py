from __future__ import annotations

from unittest.mock import Mock, patch

import pytest

from road24_sdk._types import HttpDirection, LogType
from road24_sdk.loggers.http_output import HttpOutputLogger
from tests.test_data_classes import HttpLogLevelTestCase

LOG_LEVEL_CASES = [
    HttpLogLevelTestCase(test_id="info_200", status_code=200, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_201", status_code=201, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_301", status_code=301, expected_level="info"),
    HttpLogLevelTestCase(
        test_id="warning_400", status_code=400, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_404", status_code=404, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_422", status_code=422, expected_level="warning"
    ),
    HttpLogLevelTestCase(test_id="error_500", status_code=500, expected_level="error"),
    HttpLogLevelTestCase(test_id="error_503", status_code=503, expected_level="error"),
]


class TestHttpOutputLogger:
    async def test_log_request_hook_sets_start_time(
        self, mock_httpx_request: Mock
    ) -> None:
        output_logger = HttpOutputLogger()
        await output_logger.log_request_hook(mock_httpx_request)

        assert "start_time" in mock_httpx_request.extensions
        assert isinstance(mock_httpx_request.extensions["start_time"], float)

    async def test_log_response_hook_calls_log(
        self, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()

        with (
            patch.object(output_logger, "log") as mock_log,
            patch("time.perf_counter", return_value=1000.5),
        ):
            await output_logger.log_response_hook(mock_httpx_response)
            mock_log.assert_called_once()

    async def test_log_response_hook_calculates_duration(
        self, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()
        mock_httpx_response.request.extensions = {"start_time": 100.0}

        with (
            patch.object(output_logger, "log") as mock_log,
            patch("time.perf_counter", return_value=100.5),
        ):
            await output_logger.log_response_hook(mock_httpx_response)

            call_args = mock_log.call_args
            duration = call_args[0][2]
            assert abs(duration - 0.5) < 0.01

    async def test_log_records_metrics(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.2,
            )

            mock_record.assert_called_once_with(
                method="POST",
                url="https://api.example.com/v1/data",
                status_code=200,
                duration_seconds=0.2,
                direction=HttpDirection.OUTPUT,
            )

    async def test_log_skips_metrics_when_disabled(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()

        with (
            patch("road24_sdk.loggers.http_output.logger"),
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.2,
                record_metrics=False,
            )

            mock_record.assert_not_called()

    async def test_log_success_logs_info(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()
        mock_httpx_response.status_code = 200

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.1,
            )

            mock_logger.info.assert_called_once()

    async def test_log_client_error_logs_warning(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()
        mock_httpx_response.status_code = 404

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.1,
            )

            mock_logger.warning.assert_called_once()

    async def test_log_server_error_logs_error(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()
        mock_httpx_response.status_code = 500

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.1,
            )

            mock_logger.error.assert_called_once()

    async def test_log_includes_http_attributes(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.3,
            )

            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST
            extra = call_args[1]["extra"]
            assert extra["direction"] == "output"
            assert extra["method"] == "POST"

    @pytest.mark.parametrize(
        "test_case",
        LOG_LEVEL_CASES,
        ids=lambda tc: tc.test_id,
    )
    async def test_get_log_level(self, test_case: HttpLogLevelTestCase) -> None:
        output_logger = HttpOutputLogger()
        result = output_logger._get_log_level(test_case.status_code)
        assert result == test_case.expected_level

    async def test_log_response_hook_zero_duration_when_no_start_time(
        self, mock_httpx_response: Mock
    ) -> None:
        output_logger = HttpOutputLogger()
        mock_httpx_response.request.extensions = {}

        with patch.object(output_logger, "log") as mock_log:
            await output_logger.log_response_hook(mock_httpx_response)

            call_args = mock_log.call_args
            duration = call_args[0][2]
            assert duration == 0.0
