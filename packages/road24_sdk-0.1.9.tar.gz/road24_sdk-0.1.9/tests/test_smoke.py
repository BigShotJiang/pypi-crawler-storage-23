"""
Smoke tests — verify all logging and metrics modules work without real services.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, Mock, patch

import pytest

from road24_sdk._types import (
    BrokerType,
    DbOperation,
    FastStreamDirection,
    HttpDirection,
    RedisOperation,
)


class TestHttpInputSmoke:
    async def test_log_200_produces_info(self) -> None:
        from road24_sdk.loggers.http_input import HttpInputLogger

        scope = {
            "method": "GET",
            "path": "/api/v1/health",
            "scheme": "http",
            "headers": [(b"host", b"localhost")],
        }

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_log,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            HttpInputLogger().log(scope=scope, status_code=200, duration_seconds=0.01)

        mock_log.info.assert_called_once()
        extra = mock_log.info.call_args[1]["extra"]
        assert extra["direction"] == "input"
        assert extra["method"] == "GET"
        assert extra["status_code"] == 200

    async def test_log_500_produces_error(self) -> None:
        from road24_sdk.loggers.http_input import HttpInputLogger

        scope = {
            "method": "GET",
            "path": "/err",
            "scheme": "http",
            "headers": [],
        }

        with (
            patch("road24_sdk.loggers.http_input.logger") as mock_log,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            HttpInputLogger().log(
                scope=scope,
                status_code=500,
                duration_seconds=0.1,
                exc=RuntimeError("boom"),
            )

        mock_log.error.assert_called_once()
        extra = mock_log.error.call_args[1]["extra"]
        assert extra["error_class"] == "RuntimeError"


class TestHttpOutputSmoke:
    async def test_log_produces_output_direction(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        from road24_sdk.loggers.http_output import HttpOutputLogger

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_log,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            HttpOutputLogger().log(mock_httpx_request, mock_httpx_response, 0.05)

        mock_log.info.assert_called_once()
        extra = mock_log.info.call_args[1]["extra"]
        assert extra["direction"] == "output"
        assert extra["method"] == "POST"

    async def test_response_hook_reads_body(self) -> None:
        from road24_sdk.loggers.http_output import HttpOutputLogger

        output_logger = HttpOutputLogger()
        request = Mock()
        request.extensions = {"start_time": 1000.0}
        request.method = "GET"
        request.url = "http://example.com/test"
        request.content = b""
        request.headers = {}

        response = Mock()
        response.status_code = 200
        response.content = b'{"ok": true}'
        response.headers = {"content-type": "application/json"}
        response.request = request
        response.aread = AsyncMock()

        with (
            patch("road24_sdk.loggers.http_output.logger"),
            patch("road24_sdk.metrics.http.record_http_request"),
            patch("time.perf_counter", return_value=1000.05),
        ):
            await output_logger.log_response_hook(response)

        response.aread.assert_awaited_once()


class TestDbSmoke:
    async def test_log_query_select(self) -> None:
        from road24_sdk.loggers.db import DbLogger

        with (
            patch("road24_sdk.loggers.db.logger") as mock_log,
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            DbLogger().log_query(
                operation=DbOperation.SELECT,
                table="users",
                duration_seconds=0.01,
                statement="SELECT * FROM users",
            )

        mock_log.info.assert_called_once()
        extra = mock_log.info.call_args[1]["extra"]
        assert extra["operation"] == "select"
        assert extra["table"] == "users"

    async def test_before_after_execute(self) -> None:
        from road24_sdk.loggers.db import DbLogger

        db_logger = DbLogger()
        conn = Mock()
        conn.info = {}

        db_logger.before_execute(conn, None, "SELECT 1", None, None, False)
        assert "_query_start_time" in conn.info

        with (
            patch("road24_sdk.loggers.db.logger"),
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            db_logger.after_execute(conn, None, "SELECT 1", None, None, False)

        assert "_query_start_time" not in conn.info


class TestRedisSmoke:
    async def test_log_get(self) -> None:
        from road24_sdk.loggers.redis import RedisLogger

        with (
            patch("road24_sdk.loggers.redis.logger") as mock_log,
            patch("road24_sdk.metrics.redis.record_redis_command"),
        ):
            RedisLogger().log(
                operation=RedisOperation.GET,
                key="user:42",
                duration_seconds=0.001,
            )

        mock_log.info.assert_called_once()
        extra = mock_log.info.call_args[1]["extra"]
        assert extra["operation"] == "get"
        assert extra["key"] == "user:42"

    async def test_logged_redis_get(self, mock_redis_client: AsyncMock) -> None:
        from road24_sdk.loggers.redis import LoggedRedis

        logged = LoggedRedis(mock_redis_client, record_metrics=False)

        with patch("road24_sdk.loggers.redis.logger"):
            result = await logged.get("key")

        assert result == b"value"
        mock_redis_client.get.assert_awaited_once()

    async def test_logged_redis_set(self, mock_redis_client: AsyncMock) -> None:
        from road24_sdk.loggers.redis import LoggedRedis

        logged = LoggedRedis(mock_redis_client, record_metrics=False)

        with patch("road24_sdk.loggers.redis.logger"):
            await logged.set("k", "v", ex=300)

        mock_redis_client.set.assert_awaited_once()

    async def test_logged_redis_delete(self, mock_redis_client: AsyncMock) -> None:
        from road24_sdk.loggers.redis import LoggedRedis

        logged = LoggedRedis(mock_redis_client, record_metrics=False)

        with patch("road24_sdk.loggers.redis.logger"):
            await logged.delete("k")

        mock_redis_client.delete.assert_awaited_once()

    async def test_logged_redis_hash_ops(self, mock_redis_client: AsyncMock) -> None:
        from road24_sdk.loggers.redis import LoggedRedis

        logged = LoggedRedis(mock_redis_client, record_metrics=False)

        with patch("road24_sdk.loggers.redis.logger"):
            await logged.hget("h", "f")
            await logged.hset("h", "f", "v")

        mock_redis_client.hget.assert_awaited_once()
        mock_redis_client.hset.assert_awaited_once()

    async def test_logged_redis_list_ops(self, mock_redis_client: AsyncMock) -> None:
        from road24_sdk.loggers.redis import LoggedRedis

        logged = LoggedRedis(mock_redis_client, record_metrics=False)

        with patch("road24_sdk.loggers.redis.logger"):
            await logged.lpush("list", "a")
            await logged.rpush("list", "b")
            await logged.lpop("list")
            await logged.rpop("list")

        mock_redis_client.lpush.assert_awaited_once()
        mock_redis_client.rpush.assert_awaited_once()
        mock_redis_client.lpop.assert_awaited_once()
        mock_redis_client.rpop.assert_awaited_once()

    async def test_logged_redis_expire(self, mock_redis_client: AsyncMock) -> None:
        from road24_sdk.loggers.redis import LoggedRedis

        logged = LoggedRedis(mock_redis_client, record_metrics=False)

        with patch("road24_sdk.loggers.redis.logger"):
            await logged.expire("k", 60)

        mock_redis_client.expire.assert_awaited_once()

    async def test_logged_redis_ping_and_close(
        self, mock_redis_client: AsyncMock
    ) -> None:
        from road24_sdk.loggers.redis import LoggedRedis

        logged = LoggedRedis(mock_redis_client, record_metrics=False)
        assert await logged.ping() is True
        await logged.aclose()
        mock_redis_client.aclose.assert_awaited_once()


class TestFastStreamSmoke:
    async def test_log_consume(self) -> None:
        from road24_sdk.loggers.faststream import FastStreamLogger

        with (
            patch("road24_sdk.loggers.faststream.logger") as mock_log,
            patch("road24_sdk.metrics.faststream.record_faststream_message"),
        ):
            FastStreamLogger().log(
                direction=FastStreamDirection.CONSUME,
                broker=BrokerType.RABBITMQ,
                queue="orders.created",
                duration_seconds=0.05,
                message_body='{"order_id": 1}',
            )

        mock_log.info.assert_called_once()
        extra = mock_log.info.call_args[1]["extra"]
        assert extra["direction"] == "consume"
        assert extra["broker"] == "rabbitmq"
        assert extra["queue"] == "orders.created"

    async def test_log_with_error(self) -> None:
        from road24_sdk.loggers.faststream import FastStreamLogger

        with (
            patch("road24_sdk.loggers.faststream.logger") as mock_log,
            patch("road24_sdk.metrics.faststream.record_faststream_message"),
        ):
            FastStreamLogger().log(
                direction=FastStreamDirection.CONSUME,
                broker=BrokerType.KAFKA,
                queue="events",
                duration_seconds=0.1,
                exc=RuntimeError("fail"),
            )

        mock_log.error.assert_called_once()
        extra = mock_log.error.call_args[1]["extra"]
        assert extra["error_class"] == "RuntimeError"

    async def test_log_skips_metrics_when_disabled(self) -> None:
        from road24_sdk.loggers.faststream import FastStreamLogger

        with (
            patch("road24_sdk.loggers.faststream.logger"),
            patch(
                "road24_sdk.metrics.faststream.record_faststream_message"
            ) as mock_record,
        ):
            FastStreamLogger(record_metrics=False).log(
                direction=FastStreamDirection.PUBLISH,
                broker=BrokerType.NATS,
                queue="q",
                duration_seconds=0.01,
            )

        mock_record.assert_not_called()


class TestFastStreamIntegrationSmoke:
    async def test_detect_broker_type(self) -> None:
        from road24_sdk.integrations.faststream import _detect_broker_type

        rabbit = type("RabbitBroker", (), {})()
        kafka = type("KafkaBroker", (), {})()
        nats = type("NatsBroker", (), {})()
        redis = type("RedisBroker", (), {})()
        unknown = type("FooBroker", (), {})()

        assert _detect_broker_type(rabbit) == BrokerType.RABBITMQ
        assert _detect_broker_type(kafka) == BrokerType.KAFKA
        assert _detect_broker_type(nats) == BrokerType.NATS
        assert _detect_broker_type(redis) == BrokerType.REDIS
        assert _detect_broker_type(unknown) == BrokerType.RABBITMQ

    async def test_extract_queue_routing_key(self) -> None:
        from road24_sdk.integrations.faststream import _extract_queue

        msg = Mock()
        msg.raw_message = Mock()
        msg.raw_message.routing_key = "orders.created"

        assert _extract_queue(msg) == "orders.created"

    async def test_extract_queue_topic(self) -> None:
        from road24_sdk.integrations.faststream import _extract_queue

        msg = Mock()
        msg.raw_message = Mock(spec=[])
        msg.raw_message.topic = "events.user"
        del msg.path

        assert _extract_queue(msg) == "events.user"

    async def test_extract_queue_subject(self) -> None:
        from road24_sdk.integrations.faststream import _extract_queue

        msg = Mock()
        msg.raw_message = Mock(spec=[])
        msg.raw_message.subject = "tasks.run"
        del msg.path

        assert _extract_queue(msg) == "tasks.run"

    async def test_extract_queue_channel(self) -> None:
        from road24_sdk.integrations.faststream import _extract_queue

        msg = Mock()
        msg.raw_message = Mock(spec=[])
        msg.raw_message.channel = "ch1"
        del msg.path

        assert _extract_queue(msg) == "ch1"

    async def test_extract_queue_path_name(self) -> None:
        from road24_sdk.integrations.faststream import _extract_queue

        msg = Mock(spec=[])
        msg.path = Mock()
        msg.path.name = "my-queue"

        assert _extract_queue(msg) == "my-queue"

    async def test_extract_queue_unknown(self) -> None:
        from road24_sdk.integrations.faststream import _extract_queue

        msg = Mock(spec=[])
        assert _extract_queue(msg) == "unknown"

    async def test_extract_exchange(self) -> None:
        from road24_sdk.integrations.faststream import _extract_exchange

        msg = Mock()
        msg.raw_message = Mock()
        msg.raw_message.exchange = "orders"
        assert _extract_exchange(msg) == "orders"

        msg_no_exchange = Mock()
        msg_no_exchange.raw_message = Mock(spec=[])
        assert _extract_exchange(msg_no_exchange) == ""

    async def test_extract_routing_key(self) -> None:
        from road24_sdk.integrations.faststream import _extract_routing_key

        msg = Mock()
        msg.raw_message = Mock()
        msg.raw_message.routing_key = "rk"
        assert _extract_routing_key(msg) == "rk"

    async def test_decode_body_bytes(self) -> None:
        from road24_sdk.integrations.faststream import _decode_body

        msg = Mock()
        msg.body = b'{"key": "value"}'
        assert _decode_body(msg) == '{"key": "value"}'

    async def test_decode_body_dict(self) -> None:
        from road24_sdk.integrations.faststream import _decode_body

        msg = Mock()
        msg.body = {"key": "value"}
        assert json.loads(_decode_body(msg)) == {"key": "value"}

    async def test_decode_body_decoded_body(self) -> None:
        from road24_sdk.integrations.faststream import _decode_body

        msg = Mock(spec=[])
        msg.decoded_body = {"k": "v"}
        assert json.loads(_decode_body(msg)) == {"k": "v"}

    async def test_decode_body_decoded_body_str(self) -> None:
        from road24_sdk.integrations.faststream import _decode_body

        msg = Mock(spec=[])
        msg.decoded_body = "hello"
        assert _decode_body(msg) == "hello"

    async def test_decode_body_empty(self) -> None:
        from road24_sdk.integrations.faststream import _decode_body

        msg = Mock(spec=[])
        assert _decode_body(msg) == ""

    async def test_decode_body_exception(self) -> None:
        from road24_sdk.integrations.faststream import _decode_body

        msg = Mock()
        msg.body = property(lambda self: (_ for _ in ()).throw(TypeError("bad")))
        type(msg).body = property(lambda self: (_ for _ in ()).throw(TypeError("bad")))
        assert _decode_body(msg) == ""

    async def test_setup_adds_middleware(self) -> None:
        from road24_sdk.integrations.faststream import FastStreamLoggingIntegration

        broker = Mock()
        broker.middlewares = ()

        FastStreamLoggingIntegration().setup(broker)

        assert len(broker.middlewares) == 1

    async def test_middleware_on_consume_and_after(self) -> None:
        from road24_sdk.integrations.faststream import _LogMiddleware

        msg = Mock()
        msg.raw_message = Mock()
        msg.raw_message.routing_key = "q"
        msg.raw_message.exchange = "ex"
        msg.body = b'{"data": 1}'

        faststream_logger = Mock()
        mw = _LogMiddleware(
            msg,
            faststream_logger=faststream_logger,
            broker_type=BrokerType.RABBITMQ,
            enable_logging=True,
        )

        result = await mw.on_consume(msg)
        assert result is msg

        await mw.after_consume(None)
        faststream_logger.log.assert_called_once()
        call_kwargs = faststream_logger.log.call_args[1]
        assert call_kwargs["direction"] == FastStreamDirection.CONSUME
        assert call_kwargs["queue"] == "q"

    async def test_middleware_after_consume_disabled(self) -> None:
        from road24_sdk.integrations.faststream import _LogMiddleware

        faststream_logger = Mock()
        mw = _LogMiddleware(
            Mock(),
            faststream_logger=faststream_logger,
            broker_type=BrokerType.RABBITMQ,
            enable_logging=False,
        )

        await mw.on_consume(Mock())
        await mw.after_consume(None)
        faststream_logger.log.assert_not_called()

    async def test_middleware_on_publish_and_after(self) -> None:
        from road24_sdk.integrations.faststream import _LogMiddleware

        msg = Mock()
        msg.raw_message = Mock()
        msg.raw_message.routing_key = "pub-q"

        faststream_logger = Mock()
        mw = _LogMiddleware(
            msg,
            faststream_logger=faststream_logger,
            broker_type=BrokerType.KAFKA,
            enable_logging=True,
        )

        result = await mw.on_publish(b"data")
        assert result == b"data"

        await mw.after_publish(None)
        faststream_logger.log.assert_called_once()
        call_kwargs = faststream_logger.log.call_args[1]
        assert call_kwargs["direction"] == FastStreamDirection.PUBLISH

    async def test_middleware_after_publish_disabled(self) -> None:
        from road24_sdk.integrations.faststream import _LogMiddleware

        faststream_logger = Mock()
        mw = _LogMiddleware(
            Mock(),
            faststream_logger=faststream_logger,
            broker_type=BrokerType.RABBITMQ,
            enable_logging=False,
        )

        await mw.on_publish(b"x")
        await mw.after_publish(None)
        faststream_logger.log.assert_not_called()


class TestFastApiIntegrationSmoke:
    async def test_middleware_200_flow(self) -> None:
        from road24_sdk.integrations.fastapi import _LogMiddleware

        scope = {
            "type": "http",
            "method": "GET",
            "path": "/api/test",
            "scheme": "http",
            "headers": [(b"host", b"localhost")],
        }

        async def mock_app(scope: dict, receive: Any, send: Any) -> None:
            await receive()
            await send({"type": "http.response.start", "status": 200, "headers": []})
            await send({"type": "http.response.body", "body": b"ok"})

        receive = AsyncMock(return_value={"type": "http.request", "body": b""})
        send = AsyncMock()

        with patch("road24_sdk.integrations.fastapi.HttpInputLogger") as cls:
            cls.return_value = Mock()
            cls.return_value.log = Mock()
            middleware = _LogMiddleware(mock_app)
            await middleware(scope, receive, send)

        cls.return_value.log.assert_called_once()

    async def test_middleware_skips_non_http(self) -> None:
        from road24_sdk.integrations.fastapi import _LogMiddleware

        mock_app = AsyncMock()
        scope = {"type": "websocket", "path": "/ws", "headers": []}
        middleware = _LogMiddleware(mock_app)
        await middleware(scope, AsyncMock(), AsyncMock())
        mock_app.assert_awaited_once()

    async def test_middleware_skips_docs(self) -> None:
        from road24_sdk.integrations.fastapi import _LogMiddleware

        mock_app = AsyncMock()
        scope = {"type": "http", "path": "/docs", "headers": []}
        middleware = _LogMiddleware(mock_app)
        await middleware(scope, AsyncMock(), AsyncMock())
        mock_app.assert_awaited_once()

    async def test_middleware_handles_exception(self) -> None:
        from road24_sdk.integrations.fastapi import _LogMiddleware

        scope = {
            "type": "http",
            "method": "GET",
            "path": "/err",
            "scheme": "http",
            "headers": [],
        }

        async def failing_app(scope: dict, receive: Any, send: Any) -> None:
            await receive()
            raise RuntimeError("boom")

        sent: list[dict] = []

        async def capture_send(msg: dict) -> None:
            sent.append(msg)

        receive = AsyncMock(return_value={"type": "http.request", "body": b""})

        with patch("road24_sdk.integrations.fastapi.HttpInputLogger") as cls:
            cls.return_value = Mock()
            cls.return_value.log = Mock()
            middleware = _LogMiddleware(failing_app)
            await middleware(scope, receive, capture_send)

        assert sent[0]["status"] == 500
        body = json.loads(sent[1]["body"])
        assert body["error_type"] == "RuntimeError"

    async def test_setup_adds_middleware(self) -> None:
        from road24_sdk.integrations.fastapi import FastApiLoggingIntegration

        mock_app = Mock()
        FastApiLoggingIntegration().setup(mock_app)
        mock_app.add_middleware.assert_called_once()


class TestHttpxIntegrationSmoke:
    async def test_setup_adds_hooks(self) -> None:
        from road24_sdk.integrations.httpx import HttpxLoggingIntegration

        client = Mock()
        client.event_hooks = {"request": [], "response": []}

        HttpxLoggingIntegration().setup(client)

        assert len(client.event_hooks["request"]) == 1
        assert len(client.event_hooks["response"]) == 1

    async def test_setup_disabled_no_hooks(self) -> None:
        from road24_sdk.integrations.httpx import HttpxLoggingIntegration

        client = Mock()
        client.event_hooks = {"request": [], "response": []}

        HttpxLoggingIntegration(enable_logging=False).setup(client)

        assert len(client.event_hooks["request"]) == 0

    async def test_create_client(self) -> None:
        from road24_sdk.integrations.httpx import HttpxLoggingIntegration

        integration = HttpxLoggingIntegration()
        client = integration.create_client(base_url="http://test")
        assert len(client.event_hooks["request"]) == 1
        assert len(client.event_hooks["response"]) == 1
        await client.aclose()


class TestSqlalchemyIntegrationSmoke:
    async def test_setup_listens_events(self) -> None:
        from road24_sdk.integrations.sqlalchemy import SqlalchemyLoggingIntegration

        engine = Mock()
        engine.sync_engine = Mock()

        with patch("sqlalchemy.event.listen") as mock_listen:
            SqlalchemyLoggingIntegration().setup(engine)

        assert mock_listen.call_count == 2


class TestRedisIntegrationSmoke:
    async def test_setup_patches_execute(self) -> None:
        from road24_sdk.integrations.redis import RedisLoggingIntegration

        client = AsyncMock()
        original = client.execute_command

        RedisLoggingIntegration().setup(client)

        assert client.execute_command is not original


class TestMetricsSmoke:
    async def test_http_metrics(self) -> None:
        from road24_sdk.metrics.http import record_http_request

        record_http_request(
            method="GET",
            url="http://example.com/api/v1/test",
            status_code=200,
            duration_seconds=0.01,
            direction=HttpDirection.INPUT,
        )

    async def test_db_metrics(self) -> None:
        from road24_sdk._types import DbDirection
        from road24_sdk.metrics.db import record_db_query

        record_db_query(
            operation=DbOperation.SELECT,
            duration_seconds=0.005,
            direction=DbDirection.SQLALCHEMY,
        )

    async def test_redis_metrics(self) -> None:
        from road24_sdk._types import RedisDirection
        from road24_sdk.metrics.redis import record_redis_command

        record_redis_command(
            operation=RedisOperation.GET,
            duration_seconds=0.001,
            direction=RedisDirection.REDIS,
        )

    async def test_faststream_metrics(self) -> None:
        from road24_sdk.metrics.faststream import record_faststream_message

        record_faststream_message(
            direction=FastStreamDirection.CONSUME,
            broker=BrokerType.RABBITMQ,
            queue="test-q",
            duration_seconds=0.01,
        )


class TestIntegrationBaseSmoke:
    async def test_mark_setup_once_idempotent(self) -> None:
        from road24_sdk.integrations._base import Integration

        class DummyIntegration(Integration):
            def setup_once(self) -> None:
                pass

        DummyIntegration._reset_setup_once()
        assert DummyIntegration._mark_setup_once() is False
        assert DummyIntegration._mark_setup_once() is True
        DummyIntegration._reset_setup_once()


class TestFastApiExceptionHandlersSmoke:
    async def test_http_exception_handler(self) -> None:
        from road24_sdk.integrations.fastapi import _http_exception_handler

        exc = Mock()
        exc.status_code = 404
        exc.detail = "Not found"
        exc.headers = None

        response = await _http_exception_handler(Mock(), exc)
        assert response.status_code == 404
        body = json.loads(response.body)
        assert body["detail"] == "Not found"
        assert "trace_id" not in body

    async def test_http_exception_handler_500(self) -> None:
        from road24_sdk.integrations.fastapi import (
            _http_exception_handler,
            _request_exception,
        )

        exc = Mock()
        exc.status_code = 500
        exc.detail = "Server error"
        exc.headers = None

        await _http_exception_handler(Mock(), exc)
        assert _request_exception.get() is exc
        _request_exception.set(None)

    async def test_validation_exception_handler(self) -> None:
        from road24_sdk.integrations.fastapi import _validation_exception_handler

        exc = Mock()
        exc.errors.return_value = [
            {"type": "missing", "loc": ["body", "name"], "msg": "required"}
        ]

        response = await _validation_exception_handler(Mock(), exc)
        assert response.status_code == 422
        body = json.loads(response.body)
        assert "detail" in body
        assert "trace_id" not in body

    async def test_validation_exception_handler_bytes_input(self) -> None:
        from road24_sdk.integrations.fastapi import _validation_exception_handler

        exc = Mock()
        exc.errors.return_value = [
            {"type": "json_invalid", "input": b"\xff\xfe", "msg": "bad"}
        ]

        response = await _validation_exception_handler(Mock(), exc)
        body = json.loads(response.body)
        assert isinstance(body["detail"][0]["input"], str)

    async def test_general_exception_handler(self) -> None:
        from road24_sdk.integrations.fastapi import _general_exception_handler

        response = await _general_exception_handler(Mock(), RuntimeError("boom"))
        assert response.status_code == 500
        body = json.loads(response.body)
        assert body["error_type"] == "RuntimeError"
        assert "trace_id" not in body

    async def test_setup_registers_exception_handlers(self) -> None:
        from fastapi import FastAPI

        from road24_sdk.integrations.fastapi import FastApiLoggingIntegration

        app = FastAPI()
        FastApiLoggingIntegration(enable_exception_handlers=True).setup(app)

    async def test_setup_skips_exception_handlers(self) -> None:
        from road24_sdk.integrations.fastapi import FastApiLoggingIntegration

        mock_app = Mock()
        FastApiLoggingIntegration(enable_exception_handlers=False).setup(mock_app)
        mock_app.add_exception_handler.assert_not_called()

    async def test_is_fastapi_app_true(self) -> None:
        from fastapi import FastAPI

        from road24_sdk.integrations.fastapi import FastApiLoggingIntegration

        assert FastApiLoggingIntegration._is_fastapi_app(FastAPI()) is True

    async def test_is_fastapi_app_false(self) -> None:
        from road24_sdk.integrations.fastapi import FastApiLoggingIntegration

        assert FastApiLoggingIntegration._is_fastapi_app(Mock()) is False


class TestHttpxSetupOnceSmoke:
    async def test_setup_once_patches_init(self) -> None:
        from httpx import AsyncClient

        from road24_sdk.integrations.httpx import HttpxLoggingIntegration

        integration = HttpxLoggingIntegration()
        HttpxLoggingIntegration._reset_setup_once()

        original_init = AsyncClient.__init__
        try:
            integration.setup_once()
            assert AsyncClient.__init__ is not original_init

            integration.setup_once()
        finally:
            AsyncClient.__init__ = original_init
            HttpxLoggingIntegration._reset_setup_once()


class TestRedisSetupOnceSmoke:
    async def test_setup_once_patches_execute(self) -> None:
        from redis.asyncio import Redis

        from road24_sdk.integrations.redis import RedisLoggingIntegration

        integration = RedisLoggingIntegration()
        RedisLoggingIntegration._reset_setup_once()

        original = Redis.execute_command
        try:
            integration.setup_once()
            assert Redis.execute_command is not original

            integration.setup_once()
        finally:
            Redis.execute_command = original
            RedisLoggingIntegration._reset_setup_once()

    async def test_instrument_returns_logged_redis(self) -> None:
        from road24_sdk.integrations.redis import RedisLoggingIntegration
        from road24_sdk.loggers.redis import LoggedRedis

        client = AsyncMock()
        logged = RedisLoggingIntegration().instrument(client)
        assert isinstance(logged, LoggedRedis)


class TestSqlalchemySetupOnceSmoke:
    async def test_setup_once_listens_events(self) -> None:
        from road24_sdk.integrations.sqlalchemy import SqlalchemyLoggingIntegration

        integration = SqlalchemyLoggingIntegration()
        SqlalchemyLoggingIntegration._reset_setup_once()

        with patch("sqlalchemy.event.listen") as mock_listen:
            integration.setup_once()
            assert mock_listen.call_count == 2

            integration.setup_once()
            assert mock_listen.call_count == 2

        SqlalchemyLoggingIntegration._reset_setup_once()


class TestHttpOutputBinarySmoke:
    async def test_binary_request_body_redacted(self) -> None:
        from road24_sdk.loggers.http_output import HttpOutputLogger

        request = Mock()
        request.method = "POST"
        request.url = "http://example.com/upload"
        request.content = b"\x89PNG..."
        request.headers = {"content-type": "image/png"}

        response = Mock()
        response.status_code = 200
        response.content = b'{"ok": true}'
        response.headers = {"content-type": "application/json"}

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_log,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            HttpOutputLogger().log(request, response, 0.01)

        extra = mock_log.info.call_args[1]["extra"]
        assert extra["request_body"] == "***BINARY-REDACTED***"
        assert "PNG" not in extra["request_body"]

    async def test_binary_response_body_redacted(self) -> None:
        from road24_sdk.loggers.http_output import HttpOutputLogger

        request = Mock()
        request.method = "GET"
        request.url = "http://example.com/file"
        request.content = b""
        request.headers = {}

        response = Mock()
        response.status_code = 200
        response.content = b"\x89PNG..."
        response.headers = {"content-type": "image/png"}

        with (
            patch("road24_sdk.loggers.http_output.logger") as mock_log,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            HttpOutputLogger().log(request, response, 0.01)

        extra = mock_log.info.call_args[1]["extra"]
        assert extra["response_body"] == "***BINARY-REDACTED***"


class TestFastStreamSchemaSmoke:
    async def test_faststream_attributes_as_dict(self) -> None:
        from road24_sdk._schemas import FastStreamAttributes

        attrs = FastStreamAttributes(
            direction=FastStreamDirection.CONSUME,
            broker=BrokerType.RABBITMQ,
            queue="orders",
            duration_seconds=0.05,
            message_body='{"id": 1}',
            exchange="ex",
            routing_key="rk",
        )
        d = attrs.as_dict()
        assert d["direction"] == "consume"
        assert d["exchange"] == "ex"
        assert d["routing_key"] == "rk"

    async def test_faststream_attributes_no_optional(self) -> None:
        from road24_sdk._schemas import FastStreamAttributes

        attrs = FastStreamAttributes(
            direction=FastStreamDirection.PUBLISH,
            broker=BrokerType.KAFKA,
            queue="q",
            duration_seconds=0.01,
        )
        d = attrs.as_dict()
        assert "exchange" not in d
        assert "routing_key" not in d
        assert "error_class" not in d


class TestInitSmoke:
    async def test_init_sets_config(self) -> None:
        import road24_sdk

        road24_sdk.init(service_name="test-smoke", log_level="WARNING")
        config = road24_sdk.configure()
        assert config.service_name == "test-smoke"
        assert config.log_level == "WARNING"

    async def test_init_with_integrations(self) -> None:
        import road24_sdk

        integration = Mock()
        integration.setup_once = Mock()

        road24_sdk.init(
            service_name="test-smoke",
            integrations=[integration],
        )

        integration.setup_once.assert_called_once()

    async def test_init_handles_failing_integration(self) -> None:
        import road24_sdk

        integration = Mock()
        integration.setup_once.side_effect = RuntimeError("setup failed")

        road24_sdk.init(
            service_name="test-smoke",
            integrations=[integration],
        )

        config = road24_sdk.configure()
        assert config.service_name == "test-smoke"
