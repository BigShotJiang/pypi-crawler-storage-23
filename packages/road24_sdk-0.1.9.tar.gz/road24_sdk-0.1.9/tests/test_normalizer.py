from __future__ import annotations

from dataclasses import dataclass

import pytest

from road24_sdk._normalizer import normalize_redis_key, normalize_url


@dataclass
class UrlNormTestCase:
    test_id: str
    input_url: str
    expected: str


URL_CASES = [
    UrlNormTestCase(
        test_id="simple_path",
        input_url="/api/v1/users",
        expected="/api/v1/users",
    ),
    UrlNormTestCase(
        test_id="numeric_id_in_path",
        input_url="/api/v1/users/12345",
        expected="/api/v1/users/{id}",
    ),
    UrlNormTestCase(
        test_id="uuid_in_path",
        input_url="/api/v1/users/550e8400-e29b-41d4-a716-446655440000/docs",
        expected="/api/v1/users/{id}/docs",
    ),
    UrlNormTestCase(
        test_id="full_url_strips_query_params",
        input_url="https://api.example.com/v1/cars/info?pin=12345&transaction_id=abc",
        expected="/v1/cars/info",
    ),
    UrlNormTestCase(
        test_id="full_url_strips_fragment",
        input_url="https://example.com/page#section",
        expected="/page",
    ),
    UrlNormTestCase(
        test_id="multiple_numeric_segments",
        input_url="/api/v1/users/42/orders/999",
        expected="/api/v1/users/{id}/orders/{id}",
    ),
    UrlNormTestCase(
        test_id="hex_id_16_chars",
        input_url="/api/v1/sessions/abc123def456abcd",
        expected="/api/v1/sessions/{id}",
    ),
    UrlNormTestCase(
        test_id="root_path",
        input_url="/",
        expected="/",
    ),
    UrlNormTestCase(
        test_id="empty_string",
        input_url="",
        expected="/",
    ),
    UrlNormTestCase(
        test_id="path_only_url",
        input_url="/health",
        expected="/health",
    ),
    UrlNormTestCase(
        test_id="scheme_host_path",
        input_url="https://example.com/api/v1/test",
        expected="/api/v1/test",
    ),
    UrlNormTestCase(
        test_id="short_hex_not_replaced",
        input_url="/api/v1/items/abc123",
        expected="/api/v1/items/abc123",
    ),
]


@pytest.mark.parametrize("test_case", URL_CASES, ids=lambda tc: tc.test_id)
async def test_normalize_url(test_case: UrlNormTestCase) -> None:
    assert normalize_url(test_case.input_url) == test_case.expected


@dataclass
class RedisKeyNormTestCase:
    test_id: str
    input_key: str
    expected: str


REDIS_KEY_CASES = [
    RedisKeyNormTestCase(
        test_id="static_key",
        input_key="queue:tasks",
        expected="queue:tasks",
    ),
    RedisKeyNormTestCase(
        test_id="numeric_id_segment",
        input_key="user:12345:sessions",
        expected="user:{id}:sessions",
    ),
    RedisKeyNormTestCase(
        test_id="uuid_segment",
        input_key="session:550e8400-e29b-41d4-a716-446655440000",
        expected="session:{id}",
    ),
    RedisKeyNormTestCase(
        test_id="multiple_dynamic_segments",
        input_key="cache:42:item:999",
        expected="cache:{id}:item:{id}",
    ),
    RedisKeyNormTestCase(
        test_id="no_colon_static",
        input_key="simple_key",
        expected="simple_key",
    ),
    RedisKeyNormTestCase(
        test_id="empty_key",
        input_key="",
        expected="",
    ),
    RedisKeyNormTestCase(
        test_id="short_hex_not_replaced",
        input_key="token:abc123",
        expected="token:abc123",
    ),
]


@pytest.mark.parametrize("test_case", REDIS_KEY_CASES, ids=lambda tc: tc.test_id)
async def test_normalize_redis_key(test_case: RedisKeyNormTestCase) -> None:
    assert normalize_redis_key(test_case.input_key) == test_case.expected
