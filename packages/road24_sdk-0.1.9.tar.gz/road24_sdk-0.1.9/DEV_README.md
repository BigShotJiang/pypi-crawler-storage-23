# Developer Guide

How to maintain, extend, and publish road24-sdk.

## Prerequisites

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) package manager
- PyPI account with API token (for publishing)

## Setup

```bash
git clone <repo-url>
cd road24-sdk
make install   # uv sync --all-extras
```

## Commands

```bash
make install       # Install all dependencies
make test          # Run tests with 90% coverage threshold
make lint          # Lint + format check (ruff)
make format        # Auto-format code (ruff)
make check         # lint + test
make push_to_pypi  # Build and publish to PyPI
```

## Publishing to PyPI

### Step 1: Bump version

Open `pyproject.toml` and update the `version` field:

```toml
[project]
name = "road24-sdk"
version = "0.1.9"  # <- increment this
```

### Step 2: Publish

```bash
make push_to_pypi
```

This command:
1. Cleans the `dist/` directory
2. Builds the wheel with `python -m build`
3. Uploads to PyPI with `python -m twine upload`

Requires `TWINE_USERNAME` and `TWINE_PASSWORD` environment variables, or a `~/.pypirc` file.

## CI/CD

**`.github/workflows/publish.yml`** runs on every push and PR to `main`:
- **lint job** — `ruff check` + `ruff format --check`
- **test job** — `pytest` with `--cov-fail-under=90`

CI does **not** publish. Publishing is manual via `make push_to_pypi`.

## Architecture

The SDK follows a Sentry-like pattern: call `init()` with a list of integrations, and they auto-instrument frameworks at the class level.

```
road24_sdk.init(integrations=[...])
    |
    v
integration.setup_once()          # Patches framework classes (httpx.AsyncClient, Redis, Engine)
    |
    v
All new instances auto-instrumented
    |
    v
Logger records structured JSON     # loggers/
Metrics records Prometheus data     # metrics/
```

### Request Flow (FastAPI Example)

```
HTTP request arrives
  -> _LogMiddleware captures start time
  -> Calls next middleware / route handler
  -> On response: logs attributes, records metrics
```

## Project Structure

```
road24_sdk/
├── __init__.py                # Public API: init(), configure(), enum exports
├── _types.py                  # All type definitions (enums + Road24Config)
├── _schemas.py                # Dataclass schemas for log attributes
├── _formatter.py              # JSON log formatter, setup_logging()
├── _sanitizer.py              # Body sanitization (redacts sensitive fields)
├── _normalizer.py             # URL/Redis key normalization ({id} replacement)
├── integrations/              # Framework-specific auto-instrumentation
│   ├── __init__.py            # Re-exports all integration classes
│   ├── _base.py               # Integration ABC with setup_once() pattern
│   ├── fastapi.py             # ASGI middleware + exception handlers
│   ├── httpx.py               # Patches AsyncClient.__init__ with hooks
│   ├── sqlalchemy.py          # Registers Engine event listeners
│   ├── redis.py               # Patches Redis.execute_command
│   └── faststream.py          # FastStream middleware for broker messages
├── loggers/                   # Structured log producers
│   ├── __init__.py            # Re-exports all logger classes
│   ├── http_input.py          # Incoming HTTP request logging
│   ├── http_output.py         # Outgoing HTTP request logging (httpx hooks)
│   ├── db.py                  # Database query logging + SQL parsing
│   ├── redis.py               # Redis command logging + LoggedRedis wrapper
│   └── faststream.py          # FastStream message logging
└── metrics/                   # Prometheus metric recorders
    ├── __init__.py            # Re-exports all record functions
    ├── http.py                # http_requests_total, http_request_duration_seconds
    ├── db.py                  # db_queries_total, db_query_duration_seconds
    ├── redis.py               # redis_commands_total, redis_command_duration_seconds
    └── faststream.py          # faststream_messages_total, faststream_message_duration_seconds
```

## Adding a New Integration

1. **Create the logger** in `loggers/new_module.py`
2. **Create the metrics** in `metrics/new_module.py` — Counter + Histogram with `record_*()` function
3. **Create the integration** in `integrations/new_module.py`:
   - Inherit from `Integration`
   - Implement `setup_once()` for class-level patching (use `_mark_setup_once()` guard)
   - Implement `setup(client)` for instance-level patching
4. **Add enums** to `_types.py` if needed (direction, operation types)
5. **Add schema** to `_schemas.py` with `as_dict()` method
6. **Export** from `integrations/__init__.py` and `__init__.py`
7. **Add optional dependency** to `pyproject.toml` under `[project.optional-dependencies]`
8. **Write tests** in `tests/test_smoke.py`

## Tests

```
tests/
├── conftest.py                # Shared fixtures (mock clients, sample data)
├── test_data_classes.py       # Dataclass definitions for parametrized tests
├── test_formatter.py          # LogFormatter, setup_logging
├── test_init.py               # SDK init() and configure()
├── test_normalizer.py         # URL and Redis key normalization
├── test_sanitizer.py          # Body sanitization
├── test_schemas.py            # Schema dataclasses and as_dict()
├── test_types.py              # Enum completeness and values
├── test_smoke.py              # Smoke tests for all loggers, metrics, and integrations
└── test_loggers/
    ├── test_http_input.py     # HttpInputLogger
    └── test_http_output.py    # HttpOutputLogger
```

### Test Conventions

- All tests are `async def` (pytest-asyncio with `asyncio_mode = "auto"`)
- AAA pattern: Arrange, Act, Assert
- Parametrized tests use dataclasses from `test_data_classes.py`
- Coverage threshold: 90% minimum (enforced by `--cov-fail-under=90`)

### Running Tests

```bash
make test                              # All tests with coverage
pytest tests/test_types.py -v          # Single file
pytest tests/test_smoke.py -v          # Smoke tests only
pytest -k "test_log_query" -v          # By name pattern
```

## Code Style

- Python 3.12+ type hints on all functions
- `StrEnum` for all enumerations
- `ContextVar` for request-scoped state
- `dataclass(slots=True)` for schemas
- Guard clauses (early returns) over nested conditionals
- Functions under 20 lines
- `TYPE_CHECKING` for optional dependency imports
- No comments except for complex logic
- Line length: 88 characters
- Linter: ruff (`E,F,I,N,UP,B,ANN` rules)
