"""AWS checks registry."""
