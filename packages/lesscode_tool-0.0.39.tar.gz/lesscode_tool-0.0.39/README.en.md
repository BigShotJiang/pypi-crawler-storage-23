# lesscodeTool

#### Description
```
Usage: lesscodeTool [OPTIONS] COMMAND [ARGS]...

  低代码构建工具.

Options:
  --help  Show this message and exit.

Commands:
  sqlacodegen  生成SQLALCHEMY模型类
  subcommand   执行系统命令
  swagger      swagger api转换
  
swagger:
  - Params:
    - -o/--out_type supports md,markdown,yaml,yml,docx,pdf,toml,toon
    - -f/--file output file path
    - --to-file export to default file

Optional Dependencies:
- click: run CLI
- requests: fetch swagger JSON
- sqlalchemy: sqlacodegen
- pyyaml: output yaml/yml
- python-docx: output docx
- reportlab: output pdf
- tomli-w or toml: output toml
```
