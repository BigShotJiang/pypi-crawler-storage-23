# lesscodeTool

#### Description
```
Usage: lesscodeTool [OPTIONS] COMMAND [ARGS]...

  低代码构建工具.

Options:
  --help  Show this message and exit.

Commands:
  sqlacodegen  生成SQLALCHEMY模型类
  subcommand   执行系统命令
  swagger      swagger api转换
  
swagger:
  - 参数:
    - -o/--out_type 支持 md,markdown,yaml,yml,docx,pdf,toml,toon
    - -f/--file 输出到文件路径
    - --to-file 将结果导出到默认文件

可选依赖:
- click：运行 CLI
- requests：拉取 swagger JSON
- sqlalchemy：sqlacodegen
- pyyaml：输出 yaml/yml
- python-docx：输出 docx
- reportlab：输出 pdf
- tomli-w 或 toml：输出 toml
```
