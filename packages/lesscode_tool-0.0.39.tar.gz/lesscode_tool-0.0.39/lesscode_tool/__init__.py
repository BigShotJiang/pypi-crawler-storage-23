import os

try:
    import click
except ImportError:
    raise SystemExit("click 未安装，请运行: pip install click")

"""
Usage: lesscodeTool [OPTIONS] COMMAND [ARGS]...

  低代码构建工具.

Options:
  --help  Show this message and exit.

Commands:
  sqlacodegen  生成SQLALCHEMY模型类
  subcommand   执行系统命令
  swagger      swagger api转换
"""


@click.help_option(*['-h', '-–help'], help="查看命令帮助")
@click.group(help="低代码构建工具.", context_settings=dict(help_option_names=['-–help', '-h']))
def cli():
    pass


@cli.command()
@click.option('-u', '--url', type=str, required=True, help='数据库连接')
@click.option('-s', '--schemas', type=str, help='库名，用英文逗号连接多个库')
@click.option('-t', '--tables', type=str, help='表名，用英文逗号连接多个表')
@click.option('-o', '--out', type=str, help='表结构类输出文件')
@click.option('-a', '--add', type=bool, default=False, show_default=True, help='生成model是否带库名')
@click.option('-i', '--ignore', type=bool, default=True, show_default=True, help='忽略字段的None属性')
@click.help_option('-h', '--help', help='查看子命令sqlacodegen的帮助')
def sqlacodegen(url, schemas, tables, out, add, ignore):
    """生成SQLALCHEMY模型类"""
    try:
        import sqlalchemy  # noqa: F401
    except ImportError:
        raise SystemExit("sqlalchemy 未安装，请运行: pip install sqlalchemy")
    from tool.table_model_gen import table_model_gen
    if schemas:
        schemas = schemas.split(",")
    if tables:
        tables = tables.split(",")
    table_model_gen(url, schemas, tables, out, add, ignore)


@cli.command()
@click.option('-u', '--url', type=str, required=True, help='swagger api地址')
@click.option('-o', '--out_type', type=str, default="md", help='输出类型，支持md,markdown,yaml,yml,docx,pdf,toml,toon')
@click.option('-f', '--file', type=str, help='输出到文件的地址')
@click.option('--to-file', is_flag=True, default=False, show_default=True, help='导出到默认文件')
@click.option('-b', '--base', type=str, default="http://127.0.0.1", help='接口基地址')
@click.help_option('-h', '--help', help='swagger api转换')
def swagger(url, out_type, file, to_file, base):
    """swagger api转换"""
    from tool.swagger_tool import swagger_convert
    try:
        from requests import get
    except ImportError:
        raise SystemExit("requests 未安装，请运行: pip install requests")
    json_data = get(url).json()
    if not file and to_file:
        ext_map = {
            "md": "md", "markdown": "md",
            "yaml": "yaml", "yml": "yml",
            "docx": "docx", "pdf": "pdf",
            "toml": "toml", "toon": "toon"
        }
        ext = ext_map.get(out_type, out_type)
        file = os.path.join(os.getcwd(), f"swagger.{ext}")
    swagger_convert(json_data, out_type, file, base)


@cli.command()
@click.option('-c', '--command', type=str, required=True, help='数据库连接')
@click.help_option('-h', '--help', help='查看子命令subcommand的帮助')
def subcommand(command):
    """执行系统命令"""
    os.system(command)


def main():
    cli()
