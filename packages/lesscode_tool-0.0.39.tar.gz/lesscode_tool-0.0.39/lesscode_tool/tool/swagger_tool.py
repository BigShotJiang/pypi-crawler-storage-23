# -*- coding: utf-8 -*-
import json
import re
from itertools import groupby
from operator import itemgetter
import io


def doc2dict(doc):
    param_dict = dict()
    response_dict = dict()
    example = ""

    param_pattern = r":param (\w+): (.+)"
    param_matches = re.findall(param_pattern, doc)
    for param_name, param_desc in param_matches:
        param_dict[param_name] = param_desc

    return_pattern = r":return (\w+): (.+)"
    return_match = re.findall(return_pattern, doc)
    for return_name, return_desc in return_match:
        response_dict[return_name] = return_desc

    example_pattern = r":example (.+)"
    example_match = re.search(example_pattern, doc, flags=re.S)
    if example_match:
        example = example_match.groups()[0]

    result = {
        "param_dict": param_dict,
        "response_dict": response_dict,
        "example": example
    }
    return result


def gen_md_table(headers: list, data: list):
    trs = ''.join([f"<tr>{''.join([f'<td>{td}</td>' for td in tr])}</tr>" for tr in data])
    table_str = f"<table border=\"1\">" \
                f"<tr>{''.join([f'<th>{th}</th>' for th in headers])}</tr>" \
                f"{trs}" \
                f"</table>  \n"
    return table_str


def data2md_str(data, field="tag", base_url="http://127.0.0.1"):
    data.sort(key=itemgetter(field))
    api_class_str = ""
    index = 1
    for key, items in groupby(data, key=itemgetter(field)):
        api_class_str += f"\n## **{index}.{key}**  \n"
        for i, api in enumerate(items):
            description = api.get('description') if api.get('description') and isinstance(api.get('description'),
                                                                                          str) else ""
            description_info = doc2dict(description)
            url = f"{base_url}{api.get('url')}"
            header_arr = []
            param_arr = []
            body_arr = []
            for param in api.get("parameters", []):
                if param.get("in") == "query":
                    param_name = param.get('name')
                    param_desc = description_info.get("param_dict", {}).get(param_name) if description_info.get(
                        "param_dict", {}).get(param_name) else ""
                    param_default = param.get('default') if param.get('default') is not None else "null"
                    param_required = 'true' if param.get('required') else 'false'
                    param_type = param.get('type')
                    param_arr.append([param_name, param_required, param_type, param_default, param_desc])
                elif param.get("in") == "header":
                    header_name = param.get('name')
                    header_desc = description_info.get(header_name) if description_info.get(header_name) else ""
                    header_required = 'true' if param.get('required') else 'false'
                    header_type = param.get('type')
                    header_default = param.get('default') if param.get('default') is not None else "null"
                    header_arr.append([header_name, header_required, header_type, header_default, header_desc])
                elif param.get("in") in ["body", "path", "cookie"]:
                    schema = param.get('schema', {})
                    if schema:
                        required_props = set(schema.get("required") or [])
                        for property_name, property_info in schema.get("properties", {}).items():
                            property_desc = description_info.get("param_dict", {}).get(
                                property_name) if description_info.get("param_dict", {}).get(
                                property_name) else ""
                            property_default = property_info.get('default') if property_info.get(
                                'default') is not None else "null"
                            property_required = 'true' if property_name in required_props or property_info.get('required') else 'false'
                            property_type = property_info.get('type')
                            param_arr.append(
                                [property_name, property_required, property_type, property_default, property_desc])
            request_body = api.get("requestBody") or {}
            content = request_body.get("content") or {}
            for _, media in content.items():
                schema = media.get("schema") or {}
                required_props = set(schema.get("required") or [])
                for property_name, property_info in schema.get("properties", {}).items():
                    property_desc = description_info.get("param_dict", {}).get(property_name) if description_info.get("param_dict", {}).get(property_name) else ""
                    property_default = property_info.get('default') if property_info.get('default') is not None else "null"
                    property_required = 'true' if property_name in required_props or property_info.get('required') else 'false'
                    property_type = property_info.get('type')
                    body_arr.append([property_name, property_required, property_type, property_default, property_desc])
            produces = api.get("produces")
            content_types = ", ".join(produces) if isinstance(produces, list) and produces else "JSON"
            api_class_str += f"\n### {index}.{i + 1} {api.get('summary')}  \n###### 请求地址  \n> <{url}>  \n\n" \
                             f"###### 支持格式  \n> {content_types}  \n\n###### HTTP请求方式  \n" \
                             f"> {api.get('method').upper()}  \n\n"
            header_arr.append(["Content-Type", "true", "string", "", "application/json"])
            if header_arr:
                header_table_headers = ['参数', '必选', '类型', '默认值', '说明']
                header_str = f'###### 请求头  \n{gen_md_table(header_table_headers, header_arr)}'
                api_class_str = f"{api_class_str}  \n{header_str}  \n"
            if param_arr:
                param_table_headers = ['参数', '必选', '类型', '默认值', '说明']
                param_str = f'###### 请求参数  \n{gen_md_table(param_table_headers, param_arr)}'
                api_class_str = f"{api_class_str}  \n{param_str}  \n"
            if body_arr:
                body_table_headers = ['参数', '必选', '类型', '默认值', '说明']
                body_str = f'###### 请求参数  \n{gen_md_table(body_table_headers, body_arr)}'
                api_class_str = f"{api_class_str}  \n{body_str}  \n"
            response_dict = description_info.get("response_dict", {})
            if response_dict:
                response_table_headers = ['参数', '说明']
                response_arr = [[k, v] for k, v in response_dict.items()]
                api_class_str += f"###### 返回字段  \n{gen_md_table(response_table_headers, response_arr)}  \n"
            example = description_info.get("example")
            if example:
                api_class_str += f"\n###### 响应示例  \n```json\n{example}\n```"
            api_class_str += "\n\n"
        index += 1
    return api_class_str


def swagger_json2yaml(data):
    try:
        import yaml
    except ImportError:
        raise SystemExit("pyyaml 未安装，请运行: pip install pyyaml")
    class IndentDumper(yaml.Dumper):
        def increase_indent(self, flow=False, indentless=False):
            return super(IndentDumper, self).increase_indent(flow, False)
    data_str = json.dumps(data)
    data_yaml = yaml.load(data_str, Loader=yaml.FullLoader)
    return yaml.dump(data_yaml, Dumper=IndentDumper, indent=2, default_flow_style=False,
                     explicit_start=True, allow_unicode=True, encoding="utf-8").decode(encoding="utf-8")


def swagger_json2markdown(data, base_url):
    route_str = data2md_str(data.get("paths"), "tag", base_url)
    title = ""
    info = data.get('info')
    if info and isinstance(info, dict):
        title = info.get("title")
    result_str = f"# 项目名称:{title}  \n" + route_str
    return result_str

def swagger_json2docx(data, base_url, file_path):
    try:
        from docx import Document
        from docx.shared import Pt
    except Exception:
        raise SystemExit("python-docx 未安装，请运行: pip install python-docx")
    document = Document()
    title = ""
    info = data.get('info')
    if info and isinstance(info, dict):
        title = info.get("title")
    document.add_heading(f"项目名称:{title}", level=0)
    items = data.get("paths") or []
    items.sort(key=itemgetter("tag"))
    index = 1
    for key, group in groupby(items, key=itemgetter("tag")):
        document.add_heading(f"{index}.{key}", level=1)
        for i, api in enumerate(group):
            description = api.get('description') if api.get('description') and isinstance(api.get('description'), str) else ""
            description_info = doc2dict(description)
            url = f"{base_url}{api.get('url')}"
            document.add_heading(f"{index}.{i + 1} {api.get('summary')}", level=2)
            document.add_paragraph(f"请求地址: {url}")
            produces = api.get("produces")
            content_types = ", ".join(produces) if isinstance(produces, list) and produces else "JSON"
            document.add_paragraph(f"支持格式: {content_types}")
            document.add_paragraph(f"HTTP请求方式: {api.get('method').upper()}")
            header_arr = []
            param_arr = []
            body_arr = []
            for param in api.get("parameters", []) or []:
                if param.get("in") == "query":
                    param_name = param.get('name')
                    param_desc = description_info.get("param_dict", {}).get(param_name) if description_info.get("param_dict", {}).get(param_name) else ""
                    param_default = param.get('default') if param.get('default') is not None else "null"
                    param_required = 'true' if param.get('required') else 'false'
                    param_type = param.get('type')
                    param_arr.append([param_name, param_required, param_type, param_default, param_desc])
                elif param.get("in") == "header":
                    header_name = param.get('name')
                    header_desc = description_info.get(header_name) if description_info.get(header_name) else ""
                    header_required = 'true' if param.get('required') else 'false'
                    header_type = param.get('type')
                    header_default = param.get('default') if param.get('default') is not None else "null"
                    header_arr.append([header_name, header_required, header_type, header_default, header_desc])
                elif param.get("in") in ["body", "path", "cookie"]:
                    schema = param.get('schema', {})
                    if schema:
                        required_props = set(schema.get("required") or [])
                        for property_name, property_info in schema.get("properties", {}).items():
                            property_desc = description_info.get("param_dict", {}).get(property_name) if description_info.get("param_dict", {}).get(property_name) else ""
                            property_default = property_info.get('default') if property_info.get('default') is not None else "null"
                            property_required = 'true' if property_name in required_props or property_info.get('required') else 'false'
                            property_type = property_info.get('type')
                            body_arr.append([property_name, property_required, property_type, property_default, property_desc])
            request_body = api.get("requestBody") or {}
            content = request_body.get("content") or {}
            for _, media in content.items():
                schema = media.get("schema") or {}
                required_props = set(schema.get("required") or [])
                for property_name, property_info in schema.get("properties", {}).items():
                    property_desc = description_info.get("param_dict", {}).get(property_name) if description_info.get("param_dict", {}).get(property_name) else ""
                    property_default = property_info.get('default') if property_info.get('default') is not None else "null"
                    property_required = 'true' if property_name in required_props or property_info.get('required') else 'false'
                    property_type = property_info.get('type')
                    body_arr.append([property_name, property_required, property_type, property_default, property_desc])
            header_arr.append(["Content-Type", "true", "string", "", "application/json"])
            if header_arr:
                table = document.add_table(rows=1, cols=5)
                hdr_cells = table.rows[0].cells
                labels = ['参数', '必选', '类型', '默认值', '说明']
                for idx, label in enumerate(labels):
                    hdr_cells[idx].text = label
                for row in header_arr:
                    cells = table.add_row().cells
                    for idx, cell_val in enumerate(row):
                        cells[idx].text = str(cell_val)
            if param_arr:
                table = document.add_table(rows=1, cols=5)
                hdr_cells = table.rows[0].cells
                labels = ['参数', '必选', '类型', '默认值', '说明']
                for idx, label in enumerate(labels):
                    hdr_cells[idx].text = label
                for row in param_arr:
                    cells = table.add_row().cells
                    for idx, cell_val in enumerate(row):
                        cells[idx].text = str(cell_val)
            if body_arr:
                table = document.add_table(rows=1, cols=5)
                hdr_cells = table.rows[0].cells
                labels = ['参数', '必选', '类型', '默认值', '说明']
                for idx, label in enumerate(labels):
                    hdr_cells[idx].text = label
                for row in body_arr:
                    cells = table.add_row().cells
                    for idx, cell_val in enumerate(row):
                        cells[idx].text = str(cell_val)
            response_dict = description_info.get("response_dict", {})
            if response_dict:
                table = document.add_table(rows=1, cols=2)
                hdr_cells = table.rows[0].cells
                labels = ['参数', '说明']
                for idx, label in enumerate(labels):
                    hdr_cells[idx].text = label
                for k, v in response_dict.items():
                    cells = table.add_row().cells
                    cells[0].text = str(k)
                    cells[1].text = str(v)
            example = description_info.get("example")
            if example:
                document.add_paragraph("响应示例:")
                document.add_paragraph(example)
        index += 1
    if not file_path:
        raise Exception("docx输出必须指定文件路径, 使用参数-f")
    document.save(file_path)

def swagger_json2pdf(data, base_url, file_path):
    try:
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
    except Exception:
        raise SystemExit("reportlab 未安装，请运行: pip install reportlab")
    doc = SimpleDocTemplate(file_path, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []
    title = ""
    info = data.get('info')
    if info and isinstance(info, dict):
        title = info.get("title")
    elements.append(Paragraph(f"项目名称:{title}", styles['Title']))
    items = data.get("paths") or []
    items.sort(key=itemgetter("tag"))
    index = 1
    for key, group in groupby(items, key=itemgetter("tag")):
        elements.append(Paragraph(f"{index}.{key}", styles['Heading1']))
        for i, api in enumerate(group):
            description = api.get('description') if api.get('description') and isinstance(api.get('description'), str) else ""
            description_info = doc2dict(description)
            url = f"{base_url}{api.get('url')}"
            elements.append(Paragraph(f"{index}.{i + 1} {api.get('summary')}", styles['Heading2']))
            elements.append(Paragraph(f"请求地址: {url}", styles['Normal']))
            produces = api.get("produces")
            content_types = ", ".join(produces) if isinstance(produces, list) and produces else "JSON"
            elements.append(Paragraph(f"支持格式: {content_types}", styles['Normal']))
            elements.append(Paragraph(f"HTTP请求方式: {api.get('method').upper()}", styles['Normal']))
            header_arr = []
            param_arr = []
            body_arr = []
            for param in api.get("parameters", []) or []:
                if param.get("in") == "query":
                    param_name = param.get('name')
                    param_desc = description_info.get("param_dict", {}).get(param_name) if description_info.get("param_dict", {}).get(param_name) else ""
                    param_default = param.get('default') if param.get('default') is not None else "null"
                    param_required = 'true' if param.get('required') else 'false'
                    param_type = param.get('type')
                    param_arr.append([param_name, param_required, param_type, param_default, param_desc])
                elif param.get("in") == "header":
                    header_name = param.get('name')
                    header_desc = description_info.get(header_name) if description_info.get(header_name) else ""
                    header_required = 'true' if param.get('required') else 'false'
                    header_type = param.get('type')
                    header_default = param.get('default') if param.get('default') is not None else "null"
                    header_arr.append([header_name, header_required, header_type, header_default, header_desc])
                elif param.get("in") in ["body", "path", "cookie"]:
                    schema = param.get('schema', {})
                    if schema:
                        required_props = set(schema.get("required") or [])
                        for property_name, property_info in schema.get("properties", {}).items():
                            property_desc = description_info.get("param_dict", {}).get(property_name) if description_info.get("param_dict", {}).get(property_name) else ""
                            property_default = property_info.get('default') if property_info.get('default') is not None else "null"
                            property_required = 'true' if property_name in required_props or property_info.get('required') else 'false'
                            property_type = property_info.get('type')
                            body_arr.append([property_name, property_required, property_type, property_default, property_desc])
            request_body = api.get("requestBody") or {}
            content = request_body.get("content") or {}
            for _, media in content.items():
                schema = media.get("schema") or {}
                required_props = set(schema.get("required") or [])
                for property_name, property_info in schema.get("properties", {}).items():
                    property_desc = description_info.get("param_dict", {}).get(property_name) if description_info.get("param_dict", {}).get(property_name) else ""
                    property_default = property_info.get('default') if property_info.get('default') is not None else "null"
                    property_required = 'true' if property_name in required_props or property_info.get('required') else 'false'
                    property_type = property_info.get('type')
                    body_arr.append([property_name, property_required, property_type, property_default, property_desc])
            header_arr.append(["Content-Type", "true", "string", "", "application/json"])
            if header_arr:
                data_table = [['参数', '必选', '类型', '默认值', '说明']] + [[str(c) for c in r] for r in header_arr]
                table = Table(data_table)
                table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey), ('GRID', (0, 0), (-1, -1), 0.5, colors.black)]))
                elements.append(table)
            if param_arr:
                data_table = [['参数', '必选', '类型', '默认值', '说明']] + [[str(c) for c in r] for r in param_arr]
                table = Table(data_table)
                table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey), ('GRID', (0, 0), (-1, -1), 0.5, colors.black)]))
                elements.append(table)
            if body_arr:
                data_table = [['参数', '必选', '类型', '默认值', '说明']] + [[str(c) for c in r] for r in body_arr]
                table = Table(data_table)
                table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey), ('GRID', (0, 0), (-1, -1), 0.5, colors.black)]))
                elements.append(table)
            response_dict = description_info.get("response_dict", {})
            if response_dict:
                data_table = [['参数', '说明']] + [[str(k), str(v)] for k, v in response_dict.items()]
                table = Table(data_table)
                table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey), ('GRID', (0, 0), (-1, -1), 0.5, colors.black)]))
                elements.append(table)
            example = description_info.get("example")
            if example:
                elements.append(Paragraph("响应示例:", styles['Normal']))
                elements.append(Paragraph(example, styles['Code']))
        index += 1
    doc.build(elements)


def remove_null(data):
    if isinstance(data, dict):
        new_data = dict()
        for key, value in data.items():
            if key and value:
                if isinstance(value, dict) or isinstance(value, list):
                    value = remove_null(value)
                new_data.update({key: value})
    elif isinstance(data, list):
        new_data = list()
        for item in data:
            if item:
                if isinstance(item, dict) or isinstance(item, list):
                    item = remove_null(item)
                new_data.append(remove_null(item))
    else:
        new_data = data
    return new_data


def dict_update(origin: dict, key, value):
    if key and value:
        origin.update({key: value})


def swagger_pre_handle(data: dict):
    new_data = dict()
    version = data.get("openapi") or data.get("swagger")
    if version:
        dict_update(new_data, "openapi", remove_null(data.get("openapi")))
        dict_update(new_data, "swagger", remove_null(data.get("swagger")))
    dict_update(new_data, "info", remove_null(data.get("info")))
    dict_update(new_data, "host", remove_null(data.get("host")))
    dict_update(new_data, "basePath", remove_null(data.get("basePath")))
    dict_update(new_data, "schemes", remove_null(data.get("schemes")))
    dict_update(new_data, "consumes", remove_null(data.get("consumes")))
    dict_update(new_data, "produces", remove_null(data.get("produces")))
    dict_update(new_data, "securityDefinitions", remove_null(data.get("securityDefinitions")))
    dict_update(new_data, "security", remove_null(data.get("security")))
    dict_update(new_data, "tags", remove_null(data.get("tags")))
    dict_update(new_data, "externalDocs", remove_null(data.get("externalDocs")))
    dict_update(new_data, "definitions", remove_null(data.get("definitions")))
    dict_update(new_data, "parameters", remove_null(data.get("parameters")))
    dict_update(new_data, "servers", remove_null(data.get("servers")))
    dict_update(new_data, "components", remove_null(data.get("components")))
    paths = data.get("paths", {})
    new_paths = list()
    for url, info in paths.items():
        for method, method_info in info.items():
            method_tags = method_info.get("tags")
            if method_tags:
                for tag in method_tags:
                    new_info = {
                        "url": url
                    }
                    new_info.update({"method": method,
                                     "tag": tag if tag else '',
                                     "summary": method_info.get("summary"),
                                     "parameters": method_info.get("parameters"),
                                     "requestBody": method_info.get("requestBody"),
                                     "description": method_info.get("description"),
                                     "responses": method_info.get("responses"),
                                     "consumes": method_info.get("consumes"),
                                     "produces": method_info.get("produces"),
                                     "security": method_info.get("security"),
                                     "deprecated": method_info.get("deprecated"),
                                     "operationId": method_info.get("operationId")})
                    new_paths.append(new_info)
    new_data.update({"paths": new_paths})
    return new_data


def swagger_json2toml(data):
    try:
        import tomli_w
        return tomli_w.dumps(data)
    except Exception:
        try:
            import toml
            return toml.dumps(data)
        except Exception:
            raise SystemExit("tomli-w 或 toml 未安装，请运行: pip install tomli-w 或 pip install toml")

def swagger_json2toon(data, base_url):
    items = data.get("paths") or []
    items.sort(key=itemgetter("tag"))
    lines = []
    title = ""
    info = data.get('info')
    if info and isinstance(info, dict):
        title = info.get("title")
    lines.append(f"Project: {title}")
    index = 1
    for key, group in groupby(items, key=itemgetter("tag")):
        lines.append(f"\n[{index}] {key}")
        for i, api in enumerate(group):
            url = f"{base_url}{api.get('url')}"
            lines.append(f"- {index}.{i+1} {api.get('summary')} [{api.get('method').upper()}] {url}")
            params = []
            for p in api.get("parameters", []) or []:
                name = p.get("name")
                typ = p.get("type")
                required = 'true' if p.get("required") else 'false'
                loc = p.get("in")
                params.append(f"{name}({typ},{required},{loc})")
            if params:
                lines.append(f"  params: " + ", ".join(params))
            rb = api.get("requestBody") or {}
            content = rb.get("content") or {}
            body_params = []
            for _, media in content.items():
                schema = media.get("schema") or {}
                required_props = set(schema.get("required") or [])
                for property_name, property_info in schema.get("properties", {}).items():
                    typ = property_info.get("type")
                    required = 'true' if property_name in required_props or property_info.get('required') else 'false'
                    body_params.append(f"{property_name}({typ},{required},body)")
            if body_params:
                lines.append(f"  body: " + ", ".join(body_params))
    return "\n".join(lines)


def swagger_convert(json_data, out_type, file_path=None, base_url="http://127.0.0.1"):
    json_data = swagger_pre_handle(json_data)
    if out_type in ["yaml", "yml"]:
        result_data = swagger_json2yaml(json_data)
    elif out_type in ["md", "markdown"]:
        result_data = swagger_json2markdown(json_data, base_url)
    elif out_type in ["toml"]:
        result_data = swagger_json2toml(json_data)
    elif out_type in ["toon"]:
        result_data = swagger_json2toon(json_data, base_url)
    elif out_type in ["docx"]:
        swagger_json2docx(json_data, base_url, file_path)
        result_data = None
    elif out_type in ["pdf"]:
        swagger_json2pdf(json_data, base_url, file_path)
        result_data = None
    else:
        print(f"暂不支持输出类型{out_type}")
        return
    if result_data is not None:
        if file_path:
            with open(file_path, "w+") as f:
                f.write(result_data)
        else:
            print(result_data)
