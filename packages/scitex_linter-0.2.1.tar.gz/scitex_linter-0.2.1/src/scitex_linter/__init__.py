"""SciTeX Linter — enforce reproducible research patterns via AST analysis."""

__version__ = "0.2.1"
