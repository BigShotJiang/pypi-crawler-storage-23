"""MCP integration for scitex-linter."""
