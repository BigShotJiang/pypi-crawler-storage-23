# Harmonized Telemetry Format (HTF)

Detailed description coming soon.

Exemplary HTF file content:
```htf
[static_metadata;s]12.51
[dim_metadata;index;delta]2;0.08;4;0.484
(channel;s;50;135)0=12.27;1=12.42;...
(empty_channel;m;50;135)0=;
```
