"""Implements `gradlite`'s differentiation engine.
"""

from gradlite.core.parameter import Parameter

__all__ = ['Parameter']
