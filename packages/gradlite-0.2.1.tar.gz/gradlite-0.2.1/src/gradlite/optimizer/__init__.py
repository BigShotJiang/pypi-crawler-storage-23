"""Implements nnets optimizers in gradlite.
"""
