"""
Ionworks API Client.

A Python client for interacting with the Ionworks platform for battery cell
testing, simulation, and modeling.

Example:
-------
>>> from ionworks import Ionworks
>>> client = Ionworks()
>>> specs = client.cell_spec.list()
"""

from .client import Ionworks
from .errors import IonworksError
from .validators import (
    MeasurementValidationError,
    get_dataframe_backend,
    set_dataframe_backend,
)

__all__ = [
    "Ionworks",
    "IonworksError",
    "MeasurementValidationError",
    "get_dataframe_backend",
    "set_dataframe_backend",
]
