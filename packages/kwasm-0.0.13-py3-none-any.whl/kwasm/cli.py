"""kwasm CLI — bundle and view GDS layouts."""

import tempfile
import webbrowser
from pathlib import Path

import typer

from kwasm.embed import bundle as _bundle

app = typer.Typer()


@app.command()
def bundle(
    gds: str,
    output: str | None = None,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout into a self-contained HTML file."""
    _bundle(gds, output=output, lyp=lyp, lyrdb=lyrdb, netlist=netlist)


@app.command()
def view(
    gds: str,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout and open it in the default browser."""
    with tempfile.NamedTemporaryFile(
        suffix=".html", prefix="kwasm_", delete=False
    ) as tmp:
        tmp_path = Path(tmp.name).resolve()
        _bundle(gds, output=tmp_path, lyp=lyp, lyrdb=lyrdb, netlist=netlist)
        webbrowser.open(tmp_path.as_uri())


if __name__ == "__main__":
    app()
