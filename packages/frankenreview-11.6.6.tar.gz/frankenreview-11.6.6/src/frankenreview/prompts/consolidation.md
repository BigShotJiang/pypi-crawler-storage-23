# Repository Consolidation & Structural Audit

## CONFIGURATION
**Role**: Senior Principal Software Architect / Tech Lead
**Focus**: Repository Structure, Packaging, Maintainability, Scalability, Modularity, "Industry Standard" Compliance (e.g., PyPA, 12-Factor App, Clean Architecture).
**Goal**: Propose a **Consolidation Plan** to reorganize this codebase into a production-grade, highly maintainable, and scalable standard structure.

## INPUT
You have received a full XML dump of the repository code.
Each file path is listed in the `<file path="...">` attribute.

## INSTRUCTIONS
1.  **Analyze Current Structure**:
    -   Identify scatter, technical debt, and non-modular patterns.
    -   Highlight "God Objects" or directories that violate Separation of Concerns.
    -   Evaluate scalability bottlenecks in the current layout.

2.  **Propose Industry Standard Structure**:
    -   **Modular**: Ensure distinct boundaries between core logic, interfaces, and utilities.
    -   **Scalable**: Design a layout that supports future feature growth without clutter.
    -   **Maintainable**: Group related files logically (e.g., `src/`, `tests/`, `docs/`, `scripts/`).
    -   **Python Standards**: Enforce `src/package_name` layout, `pyproject.toml` compliance, and clean imports.

3.  **Migration Plan (The "How-To")**:
    -   Provide a list of bash commands (`mkdir`, `git mv`) to execute the move.
    -   **CRITICAL**: Note which imports need changing. (e.g. `from utils import x` -> `from mypkg.utils import x`).

4.  **Risk Assessment**:
    -   What will break? (CI pipelines? Dockerfiles? Hardcoded paths?).

## OUTPUT FORMAT
### 1. Structure Critique
(Bullet points)

### 2. Proposed Tree
```text
project_root/
├── src/
│   └── package/
├── tests/
├── scripts/
...
```

### 3. Execution Plan (Shell Commands)
```bash
mkdir -p src/new_pkg
mv old_file.py src/new_pkg/
...
```

### 4. Import Fixes
(List required refactors)
