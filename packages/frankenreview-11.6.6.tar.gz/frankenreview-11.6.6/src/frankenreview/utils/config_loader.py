"""
Frankenreview - Configuration Loader

Canonical configuration loading logic.
Resolves config.yaml from multiple sources (env var, dev root, installed package).
"""

import os
import yaml
import importlib.resources


def load_config(config_path=None):
    """
    Load configuration from yaml file.
    
    Priority:
    1. Explicit config_path argument
    2. FR_CONFIG_PATH environment variable
    3. Project root config.yaml (development mode)
    4. Packaged config.yaml (installed mode)
    5. Current directory fallback
    
    Returns:
        dict: Configuration dictionary
    """
    if config_path and not os.path.exists(str(config_path)):
        config_path = None
    
    if config_path is None:
        # Priority 1: Environment Variable
        env_path = os.environ.get('FR_CONFIG_PATH')
        if env_path and os.path.exists(env_path):
            config_path = env_path
        else:
            # Priority 2: Project Root (Development Mode)
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # utils/ -> frankenreview/ -> src/ -> ROOT
            dev_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
            dev_config = os.path.join(dev_root, "config.yaml")
            
            # Priority 2.5: .frankenreview/config.yaml (Canonical workspace config)
            dot_fr_config = os.path.join(os.getcwd(), ".frankenreview", "config.yaml")

            if os.path.exists(dev_config):
                config_path = dev_config
            elif os.path.exists(dot_fr_config):
                config_path = dot_fr_config
            else:
                # Priority 3: Installed Package (via Importlib)
                try:
                    with importlib.resources.path('frankenreview', 'config.yaml') as pkg_config:
                        config_path = str(pkg_config)
                except (ImportError, FileNotFoundError):
                    # Last Resort: current directory
                    config_path = "config.yaml"
    
    if not os.path.exists(config_path):
        # Fallback to minimal dict if absolutely nothing found
        return {"project_root": "."}

    with open(config_path) as f:
        return yaml.safe_load(f)


def get_effective_config_path():
    """
    Returns the path to the config file that will be used.
    Used for tools that need to write back to the config.
    """
    from .workspace import get_config_path
    
    # Check environment variable first
    env_path = os.environ.get('FR_CONFIG_PATH')
    if env_path and os.path.exists(env_path):
        return env_path
        
    # Check .frankenreview/config.yaml (preferred repo-specific path)
    dot_fr_config = get_config_path(os.getcwd())
    if dot_fr_config.exists():
        return str(dot_fr_config)
        
    # Fallback to current directory config.yaml if it exists
    if os.path.exists("config.yaml"):
        return os.path.abspath("config.yaml")
        
    # Default to .frankenreview/config.yaml (creation target)
    return str(dot_fr_config)
