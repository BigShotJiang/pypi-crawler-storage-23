import ast
from pathlib import Path
from typing import List

# Layer Hierarchy: utils (0) < engine (1) < core (2) < agents (3)
LAYER_ORDER = {
    'utils': 0,
    'engine': 1,
    'core': 2,
    'agents': 3
}

def check_architecture(root_path: Path) -> List[str]:
    """
    Scans all Python files in the specific root and enforces layer direction.
    Rule: Layer N can only import Layer <= N (and siblings).
    Strict Rule: Utils (0) CANNOT import Core (2) or Agents (3).
    """
    violations = []
    
    # Ensure we are looking at src/frankenreview
    src_fr = root_path 
    
    if src_fr.name != "frankenreview":
        if (root_path / "src" / "frankenreview").exists():
            src_fr = root_path / "src" / "frankenreview"
        elif (root_path / "frankenreview").exists():
            src_fr = root_path / "frankenreview"
        else:
             return [f"Could not find src/frankenreview to scan in {root_path}"]

    for py_file in src_fr.rglob("*.py"):
        # Identify which layer this file belongs to
        parts = py_file.parts
        if 'frankenreview' not in parts: 
            continue
        
        try:
            # Find the part after 'frankenreview'
            idx = parts.index('frankenreview')
            if idx + 1 >= len(parts):
                continue # Top level files like cli.py
                
            current_layer_name = parts[idx + 1]
            if current_layer_name not in LAYER_ORDER: 
                continue
            current_level = LAYER_ORDER[current_layer_name]
        except (IndexError, ValueError):
            continue

        # Parse imports
        try:
            content = py_file.read_text(encoding='utf-8')
            tree = ast.parse(content)
        except Exception:
            continue # Syntax errors handled elsewhere

        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                # Extract module name
                module = node.module if isinstance(node, ast.ImportFrom) else None
                if not module:
                     if isinstance(node, ast.Import):
                         module = node.names[0].name
                
                if not module or not module.startswith('frankenreview.'):
                    continue
                
                # Check import target layer
                # frankenreview.core.daemon -> core
                target_parts = module.split('.')
                if len(target_parts) > 1:
                    target_layer = target_parts[1]
                    if target_layer in LAYER_ORDER:
                        target_level = LAYER_ORDER[target_layer]
                        
                        # VIOLATION: Lower layer imports Higher layer
                        # e.g. Utils (0) imports Core (2)
                        if current_level < target_level:
                            violations.append(
                                f"[ARCH] {py_file.name} ({current_layer_name}) illegally imports {module} ({target_layer})"
                            )
                            
    return violations
