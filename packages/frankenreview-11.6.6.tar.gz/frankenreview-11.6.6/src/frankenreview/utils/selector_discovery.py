#!/usr/bin/env python3
"""
Active Selector Discovery Script for Frankenreview
Performs a live "Hello World" test to find all dynamic selectors.
"""

import sys
import os
import time
import yaml
from pathlib import Path
from playwright.sync_api import sync_playwright

from .config_loader import load_config, get_effective_config_path

def discover_active():
    print("[-] connecting to chrome...")
    config = load_config()
    
    port = config.get("chrome_debugger_port", 9222)
    
    with sync_playwright() as p:
        try:
            browser = p.chromium.connect_over_cdp(f"http://localhost:{port}")
        except Exception as e:
            print(f"[!] Failed to connect to Chrome: {e}")
            return

        context = browser.contexts[0]
        page = None
        for p_obj in context.pages:
            if "aistudio.google.com" in p_obj.url:
                page = p_obj
                break
        
        if not page:
            print("[!] No AI Studio tab found. Please open it manually.")
            return

        print(f"[+] Attached to {page.url}")
        
        # Ensure we are on a Chat page
        if "prompts/new_chat" not in page.url:
             print("    [!] Not on Chat page. Navigating to New Chat...")
             page.goto("https://aistudio.google.com/prompts/new_chat")
             time.sleep(3)
        
        # 0. Login Check
        login_btn = page.query_selector("a[aria-label*='Sign in'], button:has-text('Sign in')")
        if login_btn:
             print("[!] ERROR: Not logged in. Please log in first.")
             return

        results = {}

        # 1. Find & Fill Textarea
        print("[-] Step 1: Finding Input...")
        # Heuristic: Textarea with aria-label 'Enter a prompt' or similar
        potential_inputs = ["textarea[aria-label='Enter a prompt']", "textarea[placeholder*='Type']", "textarea"]
        input_sel = None
        for sel in potential_inputs:
            if page.query_selector(sel):
                input_sel = sel
                break
        
        if not input_sel:
            print("[!] Could not find input textarea.")
            return
            
        print(f"    [+] Found Input: {input_sel}")
        results['textarea'] = input_sel
        
        # Focus and Type
        try:
            page.click(input_sel)
            # Clear it safely
            page.fill(input_sel, "") 
            # Use a complex prompt to trigger Thinking mode
            page.fill(input_sel, "Think step-by-step and research the implications of P=NP. Be verbose.")
            print("    [+] Typed complex prompt (to trigger Thinking)...")
        except Exception as e:
            print(f"    [!] Failed to type: {e}")

        # 2. Find Run Button
        print("[-] Step 2: Finding Run Button...")
        potential_runs = ["button[aria-label='Run']", "button:has-text('Run')"]
        run_sel = None
        for sel in potential_runs:
            if page.query_selector(sel):
                run_sel = sel
                break
        
        if run_sel:
             print(f"    [+] Found Run Button: {run_sel}")
             results['run_button'] = run_sel
             page.click(run_sel)
             print("    [>] Clicked Run...")
        else:
             print("[!] Could not find Run button.")
             
        # 3. Monitor Generation (Thinking & Stop)
        print("[-] Step 3: Monitoring Generation (Waiting for Stop/Thinking)...")
        stop_found = False
        thinking_found = False
        
        # Immediate wait to allow UI transition
        time.sleep(2.0)
        
        # Scan for 30 seconds (Thinking might take a moment to appear)
        end_time = time.time() + 30
        while time.time() < end_time:
            # Check Stop
            stop_candidates = [
                "button[aria-label='Stop']", 
                "button:has-text('Stop')",
                "button:has-text('Stop generating')"
            ]
            for s in stop_candidates:
                if page.query_selector(s):
                    if not stop_found:
                        print(f"    [+] Found Stop Button (Dynamic): {s}")
                        results['stop_button'] = s
                        stop_found = True
            
            # Check Thinking (mat-expansion-panel)
            think_candidates = [
                "ms-chat-turn:last-of-type mat-expansion-panel", 
                "mat-expansion-panel-header:has-text('Thoughts')",
                "span:has-text('Thinking')",
                "span:has-text('Thoughts')"
            ]
            for t in think_candidates:
                 if page.query_selector(t):
                      if not thinking_found:
                          print(f"    [+] Found Thinking Indicator: {t}")
                          results['thinking_indicator'] = t
                          thinking_found = True
            
            # If we found both, or at least Stop and some time passed, we can relax the loop
            if stop_found and thinking_found:
                break
                
            time.sleep(0.5)

        if not stop_found:
             results['stop_button'] = "button[aria-label='Stop'] # (Not seen)"
        
        # 4. Wait for Completion
        print("[-] Step 4: Waiting for Completion...")
        # Wait until Run button is enabled again
        try:
             run_btn_sel = results.get('run_button', 'button')
             page.wait_for_selector(f"{run_btn_sel}:not([disabled])", timeout=600000)
             # Extra safety: wait even longer for Thinking to resolve if needed
             time.sleep(1.0)
             print(f"    [+] Generation Complete (Run button re-enabled: {run_btn_sel})")
        except Exception:
             print("    [!] Timeout waiting for run button to re-enable (Model might be slow)")

        # 5. Response Container
        print("[-] Step 5: Finding Response...")
        # Check for ms-chat-turn
        potential_responses = ["ms-chat-turn", "[data-turn-role='model']", ".model-turn", "ms-markdown-block"]
        found_response = None
        for r in potential_responses:
            if page.query_selector(r):
                found_response = r
                break
        
        if found_response:
            results['response'] = f"{found_response}, ms-markdown-block"
            print(f"    [+] Found Response Container: {found_response}")
            
            # FIDELITY CHECK
            try:
                print(f"    [.] Verifying content extraction from {found_response}...")
                # We want the LAST turn usually, but for discovery just the first one found is fine/safe? 
                # Actually, "active test" creates a new chat, so there should be 2 turns (User, Model).
                # query_selector finds the first one. User turn might be ms-chat-turn too?
                # We need to distinguish model turn.
                
                # Refine selection to model turn
                model_sel = f"{found_response}:has-text('P=NP')" # Might match user prompt?
                # Better: check data-turn-role or look for model specific attributes if possible.
                # AI Studio usually uses ms-chat-turn for both.
                
                # Let's count them
                count = page.locator(found_response).count()
                print(f"    [i] Found {count} chat turns.")
                
                # Grab the last one (should be the model response to our prompt)
                last_turn_text = page.locator(found_response).last.inner_text()
                if len(last_turn_text) > 10:
                    print(f"    [OK] Content Verification: {len(last_turn_text)} chars extracted.")
                    print(f"    [Sample] {last_turn_text[:100].replace(chr(10), ' ')}...") # chr(10) is newline
                else:
                    print(f"    [!] Content Verification WARNING: Text too short ({len(last_turn_text)} chars).")
            except Exception as e:
                print(f"    [!] Content Verification FAILED: {e}")
        else:
            results['response'] = "ms-chat-turn, ms-markdown-block" # Default fallback
            print("    [!] Could not find response container (using default)")

        # Verify Stop Button is GONE
        print("[-] Step 5b: Verifying Generation Complete (Stop Button)...")
        if 'stop_button' in results:
             if page.query_selector(results['stop_button']):
                 print(f"    [!] WARNING: Stop button {results['stop_button']} is STILL visible!")
             else:
                 print(f"    [OK] Stop button has disappeared (Generation confirmed finished).")

        # 6. Menus (Copy/Delete)
        print("[-] Step 6: Checking Menus...")
        # Hover last turn to see options? Or click "More options"
        try:
             # Find "open options" button in last turn
             opts_sel = "button[aria-label='Open options']"
             if page.query_selector(opts_sel):
                  results['more_options_button'] = opts_sel
                  # Click it to reveal menu items
                  page.locator(opts_sel).last.click()
                  time.sleep(1.0) # Wait for animation
                  
                  # Look for Copy Markdown
                  # Strategy: Find button with specific text or icon inside the menu
                  # Exclude generic "button" unless it has specific role/text
                  copy_strategies = [
                      "button[role='menuitem']:has-text('Copy')",
                      "mat-dialog-container button:has-text('Copy')", 
                      "div[role='menu'] button:has-text('Copy')"
                  ]
                  for cs in copy_strategies:
                      if page.query_selector(cs):
                          results['copy_markdown_button'] = cs
                          print(f"    [+] Found Copy Button: {cs}")
                          break
                  
                  # Close menu (click body)
                  page.mouse.click(0,0)
                  time.sleep(0.5)
        except Exception as e:
             print(f"    [!] Menu check failed: {e}")

        # Delete Button & Dialog (Full Flow)
        print("[-] Step 7: Verifying Delete Flow...")
        try:
             del_sel = "button[aria-label='Delete prompt']" # Usually top right
             chat_menu_sel = "button[aria-label='View more actions']" # Sometimes inside a menu
             
             # Try direct button first
             found_delete = False
             if page.query_selector(del_sel):
                 print("    [+] Found Delete Prompt button (Top Level)")
                 results['delete_prompt_button'] = del_sel
                 page.click(del_sel)
                 found_delete = True
             elif page.query_selector(chat_menu_sel):
                 print("    [+] Found Chat Actions Menu")
                 results['chat_menu_button'] = chat_menu_sel
                 page.click(chat_menu_sel)
                 time.sleep(0.5)
                 if page.query_selector(del_sel):
                     print("    [+] Found Delete Prompt button (Inside Menu)")
                     results['delete_prompt_button'] = del_sel
                     page.click(del_sel)
                     found_delete = True
             
             if found_delete:
                 # Look for Dialog
                 print("    [.] Waiting for Confirm Dialog...")
                 dialog_sel = "mat-dialog-container"
                 try:
                     page.wait_for_selector(dialog_sel, timeout=3000)
                     print(f"    [+] Found Dialog Container: {dialog_sel}")
                     results['dialog_container'] = dialog_sel
                     
                     # Find Confirm Button
                     confirm_sel = f"{dialog_sel} button.ms-button-primary"
                     if page.query_selector(confirm_sel):
                         print(f"    [+] Found Confirm Button: {confirm_sel}")
                         results['dialog_confirm_button'] = confirm_sel
                     
                     # Find Cancel Button (NEW)
                     cancel_sel = f"{dialog_sel} button:not(.ms-button-primary)"
                     if page.query_selector(cancel_sel):
                          print(f"    [+] Found Cancel Button: {cancel_sel}")
                          results['dialog_cancel_button'] = cancel_sel
                          # Click cancel to verify and keep chat? No, user says "delete" flow.
                          # But wait, to be safe we should probably cancel if we don't want to destroy data? 
                          # User asked for delete verification. We'll stick to confirming 
                          # UNLESS we are in a loop where we want to keep testing.
                     
                     # Validate Delete
                     page.click(confirm_sel)
                     print("    [>] Clicked Confirm (Chat Deleted)")
                 except Exception:
                     print("    [!] Dialog did not appear")

        except Exception as e: 
             print(f"    [!] Delete flow failed: {e}")
        
        # 8. Model Name (Sidebar)
        print("[-] Step 8: Checking Model Name...")
        try:
             time.sleep(1.0)
             model_sels = [
                 "ms-model-selector button .title", 
                 "ms-run-settings .title", 
                 "ms-model-selector span.title",
                 "ms-model-selector button .mat-mdc-button-touch-target + .title",
                 "button[data-test-id='model-selector'] .title",
                 ".model-selector-button .title",
             ]
             for sel in model_sels:
                 el = page.query_selector(sel)
                 if el:
                     text = el.inner_text().lower()
                     if "gemini" in text or "learnlm" in text:
                         print(f"    [+] Found Valid Model Name ({text}): {sel}")
                         results['model_name'] = sel
                         break
                     else:
                         print(f"    [?] Ignoring ambiguous model selector: {sel} (text: {text})")
             
             if 'model_name' not in results:
                  print("    [!] Could not find Model Name selector")
        except Exception: pass

        # 9. File Upload (Active)
        print("[-] Step 9: Verifying File Upload Menu...")
        results['attach_button'] = "button[aria-label^='Insert']"
        try:
            if page.query_selector(results['attach_button']):
                print("    [>] Clicking Insert Menu...")
                page.click(results['attach_button'])
                time.sleep(1.5)
                
                # Check for file input (class-based selector preferred)
                file_selectors = ["input.file-input", "input[type='file']"]
                for file_sel in file_selectors:
                    if page.query_selector(file_sel):
                        print(f"    [+] Found File Input (Active): {file_sel}")
                        results['file_input'] = file_sel
                        break
                
                page.mouse.click(0, 0)
                time.sleep(0.5)
            else:
                 print("    [!] Could not find Attach button to verify File Input")
                 results['file_input'] = "input.file-input # (Not verified)"
        except Exception as e:
            print(f"    [!] File upload check failed: {e}")
            results['file_input'] = "input.file-input"

        # 10. Media Containers & Error Detection
        print("[-] Step 10: Checking Media Container Selectors...")
        media_container_sels = [
            "[data-test-id='prompt-media-container']",
            ".prompt-media-item-container",
        ]
        for sel in media_container_sels:
            el = page.query_selector(sel)
            if el:
                print(f"    [+] Found Media Container: {sel}")
                results['media_container'] = sel
                break
            else:
                print(f"    [.] Not present (no uploads): {sel}")
        
        # Check for error detection selectors (only relevant with uploads)
        error_sels = [
            ".prompt-media-item-container.has-error",
            "[data-test-id='prompt-media-container'].has-error",
        ]
        for sel in error_sels:
            print(f"    [i] Error selector registered: {sel}")
        results['media_error_selector'] = ".prompt-media-item-container.has-error"
        
        # Check for remove media button pattern
        remove_sels = [
            "button[aria-label='Remove media']",
            "button[aria-label*='Remove']",
            ".action-button",
        ]
        for sel in remove_sels:
            print(f"    [i] Remove button pattern: {sel}")
        results['remove_media_button'] = "button[aria-label='Remove media']"

        # ---------------------------------------------------------
        # VALIDATION & ANTI-HALLUCINATION
        # ---------------------------------------------------------
        print("\n" + "="*60)
        print("VALIDATION & RISK ANALYSIS")
        print("="*60)
        
        verified_results = {}
        for key, sel in results.items():
            risk_score = 0
            warnings = []
            
            # 1. Uniqueness Check
            try:
                count = page.locator(sel).count()
                if count == 0:
                    warnings.append("count=0 (Not found currently)")
                    risk_score += 10
                elif count > 1:
                     if key in ['run_button', 'textarea']: # Should be unique
                         warnings.append(f"count={count} (Ambiguous)")
                         risk_score += 5
            except Exception: pass
            
            # 2. Stability Check (Obfuscation)
            import re
            if re.search(r'\.[a-zA-Z0-9]{4,8}(-|$)', sel): # e.g. .css-1a2b3c
                warnings.append("Obfuscated class detected (Unstable)")
                risk_score += 8
                
            # 3. Quality Check
            if "aria-label" in sel:
                pass # Gold standard
            elif "role=" in sel:
                risk_score += 1
            elif ":has-text" in sel:
                risk_score += 2 # Text can change (localization)
            else:
                risk_score += 5 # Generic selector
                
            # Report
            if risk_score > 5:
                print(f" [!] {key:<20}: {sel[:40]}... | Risk: HIGH ({', '.join(warnings)})")
            elif risk_score > 0:
                print(f" [~] {key:<20}: {sel[:40]}... | Risk: LOW  ({', '.join(warnings)})")
            else:
                print(f" [OK] {key:<20}: Verified Stable")
                
            verified_results[key] = sel

        
        # ---------------------------------------------------------
        # DIFF REPORT & SMART VERIFICATION
        # ---------------------------------------------------------
        print("\n" + "="*60)
        print("SELECTOR DIFF REPORT")
        print("="*60)
        
        current_selectors = config.get('selectors', {})
        
        # Calculate Diff with Smart Awareness
        all_keys = set(verified_results.keys()) | set(current_selectors.keys())
        has_changes = False
        
        for key in sorted(all_keys):
            new_val = verified_results.get(key)
            old_val = current_selectors.get(key)
            
            if new_val == old_val:
                print(f" [=] {key:<25}: UNCHANGED")
            elif old_val and new_val:
                # SMART CHECK: Is new_val one of the strategies in old_val?
                old_list = [s.strip() for s in str(old_val).split(',')]
                if new_val in old_list:
                    print(f" [=] {key:<25}: STABLE (Strategy matches existing list)")
                else:
                    print(f" [~] {key:<25}: MODIFIED")
                    print(f"     OLD: {old_val}")
                    print(f"     NEW: {new_val}")
                    has_changes = True
            elif old_val is None:
                print(f" [+] {key:<25}: NEW      -> {new_val}")
                has_changes = True
            elif new_val is None:
                print(f" [-] {key:<25}: REMOVED  (was {old_val})")
                has_changes = True

        print("-" * 60)
        
        # ---------------------------------------------------------
        # MIGRATION & BACKUP
        # ---------------------------------------------------------
        if has_changes:
             print("\n" + "="*60)
             print("MIGRATION")
             print("="*60)
             
             # Prompt User
             target_path = get_effective_config_path()
             try:
                 resp = input(f"Apply these changes to {os.path.relpath(target_path)}? [y/N] ").strip().lower()
             except Exception:
                 resp = "n"
                 
             if resp == 'y':
                 # 1. Backup
                 import shutil
                 timestamp = time.strftime("%Y%m%d_%H%M%S")
                 backup_dir = os.path.join(os.getcwd(), "deleted", "configs")
                 os.makedirs(backup_dir, exist_ok=True)
                 backup_path = os.path.join(backup_dir, f"config_backup_{timestamp}.yaml")
                 
                 try:
                     if os.path.exists(target_path):
                         shutil.copy(target_path, backup_path)
                         print(f" [i] Backup created: {os.path.relpath(backup_path)}")
                     else:
                         print(f" [i] New config to be created at: {os.path.relpath(target_path)}")
                 except Exception as e:
                     print(f" [!] Backup failed: {e}. Aborting.")
                     return

                 # 2. Update Config
                 try:
                     # Load fresh to preserve comments/structure? YAML is lossy.
                     # We'll just update the dict and dump.
                     config['selectors'] = verified_results
                     if 'selector_metadata' not in config:
                         config['selector_metadata'] = {}
                     
                     config['selector_metadata']['last_updated'] = time.strftime("%Y-%m-%d %H:%M:%S")
                     config['selector_metadata']['verified_by'] = 'scripts/discover_selectors.py'
                     
                     with open(target_path, "w") as f:
                         yaml.dump(config, f, sort_keys=False)
                     print(f" [+] {os.path.relpath(target_path)} updated successfully.")
                 except Exception as e:
                     print(f" [!] Update failed: {e}")
             else:
                 print(" [i] Changes discarded.")
        else:
             print(" [OK] Configuration is up to date.")

def discover_selectors_cli():
    """CLI entry point for selector discovery."""
    print("============================================================")
    print(" Frankenreview Selector Discovery (Agentic Mode)")
    print("============================================================")
    
    # Config check is now handled inside discover_active via load_config
    # which returns a minimal dict if no file is found.
    # We always allow discovery to run and create the config on save.

    discover_active()

if __name__ == "__main__":
    discover_selectors_cli()
