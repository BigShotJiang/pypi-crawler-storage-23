"""
Frankenreview v11 - Research Mode Module

Provides agentic deep research functionality via browser automation.
Takes a user prompt file and runs it through Gemini 3 Pro / Gemini 2.5 Pro
for structured research output.

Usage:
    frankenreview --research --prompt research_topic.md --output research_output.md
"""

import time
from pathlib import Path
from typing import Optional
from datetime import datetime

from ..utils.log_config import get_logger
from ..utils.output import out
from ..utils.ui import prompt_with_timeout

# Module logger
log = get_logger("frankenreview.research")

# Research system prompt template
RESEARCH_SYSTEM_PROMPT = """# FRANKENREVIEW RESEARCH AGENT

You are a Senior Research Analyst with PhD-level expertise. You are conducting 
deep, rigorous research for a software engineering team. Your findings will 
directly influence technical decisions.

## Your Research Protocol

1. **Understand Deeply:** Parse the research question completely before responding
2. **Multiple Perspectives:** Consider alternative approaches and trade-offs
3. **Cite Sources:** Reference real technologies, papers, versions, and dates
4. **Structure Output:** Make findings scannable and actionable
5. **Flag Uncertainties:** Explicitly state "UNCERTAINTY:" when unsure

## Required Output Format

### 1. Executive Summary
2-3 sentences distilling the core answer to the research question.

### 2. Key Findings
Numbered list of critical discoveries with brief explanations.
Each finding should be actionable or informative.

### 3. Technical Analysis
Deep dive into implementation considerations:
- Architecture implications
- Technology choices and trade-offs
- Integration considerations
- Performance characteristics

### 4. Risks & Challenges
What could go wrong:
- Technical risks
- Operational concerns
- Scalability issues
- Maintenance burden

### 5. Recommended Approach
Actionable next steps in priority order:
1. Immediate actions
2. Short-term implementations
3. Long-term considerations

### 6. Open Questions
What needs further investigation before proceeding.

## Constraints

- **Be Brutally Honest:** Do not oversell or undersell
- **No Hallucination:** If you don't know, say so
- **Cite Specifics:** Technologies, versions, dates where applicable
- **Keep Under 3000 Tokens:** Be concise and high-impact

---

## USER RESEARCH TOPIC

"""


def run_research(
    prompt_path: Path,
    output_path: Path,
    model: str = "gemini-3-pro-preview",
    verbose: bool = False,
    port: int = 9222
) -> int:
    """
    Execute research workflow via browser automation.
    
    Args:
        prompt_path: Path to file containing research prompt/question
        output_path: Path to write research output
        model: Model ID to use (gemini-3-pro-preview or gemini-2.5-pro)
        verbose: Enable verbose logging
        port: Debugger port for Chrome
        
    Returns:
        Exit code (0 = success, 1 = error)
    """
    from ..engine.browser import StudioClient
    from ..cli import start_chrome
    
    log.info(f"Starting research mode with model: {model}")
    
    
    # Check if input is a file path or raw text
    prompt_str = str(prompt_path)
    if Path(prompt_str).exists():
        try:
            user_prompt = Path(prompt_str).read_text(encoding='utf-8')
            prompt_source_name = Path(prompt_str).name
        except Exception as e:
            log.error(f"Failed to read prompt file: {e}")
            return 1
    else:
        # Treat as raw string input
        user_prompt = prompt_str
        prompt_source_name = "cli_input"
        
        # Save to file for record keeping
        try:
            # Ensure .frankenreview exists
            fr_dir = Path.cwd() / ".frankenreview"
            fr_dir.mkdir(exist_ok=True)
            record_path = fr_dir / "research_input.md"
            with open(record_path, "w", encoding="utf-8") as f:
                f.write(user_prompt)
        except Exception:
            pass
    
    if len(user_prompt.strip()) < 5:
        log.error("Prompt too short (< 5 characters)")
        return 1
    
    log.info(f"Research Query: {user_prompt[:50]}... ({len(user_prompt)} chars)")
    
    # Build full prompt
    full_prompt = RESEARCH_SYSTEM_PROMPT + user_prompt
    
    # Load config
    # Priority 1: Current Working Directory (User Config)
    config_path = Path.cwd() / "config.yaml"
    
    # Priority 2: Project Root (Deduced from package location)
    if not config_path.exists():
        # research.py -> agents -> frankenreview -> src -> ROOT
        config_path = Path(__file__).resolve().parent.parent.parent.parent / "config.yaml"
    
    config = {}
    if config_path.exists():
        import yaml
        try:
            with open(config_path) as f:
                config = yaml.safe_load(f) or {}
                # log.info(f"Loaded config from: {config_path}")
        except Exception:
            pass
    
    # Set research model URL
    config['chat_url'] = f"https://aistudio.google.com/prompts/new_chat?model={model}"
    
    # Enable thinking mode only for actual thinking models
    if 'thinking' in model.lower() or ('gemini-3' in model and 'flash' not in model.lower()):
        config['thinking_mode'] = True
    
    # Connect to Chrome
    try:
        client = StudioClient(debugger_port=port, config=config, model=model)
    except Exception as e:
        if "Chrome not found on port" in str(e):
            # Try to help the user
            from ..cli import is_port_in_use, get_chrome_path
            if not is_port_in_use(port):
                print(f"\n[!] Chrome is not running on port {port}.")
                choice = prompt_with_timeout("[?] Would you like to start Chrome now?", timeout=5, default='y')
                if choice == 'y':
                    from ..cli import start_chrome
                    if start_chrome(port=port):
                        print("[i] Waiting 3s for Chrome to initialize...")
                        time.sleep(3)
                        # Retry connection
                        try:
                            client = StudioClient(debugger_port=port, config=config, model=model)
                        except Exception as retry_e:
                            log.error(f"Retry failed: {retry_e}")
                            return 1
                    else:
                        log.error("Failed to auto-start Chrome.")
                        return 1
                else:
                    log.error(f"Failed to connect to Chrome: {e}")
                    return 1
            else:
                 log.error(f"Failed to connect to Chrome: {e}")
                 return 1
        else:
            log.error(f"Failed to connect to Chrome: {e}")
            return 1
    
    # Send to AI Studio
    out.info(f"Sending research prompt to AI Studio (Model: {model})...")
    start_time = time.time()
    
    try:
        # Use send_review but with no XML attachment (pure text prompt)
        response = client.send_review(full_prompt)
    except Exception as e:
        log.error(f"Research failed: {e}")
        return 1
    
    elapsed = time.time() - start_time
    log.info(f"Research completed in {elapsed:.1f}s")
    
    if response.startswith("Error:"):
        log.error(f"Research failed: {response}")
        return 1
    
    # Write output
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = f"""# Frankenreview Research Output

**Generated:** {timestamp}  
**Model:** {model}  
**Prompt Source:** {prompt_source_name}

---

"""
    
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(header)
            f.write(response)
    except Exception as e:
        log.error(f"Failed to write output: {e}")
        return 1
    
    # Print summary
    try:
        rel_output = output_path.relative_to(Path.cwd())
    except ValueError:
        rel_output = output_path
    
    out.ok(f"Research complete ({elapsed:.1f}s): {rel_output}")
    print(f"[i] Agent Context: Research output is in {rel_output}. Read this file for findings.")
    
    return 0


def run_feature_research(
    query: str,
    project_root: Path,
    output_path: Path,
    model: str = "gemini-3-pro-preview", 
    verbose: bool = False,
    port: int = 9222
) -> int:
    """
    Run feature research combining Repo Dump + User Query.
    
    Args:
        query: User's research question (e.g. "How do I implement auth?")
        project_root: Path to project root
        output_path: Output file path
        model: Model ID to use
        verbose: Verbose logging
        
    Returns:
        Exit code (0=success)
    """
    from ..engine.repo_dumper import dump_repo
    from ..engine.token_governor import optimize_dump
    from ..engine.browser import StudioClient
    from ..utils.workspace import get_dump_dir, ensure_fr_folder

    # 1. Setup paths
    ensure_fr_folder(str(project_root))
    dump_dir = get_dump_dir(str(project_root))
    
    # Check if query is a file path (and not just a long research query)
    if len(query) < 255 and Path(query).exists():
        try:
            log.info(f"Loading feature research prompt from file: {query}")
            query_content = Path(query).read_text(encoding='utf-8')
            # Save original query filename for record
            input_record = f"File: {query}\n\n{query_content}"
        except Exception as e:
            log.error(f"Failed to read query file: {e}")
            return 1
    else:
        query_content = query
        input_record = query

    # Save query to input record
    try:
        fr_dir = Path.cwd() / ".frankenreview"
        fr_dir.mkdir(exist_ok=True)
        record_path = fr_dir / "research_input.md"
        with open(record_path, "w", encoding="utf-8") as f:
            f.write(input_record)
    except Exception as e:
        log.warning(f"Failed to save research input record: {e}")
    
    # 2. Generate XML Dump
    log.info("Generating repository context for research...")
    config_path = project_root / "config.yaml"
    config = {}
    if config_path.exists():
        import yaml
        with open(config_path) as f:
            config = yaml.safe_load(f) or {}

    dump_path = dump_repo(
        str(project_root), 
        str(dump_dir), 
        prune_dirs=config.get('prune_dirs'), 
        prune_files=config.get('prune_files'),
        prune_exts=config.get('prune_exts')
    )
    
    if not dump_path:
        log.error("Failed to generate dump")
        return 1
        
    # 3. Read & Optimize Context
    with open(dump_path, 'r', encoding='utf-8') as f:
        xml_content = f.read()
        
    # Optimize (hard limit to 1M chars for research to leave room for output)
    xml_content = optimize_dump(xml_content, max_tokens=1000000)
    
    # 4. Construct Prompt
    # We use a special research prompt that includes the context
    system_prompt = f"""# FEATURE RESEARCH AGENT
    
You are a Lead Architect answering a specific implementation question about this codebase.

## QUESTION:
{query_content}

## INSTRUCTIONS:
1. Analyze the provided codebase XML
2. Provide a concrete implementation strategy
3. Cite specific files/functions to modify
4. Warn about side effects or dependencies
5. Be practical and code-focused

---

## REPOSITORY CONTEXT:
"""
    
    full_prompt = system_prompt + "\n\n(XML ATTACHED)"
    
    # 5. Send to AI Studio
    # Configure client
    config['chat_url'] = f"https://aistudio.google.com/prompts/new_chat?model={model}"
    if 'thinking' in model.lower() or ('gemini-3' in model and 'flash' not in model.lower()):
        config['thinking_mode'] = True
        
    try:
        client = StudioClient(debugger_port=port, config=config, model=model)
    except Exception as e:
        if "Chrome not found on port" in str(e):
             # Try to help the user
            from ..cli import is_port_in_use, get_chrome_path
            if not is_port_in_use(port):
                print(f"\n[!] Chrome is not running on port {port}.")
                choice = prompt_with_timeout("[?] Would you like to start Chrome now?", timeout=5, default='y')
                if choice == 'y':
                    from ..cli import start_chrome
                    if start_chrome(port=port):
                        print("[i] Waiting 3s for Chrome to initialize...")
                        time.sleep(3)
                        # Retry connection
                        try:
                            client = StudioClient(debugger_port=port, config=config, model=model)
                        except Exception as retry_e:
                            log.error(f"Retry failed: {retry_e}")
                            return 1
                    else:
                        log.error("Failed to auto-start Chrome.")
                        return 1
                else:
                    log.error(f"Failed to connect to Chrome: {e}")
                    return 1
            else:
                 log.error(f"Failed to connect to Chrome: {e}")
                 return 1
        else:
            log.error(f"Failed to connect to Chrome: {e}")
            return 1
        
    out.info(f"Sending feature research query: '{query}' (Model: {model})...")
    start_time = time.time()
    
    try:
        # Send query + XML attachment
        response = client.send_review(full_prompt, xml_content=xml_content)
    except Exception as e:
        log.error(f"Research failed: {e}")
        return 1
        
    elapsed = time.time() - start_time
    
    # 6. Write Output
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = f"""# Feature Research: {query}

**Generated:** {timestamp}
**Model:** {model}
**Context:** {Path(dump_path).name}

---

"""
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(header)
            f.write(response)
    except Exception as e:
        log.error(f"Failed to write output: {e}")
        return 1
        
    out.ok(f"Feature research complete ({elapsed:.1f}s): {output_path}")
    return 0


def get_available_models() -> dict:
    """
    Return dictionary of available research models.
    
    Returns:
        Dict mapping model aliases to full model IDs
    """
    return {
        "gemini-3-pro": "gemini-3-pro-preview",
        "gemini-2.5-pro": "gemini-2.5-pro",
        "3-pro": "gemini-3-pro-preview",
        "2.5-pro": "gemini-2.5-pro",
    }
