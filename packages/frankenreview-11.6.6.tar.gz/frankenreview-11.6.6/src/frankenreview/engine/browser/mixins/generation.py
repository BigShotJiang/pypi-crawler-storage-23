"""
Generation monitoring and response extraction.
CRITICAL: Contains _fallback_scrape with intricate 85-line DOM extraction logic.
"""
import time
import sys
import os


class GenMixin:
    """Mixin providing generation monitoring and response scraping."""
    def _wait_generation_done(self, page, timeout=180, min_count=0, initial_started=False):
        """
        Wait for generation to complete with robust virtualization handling.
        
        Handles:
        - Model-based timeout configuration (Flash: 60s, Thinking: 300s)
        - Virtualization-aware character counting (forced scroll before measurement)
        - Incremental temp file saves for crash recovery
        - Rate limit detection and automatic model switching
        
        Args:
            page: Playwright page object
            timeout: Base timeout in seconds (will be adjusted by model type)
            min_count: Minimum model turn count to wait for
            initial_started: Whether generation start was already confirmed
            
        Returns:
            True if generation completed, "RATE_LIMIT_SWITCH" for failover, False on error
        """
        # Model-based thinking mode detection (NOT mat-expansion-panel based)
        model_id = self.active_model_id.lower() if self.active_model_id else ""
        is_thinking_model = 'thinking' in model_id or ('gemini-3' in model_id and 'flash' not in model_id)
        is_fast_model = 'flash' in model_id or 'lite' in model_id
        
        # Configure timeouts based on model type
        if is_thinking_model:
            timeout = max(timeout, 300)
            stability_threshold = 30  # Thinking models need more stability time
            print(f"   [*] Thinking Model detected. Timeout: {timeout}s, Stability: {stability_threshold}s")
        elif is_fast_model:
            timeout = min(timeout, 90)  # Fast models should complete quickly  
            stability_threshold = 5
            print(f"   [i] Fast Model detected. Timeout: {timeout}s, Stability: {stability_threshold}s")
        else:
            stability_threshold = 10
            print(f"   [i] Standard Model. Timeout: {timeout}s, Stability: {stability_threshold}s")
        
        # Selectors from config (with robust fallbacks)
        run_selector = self.selectors.get('run_button', "button:has-text('Run')") + ", button[aria-label*='Run'], button[aria-label*='Send']"
        stop_selector = self.selectors.get('stop_button', "button:has-text('Stop')") + ", button[aria-label*='Stop']"
        
        error_selectors = [
            ".mat-mdc-snack-bar-container",
            ".error-notification",
            "div:has-text('too long')",
            "div:has-text('limit exceeded')",
        ]
        
        # Incremental save setup
        partial_save_path = os.path.join(os.path.expanduser("~"), ".frankenreview", "partial_response.md")
        os.makedirs(os.path.dirname(partial_save_path), exist_ok=True)
        last_save_time = time.monotonic()
        save_interval = 5.0  # Save every 5 seconds

        # 1. Wait for generation to actually START
        start_wait_end = time.monotonic() + 15
        started = initial_started
        if not started:
            print("   [.] Waiting for generation to start...")
            while time.monotonic() < start_wait_end:
                # CHECK RATE LIMIT FAILOVER
                if self._check_rate_limit(page):
                    print("   [!] Rate Limit detected during startup.")
                    if self._switch_model(page):
                         print("   [>] Switched model. Signaling full restart...")
                         return "RATE_LIMIT_SWITCH"
                    else:
                        return False
                
                # STUCK DETECTION: Retry Click if 10s passed with no start
                if time.monotonic() > (start_wait_end - 5) and not started:
                    print("   [!] Generation start delayed. Retrying Run click...")
                    try:
                        run_loc = page.locator(run_selector.split(',')[0].strip())
                        if run_loc.count() > 0:
                            run_loc.first.click()
                    except Exception: pass

                try:
                    if self._verify_generation_triggered(page, initial_count=min_count, timeout=1.0):
                        started = True
                        break
                except Exception: pass
                time.sleep(0.5)
        else:
            print("   [i] Generation start already confirmed.")
            
        if started:
            print("   [>] Generation started...")
        else:
            print("   [!] Generation didn't signal start clearly. Checking anyway...")

        # Display active model from UI for verification
        active_model = self._get_active_model_name(page)
        print(f"   [i] Active Model (UI): {active_model}")

        # 2. Main wait loop
        end = time.monotonic() + timeout
        loop_start = time.monotonic()  # For exponential backoff calculation
        last_log_time = 0
        stop_was_visible = False
        
        # Stability tracking
        stability_counter = 0
        last_len = 0
        max_len_seen = 0  # Track max to detect virtualization drops

        while time.monotonic() < end:
            # CHECK RATE LIMIT FAILOVER
            if self._check_rate_limit(page):
                print("   [!] Rate Limit detected during generation loop.")
                if self._switch_model(page):
                     print("   [>] Switched model. Signaling full restart...")
                     return "RATE_LIMIT_SWITCH"
                else:
                    return False

            try:
                current_count = self._get_model_turn_count(page)
                
                # Check for errors
                for sel in error_selectors:
                    try:
                        loc = page.locator(sel)
                        if loc.count() > 0 and loc.first.is_visible():
                            txt = loc.first.inner_text().lower()
                            if "skip to main content" in txt:
                                continue
                            if any(w in txt for w in ['too long', 'exceeds', 'limit', 'rejected', 'failed', 'error']):
                                print(f"   [x] Model error: {txt[:100]}")
                                return False
                    except Exception: pass

                # Force scroll to bottom and get character count (virtualization-aware)
                now = time.monotonic()
                if now - last_log_time > 1.0:
                    # Forced scroll before measurement to handle virtualization
                    self._scroll_to_bottom(page)
                    time.sleep(0.1)  # Brief pause for render
                    
                    # Detect stop button state
                    stop_loc = page.locator(stop_selector.split(',')[0].strip())
                    is_stop_visible = stop_loc.count() > 0 and stop_loc.first.is_visible()
                    
                    # Get text length with forced scroll-into-view
                    current_len = page.evaluate("""() => {
                        const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
                        if (!lastTurn) return 0;
                        
                        // Force scroll into view to ensure DOM is mounted
                        lastTurn.scrollIntoView({ behavior: 'instant', block: 'end' });
                        
                        const clone = lastTurn.cloneNode(true);
                        // Remove thinking blocks and UI noise
                        const remove = clone.querySelectorAll('mat-expansion-panel, .model-thoughts, ms-thought-chunk, .turn-footer');
                        remove.forEach(el => el.remove());
                        return clone.innerText.length;
                    }""")
                    
                    # Virtualization recovery: if count dropped to 0 but we had content, force re-scroll
                    if current_len == 0 and max_len_seen > 100:
                        self._scroll_to_bottom(page)
                        time.sleep(0.3)
                        current_len = page.evaluate("""() => {
                            const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
                            if (!lastTurn) return 0;
                            lastTurn.scrollIntoView({ behavior: 'instant', block: 'center' });
                            return lastTurn.innerText.length;
                        }""")
                    
                    max_len_seen = max(max_len_seen, current_len)
                    
                    remaining = int(end - now)
                    if is_stop_visible:
                        sys.stdout.write(f"\033[2K\r   [>] Generating... ({remaining}s) | {current_len:,} chars")
                    else:
                        sys.stdout.write(f"\033[2K\r   [○] Waiting... ({remaining}s) | {current_len:,} chars")
                    sys.stdout.flush()
                    last_log_time = now
                    
                    # Incremental save for crash recovery
                    if now - last_save_time > save_interval and current_len > 100:
                        try:
                            partial_text = self._fallback_scrape(page, silent=True)
                            if partial_text and len(partial_text) > 50:
                                with open(partial_save_path, 'w', encoding='utf-8') as f:
                                    f.write(f"# PARTIAL RESPONSE (Saved at {time.strftime('%H:%M:%S')})\n\n")
                                    f.write(partial_text)
                                last_save_time = now
                        except Exception: pass

                if is_stop_visible:
                    stop_was_visible = True
                    
                # Check Run Button
                run_loc = page.locator(run_selector.split(',')[0].strip())
                is_disabled = True
                
                if run_loc.count() > 0:
                    btn = run_loc.first
                    attr_disabled = btn.get_attribute("disabled")
                    attr_aria = btn.get_attribute("aria-disabled")
                    is_disabled = (attr_disabled is not None) or (attr_aria == "true")

                    # Case A: Run button re-enabled (Standard completion)
                    if not is_disabled and not is_stop_visible:
                        print("\n   [+] Generation complete (Run button enabled)")
                        return True
                        
                    # Case B: Stop button vanished 
                    if stop_was_visible and not is_stop_visible:
                        print("\n   [+] Generation complete (Stop button vanished)")
                        time.sleep(1.5)
                        return True

                    # Case C: Stability Override (text unchanged for threshold seconds)
                    if current_len > 5:
                        if current_len == last_len:
                            stability_counter += 1
                            if stability_counter >= stability_threshold:
                                print(f"\n   [+] Generation complete (Text stable for {stability_counter}s)")
                                return True
                        else:
                            stability_counter = 0
                    last_len = current_len

                    # Case D: Fallback for fast models (new content + Run enabled)
                    if not is_disabled and current_count > min_count:
                        print("\n   [+] Generation complete (Run enabled + new content)")
                        return True
                            
            except Exception as e:
                if "SyntaxError" in str(e) or "ReferenceError" in str(e):
                    print(f"   [!] Critical Loop Error: {e}")
            
            # Exponential backoff: increase polling interval after 60s to reduce CPU pressure
            elapsed = time.monotonic() - loop_start
            if elapsed > 60:
                time.sleep(2.0)  # Slower polling for long generations
            else:
                time.sleep(0.5)
            
        print("\n   [!] Timed out waiting for generation.")
        return False


    def _wait_response_stable(self, page, settle_seconds=2.0, timeout=60, min_length=1):
        """
        Poll the response text to ensure it has stopped changing.
        Filters out 'Thinking' blocks to focus only on the final output.
        For Thinking models, requires min_length chars to ensure actual response exists.
        """
        print("   [.] Checking text stability...")
        
        # Aggressive scrolling to trigger virtualization
        self._scroll_to_bottom(page)
        time.sleep(1.0) # Wait for render
        
        last_text = ""
        stable_start = None
        copy_button_selectors = self.selectors.get('copy_markdown_button', "button[role='menuitem']").split(', ')
        run_sel = self.selectors.get('run_button', "button[aria-label='Run']")
        stop_sel = self.selectors.get('stop_button', "button[aria-label*='Stop']")
        thinking_sel = self.selectors.get('thinking_indicator')
        end = time.monotonic() + timeout
        
        # Script to extract clean response text (EXCLUDING thinking blocks and UI noise)
        extract_script = """() => {
            const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
            if (!lastTurn) return "";
            
            const clone = lastTurn.cloneNode(true);
            
            // Remove thinking expansion panels COMPLETELY
            const thinking = clone.querySelectorAll('mat-expansion-panel, .model-thoughts, ms-thought-chunk');
            thinking.forEach(t => t.remove());
            
            // Remove UI noise elements
            const noise = clone.querySelectorAll('.author-label, .turn-footer, .actions-container, button, .xap-inline-dialog');
            noise.forEach(n => n.remove());
            
            const contentDiv = clone.querySelector('.turn-content');
            if (contentDiv) {
                return contentDiv.textContent.trim();
            }
            return clone.textContent.trim();
        }"""
        
        while time.monotonic() < end:
            try:
                text = page.evaluate(extract_script)
                
                # For Thinking models: require minimum text length to ensure actual response exists
                if len(text) < min_length:
                    stable_start = None
                    last_text = text
                    time.sleep(1.0)
                    continue
                
                if text == last_text:
                    if stable_start is None:
                        stable_start = time.monotonic()
                    elif time.monotonic() - stable_start >= settle_seconds:
                        print(f"   [+] Text stable (length: {len(text):,} chars)")
                        return True
                else:
                    stable_start = None
                    last_text = text
            except Exception:
                pass
            
            # Copy-as-markdown button appeared -> assume response is ready
            copy_ready = False
            for sel in copy_button_selectors:
                sel = sel.strip()
                if not sel:
                    continue
                try:
                    loc = page.locator(sel)
                    if loc.count() > 0 and loc.first.is_visible():
                        copy_ready = True
                        break
                except Exception:
                    continue

            if copy_ready and len(text) > 0 and (not self.config.get('thinking_mode') or len(text) >= min_length):
                print("   [i] Copy menu available - assuming text has stabilized.")
                return True

            # Stop vanished and Run visible (any state) -> likely done
            try:
                stop_visible = page.locator(stop_sel).count() > 0 and page.locator(stop_sel).first.is_visible()
                run_visible = page.locator(run_sel).count() > 0 and page.locator(run_sel).first.is_visible()
                thinking_visible = False
                if thinking_sel:
                    thinking_loc = page.locator(thinking_sel)
                    thinking_visible = thinking_loc.count() > 0 and thinking_loc.first.is_visible()
                if run_visible and not stop_visible and not thinking_visible and len(text) >= min_length:
                    if stable_start is None:
                        stable_start = time.monotonic()
                    elif time.monotonic() - stable_start >= settle_seconds:
                        print("   [i] Stop gone + Run visible. Treating response as stable.")
                        return True
            except Exception:
                pass

            time.sleep(1.0)
            
        print("   [!] Stability timeout (proceeding anyway)")
        return False


    def _wait_for_response(self, page, initial_count=0, start_confirmed=False):
        """
        Wait for AI response generation to complete and extract via 'Copy as markdown'.
        Strategy: Hover over response -> Click 'More options' -> Click 'Copy as markdown'
        """
        print("   [.] Waiting for generation to complete...")
        
        # Step 1: Wait for completion (and check errors)
        status = self._wait_generation_done(page, timeout=180, min_count=initial_count, initial_started=start_confirmed)
        if status == "RATE_LIMIT_SWITCH":
             return "RATE_LIMIT_SWITCH"
        if not status:
             # For safety, let stability code run anyway but it might fail
             pass
        
        # Step 2: Ensure Text Stability
        # If Thinking Mode, give it more time (300s) and higher min_length
        is_thinking = self.config.get('thinking_mode', False)
        stability_timeout = 300 if is_thinking else 60
        min_len = 50 if is_thinking else 1
        
        self._wait_response_stable(page, timeout=stability_timeout, min_length=min_len)
        
        print("   [>] Extracting text...")
        
        # Check if clipboard extraction is enabled
        # P1 Fix: Force False to prevent Race Condition
        use_clipboard = False # self.config.get('use_clipboard_for_extraction', True)

        # Override: If Thinking Mode is enabled, force Smart Scrape to remove thought artifacts
        if self.config.get('thinking_mode', False):
             print("   [i] Thinking Mode detected. Forcing Smart Scrape to remove thought artifacts.")
             use_clipboard = False
        
        if not use_clipboard:
             print("   [i] Clipboard extraction disabled. Using Smart Scrape.")
             return self._fallback_scrape(page)
        
        try:
            # Wait a bit for everything to render
            time.sleep(1)
            
            # Hover Strategy to reveal the menu
            # Hover Strategy to reveal the menu
            # JS to find the last response and specific menu button for it
            copy_script = """async () => {
                const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
                if (!lastTurn) return { success: false, error: "No turns found" };
                
                // 1. Force Scroll into view (Critical for Virtual Scrolling)
                lastTurn.scrollIntoView({block: 'center'});
                
                // 2. Wait for hydration/rendering (Virtual DOM needs a moment)
                await new Promise(r => setTimeout(r, 500));
                
                // 3. Debug context capture (AFTER scroll)
                const dump = {
                    outerHTML: lastTurn.outerHTML,
                    innerText: lastTurn.innerText,
                    rect: lastTurn.getBoundingClientRect()
                };
                
                // 4. Hover
                const mouseEvent = new MouseEvent('mouseover', {
                    view: window, bubbles: true, cancelable: true
                });
                lastTurn.dispatchEvent(mouseEvent);
                
                // 5. Find Options menu
                let menuBtn = lastTurn.querySelector('button[aria-label="Open options"]');
                if (!menuBtn) return { success: false, error: "Options menu button not found" };
                
                menuBtn.click();
                return { success: true, preview: dump.innerText.substring(0, 50), dump: dump };
            }"""
            
            result = page.evaluate(copy_script)
            
            # Save Debug Dump if available
            if result.get("dump"):
                try:
                    # Save to .frankenreview/ folder
                    project_root = self.config.get('project_root', '.')
                    fr_folder = os.path.join(project_root, '.frankenreview')
                    os.makedirs(fr_folder, exist_ok=True)
                    dump_path = os.path.join(fr_folder, "last_response_dump.html")
                    with open(dump_path, "w", encoding='utf-8') as f:
                        f.write(f"<!-- InnerText: {result['dump'].get('innerText')} -->\n")
                        f.write(result['dump'].get('outerHTML', ''))
                    print(f"   [d] Saved HTML dump to {self._rel_path(dump_path)}")
                except Exception as e:
                    print(f"   [!] Could not save dump: {e}")

            if not result.get("success"):
                print(f"   [x] JS Error: {result.get('error')}")
                if result.get("debug_roles"):
                    print(f"   [d] Available roles on page: {result.get('debug_roles')}")

            if result.get("success"):
                print(f"   [>] Targeted response preview: '{result.get('preview')}...'")
                time.sleep(0.5) # Wait for menu to open
                
                # Screenshot just before copying (menu should be open)
                self._capture_debug(page, "before-copy-markdown")

                # 4. Click 'Copy as markdown' using JS to avoid scrollbar interception
                click_copy_script = """() => {
                const selectors = [
                        "button[role='menuitem']",
                        "li[role='menuitem']", 
                        ".mat-mdc-menu-item"
                    ];
                    
                    // Find visible menu items
                    let items = [];
                    for (let s of selectors) {
                        items = items.concat(Array.from(document.querySelectorAll(s)));
                    }
                    
                    // Find the one with text 'Copy as markdown'
                    let copyBtn = items.find(el => el.innerText.includes("Copy as markdown"));
                    
                    if (!copyBtn) {
                        // Fallback: Look for icon-based button (new UI)
                        const icon = document.querySelector("span.copy-markdown-button");
                        if (icon) {
                            copyBtn = icon.closest("button");
                        }
                    }

                    if (copyBtn) {
                        copyBtn.click();
                        return true;
                    }
                    return false;
                }"""
                
                if page.evaluate(click_copy_script):
                    print("   [+] Clicked 'Copy as markdown' (JS)")
                    clicked_copy = True
                else:
                    print("   [!] JS Click failed, trying Playwright fallback...")
                    # Fallback to Playwright
                    copy_btn_sel = [
                        "button[role='menuitem']:has-text('Copy as markdown')", 
                        "text=Copy as markdown"
                    ]
                    for sel in copy_btn_sel:
                         try:
                             locator = page.locator(sel)
                             if locator.count() == 0:
                                 continue
                             if locator.first.is_visible():
                                 locator.first.click()
                                 clicked_copy = True
                                 break
                         except Exception:
                             pass

                    if not clicked_copy:
                        # Icon-based button fallback
                        try:
                            clicked_copy = page.evaluate("""
                                () => {
                                    const icon = document.querySelector("span.copy-markdown-button");
                                    if (!icon) return false;
                                    const btn = icon.closest("button");
                                    if (!btn) return false;
                                    btn.click();
                                    return true;
                                }
                            """)
                        except Exception:
                            clicked_copy = False

                if clicked_copy:
                    # 5. Get from clipboard (Using JS to avoid system clipboard dependency)
                    time.sleep(0.5)
                    try:
                        # Attempt to read clipboard via browser API
                        # This requires permission, but usually works in automation context if configured
                        # Note: We stripped pyperclip, so this is the only way
                        content = page.evaluate("navigator.clipboard.readText()")
                    except Exception as e:
                        print(f"   [!] Browser Clipboard read failed: {e}")
                        content = None
                        
                    if content and len(content) > 10:
                        return content
                    else:
                        print("   [!] Clipboard empty/failed after copy click")
            else:
                 print(f"   [!] Could not open options menu: {result.get('error')}")

        except Exception as e:
            print(f"   [!] Hover/Copy failed: {e}")
            
        print("   [!] Fallback to DOM scraping...")
        return self._fallback_scrape(page)


    # NOTE: _wait_response_stable method is defined earlier in the file (around line 254)


    def _fallback_scrape(self, page):
        """Fallback DOM scraping if native copy fails - reconstructs Markdown from live DOM"""
        try:
            # Scroll last turn into view first to handle virtualization
            page.evaluate("""() => {
                const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
                if (lastTurn) lastTurn.scrollIntoView({behavior: 'instant', block: 'center'});
            }""")
            page.wait_for_timeout(500)
            
            # Extract and reconstruct Markdown from LIVE DOM (not cloned)
            # This preserves newline context from block elements
            text = page.evaluate("""() => {
                const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
                if (!lastTurn) return "";
                
                const contentDiv = lastTurn.querySelector('.turn-content');
                if (!contentDiv) return "";
                
                // Helper: Recursively build text with proper newlines
                function extractMarkdown(element) {
                    let result = '';
                    
                    for (const node of element.childNodes) {
                        // Skip thinking blocks completely
                        if (node.nodeType === 1) { // Element node
                            const tag = node.tagName?.toLowerCase() || '';
                            const classList = node.className || '';
                            
                            // Skip thinking/noise elements
                            if (tag === 'mat-expansion-panel' || 
                                classList.includes('model-thoughts') ||
                                classList.includes('turn-footer') ||
                                classList.includes('actions-container') ||
                                classList.includes('author-label') ||
                                tag === 'button') {
                                continue;
                            }
                            
                            // Handle block elements with newlines
                            if (tag === 'p') {
                                result += extractMarkdown(node) + '\\n\\n';
                            } else if (tag === 'h1') {
                                result += '# ' + extractMarkdown(node) + '\\n\\n';
                            } else if (tag === 'h2') {
                                result += '## ' + extractMarkdown(node) + '\\n\\n';
                            } else if (tag === 'h3') {
                                result += '### ' + extractMarkdown(node) + '\\n\\n';
                            } else if (tag === 'h4') {
                                result += '#### ' + extractMarkdown(node) + '\\n\\n';
                            } else if (tag === 'li') {
                                result += '- ' + extractMarkdown(node) + '\\n';
                            } else if (tag === 'ul' || tag === 'ol') {
                                result += extractMarkdown(node) + '\\n';
                            } else if (tag === 'br') {
                                result += '\\n';
                            } else if (tag === 'ms-code-block' || classList.includes('code-block')) {
                                const lang = node.getAttribute('language') || '';
                                const code = node.innerText || '';
                                result += '\\n```' + lang + '\\n' + code + '\\n```\\n\\n';
                            } else if (tag === 'ms-cmark-node' || tag === 'ms-text-chunk' || tag === 'ms-prompt-chunk') {
                                // These are wrapper elements, recurse
                                result += extractMarkdown(node);
                            } else if (tag === 'strong' || tag === 'b') {
                                result += '**' + extractMarkdown(node) + '**';
                            } else if (tag === 'em' || tag === 'i') {
                                result += '*' + extractMarkdown(node) + '*';
                            } else if (tag === 'code' || classList.includes('inline-code')) {
                                result += '`' + (node.innerText || '') + '`';
                            } else if (tag === 'a') {
                                const href = node.getAttribute('href') || '';
                                result += '[' + extractMarkdown(node) + '](' + href + ')';
                            } else if (tag === 'div' || tag === 'span') {
                                // Generic containers - recurse
                                result += extractMarkdown(node);
                            } else {
                                // Unknown element - just get text
                                result += node.innerText || '';
                            }
                        } else if (node.nodeType === 3) { // Text node
                            result += node.textContent || '';
                        }
                    }
                    return result;
                }
                
                return extractMarkdown(contentDiv).trim();
            }""")
            
            if text and len(text) > 10:
                print(f"   [>] Smart Scrape successful ({len(text):,} chars)")
                return text
            
            return "Error: Could not extract response (scrape returned empty)."
        except Exception as e:
            print(f"   [!] Scrape failed: {e}")
            return "Error: Could not extract response."
