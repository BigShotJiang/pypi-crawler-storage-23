"""
Session management for AI Studio browser automation.
Handles connection, login checks, rate limits, and model switching.
"""
import os
import sys
import time
import re


class SessionMixin:
    """Mixin providing session and connection management."""
    def connect_to_aistudio(self):
        """
        Find the AI Studio tab. Reuse existing tabs to avoid "Double Tab" issues.
        If a tab exists but has the wrong Session ID/URL, NAVIGATE it.
        Only open a new tab if absolutely zero AI Studio tabs exist.
        
        Session Continuation (v11.5):
        - If self.continue_url is set, navigate directly to that chat URL.
        """
        print(f"   [i] Connecting to AI Studio (Port {self.config.get('port', 9222)})...")
        
        # Session Continuation: If continue_url is set, navigate directly to saved chat
        if hasattr(self, 'continue_url') and self.continue_url:
            print(f"   [>] Continuing saved session...")
            time.sleep(1.0)
            
            # Find or create a page
            if len(self.context.pages) == 0:
                page = self.context.new_page()
            else:
                page = self.context.pages[0]
            
            page.goto(self.continue_url)
            time.sleep(2.0)
            
            # Save current URL for future reference
            if hasattr(self, 'current_chat_url'):
                self.current_chat_url = page.url
                
            self.verified_page = page
            return page
        
        # 1. Get Expected Session ID
        # 1. Get Expected Session ID
        session_id = None
        
        # Priority 1: Per-Port Global Session (matches start_chrome.py)
        port = self.config.get('port', 9222)
        home_fr = os.path.join(os.path.expanduser("~"), ".frankenreview", f"session_{port}.id")
        
        if os.path.exists(home_fr):
            with open(home_fr, 'r') as f:
                session_id = f.read().strip()
        else:
            # Priority 2: Local Project Session (Legacy/fallback)
            session_file = os.path.join(os.getcwd(), ".frankenreview", "session.id")
            if os.path.exists(session_file):
                 with open(session_file, 'r') as f:
                     session_id = f.read().strip()
                 
        # 2. Re-verify cached page (Optimistic)
        if self.verified_page:
            try:
                if not self.verified_page.is_closed():
                    print(f"   [+] Reusing verified session tab (Cached).")
                    # Ensure model is correct even on reuse
                    self._select_model_via_ui(self.verified_page, self.active_model_id)
                    return self.verified_page
            except Exception:
                self.verified_page = None

        # 3. Scan Buffer (Wait for Chrome to settle)
        # Give Chrome a moment to process the initial command-line URL open
        time.sleep(2.0)
        
        if len(self.context.pages) == 0:
            print("   [!] No pages found in browser context. Opening new one...")
            page = self.context.new_page()
            
            # Use configured base_url (config.yaml) which includes model param
            target_url = self.base_url
            if session_id:
                # Append session ID properly (after query params)
                separator = "&" if "?" in target_url else "?"
                target_url += f"{separator}fr_session_id={session_id}"
                
            page.goto(target_url)
            self.verified_page = page
            # Ensure model is correct
            self._select_model_via_ui(page, self.active_model_id)
            return page

        # 4. Find ANY AI Studio tab
        target_page = None
        
        # Priority 1: Exact Match (Session ID)
        for p in self.context.pages:
            url = p.url
            if session_id and f"fr_session_id={session_id}" in url:
                print(f"   [+] Found verified session tab: {url[:60]}...")
                target_page = p
                self.verified_page = p
                # Ensure model is correct
                self._select_model_via_ui(p, self.active_model_id)
                return p
        
        # Priority 2: Any AI Studio tab (reuse & redirect)
        for p in self.context.pages:
            if "aistudio.google.com" in p.url:
                print(f"   [i] Found existing AI Studio tab (ID mismatch). Reusing & Redirecting...")
                target_page = p
                break
                
        if target_page:
            # Force navigation to correct URL (Model + Session)
            target_url = self.base_url
            if session_id:
                separator = "&" if "?" in target_url else "?"
                target_url += f"{separator}fr_session_id={session_id}"
                
            print(f"   [>] Navigating existing tab to Configured Model/Session...")
            target_page.goto(target_url)
            time.sleep(2.0)
            
            self.verified_page = target_page
            # Ensure model is correct
            self._select_model_via_ui(target_page, self.active_model_id)
            return target_page

        # Priority 3: No AI Studio tab found -> Open new one
        print("   [i] No AI Studio tabs found. Creating new session tab...")
        page = self.context.new_page()
        
        target_url = self.base_url
        if session_id:
            separator = "&" if "?" in target_url else "?"
            target_url += f"{separator}fr_session_id={session_id}"
            
        page.goto(target_url)
        self.verified_page = page
        # Ensure model is correct
        self._select_model_via_ui(page, self.active_model_id)
        return page


    def _check_login(self, page):
        """Check if user is logged in, raise error if not."""
        # Check for Sign In button
        try:
             # Common Google Sign In indicators
             if page.locator("a[aria-label*='Sign in']").is_visible() or \
                page.locator("button:has-text('Sign in')").is_visible() or \
                page.locator("text='Sign in to continue'").is_visible():
                 
                 # Take screenshot of login screen
                 self._capture_debug(page, "login_required")
                 raise Exception("User not logged in. Please run with --visible and log in.")
        except Exception as e:
            if "User not logged in" in str(e):
                raise e
            pass



    def _check_rate_limit(self, page):
        """
        Check for "You've reached your rate limit" modal/toast.
        Returns True if detected.
        """
        try:
            # Check for specific rate limit text (Case Insensitive)
            is_limit = page.evaluate("""() => {
                const body = document.body.innerText.toLowerCase();
                const limitTexts = [
                    "you've reached your rate limit",
                    "rate limit exceeded",
                    "too many requests",
                    "quota exceeded",
                    "try again later",
                    "failed to generate content",
                    "out of free generations"
                ];
                return limitTexts.some(text => body.includes(text));
            }""")
            
            if is_limit:
                print(f"   [!] RATE LIMIT DETECTED (Text Match)")
                return True
                
            return False
        except Exception as e:
            return False


    def _switch_model(self, page):
        """
        Switch to an alternate model via UI-based selection to bypass rate limits.
        Strategy: Use model selector dropdown to pick next failover model.
        
        Args:
            page: Playwright page object connected to AI Studio
            
        Returns:
            True if switched successfully, False if failed.
        """
        print("   [i] Initiating Model Switch Failover (UI-Based)...")
        
        # Get failover models from config or use defaults
        failover_models = self.config.get('model_failover', [
            "gemini-3-flash-preview",
            "gemini-2.5-pro",
            "gemini-2.5-flash",
            "gemini-2.0-flash"
        ])
        
        # Find next model in failover list
        current_model = self.active_model_id or ""
        try:
            current_idx = next((i for i, m in enumerate(failover_models) if m in current_model), -1)
            next_idx = (current_idx + 1) % len(failover_models)
            target_model = failover_models[next_idx]
        except (ValueError, IndexError):
            target_model = failover_models[0] if failover_models else "gemini-2.0-flash"
        
        print(f"   [>] Switching from '{current_model or 'unknown'}' to '{target_model}'...")
        
        try:
            # 1. Click model selector button - try multiple patterns
            model_selector_patterns = [
                "ms-model-selector button",
                "[data-test-id='model-selector'] button",
                "button[aria-label*='Model']",
                "button[aria-label*='model']",
                ".model-selector button",
                "button:has-text('Gemini')"
            ]
            
            model_btn = None
            for pattern in model_selector_patterns:
                try:
                    loc = page.locator(pattern).first
                    if loc.count() > 0 and loc.is_visible():
                        model_btn = loc
                        break
                except Exception:
                    continue
            
            if not model_btn:
                print("   [!] Could not find model selector button.")
                return False
            
            model_btn.click(force=True)
            time.sleep(1.5)
            
            # 2. Click "All" tab to show all models (not just "Featured")
            all_tab = page.locator('button:has-text("All"), mat-button-toggle:has-text("All")').first
            if all_tab.count() > 0:
                all_tab.click(force=True)
                time.sleep(0.5)
            
            # 3. Search for the target model
            search_sel = "input[placeholder*='Search'], mat-form-field input"
            search_box = page.locator(search_sel).first
            if search_box.count() > 0:
                search_box.fill(target_model)
                time.sleep(1.5)
            
            # 3. Click the matching model item
            item_sel = f"button.content-button:has-text('{target_model}')"
            item = page.locator(item_sel).first
            
            if item.count() > 0:
                item.click()
                print(f"   [+] Clicked model item: {target_model}")
                time.sleep(2.0)
            else:
                # Fallback: click first search result
                first_result = page.locator("button.content-button").first
                if first_result.count() > 0:
                    first_result.click()
                    print(f"   [!] Specific item not found. Clicked first search result.")
                    time.sleep(2.0)
                else:
                    print(f"   [!] Could not find any model items")
                    page.keyboard.press("Escape")
                    return False
            
            # 4. Verify selection
            new_model = self._get_active_model_name(page) if hasattr(self, '_get_active_model_name') else "Unknown"
            print(f"   [i] New Active Model (UI): {new_model}")
            
            # Update internal state — sync both model ID and base_url to prevent
            # re-navigation back to the rate-limited model in _do_send_review
            self.active_model_id = target_model
            if hasattr(self, 'base_url') and self.base_url:
                import re as _re
                if 'model=' in self.base_url:
                    self.base_url = _re.sub(r'model=[^&]*', f'model={target_model}', self.base_url)
                else:
                    sep = "&" if "?" in self.base_url else "?"
                    self.base_url = f"{self.base_url}{sep}model={target_model}"
            self.verified_page = page
            return True
            
        except Exception as e:
            print(f"   [x] UI model switch failed: {e}")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            return False



    def cleanup_temp_files(self):
        """Clean up temporary files"""
        import shutil
        try:
            shutil.rmtree(self.temp_dir)
        except Exception:
            pass


    def close(self):
        """Close the browser connection"""
        self.cleanup_temp_files()
        try:
            self.p.stop()
        except Exception:
            pass
