"""Configuration manager for useCli CLI.

Handles loading and accessing configuration from project-level files.
Configuration is loaded from (in priority order):
  1. pyproject.toml [tool.usecli] section (preferred for Python projects)
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from usecli.cli.core.exceptions.config import UsecliConfigError

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _normalize_themes_dir(value: Any) -> list[str]:
    if isinstance(value, str):
        normalized = value.strip()
        return [normalized] if normalized else []
    if isinstance(value, list):
        result: list[str] = []
        for entry in value:
            if not isinstance(entry, str):
                continue
            normalized = entry.strip()
            if normalized:
                result.append(normalized)
        return result
    return []


def _dedupe_items(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


class ConfigManager:
    """Manages useCli configuration from project-level files.

    Configuration is loaded from:
    1. pyproject.toml [tool.usecli] in current directory (highest priority)
    2. Default values (lowest priority)

    Attributes:
        pyproject_path: Path to pyproject.toml in current directory.
        _config: The merged configuration dictionary.
    """

    DEFAULT_CONFIG: dict[str, Any] = {
        "title": "usecli",
        "title_file": None,
        "description": "A customizable CLI framework",
        "commands_dir": "cli/commands",
        "templates_dir": "cli/templates",
        "themes_dir": ["cli/themes"],
        "title_font": "big",
        "theme": "default",
        "environment": "prod",
        "command_name": "usecli",
        "hide_init": False,
        "hide_inspire": False,
        "hide_make_command": False,
    }

    def __init__(
        self,
        pyproject_path: Path | None = None,
        start_dir: Path | None = None,
    ) -> None:
        """Initialize the configuration manager.

        Args:
            pyproject_path: Optional path to pyproject.toml. Defaults to
                ./pyproject.toml.
            start_dir: Optional directory to start searching for pyproject.toml.
                Defaults to current working directory.
        """
        if start_dir is None:
            start_dir = Path.cwd()

        if pyproject_path is None:
            pyproject_path = self._find_pyproject_toml(start_dir) or (
                start_dir / "pyproject.toml"
            )

        self.pyproject_path: Path = pyproject_path
        self.start_dir: Path = start_dir
        self.project_root: Path = find_project_root(start_dir) or start_dir.resolve()
        self._config: dict[str, Any] = {}
        self._overrides: dict[str, Any] = {}
        self._load_config()

    def _load_config(self) -> None:
        """Load and merge configurations from all sources."""
        self._config = self.DEFAULT_CONFIG.copy()
        self._overrides = {}

        if self.pyproject_path.exists():
            try:
                pyproject_config = self._load_pyproject_toml(self.pyproject_path)
                if pyproject_config:
                    self._config = _deep_merge(self._config, pyproject_config)
                    self._overrides = _deep_merge(self._overrides, pyproject_config)
            except (tomllib.TOMLDecodeError, OSError) as e:
                raise UsecliConfigError(
                    f"Failed to load pyproject.toml: {e}",
                    config_file=str(self.pyproject_path),
                ) from e

        default_themes = _normalize_themes_dir(self.DEFAULT_CONFIG.get("themes_dir"))
        override_themes = _normalize_themes_dir(self._overrides.get("themes_dir"))
        merged_themes = _dedupe_items(default_themes + override_themes)
        if merged_themes:
            self._config["themes_dir"] = merged_themes

    @staticmethod
    def _pyproject_has_usecli(path: Path) -> bool:
        if not path.exists():
            return False
        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
                return "usecli" in data.get("tool", {})
        except (tomllib.TOMLDecodeError, OSError):
            return False

    @classmethod
    def _find_pyproject_toml(cls, start_dir: Path) -> Path | None:
        current = start_dir.resolve()

        while True:
            pyproject_path = current / "pyproject.toml"
            if pyproject_path.exists():
                return pyproject_path

            parent = current.parent
            if parent == current:
                break
            current = parent

        return None

    @staticmethod
    def _load_pyproject_toml(path: Path) -> dict[str, Any]:
        """Load pyproject.toml and return [tool.usecli] section.

        Args:
            path: Path to the pyproject.toml file.

        Returns:
            Parsed [tool.usecli] content as a dictionary, or empty dict.
        """
        with open(path, "rb") as f:
            data = tomllib.load(f)
            return data.get("tool", {}).get("usecli", {})

    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value using dot notation.

        Args:
            key: The configuration key in dot notation (e.g., "logging.level").
            default: Default value if key not found.

        Returns:
            The configuration value, or default if not found.
        """
        keys = key.split(".")
        value = self._config
        for k in keys:
            if not isinstance(value, dict) or k not in value:
                return default
            value = value[k]
        return value

    def get_all(self) -> dict[str, Any]:
        """Get the complete merged configuration."""
        return self._config.copy()

    def has_key(self, key: str) -> bool:
        keys = key.split(".")
        value: Any = self._overrides
        for k in keys:
            if not isinstance(value, dict) or k not in value:
                return False
            value = value[k]
        return True

    def get_project_root(self) -> Path:
        return self.project_root

    def get_project_version(self) -> str | None:
        pyproject_version = self._load_project_version(self.pyproject_path)
        if pyproject_version:
            return pyproject_version
        return None

    def get_project_commands_dir(self) -> Path:
        commands_dir = self.get("commands_dir", "cli/commands")
        commands_path = Path(commands_dir)
        if commands_path.is_absolute():
            return commands_path
        return (self.project_root / commands_path).resolve()

    def get_project_templates_dir(self) -> Path:
        templates_dir = self.get("templates_dir", "cli/templates")
        templates_path = Path(templates_dir)
        if templates_path.is_absolute():
            return templates_path
        return (self.project_root / templates_path).resolve()

    def get_project_themes_dirs(self) -> list[Path]:
        themes_dir = self.get("themes_dir", [])
        themes_entries = _normalize_themes_dir(themes_dir)
        result: list[Path] = []
        for entry in themes_entries:
            theme_path = Path(entry)
            if not theme_path.is_absolute():
                theme_path = self.project_root / theme_path
            result.append(theme_path.resolve())
        return result

    def is_dev(self) -> bool:
        """Check if running in development environment."""
        return self.get("environment", "prod") == "dev"

    def is_prod(self) -> bool:
        """Check if running in production environment."""
        return self.get("environment", "prod") == "prod"

    def reload(self) -> None:
        """Reload configuration from disk."""
        self._load_config()

    @property
    def pyproject_exists(self) -> bool:
        """Check if pyproject.toml with [tool.usecli] exists."""
        if not self.pyproject_path.exists():
            return False
        return self._pyproject_has_usecli(self.pyproject_path)

    @staticmethod
    def _load_project_version(path: Path) -> str | None:
        if not path.exists():
            return None
        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
        except (tomllib.TOMLDecodeError, OSError):
            return None

        project_version = data.get("project", {}).get("version")
        if isinstance(project_version, str) and project_version.strip():
            return project_version.strip()

        tool_version = data.get("tool", {}).get("usecli", {}).get("version")
        if isinstance(tool_version, str) and tool_version.strip():
            return tool_version.strip()

        return None


_config_manager: ConfigManager | None = None


def get_config() -> ConfigManager:
    """Get the global ConfigManager instance."""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager


def reset_config() -> None:
    """Reset the global ConfigManager instance."""
    global _config_manager
    _config_manager = None


def find_project_root(start_dir: Path | None = None) -> Path | None:
    if start_dir is None:
        start_dir = Path.cwd()

    current = start_dir.resolve()

    while True:
        pyproject_path = current / "pyproject.toml"
        if pyproject_path.exists():
            return current

        git_dir = current / ".git"
        if git_dir.exists():
            return current

        parent = current.parent
        if parent == current:
            break
        current = parent

    return None
