"""Shared configuration and utilities for usecli."""

from __future__ import annotations
