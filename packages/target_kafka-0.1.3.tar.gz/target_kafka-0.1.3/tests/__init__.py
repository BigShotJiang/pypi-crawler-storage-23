"""Test suite for target-kafka."""
