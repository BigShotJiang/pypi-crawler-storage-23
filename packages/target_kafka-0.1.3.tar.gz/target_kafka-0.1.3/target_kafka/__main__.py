"""Kafka entry point."""

from __future__ import annotations

from target_kafka.target import TargetKafka

TargetKafka.cli()
