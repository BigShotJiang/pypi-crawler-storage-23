"""Target for Kafka."""
