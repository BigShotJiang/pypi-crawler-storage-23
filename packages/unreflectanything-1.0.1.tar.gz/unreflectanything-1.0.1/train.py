from main import run_pipeline

if __name__ == "__main__":
    run_pipeline(mode="train")
