from __future__ import annotations

import enum
from typing import TypedDict


class Store(TypedDict):
    store_name: str | None
    address: str | None
    phone: str | None
    siret: str | None
    naf: str | None


class Properties(TypedDict, total=False):
    bio: bool
    milk_treatment: str
    production: str
    brand: str
    label: str
    packaging: str
    origin: str
    affinage_months: int
    baby_months: int
    baby_recipe: str


class Item(TypedDict):
    raw: str
    raw_name: str
    name: str
    price: float
    bought: int
    units: float | None
    grams: float | None
    volume_ml: float | None
    fat_pct: float | None
    tr: bool
    way_of_paying: str | None
    discount: float | None
    properties: Properties


class Category(enum.Enum):
    FRUITS_ET_LEGUMES = "FRUITS ET LEGUMES"
    PAT_INDUSTRIELLE = "PAT INDUSTRIELLE"
    EPICERIE = "EPICERIE"
    FROMAGE_A_LA_COUPE = "FROMAGE A LA COUPE"
    BEAUTE_SANTE = "BEAUTE SANTE"
    CREMERIE_LS = "CREMERIE L.S."
    VOL_LS_INDUST = "VOL.LS INDUST."
    ENTRETIEN = "ENTRETIEN"
    LIQUIDES = "LIQUIDES"
    BOUCHERIE_LS_INDUST = "BOUCH.LS.INDUST."
    CHARC_TRAIT_TRADT = "CHARCT.TRAIT.TRADT."
    BOUCH_VOL_ATELIER = "BOUCH.VOL.ATELIER"
    CHARC_TRAIT_SAUC_SECS = "CHARC.TRAIT.SAUC.SECS L"
    BVP = "BVP"
    POISSONNERIE = "POISSONNERIE"
    VETEMENT = "VETEMENT"
    EQUIPEMENT_DE_LA_MAISON = "EQUIPEMENT DE LA MAISON"
    BRICOLAGE_JARDINAGE_AUT = "BRICOLAGE JARDINAGE AUT"
    BAZAR_A_SERVICE = "BAZAR A SERVICE"
    SURGELES = "SURGELES"
    LOISIRS = "LOISIRS"
    CULTURE = "CULTURE"
    CHAUSSURE = "CHAUSSURE"
    COLLANT_CHAUSSETTES = "COLLANT-CHAUSSETTES"
    EQUIPEMENT = "EQUIPEMENT"
    SOUS_VETEMENT = "SOUS-VETEMENT"

    # V2 categories
    AIDE_PATISSERIE = "AIDE PATISSERIE"
    ALIMENTS_POUR_ENFANTS = "ALIMENTS POUR ENFANTS"
    BEURRE = "BEURRE"
    BISCUITS_SUCRES = "BISCUITS SUCRES"
    BOISSONS_SANS_ALCOOL = "BOISSONS SANS ALCOOL"
    BOUCHERIE_FRAICHE_PREEMB = "BOUCHERIE FRAICHE PREEMB"
    BOUCH_LS_UVCI = "BOUCH.LS (UVCI)"
    BOULANGERIE = "BOULANGERIE"
    BRICOLAGE = "BRICOLAGE"
    CHARCUTERIE_FRAICH_EMBAL = "CHARCUTERIE FRAICH EMBAL"
    CEREALES_ET_POUDRES_CHOCOLAT = "CEREALES ET POUDRES CHOCOLAT"
    CHARCT_LS_UVCI = "CHARCT.LS UVCI"
    CHIEN_CHAT = "CHIEN-CHAT"
    CHOCOLATS_TABLETTES = "CHOCOLATS TABLETTES"
    CONDIMENTS_SAUCES_FROIDE = "CONDIMENTS-SAUCES FROIDE"
    CONFISERIE_CAISSE = "CONFISERIE CAISSE"
    CONFITURES_MIEL = "CONFITURES MIEL P.A.TARTINER"
    CONSERVES_DE_LEGUMES = "CONSERVES DE LEGUMES"
    CONSERVES_DE_POISSON = "CONSERVES DE POISSON"
    CONSERVES_DE_VIANDES = "CONSERVES DE VIANDES"
    COTON = "COTON"
    COUSCOUS_PUREE_LEG_SECS_BLE = "COUSCOUS PUREE LEG SECS BLE"
    DESSERTS_TOUT_PRETS = "DESSERTS TOUT PRETS"
    EMBALLAGE_MENAGER = "EMBALLAGE MENAGER"
    ENTRETIEN_DU_LINGE = "ENTRETIEN DU LINGE"
    FARINES_ET_FECULENTS = "FARINES ET FECULENTS"
    FROMAGE_COUPE = "FROMAGE COUPE"
    FROMAGE_COUPE_EMBALLE = "FROMAGE COUPE EMBALLE"
    FROMAGE_LS = "FROMAGE LS"
    FRUITS = "FRUITS"
    HUILES = "HUILES"
    HYGIENE_FEMININE = "HYGIENE FEMININE"
    JOUETS = "JOUETS"
    JUS_DE_FRUITS_FRAIS = "JUS DE FRUITS FRAIS"
    JUS_ET_NECTARS = "JUS ET NECTARS"
    LA_CUISINE = "LA CUISINE"
    LAITS_ET_DERIVES = "LAITS ET DERIVES"
    LEGUMES = "LEGUMES"
    LINGE_DE_MAISON = "LINGE DE MAISON"
    MARGARINES_ET_COMPOSES = "MARGARINES ET COMPOSES"
    OEUFS = "OEUFS"
    PAIN_DE_MIE_LS = "PAIN DE MIE (LS)"
    PAPETERIE_ECRITURE = "PAPETERIE ECRITURE"
    PAPIER_TOILETTE = "PAPIER TOILETTE"
    PARFUMERIE = "PARFUMERIE"
    PATES = "PATES"
    PATIS_INDUSTRIELLE = "PATIS.INDUSTRIELLE"
    PATISSERIE = "PATISSERIE"
    PETITE_PARAPHARMACIE = "PETITE PARAPHARMACIE"
    POISSON_LS_UVCI = "POISSON LS UVCI"
    POISSON_TRADITIONNEL = "POISSON TRADITIONNEL"
    PRODUITS_ETRANGERS = "PRODUITS ETRANGERS"
    PRODUITS_VAISSELLE = "PRODUITS VAISSELLE"
    SAUCES_CHAUDES = "SAUCES CHAUDES"
    SEL = "SEL"
    SIROPS = "SIROPS"
    SUCRES = "SUCRES"
    SURGELE_SALE = "SURGELE SALE"
    SURGELE_SUCRE = "SURGELE SUCRE"
    THES_ET_INFUSIONS = "THES ET INFUSIONS"
    TRAITEUR_FRAIS_EMBALLE = "TRAITEUR FRAIS EMBALLE"
    TRAITEUR_LS_UVCI = "TRAITEUR LS UVCI"
    ULTRA_FRAIS = "ULTRA FRAIS"
    VENTE_DIVERSE_POISSON_AR = "VENTE DIVERSE POISSON AR"
    VETEMENT_FEMME = "VETEMENT FEMME"
    VIENNOISERIE = "VIENNOISERIE"
    S_VETEMENT_LAYETTE = "S.VETEMENT LAYETTE"
    VIENNOISERIE_INDUSTRIELLE = "VIENNOISERIE INDUSTRIELLE"
    VINAIGRES_ET_VINAIGRETTES = "VINAIGRES ET VINAIGRETTES"
    VOL_LS_STANDARD = "VOL.LS STANDARD"

    DISCOUNT = "DISCOUNT"
    UNDEFINED = ""


Items = dict[Category, list[Item]]


class Card(TypedDict):
    balance_previous: float
    balance_earned: float
    balance_used: float
    balance_new: float


class Receipt(TypedDict):
    date: str | None
    store: Store
    card: Card
    items: Items
    subtotal: float | None
    total_discount: float | None
    total: float
    number_of_items: int
    eligible_tr: float | None
    paid_tr: float | None


# ---------------------------------------------------------------------------
# Aggregate / compare output types
# ---------------------------------------------------------------------------


class StoreSummary(TypedDict):
    id: str
    store_name: str | None
    location: str | None
    siret: str | None
    naf: str | None


class SessionSummary(TypedDict):
    id: int
    date: str | None
    store_id: str | None


class SessionTotal(TypedDict):
    session_id: int
    date: str
    total: float


class SessionCategoryTotal(TypedDict):
    date: str
    session_id: int
    categories: dict[str, float]


class CategoryRollingAverage(TypedDict):
    date: str
    categories: dict[str, float]


class _ObservationRequired(TypedDict):
    original_name: str
    session_id: int
    price: float
    quantity: int
    grams: float | None
    discount: float | None
    price_per_kg: float | None
    volume_ml: float | None
    price_per_liter: float | None
    unit_count: float
    fat_pct: float | None


class Observation(_ObservationRequired, total=False):
    bio: bool
    milk_treatment: str
    production: str
    brand: str
    label: str
    packaging: str
    origin: str
    affinage_months: int
    baby_months: int
    baby_recipe: str


class ProductSummary(TypedDict):
    canonical_name: str
    observations: list[Observation]


class CompareResult(TypedDict):
    stores: list[StoreSummary]
    sessions: list[SessionSummary]
    session_totals: list[SessionTotal]
    session_category_totals: list[SessionCategoryTotal]
    category_rolling_averages: list[CategoryRollingAverage]
    products: list[ProductSummary]
