from __future__ import annotations

import logging
import re
from collections import defaultdict

from superslurp.parse.common import (
    CompiledSynonyms,
    _parse_name_attributes,
    build_item,
    post_process_item,
)
from superslurp.parse.v1.parse_categories import iter_categories_and_items
from superslurp.repr.items import repr_items
from superslurp.superslurp_typing import Category, Item, Items


class WrongNumberOfItemException(Exception): ...


_NAME_CHAR = r"(?:(?!\(T\))[\w .\/%,=\-\"'€°+Éé()\*])"

items_patterns = [
    re.compile(
        rf"(?P<name>{_NAME_CHAR}*)(?P<tr>\(T\))?(\d\d)?[ \n]*"
        r"(?P<quantity>[\d kgx,.]+ €(\/kg)?)? +(?P<price>\d+[,|\.][ \d€]+) ?(?P<way_of_paying>\d{2})+ ?\n"
        r"|\s*Pourcentage:\s*(?P<pourcentage>\d+)\s*-(?P<discount>\d+[,|\.][ \d€]+)\n"
        r"|\s+[^\n]+-(?P<inline_discount>\d+[,\.]\d+ €)\s*\n"
    ),
    # Weighted items where name + way_of_paying are on line 1, weight + price on line 2
    re.compile(
        rf"(?P<name>{_NAME_CHAR}*)(?P<tr>\(T\))? +(?P<way_of_paying>\d{{2}}) ?\n"
        r"\s+(?P<quantity>[\d,]+ kg\s+x\s+[\d,]+ €/kg)\s+(?P<price>\d+[,|\.]\d+ €)\n"
    ),
]


def parse_items(
    text: str,
    expected_number_of_items: int,
    synonyms: CompiledSynonyms | None = None,
) -> Items:
    compiled_syn = synonyms
    nb_parsed = 0
    items: dict[Category, list[Item]] = defaultdict(list)
    category = Category.UNDEFINED
    for category, items_info in iter_categories_and_items(text):
        nb_parsed_category = 0
        for items_pattern in items_patterns:
            logging.debug(
                f"Parsing {category=} with {items_pattern}:\n<\n{items_info}\n>"
            )
            if not (matched_items := items_pattern.finditer(items_info)):
                logging.debug(f"Matched nothing with {items_pattern}")
                continue
            for item_info in matched_items:
                logging.debug(f"Item found in {category}: {item_info}")
                if (discount_str := _get_discount(item_info)) is not None:
                    items[category][-1]["discount"] = _get_price(discount_str)
                    continue
                item = get_item_from_item_infos(item_info, synonyms=compiled_syn)
                post_process_item(item, category)
                nb_parsed_category += item["bought"]
                items[category].append(item)
        if nb_parsed_category == 0:
            err_msg = (
                f"No items found in {category}, that's impossible.\n"
                f"In:\n<\n{items_info}\n>\nnothing matched by {items_patterns!r}"
            )
            logging.error(err_msg)
            raise WrongNumberOfItemException(err_msg)
        nb_parsed += nb_parsed_category
    if nb_parsed != expected_number_of_items:
        err_msg = (
            f"Expected {expected_number_of_items} items not {nb_parsed} in\n{text}\n"
            f"But parsing extracted:\n{repr_items(items)}\n"
            f"Pre-parsing of categories was:\n{category}"
        )
        logging.error(err_msg)
        raise WrongNumberOfItemException(err_msg)
    return items


def get_new_category(line: str) -> Category:
    try:
        return Category(line.replace(">>>>", "").strip())
    except ValueError as e:
        raise ValueError(f"Missing value in enum '{Category!r}': {e}") from e


def get_item_from_item_infos(
    item_info: re.Match[str],
    synonyms: CompiledSynonyms | None = None,
) -> Item:
    if (matched_name := item_info.group("name")) is None:
        raise ValueError(f"Nothing matched the name in {item_info}")
    raw_name = matched_name.strip()
    assert raw_name, f"Name is empty: {raw_name}"
    if len(raw_name) < 10:
        logging.warning(f"Name is really short, that suspicious: {raw_name}")
    attrs = _parse_name_attributes(raw_name, synonyms=synonyms)
    quantity_str = item_info.group("quantity")
    grams = attrs.grams
    if grams is None and quantity_str and "kg" in quantity_str:
        grams = _get_grams_from_quantity(quantity_str)
    if (quantity := _parse_quantity(quantity_str)) == 1:
        price = item_info.group("price")
    else:
        price = item_info.group("quantity").split("x")[1]
    return build_item(
        raw=item_info.group(0).strip(),
        raw_name=raw_name,
        attrs=attrs,
        price=_get_price(price),
        bought=quantity,
        tr=_get_tr(item_info.group("tr")),
        way_of_paying=item_info.group("way_of_paying"),
        grams=grams,
    )


def _parse_quantity(quantity: str | None) -> int:
    if quantity is None:
        return 1
    quantity = quantity.strip()
    if " x" in quantity:
        before_x = quantity.split(" x")[0].strip()
        if "kg" in before_x:
            return 1
        return int(before_x)
    return int(quantity)


def _get_grams_from_quantity(quantity_str: str) -> float | None:
    """Extract grams from a weighted quantity string like '0,980 kg  x  3,75 €/kg'."""
    if (match := re.search(r"([\d,]+)\s*kg", quantity_str)) is None:
        return None
    return float(match.group(1).replace(",", ".")) * 1000


def _get_discount(item_info: re.Match[str]) -> str | None:
    for group_name in ("discount", "inline_discount"):
        try:
            value = item_info.group(group_name)
        except IndexError:
            continue
        if value is not None:
            return value
    return None


def _get_price(price: str) -> float:
    price = price.split(" €")[0].replace(",", ".")
    return float(price)


def _get_tr(tr: str) -> bool:
    return tr == "(T)"


def get_items_infos_from_line(line: str) -> list[str]:
    items_info = [word.strip() for word in line.split("  ")]
    items_info = [word for word in items_info if word]
    return items_info
