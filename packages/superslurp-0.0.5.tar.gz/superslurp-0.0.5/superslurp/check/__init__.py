from __future__ import annotations

__all__ = ["check_consistency"]

from superslurp.check.consistency import check_consistency
