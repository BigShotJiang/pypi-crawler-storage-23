import asyncio
import uuid
from typing import Any, Callable, Optional, Mapping, List, Union
from .backend import TaskBackend, JobHandle, Schedule
from ..context import IntegrationContext, current_context, integration_context

class AsyncioJobHandle:
    def __init__(self, task: asyncio.Task, tags: Mapping[str, Any]):
        self.id = str(uuid.uuid4())
        self._task = task
        self.tags = tags

    def status(self) -> str:
        if self._task.done():
            if self._task.cancelled():
                return "cancelled"
            if self._task.exception():
                return "failed"
            return "finished"
        return "running"

    async def result(self, timeout: Optional[float] = None) -> Any:
        if timeout:
            return await asyncio.wait_for(self._task, timeout)
        return await self._task

    def cancel(self) -> bool:
        return self._task.cancel()

class AsyncioBackend:
    """
    A TaskBackend that executes tasks immediately using asyncio.create_task.
    Useful for testing and local development without a worker process.
    """
    def submit(
        self, 
        func: Callable, 
        args: tuple, 
        kwargs: dict, 
        context: Optional[IntegrationContext] = None,
        integration: Optional[str] = None,
        pipeline: Optional[str] = None,
        tags: Optional[Mapping[str, Any]] = None
    ) -> JobHandle:
        # Capture current context if not provided
        ctx = context or current_context()
        
        is_subtask = (tags or {}).get("fw.is_subtask", False)

        async def _run_with_context():
            # Restore context in the asyncio task
            # We prioritize explicit integration/pipeline, then context, then None
            with integration_context(
                integration=integration or (ctx.integration if ctx else None),
                integration_pipeline=pipeline or (ctx.integration_pipeline if ctx else None),
                run_id=ctx.run_id if ctx else None,
                tags={**(ctx.tags if ctx else {}), **(tags or {})}
            ):
                from ..observability.ingestion import (
                    record_run_started, record_run_ended,
                    record_span_started, record_span_ended
                )
                from datetime import datetime, UTC
                new_ctx = current_context()
                span_name = f"{new_ctx.integration_pipeline}.{func.__name__}"
                
                if not is_subtask:
                    await record_run_started(correlation=new_ctx.corelation)
                else:
                    await record_span_started(name=span_name, correlation=new_ctx.corelation)

                status = "SUCCEEDED"
                error = None
                try:
                    if asyncio.iscoroutinefunction(func):
                        return await func(*args, **kwargs)
                    else:
                        return func(*args, **kwargs)
                except Exception as e:
                    status = "FAILED"
                    error = str(e)
                    raise
                finally:
                    if not is_subtask:
                        await record_run_ended(status=status, correlation=new_ctx.corelation)
                    else:
                        await record_span_ended(
                            name=span_name,
                            status="OK" if status == "SUCCEEDED" else "ERROR",
                            correlation=new_ctx.corelation,
                            error_summary=error
                        )

        task = asyncio.create_task(_run_with_context())
        return AsyncioJobHandle(task, tags or {})

    def schedule(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        eta_or_delay: Union[int, float, Any],
        context: Optional[IntegrationContext] = None,
        integration: Optional[str] = None,
        pipeline: Optional[str] = None,
        tags: Optional[Mapping[str, Any]] = None
    ) -> JobHandle:
        raise NotImplementedError("AsyncioBackend does not support scheduling. Use DramatiqBackend for scheduling.")

    def register_schedule(
        self,
        func: Callable,
        schedule: Schedule,
        args: Optional[tuple] = None,
        kwargs: Optional[dict] = None,
        tags: Optional[Mapping[str, Any]] = None,
    ) -> None:
        raise NotImplementedError("AsyncioBackend does not support persistent schedules.")

    def get_scheduled_jobs(self) -> List[JobHandle]:
        return []
