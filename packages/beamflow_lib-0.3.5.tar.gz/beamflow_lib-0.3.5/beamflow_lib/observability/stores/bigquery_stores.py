import datetime
from typing import List, Dict, Any, Optional
from google.cloud import bigquery # type: ignore
from ..model import RunEvent, SpanEvent, Correlation, DataExchange, RecordLink
from .protocols import EventsStore, DataExchangeStore, RecordsStore

class BigQueryRecordsStore(RecordsStore):
    def __init__(self, client: bigquery.Client, dataset_id: str):
        self.client = client
        self.dataset_id = dataset_id
        self.table_record_links = f"{dataset_id}.record_links"

    def write_record_link(self, link: RecordLink) -> None:
        row = {
            "tenant_id": link.tenant_id,
            "integration": link.integration,
            "pipeline": link.pipeline,
            "run_id": link.run_id,
            "trace_id": link.trace_id,
            "span_id": link.span_id,
            "record_key": link.record_key,
            "event_time": link.event_time.isoformat() if link.event_time else None,
            "kind": link.kind,
            "source": link.source
        }
        errors = self.client.insert_rows_json(self.table_record_links, [row])
        if errors:
            raise RuntimeError(f"BigQuery insert errors: {errors}")

class BigQueryEventsStore(EventsStore):

    def __init__(self, client: bigquery.Client, dataset_id: str):
        self.client = client
        self.dataset_id = dataset_id
        
        self.table_run = f"{dataset_id}.run_events"
        self.table_span = f"{dataset_id}.span_facts"
        self.table_log = f"{dataset_id}.log_events"

    def _insert_rows(self, table: str, rows: List[Dict[str, Any]]) -> None:
        errors = self.client.insert_rows_json(table, rows)
        if errors:
            # In a real system, you might want to retry or log these errors more robustly
            raise RuntimeError(f"BigQuery insert errors: {errors}")

    def write_run_event(self, event: RunEvent) -> None:
        row = {
            "correlation_integration": event.correlation.integration,
            "integration_pipeline": event.correlation.integration_pipeline,
            "run_id": event.correlation.run_id,
            "trace_id": event.correlation.trace_id,
            "span_id": event.correlation.span_id,
            "event_type": event.event_type,
            "status": event.status,
            "tags": event.correlation.tags,
            "attrs": event.attrs,
            "occurred_at": event.occurred_at.isoformat() if event.occurred_at else None
        }

        if event.event_type == "STARTED":
            row["artifact_id"] = event.artifact_id
            row["env_snapshot_id"] = event.env_snapshot_id
            if event.occurred_at:
                 row["event_time"] = event.occurred_at.isoformat()
        elif event.event_type == "ENDED":
            if event.finished_at:
                row["event_time"] = event.finished_at.isoformat()
        
        self._insert_rows(self.table_run, [row])

    def write_span_event(self, event: SpanEvent) -> None:
         row = {
            "correlation_integration": event.correlation.integration,
            "integration_pipeline": event.correlation.integration_pipeline,
            "run_id": event.correlation.run_id,
            "trace_id": event.correlation.trace_id,
            "span_id": event.correlation.span_id,
            "parent_span_id": event.correlation.parent_span_id,
            "step_key": event.correlation.step_key,
            "attempt": event.correlation.attempt,
            "name": event.name,
            "event_type": event.event_type,
            "status": event.status,
            "tags": event.correlation.tags,
            "attrs": event.attrs,
            "occurred_at": event.occurred_at.isoformat() if event.occurred_at else None
        }
         
         if event.event_type == "ENDED":
             row["error_summary"] = event.error_summary
             if event.start_time:
                 row["start_time"] = event.start_time.isoformat()
             if event.end_time:
                 row["end_time"] = event.end_time.isoformat()

         self._insert_rows(self.table_span, [row])

    def write_log(self, correlation: Correlation, severity: str, message: str, attrs: dict | None = None) -> None:
        row = {
            "time": datetime.datetime.utcnow().isoformat(),
            "correlation_integration": correlation.integration,
            "integration_pipeline": correlation.integration_pipeline,
            "run_id": correlation.run_id,
             "trace_id": correlation.trace_id,
            "span_id": correlation.span_id,
            "step_key": correlation.step_key,
            "attempt": correlation.attempt,
            "severity": severity,
            "message": message,
            "tags": correlation.tags,
            "attrs": attrs
        }
        self._insert_rows(self.table_log, [row])


class BigQueryDataExchangeStore(DataExchangeStore):
    def __init__(self, client: bigquery.Client, dataset_id: str):
        self.client = client
        self.dataset_id = dataset_id
        self.table_dx = f"{dataset_id}.data_exchange"

    def write_data_exchange(self, dx: DataExchange) -> None:
        row = {
            "id": dx.id,
            "correlation_integration": dx.correlation.integration,
            "integration_pipeline": dx.correlation.integration_pipeline,
             "run_id": dx.correlation.run_id,
             "trace_id": dx.correlation.trace_id,
            "span_id": dx.correlation.span_id,
            "parent_span_id": dx.correlation.parent_span_id,
            "step_key": dx.correlation.step_key,
            "correlation_attempt": dx.correlation.attempt,
            
            "integration": dx.integration,
            "channel": dx.channel,
            "operation": dx.operation,
            "remote_system": dx.remote_system,
            "address": dx.address,
            
            "occurred_at": dx.occurred_at.isoformat(),
            "completed_at": dx.completed_at.isoformat() if dx.completed_at else None,
            "state": dx.state,
            "attempt_num": dx.attempt,
            "retry_of_id": dx.retry_of_id,
            "duration_ms": dx.duration_ms,
            
            "http_method": dx.http_method,
            "status_code": dx.status_code,
            
            "request_payload_ref": dx.request_payload_ref,
            "response_payload_ref": dx.response_payload_ref,
             "request_content_type": dx.request_content_type,
            "response_content_type": dx.response_content_type,
            "request_size_bytes": dx.request_size_bytes,
            "response_size_bytes": dx.response_size_bytes,
            
            "tags": dx.correlation.tags,
            "attrs": dx.attrs
        }
        
        errors = self.client.insert_rows_json(self.table_dx, [row])
        if errors:
            raise RuntimeError(f"BigQuery insert errors: {errors}")
