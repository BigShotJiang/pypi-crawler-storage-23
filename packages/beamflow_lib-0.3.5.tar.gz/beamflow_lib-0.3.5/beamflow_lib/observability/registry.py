from typing import Tuple, Optional
from .model import RunEvent, SpanEvent, Correlation, DataExchange, RecordLink
from .stores.protocols import EventsStore, DataExchangeStore, BlobStore, RecordsStore

from ..config.observability_config import ObservabilityConfig, StoreType

class NoOpEventsStore(EventsStore):
    def write_run_event(self, event: RunEvent) -> None:
        pass

    def write_span_event(self, event: SpanEvent) -> None:
        pass

    def write_log(self, correlation: Correlation, severity: str, message: str, attrs: dict | None = None) -> None:
        pass

class NoOpRecordsStore(RecordsStore):
    def write_record_link(self, link: RecordLink) -> None:
        pass

class NoOpDataExchangeStore(DataExchangeStore):

    def write_data_exchange(self, dx: DataExchange) -> None:
        pass

class NoOpBlobStore(BlobStore):
    def put(self, *, path_hint: str, content_type: str, data: bytes) -> Tuple[str, int, str]:
        # Return dummy values
        return f"noop://{path_hint}", len(data), "noop-sha"

_events_store: EventsStore = NoOpEventsStore()
_dx_store: DataExchangeStore = NoOpDataExchangeStore()
_blob_store: BlobStore = NoOpBlobStore()
_records_store: RecordsStore = NoOpRecordsStore()


def configure(config: ObservabilityConfig):
    global _events_store, _dx_store, _blob_store, _records_store

    
    if config.store_type == StoreType.LOCAL:
        from .stores.file_stores import FileStore
        store = FileStore(config.local_store_path)
        _events_store = store
        _dx_store = store
        _blob_store = store
        _records_store = store

    elif config.store_type == StoreType.GCP:
        from google.cloud import bigquery
        from .stores.bigquery_stores import (
            BigQueryEventsStore, BigQueryDataExchangeStore, BigQueryRecordsStore
        )
        from .stores.gcs_blob_store import GCSBlobStore
        
        bq_client = bigquery.Client(project=config.gcp_project_id)

        
        if not config.gcp_dataset_id:
            raise ValueError("gcp_dataset_id is required for GCP store type")
        if not config.gcp_bucket_name:
            raise ValueError("gcp_bucket_name is required for GCP store type")
            
        _events_store = BigQueryEventsStore(bq_client, config.gcp_dataset_id)
        _dx_store = BigQueryDataExchangeStore(bq_client, config.gcp_dataset_id)
        _records_store = BigQueryRecordsStore(bq_client, config.gcp_dataset_id)
        _blob_store = GCSBlobStore(config.gcp_bucket_name, config.gcp_project_id)


def get_events_store() -> EventsStore:
    return _events_store

def set_events_store(store: EventsStore) -> None:
    global _events_store
    _events_store = store

def get_data_exchange_store() -> DataExchangeStore:
    return _dx_store

def set_data_exchange_store(store: DataExchangeStore) -> None:
    global _dx_store
    _dx_store = store

def get_blob_store() -> BlobStore:
    return _blob_store

def set_blob_store(store: BlobStore) -> None:
    global _blob_store
    _blob_store = store

def get_records_store() -> RecordsStore:
    return _records_store

def set_records_store(store: RecordsStore) -> None:
    global _records_store
    _records_store = store


# Initialize with default configuration
configure(ObservabilityConfig())
