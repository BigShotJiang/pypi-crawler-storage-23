from dataclasses import dataclass, field
from typing import Any, Mapping, Optional
import contextvars
import uuid

@dataclass(frozen=True)
class IntegrationContext:
    integration: str
    integration_pipeline: str
    run_id: str
    traceparent: Optional[str] = None
    tracestate: Optional[str] = None
    baggage: Mapping[str, str] = field(default_factory=dict)
    tags: Mapping[str, Any] = field(default_factory=dict)
    tenant_id: str = "default"
    current_record_key: Optional[str] = None



    @property
    def corelation(self) -> Any:
        # Import inside to avoid circular dependencies
        from .observability.model import Correlation
        
        trace_id = None
        span_id = None
        if self.traceparent:
            parts = self.traceparent.split("-")
            if len(parts) >= 3:
                trace_id = parts[1]
                span_id = parts[2]

        return Correlation(
            integration=self.integration,
            integration_pipeline=self.integration_pipeline,
            run_id=self.run_id,
            trace_id=self.trace_id,
            span_id=self.span_id,
            tags={k: str(v) for k, v in self.tags.items()}
        )

    @property
    def trace_id(self) -> Optional[str]:
        if self.traceparent:
            parts = self.traceparent.split("-")
            if len(parts) >= 2:
                return parts[1]
        return None

    @property
    def span_id(self) -> Optional[str]:
        if self.traceparent:
            parts = self.traceparent.split("-")
            if len(parts) >= 3:
                return parts[2]
        return None



_current_ctx: contextvars.ContextVar[Optional[IntegrationContext]] = contextvars.ContextVar(
    "framework.integration_context", default=None
)

def current_context() -> Optional[IntegrationContext]:
    """Return the current integration context."""
    return _current_ctx.get()

get_context = current_context

def set_context(ctx: IntegrationContext) -> Any:
    """Set the current integration context. Returns a token for resetting."""
    return _current_ctx.set(ctx)

def reset_context(token: Any):
    """Reset the integration context to its previous state."""
    _current_ctx.reset(token)

class integration_context:
    """
    Context manager for setting/creating an IntegrationContext.
    If no context exists, it creates one with a new run_id.
    """
    def __init__(
        self,
        integration: Optional[str] = None,
        integration_pipeline: Optional[str] = None,
        run_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        current_record_key: Optional[str] = None,

        **kwargs

    ):
        self.overrides = {
            "integration": integration,
            "integration_pipeline": integration_pipeline,
            "run_id": run_id,
            "tenant_id": tenant_id,
            **kwargs
        }

        self.token = None

    def __enter__(self) -> IntegrationContext:
        parent = current_context()
        if parent:
            # Reuse parent values if not overridden
            merged = {
                "integration": self.overrides.get("integration") or parent.integration,
                "integration_pipeline": self.overrides.get("integration_pipeline") or parent.integration_pipeline,
                "run_id": self.overrides.get("run_id") or parent.run_id,
                "tenant_id": self.overrides.get("tenant_id") or parent.tenant_id,
                "traceparent": parent.traceparent,
                "tracestate": parent.tracestate,
                "baggage": {**parent.baggage, **(self.overrides.get("baggage") or {})},
                "tags": {**parent.tags, **(self.overrides.get("tags") or {})},
                "current_record_key": self.overrides.get("current_record_key") or parent.current_record_key
            }


        else:
            # New root context
            merged = {
                "integration": self.overrides.get("integration") or "unknown",
                "integration_pipeline": self.overrides.get("integration_pipeline") or "unknown",
                "run_id": self.overrides.get("run_id") or str(uuid.uuid4()),
                "tenant_id": self.overrides.get("tenant_id") or "default",
                "baggage": self.overrides.get("baggage") or {},
                "tags": self.overrides.get("tags") or {},
                "current_record_key": self.overrides.get("current_record_key")
            }


        
        ctx = IntegrationContext(**merged)
        self.token = set_context(ctx)
        return ctx

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token:
            reset_context(self.token)
