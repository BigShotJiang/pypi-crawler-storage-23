import yaml
from typing import Any, Dict, Optional
from pathlib import Path
from .runtime_config import RuntimeConfig, ClientsConfigPointer, BackendConfig, WebhooksConfig
from .observability_config import ObservabilityConfig
from beamflow_clients.config import ClientSettings

def load_env_yaml(path: str | Path) -> Dict[str, Any]:
    """Load an environment YAML file."""
    with open(path, "r") as f:
        data = yaml.safe_load(f)
        return data if isinstance(data, dict) else {}

def _load_data_from_dir(path: Path) -> tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]], Dict[str, ClientSettings]]:
    """Helper to load config components from a single directory."""
    # 1. Observability
    obs_file = path / "observability.yaml"
    observability = None
    if obs_file.exists():
        observability = load_env_yaml(obs_file)

    # 2. Backend
    backend_file = path / "backend.yaml"
    backend = None
    if backend_file.exists():
        backend = load_env_yaml(backend_file)

    # 3. Clients
    clients_file = path / "clients.yaml"
    clients: Dict[str, ClientSettings] = {}
    
    if clients_file.exists():
        clients_pointer_data = load_env_yaml(clients_file)
        pointer = ClientsConfigPointer.model_validate(clients_pointer_data)
        
        clients_dir = Path(pointer.path)
        if not clients_dir.is_absolute():
            clients_dir = (path / clients_dir).resolve()
        
        if not clients_dir.is_dir():
             raise ValueError(f"Clients directory {clients_dir} (from clients.yaml) does not exist")

        pattern = pointer.pattern
        recursive = pointer.recursive
        
        search_pattern = f"**/{pattern}" if recursive else pattern
        client_files = list(clients_dir.glob(search_pattern))
        
        for cf in client_files:
            if not cf.is_file():
                continue
            
            client_data = load_env_yaml(cf)
            client_id = client_data.get("client_id") or client_data.get("clientId") or cf.stem
            
            if client_id in clients:
                raise ValueError(f"Duplicate client_id '{client_id}' found in {cf}")

            if "client_id" not in client_data:
                client_data["client_id"] = client_id
                
            settings = ClientSettings.model_validate(client_data)
            
            # Known keys to exclude from extra
            settings_fields = set(ClientSettings.model_fields.keys())
            for field in ClientSettings.model_fields.values():
                if field.alias:
                    settings_fields.add(field.alias)
            
            known_keys = settings_fields | {"client_id", "clientId"}
            extra = {k: v for k, v in client_data.items() if k not in known_keys}
            settings.extra.update(extra)
            
            clients[client_id] = settings
    return observability, backend, clients

def load_config_dir(config_dir: str | Path, environment: str) -> RuntimeConfig:
    """
    Loads unified configuration from a directory.
    - {config_dir}/shared/ - shared base config
    - {config_dir}/{environment}/ - environment-specific overrides
    """

    print("Loading config for environment: ", environment)
    config_path = Path(config_dir)
    if not config_path.is_dir():
        raise ValueError(f"Config directory {config_dir} does not exist or is not a directory")

    shared_path = config_path / "shared"
    env_path = config_path / environment

    # Load shared config
    obs_shared, backend_shared, clients_shared = None, None, {}
    if shared_path.is_dir():
        obs_shared, backend_shared, clients_shared = _load_data_from_dir(shared_path)

    # Load env config
    obs_env, backend_env, clients_env = None, None, {}
    if env_path.is_dir():
        obs_env, backend_env, clients_env = _load_data_from_dir(env_path)
    elif environment != "shared":
        raise ValueError(f"Environment directory {env_path} does not exist")

    # Merge
    # Observability: Env wins
    observability_data = obs_env or obs_shared
    observability = ObservabilityConfig.model_validate(observability_data) if observability_data else None

    # Backend: Env wins
    import os
    backend_yaml_env = backend_env or backend_shared or {}
    
    backend_data = backend_yaml_env.get("backend")
    backend_config = BackendConfig.model_validate(backend_data) if backend_data else BackendConfig()
    
    webhooks_data = backend_yaml_env.get("webhooks")
    webhooks_config = WebhooksConfig.model_validate(webhooks_data) if webhooks_data else WebhooksConfig()
    
    # Clients: Merge dicts, Env wins on collision
    clients = {**clients_shared, **clients_env}

    return RuntimeConfig(
        observability=observability,
        backend=backend_config,
        webhooks=webhooks_config,
        clients=clients
    )
