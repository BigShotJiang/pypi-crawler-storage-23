import functools
import inspect
from typing import Any, Callable, Optional, Dict, List
from ..context import integration_context, current_context

class Ingress:
    """Namespace for ingress decorators."""
    
    def __init__(self):
        self._webhooks: List[Callable] = []

    def webhook(self, pipeline: str, integration: str, path: str, method: str = "POST"):
        """
        Metadata-only decorator for webhook handlers.
        Registers the handler in a shared registry for discovery.
        """
        def decorator(func: Callable):
            # Attach metadata to func
            metadata = {
                "kind": "webhook",
                "pipeline": pipeline,
                "integration": integration,
                "path": path,
                "method": method
            }
            setattr(func, "_ingress_metadata", metadata)
            self._webhooks.append(func)
            return func
        return decorator

    def get_webhooks(self) -> List[Callable]:
        """Return all registered webhook handlers."""
        return self._webhooks


    def poll(self, pipeline: str, integration: str, schedule: str, name: Optional[str] = None):
        """
        Scheduler entrypoint for polling.
        Behaves as a specialized integration_task that manages state.
        Injects 'state: dict' as the first argument.
        """
        from ..decorators import TaskWrapper
        from ..queue.backend import Schedule

        def decorator(func: Callable):
            ingress_name = name or func.__name__
            
            @functools.wraps(func)
            async def state_wrapper(*args, **kwargs):
                ctx = current_context()
                if not ctx:
                    # Polling must run within an integration context (usually provided by worker)
                    raise RuntimeError("ingress.poll must run within an integration context")

                # 1. Load state
                state = self._load_state(ctx.tenant_id, pipeline, ingress_name)
                
                # 2. Inject as first arg and call
                try:
                    if inspect.iscoroutinefunction(func):
                        result = await func(state, *args, **kwargs)
                    else:
                        result = func(state, *args, **kwargs)
                except Exception:
                    # Do not save on exception
                    raise
                
                # 3. Save state on success
                self._save_state(ctx.tenant_id, pipeline, ingress_name, state)
                return result

            tw = TaskWrapper(state_wrapper, {
                "integration": integration,
                "pipeline": pipeline,
                "name": ingress_name,
                "default_schedule": Schedule(cron=schedule)
            })
            
            # Attach metadata for discovery
            setattr(tw, "_ingress_metadata", {
                "kind": "poll",
                "pipeline": pipeline,
                "integration": integration,
                "schedule": schedule,
                "name": ingress_name
            })
            
            return tw
        return decorator


    def _load_state(self, tenant_id: str, pipeline: str, ingress_key: str) -> dict:
        # Placeholder for real state store (e.g. Redis, Postgres, Firestore)
        # In a real system, this would be: 
        # return state_store.get(tenant_id, pipeline, ingress_key)
        return {}

    def _save_state(self, tenant_id: str, pipeline: str, ingress_key: str, state: dict):
        # Placeholder for real state store
        # state_store.save(tenant_id, pipeline, ingress_key, state)
        pass

ingress = Ingress()
