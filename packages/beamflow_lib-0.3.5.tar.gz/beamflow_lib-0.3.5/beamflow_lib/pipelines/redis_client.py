import redis.asyncio as redis
from typing import Optional

_redis_client: Optional[redis.Redis] = None

def get_redis_client(redis_url: Optional[str] = None) -> redis.Redis:
    """
    Get a shared async Redis client.
    If redis_url is provided, it will initialize/re-initialize the client.
    """
    global _redis_client
    
    if redis_url:
        _redis_client = redis.from_url(redis_url, decode_responses=True)
        return _redis_client

    if _redis_client is None:
        import os
        redis_url = os.getenv("REDIS_URL")
        if redis_url:
            print(f"Connecting to Redis at {redis_url}")
            _redis_client = redis.from_url(redis_url, decode_responses=True)
        else:
            # Try to initialize with defaults if not already done
            print("Connecting to Redis at localhost:6379")
            _redis_client = redis.Redis(host="localhost", port=6379, db=0, decode_responses=True)
    
    return _redis_client
