"""Allow running twicc with ``python -m twicc``."""

from twicc import main

main()
