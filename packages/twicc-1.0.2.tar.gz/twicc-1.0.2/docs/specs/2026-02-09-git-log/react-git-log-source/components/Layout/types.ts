import { ReactElement } from 'react'

export interface LayoutProps {
  tags?: ReactElement
  graph?: ReactElement
  table?: ReactElement
}