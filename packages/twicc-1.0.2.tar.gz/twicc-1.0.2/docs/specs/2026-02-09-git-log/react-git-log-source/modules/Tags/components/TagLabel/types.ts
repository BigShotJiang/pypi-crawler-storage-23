import { Commit } from 'types/Commit'

export interface TagLabelProps {
  commit: Commit
  className?: string
}