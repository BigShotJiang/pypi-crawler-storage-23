export interface CurvedEdgeProps {
  id: string
  colour: string
  path: string
  dashed?: boolean
}