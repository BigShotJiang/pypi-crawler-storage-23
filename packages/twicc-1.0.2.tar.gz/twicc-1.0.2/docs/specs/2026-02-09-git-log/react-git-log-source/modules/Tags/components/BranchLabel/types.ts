import { Commit } from 'types/Commit'

export interface BranchLabelProps {
  commit: Commit
}