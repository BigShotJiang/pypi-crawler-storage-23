import { CSSProperties } from 'react'

export interface CommitMessageDataProps {
  index: number
  isIndex: boolean
  style: CSSProperties
  commitMessage: string
}