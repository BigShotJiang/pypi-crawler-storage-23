export interface TagIconProps {
  className?: string
}