import { HTMLAttributes } from 'react'

export interface BranchIconProps extends HTMLAttributes<SVGElement> {
  className?: string
}