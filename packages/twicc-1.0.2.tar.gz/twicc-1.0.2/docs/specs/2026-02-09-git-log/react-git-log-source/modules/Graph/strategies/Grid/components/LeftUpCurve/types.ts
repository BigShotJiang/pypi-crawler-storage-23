export interface LeftUpCurveProps {
  color: string
  showTopBreakPoint?: boolean
  isPlaceholder?: boolean
}