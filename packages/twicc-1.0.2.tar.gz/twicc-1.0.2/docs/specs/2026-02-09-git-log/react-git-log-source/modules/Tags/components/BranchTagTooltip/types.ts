import { Commit } from 'types/Commit'

export interface BranchTagTooltipProps {
  id: string
  commit: Commit
}