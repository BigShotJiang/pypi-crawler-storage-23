export interface ShouldExist<T> {
  shouldExist?: T
}