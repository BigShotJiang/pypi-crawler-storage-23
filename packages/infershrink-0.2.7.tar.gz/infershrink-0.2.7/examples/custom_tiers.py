"""InferShrink — Custom Model Tiers Example.

Configure your own model tiers to match your infrastructure.
Works with OpenRouter, Azure OpenAI, local models, etc.
"""

import openai
from infershrink import optimize

# Example: Custom tiers for OpenRouter
client = optimize(
    openai.Client(
        base_url="https://openrouter.ai/api/v1",
        api_key="your-openrouter-key",
    ),
    config={
        "tiers": {
            "tier1": {
                "models": ["minimax/minimax-m2.1"],
                "max_complexity": "SIMPLE",
                "cost_per_1k_input": 0.0001,
                "cost_per_1k_output": 0.0004,
            },
            "tier2": {
                "models": ["minimax/minimax-m2.5"],
                "max_complexity": "MODERATE",
                "cost_per_1k_input": 0.001,
                "cost_per_1k_output": 0.004,
            },
            "tier3": {
                "models": ["anthropic/claude-opus-4-6"],
                "max_complexity": "COMPLEX",
                "cost_per_1k_input": 0.015,
                "cost_per_1k_output": 0.075,
            },
        },
        "compression": {
            "enabled": True,
            "min_tokens": 300,  # Compress sooner for extra savings
        },
    },
)

# Simple question → routed to minimax-m2.1
response = client.chat.completions.create(
    model="anthropic/claude-opus-4-6",
    messages=[{"role": "user", "content": "What is 2+2?"}],
)
print(f"Simple task: {response.choices[0].message.content}")

# Complex question → stays on claude-opus-4-6
code = '''```python
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)
```'''

response = client.chat.completions.create(
    model="anthropic/claude-opus-4-6",
    messages=[
        {
            "role": "user",
            "content": f"Analyze this code step by step and suggest optimizations:\n{code}",
        }
    ],
)
print(f"Complex task: {response.choices[0].message.content}")

# View savings
print("\n" + client.infershrink_tracker.summary())
