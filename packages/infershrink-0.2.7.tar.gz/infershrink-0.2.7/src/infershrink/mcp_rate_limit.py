"""Rate limiter for InferShrink MCP Server.

Sliding window rate limiting per client, tier-based limits.
In-memory — resets on server restart (acceptable for single-instance).
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict
from dataclasses import dataclass
from typing import Optional

# Requests per minute by tier
TIER_LIMITS = {
    "free": 10,
    "pro": 100,
    "team": 1000,
    "admin": 10000,  # Effectively unlimited
}

WINDOW_SECONDS = 60


@dataclass
class RateLimitResult:
    """Result of a rate limit check."""

    allowed: bool
    remaining: int = 0
    retry_after: int = 0
    tier: str = "free"
    limit: int = 10
    error: str = ""


class RateLimiter:
    """Sliding window rate limiter per client."""

    def __init__(self):
        # client_id -> list of request timestamps
        self._windows: dict[str, list[float]] = defaultdict(list)
        self._lock = threading.Lock()

    def check(self, client_id: str, tier: str = "free") -> RateLimitResult:
        """Check if a request is allowed and record it if so.

        Args:
            client_id: Unique client identifier (IP, token, etc.)
            tier: Client tier (free, pro, team, admin)

        Returns:
            RateLimitResult with allowed status and metadata.
        """
        limit = TIER_LIMITS.get(tier, TIER_LIMITS["free"])
        now = time.time()
        window_start = now - WINDOW_SECONDS

        with self._lock:
            # Clean old entries
            timestamps = self._windows[client_id]
            timestamps[:] = [t for t in timestamps if t > window_start]

            if len(timestamps) >= limit:
                # Calculate when the oldest request in window expires
                oldest = timestamps[0] if timestamps else now
                retry_after = int(oldest + WINDOW_SECONDS - now) + 1
                return RateLimitResult(
                    allowed=False,
                    remaining=0,
                    retry_after=retry_after,
                    tier=tier,
                    limit=limit,
                    error=(
                        f"Rate limit exceeded. Current tier: {tier} ({limit}/min). "
                        f"Retry after {retry_after}s. "
                        f"Upgrade at musashi-labs.lemonsqueezy.com for higher limits."
                    ),
                )

            # Allow and record
            timestamps.append(now)
            return RateLimitResult(
                allowed=True,
                remaining=limit - len(timestamps),
                tier=tier,
                limit=limit,
            )

    def reset(self, client_id: Optional[str] = None):
        """Reset rate limit state.

        Args:
            client_id: Reset for specific client, or all if None.
        """
        if client_id:
            self._windows.pop(client_id, None)
        else:
            self._windows.clear()
