"""Configuration for InferShrink — model tiers, thresholds, defaults."""

from __future__ import annotations

import copy
import os
import subprocess
from typing import Any, Dict

DEFAULT_CONFIG: Dict[str, Any] = {
    "tiers": {
        "tier1": {
            "models": [
                "gpt-4o-mini",
                "gpt-4.1-mini",
                "gpt-4.1-nano",  # OpenAI cheap
                "gemini-2.5-flash",  # Google cheap
                "qwen2.5:32b",  # Local
            ],
            "max_complexity": "SIMPLE",
            "cost_per_1k_input": 0.00015,
            "cost_per_1k_output": 0.0006,
        },
        "tier2": {
            "models": [
                "gpt-4o",
                "gpt-4.1",  # OpenAI mid
                "claude-sonnet-4-20250514",
                "claude-3-5-haiku-20241022",  # Anthropic mid
                "gemini-2.5-pro",  # Google mid
            ],
            "max_complexity": "MODERATE",
            "cost_per_1k_input": 0.0025,
            "cost_per_1k_output": 0.01,
        },
        "tier3": {
            "models": [
                "gpt-4.5-preview",
                "o3",  # OpenAI expensive
                "claude-opus-4-6",  # Anthropic expensive
                "gemini-3-pro-preview",  # Google expensive
            ],
            "max_complexity": "COMPLEX",
            "cost_per_1k_input": 0.015,
            "cost_per_1k_output": 0.075,
        },
    },
    "compression": {
        "enabled": True,
        "min_tokens": 500,
        "skip_for": ["SECURITY_CRITICAL"],
    },
    "quality_floor": 0.95,
    "cost_tracking": True,
    "telemetry": {
        "edge": {
            "enabled": False,
            "endpoint": "",
            "batch_size": 50,
            "flush_interval_s": 300,
        },
    },
}

# Map complexity → tier name
COMPLEXITY_TO_TIER: Dict[str, str] = {
    "SIMPLE": "tier1",
    "MODERATE": "tier2",
    "COMPLEX": "tier3",
    "SECURITY_CRITICAL": "tier3",
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge *override* into *base*, returning a new dict."""
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _discover_available_models() -> Dict[str, Any]:
    """Check environment for available model backends and return config overrides."""
    overrides: Dict[str, Any] = {}
    available_tier1: list[str] = []
    available_tier2: list[str] = []

    # Check Gemini API key → enable Gemini models in tier1/tier2
    if os.environ.get("GEMINI_API_KEY"):
        available_tier1.append("gemini-2.5-flash")
        available_tier2.extend(["gemini-3-pro-preview", "gemini-3-flash-preview", "gemini-2.5-pro"])

    # Check if Ollama is running → enable local models
    try:
        result = subprocess.run(  # noqa: S603 — hardcoded safe command, no user input
            [
                "curl",
                "-s",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "http://localhost:11434/api/tags",
            ],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.stdout.strip() == "200":
            available_tier1.append("qwen2.5:32b")
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    # Check Anthropic API key → enable tier3
    if os.environ.get("ANTHROPIC_API_KEY"):
        overrides.setdefault("tiers", {})["tier3"] = {
            "models": ["claude-opus-4-6", "claude-sonnet-4-20250514"],
            "cost_per_1k_input": 0.015,
            "cost_per_1k_output": 0.075,
        }

    # Only add discovered models — never replace the default list or costs.
    # _deep_merge replaces lists, so we prepend discovered models to defaults.
    if available_tier1:
        default_tier1 = DEFAULT_CONFIG["tiers"]["tier1"]["models"]
        overrides.setdefault("tiers", {}).setdefault("tier1", {})["models"] = [
            m for m in available_tier1 if m not in default_tier1
        ] + default_tier1
    if available_tier2:
        default_tier2 = DEFAULT_CONFIG["tiers"]["tier2"]["models"]
        overrides.setdefault("tiers", {}).setdefault("tier2", {})["models"] = [
            m for m in available_tier2 if m not in default_tier2
        ] + default_tier2

    return overrides


def build_config(
    user_config: Dict[str, Any] | None = None, auto_discover: bool = False
) -> Dict[str, Any]:
    """Return the effective config by merging user overrides into defaults.

    Parameters
    ----------
    user_config:
        Optional user-provided configuration overrides.
    auto_discover:
        If True, probe environment for available model backends.
    """
    base = copy.deepcopy(DEFAULT_CONFIG)
    if auto_discover:
        discovered = _discover_available_models()
        if discovered:
            base = _deep_merge(base, discovered)
    if user_config is None:
        return base
    return _deep_merge(base, user_config)
