"""Type definitions for InferShrink."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List


class Complexity(Enum):
    """Task complexity levels used for routing decisions."""

    SIMPLE = "SIMPLE"
    MODERATE = "MODERATE"
    COMPLEX = "COMPLEX"
    SECURITY_CRITICAL = "SECURITY_CRITICAL"


class InferShrinkQuotaError(Exception):
    """Raised when the monthly request quota is exceeded for the current tier."""

    pass


@dataclass
class ClassificationResult:
    """Result of classifying a messages array."""

    complexity: Complexity
    reason: str
    estimated_tokens: int = 0
    signals: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RoutingDecision:
    """The model routing decision."""

    original_model: str
    routed_model: str
    complexity: Complexity
    was_downgraded: bool = False
    was_upgraded: bool = False


@dataclass
class CompressionResult:
    """Result of prompt compression."""

    messages: List[Dict[str, Any]]
    original_tokens: int
    compressed_tokens: int
    compression_ratio: float
    was_compressed: bool


@dataclass
class RequestRecord:
    """A single tracked request."""

    original_model: str
    routed_model: str
    original_tokens: int
    compressed_tokens: int
    complexity: Complexity
    estimated_cost_original: float = 0.0
    estimated_cost_routed: float = 0.0
    savings: float = 0.0


@dataclass
class SessionStats:
    """Accumulated session statistics."""

    total_requests: int = 0
    total_original_tokens: int = 0
    total_compressed_tokens: int = 0
    total_tokens_saved: int = 0
    total_estimated_savings_usd: float = 0.0
    requests_downgraded: int = 0
    requests_compressed: int = 0
    compression_ratio: float = 1.0
    records: List[RequestRecord] = field(default_factory=list)


# Type alias for message dicts
Message = Dict[str, Any]
Messages = List[Message]

# Config type
Config = Dict[str, Any]
