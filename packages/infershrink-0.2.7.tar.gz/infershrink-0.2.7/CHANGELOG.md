# Changelog

## [0.2.7] - 2026-02-28

### Fixed
- `__version__` now synced with pyproject.toml (was stale at 0.2.4 in 0.2.5-0.2.6)
- MCP status endpoint reports correct version

## [0.2.6] - 2026-02-28

### Fixed
- **MCP optimize tool** — now accepts `prompt` (string) as alternative to `messages` (array), matching user expectations
- **MCP optimize tool** — accepts `model` as alias for `current_model` for natural usage
- Proper error with `isError: true` when neither `prompt` nor `messages` provided

### Changed
- 594 tests passing (was 561)

## [0.2.5] - 2026-02-27

### Added
- **Injection-pattern detection in classifier (v2)** — prevents adversarial prompts from being cost-optimized into weaker models
  - 50+ injection phrase patterns (instruction override, system prompt probing, role confusion, router manipulation)
  - 8 structural regex heuristics (pivot patterns, fake system tags, conversation history spoofing)
  - Dangerous content keyword detection (exploit types, attack techniques, safety-critical markers)
  - Router probing keyword detection (classification manipulation, tier probing)
- Ronin red-team bypass rate: **73.6% → 3.8%** (51/53 vectors blocked)

## [0.2.4] - 2026-02-27

### Fixed
- **Critical: MCP server won't start** — `FastMCP.run()` rejects `host`/`port` in MCP SDK 1.26+; moved to constructor
- **Critical: Routing broken for OpenAI/Anthropic** — `auto_discover` replaced tier model lists instead of augmenting, wiping gpt-4o-mini and claude-sonnet from lower tiers. Simple prompts now correctly route to cheaper models (94% savings on gpt-4o → gpt-4o-mini)
- **MCP error responses** — invalid provider returned `isError: false`; now raises exceptions so MCP SDK sets `isError: true`

### Added
- `.gitleaksignore` for test fixture false positives
- CI: Gitleaks matrix conflict fix, `pull-requests: read` permission

## [0.2.2] - 2026-02-24

### Added
- **Edge telemetry** — optional sync of usage metadata to Edge CRDT Runtime (disabled by default)
- `EdgeSync` class with batching, thread safety, automatic failure fallback
- `telemetry.edge` config section + env var overrides
- `_extract_provider()` for automatic provider detection from model names
- 18 new edge sync tests

### Fixed
- **Critical: `classify()` crashes on string input** — published v0.2.1 didn't include the string-acceptance fix
- **Critical: `--no-strict` mypy flag** — CI was failing on newer mypy versions
- **Null-content recovery** — retry with original model if downgraded model returns null
- **Improved classifier** — 17 new complex keywords, multi-clause detection

### Changed
- 509+ tests passing (was 443)
- Edge telemetry wired into `Tracker.record()` (best-effort, never affects core)
- Config includes `telemetry.edge` section (disabled by default)

## [0.2.1] - 2026-02-24

### Added
- **Streaming support** — `stream=True` now works transparently with routing and tracking
- **License key validation** — LemonSqueezy integration with 24h cache + 72h grace period
- **Tier gating** — dev/free/pro/team feature gates (compression, retrieval, dedup)
- **Same-provider routing** — Router only downgrades within the same provider (gpt→gpt, claude→claude)
- Provider detection for OpenAI, Anthropic, Google, and local models
- 5 streaming tests

### Fixed
- **Critical: Cross-provider routing** — Previously could route `gpt-4o` to `qwen2.5:32b`, causing 404s on OpenAI API
- `__version__` now matches pyproject.toml

### Changed
- Default tiers include OpenAI, Anthropic, and Google models at each tier
- Cost table updated with accurate per-model pricing
- 438→443+ tests

## [0.2.0] - 2026-02-23

### Added
- Same-provider routing (shipped with cosmetic __version__ bug)
- License validation module

## [0.2.0a1] - 2026-02-23

### Added
- First public alpha
- OpenAI + Anthropic client wrappers
- Rule-based complexity classifier
- Prompt compression via LLMLingua-2
- FAISS retrieval engine (from TokenShrink)
- Cost tracking with JSONL persistence
- CLI (`infershrink classify`, `infershrink route`)
- 414 tests

## [0.1.0a3] - 2026-02-13

### Fixed
- Reverted injection detection (not InferShrink's job — that's Agent Guard)
- Pure cost-optimization classifier

## [0.1.0a2] - 2026-02-12

### Added
- Injection detection (reverted in 0.1.0a3)

## [0.1.0a1] - 2026-02-10

### Added
- Initial alpha release
- Basic classifier and router
