"""
InferShrink Demo — LLM Cost Optimization in One Line

Run: python demo_video.py
"""

import os

import openai

from infershrink import optimize

print("=" * 60)
print("  InferShrink — Cut LLM Costs 80%+")
print("=" * 60)
print()

# 1. Wrap your OpenAI-compatible client — one line
client = optimize(
    openai.Client(
        base_url="https://openrouter.ai/api/v1",
        api_key=os.environ["OPENROUTER_API_KEY"],
    ),
    config={
        "tiers": {
            "tier1": {
                "models": ["google/gemini-2.0-flash-lite-001"],
                "max_complexity": "SIMPLE",
                "cost_per_1k_input": 0.000075,
                "cost_per_1k_output": 0.0003,
            },
            "tier2": {
                "models": ["google/gemini-2.5-flash"],
                "max_complexity": "MODERATE",
                "cost_per_1k_input": 0.00015,
                "cost_per_1k_output": 0.0006,
            },
            "tier3": {
                "models": ["anthropic/claude-sonnet-4"],
                "max_complexity": "COMPLEX",
                "cost_per_1k_input": 0.003,
                "cost_per_1k_output": 0.015,
            },
        }
    },
)

print("✓ Client wrapped with optimize() — one line of code\n")

# 2. Simple question → routed to cheapest model
print("─" * 60)
print("Request 1: Simple question")
print("  model='anthropic/claude-sonnet-4'")
print("─" * 60)
response = client.chat.completions.create(
    model="anthropic/claude-sonnet-4",
    messages=[{"role": "user", "content": "What is the capital of France?"}],
)
print(f"→ Answer: {response.choices[0].message.content}\n")

# 3. Complex question → kept on premium model
print("─" * 60)
print("Request 2: Complex analysis")
print("  model='anthropic/claude-sonnet-4'")
print("─" * 60)
response = client.chat.completions.create(
    model="anthropic/claude-sonnet-4",
    messages=[
        {
            "role": "user",
            "content": "Compare proof-of-stake vs proof-of-work consensus for financial settlement, covering finality, MEV resistance, and validator centralization.",
        }
    ],
    max_tokens=500,
)
answer = response.choices[0].message.content
print(f"→ Answer: {answer[:250]}...\n")

# 4. Another simple one
print("─" * 60)
print("Request 3: Simple math")
print("  model='anthropic/claude-sonnet-4'")
print("─" * 60)
response = client.chat.completions.create(
    model="anthropic/claude-sonnet-4",
    messages=[{"role": "user", "content": "What is 127 * 43?"}],
)
print(f"→ Answer: {response.choices[0].message.content}\n")

# 5. Show savings
print("=" * 60)
print("  Cost Summary")
print("=" * 60)
print(client.infershrink_tracker.summary())
