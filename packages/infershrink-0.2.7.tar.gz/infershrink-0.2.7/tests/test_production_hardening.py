"""Tests for production hardening fixes.

Covers: race condition prevention, memory bounds, max_tokens cap,
Path.home() safety, key hashing, datetime.utcnow removal, etc.
"""

import json
import threading
from unittest.mock import MagicMock, patch

import pytest

from infershrink.license import RequestCounter, _hash_key, _safe_home_dir
from infershrink.tracker import _MAX_IN_MEMORY_RECORDS, Tracker
from infershrink.types import Complexity, InferShrinkQuotaError
from infershrink.wrapper import _MAX_TOKENS_CEILING

# ── RequestCounter: atomic check_and_increment ──


class TestCheckAndIncrement:
    """Test the new atomic check_and_increment method."""

    def test_atomic_check_and_increment(self, tmp_path):
        """check_and_increment should atomically check + bump."""
        counter = RequestCounter(usage_file=tmp_path / "usage.json")
        counter.check_and_increment(limit=10)
        assert counter.remaining(10) == 9

    def test_atomic_raises_at_limit(self, tmp_path):
        """Should raise when limit is reached."""
        usage_file = tmp_path / "usage.json"
        usage_file.write_text(json.dumps({"month": "2099-01", "count": 5}))

        counter = RequestCounter(usage_file=usage_file)
        with patch.object(counter, "_get_current_month", return_value="2099-01"):
            with pytest.raises(InferShrinkQuotaError):
                counter.check_and_increment(limit=5)

    def test_atomic_unlimited(self, tmp_path):
        """Should not raise when limit is None (unlimited)."""
        counter = RequestCounter(usage_file=tmp_path / "usage.json")
        # Should not raise
        for _ in range(100):
            counter.check_and_increment(limit=None)

    def test_thread_safety(self, tmp_path):
        """Multiple threads should not corrupt the counter."""
        counter = RequestCounter(usage_file=tmp_path / "usage.json")
        errors = []

        def increment_many():
            try:
                for _ in range(50):
                    counter.check_and_increment(limit=None)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=increment_many) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        # Count should be exactly 200 (4 threads × 50 increments)
        data = json.loads((tmp_path / "usage.json").read_text())
        assert data["count"] == 200


# ── Tracker: bounded records list ──


class TestTrackerBoundedRecords:
    """Test that the tracker caps in-memory records."""

    def test_records_capped(self):
        """Records should not exceed _MAX_IN_MEMORY_RECORDS."""
        tracker = Tracker(config={}, persist_path="")

        for _i in range(_MAX_IN_MEMORY_RECORDS + 100):
            tracker.record(
                original_model="gpt-4o",
                routed_model="gpt-4o-mini",
                original_tokens=100,
                compressed_tokens=80,
                complexity=Complexity.SIMPLE,
            )

        stats = tracker.stats()
        # Total requests should be fully counted
        assert stats.total_requests == _MAX_IN_MEMORY_RECORDS + 100
        # But in-memory records should be capped
        assert len(stats.records) == _MAX_IN_MEMORY_RECORDS

    def test_stats_accurate_beyond_cap(self):
        """Stats (savings, tokens) should be accurate even beyond the record cap."""
        tracker = Tracker(config={}, persist_path="")

        n = _MAX_IN_MEMORY_RECORDS + 50
        for _ in range(n):
            tracker.record(
                original_model="gpt-4o",
                routed_model="gpt-4o-mini",
                original_tokens=100,
                compressed_tokens=80,
                complexity=Complexity.SIMPLE,
            )

        stats = tracker.stats()
        assert stats.total_requests == n
        assert stats.total_original_tokens == n * 100
        assert stats.total_compressed_tokens == n * 80
        assert stats.total_tokens_saved == n * 20


# ── Max tokens cap ──


class TestMaxTokensCeiling:
    """Test the max_tokens retry ceiling."""

    def test_ceiling_constant_exists(self):
        assert _MAX_TOKENS_CEILING == 16384

    def test_wrapper_caps_retry(self):
        """When retrying with increased max_tokens, should not exceed ceiling."""
        from infershrink.wrapper import _InferShrinkCompletionProxy

        # Create a mock response with null content and finish_reason="length"
        mock_choice = MagicMock()
        mock_choice.message.content = None
        mock_choice.finish_reason = "length"

        first_response = MagicMock()
        first_response.choices = [mock_choice]

        # Second response (retry) returns actual content
        retry_choice = MagicMock()
        retry_choice.message.content = "Hello!"
        retry_choice.finish_reason = "stop"
        retry_response = MagicMock()
        retry_response.choices = [retry_choice]

        mock_completions = MagicMock()
        mock_completions.create.side_effect = [first_response, retry_response]

        proxy = _InferShrinkCompletionProxy(
            mock_completions,
            config={
                "_license_limits": {"compression_enabled": True, "max_requests_per_month": None}
            },
            tracker=Tracker(config={}, persist_path=""),
        )

        proxy.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
            max_tokens=8192,
        )

        # Should have called create twice
        assert mock_completions.create.call_count == 2

        # Second call should have capped max_tokens
        retry_call_kwargs = mock_completions.create.call_args_list[1][1]
        assert retry_call_kwargs["max_tokens"] <= _MAX_TOKENS_CEILING


# ── Path.home() safety ──


class TestSafeHomeDir:
    """Test _safe_home_dir fallback."""

    def test_returns_path(self):
        result = _safe_home_dir()
        assert hasattr(result, "exists")

    def test_fallback_on_error(self):
        """Should fall back to /tmp if Path.home() fails."""
        with patch("infershrink.license.Path.home", side_effect=RuntimeError("no HOME")):
            from importlib import reload

            import infershrink.license

            result = infershrink.license._safe_home_dir()
            assert str(result) == "/tmp"  # noqa: S108
            reload(infershrink.license)


# ── Key hashing ──


class TestKeyHashing:
    """Test license key hashing for cache storage."""

    def test_deterministic(self):
        assert _hash_key("abc") == _hash_key("abc")

    def test_different_keys(self):
        assert _hash_key("key1") != _hash_key("key2")

    def test_sha256_length(self):
        h = _hash_key("test")
        assert len(h) == 64

    def test_empty_key(self):
        h = _hash_key("")
        assert len(h) == 64


# ── Classifier: "token" no longer triggers SECURITY_CRITICAL ──


class TestTokenKeywordFix:
    """Verify the word 'token' alone no longer triggers SECURITY_CRITICAL."""

    def test_bare_token_not_security_critical(self):
        """Plain 'token' (e.g., 'how many tokens?') should not be security-critical."""
        from infershrink.classifier import classify

        result = classify([{"role": "user", "content": "How many tokens does this cost?"}])
        assert result.complexity != Complexity.SECURITY_CRITICAL

    def test_auth_token_is_security_critical(self):
        """'auth token' should still trigger SECURITY_CRITICAL."""
        from infershrink.classifier import classify

        result = classify([{"role": "user", "content": "My auth token is abc123"}])
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_access_token_is_security_critical(self):
        from infershrink.classifier import classify

        result = classify([{"role": "user", "content": "Store this access token securely"}])
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_bearer_token_is_security_critical(self):
        from infershrink.classifier import classify

        result = classify([{"role": "user", "content": "Use this bearer token"}])
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_refresh_token_is_security_critical(self):
        from infershrink.classifier import classify

        result = classify([{"role": "user", "content": "My refresh token expired"}])
        assert result.complexity == Complexity.SECURITY_CRITICAL


# ── Tracker: no datetime.utcnow() ──


class TestNoDeprecatedDatetime:
    """Verify that deprecated datetime.utcnow() is not used in tracker."""

    def test_weekly_stats_uses_utc(self):
        """weekly_stats should use timezone-aware datetime."""
        tracker = Tracker(config={}, persist_path="")
        # Should not raise DeprecationWarning
        results = tracker.weekly_stats()
        assert len(results) == 7
        for day in results:
            assert "date" in day


# ── Tracker: file encoding ──


class TestTrackerFileEncoding:
    """Test that tracker persists with UTF-8 encoding."""

    def test_persist_with_unicode(self, tmp_path):
        persist_file = tmp_path / "stats.jsonl"
        tracker = Tracker(config={}, persist_path=str(persist_file))

        tracker.record(
            original_model="gpt-4o",
            routed_model="gpt-4o-mini",
            original_tokens=100,
            compressed_tokens=80,
            complexity=Complexity.SIMPLE,
        )

        # Verify file was written with proper encoding
        content = persist_file.read_text(encoding="utf-8")
        record = json.loads(content.strip())
        assert record["original_model"] == "gpt-4o"
        assert "timestamp" in record
