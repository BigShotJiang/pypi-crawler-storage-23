"""Comprehensive router tests — same-provider routing, edge cases, all paths."""

import pytest

from infershrink.config import build_config
from infershrink.router import (
    _TIER_ORDER,
    _detect_provider,
    _find_tier_for_model,
    _tier_index,
    route,
)
from infershrink.types import Complexity


class TestTierHelpers:
    def test_tier_index_known(self):
        assert _tier_index("tier1") == 0
        assert _tier_index("tier2") == 1
        assert _tier_index("tier3") == 2

    def test_tier_index_unknown(self):
        assert _tier_index("tier99") == len(_TIER_ORDER)

    def test_tier_order(self):
        assert _TIER_ORDER == ["tier1", "tier2", "tier3"]

    def test_find_tier_for_known_model(self):
        config = build_config()
        tiers = config["tiers"]
        assert _find_tier_for_model("gpt-4o-mini", tiers) == "tier1"
        assert _find_tier_for_model("gpt-4o", tiers) == "tier2"
        assert _find_tier_for_model("claude-opus-4-6", tiers) == "tier3"
        assert _find_tier_for_model("claude-sonnet-4-20250514", tiers) == "tier2"

    def test_find_tier_for_unknown_model(self):
        config = build_config()
        assert _find_tier_for_model("unknown-model", config["tiers"]) is None

    def test_find_tier_empty_tiers(self):
        assert _find_tier_for_model("gpt-4o", {}) is None


class TestRoutingDecisionStructure:
    def test_original_model_preserved(self):
        config = build_config()
        for model in ["gpt-4o-mini", "gpt-4o", "claude-opus-4-6", "unknown"]:
            for complexity in Complexity:
                decision = route(model, complexity, config)
                assert decision.original_model == model

    def test_complexity_preserved(self):
        config = build_config()
        for complexity in Complexity:
            decision = route("gpt-4o", complexity, config)
            assert decision.complexity == complexity

    def test_routed_model_always_string(self):
        config = build_config()
        for model in ["gpt-4o-mini", "gpt-4o", "claude-opus-4-6", "unknown"]:
            for complexity in Complexity:
                decision = route(model, complexity, config)
                assert isinstance(decision.routed_model, str)
                assert len(decision.routed_model) > 0


class TestAllRoutingCombinations:
    @pytest.fixture
    def config(self):
        return build_config()

    # gpt-4o-mini (tier1) × all complexities
    def test_tier1_simple(self, config):
        d = route("gpt-4o-mini", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_downgraded is False

    def test_tier1_moderate(self, config):
        d = route("gpt-4o-mini", Complexity.MODERATE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_upgraded is False

    def test_tier1_complex(self, config):
        d = route("gpt-4o-mini", Complexity.COMPLEX, config)
        assert d.routed_model == "gpt-4o-mini"

    def test_tier1_security(self, config):
        d = route("gpt-4o-mini", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "gpt-4o-mini"

    # gpt-4o (tier2) → same-provider downgrades
    def test_tier2_simple(self, config):
        d = route("gpt-4o", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"
        assert d.was_downgraded is True

    def test_tier2_moderate(self, config):
        d = route("gpt-4o", Complexity.MODERATE, config)
        assert d.routed_model == "gpt-4o"

    # claude-opus (tier3) → anthropic-only downgrades
    def test_tier3_simple(self, config):
        d = route("claude-opus-4-6", Complexity.SIMPLE, config)
        provider = _detect_provider(d.routed_model)
        assert provider == "anthropic"
        assert d.was_downgraded is True

    def test_tier3_moderate(self, config):
        d = route("claude-opus-4-6", Complexity.MODERATE, config)
        assert d.routed_model == "claude-sonnet-4-20250514"
        assert d.was_downgraded is True

    def test_tier3_complex(self, config):
        d = route("claude-opus-4-6", Complexity.COMPLEX, config)
        assert d.routed_model == "claude-opus-4-6"

    def test_tier3_security(self, config):
        d = route("claude-opus-4-6", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "claude-opus-4-6"

    # gpt-4.5-preview (tier3) → openai downgrades
    def test_openai_tier3_simple(self, config):
        d = route("gpt-4.5-preview", Complexity.SIMPLE, config)
        assert _detect_provider(d.routed_model) == "openai"
        assert d.was_downgraded is True

    def test_openai_tier3_moderate(self, config):
        d = route("gpt-4.5-preview", Complexity.MODERATE, config)
        assert _detect_provider(d.routed_model) == "openai"
        assert d.was_downgraded is True


class TestUnknownModelRouting:
    @pytest.fixture
    def config(self):
        return build_config()

    def test_unknown_provider_stays_put(self, config):
        """Unknown provider can't match any tier → keeps original"""
        d = route("my-custom-model", Complexity.SIMPLE, config)
        assert d.routed_model == "my-custom-model"

    def test_local_model_simple_routes_to_local(self, config):
        """Local model (llama) can route to local tier1 (qwen)"""
        d = route("llama3:70b", Complexity.SIMPLE, config)
        # llama3:70b not in any tier, but provider is "local"
        # tier1 has qwen2.5:32b (local) → can route there
        if d.was_downgraded:
            assert _detect_provider(d.routed_model) == "local"

    def test_unknown_model_complex_kept(self, config):
        d = route("my-custom-model", Complexity.COMPLEX, config)
        assert d.routed_model == "my-custom-model"

    def test_unknown_model_security_kept(self, config):
        d = route("my-custom-model", Complexity.SECURITY_CRITICAL, config)
        assert d.routed_model == "my-custom-model"

    def test_empty_string_model(self, config):
        d = route("", Complexity.SIMPLE, config)
        # Empty string → unknown provider → stays
        assert isinstance(d.routed_model, str)

    def test_very_long_model_name(self, config):
        long_name = "a" * 1000
        d = route(long_name, Complexity.COMPLEX, config)
        assert d.routed_model == long_name


class TestCustomConfigRouting:
    def test_single_tier_config(self):
        config = build_config(
            {
                "tiers": {
                    "tier1": {"models": ["gpt-4o-mini"]},
                    "tier2": {"models": ["gpt-4o"]},
                    "tier3": {"models": ["gpt-4.5-preview"]},
                }
            }
        )
        d = route("gpt-4.5-preview", Complexity.SIMPLE, config)
        assert d.routed_model == "gpt-4o-mini"

    def test_empty_models_list(self):
        config = build_config(
            {
                "tiers": {
                    "tier1": {"models": []},
                }
            }
        )
        d = route("gpt-4o", Complexity.SIMPLE, config)
        # No models in tier1 → can't downgrade → keep original
        assert d.routed_model == "gpt-4o"

    def test_missing_target_tier(self):
        config = build_config()
        del config["tiers"]["tier1"]
        d = route("gpt-4o", Complexity.SIMPLE, config)
        # tier1 missing → can't downgrade → keep
        assert isinstance(d.routed_model, str)

    def test_no_tiers_at_all(self):
        config = build_config()
        config["tiers"] = {}
        d = route("claude-opus-4-6", Complexity.SIMPLE, config)
        assert d.routed_model == "claude-opus-4-6"


class TestRoutingNeverCrossesProviders:
    """Core invariant: routing NEVER crosses provider boundaries."""

    @pytest.fixture
    def config(self):
        return build_config()

    @pytest.mark.parametrize(
        "model",
        [
            "gpt-4o",
            "gpt-4.5-preview",
            "claude-opus-4-6",
            "claude-sonnet-4-20250514",
            "gemini-2.5-pro",
            "gemini-3-pro-preview",
        ],
    )
    def test_same_provider_always(self, config, model):
        original_provider = _detect_provider(model)
        for complexity in Complexity:
            d = route(model, complexity, config)
            routed_provider = _detect_provider(d.routed_model)
            assert routed_provider == original_provider, (
                f"{model} ({original_provider}) + {complexity.value} "
                f"→ {d.routed_model} ({routed_provider})"
            )


class TestRoutingNeverUpgrades:
    @pytest.fixture
    def config(self):
        return build_config()

    @pytest.mark.parametrize(
        "model,complexity",
        [
            ("gpt-4o-mini", Complexity.MODERATE),
            ("gpt-4o-mini", Complexity.COMPLEX),
            ("gpt-4o", Complexity.COMPLEX),
            ("gpt-4o", Complexity.SECURITY_CRITICAL),
        ],
    )
    def test_no_upgrade(self, config, model, complexity):
        d = route(model, complexity, config)
        original_tier = _find_tier_for_model(model, config["tiers"])
        routed_tier = _find_tier_for_model(d.routed_model, config["tiers"])
        if original_tier and routed_tier:
            assert _tier_index(routed_tier) <= _tier_index(original_tier)
        else:
            assert d.routed_model == model
