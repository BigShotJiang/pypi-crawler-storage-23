"""Tests for the model router — same-provider routing."""

import pytest

from infershrink.config import build_config
from infershrink.router import _detect_provider, route
from infershrink.types import Complexity


@pytest.fixture
def config():
    return build_config()


class TestProviderDetection:
    def test_openai_models(self):
        assert _detect_provider("gpt-4o") == "openai"
        assert _detect_provider("gpt-4o-mini") == "openai"
        assert _detect_provider("gpt-4.1-nano") == "openai"
        assert _detect_provider("o3") == "openai"

    def test_anthropic_models(self):
        assert _detect_provider("claude-opus-4-6") == "anthropic"
        assert _detect_provider("claude-sonnet-4-20250514") == "anthropic"
        assert _detect_provider("claude-3-5-haiku-20241022") == "anthropic"

    def test_google_models(self):
        assert _detect_provider("gemini-2.5-flash") == "google"
        assert _detect_provider("gemini-2.5-pro") == "google"

    def test_local_models(self):
        assert _detect_provider("qwen2.5:32b") == "local"
        assert _detect_provider("llama3:8b") == "local"

    def test_unknown_model(self):
        assert _detect_provider("my-custom-model") == "unknown"


class TestSimpleRouting:
    def test_openai_downgrades_within_provider(self, config):
        """gpt-4o (tier2) + SIMPLE → gpt-4o-mini (tier1, same provider)"""
        decision = route("gpt-4o", Complexity.SIMPLE, config)
        assert _detect_provider(decision.routed_model) == "openai"
        assert decision.routed_model == "gpt-4o-mini"
        assert decision.was_downgraded is True

    def test_anthropic_downgrades_within_provider(self, config):
        """claude-opus (tier3) + SIMPLE → haiku (tier2) since no anthropic in tier1"""
        decision = route("claude-opus-4-6", Complexity.SIMPLE, config)
        assert _detect_provider(decision.routed_model) == "anthropic"
        assert decision.was_downgraded is True

    def test_google_downgrades_within_provider(self, config):
        """gemini-3-pro (tier3) + SIMPLE → gemini-2.5-flash (tier1)"""
        decision = route("gemini-3-pro-preview", Complexity.SIMPLE, config)
        assert _detect_provider(decision.routed_model) == "google"
        assert decision.routed_model == "gemini-2.5-flash"
        assert decision.was_downgraded is True

    def test_keeps_cheap_model_for_simple_task(self, config):
        decision = route("gpt-4o-mini", Complexity.SIMPLE, config)
        assert decision.routed_model == "gpt-4o-mini"
        assert decision.was_downgraded is False

    def test_never_crosses_providers(self, config):
        """claude should never route to gpt or gemini"""
        decision = route("claude-opus-4-6", Complexity.SIMPLE, config)
        assert _detect_provider(decision.routed_model) in ("anthropic",)


class TestModerateRouting:
    def test_downgrades_tier3_to_tier2_same_provider(self, config):
        """claude-opus (tier3) + MODERATE → claude-sonnet (tier2)"""
        decision = route("claude-opus-4-6", Complexity.MODERATE, config)
        assert decision.routed_model == "claude-sonnet-4-20250514"
        assert decision.was_downgraded is True

    def test_keeps_tier2_for_moderate(self, config):
        decision = route("gpt-4o", Complexity.MODERATE, config)
        assert decision.routed_model == "gpt-4o"
        assert decision.was_downgraded is False

    def test_openai_tier3_to_tier2(self, config):
        decision = route("gpt-4.5-preview", Complexity.MODERATE, config)
        assert _detect_provider(decision.routed_model) == "openai"
        assert decision.was_downgraded is True

    def test_does_not_upgrade_tier1_for_moderate(self, config):
        decision = route("gpt-4o-mini", Complexity.MODERATE, config)
        assert decision.routed_model == "gpt-4o-mini"
        assert decision.was_upgraded is False


class TestComplexRouting:
    def test_keeps_tier3_for_complex(self, config):
        decision = route("claude-opus-4-6", Complexity.COMPLEX, config)
        assert decision.routed_model == "claude-opus-4-6"

    def test_does_not_upgrade_tier1_for_complex(self, config):
        decision = route("gpt-4o-mini", Complexity.COMPLEX, config)
        assert decision.routed_model == "gpt-4o-mini"


class TestSecurityCriticalRouting:
    def test_keeps_tier3_for_security(self, config):
        decision = route("claude-opus-4-6", Complexity.SECURITY_CRITICAL, config)
        assert decision.routed_model == "claude-opus-4-6"

    def test_keeps_claude_sonnet_for_security(self, config):
        decision = route("claude-sonnet-4-20250514", Complexity.SECURITY_CRITICAL, config)
        assert decision.routed_model == "claude-sonnet-4-20250514"

    def test_never_downgrades_security(self, config):
        decision = route("claude-opus-4-6", Complexity.SECURITY_CRITICAL, config)
        assert decision.was_downgraded is False


class TestUnknownModel:
    def test_unknown_model_simple_stays_put(self, config):
        """Unknown provider can't match any tier1 model → stays"""
        decision = route("my-custom-model", Complexity.SIMPLE, config)
        assert decision.routed_model == "my-custom-model"

    def test_unknown_model_complex_task_kept(self, config):
        decision = route("my-custom-model", Complexity.COMPLEX, config)
        assert decision.routed_model == "my-custom-model"

    def test_unknown_model_security_kept(self, config):
        decision = route("my-custom-model", Complexity.SECURITY_CRITICAL, config)
        assert decision.routed_model == "my-custom-model"


class TestCustomConfig:
    def test_custom_tier_respects_provider(self):
        """Custom config with provider-matching models"""
        config = build_config(
            {
                "tiers": {
                    "tier1": {
                        "models": ["gpt-4o-mini", "claude-3-5-haiku-20241022"],
                        "max_complexity": "SIMPLE",
                    }
                }
            }
        )
        # Claude should route to haiku, not gpt-4o-mini
        decision = route("claude-opus-4-6", Complexity.SIMPLE, config)
        assert _detect_provider(decision.routed_model) == "anthropic"

    def test_routing_decision_fields(self, config):
        decision = route("gpt-4.5-preview", Complexity.SIMPLE, config)
        assert decision.original_model == "gpt-4.5-preview"
        assert decision.complexity == Complexity.SIMPLE
