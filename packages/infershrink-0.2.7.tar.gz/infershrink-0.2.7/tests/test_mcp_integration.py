"""Integration tests for InferShrink MCP Server.

End-to-end tests: build server → call tools → verify responses.
Covers auth flow, rate limiting, and tool chaining.
"""

from __future__ import annotations

import pytest

mcp = pytest.importorskip("mcp", reason="MCP SDK not installed")


class TestEndToEnd:
    """Full round-trip tests."""

    def _build(self):
        from infershrink.mcp_server import _build_server

        return _build_server()

    def test_classify_then_optimize_consistent(self):
        """Classify and optimize should agree on complexity."""
        server = self._build()
        classify_fn = server._tool_manager._tools["infershrink_classify"].fn
        optimize_fn = server._tool_manager._tools["infershrink_optimize"].fn

        prompt = "What is 2+2?"
        c_result = classify_fn(prompt=prompt, provider="openai")
        o_result = optimize_fn(
            messages=[{"role": "user", "content": prompt}],
            provider="openai",
            current_model="gpt-4o",
        )
        assert c_result["complexity"] == o_result["complexity"]

    def test_complex_prompt_stays_on_tier3(self):
        server = self._build()
        optimize_fn = server._tool_manager._tools["infershrink_optimize"].fn
        result = optimize_fn(
            messages=[
                {
                    "role": "user",
                    "content": (
                        "Write a comprehensive step-by-step analysis of "
                        "recursive algorithms with mathematical proofs "
                        "and benchmark comparisons"
                    ),
                }
            ],
            provider="openai",
            current_model="gpt-4o",
        )
        assert result["complexity"] == "complex"
        # Should not downgrade a complex request
        assert result["downgraded"] is False

    def test_status_after_multiple_calls(self):
        server = self._build()
        classify_fn = server._tool_manager._tools["infershrink_classify"].fn
        status_fn = server._tool_manager._tools["infershrink_status"].fn

        # Make several calls
        for _ in range(5):
            classify_fn(prompt=f"Test prompt {_}", provider="openai")

        status = status_fn()
        assert status["total_requests"] >= 5
        assert "routing" in status["features"]
        assert status["version"]

    def test_all_providers_work(self):
        server = self._build()
        classify_fn = server._tool_manager._tools["infershrink_classify"].fn

        for provider in ["openai", "anthropic", "google"]:
            result = classify_fn(prompt="Hello", provider=provider)
            assert result["provider"] == provider
            assert result["complexity"] in ("simple", "moderate", "complex", "security_critical")

    def test_security_critical_detected(self):
        server = self._build()
        classify_fn = server._tool_manager._tools["infershrink_classify"].fn
        result = classify_fn(
            prompt="Store this api_key: sk-abc123 in the database", provider="openai"
        )
        assert result["complexity"] == "security_critical"

    def test_optimize_with_multi_turn(self):
        server = self._build()
        optimize_fn = server._tool_manager._tools["infershrink_optimize"].fn
        result = optimize_fn(
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": "What's the weather?"},
                {"role": "assistant", "content": "I don't have weather data."},
                {"role": "user", "content": "Ok thanks"},
            ],
            provider="openai",
            current_model="gpt-4o",
        )
        assert result["provider"] == "openai"
        assert "complexity" in result


class TestAuthIntegration:
    """Test auth module integration."""

    def test_bearer_auth_flow(self, monkeypatch):
        monkeypatch.setenv("INFERSHRINK_API_KEY", "test-key")
        from infershrink.mcp_auth import authenticate

        result = authenticate(bearer_token="test-key")
        assert result.authenticated
        assert result.tier == "pro"

    def test_free_tier_no_auth(self, monkeypatch):
        monkeypatch.delenv("INFERSHRINK_API_KEY", raising=False)
        from infershrink.mcp_auth import authenticate

        result = authenticate()
        assert result.authenticated
        assert result.tier == "free"


class TestRateLimitIntegration:
    """Test rate limiter with tool calls."""

    def test_free_tier_rate_limit(self):
        from infershrink.mcp_rate_limit import RateLimiter

        limiter = RateLimiter()
        # Simulate 10 tool calls (free tier limit)
        for _ in range(10):
            result = limiter.check("test-client", "free")
            assert result.allowed

        # 11th should be blocked
        result = limiter.check("test-client", "free")
        assert not result.allowed
        assert "free" in result.error

    def test_pro_tier_allows_more(self):
        from infershrink.mcp_rate_limit import RateLimiter

        limiter = RateLimiter()
        for _ in range(50):
            result = limiter.check("pro-client", "pro")
            assert result.allowed
