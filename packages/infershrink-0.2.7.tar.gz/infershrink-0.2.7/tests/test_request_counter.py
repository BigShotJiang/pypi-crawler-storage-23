"""Tests for request counting and quota enforcement."""

import json
from unittest.mock import patch

import pytest

from infershrink.license import TIER_LIMITS, RequestCounter
from infershrink.types import InferShrinkQuotaError


@pytest.fixture
def temp_usage_file(tmp_path):
    """Create a temporary usage file."""
    return tmp_path / "usage.json"


@pytest.fixture
def counter(temp_usage_file):
    """Create a RequestCounter with a temporary file."""
    return RequestCounter(usage_file=temp_usage_file)


def test_increment_creates_file(counter, temp_usage_file):
    """Test that increment creates the usage file if it doesn't exist."""
    assert not temp_usage_file.exists()
    counter.increment()
    assert temp_usage_file.exists()

    data = json.loads(temp_usage_file.read_text())
    assert data["count"] == 1
    assert "month" in data


def test_increment_counts_correctly(counter, temp_usage_file):
    """Test that increment increases the count."""
    counter.increment()
    counter.increment()
    counter.increment()

    data = json.loads(temp_usage_file.read_text())
    assert data["count"] == 3


def test_remaining(counter):
    """Test remaining calculation."""
    limit = 100
    assert counter.remaining(limit) == 100

    counter.increment()
    assert counter.remaining(limit) == 99

    # Simulate usage
    for _ in range(10):
        counter.increment()
    assert counter.remaining(limit) == 89


def test_remaining_unlimited(counter):
    """Test remaining with no limit (None)."""
    assert counter.remaining(None) is None
    counter.increment()
    assert counter.remaining(None) is None


def test_quota_error(counter):
    """Test that InferShrinkQuotaError is raised when limit is reached."""
    limit = 5

    # Use up the quota
    for _ in range(5):
        counter.increment()

    # Check should raise error now
    with pytest.raises(InferShrinkQuotaError) as exc:
        counter.check(limit)

    assert "Monthly request limit of 5 exceeded" in str(exc.value)


def test_reset_on_new_month(counter, temp_usage_file):
    """Test that count resets when month changes."""
    # Write old month data
    old_data = {"month": "2023-01", "count": 500}
    temp_usage_file.write_text(json.dumps(old_data))

    # Should reset on read/increment because current month is different
    # We rely on the real datetime which is definitely not 2023-01
    counter.increment()

    data = json.loads(temp_usage_file.read_text())
    assert data["count"] == 1
    assert data["month"] != "2023-01"


def test_dev_tier_unlimited(counter):
    """Test that dev tier (limit=None) never raises error."""
    limit = TIER_LIMITS["dev"]["max_requests_per_month"]
    assert limit is None

    # Simulate many requests
    for _ in range(100):
        counter.increment()

    # Should not raise
    counter.check(limit)


def test_free_tier_limit(counter):
    """Test free tier limits."""
    limit = TIER_LIMITS["free"]["max_requests_per_month"]
    assert limit == 1000

    # Mock reading usage to simulate being near limit
    with patch.object(counter, "_read_usage") as mock_read:
        mock_read.return_value = {"month": "2024-01", "count": 1000}

        with pytest.raises(InferShrinkQuotaError):
            counter.check(limit)


def test_persistence(counter, temp_usage_file):
    """Test that data persists between instances."""
    counter.increment()

    # New instance pointing to same file
    counter2 = RequestCounter(usage_file=temp_usage_file)
    counter2.increment()

    data = json.loads(temp_usage_file.read_text())
    assert data["count"] == 2
