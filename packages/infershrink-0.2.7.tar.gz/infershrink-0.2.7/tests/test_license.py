"""Tests for license key validation and tier gating."""

import os
import time
from unittest.mock import patch

from infershrink.license import (
    TIER_LIMITS,
    _cache_path,
    _hash_key,
    _write_cache,
    get_limits,
    validate,
)


class TestNoKey:
    """No key = dev mode, all features enabled."""

    def test_no_key_returns_dev(self):
        with patch.dict(os.environ, {}, clear=True):
            info = validate("")
            assert info.tier == "dev"
            assert info.valid is True

    def test_no_env_returns_dev(self):
        env = {k: v for k, v in os.environ.items() if k != "INFERSHRINK_LICENSE_KEY"}
        with patch.dict(os.environ, env, clear=True):
            info = validate(None)
            assert info.tier == "dev"

    def test_dev_all_features_enabled(self):
        limits = get_limits("dev")
        assert limits["compression_enabled"] is True
        assert limits["retrieval_enabled"] is True
        assert limits["dedup_enabled"] is True
        assert limits["max_requests_per_month"] is None


class TestFreeTier:
    """Free tier has limited features."""

    def test_free_limits(self):
        limits = get_limits("free")
        assert limits["compression_enabled"] is False
        assert limits["retrieval_enabled"] is False
        assert limits["max_requests_per_month"] == 1_000
        assert limits["max_models"] == 2


class TestProTier:
    def test_pro_limits(self):
        limits = get_limits("pro")
        assert limits["compression_enabled"] is True
        assert limits["retrieval_enabled"] is True
        assert limits["max_requests_per_month"] == 50_000
        assert limits["max_keys"] == 1


class TestTeamTier:
    def test_team_limits(self):
        limits = get_limits("team")
        assert limits["max_requests_per_month"] == 500_000
        assert limits["max_keys"] == 5


class TestRemoteValidation:
    """Test LemonSqueezy API validation (mocked)."""

    @patch("infershrink.license._validate_remote")
    def test_valid_pro_key(self, mock_remote):
        mock_remote.return_value = {
            "valid": True,
            "meta": {"variant_name": "InferShrink Pro"},
            "license_key": {
                "instance_id": "inst_123",
                "customer_email": "user@example.com",
                "expires_at": None,
            },
        }
        # Clear cache
        cache_path = _cache_path()
        if cache_path.exists():
            cache_path.unlink()

        info = validate("ls_live_test123")
        assert info.tier == "pro"
        assert info.valid is True
        assert info.customer_email == "user@example.com"

    @patch("infershrink.license._validate_remote")
    def test_valid_team_key(self, mock_remote):
        mock_remote.return_value = {
            "valid": True,
            "meta": {"variant_name": "InferShrink Team"},
            "license_key": {},
        }
        cache_path = _cache_path()
        if cache_path.exists():
            cache_path.unlink()

        info = validate("ls_live_team456")
        assert info.tier == "team"
        assert info.valid is True

    @patch("infershrink.license._validate_remote")
    def test_invalid_key(self, mock_remote):
        mock_remote.return_value = {
            "valid": False,
            "meta": {},
            "license_key": {},
        }
        cache_path = _cache_path()
        if cache_path.exists():
            cache_path.unlink()

        info = validate("ls_live_invalid")
        assert info.tier == "free"
        assert info.valid is False


class TestCache:
    """Test 24h cache + 72h grace period."""

    @patch("infershrink.license._validate_remote")
    def test_fresh_cache_skips_remote(self, mock_remote):
        """Within 24h, don't call API."""
        _write_cache(
            {
                "key_hash": _hash_key("ls_live_cached"),
                "tier": "pro",
                "valid": True,
                "validated_at": time.time(),
            }
        )

        info = validate("ls_live_cached")
        assert info.tier == "pro"
        assert info.valid is True
        mock_remote.assert_not_called()

    @patch("infershrink.license._validate_remote")
    def test_stale_cache_grace_period(self, mock_remote):
        """Between 24h-72h, try remote but fall back to cache on failure."""
        mock_remote.side_effect = Exception("Network error")
        _write_cache(
            {
                "key_hash": _hash_key("ls_live_grace"),
                "tier": "pro",
                "valid": True,
                "validated_at": time.time() - 90000,  # ~25 hours ago
            }
        )

        info = validate("ls_live_grace")
        assert info.tier == "pro"  # Falls back to cached
        assert "grace period" in (info.error or "")

    @patch("infershrink.license._validate_remote")
    def test_expired_cache_requires_remote(self, mock_remote):
        """Beyond 72h, must validate remotely."""
        mock_remote.return_value = {
            "valid": True,
            "meta": {"variant_name": "Pro"},
            "license_key": {},
        }
        _write_cache(
            {
                "key_hash": _hash_key("ls_live_expired"),
                "tier": "pro",
                "valid": True,
                "validated_at": time.time() - 300000,  # ~3.5 days ago
            }
        )

        validate("ls_live_expired")
        mock_remote.assert_called_once()


class TestEnvVar:
    """Test INFERSHRINK_LICENSE_KEY env var."""

    @patch("infershrink.license._validate_remote")
    def test_reads_from_env(self, mock_remote):
        mock_remote.return_value = {
            "valid": True,
            "meta": {"variant_name": "Pro"},
            "license_key": {},
        }
        cache_path = _cache_path()
        if cache_path.exists():
            cache_path.unlink()

        with patch.dict(os.environ, {"INFERSHRINK_LICENSE_KEY": "ls_live_env"}):
            info = validate()  # No explicit key
            assert info.valid is True
            mock_remote.assert_called_once()

    def test_explicit_key_overrides_env(self):
        with patch.dict(os.environ, {"INFERSHRINK_LICENSE_KEY": "ls_live_env"}):
            info = validate("")  # Explicit empty = dev mode
            assert info.tier == "dev"


class TestAllTiersExist:
    def test_all_tiers_defined(self):
        for tier in ["dev", "free", "pro", "team"]:
            limits = get_limits(tier)
            assert "compression_enabled" in limits
            assert "max_requests_per_month" in limits

    def test_unknown_tier_defaults_to_free(self):
        limits = get_limits("nonexistent")
        assert limits == TIER_LIMITS["free"]


class TestKeyHashing:
    """Test that license keys are hashed for cache comparison."""

    def test_hash_is_deterministic(self):
        assert _hash_key("test123") == _hash_key("test123")

    def test_different_keys_different_hashes(self):
        assert _hash_key("key1") != _hash_key("key2")

    def test_hash_is_sha256_hex(self):
        h = _hash_key("test")
        assert len(h) == 64  # SHA-256 hex is 64 chars
        assert all(c in "0123456789abcdef" for c in h)
