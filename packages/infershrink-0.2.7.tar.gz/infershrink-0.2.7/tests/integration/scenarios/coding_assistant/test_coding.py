"""
Coding Assistant scenario: Agent generates, reviews, and debugs code.

InferShrink should:
- Route simple completions (docstrings, type hints, typos) to cheap models
- Route complex refactors and architecture to strong models
- Correctly identify code blocks as complexity signals
- Never downgrade security-sensitive code operations
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent / "src"))

from infershrink.types import Complexity


class TestCodingClassification:
    """Test classification of coding tasks."""

    def test_simple_coding_tasks(self, classify_fn, coding_tasks):
        """Simple coding tasks should be classified as SIMPLE."""
        simple_tasks = [t for t in coding_tasks if t["expected_complexity"] == Complexity.SIMPLE]
        correct = 0
        for task in simple_tasks:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            if result.complexity == Complexity.SIMPLE:
                correct += 1
        # At least 60% correct
        assert correct >= len(simple_tasks) * 0.6, (
            f"Only {correct}/{len(simple_tasks)} simple coding tasks classified correctly"
        )

    def test_moderate_coding_tasks(self, classify_fn, coding_tasks):
        """Moderate coding tasks should not be classified as SIMPLE."""
        moderate_tasks = [
            t for t in coding_tasks if t["expected_complexity"] == Complexity.MODERATE
        ]
        not_simple = 0
        for task in moderate_tasks:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            if result.complexity != Complexity.SIMPLE:
                not_simple += 1
        assert not_simple >= len(moderate_tasks) * 0.6, (
            f"Only {not_simple}/{len(moderate_tasks)} moderate tasks avoided SIMPLE"
        )

    def test_complex_coding_tasks(self, classify_fn, coding_tasks):
        """Complex coding tasks with code blocks should be classified as COMPLEX or MODERATE."""
        complex_tasks = [t for t in coding_tasks if t["expected_complexity"] == Complexity.COMPLEX]
        high_complexity = 0
        for task in complex_tasks:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            if result.complexity in (Complexity.COMPLEX, Complexity.MODERATE):
                high_complexity += 1
        # At least 50% — short prompts without code blocks may classify lower
        assert high_complexity >= len(complex_tasks) * 0.5, (
            f"Only {high_complexity}/{len(complex_tasks)} complex tasks classified as MODERATE+"
        )


class TestCodingRouting:
    """Test routing decisions for coding tasks."""

    def test_docstring_routed_cheap(self, tracked_client):
        tracked_client.chat.completions.create(
            model="gpt-4.5-preview",
            messages=[
                {"role": "user", "content": "Add a docstring to: def add(a, b): return a + b"}
            ],
        )
        model = tracked_client.chat.completions.calls[-1].get("model", "")
        assert "mini" in model, f"Simple docstring task routed to {model}"

    def test_refactor_stays_strong(self, tracked_client):
        prompt = """Refactor this 500-line monolithic function into a class hierarchy.
Apply SOLID principles. Create separate modules for:
```python
def process_everything(data, config, db, cache, logger, metrics):
    # ... imagine 500 lines of tangled logic
    # validation, transformation, persistence, notification
    # error handling, retry logic, circuit breaking
    # all mixed together
    pass
```
Include type hints, docstrings, unit tests, and a migration guide."""
        tracked_client.chat.completions.create(
            model="gpt-4.5-preview",
            messages=[{"role": "user", "content": prompt}],
        )
        model = tracked_client.chat.completions.calls[-1].get("model", "")
        assert "mini" not in model, f"Complex refactor should not be downgraded, got {model}"

    def test_security_code_never_downgraded(self, tracked_client):
        """Code handling credentials/secrets should never be downgraded."""
        prompt = """Review this authentication code for security vulnerabilities:
```python
def authenticate(username, password):
    api_key = os.environ.get('SECRET_API_KEY')
    hashed = hashlib.sha256(password.encode()).hexdigest()
    token = jwt.encode({'user': username}, api_key, algorithm='HS256')
    return token
```
Check for: timing attacks, key management, token expiration, password hashing strength."""
        tracked_client.chat.completions.create(
            model="gpt-4.5-preview",
            messages=[{"role": "user", "content": prompt}],
        )
        model = tracked_client.chat.completions.calls[-1].get("model", "")
        assert "mini" not in model, f"Security code review must not be downgraded, got {model}"


class TestCodingCostSavings:
    """Test that coding sessions show meaningful cost savings."""

    def test_mixed_coding_session(self, tracked_client, coding_tasks):
        """A realistic coding session should save on simple tasks."""
        for task in coding_tasks:
            tracked_client.chat.completions.create(
                model="gpt-4.5-preview",
                messages=[{"role": "user", "content": task["prompt"]}],
            )

        stats = tracked_client.infershrink_tracker.stats()
        assert stats.total_requests == len(coding_tasks)
        # Should downgrade at least the simple tasks
        simple_count = sum(1 for t in coding_tasks if t["expected_complexity"] == Complexity.SIMPLE)
        assert stats.requests_downgraded >= simple_count * 0.5, (
            f"Expected at least {simple_count * 0.5} downgrades from {simple_count} simple tasks"
        )
