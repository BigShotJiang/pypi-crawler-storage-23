"""
Research Assistant scenario: Agent answers questions from a knowledge base.

InferShrink should:
- Route simple factual Q&A to cheap models
- Route complex analytical questions to strong models
- Compress verbose context before sending
- Track cost savings across all queries
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent / "src"))

from infershrink.types import Complexity


class TestResearchClassification:
    """Test that research queries are classified correctly."""

    def test_simple_factual_query(self, classify_fn):
        messages = [{"role": "user", "content": "What are the API rate limits?"}]
        result = classify_fn(messages)
        assert result.complexity in (Complexity.SIMPLE, Complexity.MODERATE)

    def test_simple_lookup(self, classify_fn):
        messages = [{"role": "user", "content": "How do I install the SDK?"}]
        result = classify_fn(messages)
        assert result.complexity == Complexity.SIMPLE

    def test_moderate_analysis(self, classify_fn):
        messages = [
            {
                "role": "user",
                "content": """Compare the architecture of our system
        with a monolithic approach. What are the tradeoffs in terms of latency,
        operational complexity, and development velocity?""",
            }
        ]
        result = classify_fn(messages)
        assert result.complexity in (Complexity.MODERATE, Complexity.COMPLEX)

    def test_complex_with_context(self, classify_fn):
        """Long context + analytical question = complex."""
        context = "Technical specification document... " * 100  # ~500 tokens
        messages = [
            {"role": "system", "content": f"Context: {context}"},
            {
                "role": "user",
                "content": """Based on the above architecture docs,
            design a migration plan from the current microservices setup to a
            serverless architecture. Include risk assessment, rollback strategy,
            and estimated timeline for each phase.""",
            },
        ]
        result = classify_fn(messages)
        assert result.complexity in (Complexity.MODERATE, Complexity.COMPLEX)


class TestResearchRouting:
    """Test that research queries are routed to appropriate models."""

    def test_simple_queries_routed_cheap(self, tracked_client):
        """Simple factual queries should be routed to cheap models."""
        simple_queries = [
            "What is the return policy?",
            "How do I reset my password?",
            "What time does the store open?",
            "Where is the nearest office?",
            "What version is the latest release?",
        ]
        for query in simple_queries:
            tracked_client.chat.completions.create(
                model="gpt-4.5-preview",
                messages=[{"role": "user", "content": query}],
            )

        calls = tracked_client.chat.completions.calls
        mini_count = sum(1 for c in calls if "mini" in c.get("model", ""))
        # At least 60% should be routed to tier1
        assert mini_count >= 3, f"Only {mini_count}/5 simple queries routed to tier1"

    def test_complex_queries_stay_strong(self, tracked_client):
        """Complex analytical queries should stay on strong models."""
        complex_query = """Based on the provided documentation covering API architecture,
        authentication flows, and rate limiting, design a comprehensive testing strategy
        that covers:
        1. Load testing under various rate limit scenarios
        2. Authentication edge cases (expired tokens, concurrent sessions)
        3. Failover behavior when the query engine is degraded
        4. Data consistency during cache invalidation
        Include specific test cases, expected outcomes, and tooling recommendations."""

        tracked_client.chat.completions.create(
            model="gpt-4.5-preview",
            messages=[{"role": "user", "content": complex_query}],
        )

        last_call = tracked_client.chat.completions.calls[-1]
        assert "mini" not in last_call.get("model", ""), (
            "Complex query should not be downgraded to mini"
        )


class TestResearchCostTracking:
    """Test cost tracking across a research session."""

    def test_mixed_session_tracking(self, tracked_client):
        """A mix of simple and complex queries should show savings."""
        queries = [
            "What is Python?",
            "Hello",
            "How do I print?",
            """Design a distributed caching system that handles:
            - Cache invalidation across 5 regions
            - Conflict resolution for concurrent writes
            - Graceful degradation under partition
            Include sequence diagrams and failure modes.""",
            "What is a variable?",
            "Thanks!",
        ]

        for q in queries:
            tracked_client.chat.completions.create(
                model="gpt-4.5-preview",
                messages=[{"role": "user", "content": q}],
            )

        tracker = tracked_client.infershrink_tracker
        stats = tracker.stats()
        assert stats.total_requests == 6
        assert stats.requests_downgraded >= 3, (
            f"Expected >=3 downgrades, got {stats.requests_downgraded}"
        )

    def test_tracker_summary_format(self, tracked_client):
        """Tracker summary should be human-readable."""
        tracked_client.chat.completions.create(
            model="gpt-4.5-preview",
            messages=[{"role": "user", "content": "Hello"}],
        )
        summary = tracked_client.infershrink_tracker.summary()
        assert "Total requests" in summary
        assert "1" in summary

    def test_tracker_reset(self, tracked_client):
        """Tracker reset should clear all data."""
        tracked_client.chat.completions.create(
            model="gpt-4.5-preview",
            messages=[{"role": "user", "content": "Hi"}],
        )
        tracked_client.infershrink_tracker.reset()
        stats = tracked_client.infershrink_tracker.stats()
        assert stats.total_requests == 0
