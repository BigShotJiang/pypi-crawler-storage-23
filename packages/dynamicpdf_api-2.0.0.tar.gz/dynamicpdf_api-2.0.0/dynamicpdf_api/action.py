class Action:
    '''Base class representing an action to perform tasks in many places 
    such as in outlines, links, buttons etc.'''

    def __init__(self):
        pass