class Color:
    '''
    Base class representing a color.
    '''
    
    def __init__(self):
        self.color_string=None