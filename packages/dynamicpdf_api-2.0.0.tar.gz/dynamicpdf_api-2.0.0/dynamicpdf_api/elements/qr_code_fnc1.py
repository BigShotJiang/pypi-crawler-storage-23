class QrCodeFnc1:
    '''
    The type of FNC1 mode to use.
    '''
    
    # FNC1 None
    none="none"

    # FNC1 Gs1
    Gs1="gs1"

    # FNC1 Industry
    Industry="industry"