class OutlineStyle:
    '''
    Specifies the style of the outline
    '''
    
    # Bold.
    Bold = "bold"

    # Bold Italic.
    BoldItalic = "boldItalic"
    
    # Italic.
    Italic = "italic"

    # Regular.
    Regular = "regular"
