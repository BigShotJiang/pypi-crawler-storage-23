class FontInformation:
    def __init__(self, font_name, file_path):
        self._font_name = font_name
        self._file_path = file_path
