from .color_format import ColorFormat

class PngColorFormat(ColorFormat):
    def __init__(self, type):
        super().__init__(type)