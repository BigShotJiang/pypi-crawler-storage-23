from enum import Enum

class ImageSizeUnit(Enum):
    Millimeter = 'Millimeter'
    Inch = 'Inch'
    Point = 'Point'