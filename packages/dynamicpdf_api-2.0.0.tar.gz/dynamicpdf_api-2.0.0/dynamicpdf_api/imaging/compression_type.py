from enum import Enum

class CompressionType(Enum):
    CcitGroup3 = 'CcitGroup3'
    CcitGroup4 = 'CcitGroup4'