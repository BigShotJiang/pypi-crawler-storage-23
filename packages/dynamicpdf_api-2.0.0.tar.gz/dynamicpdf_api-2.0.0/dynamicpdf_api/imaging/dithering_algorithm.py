from enum import Enum

class DitheringAlgorithm(Enum):
    FloydSteinberg = 'FloydSteinberg'
    Bayer = 'Bayer'
    none = "none"