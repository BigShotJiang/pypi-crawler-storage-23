"""Setup script for emk package."""
from setuptools import setup

# Configuration is in pyproject.toml
setup()
