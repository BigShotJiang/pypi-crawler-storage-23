"""
Test suite for Context-as-a-Service.
"""
