"""
API module initialization.
"""

from caas.api.server import app

__all__ = ["app"]
