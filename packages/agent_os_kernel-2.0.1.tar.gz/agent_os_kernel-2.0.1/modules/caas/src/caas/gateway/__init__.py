# Community Edition — basic context/memory management
"""
Gateway sub-package — placeholder after Trust Gateway removal.
"""

__all__: list = []

