"""Player Estimated Metrics endpoint for estimated advanced statistics."""

from typing import ClassVar

from pydantic import Field

from fastbreak.endpoints.base import Endpoint
from fastbreak.models.player_estimated_metrics import PlayerEstimatedMetricsResponse
from fastbreak.seasons import get_season_from_date
from fastbreak.types import LeagueID, Season, SeasonType


class PlayerEstimatedMetrics(Endpoint[PlayerEstimatedMetricsResponse]):
    """Fetch estimated advanced metrics for all players in the league.

    Returns estimated offensive/defensive ratings, efficiency percentages,
    pace, and league-wide rankings for each player.

    Args:
        league_id: League identifier ("00" for NBA)
        season: Season in YYYY-YY format (e.g., "2024-25")
        season_type: Type of season ("Regular Season", "Playoffs", "Pre Season")

    """

    path: ClassVar[str] = "playerestimatedmetrics"
    response_model: ClassVar[type[PlayerEstimatedMetricsResponse]] = (
        PlayerEstimatedMetricsResponse
    )

    league_id: LeagueID = "00"
    season: Season = Field(default_factory=get_season_from_date)
    season_type: SeasonType = "Regular Season"

    def params(self) -> dict[str, str]:
        """Return the query parameters for this endpoint."""
        return {
            "LeagueID": self.league_id,
            "Season": self.season,
            "SeasonType": self.season_type,
        }
