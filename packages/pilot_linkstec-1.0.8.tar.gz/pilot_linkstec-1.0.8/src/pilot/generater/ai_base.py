from typing import Dict, Any, Optional

from pilot.generater.ai_interface import AIInterface
from pilot.generater.generation_config import GenerationConfigDTO

class AIBase(AIInterface):
    def generate_content(
        self, 
        prompt: str, 
        gen_config: Optional[GenerationConfigDTO] = None,
        stream: Optional[bool] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        ベース実装。具体的なAPI呼び出しは子クラスでオーバーライドすること。
        """
        # 如果 AIBase 不做具体的逻辑处理，可以直接 pass 或者抛出异常
        raise NotImplementedError("サブクラスで generate_content を実装してください")