from dataclasses import dataclass
from typing import Optional

@dataclass
class GenerationConfigDTO:
    temperature: float = 1.0
    top_p: float = 0.95
    max_output_tokens: int = 262128
    thinking_budget: Optional[int] = None
    include_thoughts: bool = True
    system_instruction: str = ""
    stream: bool = False
    timeout: int = 600
    api_version : str = "v1"
    deployment_name : str = ""
