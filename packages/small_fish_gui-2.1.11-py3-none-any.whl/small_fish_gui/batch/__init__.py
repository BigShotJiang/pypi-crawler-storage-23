""""
Module handling all batch processing interface; organised output and call to pipeline
"""

from .prompt import batch_promp