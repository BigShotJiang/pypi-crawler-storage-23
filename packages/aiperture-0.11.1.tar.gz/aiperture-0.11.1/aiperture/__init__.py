"""AIperture — The permission layer for AI agents."""

__version__ = "0.2.0"
