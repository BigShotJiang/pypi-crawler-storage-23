import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from HalChat import HalChat

#codeBot="hBfWguy2XqgTbS852z71alaQSWaCyxcOgD7jCLMK1icfWiHpfMEWqidNtgSqppsCV0DoVSuEIb3a0FB3bmB0sUqfa2OjVJpFZcSz"
codeBot="hBfWguy2XqgTbS852z71alaQSWaCyxcOgD7jCLMK1icfWiHpfMEWqidNtgSqppsCV0DoVSuEIb3a0FB3bmB0sUqfa2OjVJpFZcSz"
hca=HalChat(codeBot,log_level=3)

test_buttons=[
    {
        "text":"Кнопка 0",
        "color":"#ffffff"
    },
    {
        "text":"Кнопка 1",
        "color":"#ff0000"
    },
    {
        "text":"Кнопка 2",
        "color":"#00ff00"
    },
    {
        "text":"Кнопка 3",
        "color":"#000000"
    }
]

test_menu=[
    {
        "icon":"JPJ6PANAwrmUCNjBmBqZjQbTXyA3jqxUGAwVT2CRAoLWgpaIy7UBKvgk51yoMpStuk9kVrWbTHFmMLZznBjC0Ks6TRL7biZsl30b",
        "command":"тест",
        "description":"Тестовая команда"
    }
]

@hca.event('onNewMessage')
async def on_new_message(msg,isExistPassword):
    print("on_new_message: ", msg, isExistPassword)
    if not isExistPassword:
        return

    chatId=msg['fromChat']

    if(msg['message']=="/тест"):
        await hca.send_message(chatId,"Тест кнопок:",buttons=test_buttons)
        return

    await hca.send_message(chatId,"Привет!")
    await hca.set_menu(chatId,test_menu)

@hca.event('onReceivePassword')
async def on_receive_password(chatId):
    await hca.send_message(chatId,'Бот успешно инициализирован.')
    print("on_receive_password: ", chatId)
    await hca.set_menu(chatId,test_menu)

@hca.event('onNewChat')
async def on_new_chat(chatId,fromId,inviteId):
    print("new chat")

@hca.event('onClickButton')
async def on_click_button(chatId,fromId,fromMsg,button):
    await hca.send_message(chatId,"Нажата: "+button['text'])

if __name__ == "__main__":
    hca.run()