# HalChat API module

API for HalChat in python

NEED INSTALL ANOTHER PYTHON LIBRARIES:
pip install pycryptodomex requests asyncio websockets