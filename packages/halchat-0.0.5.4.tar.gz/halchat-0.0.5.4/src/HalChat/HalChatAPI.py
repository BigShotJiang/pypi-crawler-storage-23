import aiohttp
import json
import logging

class HalChatAPI:
    """
    Класс для асинхронной работы с HTTP (REST) запросами к HalChat-серверу.
    """

    def __init__(self, code: str, base_url: str = 'https://halchat.halwarsing.net/api', logger:logging.Logger = None):
        self.code = code
        self.url = base_url
        self.logger=logger

    async def api_req(self, req: str, post_data: dict = None):
        """
        Асинхронный метод для выполнения API запроса через WS
        Возвращает распарсенный JSON или None при ошибке.
        """
        if post_data is None:
            post_data = {}
        post_data['code'] = self.code  # Добавляем code
        full_url = f"{self.url}?req={req}{get_data}"

        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(full_url, data=post_data) as response:
                    if response.status == 200:
                        # Пытаемся распарсить JSON
                        content_type = response.headers.get('Content-Type', '')
                        if 'application/json' in content_type:
                            o = await response.json()
                        else:
                            # Если не JSON, пробуем текст
                            text_data = await response.text()
                            self.logger.error(f"Error: Response is not JSON. Text: {text_data}")
                            return None

                        if o['errorCode'] > 0:
                            self.logger.error('Error api: ', o,req,get_data,full_url,post_data)
                        self.logger.debug('Successfully api request: ', req, get_data, post_data, o)
                        return o
                    else:
                        self.logger.error(f"HTTP Error code: {response.status}")
                        return None
            except aiohttp.ClientError as e:
                self.logger.error(f"ClientError in api_req: {e}")
                return None
            except Exception as e:
                self.logger.error(f"Unexpected error in api_req: {e}")
                return None