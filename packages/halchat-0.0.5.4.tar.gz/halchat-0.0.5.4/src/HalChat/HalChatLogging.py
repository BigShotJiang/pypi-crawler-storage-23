#Loggin HalChat Module

import logging
from pathlib import Path

def setup_logs(name:str,log_level:int=1,logfile:str|Path|None = None) -> logging.Logger:
    if isinstance(log_level,str):
        level=getattr(logging,log_level,logging.INFO)
    elif isinstance(log_level,int):
        if(log_level==0):
            level=logging.ERROR
        elif(log_level==1):
            level=logging.WARNING
        elif(log_level==2):
            level=logging.INFO
        elif(log_level>2):
            level=logging.DEBUG
    handlers=[logging.StreamHandler()]
    if logfile:
        handlers.append(logging.FileHandler(logfile,encoding="utf-8"))

    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
        force=True
    )

    return logging.getLogger(name)