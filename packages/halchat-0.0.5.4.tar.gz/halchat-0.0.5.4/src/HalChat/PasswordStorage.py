import keyring

class PasswordStorage:
    version="0.0.1"
    service_name="HalChatAPI"

    def __init__(self, botId:int|str):
        self.botId=botId

    def getUsernameByChatId(self, chatId:int|str) -> str:
        return str(self.botId)+":"+str(chatId)

    def hasPasswordChat(self, chatId:int|str) -> bool:
        return keyring.get_password(PasswordStorage.service_name, self.getUsernameByChatId(chatId))!=None

    def getPasswordChat(self, chatId:int|str) -> str:
        return keyring.get_password(PasswordStorage.service_name, self.getUsernameByChatId(chatId))

    def setPasswordChat(self, chatId:int|str, psw:str) -> None:
        return keyring.set_password(PasswordStorage.service_name, self.getUsernameByChatId(chatId), psw)

    def deletePasswordChat(self, chatId:int|str) -> None:
        return keyring.delete_password(PasswordStorage.service_name, self.getUsernameByChatId(chatId))