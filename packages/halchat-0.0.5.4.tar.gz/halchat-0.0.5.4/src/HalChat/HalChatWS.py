import json
import asyncio
import websockets
import uuid
import logging

class HalChatWS:
    """
    Класс для подключения и работы с HalChat по WebSockets.
    Внутри есть:
    - connect(): постоянная попытка подключиться
    - auth(): авторизация как бот
    - keep_alive(): периодическая отправка ping
    - listen(): чтение сообщений (их dispatch в handle_event)
    """

    def __init__(self, hc, code: str, ws_url: str = 'wss://halchat.halwarsing.net/ws/', logger:logging.Logger=None, onAuth=None):
        self.code = code
        self.ws_url = ws_url
        self.logger=logger
        self.hc=hc

        self.is_run = False
        self.is_auth = False
        self.onAuth=onAuth
        self.ws = None
        # callback или объект, который будет получать события
        self.event_handler = None

        # Хранение «висящих» запросов { request_id: Future }
        self.rpc_futures = {}

    async def connect(self):
        """
        Запуск бесконечного цикла для подключения к WS-серверу.
        При разрыве соединения пытается переподключиться.
        """
        self.is_run = True
        while self.is_run:
            try:
                self.ws = await websockets.connect(self.ws_url)
                await self.auth()
                self.logger.info("Connected to "+self.ws_url)

                await self.listen()
            except websockets.ConnectionClosed:
                self.logger.warning("Connection closed, reconnecting...")
                self.is_auth = False
                await asyncio.sleep(5)
            except Exception as e:
                self.logger.error(f"Error WebSocket: ",e)
                self.is_auth = False
                await asyncio.sleep(5)

    async def auth(self):
        """Шлёт action=authBot с токеном. Считывает ответ."""
        auth_payload = {"action": "authBot", "token": self.code}
        await self.ws.send(json.dumps(auth_payload))
        response = await self.ws.recv()
        self.is_auth=True
        if(not self.onAuth is None):
            self.onAuth()

    async def api_req(self,req,post_data):
        req_id=uuid.uuid4().hex

        loop=asyncio.get_running_loop()
        future=loop.create_future()
        self.rpc_futures[req_id]=future

        post_data['req']=req
        api_payload={"action":"api","data":post_data,'reqId':req_id}

        await self.ws.send(json.dumps(api_payload))

        response=await future
        if('errorCode' in response):
            if(response['errorCode']>0):
                self.logger.warning("Error API "+req+": "+str(response['error']+';'+str(response['errorCode'])))
            else:
                self.logger.debug("API "+req+": "+str(response))
        return response

    async def listen(self):
        """Основной цикл чтения входящих сообщений по WebSocket."""
        async for message in self.ws:
            if message == "pong":
                continue
            data = json.loads(message)
            asyncio.create_task(self.handle_event(data))

    async def handle_event(self, data: dict):
        """
        Здесь обрабатываем JSON-сообщение от WS-сервера.
        По умолчанию вызываем self.event_handler(data), если он задан.
        """
        if "action" in data and "reqId" in data and data['action']=="api":
            req_id=data['reqId']
            if req_id and req_id in self.rpc_futures:
                fut=self.rpc_futures[req_id]
                fut.set_result(data['result'])
                del self.rpc_futures[req_id]
            return
        if "rtype" in data:
            if data['rtype']=='sendPSW':
                await self.hc.psync.onReceivePassword(data)
            elif data['rtype']=='checkPSW':
                await self.hc.psync.onCheckPassword(data)
        if self.event_handler:
            await self.event_handler(data)

    async def close(self):
        """Остановка WS-сессии."""
        self.is_run = False
        self.is_auth = False
        if self.ws:
            await self.ws.close()