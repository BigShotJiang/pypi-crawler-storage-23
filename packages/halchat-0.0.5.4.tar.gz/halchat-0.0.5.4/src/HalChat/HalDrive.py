import aiohttp
import asyncio
import logging
import os

class HalDrive:
    def __init__(self, code: str, logger:logging.Logger=None):
        self.code = code
        self.logger=logger

    async def uploadFile(self, file:str, path:str="", publicType:int=1, systemType:int=0, replace: bool=False):
        url="https://haldrive.halwarsing.net/api"
        params = {
            "req":"uploadFile",
            "path": path,
            "publicType": publicType,
            "systemType": systemType,
            "replace":"true" if replace else "false"
        }

        async with aiohttp.ClientSession() as session:
            data=aiohttp.FormData()
            data.add_field('file',open(file,'rb'),filename=os.path.basename(file))
            data.add_field('code',self.code)
            async with session.post(url,params=params,data=data) as response:
                if response.status==200:
                    try:
                        result=await response.json()
                        return result
                    except Exception as e:
                        return {"errorCode":-2,"error": f"Status: {response.text()}"}
                else:
                    return {"errorCode":-2,"error": f"Status: {response.status}"}

    async def downloadFile(self, fileId:str, file:str):
        url = f"https://haldrive.halwarsing.net/file/{fileId}"
        payload = {"code": self.code}

        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=payload, allow_redirects=False) as response:
                if response.status in (301, 302, 303, 307, 308):
                    return {
                        "errorCode": -1,
                        "error": f"Скачивание отклонено. Переадресация на: {response.headers.get('Location')}"
                    }
                if response.status == 200:
                    try:
                        with open(file, 'wb') as f:
                            async for chunk in response.content.iter_chunked(1024 * 1024):
                                f.write(chunk)
                        return {"errorCode": 0, "error":"Успешно"}
                    except Exception as e:
                        return {"errorCode": -2, "error": str(e)}
                else:
                    return {"errorCode": -2, "error": f"Status: {response.status}"}