import json
import os
import logging
"""HalChatStorage - хранилище информации о чатах для дальнейшего использования ботом"""

class HalChatStorage:
    version = "0.0.1"

    def __init__(self, path:str, logger:logging.Logger, auto_save:bool=True):
        self.path=path
        self.data={"version":HalChatStorage.version,"chats":{}}
        self.logger=logger
        self.auto_save=auto_save

        if(os.path.isfile(path)):
            self.load()
        else:
            self.save()

    def save(self):
        with open(self.path,'w') as f:
            f.write(json.dumps(self.data))

    def load(self):
        with open(self.path,'r') as f:
            try:
                self.data=json.loads(f.read())
            except Exception as e:
                self.logger.error("Error load HalChatStorage",e)

    def addChat(self, chatId:int|str, chatInfo:dict) -> None:
        if(self.hasChat(chatId)):return
        self.data['chats'][str(chatId)]=chatInfo
        
        if self.auto_save:
            self.save()

    def updateChat(self, chatId:int|str, chatInfo:dict) -> None:
        if(self.hasChat(chatId)):
            self.data['chats'][str(chatId)]=chatInfo
        else:
            self.addChat(chatId, chatInfo)
        
        if self.auto_save:
            self.save()
    
    def hasChat(self, chatId:int|str) -> bool:
        return str(chatId) in self.data['chats']
    
    def deleteChat(self, chatId:int|str) -> None:
        try:
            del self.data['chats'][str(chatId)]
        except Exception as e:
            self.logger.error("Error deleteChat",e)

    def getChat(self, chatId:int|str) -> dict:
        try:
            return self.data['chats'][str(chatId)]
        except Exception as e:
            self.logger.error("Error getChat",e)

    def getChats(self) -> list:
        return list(self.data['chats'].keys())