import asyncio
import json
import time
import os
import base64
from pathlib import Path
import inspect

# Импортируем наши классы
from .HalChatEncryption import HalChatEncryption
from .HalChatWS import HalChatWS
from .HalChatLogging import setup_logs
from .PasswordStorage import PasswordStorage
from .PasswordSync import PasswordSync
from .HalChatStorage import HalChatStorage

class HalChat:
    """
    Главный класс, объединяющий:
    - шифрование (HalChatEncryption)
    - HTTP API (HalChatAPI)
    - WebSocket (HalChatWS)
    - события (onNewMessage и т.д.)
    """
    pstorage:PasswordStorage=None
    version = "0.0.5.4"

    def __init__(self,
                 code: str,
                 path: str = 'HalChat.json',
                 auto_join_chats: bool = True,
                 check_bots_messages: bool = False,
                 log_level: int = 1,
                 log_path:str|Path|None=None,
                 send_password: bool=True
                 ):
        self.logger=setup_logs("HalChat",log_level,log_path)

        self.code = code
        self.path = path
        self.auto_join_chats = auto_join_chats
        self.check_bots_messages = check_bots_messages
        self.log_level = log_level
        self.log_path = log_path
        self.send_password=send_password

        # Инициализация вспомогательных классов
        self.encryption = HalChatEncryption(logger=self.logger)
        self.api_net=HalChatWS(self, code, ws_url='wss://halwarsing.net/ws/', logger=self.logger, onAuth=lambda: self.onAuth())
        self.api = HalChatWS(self, code, logger=self.logger,onAuth=lambda: self.onAuth())
        self.api.event_handler=self.handle_ws_event

        #self.api = HalChatWS(code, self.logger)  # для WebSockets
        #self.api.event_handler = self.handle_ws_event    # все сообщения идут сюда
        self.hcstorage=HalChatStorage(path, self.logger)


        # События
        self.events = {
            #onNewMessage(msg:HalChatMessage,isExistedPassword:bool)
            'onNewMessage': [],
            #onNewChat(fromChat:int,fromId:int,inviteId:int)
            'onNewChat': [],
            #onReceivePassword(fromChat:int)
            'onReceivePassword': [],
            #onStart()
            'onStart': [],
            #onClickButton(fromChat:int,fromId:int,fromMsg:int,button:HalChatButton)
            'onClickButton': [],
            #onBotMessage(fromId:int,time:int,data:str)
            'onBotMessage': [],
            #onDeleteMessage(fromChat:int,fromId:int,fromMsg:int)
            'onDeleteMessage': [],
            #onEditMessage(fromChat:int,fromId:int,fromMsg:int)
            'onEditMessage': []
        }

        # Прочие поля
        self.is_run = False
        self.bot_info = None
        self.bot_id = None

        # Пытаемся узнать данные бота сразу (синхронно нельзя, делаем чутка позже асинхронно)
        # Можно сделать метод init_bot_info(), который вызовем в run().

    def onAuth(self):
        #if(self.api.is_auth and self.api_net.is_auth and self.is_run):
        #    asyncio.run(self.start())
        pass

    # ----------------------------------------------------------------
    #   Методы регистрации/вызова событий
    # ----------------------------------------------------------------
    def event(self, name: str):
        """Декоратор для подписки на события (onNewMessage, onReceivePassword, и т.д.)."""
        def decorator(func):
            self.event_add(name, func)
            return func
        return decorator

    def event_add(self, name: str, func):
        if name in self.events:
            self.events[name].append(func)
            return True
        return False

    def run_event(self, name: str, args: list):
        """Асинхронно запускаем все колбэки, подписанные на событие `name`."""
        if name in self.events:
            for ev in self.events[name]:
                if inspect.iscoroutinefunction(ev):
                    # обёртка для отлова ошибок
                    async def safe_ev(*a):
                        try:
                            await ev(*a)
                        except Exception as e:
                            self.logger.error(f"[run_event] Ошибка в событии {name}: {e}")
                    asyncio.create_task(safe_ev(*args))
                else:
                    # синхронные функции (если будут)
                    loop = asyncio.get_running_loop()
                    def safe_ev_sync(*a):
                        try:
                            ev(*a)
                        except Exception as e:
                            self.logger.error(f"[run_event] Ошибка в sync событии {name}: {e}")
                    loop.run_in_executor(None, safe_ev_sync, *args)

    # ----------------------------------------------------------------
    #   Методы запуска/остановки
    # ----------------------------------------------------------------
    def run(self):
        """Запуск асинхронного цикла."""
        asyncio.run(self.async_run())

    async def checkAllChats(self):
        data = await self.api.api_req("getListChats",{})
        if(data['errorCode']==0):
            for chat in data['chats']:
                self.hcstorage.addChat(chat['uid'],chat)

                chat=self.hcstorage.getChat(chat['uid'])
                if not 'isJoin' in chat.keys() or not chat['isJoin']:
                    if self.auto_join_chats:
                        await self.join_chat_by_id(chat['uid'])

    async def start(self):
        # Запрашиваем инфо о боте, чтобы получить self.bot_id
        await self.init_bot_info()

        # Вызываем onStart
        self.run_event('onStart', [])

        tasks=[]
        tasks.append(asyncio.create_task(self.checkAllChats()))
        tasks.append(asyncio.create_task(self.psync.checkAllAvailablePasswords()))
        tasks.append(asyncio.create_task(self.psync.requestMissingPasswords()))
        tasks.append(asyncio.create_task(self.psync.checkRequestsPasswords()))

        for task in tasks:
            await task

    async def async_run(self):
        """Асинхронная инициализация + запуск WebSocket."""
        self.is_run = True
        net_task=asyncio.create_task(self.api_net.connect())
        chat_task=asyncio.create_task(self.api.connect())

        await self._wait_for_both_auth()

        start_task=asyncio.create_task(self.start())

        await asyncio.gather(net_task,chat_task,start_task)

    async def _wait_for_both_auth(self):
        """
        Поллинг раз в 100 мс, пока оба WS не установят is_auth=True.
        Можно заменить на asyncio.Event, если хочется более «чистого» решения.
        """
        while not (self.api_net.is_auth and self.api.is_auth):
            await asyncio.sleep(0.1)

    async def init_bot_info(self):
        """
        Получаем информацию о боте через HTTP (getInfoUser).
        Сохраняем в self.bot_info и self.bot_id.
        """
        res = await self.api_net.api_req('getInfoUser', {})
        if res and res['errorCode'] == 0:
            self.bot_info = res
            self.bot_id = res['id']

            #init on getInfo
            self.pstorage=PasswordStorage(self.bot_id)
            self.psync=PasswordSync(self,self.logger,self.send_password)
        else:
            self.logger.error("Failed to get bot info. res=", res)

    async def close(self):
        """Остановка работы."""
        self.is_run = False
        await self.api.close()


    # ----------------------------------------------------------------
    #   Асинхронные обёртки для API методов
    # ----------------------------------------------------------------
    async def join_chat_by_invite_id(self, chatUID:int|str, invite_id: int):
        data=await self.api.api_req('joinChatByInviteId', {"inviteId":invite_id})
        if(data['errorCode']==0):
            self.logger.info(f"Joined chat with inviteId {invite_id}")
            chat=self.hcstorage.getChat(chatUID)
            chat['isJoin']=True
            self.hcstorage.updateChat(chatUID,chat)
    
    async def join_chat_by_id(self, chat_id: int|str):
        """
        Асинхронно присоединяемся к чату по его ID.
        """
        if not self.pstorage.hasPasswordChat(chat_id):
            self.logger.error(f"Chat with ID {chat_id} not found in password storage.")
            await self.psync.requestMissingPassword(chat_id)
            return
        
        data = await self.api.api_req('joinChat', {'chatId': chat_id, 'password': self.encryption.he.hh.Str2Hash(self.pstorage.getPasswordChat(chat_id),100,10)})
        if data['errorCode'] == 0:
            self.logger.info(f"Joined chat with ID {chat_id}")
            chat = self.hcstorage.getChat(chat_id)
            chat['isJoin'] = True
            self.hcstorage.updateChat(chat_id, chat)

    async def set_menu(self, chat_id: int, menu: list):
        await self.api.api_req('setMenu',
                                      post_data={'menu': json.dumps(menu),'chatId':chat_id})

    async def send_message(self,
                           chat_id: int,
                           message: str,
                           encrypt_id: str=None,
                           attachments: list=[],
                           answer_msg: int=-1,
                           comment_msg: int=-1,
                           sound_msg: str='-1',
                           buttons: list=None,
                           plugins=None
                           ):
        """
        Асинхронно отправляем сообщение в чат, шифруем, если есть пароль.
        """
        chat_id_s = str(chat_id)
        if self.pstorage.hasPasswordChat(chat_id_s):
            if not encrypt_id:
                # формируем encrypt_id
                encrypt_id = self.encryption.str2hash(
                    f"{time.time_ns()}:{chat_id}:"+str(self.hcstorage.getChat(chat_id)),
                    16, 16
                )
            # шифруем тело
            password = self.pstorage.getPasswordChat(chat_id_s) + encrypt_id
            message = self.encryption.encrypt_hex(message.encode('utf-8'), password, 10)
        else:
            if not encrypt_id:
                encrypt_id = ""
            #ERROR

        post_data = {
            'message': message,
            'attachments': json.dumps(attachments),
            'encryptId': encrypt_id,
            'soundMsg':sound_msg,
            'chatId':chat_id
        }
        if buttons is not None:
            post_data['buttons'] = json.dumps(buttons)
        if plugins is not None:
            post_data['plugins'] = json.dumps(plugins)

        if(answer_msg!=-1):
            post_data['answerMsg']=answer_msg
        if(comment_msg!=-1):
            post_data['commentMsg']=comment_msg

        return await self.api.api_req("sendMessage", post_data)

    async def delete_message(self, chat_id: int, msg_id: int):
        return await self.api.api_req('deleteMessage',{'chatId':chat_id,'msgId':msg_id})

    async def edit_message(self, chat_id: int, msg_id: int, message: str,
                           encrypt_id: str=None, attachments: list=[]):
        chat_id_s = str(chat_id)
        if self.pstorage.hasPasswordChat(chat_id_s):
            if not encrypt_id:
                encrypt_id = self.encryption.str2hash(
                    f"{time.time_ns()}:{chat_id}:"+str(self.hcstorage.getChat(chat_id)),
                    16, 16
                )
            password = self.pstorage.getPasswordChat(chat_id_s) + encrypt_id
            message = self.encryption.encrypt_hex(message.encode('utf-8'), password, 10)
        else:
            if not encrypt_id:
                encrypt_id = ""
            #error

        post_data = {
            'message': message,
            'attachments': json.dumps(attachments),
            'encryptId': encrypt_id,
            'chatId':chat_id,
            'msgId':msg_id
        }
        return await self.api.api_req('editMessage',
                                      post_data)

    async def get_message(self, chat_id: int, msg_id: int):
        out = await self.api.api_req('getMessage',{'chatId':chat_id,'msgId':msg_id})
        if out and out['errorCode'] == 0:
            msg = out['msg']
            chat_id_s = str(msg['fromChat'])
            if self.pstorage.hasPasswordChat(chat_id_s):
                password = self.pstorage.getPasswordChat(chat_id_s) + msg['encryptId']
                msg['message'] = self.encryption.decrypt_hex(msg['message'], password, 10)
                if msg['answerMsg'] != '-1':
                    msg['answerMsgText'] = self.encryption.decrypt_hex(
                        msg['answerMsgText'],
                        self.pstorage.getPasswordChat(chat_id_s) + msg['answerMsgEncryptId'],
                        10
                    )
            return msg
        return None

    async def send_bot_message(self, to_id: int, data: str):
        return await self.api.api_req('sendBotMessage', {'data': data,'toId':to_id})

    async def addNewChat(self, chatId:int|str) -> None:
        if(self.hcstorage.hasChat(chatId)):return
        data = await self.api.api_req("getChat",{"chatId":chatId})
        await self.join_chat_by_id(chatId)
        if(data['errorCode']==0):
            self.hcstorage.addChat(chatId,data['data'])
            await self.psync.requestMissingPassword(chatId)

    # ----------------------------------------------------------------
    #   Обработка событий от WebSockets
    # ----------------------------------------------------------------
    async def handle_ws_event(self, data: dict):
        """
        Получаем сырые данные из WebSocket (HalChatWS).
        Анализируем rtype, type, вызываем соответствующие события
        и/или декодируем сообщения.
        """
        rtype = data.get("rtype")

        if('fromChat' in data and not self.hcstorage.hasChat(data['fromChat'])):
            await self.addNewChat(data['fromChat'])


        if 'fromChat' in data and not self.pstorage.hasPasswordChat(data['fromChat']):
            asyncio.create_task(self.psync.requestMissingPassword(data['fromChat']))

        if rtype == "msg":
            # Новое сообщение
            msg = data
            if(msg['fromId']!=self.bot_id):
                chat_id = str(msg['fromChat'])
                if self.pstorage.hasPasswordChat(chat_id):
                    password = self.pstorage.getPasswordChat(chat_id) + msg['encryptId']
                    msg['message'] = self.encryption.decrypt_hex(msg['message'], password, 10)
                    if msg['answerMsg'] != '-1':
                        msg['answerMsgText'] = self.encryption.decrypt_hex(
                            msg['answerMsgText'],
                            self.pstorage.getPasswordChat(chat_id) + msg['answerMsgEncryptId'],
                            10
                        )
                # Вызываем onNewMessage
                self.run_event("onNewMessage", [msg, self.pstorage.hasPasswordChat(chat_id)])

        elif rtype == "act":
            v = data
            act_type = v['type']
            # 0 - deleteMsg, 1 - editMsg, 2 - password, 3 - newChat, 6 - clickButton
            if act_type == 0:
                self.run_event('onDeleteMessage', [v['fromChat'], v['fromId'], v['fromMsg']])
            elif act_type == 1:
                self.run_event('onEditMessage', [v['fromChat'], v['fromId'], v['fromMsg']])
            elif act_type == 3:
                # Новый чат
                # v['uid'] - inviteId
                # if v['toId'] == self.bot_id: ...
                if self.auto_join_chats:
                    asyncio.create_task(self.join_chat_by_invite_id(v['fromChat'],v['uid']))

                self.run_event('onNewChat', [v['fromChat'], v['fromId'], v['uid']])

            elif act_type == 6:
                # Клик по кнопке
                self.run_event('onClickButton', [v['fromChat'], v['fromId'], v['fromMsg'], v['data']])

        elif rtype == "botmsg":
            # Сообщение для бота
            if self.check_bots_messages:
                self.run_event('onBotMessage', [data['fromId'], data['time'], data['data']])

        # rtype == "pong" обрабатывается внутри ws_client.listen()