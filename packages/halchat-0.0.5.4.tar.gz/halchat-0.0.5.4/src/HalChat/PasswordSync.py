import asyncio
from .PasswordStorage import PasswordStorage
from Cryptodome.Cipher import PKCS1_OAEP
from Cryptodome.PublicKey import RSA
from Cryptodome.Hash import SHA256
import base64
import logging

class PasswordSync:
    version="0.0.1"

    def __init__(self,hc,logger:logging.Logger,send_psw=True):
        self.hc=hc
        self.logger=logger
        self.send_psw=send_psw
        self.chat_passwords={}

    #SEND PASSWORDS

    async def sendPasswordChat(self, chatUID:int|str, id_req: int, publicKey: PKCS1_OAEP.PKCS1OAEP_Cipher) -> bool:
        if(not self.send_psw):
            return False

        if(chatUID>0 and id_req>0 and publicKey!=None and self.hc.pstorage.hasPasswordChat(chatUID)):
            password=self.hc.pstorage.getPasswordChat(chatUID)
            encPSW=self.hc.encryption.encrypt_rsa(publicKey,password)
            encPSW=base64.b64encode(encPSW).decode('utf-8')

            data=await self.hc.api.api_req("sendPasswordChatAuto",{"uid":id_req,"password":encPSW})
            if(data['errorCode']==0):
                self.logger.debug("Successfully sendPasswordChatAuto in ChatUID:"+str(chatUID))
            else:
                self.logger.warning("Failed to sendPasswordChatAuto: "+data['error']+';'+data['errorCode'])

            return True
        return False

    async def checkToSendRequestsPassword(self, chatUID:int|str) -> None:
        data=await self.hc.api.api_req("getRequestsPasswordChat",{"chatId":chatUID})
        if(data['errorCode']==0):
            requests=data['requests']
            tasks=[]

            for i in range(0,len(requests)):
                req=requests[i]
                publicKey=self.hc.encryption.import_key(req['publicKey'])
                tasks.append(asyncio.create_task(self.sendPasswordChat(chatUID,req['uid'],publicKey)))

            for task in tasks:
                await task

    async def checkAllAvailablePasswords(self) -> None:
        if(not self.send_psw):return
        for chatId in self.hc.hcstorage.getChats():
            if self.hc.pstorage.hasPasswordChat(chatId) and not self.hc.pstorage.hasPasswordChat(chatId):
                await self.checkToSendRequestsPassword(chatId)

    #REQUEST PASSWORDS

    async def requestMissingPassword(self, chatUID:int|str) -> None:
        if(self.hc.pstorage.hasPasswordChat(chatUID)):return

        key,encryptor,public_key=self.hc.encryption.generate_rsa_key_bytes()

        data = await self.hc.api.api_req("requestPasswordAuto",{"chatId":chatUID,"publicKey":self.hc.encryption.bytes_to_hex(public_key)})
        if data['errorCode']==0:
            self.logger.info("Successful request missing password chatUID:"+str(chatUID))
            self.chat_passwords[str(chatUID)]=encryptor

    async def requestMissingPasswords(self) -> None:
        availableChats=self.hc.hcstorage.getChats()
        for key in availableChats:
            if(key.isdigit() and not self.hc.pstorage.hasPasswordChat(key) and not key in self.chat_passwords):
                await self.requestMissingPassword(key)

    #Check sent requests

    #decrypt received password
    async def decryptRequestPassword(self, chatUID:int|str, psw:str) -> bool:
        if (self.hc.pstorage.hasPasswordChat(chatUID) or not str(chatUID) in self.chat_passwords):
            return False

        try:
            cipher_bytes = base64.b64decode(psw)

            rsa=self.chat_passwords[str(chatUID)]

            decryptedPassword=rsa.decrypt(cipher_bytes).decode('utf-8')

            self.logger.debug("Successfully decrypted received password chatUID:"+str(chatUID))
            self.hc.pstorage.setPasswordChat(chatUID,decryptedPassword)
            del self.chat_passwords[str(chatUID)]
            self.hc.run_event("onReceivePassword",[int(chatUID)])
        except Exception as e:
            del self.chat_passwords[str(chatUID)]
            self.logger.error("Error decryptRequestPassword",e)
            return False

        return True

    async def checkRequestPassword(self, chatUID:int|str) -> None:
        if(self.hc.pstorage.hasPasswordChat(chatUID) or not str(chatUID) in self.chat_passwords):
            return

        data = await self.hc.api.api_req("getRequestPasswordAuto",{"chatId":chatUID})
        if(data['errorCode']==0):
            self.logger.debug("Successfully received password chatUID:"+str(chatUID))
            await self.decryptRequestPassword(chatUID,data['psw'])
        elif data['errorCode']==5:
            self.logger.warning("Password didn't receive chatUID:"+str(chatUID))

    #check all requests from this bot
    async def checkRequestsPasswords(self) -> None:
        availableChats=self.hc.hcstorage.getChats()
        for key in availableChats:
            if(key.isdigit() and not self.hc.pstorage.hasPasswordChat(key) and key in self.chat_passwords):
                await self.checkRequestPassword(int(key))

    #Event on receive password in ws
    async def onReceivePassword(self, data: dict) -> None:
        self.logger.info("onReceivePassword: "+str(data))

        if(not self.hc.hcstorage.hasChat(data['chatId'])):
            await self.hc.addNewChat(data['chatId'])

        b=await self.decryptRequestPassword(data['chatId'],data['psw'])
        if(b):
            await self.hc.api.api_req("getRequestPasswordAuto",{"chatId":data['chatId']})

    #Event on check password in ws (to send available password)
    async def onCheckPassword(self, data: dict) -> None:
        self.logger.info("onCheckPassword: "+str(data))
        key=self.hc.encryption.import_key(data['publicKey'])
        await self.sendPasswordChat(data['chatId'],data['reqId'],key)
