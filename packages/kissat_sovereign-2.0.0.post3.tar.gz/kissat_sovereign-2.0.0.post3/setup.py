from setuptools import setup

setup(
    name="kissat-sovereign",
    version="2.0.0.post3", # Bump version for the CLI update
    author="Americo Simoes",
    py_modules=["kissat_apex"],
    data_files=[('lib', ['libkissat.so'])],
    include_package_data=True,
    # This creates the "bash" command
    entry_points={
        'console_scripts': [
            'kissat-sovereign=kissat_apex:solve_sovereign_cli',
        ],
    },
)
