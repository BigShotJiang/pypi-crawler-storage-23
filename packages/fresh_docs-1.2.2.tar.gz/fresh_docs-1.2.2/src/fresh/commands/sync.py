"""Sync command - download entire documentation for offline use."""

from __future__ import annotations

import json
import re
import shutil
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse, quote

import typer
from rich.progress import BarColumn, Progress, TextColumn, TimeRemainingColumn

from ..config import resolve_alias
from ..console import print_summary, reset_console, set_verbose
from ..scraper import crawler, filter as filter_module, sitemap
from ..scraper.http import fetch_binary_aware, is_binary_url, is_allowed_by_robots, validate_url
from ..ui import is_interactive, spinner

app = typer.Typer(help="Download entire documentation for offline use.")

# Default sync directory
DEFAULT_SYNC_DIR = Path.home() / ".fresh" / "docs"


def _get_sync_dir(url: str, output_dir: Path | None) -> Path:
    """Get the sync directory for a URL."""
    if output_dir:
        return output_dir

    # Create directory based on domain
    parsed = urlparse(url)
    domain = parsed.netloc.replace(":", "_").replace(".", "_")
    return DEFAULT_SYNC_DIR / domain


def _save_metadata(sync_dir: Path, base_url: str, page_count: int) -> None:
    """Save sync metadata."""
    metadata = {
        "site": base_url,
        "last_sync": datetime.now().isoformat(),
        "page_count": page_count,
    }
    metadata_file = sync_dir / "_sync.json"
    metadata_file.write_text(json.dumps(metadata, indent=2))


def _fetch_page_for_sync(page_url: str) -> str | None:
    """
    Fetch a page for sync, skipping binary content.

    Args:
        page_url: The URL to fetch

    Returns:
        HTML content, None if binary/failed
    """
    # Use binary-aware fetch
    return fetch_binary_aware(page_url, skip_binary=True)


def _save_page(page_url: str, pages_dir: Path) -> bool | None:
    """
    Fetch and save a single page to the sync directory.

    Args:
        page_url: The URL of the page to save
        pages_dir: The directory to save pages to

    Returns:
        True if page was saved successfully, False if failed, None if skipped (binary)
    """
    # Check for binary URLs - skip but don't count as failure
    if is_binary_url(page_url):
        return None

    response = _fetch_page_for_sync(page_url)
    if not response or not isinstance(response, str):
        return False

    parsed = urlparse(page_url)
    path = parsed.path.lstrip("/")
    if not path or path.endswith("/"):
        path = path + "index.html"

    # Sanitize filename
    filename = quote(path, safe="")
    if len(filename) > 200:
        filename = filename[:200]

    page_file = pages_dir / filename
    page_file.parent.mkdir(parents=True, exist_ok=True)
    page_file.write_text(response, encoding="utf-8")
    return True


@app.command(name="sync")
def sync(
    url: str = typer.Argument(..., help="The URL or alias of the documentation website"),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Target directory for synced docs"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Use verbose output"),
    max_pages: int = typer.Option(100, "--max-pages", help="Maximum number of pages to sync"),
    depth: int = typer.Option(3, "--depth", "-d", help="Maximum crawl depth"),
    force: bool = typer.Option(False, "--force", "-f", help="Force re-sync (delete existing files first)"),
    pattern: str | None = typer.Option(None, "--pattern", "-p", help="Filter paths matching pattern"),
) -> None:
    """Download entire documentation for offline use."""
    # Initialize console with verbose mode
    set_verbose(verbose)
    reset_console()

    # Resolve alias to URL
    resolved_url = resolve_alias(url)

    if verbose and resolved_url != url:
        typer.echo(f"Resolved alias '{url}' to {resolved_url}")

    # Validate URL
    if not validate_url(resolved_url):
        typer.echo(f"Error: Invalid URL: {resolved_url}", err=True)
        raise typer.Exit(1)

    # Get sync directory
    sync_dir = _get_sync_dir(resolved_url, output_dir)

    # Handle --force option
    if force and sync_dir.exists():
        if verbose:
            typer.echo("Removing existing sync directory...")
        shutil.rmtree(sync_dir)

    sync_dir.mkdir(parents=True, exist_ok=True)

    typer.echo(f"Syncing to: {sync_dir}")

    # Discover pages
    discovered_urls: set[str] = set()

    # Extract domain from sitemap for consistent robots.txt checking
    sitemap_domain: str | None = None

    if verbose:
        typer.echo("Discovering pages...")
        sitemap_url = sitemap.discover_sitemap(resolved_url)
    elif is_interactive():
        with spinner("Discovering pages..."):
            sitemap_url = sitemap.discover_sitemap(resolved_url)
    else:
        sitemap_url = sitemap.discover_sitemap(resolved_url)

    if sitemap_url:
        if verbose:
            typer.echo(f"Found sitemap at {sitemap_url}")
        # Extract domain from sitemap URL for consistent robots.txt checks
        sitemap_parsed = urlparse(sitemap_url)
        sitemap_domain = sitemap_parsed.netloc
        if verbose:
            typer.echo(f"Using domain for robots.txt checks: {sitemap_domain}")

        # Fetch sitemap content
        if is_interactive() and not verbose:
            with spinner("Fetching sitemap..."):
                xml_content = sitemap.fetch_with_retry(sitemap_url)
        else:
            xml_content = sitemap.fetch_with_retry(sitemap_url)

        if xml_content and isinstance(xml_content, str):
            urls = sitemap.parse_sitemap(xml_content)
            if urls:
                filtered = [u for u in urls if filter_module.is_relevant_url(u)]
                discovered_urls.update(filtered)

    # Fallback to crawler if no sitemap
    if not discovered_urls:
        if verbose:
            typer.echo("No sitemap found, using crawler...")
            discovered_urls = crawler.crawl(resolved_url, max_pages=max_pages, max_depth=depth)
        elif is_interactive():
            with spinner(f"Crawling pages (max {max_pages})..."):
                discovered_urls = crawler.crawl(resolved_url, max_pages=max_pages, max_depth=depth)
        else:
            discovered_urls = crawler.crawl(resolved_url, max_pages=max_pages, max_depth=depth)

    # Apply pattern filter if specified
    if pattern:
        pattern_re = re.compile(pattern.replace("*", ".*"))
        discovered_urls = {u for u in discovered_urls if pattern_re.search(u)}

    # Limit pages
    urls_to_sync: list[str] = list(discovered_urls)[:max_pages]

    typer.echo(f"Found {len(urls_to_sync)} pages to sync")

    # Create pages directory
    pages_dir = sync_dir / "pages"
    pages_dir.mkdir(exist_ok=True)

    # Fetch each page
    success_count = 0
    fail_count = 0
    skipped_robots = 0
    skipped_binary = 0
    total_pages = len(urls_to_sync)

    # Process pages based on output mode
    if verbose:
        # Verbose mode: show detailed output for each page
        for i, page_url in enumerate(urls_to_sync):
            typer.echo(f"[{i + 1}/{total_pages}] Syncing: {page_url}")

            # Check robots.txt before fetching (use sitemap domain if available)
            if not is_allowed_by_robots(page_url, domain=sitemap_domain):
                typer.echo(f"  Skipped (robots.txt): {page_url}")
                skipped_robots += 1
                continue

            # Fetch and save the page
            try:
                result = _save_page(page_url, pages_dir)
                if result is True:
                    success_count += 1
                elif result is None:
                    # Binary file - skipped
                    skipped_binary += 1
                    typer.echo(f"  Skipped (binary): {page_url}")
                else:
                    fail_count += 1
                    typer.echo(f"  Failed (empty response): {page_url}")
            except Exception as e:
                fail_count += 1
                typer.echo(f"  Error: {page_url} - {e}")

    elif is_interactive():
        # Interactive mode: show progress bar
        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeRemainingColumn(),
        ) as progress:
            task = progress.add_task(
                f"Syncing pages ({success_count}/{total_pages})...",
                total=total_pages,
            )

            for page_url in urls_to_sync:
                # Check robots.txt before fetching (use sitemap domain for consistency)
                if not is_allowed_by_robots(page_url, domain=sitemap_domain):
                    skipped_robots += 1
                    progress.advance(task)
                    continue

                # Fetch and save the page
                try:
                    result = _save_page(page_url, pages_dir)
                    if result is True:
                        success_count += 1
                    elif result is None:
                        # Binary file - skipped
                        skipped_binary += 1
                    else:
                        fail_count += 1
                except Exception:
                    fail_count += 1

                progress.update(
                    task,
                    description=f"Syncing pages ({success_count}/{total_pages})...",
                )
                progress.advance(task)

    else:
        # Non-interactive mode: simple progress without spinner
        for page_url in urls_to_sync:
            # Check robots.txt before fetching (use sitemap domain for consistency)
            if not is_allowed_by_robots(page_url, domain=sitemap_domain):
                skipped_robots += 1
                continue

            # Fetch and save the page
            try:
                result = _save_page(page_url, pages_dir)
                if result is True:
                    success_count += 1
                elif result is None:
                    # Binary file - skipped
                    skipped_binary += 1
                else:
                    fail_count += 1
            except Exception:
                fail_count += 1

    # Save metadata
    _save_metadata(sync_dir, resolved_url, success_count)

    # Summary
    typer.echo("\nSync complete!")
    typer.echo(f"  Success: {success_count} pages")
    if skipped_binary > 0:
        typer.echo(f"  Skipped (binary): {skipped_binary} pages")
    if skipped_robots > 0:
        typer.echo(f"  Skipped (robots.txt): {skipped_robots} pages")
    if fail_count > 0:
        typer.echo(f"  Failed: {fail_count} pages")
    typer.echo(f"  Saved to: {sync_dir}")

    # Print error/warning summary
    print_summary()
