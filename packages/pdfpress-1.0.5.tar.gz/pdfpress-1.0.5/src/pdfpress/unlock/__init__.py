"""PDF unlock functionality."""

from pdfpress.unlock.unlocker import UnlockResult, is_encrypted, unlock_pdf

__all__ = ["UnlockResult", "is_encrypted", "unlock_pdf"]
