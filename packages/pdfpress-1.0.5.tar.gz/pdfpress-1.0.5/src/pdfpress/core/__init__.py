"""Core compression functionality."""

from pdfpress.core.compressor import CompressionOutcome, PDFCompressor

__all__ = ["PDFCompressor", "CompressionOutcome"]
