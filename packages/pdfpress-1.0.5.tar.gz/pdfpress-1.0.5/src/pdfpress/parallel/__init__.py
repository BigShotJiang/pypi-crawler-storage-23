"""Parallel processing functionality."""

from pdfpress.parallel.executor import ParallelCompressor

__all__ = ["ParallelCompressor"]
