"""A command line task manager."""
