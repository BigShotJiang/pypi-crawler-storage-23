from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from opentelemetry.trace import get_current_span
from uuid import uuid4

from core_alo.keycloak_auth import get_payload, get_current_user, get_user_info
from .config import settings
from .utils.logging_config import set_username, set_request_id, clear_context


async def _user_auth_middleware(request: Request, call_next):
    """Extract user from token and store in request.state (ONE Keycloak call)."""
    request.state.user = None
    if settings.AUTH_TYPE == "none":
        return await call_next(request)

    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return await call_next(request)
    token = auth_header.replace("Bearer ", "")

    request_id = request.headers.get('X-Request-ID', str(uuid4()))
    set_request_id(request_id)


    try:
        payload = get_payload(token)
        user = get_current_user(user_info=get_user_info(payload))
        if user.username: set_username(str(user.username))
        request.state.user = user
        response = await call_next(request)
        return response
    except HTTPException as e:
        # HTTPException raised in middleware needs to be converted to JSONResponse
        return JSONResponse(
            status_code=e.status_code,
            content={"detail": e.detail},
            headers=e.headers,
        )
    finally:
        # Clear logging context vars after request
        clear_context()


async def _add_user_to_trace_middleware(request: Request, call_next):
    """Middleware to add user information to the trace."""

    user = getattr(request.state, "user", None)
    if not user:
        return await call_next(request)

    span = get_current_span()
    if not span:
        return await call_next(request)

    span.set_attribute("user.email", user.email or "")

    return await call_next(request)
