import time
import functools
import logging
from typing import Callable, Any, TypeVar, cast

logger = logging.getLogger("exec_time")
F = TypeVar("F", bound=Callable[..., Any])


def sync_exec_time(func: F) -> F:
    """
    Decorator to log the execution time of a synchronous method.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start_time = time.perf_counter()
        try:
            return func(*args, **kwargs)
        finally:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            logger.debug(f"[exec_time] '{func.__qualname__}' executed in {elapsed_time:.3f} seconds")

    return cast(F, wrapper)


def async_exec_time(func: F) -> F:
    """
    Decorator to log the execution time of an asynchronous method.
    """

    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        start_time = time.perf_counter()
        try:
            return await func(*args, **kwargs)
        finally:
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            logger.debug(f"[exec_time] '{func.__qualname__}' executed in {elapsed_time:.3f} seconds")

    return cast(F, wrapper)
