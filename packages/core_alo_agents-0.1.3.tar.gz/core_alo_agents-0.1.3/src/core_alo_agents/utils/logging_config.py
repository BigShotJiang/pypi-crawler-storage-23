import logging
import sys
from contextvars import ContextVar
from ..config import settings

# Create context variables
request_id_var: ContextVar[str] = ContextVar('request_id', default='')
username_var: ContextVar[str] = ContextVar('username', default='')


class SingleLineFilter(logging.Filter):
    def filter(self, record):
        if record.msg and isinstance(record.msg, str):
            record.msg = record.msg.replace('\n', '\\n').replace('\r', '\\r')
        if record.args:
            new_args = []
            for arg in record.args if isinstance(record.args, tuple) else [record.args]:
                if isinstance(arg, str):
                    new_args.append(arg.replace('\n', '\\n').replace('\r', '\\r'))
                else:
                    new_args.append(arg)
            record.args = tuple(new_args) if isinstance(record.args, tuple) else new_args[0]

        return True


class AloDefaultFormatter(logging.Formatter):
    base_format = "[%(levelname)s]"
    date_format = "%Y-%m-%d %H:%M:%S"

    def format(self, record):
        # Get context variables
        request_id = request_id_var.get()
        username = username_var.get()

        # Build context string
        context_parts = []
        if request_id:
            context_parts.append(f"request_id: {request_id}")
        if username:
            context_parts.append(f"username: {username}")
        context_str = f" [{' , '.join(context_parts)}]" if context_parts else ""

        # Print logger name for debug mode
        if settings.LOGGING_LEVEL.upper() == "DEBUG":
            log_fmt = f"[%(levelname)s:{record.name}] %(message)s {context_str}"
        else:
            log_fmt = f"[%(levelname)s] %(message)s {context_str}"

        formatter = logging.Formatter(log_fmt, datefmt=self.date_format)
        output = formatter.format(record)
        return output.replace('\n', '\\n').replace('\r', '\\r')


def setup_logging():
    # 1. Check for DEBUG override
    env_level = settings.LOGGING_LEVEL.upper()
    numeric_level = getattr(logging, env_level, logging.INFO)

    # 2. Configure the Root Logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)
    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    # 3. Create Console Handlers
    # stdout handler for INFO and below — Cloud Run treats stdout as INFO
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(AloDefaultFormatter())
    stdout_handler.addFilter(SingleLineFilter())
    stdout_handler.addFilter(lambda record: record.levelno < logging.WARNING)
    root_logger.addHandler(stdout_handler)

    # stderr handler for WARNING and above — Cloud Run treats stderr as ERROR
    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setFormatter(AloDefaultFormatter())
    stderr_handler.addFilter(SingleLineFilter())
    stderr_handler.setLevel(logging.WARNING)
    root_logger.addHandler(stderr_handler)

    # 4. Handle muting packages loggers (skipped if LOGGING_LEVEL=DEBUG)
    if env_level != "DEBUG":
        for logger_name in settings.MUTED_LOGGERS:
            logger = logging.getLogger(logger_name)
            logger.setLevel(logging.WARNING)
            logger.propagate = False
    else:
        print("DEBUG mode detected: All logs unmuted.")


# Helper functions to set context
def set_request_id(request_id: str):
    request_id_var.set(request_id)


def set_username(user_id: str):
    username_var.set(user_id)


def clear_context():
    request_id_var.set('')
    username_var.set('')
