import asyncio
from dataclasses import dataclass
from typing import List, AsyncGenerator

from pydantic import BaseModel
from pydantic_ai import RunContext
from pydantic_ai.models.openai import OpenAIResponsesModel, OpenAIResponsesModelSettings
from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
from pydantic_ai.models.anthropic import AnthropicModel, AnthropicModelSettings
import uvicorn
from dotenv import load_dotenv

from ..features.agents.a2a_types import AgentCard, AgentProvider, AgentSkill
from ..features.agents.agents import Agent, AgentDeps
from ..features.agents.utils import get_agent_host_port


# First load the .env file, then create the settings instance
load_dotenv()
from ..config import Settings

settings = Settings()
settings.AGENT_URL = "http://0.0.0.0:8012"


SYSTEM_PROMPT = """
# Persona:
You are a helpful assistant that can answer questions and help with tasks.
"""

MCP_SERVERS = []


TEXT_TITLE = "THE OLD LIGHTHOUSE KEEPER"
TEXT = "The old lighthouse keeper found a bottle washed ashore. Inside, a child's drawing of a rainbow and the words 'Thank you for keeping us safe.' He'd worked alone for thirty years, wondering if anyone noticed his light cutting through storms. That night, he polished the lens extra bright, tears blurring his vision. The beam swept across dark waters, a silent promise that someone always cared, someone was always watching, guiding lost souls home through the endless night."


@dataclass
class BraveHWAgentDeps(AgentDeps):
    pass


class TextSchema(BaseModel):
    text: str


class ComplexSchema(BaseModel):
    title: TextSchema
    content: TextSchema
    tags: List[str]
    summary: str | None = None
    index: int


async def direct_text_from_tool(ctx: RunContext[BraveHWAgentDeps]) -> str:
    return TEXT


async def stream_text_from_tool(
    ctx: RunContext[BraveHWAgentDeps],
) -> AsyncGenerator[str, None]:
    for char in TEXT:
        yield char
        await asyncio.sleep(0.02)


async def stream_text_dict_from_tool(
    ctx: RunContext[BraveHWAgentDeps],
) -> AsyncGenerator[dict, None]:
    for char in TEXT:
        yield {"text": char}
        await asyncio.sleep(0.02)


async def stream_text_schema_from_tool(
    ctx: RunContext[BraveHWAgentDeps],
) -> AsyncGenerator[TextSchema, None]:
    for char in TEXT:
        yield TextSchema(text=char)
        await asyncio.sleep(0.02)


async def stream_complex_schema_from_tool(
    ctx: RunContext[BraveHWAgentDeps],
) -> AsyncGenerator[ComplexSchema, None]:
    for i, char in enumerate(TEXT):
        yield ComplexSchema(
            title=TextSchema(text=TEXT_TITLE[i] if i < len(TEXT_TITLE) else ""),
            content=TextSchema(text=char),
            tags=[f"test {i}"] if i < 10 else [],
            summary=char,
            index=i,
        )
        await asyncio.sleep(0.02)


async def stream_number_from_tool(
    ctx: RunContext[BraveHWAgentDeps],
) -> AsyncGenerator[int, None]:
    for i in range(10):
        yield i
        await asyncio.sleep(0.02)


agent = Agent(
    agent_card=AgentCard(
        name="Tool Streaming test agent",
        description="A simple agent that can stream text from a tool.",
        url=settings.AGENT_URL,
        provider=AgentProvider(organization="OpenAI"),
        skills=[
            AgentSkill(
                id="stream_text_from_tool",
                name="Stream Text from Tool",
                description="A simple tool that streams text from a tool",
            ),
        ],
    ),
    pydanticai_args={
        # -- Example: OpenAI no reasoning
        # "model": "openai:gpt-4o",
        # -- Example: Openai with reasoning
        # "model": OpenAIResponsesModel("o4-mini"),
        # "model_settings": OpenAIResponsesModelSettings(
        #     openai_reasoning_effort="medium",
        #     openai_reasoning_summary="detailed",
        # ),
        # -- Example: Google Gemini with reasoning
        "model": GoogleModel("gemini-2.5-flash"),
        "model_settings": GoogleModelSettings(
            google_thinking_config={"include_thoughts": True}
        ),
        # -- Example: Anthropic with reasoning
        # "model": AnthropicModel("claude-sonnet-4-20250514"),
        # "model_settings": AnthropicModelSettings(
        #     anthropic_thinking={"type": "enabled", "budget_tokens": 1024},
        # ),
        "instructions": SYSTEM_PROMPT,
        "deps_type": BraveHWAgentDeps,
        "toolsets": MCP_SERVERS,
        "tools": [
            direct_text_from_tool,
            stream_text_from_tool,
            stream_text_dict_from_tool,
            stream_text_schema_from_tool,
            stream_complex_schema_from_tool,
            stream_number_from_tool,
        ],
    },
    settings=settings,
)


agent_app = agent.get_a2a_app()

if __name__ == "__main__":
    host, port = get_agent_host_port(settings.AGENT_URL)
    uvicorn.run(agent_app, host=host, port=port)
