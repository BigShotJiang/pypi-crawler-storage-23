from dataclasses import dataclass

from pydantic_ai import WebSearchTool, UrlContextTool
from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
import uvicorn
from dotenv import load_dotenv

from ..features.agents.agents import Agent, AgentDeps
from ..features.agents.a2a_types import AgentCard, AgentProvider, AgentSkill
from ..features.agents.utils import get_agent_host_port


# First load the .env file, then create the settings instance
load_dotenv()
from ..config import Settings

settings = Settings()
settings.AGENT_URL = "http://0.0.0.0:8015"
settings.PROJECT_NAME = "Native Google Search Agent"
settings.PROJECT_TECHNICAL_NAME = "native_google_search_agent"


SYSTEM_PROMPT = """
# Persona:
You are a helpful assistant that can answer questions and help with tasks.
"""

MCP_SERVERS = []


@dataclass
class NativeGoogleSearchAgentDeps(AgentDeps):
    pass


agent = Agent(
    agent_card=AgentCard(
        name="Native Google Search agent",
        technicalName=settings.PROJECT_TECHNICAL_NAME,
        description="A simple agent that can answer questions and help with tasks using Google Search.",
        url=settings.AGENT_URL,
        provider=AgentProvider(organization="OpenAI"),
        skills=[
            AgentSkill(
                id="google_search",
                name="Google Search",
                description="A simple tool that returns a string",
            ),
        ],
    ),
    pydanticai_args={
        "model": GoogleModel("gemini-2.5-flash"),
        "model_settings": GoogleModelSettings(
            google_thinking_config={"include_thoughts": True}
        ),
        "instructions": SYSTEM_PROMPT,
        "deps_type": NativeGoogleSearchAgentDeps,
        "toolsets": MCP_SERVERS,
        "tools": [],
        # https://ai.pydantic.dev/builtin-tools/
        # NOTE: Gemini doesnt support both builtin_tools and tools at the same time
        # NOTE: no way to extract grounding right now (for grounding use tools.google_search_with_sources)
        #   https://github.com/pydantic/pydantic-ai/pull/2102#issuecomment-3271595199
        "builtin_tools": [UrlContextTool(), WebSearchTool(search_context_size="high")],
    },
    settings=settings,
)


agent_app = agent.get_a2a_app(enable_telemetry=True)

if __name__ == "__main__":
    host, port = get_agent_host_port(settings.AGENT_URL)
    uvicorn.run(agent_app, host=host, port=port)
