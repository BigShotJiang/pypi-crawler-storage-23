from typing import Callable
from fastapi import Request, Security, HTTPException, status

from core_alo.schemas import UserPublic
from core_alo.constants import ErrorMsgs
from core_alo.keycloak_auth import oauth2_scheme, get_current_user_no_auth

from .config import Settings


# Overwriting with logic to get the user from middleware and be able to track the user in Logfire Tracing
def get_current_user(
    request: Request,
    _token: str = Security(
        oauth2_scheme
    ),  # _token is for the Swagger schema and Authorize button, the user is parsed in middleware
) -> UserPublic:
    """Get user from request.state (already extracted by middleware)."""
    user = getattr(request.state, "user", None)

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=ErrorMsgs.INVALID_AUTH_CREDENTIALS,
            headers={"WWW-Authenticate": "Bearer"},
        )

    return user


def get_auth_deps(settings: Settings) -> Callable:
    if settings.AUTH_TYPE == "oidc":
        return get_current_user
    else:
        return get_current_user_no_auth
