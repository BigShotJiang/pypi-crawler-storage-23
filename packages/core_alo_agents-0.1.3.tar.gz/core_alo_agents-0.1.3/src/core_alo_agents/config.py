from core_alo.config import Settings as CoreAloSettings
from pathlib import Path


class Settings(CoreAloSettings):
    PROJECT_NAME: str = "Alomana Agent"
    PROJECT_TECHNICAL_NAME: str = "alomana_agent"
    AGENT_URL: str = "http://0.0.0.0:8000"
    ROOT_PATH: Path = Path(__file__).parent / "features"
    PERMISSIONS_CONFIGURABLE: bool = False
    DEFAULT_PERMISSIONS_PATH: Path | None = None

    BACKEND_HOST: str = "http://localhost:8082"

    # Google
    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_CLIENT_SECRET: str = ""
    GC_BUCKET_NAME: str = ""

    # E2B
    E2B_API_KEY: str = ""
    E2B_TIMEOUT_MINUTES: int = 60

    @property
    def E2B_TIMEOUT_SECONDS(self) -> int:
        return self.E2B_TIMEOUT_MINUTES * 60

    DATA_SOURCES_ENCRYPTION_KEY: str = ""

    # Integrations
    SLACK_BOT_TOKEN: str = ""
    SLACK_SIGNING_SECRET: str = ""

    LOGGING_LEVEL: str = "INFO"
    MUTED_LOGGERS: list[str] = [
        "google_genai",
        "httpx",
        "hypercorn",
        "pydantic_ai",
        "google.api_core",
        "google.auth",
        "google.auth.transport",
        "googleapiclient.discovery_cache",
        "google_auth_httplib2",
        "urllib3",
        "httpx",
        "httpcore",
        "e2b.api",
        "opentelemetry",
    ]



settings = Settings()
parent_settings = settings

