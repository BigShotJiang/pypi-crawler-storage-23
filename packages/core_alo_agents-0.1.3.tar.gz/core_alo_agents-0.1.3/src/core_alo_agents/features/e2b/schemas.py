from typing import Any, Optional
from datetime import datetime

from pydantic import BaseModel, Field
from core_alo.schemas import BaseSchema, TimeAuditSchemaMixin


class SandboxStatusData(BaseModel):
    sandbox_id: Optional[str] = None
    url: Optional[str] = None
    files_tracked: Optional[list[str]] = None


class BaseSandboxAction(BaseModel):
    success: bool
    error: Optional[str] = None
    message: Optional[str] = None


class SandboxStatus(BaseModel):
    active: bool
    healthy: bool
    sandboxData: Optional[SandboxStatusData] = None
    message: str


class SandboxLogs(BaseSandboxAction):
    logs: dict[int, Any]


class SandboxFiles(BaseSandboxAction):
    files: Optional[dict] = None
    structure: Optional[str] = None
    file_count: Optional[int] = None
    raw_output: Optional[str] = None


class RunSandboxCommandPayload(BaseModel):
    command: str


class RunSandboxCommand(BaseSandboxAction):
    output: Optional[str] = None


class InstallPackages(BaseSandboxAction):
    packages_installed: list | None = None
    packages_already_installed: list | None = None
    packages_failed: list | None = None
    logs: str | None = None


# =============================================================================
# Sandbox Schemas
# =============================================================================


class SandboxBase(BaseModel):
    remote_id: Optional[str] = Field(None, max_length=255)
    url: Optional[str] = Field(None, max_length=255)
    injected_skills: Optional[list[str]] = Field(None, max_length=255)


class SandboxCreate(SandboxBase):
    pass


class SandboxUpdate(SandboxBase):
    remote_id: Optional[str] = Field(None, max_length=255)
    url: Optional[str] = Field(None, max_length=255)
    last_timeout_check: Optional[datetime] = None


class SandboxPublic(BaseSchema, SandboxBase, TimeAuditSchemaMixin):
    id: int
    user_email: str
