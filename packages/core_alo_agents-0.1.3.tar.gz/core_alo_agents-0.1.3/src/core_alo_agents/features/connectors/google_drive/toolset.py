import logging
from enum import StrEnum
from io import StringIO
import pandas as pd
from pydantic_ai import FunctionToolset, RunContext
from googleapiclient.discovery import build

from ..constants import ConnectorProvider, ConnectorError
from ..utils import get_connector_credentials
from ...agents.types import ToolReturn


class GoogleMimeType(StrEnum):
    GOOGLE_APPS_DOCUMENT = "application/vnd.google-apps.document"
    GOOGLE_APPS_SPREADSHEET = "application/vnd.google-apps.spreadsheet"
    GOOGLE_APPS_PRESENTATION = "application/vnd.google-apps.presentation"
    GOOGLE_APPS = "application/vnd.google-apps"


# EXPORT_MIME_TYPES = {mime_type.value for mime_type in GoogleMimeType}


GOOGLE_MIME_TYPE_TO_EXPORT = {
    GoogleMimeType.GOOGLE_APPS_DOCUMENT: "text/plain",
    GoogleMimeType.GOOGLE_APPS_SPREADSHEET: "text/csv",
    GoogleMimeType.GOOGLE_APPS_PRESENTATION: "text/plain",
    # GoogleMimeType.GOOGLE_APPS: "application/pdf",
}


async def gd_list_files(
    ctx: RunContext,
    api_query: str = "",
    page_size: int = 10,
    order_by: str | None = None,
    page_token: str | None = None,
) -> ToolReturn:
    """
    List files from Google Drive owned by the authenticated user.

    Args:
        api_query: The Google Drive API query string (e.g., "name contains 'report'", "fullText contains 'budget'"). By default filters for files owned by the authenticated user.
        page_size: Number of results to return (default: 10)
        order_by: How to sort results. Valid values: createdTime, folder, modifiedByMeTime, modifiedTime, name, quotaBytesUsed, recency, sharedWithMeTime, starred, viewedByMeTime. Add " desc" for descending order (e.g., "modifiedTime desc")
        page_token: For paginating through results
    """
    credentials = await get_connector_credentials(
        jwt=ctx.deps.request.headers.get("Authorization"),
        client_id=ctx.deps.settings.GOOGLE_CLIENT_ID,
        client_secret=ctx.deps.settings.GOOGLE_CLIENT_SECRET,
        connector_provider=ConnectorProvider.GOOGLE_DRIVE,
    )
    if not credentials:
        return ToolReturn(
            error=ConnectorError.FAILED_TO_ACCESS.value.format(
                connector_provider="Google Drive"
            )
        )
    service = build("drive", "v3", credentials=credentials)

    query = "'me' in owners"
    if api_query:
        query = f"({api_query}) and {query}"

    list_params = {
        "q": query,
        "pageSize": page_size,
        "fields": "nextPageToken, files(id, name, mimeType, createdTime, modifiedTime, webViewLink, owners, size)",
    }

    if order_by:
        list_params["orderBy"] = order_by
    if page_token:
        list_params["pageToken"] = page_token

    results = service.files().list(**list_params).execute()
    files = results.get("files", [])

    return ToolReturn(
        data={
            "files": files,
            "nextPageToken": results.get("nextPageToken"),
        }
    )


async def gd_get_file(
    ctx: RunContext,
    document_id: str,
):
    """
    Get a specific file from Google Drive including its content.

    Args:
        document_id: The ID of the document to retrieve.
    """
    credentials = await get_connector_credentials(
        jwt=ctx.deps.request.headers.get("Authorization"),
        client_id=ctx.deps.settings.GOOGLE_CLIENT_ID,
        client_secret=ctx.deps.settings.GOOGLE_CLIENT_SECRET,
        connector_provider=ConnectorProvider.GOOGLE_DRIVE,
    )
    if not credentials:
        return ToolReturn(
            error=ConnectorError.FAILED_TO_ACCESS.value.format(
                connector_provider="Google Drive"
            )
        )
    service = build("drive", "v3", credentials=credentials)

    file = (
        service.files()
        .get(
            fileId=document_id,
            fields="id, name, mimeType, createdTime, modifiedTime, webViewLink, owners, size, description, parents",
        )
        .execute()
    )

    mime_type = file.get("mimeType", "")
    content = None

    if mime_type in GOOGLE_MIME_TYPE_TO_EXPORT:
        try:
            content = (
                service.files()
                .export(
                    fileId=document_id, mimeType=GOOGLE_MIME_TYPE_TO_EXPORT[mime_type]
                )
                .execute()
            )

            if isinstance(content, bytes):
                content = content.decode()

            if mime_type == GoogleMimeType.GOOGLE_APPS_SPREADSHEET:
                df = pd.read_csv(StringIO(content))
                content = df.to_markdown(index=False)

        except Exception as e:
            logging.error(f"Error getting content of the file: {e}")
            content = "Unsupported file type."
    else:
        content = "Unsupported file type."

    file["content"] = content
    return ToolReturn(data=file)


google_drive_toolset = FunctionToolset(tools=[gd_list_files, gd_get_file])
