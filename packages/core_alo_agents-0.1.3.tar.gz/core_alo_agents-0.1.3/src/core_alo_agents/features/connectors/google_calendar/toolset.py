from datetime import datetime
from pydantic_ai import FunctionToolset, RunContext
from googleapiclient.discovery import build

from ..constants import ConnectorProvider, ConnectorError

from ..utils import get_connector_credentials
from ...agents.types import ToolReturn


async def gc_list_events(
    ctx: RunContext,
    calendar_id: str = "primary",
    max_results: int = 25,
    page_token: str | None = None,
    query: str | None = None,
    #  RFC3339 timestamp with timezone
    time_min: datetime | None = None,
    time_max: datetime | None = None,
    # IANA Time Zone Database name (e.g., "Europe/Rome", "America/New_York")
    time_zone: str | None = "Europe/Rome",
) -> ToolReturn:
    """
    List events from a Google Calendar.

    Args:
        calendar_id: The ID of the calendar to list events from.
        max_results: The maximum number of events to return.
        page_token: The token for the next page of events.
        query: The query to search for events.
        time_min: The minimum time for the events. RFC3339 timestamp with timezone
        time_max: The maximum time for the events. RFC3339 timestamp with timezone
        time_zone: The time zone for the events. IANA Time Zone Database name (e.g., "Europe/Rome", "America/New_York")
    """
    credentials = await get_connector_credentials(
        jwt=ctx.deps.request.headers.get("Authorization"),
        client_id=ctx.deps.settings.GOOGLE_CLIENT_ID,
        client_secret=ctx.deps.settings.GOOGLE_CLIENT_SECRET,
        connector_provider=ConnectorProvider.GOOGLE_CALENDAR,
    )
    if not credentials:
        return ToolReturn(
            error=ConnectorError.FAILED_TO_ACCESS.value.format(
                connector_provider="Google Calendar"
            )
        )
    service = build("calendar", "v3", credentials=credentials)

    # Build the parameters for the API call
    list_params = {
        "calendarId": calendar_id,
        "maxResults": max_results,
        "singleEvents": True,
        "orderBy": "startTime",
    }

    # Add optional filters
    if page_token:
        list_params["pageToken"] = page_token
    if query:
        list_params["q"] = query
    if time_min:
        list_params["timeMin"] = time_min.isoformat()
    if time_max:
        list_params["timeMax"] = time_max.isoformat()
    if time_zone:
        list_params["timeZone"] = time_zone

    events_result = service.events().list(**list_params).execute()

    events = events_result.get("items", [])
    return ToolReturn(data=events)


async def gc_get_event(
    ctx: RunContext,
    event_id: str,
    calendar_id: str = "primary",
):
    """
    Get a specific event from a Google Calendar.

    Args:
        event_id: The ID of the event to retrieve.
        calendar_id: The ID of the calendar containing the event.
    """
    credentials = await get_connector_credentials(
        jwt=ctx.deps.request.headers.get("Authorization"),
        client_id=ctx.deps.settings.GOOGLE_CLIENT_ID,
        client_secret=ctx.deps.settings.GOOGLE_CLIENT_SECRET,
        connector_provider=ConnectorProvider.GOOGLE_CALENDAR,
    )
    if not credentials:
        return ToolReturn(
            error=ConnectorError.FAILED_TO_ACCESS.value.format(
                connector_provider="Google Calendar"
            )
        )
    service = build("calendar", "v3", credentials=credentials)

    event = service.events().get(calendarId=calendar_id, eventId=event_id).execute()

    return ToolReturn(data=event)


google_calendar_toolset = FunctionToolset(tools=[gc_list_events, gc_get_event])
