import httpx
from google.oauth2.credentials import Credentials

from .schemas import ConnectorCredentials
from .constants import ConnectorProvider
from ...config import settings


async def get_connector_credentials(
    jwt: str,
    client_id: str,
    client_secret: str,
    connector_provider: ConnectorProvider,
) -> Credentials | None:
    connector_credentials_response = httpx.get(
        f"{settings.BACKEND_HOST}/api/v1/connectors/{connector_provider}/credential/",
        headers={"Authorization": jwt},
    )
    connector_credentials_data = connector_credentials_response.json()
    if not connector_credentials_data:
        return

    connector_credentials = ConnectorCredentials.model_validate(
        connector_credentials_data
    )

    credentials = Credentials(
        token=connector_credentials.access_token,
        refresh_token=connector_credentials.refresh_token,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=client_id,
        client_secret=client_secret,
        scopes=connector_credentials.scopes,
    )
    return credentials
