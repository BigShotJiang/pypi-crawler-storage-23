from enum import StrEnum


class ConnectorProvider(StrEnum):
    GOOGLE_CALENDAR = "google_calendar"
    GOOGLE_DRIVE = "google_drive"


class ConnectorError(StrEnum):
    FAILED_TO_ACCESS = "Failed to access {connector_provider}. Please try again later or try to re-activate the connector."
