from typing import Any
from pydantic_ai import RunContext
from ...features.agents.types import ToolReturn
from ...features.agents.agents import AgentDeps
from ...features.data_sources.services.query_execution_service import (
    QueryExecutionService,
)
from ...features.data_sources.services.crypto_service import CryptoService
from ...features.data_sources.schemas import DataSourceConnection
from ...features.data_sources.query_validator import QueryValidator
from ...features.e2b.services import E2BSandboxService
from ...features.e2b.constants import SANDBOX_APP_PATH


# TODO: for each of the connectors the results are different, so move to specfic connector file
#    for example for google sheets, we can save the files directly
CONVERSION_TO_DF_CODE = """
import pandas as pd
import json
import os
from decimal import Decimal
import datetime
import zoneinfo
from uuid import UUID

# Load the query results
query_results = {query_result_repr}

# Convert to DataFrame
if isinstance(query_results, dict) and 'data' in query_results:
    data = query_results['data']
elif isinstance(query_results, list):
    data = query_results
else:
    data = [query_results]

# Create DataFrame temporarily to save as CSV
if data and isinstance(data[0], (list, tuple)):
    # List of tuples/lists - assume no column names
    df = pd.DataFrame(data)
elif data and isinstance(data[0], dict):
    # List of dicts - use keys as column names
    df = pd.DataFrame(data)
else:
    df = pd.DataFrame(data)

# Save DataFrame to CSV file
csv_path = "{data_folder}/{csv_filename}"
df.to_csv(csv_path, index=False)

print("Query results saved to:", csv_path)
print("Shape:", df.shape)
print("Columns:", df.columns.tolist())
print("Row count:", len(df))
print("First few rows:")
print(df.head())
"""


async def query_data_source(
    ctx: RunContext[AgentDeps], query: dict[str, Any], save_results: bool = True
) -> ToolReturn:
    """
    Query a data source connection to retrieve data and optionally save as CSV file.

    TIP: Use get_data_source_metadata first to discover available tables and columns
    before writing SQL queries. This ensures you use correct table and column names.

    This tool works with ANY type of data source connector (SQL databases, spreadsheets, APIs, etc.).
    The connector-specific instructions are defined in "Data source context" session of the prompt.

    Common query formats by connector type:
    - SQL databases (PostgreSQL, Snowflake, MySQL): {"sql": "SELECT * FROM table_name"}
    - Google Sheets: {"spreadsheet_name": "My Sheet", "sheet_name": "Sheet1", "range": "A1:D10"}
    - Other connectors: Format varies - instructions will be provided automatically

    Args:
        query: Query payload in connector-specific format
        save_results: If True (default), saves results as CSV for further analysis.
                     Set to False for simple queries like "SELECT 1", connectivity tests,
                     or when you only need to see the immediate results without further analysis.

    Returns:
        Query results, and CSV file path if save_results=True
    """
    data_connection = (ctx.deps.payload.message.metadata or {}).get("data_connection")
    if not data_connection:
        return ToolReturn(error="Data connection not found")
    data_connection = DataSourceConnection.model_validate(data_connection)

    crypto_service = CryptoService()
    query_service = QueryExecutionService(
        ctx.deps.db,
        crypto_service=crypto_service,
    )
    user = ctx.deps.user

    try:
        # Get semantic layer for table access validation
        semantic_layer = getattr(data_connection, "semantic_layer", None)
        QueryValidator.validate_query_with_semantic_layer(query, semantic_layer)
    except Exception as e:
        return ToolReturn(error=f"Error validating query: {e.detail}")

    try:
        query_result = await query_service.execute_query(
            connection=data_connection,
            query=query,
            user_id=getattr(user, "id", None),
            # timeout=payload.timeout_seconds,
        )
    except Exception as e:
        return ToolReturn(error=f"Error executing query: {e.detail}")

    if not save_results:
        return ToolReturn(
            message="Query executed successfully (results not saved)",
            data=query_result,
        )

    sandbox_service = E2BSandboxService(
        db=ctx.deps.db, user=user, request=ctx.deps.request
    )
    sandbox_db, sandbox = await sandbox_service.create_sandbox(
        context_id=None if user else ctx.deps.payload.message.contextId
    )

    # Generate a unique filename based on tool call ID
    csv_filename = f"query_{ctx.tool_call_id.replace('-', '_')}.csv"
    data_folder = f"{SANDBOX_APP_PATH}/data_sources"
    csv_file_path = f"{data_folder}/{csv_filename}"
    await sandbox.run_code(f"import os; os.makedirs('{data_folder}', exist_ok=True)")

    conversion_code = CONVERSION_TO_DF_CODE.format(
        query_result_repr=repr(query_result),
        csv_filename=csv_filename,
        data_folder=data_folder,
    )
    conversion_response = await sandbox.run_code(conversion_code)
    if conversion_response.error:
        return ToolReturn(
            error=f"Error saving query results to CSV: {conversion_response.error}"
        )

    # Extract info from the output
    output_logs = (
        "\n".join(conversion_response.logs.stdout)
        if conversion_response.logs.stdout
        else ""
    )

    # TOOD: perhaps show preview of query_result (max 20/50rows) or sth; but decide if needed
    return ToolReturn(
        message=f"Query executed successfully. Results saved to CSV file at {csv_file_path}",
        data={
            "csv_file_path": csv_file_path,
            "csv_filename": csv_filename,
            "data_folder": data_folder,
            "preview": output_logs,
        },
    )


async def get_data_source_metadata(ctx: RunContext[AgentDeps]) -> ToolReturn:
    data_connection = (ctx.deps.payload.message.metadata or {}).get("data_connection")
    user = getattr(ctx.deps, "user", None)
    user_id = user.id if user else None

    if not data_connection:
        return ToolReturn(error="Data connection not found")
    data_connection = DataSourceConnection.model_validate(data_connection)

    crypto_service = CryptoService()
    query_service = QueryExecutionService(
        ctx.deps.db,
        crypto_service=crypto_service,
    )

    try:
        data = await query_service.get_metadata(
            connection=data_connection,
            user_id=user_id,
            # timeout=data_connection.timeout_seconds,
        )
    except Exception as e:
        return ToolReturn(error=f"Error retrieving data source metadata: {e.detail}")

    return ToolReturn(message="Data source metadata retrieved successfully", data=data)
