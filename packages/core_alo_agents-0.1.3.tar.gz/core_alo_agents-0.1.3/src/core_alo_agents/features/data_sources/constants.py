from enum import StrEnum


class ConnectorType(StrEnum):
    DATABASE = "database"
    FILE = "file"
    FOLDER = "folder"
