from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import snowflake.connector as sc
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from snowflake.connector import SnowflakeConnection

from .base import BaseConnector
from .connector_factory import register_connector
from ..exceptions import (
    ExternalServiceAuthException,
    ExternalServiceException,
    QueryExecutionException,
)
from ..query_validator import QueryValidator
from ..schemas import (
    AuthStrategy,
    ColumnMetadata,
    CredentialDetails,
    DataSourceMetadata,
    DocumentationLink,
    FieldDefinition,
    TableMetadata,
)
from ..constants import ConnectorType

logger = logging.getLogger(__name__)


class _SnowflakeConnection:
    _BASE_PARAMS = frozenset(
        {
            "account",
            "user",
            "database",
            "schema",
            "warehouse",
            "role",
            "auth_type",
            "session_parameters",
            "login_timeout",
            "network_timeout",
            "socket_timeout",
            "ocsp_fail_open",
            "ocsp_response_cache_filename",
        }
    )

    _AUTH_PARAMS: dict[str, frozenset[str]] = {
        "basic": frozenset({"password"}),
        "token": frozenset({"token"}),
        "key-pair": frozenset(
            {
                "private_key_file_pwd",
                "private_key",
            }
        ),
        "externalbrowser": frozenset(),
        "workload_identity": frozenset(
            {
                "workload_identity_provider",
                "token",
            }
        ),
    }

    _AUTH_TYPE_TO_AUTHENTICATOR: dict[str, str | None] = {
        "basic": "snowflake",
        "token": "PROGRAMMATIC_ACCESS_TOKEN",
        "key-pair": None,  # Key-pair auth doesn't need authenticator, just private_key param
        "externalbrowser": "externalbrowser",
        "workload_identity": "WORKLOAD_IDENTITY",
    }

    def __init__(self, connection_data: dict[str, Any]) -> None:
        self.connection_data = connection_data.copy()
        self.connection: SnowflakeConnection | None = None
        self.is_connected: bool = False

    def _process_private_key(
        self, key_data: bytes, password: str | None = None
    ) -> bytes:
        """Convert PEM private key to DER format if needed.

        Args:
            key_data: Private key data (PEM or DER format)
            password: Optional password for encrypted keys

        Returns:
            DER-encoded private key bytes
        """
        try:
            # Try to load as PEM
            p_key = serialization.load_pem_private_key(
                key_data,
                password=password.encode() if password else None,
                backend=default_backend(),
            )
            # Convert to DER
            return p_key.private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
        except ValueError:
            # If it fails, it might already be DER or invalid
            return key_data

    def _resolve_auth_type(self) -> str:
        auth_type = self.connection_data.get("auth_type")
        if isinstance(auth_type, str) and auth_type.strip():
            return auth_type.strip()

        raise ValueError("auth_type is required for Snowflake connections")

    def _resolve_authenticator(self, auth_type: str) -> str | None:
        return self._AUTH_TYPE_TO_AUTHENTICATOR.get(auth_type)

    def _build_config(self) -> dict[str, Any]:
        auth_type = self._resolve_auth_type()
        authenticator = self._resolve_authenticator(auth_type)

        allowed_params = set(self._BASE_PARAMS)
        auth_params = self._AUTH_PARAMS.get(auth_type)
        if auth_params is None:
            # Unknown auth type - pass through but remove auth_type (not a Snowflake param)
            config = {k: v for k, v in self.connection_data.items() if k != "auth_type"}
            if authenticator:
                config["authenticator"] = authenticator
            return config

        allowed_params.update(auth_params)
        # Filter to allowed params, excluding auth_type (not a Snowflake param)
        config = {
            key: value
            for key, value in self.connection_data.items()
            if key in allowed_params and key != "auth_type"
        }

        # Set authenticator only if specified (key-pair auth uses None)
        if authenticator:
            config["authenticator"] = authenticator

        # Process private_key if provided (convert PEM to DER)
        if "private_key" in config:
            if isinstance(config["private_key"], bytes):
                pwd = self.connection_data.get("private_key_file_pwd")
                config["private_key"] = self._process_private_key(
                    config["private_key"], pwd
                )
            elif isinstance(config["private_key"], str):
                # If it's a string, convert to bytes first
                pwd = self.connection_data.get("private_key_file_pwd")
                config["private_key"] = self._process_private_key(
                    config["private_key"].encode(), pwd
                )

        return config

    def connect(self) -> SnowflakeConnection:
        if self.is_connected and self.connection is not None:
            return self.connection
        config = self._build_config()
        self.connection = sc.connect(**config)
        self.is_connected = True
        return self.connection

    def disconnect(self) -> None:
        if not self.is_connected or self.connection is None:
            return
        self.connection.close()
        self.connection = None
        self.is_connected = False

    def check_connection(self) -> bool:
        try:
            connection = self.connect()
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
            return True
        except sc.errors.Error:
            self.is_connected = False
            self.connection = None
            return False

    def execute_query(
        self,
        query: str,
        params: dict[str, Any] | tuple[Any, ...] | None = None,
        retry_count: int = 0,
        retry_delay: float = 1.0,
    ) -> list[tuple[Any, ...]]:
        """Execute a SQL query with optional retry logic.

        Args:
            query: The SQL query to execute
            params: Optional parameters to bind to the query
            retry_count: Number of retry attempts on failure (default: 0)
            retry_delay: Delay in seconds between retries (default: 1.0)

        Returns:
            List of result rows as tuples

        Raises:
            snowflake.connector.errors.Error: If the query fails after all retry attempts
        """
        last_error: Exception | None = None
        attempts = retry_count + 1  # Total attempts = initial + retries

        for attempt in range(attempts):
            try:
                connection = self.connect()
                with connection.cursor() as cursor:
                    if params is not None:
                        cursor.execute(query, params)
                    else:
                        cursor.execute(query)
                    return cursor.fetchall()
            except sc.errors.Error as e:
                last_error = e
                # Don't retry on the last attempt
                if attempt < attempts - 1:
                    time.sleep(retry_delay)
                    # Reset connection state for retry
                    self.is_connected = False
                    self.connection = None

        # All attempts failed, raise the last error
        raise last_error  # type: ignore[misc]


@register_connector("snowflake")
class SnowflakeConnector(BaseConnector):

    connector_type: ConnectorType = ConnectorType.DATABASE
    name: str = "Snowflake"
    description: str = (
        "Snowflake data warehouse connector supporting multiple authentication methods"
    )
    version: str = "0.1.0"
    logo_url: str | None = None

    def __init__(self):
        super().__init__()
        self._connection_impl: _SnowflakeConnection | None = None

    instructions_prompt: str = """You are querying a Snowflake data warehouse. Key points:
- Use standard SQL syntax (Snowflake supports ANSI SQL)
- Use three-part identifiers: DATABASE.SCHEMA.TABLE when needed
- Snowflake is case-insensitive by default, but use uppercase for system objects
- Use double quotes for case-sensitive identifiers: "MyTable"
- Common functions: CURRENT_TIMESTAMP(), CURRENT_USER(), CURRENT_ROLE()
- Window functions are fully supported
- Use LIMIT instead of TOP
- Date functions: DATEADD(), DATEDIFF(), DATE_TRUNC()
- String functions: CONCAT(), SPLIT(), SUBSTRING()
- Aggregate functions: COUNT(), SUM(), AVG(), MIN(), MAX()
- Use %(param_name)s for named parameters in queries
- Use %s for positional parameters
- Always specify warehouse, database, schema, and role in connection if available
- Be aware of timezone settings (default is UTC)
- Use INFORMATION_SCHEMA views for metadata queries"""

    credential_details = CredentialDetails(
        auth_strategies=[
            AuthStrategy(
                type="basic",
                label="Username and Password",
                description="Authenticate using username and password",
                fields=[
                    FieldDefinition(
                        name="password",
                        label="Password",
                        type="password",
                        required=True,
                        is_sensitive=True,
                        description="Your Snowflake account password",
                    ),
                ],
            ),
            AuthStrategy(
                type="token",
                label="Programmatic Access Token (PAT)",
                description="Authenticate using a Programmatic Access Token. More secure than password authentication.",
                fields=[
                    FieldDefinition(
                        name="token",
                        label="Access Token",
                        type="password",
                        required=True,
                        is_sensitive=True,
                        description="Your Snowflake Programmatic Access Token",
                    ),
                ],
            ),
            AuthStrategy(
                type="key-pair",
                label="Key Pair (JWT)",
                description="Authenticate using RSA key pair. Paste your private key in PEM format.",
                fields=[
                    FieldDefinition(
                        name="private_key",
                        label="Private Key",
                        type="text",
                        required=True,
                        is_sensitive=True,
                        description="Private key content in PEM format (-----BEGIN PRIVATE KEY-----...)",
                    ),
                    FieldDefinition(
                        name="private_key_file_pwd",
                        label="Private Key Password",
                        type="password",
                        required=False,
                        is_sensitive=True,
                        description="Password for encrypted private key (if applicable)",
                    ),
                ],
            ),
        ],
        common_fields=[
            FieldDefinition(
                name="account",
                label="Account",
                type="text",
                required=True,
                is_sensitive=False,
                description="Your Snowflake account identifier (e.g., 'xy12345' or 'xy12345.us-east-1')",
                placeholder="xy12345",
            ),
            FieldDefinition(
                name="user",
                label="Username",
                type="text",
                required=True,
                is_sensitive=False,
                description="Your Snowflake username",
            ),
            FieldDefinition(
                name="database",
                label="Database",
                type="text",
                required=False,
                is_sensitive=False,
                description="Default database to use",
            ),
            FieldDefinition(
                name="schema",
                label="Schema",
                type="text",
                required=False,
                is_sensitive=False,
                description="Default schema to use",
            ),
            FieldDefinition(
                name="warehouse",
                label="Warehouse",
                type="text",
                required=False,
                is_sensitive=False,
                description="Snowflake warehouse to use for queries",
            ),
            FieldDefinition(
                name="role",
                label="Role",
                type="text",
                required=False,
                is_sensitive=False,
                description="Snowflake role to use",
            ),
        ],
        documentation_links=[
            DocumentationLink(
                label="Snowflake Documentation",
                url="https://docs.snowflake.com/",
            ),
            DocumentationLink(
                label="Python Connector Guide",
                url="https://docs.snowflake.com/en/user-guide/python-connector",
            ),
        ],
    )

    async def connect(self, credentials: dict[str, Any]) -> None:
        try:
            if self._connection_impl and self._connection_impl.is_connected:
                await asyncio.to_thread(self._connection_impl.disconnect)
            self._connection_impl = await asyncio.to_thread(
                _SnowflakeConnection, credentials
            )
            await asyncio.to_thread(self._connection_impl.connect)
            self.connection = self._connection_impl
        except sc.errors.OperationalError as e:
            logger.exception("Snowflake connection failed")
            raise ExternalServiceException("Snowflake", operation="connecting") from e
        except sc.errors.DatabaseError as e:
            logger.exception("Snowflake authentication failed")
            raise ExternalServiceAuthException("Snowflake") from e
        except Exception as e:
            logger.exception("Unexpected error connecting to Snowflake")
            raise ExternalServiceException("Snowflake", operation="connecting") from e

    async def execute_query(self, query: dict[str, Any]) -> Any:
        if not self.connection or not isinstance(self.connection, _SnowflakeConnection):
            raise QueryExecutionException("Not connected to Snowflake")

        sql = QueryValidator.extract_sql(query)

        if not sql:
            raise QueryExecutionException(
                f"Query must contain one of: {', '.join(QueryValidator.SQL_KEYS)}"
            )

        # Get configured database from connection
        configured_database = self.connection.connection_data.get("database")

        # Validate database scope (reject cross-database queries)
        if configured_database:
            QueryValidator.validate_database_scope(
                sql,
                allowed_database=configured_database,
                enforce=True,
            )

        params = query.get("params")

        try:
            # Prepend USE DATABASE to ensure session context
            if configured_database:
                db_escaped = configured_database.replace('"', '""')
                use_db_sql = f'USE DATABASE "{db_escaped}"'
                await asyncio.to_thread(self.connection.execute_query, use_db_sql, None)

            results = await asyncio.to_thread(
                self.connection.execute_query, sql, params
            )
            return {"success": True, "data": results}
        except sc.errors.ProgrammingError as e:
            logger.exception("Snowflake query execution failed")
            raise QueryExecutionException(f"Query execution failed: {str(e)}") from e
        except sc.errors.OperationalError as e:
            logger.exception("Snowflake connection error during query")
            raise ExternalServiceException(
                "Snowflake", operation="executing query"
            ) from e
        except Exception as e:
            logger.exception("Unexpected error executing Snowflake query")
            raise QueryExecutionException(f"Query execution failed: {str(e)}") from e

    async def test_connection(self, credentials: dict[str, Any]) -> bool:
        try:
            connection_impl = await asyncio.to_thread(_SnowflakeConnection, credentials)
            result = await asyncio.to_thread(connection_impl.check_connection)
            await asyncio.to_thread(connection_impl.disconnect)
            return result
        except Exception:
            return False

    async def get_metadata(self) -> DataSourceMetadata:
        if not self.connection or not isinstance(self.connection, _SnowflakeConnection):
            raise QueryExecutionException("Not connected to Snowflake")

        try:
            database = self.connection.connection_data.get("database")
            schema = self.connection.connection_data.get("schema")

            tables_query = """
                SELECT 
                    TABLE_CATALOG,
                    TABLE_SCHEMA,
                    TABLE_NAME,
                    TABLE_TYPE
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_TYPE IN ('BASE TABLE', 'VIEW')
            """
            if database and isinstance(database, str) and database.strip():
                db_escaped = database.replace("'", "''")
                tables_query += f" AND TABLE_CATALOG = '{db_escaped}'"
            if schema and isinstance(schema, str) and schema.strip():
                schema_escaped = schema.replace("'", "''")
                tables_query += f" AND TABLE_SCHEMA = '{schema_escaped}'"
            tables_query += " ORDER BY TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME"

            tables_result = await asyncio.to_thread(
                self.connection.execute_query, tables_query
            )

            tables_map: dict[str, TableMetadata] = {}

            for row in tables_result:
                if len(row) < 4:
                    continue
                table_catalog, table_schema, table_name, table_type = (
                    row[0],
                    row[1],
                    row[2],
                    row[3],
                )
                if not all([table_catalog, table_schema, table_name]):
                    continue
                full_name = f"{table_catalog}.{table_schema}.{table_name}"
                tables_map[full_name] = TableMetadata(
                    name=full_name,
                    display_name=str(table_name),
                    is_view=table_type == "VIEW",
                    columns=[],
                    primary_key=None,
                    foreign_keys=[],
                )

            if not tables_map:
                return DataSourceMetadata(tables=[])

            table_tuples = [(r[0], r[1], r[2]) for r in tables_result]
            table_placeholders = ", ".join(
                f"('{str(cat).replace(chr(39), chr(39) + chr(39))}', '{str(sch).replace(chr(39), chr(39) + chr(39))}', '{str(tbl).replace(chr(39), chr(39) + chr(39))}')"
                for cat, sch, tbl in table_tuples
            )

            columns_query = f"""
                SELECT 
                    TABLE_CATALOG,
                    TABLE_SCHEMA,
                    TABLE_NAME,
                    COLUMN_NAME,
                    DATA_TYPE,
                    IS_NULLABLE,
                    COLUMN_DEFAULT,
                    CHARACTER_MAXIMUM_LENGTH,
                    NUMERIC_PRECISION,
                    NUMERIC_SCALE
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE (TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME) IN ({table_placeholders})
                ORDER BY TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION
            """

            columns_result = await asyncio.to_thread(
                self.connection.execute_query, columns_query
            )

            for row in columns_result:
                if len(row) < 10:
                    continue
                table_catalog, table_schema, table_name = row[0], row[1], row[2]
                full_name = f"{table_catalog}.{table_schema}.{table_name}"
                if full_name in tables_map:
                    col_name = row[3]
                    data_type = row[4]
                    is_nullable = row[5] == "YES" if row[5] else True
                    default_value = row[6]

                    canonical_type = self._map_snowflake_type(
                        str(data_type) if data_type else "STRING"
                    )

                    tables_map[full_name].columns.append(
                        ColumnMetadata(
                            name=col_name,
                            data_type=canonical_type,
                            nullable=is_nullable,
                            default_value=str(default_value) if default_value else None,
                            description=None,
                        )
                    )

            primary_keys_query = f"""
                SELECT 
                    TABLE_CATALOG,
                    TABLE_SCHEMA,
                    TABLE_NAME,
                    CONSTRAINT_NAME
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                WHERE CONSTRAINT_TYPE = 'PRIMARY KEY'
                AND (TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME) IN ({table_placeholders})
            """

            pk_result = await asyncio.to_thread(
                self.connection.execute_query, primary_keys_query
            )

            pk_constraints: dict[str, str] = {}
            for row in pk_result:
                if len(row) < 4:
                    continue
                table_catalog, table_schema, table_name, constraint_name = (
                    row[0],
                    row[1],
                    row[2],
                    row[3],
                )
                full_name = f"{table_catalog}.{table_schema}.{table_name}"
                if full_name in tables_map:
                    pk_constraints[full_name] = str(constraint_name)

            for full_name, constraint_name in pk_constraints.items():
                parts = full_name.split(".")
                if len(parts) != 3:
                    continue
                cat, sch, tbl = parts
                cat_escaped = str(cat).replace(chr(39), chr(39) + chr(39))
                sch_escaped = str(sch).replace(chr(39), chr(39) + chr(39))
                tbl_escaped = str(tbl).replace(chr(39), chr(39) + chr(39))
                constraint_escaped = str(constraint_name).replace(
                    chr(39), chr(39) + chr(39)
                )
                key_columns_query = f"""
                    SELECT COLUMN_NAME
                    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE TABLE_CATALOG = '{cat_escaped}'
                    AND TABLE_SCHEMA = '{sch_escaped}'
                    AND TABLE_NAME = '{tbl_escaped}'
                    AND CONSTRAINT_NAME = '{constraint_escaped}'
                    ORDER BY ORDINAL_POSITION
                """

                key_cols_result = await asyncio.to_thread(
                    self.connection.execute_query, key_columns_query
                )
                pk_columns = [
                    str(row[0]) for row in key_cols_result if row and len(row) > 0
                ]
                if full_name in tables_map and pk_columns:
                    tables_map[full_name].primary_key = pk_columns

            return DataSourceMetadata(tables=list(tables_map.values()))

        except sc.errors.ProgrammingError as e:
            logger.exception("Snowflake metadata query failed")
            raise QueryExecutionException(f"Metadata retrieval failed: {str(e)}") from e
        except sc.errors.OperationalError as e:
            logger.exception("Snowflake connection error during metadata retrieval")
            raise ExternalServiceException(
                "Snowflake", operation="retrieving metadata"
            ) from e
        except Exception as e:
            logger.exception("Unexpected error retrieving Snowflake metadata")
            raise QueryExecutionException(f"Metadata retrieval failed: {str(e)}") from e

    @staticmethod
    def _map_snowflake_type(snowflake_type: str) -> str:
        type_mapping = [
            ("TIMESTAMP_NTZ", "datetime"),
            ("TIMESTAMP_LTZ", "datetime"),
            ("TIMESTAMP_TZ", "datetime"),
            ("TIMESTAMP", "datetime"),
            ("DOUBLE PRECISION", "number"),
            ("NUMBER", "number"),
            ("DECIMAL", "number"),
            ("NUMERIC", "number"),
            ("INT", "number"),
            ("INTEGER", "number"),
            ("BIGINT", "number"),
            ("SMALLINT", "number"),
            ("TINYINT", "number"),
            ("FLOAT", "number"),
            ("FLOAT4", "number"),
            ("FLOAT8", "number"),
            ("DOUBLE", "number"),
            ("REAL", "number"),
            ("VARCHAR", "string"),
            ("CHAR", "string"),
            ("CHARACTER", "string"),
            ("STRING", "string"),
            ("TEXT", "string"),
            ("DATE", "date"),
            ("TIME", "time"),
            ("BOOLEAN", "boolean"),
            ("BINARY", "binary"),
            ("VARBINARY", "binary"),
            ("VARIANT", "json"),
            ("OBJECT", "json"),
            ("ARRAY", "array"),
        ]
        snowflake_type_upper = snowflake_type.upper()
        for sf_type, canonical in type_mapping:
            if snowflake_type_upper.startswith(sf_type):
                return canonical
        return "string"
