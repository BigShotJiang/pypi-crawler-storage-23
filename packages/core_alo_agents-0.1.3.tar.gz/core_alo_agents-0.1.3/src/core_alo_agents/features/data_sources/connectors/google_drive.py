from __future__ import annotations

import asyncio
import io
import logging
from typing import Any

from googleapiclient.discovery import build  # type: ignore[import-untyped]
from googleapiclient.errors import HttpError  # type: ignore[import-untyped]
from googleapiclient.http import MediaIoBaseDownload  # type: ignore[import-untyped]

from .base import BaseConnector, GoogleConnectionBase
from .connector_factory import register_connector
from ..exceptions import (
    ExternalServiceAuthException,
    ExternalServiceException,
    QueryExecutionException,
)
from ..schemas import (
    AuthStrategy,
    ColumnMetadata,
    CredentialDetails,
    DataSourceMetadata,
    DocumentationLink,
    FieldDefinition,
    TableMetadata,
)
from ..constants import ConnectorType

logger = logging.getLogger(__name__)


class _GoogleDriveConnection(GoogleConnectionBase):
    """Internal connection class for Google Drive API."""

    # Required scopes for reading Drive files
    SCOPES = [
        "https://www.googleapis.com/auth/drive.readonly",
        "https://www.googleapis.com/auth/drive.metadata.readonly",
    ]

    _BASE_PARAMS: frozenset[str] = frozenset({"auth_type", "folder_id"})

    _AUTH_PARAMS: dict[str, frozenset[str]] = {
        "key-pair": frozenset(
            {
                "service_account_key",
                "subject",
            }
        ),
    }

    def __init__(self, connection_data: dict[str, Any]) -> None:
        super().__init__(connection_data)
        self.drive_service: Any = None

    def connect(self) -> None:
        """Establish a connection to Google Drive API."""
        if self.is_connected and self.credentials is not None:
            return

        # Build and validate configuration
        self._config = self._build_config()
        self.credentials = self._build_credentials()

        # Build service client
        self.drive_service = build("drive", "v3", credentials=self.credentials)
        self.is_connected = True

    def disconnect(self) -> None:
        """Close the connection to Google API."""
        if not self.is_connected:
            return

        self.credentials = None
        self.drive_service = None
        self.is_connected = False

    def check_connection(self) -> bool:
        """Check if the connection is valid by listing files."""
        try:
            self.connect()
            # Try to list 1 file to verify connection
            self.drive_service.files().list(pageSize=1).execute()
            return True
        except (HttpError, Exception):
            self.is_connected = False
            self.credentials = None
            return False

    def _get_configured_folder_id(self) -> str | None:
        """Get the configured folder_id if set."""
        if not self._config:
            return None
        folder_id = self._config.get("folder_id")
        return (
            folder_id.strip()
            if isinstance(folder_id, str) and folder_id.strip()
            else None
        )

    def _verify_file_in_folder(self, file_id: str, allowed_folder_id: str) -> bool:
        """Verify that a file is within the allowed folder hierarchy.

        Args:
            file_id: The file ID to check
            allowed_folder_id: The root folder ID that files must be under

        Returns:
            True if file is in allowed folder or subfolder, False otherwise
        """
        try:
            file_metadata = (
                self.drive_service.files()
                .get(fileId=file_id, fields="parents")
                .execute()
            )

            parents = file_metadata.get("parents", [])
            if not parents:
                return False

            # Check if any parent is the allowed folder
            if allowed_folder_id in parents:
                return True

            # Recursively check parent folders
            for parent_id in parents:
                if self._verify_file_in_folder(parent_id, allowed_folder_id):
                    return True

            return False
        except HttpError:
            return False

    def list_files(
        self,
        filter: str | None = None,
        folder_id: str | None = None,
        max_results: int = 100,
        page_token: str | None = None,
    ) -> dict[str, Any]:
        """List files in Google Drive.

        Args:
            filter: Optional search filter (Drive API query syntax)
            folder_id: Optional folder ID to search within
            max_results: Maximum number of results to return
            page_token: Token for pagination

        Returns:
            Dictionary with 'files' and optional 'nextPageToken'
        """
        self.connect()

        # Check if there's a configured folder_id (folder scope)
        configured_folder_id = self._get_configured_folder_id()

        # If folder scope is configured, enforce it
        # If user provides a folder_id, it must match the configured one
        if configured_folder_id:
            if folder_id and folder_id != configured_folder_id:
                raise ValueError(
                    f"Access denied: Connection is scoped to folder {configured_folder_id}. "
                    f"Cannot access folder {folder_id}"
                )
            folder_id = configured_folder_id

        # Build query
        queries = []
        if filter:
            queries.append(filter)
        if folder_id:
            queries.append(f"'{folder_id}' in parents")

        # Always exclude trashed files
        queries.append("trashed = false")

        combined_query = " and ".join(queries) if queries else None

        # Execute request
        request_params = {
            "pageSize": min(max_results, 1000),
            "fields": "nextPageToken, files(id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink, owners)",
        }

        if combined_query:
            request_params["q"] = combined_query

        if page_token:
            request_params["pageToken"] = page_token

        results = self.drive_service.files().list(**request_params).execute()

        return {
            "files": results.get("files", []),
            "nextPageToken": results.get("nextPageToken"),
        }

    def get_file_metadata(self, file_id: str) -> dict[str, Any]:
        """Get metadata for a specific file.

        Args:
            file_id: The Google Drive file ID

        Returns:
            File metadata dictionary
        """
        self.connect()

        # Check folder scope
        configured_folder_id = self._get_configured_folder_id()
        if configured_folder_id:
            # Verify file is within allowed folder
            if not self._verify_file_in_folder(file_id, configured_folder_id):
                raise ValueError(
                    f"Access denied: File {file_id} is not within the scoped folder {configured_folder_id}"
                )

        file = (
            self.drive_service.files()
            .get(
                fileId=file_id,
                fields="id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink, owners, description",
            )
            .execute()
        )

        return file

    def search_files(
        self, search_term: str, max_results: int = 100
    ) -> list[dict[str, Any]]:
        """Search for files by name.

        Args:
            search_term: Term to search for in file names
            max_results: Maximum number of results to return

        Returns:
            List of file metadata dictionaries
        """
        self.connect()

        # Build base query
        queries = [f"name contains '{search_term}'", "trashed = false"]

        # Enforce folder scope if configured
        configured_folder_id = self._get_configured_folder_id()
        if configured_folder_id:
            queries.append(f"'{configured_folder_id}' in parents")

        query = " and ".join(queries)

        results = (
            self.drive_service.files()
            .list(
                q=query,
                pageSize=max_results,
                fields="files(id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink)",
                orderBy="modifiedTime desc",
            )
            .execute()
        )

        return results.get("files", [])

    def list_files_in_folder(
        self, folder_id: str | None = None, max_results: int = 100
    ) -> list[dict[str, Any]]:
        """List all files in a specific folder or root.

        Args:
            folder_id: Optional folder ID (None = root/My Drive accessible files)
            max_results: Maximum number of results to return

        Returns:
            List of files with their metadata
        """
        self.connect()

        # Check folder scope
        configured_folder_id = self._get_configured_folder_id()
        if configured_folder_id:
            # If folder scope is configured, enforce it
            if folder_id and folder_id != configured_folder_id:
                # Verify the requested folder is a subfolder of the configured folder
                if not self._verify_file_in_folder(folder_id, configured_folder_id):
                    raise ValueError(
                        f"Access denied: Connection is scoped to folder {configured_folder_id}. "
                        f"Cannot access folder {folder_id}"
                    )
            else:
                # If no folder_id provided, use configured folder
                folder_id = configured_folder_id

        # Build query for files in the specified folder
        query = "trashed = false"
        if folder_id:
            query += f" and '{folder_id}' in parents"

        results = (
            self.drive_service.files()
            .list(
                q=query,
                pageSize=max_results,
                fields="files(id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink)",
                orderBy="modifiedTime desc",
            )
            .execute()
        )

        return results.get("files", [])

    def list_folders(
        self, parent_folder_id: str | None = None, max_results: int = 100
    ) -> list[dict[str, Any]]:
        """List folders only.

        Args:
            parent_folder_id: Optional parent folder ID (None = root level folders)
            max_results: Maximum number of results to return

        Returns:
            List of folders with their metadata
        """
        self.connect()

        # Check folder scope
        configured_folder_id = self._get_configured_folder_id()
        if configured_folder_id:
            # If folder scope is configured, enforce it
            if parent_folder_id and parent_folder_id != configured_folder_id:
                # Verify the requested folder is within the configured folder
                if not self._verify_file_in_folder(
                    parent_folder_id, configured_folder_id
                ):
                    raise ValueError(
                        f"Access denied: Connection is scoped to folder {configured_folder_id}. "
                        f"Cannot access folder {parent_folder_id}"
                    )
            else:
                # If no parent_folder_id provided, use configured folder
                parent_folder_id = configured_folder_id

        query = "mimeType = 'application/vnd.google-apps.folder' and trashed = false"
        if parent_folder_id:
            query += f" and '{parent_folder_id}' in parents"

        results = (
            self.drive_service.files()
            .list(
                q=query,
                pageSize=max_results,
                fields="files(id, name, mimeType, createdTime, modifiedTime, parents)",
                orderBy="name",
            )
            .execute()
        )

        return results.get("files", [])

    def download_file(self, file_id: str) -> bytes:
        """Download file content as binary data.

        This method downloads the actual file content from Google Drive.
        For Google Workspace files (Docs, Sheets, Slides), they are automatically
        exported to appropriate Office formats (DOCX, XLSX, PPTX).

        Args:
            file_id: The Google Drive file ID to download

        Returns:
            Binary content of the file

        Raises:
            HttpError: If the file cannot be downloaded (not found, no access, etc.)
            ValueError: If file is outside folder scope (when folder scoping is enabled)
        """
        self.connect()

        # Check folder scope
        configured_folder_id = self._get_configured_folder_id()
        if configured_folder_id:
            # Verify file is within the configured folder scope
            if not self._verify_file_in_folder(file_id, configured_folder_id):
                raise ValueError(
                    f"Access denied: Connection is scoped to folder {configured_folder_id}. "
                    f"File {file_id} is outside this scope."
                )

        # Get file metadata to check if it's a Google Workspace file
        file_metadata = self.get_file_metadata(file_id)
        mime_type = file_metadata.get("mimeType", "")

        # Google Workspace files need to be exported, not downloaded directly
        if mime_type.startswith("application/vnd.google-apps."):
            # Handle Google Workspace files by exporting to appropriate format
            export_mime_type = self._get_export_mime_type(mime_type)
            request = self.drive_service.files().export_media(
                fileId=file_id, mimeType=export_mime_type
            )
        else:
            # Regular files can be downloaded directly
            request = self.drive_service.files().get_media(fileId=file_id)

        # Download the file content
        file_handle = io.BytesIO()
        downloader = MediaIoBaseDownload(file_handle, request)

        done = False
        while not done:
            status, done = downloader.next_chunk()
            if status:
                logger.debug(f"Download progress: {int(status.progress() * 100)}%")

        # Get the binary content
        file_handle.seek(0)
        return file_handle.read()

    @staticmethod
    def _get_export_mime_type(google_mime_type: str) -> str:
        """Get appropriate export MIME type for Google Workspace files.

        Args:
            google_mime_type: The Google Workspace MIME type

        Returns:
            Export MIME type for the file
        """
        export_mapping = {
            "application/vnd.google-apps.document": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  # DOCX
            "application/vnd.google-apps.spreadsheet": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",  # XLSX
            "application/vnd.google-apps.presentation": "application/vnd.openxmlformats-officedocument.presentationml.presentation",  # PPTX
            "application/vnd.google-apps.drawing": "application/pdf",
            "application/vnd.google-apps.script": "application/vnd.google-apps.script+json",
        }

        return export_mapping.get(google_mime_type, "application/pdf")


@register_connector("google_drive")
class GoogleDriveConnector(BaseConnector):
    connector_type: ConnectorType = ConnectorType.FOLDER
    name: str = "Google Drive"
    description: str = "Google Drive connector for accessing files and folders."
    version: str = "0.1.0"
    logo_url: str | None = None
    instructions_prompt: str = """You are querying Google Drive files and folders. Key points:

FOLDER SCOPING:
- If a folder_id is configured in the connection settings, ALL operations are automatically scoped to that folder and its subfolders
- You cannot access files or folders outside the configured folder scope
- When folder scope is active, folder_id parameters in operations must match or be subfolders of the configured folder

SUPPORTED OPERATIONS:
1. list_files - List files with optional filtering
   Format: {"operation": "list_files", "filter": "name contains 'report'", "max_results": 50}
   Note: Use "filter" parameter (NOT "query") to avoid SQL validation errors
   
2. search_files - Simple text search in file names
   Format: {"operation": "search_files", "search_term": "report", "max_results": 50}
   
3. get_file_metadata - Get details of a specific file
   Format: {"operation": "get_file_metadata", "file_id": "abc123"}
   Note: File must be within the configured folder scope if set
   
4. list_files_in_folder - List all files in a specific folder
   Format: {"operation": "list_files_in_folder", "folder_id": "abc123", "max_results": 100}
   If folder_id is omitted, uses configured folder scope or root/My Drive
   
5. list_folders - List folders only
   Format: {"operation": "list_folders", "parent_folder_id": "abc123", "max_results": 100}
   If parent_folder_id is omitted, uses configured folder scope or root-level folders

DRIVE API FILTER SYNTAX (for list_files "filter" parameter):
- name = 'exact name' - Exact match
- name contains 'partial' - Contains text
- mimeType = 'application/pdf' - Filter by MIME type
- mimeType = 'application/vnd.google-apps.folder' - Folders only
- modifiedTime > '2024-01-01T00:00:00' - Date filters
- Combine with 'and': "name contains 'report' and mimeType = 'application/pdf'"

COMMON MIME TYPES:
- Folders: application/vnd.google-apps.folder
- Google Docs: application/vnd.google-apps.document
- Google Sheets: application/vnd.google-apps.spreadsheet
- PDF: application/pdf
- Excel: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet

TIPS:
- Always use "filter" not "query" to avoid SQL validation
- File names are case-sensitive in filters
- search_files is simpler for basic text searches
- All data is read-only
- Results include: id, name, mimeType, size, timestamps, webViewLink
- Respect folder scope restrictions - operations outside the configured folder will be rejected"""

    credential_details: CredentialDetails = CredentialDetails(
        auth_strategies=[
            AuthStrategy(
                type="key-pair",
                label="Service Account",
                description="Authenticate using a Google service account JSON key",
                fields=[
                    FieldDefinition(
                        name="service_account_key",
                        label="Service Account Key (JSON)",
                        type="text",
                        required=True,
                        is_sensitive=True,
                        description="Service account JSON key as string (entire JSON object)",
                    ),
                    FieldDefinition(
                        name="subject",
                        label="Subject (Optional)",
                        type="text",
                        required=False,
                        is_sensitive=False,
                        description="User email to impersonate (for domain-wide delegation)",
                    ),
                ],
            ),
        ],
        common_fields=[
            FieldDefinition(
                name="folder_id",
                label="Folder ID (Optional)",
                type="text",
                required=False,
                is_sensitive=False,
                description="Google Drive folder ID to scope access to. If provided, all operations will be restricted to this folder and its subfolders only. You can get the folder ID from the URL: https://drive.google.com/drive/folders/[FOLDER_ID]",
                placeholder="1a2B3c4D5e6F7g8H9i0J",
            ),
        ],
        documentation_links=[
            DocumentationLink(
                label="Google Drive API Documentation",
                url="https://developers.google.com/drive/api",
            ),
            DocumentationLink(
                label="Service Account Setup Guide",
                url="https://developers.google.com/identity/protocols/oauth2/service-account",
            ),
            DocumentationLink(
                label="Search Files Query Syntax",
                url="https://developers.google.com/drive/api/guides/search-files",
            ),
        ],
    )

    def __init__(self):
        super().__init__()
        self._connection_impl: _GoogleDriveConnection | None = None

    async def connect(self, credentials: dict[str, Any]) -> None:
        """Establish a connection to Google Drive API."""
        try:
            if self._connection_impl and self._connection_impl.is_connected:
                await asyncio.to_thread(self._connection_impl.disconnect)
            self._connection_impl = await asyncio.to_thread(
                _GoogleDriveConnection, credentials
            )
            await asyncio.to_thread(self._connection_impl.connect)
            self.connection = self._connection_impl
        except HttpError as e:
            if e.resp.status == 401:
                logger.exception("Google Drive authentication failed")
                raise ExternalServiceAuthException("Google Drive") from e
            logger.exception("Google Drive connection failed")
            raise ExternalServiceException(
                "Google Drive", operation="connecting"
            ) from e
        except ValueError as e:
            logger.exception("Google Drive connection configuration error")
            raise ExternalServiceAuthException("Google Drive", reason=str(e)) from e
        except Exception as e:
            logger.exception("Unexpected error connecting to Google Drive")
            raise ExternalServiceException(
                "Google Drive", operation="connecting"
            ) from e

    async def execute_query(self, query: dict[str, Any]) -> Any:
        """Execute a query to interact with Google Drive.

        Query format:
        {
            "operation": "list_files" | "search_files" | "get_file_metadata" | "list_files_in_folder" | "list_folders",
            ... operation-specific parameters
        }

        Operations:
        - list_files: {"operation": "list_files", "filter": "...", "folder_id": "...", "max_results": 100}
        - search_files: {"operation": "search_files", "search_term": "...", "max_results": 100}
        - get_file_metadata: {"operation": "get_file_metadata", "file_id": "..."}
        - list_files_in_folder: {"operation": "list_files_in_folder", "folder_id": "...", "max_results": 100}
        - list_folders: {"operation": "list_folders", "parent_folder_id": "...", "max_results": 100}

        Returns structured data based on the operation.
        """
        if not self.connection or not isinstance(
            self.connection, _GoogleDriveConnection
        ):
            raise QueryExecutionException("Not connected to Google Drive")

        operation = query.get("operation")
        if not operation:
            raise QueryExecutionException(
                "Query must contain 'operation' field (list_files, search_files, get_file_metadata, list_files_in_folder, or list_folders)"
            )

        try:
            if operation == "list_files":
                result = await asyncio.to_thread(
                    self.connection.list_files,
                    filter=query.get("filter"),
                    folder_id=query.get("folder_id"),
                    max_results=query.get("max_results", 100),
                    page_token=query.get("page_token"),
                )
                return {"success": True, "data": result}

            elif operation == "search_files":
                search_term = query.get("search_term")
                if not search_term:
                    raise QueryExecutionException(
                        "search_files operation requires 'search_term'"
                    )
                result = await asyncio.to_thread(
                    self.connection.search_files,
                    search_term=search_term,
                    max_results=query.get("max_results", 100),
                )
                return {"success": True, "data": result}

            elif operation == "get_file_metadata":
                file_id = query.get("file_id")
                if not file_id:
                    raise QueryExecutionException(
                        "get_file_metadata operation requires 'file_id'"
                    )
                result = await asyncio.to_thread(
                    self.connection.get_file_metadata,
                    file_id=file_id,
                )
                return {"success": True, "data": result}

            elif operation == "list_files_in_folder":
                result = await asyncio.to_thread(
                    self.connection.list_files_in_folder,
                    folder_id=query.get("folder_id"),
                    max_results=query.get("max_results", 100),
                )
                return {"success": True, "data": result}

            elif operation == "list_folders":
                result = await asyncio.to_thread(
                    self.connection.list_folders,
                    parent_folder_id=query.get("parent_folder_id"),
                    max_results=query.get("max_results", 100),
                )
                return {"success": True, "data": result}

            else:
                raise QueryExecutionException(
                    f"Unknown operation: {operation}. Supported: list_files, search_files, get_file_metadata, list_files_in_folder, list_folders"
                )

        except ValueError as e:
            logger.exception("Google Drive query validation failed")
            raise QueryExecutionException(f"Query validation failed: {str(e)}") from e
        except HttpError as e:
            if e.resp.status == 404:
                logger.exception("Google Drive file/folder not found")
                raise QueryExecutionException(
                    f"File or folder not found: {str(e)}"
                ) from e
            logger.exception("Google Drive query execution failed")
            raise ExternalServiceException(
                "Google Drive", operation="executing query"
            ) from e
        except Exception as e:
            logger.exception("Unexpected error executing Google Drive query")
            raise QueryExecutionException(f"Query execution failed: {str(e)}") from e

    async def test_connection(self, credentials: dict[str, Any]) -> bool:
        """Test if the provided credentials are valid."""
        try:
            conn = _GoogleDriveConnection(credentials)
            conn.connect()
            valid = conn.check_connection()
            conn.disconnect()
            if not valid:
                raise ExternalServiceAuthException(
                    "Google Drive",
                    reason="Service account credentials are invalid.",
                )
            return True
        except Exception as e:
            raise ExternalServiceAuthException("Google Drive", reason=str(e)) from e

    async def get_metadata(self) -> DataSourceMetadata:
        """Get metadata about available files and folders in Google Drive.

        Returns a simplified view of the Drive structure with folders as "tables"
        and their files as "rows". This provides a database-like view of Drive.
        Respects folder scoping if configured.
        """
        if not self.connection or not isinstance(
            self.connection, _GoogleDriveConnection
        ):
            raise QueryExecutionException("Not connected to Google Drive")

        try:
            # Get folders (automatically scoped to configured folder if set)
            folders = await asyncio.to_thread(
                self.connection.list_folders, parent_folder_id=None
            )

            tables: list[TableMetadata] = []

            # Add a special "All Files" table
            all_files_table = TableMetadata(
                name="AllFiles",
                display_name="All Files",
                is_view=False,
                columns=[
                    ColumnMetadata(
                        name="id",
                        data_type="string",
                        nullable=False,
                        default_value=None,
                        description="File ID",
                    ),
                    ColumnMetadata(
                        name="name",
                        data_type="string",
                        nullable=False,
                        default_value=None,
                        description="File name",
                    ),
                    ColumnMetadata(
                        name="mimeType",
                        data_type="string",
                        nullable=True,
                        default_value=None,
                        description="MIME type of the file",
                    ),
                    ColumnMetadata(
                        name="size",
                        data_type="number",
                        nullable=True,
                        default_value=None,
                        description="File size in bytes",
                    ),
                    ColumnMetadata(
                        name="createdTime",
                        data_type="datetime",
                        nullable=True,
                        default_value=None,
                        description="File creation timestamp",
                    ),
                    ColumnMetadata(
                        name="modifiedTime",
                        data_type="datetime",
                        nullable=True,
                        default_value=None,
                        description="File modification timestamp",
                    ),
                    ColumnMetadata(
                        name="webViewLink",
                        data_type="string",
                        nullable=True,
                        default_value=None,
                        description="Web link to view the file",
                    ),
                ],
                primary_key=["id"],
                foreign_keys=[],
            )
            tables.append(all_files_table)

            # Add each folder as a "table"
            for folder in folders[:50]:  # Limit to first 50 folders
                folder_name = folder.get("name", "Unnamed Folder")
                folder_id = folder.get("id")

                folder_table = TableMetadata(
                    name=f"Folder_{folder_id}",
                    display_name=f"Folder: {folder_name}",
                    is_view=False,
                    columns=[
                        ColumnMetadata(
                            name="id",
                            data_type="string",
                            nullable=False,
                            default_value=None,
                            description="File ID",
                        ),
                        ColumnMetadata(
                            name="name",
                            data_type="string",
                            nullable=False,
                            default_value=None,
                            description="File name",
                        ),
                        ColumnMetadata(
                            name="mimeType",
                            data_type="string",
                            nullable=True,
                            default_value=None,
                            description="MIME type of the file",
                        ),
                        ColumnMetadata(
                            name="size",
                            data_type="number",
                            nullable=True,
                            default_value=None,
                            description="File size in bytes",
                        ),
                    ],
                    primary_key=["id"],
                    foreign_keys=[],
                )
                tables.append(folder_table)

            return DataSourceMetadata(tables=tables)

        except HttpError as e:
            if e.resp.status == 401:
                raise ExternalServiceAuthException(
                    "Google Drive",
                    reason="Service account credentials are invalid or expired",
                ) from e
            logger.exception("Google Drive metadata retrieval failed")
            raise ExternalServiceException(
                "Google Drive", operation="retrieving metadata"
            ) from e
        except Exception as e:
            logger.exception("Unexpected error retrieving Google Drive metadata")
            raise QueryExecutionException(f"Metadata retrieval failed: {str(e)}") from e

    async def download_file(self, file_id: str) -> bytes:
        """Download file content as binary data (async wrapper for internal use).

        This is an internal method for downloading files from Google Drive.
        It is NOT exposed through execute_query - use it directly in your code.

        For Google Workspace files (Docs, Sheets, Slides), they are automatically
        exported to appropriate Office formats:
        - Google Docs → DOCX
        - Google Sheets → XLSX
        - Google Slides → PPTX

        Args:
            file_id: The Google Drive file ID to download

        Returns:
            Binary content of the file

        Raises:
            QueryExecutionException: If not connected or download fails
            ExternalServiceException: If Google Drive API error occurs

        Example:
            ```python
            connector = GoogleDriveConnector()
            await connector.connect(credentials)
            file_content = await connector.download_file("abc123xyz")
            # file_content is now a bytes object with the file data
            ```
        """
        if not self.connection or not isinstance(
            self.connection, _GoogleDriveConnection
        ):
            raise QueryExecutionException("Not connected to Google Drive")

        try:
            result = await asyncio.to_thread(
                self.connection.download_file,
                file_id=file_id,
            )
            return result
        except ValueError as e:
            logger.exception("Google Drive file access denied")
            raise QueryExecutionException(f"File access denied: {str(e)}") from e
        except HttpError as e:
            if e.resp.status == 404:
                logger.exception("Google Drive file not found")
                raise QueryExecutionException(f"File not found: {file_id}") from e
            logger.exception("Google Drive file download failed")
            raise ExternalServiceException(
                "Google Drive", operation="downloading file"
            ) from e
        except Exception as e:
            logger.exception("Unexpected error downloading file from Google Drive")
            raise QueryExecutionException(f"File download failed: {str(e)}") from e
