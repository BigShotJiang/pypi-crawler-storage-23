from __future__ import annotations

import base64
import os
from typing import Any, Mapping


from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel, Field

from ....config import settings
from ..schemas import DataSourceConnection, CredentialDetails
from ..connectors.connector_factory import ConnectorFactory
from ..exceptions import QueryExecutionException, ConnectorNotFoundException
from ..logging import log_credential_access

"""Utilities for encrypting connector credentials using AES-GCM.

Example:
    crypto = CryptoService()
    encrypted = crypto.encrypt_payload(user_payload, credential_schema.fields)
    decrypted = crypto.decrypt_payload(encrypted, credential_schema.fields)
"""


class EncryptedField(BaseModel):
    """Standard envelope for encrypted values."""

    encrypted_data: str = Field(
        ..., description="Base64 encoded ciphertext (without auth tag)"
    )
    iv: str = Field(
        ..., description="Base64 encoded initialization vector (12 bytes for AES-GCM)"
    )
    auth_tag: str = Field(
        ..., description="Base64 encoded authentication tag (16 bytes for AES-GCM)"
    )


class CryptoService:
    """Encrypts and decrypts sensitive values using AES-GCM (256-bit).

    Also provides field-level encryption for credential payloads based on schema sensitivity.

    Example:
        crypto = CryptoService.get_encryption_key_from_env()
        encrypted = crypto.encrypt_payload(user_payload, credential_schema.fields)
        decrypted = crypto.decrypt_payload(encrypted, credential_schema.fields)
    """

    def __init__(self):
        self._key = base64.urlsafe_b64decode(settings.DATA_SOURCES_ENCRYPTION_KEY)

    def encrypt(
        self, plaintext: bytes, *, associated_data: bytes | None = None
    ) -> EncryptedField:
        aesgcm = AESGCM(self._key)
        iv = os.urandom(12)
        ciphertext_with_tag = aesgcm.encrypt(iv, plaintext, associated_data)
        # AESGCM appends auth tag to ciphertext; split last 16 bytes
        auth_tag = ciphertext_with_tag[-16:]
        ciphertext = ciphertext_with_tag[:-16]
        return EncryptedField(
            encrypted_data=base64.urlsafe_b64encode(ciphertext).decode(),
            iv=base64.urlsafe_b64encode(iv).decode(),
            auth_tag=base64.urlsafe_b64encode(auth_tag).decode(),
        )

    def decrypt(
        self, encrypted: EncryptedField, *, associated_data: bytes | None = None
    ) -> bytes:
        aesgcm = AESGCM(self._key)
        iv = base64.urlsafe_b64decode(encrypted.iv)
        ciphertext = base64.urlsafe_b64decode(encrypted.encrypted_data)
        auth_tag = base64.urlsafe_b64decode(encrypted.auth_tag)
        combined = ciphertext + auth_tag
        return aesgcm.decrypt(iv, combined, associated_data)

    def encrypt_payload(
        self, payload: Mapping[str, Any], schema_fields: list[Mapping[str, Any]]
    ) -> dict[str, Any]:
        """Encrypt fields marked sensitive in schema_fields.

        schema_fields: list of FieldDefinition-like dicts (expects keys: key, sensitive).
        """
        result: dict[str, Any] = {}
        sensitive_keys = {
            self._field_key(field)
            for field in schema_fields
            if self._field_sensitive(field)
        }

        for key, value in payload.items():
            if key in sensitive_keys and value is not None:
                encrypted = self.encrypt(str(value).encode())
                result[key] = encrypted.model_dump()
            else:
                result[key] = value
        return result

    def decrypt_payload(
        self, payload: Mapping[str, Any], schema_fields: list[Mapping[str, Any]]
    ) -> dict[str, Any]:
        """Decrypt fields that were encrypted according to schema_fields."""
        result: dict[str, Any] = {}
        sensitive_keys = {
            self._field_key(field)
            for field in schema_fields
            if self._field_sensitive(field)
        }

        for key, value in payload.items():
            if (
                key in sensitive_keys
                and isinstance(value, Mapping)
                and self._looks_encrypted(value)
            ):
                encrypted = EncryptedField.model_validate(value)
                plaintext = self.decrypt(encrypted).decode()
                result[key] = plaintext
            else:
                result[key] = value
        return result

    @staticmethod
    def _looks_encrypted(value: Mapping[str, Any]) -> bool:
        return {
            "encrypted_data",
            "iv",
            "auth_tag",
        }.issubset(value.keys())

    @staticmethod
    def _field_key(field: Mapping[str, Any] | Any) -> str:
        if isinstance(field, Mapping):
            return str(field.get("name") or field.get("key"))
        return str(getattr(field, "name", None) or getattr(field, "key", None))

    @staticmethod
    def _field_sensitive(field: Mapping[str, Any] | Any) -> bool:
        if isinstance(field, Mapping):
            return bool(field.get("is_sensitive"))
        return bool(getattr(field, "is_sensitive", False))

    @staticmethod
    def decrypt_connection_credentials(
        connection: DataSourceConnection, crypto_service: CryptoService
    ) -> dict[str, Any]:
        """Resolve and decrypt stored credentials for a connection."""
        auth_payload = connection.credentials or {}
        auth_type = None
        if isinstance(auth_payload, dict):
            auth_type = auth_payload.get("auth_type") or auth_payload.get(
                "values", {}
            ).get("auth_type")

        if not auth_type:
            raise QueryExecutionException(
                "Missing auth_type for connection credentials"
            )

        factory = ConnectorFactory()
        try:
            connector_class = factory.get_connector_class(connection.connector_key)
        except ConnectorNotFoundException as exc:  # noqa: BLE001
            raise QueryExecutionException(
                f"Connector '{connection.connector_key}' is not registered"
            ) from exc

        credential_details = CredentialDetails.model_validate(
            connector_class.credential_details
        )
        strategy = next(
            (s for s in credential_details.auth_strategies if s.type == auth_type), None
        )

        if not strategy:
            valid_types = ", ".join(s.type for s in credential_details.auth_strategies)
            raise QueryExecutionException(
                f"Invalid auth_type '{auth_type}'. Must be one of: {valid_types}"
            )

        fields = [
            f.model_dump() for f in credential_details.common_fields + strategy.fields
        ]
        values = auth_payload.get("values") if isinstance(auth_payload, dict) else {}
        log_credential_access(
            user_id=getattr(connection, "user_id", 0) or 0,
            connection_id=getattr(connection, "id", 0) or 0,
            connector_key=getattr(connection, "connector_key", ""),
            purpose="query_execution",
            agent_id=None,
        )
        decrypted = crypto_service.decrypt_payload(values or {}, fields)
        # Include auth_type in credentials (needed by connectors)
        decrypted["auth_type"] = auth_type
        return decrypted
