"""Slack integration for agent communication."""

from typing import TYPE_CHECKING
import asyncio
import base64
import gzip
import json
import httpx
from typing import Any

from fastapi import Request
from sqlalchemy.orm import Session
from pydantic_ai.messages import ModelMessage as PAIModelMessage

from core_alo.schemas import UserPublic

from .base import IntegrationBase
from .constants import (
    ACKNOWLEDGMENT_MESSAGE,
    IntegrationType,
    HISTORY_LENGTH,
    SlackIntegrationCommand,
)
from ..agents.a2a_types import TextPart, FilePart, FileWithBytes, Message
from core_alo.services import GCStorage


if TYPE_CHECKING:
    from ..agents.agents import Agent

    # TODO: test if works
    from slack_sdk.web.async_slack_response import AsyncSlackResponse


METADATA_SIZE_LIMIT = 3800


class SlackIntegration(IntegrationBase):
    """Slack integration that allows agents to receive and respond to Slack messages."""

    integration_type = IntegrationType.SLACK

    def __init__(
        self,
        agent: "Agent",
        db: Session,
        user: UserPublic | None = None,
        request: Request | None = None,
    ):
        super().__init__(agent, db, user, request)

        self._is_available = self.is_available()
        if not self._is_available:
            self.logger.warning(
                "slack-sdk not installed. Slack integration will not be available. "
                "Install with: pip install 'core-alo-agents[slack]'"
            )
            raise RuntimeError(
                "Slack integration not available",
            )

        # local import as slack-sdk is optional
        from slack_sdk.web.async_client import AsyncWebClient
        from slack_sdk.errors import SlackApiError
        from slack_sdk.signature import SignatureVerifier

        self.AsyncWebClient = AsyncWebClient
        self.SlackApiError = SlackApiError

        self.client = AsyncWebClient(token=self.agent.settings.SLACK_BOT_TOKEN)
        self.signature_verifier = SignatureVerifier(
            signing_secret=self.agent.settings.SLACK_SIGNING_SECRET
        )

    @classmethod
    def is_available(cls) -> bool:
        """Check if slack-sdk is installed."""
        try:
            import slack_sdk

            return True
        except ImportError:
            return False

    async def verify_auth(self) -> bool:
        """
        Verify the authentication of the Slack integration using signing secret.

        Uses Slack SDK's SignatureVerifier:
        https://api.slack.com/authentication/verifying-requests-from-slack

        Returns:
            True if the request is verified, False otherwise
        """
        body = await self.request.body()
        timestamp = self.request.headers.get("X-Slack-Request-Timestamp", "")
        signature = self.request.headers.get("X-Slack-Signature", "")

        is_valid = self.signature_verifier.is_valid(
            body=body.decode("utf-8"), timestamp=timestamp, signature=signature
        )
        return is_valid

    async def handle_event(self) -> dict[str, Any]:
        """
        Handle incoming Slack events.

        Supports:
        - URL verification challenges
        - App mentions (@bot)
        - Direct messages to the bot
        """
        body = await self.request.json()

        type = body.get("type")
        event_id = body.get("event_id")
        event = body.get("event")
        match type:
            case "url_verification":
                return {"challenge": body["challenge"]}
            case "event_callback":
                res = await self.process_event(event)
                self.logger.info(f"Processed event: {event_id}")
                return res
            case _:
                self.logger.info(f"Unknown event type: {type}")
                return {"status": "ok"}

    async def process_event(self, event: dict) -> dict[str, Any]:
        # Ignore bot messages to prevent loops, or edit messages
        bot_id = event.get("bot_id") or event.get("message", {}).get("bot_id")
        subtype = event.get("subtype")
        if bot_id or subtype in ["message_changed", "message_deleted"]:
            self.logger.info(f"Ignored event with bot_id: {bot_id}, subtype: {subtype}")
            return {"status": "ignored_event"}

        # Handle direct messages to the bot
        if event["type"] == "message" and event.get("channel_type") == "im":
            asyncio.create_task(self.process_message_in_thread(event))
            self.logger.info(f"Processed direct message for event: {event}")
            return {"status": "ok"}

        # Handle app mentions (@bot)
        if event["type"] == "app_mention":
            asyncio.create_task(self.process_message_in_thread(event))
            self.logger.info(f"Processed message for event: {event}")
            return {"status": "ok"}

    # TODO: this doesnt answer in thread, but as direct msg in the channel
    # async def process_direct_message(self, event: dict):
    #     channel = event["channel"]

    #     history_result = await self.client.conversations_history(
    #         channel=channel, limit=HISTORY_LENGTH, include_all_metadata=True
    #     )
    #     if not history_result.get("ok", False):
    #         self.logger.error(
    #             f"Failed to fetch channel history: {history_result.get('error')}"
    #         )
    #     slack_history_messages = (history_result.get("messages", []) or [])[::-1]

    #     await self.process_message(
    #         event, in_thread=False, slack_history_messages=slack_history_messages
    #     )

    async def process_message_in_thread(self, event: dict):
        channel = event["channel"]
        thread_ts = event.get("thread_ts") or event.get("ts")

        history_result = await self.client.conversations_replies(
            channel=channel,
            ts=thread_ts,
            limit=HISTORY_LENGTH,
            include_all_metadata=True,
        )
        if not history_result.get("ok", False):
            self.logger.error(
                f"Failed to fetch thread history: {history_result.get('error')}"
            )
        slack_history_messages = (history_result.get("messages", []) or [])[::-1]

        # sandbox per thread in group chats
        context_id = f"slack-{channel}-{thread_ts}"

        await self.process_message(
            event,
            in_thread=True,
            slack_history_messages=slack_history_messages,
            context_id=context_id,
        )

    async def process_message(
        self,
        event: dict,
        in_thread: bool = False,
        slack_history_messages: list[dict] = None,
        context_id: str | None = None,
    ):
        slack_history_messages = slack_history_messages or []
        user_text = event.get("text", "")
        channel = event["channel"]
        thread_ts = event.get("thread_ts") or event.get("ts")
        user_files = event.get("files", [])

        ack_result = await self.send_message(
            channel=channel,
            text=ACKNOWLEDGMENT_MESSAGE,
            thread_ts=thread_ts if in_thread else None,
        )
        ack_ts = ack_result.get("ts")

        context_id = context_id or f"slack-{channel}"
        message_id = f"slack-{channel}-{thread_ts}"

        parts = []
        if user_text:
            parts.append(TextPart(text=user_text))
        if user_files:
            parts.extend(await self.process_files(user_files))

        history = await self.get_history(slack_history_messages, channel)

        full_text, full_reasoning, internal_messages = await self.ask_agent(
            parts, context_id, message_id, history
        )

        tools = self.extract_tools_from_internal_messages(internal_messages)

        if tools:
            # TODO: THIS IS ONLY FOR FIRST TESTS; MIGRATE TO EXTERNAL STORAGE for full metadata
            full_tools_data = {
                "tools": [tool.model_dump(mode="json") for tool in tools.values()],
            }
            compressed_full = self.compress_metadata(full_tools_data)

            # Check if full compressed data fits within Slack's limit
            # Target 3800 to leave room for metadata structure overhead
            if len(compressed_full) <= METADATA_SIZE_LIMIT:
                compressed_tools = compressed_full
                self.logger.info("Using full tools data (fits within limit)")
            else:
                # Data too large - progressively truncate to fit
                compressed_tools = self.truncate_tools_for_slack_metadata(
                    tools, len(compressed_full)
                )

            event_payload = {"tools": compressed_tools}
        else:
            event_payload = {}

        metadata = {
            "event_type": "agent_response",
            "event_payload": event_payload,
        }

        update_params = {
            "channel": channel,
            "ts": ack_ts,
            "text": full_text,
            "metadata": metadata,
        }

        result = await self.client.chat_update(**update_params)
        if not result.get("ok", False):
            error = result.get("error", "Unknown error")
            self.logger.error(f"Failed to update Slack message: {error}")

        generated_files = self.extract_generated_files_from_tools(tools)
        for file_info in generated_files:
            # TODO: in theory should be only 1 bucket for the agent; so perhaps move file_service to __init__
            file_service = GCStorage(
                bucket_name=file_info["bucket_name"],
                settings=self.agent.settings,
            )
            file_bytes = file_service.get_file(
                file_info["gcs_path"],
            )
            result = await self.client.files_upload_v2(
                channel=channel,
                content=file_bytes,
                filename=file_info["filename"],
                initial_comment=f"📎 Generated file: {file_info['filename']}",
                thread_ts=thread_ts if in_thread else None,
            )
            if not result.get("ok", False):
                error = result.get("error", "Unknown error")
                self.logger.error(
                    f"Failed to upload file to Slack: {error}. File: {file_info}"
                )

    async def send_message(
        self, text: str, channel: str, thread_ts: str | None = None, **kwargs
    ) -> "AsyncSlackResponse":
        """Send a message to a Slack channel or thread."""

        result = await self.client.chat_postMessage(
            channel=channel, text=text, thread_ts=thread_ts, **kwargs
        )
        if not result.get("ok", False):
            error = result.get("error", "Unknown error")
            self.logger.error(f"Failed to send to Slack: {error}")

        return result

    async def get_history(
        self, messages: list, channel: str, history_length: int = HISTORY_LENGTH
    ) -> list[Message]:
        history = []

        for msg in messages:
            is_bot = msg.get("bot_id") is not None
            role = "agent" if is_bot else "user"

            text = msg.get("text", "")

            parts = []
            if text and text != ACKNOWLEDGMENT_MESSAGE:
                parts.append({"kind": "text", "text": text})

            if msg.get("files") and role == "user":
                file_parts = await self.process_files(msg.get("files"))
                for file_part in file_parts:
                    parts.append(
                        {
                            "kind": "file",
                            "file": {
                                "name": file_part.file.name,
                                "mimeType": file_part.file.mimeType,
                                "bytes": file_part.file.bytes,
                            },
                        }
                    )

            if not parts:
                continue

            event_payload = msg.get("metadata", {}).get("event_payload", {})
            metadata = {}
            if "tools" in event_payload and isinstance(event_payload["tools"], str):
                decompressed_data = self.decompress_metadata(event_payload["tools"])
                metadata = {**decompressed_data}

            history.append(
                Message(
                    messageId=msg.get("ts"),
                    role=role,
                    parts=parts,
                    contextId=f"slack-{channel}",
                    metadata=metadata,
                )
            )

        return list(reversed(history))[:-1]

    # TODO: THE METHODS RELATED TO TRUNCATE AND COMPRESS METADATA ARE ONLY FOR FIRST TESTS; TO REWORK INTO MORE STABLE
    def truncate_tool_by_percentage(self, tool, keep_percentage: float = 1.0) -> dict:
        """
        Truncate tool data by a percentage to reduce size.

        Args:
            tool: MessageTool object
            keep_percentage: Percentage of string data to keep (0.0 to 1.0)

        Returns:
            Truncated dictionary representation
        """
        data = tool.model_dump(mode="json")

        # If keep_percentage is 1.0 or more, return as-is
        if keep_percentage >= 1.0:
            return data

        # Truncate string values in args
        if "args" in data and isinstance(data["args"], dict):
            for key, value in data["args"].items():
                if isinstance(value, str) and len(value) > 100:
                    new_length = int(len(value) * keep_percentage)
                    if key == "code":
                        # For code, keep first 60% + last 40% of new length
                        first_chars = int(new_length * 0.6)
                        last_chars = int(new_length * 0.4)
                        data["args"][key] = (
                            value[:first_chars]
                            + f"\n# ... [truncated {len(value) - new_length} chars] ...\n"
                            + value[-last_chars:]
                        )
                    else:
                        data["args"][key] = (
                            value[:new_length]
                            + f"... [+{len(value) - new_length} chars]"
                        )

        # Truncate content/result if present
        if "content" in data and data["content"]:
            content = data["content"]
            if isinstance(content, dict) and "data" in content:
                content_data = content["data"]
                if isinstance(content_data, dict) and "result" in content_data:
                    result_str = str(content_data["result"])
                    if len(result_str) > 100:
                        new_length = int(len(result_str) * keep_percentage)
                        data["content"]["data"]["result"] = result_str[:new_length]

        return data

    def truncate_tools_for_slack_metadata(
        self, tools: dict, compressed_full_size: int
    ) -> str:
        """
        Progressively truncate tool data until it fits under the size limit.

        Args:
            tools: Dictionary of MessageTool objects
            compressed_full_size: Size of the full compressed data

        Returns:
            Compressed string that fits under 3800 bytes (leaves room for metadata overhead)
        """
        self.logger.info(
            f"Full data too large ({compressed_full_size} bytes), "
            "progressively truncating to fit"
        )

        # Calculate how much we need to reduce
        target_size = METADATA_SIZE_LIMIT
        reduction_needed = target_size / compressed_full_size

        # Progressively reduce by 10% increments until it fits
        compressed_tools = None
        keep_percentage = reduction_needed
        attempt = 0

        while keep_percentage > 0.1 and attempt < 10:  # Safety limit
            attempt += 1
            compact_tools_data = {
                "tools": [
                    self.truncate_tool_by_percentage(tool, keep_percentage)
                    for tool in tools.values()
                ],
            }
            compressed = self.compress_metadata(compact_tools_data)

            if len(compressed) <= target_size:
                compressed_tools = compressed
                self.logger.info(
                    f"Fit data in {len(compressed)} bytes "
                    f"(attempt {attempt}, kept {keep_percentage * 100:.1f}% of strings)"
                )
                break

            # Reduce by 10% for next attempt
            keep_percentage *= 0.9

        # Fallback if still too large (shouldn't happen)
        if compressed_tools is None:
            self.logger.warning(
                f"Could not fit data after {attempt} attempts, using last version"
            )
            compressed_tools = compressed

        return compressed_tools

    def compress_metadata(self, data: dict) -> str:
        """
        Compress and encode metadata to reduce size for Slack storage.

        Uses gzip compression and base64 encoding to fit within Slack's
        4KB metadata size limit.

        Args:
            data: Dictionary to compress

        Returns:
            Base64-encoded compressed string
        """
        json_str = json.dumps(data)
        compressed = gzip.compress(json_str.encode("utf-8"))
        encoded = base64.b64encode(compressed).decode("utf-8")

        self.logger.info(
            f"Compressed metadata: {len(json_str)} bytes -> {len(encoded)} bytes "
            f"({len(encoded) / len(json_str) * 100:.1f}% of original)"
        )

        return encoded

    def decompress_metadata(self, encoded_str: str) -> dict:
        """
        Decompress and decode metadata from Slack storage.

        Reverses the compression/encoding process.

        Args:
            encoded_str: Base64-encoded compressed string

        Returns:
            Original dictionary
        """
        try:
            compressed = base64.b64decode(encoded_str.encode("utf-8"))
            json_str = gzip.decompress(compressed).decode("utf-8")
            return json.loads(json_str)
        except Exception as e:
            self.logger.error(f"Failed to decompress metadata: {e}")
            return {}

    async def handle_command(self):
        body = await self.request.form()
        command = body.get("command").replace("/", "")

        match command:
            case SlackIntegrationCommand.CLEAR_CONVERSATION:
                asyncio.create_task(self.clear_conversation(body))
                return {"status": "ok", "message": "Not implemented"}
            case _:
                self.logger.warning(f"Unknown command: {command}")
                return {"status": "error", "message": "Unknown command"}

    async def clear_conversation(self, body):
        pass

    async def process_files(self, files: list[dict]) -> list[FilePart]:
        """
        Download files from Slack and convert to FilePart objects.

        Args:
            files: List of file objects from Slack event

        Returns:
            List of FilePart objects
        """
        file_parts = []

        for file in files:
            file_url = file.get("url_private")
            file_name = file.get("name", "unknown")
            mime_type = file.get("mimetype", "application/octet-stream")

            if not file_url:
                continue

            async with httpx.AsyncClient(follow_redirects=True) as client:
                response = await client.get(
                    file_url,
                    headers={
                        "Authorization": f"Bearer {self.agent.settings.SLACK_BOT_TOKEN}"
                    },
                    timeout=30.0,
                )
                response.raise_for_status()
                file_bytes = response.content

            # Create FilePart with bytes
            file_part = FilePart(
                file=FileWithBytes(
                    name=file_name,
                    mimeType=mime_type,
                    bytes=base64.b64encode(file_bytes).decode(),
                )
            )
            file_parts.append(file_part)
            self.logger.info(f"Downloaded file: {file_name} ({len(file_bytes)} bytes)")

        return file_parts

    @classmethod
    def is_available(cls) -> bool:
        """Check if Slack SDK is available"""
        try:
            import slack_sdk

            return True
        except ImportError:
            return False
