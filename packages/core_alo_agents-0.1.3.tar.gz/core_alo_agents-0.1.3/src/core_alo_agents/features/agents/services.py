from core_alo.services import BaseService
from ..authz.mixins import PermissionsServiceMixin
from .models import AgentConfig
from .permissions import AgentConfigPermissionsMixin


class AgentConfigService(
    AgentConfigPermissionsMixin, PermissionsServiceMixin, BaseService
):
    model = AgentConfig
