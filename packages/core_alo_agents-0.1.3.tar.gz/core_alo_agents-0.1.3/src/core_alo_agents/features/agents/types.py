from pydantic import BaseModel
from typing import Any


class AgentInternalMessage(BaseModel):
    kind: str
    parts: list[Any]


class ToolReturn(BaseModel):
    data: Any = None
    # for internal info; excluded from agent history
    internal: Any | None = None
    error: str | None = None
    message: str | None = None


class MessageTool(BaseModel):
    id: str
    name: str
    args: str | dict | None = None
    content: Any = None
