## Overview

This is an A2A compatible AI agent.

## Endpoints

-   `GET /.well-known/agent.json` - Agent card
-   `GET /.well-known/documentation.md` - This documentation
-   `POST /jsonrpc` - JSON-RPC interface

## Supported Methods

-   `message/send` - Send a message
-   `message/stream` - Stream a message response
