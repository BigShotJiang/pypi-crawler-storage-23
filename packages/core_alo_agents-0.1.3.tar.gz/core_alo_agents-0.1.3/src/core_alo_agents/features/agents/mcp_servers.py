import os
from pydantic_ai.mcp import MCPServerStdio
from .constants import McpServerName


# STDIO usually works only for local dev/usage
# TODO: implement SSE
def get_stdio_mcp_server(server_name: McpServerName) -> MCPServerStdio:
    match server_name:
        case McpServerName.BRAVE_SEARCH:
            return MCPServerStdio(
                "npx",
                ["-y", "@modelcontextprotocol/server-brave-search"],
                env={"BRAVE_API_KEY": os.getenv("BRAVE_API_KEY")},
                tool_prefix=server_name,
            )
        case McpServerName.FETCH:
            return MCPServerStdio(
                "uvx",
                ["mcp-server-fetch"],
                tool_prefix=server_name,
            )
        case McpServerName.LINKEDIN:
            return MCPServerStdio(
                "docker",
                [
                    "run",
                    "-i",
                    "--rm",
                    "-e",
                    "LINKEDIN_EMAIL",
                    "-e",
                    "LINKEDIN_PASSWORD",
                    "stickerdaniel/linkedin-mcp-server",
                ],
                env={
                    "LINKEDIN_EMAIL": os.getenv("LINKEDIN_EMAIL"),
                    "LINKEDIN_PASSWORD": os.getenv("LINKEDIN_PASSWORD"),
                },
                tool_prefix=server_name,
            )
        # From: https://github.com/shadi-fsai/fmp_mcp_server_finance
        # https://playbooks.com/mcp/shadi-fsai-financial-modeling-prep#claude-desktop-setup
        case McpServerName.FMP:
            return MCPServerStdio(
                "uv",
                [
                    "--directory",
                    os.getenv("FMP_MCP_DIR"),
                    "run",
                    "fmp_mcp_server.py",
                ],
                tool_prefix=server_name,
            )
