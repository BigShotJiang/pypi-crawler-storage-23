from pydantic import BaseModel, Field
from core_alo.schemas import BaseSchema, TimeAuditSchemaMixin


class OTLPAction(BaseModel):
    technical_name: str
    label: str


# AgentConfig Schemas
class AgentConfigBase(BaseSchema):
    name: str
    type: str
    description: str
    instructions: str
    enabled_skills: list[str] = []


class AgentConfigCreate(BaseModel):
    name: str
    type: str
    instructions: str
    enabled_skills: list[str] | None = None
    description: str = ""


class AgentConfigCreatePayload(AgentConfigCreate):
    skills_set: list[str] | None = None


class AgentConfigUpdate(BaseModel):
    name: str | None = None
    type: str | None = None
    instructions: str | None = None
    enabled_skills: list[str] | None = None
    description: str | None = None

class AgentConfigUpdatePayload(AgentConfigUpdate):
    skills_set: list[str] | None = None


class AgentConfigPublic(TimeAuditSchemaMixin, AgentConfigBase):
    id: int
    # Computed field: list of skill sets (e.g. 'pdf', 'ppt') inferred
    # from the functions stored in enabled_skills.
    skills_set: list[str] | None = None


class GcsPresignedUrlRequest(BaseModel):
    gcs_path: str = Field(description="GCS file path")
    bucket_name: str = Field(description="GCS bucket name")


class FilePresignedUrlResponse(BaseModel):
    url: str = Field(description="Presigned URL for file access")
    expires_in_minutes: int = Field(description="URL expiration time in minutes")


class ModelConfigResponse(BaseModel):
    """Response schema for model configuration endpoint."""

    default_model: str = Field(description="Default LLM model")
    allowed_models: list[str] = Field(description="List of allowed LLM models")


# Skills Schemas
class SkillFunctionInfo(BaseModel):
    """Information about a single function in a skill."""

    name: str = Field(description="Function name")


class SkillInfo(BaseModel):
    """Information about a single skill."""

    name: str = Field(description="Skill name (e.g., 'pdf', 'ppt')")
    description: str = Field(description="Description of what the skill provides")
    functions: dict[str, str] = Field(
        description="Dictionary mapping function names to their docstrings"
    )


class AvailableSkillsResponse(BaseModel):
    """Response schema for listing all available skills."""

    skills: list[SkillInfo] = Field(description="List of available skills")


# Sandbox Schemas
class StopSandboxRequest(BaseModel):
    """Request schema for stopping a workflow execution sandbox."""

    context_id: str = Field(
        description="The execution context ID (e.g., 'workflow-5-exec-123')"
    )


class StopSandboxResponse(BaseModel):
    """Response schema for stop sandbox endpoint."""

    success: bool = Field(description="Whether the sandbox was stopped successfully")
    message: str = Field(description="Status message")
    sandbox_id: str | None = Field(
        description="The E2B sandbox ID that was stopped", default=None
    )
