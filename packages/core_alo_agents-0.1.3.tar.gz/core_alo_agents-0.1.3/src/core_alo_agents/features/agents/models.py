from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import ARRAY

from core_alo.models import BaseModel, TimeAuditModelMixin


class AgentConfig(TimeAuditModelMixin, BaseModel):
    """Database model for storing agent configurations.

    Allows defining different variations of agents with custom instructions
    that can be loaded dynamically instead of using hardcoded system prompts.
    """

    __tablename__ = "agent_config"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    type: Mapped[str] = mapped_column(
        String(255), unique=True, nullable=False, index=True
    )
    instructions: Mapped[str] = mapped_column(Text, nullable=False)
    enabled_skills: Mapped[list[str]] = mapped_column(ARRAY(String), default=list, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
