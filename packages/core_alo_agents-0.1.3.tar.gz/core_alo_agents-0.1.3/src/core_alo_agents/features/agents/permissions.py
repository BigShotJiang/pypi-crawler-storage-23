from ..authz.permissions import BasePermissionsMixin
from .models import AgentConfig


class AgentConfigPermissionsMixin(BasePermissionsMixin):
    model = AgentConfig

    AUTHZ_DEFAULTS = {
        **BasePermissionsMixin.AUTHZ_DEFAULTS,
    }
