import logging
import re
import ast
from sqlalchemy.orm import Session
from core_alo_agents.config import settings
from e2b_code_interpreter import AsyncSandbox
from pydantic_ai import Agent
from pydantic_ai.models.anthropic import AnthropicModel, AnthropicModelSettings

from ... import skill_registry as registry_module
from ..code_generation.constants import OUTPUT_FOLDER
from ....e2b.models import SandboxModel

CODE_GENERATION_PROMPT = """
You are a Python code generator. Generate executable Python code to fulfill user requests.

**RETURN ONLY PURE PYTHON CODE - NO MARKDOWN, NO EXPLANATIONS, NO CODE FENCES**

Rules:
1. Write clean, executable Python code
2. Store final result in variable called 'result' as a DICTIONARY with keys: 'message' and 'generated_files', or additional keys as needed
3. Use 'output_folder' variable for saving files (always available, points to 'output' directory)
4. ALWAYS track generated files and include them in the result
5. Import libraries as needed: pandas, numpy, matplotlib, seaborn, reportlab, PIL, etc.
6. Include error handling with try-except

Skills:
You can be provided with a set of re-usable functions inside the folder skills. Check in user/skills if there are some python scripts useful to accomplish the task.
If skills are provided, you must use them.

File Locations:
- User uploaded files are located in: /home/user/user_files/
- Previous outputs (if any) are located in: output/ (same as output_folder)
- When user asks to work with uploaded files, look for them in /home/user/user_files/
- When user asks to modify/update previous outputs, check the output_folder

Result Format:
result = {
    "message": "Your summary message here",
    "generated_files": ["output/file1.png", "output/file2.csv"],  # List of generated file paths
    # Additional keys as needed
}

Example for calculation:
import math
factorial_result = math.factorial(10)
result = {
    "message": f"Factorial of 10 is {factorial_result}",
    "generated_files": []
}

Example for file generation:
import matplotlib.pyplot as plt
import os

data = [10, 20, 30, 40, 50]
plt.plot(data)
plt.title('My Chart')

filepath = os.path.join(output_folder, 'chart.png')
plt.savefig(filepath)
plt.close()

result = {
    "message": f"Chart saved to {filepath}",
    "generated_files": [filepath]
}

Example for working with user-uploaded file:
import pandas as pd
import os

# Read user's uploaded CSV file
user_file = '/home/user/user_files/data.csv'
df = pd.read_csv(user_file)

# Process and save result
output_file = os.path.join(output_folder, 'processed_data.csv')
df.describe().to_csv(output_file)

result = {
    "message": f"Processed {len(df)} rows, saved to {output_file}",
    "generated_files": [output_file]
}

Return ONLY the Python code, nothing else.
"""

FIX_CODE_INSTRUCTIONS = """
# You are an elite Python code debugging specialist focused on fixing data analysis errors.

## CRITICAL REQUIREMENTS:
🚨 **RETURN ONLY THE CORRECTED PYTHON CODE - NO MARKDOWN, NO EXPLANATIONS, NO CODE FENCES** 🚨

## Your Mission:
Fix the provided Python code by addressing the specific error while preserving ALL existing logic and functionality.

## Code Fixing Excellence Standards:

### 1. **Error-Only Fixes**
- Fix ONLY the specific error mentioned in the error message and traceback
- Do NOT modify any other logic, variable names, or code structure
- Do NOT add new features or change the analysis approach
- Do NOT remove existing functionality unless it's causing the error
- Preserve all existing imports, variable assignments, and data processing steps

### 2. **Common Error Patterns & Fixes**

#### **Import Errors:**
- Missing imports: Add the missing import statement at the top
- Wrong module names: Correct the module name (e.g., `matplotlib.pyplot` not `matplotlib`)
- Version conflicts: Use compatible function calls

#### **DataFrame Errors:**
- KeyError: Check if column exists before accessing, use `.get()` or conditional logic
- AttributeError: Verify DataFrame methods exist, check for None values
- IndexError: Validate index bounds, handle empty DataFrames

#### **File Path Errors:**
- FileNotFoundError: Ensure correct file paths, check file existence
- PermissionError: Use appropriate file permissions, check directory existence

#### **Data Type Errors:**
- TypeError: Convert data types appropriately (str, int, float)
- ValueError: Validate data before operations, handle edge cases
- AttributeError: Check object types before method calls

#### **Syntax Errors:**
- SyntaxError: Fix indentation, brackets, quotes, colons
- NameError: Define variables before use, fix variable names

### 3. **Error Handling Patterns**
```python
# Add try-catch only if needed to handle the specific error
try:
    # Original problematic code
    result = df['column'].sum()
except KeyError:
    result = "Error: Column 'column' not found in data"
except Exception as e:
    result = f"Error: {str(e)}"
```

### 4. **Preservation Rules**
- Keep all existing variable names exactly the same
- Maintain the same analysis logic and approach
- Preserve all existing comments and documentation
- Keep the same result structure and format
- Maintain all existing file saving operations

## MANDATORY OUTPUT FORMAT:
Return ONLY the corrected executable Python code. No markdown. No explanations. No code fences.

## Remember:
- Fix ONLY the error, change nothing else
- Preserve ALL existing logic and functionality
- Return executable Python code only
- No explanations or markdown formatting
"""


class CodeExecutor:
    """Generate and execute Python code from user queries"""

    def __init__(self, db: Session):
        self.db = db

        self.fix_agent = Agent(
            model=AnthropicModel("claude-sonnet-4-5"),
            model_settings=AnthropicModelSettings(
                max_tokens=8192,
                stop_sequences=[],
            ),
            instructions=FIX_CODE_INSTRUCTIONS,
        )

    async def execute(
        self,
        code: str,
        sandbox: AsyncSandbox,
        sandbox_db: SandboxModel,
        output_folder: str = OUTPUT_FOLDER,
        max_retries: int = 2,
        enabled_skills: list[str] | None = None,
    ) -> dict:
        """
        Execute Python code in the sandbox.

        Args:
            code: Python code to execute
            sandbox: E2B AsyncSandbox instance
            output_folder: Folder to save generated files
            max_retries: Number of retries for auto-installing missing packages
            enabled_skills: List of skill names to inject into sandbox (if not already injected)
            sandbox_db: SandboxModel instance for tracking injected skills

        Returns:
            dict with keys: result, error, generated_files, generated_code
        """

        if enabled_skills and sandbox_db:
            await self._inject_skills_into_sandbox(sandbox, enabled_skills, sandbox_db)

        # Create output folder in sandbox
        setup_code = f"""import os
import sys

# Add skills directory to Python path for imports
sys.path.insert(0, '/home/user')

output_folder = "{output_folder}"
os.makedirs(output_folder, exist_ok=True)
"""

        # Combine setup + generated code
        full_code = setup_code + "\n" + code

        # Try to execute with retries for missing packages
        for attempt in range(max_retries + 1):
            logging.info(
                f"[SimpleCodeExecutor] Executing code (attempt {attempt + 1}/{max_retries + 1})..."
            )
            logging.info(f"[SimpleCodeExecutor] Code:\n{full_code}")

            # Execute the code
            execution = await sandbox.run_code(
                full_code,
                envs={
                    "GEMINI_API_KEY": settings.GEMINI_API_KEY,
                },
            )

            # Check for errors
            if execution.error:
                error_msg = execution.error.value
                error_trace = execution.error.traceback
                logging.error(f"[SimpleCodeExecutor] Error: {error_msg}")

                logging.info("[SimpleCodeExecutor] Attempting to fix code...")
                fixed_code = await self._fix_code(full_code, error_msg, error_trace)
                if fixed_code and fixed_code != full_code:
                    full_code = fixed_code
                    logging.info("[SimpleCodeExecutor] Retrying with fixed code...")
                    continue

                # If last attempt, return error
                return {
                    "result": None,
                    "error": f"Execution failed: {error_msg}",
                    "traceback": error_trace,
                    "generated_files": [],
                    "generated_code": code,
                }

            # Success! Get result
            code_result = await sandbox.run_code("result")
            result_text = code_result.results[0].text if code_result.results else ""

            # Try to parse result as dictionary
            try:
                result = ast.literal_eval(result_text)
            except (ValueError, SyntaxError):
                result = result_text

            # TODO: ?
            # Ensure result is in the expected format
            if isinstance(result, dict):
                message = result.get("message", "")
                generated_files = result.get("generated_files", [])
            else:
                # Fallback for old format or unexpected format
                message = str(result)
                generated_files = []

            all_files = generated_files

            logging.info(f"[SimpleCodeExecutor] Success! Message: {str(message)[:200]}")
            logging.info(
                f"[SimpleCodeExecutor] Generated {len(all_files)} files: {all_files}"
            )

            return {
                "result": message,
                "error": None,
                "generated_files": all_files,
                "generated_code": code,
            }

        # Should not reach here but just in case
        return {
            "result": None,
            "error": "Max retries exceeded",
            "generated_files": [],
            "generated_code": code,
        }

    def _extract_python_code(self, raw_response: str) -> str:
        """Extract pure Python code from LLM response"""
        # Remove ```python ... ``` blocks
        python_block = r"```python\s*\n(.*?)\n```"
        match = re.search(python_block, raw_response, re.DOTALL)
        if match:
            return match.group(1).strip()

        # Remove ``` ... ``` blocks
        code_block = r"```\s*\n(.*?)\n```"
        match = re.search(code_block, raw_response, re.DOTALL)
        if match:
            return match.group(1).strip()

        # Return as-is if no fences found
        return raw_response.strip()

    async def _inject_skills_into_sandbox(
        self, sandbox: AsyncSandbox, enabled_skills: list[str], sandbox_db
    ) -> None:
        """
        Inject enabled skills into the sandbox by uploading skill files and installing dependencies.
        Uses database to track which skills are already injected to avoid redundant work.

        Args:
            sandbox: E2B AsyncSandbox instance
            enabled_skills: List of skill names to inject
            sandbox_db: SandboxModel instance
            db: Database session
        """
        if not enabled_skills:
            return
        
        # Get currently injected skills from database
        injected_skills = set(sandbox_db.injected_skills or [])
        enabled_skills_set = set(enabled_skills)

        skills_to_inject = enabled_skills_set - injected_skills
        if not skills_to_inject:
            logging.info(f"[Skills] All required skills already injected: {enabled_skills}")
            return
        
        logging.info(f"[Skills] Skills to inject: {list(skills_to_inject)}")
        logging.info(f"[Skills] Already injected: {list(injected_skills)}")
        
        # Get skill files and required packages for new skills only
        skill_files = registry_module.skill_registry.get_skill_files(
            list(skills_to_inject)
        )
        
        if not skill_files:
            logging.info("[Skills] No skill files to inject")
            return

        logging.info(f"[Skills] Injecting {len(skill_files)} skill files: {list(skill_files.keys())}")

        # Install required packages first
        if required_packages := registry_module.skill_registry.get_required_packages(enabled_skills):
            logging.info(f"[Skills] Installing required packages: {required_packages}")
            packages_str = " ".join(required_packages)
            install_cmd = f"pip install --quiet {packages_str}"
            
            try:
                result = await sandbox.run_code(install_cmd)
                if result.error:
                    logging.warning(f"[Skills] Package installation had warnings: {result.error}")
                else:
                    logging.info(f"[Skills] Successfully installed packages: {required_packages}")
            except Exception as e:
                logging.error(f"[Skills] Error installing packages: {e}")
                # Continue anyway - packages might already be installed

        # Create skills directory in sandbox
        await sandbox.run_code("import os; os.makedirs('/home/user/skills', exist_ok=True)")

        # Upload each skill file
        for sandbox_path, local_path in skill_files.items():
            try:
                with open(local_path, 'r') as f:
                    skill_content = f.read()
                
                await sandbox.files.write(sandbox_path, skill_content)
                logging.info(f"[Skills] Uploaded {local_path.name} to {sandbox_path}")
            except Exception as e:
                logging.error(f"[Skills] Error uploading {local_path}: {e}")

        # Create __init__.py in skills directory for proper module imports
        init_content = '"""Skills module - Auto-generated"""'
        await sandbox.files.write('/home/user/skills/__init__.py', init_content)
        
        # Update database with newly injected skills
        updated_skills = list(injected_skills | skills_to_inject)
        sandbox_db.injected_skills = updated_skills
        self.db.commit()
        logging.info(f"[Skills] Updated database with injected skills: {updated_skills}")
        
        logging.info("[Skills] Successfully injected skills into sandbox")

    async def _fix_code(self, code: str, error: str, traceback: str = "") -> str:
        """
        Fix Python code based on error message using AI

        Args:
            code: The code that failed
            error: The error message
            traceback: The error traceback

        Returns:
            Fixed code or empty string if fixing failed
        """
        logging.info(f"[CODE-FIX] Attempting to fix error: {error}")

        fix_prompt = (
            "Fix the following Python code that has an error. "
            + f"ORIGINAL CODE:\n{code}\n"
            + f"ERROR MESSAGE:\n{error}\n"
            + f"TRACEBACK:\n{traceback}\n"
            + "Return ONLY the corrected Python code. Fix only the specific error while preserving all existing logic and functionality."
        )

        try:
            response = await self.fix_agent.run(fix_prompt)
            fixed_code = self._extract_python_code(response.output)

            logging.info("[CODE-FIX] Generated fix")
            logging.info(f"[CODE-FIX] Fixed code:\n{fixed_code}")

            return fixed_code
        except Exception as e:
            logging.error(f"[CODE-FIX] Error during code fixing: {e}")
            return ""
