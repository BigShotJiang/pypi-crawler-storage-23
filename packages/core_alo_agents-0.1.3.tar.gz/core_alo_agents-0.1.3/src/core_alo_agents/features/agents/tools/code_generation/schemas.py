from pydantic import BaseModel


class FileUploadInfo(BaseModel):
    filename: str
    mime_type: str
    file_size: int
    path: str | None = None
    error: str | None = None
    gcs_path: str | None = None
