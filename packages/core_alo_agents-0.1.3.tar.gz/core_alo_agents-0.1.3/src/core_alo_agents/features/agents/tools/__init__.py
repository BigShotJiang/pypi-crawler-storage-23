from core_alo.utils import send_email


def send_email_tool(email: str, subject: str, html_content: str) -> bool:
    """
    Send an email to the user.
    """
    response = send_email(email_to=email, subject=subject, html_content=html_content)
    return response.success
