"""
PDF compression skill - Compress PDF files to a target size using iterative optimization by adjusting image quality and DPI settings.
"""

REQUIRED_PACKAGES = ["pymupdf"]

import os
import fitz  # PyMuPDF


def compress_pdf_to_size(
    input_path: str,
    output_path: str,
    target_size_mb: float,
    max_iterations: int = 5,
    tolerance_mb: float = 0.1,
) -> bool:
    """
    Compress a PDF file to approximately the target size using iterative optimization.

    This function compresses PDF files by converting pages to images with adjustable
    quality and DPI settings. It iteratively adjusts compression parameters to achieve
    the target file size within the specified tolerance.

    Args:
        input_path: Path to the input PDF file
        output_path: Path where compressed PDF will be saved
        target_size_mb: Target file size in megabytes
        max_iterations: Maximum number of compression attempts (default: 5)
        tolerance_mb: Acceptable size difference in MB (default: 0.1 MB = 100 KB)

    Returns:
        bool: True if compression was successful, False otherwise

    Example:
        >>> compress_pdf_to_size("large_document.pdf", "compressed.pdf", 2.5)
        Original file size: 5.23 MB
        Target size: 2.50 MB
        Iteration 1: Trying quality 50...
        Output size: 2.45 MB (diff: 0.05 MB)
        ✓ Successfully compressed to target size!
        True
    """

    # Helper function to get file size in MB
    def _get_file_size_mb(file_path: str) -> float:
        """Get file size in megabytes."""
        return os.path.getsize(file_path) / (1024 * 1024)

    # Validate input file exists
    if not os.path.exists(input_path):
        print(f"Error: Input file '{input_path}' does not exist.")
        return False

    input_size = _get_file_size_mb(input_path)
    print(f"Original file size: {input_size:.2f} MB")
    print(f"Target size: {target_size_mb:.2f} MB")

    # If file is already smaller than target, just copy it
    if input_size <= target_size_mb:
        print(f"File is already smaller than target size. No compression needed.")
        doc = fitz.open(input_path)
        doc.save(output_path)
        doc.close()
        return True

    # Calculate compression ratio needed
    compression_ratio = target_size_mb / input_size

    # Start with an initial quality estimate based on compression ratio
    # Quality ranges from 0 (worst) to 100 (best)
    if compression_ratio > 0.8:
        initial_quality = 85
    elif compression_ratio > 0.6:
        initial_quality = 70
    elif compression_ratio > 0.4:
        initial_quality = 50
    elif compression_ratio > 0.2:
        initial_quality = 30
    else:
        initial_quality = 15

    quality = initial_quality
    iteration = 0
    best_output = None
    best_size_diff = float("inf")

    # Iterative compression loop
    while iteration < max_iterations:
        iteration += 1
        print(f"\nIteration {iteration}: Trying quality {quality}...")

        try:
            # Open the input PDF
            doc = fitz.open(input_path)
            output_doc = fitz.open()

            # Create a temporary output path
            temp_output = (
                output_path
                if iteration == max_iterations
                else f"{output_path}.tmp{iteration}"
            )

            # Process each page
            for page_num in range(len(doc)):
                page = doc[page_num]

                # Adjust DPI based on quality to control output size
                # Lower quality = lower DPI = smaller file
                dpi = 72 + (quality * 1.5)  # Range from ~72 to ~214 DPI
                zoom = dpi / 72.0
                mat = fitz.Matrix(zoom, zoom)

                # Render page to pixmap
                pix = page.get_pixmap(matrix=mat, alpha=False)

                # Convert to RGB if needed
                if pix.n > 3:
                    pix = fitz.Pixmap(fitz.csRGB, pix)

                # Compress the pixmap to JPEG bytes
                img_bytes = pix.tobytes(output="jpeg", jpg_quality=quality)

                # Create a new page in output document with same dimensions
                page_rect = page.rect
                new_page = output_doc.new_page(
                    width=page_rect.width, height=page_rect.height
                )

                # Insert the compressed image
                new_page.insert_image(page_rect, stream=img_bytes)

            # Save with compression options
            output_doc.save(
                temp_output,
                garbage=4,  # Maximum garbage collection
                deflate=True,  # Compress streams
                clean=True,  # Clean up unused objects
            )

            doc.close()
            output_doc.close()

            # Check the output size
            output_size = _get_file_size_mb(temp_output)
            size_diff = abs(output_size - target_size_mb)

            print(f"Output size: {output_size:.2f} MB (diff: {size_diff:.2f} MB)")

            # Check if we're within tolerance
            if size_diff <= tolerance_mb:
                print(f"✓ Successfully compressed to target size!")
                if temp_output != output_path:
                    os.rename(temp_output, output_path)
                    # Clean up any previous temp files
                    for i in range(1, iteration):
                        temp_file = f"{output_path}.tmp{i}"
                        if os.path.exists(temp_file):
                            os.remove(temp_file)
                return True

            # Track the best result so far
            if size_diff < best_size_diff:
                best_size_diff = size_diff
                if best_output and os.path.exists(best_output):
                    os.remove(best_output)
                best_output = temp_output
            else:
                if temp_output != output_path and os.path.exists(temp_output):
                    os.remove(temp_output)

            # Adjust quality for next iteration
            if output_size > target_size_mb:
                # Need more compression - reduce quality
                quality = int(quality * 0.75)
                if quality < 10:
                    quality = 10
            else:
                # Too much compression - increase quality
                quality = int(quality * 1.15)
                if quality > 95:
                    quality = 95

        except Exception as e:
            print(f"Error during compression: {e}")
            return False

    # If we exhausted iterations, use the best result
    if best_output:
        print(f"\nReached maximum iterations. Using best result:")
        final_size = _get_file_size_mb(best_output)
        print(f"Final size: {final_size:.2f} MB (target: {target_size_mb:.2f} MB)")

        if best_output != output_path:
            os.rename(best_output, output_path)

        # Clean up temp files
        for i in range(1, max_iterations + 1):
            temp_file = f"{output_path}.tmp{i}"
            if os.path.exists(temp_file) and temp_file != best_output:
                os.remove(temp_file)

        return True

    return False
