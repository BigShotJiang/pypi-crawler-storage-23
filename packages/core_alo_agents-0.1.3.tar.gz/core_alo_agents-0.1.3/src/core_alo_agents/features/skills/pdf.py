"""
PDF processing skills - Tools for reading and extracting data from PDF files.
"""

REQUIRED_PACKAGES = ["pypdf"]

import pypdf
from typing import List, Dict, Any


def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Extract all text from a PDF file.
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        Extracted text as a string
    """
    with open(pdf_path, 'rb') as file:
        pdf_reader = pypdf.PdfReader(file)
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"
    return text


def extract_text_by_page(pdf_path: str) -> List[str]:
    """
    Extract text from each page of a PDF file separately.
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        List of strings, one per page
    """
    with open(pdf_path, 'rb') as file:
        pdf_reader = pypdf.PdfReader(file)
        pages_text = []
        for page in pdf_reader.pages:
            pages_text.append(page.extract_text())
    return pages_text


def get_pdf_metadata(pdf_path: str) -> Dict[str, Any]:
    """
    Extract metadata from a PDF file.
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        Dictionary with metadata (author, title, pages, etc.)
    """
    with open(pdf_path, 'rb') as file:
        pdf_reader = pypdf.PdfReader(file)
        metadata = {
            'num_pages': len(pdf_reader.pages),
            'author': pdf_reader.metadata.get('/Author', 'Unknown'),
            'title': pdf_reader.metadata.get('/Title', 'Unknown'),
            'subject': pdf_reader.metadata.get('/Subject', 'Unknown'),
            'creator': pdf_reader.metadata.get('/Creator', 'Unknown'),
        }
    return metadata
