"""
PowerPoint processing skills - Tools for generating and manipulating PowerPoint slides.
"""

REQUIRED_PACKAGES = ["python-pptx"]

from pptx import Presentation
from typing import List, Dict, Any


def create_presentation(title: str, output_path: str) -> str:
    """
    Create a new PowerPoint presentation with a title slide.
    
    Args:
        title: Title for the first slide
        output_path: Path where to save the presentation
        
    Returns:
        Path to the created presentation
    """
    prs = Presentation()
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    title_placeholder = slide.shapes.title
    title_placeholder.text = title
    
    prs.save(output_path)
    return output_path


def add_content_slide(ppt_path: str, title: str, content: List[str], output_path: str) -> str:
    """
    Add a content slide with bullet points to an existing presentation.
    
    Args:
        ppt_path: Path to existing PowerPoint file
        title: Title for the new slide
        content: List of bullet points to add
        output_path: Path where to save the modified presentation
        
    Returns:
        Path to the saved presentation
    """
    prs = Presentation(ppt_path)
    bullet_slide_layout = prs.slide_layouts[1]  # Layout with title and content
    slide = prs.slides.add_slide(bullet_slide_layout)
    
    title_shape = slide.shapes.title
    title_shape.text = title
    
    body_shape = slide.placeholders[1]
    text_frame = body_shape.text_frame
    
    for i, point in enumerate(content):
        if i == 0:
            text_frame.text = point
        else:
            p = text_frame.add_paragraph()
            p.text = point
            p.level = 0
    
    prs.save(output_path)
    return output_path


def extract_presentation_text(ppt_path: str) -> Dict[int, Dict[str, Any]]:
    """
    Extract all text from a PowerPoint presentation.
    
    Args:
        ppt_path: Path to the PowerPoint file
        
    Returns:
        Dictionary with slide numbers as keys and slide content as values
    """
    prs = Presentation(ppt_path)
    slides_content = {}
    
    for i, slide in enumerate(prs.slides):
        slide_text = {
            'title': '',
            'content': []
        }
        
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                if shape == slide.shapes.title:
                    slide_text['title'] = shape.text
                else:
                    slide_text['content'].append(shape.text)
        
        slides_content[i + 1] = slide_text
    
    return slides_content


def get_presentation_metadata(ppt_path: str) -> Dict[str, Any]:
    """
    Extract metadata from a PowerPoint presentation.
    
    Args:
        ppt_path: Path to the PowerPoint file
        
    Returns:
        Dictionary with metadata (slide count, author, title, etc.)
    """
    prs = Presentation(ppt_path)
    metadata = {
        'num_slides': len(prs.slides),
        'slide_width': prs.slide_width,
        'slide_height': prs.slide_height,
    }
    
    # Try to extract core properties
    core_props = prs.core_properties
    metadata['title'] = core_props.title or 'Unknown'
    metadata['author'] = core_props.author or 'Unknown'
    metadata['subject'] = core_props.subject or 'Unknown'
    
    return metadata
