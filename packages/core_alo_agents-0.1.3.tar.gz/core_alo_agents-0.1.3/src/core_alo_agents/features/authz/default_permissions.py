DEFAULT_PERMISSIONS: dict[str, list[dict]] = {
    "system": [
        {
            "name": "Can send jsonrpc",
            "description": "Can send jsonrpc to the agent",
            "resource_type": "system",
            "action": "send_jsonrpc",
            "has_access": True,
            "role_slugs": ["admins"],
        },
    ],
    "agent_config": [
        {
            "name": "List Agent Config",
            "description": "List all agent configs",
            "resource_type": "agent_config",
            "action": "list",
            "has_access": True,
            "role_slugs": ["admins"],
        },
        {
            "name": "Detail Agent Config",
            "description": "Detail an agent config",
            "resource_type": "agent_config",
            "action": "detail",
            "has_access": True,
            "role_slugs": ["admins"],
        },
        {
            "name": "Create Agent Config",
            "description": "Create new agent configs",
            "resource_type": "agent_config",
            "action": "create",
            "has_access": True,
            "role_slugs": ["admins"],
        },
        {
            "name": "Edit Agent Config",
            "description": "Edit and modify any agent config",
            "resource_type": "agent_config",
            "action": "edit",
            "has_access": True,
            "role_slugs": ["admins"],
        },
        {
            "name": "Delete Agent Config",
            "description": "Delete any agent config",
            "resource_type": "agent_config",
            "action": "delete",
            "has_access": True,
            "role_slugs": ["admins"],
        },
    ],
}
