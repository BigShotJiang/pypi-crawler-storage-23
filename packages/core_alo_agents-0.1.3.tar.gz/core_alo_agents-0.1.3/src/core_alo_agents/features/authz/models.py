from typing import Any
from sqlalchemy import (
    String,
    Boolean,
    UniqueConstraint,
    Index,
)
from sqlalchemy.dialects.postgresql import JSONB, ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from core_alo.models import BaseModel, TimeAuditModelMixin
from .constants import PermissionOperator


class Permission(TimeAuditModelMixin, BaseModel):
    __tablename__ = "authz_permission"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(String(500))

    # Global lvl for built-in actions like list, detail, create, edit, delete
    has_access: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    resource_type: Mapped[str] = mapped_column(
        String(255), index=True, nullable=False
    )  # 'agent'
    action: Mapped[str] = mapped_column(
        String(255), index=True, nullable=False
    )  # 'list'

    # Role slugs that have this permission (from Keycloak)
    role_slugs: Mapped[list[str]] = mapped_column(
        ARRAY(String), nullable=False, server_default="{}"
    )  # ['admins', 'developers']

    # Attribute-based filtering (NULL = wildcard/all resources)
    attribute_field: Mapped[str | None] = mapped_column(String(100))  # 'id', 'slug'
    attribute_value: Mapped[Any | None] = mapped_column(JSONB)  # '101', 'agent-lens'
    attribute_operator: Mapped[str] = mapped_column(
        String(255), default=PermissionOperator.EQUALS, nullable=True
    )

    __table_args__ = (
        Index("ix_perm_lookup", "resource_type", "action"),
        Index("ix_perm_role_slugs", "role_slugs", postgresql_using="gin"),
        # Prevent creating two identical rules.
        UniqueConstraint(
            "resource_type",
            "action",
            "attribute_field",
            "attribute_operator",
            "attribute_value",
            name="uq_permission_logic",
        ),
    )
