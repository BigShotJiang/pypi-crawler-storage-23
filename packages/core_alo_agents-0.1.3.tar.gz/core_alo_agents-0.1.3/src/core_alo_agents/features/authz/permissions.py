import re
from typing import Any
from sqlalchemy import select, or_
from sqlalchemy.sql.expression import ColumnElement

from core_alo.exceptions import HTTPForbiddenException
from .models import Permission
from .constants import PermissionOperator
from .schemas import AuthzDefaultInfo
from ...config import settings


class BasePermissionsMixin:
    """
    Automatic Authorization Mixin.

    EXPECTS:
    - self.model: The SQLAlchemy model class (e.g., Agent)
    - self.user: The User object (with Keycloak roles)
    - self.db: The DB Session
    """

    PLACEHOLDER_PATTERN = re.compile(r"^\$\{(.+)\}$")

    AUTHZ_DEFAULTS: dict[str, AuthzDefaultInfo] = {
        "list": AuthzDefaultInfo(value=False, name="List"),
        "detail": AuthzDefaultInfo(value=False, name="Detail"),
        "read": AuthzDefaultInfo(value=False, name="Read"),
        "create": AuthzDefaultInfo(value=False, name="Create"),
        "edit": AuthzDefaultInfo(value=False, name="Edit"),
        "delete": AuthzDefaultInfo(value=False, name="Delete"),
    }

    @property
    def authz_resource_key(self) -> str:
        if not hasattr(self, "model"):
            raise ValueError(
                f"Class {self.__class__.__name__} must define 'model = MyModel'"
            )

        return self.model.__tablename__

    def should_use_authz(self) -> bool:
        if (
            settings.AUTH_TYPE == "none"
            or not settings.PERMISSIONS_CONFIGURABLE
            or not self.user
            # TODO: decide if need to skip on superusers?
            # or self.user
            # and self.user.is_superuser
        ):
            return False
        return True

    def get_authz_filters(self, action: str) -> list[ColumnElement]:
        if not self.should_use_authz():
            return []

        db_filters = self._build_db_filters(self.authz_resource_key, action)
        return db_filters

    def _build_db_filters(self, resource_type: str, action: str) -> list[ColumnElement]:
        """
        Constructs SQLAlchemy filters based on Permission rows.
        """
        roles = self._get_user_roles()
        if not roles:
            return []

        # Query for specific action permissions
        permissions = self.db.scalars(
            select(Permission).where(
                Permission.role_slugs.overlap(roles),
                Permission.resource_type == resource_type,
                Permission.action == action,
            )
        ).all()
        if not permissions:
            return []

        conditions = []

        for perm in permissions:
            # NULL attribute_field and attribute_value = wildcard (match all)
            if perm.attribute_field is None and perm.attribute_value is None:
                continue

            # Build condition for attribute-based filtering
            if perm.attribute_field and perm.attribute_value is not None:
                current_condition = self._build_attribute_expression(perm)
                if current_condition is not None:
                    conditions.append(current_condition)

        return [or_(*conditions)] if conditions else []

    def check_permission(self, action: str, resource_type: str = None) -> None:
        """
        Verifies permission exists. Raises 403 if not.

        Priority order:
        1. Check for explicit deny (highest priority)
        2. Check for explicit allow in database
        3. Fall back to AUTHZ_DEFAULTS
        4. Deny if no permission found
        """
        if not self.should_use_authz():
            return

        target_resource = resource_type or self.authz_resource_key

        # Step 1: Check for explicit deny on specific action
        if self._has_explicit_deny(target_resource, action):
            raise HTTPForbiddenException(
                detail=f"Permission explicitly denied for '{action}' on '{target_resource}'"
            )

        # Step 2: Check for explicit allow in database
        if self._has_explicit_allow(target_resource, action):
            return

        # Step 3: Fall back to AUTHZ_DEFAULTS
        default_permission = self.AUTHZ_DEFAULTS.get(action)
        if default_permission and default_permission.value:
            return

        # Step 4: Deny if no permission found
        raise HTTPForbiddenException(
            detail=f"You do not have permission to perform '{action}' on '{target_resource}'"
        )

    def _has_explicit_deny(self, resource_type: str, action: str) -> bool:
        """
        Checks if there is a Global Rule with has_access=False
        """
        roles = self._get_user_roles()
        if not roles:
            return False

        query = select(Permission.id).where(
            Permission.role_slugs.overlap(roles),
            Permission.resource_type == resource_type,
            Permission.action == action,
            ~Permission.has_access,  # Explicit DENY
            Permission.attribute_field.is_(
                None
            ),  # Only check Global Denies (NULL = wildcard)
            Permission.attribute_value.is_(None),
        )
        return self.db.scalar(query) is not None

    def _has_explicit_allow(self, resource_type: str, action: str) -> bool:
        """
        Checks if user has any explicit allow permission in database for this action.
        This includes both global (*) and specific resource permissions.
        """
        roles = self._get_user_roles()
        if not roles:
            return False

        query = select(Permission.id).where(
            Permission.role_slugs.overlap(roles),
            Permission.resource_type == resource_type,
            Permission.action == action,
            Permission.has_access,  # Explicit ALLOW
        )
        return self.db.scalar(query) is not None

    def _get_user_roles(self) -> list[str]:
        """Extract roles safely from User object"""
        if hasattr(self.user, "_keycloak_user") and hasattr(
            self.user._keycloak_user, "realm_roles"
        ):
            return self.user._keycloak_user.realm_roles or []
        return []

    def _build_attribute_expression(self, perm: Permission):
        """
        Maps Field + Operator + Value to SQLAlchemy Expression
        """
        if not hasattr(self.model, perm.attribute_field):
            return None

        attr = getattr(self.model, perm.attribute_field)
        val = self._resolve_dynamic_placeholder(perm.attribute_value)
        op = perm.attribute_operator

        match op:
            case PermissionOperator.EQUALS:
                return attr == val
            case PermissionOperator.NOT_EQUALS:
                return attr != val
            case PermissionOperator.GREATER_THAN:
                return attr > val
            case PermissionOperator.LESS_THAN:
                return attr < val
            case PermissionOperator.GREATER_THAN_OR_EQUAL:
                return attr >= val
            case PermissionOperator.LESS_THAN_OR_EQUAL:
                return attr <= val
            case PermissionOperator.IN:
                if not isinstance(val, (list, tuple)):
                    val = [val]
                return attr.in_(val)
            case PermissionOperator.NOT_IN:
                if not isinstance(val, (list, tuple)):
                    val = [val]
                return ~attr.in_(val)
            case _:
                # TODO: decide how to handle this better
                # logging.warning(f"Unknown operator: {op}")
                raise ValueError(f"Unknown operator: {op}")

    def _resolve_dynamic_placeholder(self, value: Any) -> Any:
        """
        Detects if value is a placeholder (e.g. "${user.id}") and resolves it
        against the current runtime context (self.user).
        """
        if not isinstance(value, str):
            return value

        match = self.PLACEHOLDER_PATTERN.match(value)
        if not match:
            return value

        path = match.group(1)
        return self._get_dynamic_context_value(path)

    def _get_dynamic_context_value(self, path: str) -> Any:
        """
        Traverses objects using dot notation.
        Supported roots: "user"
        """
        context = {
            "user": getattr(self, "user", None),
            # more global context can be added here in the future:
            # "request": getattr(self, "request", None),
        }

        parts = path.split(".")
        root_key = parts[0]
        current_obj = context.get(root_key)
        if current_obj is None:
            return None

        # Traverse: .id -> .profile -> .email
        for part in parts[1:]:
            current_obj = (
                current_obj.get(part)
                if isinstance(current_obj, dict)
                else getattr(current_obj, part, None)
            )

            if current_obj is None:
                return None  # Path broken

        return current_obj


class SystemPermissions(BasePermissionsMixin):
    AUTHZ_DEFAULTS = {
        "send_jsonrpc": AuthzDefaultInfo(value=False, name="Send JSONRPC"),
    }

    @property
    def authz_resource_key(self) -> str:
        return "system"
