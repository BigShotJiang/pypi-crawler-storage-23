# core_alo_agents


# Info:
- Internal Agentic Framework to build agents based on A2A, MCP, PydanticAI, FastAPI


# TODO:
- Use as submodule in agent apps (perhaps make as pip package later)
