"""add enabled_skills field to agent_config

Revision ID: 0003
Revises: 0002
Create Date: 2026-01-05 16:21:00

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '0003'
down_revision: Union[str, None] = '0002'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add enabled_skills column to agent_config table
    op.add_column(
        'agent_config',
        sa.Column('enabled_skills', postgresql.ARRAY(sa.String()), nullable=False, server_default='{}')
    )


def downgrade() -> None:
    # Remove enabled_skills column from agent_config table
    op.drop_column('agent_config', 'enabled_skills')
