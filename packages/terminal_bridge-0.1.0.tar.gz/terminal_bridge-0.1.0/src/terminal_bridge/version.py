"""Single source of version truth for terminal-bridge."""

__version__ = "0.1.0"

