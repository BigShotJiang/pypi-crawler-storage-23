"""Remote agent -- runs on the Mac you want to control."""

