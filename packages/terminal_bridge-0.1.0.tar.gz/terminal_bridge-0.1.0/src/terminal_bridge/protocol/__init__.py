"""Protocol message definitions for Terminal Bridge."""

