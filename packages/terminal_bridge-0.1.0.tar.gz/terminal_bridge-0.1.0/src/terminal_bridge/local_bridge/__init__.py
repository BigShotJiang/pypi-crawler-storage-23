"""Local bridge -- runs on the Mac where your AI operates."""

