"""Terminal Bridge test suite."""

