"""Submodules provide multithreaded convenience to parallelize work.

"""
__author__ = 'Paul Landes'

from .stash import *
from .factory import *
