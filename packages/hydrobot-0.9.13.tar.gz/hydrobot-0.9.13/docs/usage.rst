=====
Usage
=====

To use Hydrobot in a project::

    import hydrobot
