hydrobot package
================

Submodules
----------

hydrobot.data\_acquisition module
---------------------------------

.. automodule:: hydrobot.data_acquisition
   :members:
   :undoc-members:
   :show-inheritance:

hydrobot.data\_sources module
-----------------------------

.. automodule:: hydrobot.data_sources
   :members:
   :undoc-members:
   :show-inheritance:

hydrobot.evaluator module
-------------------------

.. automodule:: hydrobot.evaluator
   :members:
   :undoc-members:
   :show-inheritance:

hydrobot.filters module
-----------------------

.. automodule:: hydrobot.filters
   :members:
   :undoc-members:
   :show-inheritance:

hydrobot.plotter module
-----------------------

.. automodule:: hydrobot.plotter
   :members:
   :undoc-members:
   :show-inheritance:

hydrobot.processor module
-------------------------

.. automodule:: hydrobot.processor
   :members:
   :undoc-members:
   :show-inheritance:

hydrobot.testicle module
------------------------

.. automodule:: hydrobot.testicle
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: hydrobot
   :members:
   :undoc-members:
   :show-inheritance:
