SELECT TOP (1) [SiteInfo]
  FROM [hilltop].[dbo].[Sites]
  WHERE SiteName = :site
