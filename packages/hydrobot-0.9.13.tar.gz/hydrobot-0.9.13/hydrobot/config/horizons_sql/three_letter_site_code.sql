SELECT TOP (1) [AuxName2]
FROM [dbo].[Sites]
WHERE SiteName = :site
