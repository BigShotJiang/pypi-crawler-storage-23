"""Top-level package for Hydro Processing Tools."""

__author__ = """Nic Mostert"""
__email__ = "nicolas.mostert@horizons.govt.nz"
__version__ = "0.9.13"
