"""Events module."""
