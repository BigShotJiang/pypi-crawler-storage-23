"""CUI widgets module."""
