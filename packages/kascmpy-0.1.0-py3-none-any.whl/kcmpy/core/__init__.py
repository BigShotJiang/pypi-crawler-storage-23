"""Core module."""
