from .ge_exception import GeException

class GeNotAuthenticatedError(GeException):
    """Error raised when the user is not Not Authenticated"""
    pass