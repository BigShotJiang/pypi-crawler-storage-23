from .ge_exception import GeException

class GeClientDisconnectedError(GeException):
    """Error raised when the client is disconnected"""
    pass
