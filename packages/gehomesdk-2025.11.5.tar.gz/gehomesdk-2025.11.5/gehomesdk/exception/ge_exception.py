class GeException(Exception):
    """ Base class for all other custom exceptions """
    pass