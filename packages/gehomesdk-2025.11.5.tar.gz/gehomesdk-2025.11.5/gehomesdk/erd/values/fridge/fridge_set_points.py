from typing import NamedTuple

class FridgeSetPoints(NamedTuple):
    fridge: int
    freezer: int
