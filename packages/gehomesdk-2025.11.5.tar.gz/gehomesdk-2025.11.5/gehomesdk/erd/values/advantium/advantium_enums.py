import enum
from typing import Optional

@enum.unique
class AdvantiumCoolingFanStatus(enum.Enum):
    OFF = 0
    ON = 1

    def boolify(self) -> Optional[bool]:
        return self == AdvantiumCoolingFanStatus.ON

@enum.unique
class AdvantiumTerminationReason(enum.Enum):
    UNKNOWN = 0
    COOK_TIME_COMPLETE = 1
    USER_CANCELED = 2
    MAX_TIME_SHUTOFF = 3
    DOOR_OPENENED_WHILE_SENSING = 4
    FAULT = 5

@enum.unique
class AdvantiumWarmStatus(enum.IntEnum):
    OFF = 0
    CRISP = 1
    MOIST = 2
    UNKNOWN = 255

    @classmethod
    def _missing_(cls, value):
        if value == 223:
            return cls.OFF
        # fall back to default behavior -> raises ValueError
        return super()._missing_(value)

@enum.unique
class AdvantiumDoorStatus(enum.Enum):
    OPEN = 0
    CLOSED = 1

    def boolify(self) -> Optional[bool]:
        return self == AdvantiumDoorStatus.OPEN    

@enum.unique
class AdvantiumCookAction(enum.IntEnum):
    STOP = 0
    START = 1
    UPDATED = 2
    PAUSE = 3
    RESUME = 4
    UNKNOWN = 255

    @classmethod
    def _missing_(cls, value):
        if value in (20, 178):
            return cls.STOP
        # fall back to default behavior -> raises ValueError
        return super()._missing_(value)

@enum.unique
class AdvantiumCookMode(enum.IntEnum):
    NO_MODE = 0
    CONVECTION_BAKE = 1
    BROIL = 2
    MICROWAVE = 3
    MICROWAVE_SENSOR = 4
    MICROWAVE_STAGED = 5
    PRECISION_COOK = 6
    PRECISION_COOK_STAGED = 7
    PRECISION_COOK_CUSTOM = 8
    WARM = 9
    PROOF = 10
    TOAST = 11
    STEAM_CLEAN = 12
    MICROWAVE_SLOW_COOK = 13
    UNKNOWN = 255

    @classmethod
    def _missing_(cls, value):
        if value in (153,223,253):
            return cls.NO_MODE
        # fall back to default behavior -> raises ValueError
        return super()._missing_(value)


@enum.unique
class AdvantiumOvenLightStatus(enum.Enum):
    OFF = 0
    ON = 1

    def boolify(self) -> Optional[bool]:
        return self == AdvantiumOvenLightStatus.ON    

@enum.unique
class AdvantiumPreheatStatus(enum.Enum):
    NO_PREHEAT = 0
    PREHEAT_ACTIVE = 1
    PREHEAT_COMPLETE = 2

@enum.unique
class AdvantiumSensingActive(enum.Enum):
    INACTIVE = 0
    ACTIVE = 1

    def boolify(self) -> Optional[bool]:
        return self == AdvantiumSensingActive.ACTIVE    
