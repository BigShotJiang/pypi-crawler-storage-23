from typing import NamedTuple


class ErdWaterHeaterMinMaxTemperature(NamedTuple):
    lower: float
    upper: float
