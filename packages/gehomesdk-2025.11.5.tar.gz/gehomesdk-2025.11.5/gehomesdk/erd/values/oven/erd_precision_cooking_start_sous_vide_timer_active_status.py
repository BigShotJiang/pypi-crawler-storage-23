import enum

@enum.unique
class ErdPrecisionCookingStartSousVideTimerActiveStatus(enum.Enum):
    NA = -1
    INACTIVE = 0
    ACTIVE = 1
