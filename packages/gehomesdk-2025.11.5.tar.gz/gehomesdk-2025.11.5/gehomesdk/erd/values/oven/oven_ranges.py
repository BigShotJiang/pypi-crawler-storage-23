from typing import NamedTuple

class OvenRanges(NamedTuple):
    lower: int
    upper: int

