def print_usage():
    print('''\033[92m🌟 Successfully installed splashcodex-api-manager v5.0!\033[0m
\033[96m📚 Documentation: https://pypi.org/project/splashcodex-api-manager/\033[0m

\033[93m🚀 Quick Start (Gemini Preset):\033[0m
import asyncio
from splashcodex_api_manager.presets.gemini import GeminiManager
from splashcodex_api_manager.core.types import ExecuteOptions

async def main():
    gemini = await GeminiManager.get_instance()

    # Automatically handles key rotation on failure (e.g. 429 quota limits)
    response = await gemini.execute(
        lambda key: my_llm_call(key, "Hello!"),
        ExecuteOptions(maxRetries=3)
    )

asyncio.run(main())

\033[95m💡 Tip: Provide GOOGLE_GEMINI_API_KEY in your environment variables.\033[0m
''')

if __name__ == '__main__':
    print_usage()
