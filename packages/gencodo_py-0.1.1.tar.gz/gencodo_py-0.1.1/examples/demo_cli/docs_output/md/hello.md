# hello

Say hello to the world

**Usage:**

```
democli hello
```

## Overview

Prints a friendly hello message to standard output.

This is the simplest possible command with no arguments.

## Examples

**Say hello**

```
democli hello
```

## See also

- [farewell](farewell.md)
- [greet](greet.md)
