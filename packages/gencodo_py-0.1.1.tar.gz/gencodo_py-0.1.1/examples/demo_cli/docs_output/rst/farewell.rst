.. _ref_farewell:

farewell
========

Say goodbye

**Usage:**

.. code-block:: bash

   democli farewell [--formal]

Overview
--------

Prints a farewell message. Supports formal and informal styles.

Options
-------

.. option:: --formal

      Use formal farewell style

   Default: ``False``

Examples
--------

**Say farewell**

.. code-block:: bash

   democli farewell

**Formal farewell**

.. code-block:: bash

   democli farewell --formal

See also
--------

- :ref:`greet <ref_greet>`
- :ref:`hello <ref_hello>`
