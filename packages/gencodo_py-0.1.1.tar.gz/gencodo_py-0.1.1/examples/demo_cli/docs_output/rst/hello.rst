.. _ref_hello:

hello
=====

Say hello to the world

**Usage:**

.. code-block:: bash

   democli hello

Overview
--------

Prints a friendly hello message to standard output.

This is the simplest possible command with no arguments.

Examples
--------

**Say hello**

.. code-block:: bash

   democli hello

See also
--------

- :ref:`farewell <ref_farewell>`
- :ref:`greet <ref_greet>`
