# -*- coding: utf-8 -*-
"""
🦞💥 OpenClaw Uninstaller
温柔地说再见
"""

__version__ = "1.0.0"
__author__ = "Duka Works"
__email__ = "chenzhy.bj@gmail.com"
