from unittest.mock import patch, MagicMock
from orion_cache import redis_cache


def test_cache_miss_then_hit():
    mock_client = MagicMock()
    mock_client.get.return_value = None  # first call is a miss

    with patch("orion_cache.cache.get_client", return_value=mock_client):
        @redis_cache(ttl=60)
        def get_data(name):
            return {"name": name}

        result = get_data("ali")
        assert result == {"name": "ali"}
        mock_client.setex.assert_called_once()


def test_cache_hit_returns_cached():
    import json
    mock_client = MagicMock()
    mock_client.get.return_value = json.dumps({"name": "ali"})

    with patch("orion_cache.cache.get_client", return_value=mock_client):
        @redis_cache(ttl=60)
        def get_data(name):
            raise Exception("should not be called")

        result = get_data("ali")
        assert result == {"name": "ali"}