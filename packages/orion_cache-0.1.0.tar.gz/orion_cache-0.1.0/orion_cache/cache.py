import json
import logging
import functools
from typing import Callable, Any

import redis

from .config import REDIS_URL, DEFAULT_TTL

logger = logging.getLogger(__name__)

_client: redis.Redis | None = None


def get_client() -> redis.Redis:
    """Returns a singleton Redis client."""
    global _client
    if _client is None:
        _client = redis.from_url(REDIS_URL, decode_responses=True, socket_timeout=2)
    return _client


def redis_cache(ttl: int = DEFAULT_TTL) -> Callable:
    """
    Decorator that caches a function's return value in Redis.

    Usage:
        @redis_cache(ttl=120)
        def get_orders(customer):
            return db.query(...)
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            key = f"{func.__name__}:{args}:{kwargs}"
            client = get_client()

            try:
                cached = client.get(key)
                if cached is not None:
                    logger.debug("Cache HIT: %s", key)
                    return json.loads(cached)
            except redis.RedisError as e:
                logger.warning("Cache read failed, falling through to function. Error: %s", e)

            logger.debug("Cache MISS: %s", key)
            result = func(*args, **kwargs)

            try:
                client.setex(key, ttl, json.dumps(result, default=str))
            except redis.RedisError as e:
                logger.warning("Cache write failed. Error: %s", e)

            return result
        return wrapper
    return decorator


def clear_all_caches(pattern: str = "*") -> int:
    """
    Deletes all keys matching the given pattern.
    Defaults to clearing everything. Use a pattern like 'get_orders:*' to be selective.
    Returns number of deleted keys.
    """
    client = get_client()
    try:
        cursor = 0
        deleted = 0
        while True:
            cursor, keys = client.scan(cursor, match=pattern, count=100)
            if keys:
                client.delete(*keys)
                deleted += len(keys)
            if cursor == 0:
                break
        logger.info("Cleared %d cache keys (pattern: %s)", deleted, pattern)
        return deleted
    except redis.RedisError as e:
        logger.error("Cache clear failed. Error: %s", e)
        return 0