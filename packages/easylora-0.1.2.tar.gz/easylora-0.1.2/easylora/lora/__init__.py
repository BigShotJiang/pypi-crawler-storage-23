"""LoRA / QLoRA adapter management."""
