"""
Empty setup.py for toporequires3
"""
from setuptools import setup

setup(
    name="toporequires3",
    version="0.0.0",
    description="Empty placeholder package - reserved name",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
