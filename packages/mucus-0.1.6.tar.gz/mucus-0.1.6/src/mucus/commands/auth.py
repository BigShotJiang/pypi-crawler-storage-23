import random

import mucus.command


class Command(mucus.command.Command):
    def __call__(self, client, command, **kwargs):
        if command['args']:
            client.auth.arl = command['args']
        client.post('deezer_userAutolog', json={
            'APP_NAME': 'Deezer',
            'APPLICATION_ID': 632384,
            'AUTHORIZE_UNLOGGED': True,
            'CHECKFORM': True,
            'DEVICE_TOKEN': ''.join(random.choice('0123456789abcdef') for _ in range(64))
        })
