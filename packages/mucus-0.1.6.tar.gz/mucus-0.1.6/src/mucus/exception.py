class MucusException(Exception):
    pass


class Exit(MucusException):
    pass


class NoMedia(MucusException):
    pass


class NoSource(MucusException):
    pass


class NoSuchCommand(MucusException):
    pass


class DeezerError(MucusException):
    pass


class DeezerAuthError(DeezerError):
    pass


class DeezerStreamError(DeezerError):
    pass
