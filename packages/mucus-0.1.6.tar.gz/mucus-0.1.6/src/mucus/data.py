import pathlib
import yaml


def path(filename=None):
    path = pathlib.Path().home().joinpath('.local', 'share', 'mucus')
    if filename is not None:
        path = path.joinpath(filename)
    return path


def load(filename='data.yaml'):
    try:
        with path(filename).open('r') as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        return {}


def dump(data, filename='data.yaml'):
    path().mkdir(parents=True, exist_ok=True)
    with path(filename).open('w') as f:
        yaml.dump(data, f)
