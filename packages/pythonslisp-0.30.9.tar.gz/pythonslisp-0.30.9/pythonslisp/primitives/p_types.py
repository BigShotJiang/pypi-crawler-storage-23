from fractions import Fraction
from typing import Any, Callable

from pythonslisp.Environment import Environment
from pythonslisp.LispAST import ( LSymbol, LNUMBER, LCallable, LFunction, LMacro, LPrimitive,
                                   LContinuation, prettyPrint, prettyPrintSExpr )
from pythonslisp.LispAST import L_T, L_NIL
from pythonslisp.LispExceptions import LispRuntimeFuncError
from pythonslisp.LispParser import ParseError


def _eql( a: Any, b: Any ) -> bool:
   """CL eql: symbols by name, numbers by type+value, everything else by identity."""
   if isinstance(a, LSymbol) and isinstance(b, LSymbol):
      return a.strval == b.strval
   if type(a) is type(b) and isinstance(a, (int, float, Fraction)):
      return a == b
   return a is b

def _equal( a: Any, b: Any ) -> bool:
   """CL equal: recursive structural equality; falls back to eql at leaves."""
   if isinstance(a, list) and isinstance(b, list):
      return len(a) == len(b) and all(_equal(x, y) for x, y in zip(a, b))
   if isinstance(a, str) and isinstance(b, str):
      return a == b
   if isinstance(a, dict) and isinstance(b, dict):
      return ( set(a.keys()) == set(b.keys()) and
               all(_equal(a[k], b[k]) for k in a) )
   return _eql(a, b)

def _equalp( a: Any, b: Any ) -> bool:
   """CL equalp: equal + case-insensitive strings + cross-type numbers."""
   if isinstance(a, list) and isinstance(b, list):
      return len(a) == len(b) and all(_equalp(x, y) for x, y in zip(a, b))
   if isinstance(a, str) and isinstance(b, str):
      return a.lower() == b.lower()
   if isinstance(a, (int, float, Fraction)) and isinstance(b, (int, float, Fraction)):
      return a == b
   if isinstance(a, dict) and isinstance(b, dict):
      return ( set(a.keys()) == set(b.keys()) and
               all(_equalp(a[k], b[k]) for k in a) )
   return _eql(a, b)


def register(primitive, parseLispString: Callable) -> None:

   @primitive( 'numberp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_numberp( env: Environment, *args ) -> Any:
      """Returns t if expr is a number otherwise nil."""
      return L_T if isinstance( args[0], LNUMBER ) else L_NIL

   @primitive( 'integerp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_integerp( env: Environment, *args ) -> Any:
      """Returns t if expr is an integer otherwise nil."""
      return L_T if isinstance( args[0], int ) else L_NIL

   @primitive( 'rationalp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_rationalp( env: Environment, *args ) -> Any:
      """Returns t if expr is an integer or fraction otherwise nil."""
      return L_T if isinstance( args[0], (int,Fraction) ) else L_NIL

   @primitive( 'floatp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_floatp( env: Environment, *args ) -> Any:
      """Returns t if expr is a float otherwise nil."""
      return L_T if isinstance( args[0], float ) else L_NIL

   @primitive( 'symbolp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_symbolp( env: Environment, *args ) -> Any:
      """Returns t if expr is a symbol otherwise nil."""
      return L_T if isinstance( args[0], LSymbol ) else L_NIL

   @primitive( 'symbol-name', '<symbol>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_symbol_name( env: Environment, *args ) -> Any:
      """Returns the name of a symbol as a string."""
      if not isinstance( args[0], LSymbol ):
         raise LispRuntimeFuncError( LP_symbol_name, 'Argument 1 must be a Symbol.' )
      return args[0].strval

   @primitive( 'atom', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_atom( env: Environment, *args ) -> Any:
      """Returns t if expr is an atom (int,float,string,map or nil) otherwise nil."""
      arg = args[0]
      if isinstance(arg, list):
         return L_T if len(arg) == 0 else L_NIL
      return L_T

   @primitive( 'listp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_listp( env: Environment, *args ) -> Any:
      """Returns t if expr is a list otherwise nil."""
      return L_T if isinstance(args[0], list) else L_NIL

   @primitive( 'mapp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_mapp( env: Environment, *args ) -> Any:
      """Returns t if expr is a map otherwise nil."""
      return L_T if isinstance(args[0], dict) else L_NIL

   @primitive( 'stringp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_stringp( env: Environment, *args ) -> Any:
      """Returns t if expr is a string otherwise nil."""
      return L_T if isinstance( args[0], str ) else L_NIL

   @primitive( 'functionp', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_functionp( env: Environment, *args ) -> Any:
      """Returns t if expr is a function otherwise nil."""
      return L_T if isinstance( args[0], LFunction ) else L_NIL

   @primitive( 'macrop', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_macrop( env: Environment, *args ) -> Any:
      """Returns t if expr is a macro otherwise nil."""
      return L_T if isinstance( args[0], LMacro ) else L_NIL

   @primitive( 'type-of', '<sexpr>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_typeof( env: Environment, *args ) -> Any:
      """Returns the type of its argument as a symbol (CL type-of conventions)."""
      arg = args[0]
      if isinstance( arg, list ):
         return LSymbol('NULL') if len(arg) == 0 else LSymbol('CONS')
      elif isinstance( arg, int ):
         return LSymbol('INTEGER')
      elif isinstance( arg, float ):
         return LSymbol('FLOAT')
      elif isinstance( arg, Fraction ):
         return LSymbol('RATIO')
      elif isinstance( arg, str ):
         return LSymbol('STRING')
      elif isinstance( arg, LSymbol ):
         return LSymbol('SYMBOL')
      elif isinstance( arg, dict ):
         struct_type = arg.get('STRUCT-TYPE')
         return struct_type if struct_type is not None else LSymbol('MAP')
      elif isinstance( arg, LFunction ):
         return LSymbol('FUNCTION')
      elif isinstance( arg, LMacro ):
         return LSymbol('MACRO')
      elif isinstance( arg, LPrimitive ):
         return LSymbol('PRIMITIVE')
      elif isinstance( arg, LContinuation ):
         return LSymbol('CONTINUATION')
      else:
         return LSymbol('T')

   @primitive( 'not', '<boolean>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_not( env: Environment, *args ) -> Any:
      """Returns t if the argument is nil otherwise returns nil."""
      arg1 = args[0]
      return L_T if (isinstance(arg1,list) and (len(arg1)==0)) else L_NIL

   @primitive( 'eq', '<a> <b>',
               min_args=2, max_args=2, arity_msg='2 arguments expected.' )
   def LP_eq( env: Environment, *args ) -> Any:
      """Returns t if the two values are the same object otherwise nil.
For numbers and strings uses value equality as a pragmatic choice since
Python does not guarantee object identity for equal primitive values."""
      arg1, arg2 = args
      if isinstance(arg1, LSymbol) and isinstance(arg2, LSymbol):
         return L_T if (arg1.strval == arg2.strval) else L_NIL
      if isinstance(arg1, (int, float, str)):
         return L_T if (arg1 == arg2) else L_NIL
      return L_T if (arg1 is arg2) else L_NIL

   @primitive( 'eql', '<a> <b>',
               min_args=2, max_args=2, arity_msg='2 arguments expected.' )
   def LP_eql( env: Environment, *args ) -> Any:
      """Returns t if a and b are eql: symbols with the same name; numbers of the
same type with the same value (so 1 and 1.0 are not eql); or any other objects
that are the same (identical) object."""
      return L_T if _eql(args[0], args[1]) else L_NIL

   @primitive( 'equal', '<a> <b>',
               min_args=2, max_args=2, arity_msg='2 arguments expected.' )
   def LP_equalCL( env: Environment, *args ) -> Any:
      """Returns t if a and b are structurally equal.  Recursively compares lists
element by element and strings by content.  Uses eql at the leaves so numbers
must be the same type: (equal 1 1.0) is nil."""
      return L_T if _equal(args[0], args[1]) else L_NIL

   @primitive( 'equalp', '<a> <b>',
               min_args=2, max_args=2, arity_msg='2 arguments expected.' )
   def LP_equalp( env: Environment, *args ) -> Any:
      """Returns t if a and b are equalp.  Like equal but case-insensitive for
strings and type-insensitive for numbers: (equalp 1 1.0) is t,
(equalp \"ABC\" \"abc\") is t."""
      return L_T if _equalp(args[0], args[1]) else L_NIL

   @primitive( '=', '<expr1> <expr2> ...',
               min_args=2, arity_msg='2 or more arguments expected.' )
   def LP_equal( env: Environment, *args ) -> Any:
      """Returns t if the two exprs are the same value otherwise nil."""

      prior = None
      for mbr in args:
         if prior is not None:
            if not( prior == mbr ):
               return L_NIL
         prior = mbr

      return L_T

   @primitive( '/=', '<expr1> <expr2> ...',
               min_args=2, arity_msg='2 or more arguments expected.' )
   def LP_notEqual( env: Environment, *args ) -> Any:
      """Returns t if the two exprs are different values otherwise nil."""

      prior = None
      for mbr in args:
         if prior is not None:
            if not( prior != mbr ):
               return L_NIL
         prior = mbr

      return L_T

   @primitive( '<', '<expr1> <expr2> ...',
               min_args=2, arity_msg='2 or more arguments expected.' )
   def LP_less( env: Environment, *args ) -> Any:
      """Returns t if the arguments are in ascending order."""

      prior = None
      try:
         for mbr in args:
            if prior is not None:
               if not( prior < mbr ):
                  return L_NIL
            prior = mbr
      except TypeError:
         raise LispRuntimeFuncError( LP_less, 'Invalid argument.  Arguments are not comparable.' )

      return L_T

   @primitive( '<=', '<expr1> <expr2> ...',
               min_args=2, arity_msg='2 or more arguments expected.' )
   def LP_lessOrEqual( env: Environment, *args ) -> Any:
      """Returns t if the adjacent arguments are less-than-or-equal otherwise nil."""

      prior = None
      try:
         for mbr in args:
            if prior is not None:
               if not( prior <= mbr ):
                  return L_NIL
            prior = mbr
      except TypeError:
         raise LispRuntimeFuncError( LP_lessOrEqual, 'Invalid argument.  Arguments are not comparable.' )

      return L_T

   @primitive( '>', '<expr1> <expr2> ...',
               min_args=2, arity_msg='2 or more arguments expected.' )
   def LP_greater( env: Environment, *args ) -> Any:
      """Returns t if the arguments are in descending order otherwise nil."""

      prior = None
      try:
         for mbr in args:
            if prior is not None:
               if not( prior > mbr ):
                  return L_NIL
            prior = mbr
      except TypeError:
         raise LispRuntimeFuncError( LP_greater, 'Invalid argument.  Arguments are not comparable.' )

      return L_T

   @primitive( '>=', '<expr1> <expr2> ...',
               min_args=2, arity_msg='2 or more arguments expected.' )
   def LP_greaterOrEqual( env: Environment, *args ) -> Any:
      """Returns t if the adjacent arguments are greater-than-or-equal otherwise nil."""

      prior = None
      try:
         for mbr in args:
            if prior is not None:
               if not( prior >= mbr ):
                  return L_NIL
            prior = mbr
      except TypeError:
         raise LispRuntimeFuncError( LP_greaterOrEqual, 'Invalid argument.  Arguments are not comparable.' )

      return L_T

   @primitive( 'float', '<number>',
               min_args=1, max_args=1, arity_msg='1 argument expected.' )
   def LP_float( env: Environment, *args ) -> Any:
      """Returns val as a float.  Val can be any number type or a string containing a valid lisp float."""
      try:
         return float(args[0])
      except (ValueError, TypeError):
         raise LispRuntimeFuncError( LP_float, 'Invalid argument.' )

   @primitive( 'integer', '<number> &optional (<base> 10)',
               min_args=1, max_args=2, arity_msg='1 or 2 arguments expected.' )
   def LP_integer( env: Environment, *args ) -> Any:
      """Returns val as an integer.  Val can be any number type or a string containing a valid lisp integer."""
      try:
         return int(*args)
      except (TypeError, ValueError):
         raise LispRuntimeFuncError( LP_integer, 'Invalid argument.' )

   @primitive( 'rational', '<number>',
               min_args=1, max_args=1, arity_msg='Exactly 1 argument expected.' )
   def LP_rational( env: Environment, *args ) -> Any:
      """Returns its argument as a fraction.  Val can be any number or a string
containing a valid lisp number that can be expressed as a fraction."""
      try:
         return Fraction(args[0])
      except (IndexError, TypeError, ValueError):
         raise LispRuntimeFuncError( LP_rational, 'Invalid argument.' )

   @primitive( 'string', '<object1> <object2> ...',
               min_args=1, arity_msg='1 or more arguments expected.' )
   def LP_string( env: Environment, *args ) -> Any:
      """PrettyPrints as programmer readable strings each argument object and
concatenates the results to form a new string."""

      resultStrs = [ prettyPrintSExpr(sExpr) for sExpr in args ]
      return ''.join(resultStrs)

   @primitive( 'ustring', '<object1> <object2> ...',
               min_args=1, arity_msg='1 or more arguments expected.' )
   def LP_ustring( env: Environment, *args ) -> Any:
      """PrettyPrints as user readable strings each argument object and
concatenates the results to form a new string."""

      resultStrs = [ prettyPrint(sExpr) for sExpr in args ]
      return ''.join(resultStrs)

   @primitive( 'symbol', '<string1> <string2> ...',
               min_args=1, arity_msg='1 or more string argument expected.' )
   def LP_symbol( env: Environment, *args ) -> Any:
      """PrettyPrints as user readable strings each argument object and
concatenates the results to form a new string which is used to define a new
symbol object."""

      strList = [ prettyPrint(arg) for arg in args ]
      symstr = ''.join(strList)
      try:
         parsed = parseLispString(symstr)
      except ParseError:
         raise LispRuntimeFuncError( LP_symbol, f'The resulting string "{symstr}" is not a valid Lisp symbol.' )
      sym = parsed[1] if isinstance(parsed, list) and len(parsed) == 2 else parsed
      if not isinstance(sym, LSymbol):
         raise LispRuntimeFuncError( LP_symbol, f'The resulting string "{symstr}" is not a valid Lisp symbol.' )
      return sym
