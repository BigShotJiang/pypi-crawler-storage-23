import sys
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
import pymysql
from PyQt6.QtWidgets import (QApplication, QMainWindow, QStackedWidget, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QSpinBox, QScrollArea, QGridLayout,
    QFrame, QGroupBox, QMessageBox, QRadioButton, QButtonGroup, QTextEdit, QFormLayout)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QPixmap

IMG_DIR = Path(__file__).parent

DB = {"host": "localhost", "user": "root", "password": "0210", "database": "shop", "charset": "utf8mb4", "cursorclass": pymysql.cursors.DictCursor}

class conn:
    """Работа с реляционной БД (ТЗ п.6): товары, пользователи, заказы, адреса."""
    def __enter__(self):
        self.c = pymysql.connect(**DB)
        return self.c
    def __exit__(self, *a):
        if a[0]: self.c.rollback()
        else: self.c.commit()
        self.c.close()

# Корзина
cart = {}
def cart_add(p, q=1):
    i = p["id"]
    if i in cart: cart[i]["q"] += q
    else: cart[i] = {"p": p, "q": q}
def cart_del(i): cart.pop(i, None)
def cart_upd(i, d):
    if i in cart:
        cart[i]["q"] += d
        if cart[i]["q"] <= 0: del cart[i]
def cart_items(): return list(cart.values())
def cart_total(): return sum(x["p"]["price"]*x["q"] for x in cart.values())
def cart_clear(): cart.clear()

def _hash_password(password: str) -> str:
    """Хеширование пароля (ТЗ п.4 — безопасное хранение)."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

# === Стили ===
BTN = "QPushButton{background:#2c5aa0;color:white;border:none;padding:8px 16px;border-radius:4px;} QPushButton:hover{background:#3d6bb5;}"

def load_img(path, size=60):
    name = (path or "img1.png").replace(".png", "").replace(".jpg", "")
    for ext in [".png", ".jpg", ".jpeg"]:
        f = IMG_DIR / (name + ext)
        if f.exists():
            px = QPixmap(str(f))
            if not px.isNull():
                return px.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
    return None

class ProductCard(QFrame):
    def __init__(self, p, on_add):
        super().__init__()
        self.setFrameStyle(QFrame.Shape.Box)
        self.setStyleSheet("background:white;border-radius:6px;padding:6px;")
        self.setFixedHeight(180)
        ly = QHBoxLayout(self)
        img_lbl = QLabel()
        px = load_img(p.get("photo_path") or "img1.png")
        if px: img_lbl.setPixmap(px); img_lbl.setFixedSize(60, 60)
        ly.addWidget(img_lbl)
        right = QVBoxLayout()
        right.addWidget(QLabel(p["name"][:35]+".." if len(p["name"])>35 else p["name"], font=QFont("",10,QFont.Weight.Bold)))
        right.addWidget(QLabel(f"{p['material']} | {p['manufacturer']} | {p['price']:.0f} ₽"))
        r = QHBoxLayout(); sp = QSpinBox(); sp.setRange(1,99); sp.setValue(1)
        b = QPushButton("В корзину"); b.setStyleSheet(BTN); b.clicked.connect(lambda: on_add(p, sp.value()))
        r.addWidget(sp); r.addWidget(b); right.addLayout(r)
        ly.addLayout(right)

class CatalogView(QWidget):
    def __init__(self, nav):
        super().__init__()
        self.nav = nav
        ly = QVBoxLayout(self)
        t = QHBoxLayout(); t.addWidget(QLabel("Каталог")); t.addStretch()
        self.user_lbl = QLabel("Гость"); t.addWidget(self.user_lbl)
        self.login_btn = QPushButton("Войти"); self.login_btn.setStyleSheet(BTN)
        self.login_btn.clicked.connect(lambda: nav.go("auth")); t.addWidget(self.login_btn)
        self.logout_btn = QPushButton("Выйти"); self.logout_btn.setFlat(True)
        self.logout_btn.clicked.connect(lambda: self._logout()); t.addWidget(self.logout_btn)
        b = QPushButton("Корзина"); b.setStyleSheet(BTN); b.clicked.connect(lambda: nav.go("cart")); t.addWidget(b)
        ly.addLayout(t)
        # фильтры
        f = QHBoxLayout()
        self.ct = QComboBox(); self.ct.addItem("Все типы", None)
        self.cm = QComboBox(); self.cm.addItem("Все материалы", None)
        self.cp = QComboBox(); self.cp.addItem("Все назначения", None)
        with conn() as c:
            cur = c.cursor()
            for col, cb in [("product_type", self.ct), ("material", self.cm), ("purpose", self.cp)]:
                cur.execute(f"SELECT DISTINCT `{col}` FROM products ORDER BY 1")
                for r in cur.fetchall(): cb.addItem(r[col], r[col])
        self.ct.currentIndexChanged.connect(self.load); self.cm.currentIndexChanged.connect(self.load); self.cp.currentIndexChanged.connect(self.load)
        self.pr_min = QLineEdit(); self.pr_min.setPlaceholderText("Мин ₽"); self.pr_min.setMaximumWidth(60)
        self.pr_max = QLineEdit(); self.pr_max.setPlaceholderText("Макс ₽"); self.pr_max.setMaximumWidth(60)
        self.pr_min.textChanged.connect(self.load); self.pr_max.textChanged.connect(self.load)
        self.sort = QComboBox(); self.sort.addItems(["Название","Цена ↑","Цена ↓"])
        self.sort.currentIndexChanged.connect(self.load)
        self.search = QLineEdit(); self.search.setPlaceholderText("Поиск..."); self.search.textChanged.connect(self.load)
        f.addWidget(QLabel("Тип:")); f.addWidget(self.ct); f.addWidget(QLabel("Матер:")); f.addWidget(self.cm); f.addWidget(QLabel("Назнач:")); f.addWidget(self.cp)
        f.addWidget(self.pr_min); f.addWidget(self.pr_max); f.addWidget(self.sort); f.addWidget(self.search)
        ly.addLayout(f)

        def _logout():
            nav.user = None
            nav._update_user_label()
        self._logout = _logout
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.cont = QWidget(); self.grid = QGridLayout(self.cont); sc.setWidget(self.cont); ly.addWidget(sc)
        self.load()

    def load(self):
        for i in reversed(range(self.grid.count())):
            w = self.grid.itemAt(i).widget()
            if w: w.deleteLater()
        q = "SELECT * FROM products WHERE 1=1"; par = []
        for k, cb in [("product_type", self.ct), ("material", self.cm), ("purpose", self.cp)]:
            v = cb.currentData()
            if v: q += f" AND {k}=%s"; par.append(v)
        try: pmin = float(self.pr_min.text().replace(",",".")) if self.pr_min.text() else None
        except: pmin = None
        try: pmax = float(self.pr_max.text().replace(",",".")) if self.pr_max.text() else None
        except: pmax = None
        if pmin is not None: q += " AND price>=%s"; par.append(pmin)
        if pmax is not None: q += " AND price<=%s"; par.append(pmax)
        s = self.search.text().strip()
        if s: q += " AND (name LIKE %s OR manufacturer LIKE %s)"; par.extend([f"%{s}%", f"%{s}%"])
        q += " ORDER BY " + ["name","price","price DESC"][self.sort.currentIndex()]
        with conn() as c:
            cur = c.cursor(); cur.execute(q, par); rows = cur.fetchall()
        for i, p in enumerate(rows):
            self.grid.addWidget(ProductCard(p, self.add_cart), i//4, i%4)

    def add_cart(self, p, q): cart_add(p, q); QMessageBox.information(self, "Добавлено", f"{p['name']} в корзину")

class CartView(QWidget):
    def __init__(self, nav):
        super().__init__()
        self.nav = nav
        ly = QVBoxLayout(self)
        t = QHBoxLayout(); t.addWidget(QLabel("Корзина", styleSheet="font-weight:bold;font-size:16px")); t.addStretch()
        b = QPushButton("Каталог"); b.setStyleSheet(BTN); b.clicked.connect(lambda: nav.go("catalog")); t.addWidget(b); ly.addLayout(t)
        self.scr = QScrollArea(); self.scr.setWidgetResizable(True)
        self.cont = QWidget(); self.vl = QVBoxLayout(self.cont); self.scr.setWidget(self.cont); ly.addWidget(self.scr)
        self.total = QLabel("Итого: 0 ₽"); self.total.setFont(QFont("",14,QFont.Weight.Bold)); ly.addWidget(self.total)
        bt = QPushButton("Оформить заказ"); bt.setStyleSheet(BTN); bt.clicked.connect(self.checkout); ly.addWidget(bt)

    def refresh(self):
        for i in reversed(range(self.vl.count())):
            w = self.vl.itemAt(i).widget()
            if w: w.deleteLater()
        for x in cart_items():
            p, q = x["p"], x["q"]
            r = QHBoxLayout()
            img_lbl = QLabel()
            px = load_img(p.get("photo_path") or "img1.png", 50)
            if px: img_lbl.setPixmap(px); img_lbl.setFixedSize(50, 50)
            r.addWidget(img_lbl)
            r.addWidget(QLabel(f"{p['name']} × {q}")); r.addWidget(QLabel(f"{p['price']*q:.0f} ₽"))
            m = QPushButton("−"); m.setMaximumWidth(28); m.clicked.connect(lambda c, i=p["id"]: (cart_upd(i,-1), self.refresh()))
            pl = QPushButton("+"); pl.setMaximumWidth(28); pl.clicked.connect(lambda c, i=p["id"]: (cart_upd(i,1), self.refresh()))
            d = QPushButton("Удалить"); d.clicked.connect(lambda c, i=p["id"]: (cart_del(i), self.refresh()))
            r.addWidget(m); r.addWidget(pl); r.addWidget(d)
            w = QWidget(); w.setLayout(r); self.vl.addWidget(w)
        self.total.setText(f"Итого: {cart_total():.0f} ₽"); self.vl.addStretch()

    def checkout(self):
        if not cart: QMessageBox.warning(self, "Корзина пуста", "Добавьте товары"); return
        self.nav.go("checkout" if self.nav.user else "auth")

class AuthView(QWidget):
    def __init__(self, nav):
        super().__init__()
        self.nav = nav; self.st = QStackedWidget()
        # вход
        lf = QWidget(); ll = QFormLayout(lf)
        self.le = QLineEdit(); self.le.setPlaceholderText("email"); ll.addRow("E-mail:", self.le)
        self.lp = QLineEdit(); self.lp.setEchoMode(QLineEdit.EchoMode.Password); ll.addRow("Пароль:", self.lp)
        lb = QPushButton("Войти"); lb.setStyleSheet(BTN); lb.clicked.connect(self.login); ll.addRow(lb)
        lr = QPushButton("Зарегистрироваться"); lr.setFlat(True); lr.clicked.connect(lambda: self.st.setCurrentIndex(1)); ll.addRow(lr)
        self.st.addWidget(lf)
        # регистрация
        rf = QWidget(); rl = QFormLayout(rf)
        self.rn = QLineEdit(); self.re = QLineEdit(); self.rp = QLineEdit(); self.rpass = QLineEdit(); self.rpass.setEchoMode(QLineEdit.EchoMode.Password)
        rl.addRow("ФИО:", self.rn); rl.addRow("E-mail:", self.re); rl.addRow("Телефон:", self.rp); rl.addRow("Пароль:", self.rpass)
        rb = QPushButton("Регистрация"); rb.setStyleSheet(BTN); rb.clicked.connect(self.register); rl.addRow(rb)
        rr = QPushButton("Войти"); rr.setFlat(True); rr.clicked.connect(lambda: self.st.setCurrentIndex(0)); rl.addRow(rr)
        self.st.addWidget(rf)
        ly = QVBoxLayout(self); ly.addWidget(QLabel("Вход / Регистрация", styleSheet="font-weight:bold")); ly.addWidget(self.st)
        bb = QPushButton("Назад"); bb.setStyleSheet(BTN); bb.clicked.connect(lambda: nav.go("catalog")); ly.addWidget(bb)

    def login(self):
        """Вход по email и паролю (ТЗ п.4)."""
        e, p = self.le.text().strip(), self.lp.text()
        if not e or not p: QMessageBox.warning(self, "Ошибка", "Введите email и пароль"); return
        p_hash = _hash_password(p)
        with conn() as c:
            cur = c.cursor(); cur.execute("SELECT id,full_name,email,phone FROM users WHERE email=%s AND password_hash=%s", (e, p_hash)); u = cur.fetchone()
        if u: self.nav.user = u; self.nav.go("checkout")
        else: QMessageBox.warning(self, "Ошибка", "Неверный email или пароль")

    def register(self):
        """Регистрация: ФИО, e-mail, телефон, пароль (ТЗ п.4)."""
        n, e, ph, p = self.rn.text().strip(), self.re.text().strip(), self.rp.text().strip(), self.rpass.text()
        if not all([n,e,ph,p]): QMessageBox.warning(self, "Ошибка", "Заполните все поля"); return
        p_hash = _hash_password(p)
        try:
            with conn() as c:
                cur = c.cursor(); cur.execute("INSERT INTO users (full_name,email,phone,password_hash) VALUES (%s,%s,%s,%s)", (n,e,ph,p_hash)); uid = cur.lastrowid
            self.nav.user = {"id":uid,"full_name":n,"email":e,"phone":ph}; QMessageBox.information(self, "OK", "Регистрация успешна"); self.nav.go("checkout")
        except pymysql.err.IntegrityError: QMessageBox.warning(self, "Ошибка", "Email уже занят")

class CheckoutView(QWidget):
    def __init__(self, nav):
        super().__init__()
        self.nav = nav
        ly = QVBoxLayout(self)
        ly.addWidget(QLabel("Оформление заказа (ТЗ п.5)", styleSheet="font-weight:bold"))
        self.summ = QTextEdit(); self.summ.setReadOnly(True); ly.addWidget(self.summ)
        ag = QGroupBox("Адрес"); al = QVBoxLayout(ag)
        self.ac = QComboBox(); self.ae = QLineEdit(); self.ae.setPlaceholderText("Новый адрес"); self.chk = QRadioButton("Сохранить адрес"); al.addWidget(self.ac); al.addWidget(self.ae); al.addWidget(self.chk); ly.addWidget(ag)
        pg = QGroupBox("Оплата (ТЗ п.5)"); pl = QVBoxLayout(pg); self.rc = QRadioButton("Наличные"); self.rc.setChecked(True); self.rk = QRadioButton("Банковская карта"); pl.addWidget(self.rc); pl.addWidget(self.rk); ly.addWidget(pg)
        cb = QPushButton("Подтвердить"); cb.setStyleSheet(BTN); cb.clicked.connect(self.confirm); ly.addWidget(cb)
        bb = QPushButton("Назад"); bb.setStyleSheet(BTN); bb.clicked.connect(lambda: nav.go("catalog")); ly.addWidget(bb)

    def refresh(self):
        items = cart_items(); total = cart_total(); u = self.nav.user
        t = "Заказ:\n\n" + "\n".join(f"• {x['p']['name']} × {x['q']} — {x['p']['price']*x['q']:.0f} ₽" for x in items) + f"\n\nСумма: {total:.0f} ₽"
        if u: t += f"\n\n{u.get('full_name','')}\n{u.get('email','')}\n{u.get('phone','')}"
        self.summ.setText(t)
        self.ac.clear()
        if u:
            with conn() as c: cur = c.cursor(); cur.execute("SELECT * FROM addresses WHERE user_id=%s ORDER BY is_default DESC", (u["id"],)); addrs = cur.fetchall()
            for a in addrs: self.ac.addItem(a["address"], a["id"])
        self.ac.addItem("— Новый —", None); self.ae.clear()

    def confirm(self):
        addr = self.ae.text().strip() or (self.ac.currentText() if self.ac.currentData() else None)
        if not addr or addr == "— Новый —": QMessageBox.warning(self, "Ошибка", "Укажите адрес"); return
        u = self.nav.user
        if not u: QMessageBox.warning(self, "Ошибка", "Войдите в систему"); return
        pay = "наличные" if self.rc.isChecked() else "банковская карта"
        if self.ae.text().strip() and self.chk.isChecked():
            with conn() as c: c.cursor().execute("INSERT INTO addresses (user_id,address,is_default) VALUES (%s,%s,0)", (u["id"], addr))
        items = [{"product_id": x["p"]["id"], "quantity": x["q"], "price": x["p"]["price"]} for x in cart_items()]
        total = sum(i["price"]*i["quantity"] for i in items); est = (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d")
        with conn() as c:
            cur = c.cursor()
            cur.execute("INSERT INTO orders (user_id,payment_method,delivery_address,total_amount,status,estimated_delivery) VALUES (%s,%s,%s,%s,'pending',%s)", (u["id"], pay, addr, total, est))
            oid = cur.lastrowid
            for i in items: cur.execute("INSERT INTO order_items (order_id,product_id,quantity,price_per_unit) VALUES (%s,%s,%s,%s)", (oid, i["product_id"], i["quantity"], i["price"]))
        cart_clear(); QMessageBox.information(self, "Готово", f"Заказ #{oid}\nДоставка: {est}"); self.nav.go("catalog")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Магазин канцелярии"); self.setMinimumSize(880, 600); self.resize(1000, 650); self.user = None
        self.stack = QStackedWidget()
        self.stack.addWidget(CatalogView(self)); self.stack.addWidget(CartView(self)); self.stack.addWidget(AuthView(self)); self.stack.addWidget(CheckoutView(self))
        self.setCentralWidget(self.stack)

    def go(self, name):
        self.stack.setCurrentIndex({"catalog":0,"cart":1,"auth":2,"checkout":3}[name])
        if name == "cart": self.stack.widget(1).refresh()
        elif name == "checkout": self.stack.widget(3).refresh()
        self._update_user_label()

    def _update_user_label(self):
        """Обновление индикатора роли (ТЗ п.1): Гость или Авторизованный пользователь."""
        cat = self.stack.widget(0)
        if hasattr(cat, "user_lbl"):
            if self.user:
                cat.user_lbl.setText(f"Авторизованный: {self.user.get('full_name', '')}")
            else:
                cat.user_lbl.setText("Гость")
        if hasattr(cat, "login_btn"):
            cat.login_btn.setVisible(not self.user)
        if hasattr(cat, "logout_btn"):
            cat.logout_btn.setVisible(bool(self.user))

def main():
    app = QApplication(sys.argv); app.setStyle("Fusion")
    try:
        with conn() as c: c.cursor().execute("SELECT 1")
        print("БД OK")
    except Exception as e: QMessageBox.critical(None, "Ошибка БД", f"Проверьте MySQL и выполните db.sql\n{e}"); sys.exit(1)
    w = MainWindow(); w._update_user_label(); w.show(); sys.exit(app.exec())

if __name__ == "__main__":
    main()
