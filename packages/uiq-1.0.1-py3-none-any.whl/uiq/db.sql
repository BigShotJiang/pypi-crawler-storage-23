CREATE DATABASE IF NOT EXISTS shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shop;

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Таблица товаров
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    photo_path VARCHAR(500) DEFAULT NULL,
    material VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    manufacturer VARCHAR(255) NOT NULL,
    product_type VARCHAR(100) NOT NULL,
    purpose VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Таблица адресов доставки
CREATE TABLE IF NOT EXISTS addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address TEXT NOT NULL,
    is_default TINYINT(1) DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Таблица заказов
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    delivery_address TEXT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    estimated_delivery DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- Таблица позиций заказа
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price_per_unit DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- Таблица методов доставки (ТЗ п.6)
CREATE TABLE IF NOT EXISTS delivery_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO delivery_methods (id, name) VALUES (1, 'Курьер'), (2, 'Почта'), (3, 'Пункт выдачи');

-- Тестовые данные (пароль для test@test.ru: 12345, хеш SHA-256)
INSERT IGNORE INTO users (id, full_name, email, phone, password_hash) VALUES
(1, 'Тестовый Пользователь', 'test@test.ru', '+7 999 123-45-67', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5');

INSERT INTO products (name, photo_path, material, price, manufacturer, product_type, purpose) VALUES
('Ручка шариковая синяя', 'img1.png', 'пластик', 25.00, 'BIC', 'ручки', 'для школьников'),
('Ручка гелевая чёрная', 'img1.png', 'пластик', 45.00, 'Pilot', 'ручки', 'офисные принадлежности'),
('Блокнот A5 96 листов', 'img1.png', 'бумага', 120.00, 'Hatber', 'блокноты', 'для школьников'),
('Блокнот А4 в клетку', 'img1.png', 'бумага', 85.00, 'Спбкартон', 'блокноты', 'офисные принадлежности'),
('Папка-регистратор А4', 'img1.png', 'пластик', 350.00, 'Комус', 'папки', 'офисные принадлежности'),
('Папка с файлами', 'img1.png', 'пластик', 95.00, 'Brauberg', 'папки', 'офисные принадлежности'),
('Карандаш HB', 'img1.png', 'дерево', 15.00, 'Koh-i-Noor', 'карандаши', 'художественные материалы'),
('Ластик белый', 'img1.png', 'резина', 20.00, 'Faber-Castell', 'ластики', 'для школьников'),
('Тетрадь 12 листов клетка', 'img1.png', 'бумага', 18.00, 'Hatber', 'тетради', 'для школьников'),
('Маркеры цветные 12 шт', 'img1.png', 'пластик', 280.00, 'Copic', 'маркеры', 'художественные материалы'),
('Корректор-лента', 'img1.png', 'пластик', 65.00, 'Снежинка', 'корректоры', 'офисные принадлежности'),
('Степлер металлический', 'img1.png', 'металл', 180.00, 'Sparco', 'степлеры', 'офисные принадлежности');
