# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FetchResponse", "Data", "DataResponse"]


class DataResponse(BaseModel):
    """HTTP response information (URL, status code, optionally headers)"""

    status_code: float = FieldInfo(alias="statusCode")
    """HTTP status code of the response"""

    url: str
    """The URL that was fetched"""

    headers: Optional[Dict[str, str]] = None
    """
    Response headers from the fetch operation (keys are lower-cased HTTP header
    names)
    """


class Data(BaseModel):
    """
    Contains the extracted content in the formats specified by the select configuration
    """

    response: DataResponse
    """HTTP response information (URL, status code, optionally headers)"""

    appendix: Optional[object] = None

    browser_session_id: Optional[str] = FieldInfo(alias="browserSessionId", default=None)
    """Unique identifier for the browser session that performed this fetch"""

    html: Optional[object] = None

    json_: Optional[object] = FieldInfo(alias="json", default=None)
    """Pruned JSON objects extracted from the page (from HTML and network responses).

    This is recomputed on every fetch and is not persisted.
    """

    links: Optional[object] = None

    markdown: Optional[object] = None

    meta: Optional[object] = None
    """
    Page metadata extracted from HTML head (title, description, Open Graph, Twitter
    Card, icons)
    """

    screenshot: Optional[object] = None

    snippets: Optional[object] = None

    summary: Optional[object] = None


class FetchResponse(BaseModel):
    """Complete response from a fetch operation"""

    data: Data
    """
    Contains the extracted content in the formats specified by the select
    configuration
    """
