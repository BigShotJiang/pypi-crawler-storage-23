"""
autobee 🐝 — A clean one-line DSA toolkit for Python.
Perfect for students, interview prep, and quick prototyping.
"""

from autobee.sorting import (
    bubble_sort,
    insertion_sort,
    selection_sort,
    merge_sort,
    quick_sort,
    heap_sort,
)
from autobee.searching import (
    binary_search,
    linear_search,
)
from autobee.graph import (
    bfs,
    dfs,
    dijkstra,
)
from autobee.dp import (
    fibonacci,
    knapsack,
    lcs,
)
from autobee.structures import (
    Stack,
    Queue,
    LinkedList,
    BST,
)

__version__ = "0.1.0"
__author__ = "autobee contributors"
__all__ = [
    # Sorting
    "bubble_sort", "insertion_sort", "selection_sort",
    "merge_sort", "quick_sort", "heap_sort",
    # Searching
    "binary_search", "linear_search",
    # Graph
    "bfs", "dfs", "dijkstra",
    # DP
    "fibonacci", "knapsack", "lcs",
    # Structures
    "Stack", "Queue", "LinkedList", "BST",
]
