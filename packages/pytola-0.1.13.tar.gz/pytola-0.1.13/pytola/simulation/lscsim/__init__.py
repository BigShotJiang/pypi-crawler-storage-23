"""LSCSIM - Python-based Simulation System."""

__version__ = "0.1.13"
__author__ = "LSCSIM Team"
