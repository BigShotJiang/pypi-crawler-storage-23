import sys
import sysconfig
from importlib.resources import files
from pathlib import Path


def _package_data_candidates(*relative_parts: str):
    yield Path(files("cogniflow_pipeline_sdk")).joinpath(*relative_parts)

    paths = sysconfig.get_paths()
    for key in ("platlib", "purelib"):
        value = paths.get(key)
        if value:
            yield Path(value) / "cogniflow_pipeline_sdk" / Path(*relative_parts)

    for entry in sys.path:
        if not entry:
            continue
        yield Path(entry) / "cogniflow_pipeline_sdk" / Path(*relative_parts)


def _first_existing_path(*relative_parts: str) -> Path:
    primary = None
    seen = set()
    for candidate in _package_data_candidates(*relative_parts):
        candidate_key = str(candidate)
        if candidate_key in seen:
            continue
        seen.add(candidate_key)
        if primary is None:
            primary = candidate
        if candidate.exists():
            return candidate
    return primary if primary is not None else Path(*relative_parts)


def cf_siggen_path() -> str:
    exe = "cf_siggen.exe" if sys.platform.startswith("win") else "cf_siggen"
    return str(_first_existing_path("bin", exe))


def cf_sdk_include_path() -> str:
    return str(_first_existing_path("include"))
