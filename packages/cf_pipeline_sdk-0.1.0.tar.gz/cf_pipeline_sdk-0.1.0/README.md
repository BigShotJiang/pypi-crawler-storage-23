# cf_pipeline_sdk

`cf_pipeline_sdk` packages the native SDK assets needed by Cogniflow step packages:

- the Python module `cogniflow_pipeline_sdk`
- the `python -m cogniflow_pipeline_sdk.siggen` entry path
- packaged C/C++ headers for downstream builds
- the `cf_siggen` native binary copied into the installed package

Published distribution name:

```bash
pip install cf-pipeline-sdk
```

## Scope

The published distribution name is `cf-pipeline-sdk`.
The Python import package remains `cogniflow_pipeline_sdk`.

Downstream native step packages consume the SDK through:

- `import cogniflow_pipeline_sdk`
- `cogniflow_pipeline_sdk.cf_sdk_include_path()`
- `cogniflow_pipeline_sdk.cf_siggen_path()`
- `python -m cogniflow_pipeline_sdk.siggen`

## Native build prerequisites

The SDK is built with `scikit-build-core` and CMake.

For Windows publish/preflight runs, use:

- CPython 3.13
- CMake on `PATH`
- a working Windows C++ toolchain compatible with that CMake installation

The CI publish workflow targets `windows-latest`.
If your local machine exposes multiple CMake/compiler combinations, keep the selected CMake and compiler toolchain consistent for the whole build.

## Publishing

`cf_pipeline_sdk` is published with the dedicated Windows workflow:

- Workflow: `.github/workflows/cf_pipeline_sdk_windows_publish.yml`
- Package directory: `sandcastle/cf_pipeline/cf_pipeline_sdk`
- PyPI tag: `cf-pipeline-sdk-v<version>`
- TestPyPI tag: `cf-pipeline-sdk-v<version>-test`

Local preflight:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/mimic_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_pipeline_sdk_windows_publish.yml `
  -PackageDir sandcastle/cf_pipeline/cf_pipeline_sdk `
  -PythonExe py `
  -PythonVersion 3.13
```

Queue a dry-run dispatch:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/queue_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_pipeline_sdk_windows_publish.yml `
  -PackageDir sandcastle/cf_pipeline/cf_pipeline_sdk `
  -PublishTarget testpypi `
  -Ref main `
  -RequireLocalPass `
  -DryRun
```
