from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import cogniflow_pipeline_sdk as sdk


def test_cf_sdk_include_path_contains_expected_headers() -> None:
    include_dir = Path(sdk.cf_sdk_include_path())

    assert include_dir.is_dir()
    assert (include_dir / "cf_step_abi.h").is_file()
    assert (include_dir / "cf_step_utils.h").is_file()
    assert (include_dir / "cf_plugin_table.h").is_file()


def test_cf_siggen_path_points_to_existing_binary() -> None:
    siggen_path = Path(sdk.cf_siggen_path())

    assert siggen_path.is_file()
    assert siggen_path.name in {"cf_siggen", "cf_siggen.exe"}


def test_siggen_module_entrypoint_is_available() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "cogniflow_pipeline_sdk.siggen", "--help"],
        check=False,
        capture_output=True,
        text=True,
    )

    combined_output = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined_output
    assert "Generate step signature header" in combined_output
