from simian.gui.form import Form as Form

__all__ = ['Form', 'doc']

def doc() -> None:
    """Open the documentation of Simian GUI."""
