import abc
import numbers
from _typeshed import Incomplete
from pandas import DataFrame
from pathlib import Path
from simian.gui import component_properties
from typing import Any, Iterable

COMPONENT_LIST: Incomplete

class Component(abc.ABC):
    """Abstract class of a COMPONENT of a form."""
    defaultValue: Incomplete
    key: Incomplete
    label: Incomplete
    @defaultValue.setter
    def defaultValue(self, value) -> None:
        """Set default value.

        For some components, perform specific validation so that we can properly let the user
        know when the default value is invalid or when it will not be understood by the frontend.
        """
    @key.setter
    def key(self, new_key: str):
        """Do not allow setting the display value outside the constructor."""
    @label.setter
    def label(self, value: None | str): ...
    type: Incomplete
    placeholder: Incomplete
    input: bool
    tableView: bool
    multiple: bool
    protected: bool
    prefix: Incomplete
    suffix: Incomplete
    description: Incomplete
    clearOnHide: bool
    unique: bool
    hidden: bool
    validate: Incomplete
    validateWhenHidden: bool
    conditional: Incomplete
    errors: Incomplete
    logic: Incomplete
    disabled: bool
    customClass: Incomplete
    customConditional: Incomplete
    dataType: str
    redrawOn: Incomplete
    attributes: Incomplete
    allowCalculateOverride: bool
    calculateValue: Incomplete
    tooltip: Incomplete
    tabindex: Incomplete
    modalEdit: bool
    customDefaultValue: Incomplete
    properties: Incomplete
    def __init__(self, type, key, parent=None) -> None:
        """This is called whenever a concrete component is instantiated.

        Perform some actions that are the same for all subclasses of this class.

        Process the inputs.
        This supports the following syntaxes:
          obj = Component(type, key)
          obj = Component(type, key, parent)

        Implementations of specific components use (used in application-specific code):
          obj = Component(key)
          obj = Component(key, parent)

        The 'type' is added when calling this constructor.

        If a parent is given, the new component is added to the parent's list of components. The
        new component is not aware of its parent!
        """
    components: Incomplete
    def addComponent(self, *args) -> None:
        """Add a child component to a component and notify the form.

        Starts off by checking if the parent component can even have child components.

        Args:
            self        The component to which a component must be added.
            args        The child components to add to the parent component.
        """
    def add_validation(self, **kwargs):
        '''Add validation to the component.

        If the component already has a Validate object, it is extended with the given inputs.
        Unexpected inputs are ignored.

        Optional args:
            required    (bool): Value may not be empty when true.
            minLength   (int): For text: the minimum length of the text.
            maxLength   (int): For text: the maximum length of the text.
            minWords    (int): For text: the minimum number of words.
            maxWords    (int): For text: the maximum number of words.
            pattern     (str): For text: checks the text against a Regular expression pattern.
            custom      (str): A custom javascript based validation.
            min         (float): For numbers: the minimum allowed value.
            max         (float): For numbers: the maximum allowed value.
            integer     (bool):  If the number should be an integer.
            customMessage (str|dict): Custom message to display when the field is invalidated.  May
                be a dict with Error class\' properties - messages. E.g.: {"min": "Value too low"}
            json        (str): Custom validation specified using JsonLogic.

        Returns:
            The component.
        '''
    def addCustomProperty(self, key, value) -> None:
        """Add a property to the component object."""
    def addCustomClass(self, *classes) -> None:
        """Add custom classes to the component.

        This makes sure a space is added between potentially already existing custom classes and
        the new classes to add.

        Args:
            self            The component to add the custom classes to.
            classesToAdd    A number of css classes to add to the component.

        Syntax:
            self.addCustomClass(class1, ..., classN)
        adds class1 through classN to the list of custom classes of the component.
        """
    def disable_when(self, trigger_type: str, trigger_value: str | dict | tuple[str, Any], disable_component: bool = True) -> None:
        '''Add disable (or enable) logic to the Component.

        The target component is disabled when the component for which the unique key is specified
        has the same value as specified in the inputs. The target component will be enabled again,
        when the value of the switch component no longer matches the specified value.

        Note that adding disable logic to a disabled target component does nothing. You need to add
        disable logic to an enabled component or enable logic to a disabled one.

        Args:
            triggerType:        The trigger type.
            triggerValue:       The trigger value.
            disable_component:  (Optional) Set to False to enable the component. Defaults to True.

        The trigger type and value must be one of the following combinations:
        * "event",          "EventName"                  (triggers when the event EventName occurs.)
        * "trigger",        trigger definition dictionary.

        The following definitions trigger when the component with key "key" has the given value.
        Note that data.key does not work in case of intermediate data components.
        * "simple",         {"key", value}:                       (\'Simple\' trigger)
        * "javascript",     "result = data.key == value"
        * "result",         "data.key == value"                   (Shorter \'javascript\' trigger.)
        * "json",           "{"==": [{"var": "data.key"}, value]}"
        '''
    @staticmethod
    def fromStruct(json_dict: dict):
        """Turn a json struct, into an instance of a Component object, including subcomponents."""
    def addFromJson(self, form_definition_file: Path | str) -> dict:
        """Create and add components defined in a json form representation to the component.

        Returns a dict with the keys and objects of the created components."""
    def getChild(self, key_or_label: str):
        """Given a key or label, returns the right child component."""
    @staticmethod
    def get_constructor(type_str: str) -> Any | None:
        '''Get the constructor of a Component subclass based on its lowercase name.

        "custom" prefixes in type_str are removed before the constructor is sought.

        Returns:
            The corresponding constructor or None if none was found.
        '''
    def hasComponents(self):
        """Returns whether the component can have subcomponents."""
    def jsonSimplify(self) -> dict:
        """Create a simple representation of the component object for json conversion."""
    def setAttribute(self, attribute: str, value: str):
        '''Set an HTML attribute of a component.

        If the attribute is already set, append it instead of overwriting. This sets the
        \'attributes\' attribute of the component.
        This is intended behaviour for for example the \'style\' attribute: "style: font-size:8px;
        color:red"
        '''
    persistent: bool
    def setNonPersistent(self) -> None:
        """Add property 'persistent' dynamically because it is not allowed to add it statically.

        No property validation can be added to dynamically added properties.
        The default value used in form.io is true, so no actions required when that is what you want
        """
    def setRequired(self) -> None:
        """Make a component required.

        This adds a Validate object to the component, if it was not there yet.
        """
    def setCalculateValue(self, calculateValue: str, allowOverride: bool = False):
        """Assign the 'calculateValue' property with a Json object.

        This is done because the calculateValue may contain JSON, which should be contained in the
        form literally, instead of transforming to json.
        """

class Address(Component):
    """ADDRESS Let's the user specify an address.

    The address form component is a special component that does lookups for addresses entered, using
    data from an (external) provider. Currently, we only support the use of OpenStreetMap Nominatim
    as the provider.

    Attributes:
        disableClearIcon        (bool)  Set to True to hide the clear button.
        enableManualMode        (bool)  Set to True to allow manual specification.
        switchToManualModeLabel (str)   Label to show when enableManualMode is true.
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    autofocus: bool
    components: Incomplete
    disableClearIcon: bool
    enableManualMode: bool
    manualModeViewString: Incomplete
    provider: str
    providerOptions: Incomplete
    switchToManualModeLabel: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct an Address component."""

class Builder(Component):
    """Builder component (use via the simian-builder package)."""
    def __init__(self, key, parent=None) -> None: ...

class Button(Component):
    """BUTTON A clickable button component.

    If the label is empty, the button becomes very thin. It is therefore advised to always have a
    non-empty label.
    For more info: https://help.form.io/userguide/form-components/#button
    """
    tableView: bool
    size: str
    leftIcon: Incomplete
    rightIcon: Incomplete
    block: bool
    action: str
    disableOnInvalid: bool
    theme: str
    event: Incomplete
    custom: Incomplete
    showValidations: bool
    autoFocus: bool
    shortcut: Incomplete
    saveOnEnter: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Button component."""
    def setEvent(self, event_name: str):
        """Set an event for a button to be executed when the button is clicked.

        Args:
            event_name (str): Name of the event.

        Raises:
            ValueError: Thrown when a reserved event name is used.
        """
    def setUpload(self, upload_content_type: None | str | Any):
        """Set the upload content type.

        Args:
          upload_content_type (str):   A valid MIME type. Wildcard is allowed for the subtype.
        """

class Checkbox(Component):
    """Defines a checkbox component.

    More info: https://help.form.io/userguide/form-components/#checkbox
    """
    tableView: bool
    hideLabel: bool
    labelWidth: Incomplete
    labelMargin: Incomplete
    dataGridLabel: bool
    name: str
    value: str
    inputType: str
    shortcut: Incomplete
    autofocus: bool
    def __init__(self, key: str, parent=None) -> None:
        """Construct a Checkbox component."""

class ColorPicker(Component):
    tableView: bool
    hideLabel: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a ColorPicker component."""

class Columns(Component):
    """Used to add one or multiple columns to a form.

    More info: https://help.form.io/userguide/layout-components/#columns

    Attributes:
        columns (list): The columns configuration and components.
    """
    input: bool
    tableView: bool
    autoAdjust: bool
    columns: Incomplete
    hideOnChildrenHidden: bool
    hideLabel: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Columns component."""
    def addColumn(self, column) -> None:
        """Add an existing Column.

        Args:
            column: The column to add.
        """
    def setContent(self, components, widths) -> tuple[component_properties.Column, ...]:
        """Add Column objects and fill them with the input components.

        Args:
            self            The Columns component.
            components:     [1 x nColumns] list of lists with components. Per column, a list of
                            components to put in the column.
                            If a column only has one component, it does not have to be in a sub-list
                            Specify an empty list to create empty columns.
            widths:         How many Bootstrap grid units wide is each column. Should total to 12
                            for a clean look. Exceeding 12 is not allowed as it would result in the
                            columns being placed below one another.

        Returns:
            Tuple of created Column objects.
        """

class Container(Component):
    """A Container holds multiple other components.

    More info: https://help.form.io/userguide/data-components/#container

    Attributes:
        hideLabel (bool): Whether or not to hide the label of the container.
        labelPosition (str): Position of the label with respect to the Container.
        tree (bool): Determines if the Validation should be performed within this component.
        components (list): Array of components the container contains.
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    tree: bool
    components: Incomplete
    redrawOn: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Container component."""

class Composed(Container):
    """A Container for building (reusable) composed components.

       When the className property is set to a subclass of composed_components.Builder that can be
       found on the Python path, a container is created and provided as input argument to the
       class __init__. Otherwise, a placeholder component is created.

    Attributes:
        className (string): fully qualified name of a subclass of composed_components.Builder.
        displayHeight (integer): Minimum height of the component placeholder.
        hideLabel (bool): Whether or not to hide the label of the container.
    """
    className: Incomplete
    displayHeight: int
    hideLabel: bool
    builder: Incomplete
    def __init__(self, key, parent=None) -> None: ...
    @className.setter
    def className(self, value) -> None:
        """Set the class name and try to resolve it."""
    def jsonSimplify(self):
        """Create a simple representation of the Composed object for json conversion.

        Returns:
            simple_dict:    A simplified dictionary version of the Composed object.
        """

class Content(Component):
    """The Content component contains HTML content.

    More info: https://help.form.io/userguide/form-components/#content-component
    """
    input: bool
    tableView: bool
    html: str
    refreshOnChange: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Content component."""

class Currency(Component):
    """Lets the user choose a currency.

      More info: https://help.form.io/userguide/form-components/#currency

    Attributes:
        currency (str): What currency is selected.
        delimiter (bool): ?
        inputFormat (str): ?
        mask (bool): Whether or not there is a mask for this component.
        labelPosition (str): The position of the label with respect to the component.
        spellCheck (bool): Whether or not to perform a spelling check.
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: bool
    currency: str
    delimiter: bool
    displayMask: Incomplete
    inputFormat: str
    inputMaskPlaceholderChar: Incomplete
    mask: bool
    multiple: bool
    spellcheck: bool
    truncateMultipleSpaces: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Currency component."""

class DataGrid(Component):
    """Data Grids allow users to add multiple components on to a line item grid.

    Once placed, users can add multiple components inside of the Data Grid.
    More info: https://help.form.io/userguide/data-components/#datagrid
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    addAnother: str
    addAnotherPosition: str
    condensed: bool
    disableAddingRemovingRows: bool
    enableRowGroups: bool
    hover: bool
    initEmpty: bool
    layoutFixed: bool
    reorder: bool
    rowGroups: Incomplete
    striped: bool
    autofocus: bool
    groupToggle: bool
    components: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a DataGrid component."""
    def getColumn(self, key_or_label: str):
        """Given a key or label, returns the right child component."""
    def setContent(self, labels: list, keys: list, component_types: list, is_editable=None):
        """Add components to a DataGrid component with given labels and component types.

        Args:
            labels:             labels, one for each column.
            keys:               Per column, the key.
            component_types:    Per column, the type of component.
            is_editable:        (optional) Per column, whether or not the value must be editable.
                                By default, all are editable.
        """
    defaultValue: Incomplete
    def setRowGroups(self, labels: list, nRowsPerGroup: list, rowNames: list = None):
        """Set the DataGrid component to use row groups with given labels and number of rows.

        Optionally, the DataGrid is initialized with row names in the first column.

        Args:
            labels:         The label of every row group. Displayed above every group.
            nRowsPerGroup:  The number of rows per group.
            rowNames:       (optional) The text to display in the first column of every row.
        """
    def setOutputAs(self, output_type: str):
        """Set the output type for the DataGrid.

        Args:
            output_type: 'json' or 'DataFrame'
        """

class DataMap(Component):
    """This component extends the DataGrid component.

    There is no additional information for this component: https://help.form.io/userguide/#datamap

    Attributes:
        labelPosition (str): The position of the label with respect to the component.
        valueComponent: The component that lets the user enter the value for every key.
    """
    valueComponent: Incomplete
    @valueComponent.setter
    def valueComponent(self, value) -> None: ...
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    addAnother: Incomplete
    autofocus: bool
    disableAddingRemovingRows: bool
    keyBeforeValue: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a DataMap component."""
    def jsonSimplify(self):
        """Create a simple representation of the DataMap object for json conversion.

        Returns:
            simple_dict:    A simplified dictionary version of the DataMap object.
        """

class DataTables(Component):
    """The DataTables component."""
    tableView: bool
    defaultValue: Incomplete
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    def __init__(self, key: str, parent=None) -> None:
        """Construct a DataTables component."""
    def setFeatures(self, **kwargs):
        """Set DataTables features."""
    def setCallbacks(self, **kwargs):
        """Set DataTables callbacks."""
    def setOptions(self, **kwargs):
        """Set DataTables options."""
    def setColumns(self, titles, keys, **kwargs):
        """Set DataTables columns."""
    def setInternationalisation(self, **kwargs):
        """Set DataTables internationalisation."""
    def setSelect(self, **kwargs):
        """Set DataTables select options."""
    def setEditorFields(self, **kwargs):
        """Set editor field options.

        See the Field section at https://editor.datatables.net/reference/option/ for more info.
        Note: these options are only applied to editing, not displaying a row.
        The 'def' option is edited by using the 'default' argument because 'def' is not a valid
        argument name in Python.
        """
    def setEditorMode(self, enabled: bool, **kwargs):
        """Set DataTables editor mode."""
    def setEditorInternationalisation(self, **kwargs):
        """Set DataTables editor internationalisation."""
    @staticmethod
    def checkUniqueIds(value: list[dict]) -> None:
        """Check the uniqueness of the ids in the specified table values.

        Args:
            value:          New DataTables values, containing unique ids.

        Raises:
            AttributeError: When the ids in the DataTables values are not unique.
        """
    @staticmethod
    def getNewRows(payload: dict, key: str, nested_form: str = '', parent: str = '') -> tuple[dict, DataFrame]:
        """Return the submission data of all new rows of a DataTables component.

        Removes the 'new-' prefix of the ids of the rows. Takes optional inputs parent and
        nested_form to specify the datatables component.
        """
    def setOutputAs(self, output_type: str):
        """Set the output type for the DataTables.

        Args:
            output_type      : 'json' or 'DataFrame'
        """

class DateTime(Component):
    """A DateTime component lets the user enter a date and/or time.

    More info: https://help.form.io/userguide/form-components/#datetime
    """
    tableView: bool
    suffix: str
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    format: str
    enableDate: bool
    enableTime: bool
    defaultDate: Incomplete
    datePicker: Incomplete
    timePicker: Incomplete
    enableMinDateInput: bool
    enableMaxDateInput: bool
    widget: Incomplete
    useLocaleSettings: bool
    allowInput: bool
    autofocus: bool
    shortcutButtons: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a DateTime component."""
    def setDateSelection(self) -> None:
        """Set the properties of a DateTime component so that it is displayed as a date selector."""
    def setOutputAs(self, output_type: str):
        """Set the output type for the DateTime.

        Args:
            output_type: 'string' or 'datetime'
        """

class Day(Component):
    """Component for selecting a day interactively.

    More info: https://help.form.io/userguide/#day

    fields.day.type           The type of input for the day field
    fields.day.placeholder    The placeholder to put in the day field text box.
    fields.day.required       If this day input should be required for input.
    fields.month.type         The type of input for the month field
    fields.month.placeholder  The placeholder to put in the month field text box.
    fields.month.required     If this month input should be required for input.
    fields.year.type          The type of input for the year field
    fields.year.placeholder   The placeholder to put in the year field text box.
    fields.year.required      If this year input should be required for input.

    Attributes:
        fields (dict):
        dayFirst (bool): If the day input should be the first input item
    """
    tableView: bool
    defaultValue: str
    fields: Incomplete
    dayFirst: bool
    hideInputLabels: bool
    inputsLabelPosition: str
    useLocaleSettings: bool
    redrawOn: Incomplete
    minYear: Incomplete
    maxYear: Incomplete
    hideLabel: bool
    autofocus: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Day component."""
    def setOutputAs(self, output_type: str):
        """Set the output type for the Day.

        Args:
            output_type: 'string' or 'datetime'
        """

class EditGrid(Component):
    """Edit Grids allow users to add multiple components on to a line item grid.

    Once placed, users can add multiple components inside of the Edit Grid.
    More info: https://help.form.io/userguide/data-components/#editgrid

    Attributes:
        saveRow (str): Text to display on the 'save' button when editing a row.
        components (list): An array of components that represent a single row for the edit grid.
        labelPosition (str): The position of the label with respect to the component.
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    disableAddingRemovingRows: bool
    rowDrafts: bool
    saveRow: str
    templates: Incomplete
    components: Incomplete
    autofocus: bool
    rowClass: Incomplete
    addAnother: Incomplete
    modal: bool
    removeRow: Incomplete
    displayAsTable: bool
    openWhenEmpty: bool
    inlineEdit: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a EditGrid component."""
    def getColumn(self, key_or_label: str):
        """Given a key or label, returns the right child component."""
    def setContent(self, labels: list, keys: list, types: list, is_editable: list):
        """Add components to an EditGrid component with given headers, labels, and component types.

        Args:
            labels:           String array of headers, one for each column.
            keys:             Per column, the key.
            types:            Per column, the type of component. If empty string, the component type
                              added is Content.
            is_editable:      For every component, whether or not they are editable.
        """
    def setOutputAs(self, output_type: str):
        """Set the output type for the EditGrid.

        Args:
            output_type: 'json' or 'DataFrame'
        """

class Email(Component):
    """Lets the user enter an email address.

    More info: https://help.form.io/userguide/form-components/#email

    Attributes:
        kickbox (dict): If the Kickbox validation should be enabled for this email input
        labelPosition (str): The position of the label with respect to the component.
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: bool
    displayMask: Incomplete
    inputFormat: str
    inputMaskPlaceholderChar: Incomplete
    inputMasks: Incomplete
    kickbox: Incomplete
    mask: bool
    redrawOn: Incomplete
    spellcheck: bool
    truncateMultipleSpaces: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Email component."""

class Extension(Component):
    constructorFn: Incomplete
    initFn: Incomplete
    renderFn: Incomplete
    attachFn: Incomplete
    detachFn: Incomplete
    destroyFn: Incomplete
    normalizeValueFn: Incomplete
    setValueFn: Incomplete
    setValueAtFn: Incomplete
    getValueFn: Incomplete
    getValueAtFn: Incomplete
    updateValueFn: Incomplete
    tableView: bool
    hideLabel: bool
    event: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct an Extension component."""

class FieldSet(Component):
    """FieldSet components can be used to create a title of an area of the form.

    More info: https://help.form.io/userguide/layout-components/#fieldset

    Attributes:
        legend (str): The text to place within the legend of this fieldset.
    """
    input: bool
    tableView: bool
    components: Incomplete
    legend: str
    def __init__(self, key, parent=None) -> None:
        """Construct a FieldSet component."""

class File(Component):
    """File components can be used to upload files.

    More info: https://help.form.io/userguide/form-components/#file

    Attributes:
        image (bool): If this file component should be used for managing images
        imageSize (str): If this file component is configured as an image upload, then the size of
                         images that are shown when uploaded.
        storage (str): The place/system to store the uploaded files in/with.
        webcam (bool): Whether or not to upload a picture taken with a webcam.
        filePattern (str)
        labelPosition (str): The position of the label with respect to the component.
    """
    tableView: bool
    storage: str
    url: str
    dir: str
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    image: bool
    imageSize: Incomplete
    webcam: bool
    webcamSize: Incomplete
    filePattern: str
    fileTypes: Incomplete
    uploadOnly: bool
    autofocus: bool
    fileMinSize: Incomplete
    fileMaxSize: Incomplete
    multiple: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a File component."""
    def useBase64Upload(self) -> None:
        """Allow the user to use base64 in deployed mode anyway."""
    @staticmethod
    def storeUploadedFiles(meta_data: dict, payload: dict, key: str, nested_form: str = '', parent: str = '') -> tuple[dict, list]:
        '''Store file(s) uploaded by the file component.

        Args:
            meta_data (dict): Meta data dictionary.
            payload (dict): Payload dictionary.
            key (str): Key of the File component.
            nested_form (str, optional): Nested form key. Defaults to "".
            parent (str, optional): Parent component key. Defaults to "".

        Returns:
            (dict, list): The payload and the file paths of the stored files.
        '''

class Form(Component):
    """Defines a component for including a referenced form in the form.

    More info: https://help.form.io/userguide/form-components/#nested-form
    """
    src: Incomplete
    reference: bool
    form: Incomplete
    components: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Form component."""

class Hidden(Component):
    """A class for creating a data component that is not visible to the user.

    More info: https://help.form.io/userguide/data-components/#hidden
    """
    tableView: bool
    input: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Hidden component."""

class Html(Component):
    """The Html component can be used to show preformatted HTML."""
    input: bool
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    sanitizeOptions: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Html component."""

class HtmlElement(Component):
    """An HtmlElement is a component used to display a single HTML element in the form.

    More info: https://help.form.io/userguide/form-components/#html-element-component

    Attributes:
        tag (str): The HTML Tag to use for this element
        className (str): The class name to provide to the HTML Element
        content (str): The HTML content to place within this element.
        refreshOnChange (bool): Whether or not to refresh the form(?) when a change is detected.
        attrs (list): An array of key-value pairs of attributes and their values to assign to this
        html element
        stationary (dict): Stationary values such as label, row names etc. This property value is
            stored in the formMap and can therefore be used during guiEvents. Can only be used by
            the composedComponent HtmlTable.
    """
    input: bool
    tableView: bool
    tag: str
    className: str
    content: str
    refreshOnChange: bool
    attrs: Incomplete
    stationary: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a HtmlElement component."""
    def setAttrs(self, attrs, values) -> None:
        """Set the 'attrs' property of an HtmlElement component."""
    def setLocalImage(self, image_file, alt: str = None, scale_to_parent_width: bool = False):
        """Add content to an HtmlElement component for displaying a local image.

        Args:
            image_file:      Path to the image. Can be relative if it is on the path.
            alt:                    alt attribute to assign to the <img> element.
            scale_to_parent_width:  Whether or not to scale the image to match the parent's width.
        """

class HtmlTable(Html):
    """Html display of table."""
    defaultValue: str
    stationary: Incomplete
    def __init__(self, key: str, parent=None, caption: str = '', column_names: list = [], row_names: list = []) -> None:
        '''Create HtmlTable.

        Args:
            key: Key of the HtmlElement to create.
            parent (optional): Parent of the HtmlElement to create. Defaults to None.
            caption (optional): Text to display above the table. Defaults to "".
            column_names (optional): Names of the table\'s columns. Defaults to "".
            row_names (optional): Names of the table\'s rows. Defaults to "".
        '''
    def setDefaultValue(self, data, customization: dict = ...):
        """Set the default value of a table, including optional highlighting.

        Args:
            data: Data to display in the table.
            customization (optional): Dict containing info on customization of the table: font
                colouring, row names etc.. Defaults to dict().
        """
    @staticmethod
    def getTable(input_data, customization: dict, stationary: dict) -> str:
        """Get the submission data for an HTML table given the input data and the options.

        This is called by setSubmissionData and can also be used to set the initial values of a
        table.

        Note that the inputData list's contents are modified by this method, so no new output.

        Args:
            input_data:     Data to display in the table. List of lists of numbers and/or strings.
                Input of setSubmissionData call. Each list in the main lists corresponds to a row.
            customization:  Customization as provided to setSubmissionData.
            stationary:     The stationary dict (property of HtmlElement) as set during
                initialization. Will always have fields label, rowNames and colNames.

        Returns:
            String of the created Html table.
        """
    @staticmethod
    def cell_2_html_table(table_cell: list, **kwargs) -> str:
        """cell_2_html_table Generates the HTML to view a cell array in HTML browsers.

        Args:
            table_cell: list of lists of table contents. Include row and column headers if needed.
            kwargs:     param-value pairs as listed in the code (esp for formatting the table).

        Returns:
            String of the created HTML table.
        """

class ImageGrid(Component):
    """A Grid for showing tiles in a horizontal flow layout."""
    tableView: bool
    hideLabel: bool
    tileWidth: str
    tileHeight: str
    multiple: bool
    def __init__(self, key, parent=None) -> None:
        """Construct an ImageGrid component."""

class Number(Component):
    """A component for letting the user enter a number.

    More info: https://help.form.io/userguide/form-components/#number
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: Incomplete
    decimalLimit: Incomplete
    delimiter: bool
    displayMask: Incomplete
    inputFormat: str
    inputMaskPlaceholderChar: Incomplete
    mask: bool
    multiple: bool
    redrawOn: Incomplete
    requireDecimal: bool
    spellCheck: bool
    truncateMultipleSpaces: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Number component."""

class Panel(Component):
    """Use a Panel to wrap groups of fields with a title and styling.

    More info: https://help.form.io/userguide/layout-components/#panels

    Attributes:
        title (str): The title of the panel
        theme (str): Any valid Bootstrap Panel Theme
        collapsible (bool): Whether or not the component can be collapsed.
    """
    title: str
    input: bool
    tableView: bool
    theme: str
    collapsible: bool
    collapsed: bool
    components: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Panel component."""

class Password(Component):
    """A component for entering a password in which the entered characters are obfuscated.

    More info: https://help.form.io/userguide/form-components/#password
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: bool
    displayMask: Incomplete
    inputMaskPlaceholderChar: Incomplete
    protected: bool
    showCharCount: bool
    showWordCount: bool
    spellcheck: bool
    tableView: bool
    truncateMultipleSpaces: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Password component."""

class PhoneNumber(Component):
    """Lets the user enter a phone number.

    More info: https://help.form.io/userguide/form-components/#phone-number

    Attributes:
        inputMask (str): The input mask for this phone number input.
        labelPosition (str): The position of the label with respect to the component.
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    allowMultipleMasks: bool
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: bool
    displayMask: Incomplete
    inputFormat: str
    inputMask: str
    inputMaskPlaceholderChar: Incomplete
    inputMasks: Incomplete
    mask: bool
    spellcheck: bool
    truncateMultipleSpaces: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a PhoneNumber component."""

class Plotly(Component):
    """Lets the user add a plotly figure to the form."""
    tableView: bool
    defaultValue: Incomplete
    figure: Incomplete
    data: Incomplete
    aspectRatio: Incomplete
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Plotly component."""
    def jsonSimplify(self):
        """Create a simple representation of the component object for json conversion.

        Returns:
            simple_dict:    A simplified dictionary version of the Plotly object.
        """

class Radio(Component):
    """Define the specifics of a set of options of which exactly one must be selected.

    More info: https://help.form.io/userguide/form-components/#radio

    Attributes:
        values (list): An array of value objects
        inline (bool): If set to true, layout the radio buttons horizontally instead of vertically.
        labelPosition (str): The position of the label with respect to the component.
        optionsLabelPosition (str): Position of the label of each of the options,
            with respect to those options.
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    values: Incomplete
    inline: bool
    optionsLabelPosition: str
    autofocus: bool
    dataType: str
    redrawOn: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Radio component."""
    def fromStructSpecific(self, json_dict: dict):
        """Radio specific json load functionality. Loads the values definitions from the json."""
    defaultValue: Incomplete
    def setValues(self, labels: list, values: list, default: str = None):
        """Set the 'values' property of a Radio component."""

class ResultFile(Component):
    """Component for showing files uploaded with the File component."""
    tableView: bool
    multiple: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    meta: Incomplete
    def __init__(self, key: str, parent=None) -> None:
        """Initialize ResultFile composed component.

        Args:
            key: The component base key.
            parent (optional): The parent component. Defaults to None.
        """
    @staticmethod
    def create_content(urls: Iterable[str], file_names: Iterable[str], file_sizes: Iterable[numbers.Number]) -> list:
        """Create HTML showing download links.

        Args:
            urls: List of download URLs.
            file_names: List of file names.
            file_sizes: List of file sizes (bytes).

        Returns:
            str: HTML string for displaying.
        """
    @staticmethod
    def upload(file_paths: list[Path | str], mime_types: list[str], meta_data, payload, key, nested_form: str = '', parent: str = '', file_names: list[str] = [], append: bool = False) -> dict:
        '''Upload result files to portal.

        Args:
            file_paths: List of files to upload.
            mime_types: List of MIME-types corresponding to files.
            meta_data: The meta data.
            payload: Payload data.
            key: ResultFile component key.
            nested_form (optional): The nested form key. Defaults to "".
            parent (optional): The parent key. Defaults to "".
            file_names (optional): List of file names to display in the user interface.
            append (optional): Append the files to the contents of the component instead of replacing them.

        Raises:
            Exception: When the component does not exist.

        Returns:
            dict: Payload data.
        '''
    def useBase64Upload(self) -> None:
        """Allow the user to use base64 in deployed mode anyway."""

class Select(Component):
    """The Select component represents a dropdown list from which a selection can be made.

    More info: https://help.form.io/userguide/form-components/#select
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    data: Incomplete
    dataSrc: str
    dbIndex: bool
    valueProperty: str
    refreshOn: str
    filter: str
    authenticate: bool
    template: str
    searchEnabled: bool
    selectThreshold: float
    widget: str
    autofocus: bool
    multiple: bool
    uniqueOptions: bool
    dataType: str
    refreshOnBlur: Incomplete
    clearOnRefresh: bool
    readOnlyValue: bool
    useExactSearch: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Select component."""
    defaultValue: Incomplete
    def setValues(self, labels: list, values: list, default: str = None):
        """Set the 'data' property of a Select object, setting the options that can be selected."""

class Selectboxes(Component):
    """Defines a group of checkboxes in a form.

    More info: https://help.form.io/userguide/form-components/#selectboxes

    Attributes:
        inline (bool): Determines if the selectboxes should be shown inline (horizontally)
        values (list)
        inputType (str)
        labelPosition (str): The position of the label with respect to the component.
        optionsLabelPosition (str)
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    inline: bool
    values: Incomplete
    inputType: str
    optionsLabelPosition: str
    autofocus: bool
    redrawOn: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a SelectBoxes component."""
    def fromStructSpecific(self, json_dict: dict):
        """Selectboxes specific json load functionality. Loads the values definitions from json."""
    defaultValue: Incomplete
    def setValues(self, labels: list, values: list, defaults: list = None):
        """Set the checkboxes to add to the Selectboxes component. Optionally add default values.

        Args:
            labels:     String array of text to display per checkbox.
            values:     The value (key) of each of the checkboxes.
            defaults:   (optional) Default values (logicals). Can be a scalar to give all
                checkboxes the same default value.
        """

class Signature(Component):
    """A component that lets the user sign a form.

    More info: https://help.form.io/userguide/form-components/#signature

    Attributes:
        footer (str): The text to place at the footer of the signature component.
        width (str): The width of the signature pad
        height (str): The height of the signature pad
        penColor (str): The color of the pen that is used to sign the pad
        backgroundColor (str): The background color of the signature pad
        labelPosition (str): Position of the label.
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    footer: str
    width: str
    height: str
    penColor: str
    backgroundColor: str
    redrawOn: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Signature component."""

class Slider(Component):
    min: int
    max: int
    step: int
    tableView: bool
    hideLabel: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Slider component."""

class Survey(Component):
    """Similar to Radio buttons, but asks multiple questions, all with the same answers.

    More info: https://help.form.io/userguide/form-components/#survey

    Attributes:
        labelPosition (str): Position of the label with respect to the component.
        questions (list): An array of question objects
        values (list): An array of value objects
    """
    tableView: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    questions: Incomplete
    values: Incomplete
    autofocus: bool
    redrawOn: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Survey component."""
    def setQuestions(self, labels: list, values: list):
        """Set the 'questions' property of a Survey component."""
    def setAnswers(self, labels, values) -> None:
        """Set the 'questions' property of a Survey component."""

class Table(Component):
    """Create a table component that allows for components to be added to its rows and columns.

    More info: https://help.form.io/userguide/layout-components/#table

    Attributes:
        numRows (int): The number of rows for this table
        numCols (int): The number of columns for this table
        rows (list): A multi-dimensional array that provides the rows of the table.
                     Within each row is another array that contains the columns of that row,
                     and within that is the components that are contained within that cell
                     of the table.
        header (str): An array of strings that serve as the header for the columns of the table.
        striped (bool): If the table should be striped
        bordered (bool): If the table should contain borders
        hover (bool): If the table should have a hover highlight over the rows.
        condensed (bool): If the table should be condensed
        cellAlignment (str)
    """
    input: bool
    tableView: bool
    numRows: int
    numCols: int
    rows: Incomplete
    header: str
    striped: bool
    bordered: bool
    hover: bool
    condensed: bool
    cellAlignment: str
    hideLabel: bool
    cloneRows: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Table component."""
    def setContent(self, contents: list):
        """Set the contents of a table given an input list of lists of strings or components.

        HtmlElement components are created for every string in the input. This sets the number
        of rows and columns based on the size of the input.

        Args:
          contents:     Content to set for the table. Can be one of the following:
                          - list with per cell, a string, component, or list of components.
        """

class Tabs(Component):
    """Tabs allow users to add different components to one of multiple tabs/pages in the form.

    More info: https://help.form.io/userguide/#tabs
    """
    tableView: bool
    input: bool
    hideLabel: bool
    verticalLayout: bool
    components: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Tabs component."""
    def addTab(self, label: str, key: None | str = None) -> component_properties.Tab:
        """Create a tab and add it to the Tabs component.

        Args:
            label:      Label to be shown on the tab.
            key:        (Optional) Key to identify the tab with. Defaults to the label.

        Returns:
            The created tab.
        """
    def fillTabs(self, labels: list[str], fill_fcns: list[callable], inputs: None | list = None) -> None:
        '''Add tabs to the Tabs component.

        Uses a set of labels, functions, and possibly input arguments.
        Each tab is filled by calling the functions with as input the tab and optional
        additional inputs.

        Args:
            labels:     One label per tab to add and fill. Must be unique.
            fill_fcns:  Per tab, the function handle for filling it.
            inputs:     Per tab, a cell array containing the inputs to pass on to the createFcn.
                        Can be left out.

        Syntax:
            self.fillTabs(["Setup", "Analysis", "Reporting"], [fill1, fill2, init3])
        Adds three tabs with the given labels. The tabs are filled by calling the functions.
        Their syntax is: fillFcn(tab)

            self.fillTabs(["Setup", "Analysis", "Reporting"], [fill1, fill2, init3], ...
                [[False], [True, 10], []])
        Adds three tabs with the given labels. The tabs are filled by calling the functions. The
        first function gets the tab and False as input. The second function gets the tab, True, and
        10 as inputs. The third function only has the tab as input.

        Note that debugging the functions specified in the inputs is not possible. For debugging to
        work the functions need to be executed in the application specific code. The alternative for
        this method is to use the following:
            for i_tab, i_fill_fcn, i_inputs in zip(tabs.setContent(labels), fill_fcns, inputs):
                i_fill_fcn(i_tab, *i_inputs)
        '''
    def getTab(self, key_or_label: str):
        """Given a key or label, returns the right tab."""
    def setContent(self, labels: list[str], keys: None | list[str] = None, components: None | list[Component] = None) -> tuple[component_properties.Tab, ...]:
        """Add Tab objects and fill them with the input components.

        Args:
            labels:         The text to display at the top of every tab.
            keys:           (optional) A key for every tab to create.
            components:     (optional) [1 x nTabs] list of components. Per list, a list of the
                            components to add to the tab. If a tab only has one component, its
                            cell does not have to be a list.

        Returns:
            all_tabs:       Tuple of all tabs. Use this to add components to the tabs later on.
        """

class Tags(Component):
    """Tags allow users to add tags as separate words.

    Attributes:
        delimiter (str): The delimiter to use in the submission data when the 'storeas' attribute is
            set to 'string'.
        delimeter (str): The delimiter attribute, but spelled like the form.io component.
            Undocumented.
        labelPosition (str): The position of the label with respect to the Tags component.
        maxTags (int): Maximum number of tags to be entered.
        storeas (str): Store the tags in submission data as a string, or as an array. Options:
            'array', 'string'.
    """
    delimeter: Incomplete
    @delimeter.setter
    def delimeter(self, new_delimeter: str):
        """Do not allow setting the delimeter value."""
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    tableView: bool
    delimiter: str
    maxTags: int
    storeas: str
    autofocus: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Tags component."""
    def jsonSimplify(self):
        """Create a simple representation of the Tags object for json conversion.

        Makes sure the delimeter field (with that spelling) is part of the JSON.

        Returns:
            simple_dict:    A simplified dictionary version of the Tags object.
        """

class TextArea(Component):
    """A multi-line input field allowing for long input text.

    More info: https://help.form.io/userguide/form-components/#textarea

    Attributes:
        rows (int): How many rows this text area should contain.
        autoExpand (bool): Whether or not the text area should expand automatically when it is full.
        labelPosition (str): Position of the label with respect to the TextArea.
        showCharCount (bool): Whether or not to show the number of characters entered below the
            textarea.
        showWordCount (bool): Whether or not to show the number of words entered below the textarea.
    """
    rows: int
    autoExpand: bool
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: bool
    displayMask: Incomplete
    editor: Incomplete
    inputFormat: Incomplete
    inputMask: Incomplete
    inputMaskPlaceholderChar: Incomplete
    isUploadEnabled: bool
    showCharCount: bool
    showWordCount: bool
    spellcheck: bool
    truncateMultipleSpaces: bool
    uploadDir: Incomplete
    uploadStorage: str
    def __init__(self, key, parent=None) -> None:
        """Construct a TextArea component."""

class TextField(Component):
    """An input field that lets the user type.

    More info: https://help.form.io/userguide/form-components/#textfield
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    allowMultipleMasks: bool
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: bool
    displayMask: Incomplete
    errorLabel: Incomplete
    inputFormat: str
    inputMask: Incomplete
    inputMaskPlaceholderChar: Incomplete
    inputMasks: Incomplete
    mask: bool
    multiple: bool
    redrawOn: Incomplete
    showCharCount: bool
    showWordCount: bool
    spellcheck: bool
    truncateMultipleSpaces: bool
    widget: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a TextField component."""

class Time(Component):
    """A component that lets the user enter a time.

    More info: https://help.form.io/userguide/#time

    Attributes:
        format (str): The time format for display of the captured time.
        inputMask (str): Use this to only allow numbers to be entered.
        labelPosition (str): Position of the label with respect to the Time component.
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    autofocus: bool
    dataFormat: Incomplete
    displayMask: Incomplete
    format: str
    inputFormat: Incomplete
    inputMask: str
    inputType: Incomplete
    multiple: bool
    truncateMultipleSpaces: bool
    def __init__(self, key, parent=None) -> None:
        """Construct a Time component."""

class Toggle(Component):
    tableView: bool
    hideLabel: bool
    leftLabel: str
    rightLabel: str
    def __init__(self, key, parent=None) -> None:
        """Construct a Toggle component."""

class Url(Component):
    """A component for letting the user enter a url.

    More info: https://help.form.io/userguide/form-building/advanced-components#url
    """
    hideLabel: bool
    labelPosition: str
    labelWidth: Incomplete
    labelMargin: Incomplete
    allowMultipleMasks: bool
    applyMaskOn: Incomplete
    autocomplete: Incomplete
    autofocus: bool
    displayMask: Incomplete
    errorLabel: Incomplete
    inputFormat: str
    inputMask: Incomplete
    inputMaskPlaceholderChar: Incomplete
    inputMasks: Incomplete
    mask: bool
    multiple: bool
    redrawOn: Incomplete
    showCharCount: bool
    showWordCount: bool
    spellcheck: bool
    truncateMultipleSpaces: bool
    widget: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a url component."""

class Well(Component):
    """A container for components with a border and a gray background.

    More info: https://help.form.io/userguide/layout-components/#well
    Also: https://www.w3schools.com/bootstrap/bootstrap_wells.asp
    """
    input: bool
    tableView: bool
    hideLabel: bool
    components: Incomplete
    def __init__(self, key, parent=None) -> None:
        """Construct a Well component."""

def must_not_be_form_event(event_name: str):
    """Check for reserved event names.

    Args:
        event_name (str): Event name to check.

    Raises:
        ValueError: Thrown when a reserved event name is used.
    """
