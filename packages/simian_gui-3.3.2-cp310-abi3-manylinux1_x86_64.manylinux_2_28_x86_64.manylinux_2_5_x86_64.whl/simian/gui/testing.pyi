import abc
from _typeshed import Incomplete

class Testing(abc.ABC, metaclass=abc.ABCMeta):
    """Use this class as superclass to test applications created with the webframework.

    Any subclass must declare a value for the namespace property. Optionally an add_meta_data dict
    property may be set with which the meta data dict can be extended.
    """
    @property
    @abc.abstractmethod
    def namespace(self):
        """The namespace used to create an instance of the application."""
    add_meta_data: Incomplete
    form_map: Incomplete
    form_obj: Incomplete
    payload: Incomplete
    def choose(self, key, option_to_choose, nested_form: str = '', parent: str = '', index: int = None, label: str = '', question: str = ''):
        """Use this method to simulate choosing an option of a component.

        Syntax:
            CHOOSE(obj, KEY, OPTION)
        Updates submission data by 'choosing' the given OPTION for the component given by KEY (the
        first one found by that key). OPTION can be numeric or text, depending on the type of
        component.

            CHOOSE(..., nested_form=NESTEDFORM)
        Chooses an option of a component in the nested form with key NESTEDFORM.

            CHOOSE(..., parent=PARENT)
        Chooses an option of a component parented by a component with key PARENT.

            CHOOSE(..., index=INDEX)
        Chooses an option of a component in the INDEX'th row.

            CHOOSE(..., label=LABEL)
        For components with multiple values, set the value labeled LABEL to OPTION.

            CHOOSE(..., question=QUESTION)
        For Survey components, the label or value of the question to answer with OPTION.

        Args:
            self:               The testCase object.
            key:                The key of the button whose press to simulate.
            option_to_choose:   The option to choose (label or value). For checkboxes, this is a
                logical.

        Optional keyword Arguments:
            nested_form:        The key of the nested form the component is in.
            parent:             The key of the parent component.
            index:              If the parent has multiple values for the component, this is the row
                index to type in.
            label:              The label of the value to set the option to.
            question:           For Survey components, the label or value of the question to choose
                an answer for.
        """
    def findLabelOrValue(self, str_to_find: str, the_list: list, message: str):
        """Returns the values of the list of dicts matching the str_to_find.

        Given a list of dicts, each with fields 'label' and 'value, return the value for which the
        str_to_find matches either the label or value of that struct. If str_to_find is a 'value',
        the output value equals str_to_find.

        Args:
            self:           The Testing object.
            str_to_find:    String to match with either one of the labels, or one of the values in
                the input list.
            the_list:       List of dicts, each with keys 'label' and 'value'.
            message:        The message to print when str_to_find was not found in the input list.

        Returns:
            value:            The value matching the given str_to_find.
            all_values:       List of the 'value' key values of the_list. None's are inserted when a
                dict does not have the 'value' key.
        """
    def getSubmissionData(self, key: str, nested_form: str = '', parent: str = '', **kwargs) -> tuple[dict, bool]:
        """Calls the util with the same name. Use this method for easy access.

        Args:
            self:               The test object.
            key:                Key of the component whose submission data to return.

        Optional keyword Arguments:
            nested_form:        Key of the nested form the component is in.
            parent:             Key of the parent component.

        Returns:
            data:               The submission data for the requested component.
            is_found:           True if the submission data was found.

        See Also:
            :meth:'simian.gui.Testing.verifySubmissionData'
            :meth:'simian.gui.utils.getSubmissionData'
        """
    def performGesture(self, gesture: str, key, **kwargs):
        '''Simulate performing the given gesture for the given component.

        Finds the component to perform the gesture on and calls the correct method of the relevant
        class in the simian.gui.testing package.

        Args:
            gesture:        Gesture to perform. ["choose", "press", "type"]
            key:            Key of the component to perform the gesture on.
            kwargs:         Options struct passed on from Testing.<GestureName>. Will have a field
                \'Value\' if relevant.
        '''
    def press(self, key, option_to_press: str = '', nested_form: str = '', parent: str = '', index: int = None):
        """Use this method to simulate a component press.

        Triggers guiEvent for components of type button.

        Syntax:
            PRESS(OBJ, KEY)
        presses the component given by KEY (the first one found by that key).

            PRESS(OBJ, KEY, OPTION)
        presses the option whose label or value is OPTION of a component given by KEY (the first one
        found by that key).

            PRESS(..., nested_form=NESTEDFORM)
        presses the component given by KEY in the nested form with key NESTEDFORM.

            PRESS(..., parent=PARENT)
        presses the component given by KEY that is a direct child of the component whose key is
        PARENT.

            PRESS(..., index=INDEX)
        presses the INDEX'th element of the component. For example, when KEY points to a Checkbox of
        a DataGrid, this notation simulates checking/unchecking the checkbox on the INDEX'th row of
        the DataGrid.

        Args:
            self:               The testCase object.
            key:                The key of the button whose press to simulate.
            option_to_press:    The option to choose (label or value). For checkboxes, this is a
                logical.

        Optional keyword Arguments:
            nested_form:        The key of the nested form the component is in.
            parent:             The key of the parent component.
            index:              If the parent has multiple values for the component, this is the row
                index to type in.
        """
    def type(self, key: str, value=None, nested_form: str = '', parent: str = '', index: int = None):
        """Use this method to simulate entering a value in a component.

        Syntax:
            TYPE(obj, KEY, VALUE)
        Updates submission data with the given VALUE for the component given by KEY (the first one
        found by that key). VALUE can be numeric or text, depending on the type of component.

            TYPE(..., nested_form=NESTEDFORM)
        Updates submission data of a component in the nested form with key NESTEDFORM.

            TYPE(..., parent=PARENT)
        Updates submission data of a component parented by a component with key PARENT.

            TYPE(..., index=INDEX)
        When the key points to for example a DataGrid, indicates the INDEX'th row of the component
        whose submission data to update.

        Args:
            self:               The testCase object.
            key:                The key of the component whose typing to simulate.
            value:              The value to enter. Can be string or numeric.

        Optional keyword Arguments:
            nested_form:        The key of the nested form the component is in.
            parent:             The key of the parent component.
            index:              If the parent has multiple values for the component, this is the row
                index to type in.
        """
    def updateSubmissionData(self, key: str, new_value, nested_form: str = '', parent: str = '', **kwargs):
        """Set the submission data to a specific value.

        Args:
            key:                Key of the component whose submission data to update.
            new_value:          Value to set for the component.
            nested_form:        Key of the nested form the component is in.
            parent:             Key of the parent component.
        """
    def verifySubmissionData(self, key: str, expected, message: str = None, nested_form: str = '', parent: str = ''):
        """Verify the submission data for a given component is found and equals the expected value.

        Syntax:
            verifySubmissionData(obj, key, expected, options)

        Args:
            key:                Key of the component whose submission data to verify.
            expected:           Expected submission data.
            message:            Warning message to show when the verify fails.
            nested_form:        Key of the nested form the component is in.
            parent:             Key of the parent component.
        """

class Number:
    """This class defines what can be tested for Number components."""
    @staticmethod
    def type(test_object, component, value=None, nested_form: str = '', parent: str = '', **kwargs):
        """This method is a helper method for the Testing class. Do not use directly."""

class TextField:
    """This class defines what can be tested for TextField components."""
    @staticmethod
    def type(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class Address(TextField):
    """This class defines what can be tested for Address components."""

class Button:
    """This class defines what can be tested for Button components."""
    @staticmethod
    def press(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class Checkbox:
    """This class defines what can be tested for Checkbox components."""
    @staticmethod
    def choose(test_object, component, value: bool = False, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""
    @staticmethod
    def press(test_object, component, index=None, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class ColorPicker(TextField):
    """This class defines what can be tested for ColorPicker components."""
    @staticmethod
    def choose(test_object, component, value: bool = False, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class Currency(Number):
    """This class defines what can be tested for Currency components.

    For now, this inherits the type method of the Number class.
    When it turns out the behaviour for this component must be different, remove this dependency and
    write a unique implementation of the type method here.
    """

class DataGrid:
    """This class defines what can be tested for DataGrid components."""
    @staticmethod
    def type(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class DataTables(DataGrid):
    """This class defines what can be tested for DataTables components."""
class DateTime(TextField):
    """This class defines what can be tested for DateTime components."""
class Day(TextField):
    """This class defines what can be tested for Day components.

    For now, this inherits the type method of the TextField.
    When it turns out the behaviour for this component must be different, remove this dependency and
    write a unique implementation of the type method here.
    """
class EditGrid(DataGrid):
    """This class defines what can be tested for EditGrid components."""
class Email(TextField):
    """This class defines what can be tested for Email components.

    For now, this inherits the type method of the TextField.
    When it turns out the behaviour for this component must be different, remove this dependency and
    write a unique implementation of the type method here.
    """

class File:
    @staticmethod
    def choose(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class Password(TextField):
    """This class defines what can be tested for Password components.

    For now, this inherits the type method of the TextField.
    When it turns out the behaviour for this component must be different, remove this dependency and
    write a unique implementation of the type method here.
    """
class PhoneNumber(TextField):
    """This class defines what can be tested for PhoneNumber components.

    For now, this inherits the type method of the TextField.
    When it turns out the behaviour for this component must be different, remove this dependency and
    write a unique implementation of the type method here.
    """

class Radio:
    """This class defines what can be tested for Radio components."""
    @staticmethod
    def choose(test_object, component, value=None, nested_form: str = '', parent: str = '', **kwargs):
        """This method is a helper method for the Testing class. Do not use directly."""

class Select:
    """This class defines what can be tested for Select components."""
    @staticmethod
    def choose(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class Selectboxes:
    """This class defines what can be tested for Selectboxes components."""
    @staticmethod
    def choose(test_object, component, nested_form: str = '', parent: str = '', value=None, label: str = None, **kwargs):
        """This method is a helper method for the Testing class. Do not use directly."""
    @staticmethod
    def press(test_object, component, nested_form: str = '', parent: str = '', value=None, label: str = None, **kwargs):
        """This method is a helper method for the Testing class. Do not use directly."""

class Slider:
    """This class defines what can be tested for Slider components."""
    @staticmethod
    def choose(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class Survey:
    """This class defines what can be tested for Survey components."""
    @staticmethod
    def choose(test_object, component, question: str, nested_form: str = '', parent: str = '', value: str = None, label: str = None, **kwargs):
        """This method is a helper method for the Testing class. Do not use directly."""

class Tags:
    """This class defines what can be tested for Tags components."""
    @staticmethod
    def type(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""
    @staticmethod
    def press(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class TextArea(TextField):
    """This class defines what can be tested for TextArea components.

    For now, this inherits the type method of the TextField.
    When it turns out the behaviour for this component must be different, remove this dependency and
    write a unique implementation of the type method here.
    """
class Time(TextField):
    """This class defines what can be tested for Time components.

    For now, this inherits the type method of the TextField.
    When it turns out the behaviour for this component must be different, remove this dependency and
    write a unique implementation of the type method here.
    """

class Toggle:
    """This class defines what can be tested for Toggle components."""
    @staticmethod
    def press(test_object, component, **kwargs) -> None:
        """This method is a helper method for the Testing class. Do not use directly."""

class Url(TextField):
    """This class defines what can be tested for Url components."""
