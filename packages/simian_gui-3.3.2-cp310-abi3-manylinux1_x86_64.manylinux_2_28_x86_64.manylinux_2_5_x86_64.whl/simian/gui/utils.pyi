from _typeshed import Incomplete
from pandas import DataFrame, Series as Series
from pathlib import Path
from simian.gui import form
from typing import Any

classes: Incomplete
classNames: Incomplete
COLUMN_KEYS: Incomplete

def setSubmissionData(payload: dict, key: str, data, **options) -> tuple[dict, Any]:
    """Given a payload, set of keys and data, set the submission data for one of the components.

    If there is already submission data present for that component, it is replaced. For DataGrids
    and EditGrids (that contain subcomponents), data for all subcomponents is set at once, so the
    key of the DataGrid/EditGrid must be provided. For these components, the following types of
    input data are supported:
    * list of dicts with fields matching the keys of the components. One dict per row in the grid.
    * list of lists with the nested lists containing the data per row.
    * dict with lists with the lists containing the data per column.
    * Pandas DataFrame with one column for each of the components in the grid.
    ** If the input has no variable names, the columns are assumed to be in the same order as the
    components in the grid
    ** If the input has variable names, they must match the keys of the components in the grid.
    For other types of components, the input data is directly set to the submission data without
    preprocessing.
    This supports up to one level of form nesting.
    The key must refer to an existing component and for example names of checkboxes in a Selectboxes
    component are not supported.

    Args:
        payload:        The payload to which submission data must be added.
        key:            Key of the component whose submission data to add/change.
        data:           Data to set as submission data. This is generally a single value. However,
                        for DataGrid and EditGrid components, the options are described above.
        nested_form:     Key of the nested form containing the component whose key is provided. Can
                        be empty.
        parent:         Key of the parent component.
        customization:  Options used to change the font and format of cells in an HtmlTable composed
            component.

    Returns:
        payload:        The payload to which submission data has been added.
    """
def addConditionalClass(parent, class_name: str, condition: str):
    """Add a Logic object to the given parent that sets the class when the given condition holds.

    Args:
        parent:     Parent component to add the logic to.
        class_name: Name of the class(es) to add. Separate multiple classes with spaces.
        condition:  The JavaScript condition that holds when the class is added to the component.
            Must assign 'result'.
    """
def getCache(meta_data: dict, name: str) -> tuple[None | dict, bool]:
    """Get cached data for a given name.

    Args:
        meta_data:      Metadata including the session ID.
        name:           Name of the cached element to return.

    Returns:
        data:           The data requested (if found). If not found, this is an empty double.
        isFound:        Whether or not the data was found.
    """
def getSubmissionData(payload: dict, key: str, nested_form: str = '', parent: str = ''):
    """Return submission data given a payload, a component key and an optional nested form key.

    This supports one level of form nesting.

    Args:
        payload:            The payload holding the submission data.
        key:                The key of the component whose value(s) to return.
        nested_form:        Key of the nested form the component is in. This must be used if the
            component is in a nested form.
        parent:             Key of the parent component. Use for EditGrids, Selectboxes etc.

    Returns:
        data:               The submission data for the requested component.
        is_found:           True if the submission data was found.
    """
def isCurrentForm(payload: dict, key: list):
    """Check if the key of the currently shown form is equal to one of the input keys."""
def payloadToString(payload_out: dict | str) -> str:
    """Converts the payload dict to a json string.

    When the contents of the form field is already a string, that string is preserved, preventing
    extra quotes that may be added otherwise.

    Args:
        payload_out:    The payload dict to convert to string.

    Returns:
        payload_str:    The string version of the payload_out dict.
    """
def setCache(meta_data: dict, name: str, data):
    """Cache data under a given name to be retrieved later."""
def switchForms(payload: dict, form_key: str | form.Form):
    """Switch forms by changing the value of a hidden textfield.

    Only the nested form with the given key is shown.
    """
def encodeImage(image_file: Path | str) -> str:
    """Create base64 encoded data url.

    Args:
        image_file:      Path to the image. Can be relative if it is on the path.

    Returns:             Encoded image as data url.
    """
def addComponentsFromTable(parent, build_table: DataFrame | list[list], column_names: list[str] | None = None) -> dict:
    """Add components specified in build_table to the parent form/component.

    Args:
        parent: Form or component to which the components defined in build_table are added.
        build_table: Specifications for the components to create. Must be either a Pandas DataFrame
            or input that can be used in a DataFrame constructor with the column_names input. If the
            non-DataFrame input is not valid, the DataFrame constructor raises a ValueError.

        - key:            Component key. Must be a valid variable name and unique per level.
        - type/class:     Component type or class for creating the component.
        - level:          Nesting level. Top level components (relative to parent) have level 1.
                          Nested components, e.g. in a Panel, increase by 1. If the column is not
                          present, all levels will be set to 1.
        - options:        Struct with options, may contain any property that can be set to the
                          component. Use None to leave unspecified. If the column is not present,
                          `None` is used in all rows. Fields `defaultValue`, `label`, `tooltip`,
                          `key` and `type` in options are ignored.
        - defaultValue:   The default value for the component, must be of a valid data type for the
                          component. Use None to leave unspecified. If the column is not present,
                          all defaultValues will be set to None.
        - label           Label for the component. Use None to leave unspecified. If the column is
                          not present, all labels will be set to None.
        - tooltip         Tooltip for the component. Use None to leave unspecified. If the column
                          is not present, all tooltips will be set to None.
        column_names: (Optional) List of column names for non-DataFrame build_table inputs. Defaults
            to the fields of the build_table input argument (as stored in utils.COLUMN_KEYS).

    Returns:
        Dictionary with the component keys as keys and the created components as values.

    Raises:
        ValueError: When invalid types/classes are specified.
    """
def getSessionFolder(meta_data: dict, create: bool = False) -> str:
    """Get the path to the session folder.

    Args:
        meta_data: The meta data for the session.
        create (optional): Create the session folder if it does not exist yet. Defaults to False.

    Returns:
        Session folder path.
    """

class Plotly:
    """Plotly util class."""
    data: Incomplete
    layout: Incomplete
    config: Incomplete
    figure: Incomplete
    def __init__(self, payload_value: None | dict = None) -> None:
        """Create Plotly utility object, optionally from payload values.

        Args:
            payload_value:  (Optional) Plot values from the payload.
        """
    def clearFigure(self, keepLayout: bool = False):
        """Clear the figure contents.

        Clears the figure data and most of the layout (title, axis, etc.).

        Args:
            keepLayout: (optional): Keeps the existing layout in the figure. Defaults to False.
        """
    def fromStructSpecific(self, json_dict: dict):
        """Plotly specific json load functionality. Loads the values definitions from the json."""
    def preparePayloadValue(self) -> dict:
        """Creates the payload representation for the Plotly object for manual payload edits.

        Useful for updating plots in EditGrid rows. Otherwise use the setSubmissionData function.

        Returns:
            payloadValue:    The Plotly objects's representation that can be put in the payload.
        """
    def addShape(self, data: dict, advanced_paths: bool = False):
        """Add a shape to the Plotly figure.

        Args:
            data (dict): Shape specification. See the `add_shape` method documentation on
            https://plotly.com/python-api-reference/generated/plotly.graph_objects.html for details
            on possible input arguments.

            Note that x0 and x1 may be specified as an array x, and y0 and y1 as an array y:
                {'type': 'line', 'x': [0, 100], 'y': [200, 300]}
            will be converted to
                {'type': 'line', 'x0': 0, 'x1': 100, 'y0': 200, 'y1': 300}

            Similar, paths may also be contructed in a similar way:
                {'type': 'path', 'x': [0, 0, 100, 100], 'y': [0, 100, 100, 0], 'closed': True}
            will be converted to
                {'type': 'path', 'path': 'M0,0L0,100L100,100L100,0Z'}

            advanced_paths (bool, optional): Use advanced paths that may contain Bezier curves and
            multiple elements. Defaults to False.
            The path
                {
                    'type', 'path',
                    'command': [['M', 'L', 'L'], ['M', 'Q', ',']],
                    'x': [[0, 100, 100], [0, 100, 100]],
                    'y': [[0, 0, 100], [0, 0, 100]],
                    'closed': [True, False],
                }
            defines two elements, the second being a quadratic curve.

        Raises:
            ValueError: Errors when an incorrect shape type is specified.
        """
    def getShapes(self, advanced_paths: bool = False) -> list:
        """Process the raw shape definitions to get x and y data in lists.

        Args:
            advanced_paths (bool, optional): Use advanced paths that may contain Bezier curves and
            multiple elements. Defaults to False.

        Returns:
            list: List of shape definitions.
        """

def dispatchEvent(meta_data: dict, payload: dict) -> dict:
    """Dispatch the event to a function based on the event name.

    Forwards the call to the function corresponding to the event, i.e. the event
    'dispatch.events.my_function' calls payload = dispatch.event.my_function(meta_data, payload).

    Args:
        meta_data:  The meta data dictionary.
        payload:    The payload in.

    Returns:
        The payload out.

    Raises:
        ImportError: When no method can be found with the same name as the event.
    """
def getEventFunction(meta_data: dict, payload: dict) -> callable:
    """Get the function object that corresponds to the event name.

    'dispatch.events.my_function' returns <function dispatch.event.my_function>.

    Args:
        meta_data:  The meta data dictionary.
        payload:    The payload in.

    Returns:
        The function object to be called.

    Raises:
        ImportError: When no method can be found with the same name as the event.
    """
def addAlert(payload: dict, message: str, type: str) -> dict:
    """Add alert to the payload.

    Args:
        payload (dict): Payload dictionary to append with the alert.
        message (str): Alert message to display.
        type (str): Message type (style).

    Returns:
        dict: _description_
    """
