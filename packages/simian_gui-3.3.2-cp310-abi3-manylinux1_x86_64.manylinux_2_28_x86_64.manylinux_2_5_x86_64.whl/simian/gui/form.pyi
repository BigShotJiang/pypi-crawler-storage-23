from _typeshed import Incomplete
from pathlib import Path
from simian.gui import component
from typing import Callable

class Form:
    """Objects of type FORM hold all components of a form.

    See https://help.form.io/userguide/forms/ for more information on forms in general.

    Attributes:
        components (list): List of all component objects of the form.
        display (str): Type of the form.

    TODO: Attribute checks and protection
    """
    CALLBACKS: Incomplete
    COMPONENT_HOOKS: Incomplete
    HOOKS: Incomplete
    CSS: Incomplete
    JS: Incomplete
    LINK: Incomplete
    components: Incomplete
    @components.setter
    def components(self, comps: list):
        """Form.components setter method. Ensures that the specied list contains only Components.

        Args:
            comps (list): list of components to put in the form.
        """
    display: Incomplete
    @display.setter
    def display(self, *args) -> None:
        """Do not allow setting the display value outside the constructor."""
    def __init__(self, display_value: str = None, from_file: None | Path | str = None) -> None:
        """Create a Form object and add components to it."""
    def addComponent(self, *args) -> None:
        """Add one or more components to the form.

        Args:
            self         The Form to which a component must be added.
            args         A number of component objects to add to the form.
        """
    def addNestedForms(self, form_keys: list[str], form_create_fcn: list[callable], form_inputs: None | list = None, target_component=None) -> list[component.Form]:
        """Add nested forms to the main form using keys, functions, and possibly input arguments.

        Only the first nested form is shown, the others are hidden.

        Args:
            form_keys:          List of key strings to identify the nested forms.
            form_create_fcn:    List of form creation function objects.
            form_inputs:        (Optional) List of form creation method inputs.
            target_component:   (Optional) Component to add nested forms to. Defaults to the form.

        Returns:
            A list with the nested forms that were created.

        Note that debugging the functions specified in the inputs is not possible. For debugging to
        work the functions need to be executed in the application specific code. The alternative for
        this method is to use the following:
            nested_forms = form_obj.addNestedForms(form_keys, [lambda *args: None] * len(form_keys))
            for i_form, i_fill_fcn, i_inputs in zip(nested_forms, form_create_fcn, form_inputs):
                i_fill_fcn(i_form, *i_inputs)
        """
    @staticmethod
    def addCustomCss(css: str, attributes: dict = {}, href=None):
        """Add custom CSS code to <style>.

        Args:
            css (str): Custom CSS code.
            attributes (dict): Dictionary with attributes for <style>.
            href (str): Link to external stylesheet.
        """
    @staticmethod
    def addCustomJavaScript(js: str, attributes: dict = {}):
        """Add custom JavaScript code to <script>.

        Args:
            js (str): Custom JavaScript code.
            attributes (dict): Dictionary with attributes for <script>.
        """
    @staticmethod
    def fromStruct(json_struct):
        """Turn a struct as translated from json, into a Form object, including components.

        Args:
            json_struct (dict):  JSON structure to create a Form from.

        Returns:
            form (Form):         The form created from the json structure.
        """
    def addFromJson(self, form_definition_file: str):
        """Create and add components defined in a json form representation to the form.

        Returns a dict with the keys and objects of the created components."""
    def hasComponents(self):
        """Returns whether the form can have subcomponents."""
    def jsonEncode(self):
        """Returns the JSON encoding of the Form object."""
    def jsonSimplify(self):
        """Custom encoding for form.io Forms.

        This removes hidden nested forms at the top-level of the form to reduce the amount of data
        sent to the client and it improves performance of jsonencoding.

        Returns:
            self_dict (dict): Simplified representation of the Form.
        """
    @staticmethod
    def initializer(key: str):
        """Undocumented."""
    @staticmethod
    def componentInitializer(**kwargs: Callable[[component.Component], None]):
        """Register initialization hook(s) for component(s).

        Args:
            Named arguments, where the names are component keys and the values are functions that
            take the component as input argument.
        """
    @staticmethod
    def callback(event_name: str):
        """Undocumented."""
    @staticmethod
    def eventHandler(**kwargs: Callable[[dict, dict], dict]):
        """Register event handler(s) for event(s).

        Args:
            Named arguments, where the names are event names and the values are functions that
            take meta_data and payload as the input and return the updated payload.
        """
