from _typeshed import Incomplete
from collections.abc import Callable as Callable
from simian.gui import component
from simian.gui.component import Component as Component
from typing import Any

STATUS_THEMES: Incomplete
CONTENT: str
DEFAULT_VALUE: Incomplete
STATUSES: Incomplete

class Builder:
    """Composed component Builder class."""
    parameters: Incomplete
    key: Incomplete
    def __init__(self) -> None: ...
    def get(self, name, default):
        """Get a stored parameter.

        Args:
            name (string): Name of the parameter to get.
            default (any): Default value to use when the parameter has not been set previously.

        Returns:
            any: Parameter value.
        """
    @staticmethod
    def set(**kwargs):
        """Set parameters by specifying keyword arguments."""

class StatusIndicator(Builder):
    """Create a container with display and value components for status indicators.

    display: HtmlElement componentwith the specified styling.
    value: Hidden component for setting the value.
    """
    @staticmethod
    def create(key, parent=None, content: str = ..., defaultValue: str = ..., statuses: list = ...):
        '''Create display HtmlElement and value (hidden) TextField components to use as status
        indicators.

        Args:
            key:            Key of the composed component.
            parent:         Parent container. Can be a Form or any Component that has a
            content:        Text value to display (static).
            defaultValue:   The default value used for theming the control. Can be any of
                            the values defined in statuses.
            statuses:       list of dicts with keys "value" and "theme". Can be used to
                            create a mapping from a context specific value to one of the
                            bootstrap themes. Add field "content" to change the text based
                            on the value.

        Example:
          myStats = simian.gui.composedComponent.StatusIndicator.create(
              "statusTest", appForm, ...
              "content", "Input", ...
              "statuses", struct("value", {"noData", "notStarted", "inProgress", "completed"},
              "theme", {"dark", "danger", "warning", "success"}), ...
              "defaultValue", "notStarted");
        '''
    def __init__(self, parent: component.Composed) -> None:
        """StatusIndicator.

        Create display HtmlElement and value (hidden) TextField components to use as status
        indicators.
        """
    @staticmethod
    def get_component_initializer(content: str = ..., defaultValue: str = ..., statuses: list = ...):
        '''Get the component initializer. Allows setting the values on the generic Composed
           component that is generated from a json form.

        Args:
            content (str, optional): _description_. Defaults to "Status".
            defaultValue (str, optional): _description_. Defaults to "muted".
            statuses (list, optional): _description_. Defaults to STATUSES_DICT.
        '''
    @staticmethod
    def initialize_component(comp: component.Composed, content: str, defaultValue: str, statuses: list):
        """Initialize the component."""
    @staticmethod
    def update(payload: dict, key: str, status: str, nested_form: str = '', parent: str = '') -> dict:
        """Update the value component created with the StatusIndicator component.

        Args:
            payload:         Payload whose submission data to update.
            key:             The key of the status indicator component.
            status:          The new status to have the component indicate.
            nested_form:     (Optional) the nested form in which to search for the status indicator.
            parent:          (Optional) the key of the parent component.

        Returns:
            payload:        The payload in which the submission has changed such that a status
                indicator is updated.
        """

class PropertyEditor(Builder):
    '''Property Editor with support for boolean, numeric, text and selection data types.

    Add this class to your form as a composed Component. Use the get_initializer function to disable
    editing the properties, to set the column label and to hide the DataGrid when no properties are
    available.

    Available datatypes, component type, component key.
    - boolean   checkbox    prop__Boolean
    - numeric   number      prop__Number
    - select    select      prop__Selection
    - text      textfield   prop__Text

    Refer to the `prepare_values` and `get_values` methods for easier preparation of the submission
    data and to extract the values.

    Syntax:
        Form.componentInitializer(
            property_editor=PropertyEditor.get_initializer(
                defaultValue=PropertyEditor.prepare_values(prop_meta=[...], prop_values=[...])
                column_label="Custom column header"
            )
        )
        comp = component.Composed("property_editor", form)
        comp.className = "simian.gui.composed_component.PropertyEditor"

    Adding support for extra data types:
    - Create a sub-class of this class.
    - Extend the DICT_TYPE_CONTROL property with the parameter type(s) and new component key(s).
    - create component objects for the new data types and add them with the add_datatype_util. Note
        that you cannot use initializer functions for these component.
    - Note that any validation (including required) must be implemented as custom validation. Meta
      data is available as `row.meta`.
    '''
    DICT_TYPE_CONTROL: Incomplete
    def __init__(self, parent: component.Composed) -> None:
        """Property Editor constructor."""
    @staticmethod
    def add_datatype_util(parent: component.Composed, new_datatypes: list[Component]):
        """Add property editor components to the property editor in a subclass.

        Args:
            new_datatypes:      List of property editor components to add to the DataGrid.
        """
    @staticmethod
    def get_initializer(default_value: list[dict] | None = None, allow_editing: bool = True, column_label: str = 'Properties', addAnother: str = 'Add value', hide_when_empty: bool = True) -> Callable:
        '''Return the parameterized initializer function for the Property Editor.

        Args:
            default_value:      List of dicts with default values. Use the prepare_values function.
            allow_editing:      Allow the user to edit the values. Defaults to True.
            column_label:       The column label to be shown in the table. Defaults to "Properties".
            addAnother:         Label on button to add a row to a property. Defaults to "Add value".
            hide_when_empty:    Hides the editor when no properties are available. Defaults to True.

        Returns:
            The initializer function to be applied on the property Editor Composed Component.
        '''
    @classmethod
    def get_values(cls, table_values: dict = None) -> list[Any]:
        '''Get the values from the property Editor table payload values.

        Args:
            table_values:   the values of the property editor DataGrid.

        Example:
            table_values, _ = utils.getSubmissionData(payload, key="property_editor")
            value_list = Editor.get_values(table_values)
        '''
    @classmethod
    def prepare_values(cls, prop_meta: list[dict], prop_values: list[Any] | None = None) -> dict:
        '''Prepare Editor contents. Note that values specified here are not validated.

        The properties that can be set per Editor row:
        {
            "datatype": "property datatype",    # Mandatory
            "label": "Property name",           # Mandatory
            "tooltip": "Tooltip text",
            "required": False,
            "defaultValue": "Default value",    # Defaults to a minLength long list of Nones.
            "min": 0,                           # Numeric
            "max": 2,                           # Numeric
            "decimalLimit": 2,                  # Numeric
            "allowed": [],                      # Select component data source values definition.
            "minLength": 1,                     # {1} Scalar, or minimum array length of 0 or more.
            "maxLength": 1,                     # {1} Scalar, or maximum array length of 0 or more.
        }

        Use a list of Nones as the defaultValue to initialize the property with an array of empty
        values with the same size.

        Example:
            prep_vals = PropertyEditor.prepare_values(
                [{"datatype": "text", "label": "example"}], ["new value"]
            )
            utils.setSubmissionData(payload, key="property_editor", data=prep_vals)

        Args:
            prop_meta:      Property meta data list. `label` and `datatype` are mandatory fields.
            prop_values:    (Optional) values to show in the Editor. Defaults to the defaultValues
                the property meta data.

        Returns:
            Editor table values for the submission data.
        '''
    @staticmethod
    def generic_prop_setup(par_type: str) -> Callable:
        """Generic property editor component initializer.

        Ensures that:
        - The editor component corresponding to the meta.datatype is shown in the row.
        """
