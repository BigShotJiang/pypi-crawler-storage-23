from _typeshed import Incomplete
from simian.gui.component import Component as Component
from typing import Any

class Props:
    """Props class."""
    def jsonSimplify(self):
        """Returns a dict to export with in json format."""
    def hasComponents(self):
        """Returns whether the class has components."""

class Column(Props):
    """Defines the properties of a single column of a 'Columns' component.

    Attributes:
        width (number): How many Bootstrap grid units wide is this column (12 is full width)
        offset (number): The bootstrap column offset.
        push (number): How many bootstrap grid units to push the column
        pull (number): How many bootstrap grid units to pull the column
    """
    width: Incomplete
    offset: int
    push: int
    pull: int
    components: Incomplete
    def __init__(self, width: int = 6) -> None:
        """Construct a Column component property."""
    def addComponent(self, *args) -> None:
        """Add components to the column."""
    @staticmethod
    def fromStruct(json_dict: dict):
        """Turn a struct as translated from json, into a Column object."""

class Conditional(Props):
    """Class for defining when a component should be added to the form for processing and input."""
    show: bool
    when: Incomplete
    eq: Incomplete
    json: Incomplete
    def __init__(self, parent=None) -> None:
        """Construct a Conditional component property."""
    @staticmethod
    def fromStruct(json_dict: dict | Conditional):
        """Turn a struct as translated from json, into a Conditional object."""

class DatePickerConfiguration(Props):
    """Used to define a configuration for a date picker.

    More info: https://help.form.io/userguide/form-components/#datetime

    Attributes:
        disable (str): Comma-separated list of (ranges of) dates that should not be selectable.
        disableFunction (str): Custom function for determining which dates to disable.
            See https://flatpickr.js.org/examples/#disabling-dates
        disableWeekdays (str): Whether or not weekdays should be selectable.
        disableWeekends (str): Whether or not weekends should be selectable.
        maxDate (str): The maximum date that can be set within the date picker. Must conform to the
            datetime module's isoformat or be an empty string.
        minDate (str): The minimum date that can be set within the date picker. Must conform to the
            datetime module's isoformat or be an empty string.
    """
    minDate: Incomplete
    @minDate.setter
    def minDate(self, value) -> None: ...
    maxDate: Incomplete
    @maxDate.setter
    def maxDate(self, value) -> None: ...
    disable: str
    disableFunction: str
    disableWeekdays: bool
    disableWeekends: bool
    def __init__(self) -> None:
        """Construct a DatePickerConfiguration component property."""
    @staticmethod
    def fromStruct(json_dict: dict):
        """Turn a struct as translated from json, into a DatePickerConfiguration object."""
    def jsonSimplify(self) -> dict:
        """Create a simple representation of the DatePickerConfiguration for json conversion."""

class Error(Props):
    '''Class for defining custom validation error messages.

    Set custom error messages to be displayed with the component when the set value fails the validation criteria.
    The message are set per validation criterium.

    Note that you can use string interpolation to put validation properties in the message.

    Example:  obj.required = "{{ field }} is required. Try again."
    '''
    required: Incomplete
    min: Incomplete
    max: Incomplete
    minLength: Incomplete
    maxLength: Incomplete
    minWords: Incomplete
    maxWords: Incomplete
    invalid_email: Incomplete
    invalid_date: Incomplete
    invalid_day: Incomplete
    mask: Incomplete
    pattern: Incomplete
    custom: Incomplete
    def __init__(self, parent=None) -> None:
        """Construct a Error component property."""
    @staticmethod
    def fromStruct(json_dict: dict):
        """Turn a struct as translated from json, into an Error object."""

class Json(Props):
    """Helper class to specify Json directly."""
    json: Incomplete
    def __init__(self, jsonString: str = '') -> None:
        """Construct a Json component property."""
    def jsonSimplify(self):
        """Override jsonencode to return the json string directly."""

class Logic(Props):
    '''See https://formio.github.io/formio.js/app/examples/fieldLogic.html.

    Attributes:
        name (str): Name of the specific field logic.
        trigger (dict): When to trigger actions
            Example: trigger.type "simple"
            trigger.simple.show = true
            trigger.simple.when = "anotherKey"
            trigger.simple.eq   = "Bob"
        actions (list): The actions to trigger. list of dicts.
    '''
    name: str
    trigger: Incomplete
    actions: Incomplete
    def __init__(self, parent=None) -> None:
        """Construct a Logic component property."""
    @staticmethod
    def fromStruct(json_dict):
        """Turn a (list of) dicts as translated from json, into a list of Logic objects."""

class Tab(Props):
    """Represents a single tab in a Tabs component. Can have one or more components in it."""
    key: Incomplete
    label: Incomplete
    components: Incomplete
    def __init__(self, key: str, label: str) -> None:
        """Tab object constructor."""
    def addComponent(self, *args) -> None:
        """Add components to the column."""
    @staticmethod
    def fromStruct(json_dict: dict):
        """Turn a struct as translated from json, into an Tab object."""

class TableCell(Props):
    """Defines the properties of a single cell of a 'Table' component."""
    components: Incomplete
    def __init__(self) -> None:
        """Construct a TableCell component property."""
    def addComponent(self, *args) -> None:
        """Add components to the table cell."""
    @staticmethod
    def fromStruct(json_dict: dict):
        """Turn a struct as translated from json, into an Tab object."""

class TimePickerConfiguration(Props):
    """Used to define a configuration for a time picker.

    More info: https://help.form.io/userguide/form-components/#datetime

    Attributes:
        hourStep (int): The amount of hours to step when the up or down button is pressed.
        minuteStep (int): The amount of minutes to step when the up or down button is pressed.
        showMeridian (bool): To show the am or pm for the time.
    """
    hourStep: int
    minuteStep: int
    showMeridian: bool
    def __init__(self) -> None:
        """Construct a TimePickerConfiguration component property."""
    @staticmethod
    def fromStruct(json_dict: dict):
        """Turn a struct as translated from json, into a TimePickerConfiguration object."""

class Validate(Props):
    """Validation object to be used as a property of a component.

    Attributes:
        required (bool): True if the field is required.
        minLength (int): For text input, this checks the minimum length of text for valid input.
        maxLength (int): For text inputs, this checks the maximum length of text for valid input.
        minWords (int): For text inputs, this sets the minimum number of words.
        maxWords (int): For text inputs, this sets the maximum number of words.
        pattern (str): For text input, this checks the text against a Regular expression pattern.
        custom (str): A custom javascript based validation.
        min (number): The minimum value the number could be.
        max (number): The maximum value the number could be.
        step (number): The granularity of this number input.
        integer (bool): If this number should be an integer.
        customMessage (str): Custom message to display when the field is invalidated.
        json (Json): Custom validation specified using JSONLogic.
    """
    required: bool
    minLength: Incomplete
    maxLength: Incomplete
    minWords: Incomplete
    maxWords: Incomplete
    pattern: Incomplete
    custom: Incomplete
    min: Incomplete
    max: Incomplete
    step: Incomplete
    integer: Incomplete
    customMessage: Incomplete
    json: Incomplete
    def __init__(self, parent=None) -> None:
        """Construct a Validate component property."""
    @staticmethod
    def create(component=None, **kwargs) -> Validate:
        """Create a Validate object (for the specified component).

        If the component already has a Validate object, it is extended with the given inputs.
        Unexpected inputs are ignored.

        Optional args:
            component   (Component): The component to add the validation to.
            required    (bool): Value may not be empty when true.
            minLength   (int): For text: the minimum length of the text.
            maxLength   (int): For text: the maximum length of the text.
            minWords    (int): For text: the minimum number of words.
            maxWords    (int): For text: the maximum number of words.
            pattern     (str): For text: checks the text against a Regular expression pattern.
            custom      (str): A custom javascript based validation.
            min         (float): For numbers: the minimum allowed value.
            max         (float): For numbers: the maximum allowed value.
            integer     (bool):  If the number should be an integer.
            customMessage (str): Custom message to display when the field is invalidated.
            json        (str): Custom validation specified using JsonLogic.

        Returns:
            Validate: The Validate object.
        """
    @staticmethod
    def fromStruct(json_dict: dict | Validate) -> Validate:
        """Turn a dict as translated from json, into a Validate object."""
    def jsonSimplify(self) -> dict:
        """Override jsonencode to remove all empty properties."""

def create_disable_action(disable_target: bool = True) -> dict:
    """Returns a disable action for a Logic object.

    Args:
        disable_target: (Optional) When False, returned action enables component. Defaults to True.

    Returns:
        The disable (or enable) action definition for a Logic object.

    Example:
        enable_action = create_disable_action(disable_target=False)
    """
def create_disable_logic(trigger_type: str, trigger_value: str | dict | tuple[str, Any], target_component: Component | None = None, disable_target: bool = True) -> Logic:
    '''Add disable (or enable) logic to the target Component.

    The target component is disabled when the component for which the unique key is specified has
    the same value as specified in the inputs. The target component will be enabled again, when the
    value of the switch component no longer matches the specified value.

    Note that adding disable logic to a disabled target component does nothing. You need to add
    disable logic to an enabled component or enable logic to a disabled one.

    Args:
        triggerType:        The trigger type. See create_trigger for the allowed values.
        triggerValue:       The trigger value. See create_trigger for the allowed values.
        target_component:   (Optional) Component to add a Logic object with disable action to.
        disable_target:     (Optional) Set to False to enable the component. Defaults to True.

    Returns:
        The Logic object with the disable action of the given component.

    Example:
        # Disable the \'wind\' option when the \'drag\' option has the value false.
        new_logic = create_disable_logic(
            trigger_type="simple",
            trigger_input=["enableDrag", False],
            target_component=wind_enable_button,
        )

        # Reuse the disable logic object on another component.
        other_component.logic.append(new_logic)
    '''
def create_logic(logic_name: str, trigger_type: str, trigger_value: str | dict | tuple[str, Any], actions: list | dict, target_component: Component | None = None) -> Logic:
    """Add Logic object that triggers action(s) when the switch component's has a certain value.

    Note that for a simple action, the opposite logic and action are automatically available in the
    front-end. E.g. for simple disable logic you do not need to also add enable logic.

    Args:
        logic_name:         Name to assign to the created Logic object.
        triggerType:        The trigger type.
        triggerValue:       The trigger value. See create_trigger for the allowed values.
        actions:            (List of) action definitions.
        target_component:   (Optional) Component to add the created Logic object to.

    Returns:
        The Logic object with the simple value equality check.
    """
def create_trigger(trigger_type: str, trigger_value: str | dict | tuple[str, Any]) -> dict:
    '''Create a Logic trigger definition.

    Args:
        triggerType:        The trigger type.
        triggerValue:       The trigger value.

    The trigger type and value must be one of the following combinations:
    * "event",          "EventName"                     (triggers when the event EventName occurs.)
    * "trigger",        trigger definition dictionary.

    The following definitions trigger when the component with key "key" has the given value.
    Note that data.key does not work in case of intermediate data components.
    * "simple",         {"key", value}:                       (\'Simple\' trigger)
    * "javascript",     "result = data.key == value"
    * "result",         "data.key == value"                   (Shorter \'javascript\' trigger.)
    * "json",           "{"==": [{"var": "data.key"}, value]}"

    Examples:
        createTrigger("event", "throwing");
        createTrigger("simple", {"enableDrag", false});
        createTrigger("javascript", "result = data.options.enableDrag == false");
        createTrigger("result", "data.options.enableDrag == false");
        createTrigger("json", "{"==": [{"var": "data.options.enableDrag"}, false]}");

    Raises:
        ValueError:     When the input is not an iterable or string with the expected format.

    Returns:
        The trigger definition in a dict.
    '''
