"""entrypoint module.

Contains the entry_point function which can be used to the webserver to formio.

Copyright 2020-2024 MonkeyProof Solutions BV.
"""

import json
import logging
import platform
import subprocess
import sys
import threading
import traceback
from typing import Union

lock = threading.Lock()

FCN_NAMES = {"init": "init", "update": "event", "upload": "upload", "download": "download"}


def entry_point(operation: str, meta_data: dict, payload_in: Union[dict, str]) -> Union[dict, str]:
    """Entry point for connecting the webserver with the form.

    Args:
        operation:      The type of operation that is to be performed.
        meta_data:      Information on the application to be run.
        payload_in:     The information to be communicated from JavaScript to Python.

    Returns:
        payload_out:    The information to be communicated from Python to JavaScript. Type is the
            same as the payload_in type.

    Raises:
        Exception:      When errors occur in the backend.
        RuntimeError:   When Simian GUI cannot be used. E.g. due to an invalid license.
    """
    if operation == "config":
        # Test whether Simian GUI can be used and raise an error if it cannot be used.
        assert_simian_gui_imports()

    from simian.gui import Form
    from simian.gui.internal import callbackWrapper

    with lock:
        # Acquire a thread lock and call the callback wrapper.
        fcn_gen = callbackWrapper(operation, meta_data, payload_in)

        fcn, fcn_inputs = next(fcn_gen)

        try:
            if fcn is None:
                # No function returned.
                payload_out = next(fcn_gen)

            else:
                # User function found. Execute it.
                payload_gen = fcn(*fcn_inputs)

                if operation in FCN_NAMES.keys() and not isinstance(payload_gen, dict):
                    raise TypeError(
                        f"Invalid Simian app: the `gui_{FCN_NAMES[operation]}` function should "
                        f"return the payload dictionary, not a {type(payload_gen).__name__}."
                    )

                if operation == "init":
                    execute_component_initializers()

                payload_out = fcn_gen.send(payload_gen)

            if operation == "refresh":
                # After the close (handled above) we must also handle the refresh and init.
                fcn, fcn_inputs = next(fcn_gen)

                if fcn is not None:
                    # User gui_refresh is found. Execute it.
                    # It only takes the meta data as input and does not return anything.
                    fcn(*fcn_inputs)

                fcn, fcn_inputs = next(fcn_gen)

                if fcn is None:
                    # No function returned.
                    payload_out = next(fcn_gen)

                else:
                    # User gui_init found. Execute it.
                    payload_gen = fcn(*fcn_inputs)
                    execute_component_initializers()

                    payload_out = fcn_gen.send(payload_gen)

        except StopIteration as exc:
            logging.debug(exc)

        Form.HOOKS.clear()
        Form.COMPONENT_HOOKS.clear()
        Form.CALLBACKS.clear()

    return payload_out


def entry_point_deploy(
    app_module_full_name: str,
    input_list: Union[None, list, str] = None,
    operation: Union[None, str] = None,
    meta_data: Union[None, dict] = None,
    payload_in: Union[None, dict, str] = None,
) -> dict:
    """entry_point wrapper function for deployments.

    Accepts the fully qualified name  of the application to start. The three entry_point inputs can be specified
    as three separate inputs, or as a list or string version of these inputs. The string version is
    processed with `json.loads` to get the list of inputs.

    Examples:
        response = entry_point_deploy("simian.examples.ballthrower", request_data)

        response = entry_point_deploy(
            "simian.examples.ballthrower",
            operation=request_data[0],
            meta_data=request_data[1],
            payload_in=request_data[2],
        )

    Args:
        app_module_full_name:   Fully qualified name of the application to run.
        input_list:             (Optional) List or string of entry_point inputs. (Defaults to None)
        operation:              (Optional) The type of operation that is to be performed. (Defaults
            to None)
        meta_data:              (Optional) Information on the application to be run. (Defaults to
            None)
        payload_in:             (Optional) The information to be communicated from JavaScript to
            Python. (Defaults to None)

    Returns:
        response:       The information to be communicated from Python to JavaScript. When an error
            occurs the 'returnValue' field remains empty, and the error information is put in the
            'error' and 'stacktrace' fields.
    """
    input_message = ""

    if input_list is None:
        # Three separate inputs. Checked later.
        pass

    elif isinstance(input_list, (str, bytes)):
        # Input is a string. Convert to Python objects using the json module.
        input_list = json.loads(input_list)

        if len(input_list) == 3:
            # Correct number of inputs. Unpack.
            operation, meta_data, payload_in = input_list
        else:
            input_message += "'input_list' string must contain three values when unpacked. "

    elif len(input_list) == 3:
        # Correct number of inputs. Unpack.
        operation, meta_data, payload_in = input_list

    else:
        input_message += "'input_list' must contain three values. "

    if len(input_message) == 0:
        # The three inputs for the entry_point function should exist.
        if not isinstance(operation, str):
            input_message += "'operation' must be a string. "

        if not isinstance(meta_data, dict):
            input_message += "'meta_data' must be a dict. "

        if not isinstance(payload_in, (str, dict)):
            input_message += "'payload_in' must be string or dict. "

    if len(input_message) > 0:
        # An input error message was added. Return it to the user.
        return {
            "error": {
                "message": "Application contacted with unexpected values.",
                "stacktrace": "entry_point_deploy was called with incorrect inputs:"
                + input_message,
            }
        }

    meta_data.update({"namespace": app_module_full_name})

    try:
        payload_out = entry_point(operation=operation, meta_data=meta_data, payload_in=payload_in)

        from simian.gui import utils

        response = {"returnValue": utils.payloadToString(payload_out)}

    except Exception as exc:
        logging.error("Application encountered an error: %r", exc)
        response = {
            "error": {
                "message": str(exc),
                "stacktrace": traceback.format_tb(exc.__traceback__),
            }
        }
    return response


def assert_simian_gui_imports() -> None:
    """Check whether Simian GUI can be used by importing it.

    When the subprocess fails, a runtime error is thrown here to stop the main process and a better
    response is given to the user.

    Raises:
        RuntimeError:     When Simian GUI cannot be imported.
    """
    try:
        import simian.gui

        msg = None

    except (RuntimeError, SystemError) as exc:
        msg = f"Form startup failed: {str(exc)}"

    if msg:
        logging.error(msg)

        raise RuntimeError(msg)


def execute_component_initializers():
    """Initialize component initializer hooks attached to the form."""
    from simian.gui import Form

    for hook in Form.HOOKS:
        hook()


def get_diagnostic_information() -> str:
    """Get information about the platform and Python."""
    # Get information on the installed packages.
    packages = subprocess.check_output([sys.executable, "-m", "pip", "list"]).decode()

    # Get platform information.
    pinfo = platform.uname()
    platform_info = [f"{t:10s}- {getattr(pinfo, t)}" for t in (list(pinfo._fields) + ["processor"])]

    # Create a summary of the gathered information.
    return (
        f"Python version: {sys.version}\r\n"
        + f"\r\nInstalled packages:\r\n{packages}"
        + "\r\n\r\nPlatform information"
        + "\r\n".join(platform_info)
    )
