## Summary

<!-- What does this PR do? -->

## Changes

<!-- List the key changes -->

-

## Test plan

<!-- How was this tested? -->

- [ ] `pytest tests/ -v` passes
- [ ] `ruff check src/ tests/` clean
- [ ] Schema validation passes for affected output
- [ ] Golden tests updated (if output format changed)
