"""zip-meta-map: Generate machine-readable metadata manifests for ZIP archives and project directories."""

__version__ = "0.2.1"
