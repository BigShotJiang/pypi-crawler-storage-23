# tiny-node-tool

A minimal Node.js/TypeScript tool for fixture testing.
