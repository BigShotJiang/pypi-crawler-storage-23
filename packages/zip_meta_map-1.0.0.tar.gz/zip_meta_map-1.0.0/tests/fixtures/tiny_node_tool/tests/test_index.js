const assert = require("assert");
assert.strictEqual(typeof "hello", "string");
console.log("Tests passed");
