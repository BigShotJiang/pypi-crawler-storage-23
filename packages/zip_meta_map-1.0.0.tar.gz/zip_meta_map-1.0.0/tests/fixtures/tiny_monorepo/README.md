# tiny-monorepo

A minimal monorepo for fixture testing.

## Packages

- `packages/core` — shared utilities
- `packages/cli` — CLI entry point
