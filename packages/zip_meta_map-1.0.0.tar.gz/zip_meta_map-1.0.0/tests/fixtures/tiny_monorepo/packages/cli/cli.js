#!/usr/bin/env node
const { add } = require("@tiny/core");
console.log(add(1, 2));
