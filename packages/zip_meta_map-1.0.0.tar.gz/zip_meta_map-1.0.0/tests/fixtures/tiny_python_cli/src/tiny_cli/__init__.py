"""Tiny CLI."""
