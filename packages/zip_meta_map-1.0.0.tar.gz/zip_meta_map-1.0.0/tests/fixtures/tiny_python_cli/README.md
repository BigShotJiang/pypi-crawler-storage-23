# tiny-cli

A tiny CLI tool for testing zip-meta-map.
