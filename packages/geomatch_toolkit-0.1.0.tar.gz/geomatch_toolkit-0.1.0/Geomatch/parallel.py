"""
Parallel geomatching and optimal match selection.

This module provides tools to:

- convert latitude/longitude to 3D Cartesian coordinates on a sphere,
- compute haversine distances,
- run a parallel geomatching workflow that filters candidates in space and time,
- compute an "optimal" match between source and candidate observations
  based on a combined cost function (distance, time, pressure, and cloud flags),
- format search/source data into structures suitable for feather output.

It is typically used as part of the larger TROPOMI–IASI/ACE-FTS
collocation and geomatching workflow.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import concurrent.futures
import itertools
from . import geomatch as gm
import math

# Global configuration parameters (physical thresholds and normalisation terms)
nh = 50        # 50 km horizontal distance scale
nt = 2         # 2 hours time scale
npres = 500    # 500 Pa pressure scale
radius_earth = 6371  # Earth radius in km


def latlon_2_sphere(lat, lon, r):
    """Convert latitude/longitude coordinates to 3D Cartesian coordinates.

    Args:
        lat: Latitude in degrees (from -90 to +90).
        lon: Longitude in degrees (from -180 to +180).
        r: Sphere radius (e.g. Earth radius in km: 6371).

    Returns:
        tuple[float, float, float]: The Cartesian coordinates ``(x, y, z)``
        on the sphere of radius ``r``.
    """
    # lat is latitude from -90 to +90
    # lon is longitude from -180 to +180
    # r is the radius (e.g. Earth in km: 6371)
    theta = (lat + 90.0) * (math.pi / 180.0)
    phi = (lon + 180.0) * (math.pi / 180.0)
    x = r * np.sin(theta) * np.cos(phi)
    y = r * np.sin(theta) * np.sin(phi)
    z = r * np.cos(theta)
    return x, y, z


def haversine(lat1, lon1, lat2, lon2):
    """Calculate the haversine distance between two points.

    More information can be found in the
    `Haversine formula <https://en.wikipedia.org/wiki/Haversine_formula>`_.

    Args:
        lat1: Latitude of the first point in degrees.
        lon1: Longitude of the first point in degrees.
        lat2: Latitude of the second point in degrees.
        lon2: Longitude of the second point in degrees.

    Returns:
        float: Great-circle distance between the two points in kilometers.
    """
    R = 6371  # earth radius in km
    φ1 = lat1 * np.pi / 180
    φ2 = lat2 * np.pi / 180
    Δφ = (lat2 - lat1) * np.pi / 180
    Δλ = (lon2 - lon1) * np.pi / 180

    a = (
        np.math.sin(Δφ / 2) * np.math.sin(Δφ / 2)
        + np.math.cos(φ1) * np.math.cos(φ2)
        * np.math.sin(Δλ / 2)
        * np.math.sin(Δλ / 2)
    )

    c = 2 * np.math.atan2(np.math.sqrt(a), np.math.sqrt(1 - a))

    return R * c


def Optimal(dfs, dfc, output, candidates):
    """Compute optimal matches between source and candidate observations.

    For each source point, this function evaluates all associated candidate
    points and computes a normalised "distance" in a multi-dimensional space:

    - horizontal distance (using 3D Cartesian coordinates on a sphere),
    - temporal difference,
    - pressure difference,
    - optionally cloud-related parameters (for IASI).

    The candidate with the smallest combined distance metric is selected
    as the optimal match. Results are written to a feather file.

    Args:
        dfs: pandas DataFrame containing source observations. Expected to
            have columns like ``lats``, ``lons``, ``times``, ``ids``,
            ``fns``, ``n_source`` and pressure/cloud-related fields.
        dfc: pandas DataFrame containing candidate observations. Expected
            to have columns like ``latc``, ``lonc``, ``timec``, ``idc``,
            ``fnc``, and related physical parameters.
        output: Base name for the output feather file (``output + ".feather"``).
        candidates: String indicating the candidate sensor type, e.g.
            ``"IASI"``, ``"TROPOMIWFDM"`` or others. This controls which
            additional variables are included in the output.
    """
    # Extracting data from source (TROPOMI in present production) and s is used as source
    lons = dfs["lons"].values
    lats = dfs["lats"].values
    times = dfs["times"].values
    ids = dfs["ids"].values
    f_n_s = dfs["fns"].values
    numdc = dfs["n_source"].values

    # Depending on IASI and TROPOMI as source or searchspace
    if candidates == "IASI":
        c_f_c = dfc["c_fc"].values
        f_v_f = dfc["fit_value_flag"].values
        c_a_f = dfc["cloud_area_fraction"].values
        s_p_c = dfc["s_pc"].values
        q_a_f = dfs["qa_value"].values
        s_p = dfs["s_ps"].values  # searchspace (IASI) already in Pascal
        s_p_s = [float(i) * 100 for i in s_p]
    else:
        c_f_s = dfs["c_fs"].values
        f_v_f = dfs["fit_value_flag"].values
        c_a_f = dfs["cloud_area_fraction"].values
        s_p_s = dfs["s_ps"].values
        q_a_f = dfc["qa_value"].values
        s_p_c = dfc["s_pc"].values  # searchspace (IASI) already in Pascal
        s_p_c = [float(i) * 100 for i in s_p]

    # Extracting data from searchspace (IASI in recent production) and c is used as candidates
    lonc = dfc["lonc"].values
    latc = dfc["latc"].values
    timec = dfc["timec"].values
    idc = dfc["idc"].values
    f_n_c = dfc["fnc"].values

    # List initialization to store the optimal searchspace data
    olat = []
    olon = []
    otime = []
    oid = []
    os_p = []
    ofn = []
    odiffdist = []
    ocf = []
    ofv = []
    oca = []
    oqa = []
    odifftime = []

    it = 0
    num = 0

    # Extracting all the searchspace data corresponding to each source point
    for i in range(len(lons)):
        if i == 0:
            num = numdc[0]
        else:
            it = num
            num = num + numdc[i]

        lon = lonc[it:num]
        lat = latc[it:num]
        time = timec[it:num]
        idd = idc[it:num]
        s_p = s_p_c[it:num]
        f_n = f_n_c[it:num]

        if candidates == "IASI":
            c_f = c_f_c[it:num]
            f_v = f_v_f[it:num]
            c_a = c_a_f[it:num]

        tc = [datetime.strptime(x, "%Y-%m-%d %H:%M:%S") for x in time]
        ts = datetime.strptime(times[i], "%Y-%m-%d %H:%M:%S")

        # 1) time differences in hours
        diff_timez = [(x - ts).total_seconds() / 3600 for x in tc]
        ndt = [diff_timez[i] / nt for i in range(len(diff_timez))]

        # 2) spatial difference in spherical coordinates
        result_list = [latlon_2_sphere(x, y, radius_earth) for x, y in zip(lat, lon)]
        xsph, ysph, zsph = zip(*result_list)
        xsphs, ysphs, zsphs = latlon_2_sphere(lats[i], lons[i], radius_earth)

        diff_xy = np.sqrt(
            (xsph - xsphs) ** 2 + (ysph - ysphs) ** 2 + (zsph - zsphs) ** 2
        )  # horizontal distance in km
        ndh = diff_xy / nh  # normalization

        # 3) pressure difference
        npr = (np.array(s_p) - s_p_s[i]) / npres

        if candidates == "IASI":
            ncf = (np.array(c_f) - 1) * 1e4
            ed = [
                np.sqrt(ndh[i] ** 2 + ndt[i] ** 2 + ncf[i] ** 2 + npr[i] ** 2)
                for i in range(len(ndh))
            ]
        else:
            ed = [
                np.sqrt(ndh[i] ** 2 + ndt[i] ** 2 + npr[i] ** 2)
                for i in range(len(ndh))
            ]

        # Minimum distance point (optimal match)
        min_value_ind = np.argmin(ed)

        # Values corresponding to minimum distance and appending
        olon.append(lon[min_value_ind])
        olat.append(lat[min_value_ind])
        otime.append(time[min_value_ind])
        oid.append(idd[min_value_ind])
        os_p.append(s_p[min_value_ind])
        ofn.append(f_n[min_value_ind])
        odifftime.append(diff_timez[min_value_ind])
        odiffdist.append(diff_xy[min_value_ind])

        if candidates == "IASI":
            ocf.append(c_f[min_value_ind])
            ofv.append(f_v[min_value_ind])
            oca.append(c_a[min_value_ind])
        else:
            oqa.append(q_a_f[min_value_ind])

    if candidates == "IASI":
        data = {
            "olon": olon,
            "olat": olat,
            "otime": otime,
            "oid": oid,
            "os_p": os_p,
            "ofn": ofn,
            "odiffdist": odiffdist,
            "odifftime": odifftime,
            "ocf": ocf,
            "ofv": ofv,
            "oca": oca,
            "lons": lons,
            "lats": lats,
            "times": times,
            "ids": ids,
            "fns": f_n_s,
            "qav": q_a_f,
            "s_p_s": s_p_s,
        }
    elif candidates == "TROPOMIWFDM":
        data = {
            "olon": olon,
            "olat": olat,
            "otime": otime,
            "oid": oid,
            "os_p": os_p,
            "ofn": ofn,
            "odiffdist": odiffdist,
            "odifftime": odifftime,
            "oqa": oqa,
            "ocf": ocf,
            "ofv": ofv,
            "oca": oca,
            "lons": lons,
            "lats": lats,
            "times": times,
            "ids": ids,
            "fns": f_n_s,
            "s_p_s": s_p_s,
        }
    else:
        data = {
            "olon": olon,
            "olat": olat,
            "otime": otime,
            "oid": oid,
            "os_p": os_p,
            "ofn": ofn,
            "odiffdist": odiffdist,
            "odifftime": odifftime,
            "lons": lons,
            "lats": lats,
            "times": times,
            "ids": ids,
            "fns": f_n_s,
            "s_p_s": s_p_s,
        }

    df = pd.DataFrame(data)
    print(f"df['olon'], df['lons']: {df['olon'], df['lons']}")
    print(f"df['olat'], df['lats']: {df['olat'], df['lats']}")

    filename = output + ".feather"
    df.to_feather(filename)

def format_data_all(sensor1, sensor2, search_id, data):
    """Format data dictionaries based on sensor types."""
    lat_lon_dict = {
        "s_lat": search_id["lat"],
        "s_lon": search_id["lon"],
        "s_time": search_id["timestamp"].strftime('%Y-%m-%d %H:%M:%S'),
        "s_fn": search_id["filename"],
        "n_source": len(data.lat.tolist())
    }

    if sensor1 == "TROPOMI" and (sensor2 == "IASI" or sensor2 == "TROPOMI3"):
        lat_lon_dict.update({
            "s_ps": search_id["surface_pressure"],
            "s_cfs": search_id["cloud_summary_flag"],
            "s_fit_value_flag": search_id["fit_value_flag"],
            "s_cloud_area_fraction": search_id["cloud_area_fraction"]
        })
        data_dict = {
            'c_lat': data.lat.tolist(),
            'c_lon': data.lon.tolist(),
            'c_time': [time.strftime('%Y-%m-%d %H:%M:%S') for time in data.timestamp],
            "c_sp": data.surface_pressure.tolist(),
            "c_id": data.id.tolist(),
            "c_fn": data.filename.tolist(),
            "c_qa_value": data.qa_value.tolist()
        }
    elif sensor1 == "IASI" and sensor2 == "TROPOMI3":
        lat_lon_dict.update({
            "s_ps": search_id["surface_pressure"],
            "s_qa_value": search_id["qa_value"],
            "s_ids": search_id["index_numbers"]
        })
        data_dict = {
            'c_lat': data.lat.tolist(),
            'c_lon': data.lon.tolist(),
            'c_time': [time.strftime('%Y-%m-%d %H:%M:%S') for time in data.timestamp],
            "c_sp": data.surface_pressure.tolist(),
            "c_id": data.id.tolist(),
            "c_fn": data.filename.tolist(),
            "c_cf": data.cloud_summary_flag.tolist(),
            "c_fit_value_flag": data.fit_value_flag.tolist(),
            "c_cloud_area_fraction": data.cloud_area_fraction.tolist()
        }
    else:
        lat_lon_dict.update({
            "s_ps": search_id["surface_pressure"],
            "s_qa_value": search_id["qa_value"],
            "s_id": search_id["id"]
        })
        data_dict = {
            'c_lat': data.lat.tolist(),
            'c_lon': data.lon.tolist(),
            'c_time': [time.strftime('%Y-%m-%d %H:%M:%S') for time in data.timestamp],
            "c_sp": data.surface_pressure.tolist(),
            "c_id": data.id.tolist(),
            "c_fn": data.filename.tolist(),
            "c_cf": data.cloud_summary_flag.tolist(),
            "c_fit_value_flag": data.fit_value_flag.tolist(),
            "c_cloud_area_fraction": data.cloud_area_fraction.tolist()
        }

    return lat_lon_dict, data_dict
def parallel_thread_all(search, source, distance_km, delta, sensor1, sensor2, output=None):
    """Return all source–candidate matches within distance/time window."""
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = {}
        matches = []
        search = search.copy()
        #search = search.reset_index(drop=True).copy()
        search["tropomi_index"] = range(1, len(search) + 1)
          # Inside parallel_thread, replace the expansion loop:
        # DEBUG CHECK
        
        for _, center in search.iterrows():
            filtered = gm.filter_by_distance(center, source, distance_km)
            #print(f'filtered{filtered}')
            future = executor.submit(gm.filter_by_time, center, filtered, delta)
            #print(f'future{future}')
            futures[future] = center
            #print(f'center{center}')
            if not isinstance(center["timestamp"], datetime):
                print(f"center timestamp not datetime: {type(center['timestamp'])}, value={center['timestamp']}")
            if not np.issubdtype(source["timestamp"].dtype, np.datetime64):
                print(f"source timestamps dtype: {source['timestamp'].dtype}")
            if not isinstance(delta, timedelta):
                print(f"delta is not timedelta: {type(delta)}, value={delta}")
        for future in concurrent.futures.as_completed(futures):
            search_id = futures[future]
            try:
                data = future.result()
                print(data)
            except Exception as exc:
                print(f"{search_id} generated an exception: {exc}")
            else:
                lat_lon_dict, data_dict = format_data(sensor1, sensor2, search_id, data)
                n_matches = len(data_dict['c_lat'])
                lat_lon_dict['n_matches'] = n_matches  # <-- Add this column
                lat_lon_dict['tropomi_index'] = search_id['tropomi_index']
                for i in range(n_matches):
                    row = {**lat_lon_dict}
                    row.update({k: v[i] for k, v in data_dict.items()})
                    matches.append(row)

    dfmatches = pd.DataFrame(matches)
    return dfmatches

def run_all(distance_km, delta, sensor1, sensor2, start, end, percentage, output):
    """Save all IASI/TROPOMI matches (merged source–candidate rows)."""
    print("i)- Loading data ----")
    client = gm.connect()
    candidates = gm.get_search(client, sensor1, start, end)
    source = gm.get_source(client, sensor2, start, end)

    candidates['timestamp'] = pd.to_datetime(candidates['timestamp'], errors='coerce')
    source['timestamp'] = pd.to_datetime(source['timestamp'], errors='coerce')

    tic = time.perf_counter()
    if percentage is None:
        n = source.index.size
    else:
        n = int(source.index.size * percentage)
    print(f"ii)- Processing {n} data ---")

    dfmatches = parallel_thread_all(
        source[:n], candidates, distance_km, delta, sensor1, sensor2, output
    )

    filename = output + ".feather"
    dfmatches.to_feather(filename)
    print("iii)- Saved all source–candidate matches (skipped Optimal step)")

    toc = time.perf_counter()
    print(f"Calculation was done in {toc - tic:0.4f} seconds")

def format_data_optimal(sensor1, sensor2, search_id, data):
    """Format search and candidate data into dictionaries for further processing.

    This function prepares two dictionaries:

    - one describing the "search" (source) observation,
    - one describing the corresponding candidate observations.

    The exact content depends on the sensor combination (e.g., TROPOMI–IASI,
    IASI–TROPOMI3, ACE–IASI, etc.).

    Args:
        sensor1: Name of the primary/search sensor (e.g. ``"TROPOMI"``,
            ``"IASI"``, ``"ACEFTS"``).
        sensor2: Name of the candidate sensor.
        search_id: A pandas Series representing the current search/source
            observation.
        data: pandas DataFrame containing candidate observations associated
            with this search/source point.

    Returns:
        tuple[dict, dict]: ``(lat_lon_dict, data_dict)`` where

        - ``lat_lon_dict`` contains source-related information,
        - ``data_dict`` contains candidate-related information.
    """
    lat_lon_dict = {
        "lats": search_id["lat"],
        "lons": search_id["lon"],
        "times": search_id["timestamp"].strftime("%Y-%m-%d %H:%M:%S"),
        "fns": search_id["filename"],
        "n_source": len(data.lat.tolist()),
    }

    if sensor1 == "TROPOMI" and (sensor2 == "IASI" or sensor2 == "TROPOMI3"):
        lat_lon_dict.update(
            {
                "s_ps": search_id["surface_pressure"],
                "c_fs": search_id["cloud_summary_flag"],
                "fit_value_flag": search_id["fit_value_flag"],
                "cloud_area_fraction": search_id["cloud_area_fraction"],
            }
        )
        data_dict = {
            "latc": data.lat.tolist(),
            "lonc": data.lon.tolist(),
            "timec": [
                t.strftime("%Y-%m-%d %H:%M:%S") for t in data.timestamp
            ],
            "s_pc": data.surface_pressure.tolist(),
            "idc": data.id.tolist(),
            "fnc": data.filename.tolist(),
            "qa_value": data.qa_value.tolist(),
        }

    elif sensor1 == "IASI" and sensor2 == "TROPOMI3":
        lat_lon_dict.update(
            {
                "s_ps": search_id["surface_pressure"],
                "qa_value": search_id["qa_value"],
                "ids": search_id["index_numbers"],
            }
        )
        data_dict = {
            "latc": data.lat.tolist(),
            "lonc": data.lon.tolist(),
            "timec": [
                t.strftime("%Y-%m-%d %H:%M:%S") for t in data.timestamp
            ],
            "s_pc": data.surface_pressure.tolist(),
            "idc": data.id.tolist(),
            "fnc": data.filename.tolist(),
            "c_fc": data.cloud_summary_flag.tolist(),
            "fit_value_flag": data.fit_value_flag.tolist(),
            "cloud_area_fraction": data.cloud_area_fraction.tolist(),
        }

    elif sensor1 == "ACEFTS" and sensor2 == "IASI":
        data_dict = {
            "latc": data.lat.tolist(),
            "lonc": data.lon.tolist(),
            "timec": [
                t.strftime("%Y-%m-%d %H:%M:%S") for t in data.timestamp
            ],
            "idc": data.id.tolist(),
            "fnc": data.filename.tolist(),
            "altitudec": data.altitude.tolist(),
            "max_so2c": data.max_so2.tolist(),
        }

    elif sensor1 == "IASI" and sensor2 == "ACEFTS":
        lat_lon_dict.update(
            {
                "altitudes": search_id["altitude"],
                "max_so2s": search_id["max_so2"],
            }
        )
        data_dict = {
            "latc": data.lat.tolist(),
            "lonc": data.lon.tolist(),
            "timec": [
                t.strftime("%Y-%m-%d %H:%M:%S") for t in data.timestamp
            ],
            "idc": data.id.tolist(),
            "fnc": data.filename.tolist(),
        }

    else:
        lat_lon_dict.update(
            {
                "s_ps": search_id["surface_pressure"],
                "qa_value": search_id["qa_value"],
                "ids": search_id["id"],
            }
        )
        data_dict = {
            "latc": data.lat.tolist(),
            "lonc": data.lon.tolist(),
            "timec": [
                t.strftime("%Y-%m-%d %H:%M:%S") for t in data.timestamp
            ],
            "s_pc": data.surface_pressure.tolist(),
            "idc": data.id.tolist(),
            "fnc": data.filename.tolist(),
            "c_fc": data.cloud_summary_flag.tolist(),
            "fit_value_flag": data.fit_value_flag.tolist(),
            "cloud_area_fraction": data.cloud_area_fraction.tolist(),
        }

    return lat_lon_dict, data_dict


def parallel_thread_optimal(search, source, distance_km, delta, sensor1, sensor2, output=None):
    """Run temporal + spatial filtering in parallel using threads.

    For each row in the ``search`` DataFrame, this function:

    1. Filters the ``source`` DataFrame by spatial distance,
    2. Submits a time-window filtering job to a thread pool,
    3. Collects all results, formats them via :func:`format_data`,
    4. Aggregates all candidate and source results into DataFrames.

    Args:
        search: pandas DataFrame representing the "search" or primary dataset.
        source: pandas DataFrame representing the "source" or candidate dataset.
        distance_km: Maximum horizontal distance in kilometers for
            spatial filtering.
        delta: Temporal window as :class:`datetime.timedelta` for
            time filtering.
        sensor1: Name of the primary/search sensor.
        sensor2: Name of the candidate sensor.
        output: Optional output base name (unused here, kept for API
            compatibility).

    Returns:
        tuple[pd.DataFrame, pd.DataFrame]: ``(dfsource, dfsearch)`` where

        - ``dfsource`` contains search/source-related metadata,
        - ``dfsearch`` contains all matching candidate observations.
    """
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = {}
        source_results = []
        search_results = []

        for idx, center in search.iterrows():
            filtered = gm.filter_by_distance(center, source, distance_km)
            future = executor.submit(gm.filter_by_time, center, filtered, delta)
            futures[future] = center

        for future in concurrent.futures.as_completed(futures):
            search_id = futures[future]
            try:
                data = future.result()
            except Exception as exc:
                print(f"{search_id} generated an exception: {exc}")
            else:
                lat_lon_dict, data_dict = format_data(
                    sensor1, sensor2, search_id, data
                )
                res = list(data_dict.values())
                res2 = list(itertools.chain.from_iterable(res))
                if len(res2) > 0:
                    search_results.append(data_dict)
                    source_results.append(lat_lon_dict)

    lonns = list(itertools.chain(*[d["lonc"] for d in search_results]))
    latts = list(itertools.chain(*[d["latc"] for d in search_results]))
    timee = list(itertools.chain(*[d["timec"] for d in search_results]))
    fnn = list(itertools.chain(*[d["fnc"] for d in search_results]))
    idd = list(itertools.chain(*[d["idc"] for d in search_results]))

    if sensor1 == "IASI":
        s_pp = list(itertools.chain(*[d["s_pc"] for d in search_results]))
        c_f = list(itertools.chain(*[d["c_fc"] for d in search_results]))
        fitvalueflag = list(
            itertools.chain(*[d["fit_value_flag"] for d in search_results])
        )
        cloudareafraction = list(
            itertools.chain(*[d["cloud_area_fraction"] for d in search_results])
        )
    else:
        s_pp = list(itertools.chain(*[d["s_pc"] for d in search_results]))
        qa_value = list(itertools.chain(*[d["qa_value"] for d in search_results]))

    datadict = {
        "lonc": lonns,
        "latc": latts,
        "timec": timee,
        "fnc": fnn,
        "idc": idd,
        "s_pc": s_pp,
    }

    if sensor1 == "IASI":
        datadict.update(
            {
                "c_fc": c_f,
                "fit_value_flag": fitvalueflag,
                "cloud_area_fraction": cloudareafraction,
            }
        )
    else:
        datadict.update({"qa_value": qa_value})

    dfsource = pd.DataFrame(source_results)
    dfsearch = pd.DataFrame(datadict)

    return dfsource, dfsearch

def run_optimal(distance_km, delta, sensor1, sensor2, start, end, percentage, output):
    """Run the full 'optimal match' workflow."""
    print("i)- Loading data ----")
    client = gm.connect()
    candidates = gm.get_search(client, sensor1, start, end)
    source = gm.get_source(client, sensor2, start, end)

    tic = time.perf_counter()

    n = int(source.index.size * percentage)
    print(f"ii)- Processing {n} data ---")

    dfs, dfc = parallel_thread_optimal(
        source[:n], candidates, distance_km, delta, sensor1, sensor2, output
    )

    print("iii)- Now Optimal matches---")
    Optimal(dfs, dfc, output, candidates=sensor1)

    toc = time.perf_counter()
    print(f"Calculation was done in {toc - tic:0.4f} seconds")

# def main(distance_km, delta, sensor1, sensor2, start, end, percentage, output):
#     """Run a full parallel geomatching workflow.

#     This function ties together the MongoDB-based data loading, the
#     parallel spatial/temporal filtering, and the optimal match selection
#     for a subset of the available data.

#     Steps:
#         1. Connect to MongoDB via :mod:`geomatch.geomatch`.
#         2. Load candidate and source datasets for the given sensor pair.
#         3. Select a fraction of the source data (``percentage``).
#         4. Run the parallel filtering using :func:`parallel_thread`.
#         5. Determine optimal matches using :func:`Optimal`.
#         6. Write the optimal matches to a feather file.

#     Args:
#         distance_km: Maximum allowed match distance in kilometers.
#         delta: Temporal window as :class:`datetime.timedelta`.
#         sensor1: Name of the first sensor (used as candidates in search).
#         sensor2: Name of the second sensor (used as source data).
#         start: Start datetime of the matching interval.
#         end: End datetime of the matching interval.
#         percentage: Fraction (0–1) of the source data to process.
#         output: Base name used by :func:`Optimal` for the feather output file.
#     """
#     print("i)- Loading data ----")
#     client = gm.connect()
#     candidates = gm.get_search(client, sensor1, start, end)
#     source = gm.get_source(client, sensor2, start, end)

#     tic = time.perf_counter()
#     current_time = datetime.now()

#     n = int(source.index.size * percentage)
#     print(f"ii)- Processing {n} data ---")

#     dfs, dfc = parallel_thread(
#         source[:n], candidates, distance_km, delta, sensor1, sensor2, output
#     )

#     print("iii)- Now Optimal matches---")
#     Optimal(dfs, dfc, output, candidates=sensor1)

#     toc = time.perf_counter()
#     print(f"Calculation was done in {toc - tic:0.4f} seconds")

def main(distance_km, delta, sensor1, sensor2, start, end, percentage, output, mode):
    """
    Unified main:
    - mode='optimal' → run_optimal()
    - mode='all'     → run_all()
    """
    if mode == "optimal":
        run_optimal(distance_km, delta, sensor1, sensor2, start, end, percentage, output)
    elif mode == "all":
        run_all(distance_km, delta, sensor1, sensor2, start, end, percentage, output)
    else:
        raise ValueError(f"Unknown mode: {mode}. Use 'optimal' or 'all'.")
if __name__ == "__main__":
    # Simple default example; you can also wire this with argparse if you like.
    distance_km = 160.934
    delta = timedelta(hours=6)
    percentage = 0.01      # or None for all
    output = "matches"     # change as you like
    sensor1 = "IASI"       # example
    sensor2 = "TROPOMI3"   # example
    start = True           # your existing API to gm.get_search/get_source
    end = True
    mode = "optimal"       # change to "all" when you want all matches

    main(distance_km, delta, sensor1, sensor2, start, end, percentage, output, mode)
# if __name__ == "__main__":
#     distance_km = 160.934
#     delta = timedelta(hours=6)
#     percentage = 0.01
#     output = None
#     sensor1 = None
#     sensor2 = None
#     start = True
#     end = True
#     main(distance_km, delta, sensor1, sensor2, start, end, percentage, output)