import json
import os
from datetime import timedelta, datetime

from pandas import DataFrame
from pymongo import MongoClient
import pandas as pd  # currently unused, but kept for compatibility

from . import haversine as hv
from . import mongo as m  # currently unused, but may be used elsewhere


"""
MongoDB helpers and geomatching utilities.

This module provides functions to:

- establish a connection to a MongoDB instance,
- retrieve "source" and "search" datasets for different sensors in a given
  time range,
- convert MongoDB query results into pandas DataFrames with latitude and
  longitude columns,
- filter candidate observations by temporal and spatial distance.

It is typically used as part of a larger geomatching workflow that matches
observations from different satellite products (e.g., IASI, TROPOMI, ACE-FTS).
"""


def connect():
    """
    Create a MongoDB client safely using environment variables.

    Expected environment variables:
        MONGO_URI  – full MongoDB connection URI
    or:
        MONGO_USERNAME
        MONGO_PASSWORD
        MONGO_HOST
        MONGO_PORT
        MONGO_DB (optional)

    The user must set these in their environment before running the tool.

    Returns:
        MongoClient: A pymongo client instance.
    """
    # Preferred: full URI via ONE variable
    uri = os.getenv("MONGO_URI")

    if uri:
        return MongoClient(uri)

    # Fallback: build URI from individual components
    username = os.getenv("MONGO_USERNAME")
    password = os.getenv("MONGO_PASSWORD")
    host = os.getenv("MONGO_HOST", "localhost")
    port = os.getenv("MONGO_PORT", "27017")

    if username and password:
        uri = f"mongodb://{username}:{password}@{host}:{port}"
    else:
        # No credentials provided → local MongoDB without auth
        uri = f"mongodb://{host}:{port}"

    return MongoClient(uri)

def _query_result_to_gdb(data, filename, index="time"):
    """Convert MongoDB cursor entries into a DataFrame with geospatial columns.

    This is an internal helper function that selects a subset of fields from
    each MongoDB document, adds latitude and longitude from the ``loc``
    field, and returns a time-indexed pandas :class:`DataFrame`.

    The exact set of fields depends on the sensor/database type inferred
    from ``filename``.

    Args:
        data: Iterable of MongoDB documents (e.g., a cursor).
        filename: Sensor name or collection identifier (e.g. ``"IASI"``,
            ``"TROPOMI3"``, ``"ACEFTS"``) used to select which fields to keep.
        index: Name of the column to use as index (default: ``"time"``).

    Returns:
        DataFrame | None: A pandas DataFrame sorted by the index column, or
        ``None`` if the input contains no entries.
    """

    def _single_entry(entry):
        if filename == "IASI":
            result = {
                k: entry[k]
                for k in [
                    "time",
                    "id",
                    "_id",
                    "surface_pressure",
                    "filename",
                    "cloud_summary_flag",
                    "fit_value_flag",
                    "cloud_area_fraction",
                ]
            }
        elif filename == "TROPOMI3":
            result = {
                k: entry[k]
                for k in [
                    "time",
                    "_id",
                    "surface_pressure",
                    "filename",
                    "qa_value",
                    "index_numbers",
                ]
            }

        elif filename == "ACEFTS":
            result = {
                k: entry[k]
                for k in ["time", "id", "_id", "max_so2", "altitude", "filename"]
            }
        else:
            result = {
                k: entry[k]
                for k in [
                    "time",
                    "id",
                    "_id",
                    "surface_pressure",
                    "filename",
                    "qa_value",
                ]
            }

        # Extract geolocation
        result["lat"] = entry["loc"]["coordinates"][1]
        result["lon"] = entry["loc"]["coordinates"][0]
        # Keep a copy of the time stamp for temporal filtering
        result["timestamp"] = result["time"]
        return result

    entries = [_single_entry(x) for x in data]
    if not entries:
        return None

    df = DataFrame(entries).set_index(index)
    df = df.sort_index()
    return df


def get_search(client, sensor, start, end, delta=6, index="time"):
    """Retrieve candidate (search) data for a given sensor and time window.

    The function queries a MongoDB collection for the specified ``sensor``.
    It expands the time window by ``delta`` hours on both sides to define
    a broader search interval.

    Args:
        client: A :class:`pymongo.MongoClient` instance.
        sensor: Name of the sensor/collection (e.g. ``"IASI"``, ``"TROPOMI3"``).
        start: Start datetime of the core interval.
        end: End datetime of the core interval.
        delta: Number of hours to expand the interval on each side for the
            search window (default: 6 hours).
        index: Column to use as index in the returned DataFrame
            (default: ``"time"``).

    Returns:
        DataFrame | None: A pandas DataFrame containing the matching entries,
        or ``None`` if no results are found.
    """
    print("Search:-----------" + sensor)
    start_n = start - timedelta(hours=delta)
    end_n = end + timedelta(hours=delta)

    if sensor == "TROPOMI3":
        db = "TROPOMIWFMD"
    else:
        db = sensor + "2"

    query = {"time": {"$gte": start_n, "$lt": end_n}}
    cursor = client[db][sensor].find(query)
    gdf = _query_result_to_gdb(cursor, sensor, index)

    print("Query is " + str(query))
    print(gdf)
    return gdf


def get_source(client, sensor, start, end, delta=6, index="time"):
    """Retrieve source data for a given sensor and time window.

    Unlike :func:`get_search`, this function uses the provided start and end
    times directly without expanding them by ``delta`` hours.

    Args:
        client: A :class:`pymongo.MongoClient` instance.
        sensor: Name of the sensor/collection (e.g. ``"IASI"``, ``"TROPOMI3"``).
        start: Start datetime of the source interval.
        end: End datetime of the source interval.
        delta: Currently unused, reserved for compatibility (default: 6).
        index: Column to use as index in the returned DataFrame
            (default: ``"time"``).

    Returns:
        DataFrame | None: A pandas DataFrame containing the source entries,
        or ``None`` if no results are found.
    """
    print("Source:----------------   " + sensor)
    start_n = start
    end_n = end
    print(start_n, end_n)

    query = {"time": {"$gte": start_n, "$lt": end_n}}

    if sensor == "TROPOMI3":
        db = "TROPOMIWFMD"
    else:
        db = sensor + "2"

    cursor = client[db][sensor].find(query)
    gdf = _query_result_to_gdb(cursor, sensor, index)

    print("Query is " + str(query))
    print(gdf)
    return gdf


def temporal_boundaries(center, delta, window_center=True):
    """Compute temporal boundaries around a central observation.

    The boundaries are defined relative to the time index of the ``center``
    observation (typically a row from a time-indexed DataFrame).

    Args:
        center: A pandas Series whose index label (``center.name``) is a
            datetime-like time stamp.
        delta: Time window as a :class:`datetime.timedelta`.
        window_center: If ``True`` (default), interpret ``delta`` as the full
            window size and compute +/- ``delta/2`` around the center. If
            ``False``, use ``delta`` as a one-sided offset.

    Returns:
        tuple[datetime, datetime]: A tuple ``(tmin, tmax)`` representing the
        lower and upper time boundaries.
    """
    window = delta / 2 if window_center else delta
    tmin = center.name - window
    tmax = center.name + window
    return (tmin, tmax)


def filter_by_distance(center, candidate_list, distance_km):
    """Filter candidate observations by spatial distance.

    Uses a vectorized haversine implementation to select only those
    candidates that lie within ``distance_km`` of the central observation.

    Args:
        center: A pandas Series representing the central observation with
            ``lat`` and ``lon`` attributes.
        candidate_list: A pandas DataFrame with ``lat`` and ``lon`` columns
            containing candidate observations.
        distance_km: Maximum allowed distance in kilometers.

    Returns:
        DataFrame: Subset of ``candidate_list`` containing only observations
        within ``distance_km`` of the central point.
    """
    lat = center.lat
    lon = center.lon
    lats = candidate_list.lat.values
    lons = candidate_list.lon.values
    mask = hv.haversine_par(lats, lons, lat, lon, distance_km)
    result = candidate_list[mask]
    return result


def filter_by_time(center, candidate_list, delta):
    """Filter candidate observations by temporal distance.

    The function computes a time window around the central observation
    using :func:`temporal_boundaries` and selects all candidates whose
    ``timestamp`` falls within that interval.

    Args:
        center: A pandas Series whose index label (``center.name``) is a
            datetime-like time stamp.
        candidate_list: A pandas DataFrame with a ``timestamp`` column.
        delta: Time window as a :class:`datetime.timedelta`.

    Returns:
        DataFrame: Subset of ``candidate_list`` with timestamps inside
        the computed temporal window.
    """
    tmin, tmax = temporal_boundaries(center, delta)
    mask = candidate_list["timestamp"].between(tmin, tmax)
    result = candidate_list[mask]
    return result


def to_json(fname, obj):
    """Write a Python object to a JSON file.

    Args:
        fname: Path to the output JSON file.
        obj: Any JSON-serializable Python object to be written.
    """
    with open(fname, "w") as f:
        json.dump(obj, f)


def main(distance_km, delta, sensor1, sensor2, ix, query=None):
    """Example application of the MongoDB search and filtering workflow.

    This function demonstrates how to:

    1. Connect to MongoDB.
    2. Load a source dataset for ``sensor1``.
    3. Load candidate observations for ``sensor2``.
    4. Select a central observation at index ``ix``.
    5. Apply temporal and spatial filtering to find matches.

    Args:
        distance_km: Maximum allowed spatial distance in kilometers.
        delta: Time window as a :class:`datetime.timedelta` for temporal
            filtering.
        sensor1: Name of the source sensor/collection.
        sensor2: Name of the search/candidate sensor/collection.
        ix: Row index of the central observation within the source DataFrame.
        query: Optional MongoDB query to further restrict the loaded data
            (currently not used in this simplified example).
    """
    client = connect()

    # Note: in a full implementation, `start`/`end` and `query` would be used.
    # Here we assume that the functions are called with appropriate parameters.
    source = get_source(client, sensor1, query=query)  # size: ~155.654
    candidates = get_search(client, sensor2, query=query)  # size: ~657.417
    searchspace = sensor1

    current_time = datetime.now()

    center = source.iloc[ix]

    filtered_t = filter_by_time(center, candidates, delta)
    filter_fin = filter_by_distance(center, filtered_t, distance_km)


if __name__ == "__main__":
    distance_km = 160.934
    delta = timedelta(hours=6)
    ix = 0
    main(distance_km, delta, ix)