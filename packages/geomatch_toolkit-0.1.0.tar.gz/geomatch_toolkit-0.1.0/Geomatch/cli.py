#!/usr/bin/env python
# coding: utf-8
"""
Command-line interface for the geomatching workflow.

This module defines a Click-based CLI that orchestrates the main components
of the geomatching project:

- :mod:`geomatch`: core geomatching algorithm
- :mod:`mongo`: MongoDB-based spatial selection
- :mod:`parallel`: parallel execution of the geomatching algorithm
- :mod:`plot`: plotting and visualization of single-match results

The main entry point is :func:`main`, which runs the Click command group
:func:`cli`.
"""

from datetime import timedelta, datetime
import click
from bson.objectid import ObjectId

from .geomatch import main as geomatch_main
from .mongo import main as mongo_main
from .parallel import main as par_main   # <-- this now accepts a `mode` argument
from .plot import main as plot_main


def validate_datetime(ctx, param, value):
    """Validate and parse a datetime string.

    This helper function can be used as a Click callback to ensure that the
    user provides a datetime in the expected format.

    Args:
        ctx: Click context object (unused here, but required by the signature).
        param: The Click parameter being processed.
        value: The raw string value provided by the user.

    Returns:
        datetime: Parsed :class:`datetime.datetime` object.

    Raises:
        click.BadParameter: If the datetime string does not match the expected
            format ``YYYY-MM-DD HH:MM:SS``.
    """
    try:
        # Parse the new time string format into a datetime object
        datetime_obj = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
        return datetime_obj
    except ValueError:
        raise click.BadParameter(
            "Invalid datetime format. Please use YYYY-MM-DD HH:MM:SS."
        )


@click.group()
@click.version_option()
@click.option(
    "-k",
    "--km",
    "distance",
    default=20,
    show_default=None,
    type=click.FloatRange(min=0, max=6371),
    help="Spatial tolerance [km].",
)
@click.option(
    "-m",
    "--min",
    "delta",
    default=120,
    show_default=None,
    type=click.IntRange(min=0),
    help="Temporal tolerance [min].",
)
@click.option(
    "-s",
    "--start-date",
    "start",
    type=click.DateTime(formats=["%Y-%m-%dT%H:%M:%S"]),
    default=None,
    help="Start date of data.",
)
@click.option(
    "-e",
    "--end-date",
    "end",
    type=click.DateTime(formats=["%Y-%m-%dT%H:%M:%S"]),
    default=None,
    help="End date of data.",
)
@click.option(
    "-s1",
    "--sensor1",
    help="Name of sensor 1 (e.g., IASI, TROPOMI, etc.).",
)
@click.option(
    "-s2",
    "--sensor2",
    help="Name of sensor 2 (e.g., IASI, TROPOMI, etc.).",
)
@click.pass_context
def cli(ctx, distance, delta, sensor1, sensor2, start, end):
    """Top-level CLI group for the geomatching tool.

    This command group initializes common options (spatial/temporal tolerance,
    sensor names, and time period) and stores them in the Click context
    so they are available to subcommands.
    """
    ctx.ensure_object(dict)
    ctx.obj["distance"] = distance
    ctx.obj["delta"] = timedelta(minutes=delta)
    ctx.obj["sensor1"] = sensor1
    ctx.obj["sensor2"] = sensor2
    ctx.obj["start"] = start
    ctx.obj["end"] = end


@cli.command()
@click.option(
    "-p",
    "--percentage",
    default=1,
    show_default=None,
    type=click.FloatRange(0, 1),
    help="Percentage of IASI data.",
)
@click.option(
    "--output",
    default=None,
    show_default=None,
    type=click.Path(exists=False),
    help="Output feather file.",
)
@click.option(
    "--mongo/--no-mongo",
    show_default=None,
    default=False,
    help="Use MongoDB-based spatial selection instead of pure geomatching.",
)
@click.option(
    "--mode",
    type=click.Choice(["optimal", "all"], case_sensitive=False),
    default="optimal",
    show_default=True,
    help=(
        "Matching mode: 'optimal' selects one best candidate per source "
        "using the cost function; 'all' saves all candidates inside the "
        "distance/time window."
    ),
)
@click.pass_context
def match(ctx, percentage, output, mongo, mode):
    """Run the geomatching search algorithm.

    Depending on the ``--mongo`` flag, this command either calls the
    MongoDB-based search (:func:`mongo_main`) or the parallel geomatching
    workflow (:func:`par_main`).

    The ``--mode`` option controls whether the parallel workflow returns:

    - ``optimal``: one optimal match per source using the cost function.
    - ``all``: all source–candidate matches within the tolerance window.
    """
    distance = ctx.obj["distance"]
    delta = ctx.obj["delta"]
    start = ctx.obj["start"]
    end = ctx.obj["end"]
    sensor1 = ctx.obj["sensor1"]
    sensor2 = ctx.obj["sensor2"]

    if mongo:
        click.echo("Using MongoDB for finding matches.")
        # Mongo workflow is unchanged / doesn't use `mode`
        mongo_main(distance, delta, percentage, output=output)
    else:
        click.echo(f"Using geomatch for finding matches (mode={mode}).")
        # IMPORTANT: parallel.main must now accept `mode` as last argument
        par_main(
            distance,
            delta,
            sensor1,
            sensor2,
            start,
            end,
            percentage,
            output,
            mode,   # <-- new argument
        )


@cli.command()
@click.option("--id", "ident", default=None, type=str, help="TROPOMI document ID.")
@click.option(
    "--ix",
    default=0,
    type=click.IntRange(min=0),
    show_default=None,
    help="Index position in TROPOMI database.",
)
@click.option(
    "-o",
    "--output",
    default=None,
    show_default=None,
    type=click.Path(exists=False),
    help="Output HTML file for plots.",
)
@click.pass_context
def single(ctx, ident, ix, output):
    """Search and visualize a single TROPOMI entry."""
    distance = ctx.obj["distance"]
    delta = ctx.obj["delta"]
    query = None

    if ident:
        query = {"_id": ObjectId(ident)}
        ix = 0

    if output is not None:
        plot_main(distance, delta, ix, query=query, save=output)
    else:
        geomatch_main(distance, delta, ix, query=query)


def main():
    """Entry point for running the CLI from Python."""
    print("running main")
    cli(obj={})