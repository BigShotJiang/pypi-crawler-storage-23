# sat-geomatch

`GeoMatch` provides tools to geomatch satellite observations from sensors
such as TROPOMI, IASI, and ACE-FTS. It supports:

- MongoDB-backed data access
- Temporal and spatial filtering
- Parallel matching
- A command-line interface based on `click`

## Installation

```bash
pip install GeoMatch