"""WASP2 Rust acceleration module (PyO3 bindings)."""

from .wasp2_rust import *  # noqa: F401,F403
