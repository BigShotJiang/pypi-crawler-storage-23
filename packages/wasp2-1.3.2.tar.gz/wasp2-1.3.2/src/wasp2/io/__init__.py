"""
I/O module for WASP2.

Provides data structures and readers for variant files (VCF, PGEN).
"""

# Import format handlers to register them with factory
from . import vcf_source  # noqa: F401
from .variant_source import (
    Genotype,
    Variant,
    VariantGenotype,
    VariantSource,
)

# Import PGEN handler if pgenlib is available
try:
    from . import pgen_source  # noqa: F401
except ImportError:
    pass  # pgenlib not available - PGEN support disabled

# Import CyVCF2 handler if cyvcf2 is available
try:
    from . import cyvcf2_source  # noqa: F401
except ImportError:
    pass  # cyvcf2 not available - high-performance VCF support disabled

# Import compatibility functions for legacy code
from .compat import variants_to_bed, vcf_to_bed

__all__ = [
    "Genotype",
    "Variant",
    "VariantGenotype",
    "VariantSource",
    "variants_to_bed",
    "vcf_to_bed",
]
