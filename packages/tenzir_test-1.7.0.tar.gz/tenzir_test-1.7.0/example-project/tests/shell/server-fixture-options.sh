#!/bin/sh
# fixtures: [{server: {message: {greeting: world}}}]

echo "${SERVER_GREETING}"
