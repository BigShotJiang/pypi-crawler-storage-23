---
title: Improved config override log readability
type: bugfix
authors:
  - mavam
  - claude
pr: 19
created: 2026-02-13T09:23:52.071478Z
---

Configuration override log messages now use relative paths and human-friendly formatting instead of absolute paths and raw Python repr output, making debug output easier to read.
