This release improves the CLI help text with usage examples and a link to the documentation.

## 🔧 Changes

### Improved CLI help with examples and documentation

The help text for the `tenzir-test` command now provides more context and guidance.

The command description now explains the baseline comparison behavior and shows how to regenerate baselines with the `--update` flag.

*By @mavam and @claude in #12.*
