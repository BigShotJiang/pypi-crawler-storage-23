#!/bin/sh
set -eu

printf '%s\n' "satellite fixture: ${SATELLITE_MARKER:-<missing>}"
