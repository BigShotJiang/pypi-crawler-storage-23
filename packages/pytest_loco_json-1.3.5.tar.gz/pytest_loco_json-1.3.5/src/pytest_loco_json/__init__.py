"""JSON extension for pytest-loco.

The `pytest-loco-json` extension adds first-class JSON support to the
pytest-loco DSL. It provides facilities for decoding, encoding, and
querying JSON data as part of test execution.

This extension is designed to integrate seamlessly with the pytest-loco
plugin system and can be enabled by registering the `json` plugin.
Once enabled, JSON becomes a native data format within the DSL, suitable
for validation, transformation, and data-driven testing scenarios.
"""
