import os
import mosamatic2.constants as constants
from PySide6.QtWidgets import (
    QMainWindow,
)
from PySide6.QtGui import (
    QGuiApplication,
    QAction,
    QIcon,
)
from PySide6.QtCore import Qt, QByteArray
from mosamatic2.ui.utils import version, resource_path, is_macos
from mosamatic2.core.managers.logmanager import LogManager
from mosamatic2.ui.settings import Settings
from mosamatic2.ui.widgets.panels.mainpanel import MainPanel
from mosamatic2.ui.widgets.panels.logpanel import LogPanel
from mosamatic2.ui.widgets.panels.tasks.rescaledicomimagestaskpanel import RescaleDicomImagesTaskPanel
from mosamatic2.ui.widgets.panels.tasks.segmentmusclefatl3tensorflowtaskpanel import SegmentMuscleFatL3TensorFlowTaskPanel
from mosamatic2.ui.widgets.panels.tasks.segmentmusclefatt4pytorchtaskpanel import SegmentMuscleFatT4PyTorchTaskPanel
from mosamatic2.ui.widgets.panels.tasks.createpngsfromsegmentationstaskpanel import CreatePngsFromSegmentationsTaskPanel
from mosamatic2.ui.widgets.panels.tasks.calculatescorestaskpanel import CalculateScoresTaskPanel
from mosamatic2.ui.widgets.panels.tasks.dicom2niftitaskpanel import Dicom2NiftiTaskPanel
from mosamatic2.ui.widgets.panels.tasks.segmentationnifti2numpytaskpanel import SegmentationNifti2NumpyTaskPanel
from mosamatic2.ui.widgets.panels.tasks.segmentationnumpy2niftitaskpanel import SegmentationNumpy2NiftiTaskPanel
from mosamatic2.ui.widgets.panels.tasks.createdicomsummarytaskpanel import CreateDicomSummaryTaskPanel
from mosamatic2.ui.widgets.panels.tasks.selectslicefromscanstaskpanel import SelectSliceFromScansTaskPanel
from mosamatic2.ui.widgets.panels.tasks.totalsegmentatortaskpanel import TotalSegmentatorTaskPanel
from mosamatic2.ui.widgets.panels.tasks.calculatemaskstatisticstaskpanel import CalculateMaskStatisticsTaskPanel
from mosamatic2.ui.widgets.panels.tasks.applythresholdtosegmentationstaskpanel import ApplyThresholdToSegmentationsTaskPanel
from mosamatic2.ui.widgets.panels.pipelines.defaultpipelinepanel import DefaultPipelinePanel
from mosamatic2.ui.widgets.panels.pipelines.defaultdockerpipelinepanel import DefaultDockerPipelinePanel
from mosamatic2.ui.widgets.panels.pipelines.boadockerpipelinepanel import BoaDockerPipelinePanel
from mosamatic2.ui.widgets.panels.pipelines.liveranalysispipelinepanel import LiverAnalysisPipelinePanel
from mosamatic2.ui.widgets.panels.visualizations.slicevisualization.slicevisualization import SliceVisualization
from mosamatic2.ui.widgets.panels.visualizations.sliceselectionvisualization.sliceselectionvisualization import SliceSelectionVisualization
from mosamatic2.ui.widgets.panels.visualizations.liversegmentvisualization.liversegmentvisualization import LiverSegmentVisualization
from mosamatic2.ui.widgets.panels.visualizations.musclefatsegmentationvisualization.musclefatsegmentationvisualization import MuscleFatSegmentationVisualization
from mosamatic2.ui.widgets.panels.tools.segmentationeditor.segmentationeditor import SegmentationEditor


LOG = LogManager()


class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self._settings = None
        self._main_panel = None
        self._log_panel = None
        self._decompress_dicom_files_task_panel = None
        self._rescale_dicom_images_task_panel = None
        self._segment_muscle_fat_l3_tensorflow_task_panel = None
        self._segment_muscle_fat_t4_pytorch_task_panel = None
        self._create_pngs_from_segmentations_task_panel = None
        self._calculate_scores_task_panel = None
        self._dicom2nifti_task_panel = None
        self._segmentation_numpy_to_nifti_task_panel = None
        self._segmentation_nifti_to_numpy_task_panel = None
        self._create_dicom_summary_task_panel = None
        self._select_slice_from_scans_task_panel = None
        self._total_segmentator_task_panel = None
        self._calculate_mask_statistics_task_panel = None
        self._apply_threshold_to_segmentations_task_panel = None
        self._default_pipeline_panel = None
        self._default_docker_pipeline_panel = None
        self._boa_docker_pipeline_panel = None
        self._liver_analysis_pipeline_panel = None
        self._slice_visualization = None
        self._slice_selection_visualization = None
        self._liver_segment_visualization = None
        self._muscle_fat_segmentation_visualization = None
        self._segmentation_editor = None
        self.init_window()

    def init_window(self):
        self.setWindowTitle(f'{constants.MOSAMATIC2_WINDOW_TITLE} {version()}')
        icon_file_name = constants.MOSAMATIC2_APP_ICON_FILE_NAME_MAC if is_macos() else constants.MOSAMATIC2_APP_ICON_FILE_NAME_WIN
        icon_path = resource_path(os.path.join(constants.MOSAMATIC2_ICONS_DIR_PATH, icon_file_name))
        self.setWindowIcon(QIcon(icon_path))
        if not self.load_geometry_and_state():
            self.set_default_size_and_position()
        self.init_menus()
        self.init_status_bar()
        self.addDockWidget(Qt.DockWidgetArea.TopDockWidgetArea, self.main_panel())
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.log_panel())

    def init_menus(self):
        self.init_app_menu()
        self.init_tasks_menu()
        self.init_pipelines_menu()
        self.init_visualizations_menu()
        self.init_tools_menu()
        if is_macos():            
            self.menuBar().setNativeMenuBar(False)

    def init_app_menu(self):
        exit_action = QAction('Exit', self)
        exit_action.triggered.connect(self.close)
        app_menu = self.menuBar().addMenu('Application')
        app_menu.addAction(exit_action)

    def init_tasks_menu(self):
        apply_threshold_to_segmentations_task_action = QAction(self.apply_threshold_to_segmentations_task_panel().title(), self)
        apply_threshold_to_segmentations_task_action.triggered.connect(self.handle_apply_threshold_to_segmentations_task_action)
        calculate_scores_task_action = QAction(self.calculate_scores_task_panel().title(), self)
        calculate_scores_task_action.triggered.connect(self.handle_calculate_scores_task_action)
        calculate_mask_statistics_task_action = QAction(self.calculate_mask_statistics_task_panel().title(), self)
        calculate_mask_statistics_task_action.triggered.connect(self.handle_calculate_mask_statistics_task_action)
        create_pngs_from_segmentations_task_action = QAction(self.create_pngs_from_segmentations_task_panel().title(), self)
        create_pngs_from_segmentations_task_action.triggered.connect(self.handle_create_pngs_from_segmentations_task_action)
        create_dicom_summary_task_action = QAction(self.create_dicom_summary_task_panel().title(), self)
        create_dicom_summary_task_action.triggered.connect(self.handle_create_dicom_summary_task_action)
        dicom2nifti_task_action = QAction(self.dicom2nifti_task_panel().title(), self)
        dicom2nifti_task_action.triggered.connect(self.handle_dicom2nifti_task_action)
        rescale_dicom_images_task_action = QAction(self.rescale_dicom_images_task_panel().title(), self)
        rescale_dicom_images_task_action.triggered.connect(self.handle_rescale_dicom_images_task_action)
        segmentation_numpy_to_nifti_task_action = QAction(self.segmentation_numpy_to_nifti_task_panel().title(), self)
        segmentation_numpy_to_nifti_task_action.triggered.connect(self.handle_segmentation_numpy_to_nifti_task_action)
        segmentation_nifti_to_numpy_task_action = QAction(self.segmentation_nifti_to_numpy_task_panel().title(), self)
        segmentation_nifti_to_numpy_task_action.triggered.connect(self.handle_segmentation_nifti_to_numpy_task_action)
        segment_muscle_fat_l3_tensorflow_task_action = QAction(self.segment_muscle_fat_l3_tensorflow_task_panel().title(), self)
        segment_muscle_fat_l3_tensorflow_task_action.triggered.connect(self.handle_segment_muscle_fat_l3_tensorflow_task_action)
        segment_muscle_fat_t4_pytorch_task_action = QAction(self.segment_muscle_fat_t4_pytorch_task_panel().title(), self)
        segment_muscle_fat_t4_pytorch_task_action.triggered.connect(self.handle_segment_muscle_fat_t4_pytorch_task_action)
        select_slice_from_scans_task_action = QAction(self.select_slice_from_scans_task_panel().title(), self)
        select_slice_from_scans_task_action.triggered.connect(self.handle_select_slice_from_scans_task_action)
        total_segmentator_task_action = QAction(self.total_segmentator_task_panel().title(), self)
        total_segmentator_task_action.triggered.connect(self.handle_total_segmentator_task_action)
        tasks_menu = self.menuBar().addMenu('Tasks')
        tasks_menu.addAction(apply_threshold_to_segmentations_task_action)
        tasks_menu.addAction(calculate_scores_task_action)
        tasks_menu.addAction(calculate_mask_statistics_task_action)
        tasks_menu.addAction(create_pngs_from_segmentations_task_action)
        tasks_menu.addAction(create_dicom_summary_task_action)
        tasks_menu.addAction(dicom2nifti_task_action)
        tasks_menu.addAction(rescale_dicom_images_task_action)
        tasks_menu.addAction(segmentation_numpy_to_nifti_task_action)
        tasks_menu.addAction(segmentation_nifti_to_numpy_task_action)
        tasks_menu.addAction(segment_muscle_fat_l3_tensorflow_task_action)
        tasks_menu.addAction(segment_muscle_fat_t4_pytorch_task_action)
        tasks_menu.addAction(select_slice_from_scans_task_action)
        tasks_menu.addAction(total_segmentator_task_action)

    def init_pipelines_menu(self):
        boa_docker_pipeline_action = QAction(self.boa_docker_pipeline_panel().title(), self)
        boa_docker_pipeline_action.triggered.connect(self.handle_boa_docker_pipeline_action)
        default_pipeline_action = QAction(self.default_pipeline_panel().title(), self)
        default_pipeline_action.triggered.connect(self.handle_default_pipeline_action)
        default_docker_pipeline_action = QAction(self.default_docker_pipeline_panel().title(), self)
        default_docker_pipeline_action.triggered.connect(self.handle_default_docker_pipeline_action)
        liver_analysis_pipeline_action = QAction(self.liver_analysis_pipeline_panel().title(), self)
        liver_analysis_pipeline_action.triggered.connect(self.handle_liver_analysis_pipeline_action)
        pipelines_menu = self.menuBar().addMenu('Pipelines')
        pipelines_menu.addAction(boa_docker_pipeline_action)
        pipelines_menu.addAction(default_pipeline_action)
        pipelines_menu.addAction(default_docker_pipeline_action)
        pipelines_menu.addAction(liver_analysis_pipeline_action)

    def init_visualizations_menu(self):
        liver_segment_visualization_action = QAction(self.liver_segment_visualization().title(), self)
        liver_segment_visualization_action.triggered.connect(self.handle_liver_segment_visualization_action)
        muscle_fat_segmentation_visualization_action = QAction(self.muscle_fat_segmentation_visualization().title(), self)
        muscle_fat_segmentation_visualization_action.triggered.connect(self.handle_muscle_fat_segmentation_visualization_action)
        slice_selection_visualization_action = QAction(self.slice_selection_visualization().title(), self)
        slice_selection_visualization_action.triggered.connect(self.handle_slice_selection_visualization_action)
        slice_visualization_action = QAction(self.slice_visualization().title(), self)
        slice_visualization_action.triggered.connect(self.handle_slice_visualization_action)
        visualizations_menu = self.menuBar().addMenu('Visualizations')
        visualizations_menu.addAction(liver_segment_visualization_action)
        visualizations_menu.addAction(muscle_fat_segmentation_visualization_action)
        visualizations_menu.addAction(slice_selection_visualization_action)
        visualizations_menu.addAction(slice_visualization_action)

    def init_tools_menu(self):
        tools_menu = self.menuBar().addMenu('Tools')
        segmentation_editor_action = QAction(self.segmentation_editor().title(), self)
        segmentation_editor_action.triggered.connect(self.handdle_segmentation_editor_action)
        tools_menu.addAction(segmentation_editor_action)

    def init_status_bar(self):
        self.set_status('Ready')

    # GET

    def settings(self):
        if not self._settings:
            self._settings = Settings()
        return self._settings

    def main_panel(self):
        if not self._main_panel:
            self._main_panel = MainPanel(self)
            self._main_panel.add_panel(self.rescale_dicom_images_task_panel(), 'rescaledicomimagestaskpanel')
            self._main_panel.add_panel(self.segment_muscle_fat_l3_tensorflow_task_panel(), 'segmentmusclefatl3tensorflowtaskpanel')
            self._main_panel.add_panel(self.segment_muscle_fat_t4_pytorch_task_panel(), 'segmentmusclefatt4pytorchtaskpanel')
            self._main_panel.add_panel(self.create_pngs_from_segmentations_task_panel(), 'createpngsfromsegmentationstaskpanel')
            self._main_panel.add_panel(self.calculate_scores_task_panel(), 'calculatescorestaskpanel')
            self._main_panel.add_panel(self.dicom2nifti_task_panel(), 'dicom2niftitaskpanel')
            self._main_panel.add_panel(self.segmentation_numpy_to_nifti_task_panel(), 'segmentationnumpy2niftitaskpanel')
            self._main_panel.add_panel(self.segmentation_nifti_to_numpy_task_panel(), 'segmentationnifti2numpytaskpanel')
            self._main_panel.add_panel(self.create_dicom_summary_task_panel(), 'createdicomsummarytaskpanel')
            self._main_panel.add_panel(self.select_slice_from_scans_task_panel(), 'selectslicefromscanstaskpanel')
            self._main_panel.add_panel(self.total_segmentator_task_panel(), 'totalsegmentatortaskpanel')
            self._main_panel.add_panel(self.calculate_mask_statistics_task_panel(), 'calculatemaskstatisticstaskpanel')
            self._main_panel.add_panel(self.apply_threshold_to_segmentations_task_panel(), 'applythresholdtosegmentationstaskpanel')
            self._main_panel.add_panel(self.default_pipeline_panel(), 'defaultpipelinepanel')
            self._main_panel.add_panel(self.default_docker_pipeline_panel(), 'defaultdockerpipelinepanel')
            self._main_panel.add_panel(self.boa_docker_pipeline_panel(), 'boadockerpipelinepanel')
            self._main_panel.add_panel(self.liver_analysis_pipeline_panel(), 'liveranalysispipelinepanel')
            self._main_panel.add_panel(self.slice_visualization(), 'slicevisualization')
            self._main_panel.add_panel(self.slice_selection_visualization(), 'sliceselectionvisualization')
            self._main_panel.add_panel(self.liver_segment_visualization(), 'liversegmentvisualization')
            self._main_panel.add_panel(self.muscle_fat_segmentation_visualization(), 'musclefatsegmentationvisualization')
            self._main_panel.add_panel(self.segmentation_editor(), 'segmentationeditor')
            self._main_panel.select_panel('defaultpipelinepanel')
        return self._main_panel
    
    def log_panel(self):
        if not self._log_panel:
            self._log_panel = LogPanel()
            LOG.add_listener(self._log_panel)
        return self._log_panel

    # MISCELLANEOUS

    def rescale_dicom_images_task_panel(self):
        if not self._rescale_dicom_images_task_panel:
            self._rescale_dicom_images_task_panel = RescaleDicomImagesTaskPanel()
        return self._rescale_dicom_images_task_panel
    
    def segment_muscle_fat_l3_tensorflow_task_panel(self):
        if not self._segment_muscle_fat_l3_tensorflow_task_panel:
            self._segment_muscle_fat_l3_tensorflow_task_panel = SegmentMuscleFatL3TensorFlowTaskPanel()
        return self._segment_muscle_fat_l3_tensorflow_task_panel

    def segment_muscle_fat_t4_pytorch_task_panel(self):
        if not self._segment_muscle_fat_t4_pytorch_task_panel:
            self._segment_muscle_fat_t4_pytorch_task_panel = SegmentMuscleFatT4PyTorchTaskPanel()
        return self._segment_muscle_fat_t4_pytorch_task_panel

    def create_pngs_from_segmentations_task_panel(self):
        if not self._create_pngs_from_segmentations_task_panel:
            self._create_pngs_from_segmentations_task_panel = CreatePngsFromSegmentationsTaskPanel()
        return self._create_pngs_from_segmentations_task_panel
    
    def calculate_scores_task_panel(self):
        if not self._calculate_scores_task_panel:
            self._calculate_scores_task_panel = CalculateScoresTaskPanel()
        return self._calculate_scores_task_panel
    
    def dicom2nifti_task_panel(self):
        if not self._dicom2nifti_task_panel:
            self._dicom2nifti_task_panel = Dicom2NiftiTaskPanel()
        return self._dicom2nifti_task_panel

    def segmentation_numpy_to_nifti_task_panel(self):
        if not self._segmentation_numpy_to_nifti_task_panel:
            self._segmentation_numpy_to_nifti_task_panel = SegmentationNumpy2NiftiTaskPanel()
        return self._segmentation_numpy_to_nifti_task_panel
    
    def segmentation_nifti_to_numpy_task_panel(self):
        if not self._segmentation_nifti_to_numpy_task_panel:
            self._segmentation_nifti_to_numpy_task_panel = SegmentationNifti2NumpyTaskPanel()
        return self._segmentation_nifti_to_numpy_task_panel
    
    def create_dicom_summary_task_panel(self):
        if not self._create_dicom_summary_task_panel:
            self._create_dicom_summary_task_panel = CreateDicomSummaryTaskPanel()
        return self._create_dicom_summary_task_panel

    def select_slice_from_scans_task_panel(self):
        if not self._select_slice_from_scans_task_panel:
            self._select_slice_from_scans_task_panel = SelectSliceFromScansTaskPanel()
        return self._select_slice_from_scans_task_panel

    def total_segmentator_task_panel(self):
        if not self._total_segmentator_task_panel:
            self._total_segmentator_task_panel = TotalSegmentatorTaskPanel()
        return self._total_segmentator_task_panel
    
    def calculate_mask_statistics_task_panel(self):
        if not self._calculate_mask_statistics_task_panel:
            self._calculate_mask_statistics_task_panel = CalculateMaskStatisticsTaskPanel()
        return self._calculate_mask_statistics_task_panel

    def apply_threshold_to_segmentations_task_panel(self):
        if not self._apply_threshold_to_segmentations_task_panel:
            self._apply_threshold_to_segmentations_task_panel = ApplyThresholdToSegmentationsTaskPanel()
        return self._apply_threshold_to_segmentations_task_panel
    
    def default_pipeline_panel(self):
        if not self._default_pipeline_panel:
            self._default_pipeline_panel = DefaultPipelinePanel()
        return self._default_pipeline_panel

    def default_docker_pipeline_panel(self):
        if not self._default_docker_pipeline_panel:
            self._default_docker_pipeline_panel = DefaultDockerPipelinePanel()
        return self._default_docker_pipeline_panel

    def boa_docker_pipeline_panel(self):
        if not self._boa_docker_pipeline_panel:
            self._boa_docker_pipeline_panel = BoaDockerPipelinePanel()
        return self._boa_docker_pipeline_panel
    
    def liver_analysis_pipeline_panel(self):
        if not self._liver_analysis_pipeline_panel:
            self._liver_analysis_pipeline_panel = LiverAnalysisPipelinePanel()
        return self._liver_analysis_pipeline_panel
    
    def slice_visualization(self):
        if not self._slice_visualization:
            self._slice_visualization = SliceVisualization()
        return self._slice_visualization
    
    def slice_selection_visualization(self):
        if not self._slice_selection_visualization:
            self._slice_selection_visualization = SliceSelectionVisualization()
        return self._slice_selection_visualization

    def liver_segment_visualization(self):
        if not self._liver_segment_visualization:
            self._liver_segment_visualization = LiverSegmentVisualization()
        return self._liver_segment_visualization
    
    def muscle_fat_segmentation_visualization(self):
        if not self._muscle_fat_segmentation_visualization:
            self._muscle_fat_segmentation_visualization = MuscleFatSegmentationVisualization()
        return self._muscle_fat_segmentation_visualization
    
    def segmentation_editor(self):
        if not self._segmentation_editor:
            self._segmentation_editor = SegmentationEditor(self.settings())
        return self._segmentation_editor

    # SETTERS

    def set_status(self, message):
        self.statusBar().showMessage(message)

    # EVENT HANDLERS

    def handle_rescale_dicom_images_task_action(self):
        self.main_panel().select_panel('rescaledicomimagestaskpanel')

    def handle_segment_muscle_fat_l3_tensorflow_task_action(self):
        self.main_panel().select_panel('segmentmusclefatl3tensorflowtaskpanel')

    def handle_segment_muscle_fat_t4_pytorch_task_action(self):
        self.main_panel().select_panel('segmentmusclefatt4pytorchtaskpanel')

    def handle_create_pngs_from_segmentations_task_action(self):
        self.main_panel().select_panel('createpngsfromsegmentationstaskpanel')

    def handle_calculate_scores_task_action(self):
        self.main_panel().select_panel('calculatescorestaskpanel')

    def handle_dicom2nifti_task_action(self):
        self.main_panel().select_panel('dicom2niftitaskpanel')

    def handle_segmentation_numpy_to_nifti_task_action(self):
        self.main_panel().select_panel('segmentationnumpy2niftitaskpanel')

    def handle_segmentation_nifti_to_numpy_task_action(self):
        self.main_panel().select_panel('segmentationnifti2numpytaskpanel')

    def handle_create_dicom_summary_task_action(self):
        self.main_panel().select_panel('createdicomsummarytaskpanel')

    def handle_select_slice_from_scans_task_action(self):
        self.main_panel().select_panel('selectslicefromscanstaskpanel')

    def handle_total_segmentator_task_action(self):
        self.main_panel().select_panel('totalsegmentatortaskpanel')

    def handle_calculate_mask_statistics_task_action(self):
        self.main_panel().select_panel('calculatemaskstatisticstaskpanel')

    def handle_apply_threshold_to_segmentations_task_action(self):
        self.main_panel().select_panel('applythresholdtosegmentationstaskpanel')

    def handle_default_pipeline_action(self):
        self.main_panel().select_panel('defaultpipelinepanel')

    def handle_default_docker_pipeline_action(self):
        self.main_panel().select_panel('defaultdockerpipelinepanel')

    def handle_boa_docker_pipeline_action(self):
        self.main_panel().select_panel('boadockerpipelinepanel')

    def handle_liver_analysis_pipeline_action(self):
        self.main_panel().select_panel('liveranalysispipelinepanel')

    def handle_slice_visualization_action(self):
        self.main_panel().select_panel('slicevisualization')

    def handle_slice_selection_visualization_action(self):
        self.main_panel().select_panel('sliceselectionvisualization')

    def handle_liver_segment_visualization_action(self):
        self.main_panel().select_panel('liversegmentvisualization')

    def handle_muscle_fat_segmentation_visualization_action(self):
        self.main_panel().select_panel('musclefatsegmentationvisualization')

    def handdle_segmentation_editor_action(self):
        self.main_panel().select_panel('segmentationeditor')

    def showEvent(self, event):
        return super().showEvent(event)

    def closeEvent(self, event):
        self.save_geometry_and_state()
        # Save inputs and parameters of relevant panels
        self.rescale_dicom_images_task_panel().save_inputs_and_parameters()
        self.segment_muscle_fat_l3_tensorflow_task_panel().save_inputs_and_parameters()
        self.segment_muscle_fat_t4_pytorch_task_panel().save_inputs_and_parameters()
        self.create_pngs_from_segmentations_task_panel().save_inputs_and_parameters()
        self.calculate_scores_task_panel().save_inputs_and_parameters()
        self.dicom2nifti_task_panel().save_inputs_and_parameters()
        self.segmentation_numpy_to_nifti_task_panel().save_inputs_and_parameters()
        self.segmentation_nifti_to_numpy_task_panel().save_inputs_and_parameters()
        self.create_dicom_summary_task_panel().save_inputs_and_parameters()
        self.select_slice_from_scans_task_panel().save_inputs_and_parameters()
        self.total_segmentator_task_panel().save_inputs_and_parameters()
        self.calculate_mask_statistics_task_panel().save_inputs_and_parameters()
        self.apply_threshold_to_segmentations_task_panel().save_inputs_and_parameters()
        self.default_pipeline_panel().save_inputs_and_parameters()
        self.default_docker_pipeline_panel().save_inputs_and_parameters()
        self.boa_docker_pipeline_panel().save_inputs_and_parameters()
        self.liver_analysis_pipeline_panel().save_inputs_and_parameters()
        self.slice_visualization().save_inputs_and_parameters()
        self.slice_selection_visualization().save_inputs_and_parameters()
        self.liver_segment_visualization().save_inputs_and_parameters()
        self.muscle_fat_segmentation_visualization().save_inputs_and_parameters()
        return super().closeEvent(event)
    
    def keyPressEvent(self, event):
        if self.main_panel().current_panel_name() == 'segmentationeditor':
            self.segmentation_editor().view().keyPressEvent(event)
            return
        return super().keyPressEvent(event)
    
    def keyReleaseEvent(self, event):
        if self.main_panel().current_panel_name() == 'segmentationeditor':
            self.segmentation_editor().view().keyReleaseEvent(event)
            return
        return super().keyReleaseEvent(event)

    def load_geometry_and_state(self):
        geometry = self.settings().get(constants.MOSAMATIC2_WINDOW_GEOMETRY_KEY)
        state = self.settings().get(constants.MOSAMATIC2_WINDOW_STATE_KEY)
        if isinstance(geometry, QByteArray) and self.restoreGeometry(geometry):
            if isinstance(state, QByteArray):
                self.restoreState(state)
            return True
        return False

    def save_geometry_and_state(self):
        self.settings().set(constants.MOSAMATIC2_WINDOW_GEOMETRY_KEY, self.saveGeometry())
        self.settings().set(constants.MOSAMATIC2_WINDOW_STATE_KEY, self.saveState())

    def set_default_size_and_position(self):
        self.resize(constants.MOSAMATIC2_WINDOW_W, constants.MOSAMATIC2_WINDOW_H)
        self.center_window()

    def center_window(self):
        screen = QGuiApplication.primaryScreen().geometry()
        x = (screen.width() - self.geometry().width()) / 2
        y = (screen.height() - self.geometry().height()) / 2
        self.move(int(x), int(y))