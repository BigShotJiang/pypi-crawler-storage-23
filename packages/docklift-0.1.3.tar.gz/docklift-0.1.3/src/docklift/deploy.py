"""Deploy application to VPS."""

import tarfile
from pathlib import Path
from tempfile import NamedTemporaryFile, TemporaryDirectory
from typing import Any

import pathspec
import yaml
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from .bootstrap import DOCKLIFT_DIR, SHARED_NETWORK, update_caddyfile
from .config import ApplicationConfig, DockLiftConfig, ServiceConfig
from .connection import VPSConnection

console = Console()


def deploy(conn: VPSConnection, config: DockLiftConfig) -> None:
    """Deploy application to VPS.

    This is idempotent and can be run multiple times safely.

    Args:
        conn: VPS connection
        config: Full docklift configuration
    """
    app_config = config.application
    console.print(f"\n[bold cyan]Deploying {app_config.name}[/bold cyan]\n")

    # Show environment info
    if app_config.env_file:
        console.print(f"[cyan]Referencing environment file(s): {app_config.env_file}[/cyan]")

    app_dir = f"{DOCKLIFT_DIR}/apps/{app_config.name}"

    # Create application directory
    _create_app_directory(conn, app_dir)

    # Upload application context
    _upload_app_context(conn, app_config, app_dir)

    # Generate and upload docker-compose.yml
    _create_app_compose_file(conn, config, app_dir)

    # Build and start application
    _build_and_start_app(conn, app_dir)

    # Update Caddy configuration
    update_caddyfile(
        conn, app_config.domain, f"{app_config.name}-app", app_config.port
    )

    # Test deployment
    _test_deployment(conn, app_config)

    console.print(
        f"\n[bold green]✓ {app_config.name} deployed successfully![/bold green]"
    )
    console.print(f"[green]Application available at: https://{app_config.domain}[/green]\n")



def _create_app_directory(conn: VPSConnection, app_dir: str) -> None:
    """Create application directory on VPS.

    Args:
        conn: VPS connection
        app_dir: Application directory path
    """
    console.print("[cyan]Creating application directory...[/cyan]")

    if not conn.dir_exists(app_dir):
        conn.run(f"mkdir -p {app_dir}")
        console.print(f"[green]✓ Created {app_dir}[/green]")
    else:
        console.print("[green]✓ Directory exists[/green]")


def _build_dockerignore_spec(context_path: Path) -> pathspec.PathSpec | None:
    """Build a pathspec from .dockerignore in the context directory.

    Args:
        context_path: Path to the build context directory

    Returns:
        PathSpec for filtering, or None if no .dockerignore exists
    """
    dockerignore_path = context_path / ".dockerignore"
    if not dockerignore_path.exists():
        return None

    with open(dockerignore_path) as f:
        lines = [
            line.strip()
            for line in f
            if line.strip() and not line.strip().startswith("#")
        ]

    if not lines:
        return None

    return pathspec.PathSpec.from_lines("gitwildmatch", lines)


def _upload_app_context(
    conn: VPSConnection, app_config: ApplicationConfig, app_dir: str
) -> None:
    """Upload application build context to VPS, respecting .dockerignore.

    Args:
        conn: VPS connection
        app_config: Application configuration
        app_dir: Remote application directory
    """
    with Progress(
        SpinnerColumn(),
        TextColumn("[cyan]Uploading application context...[/cyan]"),
        console=console,
    ) as progress:
        progress.add_task("upload", total=None)

        context_path = Path(app_config.context).resolve()
        if not context_path.exists():
            raise FileNotFoundError(f"Context path not found: {context_path}")

        # Build dockerignore filter
        spec = _build_dockerignore_spec(context_path)

        def dockerignore_filter(tarinfo: tarfile.TarInfo) -> tarfile.TarInfo | None:
            name = tarinfo.name
            if name.startswith("./"):
                name = name[2:]
            if not name:
                return tarinfo
            if spec:
                # Append '/' for directories so patterns like 'node_modules/' match the dir itself
                check_name = name + "/" if tarinfo.isdir() else name
                if spec.match_file(check_name):
                    return None
            return tarinfo

        # Create tarball of context
        with TemporaryDirectory() as tmpdir:
            tarball_path = Path(tmpdir) / "context.tar.gz"

            with tarfile.open(tarball_path, "w:gz") as tar:
                tar.add(context_path, arcname=".", filter=dockerignore_filter)

            # Upload tarball
            remote_tarball = f"{app_dir}/context.tar.gz"
            conn.put(str(tarball_path), remote_tarball)

            # Extract on VPS
            conn.run(f"cd {app_dir} && tar -xzf context.tar.gz && rm context.tar.gz")

    console.print("[green]✓ Application context uploaded[/green]")


def _create_app_compose_file(
    conn: VPSConnection, config: DockLiftConfig, app_dir: str
) -> None:
    """Generate and upload docker-compose.yml for application.

    Args:
        conn: VPS connection
        config: Full docklift configuration
        app_dir: Remote application directory
    """
    console.print("[cyan]Creating docker-compose.yml...[/cyan]")

    compose_content = _generate_app_compose(config)

    # Upload compose file
    with NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as tmp:
        yaml.dump(compose_content, tmp, default_flow_style=False)
        tmp_path = tmp.name

    try:
        remote_compose = f"{app_dir}/docker-compose.yml"
        conn.put(tmp_path, remote_compose)
        console.print("[green]✓ docker-compose.yml created[/green]")
    finally:
        Path(tmp_path).unlink()


def _generate_app_compose(config: DockLiftConfig) -> dict[str, Any]:
    """Generate docker-compose configuration for application.

    Args:
        config: Full docklift configuration

    Returns:
        Docker compose configuration as dict
    """
    app_config = config.application
    services: dict[str, Any] = {}

    # Add dependency services (databases, caches, etc.)
    for dep_name, dep_config in app_config.dependencies.items():
        services[dep_name] = _service_config_to_compose(dep_config)

    # Start app service with any extra attributes passed through from config
    app_service: dict[str, Any] = dict(app_config.model_extra or {})

    # Apply docklift defaults (can be overridden via extra)
    app_service.setdefault("restart", "unless-stopped")

    # Set required docklift-managed attributes
    app_service["build"] = {
        "context": ".",
        "dockerfile": app_config.dockerfile,
    }
    app_service["container_name"] = f"{app_config.name}-app"
    app_service["expose"] = [str(app_config.port)]
    app_service["networks"] = [SHARED_NETWORK]

    # Environment variables (explicit config values only, not merged from env_file)
    env_vars: dict[str, str] | list[str] | None = None
    if app_config.environment:
        env_vars = dict(app_config.environment) if isinstance(app_config.environment, dict) else list(app_config.environment)

    if isinstance(env_vars, dict) and app_config.port is not None:
        env_vars.setdefault("PORT", str(app_config.port))
    elif env_vars is None and app_config.port is not None:
        env_vars = {"PORT": str(app_config.port)}

    if env_vars:
        app_service["environment"] = env_vars

    # Reference env_file directly instead of merging its contents
    if app_config.env_file:
        env_file = app_config.env_file
        app_service["env_file"] = [env_file] if isinstance(env_file, str) else env_file

    if app_config.dependencies:
        app_service["depends_on"] = list(app_config.dependencies.keys())

    services["app"] = app_service

    # Compose file structure
    compose: dict[str, Any] = {
        "services": services,
        "networks": {
            SHARED_NETWORK: {"external": True},
        },
    }

    # Top-level named volumes
    if config.volumes:
        compose["volumes"] = config.volumes

    return compose


def _service_config_to_compose(config: ServiceConfig) -> dict[str, Any]:
    """Convert ServiceConfig to docker-compose service definition.

    Args:
        config: Service configuration

    Returns:
        Docker compose service definition
    """
    # model_dump includes explicitly-declared fields and any extra fields (extra='allow')
    service: dict[str, Any] = config.model_dump(exclude_none=True)

    # Add restart policy by default (if not set by user)
    service.setdefault("restart", "unless-stopped")

    # Add to shared network
    service["networks"] = [SHARED_NETWORK]

    return service


def _build_and_start_app(
    conn: VPSConnection, app_dir: str
) -> None:
    """Build and start application using docker compose.

    Args:
        conn: VPS connection
        app_dir: Remote application directory
    """
    console.print("[cyan]Building and starting application...[/cyan]")

    # Pull dependency images
    console.print("[cyan]Pulling dependency images...[/cyan]")
    conn.run(f"cd {app_dir} && docker compose pull", warn=True)

    # Build application image
    console.print("[cyan]Building application image...[/cyan]")
    result = conn.run(f"cd {app_dir} && docker compose build app")

    if not result.ok:
        raise RuntimeError("Failed to build application image")

    console.print("[green]✓ Application image built[/green]")

    # Start services with force-recreate
    console.print("[cyan]Starting services...[/cyan]")
    result = conn.run(f"cd {app_dir} && docker compose up -d --force-recreate")

    if not result.ok:
        raise RuntimeError("Failed to start services")

    console.print("[green]✓ Services started[/green]")


def _test_deployment(conn: VPSConnection, app_config: ApplicationConfig) -> None:
    """Test that application is reachable via its domain.

    Args:
        conn: VPS connection
        app_config: Application configuration
    """
    console.print(f"[cyan]Testing deployment at {app_config.domain}...[/cyan]")

    # Wait a bit for services to start
    import time

    time.sleep(2)

    # Check if app container is running
    result = conn.run(
        f"docker ps --filter name={app_config.name}-app --format '{{{{.Status}}}}'",
        hide=True,
    )

    if "Up" not in result.stdout:
        console.print("[red]✗ Application container is not running[/red]")
        # Show logs for debugging
        conn.run(f"docker logs {app_config.name}-app")
        raise RuntimeError("Application failed to start")

    console.print("[green]✓ Application container is running[/green]")

    # Test HTTP connectivity from VPS
    result = conn.run(
        f"curl -f -s -o /dev/null -w '%{{http_code}}' http://localhost:80 -H 'Host: {app_config.domain}' || echo 'failed'",
        warn=True,
        hide=True,
    )

    if "failed" in result.stdout or result.stdout.strip() not in ["200", "301", "302", "308"]:
        console.print(
            f"[yellow]⚠ Could not verify HTTP connectivity (got: {result.stdout.strip()})[/yellow]"
        )
        console.print(
            "[yellow]This may be normal if the application requires HTTPS or returns different status codes[/yellow]"
        )
    else:
        console.print(f"[green]✓ Application responding with HTTP {result.stdout.strip()}[/green]")

    console.print(
        "[cyan]Note: SSL certificates may take a few minutes to provision on first deployment[/cyan]"
    )
