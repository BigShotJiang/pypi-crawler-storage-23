"""DockLift - Deploy web applications to VPS with Docker Compose and automatic SSL."""

from .cli import main

__all__ = ["main"]
