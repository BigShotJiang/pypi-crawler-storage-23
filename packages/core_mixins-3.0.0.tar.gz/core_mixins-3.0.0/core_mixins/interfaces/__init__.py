# -*- coding: utf-8 -*-

"""Interface definitions for factory and task patterns."""

from .factory import IFactory
from .task import ITask
from .task import TaskException
from .task import TaskResult
from .task import TaskStatus


__all__ = [
    "IFactory",
    "ITask",
    "TaskException",
    "TaskResult",
    "TaskStatus",
]
