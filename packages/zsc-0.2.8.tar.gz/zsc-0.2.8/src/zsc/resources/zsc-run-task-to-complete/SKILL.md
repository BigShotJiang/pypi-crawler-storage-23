---
name: zsc-run-task-to-complete
description: High-automation skill for running a task end-to-end. Use when the user wants to let the AI execute as many TODOs as safely possible in one go, with minimal interaction. Task creation and design is handled by zsc-create-task; interactive execution is handled by zsc-run-task.
---

# zsc-run-task-to-complete

**Scope: high-automation task execution.** This skill takes an existing task (from `.agents/tasks/task_{no}_{feat_name}/`) and tries to execute **as many TODOs as safely possible in one run**, with minimal back-and-forth. It is built on the same principles as **zsc-run-task**, but favors continuous execution over step-by-step confirmation. **Task creation and design** (闭环描述, TODO_LIST design) are handled by **zsc-create-task**; interactive, fine-grained execution remains the responsibility of **zsc-run-task**. Here, **zsc** stands for **zig slice code**.

> ⚠ **Safety note**: This is an advanced, high-automation skill. It may perform multiple code/document changes and run commands in one session. Prefer using it in feature branches or non-production environments, and always review diffs before committing or deploying.

## Scope boundary (mandatory, highest priority)

**Whenever this skill is used, regardless of the user's prompt:**

- **Allowed**:
  - Work on **one selected task only**: read that task's 闭环描述 and TODO_LIST and the project codebase.
  - Edit that task's `.md` under `.agents/tasks/` (e.g. mark TODOs done, add execution notes, rewrite TODO_LIST on completion).
  - Implement TODOs by modifying project code, tests, configs, or docs as required by the task.
  - Run local commands or tests (e.g. `pytest`, `uv pip install`, linters) when they are clearly part of the TODOs or needed to validate changes.
- **Not allowed**:
  - Create new tasks or new task directories under `.agents/tasks` (use **zsc-create-task** instead).
  - Change the design (闭环描述 / TODO_LIST structure) of **other** tasks.
  - Perform irreversible, dangerous, or out-of-scope operations (e.g. destructive data operations, production deployments) unless the TODO and context explicitly authorize them and you still confirm safety.

For actions that clearly affect production data, external services, or are otherwise hard to roll back, **prefer to log a recommendation in the task file instead of executing them automatically**. For normal development work on a feature branch or local environment, assume it is appropriate to directly implement the TODO rather than deferring it.

## When to use

Use **zsc-run-task-to-complete** instead of **zsc-run-task** when:

- The user wants to "run this task as far as possible" or "do everything in this task in one go".
- The TODO_LIST is relatively clear, sequential, and low-to-medium risk.
- The user is working in a disposable / feature branch or non-production environment and is comfortable with bulk edits.

Prefer **zsc-run-task** when:

- TODOs require many product/architecture decisions or ambiguous trade-offs.
- The user wants tight control and frequent confirmations.

## Task file location

- Task dir: `.agents/tasks/task_{no}_{feat_name}/`
- Task file: canonical name is same as directory, e.g. `task_01_scan_plugin/task_01_scan_plugin.md` (unique for @ reference in AI tools); legacy `task.md` is supported when reading.

## Execution loop (high level)

When running this skill, follow a **loop-oriented** execution style:

1. **Parse the task and TODO queue**
   - Read the task's 闭环描述 and `## TODO_LIST`.
   - Build an ordered queue of unchecked `- [ ]` TODO items for this round.
   - Skip already completed or archived items.
2. **Execute TODOs continuously**
   - Take the next TODO, infer the concrete actions required (code edits, tests, docs, commands).
   - **Prefer to actually apply changes** to the codebase and/or docs, rather than only analyzing or rewriting the TODO text.
   - Run relevant local checks or tests when appropriate (and feasible) to validate the change.
   - Update the task file:
     - Mark the item as completed (e.g. change `- [ ]` to `- [x]`) or
     - Replace it with a short execution note and mark it as done **only after real work has been performed**.
   - Proceed immediately to the next TODO **without waiting for explicit user confirmation**, unless:
     - The action appears risky or destructive, or
     - The TODO text explicitly asks for a decision from the user.
3. **Handle errors and blocking points**
   - If a command/test fails or a TODO cannot be completed automatically **after at least one concrete implementation attempt**:
     - Capture key error messages and write a short note under that TODO (or a "blocked" section), including what was already tried.
     - Decide whether to:
       - Retry with a small adjustment, or
       - Mark the TODO as "blocked" and stop further execution.
   - If the session is interrupted, ensure the task file reflects the current progress so future runs can continue from the last meaningful point.
4. **Completion and TODO_LIST rewrite**
   - When there are **no remaining unchecked `- [ ]` TODOs for this round** (either completed or explicitly marked as blocked/unimplemented for clear reasons), follow the same completion rules as **zsc-run-task**:
     - Rewrite the `## TODO_LIST` section.
     - Keep the maintenance note:
       - `> 只维护最新版本；完成后清空 TODO，仅保留"完成记录 + 日期"。`
     - Keep a line indicating that this round's TODOs are cleared, e.g.:
       - `- （本轮已完成，TODO 清空）`
     - Add a one-line completion record with date and a brief summary of what was done automatically:
       - `- 2026-02-26: Auto-ran N TODOs via zsc-run-task-to-complete; M completed, K marked as blocked with notes.`

## Relationship to zsc-run-task

- **zsc-run-task**:
  - Interactive, step-by-step.
  - Good for tasks that need human judgment and iterative adjustment.
  - You should frequently sync with the user after major steps.
- **zsc-run-task-to-complete**:
  - High-automation, "best-effort to finish the task" mode.
  - Good for well-specified TODO_LISTs where actions are mostly mechanical or low-risk.
  - You are expected to keep going across multiple TODOs, only pausing when something is ambiguous or risky.

Both skills **share the same completion semantics** for `## TODO_LIST` (maintenance note, completion marker, dated summary). When suggesting to the user which one to use, favor:

- **zsc-run-task** for fine-grained, interactive progress.
- **zsc-run-task-to-complete** for "fire-and-forget" execution in a safe environment.

---
name: zsc-run-task-to-complete
description: High-automation skill for running a task end-to-end. Use when the user wants to let the AI execute as many TODOs as safely possible in one go, with minimal interaction. Task creation and design is handled by zsc-create-task; interactive execution is handled by zsc-run-task.
---

# zsc-run-task-to-complete

**Scope: high-automation task execution.** This skill takes an existing task (from `.agents/tasks/task_{no}_{feat_name}/`) and tries to execute **as many TODOs as safely possible in one run**, with minimal back-and-forth. It is built on the same principles as **zsc-run-task**, but favors continuous execution over step-by-step confirmation. **Task creation and design** (闭环描述, TODO_LIST design) are handled by **zsc-create-task**; interactive, fine-grained execution remains the responsibility of **zsc-run-task**.

> ⚠ **Safety note**: This is an advanced, high-automation skill. It may perform multiple code/document changes and run commands in one session. Prefer using it in feature branches or non-production environments, and always review diffs before committing or deploying.

## Scope boundary (mandatory, highest priority)

**Whenever this skill is used, regardless of the user's prompt:**

- **Allowed**:
  - Work on **one selected task only**: read that task's 闭环描述 and TODO_LIST and the project codebase.
  - Edit that task's `.md` under `.agents/tasks/` (e.g. mark TODOs done, add execution notes, rewrite TODO_LIST on completion).
  - Implement TODOs by modifying project code, tests, configs, or docs as required by the task.
  - Run local commands or tests (e.g. `pytest`, `uv pip install`, linters) when they are clearly part of the TODOs or needed to validate changes.
- **Not allowed**:
  - Create new tasks or new task directories under `.agents/tasks` (use **zsc-create-task** instead).
  - Change the design (闭环描述 / TODO_LIST structure) of **other** tasks.
  - Perform irreversible, dangerous, or out-of-scope operations (e.g. destructive data operations, production deployments) unless the TODO and context explicitly authorize them and you still confirm safety.

For actions that clearly affect production data, external services, or are otherwise hard to roll back, **prefer to log a recommendation in the task file instead of executing them automatically**. For normal development work on a feature branch or local environment, assume it is appropriate to directly implement the TODO rather than deferring it.

## When to use

Use **zsc-run-task-to-complete** instead of **zsc-run-task** when:

- The user wants to "run this task as far as possible" or "do everything in this task in one go".
- The TODO_LIST is relatively clear, sequential, and low-to-medium risk.
- The user is working in a disposable / feature branch or non-production environment and is comfortable with bulk edits.

Prefer **zsc-run-task** when:

- TODOs require many product/architecture decisions or ambiguous trade-offs.
- The user wants tight control and frequent confirmations.

## Task file location

- Task dir: `.agents/tasks/task_{no}_{feat_name}/`
- Task file: canonical name is same as directory, e.g. `task_01_scan_plugin/task_01_scan_plugin.md` (unique for @ reference in AI tools); legacy `task.md` is supported when reading.

## Execution loop (high level)

When running this skill, follow a **loop-oriented** execution style:

1. **Parse the task and TODO queue**
   - Read the task's 闭环描述 and `## TODO_LIST`.
   - Build an ordered queue of unchecked `- [ ]` TODO items for this round.
   - Skip already completed or archived items.
2. **Execute TODOs continuously**
   - Take the next TODO, infer the concrete actions required (code edits, tests, docs, commands).
   - **Prefer to actually apply changes** to the codebase and/or docs, rather than only analyzing or rewriting the TODO text.
   - Run relevant local checks or tests when appropriate (and feasible) to validate the change.
   - Update the task file:
     - Mark the item as completed (e.g. change `- [ ]` to `- [x]`) or
     - Replace it with a short execution note and mark it as done **only after real work has been performed**.
   - Proceed immediately to the next TODO **without waiting for explicit user confirmation**, unless:
     - The action appears risky or destructive, or
     - The TODO text explicitly asks for a decision from the user.
3. **Handle errors and blocking points**
   - If a command/test fails or a TODO cannot be completed automatically **after at least one concrete implementation attempt**:
     - Capture key error messages and write a short note under that TODO (or a "blocked" section), including what was already tried.
     - Decide whether to:
       - Retry with a small adjustment, or
       - Mark the TODO as "blocked" and stop further execution.
   - If the session is interrupted, ensure the task file reflects the current progress so future runs can continue from the last meaningful point.
4. **Completion and TODO_LIST rewrite**
   - When there are **no remaining unchecked `- [ ]` TODOs for this round** (either completed or explicitly marked as blocked/unimplemented for clear reasons), follow the same completion rules as **zsc-run-task**:
     - Rewrite the `## TODO_LIST` section.
     - Keep the maintenance note:
       - `> 只维护最新版本；完成后清空 TODO，仅保留"完成记录 + 日期"。`
     - Keep a line indicating that this round's TODOs are cleared, e.g.:
       - `- （本轮已完成，TODO 清空）`
     - Add a one-line completion record with date and a brief summary of what was done automatically:
       - `- 2026-02-26: Auto-ran N TODOs via zsc-run-task-to-complete; M completed, K marked as blocked with notes.`

## Relationship to zsc-run-task

- **zsc-run-task**:
  - Interactive, step-by-step.
  - Good for tasks that need human judgment and iterative adjustment.
  - You should frequently sync with the user after major steps.
- **zsc-run-task-to-complete**:
  - High-automation, "best-effort to finish the task" mode.
  - Good for well-specified TODO_LISTs where actions are mostly mechanical or low-risk.
  - You are expected to keep going across multiple TODOs, only pausing when something is ambiguous or risky.

Both skills **share the same completion semantics** for `## TODO_LIST` (maintenance note, completion marker, dated summary). When suggesting to the user which one to use, favor:

- **zsc-run-task** for fine-grained, interactive progress.
- **zsc-run-task-to-complete** for "fire-and-forget" execution in a safe environment.

