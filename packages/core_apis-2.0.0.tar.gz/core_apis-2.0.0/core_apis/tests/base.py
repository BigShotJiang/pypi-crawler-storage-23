# -*- coding: utf-8 -*-

"""
Base test classes for API testing.

This module provides base test case classes that can be inherited by other test modules
to facilitate testing of FastAPI applications. It includes utilities for setting up
test clients and managing test application instances.
"""

from typing import Optional
from unittest import TestCase

from fastapi import FastAPI
from starlette.testclient import TestClient

from core_apis.api import AppConfig
from core_apis.api import CorsConfig
from core_apis.api import create_application
from core_apis.api.routers import reset_routers


class BaseApiTestCases(TestCase):
    """
    Base class for tests related to the API.

    This class provides a reusable foundation for API testing by automatically
    setting up a FastAPI test application and test client. Tests that inherit
    from this class will have access to a configured TestClient instance.
    """

    client: Optional[TestClient] = None
    app: Optional[FastAPI] = None

    def setUp(self) -> None:
        """Reset the router registry before each test to prevent cross-test pollution."""
        reset_routers()

    @classmethod
    def setUpClass(cls) -> None:
        """
        Set up the test class before any test methods run.

        This method is called once per test class and initializes the
        test client and application instance.
        """

        super().setUpClass()
        cls.init_client()

    @classmethod
    def init_client(cls, with_cors: bool = True):
        """
        Initialize the test client and FastAPI application.

        Creates a new FastAPI application instance configured for testing
        and wraps it with a TestClient for making HTTP requests.

        Args:
            with_cors: Whether to add CORS middleware to the test application.
                       Defaults to True.
        """

        app = create_application(
            app_config=AppConfig(
                name="API-Tests",
                cors_config=CorsConfig(enabled=with_cors),
            ),
        )

        cls.client = TestClient(app)
        cls.app = app
