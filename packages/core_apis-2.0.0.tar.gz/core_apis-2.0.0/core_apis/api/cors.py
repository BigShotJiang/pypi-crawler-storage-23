# -*- coding: utf-8 -*-

"""
CORS configuration dataclass.

This module provides the CorsConfig dataclass used to configure
the CORS middleware in create_application().
"""

from dataclasses import dataclass
from dataclasses import field


@dataclass
class CorsConfig:
    """
    Configuration for the CORS middleware.

    :param enabled: Whether to enable CORS middleware.
    :param origins: Allowed origins. Defaults to ``["*"]``.
    :param methods: Allowed HTTP methods. Defaults to ``["*"]``.
    :param headers: Allowed headers. Defaults to ``["*"]``.
    """

    enabled: bool = False
    origins: list[str] = field(default_factory=lambda: ["*"])
    methods: list[str] = field(default_factory=lambda: ["*"])
    headers: list[str] = field(default_factory=lambda: ["*"])
