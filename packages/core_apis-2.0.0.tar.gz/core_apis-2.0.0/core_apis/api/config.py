# -*- coding: utf-8 -*-

"""
Application configuration dataclass.

This module provides the AppConfig dataclass used to configure
the FastAPI application in create_application().
"""

from dataclasses import dataclass
from typing import Optional

from .cors import CorsConfig


@dataclass
class AppConfig:
    """
    Configuration for the FastAPI application.

    :param name: Application name.
    :param description: API description.
    :param version: The version.
    :param base_path: The base path to use when the routes are registered.

    :param cors_config:
        CORS configuration. Pass a :class:`CorsConfig` instance
        to enable and configure the CORS middleware.

    :param debug: True for debugging.
    """

    name: str = "API Service"
    description: str = "API Service example..."
    version: str = "0.0.1"
    base_path: str = "/api"
    cors_config: Optional[CorsConfig] = None
    debug: bool = False
