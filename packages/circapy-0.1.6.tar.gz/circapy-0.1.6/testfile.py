print('Hello World')

