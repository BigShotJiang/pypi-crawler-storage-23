Sleep Process
=============

.. automodule:: circaPy.sleep_process
   :members:
   :undoc-members:
   :show-inheritance:
