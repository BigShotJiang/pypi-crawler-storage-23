API Reference
=============

This section contains the full API reference for all circaPy modules.

.. toctree::
   :maxdepth: 1

   activity
   plots
   preprocessing
   periodogram
   episodes
   sleep_process
