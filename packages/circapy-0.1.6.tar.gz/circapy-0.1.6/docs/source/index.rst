.. circaPy documentation master file

circaPy documentation
=====================

circaPy is a Python library for researchers and anyone interested in analysing
circadian activity data. It contains a series of methods commonly used in the
field of circadian biology, applicable across species and monitoring devices.

Check out the :doc:`usage` section for installation and quickstart examples,
or browse the :doc:`api/index` for full API reference.

.. note::
   This project is under active development.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   usage
   api/index
