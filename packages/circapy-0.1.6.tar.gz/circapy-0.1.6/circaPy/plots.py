import re
import pdb
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gs
from matplotlib.transforms import Bbox
import circaPy.activity as act
import circaPy.preprocessing as prep


@prep.validate_input
@prep.invert_light_values
@prep.plot_kwarg_decorator
def plot_actogram(
    data,
    subject_no=0,
    light_col=-1,
    ylim=[0, 120],
    fig=False,
    subplot=False,
    ldralpha=0.5,
    start_day=0,
    day_label_size=5,
    linewidth=0.5,
    extra_day_limit="6h",
    **kwargs,
):
    """
    Plot an double plotted actogram of activity data over several days
    with background shading set by the lights

    Parameters:
    ----------
    data : (pd.DataFrame)
        time-indexed pandas dataframe with activity values in
        columns for each subject and one column for the light levels.
        WRONG - currently expecting list of dataframes, one for each animal
        and single column for each day
    subject_no : int
        which column number to plot, defaults to 0
    light_col : int
        which columns contains light information, defaults to -1
    ylim : list of two ints
        set the minimum and maximum values to plot
    fig : matplotlib figure object
        Figure to create plot on, if not passed defaults to false and
        new figure is passed
    subplot : matplotlib subplotspec object
        Subplotspec from larger figure on which to draw actogram.
        Must be created from gridspec
        If not passed
        defaults to False, which requires a fig object to be provided
    ldralpha : float
        Set the alpha level for how opaque to have the light shading,
        defaults to 0.5
    startday : int
        sets which day to start as day 0 in plot, defaults to 0
    day_label_size : int
        sets size of labels on bottom x axis, defaults to 5
    extra_day_limit : str
        sets the threshold at which an extra day of values is added to start
        and end of the actogram. In Timedelta string values. Default is "6H"

    Returns
    -------
    matplotlib.pyplot.figure
        instance containing overall figure
    matplotlib.pyplot.subplot
        the final subplot so can manipulate for xaxis
    dict
        dict containing plotting kwargs
    """
    # grab line plot constant
    if "linewidth" in kwargs:
        linewidth = kwargs["linewidth"]

    # check if data is empty
    if data.empty:
        raise ValueError("Input Dataframe is empty. Cannot plot actogram")

    # select the correct data to plot for activity and light
    col_data = data.columns[subject_no]
    ldr_col = data.columns[light_col]
    data_plot = data.loc[:, col_data].copy()
    data_light = data.loc[:, ldr_col].copy()

    # add entire day of 0s at start and end by extending index
    # grab values from current index
    freq = data_plot.index.freq # Decorator enforces
    start = data_plot.index.min()
    end = data_plot.index.max()

    # check frequency works
    try:
        pd.Timedelta(freq)
    except BaseException:
        freq = pd.Timedelta(f"1{freq}")

    # Extend the range by 1 day but make sure lines up with original index
    extended_start = data_plot.index.min().normalize()
    extended_end = (
        data_plot.index.max().normalize()
        + pd.Timedelta(days=1)
        - pd.Timedelta(seconds=1)
    )

    # Check how close data is to new start, and add extra day if so
    if abs(extended_start - data_plot.index.min()) <= pd.Timedelta(extra_day_limit):
        extended_start = extended_start - pd.Timedelta(days=1)
    if abs(extended_end - data_plot.index.max()) <= pd.Timedelta(extra_day_limit):
        extended_end = extended_end + pd.Timedelta(days=1)

    # create new index and set data to it
    extended_index = pd.date_range(start=extended_start, end=extended_end, freq=freq)
    data_plot = data_plot.reindex(extended_index, fill_value=-100)
    data_light = data_light.reindex(extended_index, fill_value = -100)

    # select just the days
    days = data_plot.index.normalize().unique()

    # Extract numpy values
    data_values = data_plot.values
    light_values = data_light.values

    # set all 0 values to be very low so not showing on y index starting at 0
    data_values[data_values == 0] = -100
    light_values[light_values == 0] = -100

    # Set interactive off to speed up plotting
    plt.ioff()

    # Create figure and subplot for every day
    # create a new figure if not passed one when called
    if not fig:
        fig, ax = plt.subplots(nrows=(len(days) - 1))
        fig.subplots_adjust(hspace=0)

    # add subplots to figure if passed when called
    else:
        # remove ticks so don't draw over when we add later
        subplot.set(yticks=[], xticks=[])

        # draw subplots for each day on the subplot given
        subplot_spec = subplot.get_subplotspec()
        subfig = fig.add_subfigure(subplot_spec)
        ax = subfig.subplots(
            nrows=(len(days) - 1),
            ncols=1,
            gridspec_kw={"wspace":0, "hspace":0}
        )

    # Fill missing/0s with nans to avoid horizontal lines
    fill_data_full = np.where(data_values > 0, data_values, np.nan)
    fill_ldr_full = np.where(light_values > 0, light_values, np.nan)
    index_arr = data_plot.index

    # Create list of starts/ends to speed up loop
    day_starts = index_arr.searchsorted(days)
    day_ends = index_arr.searchsorted(days + pd.Timedelta("2d"))

    # select each day to then plot on separate axis
    # plot two days on each row
    for start, end, axis in zip(day_starts, day_ends, ax):
        # Find start and end of data to plot
        curr_index = index_arr[start:end]

        # plot the data and light_col
        axis.plot(curr_index, data_values[start:end], linewidth=linewidth)
        axis.fill_between(curr_index, fill_data_full[start:end])
        axis.fill_between(curr_index, fill_ldr_full[start:end], alpha=ldralpha, facecolor="grey")

        # need to hide all the axis to make data visible
        axis.set(
            xticks=[],
            xlim=[curr_index[0], curr_index[-1]],
            yticks=[],
            ylim=ylim,
        )
        for spine in axis.spines.values():
            spine.set_visible(False)

    # create the y labels for every 10th row
    day_markers = np.arange(0, len(days), 10)
    day_markers = day_markers + start_day
    for axis, day in zip(ax[::10], day_markers):
        axis.set_ylabel(
            day, rotation=0, va="center", ha="right", fontsize=day_label_size
        )

    # create defaults dict
    params_dict = {
        "xlabel": "Time",
        "ylabel": "Days",
        "interval": 6,
        "title": "Double Plotted Actogram",
        "timeaxis": True,
        "subplot": subplot,
    }

    # put axis as a controllable parameter
    if "timeaxis" in kwargs:
        params_dict["timeaxis"] = kwargs["timeaxis"]

    # Restore interactive
    plt.ion()

    return fig, ax, params_dict


@prep.validate_input
@prep.invert_light_values
@prep.plot_kwarg_decorator
def plot_activity_profile(
    data,
    col=0,
    light_col=-1,
    subplot=None,
    resample=False,
    resample_freq="h",
    *args,
    **kwargs,
):
    """
    Plot the activity profile with mean and SEM (Standard Error of the Mean).
    Optionally resample the data before plotting.

    Parameters
    ----------
    data : pd.DataFrame or pd.Series
        Activity data indexed by time. If `data` is a DataFrame, the
        function uses the column specified by `col` (default is the
        first column).
    col : int, optional
        The index of the column to plot, used when `data` is a
        DataFrame (default is 0).
    subplot : matplotlib.axes._axes.Axes, optional
        Subplot to plot on. If None, a new figure and axis are
        created (default is None).
    resample : bool, optional
        Whether to resample the data before plotting.
        If `True`, the data will be resampled to the frequency
        specified by `resample_freq` (default is `False`).
    resample_freq : str, optional
        The frequency to resample the data to.
        This can be any valid pandas offset string
        (e.g., "h" for hourly, "min" for minutely).
        The default is "h" (hourly).
    *args, **kwargs : additional arguments
        These are passed to the plotting function,
        such as `timeaxis` to control the appearance of the x-axis.

    Returns
    -------
    fig : matplotlib.figure.Figure
        The figure containing the plot.
    ax : matplotlib.axes._axes.Axes
        The axis with the plot.
    params_dict : dict
        A dictionary containing the plot's parameters,
        including labels, title, and xlim.
    """
    # ability to resample if required
    if resample:
        data = data.resample(resample_freq).mean()

    # Makes col a list to works with looping
    col = [col] if isinstance(col, int) else col

    # Select LDR column and perform light calculations
    light_data = data.iloc[:, light_col]
    light_mean = act.calculate_mean_activity(light_data)

    # Convert the index of mean and sem to a DatetimeIndex starting 2001-01-01
    datetime_index, freq = _create_datetime_index(data, light_mean)
    light_mean.index = datetime_index

    # Ensure freq has a numeric component
    if not any(char.isdigit() for char in freq):
        freq = pd.Timedelta("1" + freq)  # Prepend '1' if missing

    # Extend the light_mean data to fill to the end of the plot
    light_mean = pd.concat(
        [
            light_mean,
            pd.Series(
                [light_mean.iloc[-1]],
                index=[light_mean.index[-1] + pd.Timedelta(freq)]
            ),
        ]
    )
    light_mean.ffill(inplace=True)

    # Offset the mean and sem data to plot in the middle of the hour
    offset_time = 0.5 * pd.Timedelta(freq)
    light_mean.index += offset_time

    # Set up column selection and plotting
    num_cols = len(col)
    fig, axes = plt.subplots(
        nrows=num_cols, ncols=1, figsize=(10, 4 * num_cols), sharex=True
    )

    # Plotting in case just 1 PIR col is selected
    if num_cols == 1:
        axes = [axes]

    # Loop to plot multiple PIRs if needed
    for ax, curr_col in zip(axes, col):
        # Select the PIR Columns you want to plot as indecies (PIR1 = 0, PIR2 = 1, etc.)
        col_name = data.columns[curr_col]
        curr_data = data.loc[:, col_name]

        # Calculate mean activity and SEM for PIR data
        mean, sem = act.calculate_mean_activity(curr_data, sem=True)
        mean.index = datetime_index 
        sem.index = datetime_index
        mean.index += offset_time
        sem.index += offset_time

        # Plot mean line
        ax.plot(mean.index, mean, label=f"{col_name}", color="blue", linewidth=2)

        # Plot SEM shading
        ax.fill_between(
            mean.index, mean - sem, mean + sem, color="blue", alpha=0.3, label="± SEM"
        )

        xlim = [mean.index[0], (mean.index[0] + pd.Timedelta("24h"))]

        # Get ylims to set at this level later
        ylim = ax.get_ylim()
        # Find the min and max of light_mean
        min_light_mean = light_mean.min()
        max_light_mean = light_mean.max()

        # Define the target range
        target_max = 1000 * ylim[1]
        target_min = -1 * target_max

        # Scale the light_mean values to the target range
        # The formula to scale the values is:
        # scaled_value = (value - min_value) / (max_value - min_value)
        # * (target_max - target_min) + target_min
        scaled_light_mean = (light_mean - min_light_mean) / (
            max_light_mean - min_light_mean
        ) * (target_max - target_min) + target_min

        # Add lights region
        ax.fill_between(
            scaled_light_mean.index, scaled_light_mean, color="grey", alpha=0.2
        )

        ax.set_xlabel("Time")
        # ax.set_ylabel("Activity")
        ax.set_title(f"Activity Profile with Mean and SEM: {col_name}")
        ax.set_ylim([0, ylim[1]])  # Auto-scale max, but start at 0
        ax.legend()

    # create defaults dict
    xlim = [mean.index[0], (mean.index[0] + pd.Timedelta("24h"))]
    params_dict = {
        "xlabel": "Time(hr)",
        "ylabel": "Activity",
        "interval": 2,
        "timeaxis": True,
        "xlim": xlim,
    }

    # put axis as a controllable parameter
    if "timeaxis" in kwargs:
        params_dict["timeaxis"] = kwargs["timeaxis"]

    return fig, ax, params_dict

def _create_datetime_index(data, mean, start_date="2001-01-01"):

    freq = pd.infer_freq(data.index)
    datetime_index = pd.date_range(start=start_date, periods=len(mean), freq=freq)

    return datetime_index, freq
