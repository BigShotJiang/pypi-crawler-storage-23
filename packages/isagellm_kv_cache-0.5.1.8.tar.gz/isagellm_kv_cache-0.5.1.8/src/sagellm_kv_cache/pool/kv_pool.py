"""KV Pool for token-level memory management.

Provides high-level KV cache allocation with budget control and pin mechanism.
"""

from __future__ import annotations

from collections.abc import Callable
from uuid import UUID

from sagellm_kv_cache.errors import (
    KVBudgetExceededError,
    KVInvalidHandleError,
)
from sagellm_kv_cache.models import DType, KVHandle, Layout

from .block_manager import BlockManager


class KVPool:
    """KV cache memory pool with budget control.

    Manages KV cache allocation at token level with:
    - Budget control (max_tokens)
    - Pin mechanism (prevent eviction)
    - Block-level memory management
    - Reference counting

    Attributes:
        max_tokens: Maximum token capacity.
        block_size: Tokens per block.
        block_manager: Underlying block allocator.
        handles: Map of handle_id -> KVHandle.
        pinned_handles: Set of pinned handle IDs.

    Example:
        >>> pool = KVPool(max_tokens=1024, block_size=128)
        >>> handle = pool.alloc(128, dtype='fp16', layout='contiguous', device='cpu')
        >>> pool.pin(handle)
        >>> stats = pool.get_stats()
        >>> pool.unpin(handle)
        >>> pool.free(handle)
    """

    def __init__(
        self,
        max_tokens: int,
        block_size: int = 128,
        bytes_per_token: int = 32,
        on_budget_exceeded: Callable[[int, int, int], None] | None = None,
        node_rank: int | None = None,
    ) -> None:
        """Initialize KV pool.

        Args:
            max_tokens: Maximum token capacity (budget).
            block_size: Tokens per block (default: 128).
            bytes_per_token: Bytes per token (default: 32 for fp16).
            on_budget_exceeded: Optional callback when budget is exceeded.
                Callback signature: (requested: int, available: int, max_tokens: int) -> None
            node_rank: 节点 rank（分布式池化预留，默认 None = 单机模式）

        Raises:
            ValueError: If max_tokens or block_size <= 0.

        Example:
            >>> pool = KVPool(max_tokens=1024, block_size=128)
            >>> assert pool.max_tokens == 1024

        Note:
            node_rank 参数为分布式 KV 池化预留。未来用于：
            - 标识本地池归属于哪个节点
            - 支持 GlobalKVPoolManager 协调多节点分配
        """
        if max_tokens <= 0:
            raise ValueError(f"max_tokens must be positive, got {max_tokens}")
        if block_size <= 0:
            raise ValueError(f"block_size must be positive, got {block_size}")

        self.max_tokens = max_tokens
        self.block_size = block_size
        self.bytes_per_token = bytes_per_token
        self.on_budget_exceeded = on_budget_exceeded
        self.node_rank = node_rank  # 分布式池化预留：本地池的节点标识

        # Block-level allocator
        block_size_bytes = block_size * bytes_per_token
        self.block_manager = BlockManager(block_size=block_size_bytes)

        # Handle tracking
        self.handles: dict[UUID, KVHandle] = {}
        self.pinned_handles: set[UUID] = set()

        # Statistics
        self._allocated_tokens = 0

    def alloc(
        self,
        num_tokens: int,
        dtype: DType | str,
        layout: Layout | str,
        device: str,
        metadata: dict | None = None,
    ) -> KVHandle:
        """Allocate KV cache for tokens.

        Args:
            num_tokens: Number of tokens to allocate.
            dtype: Data type (DType enum or string like 'fp16', 'fp32').
            layout: Memory layout (Layout enum or string like 'contiguous').
            device: Device (e.g., 'cpu', 'cuda:0').
            metadata: Optional metadata.

        Returns:
            KVHandle for the allocated KV cache.

        Raises:
            KVBudgetExceededError: If allocation exceeds budget.
            ValueError: If num_tokens <= 0.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> handle = pool.alloc(128, DType.FP16, Layout.CONTIGUOUS, 'cpu')
            >>> assert handle.num_tokens == 128
        """
        if num_tokens <= 0:
            raise ValueError(f"num_tokens must be positive, got {num_tokens}")

        # Check budget
        available = self.max_tokens - self._allocated_tokens
        if num_tokens > available:
            # Call callback if provided
            if self.on_budget_exceeded:
                self.on_budget_exceeded(num_tokens, available, self.max_tokens)

            raise KVBudgetExceededError(
                requested=num_tokens, available=available, context={"max_tokens": self.max_tokens}
            )

        # Allocate blocks
        num_blocks = (num_tokens + self.block_size - 1) // self.block_size
        blocks = [self.block_manager.alloc_block() for _ in range(num_blocks)]

        # Increment ref counts
        for block in blocks:
            self.block_manager.incr_ref(block)

        # Convert dtype and layout to enum if they're strings
        if isinstance(dtype, str):
            dtype = DType(dtype)
        if isinstance(layout, str):
            layout = Layout(layout)

        # Prepare metadata (include node_rank for distributed pooling)
        final_metadata = metadata.copy() if metadata else {}
        if self.node_rank is not None:
            final_metadata["node_rank"] = self.node_rank  # 分布式池化：标记 KV 所在节点

        # Create handle
        handle = KVHandle.create(
            num_tokens=num_tokens,
            dtype=dtype,
            layout=layout,
            device=device,
            metadata=final_metadata,
        )

        # Store internal mapping
        handle._blocks = blocks  # type: ignore
        handle._is_pinned = False  # type: ignore  # Track pin state internally
        # TODO: better design

        # Track handle
        self.handles[handle.handle_id] = handle
        self._allocated_tokens += num_tokens

        return handle

    def free(self, handle: KVHandle) -> None:
        """Free KV cache.

        Args:
            handle: KVHandle to free.

        Raises:
            KVInvalidHandleError: If handle not found.
            KVDoubleFreeError: If handle already freed.
            ValueError: If handle is pinned.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> handle = pool.alloc(128, dtype='fp16', layout='contiguous', device='cpu')
            >>> pool.free(handle)
        """
        if handle.handle_id not in self.handles:
            raise KVInvalidHandleError(handle_id=handle.handle_id)

        if handle.handle_id in self.pinned_handles:
            raise ValueError(f"Cannot free pinned handle {handle.handle_id}. Call unpin() first.")

        # Get blocks
        blocks = getattr(handle, "_blocks", [])

        # Decrement ref counts and free blocks
        for block in blocks:
            self.block_manager.decr_ref(block)
            if block.ref_count == 0:
                self.block_manager.free_block(block)

        # Remove handle
        self._allocated_tokens -= handle.num_tokens
        del self.handles[handle.handle_id]

    def pin(self, handle: KVHandle) -> None:
        """Mark handle as pinned (prevent eviction).

        Args:
            handle: KVHandle to pin.

        Raises:
            KVInvalidHandleError: If handle not found.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> handle = pool.alloc(128, DType.FP16, Layout.CONTIGUOUS, 'cpu')
            >>> pool.pin(handle)
            >>> assert not handle.is_evictable()
        """
        if handle.handle_id not in self.handles:
            raise KVInvalidHandleError(handle_id=handle.handle_id)

        self.pinned_handles.add(handle.handle_id)
        handle.pin()  # Use KVHandle's pin method

    def unpin(self, handle: KVHandle) -> None:
        """Remove pinned status from handle.

        Args:
            handle: KVHandle to unpin.

        Raises:
            KVInvalidHandleError: If handle not found.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> handle = pool.alloc(128, DType.FP16, Layout.CONTIGUOUS, 'cpu')
            >>> pool.pin(handle)
            >>> pool.unpin(handle)
            >>> assert handle.is_evictable()
        """
        if handle.handle_id not in self.handles:
            raise KVInvalidHandleError(handle_id=handle.handle_id)

        if handle.pin_count > 0:
            handle.unpin()  # Use KVHandle's unpin method
        if handle.pin_count == 0:
            self.pinned_handles.discard(handle.handle_id)

    @staticmethod
    def _setup_handle_property() -> None:
        """Setup is_pinned property on KVHandle if not exists.

        Deprecated: No longer needed as we use KVHandle's pin_count directly.
        """
        pass

    def can_admit(self, num_tokens: int) -> bool:
        """Check if allocation can be admitted.

        Args:
            num_tokens: Number of tokens to check.

        Returns:
            True if allocation can be admitted, False otherwise.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> assert pool.can_admit(512)
            >>> assert not pool.can_admit(2000)
        """
        if num_tokens <= 0:
            return False

        available = self.max_tokens - self._allocated_tokens
        return num_tokens <= available

    def get_allocated_tokens(self) -> int:
        """Get total allocated tokens.

        Returns:
            Total allocated tokens.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> handle = pool.alloc(128, dtype='fp16', layout='contiguous', device='cpu')
            >>> assert pool.get_allocated_tokens() == 128
        """
        return self._allocated_tokens

    def get_available_tokens(self) -> int:
        """Get available tokens (budget - allocated).

        Returns:
            Available tokens.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> handle = pool.alloc(128, dtype='fp16', layout='contiguous', device='cpu')
            >>> assert pool.get_available_tokens() == 896
        """
        return self.max_tokens - self._allocated_tokens

    def get_stats(self) -> dict:
        """Get pool statistics.

        Returns:
            Dictionary with stats:
                - max_tokens: Maximum capacity
                - allocated_tokens: Currently allocated
                - pinned_tokens: Tokens in pinned handles
                - unpinned_tokens: Tokens in unpinned handles
                - used_tokens: Total used tokens (allocated_tokens)
                - available_tokens: Available for allocation
                - num_handles: Number of handles

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> stats = pool.get_stats()
            >>> assert stats['max_tokens'] == 1024
        """
        pinned_tokens = sum(self.handles[h_id].num_tokens for h_id in self.pinned_handles)
        unpinned_tokens = self._allocated_tokens - pinned_tokens

        return {
            "max_tokens": self.max_tokens,
            "allocated_tokens": self._allocated_tokens,
            "pinned_tokens": pinned_tokens,
            "unpinned_tokens": unpinned_tokens,
            "used_tokens": self._allocated_tokens,
            "available_tokens": self.get_available_tokens(),
            "num_handles": len(self.handles),
        }

    def reset(self) -> None:
        """Reset pool (free all handles).

        Warning: This will forcefully free all handles, including pinned ones.
        Useful for testing.

        Example:
            >>> pool = KVPool(max_tokens=1024)
            >>> handle = pool.alloc(128, dtype='fp16', layout='contiguous', device='cpu')
            >>> pool.reset()
            >>> assert pool.get_allocated_tokens() == 0
        """
        self.handles.clear()
        self.pinned_handles.clear()
        self.block_manager.reset()
        self._allocated_tokens = 0

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"KVPool(max_tokens={self.max_tokens}, "
            f"allocated={self._allocated_tokens}, "
            f"num_handles={len(self.handles)}, "
            f"num_pinned={len(self.pinned_handles)})"
        )


# Setup handle property at module load time
KVPool._setup_handle_property()
