"""Block-level memory manager for KV Cache.

Provides fixed-size block allocation with reference counting.
Follows CPU-First principle: no GPU dependencies.
"""

from __future__ import annotations

import time
from uuid import UUID, uuid4


class Block:
    """Fixed-size memory block.

    Attributes:
        block_id: Unique block identifier.
        size_bytes: Block size in bytes.
        ref_count: Reference count for shared ownership.
        allocated_at: Allocation timestamp.
        last_access: Last access timestamp (for eviction).
        data: Optional data buffer (None for CPU simulation).
    """

    def __init__(self, block_id: UUID, size_bytes: int) -> None:
        """Initialize a memory block.

        Args:
            block_id: Unique block identifier.
            size_bytes: Block size in bytes.
        """
        self.block_id = block_id
        self.size_bytes = size_bytes
        self.ref_count = 0
        self.allocated_at = time.time()
        self.last_access = self.allocated_at
        self.data: bytes | None = None  # CPU simulation: no actual buffer

    def touch(self) -> None:
        """Update last access timestamp."""
        self.last_access = time.time()

    def __repr__(self) -> str:
        """String representation."""
        return f"Block(id={self.block_id!s}, size={self.size_bytes}, ref_count={self.ref_count})"


class BlockManager:
    """Block-level memory allocator with reference counting.

    Manages fixed-size blocks for KV cache storage.
    Uses free list for allocation/deallocation.

    Attributes:
        block_size: Fixed block size in bytes.
        blocks: Map of block_id -> Block.
        free_blocks: Set of available block IDs.
        total_allocated_bytes: Total allocated memory.

    Example:
        >>> manager = BlockManager(block_size=4096)
        >>> block = manager.alloc_block()
        >>> manager.incr_ref(block)
        >>> print(manager.get_allocated_bytes())
        4096
        >>> manager.decr_ref(block)
        >>> manager.free_block(block)
    """

    def __init__(self, block_size: int = 4096) -> None:
        """Initialize block manager.

        Args:
            block_size: Fixed block size in bytes (default: 4096).

        Raises:
            ValueError: If block_size <= 0.
        """
        if block_size <= 0:
            raise ValueError(f"block_size must be positive, got {block_size}")

        self.block_size = block_size
        self.blocks: dict[UUID, Block] = {}
        self.free_blocks: set[UUID] = set()
        self.total_allocated_bytes = 0

    def alloc_block(self) -> Block:
        """Allocate a new block.

        Returns:
            Newly allocated Block.

        Example:
            >>> manager = BlockManager(block_size=4096)
            >>> block = manager.alloc_block()
            >>> assert block.size_bytes == 4096
        """
        # Reuse from free list if available
        if self.free_blocks:
            block_id = self.free_blocks.pop()
            block = self.blocks[block_id]
            block.ref_count = 0
            block.allocated_at = time.time()
            block.last_access = block.allocated_at
            return block

        # Allocate new block
        block_id = uuid4()
        block = Block(block_id=block_id, size_bytes=self.block_size)
        self.blocks[block_id] = block
        self.total_allocated_bytes += self.block_size

        return block

    def free_block(self, block: Block) -> None:
        """Free a block (return to free list).

        Args:
            block: Block to free.

        Raises:
            ValueError: If block has non-zero ref_count.
            KeyError: If block not found.

        Example:
            >>> manager = BlockManager()
            >>> block = manager.alloc_block()
            >>> manager.free_block(block)
        """
        if block.block_id not in self.blocks:
            raise KeyError(f"Block {block.block_id} not found")

        if block.ref_count != 0:
            raise ValueError(f"Cannot free block {block.block_id} with ref_count={block.ref_count}")

        self.free_blocks.add(block.block_id)

    def incr_ref(self, block: Block) -> None:
        """Increment block reference count.

        Args:
            block: Block to increment.

        Raises:
            KeyError: If block not found.

        Example:
            >>> manager = BlockManager()
            >>> block = manager.alloc_block()
            >>> manager.incr_ref(block)
            >>> assert block.ref_count == 1
        """
        if block.block_id not in self.blocks:
            raise KeyError(f"Block {block.block_id} not found")

        block.ref_count += 1
        block.touch()

    def decr_ref(self, block: Block) -> None:
        """Decrement block reference count.

        Args:
            block: Block to decrement.

        Raises:
            KeyError: If block not found.
            ValueError: If ref_count is already 0.

        Example:
            >>> manager = BlockManager()
            >>> block = manager.alloc_block()
            >>> manager.incr_ref(block)
            >>> manager.decr_ref(block)
            >>> assert block.ref_count == 0
        """
        if block.block_id not in self.blocks:
            raise KeyError(f"Block {block.block_id} not found")

        if block.ref_count == 0:
            raise ValueError(f"Block {block.block_id} ref_count is already 0")

        block.ref_count -= 1
        block.touch()

    def get_allocated_bytes(self) -> int:
        """Get total allocated bytes (including free blocks).

        Returns:
            Total allocated bytes.

        Example:
            >>> manager = BlockManager(block_size=4096)
            >>> block1 = manager.alloc_block()
            >>> block2 = manager.alloc_block()
            >>> assert manager.get_allocated_bytes() == 8192
        """
        return self.total_allocated_bytes

    def get_used_bytes(self) -> int:
        """Get used bytes (excluding free blocks).

        Returns:
            Used bytes (total - free).

        Example:
            >>> manager = BlockManager(block_size=4096)
            >>> block = manager.alloc_block()
            >>> manager.free_block(block)
            >>> assert manager.get_used_bytes() == 0
        """
        return self.total_allocated_bytes - len(self.free_blocks) * self.block_size

    def get_stats(self) -> dict[str, int]:
        """Get memory statistics.

        Returns:
            Dictionary with stats:
                - total_blocks: Total blocks allocated
                - free_blocks: Number of free blocks
                - used_blocks: Number of used blocks
                - total_allocated_bytes: Total allocated bytes
                - used_bytes: Used bytes
                - free_bytes: Free bytes

        Example:
            >>> manager = BlockManager(block_size=4096)
            >>> block = manager.alloc_block()
            >>> stats = manager.get_stats()
            >>> assert stats['total_blocks'] == 1
            >>> assert stats['used_blocks'] == 1
        """
        total_blocks = len(self.blocks)
        free_blocks_count = len(self.free_blocks)
        used_blocks = total_blocks - free_blocks_count

        return {
            "total_blocks": total_blocks,
            "free_blocks": free_blocks_count,
            "used_blocks": used_blocks,
            "total_allocated_bytes": self.total_allocated_bytes,
            "used_bytes": self.get_used_bytes(),
            "free_bytes": free_blocks_count * self.block_size,
        }

    def reset(self) -> None:
        """Reset manager (clear all blocks).

        Useful for testing.

        Example:
            >>> manager = BlockManager()
            >>> block = manager.alloc_block()
            >>> manager.reset()
            >>> assert manager.get_allocated_bytes() == 0
        """
        self.blocks.clear()
        self.free_blocks.clear()
        self.total_allocated_bytes = 0

    def __repr__(self) -> str:
        """String representation."""
        stats = self.get_stats()
        return (
            f"BlockManager(block_size={self.block_size}, "
            f"total_blocks={stats['total_blocks']}, "
            f"used_blocks={stats['used_blocks']}, "
            f"free_blocks={stats['free_blocks']})"
        )
