"""sagellm-kv-cache 本地 KV 模型类

本模块提供 KV Cache 本地模型类，继承自 sagellm-protocol 的协议定义，
并添加本地扩展方法（序列化、反序列化、辅助工具等）。

设计原则：
- Protocol-First：所有核心字段来自 Protocol 定义
- 本地扩展：仅在本地添加便捷方法，不改变 Protocol 语义
- Fail-Fast：方法调用时进行必要验证，失败时抛出明确错误

Author: sageLLM Team (Agent 2)
"""

from __future__ import annotations

import time
from typing import Any
from uuid import UUID, uuid4

from sagellm_protocol.kv import (
    DType,
    EvictionCandidate,
    EvictionPolicy,
    KVBlock,
    KVBlockState,
    KVPoolStats,
    KVTransferMetadata,
    Layout,
    LifetimePrediction,
    MemoryTier,
    PrefixCacheEntry,
    RequestType,
    SchedulerPlan,
    SchedulerRequest,
)
from sagellm_protocol.kv import (
    KVHandle as ProtoKVHandle,
)


class KVHandle(ProtoKVHandle):  # type: ignore[misc]
    """本地 KVHandle，扩展自 Protocol 定义。

    在保持与 Protocol 完全兼容的基础上，添加便捷方法：
    - to_dict() / from_dict()：序列化/反序列化
    - touch()：更新最后访问时间
    - is_evictable()：判断是否可被驱逐
    - incr_ref() / decr_ref()：引用计数操作

    Example:
        >>> handle = KVHandle.create(num_tokens=128, device="cuda:0")
        >>> print(handle.handle_id)
        >>> handle.touch()
        >>> data = handle.to_dict()
        >>> restored = KVHandle.from_dict(data)
    """

    @classmethod
    def create(
        cls,
        num_tokens: int,
        *,
        dtype: DType = DType.FP16,
        layout: Layout = Layout.CONTIGUOUS,
        device: str = "cpu",
        request_id: str | None = None,
        session_id: str | None = None,
        node_rank: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> KVHandle:
        """创建新的 KVHandle（工厂方法）。

        Args:
            num_tokens: 分配的 token 数量
            dtype: 数据类型，默认 FP16
            layout: 内存布局，默认 CONTIGUOUS
            device: 设备标识，默认 "cpu"
            request_id: 关联的请求 ID
            session_id: 关联的会话 ID
            node_rank: KV 所在节点的 rank（分布式池化预留，默认 None = 本地）
            metadata: 扩展元数据

        Returns:
            新创建的 KVHandle 实例

        Raises:
            ValueError: 如果 num_tokens <= 0

        Note:
            node_rank 参数为分布式 KV 池化预留。未来用于标识 KV Cache
            存储在哪个节点上，支持跨节点访问和全局池管理。
        """
        if num_tokens <= 0:
            raise ValueError(f"num_tokens must be positive, got {num_tokens}")

        now = time.time()
        memory_tier = cls._infer_memory_tier(device)

        # 准备元数据（包含分布式池化预留字段）
        final_metadata = metadata.copy() if metadata else {}
        if node_rank is not None:
            final_metadata["node_rank"] = node_rank  # 分布式池化：KV 所在节点

        return cls(
            handle_id=uuid4(),
            request_id=request_id,
            session_id=session_id,
            num_tokens=num_tokens,
            token_start=0,
            token_end=num_tokens,
            dtype=dtype,
            layout=layout,
            device=device,
            memory_tier=memory_tier,
            state=KVBlockState.ALLOCATED,
            pin_count=0,
            ref_count=1,
            last_access=now,
            access_count=0,
            created_at=now,
            metadata=final_metadata,
            is_compressed=False,
        )

    @staticmethod
    def _infer_memory_tier(device: str) -> MemoryTier:
        """根据设备标识推断内存层级。

        Args:
            device: 设备标识（如 "cuda:0", "npu:0", "cpu"）

        Returns:
            对应的 MemoryTier 枚举值
        """
        device_lower = device.lower()
        if device_lower.startswith(("cuda", "npu", "gpu")):
            return MemoryTier.GPU
        elif device_lower.startswith("cxl"):
            return MemoryTier.CXL
        elif device_lower.startswith("nvme"):
            return MemoryTier.NVME
        else:
            return MemoryTier.CPU

    @property
    def node_rank(self) -> int | None:
        """获取 KV 所在节点的 rank（分布式池化预留）。

        Returns:
            节点 rank，None 表示本地节点

        Example:
            >>> handle = KVHandle.create(num_tokens=128, node_rank=2)
            >>> assert handle.node_rank == 2  # KV 在节点 2 上
        """
        result = self.metadata.get("node_rank")
        return result if isinstance(result, int) else None

    def is_local(self, current_rank: int = 0) -> bool:
        """判断 KV 是否在本地节点（分布式池化预留）。

        Args:
            current_rank: 当前节点的 rank

        Returns:
            True 如果 KV 在本地，False 如果在远程节点

        Example:
            >>> handle = KVHandle.create(num_tokens=128, node_rank=1)
            >>> assert handle.is_local(current_rank=0) == False
            >>> assert handle.is_local(current_rank=1) == True
        """
        return self.node_rank is None or self.node_rank == current_rank

    def to_dict(self) -> dict[str, Any]:
        """序列化为字典。

        将 KVHandle 转换为可 JSON 序列化的字典。
        枚举值转换为字符串，UUID 转换为字符串。

        Returns:
            包含所有字段的字典

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> data = handle.to_dict()
            >>> assert isinstance(data["handle_id"], str)
        """
        data = self.model_dump()
        # 转换特殊类型
        data["handle_id"] = str(data["handle_id"])
        data["dtype"] = self.dtype.value if isinstance(self.dtype, DType) else self.dtype
        data["layout"] = self.layout.value if isinstance(self.layout, Layout) else self.layout
        data["state"] = self.state.value if isinstance(self.state, KVBlockState) else self.state
        data["memory_tier"] = (
            self.memory_tier.value if isinstance(self.memory_tier, MemoryTier) else self.memory_tier
        )
        return data  # type: ignore[no-any-return]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> KVHandle:
        """从字典反序列化。

        将字典还原为 KVHandle 实例，自动处理类型转换。

        Args:
            data: 包含字段的字典

        Returns:
            KVHandle 实例

        Raises:
            ValueError: 如果字典缺少必需字段或类型不正确

        Example:
            >>> data = {"handle_id": "...", "num_tokens": 128, ...}
            >>> handle = KVHandle.from_dict(data)
        """
        # 转换 handle_id
        if isinstance(data.get("handle_id"), str):
            data = data.copy()
            data["handle_id"] = UUID(data["handle_id"])

        # 转换枚举类型
        if isinstance(data.get("dtype"), str):
            data["dtype"] = DType(data["dtype"])
        if isinstance(data.get("layout"), str):
            data["layout"] = Layout(data["layout"])
        if isinstance(data.get("state"), str):
            data["state"] = KVBlockState(data["state"])
        if isinstance(data.get("memory_tier"), str):
            data["memory_tier"] = MemoryTier(data["memory_tier"])

        return cls.model_validate(data)  # type: ignore[no-any-return]

    def touch(self) -> None:
        """更新最后访问时间和访问计数。

        每次访问 KV 块时应调用此方法，用于 LRU 等驱逐策略。

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> old_time = handle.last_access
            >>> handle.touch()
            >>> assert handle.last_access >= old_time
        """
        self.last_access = time.time()
        self.access_count += 1

    def is_evictable(self) -> bool:
        """判断是否可被驱逐。

        当 pin_count > 0 或 state 为 PINNED 时不可驱逐。

        Returns:
            True 如果可被驱逐，False 否则

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> assert handle.is_evictable()
            >>> handle.pin_count = 1
            >>> assert not handle.is_evictable()
        """
        if self.pin_count > 0:
            return False
        if self.state == KVBlockState.PINNED:
            return False
        if self.state == KVBlockState.FREE:
            return False
        return True

    def incr_ref(self) -> int:
        """增加引用计数。

        Returns:
            增加后的引用计数值

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> assert handle.ref_count == 1
            >>> handle.incr_ref()
            >>> assert handle.ref_count == 2
        """
        self.ref_count += 1
        return self.ref_count  # type: ignore[no-any-return]

    def decr_ref(self) -> int:
        """减少引用计数。

        Returns:
            减少后的引用计数值

        Raises:
            ValueError: 如果引用计数已经为 0（防止下溢）

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> handle.incr_ref()  # ref_count = 2
            >>> handle.decr_ref()  # ref_count = 1
            >>> assert handle.ref_count == 1
        """
        if self.ref_count <= 0:
            raise ValueError(f"Reference count underflow: cannot decrement from {self.ref_count}")
        self.ref_count -= 1
        return self.ref_count  # type: ignore[no-any-return]

    def pin(self) -> int:
        """增加固定计数，使 handle 不可被驱逐。

        Returns:
            增加后的固定计数值

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> handle.pin()
            >>> assert not handle.is_evictable()
        """
        self.pin_count += 1
        return self.pin_count  # type: ignore[no-any-return]

    def unpin(self) -> int:
        """减少固定计数。

        Returns:
            减少后的固定计数值

        Raises:
            ValueError: 如果固定计数已经为 0

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> handle.pin()
            >>> handle.unpin()
            >>> assert handle.is_evictable()
        """
        if self.pin_count <= 0:
            raise ValueError(f"Pin count underflow: cannot unpin from {self.pin_count}")
        self.pin_count -= 1
        return self.pin_count  # type: ignore[no-any-return]

    def estimate_size_bytes(self, head_dim: int = 128, num_heads: int = 32) -> int:
        """估算 KV 块占用的字节数。

        基于 token 数量、数据类型和模型参数估算内存占用。
        公式: size = 2 * num_tokens * num_heads * head_dim * dtype_size
        （2 是因为 K 和 V 各占一份）

        Args:
            head_dim: 每个注意力头的维度，默认 128
            num_heads: 注意力头数量，默认 32

        Returns:
            估算的字节数
        """
        dtype_sizes = {
            DType.FP32: 4,
            DType.FP16: 2,
            DType.BF16: 2,
            DType.FP8: 1,
            DType.INT8: 1,
            DType.INT4: 0.5,
        }
        dtype_size = dtype_sizes.get(self.dtype, 2)  # 默认 FP16
        # K 和 V 各一份
        return int(2 * self.num_tokens * num_heads * head_dim * dtype_size)

    @property
    def is_pinned(self) -> bool:
        """Check if handle is currently pinned.

        Returns:
            True if pin_count > 0, False otherwise.

        Example:
            >>> handle = KVHandle.create(num_tokens=128)
            >>> assert not handle.is_pinned
            >>> handle.pin()
            >>> assert handle.is_pinned
        """
        return self.pin_count > 0

    def __repr__(self) -> str:
        """返回简洁的字符串表示。"""
        return (
            f"KVHandle(id={str(self.handle_id)[:8]}..., "
            f"tokens={self.num_tokens}, "
            f"device={self.device}, "
            f"state={self.state.value}, "
            f"pin={self.pin_count}, "
            f"ref={self.ref_count})"
        )


# ============================================================
# 重新导出其他 Protocol 类型（无需本地扩展）
# ============================================================

# 以下类型直接从 Protocol 导入，无需本地扩展
# 使用时可直接从 sagellm_kv_cache.models 导入

__all__ = [
    # 本地扩展类型
    "KVHandle",
    # 直接导出的 Protocol 类型（便于一站式导入）
    "KVBlock",
    "KVTransferMetadata",
    "PrefixCacheEntry",
    "EvictionCandidate",
    "SchedulerRequest",
    "SchedulerPlan",
    "LifetimePrediction",
    "KVPoolStats",
    # 枚举类型
    "KVBlockState",
    "DType",
    "Layout",
    "MemoryTier",
    "EvictionPolicy",
    "RequestType",
]
