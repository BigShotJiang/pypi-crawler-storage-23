"""Scheduler Bridge for KV Cache allocation.

Converts Scheduler requests into KV Pool allocation/deallocation actions.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING
from uuid import uuid4

from sagellm_kv_cache.errors import KVBudgetExceededError
from sagellm_kv_cache.eviction import EvictionManager
from sagellm_kv_cache.load_aware_scheduler import LoadAwareScheduler, PlacementStrategy
from sagellm_kv_cache.load_metrics import LoadMetricsCollector
from sagellm_kv_cache.models import (
    EvictionPolicy,
    KVHandle,
    SchedulerPlan,
    SchedulerRequest,
)
from sagellm_kv_cache.pool.kv_pool import KVPool
from sagellm_kv_cache.prefix_cache import PrefixCache

if TYPE_CHECKING:
    from collections.abc import Sequence


class SchedulerBridge:
    """Bridge between Scheduler and KV Cache subsystems.

    Responsibilities:
    - Convert SchedulerRequests to KV allocations
    - Trigger eviction when needed
    - Query prefix cache for reuse opportunities
    - Generate SchedulerPlan with allocation details

    Example:
        >>> from sagellm_kv_cache.models import RequestType
        >>> bridge = SchedulerBridge(max_tokens=1024, block_size=16)
        >>> req = SchedulerRequest(
        ...     request_id="req1",
        ...     trace_id="trace1",
        ...     request_type=RequestType.PREFILL,
        ...     prompt_len=100,
        ...     max_new_tokens=50,
        ...     kv_tokens_required=150,
        ... )
        >>> plan = bridge.plan([req])
        >>> assert plan.batch_size == 1
    """

    def __init__(
        self,
        max_tokens: int,
        block_size: int = 16,
        enable_prefix_cache: bool = True,
        eviction_policy: EvictionPolicy = EvictionPolicy.LRU,
        enable_load_awareness: bool = False,
        placement_strategy: PlacementStrategy = PlacementStrategy.LOWEST_KV,
        devices: list[str] | None = None,
    ) -> None:
        """Initialize scheduler bridge.

        Args:
            max_tokens: Maximum KV cache token budget.
            block_size: Tokens per block.
            enable_prefix_cache: Enable prefix caching.
            eviction_policy: Eviction policy to use.
            enable_load_awareness: Enable load-aware placement (Task2.7).
            placement_strategy: Device placement strategy (Task2.7).
            devices: List of devices for load tracking (default: ["cuda:0"]).
        """
        self.max_tokens = max_tokens
        self.block_size = block_size
        self.enable_prefix_cache = enable_prefix_cache
        self.enable_load_awareness = enable_load_awareness

        # Core components
        self.kv_pool = KVPool(
            max_tokens=max_tokens,
            block_size=block_size,
        )
        self.prefix_cache = PrefixCache(block_size=block_size) if enable_prefix_cache else None
        self.eviction_manager = EvictionManager(policy=eviction_policy)

        # Request tracking
        self._request_handles: dict[str, KVHandle] = {}

        # Load-aware placement (Task2.7)
        self.load_metrics_collector = LoadMetricsCollector()
        self.load_aware_scheduler = LoadAwareScheduler(
            collector=self.load_metrics_collector,
            strategy=placement_strategy,
            enable_load_awareness=enable_load_awareness,
        )

        # Register devices
        if devices is None:
            devices = ["cuda:0"]
        for device in devices:
            self.load_metrics_collector.register_device(
                device=device,
                kv_tokens_capacity=max_tokens,
                memory_capacity_mb=max_tokens * 2 * 2 / (1024 * 1024),  # FP16 estimate
            )

    def _ensure_device_registered(self, device: str) -> None:
        """Ensure device exists in load metrics collector."""
        if device not in self.load_metrics_collector.list_devices():
            self.load_metrics_collector.register_device(
                device=device,
                kv_tokens_capacity=self.max_tokens,
                memory_capacity_mb=self.max_tokens * 2 * 2 / (1024 * 1024),
            )

    def _sync_load_metrics(self, queue_lengths: dict[str, int] | None = None) -> None:
        """Synchronize per-device load metrics from current bridge state."""
        device_kv_tokens: dict[str, int] = {}
        device_active_requests: dict[str, int] = {}

        for handle in self._request_handles.values():
            device = handle.device
            device_kv_tokens[device] = device_kv_tokens.get(device, 0) + handle.num_tokens
            device_active_requests[device] = device_active_requests.get(device, 0) + 1

        all_devices = set(self.load_metrics_collector.list_devices())
        all_devices.update(device_kv_tokens.keys())
        all_devices.update(device_active_requests.keys())
        if queue_lengths:
            all_devices.update(queue_lengths.keys())

        for device in all_devices:
            self._ensure_device_registered(device)
            self.load_metrics_collector.update_kv_usage(
                device=device,
                kv_tokens_used=device_kv_tokens.get(device, 0),
            )
            self.load_metrics_collector.update_request_count(
                device=device,
                active=device_active_requests.get(device, 0),
                queued=(queue_lengths or {}).get(device, 0),
            )

    def plan(self, requests: Sequence[SchedulerRequest]) -> SchedulerPlan:
        """Generate scheduler plan for batch of requests.

        Args:
            requests: List of scheduler requests.

        Returns:
            SchedulerPlan with allocation details.

        Example:
            >>> from sagellm_kv_cache.models import RequestType
            >>> bridge = SchedulerBridge(max_tokens=1024)
            >>> req = SchedulerRequest(
            ...     request_id="req1",
            ...     trace_id="trace1",
            ...     request_type=RequestType.PREFILL,
            ...     prompt_len=50,
            ...     max_new_tokens=50,
            ...     kv_tokens_required=100,
            ... )
            >>> plan = bridge.plan([req])
            >>> assert plan.total_kv_tokens >= 100
        """
        total_kv_tokens = 0
        total_memory_mb = 0.0
        placement: dict[str, str] = {}
        queue_lengths: dict[str, int] = {}

        # pre-compute a simple per-device queue estimate for observability
        for request in requests:
            if request.device_affinity:
                queue_lengths[request.device_affinity] = (
                    queue_lengths.get(request.device_affinity, 0) + 1
                )

        self._sync_load_metrics(queue_lengths=queue_lengths)

        for request in requests:
            # Calculate tokens needed
            tokens_needed = request.kv_tokens_required

            # Select target device (Task2.7 load-aware placement)
            if request.device_affinity:
                target_device = request.device_affinity
            else:
                target_device = self.load_aware_scheduler.select_device_for_request(request)

            self._ensure_device_registered(target_device)

            # Check if allocation is possible
            if not self.kv_pool.can_admit(tokens_needed):
                # Try eviction
                try:
                    self._try_evict(tokens_needed)
                except Exception:
                    # Can't satisfy request, skip it in this plan
                    continue

            # Allocate KV cache
            try:
                handle = self.kv_pool.alloc(
                    num_tokens=tokens_needed,
                    dtype="fp16",
                    layout="contiguous",
                    device=target_device,
                    metadata={
                        "request_id": request.request_id,
                        "session_id": request.session_id,
                        "worker_id": request.worker_id,
                        "placement_strategy": self.load_aware_scheduler.strategy.value,
                        "load_aware_enabled": self.enable_load_awareness,
                    },
                )
                self._request_handles[request.request_id] = handle

                total_kv_tokens += tokens_needed
                # Estimate memory (2 bytes per token for fp16, K+V)
                total_memory_mb += (tokens_needed * 2 * 2) / (1024 * 1024)

                # Record placement
                placement[request.request_id] = target_device

                # request consumed from queue estimate
                queue_lengths[target_device] = max(0, queue_lengths.get(target_device, 0) - 1)
                self._sync_load_metrics(queue_lengths=queue_lengths)

            except KVBudgetExceededError:
                # Failed to allocate even after eviction
                continue

        self._sync_load_metrics(queue_lengths=queue_lengths)

        # Create plan
        plan = SchedulerPlan(
            plan_id=uuid4(),
            requests=list(requests),
            batch_size=len(requests),
            total_kv_tokens=total_kv_tokens,
            total_memory_mb=total_memory_mb,
            placement=placement,
            created_at=time.time(),
        )

        return plan

    def allocate_request(
        self,
        request_id: str,
        num_tokens: int,
        device: str = "cuda:0",
        session_id: str | None = None,
    ) -> KVHandle:
        """Allocate KV cache for a request.

        Args:
            request_id: Request identifier.
            num_tokens: Number of tokens to allocate.
            device: Target device.
            session_id: Optional session ID.

        Returns:
            KVHandle for the allocated cache.

        Raises:
            KVBudgetExceededError: If allocation fails.

        Example:
            >>> bridge = SchedulerBridge(max_tokens=1024)
            >>> handle = bridge.allocate_request("req1", 100)
            >>> assert handle.num_tokens == 100
        """
        # Try allocation
        if not self.kv_pool.can_admit(num_tokens):
            self._try_evict(num_tokens)

        handle = self.kv_pool.alloc(
            num_tokens=num_tokens,
            dtype="fp16",
            layout="contiguous",
            device=device,
            metadata={
                "request_id": request_id,
                "session_id": session_id,
            },
        )
        self._request_handles[request_id] = handle
        self._ensure_device_registered(device)
        self._sync_load_metrics()
        return handle

    def free_request(self, request_id: str) -> None:
        """Free KV cache for a request.

        Args:
            request_id: Request identifier.

        Example:
            >>> bridge = SchedulerBridge(max_tokens=1024)
            >>> handle = bridge.allocate_request("req1", 100)
            >>> bridge.free_request("req1")
        """
        if request_id in self._request_handles:
            handle = self._request_handles[request_id]
            # Unpin if pinned before freeing
            while handle.pin_count > 0:
                self.kv_pool.unpin(handle)
            self.kv_pool.free(handle)
            del self._request_handles[request_id]
            self._sync_load_metrics()

    def _try_evict(self, num_tokens_needed: int) -> None:
        """Try to evict enough tokens to satisfy allocation.

        Args:
            num_tokens_needed: Tokens to free.

        Raises:
            KVBudgetExceededError: If eviction fails.
        """
        # Get all allocated handles
        all_handles = list(self._request_handles.values())

        # Select victims
        try:
            victims = self.eviction_manager.select_victims(all_handles, num_tokens_needed)
        except Exception as e:
            raise KVBudgetExceededError(
                requested=num_tokens_needed,
                available=self.kv_pool.get_available_tokens(),
                context={"eviction_error": str(e)},
            ) from e

        # Free victims
        for victim in victims:
            # Find request_id for this handle
            for req_id, handle in self._request_handles.items():
                if handle.handle_id == victim.handle_id:
                    self.free_request(req_id)
                    break

    def get_stats(self) -> dict:
        """Get combined statistics.

        Returns:
            Dictionary with pool and cache stats.

        Example:
            >>> bridge = SchedulerBridge(max_tokens=1024)
            >>> stats = bridge.get_stats()
            >>> assert 'pool' in stats
        """
        stats = {
            "pool": self.kv_pool.get_stats(),
            "num_requests": len(self._request_handles),
            "load_metrics": {
                device: metrics.to_dict()
                for device, metrics in self.load_metrics_collector.get_all_metrics().items()
            },
            "placement": self.load_aware_scheduler.get_placement_stats(),
        }

        if self.prefix_cache:
            stats["prefix_cache"] = self.prefix_cache.get_stats()

        return stats

    def reset(self) -> None:
        """Reset all state.

        Example:
            >>> bridge = SchedulerBridge(max_tokens=1024)
            >>> bridge.allocate_request("req1", 100)
            >>> bridge.reset()
            >>> assert len(bridge._request_handles) == 0
        """
        self._request_handles.clear()
        self.kv_pool.reset()
        self.load_aware_scheduler.reset_stats()
        self._sync_load_metrics()
        if self.prefix_cache:
            self.prefix_cache.clear()

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"SchedulerBridge(max_tokens={self.max_tokens}, "
            f"block_size={self.block_size}, "
            f"num_requests={len(self._request_handles)})"
        )
