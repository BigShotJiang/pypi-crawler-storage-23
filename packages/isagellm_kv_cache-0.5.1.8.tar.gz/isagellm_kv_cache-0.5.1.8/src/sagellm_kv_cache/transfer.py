"""KV Transfer Engine for cross-node KV migration.

MVP 实现：通过 sagellm-comm 的 CommBackend 进行 KV 块的跨节点传输。
这是 Task1.3 的核心实现，位于 sagellm-kv-cache 仓库。
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from sagellm_protocol.kv.enums import TransferDirection, TransferStatus

from sagellm_kv_cache.errors import KVTransferFailedError
from sagellm_kv_cache.models import KVHandle, KVTransferMetadata

# Alias for convenience
KVTransferError = KVTransferFailedError


class KVTransferEngine:
    """KV Transfer Engine

    负责 KV 块的跨节点传输，使用 sagellm-comm 的 CommBackend 进行网络通信。

    MVP 实现：
    - 基础的 P2P 传输（send/recv）
    - 传输元数据管理
    - 传输状态跟踪

    TODO(后续优化):
    - 批量传输（batch transfer）
    - 压缩传输
    - 校验和验证
    - 传输重试机制
    """

    def __init__(self, comm_backend: Any) -> None:
        """初始化 KV Transfer Engine

        Args:
            comm_backend: sagellm-comm 的 CommBackend 实例

        Raises:
            ValueError: comm_backend 为 None 时抛出
        """
        if comm_backend is None:
            raise ValueError("comm_backend cannot be None (Fail-Fast)")

        self._comm_backend = comm_backend
        self._pending_transfers: dict[uuid.UUID, KVTransferMetadata] = {}
        self._completed_transfers: dict[uuid.UUID, KVTransferMetadata] = {}

    def transfer_kv_handle(
        self,
        handle: KVHandle,
        src_rank: int,
        dst_rank: int,
        tensor: Any | None = None,
    ) -> uuid.UUID:
        """传输 KV Handle 到目标节点

        Args:
            handle: KV 句柄
            src_rank: 源节点 rank
            dst_rank: 目标节点 rank
            tensor: 实际的 KV 张量数据（发送方提供）

        Returns:
            传输 ID

        Raises:
            KVTransferError: 传输失败时抛出
            ValueError: 参数无效时抛出
        """
        # Fail-Fast: 参数检查
        if src_rank < 0:
            raise ValueError(f"Invalid src_rank: {src_rank}")
        if dst_rank < 0:
            raise ValueError(f"Invalid dst_rank: {dst_rank}")
        if src_rank == dst_rank:
            raise ValueError("src_rank and dst_rank cannot be the same")

        # 创建传输元数据
        transfer_id = uuid.uuid4()
        current_rank = self._comm_backend.get_rank()

        # 确定传输方向
        if current_rank == src_rank:
            direction = TransferDirection.SEND
        elif current_rank == dst_rank:
            direction = TransferDirection.RECV
        else:
            raise ValueError(
                f"Current rank {current_rank} is neither src ({src_rank}) nor dst ({dst_rank})"
            )

        metadata = KVTransferMetadata(
            transfer_id=transfer_id,
            request_id=handle.request_id or "unknown",
            trace_id="unknown",  # TODO: 从上下文获取 trace_id
            layer_start=0,  # TODO: 从 handle 获取
            layer_end=1,
            token_start=handle.token_start,
            token_end=handle.token_end,
            num_heads=1,  # TODO: 从模型配置获取
            head_dim=128,
            dtype=handle.dtype,
            layout=handle.layout,
            total_bytes=handle.num_tokens * 128 * 2,  # 简化计算
            direction=direction,
            source_device=f"rank_{src_rank}:{handle.device}",
            target_device=f"rank_{dst_rank}:{handle.device}",
            status=TransferStatus.PENDING,
            created_at=time.time(),
        )

        # 记录待传输
        self._pending_transfers[transfer_id] = metadata

        try:
            # 开始传输
            metadata.status = TransferStatus.IN_PROGRESS
            metadata.started_at = time.time()

            if direction == TransferDirection.SEND:
                # 发送方：先发送元数据，再发送数据
                if tensor is None:
                    raise ValueError("tensor is required for sender")

                # TODO: 实际应该先发送元数据（序列化的 handle）
                # 这里简化为直接发送张量
                self._comm_backend.send(tensor, dst_rank)

            else:  # RECV
                # 接收方：先接收元数据，再接收数据
                if tensor is None:
                    raise ValueError("tensor buffer is required for receiver")

                # TODO: 实际应该先接收元数据
                # 这里简化为直接接收张量
                self._comm_backend.recv(tensor, src_rank)

            # 传输完成
            metadata.status = TransferStatus.COMPLETED
            metadata.completed_at = time.time()

            # 移动到已完成
            del self._pending_transfers[transfer_id]
            self._completed_transfers[transfer_id] = metadata

            return transfer_id

        except Exception as e:
            # 传输失败
            metadata.status = TransferStatus.FAILED
            metadata.completed_at = time.time()

            # 仍然记录到已完成（用于统计失败）
            if transfer_id in self._pending_transfers:
                del self._pending_transfers[transfer_id]
            self._completed_transfers[transfer_id] = metadata

            raise KVTransferError(
                transfer_id=transfer_id,
                source=metadata.source_device,
                target=metadata.target_device,
                reason=str(e),
                context={"error": str(e)},
            ) from e

    def get_transfer_status(self, transfer_id: uuid.UUID) -> TransferStatus:
        """获取传输状态

        Args:
            transfer_id: 传输 ID

        Returns:
            传输状态

        Raises:
            KeyError: 传输 ID 不存在时抛出
        """
        if transfer_id in self._pending_transfers:
            return self._pending_transfers[transfer_id].status
        if transfer_id in self._completed_transfers:
            return self._completed_transfers[transfer_id].status
        raise KeyError(f"Transfer ID {transfer_id} not found")

    def get_transfer_metadata(self, transfer_id: uuid.UUID) -> KVTransferMetadata:
        """获取传输元数据

        Args:
            transfer_id: 传输 ID

        Returns:
            传输元数据

        Raises:
            KeyError: 传输 ID 不存在时抛出
        """
        if transfer_id in self._pending_transfers:
            return self._pending_transfers[transfer_id]
        if transfer_id in self._completed_transfers:
            return self._completed_transfers[transfer_id]
        raise KeyError(f"Transfer ID {transfer_id} not found")

    def get_pending_count(self) -> int:
        """获取待传输数量"""
        return len(self._pending_transfers)

    def get_completed_count(self) -> int:
        """获取已完成数量"""
        return len(self._completed_transfers)

    def clear_completed(self) -> None:
        """清理已完成的传输记录"""
        self._completed_transfers.clear()
