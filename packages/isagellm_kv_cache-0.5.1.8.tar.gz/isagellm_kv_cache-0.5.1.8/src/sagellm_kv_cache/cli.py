#!/usr/bin/env python3
"""CLI tool for KV Cache statistics collection and visualization

This module provides command-line interface for working with KV cache access statistics.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def visualize_command(args: argparse.Namespace) -> int:
    """可视化命令

    Args:
        args: 命令行参数

    Returns:
        退出码
    """
    # 导入可视化脚本的功能
    try:
        import importlib.util

        # 检查可视化模块是否可用
        spec = importlib.util.find_spec("..scripts.visualize_access_pattern", package=__package__)
        if spec is None:
            raise ImportError
    except ImportError:
        # 如果无法相对导入，尝试直接运行脚本
        import subprocess

        script_path = (
            Path(__file__).parent.parent.parent.parent / "scripts" / "visualize_access_pattern.py"
        )

        cmd = [
            sys.executable,
            str(script_path),
            "--input",
            str(args.input),
        ]

        if args.output:
            cmd.extend(["--output", str(args.output)])

        if args.type:
            cmd.extend(["--type", args.type])

        if args.summary:
            cmd.append("--summary")

        result = subprocess.run(cmd)
        return result.returncode

    # 如果能导入，直接调用
    from ..scripts.visualize_access_pattern import (
        generate_frequency_bar_chart,
        generate_heatmap,
        generate_interval_histogram,
        print_summary,
    )

    if args.summary:
        print_summary(args.input)

    if args.type == "heatmap":
        generate_heatmap(args.input, args.output or Path("heatmap.png"))
    elif args.type == "frequency":
        output = (args.output or Path("frequency.png")).with_name(
            (args.output or Path("frequency.png")).stem + "_frequency.png"
        )
        generate_frequency_bar_chart(args.input, output)
    elif args.type == "interval":
        output = (args.output or Path("interval.png")).with_name(
            (args.output or Path("interval.png")).stem + "_interval.png"
        )
        generate_interval_histogram(args.input, output)
    elif args.type == "all":
        base = args.output or Path("kv_stats")
        base = base.with_suffix("")
        generate_heatmap(args.input, base.with_name(f"{base.name}_heatmap.png"))
        generate_frequency_bar_chart(args.input, base.with_name(f"{base.name}_frequency.png"))
        generate_interval_histogram(args.input, base.with_name(f"{base.name}_interval.png"))

    return 0


def demo_command(args: argparse.Namespace) -> int:
    """演示命令 - 创建示例统计数据

    Args:
        args: 命令行参数

    Returns:
        退出码
    """
    import random
    import time

    from ..profiling import AccessStatsCollector

    print("Generating demo access statistics...")

    collector = AccessStatsCollector()

    # 模拟一些访问
    block_ids = [f"block_{i:03d}" for i in range(20)]

    for _ in range(args.num_accesses):
        # 使用 Zipf 分布模拟热点访问
        block_id = random.choices(block_ids, weights=[1 / (i + 1) for i in range(len(block_ids))])[
            0
        ]

        is_hit = random.random() < 0.85  # 85% 命中率
        collector.record_access(block_id, is_hit=is_hit)

        # 模拟一些时间间隔
        time.sleep(random.uniform(0.001, 0.005))

    output_path = args.output or Path("demo_stats.json")
    collector.export_stats(output_path)

    print(f"\nDemo statistics generated: {output_path}")
    print(f"Total accesses: {collector.total_accesses}")
    print(f"Unique blocks: {len(collector.access_count)}")
    print(f"Hit rate: {collector.get_hit_rate():.2%}")

    return 0


def main() -> int:
    """主函数

    Returns:
        退出码
    """
    parser = argparse.ArgumentParser(
        prog="sage-kv-stats",
        description="KV Cache statistics collection and visualization tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate demo statistics
  sage-kv-stats demo --num-accesses 1000 --output demo_stats.json

  # Visualize statistics as heatmap
  sage-kv-stats visualize --input stats.json --output heatmap.png

  # Generate all visualizations
  sage-kv-stats visualize --input stats.json --type all --summary
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # visualize 子命令
    viz_parser = subparsers.add_parser(
        "visualize",
        aliases=["viz"],
        help="Visualize KV cache access statistics",
    )
    viz_parser.add_argument(
        "--input",
        "-i",
        type=Path,
        required=True,
        help="Input statistics JSON file",
    )
    viz_parser.add_argument(
        "--output",
        "-o",
        type=Path,
        help="Output image file path",
    )
    viz_parser.add_argument(
        "--type",
        "-t",
        choices=["heatmap", "frequency", "interval", "all"],
        default="heatmap",
        help="Type of visualization (default: heatmap)",
    )
    viz_parser.add_argument(
        "--summary",
        "-s",
        action="store_true",
        help="Print statistics summary",
    )
    viz_parser.set_defaults(func=visualize_command)

    # demo 子命令
    demo_parser = subparsers.add_parser(
        "demo",
        help="Generate demo statistics data",
    )
    demo_parser.add_argument(
        "--num-accesses",
        "-n",
        type=int,
        default=500,
        help="Number of accesses to simulate (default: 500)",
    )
    demo_parser.add_argument(
        "--output",
        "-o",
        type=Path,
        help="Output statistics file (default: demo_stats.json)",
    )
    demo_parser.set_defaults(func=demo_command)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
