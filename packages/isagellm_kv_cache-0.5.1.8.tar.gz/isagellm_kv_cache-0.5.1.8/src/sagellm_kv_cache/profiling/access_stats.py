"""KV Cache Access Pattern Statistics Collector

This module implements tools for collecting and analyzing KV cache access patterns.
"""

from __future__ import annotations

import json
import time
from collections import defaultdict
from pathlib import Path
from typing import Any


class AccessStatsCollector:
    """KV Cache 访问模式统计器

    收集和分析 KV Cache 的访问模式，包括：
    - 访问频率统计
    - 访问时间间隔分析
    - 命中率计算
    """

    def __init__(self) -> None:
        """初始化统计收集器"""
        self.access_times: dict[str, list[float]] = defaultdict(list)
        self.access_count: dict[str, int] = defaultdict(int)
        self.total_accesses: int = 0
        self.cache_hits: int = 0
        self.cache_misses: int = 0
        self.start_time: float = time.time()

    def record_access(self, block_id: str, is_hit: bool = True) -> None:
        """记录访问事件

        Args:
            block_id: KV Block 的唯一标识符
            is_hit: 是否命中缓存
        """
        timestamp = time.time()
        self.access_times[block_id].append(timestamp)
        self.access_count[block_id] += 1
        self.total_accesses += 1

        if is_hit:
            self.cache_hits += 1
        else:
            self.cache_misses += 1

    def get_access_intervals(self, block_id: str) -> list[float]:
        """获取指定 block 的访问时间间隔

        Args:
            block_id: KV Block 的唯一标识符

        Returns:
            访问时间间隔列表（秒）
        """
        times = self.access_times[block_id]
        if len(times) < 2:
            return []
        return [times[i + 1] - times[i] for i in range(len(times) - 1)]

    def get_all_intervals(self) -> list[float]:
        """获取所有 block 的访问时间间隔

        Returns:
            所有访问时间间隔的列表
        """
        all_intervals: list[float] = []
        for block_id in self.access_times:
            all_intervals.extend(self.get_access_intervals(block_id))
        return all_intervals

    def get_hit_rate(self) -> float:
        """计算缓存命中率

        Returns:
            命中率（0.0 ~ 1.0）
        """
        if self.total_accesses == 0:
            return 0.0
        return self.cache_hits / self.total_accesses

    def get_top_blocks(self, n: int = 10) -> list[tuple[str, int]]:
        """获取访问频率最高的 n 个 block

        Args:
            n: 返回的 block 数量

        Returns:
            [(block_id, access_count), ...] 列表
        """
        return sorted(self.access_count.items(), key=lambda x: x[1], reverse=True)[:n]

    def get_stats_summary(self) -> dict[str, Any]:
        """获取统计摘要

        Returns:
            包含各种统计信息的字典
        """
        all_intervals = self.get_all_intervals()
        avg_interval = sum(all_intervals) / len(all_intervals) if all_intervals else 0.0

        return {
            "total_accesses": self.total_accesses,
            "unique_blocks": len(self.access_count),
            "hit_rate": self.get_hit_rate(),
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "average_access_interval": avg_interval,
            "duration_seconds": time.time() - self.start_time,
            "top_10_blocks": [
                {"block_id": block_id, "access_count": count}
                for block_id, count in self.get_top_blocks(10)
            ],
        }

    def export_stats(self, output_path: str | Path) -> None:
        """导出统计数据到 JSON 文件

        Args:
            output_path: 输出文件路径
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        stats = self.get_stats_summary()

        # 添加详细的访问时间间隔数据
        stats["access_intervals"] = self.get_all_intervals()

        # 添加每个 block 的详细信息
        stats["block_details"] = {
            block_id: {
                "access_count": self.access_count[block_id],
                "first_access": self.access_times[block_id][0] - self.start_time,
                "last_access": self.access_times[block_id][-1] - self.start_time,
                "intervals": self.get_access_intervals(block_id),
            }
            for block_id in self.access_count
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

        print(f"Statistics exported to {output_path}")

    def reset(self) -> None:
        """重置所有统计数据"""
        self.access_times.clear()
        self.access_count.clear()
        self.total_accesses = 0
        self.cache_hits = 0
        self.cache_misses = 0
        self.start_time = time.time()
