"""Eviction policies for KV Cache.

Implements pluggable eviction strategies: LRU, FIFO, etc.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from sagellm_kv_cache.errors import KVAllPinnedError, KVNoVictimError
from sagellm_kv_cache.models import EvictionPolicy as EvictionPolicyEnum
from sagellm_kv_cache.models import KVHandle

if TYPE_CHECKING:
    from collections.abc import Sequence


class EvictionStrategy(ABC):
    """Abstract base class for eviction strategies."""

    @abstractmethod
    def select_victim(
        self,
        candidates: Sequence[KVHandle],
        num_tokens_needed: int,
        max_victims: int | None = None,
    ) -> list[KVHandle]:
        """Select victims to evict.

        Args:
            candidates: List of evictable handles.
            num_tokens_needed: Number of tokens to free.
            max_victims: Maximum number of handles that can be evicted in one round.

        Returns:
            List of handles to evict.

        Raises:
            KVNoVictimError: If no suitable victim found.
        """
        pass

    @abstractmethod
    def get_policy_name(self) -> EvictionPolicyEnum:
        """Get policy enum."""
        pass


class LRUEviction(EvictionStrategy):
    """Least Recently Used eviction policy.

    Evicts the least recently accessed blocks first.

    Example:
        >>> policy = LRUEviction()
        >>> from sagellm_kv_cache.models import KVHandle
        >>> h1 = KVHandle.create(num_tokens=100)
        >>> h2 = KVHandle.create(num_tokens=100)
        >>> h1.last_access = 1.0
        >>> h2.last_access = 2.0
        >>> victims = policy.select_victim([h1, h2], 100)
        >>> assert victims[0] == h1  # h1 is older
    """

    def select_victim(
        self,
        candidates: Sequence[KVHandle],
        num_tokens_needed: int,
        max_victims: int | None = None,
    ) -> list[KVHandle]:
        """Select LRU victims.

        Args:
            candidates: Evictable handles.
            num_tokens_needed: Tokens to free.
            max_victims: Maximum number of handles that can be evicted in one round.

        Returns:
            List of victims sorted by LRU (oldest first).

        Raises:
            KVNoVictimError: If no candidates available.
        """
        if not candidates:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,  # Assume 2 bytes per token
                pinned_count=0,
                total_count=0,
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "num_candidates": 0,
                },
            )

        # Sort by last_access (ascending = oldest first)
        sorted_candidates = sorted(candidates, key=lambda h: h.last_access)

        # Greedily select until enough tokens
        victims = []
        tokens_freed = 0

        for handle in sorted_candidates:
            if max_victims is not None and len(victims) >= max_victims:
                break
            victims.append(handle)
            tokens_freed += handle.num_tokens
            if tokens_freed >= num_tokens_needed:
                break

        if tokens_freed < num_tokens_needed:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,  # Assume 2 bytes per token
                pinned_count=0,
                total_count=len(candidates),
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "tokens_freed": tokens_freed,
                    "num_victims": len(victims),
                    "max_victims": max_victims,
                },
            )

        return victims

    def get_policy_name(self) -> EvictionPolicyEnum:
        """Return LRU policy enum."""
        return EvictionPolicyEnum.LRU


class FIFOEviction(EvictionStrategy):
    """First In First Out eviction policy.

    Evicts the oldest allocated blocks first.

    Example:
        >>> policy = FIFOEviction()
        >>> from sagellm_kv_cache.models import KVHandle
        >>> h1 = KVHandle.create(num_tokens=100)
        >>> h2 = KVHandle.create(num_tokens=100)
        >>> h1.created_at = 1.0
        >>> h2.created_at = 2.0
        >>> victims = policy.select_victim([h1, h2], 100)
        >>> assert victims[0] == h1  # h1 is older
    """

    def select_victim(
        self,
        candidates: Sequence[KVHandle],
        num_tokens_needed: int,
        max_victims: int | None = None,
    ) -> list[KVHandle]:
        """Select FIFO victims.

        Args:
            candidates: Evictable handles.
            num_tokens_needed: Tokens to free.
            max_victims: Maximum number of handles that can be evicted in one round.

        Returns:
            List of victims sorted by creation time (oldest first).

        Raises:
            KVNoVictimError: If no candidates available.
        """
        if not candidates:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,  # Assume 2 bytes per token
                pinned_count=0,
                total_count=0,
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "num_candidates": 0,
                },
            )

        # Sort by created_at (ascending = oldest first)
        sorted_candidates = sorted(candidates, key=lambda h: h.created_at)

        # Greedily select until enough tokens
        victims = []
        tokens_freed = 0

        for handle in sorted_candidates:
            if max_victims is not None and len(victims) >= max_victims:
                break
            victims.append(handle)
            tokens_freed += handle.num_tokens
            if tokens_freed >= num_tokens_needed:
                break

        if tokens_freed < num_tokens_needed:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,  # Assume 2 bytes per token
                pinned_count=0,
                total_count=len(candidates),
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "tokens_freed": tokens_freed,
                    "num_victims": len(victims),
                    "max_victims": max_victims,
                },
            )

        return victims

    def get_policy_name(self) -> EvictionPolicyEnum:
        """Return FIFO policy enum."""
        return EvictionPolicyEnum.FIFO


class TTLEviction(EvictionStrategy):
    """Time-To-Live eviction policy.

    Evicts handles that have exceeded their TTL first, then falls back to LRU.

    Attributes:
        ttl_seconds: Time-to-live in seconds (default: 300 = 5 minutes).

    Example:
        >>> import time
        >>> policy = TTLEviction(ttl_seconds=60)
        >>> from sagellm_kv_cache.models import KVHandle
        >>> h1 = KVHandle.create(num_tokens=100)
        >>> h2 = KVHandle.create(num_tokens=100)
        >>> h1.created_at = time.time() - 120  # 2 minutes ago (expired)
        >>> h2.created_at = time.time() - 30   # 30 seconds ago (not expired)
        >>> victims = policy.select_victim([h1, h2], 100)
        >>> assert victims[0] == h1  # h1 is expired
    """

    def __init__(self, ttl_seconds: float = 300.0) -> None:
        """Initialize TTL eviction policy.

        Args:
            ttl_seconds: Time-to-live in seconds (default: 300 = 5 minutes).
        """
        self.ttl_seconds = ttl_seconds

    def _is_expired(self, handle: KVHandle, current_time: float) -> bool:
        """Check if a handle has exceeded its TTL."""
        return (current_time - handle.created_at) > self.ttl_seconds

    def select_victim(
        self,
        candidates: Sequence[KVHandle],
        num_tokens_needed: int,
        max_victims: int | None = None,
    ) -> list[KVHandle]:
        """Select TTL victims.

        Prioritizes expired handles, then falls back to LRU for non-expired ones.

        Args:
            candidates: Evictable handles.
            num_tokens_needed: Tokens to free.
            max_victims: Maximum number of handles that can be evicted in one round.

        Returns:
            List of victims (expired first, then LRU).

        Raises:
            KVNoVictimError: If no candidates available.
        """
        import time

        if not candidates:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,
                pinned_count=0,
                total_count=0,
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "num_candidates": 0,
                },
            )

        current_time = time.time()

        # Separate expired and non-expired handles
        expired = [h for h in candidates if self._is_expired(h, current_time)]
        non_expired = [h for h in candidates if not self._is_expired(h, current_time)]

        # Sort expired by creation time (oldest first)
        # Sort non-expired by last_access (LRU fallback)
        sorted_expired = sorted(expired, key=lambda h: h.created_at)
        sorted_non_expired = sorted(non_expired, key=lambda h: h.last_access)

        # Combine: expired first, then non-expired
        sorted_candidates = sorted_expired + sorted_non_expired

        # Greedily select until enough tokens
        victims = []
        tokens_freed = 0

        for handle in sorted_candidates:
            if max_victims is not None and len(victims) >= max_victims:
                break
            victims.append(handle)
            tokens_freed += handle.num_tokens
            if tokens_freed >= num_tokens_needed:
                break

        if tokens_freed < num_tokens_needed:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,
                pinned_count=0,
                total_count=len(candidates),
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "tokens_freed": tokens_freed,
                    "num_victims": len(victims),
                    "max_victims": max_victims,
                    "expired_count": len(expired),
                },
            )

        return victims

    def get_policy_name(self) -> EvictionPolicyEnum:
        """Return TTL policy enum."""
        return EvictionPolicyEnum.TTL


class PriorityEviction(EvictionStrategy):
    """Priority-based eviction policy.

    Evicts handles with lower priority first. Priority is read from
    handle.metadata['priority'], with default priority of 0.

    Priority values:
    - Higher values = higher priority = less likely to be evicted
    - Lower values = lower priority = more likely to be evicted

    Example:
        >>> policy = PriorityEviction()
        >>> from sagellm_kv_cache.models import KVHandle
        >>> h1 = KVHandle.create(num_tokens=100)
        >>> h2 = KVHandle.create(num_tokens=100)
        >>> h1.metadata = {"priority": 1}
        >>> h2.metadata = {"priority": 5}
        >>> victims = policy.select_victim([h1, h2], 100)
        >>> assert victims[0] == h1  # h1 has lower priority
    """

    def __init__(self, default_priority: int = 0) -> None:
        """Initialize priority eviction policy.

        Args:
            default_priority: Default priority for handles without explicit priority.
        """
        self.default_priority = default_priority

    def _get_priority(self, handle: KVHandle) -> int:
        """Get priority from handle metadata."""
        if handle.metadata and "priority" in handle.metadata:
            return int(handle.metadata["priority"])
        return self.default_priority

    def select_victim(
        self,
        candidates: Sequence[KVHandle],
        num_tokens_needed: int,
        max_victims: int | None = None,
    ) -> list[KVHandle]:
        """Select priority-based victims.

        Args:
            candidates: Evictable handles.
            num_tokens_needed: Tokens to free.
            max_victims: Maximum number of handles that can be evicted in one round.

        Returns:
            List of victims sorted by priority (lowest first).

        Raises:
            KVNoVictimError: If no candidates available.
        """
        if not candidates:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,
                pinned_count=0,
                total_count=0,
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "num_candidates": 0,
                },
            )

        # Sort by priority (ascending = lowest priority first)
        # Use last_access as tiebreaker for same priority
        sorted_candidates = sorted(candidates, key=lambda h: (self._get_priority(h), h.last_access))

        # Greedily select until enough tokens
        victims = []
        tokens_freed = 0

        for handle in sorted_candidates:
            if max_victims is not None and len(victims) >= max_victims:
                break
            victims.append(handle)
            tokens_freed += handle.num_tokens
            if tokens_freed >= num_tokens_needed:
                break

        if tokens_freed < num_tokens_needed:
            raise KVNoVictimError(
                bytes_needed=num_tokens_needed * 2,
                pinned_count=0,
                total_count=len(candidates),
                context={
                    "num_tokens_needed": num_tokens_needed,
                    "tokens_freed": tokens_freed,
                    "num_victims": len(victims),
                    "max_victims": max_victims,
                },
            )

        return victims

    def get_policy_name(self) -> EvictionPolicyEnum:
        """Return PRIORITY policy enum."""
        return EvictionPolicyEnum.PRIORITY


class EvictionManager:
    """Manages eviction with pluggable strategies.

    Supports TTL configuration for TTL policy.

    Example:
        >>> from sagellm_kv_cache.models import EvictionPolicy
        >>> manager = EvictionManager(policy=EvictionPolicy.LRU)
        >>> from sagellm_kv_cache.models import KVHandle
        >>> handles = [KVHandle.create(num_tokens=100) for _ in range(5)]
        >>> # Mark one as pinned
        >>> handles[0].pin()
        >>> victims = manager.select_victims(handles, 200)
        >>> assert handles[0] not in victims  # Pinned handle not selected
    """

    def __init__(
        self,
        policy: EvictionPolicyEnum = EvictionPolicyEnum.LRU,
        ttl_seconds: float = 300.0,
        default_priority: int = 0,
    ) -> None:
        """Initialize eviction manager.

        Args:
            policy: Eviction policy to use.
            ttl_seconds: TTL in seconds for TTL policy (default: 300).
            default_priority: Default priority for Priority policy (default: 0).
        """
        self.policy = policy
        self.ttl_seconds = ttl_seconds
        self.default_priority = default_priority
        self._strategy = self._create_strategy(policy)

    def _create_strategy(self, policy: EvictionPolicyEnum) -> EvictionStrategy:
        """Create strategy instance from policy enum."""
        if policy == EvictionPolicyEnum.LRU:
            return LRUEviction()
        elif policy == EvictionPolicyEnum.FIFO:
            return FIFOEviction()
        elif policy == EvictionPolicyEnum.TTL:
            return TTLEviction(ttl_seconds=self.ttl_seconds)
        elif policy == EvictionPolicyEnum.PRIORITY:
            return PriorityEviction(default_priority=self.default_priority)
        else:
            # Default to LRU
            return LRUEviction()

    def select_victims(
        self,
        handles: Sequence[KVHandle],
        num_tokens_needed: int,
        max_victims: int | None = None,
    ) -> list[KVHandle]:
        """Select victims for eviction.

        Filters out pinned handles before passing to strategy.

        Args:
            handles: All handles to consider.
            num_tokens_needed: Number of tokens to free.
            max_victims: Maximum number of handles that can be evicted in one round.

        Returns:
            List of handles to evict.

        Raises:
            KVAllPinnedError: If all handles are pinned.
            KVNoVictimError: If not enough evictable tokens.
        """
        # Filter out pinned handles
        evictable = [h for h in handles if h.is_evictable()]

        if not evictable:
            raise KVAllPinnedError(
                candidate_count=len(handles),
                context={
                    "num_handles": len(handles),
                    "num_tokens_needed": num_tokens_needed,
                },
            )

        # Delegate to strategy
        return self._strategy.select_victim(evictable, num_tokens_needed, max_victims)

    def set_policy(self, policy: EvictionPolicyEnum) -> None:
        """Change eviction policy.

        Args:
            policy: New policy to use.

        Example:
            >>> manager = EvictionManager()
            >>> from sagellm_kv_cache.models import EvictionPolicy
            >>> manager.set_policy(EvictionPolicy.FIFO)
            >>> assert manager.policy == EvictionPolicy.FIFO
        """
        self.policy = policy
        self._strategy = self._create_strategy(policy)

    def __repr__(self) -> str:
        """String representation."""
        return f"EvictionManager(policy={self.policy.value})"
