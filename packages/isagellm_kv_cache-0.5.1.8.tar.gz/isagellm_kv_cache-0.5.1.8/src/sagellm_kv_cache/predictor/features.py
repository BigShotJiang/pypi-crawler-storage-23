"""Feature extraction for Lifetime Predictor.

Extracts relevant features from KVHandle and system context for prediction.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any
from uuid import UUID

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from sagellm_kv_cache.models import KVHandle


class PredictorFeatures(BaseModel):
    """Features extracted from KVHandle for lifetime prediction.

    This class follows Protocol-First principle: all features are well-defined
    and versioned. Features are extracted from KVHandle and system observability.

    Attributes:
        handle_id: KV handle identifier
        request_id: Request identifier
        session_id: Session identifier (if available)
        num_tokens: Number of tokens in this KV cache
        last_access: Last access timestamp
        access_count: Number of times accessed
        create_time: When the handle was created
        hit_len: Prefix cache hit length (if applicable)
        is_pinned: Whether the handle is pinned
        device: Device location (e.g., "cuda:0", "cpu")
        extracted_at: Feature extraction timestamp
    """

    # Identity
    handle_id: UUID = Field(description="KV handle ID")
    request_id: str = Field(description="Request ID")
    session_id: str | None = Field(default=None, description="Session ID")

    # KV properties
    num_tokens: int = Field(ge=0, description="Number of tokens")
    last_access: float = Field(ge=0, description="Last access timestamp")
    access_count: int = Field(ge=0, description="Access count")
    created_at: float = Field(ge=0, description="Creation timestamp")

    # Prefix cache features
    hit_len: int = Field(default=0, ge=0, description="Prefix hit length")

    # State
    is_pinned: bool = Field(default=False, description="Is pinned")
    device: str = Field(default="cpu", description="Device location")

    # Timing
    extracted_at: float = Field(default_factory=time.time, description="Extraction time")

    @classmethod
    def from_handle(
        cls, handle: KVHandle, hit_len: int = 0, extracted_at: float | None = None
    ) -> PredictorFeatures:
        """Extract features from a KVHandle.

        Args:
            handle: The KVHandle to extract features from.
            hit_len: Prefix cache hit length (default: 0).
            extracted_at: Extraction timestamp (default: current time).

        Returns:
            PredictorFeatures object.

        Example:
            >>> from sagellm_kv_cache.models import KVHandle
            >>> handle = KVHandle.create(num_tokens=128)
            >>> features = PredictorFeatures.from_handle(handle)
            >>> print(features.num_tokens)
            128
        """
        return cls(
            handle_id=handle.handle_id,
            request_id=handle.request_id or "unknown",
            session_id=handle.session_id,
            num_tokens=handle.num_tokens,
            last_access=handle.last_access,
            access_count=handle.access_count,
            created_at=handle.created_at,
            hit_len=hit_len,
            is_pinned=handle.is_pinned,
            device=handle.device,
            extracted_at=extracted_at or time.time(),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization.

        Returns:
            Dictionary representation.
        """
        return self.model_dump(mode="json")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PredictorFeatures:
        """Create from dictionary.

        Args:
            data: Dictionary representation.

        Returns:
            PredictorFeatures object.
        """
        return cls.model_validate(data)


class FeatureExtractor:
    """Utility class for batch feature extraction.

    Example:
        >>> extractor = FeatureExtractor()
        >>> features = extractor.extract_batch(handles)
    """

    def extract_batch(
        self,
        handles: list[KVHandle],
        hit_lens: list[int] | None = None,
    ) -> list[PredictorFeatures]:
        """Extract features from a batch of KVHandles.

        Args:
            handles: List of KVHandles.
            hit_lens: Optional list of prefix hit lengths (same length as handles).

        Returns:
            List of PredictorFeatures.

        Raises:
            ValueError: If hit_lens is provided but has wrong length.
        """
        if hit_lens is not None and len(hit_lens) != len(handles):
            msg = f"hit_lens length ({len(hit_lens)}) must match handles length ({len(handles)})"
            raise ValueError(msg)

        extracted_at = time.time()
        return [
            PredictorFeatures.from_handle(
                handle,
                hit_len=hit_lens[i] if hit_lens else 0,
                extracted_at=extracted_at,
            )
            for i, handle in enumerate(handles)
        ]
