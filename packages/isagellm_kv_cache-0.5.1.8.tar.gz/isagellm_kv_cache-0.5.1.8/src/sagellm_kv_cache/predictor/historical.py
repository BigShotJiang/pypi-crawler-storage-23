"""Historical-based Lifetime Predictor.

Implements prediction based on historical access patterns.
"""

from __future__ import annotations

import time
from collections import defaultdict
from typing import TYPE_CHECKING

from sagellm_protocol.kv import LifetimePrediction

from sagellm_kv_cache.predictor.base import LifetimePredictor

if TYPE_CHECKING:
    from collections.abc import Sequence

    from sagellm_kv_cache.predictor.features import PredictorFeatures


class HistoricalPredictor(LifetimePredictor):
    """Historical-based lifetime predictor (Task2.5 Year 1).

    Predicts lifetime based on historical patterns:
    - Tracks session-level statistics
    - Uses exponential moving average for predictions
    - Adapts to workload patterns over time

    Features:
    - Session-aware prediction
    - Access pattern learning
    - Lightweight (no ML dependencies)

    Example:
        >>> predictor = HistoricalPredictor(window_size=100)
        >>> # Train on historical data
        >>> for feat, lifetime in training_data:
        ...     predictor.update(feat, lifetime)
        >>> # Make predictions
        >>> predictions = predictor.predict_batch(test_features)
    """

    def __init__(
        self,
        window_size: int = 100,
        alpha: float = 0.1,
        default_reuse_prob: float = 0.5,
        default_lifetime: float = 1000.0,
    ) -> None:
        """Initialize historical predictor.

        Args:
            window_size: Number of recent observations to track.
            alpha: Exponential moving average smoothing factor (0~1).
            default_reuse_prob: Default reuse probability for cold start.
            default_lifetime: Default lifetime estimate for cold start.
        """
        self.window_size = window_size
        self.alpha = alpha
        self.default_reuse_prob = default_reuse_prob
        self.default_lifetime = default_lifetime

        # Per-session statistics
        self.session_stats: dict[str, dict[str, float]] = defaultdict(
            lambda: {
                "avg_lifetime": default_lifetime,
                "avg_reuse_prob": default_reuse_prob,
                "sample_count": 0,
            }
        )

        # Global statistics (fallback)
        self.global_avg_lifetime = default_lifetime
        self.global_avg_reuse_prob = default_reuse_prob
        self.global_sample_count = 0

    def predict_batch(self, features: Sequence[PredictorFeatures]) -> list[LifetimePrediction]:
        """Predict lifetime based on historical patterns.

        Args:
            features: Sequence of feature objects.

        Returns:
            List of LifetimePrediction objects.

        Raises:
            ValueError: If features is empty.
        """
        if not features:
            msg = "features must not be empty"
            raise ValueError(msg)

        predictions = []
        current_time = time.time()

        for feat in features:
            # Get session statistics or fallback to global
            session_id = feat.session_id or "global"
            stats = self.session_stats.get(
                session_id,
                {
                    "avg_lifetime": self.global_avg_lifetime,
                    "avg_reuse_prob": self.global_avg_reuse_prob,
                    "sample_count": 0,
                },
            )

            # Compute reuse probability
            # Factor in access pattern: more recent accesses -> higher reuse prob
            time_since_access = current_time - feat.last_access
            recency_factor = max(0.1, 1.0 / (1.0 + time_since_access / 60.0))
            base_reuse = stats["avg_reuse_prob"]
            reuse_prob = min(1.0, base_reuse * (1.0 + feat.access_count * 0.1) * recency_factor)

            # Compute remaining lifetime
            # Factor in token count: larger KV -> potentially longer lifetime
            token_factor = max(0.5, min(2.0, feat.num_tokens / 100.0))
            remaining_lifetime = stats["avg_lifetime"] * token_factor

            # Compute eviction score (inverse of expected value)
            # Higher score = more evictable
            expected_value = reuse_prob * remaining_lifetime
            evict_score = 1.0 / (expected_value + 1.0)

            # Confidence based on sample count
            confidence = min(1.0, 0.5 + stats["sample_count"] * 0.01)

            prediction = LifetimePrediction(
                handle_id=feat.handle_id,
                request_id=feat.request_id,
                reuse_prob=reuse_prob,
                remaining_lifetime=remaining_lifetime,
                evict_score=evict_score,
                confidence=confidence,
                features_summary={
                    "num_tokens": feat.num_tokens,
                    "access_count": feat.access_count,
                    "session_id": session_id,
                    "time_since_access": time_since_access,
                    "sample_count": stats["sample_count"],
                },
                predicted_at=current_time,
            )
            predictions.append(prediction)

        return predictions

    def update(self, features: PredictorFeatures, actual_lifetime: float) -> None:
        """Update predictor with observed actual lifetime.

        Uses exponential moving average to update session and global statistics.

        Args:
            features: Features of the KV handle.
            actual_lifetime: Observed actual lifetime in seconds.
        """
        session_id = features.session_id or "global"
        stats = self.session_stats[session_id]

        # Update session statistics with EMA
        if stats["sample_count"] == 0:
            stats["avg_lifetime"] = actual_lifetime
            stats["avg_reuse_prob"] = 0.8 if actual_lifetime > 0 else 0.2
        else:
            stats["avg_lifetime"] = (
                self.alpha * actual_lifetime + (1 - self.alpha) * stats["avg_lifetime"]
            )
            # Reuse prob estimate: if lifetime is longer than avg, probably reused
            reuse_indicator = 1.0 if actual_lifetime > stats["avg_lifetime"] else 0.0
            stats["avg_reuse_prob"] = (
                self.alpha * reuse_indicator + (1 - self.alpha) * stats["avg_reuse_prob"]
            )

        stats["sample_count"] += 1

        # Update global statistics
        if self.global_sample_count == 0:
            self.global_avg_lifetime = actual_lifetime
            self.global_avg_reuse_prob = 0.8 if actual_lifetime > 0 else 0.2
        else:
            self.global_avg_lifetime = (
                self.alpha * actual_lifetime + (1 - self.alpha) * self.global_avg_lifetime
            )
            reuse_indicator = 1.0 if actual_lifetime > self.global_avg_lifetime else 0.0
            self.global_avg_reuse_prob = (
                self.alpha * reuse_indicator + (1 - self.alpha) * self.global_avg_reuse_prob
            )

        self.global_sample_count += 1

        # Prune old sessions if too many
        if len(self.session_stats) > self.window_size:
            # Remove session with lowest sample count
            min_session = min(
                self.session_stats.keys(), key=lambda k: self.session_stats[k]["sample_count"]
            )
            del self.session_stats[min_session]

    def get_model_version(self) -> str:
        """Get historical predictor version.

        Returns:
            Version string.
        """
        return "historical-v0.1.0"

    def get_statistics(self) -> dict[str, dict[str, float]]:
        """Get current statistics for inspection/debugging.

        Returns:
            Dictionary of session statistics.
        """
        return {
            "global": {
                "avg_lifetime": self.global_avg_lifetime,
                "avg_reuse_prob": self.global_avg_reuse_prob,
                "sample_count": self.global_sample_count,
            },
            **{k: dict(v) for k, v in self.session_stats.items()},
        }
