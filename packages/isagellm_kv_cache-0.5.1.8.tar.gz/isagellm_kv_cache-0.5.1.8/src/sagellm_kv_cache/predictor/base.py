"""Base class for Lifetime Predictor.

Defines the abstract interface for lifetime prediction strategies.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

    from sagellm_protocol.kv import LifetimePrediction

    from sagellm_kv_cache.predictor.features import PredictorFeatures


class LifetimePredictor(ABC):
    """Abstract base class for lifetime prediction strategies.

    A lifetime predictor estimates:
    - reuse_prob: Probability of future reuse (0~1)
    - remaining_lifetime: Expected remaining lifetime in steps/time
    - evict_score: Score for eviction policy (higher = more evictable)

    The predictor consumes features extracted from KVHandle and system context,
    and produces structured predictions that can be consumed by eviction policies
    (Task2.3) and schedulers (Task2.4).

    Example:
        >>> predictor = HistoricalPredictor()
        >>> features = [PredictorFeatures.from_handle(handle) for handle in handles]
        >>> predictions = predictor.predict_batch(features)
        >>> for pred in predictions:
        ...     print(f"Handle {pred.handle_id}: reuse_prob={pred.reuse_prob:.2f}")
    """

    @abstractmethod
    def predict_batch(self, features: Sequence[PredictorFeatures]) -> list[LifetimePrediction]:
        """Predict lifetime for a batch of KV handles.

        Args:
            features: Sequence of feature objects extracted from KVHandles.

        Returns:
            List of LifetimePrediction objects, one per input feature.

        Raises:
            ValueError: If features list is empty or contains invalid data.
            RuntimeError: If prediction fails for any reason.

        Note:
            - Output order matches input order
            - If prediction fails for a specific handle, the implementation
              MUST raise an error (no silent fallback allowed)
        """
        pass

    @abstractmethod
    def update(self, features: PredictorFeatures, actual_lifetime: float) -> None:
        """Update predictor with observed actual lifetime (online learning).

        Args:
            features: Features of the KV handle.
            actual_lifetime: Observed actual lifetime in steps/seconds.

        Note:
            Year 1: This interface is reserved but not required to be functional.
            Implementations may provide a no-op stub.
        """
        pass

    @abstractmethod
    def get_model_version(self) -> str:
        """Get predictor model version string.

        Returns:
            Version string (e.g., "historical-v0.1.0", "statistical-v1.0").
        """
        pass
