"""Unified KV cache manager with prefix-aware reuse.

This module provides a high-level entrypoint to KVPool and PrefixIndex.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Sequence

from sagellm_kv_cache.errors import (
    KVAllPinnedError,
    KVBudgetExceededError,
    KVInvalidHandleError,
    KVNoVictimError,
)
from sagellm_kv_cache.eviction import EvictionManager
from sagellm_kv_cache.models import DType, EvictionPolicy, KVHandle, Layout
from sagellm_kv_cache.observability import MetricsCollector
from sagellm_kv_cache.pool import Block
from sagellm_kv_cache.pool.kv_pool import KVPool
from sagellm_kv_cache.prefix import PrefixIndex


class KVCacheManager:
    """High-level manager for KV allocation and prefix reuse.

    Responsibilities:
    - Own KVPool lifecycle
    - Maintain prefix index and longest-prefix queries
    - Pin prefix-related handles to avoid eviction
    - Emit prefix reuse metrics and structured logs
    """

    def __init__(
        self,
        max_tokens: int,
        block_size: int = 128,
        *,
        bytes_per_token: int = 32,
        eviction_policy: EvictionPolicy = EvictionPolicy.LRU,
        max_evict_handles_per_round: int | None = None,
        metrics_collector: MetricsCollector | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self.kv_pool = KVPool(
            max_tokens=max_tokens,
            block_size=block_size,
            bytes_per_token=bytes_per_token,
        )
        self.prefix_index: PrefixIndex[str] = PrefixIndex()
        self.eviction_manager = EvictionManager(policy=eviction_policy)
        self.max_evict_handles_per_round = max_evict_handles_per_round
        self._metrics_collector = metrics_collector
        self._logger = logger or logging.getLogger(__name__)

        self._prefix_lookup_count = 0
        self._prefix_hit_count = 0
        self._prefix_reuse_tokens = 0

    def alloc(
        self,
        num_tokens: int,
        dtype: DType | str = DType.FP16,
        layout: Layout | str = Layout.CONTIGUOUS,
        device: str = "cpu",
        metadata: dict | None = None,
    ) -> KVHandle:
        """Allocate a KV handle through underlying pool.

        When budget is insufficient, this method automatically attempts eviction
        using configured policy before retrying allocation.
        """
        try:
            return self.kv_pool.alloc(
                num_tokens=num_tokens,
                dtype=dtype,
                layout=layout,
                device=device,
                metadata=metadata,
            )
        except KVBudgetExceededError:
            try:
                self._evict_for_allocation(num_tokens_needed=num_tokens)
            except (KVAllPinnedError, KVNoVictimError) as exc:
                available = self.kv_pool.max_tokens - self.kv_pool.get_allocated_tokens()
                raise KVBudgetExceededError(
                    requested=num_tokens,
                    available=available,
                    context={
                        "max_tokens": self.kv_pool.max_tokens,
                        "eviction_error": exc.code.value,
                    },
                ) from exc
            return self.kv_pool.alloc(
                num_tokens=num_tokens,
                dtype=dtype,
                layout=layout,
                device=device,
                metadata=metadata,
            )

    def free(self, handle: KVHandle) -> None:
        """Free KV handle and invalidate related prefix index entries."""
        if handle.handle_id not in self.kv_pool.handles:
            raise KVInvalidHandleError(handle_id=handle.handle_id)

        self.prefix_index.remove_value(str(handle.handle_id))
        while handle.pin_count > 0:
            self.kv_pool.unpin(handle)
        self.kv_pool.free(handle)

    def register_prefix(self, prefix_tokens: Sequence[int], handle: KVHandle) -> None:
        """Register prefix mapping and pin handle to avoid eviction."""
        if handle.handle_id not in self.kv_pool.handles:
            raise KVInvalidHandleError(handle_id=handle.handle_id)
        if not prefix_tokens:
            raise ValueError("prefix_tokens must not be empty")

        self.prefix_index.insert(tuple(prefix_tokens), str(handle.handle_id))
        self.kv_pool.pin(handle)

    def query_prefix(self, tokens: Sequence[int]) -> tuple[KVHandle | None, int]:
        """Query longest prefix and return reused handle and token length."""
        self._prefix_lookup_count += 1
        if not tokens:
            self._update_prefix_metrics()
            return None, 0

        handle_id_str, matched_len = self.prefix_index.longest_prefix_match(tuple(tokens))
        if handle_id_str is None:
            self._update_prefix_metrics()
            return None, 0

        handle = self._find_handle_by_id(handle_id_str)
        if handle is None:
            self.prefix_index.remove_value(handle_id_str)
            self._update_prefix_metrics()
            return None, 0

        self._prefix_hit_count += 1
        self._prefix_reuse_tokens += matched_len
        handle.touch()
        self._update_prefix_metrics()
        self._logger.info(
            "prefix_match",
            extra={
                "event": "prefix_match",
                "handle_id": handle_id_str,
                "matched_tokens": matched_len,
            },
        )
        return handle, matched_len

    def get_reused_blocks(self, tokens: Sequence[int]) -> tuple[list[Block], int]:
        """Return already allocated blocks for matched prefix."""
        handle, matched_len = self.query_prefix(tokens)
        if handle is None:
            return [], 0
        blocks = getattr(handle, "_blocks", [])
        return blocks, matched_len

    def get_prefix_metrics(self) -> dict[str, float | int]:
        """Return prefix-cache related metrics."""
        hit_rate = (
            self._prefix_hit_count / self._prefix_lookup_count
            if self._prefix_lookup_count > 0
            else 0.0
        )
        return {
            "prefix_hit_rate": hit_rate,
            "prefix_reuse_tokens": self._prefix_reuse_tokens,
            "prefix_hits": self._prefix_hit_count,
            "prefix_lookups": self._prefix_lookup_count,
        }

    def get_stats(self) -> dict:
        """Return combined pool and prefix stats."""
        stats = {
            "pool": self.kv_pool.get_stats(),
            "prefix": {
                "entries": len(self.prefix_index),
                **self.get_prefix_metrics(),
            },
        }
        return stats

    def _find_handle_by_id(self, handle_id_str: str) -> KVHandle | None:
        for handle_id, handle in self.kv_pool.handles.items():
            if str(handle_id) == handle_id_str:
                return handle
        return None

    def _update_prefix_metrics(self) -> None:
        if self._metrics_collector is None:
            return
        metrics = self.get_prefix_metrics()
        self._metrics_collector.set_gauge("prefix_hit_rate", float(metrics["prefix_hit_rate"]))
        self._metrics_collector.set_gauge(
            "prefix_reuse_tokens", float(metrics["prefix_reuse_tokens"])
        )

    def _evict_for_allocation(self, num_tokens_needed: int) -> None:
        """Evict handles to free enough tokens for a new allocation."""
        all_handles = list(self.kv_pool.handles.values())
        started_at = time.perf_counter()

        victims = self.eviction_manager.select_victims(
            all_handles,
            num_tokens_needed,
            max_victims=self.max_evict_handles_per_round,
        )

        evicted_count = 0
        evicted_tokens = 0
        evicted_request_ids: list[str] = []
        for victim in victims:
            request_id = victim.metadata.get("request_id") if victim.metadata else None
            if isinstance(request_id, str):
                evicted_request_ids.append(request_id)
            evicted_tokens += victim.num_tokens
            self.free(victim)
            evicted_count += 1

        evict_ms = (time.perf_counter() - started_at) * 1000.0

        if self._metrics_collector is not None:
            self._metrics_collector.inc("evict_count", evicted_count)
            self._metrics_collector.set_gauge("evict_count", float(evicted_count))
            self._metrics_collector.set_gauge("evict_ms", evict_ms)
            self._metrics_collector.set_gauge("evict_tokens", float(evicted_tokens))

        self._logger.info(
            "kv_evict",
            extra={
                "event": "kv_evict",
                "evict_count": evicted_count,
                "evict_ms": evict_ms,
                "evict_tokens": evicted_tokens,
                "evict_request_ids": evicted_request_ids,
            },
        )
