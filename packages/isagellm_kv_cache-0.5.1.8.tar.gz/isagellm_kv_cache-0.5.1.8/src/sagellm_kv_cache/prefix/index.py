"""Prefix index for prefix-aware KV reuse.

Provides a trie-backed index for longest-prefix lookup.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass
class _TrieNode(Generic[T]):
    children: dict[int, _TrieNode[T]] = field(default_factory=dict)
    value: T | None = None


class PrefixIndex(Generic[T]):
    """Trie-based prefix index.

    Supports insert/update, exact lookup, and longest-prefix matching.
    """

    def __init__(self) -> None:
        self._root: _TrieNode[T] = _TrieNode()
        self._size = 0

    @staticmethod
    def _validate_prefix(prefix_tokens: list[int] | tuple[int, ...]) -> None:
        if not prefix_tokens:
            raise ValueError("prefix_tokens must not be empty")

    def insert(self, prefix_tokens: list[int] | tuple[int, ...], value: T) -> None:
        """Insert or update a prefix entry."""
        self._validate_prefix(prefix_tokens)

        node = self._root
        for token in prefix_tokens:
            node = node.children.setdefault(token, _TrieNode())

        if node.value is None:
            self._size += 1
        node.value = value

    def get(self, prefix_tokens: list[int] | tuple[int, ...]) -> T | None:
        """Get exact prefix match value."""
        self._validate_prefix(prefix_tokens)

        node = self._root
        for token in prefix_tokens:
            if token not in node.children:
                return None
            node = node.children[token]
        return node.value

    def longest_prefix_match(self, tokens: list[int] | tuple[int, ...]) -> tuple[T | None, int]:
        """Return (value, matched_prefix_length) for longest prefix."""
        if not tokens:
            return None, 0

        node = self._root
        best_value: T | None = None
        best_len = 0

        for index, token in enumerate(tokens, start=1):
            if token not in node.children:
                break
            node = node.children[token]
            if node.value is not None:
                best_value = node.value
                best_len = index

        return best_value, best_len

    def remove(self, prefix_tokens: list[int] | tuple[int, ...]) -> bool:
        """Remove exact prefix entry.

        Returns True if an entry was removed.
        """
        self._validate_prefix(prefix_tokens)

        def _remove(node: _TrieNode[T], depth: int) -> tuple[bool, bool]:
            if depth == len(prefix_tokens):
                if node.value is None:
                    return False, False
                node.value = None
                self._size -= 1
                should_prune = len(node.children) == 0
                return True, should_prune

            token = prefix_tokens[depth]
            child = node.children.get(token)
            if child is None:
                return False, False

            removed, child_prune = _remove(child, depth + 1)
            if child_prune:
                del node.children[token]

            should_prune = len(node.children) == 0 and node.value is None
            return removed, should_prune

        removed, _ = _remove(self._root, 0)
        return removed

    def remove_value(self, value: T) -> int:
        """Remove all entries whose terminal value equals `value`.

        Returns:
            Number of removed entries.
        """
        removed_count = 0

        def _walk(node: _TrieNode[T]) -> bool:
            nonlocal removed_count
            keys_to_delete: list[int] = []

            for token, child in node.children.items():
                if _walk(child):
                    keys_to_delete.append(token)

            for token in keys_to_delete:
                del node.children[token]

            if node.value == value:
                node.value = None
                self._size -= 1
                removed_count += 1

            return len(node.children) == 0 and node.value is None

        _walk(self._root)
        return removed_count

    def __len__(self) -> int:
        return self._size
