"""Prefix fingerprint strategies for grouping and similarity detection.

Implements multiple fingerprint strategies for prefix-based request grouping.
Supports segmented hashing, weighted combination, and adaptive thresholds.
"""

from __future__ import annotations

import hashlib
from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum
from typing import Any


class FingerprintStrategy(str, Enum):
    """Fingerprint computation strategies."""

    SIMPLE_HASH = "simple_hash"  # Single hash of full prefix
    SEGMENTED_HASH = "segmented_hash"  # Hash of prefix segments
    WEIGHTED_HASH = "weighted_hash"  # Weighted combination of segments
    ADAPTIVE_HASH = "adaptive_hash"  # Adaptive based on prefix length


@dataclass
class FingerprintConfig:
    """Configuration for fingerprint computation.

    Attributes:
        strategy: Fingerprint strategy to use.
        segment_size: Size of each segment for segmented strategies (default: 16).
        max_segments: Maximum number of segments to hash (default: 8).
        weight_decay: Decay factor for weighted strategy (default: 0.9).
        adaptive_threshold: Length threshold for adaptive strategy (default: 32).
    """

    strategy: FingerprintStrategy = FingerprintStrategy.SIMPLE_HASH
    segment_size: int = 16
    max_segments: int = 8
    weight_decay: float = 0.9
    adaptive_threshold: int = 32

    def __post_init__(self) -> None:
        """Validate configuration."""
        if self.segment_size <= 0:
            raise ValueError(f"segment_size must be positive, got {self.segment_size}")
        if self.max_segments <= 0:
            raise ValueError(f"max_segments must be positive, got {self.max_segments}")
        if not 0 < self.weight_decay <= 1:
            raise ValueError(f"weight_decay must be in (0, 1], got {self.weight_decay}")
        if self.adaptive_threshold <= 0:
            raise ValueError(f"adaptive_threshold must be positive, got {self.adaptive_threshold}")


class BaseFingerprintComputer(ABC):
    """Base class for fingerprint computation."""

    def __init__(self, config: FingerprintConfig) -> None:
        """Initialize fingerprint computer.

        Args:
            config: Fingerprint configuration.
        """
        self.config = config

    @abstractmethod
    def compute(self, tokens: Sequence[int]) -> bytes:
        """Compute fingerprint for token sequence.

        Args:
            tokens: Token sequence.

        Returns:
            Fingerprint hash as bytes.
        """
        pass

    @staticmethod
    def _hash_tokens(tokens: Sequence[int]) -> bytes:
        """Hash a token sequence using SHA256.

        Args:
            tokens: Token sequence.

        Returns:
            Hash as bytes.
        """
        hasher = hashlib.sha256()
        for token in tokens:
            hasher.update(token.to_bytes(4, byteorder="big", signed=False))
        return hasher.digest()

    def get_stats(self) -> dict[str, Any]:
        """Get computation statistics.

        Returns:
            Statistics dictionary.
        """
        return {
            "strategy": self.config.strategy.value,
            "segment_size": self.config.segment_size,
            "max_segments": self.config.max_segments,
        }


class SimpleHashComputer(BaseFingerprintComputer):
    """Simple hash of full prefix.

    Computes a single hash of the entire token sequence.
    Fast but may not capture prefix similarity well.
    """

    def compute(self, tokens: Sequence[int]) -> bytes:
        """Compute simple hash of full prefix.

        Args:
            tokens: Token sequence.

        Returns:
            Hash of full sequence.
        """
        return self._hash_tokens(tokens)


class SegmentedHashComputer(BaseFingerprintComputer):
    """Segmented hash strategy.

    Divides prefix into segments and combines segment hashes.
    Better captures prefix structure and similarity.
    """

    def compute(self, tokens: Sequence[int]) -> bytes:
        """Compute segmented hash.

        Divides tokens into segments, hashes each segment,
        and combines them into a final fingerprint.

        Args:
            tokens: Token sequence.

        Returns:
            Combined hash of segments.
        """
        if len(tokens) == 0:
            return b""

        segment_size = self.config.segment_size
        max_segments = self.config.max_segments

        # Compute segment hashes
        segment_hashes = []
        num_segments = min((len(tokens) + segment_size - 1) // segment_size, max_segments)

        for i in range(num_segments):
            start = i * segment_size
            end = min(start + segment_size, len(tokens))
            segment = tokens[start:end]
            segment_hash = self._hash_tokens(segment)
            segment_hashes.append(segment_hash)

        # Combine segment hashes
        combined_hasher = hashlib.sha256()
        for seg_hash in segment_hashes:
            combined_hasher.update(seg_hash)

        return combined_hasher.digest()


class WeightedHashComputer(BaseFingerprintComputer):
    """Weighted hash strategy.

    Applies exponential decay weights to segments,
    giving more importance to earlier tokens.
    """

    def compute(self, tokens: Sequence[int]) -> bytes:
        """Compute weighted hash.

        Segments are weighted with exponential decay,
        prioritizing earlier prefix tokens.

        Args:
            tokens: Token sequence.

        Returns:
            Weighted combination hash.
        """
        if len(tokens) == 0:
            return b""

        segment_size = self.config.segment_size
        max_segments = self.config.max_segments
        decay = self.config.weight_decay

        # Compute weighted segment hashes
        weighted_hashes = []
        num_segments = min((len(tokens) + segment_size - 1) // segment_size, max_segments)

        for i in range(num_segments):
            start = i * segment_size
            end = min(start + segment_size, len(tokens))
            segment = tokens[start:end]

            # Apply weight: w_i = decay^i
            weight = decay**i
            segment_hash = self._hash_tokens(segment)

            # Weight is encoded as prefix to hash
            weight_bytes = int(weight * 1000).to_bytes(4, byteorder="big")
            weighted_hashes.append((weight_bytes, segment_hash))

        # Combine weighted hashes
        combined_hasher = hashlib.sha256()
        for weight_bytes, seg_hash in weighted_hashes:
            combined_hasher.update(weight_bytes)
            combined_hasher.update(seg_hash)

        return combined_hasher.digest()


class AdaptiveHashComputer(BaseFingerprintComputer):
    """Adaptive hash strategy.

    Chooses strategy based on prefix length:
    - Short prefixes: simple hash
    - Long prefixes: segmented hash
    """

    def __init__(self, config: FingerprintConfig) -> None:
        """Initialize adaptive computer.

        Args:
            config: Fingerprint configuration.
        """
        super().__init__(config)
        self._simple_computer = SimpleHashComputer(config)
        self._segmented_computer = SegmentedHashComputer(config)

    def compute(self, tokens: Sequence[int]) -> bytes:
        """Compute adaptive hash based on prefix length.

        Args:
            tokens: Token sequence.

        Returns:
            Hash computed by appropriate strategy.
        """
        if len(tokens) < self.config.adaptive_threshold:
            return self._simple_computer.compute(tokens)
        else:
            return self._segmented_computer.compute(tokens)


class FingerprintComputer:
    """Factory and interface for fingerprint computation.

    Example:
        >>> config = FingerprintConfig(strategy=FingerprintStrategy.SEGMENTED_HASH)
        >>> computer = FingerprintComputer(config)
        >>> tokens = list(range(100))
        >>> fingerprint = computer.compute(tokens)
        >>> assert isinstance(fingerprint, bytes)
    """

    def __init__(self, config: FingerprintConfig | None = None) -> None:
        """Initialize fingerprint computer.

        Args:
            config: Fingerprint configuration (default: simple hash).
        """
        if config is None:
            config = FingerprintConfig()

        self.config = config
        self._computer = self._create_computer(config)

    @staticmethod
    def _create_computer(config: FingerprintConfig) -> BaseFingerprintComputer:
        """Create appropriate computer based on strategy.

        Args:
            config: Fingerprint configuration.

        Returns:
            Fingerprint computer instance.

        Raises:
            ValueError: If strategy is not supported.
        """
        if config.strategy == FingerprintStrategy.SIMPLE_HASH:
            return SimpleHashComputer(config)
        elif config.strategy == FingerprintStrategy.SEGMENTED_HASH:
            return SegmentedHashComputer(config)
        elif config.strategy == FingerprintStrategy.WEIGHTED_HASH:
            return WeightedHashComputer(config)
        elif config.strategy == FingerprintStrategy.ADAPTIVE_HASH:
            return AdaptiveHashComputer(config)
        else:
            raise ValueError(f"Unsupported fingerprint strategy: {config.strategy}")

    def compute(self, tokens: Sequence[int]) -> bytes:
        """Compute fingerprint for token sequence.

        Args:
            tokens: Token sequence.

        Returns:
            Fingerprint hash as bytes.

        Example:
            >>> computer = FingerprintComputer()
            >>> tokens = [1, 2, 3, 4]
            >>> fp1 = computer.compute(tokens)
            >>> fp2 = computer.compute(tokens)
            >>> assert fp1 == fp2  # Deterministic
        """
        return self._computer.compute(tokens)

    def get_stats(self) -> dict[str, Any]:
        """Get computation statistics.

        Returns:
            Statistics dictionary.
        """
        return self._computer.get_stats()

    def __repr__(self) -> str:
        """String representation."""
        return f"FingerprintComputer(strategy={self.config.strategy.value})"
