"""Prefix grouping and batch aggregation strategies.

Implements request grouping based on prefix similarity and
batch construction with configurable aggregation policies.
"""

from __future__ import annotations

import time
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from .fingerprint import FingerprintComputer, FingerprintConfig


@dataclass
class GroupingConfig:
    """Configuration for prefix grouping.

    Attributes:
        enable_grouping: Enable prefix grouping (default: True).
        aggregation_window_ms: Time window for request aggregation (default: 10 ms).
        max_queue_delay_ms: Maximum allowed queueing delay (default: 50 ms).
        auto_disable_on_timeout: Auto-disable grouping if delay exceeds threshold.
        fingerprint_config: Configuration for fingerprint computation.
    """

    enable_grouping: bool = True
    aggregation_window_ms: float = 10.0
    max_queue_delay_ms: float = 50.0
    auto_disable_on_timeout: bool = True
    fingerprint_config: FingerprintConfig = field(default_factory=FingerprintConfig)

    def __post_init__(self) -> None:
        """Validate configuration."""
        if self.aggregation_window_ms < 0:
            raise ValueError(
                f"aggregation_window_ms must be non-negative, got {self.aggregation_window_ms}"
            )
        if self.max_queue_delay_ms < 0:
            raise ValueError(
                f"max_queue_delay_ms must be non-negative, got {self.max_queue_delay_ms}"
            )


@dataclass
class Request:
    """Request representation for grouping.

    Attributes:
        request_id: Unique request identifier.
        tokens: Token sequence (prefix).
        fingerprint: Computed fingerprint (set by grouper).
        enqueue_time: Time when request was enqueued.
        metadata: Optional metadata dictionary.
    """

    request_id: str
    tokens: Sequence[int]
    fingerprint: bytes | None = None
    enqueue_time: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RequestGroup:
    """Group of requests with similar prefixes.

    Attributes:
        fingerprint: Shared fingerprint for group.
        requests: List of requests in group.
        created_at: Group creation timestamp.
    """

    fingerprint: bytes
    requests: list[Request] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def add_request(self, request: Request) -> None:
        """Add request to group.

        Args:
            request: Request to add.
        """
        self.requests.append(request)

    def get_queue_delay(self, current_time: float | None = None) -> float:
        """Get maximum queueing delay in group.

        Args:
            current_time: Current timestamp (default: now).

        Returns:
            Maximum delay in milliseconds.
        """
        if not self.requests:
            return 0.0

        if current_time is None:
            current_time = time.time()

        max_delay = max(current_time - req.enqueue_time for req in self.requests)
        return max_delay * 1000  # Convert to ms

    def size(self) -> int:
        """Get number of requests in group."""
        return len(self.requests)


class PrefixGrouper:
    """Prefix-based request grouping manager.

    Groups requests by prefix fingerprint for batch construction.
    Supports configurable aggregation windows and timeout handling.

    Example:
        >>> config = GroupingConfig(enable_grouping=True)
        >>> grouper = PrefixGrouper(config)
        >>> req = Request(request_id="req1", tokens=[1, 2, 3])
        >>> grouper.add_request(req)
        >>> groups = grouper.get_ready_groups()
    """

    def __init__(self, config: GroupingConfig | None = None) -> None:
        """Initialize prefix grouper.

        Args:
            config: Grouping configuration (default: default config).
        """
        if config is None:
            config = GroupingConfig()

        self.config = config
        self._fingerprint_computer = FingerprintComputer(config.fingerprint_config)

        # Active groups by fingerprint
        self._groups: dict[bytes, RequestGroup] = {}

        # Statistics
        self._total_requests = 0
        self._total_groups = 0
        self._total_timeouts = 0
        self._processed_groups = 0
        self._total_processed_group_size = 0
        self._total_extra_queue_delay_ms = 0.0
        self._grouping_active = config.enable_grouping

    def add_request(self, request: Request) -> None:
        """Add request to grouper.

        Computes fingerprint and adds to appropriate group.

        Args:
            request: Request to add.

        Raises:
            ValueError: If grouping is disabled.
        """
        if not self._grouping_active:
            raise ValueError("Grouping is disabled")

        # Compute fingerprint
        request.fingerprint = self._fingerprint_computer.compute(request.tokens)
        self._total_requests += 1

        # Find or create group
        if request.fingerprint not in self._groups:
            self._groups[request.fingerprint] = RequestGroup(fingerprint=request.fingerprint)
            self._total_groups += 1

        # Add to group
        self._groups[request.fingerprint].add_request(request)

    def get_ready_groups(
        self, current_time: float | None = None, force_all: bool = False
    ) -> list[RequestGroup]:
        """Get groups ready for batch construction.

        A group is ready if:
        1. Aggregation window has elapsed, OR
        2. Max queue delay exceeded (timeout)

        Args:
            current_time: Current timestamp (default: now).
            force_all: Force return all groups regardless of timing.

        Returns:
            List of ready groups (removed from active groups).
        """
        if current_time is None:
            current_time = time.time()

        ready_groups = []
        fingerprints_to_remove = []

        for fingerprint, group in self._groups.items():
            if force_all:
                queue_delay = group.get_queue_delay(current_time)
                extra_delay = max(0.0, queue_delay - self.config.aggregation_window_ms)
                self._total_extra_queue_delay_ms += extra_delay
                self._processed_groups += 1
                self._total_processed_group_size += group.size()
                ready_groups.append(group)
                fingerprints_to_remove.append(fingerprint)
                continue

            # Check if aggregation window elapsed
            window_elapsed = (current_time - group.created_at) * 1000  # ms
            queue_delay = group.get_queue_delay(current_time)

            if window_elapsed >= self.config.aggregation_window_ms:
                extra_delay = max(0.0, queue_delay - self.config.aggregation_window_ms)
                self._total_extra_queue_delay_ms += extra_delay
                self._processed_groups += 1
                self._total_processed_group_size += group.size()
                ready_groups.append(group)
                fingerprints_to_remove.append(fingerprint)

                # Check for timeout
                if queue_delay > self.config.max_queue_delay_ms:
                    self._total_timeouts += 1
                    # Auto-disable if configured
                    if self.config.auto_disable_on_timeout:
                        self._grouping_active = False

        # Remove ready groups
        for fingerprint in fingerprints_to_remove:
            del self._groups[fingerprint]

        return ready_groups

    def clear(self) -> None:
        """Clear all active groups."""
        self._groups.clear()

    def enable_grouping(self) -> None:
        """Enable grouping (re-enable after auto-disable)."""
        self._grouping_active = True

    def disable_grouping(self) -> None:
        """Disable grouping."""
        self._grouping_active = False

    def is_enabled(self) -> bool:
        """Check if grouping is currently enabled."""
        return self._grouping_active

    def get_stats(self) -> dict[str, Any]:
        """Get grouping statistics.

        Returns:
            Statistics dictionary with:
            - total_requests: Total requests processed
            - total_groups: Total groups created
            - active_groups: Current active groups
            - total_timeouts: Total timeout events
            - grouping_active: Whether grouping is enabled
            - prefix_group_size: Average size of processed groups
            - prefix_group_hit_rate: Group reuse rate
            - extra_queue_delay_ms: Average extra queue delay vs aggregation window
        """
        active_groups = len(self._groups)
        prefix_group_size = (
            self._total_processed_group_size / self._processed_groups
            if self._processed_groups > 0
            else (self._total_requests / self._total_groups if self._total_groups > 0 else 0.0)
        )
        extra_queue_delay_ms = (
            self._total_extra_queue_delay_ms / self._processed_groups
            if self._processed_groups > 0
            else 0.0
        )

        # Prefix group hit rate: percentage of requests that joined existing groups
        # (total_requests - total_groups) / total_requests
        hit_rate = (
            (self._total_requests - self._total_groups) / self._total_requests
            if self._total_requests > 0
            else 0.0
        )

        return {
            "total_requests": self._total_requests,
            "total_groups": self._total_groups,
            "active_groups": active_groups,
            "total_timeouts": self._total_timeouts,
            "grouping_active": self._grouping_active,
            "prefix_group_size": prefix_group_size,
            "prefix_group_hit_rate": hit_rate,
            "extra_queue_delay_ms": extra_queue_delay_ms,
            "aggregation_window_ms": self.config.aggregation_window_ms,
            "max_queue_delay_ms": self.config.max_queue_delay_ms,
        }

    def __len__(self) -> int:
        """Return number of active groups."""
        return len(self._groups)

    def __repr__(self) -> str:
        """String representation."""
        stats = self.get_stats()
        return (
            f"PrefixGrouper(active={self._grouping_active}, "
            f"groups={stats['active_groups']}, "
            f"requests={stats['total_requests']}, "
            f"hit_rate={stats['prefix_group_hit_rate']:.2%})"
        )


class CIPrefixGrouper(PrefixGrouper):
    """CI-friendly implementation for testing without full computation.

    Provides same interface but with minimal overhead for CI/testing.
    """

    def __init__(self, config: GroupingConfig | None = None) -> None:
        """Initialize CI grouper.

        Args:
            config: Grouping configuration (default: default config).
        """
        if config is None:
            config = GroupingConfig()

        # Initialize without full fingerprint computation
        self.config = config
        self._groups: dict[bytes, RequestGroup] = {}
        self._total_requests = 0
        self._total_groups = 0
        self._total_timeouts = 0
        self._processed_groups = 0
        self._total_processed_group_size = 0
        self._total_extra_queue_delay_ms = 0.0
        self._grouping_active = config.enable_grouping

    def add_request(self, request: Request) -> None:
        """Add request with lightweight fingerprint.

        Uses simple hash of first few tokens as fingerprint.

        Args:
            request: Request to add.
        """
        if not self._grouping_active:
            raise ValueError("Grouping is disabled")

        # Lightweight fingerprint: hash of first 4 tokens
        lite_tokens = request.tokens[:4]
        request.fingerprint = hash(tuple(lite_tokens)).to_bytes(8, byteorder="big", signed=True)
        self._total_requests += 1

        # Find or create group
        if request.fingerprint not in self._groups:
            self._groups[request.fingerprint] = RequestGroup(fingerprint=request.fingerprint)
            self._total_groups += 1

        # Add to group
        self._groups[request.fingerprint].add_request(request)
