"""Metrics collection for KV Cache operations.

This module provides a unified metrics collection interface for tracking
KV Cache performance, resource usage, and operational statistics.
"""

from __future__ import annotations

import json
import time
from typing import Any


class MetricsCollector:
    """Unified metrics collector for KV Cache operations.

    Collects timing marks, counters, and gauges for observability.
    Follows Protocol v0.1 requirements for structured metrics output.

    Attributes:
        trace_id: Unique trace identifier for distributed tracing.
        request_id: Request identifier for tracking individual requests.
        engine_id: Engine instance identifier.
        marks: Timestamp marks for key events (e.g., "queued", "executed").
        counters: Incrementable counters (e.g., "hit_count", "evict_count").
        gauges: Current value gauges (e.g., "allocated_tokens").

    Example:
        >>> import uuid
        >>> mc = MetricsCollector(
        ...     trace_id=str(uuid.uuid4()),
        ...     request_id="req-123",
        ...     engine_id="engine-0"
        ... )
        >>> mc.mark("queued")
        >>> mc.mark("executed")
        >>> mc.inc("hit_count", 5)
        >>> mc.set_gauge("allocated_tokens", 1024)
        >>> print(mc.to_json())
    """

    def __init__(self, trace_id: str, request_id: str, engine_id: str) -> None:
        """Initialize metrics collector.

        Args:
            trace_id: Unique trace identifier (UUID recommended).
            request_id: Request identifier.
            engine_id: Engine instance identifier.
        """
        self.trace_id = trace_id
        self.request_id = request_id
        self.engine_id = engine_id
        self.marks: dict[str, float] = {}
        self.counters: dict[str, int] = {}
        self.gauges: dict[str, float] = {}

    def mark(self, event: str) -> None:
        """Mark a timestamp for a specific event.

        Args:
            event: Event name (e.g., "queued", "scheduled", "executed").

        Example:
            >>> mc.mark("queued")
            >>> mc.mark("scheduled")
        """
        self.marks[event] = time.time()

    def inc(self, counter: str, value: int = 1) -> None:
        """Increment a counter.

        Args:
            counter: Counter name (e.g., "hit_count", "evict_count").
            value: Increment value (default: 1).

        Example:
            >>> mc.inc("hit_count", 5)
            >>> mc.inc("miss_count")
        """
        self.counters[counter] = self.counters.get(counter, 0) + value

    def set_gauge(self, gauge: str, value: float) -> None:
        """Set a gauge value.

        Args:
            gauge: Gauge name (e.g., "allocated_tokens", "hit_rate").
            value: Gauge value.

        Example:
            >>> mc.set_gauge("hit_rate", 0.85)
            >>> mc.set_gauge("allocated_tokens", 1024)
        """
        self.gauges[gauge] = value

    def get_counter(self, counter: str) -> int:
        """Get current counter value.

        Args:
            counter: Counter name.

        Returns:
            Current counter value (0 if not set).
        """
        return self.counters.get(counter, 0)

    def get_gauge(self, gauge: str) -> float:
        """Get current gauge value.

        Args:
            gauge: Gauge name.

        Returns:
            Current gauge value (0.0 if not set).
        """
        return self.gauges.get(gauge, 0.0)

    def to_dict(self) -> dict[str, Any]:
        """Export metrics as a dictionary.

        Returns:
            Dictionary containing all metrics in Protocol v0.1 format.

        Format:
            {
                "trace_id": "uuid",
                "request_id": "req-123",
                "engine_id": "engine-0",
                "timestamps": {
                    "queued_at": 1234567890.123,
                    "scheduled_at": 1234567890.234,
                    ...
                },
                "kv_metrics": {
                    "hit_rate": 0.85,
                    "hit_len": 512,
                    ...
                },
                "counters": {...},
                "gauges": {...}
            }
        """
        # Convert marks to timestamps with "_at" suffix
        timestamps = {}
        for event, timestamp in self.marks.items():
            if not event.endswith("_at"):
                timestamps[f"{event}_at"] = timestamp
            else:
                timestamps[event] = timestamp

        # Extract KV-specific metrics from gauges
        kv_metrics = {}
        for key in [
            "hit_rate",
            "hit_len",
            "reuse_bytes",
            "prefix_hit_rate",
            "prefix_reuse_tokens",
            "evict_count",
            "evict_bytes",
            "transfer_bw",
            "transfer_latency",
        ]:
            if key in self.gauges:
                kv_metrics[key] = self.gauges[key]

        # Also include counters that should be in kv_metrics
        for key in ["evict_count", "hit_count", "miss_count"]:
            if key in self.counters:
                kv_metrics[key] = self.counters[key]

        return {
            "trace_id": self.trace_id,
            "request_id": self.request_id,
            "engine_id": self.engine_id,
            "timestamps": timestamps,
            "kv_metrics": kv_metrics,
            "counters": self.counters,
            "gauges": self.gauges,
        }

    def to_json(self, indent: int = 2) -> str:
        """Export metrics as JSON string.

        Args:
            indent: JSON indentation level (default: 2).

        Returns:
            JSON-formatted metrics string.

        Example:
            >>> print(mc.to_json())
            {
              "trace_id": "...",
              "request_id": "req-123",
              ...
            }
        """
        return json.dumps(self.to_dict(), indent=indent)

    def reset(self) -> None:
        """Reset all metrics.

        Clears all marks, counters, and gauges.
        Useful for reusing the same collector instance.
        """
        self.marks.clear()
        self.counters.clear()
        self.gauges.clear()

    def __repr__(self) -> str:
        """String representation of MetricsCollector."""
        return (
            f"MetricsCollector(trace_id={self.trace_id!r}, "
            f"request_id={self.request_id!r}, engine_id={self.engine_id!r}, "
            f"marks={len(self.marks)}, counters={len(self.counters)}, "
            f"gauges={len(self.gauges)})"
        )
