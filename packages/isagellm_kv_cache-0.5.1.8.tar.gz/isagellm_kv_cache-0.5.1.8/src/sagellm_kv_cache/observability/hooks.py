"""Hooks for integrating metrics collection into KV Cache operations.

This module provides hook interfaces and base implementations for
injecting metrics collection into key operations.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, Protocol

from .metrics import MetricsCollector


class MetricsHookProtocol(Protocol):
    """Protocol for metrics hooks.

    Hooks can be registered at key points in KV Cache operations
    to collect metrics automatically.
    """

    def on_alloc(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Called when a KV block is allocated.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Additional context (e.g., num_tokens, dtype).
        """
        ...

    def on_free(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Called when a KV block is freed.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Additional context (e.g., handle_id).
        """
        ...

    def on_hit(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Called when prefix cache hits.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Additional context (e.g., hit_len, reuse_bytes).
        """
        ...

    def on_miss(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Called when prefix cache misses.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Additional context.
        """
        ...

    def on_evict(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Called when eviction occurs.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Additional context (e.g., evict_count, evict_bytes).
        """
        ...

    def on_transfer(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Called when KV transfer completes.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Additional context (e.g., transfer_bytes, latency).
        """
        ...


class MetricsHook:
    """Base implementation of metrics hook.

    Provides default implementations for common metric collection patterns.

    Example:
        >>> hook = MetricsHook()
        >>> collector = MetricsCollector("trace-1", "req-1", "engine-0")
        >>> hook.on_alloc(collector, num_tokens=128)
        >>> hook.on_hit(collector, hit_len=512, reuse_bytes=2048)
    """

    def on_alloc(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Record allocation event.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Must include 'num_tokens'.
        """
        collector.mark("alloc")
        if "num_tokens" in kwargs:
            collector.inc("alloc_count")
            collector.inc("total_allocated_tokens", kwargs["num_tokens"])

    def on_free(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Record free event.

        Args:
            collector: MetricsCollector instance.
            **kwargs: May include 'num_tokens'.
        """
        collector.mark("free")
        collector.inc("free_count")
        if "num_tokens" in kwargs:
            collector.inc("total_freed_tokens", kwargs["num_tokens"])

    def on_hit(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Record prefix cache hit.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Should include 'hit_len' and 'reuse_bytes'.
        """
        collector.mark("cache_hit")
        collector.inc("hit_count")

        if "hit_len" in kwargs:
            collector.set_gauge("hit_len", kwargs["hit_len"])

        if "reuse_bytes" in kwargs:
            collector.inc("total_reuse_bytes", kwargs["reuse_bytes"])
            collector.set_gauge("reuse_bytes", kwargs["reuse_bytes"])

    def on_miss(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Record prefix cache miss.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Additional context.
        """
        collector.mark("cache_miss")
        collector.inc("miss_count")

    def on_evict(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Record eviction event.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Should include 'evict_count' and 'evict_bytes'.
        """
        collector.mark("eviction")

        if "evict_count" in kwargs:
            collector.inc("evict_count", kwargs["evict_count"])
            collector.set_gauge("evict_count", kwargs["evict_count"])

        if "evict_bytes" in kwargs:
            collector.inc("total_evict_bytes", kwargs["evict_bytes"])
            collector.set_gauge("evict_bytes", kwargs["evict_bytes"])

    def on_transfer(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Record transfer event.

        Args:
            collector: MetricsCollector instance.
            **kwargs: Should include 'transfer_bytes' and 'latency_ms'.
        """
        collector.mark("transfer_complete")
        collector.inc("transfer_count")

        if "transfer_bytes" in kwargs:
            collector.inc("total_transfer_bytes", kwargs["transfer_bytes"])

        if "latency_ms" in kwargs:
            collector.set_gauge("transfer_latency", kwargs["latency_ms"])

        # Calculate bandwidth if both bytes and latency are provided
        if "transfer_bytes" in kwargs and "latency_ms" in kwargs:
            if kwargs["latency_ms"] > 0:
                # Convert to MB/s
                bw_mbps = (kwargs["transfer_bytes"] / 1024 / 1024) / (kwargs["latency_ms"] / 1000)
                collector.set_gauge("transfer_bw", bw_mbps)


class CompositeHook:
    """Composite hook that delegates to multiple hooks.

    Useful for combining multiple monitoring/logging hooks.

    Example:
        >>> hook1 = MetricsHook()
        >>> hook2 = CustomLoggingHook()
        >>> composite = CompositeHook([hook1, hook2])
        >>> composite.on_hit(collector, hit_len=512)
    """

    def __init__(self, hooks: list[MetricsHookProtocol]) -> None:
        """Initialize composite hook.

        Args:
            hooks: List of hooks to delegate to.
        """
        self.hooks = hooks

    def on_alloc(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Delegate to all hooks."""
        for hook in self.hooks:
            hook.on_alloc(collector, **kwargs)

    def on_free(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Delegate to all hooks."""
        for hook in self.hooks:
            hook.on_free(collector, **kwargs)

    def on_hit(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Delegate to all hooks."""
        for hook in self.hooks:
            hook.on_hit(collector, **kwargs)

    def on_miss(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Delegate to all hooks."""
        for hook in self.hooks:
            hook.on_miss(collector, **kwargs)

    def on_evict(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Delegate to all hooks."""
        for hook in self.hooks:
            hook.on_evict(collector, **kwargs)

    def on_transfer(self, collector: MetricsCollector, **kwargs: Any) -> None:
        """Delegate to all hooks."""
        for hook in self.hooks:
            hook.on_transfer(collector, **kwargs)


def create_callback_hook(
    on_alloc: Callable[[MetricsCollector, Any], None] | None = None,
    on_free: Callable[[MetricsCollector, Any], None] | None = None,
    on_hit: Callable[[MetricsCollector, Any], None] | None = None,
    on_miss: Callable[[MetricsCollector, Any], None] | None = None,
    on_evict: Callable[[MetricsCollector, Any], None] | None = None,
    on_transfer: Callable[[MetricsCollector, Any], None] | None = None,
) -> MetricsHook:
    """Create a hook from callback functions.

    Useful for quick custom hooks without subclassing.

    Args:
        on_alloc: Callback for allocation events.
        on_free: Callback for free events.
        on_hit: Callback for cache hit events.
        on_miss: Callback for cache miss events.
        on_evict: Callback for eviction events.
        on_transfer: Callback for transfer events.

    Returns:
        MetricsHook with custom callbacks.

    Example:
        >>> def my_alloc_callback(collector, **kwargs):
        ...     print(f"Allocated {kwargs.get('num_tokens')} tokens")
        >>> hook = create_callback_hook(on_alloc=my_alloc_callback)
    """

    class CallbackHook(MetricsHook):
        def on_alloc(self, collector: MetricsCollector, **kwargs: Any) -> None:
            super().on_alloc(collector, **kwargs)
            if on_alloc:
                on_alloc(collector, **kwargs)

        def on_free(self, collector: MetricsCollector, **kwargs: Any) -> None:
            super().on_free(collector, **kwargs)
            if on_free:
                on_free(collector, **kwargs)

        def on_hit(self, collector: MetricsCollector, **kwargs: Any) -> None:
            super().on_hit(collector, **kwargs)
            if on_hit:
                on_hit(collector, **kwargs)

        def on_miss(self, collector: MetricsCollector, **kwargs: Any) -> None:
            super().on_miss(collector, **kwargs)
            if on_miss:
                on_miss(collector, **kwargs)

        def on_evict(self, collector: MetricsCollector, **kwargs: Any) -> None:
            super().on_evict(collector, **kwargs)
            if on_evict:
                on_evict(collector, **kwargs)

        def on_transfer(self, collector: MetricsCollector, **kwargs: Any) -> None:
            super().on_transfer(collector, **kwargs)
            if on_transfer:
                on_transfer(collector, **kwargs)

    return CallbackHook()
