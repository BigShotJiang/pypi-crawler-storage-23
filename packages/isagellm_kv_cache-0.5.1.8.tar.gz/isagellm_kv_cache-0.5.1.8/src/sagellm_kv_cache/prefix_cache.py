"""Prefix Cache for KV Cache blocks.

Implements block-hash based prefix caching following vLLM design.
Reference: sagellm/reference/vllm/vllm/v1/core/kv_cache_coordinator.py
"""

from __future__ import annotations

import hashlib
import time
from collections import OrderedDict
from collections.abc import Sequence
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from uuid import UUID


# Type aliases
BlockHash = bytes  # Hash of a single block


class PrefixCache:
    """Prefix Cache using block-level hashing.

    Implements efficient prefix lookup by computing and storing hashes
    at block granularity rather than full token sequences.

    Key features:
    - Block-based indexing for efficiency
    - LRU eviction tracking
    - Hit/miss statistics

    Example:
        >>> cache = PrefixCache(block_size=16)
        >>> tokens = list(range(100))
        >>> block_hashes = cache.compute_block_hashes(tokens)
        >>> blocks = [{"block_id": i} for i in range(len(block_hashes))]
        >>> cache.insert(block_hashes, blocks)
        >>> hit_blocks, num_tokens = cache.lookup(block_hashes[:3])
        >>> assert len(hit_blocks) == 3
    """

    def __init__(
        self,
        block_size: int = 16,
        max_cached_blocks: int | None = None,
        enable_lru: bool = True,
    ) -> None:
        """Initialize prefix cache.

        Args:
            block_size: Number of tokens per block (must match KV Pool).
            max_cached_blocks: Maximum blocks to cache (None = unlimited).
            enable_lru: Enable LRU eviction policy.

        Raises:
            ValueError: If block_size <= 0.
        """
        if block_size <= 0:
            raise ValueError(f"block_size must be positive, got {block_size}")

        self.block_size = block_size
        self.max_cached_blocks = max_cached_blocks
        self.enable_lru = enable_lru

        # Cache storage: block_hash -> list of block objects
        # Multiple blocks can have same hash (different requests)
        self._cache: dict[BlockHash, list[dict]] = {}

        # LRU tracking: block_hash -> last_access_time
        # Using OrderedDict to maintain insertion/access order
        self._lru_tracker: OrderedDict[BlockHash, float] = OrderedDict()

        # Statistics
        self._hit_count = 0
        self._miss_count = 0
        self._insert_count = 0
        self._evict_count = 0

    def compute_block_hash(self, tokens: Sequence[int], block_size: int | None = None) -> BlockHash:
        """Compute hash for a single block of tokens.

        Uses SHA256 for deterministic hashing across processes.

        Args:
            tokens: Token sequence (should be exactly block_size length).
            block_size: Override block size (defaults to self.block_size).

        Returns:
            Block hash as bytes.

        Raises:
            ValueError: If tokens length doesn't match block_size.

        Example:
            >>> cache = PrefixCache(block_size=16)
            >>> tokens = list(range(16))
            >>> hash1 = cache.compute_block_hash(tokens)
            >>> hash2 = cache.compute_block_hash(tokens)
            >>> assert hash1 == hash2  # Deterministic
        """
        if block_size is None:
            block_size = self.block_size

        if len(tokens) != block_size:
            raise ValueError(f"Token count {len(tokens)} doesn't match block_size {block_size}")

        # Use SHA256 for reproducibility
        hasher = hashlib.sha256()
        # Convert tokens to bytes
        for token in tokens:
            hasher.update(token.to_bytes(4, byteorder="big", signed=False))

        return hasher.digest()

    def compute_block_hashes(
        self, tokens: Sequence[int], block_size: int | None = None
    ) -> list[BlockHash]:
        """Compute block hashes for a token sequence.

        Splits tokens into blocks and computes hash for each complete block.
        Incomplete final block is ignored.

        Args:
            tokens: Full token sequence.
            block_size: Override block size (defaults to self.block_size).

        Returns:
            List of block hashes.

        Example:
            >>> cache = PrefixCache(block_size=16)
            >>> tokens = list(range(50))
            >>> hashes = cache.compute_block_hashes(tokens)
            >>> assert len(hashes) == 3  # 50 // 16 = 3 complete blocks
        """
        if block_size is None:
            block_size = self.block_size

        num_complete_blocks = len(tokens) // block_size
        block_hashes = []

        for i in range(num_complete_blocks):
            start = i * block_size
            end = start + block_size
            block_tokens = tokens[start:end]
            block_hash = self.compute_block_hash(block_tokens, block_size)
            block_hashes.append(block_hash)

        return block_hashes

    def lookup(self, block_hashes: Sequence[BlockHash]) -> tuple[list[dict], int]:
        """Find longest prefix match in cache.

        Args:
            block_hashes: Sequence of block hashes to lookup.

        Returns:
            Tuple of (matched_blocks, num_computed_tokens):
            - matched_blocks: List of cached block objects
            - num_computed_tokens: Total tokens in matched blocks

        Example:
            >>> cache = PrefixCache(block_size=16)
            >>> tokens = list(range(48))
            >>> hashes = cache.compute_block_hashes(tokens)
            >>> blocks = [{"block_id": i, "tokens": 16} for i in range(3)]
            >>> cache.insert(hashes, blocks)
            >>> hit_blocks, num_tokens = cache.lookup(hashes)
            >>> assert len(hit_blocks) == 3
            >>> assert num_tokens == 48
        """
        matched_blocks = []
        num_matched = 0

        # Find longest prefix
        for block_hash in block_hashes:
            if block_hash in self._cache:
                # Get first block with this hash (could be multiple)
                cached_blocks = self._cache[block_hash]
                if cached_blocks:
                    matched_blocks.append(cached_blocks[0])
                    num_matched += 1

                    # Update LRU tracker on access
                    if self.enable_lru:
                        self._update_lru_on_access(block_hash)
                else:
                    break
            else:
                break

        # Update statistics
        if num_matched > 0:
            self._hit_count += 1
        else:
            self._miss_count += 1

        num_computed_tokens = num_matched * self.block_size
        return matched_blocks, num_computed_tokens

    def insert(self, block_hashes: Sequence[BlockHash], blocks: Sequence[dict]) -> None:
        """Insert blocks into cache.

        Args:
            block_hashes: Block hashes (one per block).
            blocks: Block objects to cache.

        Raises:
            ValueError: If lengths don't match.

        Example:
            >>> cache = PrefixCache(block_size=16)
            >>> hashes = [b"hash1", b"hash2"]
            >>> blocks = [{"block_id": 0}, {"block_id": 1}]
            >>> cache.insert(hashes, blocks)
        """
        if len(block_hashes) != len(blocks):
            raise ValueError(
                f"block_hashes length {len(block_hashes)} != blocks length {len(blocks)}"
            )

        for block_hash, block in zip(block_hashes, blocks):
            # Check capacity and evict if necessary
            if self.max_cached_blocks is not None and self.enable_lru:
                current_total_blocks = sum(len(b) for b in self._cache.values())
                if current_total_blocks >= self.max_cached_blocks:
                    self._evict_lru_blocks(1)  # Evict one block to make room

            if block_hash not in self._cache:
                self._cache[block_hash] = []
            self._cache[block_hash].append(block)
            self._insert_count += 1

            # Update LRU tracker
            if self.enable_lru:
                self._lru_tracker[block_hash] = time.time()
                # Move to end (most recent)
                self._lru_tracker.move_to_end(block_hash)

    def _update_lru_on_access(self, block_hash: BlockHash) -> None:
        """Update LRU tracker when a block is accessed.

        Args:
            block_hash: Hash of the accessed block.
        """
        if block_hash in self._lru_tracker:
            self._lru_tracker[block_hash] = time.time()
            # Move to end (most recently used)
            self._lru_tracker.move_to_end(block_hash)

    def _evict_lru_blocks(self, num_blocks_to_evict: int = 1) -> int:
        """Evict least recently used blocks.

        Args:
            num_blocks_to_evict: Number of blocks to evict.

        Returns:
            Number of blocks actually evicted.

        Example:
            >>> cache = PrefixCache(block_size=16, max_cached_blocks=2)
            >>> hashes = [b"hash1", b"hash2", b"hash3"]
            >>> blocks = [{"block_id": i} for i in range(3)]
            >>> cache.insert(hashes[:2], blocks[:2])
            >>> cache.insert(hashes[2:], blocks[2:])  # Should evict hash1
        """
        evicted = 0

        while evicted < num_blocks_to_evict and self._lru_tracker:
            # Get least recently used block_hash (first item in OrderedDict)
            lru_hash, _ = self._lru_tracker.popitem(last=False)

            if lru_hash in self._cache:
                blocks_removed = len(self._cache[lru_hash])
                del self._cache[lru_hash]
                self._evict_count += blocks_removed
                evicted += blocks_removed

        return evicted

    def evict_by_count(self, num_blocks: int) -> int:
        """Evict specified number of blocks using LRU policy.

        Public API for manual eviction.

        Args:
            num_blocks: Number of blocks to evict.

        Returns:
            Number of blocks actually evicted.

        Example:
            >>> cache = PrefixCache(block_size=16)
            >>> hashes = [b"hash1", b"hash2"]
            >>> blocks = [{"block_id": i} for i in range(2)]
            >>> cache.insert(hashes, blocks)
            >>> evicted = cache.evict_by_count(1)
            >>> assert evicted >= 1
        """
        if not self.enable_lru:
            raise RuntimeError("LRU eviction not enabled")

        return self._evict_lru_blocks(num_blocks)

    def invalidate(self, handle_id: UUID) -> int:
        """Invalidate all cache entries associated with a handle.

        Args:
            handle_id: Handle ID to invalidate.

        Returns:
            Number of blocks removed.

        Example:
            >>> from uuid import uuid4
            >>> cache = PrefixCache(block_size=16)
            >>> handle_id = uuid4()
            >>> hashes = [b"hash1"]
            >>> blocks = [{"block_id": 0, "handle_id": handle_id}]
            >>> cache.insert(hashes, blocks)
            >>> removed = cache.invalidate(handle_id)
            >>> assert removed == 1
        """
        removed_count = 0

        # Scan all cached blocks
        for block_hash in list(self._cache.keys()):
            blocks = self._cache[block_hash]
            # Filter out blocks with matching handle_id
            new_blocks = [b for b in blocks if b.get("handle_id") != handle_id]
            removed_count += len(blocks) - len(new_blocks)

            if new_blocks:
                self._cache[block_hash] = new_blocks
            else:
                # Remove hash entry if no blocks left
                del self._cache[block_hash]
                # Also remove from LRU tracker
                if self.enable_lru and block_hash in self._lru_tracker:
                    del self._lru_tracker[block_hash]

        self._evict_count += removed_count
        return removed_count

    def clear(self) -> None:
        """Clear all cache entries.

        Example:
            >>> cache = PrefixCache(block_size=16)
            >>> cache.insert([b"hash"], [{"block_id": 0}])
            >>> cache.clear()
            >>> assert len(cache._cache) == 0
        """
        self._cache.clear()
        if self.enable_lru:
            self._lru_tracker.clear()

    def get_stats(self) -> dict:
        """Get cache statistics.

        Returns:
            Dictionary with:
            - num_entries: Total cache entries
            - num_blocks: Total cached blocks
            - hit_count: Cache hits
            - miss_count: Cache misses
            - hit_rate: Hit rate (0-1)
            - insert_count: Total insertions
            - evict_count: Total evictions
            - max_cached_blocks: Maximum block capacity
            - enable_lru: Whether LRU is enabled

        Example:
            >>> cache = PrefixCache(block_size=16)
            >>> stats = cache.get_stats()
            >>> assert stats['hit_rate'] == 0.0
        """
        total_blocks = sum(len(blocks) for blocks in self._cache.values())
        total_requests = self._hit_count + self._miss_count
        hit_rate = self._hit_count / total_requests if total_requests > 0 else 0.0

        return {
            "num_entries": len(self._cache),
            "num_blocks": total_blocks,
            "hit_count": self._hit_count,
            "miss_count": self._miss_count,
            "hit_rate": hit_rate,
            "insert_count": self._insert_count,
            "evict_count": self._evict_count,
            "block_size": self.block_size,
            "max_cached_blocks": self.max_cached_blocks,
            "enable_lru": self.enable_lru,
        }

    def __len__(self) -> int:
        """Return number of unique block hashes in cache."""
        return len(self._cache)

    def __repr__(self) -> str:
        """String representation."""
        stats = self.get_stats()
        lru_info = f", lru={self.enable_lru}" if self.enable_lru else ""
        max_info = f", max={self.max_cached_blocks}" if self.max_cached_blocks else ""
        return (
            f"PrefixCache(block_size={self.block_size}{max_info}{lru_info}, "
            f"entries={stats['num_entries']}, "
            f"blocks={stats['num_blocks']}, "
            f"hit_rate={stats['hit_rate']:.2%})"
        )
