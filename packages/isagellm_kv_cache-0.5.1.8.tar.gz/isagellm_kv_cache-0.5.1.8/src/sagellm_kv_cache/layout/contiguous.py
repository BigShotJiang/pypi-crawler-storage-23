"""Contiguous memory layout for KV blocks.

Allocates a single large contiguous memory block for all tokens,
providing fast sequential access and minimal allocation overhead.
"""

from __future__ import annotations

from typing import Any

try:
    import torch
except ImportError:
    torch = None  # type: ignore

from .base import BaseKVBlock


class ContiguousKVBlock(BaseKVBlock):
    """Contiguous memory layout KV block.

    Allocates a single large tensor for all K/V data, enabling:
    - Fast allocation (single memory request)
    - Fast sequential access (cache-friendly)
    - Minimal memory overhead

    Memory layout: [2, num_tokens, hidden_dim]
    - kv_data[0, :, :] = all K vectors
    - kv_data[1, :, :] = all V vectors

    Example:
        >>> block = ContiguousKVBlock(num_tokens=256, hidden_dim=4096, dtype=torch.float16)
        >>> kv = block.get_kv(0)  # Get K/V for first token
        >>> block.set_kv(0, torch.randn(2, 4096, dtype=torch.float16))
        >>> print(block.get_memory_usage())  # Memory in bytes
    """

    def __init__(
        self,
        num_tokens: int,
        hidden_dim: int,
        dtype: Any | None = None,
    ) -> None:
        """Initialize contiguous KV block.

        Args:
            num_tokens: Number of tokens in the block.
            hidden_dim: Hidden dimension size.
            dtype: Data type (default: torch.float16 if torch available).

        Raises:
            ValueError: If num_tokens or hidden_dim <= 0.
            RuntimeError: If torch is not available.
        """
        if torch is None:
            raise RuntimeError("torch is required for ContiguousKVBlock")

        if dtype is None:
            dtype = torch.float16

        super().__init__(num_tokens, hidden_dim, dtype)

        # Single large memory allocation
        self.kv_data = torch.zeros(
            (2, num_tokens, hidden_dim),
            dtype=dtype,
        )

    def get_kv(self, token_idx: int) -> Any:
        """Get K and V tensors for a specific token.

        Args:
            token_idx: Token index (0-based).

        Returns:
            Tensor of shape [2, hidden_dim] containing K and V.

        Raises:
            IndexError: If token_idx is out of range.

        Example:
            >>> block = ContiguousKVBlock(256, 4096)
            >>> kv = block.get_kv(0)
            >>> assert kv.shape == (2, 4096)
        """
        if token_idx < 0 or token_idx >= self.num_tokens:
            raise IndexError(f"token_idx {token_idx} out of range [0, {self.num_tokens})")
        return self.kv_data[:, token_idx, :]

    def set_kv(self, token_idx: int, kv_data: Any) -> None:
        """Set K and V tensors for a specific token.

        Args:
            token_idx: Token index (0-based).
            kv_data: KV data tensor of shape [2, hidden_dim].

        Raises:
            IndexError: If token_idx is out of range.
            ValueError: If kv_data shape is incorrect.
        """
        if token_idx < 0 or token_idx >= self.num_tokens:
            raise IndexError(f"token_idx {token_idx} out of range [0, {self.num_tokens})")
        if kv_data.shape != (2, self.hidden_dim):
            raise ValueError(f"Expected kv_data shape (2, {self.hidden_dim}), got {kv_data.shape}")
        self.kv_data[:, token_idx, :] = kv_data

    def get_memory_usage(self) -> int:
        """Get total memory usage in bytes.

        Returns:
            Total memory used by the KV data tensor.

        Example:
            >>> block = ContiguousKVBlock(256, 4096, dtype=torch.float16)
            >>> memory = block.get_memory_usage()
            >>> expected = 2 * 256 * 4096 * 2  # 2 (K/V) * tokens * dim * 2 bytes (fp16)
            >>> assert memory == expected
        """
        return self.kv_data.element_size() * self.kv_data.numel()

    def get_num_allocations(self) -> int:
        """Get number of memory allocations.

        Returns:
            Always returns 1 (single contiguous allocation).
        """
        return 1
