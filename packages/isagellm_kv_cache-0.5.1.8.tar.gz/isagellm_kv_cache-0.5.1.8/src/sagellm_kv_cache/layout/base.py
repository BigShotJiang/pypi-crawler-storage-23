"""Abstract base class for KV Block layouts.

Defines the interface that all KV block layout implementations must follow.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseKVBlock(ABC):
    """Abstract base class for KV block memory layouts.

    All KV block implementations must inherit from this class and implement
    the required methods for memory allocation, access, and statistics.

    Attributes:
        num_tokens: Number of tokens in the block.
        hidden_dim: Hidden dimension size.
        dtype: Data type (e.g., torch.float16).
    """

    def __init__(self, num_tokens: int, hidden_dim: int, dtype: Any) -> None:
        """Initialize KV block.

        Args:
            num_tokens: Number of tokens in the block.
            hidden_dim: Hidden dimension size.
            dtype: Data type for the block.

        Raises:
            ValueError: If num_tokens or hidden_dim <= 0.
        """
        if num_tokens <= 0:
            raise ValueError(f"num_tokens must be positive, got {num_tokens}")
        if hidden_dim <= 0:
            raise ValueError(f"hidden_dim must be positive, got {hidden_dim}")

        self.num_tokens = num_tokens
        self.hidden_dim = hidden_dim
        self.dtype = dtype

    @abstractmethod
    def get_kv(self, token_idx: int) -> Any:
        """Get K and V tensors for a specific token.

        Args:
            token_idx: Token index (0-based).

        Returns:
            Tuple of (K, V) tensors for the token.

        Raises:
            IndexError: If token_idx is out of range.
        """
        pass

    @abstractmethod
    def set_kv(self, token_idx: int, kv_data: Any) -> None:
        """Set K and V tensors for a specific token.

        Args:
            token_idx: Token index (0-based).
            kv_data: KV data to set (shape: [2, hidden_dim]).

        Raises:
            IndexError: If token_idx is out of range.
        """
        pass

    @abstractmethod
    def get_memory_usage(self) -> int:
        """Get total memory usage in bytes.

        Returns:
            Total memory used by this block in bytes.
        """
        pass

    @abstractmethod
    def get_num_allocations(self) -> int:
        """Get number of memory allocations.

        Returns:
            Number of separate memory allocations made.
        """
        pass

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"{self.__class__.__name__}(num_tokens={self.num_tokens}, "
            f"hidden_dim={self.hidden_dim}, dtype={self.dtype})"
        )
