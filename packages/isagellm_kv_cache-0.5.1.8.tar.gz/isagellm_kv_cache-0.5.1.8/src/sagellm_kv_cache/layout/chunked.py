"""Chunked memory layout for KV blocks.

Allocates multiple smaller memory chunks instead of one large block,
providing flexibility at the cost of indirect access overhead.
"""

from __future__ import annotations

from typing import Any

try:
    import torch
except ImportError:
    torch = None  # type: ignore

from .base import BaseKVBlock


class ChunkedKVBlock(BaseKVBlock):
    """Chunked memory layout KV block.

    Allocates multiple small tensors (chunks) instead of one large block:
    - Flexible allocation (can handle memory fragmentation)
    - Indirect access (requires chunk index calculation)
    - Multiple allocation overhead

    Memory layout: List of [2, chunk_size, hidden_dim] tensors

    Example:
        >>> block = ChunkedKVBlock(
        ...     num_tokens=256,
        ...     hidden_dim=4096,
        ...     chunk_size=64,
        ...     dtype=torch.float16
        ... )
        >>> kv = block.get_kv(0)  # Get K/V for first token
        >>> print(block.get_num_allocations())  # 4 chunks (256 / 64)
    """

    def __init__(
        self,
        num_tokens: int,
        hidden_dim: int,
        dtype: Any | None = None,
        chunk_size: int = 64,
    ) -> None:
        """Initialize chunked KV block.

        Args:
            num_tokens: Number of tokens in the block.
            hidden_dim: Hidden dimension size.
            dtype: Data type (default: torch.float16 if torch available).
            chunk_size: Number of tokens per chunk (default: 64).

        Raises:
            ValueError: If num_tokens, hidden_dim, or chunk_size <= 0.
            RuntimeError: If torch is not available.
        """
        if torch is None:
            raise RuntimeError("torch is required for ChunkedKVBlock")

        if dtype is None:
            dtype = torch.float16

        if chunk_size <= 0:
            raise ValueError(f"chunk_size must be positive, got {chunk_size}")

        super().__init__(num_tokens, hidden_dim, dtype)

        self.chunk_size = chunk_size

        # Allocate multiple small chunks
        self.chunks: list[Any] = []
        num_chunks = (num_tokens + chunk_size - 1) // chunk_size

        for i in range(num_chunks):
            # Last chunk may be smaller
            current_chunk_size = min(chunk_size, num_tokens - i * chunk_size)
            chunk = torch.zeros(
                (2, current_chunk_size, hidden_dim),
                dtype=dtype,
            )
            self.chunks.append(chunk)

    def _get_chunk_and_offset(self, token_idx: int) -> tuple[int, int]:
        """Calculate chunk index and offset for a token.

        Args:
            token_idx: Token index (0-based).

        Returns:
            Tuple of (chunk_idx, local_offset).
        """
        chunk_idx = token_idx // self.chunk_size
        local_offset = token_idx % self.chunk_size
        return chunk_idx, local_offset

    def get_kv(self, token_idx: int) -> Any:
        """Get K and V tensors for a specific token.

        Args:
            token_idx: Token index (0-based).

        Returns:
            Tensor of shape [2, hidden_dim] containing K and V.

        Raises:
            IndexError: If token_idx is out of range.

        Example:
            >>> block = ChunkedKVBlock(256, 4096, chunk_size=64)
            >>> kv = block.get_kv(100)  # Token in 2nd chunk
            >>> assert kv.shape == (2, 4096)
        """
        if token_idx < 0 or token_idx >= self.num_tokens:
            raise IndexError(f"token_idx {token_idx} out of range [0, {self.num_tokens})")

        chunk_idx, local_offset = self._get_chunk_and_offset(token_idx)
        return self.chunks[chunk_idx][:, local_offset, :]

    def set_kv(self, token_idx: int, kv_data: Any) -> None:
        """Set K and V tensors for a specific token.

        Args:
            token_idx: Token index (0-based).
            kv_data: KV data tensor of shape [2, hidden_dim].

        Raises:
            IndexError: If token_idx is out of range.
            ValueError: If kv_data shape is incorrect.
        """
        if token_idx < 0 or token_idx >= self.num_tokens:
            raise IndexError(f"token_idx {token_idx} out of range [0, {self.num_tokens})")
        if kv_data.shape != (2, self.hidden_dim):
            raise ValueError(f"Expected kv_data shape (2, {self.hidden_dim}), got {kv_data.shape}")

        chunk_idx, local_offset = self._get_chunk_and_offset(token_idx)
        self.chunks[chunk_idx][:, local_offset, :] = kv_data

    def get_memory_usage(self) -> int:
        """Get total memory usage in bytes.

        Returns:
            Total memory used by all chunks.

        Example:
            >>> block = ChunkedKVBlock(256, 4096, chunk_size=64, dtype=torch.float16)
            >>> memory = block.get_memory_usage()
            >>> expected = 2 * 256 * 4096 * 2  # Same as contiguous
            >>> assert memory == expected
        """
        total_bytes = 0
        for chunk in self.chunks:
            total_bytes += chunk.element_size() * chunk.numel()
        return total_bytes

    def get_num_allocations(self) -> int:
        """Get number of memory allocations.

        Returns:
            Number of chunks (separate allocations).

        Example:
            >>> block = ChunkedKVBlock(256, 4096, chunk_size=64)
            >>> assert block.get_num_allocations() == 4  # 256 / 64
        """
        return len(self.chunks)
