"""Load Metrics for Scheduler Placement & Load Balancing (Task2.7).

This module provides per-device load metrics collection:
- Active request count
- KV cache occupancy
- Queue length/wait time
"""

from __future__ import annotations

import time
from typing import Any

from pydantic import BaseModel, Field


class DeviceLoadMetrics(BaseModel):
    """Per-device load metrics.

    Captures the current load state of a device for placement decisions.

    Example:
        >>> metrics = DeviceLoadMetrics.create("cuda:0")
        >>> metrics.active_requests = 5
        >>> metrics.kv_tokens_used = 1024
        >>> assert metrics.is_overloaded() == False
    """

    device: str = Field(description="Device identifier (e.g., 'cuda:0', 'cpu')")

    # Request metrics
    active_requests: int = Field(default=0, ge=0, description="Number of active requests")
    queue_length: int = Field(default=0, ge=0, description="Number of queued requests")

    # KV cache metrics
    kv_tokens_used: int = Field(default=0, ge=0, description="Current KV tokens used")
    kv_tokens_capacity: int = Field(default=0, ge=0, description="Total KV token capacity")

    # Memory metrics
    memory_used_mb: float = Field(default=0.0, ge=0, description="Memory used (MB)")
    memory_capacity_mb: float = Field(default=0.0, ge=0, description="Total memory capacity (MB)")

    # Wait time metrics
    avg_wait_time_ms: float = Field(default=0.0, ge=0, description="Average wait time (ms)")
    max_wait_time_ms: float = Field(default=0.0, ge=0, description="Max wait time (ms)")

    # Timestamp
    updated_at: float = Field(default=0.0, ge=0, description="Last update timestamp")

    model_config = {"use_enum_values": False}

    @classmethod
    def create(
        cls,
        device: str,
        kv_tokens_capacity: int = 0,
        memory_capacity_mb: float = 0.0,
    ) -> DeviceLoadMetrics:
        """Create new device load metrics.

        Args:
            device: Device identifier.
            kv_tokens_capacity: Total KV token capacity.
            memory_capacity_mb: Total memory capacity in MB.

        Returns:
            New DeviceLoadMetrics instance.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0", kv_tokens_capacity=4096)
            >>> assert metrics.kv_tokens_capacity == 4096
        """
        return cls(
            device=device,
            kv_tokens_capacity=kv_tokens_capacity,
            memory_capacity_mb=memory_capacity_mb,
            updated_at=time.time(),
        )

    def update_kv_usage(self, kv_tokens_used: int) -> None:
        """Update KV token usage.

        Args:
            kv_tokens_used: Current KV tokens used.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0", kv_tokens_capacity=4096)
            >>> metrics.update_kv_usage(1024)
            >>> assert metrics.kv_utilization() == 0.25
        """
        self.kv_tokens_used = kv_tokens_used
        self.updated_at = time.time()

    def update_request_count(self, active: int, queued: int) -> None:
        """Update request counts.

        Args:
            active: Number of active requests.
            queued: Number of queued requests.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0")
            >>> metrics.update_request_count(5, 2)
            >>> assert metrics.total_requests() == 7
        """
        self.active_requests = active
        self.queue_length = queued
        self.updated_at = time.time()

    def update_memory_usage(self, memory_used_mb: float) -> None:
        """Update memory usage.

        Args:
            memory_used_mb: Current memory used in MB.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0", memory_capacity_mb=8192)
            >>> metrics.update_memory_usage(4096)
            >>> assert metrics.memory_utilization() == 0.5
        """
        self.memory_used_mb = memory_used_mb
        self.updated_at = time.time()

    def update_wait_time(self, avg_ms: float, max_ms: float) -> None:
        """Update wait time metrics.

        Args:
            avg_ms: Average wait time in milliseconds.
            max_ms: Maximum wait time in milliseconds.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0")
            >>> metrics.update_wait_time(10.5, 25.0)
            >>> assert metrics.avg_wait_time_ms == 10.5
        """
        self.avg_wait_time_ms = avg_ms
        self.max_wait_time_ms = max_ms
        self.updated_at = time.time()

    def kv_utilization(self) -> float:
        """Calculate KV cache utilization ratio.

        Returns:
            Utilization ratio [0.0, 1.0], or 0.0 if capacity is 0.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0", kv_tokens_capacity=4096)
            >>> metrics.update_kv_usage(1024)
            >>> assert metrics.kv_utilization() == 0.25
        """
        if self.kv_tokens_capacity == 0:
            return 0.0
        return min(1.0, self.kv_tokens_used / self.kv_tokens_capacity)

    def memory_utilization(self) -> float:
        """Calculate memory utilization ratio.

        Returns:
            Utilization ratio [0.0, 1.0], or 0.0 if capacity is 0.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0", memory_capacity_mb=8192)
            >>> metrics.update_memory_usage(4096)
            >>> assert metrics.memory_utilization() == 0.5
        """
        if self.memory_capacity_mb == 0.0:
            return 0.0
        return min(1.0, self.memory_used_mb / self.memory_capacity_mb)

    def total_requests(self) -> int:
        """Total requests (active + queued).

        Returns:
            Sum of active and queued requests.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0")
            >>> metrics.update_request_count(5, 2)
            >>> assert metrics.total_requests() == 7
        """
        return self.active_requests + self.queue_length

    def is_overloaded(
        self,
        kv_threshold: float = 0.9,
        memory_threshold: float = 0.9,
    ) -> bool:
        """Check if device is overloaded.

        A device is overloaded if KV utilization or memory utilization
        exceeds the threshold.

        Args:
            kv_threshold: KV utilization threshold (default 0.9).
            memory_threshold: Memory utilization threshold (default 0.9).

        Returns:
            True if overloaded, False otherwise.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0", kv_tokens_capacity=1000)
            >>> metrics.update_kv_usage(950)
            >>> assert metrics.is_overloaded(kv_threshold=0.9) == True
        """
        return (
            self.kv_utilization() >= kv_threshold or self.memory_utilization() >= memory_threshold
        )

    def available_kv_tokens(self) -> int:
        """Calculate available KV tokens.

        Returns:
            Number of available KV tokens.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0", kv_tokens_capacity=4096)
            >>> metrics.update_kv_usage(1024)
            >>> assert metrics.available_kv_tokens() == 3072
        """
        return max(0, self.kv_tokens_capacity - self.kv_tokens_used)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.

        Returns:
            Dictionary representation.

        Example:
            >>> metrics = DeviceLoadMetrics.create("cuda:0")
            >>> data = metrics.to_dict()
            >>> assert "device" in data
        """
        return self.model_dump()  # type: ignore[no-any-return]

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"DeviceLoadMetrics(device={self.device}, "
            f"active={self.active_requests}, "
            f"queued={self.queue_length}, "
            f"kv_util={self.kv_utilization():.2f})"
        )


class LoadMetricsCollector:
    """Collector for multi-device load metrics.

    Maintains per-device load metrics for placement decisions.

    Example:
        >>> collector = LoadMetricsCollector()
        >>> collector.register_device("cuda:0", kv_tokens_capacity=4096)
        >>> collector.update_kv_usage("cuda:0", 1024)
        >>> metrics = collector.get_metrics("cuda:0")
        >>> assert metrics.kv_tokens_used == 1024
    """

    def __init__(self) -> None:
        """Initialize load metrics collector."""
        self._metrics: dict[str, DeviceLoadMetrics] = {}

    def register_device(
        self,
        device: str,
        kv_tokens_capacity: int = 0,
        memory_capacity_mb: float = 0.0,
    ) -> None:
        """Register a device for load tracking.

        Args:
            device: Device identifier.
            kv_tokens_capacity: Total KV token capacity.
            memory_capacity_mb: Total memory capacity in MB.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0", kv_tokens_capacity=4096)
            >>> assert "cuda:0" in collector.list_devices()
        """
        self._metrics[device] = DeviceLoadMetrics.create(
            device=device,
            kv_tokens_capacity=kv_tokens_capacity,
            memory_capacity_mb=memory_capacity_mb,
        )

    def unregister_device(self, device: str) -> None:
        """Unregister a device.

        Args:
            device: Device identifier.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> collector.unregister_device("cuda:0")
            >>> assert "cuda:0" not in collector.list_devices()
        """
        if device in self._metrics:
            del self._metrics[device]

    def get_metrics(self, device: str) -> DeviceLoadMetrics:
        """Get metrics for a device.

        Args:
            device: Device identifier.

        Returns:
            DeviceLoadMetrics for the device.

        Raises:
            KeyError: If device is not registered.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> metrics = collector.get_metrics("cuda:0")
            >>> assert metrics.device == "cuda:0"
        """
        if device not in self._metrics:
            raise KeyError(f"Device {device} not registered")
        return self._metrics[device]

    def update_kv_usage(self, device: str, kv_tokens_used: int) -> None:
        """Update KV token usage for a device.

        Args:
            device: Device identifier.
            kv_tokens_used: Current KV tokens used.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0", kv_tokens_capacity=4096)
            >>> collector.update_kv_usage("cuda:0", 1024)
            >>> assert collector.get_metrics("cuda:0").kv_tokens_used == 1024
        """
        self.get_metrics(device).update_kv_usage(kv_tokens_used)

    def update_request_count(self, device: str, active: int, queued: int) -> None:
        """Update request counts for a device.

        Args:
            device: Device identifier.
            active: Number of active requests.
            queued: Number of queued requests.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> collector.update_request_count("cuda:0", 5, 2)
            >>> assert collector.get_metrics("cuda:0").total_requests() == 7
        """
        self.get_metrics(device).update_request_count(active, queued)

    def update_memory_usage(self, device: str, memory_used_mb: float) -> None:
        """Update memory usage for a device.

        Args:
            device: Device identifier.
            memory_used_mb: Current memory used in MB.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0", memory_capacity_mb=8192)
            >>> collector.update_memory_usage("cuda:0", 4096)
            >>> assert collector.get_metrics("cuda:0").memory_used_mb == 4096
        """
        self.get_metrics(device).update_memory_usage(memory_used_mb)

    def update_wait_time(self, device: str, avg_ms: float, max_ms: float) -> None:
        """Update wait time metrics for a device.

        Args:
            device: Device identifier.
            avg_ms: Average wait time in milliseconds.
            max_ms: Maximum wait time in milliseconds.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> collector.update_wait_time("cuda:0", 10.5, 25.0)
            >>> assert collector.get_metrics("cuda:0").avg_wait_time_ms == 10.5
        """
        self.get_metrics(device).update_wait_time(avg_ms, max_ms)

    def list_devices(self) -> list[str]:
        """List all registered devices.

        Returns:
            List of device identifiers.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> collector.register_device("cuda:1")
            >>> assert len(collector.list_devices()) == 2
        """
        return list(self._metrics.keys())

    def get_all_metrics(self) -> dict[str, DeviceLoadMetrics]:
        """Get metrics for all devices.

        Returns:
            Dictionary mapping device to metrics.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> all_metrics = collector.get_all_metrics()
            >>> assert "cuda:0" in all_metrics
        """
        return self._metrics.copy()

    def reset(self) -> None:
        """Reset all metrics.

        Example:
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> collector.reset()
            >>> assert len(collector.list_devices()) == 0
        """
        self._metrics.clear()

    def __repr__(self) -> str:
        """String representation."""
        return f"LoadMetricsCollector(devices={len(self._metrics)})"
