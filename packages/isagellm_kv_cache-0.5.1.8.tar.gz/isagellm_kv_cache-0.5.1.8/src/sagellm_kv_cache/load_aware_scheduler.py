"""Load-Aware Scheduler for Device Placement (Task2.7).

This module provides load-aware device placement strategies:
- Select device with lowest KV occupancy
- Select device with shortest queue
- Select device with most available resources
"""

from __future__ import annotations

import enum
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sagellm_kv_cache.load_metrics import LoadMetricsCollector
    from sagellm_kv_cache.models import SchedulerRequest

logger = logging.getLogger(__name__)


class PlacementStrategy(enum.Enum):
    """Device placement strategy.

    - ROUND_ROBIN: Simple round-robin placement (baseline, no load awareness)
    - LOWEST_KV: Select device with lowest KV cache occupancy
    - SHORTEST_QUEUE: Select device with shortest queue
    - BEST_FIT: Select device with most suitable available resources
    """

    ROUND_ROBIN = "round_robin"
    LOWEST_KV = "lowest_kv"
    SHORTEST_QUEUE = "shortest_queue"
    BEST_FIT = "best_fit"


class LoadAwareScheduler:
    """Load-aware device placement scheduler.

    Implements various placement strategies for distributing requests
    across devices based on load metrics.

    Example:
        >>> from sagellm_kv_cache.load_metrics import LoadMetricsCollector
        >>> collector = LoadMetricsCollector()
        >>> collector.register_device("cuda:0", kv_tokens_capacity=4096)
        >>> collector.register_device("cuda:1", kv_tokens_capacity=4096)
        >>> scheduler = LoadAwareScheduler(
        ...     collector=collector,
        ...     strategy=PlacementStrategy.LOWEST_KV
        ... )
        >>> device = scheduler.select_device(["cuda:0", "cuda:1"], kv_tokens_required=100)
        >>> assert device in ["cuda:0", "cuda:1"]
    """

    def __init__(
        self,
        collector: LoadMetricsCollector,
        strategy: PlacementStrategy = PlacementStrategy.LOWEST_KV,
        enable_load_awareness: bool = True,
    ) -> None:
        """Initialize load-aware scheduler.

        Args:
            collector: Load metrics collector.
            strategy: Placement strategy to use.
            enable_load_awareness: Enable load-aware placement (if False, uses round-robin).

        Example:
            >>> from sagellm_kv_cache.load_metrics import LoadMetricsCollector
            >>> collector = LoadMetricsCollector()
            >>> scheduler = LoadAwareScheduler(collector)
            >>> assert scheduler.is_enabled()
        """
        self.collector = collector
        self.strategy = strategy
        self.enable_load_awareness = enable_load_awareness

        # Round-robin state
        self._round_robin_index = 0

        # Stats
        self._placement_count = 0
        self._placement_decisions: dict[str, int] = {}

    def is_enabled(self) -> bool:
        """Check if load-awareness is enabled.

        Returns:
            True if enabled, False otherwise.

        Example:
            >>> from sagellm_kv_cache.load_metrics import LoadMetricsCollector
            >>> scheduler = LoadAwareScheduler(LoadMetricsCollector(), enable_load_awareness=True)
            >>> assert scheduler.is_enabled()
        """
        return self.enable_load_awareness

    def select_device(
        self,
        candidate_devices: list[str],
        kv_tokens_required: int = 0,
        request_id: str | None = None,
    ) -> str:
        """Select a device for request placement.

        Args:
            candidate_devices: List of candidate device identifiers.
            kv_tokens_required: Required KV tokens for the request.
            request_id: Optional request ID for logging.

        Returns:
            Selected device identifier.

        Raises:
            ValueError: If no candidate devices provided.
            RuntimeError: If no suitable device found.

        Example:
            >>> from sagellm_kv_cache.load_metrics import LoadMetricsCollector
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0", kv_tokens_capacity=4096)
            >>> scheduler = LoadAwareScheduler(collector)
            >>> device = scheduler.select_device(["cuda:0"], kv_tokens_required=100)
            >>> assert device == "cuda:0"
        """
        if not candidate_devices:
            raise ValueError("No candidate devices provided")

        # If load-awareness is disabled, use round-robin
        if not self.enable_load_awareness:
            return self._select_round_robin(candidate_devices)

        # Use selected strategy
        if self.strategy == PlacementStrategy.ROUND_ROBIN:
            selected_device = self._select_round_robin(candidate_devices)
        elif self.strategy == PlacementStrategy.LOWEST_KV:
            selected_device = self._select_lowest_kv(candidate_devices)
        elif self.strategy == PlacementStrategy.SHORTEST_QUEUE:
            selected_device = self._select_shortest_queue(candidate_devices)
        elif self.strategy == PlacementStrategy.BEST_FIT:
            selected_device = self._select_best_fit(candidate_devices, kv_tokens_required)
        else:
            raise ValueError(f"Unknown strategy: {self.strategy}")

        # Update stats
        self._placement_count += 1
        self._placement_decisions[selected_device] = (
            self._placement_decisions.get(selected_device, 0) + 1
        )

        # Log decision
        logger.debug(
            f"Placed request {request_id} on {selected_device} "
            f"(strategy={self.strategy.value}, kv_required={kv_tokens_required})"
        )

        return selected_device

    def select_device_for_request(
        self,
        request: SchedulerRequest,
        candidate_devices: list[str] | None = None,
    ) -> str:
        """Select a device for a scheduler request.

        Args:
            request: Scheduler request.
            candidate_devices: Optional list of candidate devices.
                If None, uses all registered devices.
                If request has device_affinity, it's used as the only candidate.

        Returns:
            Selected device identifier.

        Example:
            >>> from sagellm_kv_cache.load_metrics import LoadMetricsCollector
            >>> from sagellm_kv_cache.models import SchedulerRequest, RequestType
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0", kv_tokens_capacity=4096)
            >>> scheduler = LoadAwareScheduler(collector)
            >>> req = SchedulerRequest(
            ...     request_id="req1",
            ...     trace_id="trace1",
            ...     request_type=RequestType.PREFILL,
            ...     prompt_len=100,
            ...     max_new_tokens=50,
            ...     kv_tokens_required=150,
            ... )
            >>> device = scheduler.select_device_for_request(req)
            >>> assert device == "cuda:0"
        """
        # Honor device affinity if specified
        if request.device_affinity:
            return request.device_affinity

        # Determine candidate devices
        if candidate_devices is None:
            candidate_devices = self.collector.list_devices()

        return self.select_device(
            candidate_devices=candidate_devices,
            kv_tokens_required=request.kv_tokens_required,
            request_id=request.request_id,
        )

    def _select_round_robin(self, candidate_devices: list[str]) -> str:
        """Select device using round-robin strategy.

        Args:
            candidate_devices: List of candidate device identifiers.

        Returns:
            Selected device identifier.
        """
        device = candidate_devices[self._round_robin_index % len(candidate_devices)]
        self._round_robin_index += 1
        return device

    def _select_lowest_kv(self, candidate_devices: list[str]) -> str:
        """Select device with lowest KV cache occupancy.

        Args:
            candidate_devices: List of candidate device identifiers.

        Returns:
            Selected device identifier.

        Raises:
            RuntimeError: If no suitable device found.
        """
        best_device = None
        lowest_utilization = float("inf")

        for device in candidate_devices:
            try:
                metrics = self.collector.get_metrics(device)
                utilization = metrics.kv_utilization()

                if utilization < lowest_utilization:
                    lowest_utilization = utilization
                    best_device = device
            except KeyError:
                # Device not registered, skip
                logger.warning(f"Device {device} not registered in collector")
                continue

        if best_device is None:
            raise RuntimeError(f"No suitable device found among {candidate_devices}")

        return best_device

    def _select_shortest_queue(self, candidate_devices: list[str]) -> str:
        """Select device with shortest queue.

        Args:
            candidate_devices: List of candidate device identifiers.

        Returns:
            Selected device identifier.

        Raises:
            RuntimeError: If no suitable device found.
        """
        best_device = None
        shortest_queue = float("inf")

        for device in candidate_devices:
            try:
                metrics = self.collector.get_metrics(device)
                queue_length = metrics.total_requests()

                if queue_length < shortest_queue:
                    shortest_queue = queue_length
                    best_device = device
            except KeyError:
                # Device not registered, skip
                logger.warning(f"Device {device} not registered in collector")
                continue

        if best_device is None:
            raise RuntimeError(f"No suitable device found among {candidate_devices}")

        return best_device

    def _select_best_fit(self, candidate_devices: list[str], kv_tokens_required: int) -> str:
        """Select device with best fit for required resources.

        Selects the device with sufficient available KV tokens
        and lowest overall utilization.

        Args:
            candidate_devices: List of candidate device identifiers.
            kv_tokens_required: Required KV tokens.

        Returns:
            Selected device identifier.

        Raises:
            RuntimeError: If no suitable device found.
        """
        best_device = None
        best_score = float("inf")

        for device in candidate_devices:
            try:
                metrics = self.collector.get_metrics(device)

                # Check if device has enough capacity
                available = metrics.available_kv_tokens()
                if available < kv_tokens_required:
                    # Not enough space
                    continue

                # Score based on utilization (lower is better)
                # Combine KV utilization and memory utilization
                score = (
                    metrics.kv_utilization() * 0.6
                    + metrics.memory_utilization() * 0.3
                    + (metrics.total_requests() / 100.0) * 0.1  # Normalize request count
                )

                if score < best_score:
                    best_score = score
                    best_device = device
            except KeyError:
                # Device not registered, skip
                logger.warning(f"Device {device} not registered in collector")
                continue

        # If no device has enough space, fallback to lowest KV
        if best_device is None:
            logger.warning(
                f"No device with sufficient space ({kv_tokens_required} tokens), "
                "falling back to lowest KV strategy"
            )
            return self._select_lowest_kv(candidate_devices)

        return best_device

    def get_placement_stats(self) -> dict[str, int | dict[str, int]]:
        """Get placement statistics.

        Returns:
            Dictionary with placement stats.

        Example:
            >>> from sagellm_kv_cache.load_metrics import LoadMetricsCollector
            >>> collector = LoadMetricsCollector()
            >>> collector.register_device("cuda:0")
            >>> scheduler = LoadAwareScheduler(collector)
            >>> scheduler.select_device(["cuda:0"])
            'cuda:0'
            >>> stats = scheduler.get_placement_stats()
            >>> assert stats["total_placements"] == 1
        """
        return {
            "total_placements": self._placement_count,
            "per_device": self._placement_decisions.copy(),
        }

    def reset_stats(self) -> None:
        """Reset placement statistics.

        Example:
            >>> from sagellm_kv_cache.load_metrics import LoadMetricsCollector
            >>> scheduler = LoadAwareScheduler(LoadMetricsCollector())
            >>> scheduler.reset_stats()
            >>> assert scheduler.get_placement_stats()["total_placements"] == 0
        """
        self._placement_count = 0
        self._placement_decisions.clear()
        self._round_robin_index = 0

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"LoadAwareScheduler(strategy={self.strategy.value}, "
            f"enabled={self.enable_load_awareness}, "
            f"placements={self._placement_count})"
        )
