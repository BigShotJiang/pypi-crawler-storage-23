"""sagellm-kv-cache 错误类定义

本模块定义 KV Cache 模块的自定义错误类，遵循 Fail-Fast 原则：
- 每个错误类对应 Protocol 中定义的错误码
- 错误消息包含充分的上下文信息，便于调试
- 支持错误链和可重试判断

设计原则：
- 所有错误继承自 KVCacheError 基类
- 错误消息模板化，包含关键上下文
- 支持 is_retryable() 方法判断是否可重试

使用示例：
    >>> from sagellm_kv_cache.errors import KVBudgetExceededError
    >>> try:
    ...     raise KVBudgetExceededError(requested=1000, available=500)
    ... except KVBudgetExceededError as e:
    ...     print(e.code, e.message)

Author: sageLLM Team (Agent 2)
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from sagellm_protocol.kv import KVErrorCode, is_retryable


class KVCacheError(Exception):
    """KV Cache 错误基类。

    所有 KV Cache 相关错误都继承自此类。

    Attributes:
        code: Protocol 定义的错误码 (KVErrorCode)
        message: 人类可读的错误消息
        context: 额外的上下文信息字典
        cause: 导致此错误的原始异常（如果有）
    """

    def __init__(
        self,
        code: KVErrorCode,
        message: str,
        context: dict[str, Any] | None = None,
        cause: Exception | None = None,
    ) -> None:
        """初始化 KV Cache 错误。

        Args:
            code: 错误码
            message: 错误消息
            context: 额外上下文信息
            cause: 原始异常
        """
        self.code = code
        self.message = message
        self.context = context or {}
        self.cause = cause
        super().__init__(f"[{code.value}] {message}")

    def is_retryable(self) -> bool:
        """判断此错误是否可重试。

        Returns:
            True 如果错误可重试，False 否则
        """
        return is_retryable(self.code)  # type: ignore[no-any-return]

    def to_dict(self) -> dict[str, Any]:
        """序列化为字典，便于日志输出。

        Returns:
            包含错误信息的字典
        """
        return {
            "error_type": self.__class__.__name__,
            "code": self.code.value,
            "message": self.message,
            "context": self.context,
            "retryable": self.is_retryable(),
        }

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code.value!r}, message={self.message!r})"


# ============================================================
# 预算/资源错误 (Task2.2 KV Pool)
# ============================================================


class KVBudgetExceededError(KVCacheError):
    """预算超出错误。

    当请求的 token/bytes 超过可用预算时抛出。

    Attributes:
        requested: 请求的数量
        available: 可用的数量
        unit: 单位（"tokens" 或 "bytes"）
        max_tokens: 最大预算（如果在 context 中提供）
    """

    def __init__(
        self,
        requested: int,
        available: int,
        *,
        unit: str = "tokens",
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化预算超出错误。

        Args:
            requested: 请求的数量
            available: 可用的数量
            unit: 单位，默认 "tokens"
            context: 额外上下文（可包含 max_tokens）
        """
        self.requested = requested
        self.available = available
        self.unit = unit
        # Extract max_tokens from context if provided
        self.max_tokens = context.get("max_tokens") if context else None

        message = (
            f"Budget exceeded: requested {requested} {unit}, only {available} {unit} available"
        )
        ctx = {"requested": requested, "available": available, "unit": unit}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.BUDGET_EXCEEDED, message, ctx)


class KVMemoryExhaustedError(KVCacheError):
    """内存耗尽错误。

    当无法分配更多内存时抛出。
    """

    def __init__(
        self,
        required_bytes: int,
        *,
        device: str = "unknown",
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化内存耗尽错误。

        Args:
            required_bytes: 需要的字节数
            device: 设备标识
            context: 额外上下文
        """
        self.required_bytes = required_bytes
        self.device = device
        message = f"Memory exhausted on device '{device}': cannot allocate {required_bytes} bytes"
        ctx = {"required_bytes": required_bytes, "device": device}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.MEMORY_EXHAUSTED, message, ctx)


class KVPoolFullError(KVCacheError):
    """内存池已满错误。

    当所有块都已分配时抛出。
    """

    def __init__(
        self,
        total_blocks: int,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化内存池已满错误。

        Args:
            total_blocks: 总块数
            context: 额外上下文
        """
        self.total_blocks = total_blocks
        message = f"KV pool is full: all {total_blocks} blocks are allocated"
        ctx = {"total_blocks": total_blocks}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.POOL_FULL, message, ctx)


# ============================================================
# 句柄操作错误 (Task2.2 KV Pool)
# ============================================================


class KVInvalidHandleError(KVCacheError):
    """无效句柄错误。

    当句柄不存在或已失效时抛出。
    """

    def __init__(
        self,
        handle_id: UUID | str,
        *,
        reason: str = "handle does not exist or has been invalidated",
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化无效句柄错误。

        Args:
            handle_id: 句柄 ID
            reason: 具体原因
            context: 额外上下文
        """
        self.handle_id = handle_id if isinstance(handle_id, str) else str(handle_id)
        self.reason = reason
        message = f"Invalid handle '{self.handle_id}': {reason}"
        ctx = {"handle_id": self.handle_id, "reason": reason}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.INVALID_HANDLE, message, ctx)


class KVDoubleFreeError(KVCacheError):
    """重复释放错误。

    当尝试释放已释放的句柄时抛出。
    """

    def __init__(
        self,
        handle_id: UUID | str,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化重复释放错误。

        Args:
            handle_id: 句柄 ID
            context: 额外上下文
        """
        self.handle_id = handle_id if isinstance(handle_id, str) else str(handle_id)
        message = f"Double free detected: handle '{self.handle_id}' has already been freed"
        ctx = {"handle_id": self.handle_id}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.DOUBLE_FREE, message, ctx)


class KVHandlePinnedError(KVCacheError):
    """句柄已固定错误。

    当尝试对已固定的句柄执行不允许的操作时抛出。
    """

    def __init__(
        self,
        handle_id: UUID | str,
        *,
        operation: str = "evict",
        pin_count: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化句柄已固定错误。

        Args:
            handle_id: 句柄 ID
            operation: 尝试执行的操作
            pin_count: 当前固定计数
            context: 额外上下文
        """
        self.handle_id = handle_id if isinstance(handle_id, str) else str(handle_id)
        self.operation = operation
        self.pin_count = pin_count
        message = (
            f"Cannot {operation} handle '{self.handle_id}': "
            f"handle is pinned (pin_count={pin_count})"
        )
        ctx = {"handle_id": self.handle_id, "operation": operation, "pin_count": pin_count}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.HANDLE_PINNED, message, ctx)


class KVHandleNotFoundError(KVCacheError):
    """句柄未找到错误。

    当指定的句柄 ID 不存在时抛出。
    """

    def __init__(
        self,
        handle_id: UUID | str,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化句柄未找到错误。

        Args:
            handle_id: 句柄 ID
            context: 额外上下文
        """
        self.handle_id = handle_id if isinstance(handle_id, str) else str(handle_id)
        message = f"Handle not found: '{self.handle_id}'"
        ctx = {"handle_id": self.handle_id}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.HANDLE_NOT_FOUND, message, ctx)


class KVRefCountUnderflowError(KVCacheError):
    """引用计数下溢错误。

    当尝试减少已为 0 的引用计数时抛出。
    """

    def __init__(
        self,
        handle_id: UUID | str,
        *,
        current_count: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化引用计数下溢错误。

        Args:
            handle_id: 句柄 ID
            current_count: 当前引用计数
            context: 额外上下文
        """
        self.handle_id = handle_id if isinstance(handle_id, str) else str(handle_id)
        self.current_count = current_count
        message = (
            f"Reference count underflow on handle '{self.handle_id}': "
            f"cannot decrement from {current_count}"
        )
        ctx = {"handle_id": self.handle_id, "current_count": current_count}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.REF_COUNT_UNDERFLOW, message, ctx)


# ============================================================
# 缓存错误 (Task2.1 Prefix Cache)
# ============================================================


class KVCacheMissError(KVCacheError):
    """缓存未命中错误。

    当请求的前缀不在缓存中时抛出（通常用于 Fail-Fast 模式）。
    """

    def __init__(
        self,
        prefix_hash: str,
        *,
        prefix_len: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化缓存未命中错误。

        Args:
            prefix_hash: 前缀哈希
            prefix_len: 前缀长度
            context: 额外上下文
        """
        self.prefix_hash = prefix_hash
        self.prefix_len = prefix_len
        message = f"Cache miss for prefix '{prefix_hash}' (length={prefix_len})"
        ctx = {"prefix_hash": prefix_hash, "prefix_len": prefix_len}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.CACHE_MISS, message, ctx)


class KVPrefixTooLongError(KVCacheError):
    """前缀过长错误。

    当前缀长度超过限制时抛出。
    """

    def __init__(
        self,
        prefix_len: int,
        max_len: int,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化前缀过长错误。

        Args:
            prefix_len: 实际前缀长度
            max_len: 最大允许长度
            context: 额外上下文
        """
        self.prefix_len = prefix_len
        self.max_len = max_len
        message = f"Prefix too long: {prefix_len} tokens exceeds maximum {max_len}"
        ctx = {"prefix_len": prefix_len, "max_len": max_len}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.PREFIX_TOO_LONG, message, ctx)


# ============================================================
# 驱逐错误 (Task2.3 Eviction)
# ============================================================


class KVNoVictimError(KVCacheError):
    """无可驱逐对象错误。

    当所有对象都被固定或引用时抛出。
    """

    def __init__(
        self,
        bytes_needed: int,
        *,
        pinned_count: int = 0,
        total_count: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化无可驱逐对象错误。

        Args:
            bytes_needed: 需要释放的字节数
            pinned_count: 被固定的对象数
            total_count: 总对象数
            context: 额外上下文
        """
        self.bytes_needed = bytes_needed
        self.pinned_count = pinned_count
        self.total_count = total_count
        message = (
            f"No eviction victim available: need {bytes_needed} bytes, "
            f"but {pinned_count}/{total_count} objects are pinned"
        )
        ctx = {
            "bytes_needed": bytes_needed,
            "pinned_count": pinned_count,
            "total_count": total_count,
        }
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.NO_VICTIM, message, ctx)


class KVEvictionFailedError(KVCacheError):
    """驱逐失败错误。

    当驱逐操作执行失败时抛出。
    """

    def __init__(
        self,
        handle_id: UUID | str,
        *,
        reason: str = "unknown",
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化驱逐失败错误。

        Args:
            handle_id: 句柄 ID
            reason: 失败原因
            context: 额外上下文
        """
        self.handle_id = handle_id if isinstance(handle_id, str) else str(handle_id)
        self.reason = reason
        message = f"Eviction failed for handle '{self.handle_id}': {reason}"
        ctx = {"handle_id": self.handle_id, "reason": reason}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.EVICTION_FAILED, message, ctx)


class KVAllPinnedError(KVCacheError):
    """全部固定错误。

    当所有候选对象都被固定时抛出。
    """

    def __init__(
        self,
        candidate_count: int,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化全部固定错误。

        Args:
            candidate_count: 候选对象数量
            context: 额外上下文
        """
        self.candidate_count = candidate_count
        message = f"All {candidate_count} eviction candidates are pinned"
        ctx = {"candidate_count": candidate_count}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.ALL_PINNED, message, ctx)


# ============================================================
# 传输错误 (Task2.8/2.9 KV Transfer)
# ============================================================


class KVTransferFailedError(KVCacheError):
    """传输失败错误。

    当 KV 数据传输失败时抛出。
    """

    def __init__(
        self,
        transfer_id: UUID | str,
        *,
        source: str = "unknown",
        target: str = "unknown",
        reason: str = "unknown",
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化传输失败错误。

        Args:
            transfer_id: 传输 ID
            source: 源设备
            target: 目标设备
            reason: 失败原因
            context: 额外上下文
        """
        self.transfer_id = transfer_id if isinstance(transfer_id, str) else str(transfer_id)
        self.source = source
        self.target = target
        self.reason = reason
        message = f"KV transfer '{self.transfer_id}' failed: {source} -> {target}, reason: {reason}"
        ctx = {
            "transfer_id": self.transfer_id,
            "source": source,
            "target": target,
            "reason": reason,
        }
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.TRANSFER_FAILED, message, ctx)


class KVTransferTimeoutError(KVCacheError):
    """传输超时错误。

    当传输操作超过时间限制时抛出。
    """

    def __init__(
        self,
        transfer_id: UUID | str,
        *,
        timeout_seconds: float,
        elapsed_seconds: float,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化传输超时错误。

        Args:
            transfer_id: 传输 ID
            timeout_seconds: 超时设置
            elapsed_seconds: 已耗时
            context: 额外上下文
        """
        self.transfer_id = transfer_id if isinstance(transfer_id, str) else str(transfer_id)
        self.timeout_seconds = timeout_seconds
        self.elapsed_seconds = elapsed_seconds
        message = (
            f"KV transfer '{self.transfer_id}' timed out: "
            f"elapsed {elapsed_seconds:.2f}s > timeout {timeout_seconds:.2f}s"
        )
        ctx = {
            "transfer_id": self.transfer_id,
            "timeout_seconds": timeout_seconds,
            "elapsed_seconds": elapsed_seconds,
        }
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.TRANSFER_TIMEOUT, message, ctx)


class KVChecksumMismatchError(KVCacheError):
    """校验和不匹配错误。

    当数据校验失败时抛出。
    """

    def __init__(
        self,
        expected: str,
        actual: str,
        *,
        transfer_id: UUID | str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化校验和不匹配错误。

        Args:
            expected: 期望的校验和
            actual: 实际的校验和
            transfer_id: 传输 ID（可选）
            context: 额外上下文
        """
        self.expected = expected
        self.actual = actual
        self.transfer_id = (
            transfer_id
            if isinstance(transfer_id, str)
            else str(transfer_id)
            if transfer_id
            else None
        )
        message = f"Checksum mismatch: expected '{expected}', got '{actual}'"
        if self.transfer_id:
            message += f" (transfer_id={self.transfer_id})"
        ctx = {"expected": expected, "actual": actual}
        if self.transfer_id:
            ctx["transfer_id"] = self.transfer_id
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.CHECKSUM_MISMATCH, message, ctx)


class KVMetadataMismatchError(KVCacheError):
    """元数据不匹配错误。

    当传输元数据与期望不符时抛出。
    """

    def __init__(
        self,
        field: str,
        expected: Any,
        actual: Any,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化元数据不匹配错误。

        Args:
            field: 不匹配的字段名
            expected: 期望值
            actual: 实际值
            context: 额外上下文
        """
        self.field = field
        self.expected = expected
        self.actual = actual
        message = f"Metadata mismatch on field '{field}': expected {expected!r}, got {actual!r}"
        ctx = {"field": field, "expected": expected, "actual": actual}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.METADATA_MISMATCH, message, ctx)


# ============================================================
# 配置错误
# ============================================================


class KVConfigMissingError(KVCacheError):
    """配置缺失错误。

    当必需的配置项未提供时抛出。
    """

    def __init__(
        self,
        config_key: str,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化配置缺失错误。

        Args:
            config_key: 缺失的配置键
            context: 额外上下文
        """
        self.config_key = config_key
        message = f"Required configuration missing: '{config_key}'"
        ctx = {"config_key": config_key}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.CONFIG_MISSING, message, ctx)


class KVConfigInvalidError(KVCacheError):
    """配置无效错误。

    当配置项值不合法时抛出。
    """

    def __init__(
        self,
        config_key: str,
        value: Any,
        *,
        reason: str = "invalid value",
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化配置无效错误。

        Args:
            config_key: 配置键
            value: 无效的值
            reason: 无效原因
            context: 额外上下文
        """
        self.config_key = config_key
        self.value = value
        self.reason = reason
        message = f"Invalid configuration '{config_key}': {value!r} - {reason}"
        ctx = {"config_key": config_key, "value": value, "reason": reason}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.CONFIG_INVALID, message, ctx)


class KVNotImplementedError(KVCacheError):
    """未实现错误。

    当请求的功能尚未实现时抛出（Fail-Fast）。
    """

    def __init__(
        self,
        feature: str,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        """初始化未实现错误。

        Args:
            feature: 未实现的功能名称
            context: 额外上下文
        """
        self.feature = feature
        message = f"Feature not implemented: '{feature}' (Fail-Fast)"
        ctx = {"feature": feature}
        if context:
            ctx.update(context)
        super().__init__(KVErrorCode.NOT_IMPLEMENTED, message, ctx)


# ============================================================
# 导出列表
# ============================================================

__all__ = [
    # 基类
    "KVCacheError",
    # 预算/资源错误
    "KVBudgetExceededError",
    "KVMemoryExhaustedError",
    "KVPoolFullError",
    # 句柄操作错误
    "KVInvalidHandleError",
    "KVDoubleFreeError",
    "KVHandlePinnedError",
    "KVHandleNotFoundError",
    "KVRefCountUnderflowError",
    # 缓存错误
    "KVCacheMissError",
    "KVPrefixTooLongError",
    # 驱逐错误
    "KVNoVictimError",
    "KVEvictionFailedError",
    "KVAllPinnedError",
    # 传输错误
    "KVTransferFailedError",
    "KVTransferTimeoutError",
    "KVChecksumMismatchError",
    "KVMetadataMismatchError",
    # 配置错误
    "KVConfigMissingError",
    "KVConfigInvalidError",
    "KVNotImplementedError",
]
