"""分布式 KV 池化接口定义（预留）

本模块为未来的分布式 KV 池化预留抽象接口。
当前 KVPool 仅支持单节点本地内存管理，真正的分布式池化需要：

1. GlobalKVPoolManager: 全局池管理器（运行在 Control Plane）
   - 跨节点内存托管（每个节点贡献内存到全局池）
   - 全局分配决策（考虑网络拓扑、负载均衡）
   - 远程访问协调（通过 KVTransferEngine）

2. NodeContribution: 节点内存贡献配置
   - 定义每个节点贡献多少内存
   - 支持多层存储（GPU/CPU/NVMe）

3. RemoteAccessLayer: 远程 KV 访问层
   - 透明的本地/远程访问
   - 通过 RDMA/KV Transfer 获取远程 KV

参考架构：Mooncake Store (KVCache.AI)
https://github.com/kvcache-ai/Mooncake

Author: sageLLM Team
Date: 2026-01-29
Status: RESERVED (未来实现)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from sagellm_kv_cache.models import DType, KVHandle, Layout


@dataclass
class NodeContribution:
    """节点内存贡献配置（分布式池化）

    定义每个节点贡献到全局 KV 池的内存资源。

    Attributes:
        node_rank: 节点的全局 rank
        total_memory_gb: 节点总内存（GB）
        contributed_memory_gb: 贡献给全局池的内存（GB）
        reserved_memory_gb: 保留给本地推理的内存（GB）
        storage_tiers: 支持的存储层级（gpu/cpu/nvme）

    Example:
        >>> contrib = NodeContribution(
        ...     node_rank=0,
        ...     total_memory_gb=100,
        ...     contributed_memory_gb=40,
        ...     reserved_memory_gb=60,
        ...     storage_tiers=["gpu", "cpu"]
        ... )
    """

    node_rank: int
    total_memory_gb: float
    contributed_memory_gb: float
    reserved_memory_gb: float
    storage_tiers: list[str]  # ["gpu", "cpu", "nvme"]

    def __post_init__(self) -> None:
        """验证配置合法性"""
        if self.contributed_memory_gb + self.reserved_memory_gb > self.total_memory_gb:
            raise ValueError(
                f"Contributed ({self.contributed_memory_gb}GB) + "
                f"Reserved ({self.reserved_memory_gb}GB) > "
                f"Total ({self.total_memory_gb}GB)"
            )
        if self.contributed_memory_gb < 0 or self.reserved_memory_gb < 0:
            raise ValueError("Memory sizes must be non-negative")


class GlobalKVPoolManager(ABC):
    """全局 KV 池管理器接口（分布式池化 - 预留）

    这是分布式 KV 池化的核心接口，负责：
    1. 管理所有节点贡献的内存资源
    2. 全局分配决策（考虑网络拓扑、负载均衡）
    3. 协调跨节点 KV 访问

    实现说明：
    - 应部署在 Control Plane 上
    - 与 KVTransferEngine 协同工作
    - 支持多层存储（GPU/CPU/NVMe）

    设计原则（Protocol-First）：
    - ❌ 禁止在协议冻结前实现功能
    - ✅ 必须先定义分配请求/响应 schema
    - ✅ 必须在 sagellm-protocol 中定义全局池相关类型

    Example (未来实现):
        >>> # 初始化全局池
        >>> nodes = [
        ...     NodeContribution(rank=0, total_memory_gb=100, contributed_memory_gb=40, ...),
        ...     NodeContribution(rank=1, total_memory_gb=100, contributed_memory_gb=50, ...),
        ... ]
        >>> manager = ConcreteGlobalKVPoolManager(nodes)
        >>>
        >>> # 全局分配（可能在任何节点）
        >>> handle = manager.alloc(num_tokens=1024, preferred_node=0)
        >>> print(f"KV allocated on node {handle.node_rank}")
        >>>
        >>> # 访问 KV（自动处理本地/远程）
        >>> kv_data = manager.get(handle)

    参考：Mooncake Store 的分布式架构
    """

    @abstractmethod
    def __init__(self, nodes: list[NodeContribution]) -> None:
        """初始化全局池管理器

        Args:
            nodes: 所有节点的内存贡献配置

        Raises:
            ValueError: 如果节点配置无效
        """
        pass

    @abstractmethod
    def alloc(
        self,
        num_tokens: int,
        dtype: DType | str,
        layout: Layout | str,
        device: str,
        preferred_node: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> KVHandle:
        """全局分配 KV Cache（可能在任何节点）

        Args:
            num_tokens: 分配的 token 数量
            dtype: 数据类型
            layout: 内存布局
            device: 设备类型
            preferred_node: 优先分配的节点 rank（可选）
            metadata: 扩展元数据

        Returns:
            KVHandle，包含 node_rank 字段标识 KV 所在节点

        Raises:
            KVBudgetExceededError: 全局池容量不足

        Note:
            分配策略应考虑：
            - 网络拓扑（NUMA 亲和性、跨机房延迟）
            - 负载均衡（各节点负载）
            - 本地优先（尽量分配在请求者所在节点）
        """
        pass

    @abstractmethod
    def free(self, handle: KVHandle) -> None:
        """释放全局 KV Cache

        Args:
            handle: 要释放的 KVHandle

        Note:
            需要根据 handle.node_rank 确定目标节点并执行释放
        """
        pass

    @abstractmethod
    def get(self, handle: KVHandle, current_rank: int) -> Any:
        """获取 KV 数据（自动处理本地/远程访问）

        Args:
            handle: KVHandle
            current_rank: 当前节点的 rank

        Returns:
            KV 数据（tensor）

        Note:
            - 如果 handle.node_rank == current_rank，从本地读取
            - 否则，通过 KVTransferEngine 从远程节点获取
        """
        pass

    @abstractmethod
    def get_global_stats(self) -> dict[str, Any]:
        """获取全局池统计信息

        Returns:
            包含以下字段的字典：
            - total_capacity_tokens: 全局池总容量
            - allocated_tokens: 全局已分配令牌数
            - per_node_stats: 各节点的统计信息

        Example:
            >>> stats = manager.get_global_stats()
            >>> print(f"Global capacity: {stats['total_capacity_tokens']}")
            >>> print(f"Node 0 allocated: {stats['per_node_stats'][0]['allocated_tokens']}")
        """
        pass

    @abstractmethod
    def rebalance(self) -> None:
        """全局负载均衡（可选）

        重新分配 KV 以优化资源利用率和访问延迟。

        策略：
        - 将冷 KV 迁移到低负载节点
        - 将热 KV 迁移到请求者附近
        - 考虑网络拓扑最小化通信开销
        """
        pass


class RemoteKVAccessor(ABC):
    """远程 KV 访问层接口（分布式池化 - 预留）

    提供透明的本地/远程 KV 访问，隐藏网络细节。

    Example (未来实现):
        >>> accessor = ConcreteRemoteKVAccessor(kv_transfer_engine, comm_backend)
        >>>
        >>> # 获取 KV（自动判断本地/远程）
        >>> kv_data = accessor.fetch(handle, current_rank=0)
        >>>
        >>> # 预取远程 KV（异步）
        >>> accessor.prefetch(handle, current_rank=0)
    """

    @abstractmethod
    def fetch(self, handle: KVHandle, current_rank: int) -> Any:
        """获取 KV 数据（同步）

        Args:
            handle: KVHandle
            current_rank: 当前节点 rank

        Returns:
            KV 数据（tensor）
        """
        pass

    @abstractmethod
    def prefetch(self, handle: KVHandle, current_rank: int) -> None:
        """预取远程 KV（异步）

        Args:
            handle: KVHandle
            current_rank: 当前节点 rank
        """
        pass

    @abstractmethod
    def is_remote(self, handle: KVHandle, current_rank: int) -> bool:
        """判断 KV 是否在远程节点

        Args:
            handle: KVHandle
            current_rank: 当前节点 rank

        Returns:
            True 如果 KV 在远程节点
        """
        pass


# ============================================================
# 使用示例（伪代码，未来实现）
# ============================================================

"""
# 场景：3 节点集群，每个节点贡献 40GB 到全局池

from sagellm_kv_cache.distributed import GlobalKVPoolManager, NodeContribution
from sagellm_kv_cache import KVTransferEngine
from sagellm_comm import GlooBackend

# 1. 配置节点贡献
nodes = [
    NodeContribution(
        node_rank=0,
        total_memory_gb=100,
        contributed_memory_gb=40,
        reserved_memory_gb=60,
        storage_tiers=["gpu", "cpu"]
    ),
    NodeContribution(
        node_rank=1,
        total_memory_gb=100,
        contributed_memory_gb=40,
        reserved_memory_gb=60,
        storage_tiers=["gpu", "cpu"]
    ),
    NodeContribution(
        node_rank=2,
        total_memory_gb=100,
        contributed_memory_gb=40,
        reserved_memory_gb=60,
        storage_tiers=["gpu", "cpu"]
    ),
]

# 2. 初始化全局池管理器（在 Control Plane 上）
global_pool = ConcreteGlobalKVPoolManager(nodes)
print(f"Global pool capacity: {global_pool.get_global_stats()['total_capacity_tokens']} tokens")

# 3. 节点 0 请求分配 KV
handle = global_pool.alloc(
    num_tokens=1024,
    dtype="fp16",
    layout="contiguous",
    device="cuda:0",
    preferred_node=0  # 优先本地分配
)

print(f"KV allocated on node {handle.node_rank}")

# 4. 节点 1 需要访问该 KV（跨节点）
if handle.node_rank != 1:  # KV 在远程节点
    kv_data = remote_accessor.fetch(handle, current_rank=1)
else:
    kv_data = local_pool.get(handle)

# 5. 释放 KV
global_pool.free(handle)
"""
