"""
VLLMDirectGenerator - 直接调用 vLLM Python API
==============================================

支持 SCBench 的 KV Cache 复用（SCDQ 模式）。

与 OpenAIGenerator 的区别：
- OpenAI API: HTTP 请求，每次独立，无法复用 KV Cache
- VLLMDirect: Python API，在同一 LLM 对象中生成，自动复用前缀 KV Cache

使用场景：
- 本地运行 vLLM（需要 GPU）
- 完整支持 SCBench 的 SCDQ 模式
- 测试 KV Cache 优化效果

调用方式::
    sub_conf = config["generator"]["vllm_direct"]   # <- 单端点子配置
    gen = VLLMDirectGenerator(sub_conf)

其中 `sub_conf` 结构示例::

    {
      "model_name": "Qwen/Qwen2.5-7B-Instruct",
      "tensor_parallel_size": 1,
      "max_tokens": 100,
      "temperature": 0.0,
      "top_p": 1.0,
      "seed": 42,
      "gpu_memory_utilization": 0.95
    }
"""

import os
from typing import Any

from sage.common.core.functions import MapFunction as MapOperator


class VLLMDirectGenerator(MapOperator):
    """
    直接调用 vLLM Python API 的 Generator

    支持两种模式：
    1. Multi-Turn: 每个 prompt 独立生成
    2. SCDQ: 复用 context 的 KV Cache（通过 vLLM 的 Automatic Prefix Caching）

    配置参数（从 config 中读取）：
        model_name: str - 模型名称或路径（必需）
        tensor_parallel_size: int - 张量并行度（默认 1）
        max_tokens: int - 最大生成 token 数（默认 100）
        temperature: float - 采样温度（默认 0.0，greedy）
        top_p: float - nucleus sampling（默认 1.0）
        seed: int - 随机种子（默认 42）
        gpu_memory_utilization: float - GPU 内存利用率（默认 0.95）
        trust_remote_code: bool - 是否信任远程代码（默认 True）
    """

    def __init__(self, config: dict, **kwargs):
        super().__init__(**kwargs)

        # 直接持有子配置
        self.config = config

        # 获取必需的配置参数（使用 .get() 提供默认值）
        self.model_name = self.config.get("model_name", "Qwen/Qwen2.5-7B-Instruct")
        # 展开环境变量（如果 model_name 包含环境变量）
        self.model_name = os.path.expandvars(self.model_name)

        # 生成参数（从配置中提取）
        self.max_tokens = self.config.get("max_tokens", 100)
        self.temperature = self.config.get("temperature", 0.0)
        self.top_p = self.config.get("top_p", 1.0)
        self.seed = self.config.get("seed", 42)

        # vLLM 特定参数
        self.tensor_parallel_size = self.config.get("tensor_parallel_size", 1)
        self.gpu_memory_utilization = self.config.get("gpu_memory_utilization", 0.95)
        self.trust_remote_code = self.config.get("trust_remote_code", True)

        # 延迟加载 vLLM
        self._llm = None
        self._tokenizer = None

        self.logger.info("VLLMDirectGenerator initialized:")
        self.logger.info(f"  - Model: {self.model_name}")
        self.logger.info(f"  - Tensor parallel: {self.tensor_parallel_size}")
        self.logger.info(f"  - Max tokens: {self.max_tokens}")
        self.logger.info(f"  - Temperature: {self.temperature}")

    @property
    def llm(self):
        """延迟加载 vLLM LLM 对象"""
        if self._llm is None:
            try:
                from vllm import LLM

                self.logger.info(f"Loading vLLM model: {self.model_name}...")
                self._llm = LLM(
                    model=self.model_name,
                    tensor_parallel_size=self.tensor_parallel_size,
                    trust_remote_code=self.trust_remote_code,
                    gpu_memory_utilization=self.gpu_memory_utilization,
                )
                self.logger.info("✅ vLLM model loaded successfully")
            except ImportError:
                raise ImportError("vLLM is not installed. Install with: pip install vllm")
            except Exception as e:
                raise RuntimeError(f"Failed to load vLLM model: {e}")
        return self._llm

    @property
    def tokenizer(self):
        """获取 tokenizer"""
        if self._tokenizer is None:
            self._tokenizer = self.llm.get_tokenizer()
        return self._tokenizer

    def execute(self, data: dict[str, Any]) -> list[dict[str, Any]]:
        """
        执行生成

        Input:
            {
                "prompts": List[str],            # 完整 prompts
                "ground_truths": List[str],      # 答案（不用于生成）
                "_eval_mode": "multi_turn" | "scdq",
                "_scdq_context_split": int,      # SCDQ 模式：context 部分索引
                ...
            }

        Output:
            {
                "generated": List[str],          # 生成的答案
                **data                           # 原始数据传递
            }
        """
        eval_mode = data.get("_eval_mode", "multi_turn")
        prompts = data.get("prompts", [])

        if not prompts:
            self.logger.warning("No prompts to generate")
            data["generated"] = []
            return [data]

        # 根据模式选择生成策略
        if eval_mode == "scdq":
            generated = self._generate_scdq(prompts, data)
        else:
            generated = self._generate_multiturn(prompts)

        data["generated"] = generated

        self.logger.debug(f"Generated {len(generated)} responses in {eval_mode} mode")

        return [data]

    def _generate_scdq(self, prompts: list[str], data: dict) -> list[str]:
        """
        SCDQ 模式：复用 context 的 KV Cache

        Prompts 格式：
        [context_prompt, query1_prompt, query2_prompt, ...]

        工作原理：
        1. 第一个 prompt 是 context（只 tokenize，不生成）
        2. 后续 prompts 是 queries，拼接 context + query 后生成
        3. vLLM 自动检测相同的 context 前缀，复用 KV Cache
        """
        from vllm import SamplingParams

        context_split = data.get("_scdq_context_split", 1)

        if len(prompts) < context_split + 1:
            self.logger.warning(
                f"SCDQ mode requires at least {context_split + 1} prompts, got {len(prompts)}"
            )
            return []

        # 第一个是 context（tokenize）
        context_prompt = prompts[0]
        context_tokens = self.tokenizer.encode(context_prompt, add_special_tokens=True)

        self.logger.debug(f"Context tokens: {len(context_tokens)}")

        # 后续是 queries
        results = []
        query_prompts = prompts[context_split:]

        sampling_params = SamplingParams(
            temperature=self.temperature,
            top_p=self.top_p,
            max_tokens=self.max_tokens,
            seed=self.seed,
        )

        for idx, query_prompt in enumerate(query_prompts):
            # Tokenize query
            query_tokens = self.tokenizer.encode(query_prompt, add_special_tokens=False)

            # 拼接 context + query
            input_ids = context_tokens + query_tokens

            self.logger.debug(
                f"Query {idx + 1}: context={len(context_tokens)} + "
                f"query={len(query_tokens)} = {len(input_ids)} tokens"
            )

            # 生成（vLLM 自动复用 context 的 KV Cache）
            outputs = self.llm.generate(
                prompt_token_ids=[input_ids],
                sampling_params=sampling_params,
            )

            generated_text = outputs[0].outputs[0].text
            results.append(generated_text)

            self.logger.debug(f"Generated: {generated_text[:100]}...")

        return results

    def _generate_multiturn(self, prompts: list[str]) -> list[str]:
        """
        Multi-Turn 模式：每个 prompt 独立生成

        适用场景：
        - 每轮 prompt 包含完整的 context + history + query
        - 不需要 KV Cache 复用
        """
        from vllm import SamplingParams

        sampling_params = SamplingParams(
            temperature=self.temperature,
            top_p=self.top_p,
            max_tokens=self.max_tokens,
            seed=self.seed,
        )

        self.logger.debug(f"Generating {len(prompts)} responses (batch mode)")

        # 批量生成（vLLM 内部会自动优化）
        outputs = self.llm.generate(
            prompts=prompts,
            sampling_params=sampling_params,
        )

        results = [output.outputs[0].text for output in outputs]

        return results
