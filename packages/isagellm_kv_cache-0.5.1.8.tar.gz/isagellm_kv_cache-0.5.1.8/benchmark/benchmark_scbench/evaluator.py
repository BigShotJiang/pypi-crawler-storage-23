"""SCBench evaluator.

This module:
- Collects predictions from Generator
- Writes results in SCBench JSONL format
- Computes scores using utils.py scoring functions
- Outputs summary JSON with final scores
"""

import atexit
import json
from pathlib import Path
from typing import TYPE_CHECKING, Any

from sage.common.core.functions import MapFunction as MapOperator

from .utils import SCBENCH_TO_INFINITEBENCH, get_score_one

if TYPE_CHECKING:
    pass


class SCBenchEvaluator(MapOperator):
    """
    SCBench 专用评估器

    职责：
    1. 收集所有预测结果
    2. 按 SCBench 格式写 JSONL（id, turn_idx, prediction, ground_truth, task）
    3. 在 finalize() 调用原始 compute_scores.py 计算最终分数
    4. 输出 Summary JSON

    Config Keys:
        output_dir: str - 结果输出目录
        model_name: str - 模型名称（用于文件命名）
        task: str - 任务名称（可以是多任务，逗号分隔）

    Input (来自 Generator):
        {
            "prompts": List[str],
            "ground_truths": List[str],
            "generated": List[str],          # Generator 输出
            "task": str,
            "id": str,
            ...
        }

    Output:
        - JSONL 文件: {output_dir}/{task}_{model_name}.jsonl
        - Summary JSON: {output_dir}/scbench_summary_{model_name}.json
    """

    def __init__(self, config: dict[str, Any] | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.config = config or {}

        # 解析配置
        # 使用相对路径，默认在当前目录的 results 子目录下
        output_dir_str = self.config.get("output_dir", "./results")
        self.output_dir = Path(output_dir_str).resolve()  # 转为绝对路径以避免相对路径问题
        self.model_name = self.config.get("model_name", "unknown_model")
        self.task = self.config.get("task", "scbench_kv")

        # 创建输出目录
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 结果收集器
        self.all_results: list[dict[str, Any]] = []
        self.task_stats: dict[str, dict[str, int]] = {}

        # Finalization flag（防止重复调用）
        self._finalized = False

        # 使用atexit确保程序退出时执行finalization
        atexit.register(self._finalize)

        self.logger.debug("SCBenchEvaluator initialized:")
        self.logger.debug(f"  - Output dir: {self.output_dir}")
        self.logger.debug(f"  - Model name: {self.model_name}")
        self.logger.debug(f"  - Task: {self.task}")

    def execute(self, data: Any) -> Any:
        """
        Process one sample from Generator (MapFunction.execute()).

        支持两种输入格式：
        1. Multi-Turn 单轮格式（来自修改后的 Promptor）:
           {
               "prompt": str,
               "ground_truth": str,
               "generated": str,        # Generator 输出
               "turn_idx": int,
               "task": str,
               "id": str,
               ...
           }

        2. SCDQ 批量格式（或旧版 Multi-Turn 格式）:
           {
               "prompts": List[str],
               "ground_truths": List[str],
               "generated": List[str],  # Generator 输出（可能是单个 str）
               "task": str,
               "id": str,
               ...
           }
        """
        task = data.get("task", "unknown")
        sample_id = data.get("id", "unknown_id")

        # 统计
        if task not in self.task_stats:
            self.task_stats[task] = {"total_samples": 0, "total_turns": 0}

        # 判断输入格式
        if "ground_truth" in data and "turn_idx" in data:
            # 新格式：单轮输出
            turn_idx = data["turn_idx"]
            pred = data.get("generated", "")
            gt = data["ground_truth"]

            # 使用data中的task（可能是turn级别的，对于混合任务如summary_with_needles）
            result_task = data.get("task", task)

            self.all_results.append(
                {
                    "id": sample_id,
                    "turn_idx": turn_idx,
                    "prediction": pred,
                    "ground_truth": gt,
                    "task": result_task,  # 使用turn级别的task（如果有）
                }
            )

            # 只在第一轮计数样本
            if turn_idx == 0:
                self.task_stats[task]["total_samples"] += 1
            self.task_stats[task]["total_turns"] += 1

        else:
            # 旧格式：批量输出（SCDQ 或旧版 Multi-Turn）
            ground_truths = data.get("ground_truths", [])
            generated = data.get("generated", [])

            # 处理 generated 可能是 str 的情况
            if isinstance(generated, str):
                generated = [generated]

            self.task_stats[task]["total_samples"] += 1

            # 收集每轮的结果
            for turn_idx, (pred, gt) in enumerate(zip(generated, ground_truths)):
                self.all_results.append(
                    {
                        "id": sample_id,
                        "turn_idx": turn_idx,
                        "prediction": pred,
                        "ground_truth": gt,
                        "task": task,
                    }
                )
                self.task_stats[task]["total_turns"] += 1

        return data  # MapFunction 必须返回数据

    def _finalize(self) -> None:
        """
        执行最终化：写文件、计算分数、打印统计
        在对象销毁时调用（通过 __del__），确保只执行一次
        """
        if self._finalized:
            return

        self._finalized = True

        if not self.all_results:
            print("⚠️  No results to finalize")
            return

        print(f"\n{'=' * 80}")
        print("🎯 SCBench Evaluation - Finalizing Results")
        print(f"{'=' * 80}")

        # 1. 写 JSONL 结果
        self._write_jsonl()

        # 2. 计算分数
        summary = self._compute_scores()

        # 3. 输出 Summary JSON
        self._write_summary(summary)

        # 4. 打印统计信息
        self._print_stats(summary)

    def __del__(self):
        """对象销毁时自动调用 finalization"""
        try:
            self._finalize()
        except Exception:
            pass

    def _write_jsonl(self) -> None:
        """写 JSONL 结果文件"""
        # 按任务分组写入
        task_results: dict[str, list[dict]] = {}
        for result in self.all_results:
            task = result["task"]
            if task not in task_results:
                task_results[task] = []
            task_results[task].append(result)

        # 写入每个任务的 JSONL 文件
        for task, results in task_results.items():
            jsonl_path = self.output_dir / f"{task}_{self.model_name}.jsonl"
            self.logger.info(f"Writing JSONL: {jsonl_path}")

            with open(jsonl_path, "w", encoding="utf-8") as f:
                for result in results:
                    f.write(json.dumps(result, ensure_ascii=False) + "\n")

            self.logger.info(f"  - Wrote {len(results)} records to {jsonl_path}")

    def _compute_scores(self) -> dict[str, Any]:
        """
        计算 SCBench 分数，使用迁移的评分函数
        """
        self.logger.info("Computing SCBench scores...")

        # 按任务分组结果
        task_results: dict[str, list[dict]] = {}
        for result in self.all_results:
            task = result["task"]
            if task not in task_results:
                task_results[task] = []
            task_results[task].append(result)

        # 计算每个任务的分数
        summary = {
            "model_name": self.model_name,
            "tasks": {},
            "average": 0.0,
            "config": {
                "output_dir": str(self.output_dir),
            },
        }

        for task, results in task_results.items():
            # 映射任务名称（SCBench → InfiniteBench-style）
            task_name = SCBENCH_TO_INFINITEBENCH.get(task, task)

            # 计算每个样本的分数
            scores = []
            for result in results:
                pred = result["prediction"]
                label = result["ground_truth"]
                try:
                    score = get_score_one(pred, label, task_name, self.model_name)
                    scores.append(score)
                except Exception as e:
                    self.logger.warning(
                        f"Error scoring {result['id']} turn {result['turn_idx']}: {e}"
                    )
                    scores.append(0.0)

            # 计算平均分
            avg_score = sum(scores) / len(scores) if scores else 0.0

            summary["tasks"][task] = {
                "score": avg_score,
                "num_samples": self.task_stats[task]["total_samples"],
                "num_turns": self.task_stats[task]["total_turns"],
            }

            self.logger.info(f"  - {task}: {avg_score:.4f}")

        # 计算总平均分
        if summary["tasks"]:
            summary["average"] = sum(t["score"] for t in summary["tasks"].values()) / len(
                summary["tasks"]
            )

        return summary

    def _write_summary(self, summary: dict[str, Any]) -> None:
        """写 Summary JSON"""
        summary_path = self.output_dir / f"scbench_summary_{self.model_name}.json"
        self.logger.info(f"Writing summary: {summary_path}")

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)

        self.logger.info(f"  - Summary written to {summary_path}")

    def _print_stats(self, summary: dict[str, Any]) -> None:
        """打印统计信息"""
        self.logger.info("=" * 60)
        self.logger.info("SCBench Evaluation Summary")
        self.logger.info("=" * 60)
        self.logger.info(f"Model: {summary['model_name']}")
        self.logger.info(f"Average Score: {summary['average']:.4f}")
        self.logger.info("")
        self.logger.info("Task-wise Scores:")
        for task, metrics in summary["tasks"].items():
            self.logger.info(
                f"  - {task}: {metrics['score']:.4f} "
                f"({metrics['num_samples']} samples, {metrics['num_turns']} turns)"
            )
        self.logger.info("=" * 60)
