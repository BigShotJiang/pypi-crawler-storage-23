"""Utility functions for SCBench evaluation.

This module reuses core evaluation logic from the original SCBench repository
to ensure 100% alignment with paper results.

Migrated from:
- scbench/compute_scores.py (scoring metrics)
- scbench/repo_qa_utils.py (RepoQA-specific utils)
"""

from __future__ import annotations

import re
import string
from collections import Counter

import evaluate
import numpy as np
from nltk.translate.bleu_score import SmoothingFunction, sentence_bleu

# ROUGE scorer for summarization tasks
ROUGE_SCORER = evaluate.load("rouge")


# ========== Text Normalization ==========


def normalize_answer(s: str) -> str:
    """Lower text and remove punctuation, articles and extra whitespace."""

    def remove_articles(text):
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text):
        return " ".join(text.split())

    def remove_punc(text):
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def lower(text):
        return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def normalize_zh_answer(s: str) -> str:
    """Chinese version. Lower text and remove punctuation, extra whitespace."""

    def white_space_fix(text):
        return "".join(text.split())

    def remove_punc(text):
        cn_punctuation = (
            "！？｡。＂＃＄％＆＇（）＊＋，－／：；＜＝＞＠［＼］＾＿｀｛｜｝～｟｠｢｣､、〃》「」『』【】〔〕〖〗〘〙〚〛〜〝〞〟〰〾〿–—''‛"
            "„‟…‧﹏."
        )  # noqa
        all_punctuation = set(string.punctuation + cn_punctuation)
        return "".join(ch for ch in text if ch not in all_punctuation)

    def lower(text):
        return text.lower()

    return white_space_fix(remove_punc(lower(s)))


# ========== Scoring Functions ==========


def f1_score(prediction, ground_truth) -> tuple[float, float, float]:
    """Token-level F1 score."""
    common = Counter(prediction) & Counter(ground_truth)
    num_same = sum(common.values())
    if num_same == 0:
        return 0, 0, 0
    precision = 1.0 * num_same / len(prediction)
    recall = 1.0 * num_same / len(ground_truth)
    f1 = (2 * precision * recall) / (precision + recall)
    return f1, precision, recall


def qa_f1_score(pred: str, ground_truths) -> float:
    """Computes the F1 score for QA tasks."""
    f1 = 0
    for ground_truth in ground_truths:
        normalized_prediction = normalize_answer(pred)
        normalized_ground_truth = normalize_answer(ground_truth)

        prediction_tokens = normalized_prediction.split()
        ground_truth_tokens = normalized_ground_truth.split()
        scores = f1_score(prediction_tokens, ground_truth_tokens)
        this_f1, _, _ = scores
        f1 = max(f1, this_f1)
    return f1


def qa_f1_score_zh(pred: str, ground_truths: list[str]) -> float:
    """QA F1 score for Chinese (character-level)."""
    f1 = 0
    for ground_truth in ground_truths:
        norm_pred = normalize_zh_answer(pred)
        norm_label = normalize_zh_answer(ground_truth)

        # One character one token
        pred_tokens = list(norm_pred)
        label_tokens = list(norm_label)
        scores = f1_score(pred_tokens, label_tokens)
        this_f1, _, _ = scores
        f1 = max(f1, this_f1)
    return f1


def string_match_all(pred, ref, model_name=""):
    """Check if all reference strings are in the prediction."""
    score = sum([1.0 if r.lower() in pred.lower() else 0.0 for r in ref]) / len(ref)
    return round(score, 2)


def first_int_match(prediction):
    """Extract the first integer from prediction."""
    pred_list = re.split("[^0-9]", prediction)
    pred_value = ""
    for item in pred_list:
        if item != "":
            pred_value = item
            break
    return pred_value


# ========== Task-Specific Scoring Functions ==========


def get_score_one_passkey(pred, label, model_name: str) -> bool:
    """Passkey retrieval: exact integer match."""
    if isinstance(label, list):
        label = label[0]
    return label == first_int_match(pred)


def get_score_one_kv_retrieval(pred, label, model_name: str) -> bool:
    """KV retrieval: substring containment check."""
    return label in pred


def get_score_one_longdialogue_qa_eng(pred, label, model_name: str) -> bool:
    """Long dialogue QA: uppercase substring match."""
    pred = pred.strip().upper()
    for item in label:
        if item.upper() in pred:
            return 1
    return 0


def get_score_one_longbook_choice_eng(pred, label, model_name: str) -> bool:
    """Multiple choice: option matching (A/B/C/D)."""
    pred = pred.strip()
    if pred == "":
        return False
    if pred[0] in "ABCD":
        return pred[0] in label
    if pred in label:
        return True

    # Clean and find answer
    for c in ["\n", '"', "'", ".", ",", "?", "!", "{", "}"]:
        pred = pred.replace(c, " ")
    while "  " in pred:
        pred = pred.replace("  ", " ")

    ans_prefixes = ["answer is:", "answer:", "answer is", "option is"]
    for prefix in ans_prefixes:
        idx = pred.find(prefix)
        if idx == -1:
            continue
        if len(pred) < idx + len(prefix) + 1:
            return False
        after_prefix = pred[idx + len(prefix) + 1 :]
        for s in label:
            if after_prefix.startswith(s):
                return True
        return False

    # Find first A/B/C/D
    words = pred.split()
    for word in words:
        if word in "ABCD":
            return word in label
    return False


def get_score_one_longbook_qa_eng(pred, label, model_name: str) -> float:
    """Long book QA: F1 score."""
    return qa_f1_score(pred, label)


def get_score_one_longbook_sum_eng(pred: str, label: str, model_name: str) -> float:
    """Long book summarization: ROUGE-Lsum."""
    score = ROUGE_SCORER.compute(predictions=[pred], references=[label], use_aggregator=False)
    return score["rougeLsum"][0]


def get_score_one_longbook_qa_chn(pred, label, model_name: str) -> float:
    """Long book QA (Chinese): character-level F1."""
    return qa_f1_score_zh(pred, label)


def get_score_one_math_find(pred, label, model_name: str) -> bool:
    """Math find: extract first number and match."""
    if isinstance(label, list):
        label = label[0]
    if isinstance(label, int):
        first_num = re.search(r"\d+\.\d+|\d+", pred)
        if first_num is None:
            return False
        first_num = first_num.group(0).strip()
        return int(float(first_num)) == label
    elif isinstance(label, float):
        first_float = re.search(r"\d+\.\d+|\d+", pred)
        if first_float is None:
            return False
        first_float = first_float.group(0).strip()
        return float(first_float) == label
    else:
        raise TypeError(f"Expected int or float, got {type(label)}")


def get_score_one_math_calc(pred, label, model_name: str) -> float:
    """Math calculation: sequence of integers match."""
    assert isinstance(label, list), f"Expected list, got {type(label)}"
    pred_nums = []
    pred_list = re.split("[^0-9]", pred)
    for item in pred_list:
        if item != "":
            pred_nums.append(int(item))

    # GPT4 always outputs the first number as prefix
    if model_name == "gpt4":
        pred_nums = pred_nums[1:]

    cnt = 0
    for i in range(len(label)):
        if i >= len(pred_nums):
            break
        if label[i] == pred_nums[i]:
            cnt += 1
        else:
            break
    return cnt / len(label)


def get_score_one_code_run(pred, label, model_name: str) -> bool:
    """Code execution result: extract last integer."""
    if isinstance(label, list):
        label = label[0]
    pred = pred.strip()
    for c in ["\n", ".", "`", "'", '"', ":"]:
        pred = pred.replace(c, " ")
    words = pred.split()
    if len(words) == 0:
        return False
    try:
        pred = int(words[-1])
        return label == pred
    except Exception:
        return False


def get_score_one_code_debug(pred, label, model_name: str) -> bool:
    """Code debugging: extract error location."""
    pred = pred.strip()
    label_c = label[1]
    fn_name = label[0]
    if pred[:2] in [f"{label_c}.", f"{label_c}:"]:
        return True

    ans_prefixes = ["answer is:", "is:", "answer:"]
    for c in ["\n", "`", "'", '"', "-", "*", "Option", "option"]:
        pred = pred.replace(c, " ")
    while "  " in pred:
        pred = pred.replace("  ", " ")
    for prefix in ans_prefixes:
        idx = pred.find(prefix)
        if idx == -1:
            continue
        if len(pred) < idx + len(prefix) + 1:
            return False
        pred = pred[idx + len(prefix) + 1 :]
        for s in [label_c, fn_name]:
            if pred.startswith(s):
                return True
        return False
    return False


def get_score_one_number_string(pred, label, model_name: str) -> bool:
    """Number string: exact match."""
    if isinstance(label, list):
        label = label[0]
    return label == first_int_match(pred)


# ========== RepoQA Utils (Simplified) ==========


def compute_function_similarity(candidate_function: str, reference_function: str) -> float:
    """Compute BLEU-based similarity between two functions."""
    candidate_tokens = [item for item in re.split(r"\s+", candidate_function.strip())]
    reference_tokens = [item for item in re.split(r"\s+", reference_function.strip())]
    chencherry = SmoothingFunction()
    return sentence_bleu(
        [reference_tokens], candidate_tokens, smoothing_function=chencherry.method4
    )


def estimate_pass_at_k(
    num_samples: int | list[int] | np.ndarray,
    num_correct: list[int] | np.ndarray,
    k: int,
) -> np.ndarray:
    """Unbiased estimator for pass@k from OpenAI Human-Eval."""

    def estimator(n: int, c: int, k: int) -> float:
        if n - c < k:
            return 1.0
        return 1.0 - np.prod(1.0 - k / np.arange(n - c + 1, n + 1))

    if isinstance(num_samples, int):
        import itertools

        num_samples_it = itertools.repeat(num_samples, len(num_correct))
    else:
        assert len(num_samples) == len(num_correct)
        num_samples_it = iter(num_samples)

    return np.array([estimator(int(n), int(c), k) for n, c in zip(num_samples_it, num_correct)])


def compute_repoqa_score_simple(preds: list, labels: list, needle_by_repo: dict) -> float:
    """Simplified RepoQA scoring (BLEU-based similarity > 0.8)."""
    correct = 0
    total = len(preds)

    for pred_item, label in zip(preds, labels):
        pred = pred_item.get("prediction", "")
        # Compute similarity
        similarity = compute_function_similarity(pred, label)
        if similarity > 0.8:  # Default threshold
            correct += 1

    return correct / total if total > 0 else 0.0


# ========== Main Scoring Dispatcher ==========


def get_score_one(pred: str, label: str, task_name: str, model_name: str) -> float:
    """
    Computes the score for one prediction.
    Returns one float (zero and one for boolean values).
    """
    NAME_TO_SCORE_GETTER = {
        # Retrieve
        "kv_retrieval": get_score_one_kv_retrieval,
        "kv_retrieval_prefix": get_score_one_kv_retrieval,
        "kv_retrieval_both": get_score_one_kv_retrieval,
        "passkey": get_score_one_passkey,
        "number_string": get_score_one_number_string,
        # Code
        "code_run": get_score_one_code_run,
        "code_debug": get_score_one_code_debug,
        # Longbook
        "longdialogue_qa_eng": get_score_one_longdialogue_qa_eng,
        "longbook_qa_eng": get_score_one_longbook_qa_eng,
        "longbook_sum_eng": get_score_one_longbook_sum_eng,
        "longbook_choice_eng": get_score_one_longbook_choice_eng,
        "longbook_qa_chn": get_score_one_longbook_qa_chn,
        # Math
        "math_find": get_score_one_math_find,
        "math_calc": get_score_one_math_calc,
        # SCBench-specific
        "scbench_summary": get_score_one_longbook_sum_eng,
        "scbench_vt": string_match_all,
        "scbench_many_shot": get_score_one_longdialogue_qa_eng,
        "scbench_kv_compressible": get_score_one_kv_retrieval,
    }
    assert task_name in NAME_TO_SCORE_GETTER, f"Invalid task name: {task_name}"
    score = NAME_TO_SCORE_GETTER[task_name](pred, label, model_name)
    return float(score)


# ========== Task Mapping ==========

# Mapping from SCBench task names to InfiniteBench-style task names
SCBENCH_TO_INFINITEBENCH = {
    "scbench_choice_eng": "longbook_choice_eng",
    "scbench_qa_eng": "longdialogue_qa_eng",
    "scbench_qa_chn": "longbook_qa_chn",
    "scbench_kv": "kv_retrieval",
    "scbench_kv_hard": "kv_retrieval",
    "scbench_hashhop": "kv_retrieval",
    "scbench_prefix_suffix": "kv_retrieval",
    "scbench_mf": "math_find",
    "scbench_passkey": "passkey",
}
