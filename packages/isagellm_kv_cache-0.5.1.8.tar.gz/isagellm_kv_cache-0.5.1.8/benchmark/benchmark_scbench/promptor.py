"""SCBench prompt constructor.

This module handles:
- Multi-Turn prompt construction (with golden answers)
- SCDQ prompt construction (independent queries)
- Middle Truncation (token-level truncation)
- Chat Template application
- Refiner integration (uses compressed context if available)
"""

import json
from pathlib import Path
from typing import Any

from sage.common.core.functions import MapFunction as MapOperator

from .constants import SCDQ_SEPARATOR


class SCBenchPromptor(MapOperator):
    """
    SCBench 专用 Promptor

    根据评测模式（Multi-Turn/SCDQ）构造不同风格的 prompts：
    - Multi-Turn: 累积历史对话 + golden answers
    - SCDQ: 分离 context 和 queries（模拟 KV Cache 复用）

    核心功能：
    1. 根据 _eval_mode 选择 prompt 构造策略
    2. Middle Truncation（token 级中间截断）
    3. Chat Template 支持（可选）
    4. Refiner 集成钩子（优先使用压缩后的 context）

    Config Keys:
        max_input_tokens: int - 最大输入 token 数（默认 128000）
        use_chat_template: bool - 是否使用 chat template（默认 False）
        model_name_or_path: str - 模型路径，用于加载 tokenizer
        truncation_manner: str - 截断方式，"middle"（默认）| "head" | "tail"
    """

    # 配置文件缓存
    _prompt_templates: dict[str, str] | None = None

    @classmethod
    def _load_configs(cls) -> None:
        """延迟加载 JSON 配置文件"""
        if cls._prompt_templates is None:
            config_dir = Path(__file__).parent / "config"
            with open(config_dir / "dataset2prompt.json", encoding="utf-8") as f:
                cls._prompt_templates = json.load(f)

    def __init__(self, config: dict[str, Any], **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._load_configs()

        self.config = config
        self.max_input_tokens: int = config.get("max_input_tokens", 128000)
        self.use_chat_template: bool = config.get("use_chat_template", False)
        self.model_name: str = config.get("model_name_or_path", "")
        self.truncation_manner: str = config.get("truncation_manner", "middle")

        # 延迟加载 tokenizer
        self._tokenizer: Any | None = None

        self.logger.info("SCBenchPromptor initialized:")
        self.logger.info(f"  - max_input_tokens: {self.max_input_tokens}")
        self.logger.info(f"  - use_chat_template: {self.use_chat_template}")
        self.logger.info(f"  - truncation_manner: {self.truncation_manner}")

    @property
    def tokenizer(self) -> Any | None:
        """延迟加载 tokenizer"""
        if self._tokenizer is None and self.model_name:
            try:
                from transformers import AutoTokenizer

                self._tokenizer = AutoTokenizer.from_pretrained(
                    self.model_name, trust_remote_code=True
                )
                self.logger.info(f"Loaded tokenizer from {self.model_name}")
            except Exception as e:
                self.logger.warning(f"Failed to load tokenizer: {e}")
        return self._tokenizer

    def execute(self, data: dict[str, Any]) -> list[dict[str, Any]]:
        """
        根据评测模式构造 prompts（每轮单独输出）

        Input (来自 Batch 或 Refiner):
            {
                "context": str,                  # 原始上下文
                "refining_results": List[str],   # 压缩后的上下文（可选）
                "multi_turns": List[Dict],       # Multi-Turn 模式
                "queries": List[str],            # SCDQ 模式
                "answers": List[str],            # 答案列表
                "task": str,                     # 任务名称
                "_eval_mode": "multi_turn" | "scdq",
                "_raw_example": dict,            # 原始数据
            }

        Output (Multi-Turn 模式):
            返回多个独立的输出，每个对应一轮：
            [
                {
                    "prompt": str,               # 单个 prompt（已截断）
                    "ground_truth": str,         # 对应答案
                    "turn_idx": int,             # 轮次索引
                    **data                       # 原始数据传递
                },
                ...  # 5 轮
            ]

        Output (SCDQ 模式):
            返回单个输出（包含所有 queries）:
            [
                {
                    "prompts": List[str],        # [context, query1, query2, ...]
                    "ground_truths": List[str],  # 对应答案
                    "_scdq_context_split": int,  # context 部分索引
                    **data                       # 原始数据传递
                }
            ]
        """
        eval_mode = data.get("_eval_mode", "multi_turn")

        self.logger.info(
            f"Promptor execute: eval_mode={eval_mode}, task={data.get('task')}, id={data.get('id')}"
        )

        # 1. 选择上下文（优先使用 Refiner 输出）
        context = self._get_context(data)

        # 2. 根据模式构造 prompts
        if eval_mode == "scdq":
            # SCDQ 模式：一次性返回所有 prompts
            prompts, ground_truths = self._create_scdq_prompts(data, context)
            result = {
                "prompts": prompts,
                "ground_truths": ground_truths,
                "_scdq_context_split": 1,  # 标记第 1 个是 context
                "task": data.get("task", ""),
                "_eval_mode": eval_mode,
                # 不传递原始 context，避免发送未截断的数据
            }
            return [result]
        else:
            # Multi-Turn 模式：每轮单独返回
            # 返回格式需要兼容 Generator 期望的 [data, prompt] 格式
            prompts, ground_truths = self._create_multiturn_prompts(data, context)
            multi_turns = data.get("multi_turns", [])
            results = []
            for idx, (prompt, ground_truth) in enumerate(zip(prompts, ground_truths)):
                # 获取原始 turn 数据（包含 options 等额外字段）
                original_turn = multi_turns[idx] if idx < len(multi_turns) else {}
                turn_data = {
                    "ground_truth": ground_truth,
                    "turn_idx": idx,
                    "task": data.get("task", ""),
                    "id": data.get("id", ""),
                    "_eval_mode": eval_mode,
                    "query": prompt,  # 添加 prompt 文本供 Generator 记录
                    "references": [ground_truth],  # 添加 references 列表供 Generator 记录
                    # 保留原始 turn 字段（如 options），排除已处理的字段
                    **{
                        k: v
                        for k, v in original_turn.items()
                        if k not in ["turn_idx", "input", "answer", "question"]
                    },
                    # 不传递原始 context，避免发送未截断的数据
                }
                # Generator 期望 [data, prompt] 格式
                results.append([turn_data, prompt])

            self.logger.info(
                f"Promptor返回 {len(results)} 轮数据: {[r[0]['turn_idx'] for r in results]}"
            )
            return results

    def _get_context(self, data: dict[str, Any]) -> str:
        """获取上下文（优先使用 Refiner 压缩后的结果）"""
        refining_results = data.get("refining_results", [])
        if refining_results and len(refining_results) > 0:
            self.logger.debug("Using compressed context from Refiner")
            return refining_results[0]  # 取第一个压缩结果
        return data.get("context", "")

    def _create_multiturn_prompts(
        self, data: dict[str, Any], context: str
    ) -> tuple[list[str], list[str]]:
        """
        创建 Multi-Turn 风格的 prompts（历史累积 + golden answers）

        每轮 prompt 包含：
        - Context（共享）
        - Query1 + GoldenAns1 + Query2 + GoldenAns2 + ... + QueryN

        特点：使用 golden answer 避免错误累积
        """
        task = data.get("task", "")
        multi_turns = data.get("multi_turns", [])
        raw_example = data.get("_raw_example", {})

        self.logger.info(f"_create_multiturn_prompts: task={task}, turns={len(multi_turns)}")

        # 获取任务模板
        template = self._prompt_templates.get(task, "{context}\n\n{input}")
        self.logger.debug(f"Using template: {template[:100]}...")

        prompts = []
        ground_truths = []

        # 构建累积的对话历史
        conversation_history = ""

        for turn in multi_turns:
            turn_idx = turn["turn_idx"]
            query = turn["input"]
            answer = turn["answer"]

            # 填充模板（首轮）
            if turn_idx == 0:
                # 处理特殊任务字段（如 scbench_choice_eng 的 options）
                if task == "scbench_choice_eng":
                    # scbench_choice_eng 模板只用 {context} 和 {input}
                    # query 本身已经包含问题和选项
                    prompt = template.format(
                        context=context,
                        input=query,  # 使用 input 而不是 question
                    )
                elif task in ["scbench_qa_eng", "scbench_qa_chn"]:
                    prompt = template.format(context=context, input=query)
                else:
                    # 所有其他任务（包括 scbench_mf）统一使用 {context} 和 {input}
                    prompt = template.format(context=context, input=query)
            else:
                # 后续轮次：追加历史（Query + GoldenAnswer）
                prompt = conversation_history + f"\n\n{query}"

            # 应用 Chat Template（可选）
            if self.use_chat_template:
                prompt = self._apply_chat_template(prompt)

            # Middle Truncation
            prompt = self._truncate(prompt)

            prompts.append(prompt)
            ground_truths.append(answer)

            # 更新对话历史（添加当前轮的 golden answer）
            conversation_history = prompt + f"\n{answer}"

        self.logger.info(f"Generated {len(prompts)} prompts for task {task}")

        return prompts, ground_truths

    def _create_scdq_prompts(
        self, data: dict[str, Any], context: str
    ) -> tuple[list[str], list[str]]:
        """
        创建 SCDQ 风格的 prompts（共享 context + 独立 queries）

        返回格式：[Context_Prompt, Query1_Prompt, Query2_Prompt, ...]
        - Context_Prompt: 只包含 context 部分
        - Query_Prompt: 独立的 query（不包含历史）

        特点：模拟 KV Cache 复用（context 只传一次）
        """
        task = data.get("task", "")
        queries = data.get("queries", [])
        answers = data.get("answers", [])
        raw_example = data.get("_raw_example", {})

        # 获取任务模板
        template = self._prompt_templates.get(task, "{context}\n\n{input}")

        # 1. 构造 Context Prompt
        context_prompt = template.format(context=context, input="")

        # 应用 Chat Template（SCDQ 特殊处理）
        if self.use_chat_template:
            context_prompt = self._apply_chat_template_scdq_context(context_prompt)

        # Truncate context
        context_prompt = self._truncate(context_prompt)

        # 2. 构造 Query Prompts（独立）
        query_prompts = []
        for query in queries:
            query_prompt = query

            # 应用 Chat Template
            if self.use_chat_template:
                query_prompt = self._apply_chat_template_scdq_query(query_prompt)

            query_prompts.append(query_prompt)

        # 返回 [context, query1, query2, ...]
        prompts = [context_prompt] + query_prompts
        return prompts, answers

    def _truncate(self, text: str) -> str:
        """Middle Truncation（token 级截断）"""
        if not self.tokenizer:
            self.logger.warning(
                f"Tokenizer not loaded, skipping truncation (text length: {len(text)} chars)"
            )
            return text

        # Encode
        tokens = self.tokenizer.encode(text, add_special_tokens=False)

        # 判断是否需要截断
        if len(tokens) <= self.max_input_tokens:
            self.logger.debug(f"No truncation needed: {len(tokens)} <= {self.max_input_tokens}")
            return text

        # 截断逻辑（与 run_scbench.py 保持一致）
        if self.truncation_manner == "middle":
            split = self.max_input_tokens // 2
            truncated_tokens = tokens[:split] + tokens[-split:]
        elif self.truncation_manner == "head":
            truncated_tokens = tokens[: self.max_input_tokens]
        elif self.truncation_manner == "tail":
            truncated_tokens = tokens[-self.max_input_tokens :]
        else:
            raise ValueError(f"Unknown truncation manner: {self.truncation_manner}")

        # Decode
        truncated_text = self.tokenizer.decode(truncated_tokens, skip_special_tokens=True)

        self.logger.info(
            f"Truncated from {len(tokens)} to {len(truncated_tokens)} tokens (manner={self.truncation_manner})"
        )

        return truncated_text

    def _apply_chat_template(self, text: str) -> str:
        """应用 Chat Template（Multi-Turn 模式）"""
        if not self.tokenizer:
            return text

        try:
            return self.tokenizer.apply_chat_template(
                [{"role": "user", "content": text}],
                add_generation_prompt=True,
                tokenize=False,
            )
        except Exception as e:
            self.logger.warning(f"Failed to apply chat template: {e}")
            return text

    def _apply_chat_template_scdq_context(self, context: str) -> str:
        """SCDQ 模式：Context 部分的 Chat Template"""
        if not self.tokenizer:
            return context

        try:
            # 使用特殊分隔符，然后分割
            full_prompt = self.tokenizer.apply_chat_template(
                [{"role": "user", "content": context + SCDQ_SEPARATOR}],
                add_generation_prompt=True,
                tokenize=False,
            )
            return full_prompt.split(SCDQ_SEPARATOR)[0]
        except Exception as e:
            self.logger.warning(f"Failed to apply chat template: {e}")
            return context

    def _apply_chat_template_scdq_query(self, query: str) -> str:
        """SCDQ 模式：Query 部分的 Chat Template"""
        if not self.tokenizer:
            return query

        try:
            # 使用特殊分隔符，然后分割
            full_prompt = self.tokenizer.apply_chat_template(
                [
                    {"role": "system", "content": ""},
                    {"role": "user", "content": SCDQ_SEPARATOR + query},
                ],
                add_generation_prompt=True,
                tokenize=False,
            )
            return full_prompt.split(SCDQ_SEPARATOR)[1]
        except Exception as e:
            self.logger.warning(f"Failed to apply chat template: {e}")
            return query
