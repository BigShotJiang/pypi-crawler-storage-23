"""SCBench data batch loader.

This module handles loading SCBench data from Hugging Face and formatting
it for the SAGE RAG pipeline. Supports two evaluation modes:

1. Multi-Turn: Conversation history with golden answers
2. SCDQ: Same context with independent queries

Data Source: https://huggingface.co/datasets/microsoft/SCBench
"""

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from sage.common.core import BatchFunction


class SCBenchBatch(BatchFunction):
    """
    SCBench 数据集批处理函数

    从 Hugging Face 自动下载并加载 SCBench 数据，支持两种评测模式：
    - Multi-Turn: 多轮对话累积（带 golden answers）
    - SCDQ: 共享上下文 + 独立查询（模拟 KV Cache 复用）

    Config Keys:
        data_dir: str - SCBench 数据目录路径
        task: str - 任务名称，如 "scbench_kv" 或 "scbench_kv,scbench_qa_eng"（多任务）
        scdq_mode: bool - true=SCDQ模式, false=Multi-Turn模式
        max_samples: int - 最大样本数，-1 表示全部
        start_idx: int - 起始样本索引（用于分布式评测）
        stop_idx: int - 结束样本索引，-1 表示到末尾

    Output Fields (Multi-Turn 模式):
        id: str - 样本唯一标识
        context: str - 共享上下文
        multi_turns: List[Dict] - 多轮查询，每轮包含 turn_idx, input, answer
        task: str - 任务名称
        _eval_mode: str - "multi_turn"

    Output Fields (SCDQ 模式):
        id: str - 样本唯一标识
        context: str - 共享上下文
        queries: List[str] - 独立查询列表
        answers: List[str] - 对应答案列表
        task: str - 任务名称
        _eval_mode: str - "scdq"
    """

    # 任务名称到文件名映射（与 eval_utils.py 保持一致）
    DATA_NAME_TO_PATH = {
        "scbench_choice_eng": "scbench_choice_eng.jsonl",
        "scbench_qa_eng": "scbench_qa_eng.jsonl",
        "scbench_qa_chn": "scbench_qa_chn.jsonl",
        "scbench_kv": "scbench_kv.jsonl",
        "scbench_kv_hard": "scbench_kv_hard.jsonl",
        "scbench_mf": "scbench_mf.jsonl",
        "scbench_passkey": "scbench_passkey.jsonl",
        "scbench_repoqa": "scbench_repoqa.jsonl",
        "scbench_summary": "scbench_summary.jsonl",
        "scbench_vt": "scbench_vt.jsonl",
        "scbench_many_shot": "scbench_many_shot.jsonl",
        "scbench_summary_with_needles": "scbench_summary_with_needles.jsonl",
        "scbench_repoqa_and_kv": "scbench_repoqa_and_kv.jsonl",
        "scbench_hashhop": "scbench_hashhop.jsonl",
        "scbench_prefix_suffix": "scbench_prefix_suffix.jsonl",
        "scbench_kv_compressible": "scbench_kv_compressible.jsonl",
    }

    def __init__(self, config: dict | None = None, **kwargs):
        super().__init__(config, **kwargs)

        # 确保 config 存在
        if not hasattr(self, "config"):
            self.config = config or {}

        # 解析配置 - 支持 HF datasets 或本地文件
        self.hf_dataset_name = self.config.get("hf_dataset_name")
        self.hf_dataset_config = self.config.get("hf_dataset_config")
        self.hf_split = self.config.get("hf_split")
        self.data_dir = self.config.get("data_dir")
        self.task = self.config.get("task")

        # 严格验证：不再向前兼容，配置不全直接报错
        if self.hf_dataset_name:
            if not self.hf_dataset_config:
                raise ValueError("hf_dataset_config is required when using hf_dataset_name")
            if not self.hf_split:
                raise ValueError("hf_split is required when using hf_dataset_name")
            self.task_name = self.hf_dataset_config
        else:
            if not self.data_dir:
                raise ValueError("data_dir is required when not using HF dataset")
            if not self.task:
                raise ValueError("task is required when not using HF dataset")
            self.task_name = self.task

        self.scdq_mode = self.config.get("scdq_mode", False)
        self.max_samples = self.config.get("max_samples", -1)
        self.start_idx = self.config.get("start_idx", 0)
        self.stop_idx = self.config.get("stop_idx", -1)

        # 解析任务列表（支持多任务，仅用于本地模式）
        self.tasks = [t.strip() for t in self.task_name.split(",")]

        # 初始化迭代器状态
        self._iterator = None
        self._sample_count = 0

        self.logger.info("SCBenchBatch initialized:")
        if self.hf_dataset_name:
            self.logger.info(f"  - HF Dataset: {self.hf_dataset_name}")
            self.logger.info(f"  - HF Config: {self.hf_dataset_config}")
            self.logger.info(f"  - HF Split: {self.hf_split}")
        else:
            self.logger.info(f"  - Data dir: {self.data_dir}")
        self.logger.info(f"  - Tasks: {self.tasks}")
        self.logger.info(f"  - Mode: {'SCDQ' if self.scdq_mode else 'Multi-Turn'}")
        self.logger.info(f"  - Max samples: {self.max_samples}")
        self.logger.info(f"  - Range: [{self.start_idx}, {self.stop_idx})")

    def execute(self) -> dict[str, Any] | None:
        """
        执行批处理，每次返回一个数据项（BatchFunction 必须实现）

        Returns:
            dict: 下一个数据样本
            None: 数据已耗尽，触发停止信号
        """
        # 懒加载：首次调用时初始化迭代器
        if self._iterator is None:
            self._iterator = self._build_iter()

        try:
            return next(self._iterator)
        except StopIteration:
            return None  # 触发 BatchOperator 发送停止信号

    def __iter__(self) -> Iterator[dict[str, Any]]:
        """支持 for sample in batch 语法"""
        return self._build_iter()

    def _build_iter(self) -> Iterator[dict[str, Any]]:
        """构建数据集迭代器"""
        # 如果配置了 HF dataset，使用 HF datasets 加载
        if self.hf_dataset_name:
            self.logger.info(
                f"Loading from HF dataset: {self.hf_dataset_name}/{self.hf_dataset_config}"
            )
            data = self._load_hf_dataset()
            task_name = self.task_name
        else:
            # 否则使用原有的 JSONL 逻辑（支持多任务）
            for task_name in self.tasks:
                self.logger.info(f"Loading task: {task_name}")
                data = self._load_jsonl(task_name)

                # 应用索引范围
                end_idx = len(data) if self.stop_idx == -1 else min(self.stop_idx, len(data))
                data = data[self.start_idx : end_idx]

                self.logger.info(f"  - Loaded {len(data)} samples for {task_name}")

                # 转换并生成样本
                for idx, example in enumerate(data):
                    if self.max_samples > 0 and self._sample_count >= self.max_samples:
                        self.logger.info(f"Reached max_samples limit: {self.max_samples}")
                        return

                    # 根据模式格式化样本
                    if self.scdq_mode:
                        formatted = self._format_scdq(example, task_name, idx)
                    else:
                        formatted = self._format_multiturn(example, task_name, idx)

                    yield formatted
                    self._sample_count += 1
            return

        # HF dataset 路径：统一处理
        # 应用索引范围
        end_idx = len(data) if self.stop_idx == -1 else min(self.stop_idx, len(data))
        data = data[self.start_idx : end_idx]

        self.logger.info(f"  - Loaded {len(data)} samples for {task_name}")

        # 转换并生成样本
        for idx, example in enumerate(data):
            if self.max_samples > 0 and self._sample_count >= self.max_samples:
                self.logger.info(f"Reached max_samples limit: {self.max_samples}")
                return

            # 根据模式格式化样本
            if self.scdq_mode:
                formatted = self._format_scdq(example, task_name, idx)
            else:
                formatted = self._format_multiturn(example, task_name, idx)

            yield formatted
            self._sample_count += 1

    def _load_hf_dataset(self) -> list[dict]:
        """从 HuggingFace datasets 加载数据"""
        try:
            from datasets import load_dataset
        except ImportError:
            raise ImportError("Please install datasets: pip install datasets")

        self.logger.info(
            f"Loading dataset: {self.hf_dataset_name}, config: {self.hf_dataset_config}, split: {self.hf_split}"
        )
        dataset = load_dataset(
            self.hf_dataset_name,
            self.hf_dataset_config,
            split=self.hf_split,
            trust_remote_code=True,
        )

        # 转换为list
        data = [dict(example) for example in dataset]
        return data

    def _load_jsonl(self, task_name: str) -> list[dict]:
        """从 JSONL 文件加载数据，如果不存在则从 Hugging Face 下载"""
        if task_name not in self.DATA_NAME_TO_PATH:
            raise ValueError(f"Unknown task: {task_name}")

        file_name = self.DATA_NAME_TO_PATH[task_name]
        file_path = Path(self.data_dir) / file_name

        # 如果文件不存在，从 Hugging Face 下载
        if not file_path.exists():
            self.logger.info("Data file not found locally, downloading from Hugging Face...")
            self._download_from_huggingface(task_name, file_path)

        # 加载 JSONL 数据
        data = []
        with open(file_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    data.append(json.loads(line))

        return data

    def _download_from_huggingface(self, task_name: str, file_path: Path) -> None:
        """从 Hugging Face 下载 SCBench 数据文件"""
        # 创建数据目录
        file_path.parent.mkdir(parents=True, exist_ok=True)

        file_name = self.DATA_NAME_TO_PATH[task_name]
        base_url = "https://huggingface.co/datasets/microsoft/SCBench/resolve/main/data/"
        download_url = f"{base_url}{file_name}?download=true"

        self.logger.info(f"Downloading {task_name} from: {download_url}")

        # 使用 wget 下载（与原 SCBench 代码保持一致）
        import subprocess

        cmd = ["wget", "-c", download_url, "-O", str(file_path)]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            raise RuntimeError(
                f"Failed to download {task_name} from Hugging Face:\n{result.stderr}"
            )

        self.logger.info(f"Successfully downloaded: {file_path}")

    def _format_multiturn(self, example: dict, task_name: str, idx: int) -> dict[str, Any]:
        """格式化为 Multi-Turn 模式（历史对话累积 + golden answers）

        Multi-Turn 特点：
        - 每轮包含历史轮次的 golden answer
        - Prompt 构造: Context + Q1 + GoldenA1 + Q2 + GoldenA2 + Q3 → Pred3
        """
        # 提取 context（不同任务字段名可能不同）
        context = example.get("context", example.get("prefix", ""))

        # 提取多轮对话
        multi_turns = example.get("multi_turns", [])

        # 构造 multi_turns 列表（标准化格式）
        formatted_turns = []
        for turn_idx, turn in enumerate(multi_turns):
            formatted_turns.append(
                {
                    "turn_idx": turn_idx,
                    "input": turn.get("input", turn.get("question", "")),
                    "answer": turn.get("answer", ""),
                    # 保留原始字段（如 options）供后续使用
                    **{k: v for k, v in turn.items() if k not in ["input", "answer", "question"]},
                }
            )

        return {
            "id": f"{task_name}_{idx}",
            "context": context,
            "multi_turns": formatted_turns,
            "task": task_name,
            "_eval_mode": "multi_turn",
            # 保留原始数据供 Promptor 使用
            "_raw_example": example,
        }

    def _format_scdq(self, example: dict, task_name: str, idx: int) -> dict[str, Any]:
        """格式化为 SCDQ 模式（共享上下文 + 独立查询）

        SCDQ 特点：
        - 每轮只追加 Query，不包含历史答案
        - Prompt 构造: [Context, Query1, Query2, Query3]（分离）
        - 模拟 KV Cache 复用场景
        """
        # 提取 context
        context = example.get("context", example.get("prefix", ""))

        # 提取多轮对话
        multi_turns = example.get("multi_turns", [])

        # 构造 queries 和 answers 列表
        queries = []
        answers = []
        for turn in multi_turns:
            queries.append(turn.get("input", turn.get("question", "")))
            answers.append(turn.get("answer", ""))

        return {
            "id": f"{task_name}_{idx}",
            "context": context,
            "queries": queries,
            "answers": answers,
            "task": task_name,
            "_eval_mode": "scdq",
            # 保留原始数据供 Promptor 使用
            "_raw_example": example,
        }
