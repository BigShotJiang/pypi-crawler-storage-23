# @test:skip           - 跳过测试

"""
Baseline SCBench Pipeline (Local vLLM)
======================================

使用本地 vLLM Python API 的 SCBench pipeline。
不使用任何压缩/refine算法，用于对比实验。

特点：
- 使用 VLLMDirectGenerator（Python API）
- 支持 Multi-Turn 和 SCDQ 两种模式
- SCDQ 模式支持 KV Cache 复用（通过 vLLM Automatic Prefix Caching）
- 需要本地 GPU（推荐 A100 或多卡 3090）

如需远程 API 访问，使用 baseline_scbench.py
"""

import logging
import os
import sys

# 添加项目根目录到 Python 路径
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 禁用 httpx 的 INFO 日志
logging.getLogger("httpx").setLevel(logging.WARNING)

from sage.common.utils.config.loader import load_config
from sage.common.utils.logging.custom_logger import CustomLogger
from sage.kernel.api.local_environment import LocalEnvironment

from benchmark.benchmark_scbench import (
    SCBenchBatch,
    SCBenchEvaluator,
    SCBenchPromptor,
    VLLMDirectGenerator,
)


def pipeline_run(config):
    """运行 Baseline SCBench pipeline（本地 vLLM）"""
    env = LocalEnvironment()

    (
        env.from_batch(SCBenchBatch, config["source"])
        # SCBench 自带 context，不需要 Retriever
        # Baseline: 不使用任何 Refiner
        .map(SCBenchPromptor, config["promptor"])
        .map(VLLMDirectGenerator, config["generator"]["vllm_direct"])  # 🔥 本地 vLLM
        .map(SCBenchEvaluator, config["evaluate"])
    )

    env.submit(autostop=True)


# ==========================================================
if __name__ == "__main__":
    CustomLogger.disable_global_console_debug()

    if os.getenv("SAGE_EXAMPLES_MODE") == "test" or os.getenv("SAGE_TEST_MODE") == "true":
        print("🧪 Test mode detected - SCBench Baseline pipeline (Local)")
        print("✅ Test passed: Example structure validated")
        sys.exit(0)

    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config_baseline.yaml")

    if not os.path.exists(config_path):
        print(f"❌ Configuration file not found: {config_path}")
        sys.exit(1)

    config = load_config(config_path)

    print("🚀 Starting Baseline SCBench Pipeline (Local vLLM)...")
    print(f"📊 Task: {config['source'].get('task', 'N/A')}")
    print(f"📈 Mode: {'SCDQ' if config['source'].get('scdq_mode', False) else 'Multi-Turn'}")
    print(f"📈 Max samples: {config['source'].get('max_samples', 'All')}")
    print(f"🤖 Model: {config['generator']['vllm_direct']['model_name']}")
    print("=" * 60)

    pipeline_run(config)
