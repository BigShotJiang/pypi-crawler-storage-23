"""Constants and configuration mappings for SCBench tasks."""

from typing import Final

# Task name to max_new_tokens mapping (from SCBench original repo)
DATA_NAME_TO_MAX_NEW_TOKENS: Final[dict[str, int]] = {
    "scbench_kv": 40,
    "scbench_passkey": 40,
    "scbench_number_string": 40,
    "scbench_choice_eng": 40,
    "scbench_qa_eng": 40,
    "scbench_qa_chn": 40,
    "scbench_summary": 200,
    "scbench_repoqa": 40,
    "scbench_mf": 40,
    "scbench_vt": 40,
    # Mixed tasks
    "scbench_summary_with_needles": 200,  # Uses summary's max_tokens
    "scbench_repoqa_and_kv": 40,
}

# Task categories for metric selection
TASK_REQUIRES_PASSKEY_EVAL: Final[set[str]] = {
    "scbench_passkey",
    "scbench_summary_with_needles",  # Contains passkey subtask
}

TASK_REQUIRES_KV_EVAL: Final[set[str]] = {
    "scbench_kv",
    "scbench_repoqa_and_kv",  # Contains KV subtask
}

TASK_REQUIRES_REPOQA_EVAL: Final[set[str]] = {
    "scbench_repoqa",
    "scbench_repoqa_and_kv",  # Contains RepoQA subtask
}

TASK_REQUIRES_QA_F1: Final[set[str]] = {
    "scbench_qa_eng",
}

TASK_REQUIRES_QA_F1_ZH: Final[set[str]] = {
    "scbench_qa_chn",
}

TASK_REQUIRES_ROUGE: Final[set[str]] = {
    "scbench_summary",
    "scbench_summary_with_needles",  # Contains summary subtask
}

TASK_REQUIRES_CHOICE_MATCH: Final[set[str]] = {
    "scbench_choice_eng",
}

TASK_REQUIRES_INT_MATCH: Final[set[str]] = {
    "scbench_mf",
}

TASK_REQUIRES_VT_EVAL: Final[set[str]] = {
    "scbench_vt",
}

# Default truncation settings
DEFAULT_MAX_INPUT_TOKENS: Final[int] = 128000  # 128K context window
DEFAULT_TRUNCATION_MANNER: Final[str] = "middle"  # middle | head | tail

# SCDQ special separator (used in chat template)
SCDQ_SEPARATOR: Final[str] = "[SEPSEPSEP]"
