# @test:skip           - 跳过测试

"""
EHPC SCBench Multi-Turn Pipeline
=================================

使用 EHPC (Ensemble of Hierarchical Prompt Compression) 算法的 SCBench Multi-Turn pipeline。
EHPC 结合了多种压缩策略，提供鲁棒的上下文压缩。

特点:
    - 层次化压缩：多层次压缩策略
    - 集成学习：综合多种压缩方法的优势
    - 自适应压缩：根据内容特点动态调整
    - 支持 Multi-Turn 模式：每轮独立压缩上下文
"""

import logging
import os
import sys

# 添加项目根目录到 Python 路径
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 禁用 httpx 的 INFO 日志
logging.getLogger("httpx").setLevel(logging.WARNING)

from sage.common.utils.config.loader import load_config
from sage.common.utils.logging.custom_logger import CustomLogger
from sage.kernel.api.local_environment import LocalEnvironment
from sage.middleware.operators.rag import OpenAIGenerator
from sage_refiner.algorithms.ehpc import EHPCRefinerOperator

from benchmark.benchmark_scbench import (
    SCBenchBatch,
    SCBenchEvaluator,
    SCBenchPromptor,
)


def pipeline_run(config):
    """运行 EHPC SCBench Multi-Turn pipeline"""
    env = LocalEnvironment()

    (
        env.from_batch(SCBenchBatch, config["source"])
        .map(EHPCRefinerOperator, config["refiner"])
        .flatmap(SCBenchPromptor, config["promptor"])  # flatmap 展开 Multi-Turn 列表
        .map(OpenAIGenerator, config["generator"]["vllm"])
        .map(SCBenchEvaluator, config["evaluate"])
    )

    env.submit(autostop=True)


# ==========================================================
if __name__ == "__main__":
    CustomLogger.disable_global_console_debug()

    if os.getenv("SAGE_EXAMPLES_MODE") == "test" or os.getenv("SAGE_TEST_MODE") == "true":
        print("🧪 Test mode detected - SCBench EHPC Multi-Turn pipeline")
        print("✅ Test passed: Example structure validated")
        sys.exit(0)

    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config_ehpc.yaml")

    if not os.path.exists(config_path):
        print(f"❌ Configuration file not found: {config_path}")
        sys.exit(1)

    config = load_config(config_path)

    print("🚀 Starting EHPC SCBench Multi-Turn Pipeline...")
    print(f"📊 Task: {config['source'].get('task', 'N/A')}")
    print("📈 Mode: Multi-Turn")
    print(f"📈 Max samples: {config['source'].get('max_samples', 'All')}")
    print(f"🤖 Generator: {config['generator']['vllm']['model_name']}")
    print(f"🔧 Refiner: EHPC (rate={config['refiner'].get('rate', 'N/A')})")
    print("=" * 60)

    pipeline_run(config)
