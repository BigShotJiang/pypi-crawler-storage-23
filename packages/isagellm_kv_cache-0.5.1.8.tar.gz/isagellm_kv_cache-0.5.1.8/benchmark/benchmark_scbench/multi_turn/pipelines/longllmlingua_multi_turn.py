# @test:skip           - 跳过测试

"""
LongLLMLingua SCBench Multi-Turn Pipeline
==========================================

使用 LongLLMLingua 压缩算法的 SCBench Multi-Turn pipeline。
LongLLMLingua 基于小型 LLM（如 LLaMA-7B）进行问题感知的压缩。

特点:
    - 问题感知压缩：根据问题重要性动态压缩
    - 粗到细策略：文档级 → 段落级 → 句子级 → token级
    - 保持关键信息：使用困惑度过滤无关内容
    - 支持 Multi-Turn 模式：每轮独立压缩上下文

参考论文: https://arxiv.org/abs/2310.06839
"""

import logging
import os
import sys

# 添加项目根目录到 Python 路径
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 禁用 httpx 的 INFO 日志
logging.getLogger("httpx").setLevel(logging.WARNING)

from sage.common.utils.config.loader import load_config
from sage.common.utils.logging.custom_logger import CustomLogger
from sage.kernel.api.local_environment import LocalEnvironment
from sage.middleware.operators.rag import OpenAIGenerator
from sage_refiner.algorithms.longllmlingua import LongLLMLinguaRefinerOperator

from benchmark.benchmark_scbench import (
    SCBenchBatch,
    SCBenchEvaluator,
    SCBenchPromptor,
)


def pipeline_run(config):
    """运行 LongLLMLingua SCBench Multi-Turn pipeline"""
    env = LocalEnvironment()

    (
        env.from_batch(SCBenchBatch, config["source"])
        .map(LongLLMLinguaRefinerOperator, config["refiner"])
        .flatmap(SCBenchPromptor, config["promptor"])  # flatmap 展开 Multi-Turn 列表
        .map(OpenAIGenerator, config["generator"]["vllm"])
        .map(SCBenchEvaluator, config["evaluate"])
    )

    env.submit(autostop=True)


# ==========================================================
if __name__ == "__main__":
    CustomLogger.disable_global_console_debug()

    if os.getenv("SAGE_EXAMPLES_MODE") == "test" or os.getenv("SAGE_TEST_MODE") == "true":
        print("🧪 Test mode detected - SCBench LongLLMLingua Multi-Turn pipeline")
        print("✅ Test passed: Example structure validated")
        sys.exit(0)

    config_path = os.path.join(
        os.path.dirname(__file__), "..", "config", "config_longllmlingua.yaml"
    )

    if not os.path.exists(config_path):
        print(f"❌ Configuration file not found: {config_path}")
        sys.exit(1)

    config = load_config(config_path)

    print("🚀 Starting LongLLMLingua SCBench Multi-Turn Pipeline...")
    print(f"📊 Task: {config['source'].get('task', 'N/A')}")
    print("📈 Mode: Multi-Turn")
    print(f"📈 Max samples: {config['source'].get('max_samples', 'All')}")
    print(f"🤖 Generator: {config['generator']['vllm']['model_name']}")
    print(f"🔧 Refiner: LongLLMLingua (rate={config['refiner'].get('rate', 'N/A')})")
    print("=" * 60)

    pipeline_run(config)
