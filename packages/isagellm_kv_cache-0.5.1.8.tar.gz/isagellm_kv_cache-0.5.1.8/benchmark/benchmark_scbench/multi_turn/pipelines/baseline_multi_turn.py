# @test:skip           - 跳过测试

"""
Baseline SCBench Pipeline (Remote API)
======================================

使用远程 OpenAI-compatible API 的 SCBench pipeline。
不使用任何压缩/refine算法，用于对比实验。

特点：
- 使用 OpenAIGenerator（HTTP API）
- 只支持 Multi-Turn 模式（无 KV Cache 复用）
- 适合远程服务器部署

如需本地运行并支持 SCDQ 模式，使用 baseline_scbench_local.py
"""

import logging
import os
import sys

# 添加项目根目录到 Python 路径
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 禁用 httpx 的 INFO 日志
logging.getLogger("httpx").setLevel(logging.WARNING)

# 禁用 SAGE 框架的 INFO 日志
logging.getLogger("sage_libs.sage_agentic.agents.action.tool_selection.registry").setLevel(
    logging.WARNING
)

from sage.common.utils.config.loader import load_config
from sage.common.utils.logging.custom_logger import CustomLogger
from sage.kernel.api.local_environment import LocalEnvironment
from sage.middleware.operators.rag import OpenAIGenerator

from benchmark.benchmark_scbench import (
    SCBenchBatch,
    SCBenchEvaluator,
    SCBenchPromptor,
)


def pipeline_run(config):
    """运行 Baseline SCBench pipeline（无 Refiner）"""
    env = LocalEnvironment()

    (
        env.from_batch(SCBenchBatch, config["source"])
        # SCBench 自带 context，不需要 Retriever
        # Baseline: 不使用任何 Refiner
        .flatmap(SCBenchPromptor, config["promptor"])  # 使用 flatmap 展开 Multi-Turn 列表
        .map(OpenAIGenerator, config["generator"]["vllm"])
        .map(SCBenchEvaluator, config["evaluate"])
    )

    env.submit(autostop=True)


# ==========================================================
if __name__ == "__main__":
    CustomLogger.disable_global_console_debug()

    if os.getenv("SAGE_EXAMPLES_MODE") == "test" or os.getenv("SAGE_TEST_MODE") == "true":
        print("🧪 Test mode detected - SCBench Baseline pipeline")
        print("✅ Test passed: Example structure validated")
        sys.exit(0)

    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config_baseline.yaml")

    if not os.path.exists(config_path):
        print(f"❌ Configuration file not found: {config_path}")
        sys.exit(1)

    config = load_config(config_path)

    print("🚀 Starting Baseline SCBench Pipeline...")
    print(f"📊 Task: {config['source'].get('task', 'N/A')}")
    print(f"📈 Mode: {'SCDQ' if config['source'].get('scdq_mode', False) else 'Multi-Turn'}")
    print(f"📈 Max samples: {config['source'].get('max_samples', 'All')}")
    print(f"🤖 Generator: {config['generator']['vllm']['model_name']}")
    print("=" * 60)

    pipeline_run(config)
