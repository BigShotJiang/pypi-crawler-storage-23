# @test:skip           - 跳过测试

"""
RECOMP Extractive SCBench Multi-Turn Pipeline
==============================================

使用 RECOMP Extractive 压缩算法的 SCBench Multi-Turn pipeline。
基于双编码器（Contriever/DPR）对检索文档进行句子级打分，
选择与 query 最相关的 top-k 句子作为压缩后的上下文。

特点:
    - 句子级提取：保留原始句子完整性
    - 双编码器相似度：基于 Contriever/DPR 计算相关性
    - 高效压缩：无需 LLM 推理
    - 支持 Multi-Turn 模式：每轮独立选择相关句子

参考论文: RECOMP: Improving Retrieval-Augmented LMs with Compression and Selective Augmentation
https://arxiv.org/abs/2310.04408
"""

import logging
import os
import sys

# 添加项目根目录到 Python 路径
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 禁用 httpx 的 INFO 日志
logging.getLogger("httpx").setLevel(logging.WARNING)

from sage.common.utils.config.loader import load_config
from sage.common.utils.logging.custom_logger import CustomLogger
from sage.kernel.api.local_environment import LocalEnvironment
from sage.middleware.operators.rag import OpenAIGenerator
from sage_refiner.algorithms.recomp_extr import RECOMPExtractiveRefinerOperator

from benchmark.benchmark_scbench import (
    SCBenchBatch,
    SCBenchEvaluator,
    SCBenchPromptor,
)


def pipeline_run(config):
    """运行 RECOMP Extractive SCBench Multi-Turn pipeline"""
    env = LocalEnvironment()

    (
        env.from_batch(SCBenchBatch, config["source"])
        .map(RECOMPExtractiveRefinerOperator, config["refiner"])
        .flatmap(SCBenchPromptor, config["promptor"])  # flatmap 展开 Multi-Turn 列表
        .map(OpenAIGenerator, config["generator"]["vllm"])
        .map(SCBenchEvaluator, config["evaluate"])
    )

    env.submit(autostop=True)


# ==========================================================
if __name__ == "__main__":
    CustomLogger.disable_global_console_debug()

    if os.getenv("SAGE_EXAMPLES_MODE") == "test" or os.getenv("SAGE_TEST_MODE") == "true":
        print("🧪 Test mode detected - SCBench RECOMP Extractive Multi-Turn pipeline")
        print("✅ Test passed: Example structure validated")
        sys.exit(0)

    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config_recomp_extr.yaml")

    if not os.path.exists(config_path):
        print(f"❌ Configuration file not found: {config_path}")
        sys.exit(1)

    config = load_config(config_path)

    print("🚀 Starting RECOMP Extractive SCBench Multi-Turn Pipeline...")
    print(f"📊 Task: {config['source'].get('task', 'N/A')}")
    print("📈 Mode: Multi-Turn")
    print(f"📈 Max samples: {config['source'].get('max_samples', 'All')}")
    print(f"🤖 Generator: {config['generator']['vllm']['model_name']}")
    print(f"🔧 Refiner: RECOMP Extractive (top_k={config['refiner'].get('top_k', 'N/A')})")
    print("=" * 60)

    pipeline_run(config)
