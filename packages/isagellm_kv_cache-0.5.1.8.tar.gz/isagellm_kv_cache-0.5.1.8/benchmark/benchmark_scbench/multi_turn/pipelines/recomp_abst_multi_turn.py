# @test:skip           - 跳过测试

"""
RECOMP Abstractive SCBench Multi-Turn Pipeline
===============================================

使用 RECOMP Abstractive 压缩算法的 SCBench Multi-Turn pipeline。
基于抽象摘要模型（FLAN-T5）对检索文档进行抽象压缩，
生成简洁的摘要作为上下文。

特点:
    - 抽象摘要：使用 FLAN-T5 生成压缩摘要
    - 信息密度高：保留关键信息，去除冗余
    - 可控压缩：通过 max_length 控制摘要长度
    - 支持 Multi-Turn 模式：每轮独立生成摘要

参考论文: RECOMP: Improving Retrieval-Augmented LMs with Compression and Selective Augmentation
https://arxiv.org/abs/2310.04408
"""

import logging
import os
import sys

# 添加项目根目录到 Python 路径
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 禁用 httpx 的 INFO 日志
logging.getLogger("httpx").setLevel(logging.WARNING)

from sage.common.utils.config.loader import load_config
from sage.common.utils.logging.custom_logger import CustomLogger
from sage.kernel.api.local_environment import LocalEnvironment
from sage.middleware.operators.rag import OpenAIGenerator
from sage_refiner.algorithms.recomp_abst import RECOMPAbstractiveRefinerOperator

from benchmark.benchmark_scbench import (
    SCBenchBatch,
    SCBenchEvaluator,
    SCBenchPromptor,
)


def pipeline_run(config):
    """运行 RECOMP Abstractive SCBench Multi-Turn pipeline"""
    env = LocalEnvironment()

    (
        env.from_batch(SCBenchBatch, config["source"])
        .map(RECOMPAbstractiveRefinerOperator, config["refiner"])
        .flatmap(SCBenchPromptor, config["promptor"])  # flatmap 展开 Multi-Turn 列表
        .map(OpenAIGenerator, config["generator"]["vllm"])
        .map(SCBenchEvaluator, config["evaluate"])
    )

    env.submit(autostop=True)


# ==========================================================
if __name__ == "__main__":
    CustomLogger.disable_global_console_debug()

    if os.getenv("SAGE_EXAMPLES_MODE") == "test" or os.getenv("SAGE_TEST_MODE") == "true":
        print("🧪 Test mode detected - SCBench RECOMP Abstractive Multi-Turn pipeline")
        print("✅ Test passed: Example structure validated")
        sys.exit(0)

    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config_recomp_abst.yaml")

    if not os.path.exists(config_path):
        print(f"❌ Configuration file not found: {config_path}")
        sys.exit(1)

    config = load_config(config_path)

    print("🚀 Starting RECOMP Abstractive SCBench Multi-Turn Pipeline...")
    print(f"📊 Task: {config['source'].get('task', 'N/A')}")
    print("📈 Mode: Multi-Turn")
    print(f"📈 Max samples: {config['source'].get('max_samples', 'All')}")
    print(f"🤖 Generator: {config['generator']['vllm']['model_name']}")
    print(
        f"🔧 Refiner: RECOMP Abstractive (summary_length={config['refiner'].get('summary_length', 'N/A')})"
    )
    print("=" * 60)

    pipeline_run(config)
