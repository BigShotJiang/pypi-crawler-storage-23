"""Benchmark script for comparing KV block memory layouts.

Compares ContiguousKVBlock vs ChunkedKVBlock on:
- Allocation speed
- Access latency (sequential and random)
- Memory usage
- Fragmentation overhead
"""

from __future__ import annotations

import argparse
import json
import random
import time
from typing import Any

import torch

from sagellm_kv_cache.layout import ChunkedKVBlock, ContiguousKVBlock


def benchmark_allocation(
    layout_cls: type,
    num_tokens: int,
    hidden_dim: int,
    trials: int = 100,
    warmup: int = 20,
    **kwargs: Any,
) -> dict[str, float]:
    """Benchmark memory allocation speed.

    Args:
        layout_cls: Layout class to benchmark.
        num_tokens: Number of tokens in the block.
        hidden_dim: Hidden dimension size.
        trials: Number of trials to average.
        warmup: Number of warmup iterations to discard.
        **kwargs: Additional arguments for the layout class.

    Returns:
        Dictionary with timing statistics (ms).
    """
    # Warmup phase to stabilize cache/allocator
    for _ in range(warmup):
        block = layout_cls(num_tokens, hidden_dim, **kwargs)
        del block

    # Actual measurement
    times = []
    for _ in range(trials):
        start = time.perf_counter()
        block = layout_cls(num_tokens, hidden_dim, **kwargs)
        elapsed = time.perf_counter() - start
        times.append(elapsed * 1000)  # Convert to ms
        del block  # Clean up

    # Sort for percentile calculations
    times_sorted = sorted(times)
    n = len(times_sorted)
    median = (
        times_sorted[n // 2]
        if n % 2 == 1
        else (times_sorted[n // 2 - 1] + times_sorted[n // 2]) / 2
    )
    p95 = times_sorted[int(n * 0.95)]
    p99 = times_sorted[int(n * 0.99)]

    return {
        "mean_ms": sum(times) / len(times),
        "median_ms": median,
        "min_ms": min(times),
        "max_ms": max(times),
        "p95_ms": p95,
        "p99_ms": p99,
        "std_ms": (sum((t - sum(times) / len(times)) ** 2 for t in times) / len(times)) ** 0.5,
    }


def benchmark_sequential_access(
    block: ContiguousKVBlock | ChunkedKVBlock,
    trials: int = 1000,
    warmup: int = 100,
) -> dict[str, float]:
    """Benchmark sequential access pattern.

    Args:
        block: KV block instance.
        trials: Number of accesses to perform.
        warmup: Number of warmup iterations.

    Returns:
        Dictionary with timing statistics (μs).
    """
    num_tokens = block.num_tokens

    # Warmup phase
    for i in range(warmup):
        token_idx = i % num_tokens
        _ = block.get_kv(token_idx)

    # Actual measurement
    times = []
    for i in range(trials):
        token_idx = i % num_tokens
        start = time.perf_counter()
        _ = block.get_kv(token_idx)
        elapsed = time.perf_counter() - start
        times.append(elapsed * 1_000_000)  # Convert to μs

    # Calculate statistics
    times_sorted = sorted(times)
    n = len(times_sorted)
    median = (
        times_sorted[n // 2]
        if n % 2 == 1
        else (times_sorted[n // 2 - 1] + times_sorted[n // 2]) / 2
    )

    return {
        "mean_us": sum(times) / len(times),
        "median_us": median,
        "min_us": min(times),
        "max_us": max(times),
        "std_us": (sum((t - sum(times) / len(times)) ** 2 for t in times) / len(times)) ** 0.5,
    }


def benchmark_random_access(
    block: ContiguousKVBlock | ChunkedKVBlock,
    trials: int = 1000,
    warmup: int = 100,
) -> dict[str, float]:
    """Benchmark random access pattern.

    Args:
        block: KV block instance.
        trials: Number of accesses to perform.
        warmup: Number of warmup iterations.

    Returns:
        Dictionary with timing statistics (μs).
    """
    num_tokens = block.num_tokens

    # Warmup phase
    warmup_indices = [random.randint(0, num_tokens - 1) for _ in range(warmup)]
    for idx in warmup_indices:
        _ = block.get_kv(idx)

    # Generate random indices for actual measurement
    indices = [random.randint(0, num_tokens - 1) for _ in range(trials)]

    # Actual measurement
    times = []
    for token_idx in indices:
        start = time.perf_counter()
        _ = block.get_kv(token_idx)
        elapsed = time.perf_counter() - start
        times.append(elapsed * 1_000_000)  # Convert to μs

    # Calculate statistics
    times_sorted = sorted(times)
    n = len(times_sorted)
    median = (
        times_sorted[n // 2]
        if n % 2 == 1
        else (times_sorted[n // 2 - 1] + times_sorted[n // 2]) / 2
    )

    return {
        "mean_us": sum(times) / len(times),
        "median_us": median,
        "min_us": min(times),
        "max_us": max(times),
        "std_us": (sum((t - sum(times) / len(times)) ** 2 for t in times) / len(times)) ** 0.5,
    }


def benchmark_write_performance(
    block: ContiguousKVBlock | ChunkedKVBlock,
    trials: int = 1000,
    warmup: int = 100,
) -> dict[str, float]:
    """Benchmark write (set_kv) performance.

    Args:
        block: KV block instance.
        trials: Number of writes to perform.
        warmup: Number of warmup iterations.

    Returns:
        Dictionary with timing statistics (μs).
    """
    num_tokens = block.num_tokens
    hidden_dim = block.hidden_dim

    # Pre-generate random data
    kv_data = torch.randn(2, hidden_dim, dtype=torch.float16)

    # Warmup phase
    for _ in range(warmup):
        token_idx = _ % num_tokens
        block.set_kv(token_idx, kv_data)

    # Actual measurement
    times = []
    for _ in range(trials):
        token_idx = _ % num_tokens
        start = time.perf_counter()
        block.set_kv(token_idx, kv_data)
        elapsed = time.perf_counter() - start
        times.append(elapsed * 1_000_000)  # Convert to μs

    # Calculate statistics
    times_sorted = sorted(times)
    n = len(times_sorted)
    median = (
        times_sorted[n // 2]
        if n % 2 == 1
        else (times_sorted[n // 2 - 1] + times_sorted[n // 2]) / 2
    )

    return {
        "mean_us": sum(times) / len(times),
        "median_us": median,
        "min_us": min(times),
        "max_us": max(times),
        "std_us": (sum((t - sum(times) / len(times)) ** 2 for t in times) / len(times)) ** 0.5,
    }


def calculate_memory_metrics(block: ContiguousKVBlock | ChunkedKVBlock) -> dict[str, float]:
    """Calculate memory usage metrics.

    Args:
        block: KV block instance.

    Returns:
        Dictionary with two metrics:
        - allocation_overhead: Measures allocation dispersion (0.0 = single allocation, approaching 1.0 = many allocations)
        - space_waste: Measures unused allocated space (0.0 = no waste, 1.0 = 100% waste)
    """
    num_allocations = block.get_num_allocations()

    # 1. Allocation overhead (dispersion) - impacts GC and allocation speed
    if num_allocations == 1:
        allocation_overhead = 0.0
    else:
        allocation_overhead = (num_allocations - 1) / num_allocations

    # 2. Space waste - impacts memory utilization
    if isinstance(block, ChunkedKVBlock):
        # Calculate wasted space in chunked layout
        allocated_tokens = num_allocations * block.chunk_size
        used_tokens = block.num_tokens
        space_waste = (allocated_tokens - used_tokens) / allocated_tokens
    else:
        # Contiguous layout has no wasted space
        space_waste = 0.0

    return {
        "allocation_overhead": allocation_overhead,
        "space_waste": space_waste,
    }


def run_benchmark(
    block_sizes: list[int],
    hidden_dim: int = 4096,
    chunk_size: int = 64,
    alloc_trials: int = 100,
    access_trials: int = 1000,
) -> dict[str, Any]:
    """Run complete benchmark suite.

    Args:
        block_sizes: List of block sizes (num_tokens) to test.
        hidden_dim: Hidden dimension size.
        chunk_size: Chunk size for ChunkedKVBlock.
        alloc_trials: Number of allocation trials.
        access_trials: Number of access trials.

    Returns:
        Dictionary with all benchmark results.
    """
    results: dict[str, Any] = {
        "config": {
            "hidden_dim": hidden_dim,
            "chunk_size": chunk_size,
            "alloc_trials": alloc_trials,
            "access_trials": access_trials,
        },
        "results": {},
    }

    for num_tokens in block_sizes:
        print(f"\n{'=' * 60}")
        print(f"Benchmarking: {num_tokens} tokens")
        print(f"{'=' * 60}")

        # Benchmark Contiguous Layout
        print("\n[Contiguous Layout]")
        contiguous_alloc = benchmark_allocation(
            ContiguousKVBlock, num_tokens, hidden_dim, trials=alloc_trials, warmup=20
        )
        print(
            f"  Allocation: {contiguous_alloc['median_ms']:.3f} ms (median, σ={contiguous_alloc['std_ms']:.3f})"
        )

        contiguous_block = ContiguousKVBlock(num_tokens, hidden_dim)
        contiguous_seq = benchmark_sequential_access(
            contiguous_block, trials=access_trials, warmup=100
        )
        print(
            f"  Sequential Access: {contiguous_seq['median_us']:.3f} μs (median, σ={contiguous_seq['std_us']:.3f})"
        )

        contiguous_rand = benchmark_random_access(
            contiguous_block, trials=access_trials, warmup=100
        )
        print(
            f"  Random Access: {contiguous_rand['median_us']:.3f} μs (median, σ={contiguous_rand['std_us']:.3f})"
        )

        contiguous_write = benchmark_write_performance(
            contiguous_block, trials=access_trials, warmup=100
        )
        print(
            f"  Write: {contiguous_write['median_us']:.3f} μs (median, σ={contiguous_write['std_us']:.3f})"
        )

        contiguous_memory = contiguous_block.get_memory_usage()
        contiguous_metrics = calculate_memory_metrics(contiguous_block)
        print(f"  Memory: {contiguous_memory / 1024 / 1024:.2f} MB")
        print(f"  Allocation Overhead: {contiguous_metrics['allocation_overhead']:.2%}")
        print(f"  Space Waste: {contiguous_metrics['space_waste']:.2%}")
        print(f"  Allocations: {contiguous_block.get_num_allocations()}")

        # Benchmark Chunked Layout
        print("\n[Chunked Layout]")
        chunked_alloc = benchmark_allocation(
            ChunkedKVBlock,
            num_tokens,
            hidden_dim,
            chunk_size=chunk_size,
            trials=alloc_trials,
            warmup=20,
        )
        print(
            f"  Allocation: {chunked_alloc['median_ms']:.3f} ms (median, σ={chunked_alloc['std_ms']:.3f})"
        )

        chunked_block = ChunkedKVBlock(num_tokens, hidden_dim, chunk_size=chunk_size)
        chunked_seq = benchmark_sequential_access(chunked_block, trials=access_trials, warmup=100)
        print(
            f"  Sequential Access: {chunked_seq['median_us']:.3f} μs (median, σ={chunked_seq['std_us']:.3f})"
        )

        chunked_rand = benchmark_random_access(chunked_block, trials=access_trials, warmup=100)
        print(
            f"  Random Access: {chunked_rand['median_us']:.3f} μs (median, σ={chunked_rand['std_us']:.3f})"
        )

        chunked_write = benchmark_write_performance(chunked_block, trials=access_trials, warmup=100)
        print(
            f"  Write: {chunked_write['median_us']:.3f} μs (median, σ={chunked_write['std_us']:.3f})"
        )

        chunked_memory = chunked_block.get_memory_usage()
        chunked_metrics = calculate_memory_metrics(chunked_block)
        print(f"  Memory: {chunked_memory / 1024 / 1024:.2f} MB")
        print(f"  Allocation Overhead: {chunked_metrics['allocation_overhead']:.2%}")
        print(f"  Space Waste: {chunked_metrics['space_waste']:.2%}")
        print(f"  Allocations: {chunked_block.get_num_allocations()}")

        # Store results
        results["results"][num_tokens] = {
            "contiguous": {
                "allocation": contiguous_alloc,
                "sequential_access": contiguous_seq,
                "random_access": contiguous_rand,
                "write": contiguous_write,
                "memory_bytes": contiguous_memory,
                "allocation_overhead": contiguous_metrics["allocation_overhead"],
                "space_waste": contiguous_metrics["space_waste"],
                "num_allocations": contiguous_block.get_num_allocations(),
            },
            "chunked": {
                "allocation": chunked_alloc,
                "sequential_access": chunked_seq,
                "random_access": chunked_rand,
                "write": chunked_write,
                "memory_bytes": chunked_memory,
                "allocation_overhead": chunked_metrics["allocation_overhead"],
                "space_waste": chunked_metrics["space_waste"],
                "num_allocations": chunked_block.get_num_allocations(),
            },
        }

    return results


def print_summary_table(results: dict[str, Any]) -> None:
    """Print summary comparison table.

    Args:
        results: Benchmark results dictionary.
    """
    print(f"\n{'=' * 96}")
    print("SUMMARY TABLE")
    print(f"{'=' * 96}")
    print(
        f"{'Tokens':<10} {'Layout':<12} {'Alloc (ms)':<12} {'Seq (μs)':<12} "
        f"{'Rand (μs)':<12} {'Write (μs)':<12} {'AllocOvhd':<10} {'SpaceWaste':<10}"
    )
    print("-" * 96)

    for num_tokens, data in results["results"].items():
        for layout_name in ["contiguous", "chunked"]:
            layout_data = data[layout_name]
            print(
                f"{num_tokens:<10} {layout_name:<12} "
                f"{layout_data['allocation']['median_ms']:<12.3f} "
                f"{layout_data['sequential_access']['median_us']:<12.3f} "
                f"{layout_data['random_access']['median_us']:<12.3f} "
                f"{layout_data['write']['median_us']:<12.3f} "
                f"{layout_data['allocation_overhead']:<10.2%} "
                f"{layout_data['space_waste']:<10.2%}"
            )


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(description="KV Block Layout Benchmark")
    parser.add_argument(
        "--block-sizes",
        type=str,
        default="100,300,700,1500,3000",
        help="Comma-separated block sizes (default: 100,300,700,1500,3000 - realistic conversation lengths)",
    )
    parser.add_argument(
        "--hidden-dim",
        type=int,
        default=4096,
        help="Hidden dimension size (default: 4096)",
    )
    parser.add_argument(
        "--chunk-size",
        type=int,
        default=64,
        help="Chunk size for ChunkedKVBlock (default: 64)",
    )
    parser.add_argument(
        "--alloc-trials",
        type=int,
        default=100,
        help="Number of allocation trials (default: 100)",
    )
    parser.add_argument(
        "--access-trials",
        type=int,
        default=1000,
        help="Number of access trials (default: 1000)",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="layout_benchmark_results.json",
        help="Output JSON file (default: layout_benchmark_results.json)",
    )

    args = parser.parse_args()

    # Parse block sizes
    block_sizes = [int(x.strip()) for x in args.block_sizes.split(",")]

    print("🚀 KV Block Layout Benchmark (Optimized)")
    print(f"   Block sizes: {block_sizes}")
    print(f"   Hidden dim: {args.hidden_dim}")
    print(f"   Chunk size: {args.chunk_size}")
    print(f"   Allocation trials: {args.alloc_trials}")
    print(f"   Access trials: {args.access_trials}")
    print("   ⚡ Using median for stability")
    print()

    # Run benchmark
    results = run_benchmark(
        block_sizes=block_sizes,
        hidden_dim=args.hidden_dim,
        chunk_size=args.chunk_size,
        alloc_trials=args.alloc_trials,
        access_trials=args.access_trials,
    )

    # Print summary
    print_summary_table(results)

    # Save results
    with open(args.output, "w") as f:
        json.dump(results, f, indent=2)

    print(f"\n✅ Results saved to: {args.output}")


if __name__ == "__main__":
    main()
