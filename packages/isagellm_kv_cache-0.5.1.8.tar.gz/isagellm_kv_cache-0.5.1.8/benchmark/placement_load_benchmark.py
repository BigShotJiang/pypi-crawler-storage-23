"""Placement load-aware benchmark (Task 2.7).

Compare scheduler behavior with load-awareness enabled/disabled.
"""

from __future__ import annotations

import argparse
import random
import statistics
import time

from sagellm_kv_cache.load_aware_scheduler import PlacementStrategy
from sagellm_kv_cache.models import RequestType, SchedulerRequest
from sagellm_kv_cache.scheduler_bridge import SchedulerBridge


def _build_request(index: int, kv_tokens: int) -> SchedulerRequest:
    """Build a synthetic scheduler request."""
    return SchedulerRequest(
        request_id=f"req-{index}",
        trace_id=f"trace-{index}",
        request_type=RequestType.PREFILL,
        prompt_len=max(1, kv_tokens // 2),
        max_new_tokens=max(1, kv_tokens // 2),
        kv_tokens_required=kv_tokens,
    )


def run_simulation(
    enable_load_awareness: bool,
    num_requests: int,
    seed: int,
) -> dict[str, float]:
    """Run one placement simulation and collect summary metrics."""
    random.seed(seed)

    bridge = SchedulerBridge(
        max_tokens=8192,
        enable_load_awareness=enable_load_awareness,
        placement_strategy=PlacementStrategy.LOWEST_KV,
        devices=["cuda:0", "cuda:1", "cuda:2"],
    )

    placed = 0
    start = time.time()

    for index in range(num_requests):
        kv_tokens = random.randint(64, 384)
        request = _build_request(index, kv_tokens)
        plan = bridge.plan([request])
        if request.request_id in plan.placement:
            placed += 1

    elapsed_s = max(1e-9, time.time() - start)
    stats = bridge.get_stats()

    per_device = stats["placement"]["per_device"]
    counts = [float(per_device.get(device, 0)) for device in ("cuda:0", "cuda:1", "cuda:2")]

    return {
        "placed_requests": float(placed),
        "throughput_rps": placed / elapsed_s,
        "imbalance_stddev": statistics.pstdev(counts) if counts else 0.0,
        "device0": counts[0],
        "device1": counts[1],
        "device2": counts[2],
    }


def main() -> None:
    """CLI entry."""
    parser = argparse.ArgumentParser(description="Task2.7 placement load-aware benchmark")
    parser.add_argument("--requests", type=int, default=200, help="number of synthetic requests")
    parser.add_argument("--seed", type=int, default=7, help="random seed")
    args = parser.parse_args()

    no_load = run_simulation(False, args.requests, args.seed)
    load_aware = run_simulation(True, args.requests, args.seed)

    print("=== Placement Benchmark: load-aware OFF vs ON ===")
    print(f"requests={args.requests}, seed={args.seed}")
    print("")
    print("[OFF]")
    print(
        f"placed={no_load['placed_requests']:.0f}, "
        f"throughput={no_load['throughput_rps']:.2f} req/s, "
        f"imbalance_stddev={no_load['imbalance_stddev']:.2f}"
    )
    print(
        f"device_distribution: cuda:0={no_load['device0']:.0f}, "
        f"cuda:1={no_load['device1']:.0f}, cuda:2={no_load['device2']:.0f}"
    )
    print("")
    print("[ON]")
    print(
        f"placed={load_aware['placed_requests']:.0f}, "
        f"throughput={load_aware['throughput_rps']:.2f} req/s, "
        f"imbalance_stddev={load_aware['imbalance_stddev']:.2f}"
    )
    print(
        f"device_distribution: cuda:0={load_aware['device0']:.0f}, "
        f"cuda:1={load_aware['device1']:.0f}, cuda:2={load_aware['device2']:.0f}"
    )


if __name__ == "__main__":
    main()
