"""Micro benchmark for prefix grouping and similarity strategies (Task2.6).

Compares grouping ON/OFF and fingerprint strategies, and reports:
- prefix_group_hit_rate
- prefix_group_size
- extra_queue_delay_ms
"""

from __future__ import annotations

import argparse
import random
import time
from dataclasses import dataclass

from sagellm_kv_cache.prefix import (
    FingerprintConfig,
    FingerprintStrategy,
    GroupingConfig,
    PrefixGrouper,
    Request,
)


@dataclass
class BenchResult:
    """Benchmark result row."""

    strategy: str
    grouping_enabled: bool
    total_requests: int
    total_groups: int
    prefix_group_hit_rate: float
    prefix_group_size: float
    extra_queue_delay_ms: float
    elapsed_ms: float


def _build_requests(num_requests: int, prefix_len: int, prefix_pool: int) -> list[list[int]]:
    """Create synthetic requests with controllable prefix similarity."""
    common_prefixes = [
        [random.randint(1, 5000) for _ in range(prefix_len)] for _ in range(max(1, prefix_pool))
    ]

    requests: list[list[int]] = []
    for _ in range(num_requests):
        shared = common_prefixes[random.randint(0, len(common_prefixes) - 1)]
        tail = [random.randint(1, 5000) for _ in range(8)]
        requests.append(shared + tail)
    return requests


def run_benchmark(
    strategy: FingerprintStrategy,
    grouping_enabled: bool,
    num_requests: int,
    aggregation_window_ms: float,
    max_queue_delay_ms: float,
    prefix_len: int,
    prefix_pool: int,
) -> BenchResult:
    """Run one benchmark configuration."""
    fp_config = FingerprintConfig(strategy=strategy, segment_size=16, max_segments=8)
    grouping_config = GroupingConfig(
        enable_grouping=grouping_enabled,
        aggregation_window_ms=aggregation_window_ms,
        max_queue_delay_ms=max_queue_delay_ms,
        auto_disable_on_timeout=False,
        fingerprint_config=fp_config,
    )
    grouper = PrefixGrouper(grouping_config)

    payloads = _build_requests(num_requests, prefix_len=prefix_len, prefix_pool=prefix_pool)

    start = time.perf_counter()
    if grouping_enabled:
        for idx, tokens in enumerate(payloads):
            grouper.add_request(Request(request_id=f"req-{idx}", tokens=tokens))
            grouper.get_ready_groups()
        grouper.get_ready_groups(force_all=True)
    else:
        # simulate no-grouping baseline: each request is independent
        for idx, tokens in enumerate(payloads):
            _ = Request(request_id=f"req-{idx}", tokens=tokens)
            _ = tokens
    elapsed_ms = (time.perf_counter() - start) * 1000

    stats = (
        grouper.get_stats()
        if grouping_enabled
        else {
            "total_requests": num_requests,
            "total_groups": num_requests,
            "prefix_group_hit_rate": 0.0,
            "prefix_group_size": 1.0,
            "extra_queue_delay_ms": 0.0,
        }
    )

    return BenchResult(
        strategy=strategy.value,
        grouping_enabled=grouping_enabled,
        total_requests=stats["total_requests"],
        total_groups=stats["total_groups"],
        prefix_group_hit_rate=stats["prefix_group_hit_rate"],
        prefix_group_size=stats["prefix_group_size"],
        extra_queue_delay_ms=stats["extra_queue_delay_ms"],
        elapsed_ms=elapsed_ms,
    )


def main() -> None:
    """CLI entry for micro benchmark."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--requests", type=int, default=2000)
    parser.add_argument("--prefix-len", type=int, default=32)
    parser.add_argument("--prefix-pool", type=int, default=32)
    parser.add_argument("--aggregation-window-ms", type=float, default=5.0)
    parser.add_argument("--max-queue-delay-ms", type=float, default=50.0)
    args = parser.parse_args()

    random.seed(42)

    rows: list[BenchResult] = []
    strategies = [
        FingerprintStrategy.SIMPLE_HASH,
        FingerprintStrategy.SEGMENTED_HASH,
        FingerprintStrategy.WEIGHTED_HASH,
        FingerprintStrategy.ADAPTIVE_HASH,
    ]

    rows.append(
        run_benchmark(
            strategy=FingerprintStrategy.SIMPLE_HASH,
            grouping_enabled=False,
            num_requests=args.requests,
            aggregation_window_ms=args.aggregation_window_ms,
            max_queue_delay_ms=args.max_queue_delay_ms,
            prefix_len=args.prefix_len,
            prefix_pool=args.prefix_pool,
        )
    )

    for strategy in strategies:
        rows.append(
            run_benchmark(
                strategy=strategy,
                grouping_enabled=True,
                num_requests=args.requests,
                aggregation_window_ms=args.aggregation_window_ms,
                max_queue_delay_ms=args.max_queue_delay_ms,
                prefix_len=args.prefix_len,
                prefix_pool=args.prefix_pool,
            )
        )

    print(
        "strategy,grouping,total_requests,total_groups,prefix_group_hit_rate,"
        "prefix_group_size,extra_queue_delay_ms,elapsed_ms"
    )
    for row in rows:
        print(
            f"{row.strategy},{int(row.grouping_enabled)},{row.total_requests},{row.total_groups},"
            f"{row.prefix_group_hit_rate:.6f},{row.prefix_group_size:.6f},"
            f"{row.extra_queue_delay_ms:.6f},{row.elapsed_ms:.3f}"
        )


if __name__ == "__main__":
    main()
