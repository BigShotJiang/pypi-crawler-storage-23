from collections import defaultdict

import numpy as np
import pandas as pd
from ..xds_input import extract_keywords

from ..symm_shelx.laue_symm_ops import symmetry_operations
from ..symm_shelx.symm_function import get_laue_group

# --- NEW: fast, cached grouping on canonical HKLs ----------------------------

_group_cache = {}


def _group_by_canon(canon: np.ndarray):
    """
    Given canonical HKLs (int32, shape (N,3)), return:
      uniq_hkl  : (K,3) int32 unique HKLs (first occurrence order)
      first_idx : (K,) indices of first occurrence in the input
      inv       : (N,) group id for each row
      counts    : (K,) counts per group
      order     : (N,) stable order that groups same inv together
      ranges    : (K+1,) cumulative sizes; members for gid are order[ranges[gid]:ranges[gid+1]]
    Results are cached per content-hash of `canon`.
    """
    import zlib
    canon = np.ascontiguousarray(canon, dtype=np.int32)

    # Content-based cache key
    key = (zlib.adler32(canon.view(np.uint8)) ^ (canon.shape[0] << 21) ^ canon.shape[1])
    g = _group_cache.get(key)
    if g is not None:
        return g

    # Pack (h,k,l) into a 1D int64 key -> cheaper/faster unique than axis=0
    max_abs = int(np.max(np.abs(canon))) if canon.size else 0
    base = np.int64(2 * max_abs + 1)
    shift = np.int64(max_abs)
    c64 = canon.astype(np.int64, copy=False)
    keys = ((c64[:, 0] + shift) * (base * base) +
            (c64[:, 1] + shift) * base +
            (c64[:, 2] + shift))

    uniq_keys, first_idx, inv, counts = np.unique(
        keys, return_index=True, return_inverse=True, return_counts=True
    )
    uniq_hkl = canon[first_idx]

    order = np.argsort(inv, kind='mergesort')
    ranges = np.concatenate(([0], np.cumsum(counts, dtype=np.int64)))

    g = (uniq_hkl, first_idx, inv, counts, order, ranges)
    _group_cache[key] = g
    return g


def mark_multiple_reflections(refls: list) -> pd.DataFrame:
    """
    Marks reflections that have multiple intensity measurements.

    Args:
        refls (list): List of reflection data, where each reflection is a tuple
                      containing (h, k, l, d, intensities, sigmas, mean_intensity,
                      weighted_sigma, mean_sigma).
    Returns:
        pd.DataFrame: DataFrame containing reflections with multiple intensities,
                      with columns ['h', 'k', 'l', 'd', 'I'].
    """
    half1 = []
    for reflection in refls:
        h, k, l, d, intensities, sigmas, _, _, _ = reflection
        if len(intensities) >= 2:
            half1.append([h, k, l, d, 0])

    half1_df = pd.DataFrame(half1, columns=['h', 'k', 'l', 'd', 'I'])
    return half1_df


def combine_hkl(refls: list, exclude: list = None) -> list:
    """Combines reflection data of same hkl by averaging intensities and sigmas.

    Args:
        refls (list): List of reflection data.
        exclude (list, optional): List of data sources to exclude.
            Defaults to None.

    Returns:
        list: Averaged reflection data for unique (h, k, l) combinations.
    """
    if exclude is None:
        exclude = []

    # Convert the input list to a numpy array for efficient processing
    data = np.array(refls)

    # Extract columns
    hkl = data[:, :3]
    I = data[:, 3]
    sigma = data[:, 4]
    data_source = data[:, 5]

    # Filter out reflections from the exclude list
    mask = np.isin(data_source, exclude, invert=True)
    hkl = hkl[mask]
    # After masking
    I = I[mask]
    sigma = sigma[mask]

    # Flatten and ensure numeric data types
    I = I.flatten().astype(float)
    sigma = sigma.flatten().astype(float)

    # Get unique (h, k, l) combinations and their indices
    unique_hkl, indices, inverse_indices, counts = np.unique(
        hkl, axis=0, return_index=True, return_inverse=True, return_counts=True)

    # Ensure inverse_indices is integer
    inverse_indices = inverse_indices.flatten().astype(int)

    # Sum intensities and sigma inverse squared
    sum_I = np.bincount(inverse_indices, weights=I)
    sum_sigma_inv_sq = np.bincount(inverse_indices, weights=1 / sigma ** 2)

    # Calculate average intensity
    avg_I = sum_I / counts
    # Calculate average sigma
    avg_sigma = 1 / np.sqrt(sum_sigma_inv_sq)

    # Combine results into a single array
    result = np.column_stack((unique_hkl, avg_I, avg_sigma)).tolist()

    return result


def _has_matrix_ops(symmetry_ops):
    return (len(symmetry_ops) > 0
            and all(isinstance(op, np.ndarray) and op.shape == (3, 3) for op in symmetry_ops))


# --- REVISED: faster canonicalisation without (M,N,3) tensor -----------------

def _canonicalize_hkl_numpy(HKL: np.ndarray, symmetry_ops: list) -> np.ndarray:
    """
    Return the canonical representative for each row of HKL under the given symmetry ops.
    Optimised path for 3x3 integer matrices: stream ops, compare via a packed lexicographic key.
    """
    HKL = np.ascontiguousarray(HKL, dtype=np.int32)
    mats = np.stack([np.asarray(op, dtype=np.int32) for op in symmetry_ops])  # (M,3,3)
    if mats.ndim != 3 or mats.shape[1:] != (3, 3):
        raise ValueError("symmetry_ops must be iterable of 3x3 integer matrices")

    # Build stable key range from input magnitude (orthogonal ops won't blow up |hkl|)
    max_abs = int(np.max(np.abs(HKL))) if HKL.size else 0
    base = np.int64(2 * max_abs + 1)
    shift = np.int64(max_abs)

    def _pack_key(arr_i32: np.ndarray) -> np.ndarray:
        a = arr_i32.astype(np.int64, copy=False)
        return ((a[:, 0] + shift) * (base * base) +
                (a[:, 1] + shift) * base +
                (a[:, 2] + shift))

    # First op
    canon = HKL @ mats[0].T  # (N,3)
    best_key = _pack_key(canon)

    # Stream remaining ops; keep lexicographic minimum
    for m in range(1, mats.shape[0]):
        cand = HKL @ mats[m].T
        k = _pack_key(cand)
        mask = k < best_key
        if np.any(mask):
            canon[mask] = cand[mask]
            best_key[mask] = k[mask]

    return canon


def _reciprocal_metric(a, b, c, alpha_deg, beta_deg, gamma_deg) -> np.ndarray:
    """Return G* (3x3) by inverting the direct metric G once."""
    al = np.deg2rad(alpha_deg)
    be = np.deg2rad(beta_deg)
    ga = np.deg2rad(gamma_deg)
    cal, cbe, cga = np.cos(al), np.cos(be), np.cos(ga)

    G = np.array([
        [a * a, a * b * cga, a * c * cbe],
        [a * b * cga, b * b, b * c * cal],
        [a * c * cbe, b * c * cal, c * c]
    ], dtype=np.float64)
    return np.linalg.inv(G)


def generate_unique_reflections(refls: list, sg_no: int, uc: list) -> list:
    """
    refls: list of [h,k,l] or [h,k,l,I,sigma]
    sg_no: space group number
    uc: [a,b,c,alpha,beta,gamma]
    Returns:
      if I,σ present:
        (h,k,l,d, [I_i...], [σ_i...], wmean, w_sigma, mean_sigma)
      else:
        (h,k,l,d)
    Sorts output by (h,k,l).
    """
    laue_group = get_laue_group(sg_no)
    symmetry_ops = symmetry_operations.get(laue_group, [])
    has_intensity_sigma = (len(refls) > 0 and len(refls[0]) > 3)

    # Unit cell -> reciprocal metric once
    a, b, c, alpha, beta, gamma = uc
    Gstar = _reciprocal_metric(a, b, c, alpha, beta, gamma)

    # Typed arrays (fromiter is robust against ragged rows)
    n = len(refls)
    H = np.fromiter((r[0] for r in refls), dtype=np.int32, count=n)
    K = np.fromiter((r[1] for r in refls), dtype=np.int32, count=n)
    L = np.fromiter((r[2] for r in refls), dtype=np.int32, count=n)
    HKL = np.ascontiguousarray(np.stack([H, K, L], axis=1), dtype=np.int32)

    if has_intensity_sigma:
        I = np.fromiter((float(r[3]) for r in refls), dtype=np.float64, count=n)
        S = np.fromiter((float(r[4]) for r in refls), dtype=np.float64, count=n)

    # Canonicalise + group (cached)
    canon = _canonicalize_hkl_numpy(HKL, symmetry_ops)
    uniq_hkl, first_idx, inv, counts, order, ranges = _group_by_canon(canon)
    Kuniq = uniq_hkl.shape[0]

    # d-spacings via reciprocal metric: d = 1 / sqrt(h^T G* h)
    h = uniq_hkl.astype(np.float64, copy=False)
    inv_d2 = np.einsum('ni,ij,nj->n', h, Gstar, h, optimize='optimal')
    d_unique = 1.0 / np.sqrt(inv_d2)

    if has_intensity_sigma:
        # Weighted aggregates
        w = 1.0 / (S * S)
        sum_w = np.bincount(inv, weights=w, minlength=Kuniq)
        sum_wI = np.bincount(inv, weights=w * I, minlength=Kuniq)
        sum_wI2 = np.bincount(inv, weights=w * I * I, minlength=Kuniq)
        sum_S2 = np.bincount(inv, weights=S * S, minlength=Kuniq)

        wmean = sum_wI / sum_w
        nrep = counts.astype(np.float64)
        wvar = (sum_wI2 - 2.0 * wmean * sum_wI + (wmean * wmean) * sum_w) / sum_w
        w_sigma = np.sqrt(np.maximum(wvar, 0.0) / np.maximum(nrep - 1.0, 1.0))

        # Match original: sqrt(sum(sig^2))/n
        mean_sigma = np.sqrt(np.maximum(sum_S2, 0.0)) / np.maximum(nrep, 1.0)

        # Singletons: keep first I,σ
        single_mask = (counts == 1)
        if np.any(single_mask):
            idx0 = first_idx[single_mask]
            wmean[single_mask] = I[idx0]
            w_sigma[single_mask] = S[idx0]

        # Sort by (h,k,l) once; then emit in that order
        sort_idx = np.lexsort((uniq_hkl[:, 2], uniq_hkl[:, 1], uniq_hkl[:, 0]))

        results = []
        for gid in sort_idx:
            h, k, l = map(int, uniq_hkl[gid])
            d = float(d_unique[gid])
            start, end = ranges[gid], ranges[gid + 1]
            members = order[start:end]
            intensities = I[members].tolist()
            sigmas = S[members].tolist()
            results.append((h, k, l, d,
                            intensities, sigmas,
                            float(wmean[gid]), float(w_sigma[gid]),
                            float(mean_sigma[gid])))
        return results

    # No intensity/sigma path: just (h,k,l,d), sorted
    sort_idx = np.lexsort((uniq_hkl[:, 2], uniq_hkl[:, 1], uniq_hkl[:, 0]))
    uniq_hkl_sorted = uniq_hkl[sort_idx]
    d_sorted = d_unique[sort_idx]
    return [(int(h), int(k), int(l), float(d))
            for (h, k, l), d in zip(uniq_hkl_sorted, d_sorted)]


def load_refls_bravais(xds_hkl: str, reso_low: float, reso_high: float) -> tuple:
    """Loads reflections from XDS HKL file within specified resolution range.

    Args:
        xds_hkl (str): Path to the XDS ASCII HKL file.
        reso_low (float): Low resolution limit.
        reso_high (float): High resolution limit.

    Returns:
        tuple: Filtered reflection data (np.ndarray) and header information (dict).
    """
    # --- Read all lines (preserves your original behaviour exactly) ---
    with open(xds_hkl, 'r') as f:
        lines = f.readlines()

    # Same header extraction as your code: collect every '!' line anywhere
    header_lines = [line[1:].strip() for line in lines if line.startswith('!')]
    header_dict = extract_keywords(header_lines)

    # Same data_start logic as your code
    try:
        data_start = lines.index('!END_OF_HEADER\n') + 1
    except ValueError:
        data_start = next(i for i, line in enumerate(lines) if line.strip() == '!END_OF_HEADER') + 1

    # --- Fast data load: read exactly the first 7 columns (h k l I SIGI X Y) after the header ---
    # This replicates your parsing but in C-speed; also tolerates blank/comment lines.
    try:
        data_array = np.loadtxt(
            xds_hkl,
            skiprows=data_start,
            usecols=(0, 1, 2, 3, 4, 5, 6),
            comments='!',  # ignore any stray commented lines (matches your len(parts)<5 skip)
            dtype=np.float64,
        )
    except StopIteration:
        data_array = np.empty((0, 7), dtype=np.float64)

    # Ensure 2D shape even if there is only one data row
    data_array = np.atleast_2d(data_array)

    # --- Compute scale and distances exactly like your code (keep sqrt for identical semantics) ---
    scale_factor = (
            float(header_dict["QX"][0]) /
            float(header_dict["DETECTOR_DISTANCE"][0]) /
            float(header_dict["X-RAY_WAVELENGTH"][0])
    )
    min_distance = 1.0 / reso_low / scale_factor
    max_distance = 1.0 / reso_high / scale_factor
    X0 = float(header_dict["ORGX"][0])
    Y0 = float(header_dict["ORGY"][0])

    # Distances (same as your code, with sqrt)
    distances = np.sqrt((data_array[:, -2] - X0) ** 2 + (data_array[:, -1] - Y0) ** 2)

    # --- Apply the same filters in the same way ---
    # Your original already excluded sigma<=0 during parsing; we reproduce that condition here.
    sigma = data_array[:, 4]
    intensity = data_array[:, 3]

    mask = (
            (sigma > 0) &  # equivalent to your early skip of sigma<=0
            (distances >= min_distance) &
            (distances <= max_distance) &
            ((intensity / sigma) > 0)  # exactly your ratio test
    )

    filtered_data = data_array[mask]

    return filtered_data, (
        header_dict["SPACE_GROUP_NUMBER"],
        header_dict["UNIT_CELL_CONSTANTS"]
    )


def generate_unique_no_d(reflections: np.ndarray, symmetry_ops: list) -> list:
    """
    reflections: ndarray with columns [h,k,l,I,sigma]
    symmetry_ops: list of 3x3 matrices
    Returns list of tuples:
      (h, k, l, 0,
       [I_i...], [sigma_i...],
       wmean, w_sigma, mean_sigma_like_original)
    """
    if reflections.shape[1] < 5:
        raise ValueError("Expected columns [h,k,l,I,sigma].")

    HKL = reflections[:, :3].astype(np.int32, copy=False)
    I = reflections[:, 3].astype(np.float64, copy=False)
    S = reflections[:, 4].astype(np.float64, copy=False)

    # Canonicalise + group (cached)
    canon = _canonicalize_hkl_numpy(HKL, symmetry_ops)
    uniq_hkl, first_idx, inv, counts, order, ranges = _group_by_canon(canon)
    K = uniq_hkl.shape[0]

    # Weighted aggregates via bincount
    w = 1.0 / (S * S)
    sum_w = np.bincount(inv, weights=w, minlength=K)
    sum_wI = np.bincount(inv, weights=w * I, minlength=K)
    sum_wI2 = np.bincount(inv, weights=w * I * I, minlength=K)
    sum_S2 = np.bincount(inv, weights=S * S, minlength=K)

    wmean = sum_wI / sum_w
    n = counts.astype(np.float64)
    # Weighted variance about wmean (population-style), then your (n-1) convention
    wvar = (sum_wI2 - 2.0 * wmean * sum_wI + (wmean * wmean) * sum_w) / sum_w
    w_sigma = np.sqrt(np.maximum(wvar, 0.0) / np.maximum(n - 1.0, 1.0))

    # Match original "mean_sigma" style: sqrt(sum(sig^2))/n
    mean_sigma = np.sqrt(np.maximum(sum_S2, 0.0)) / np.maximum(n, 1.0)

    # Singletons: keep first observation's I and σ
    single_mask = (counts == 1)
    if np.any(single_mask):
        idx0 = first_idx[single_mask]
        wmean[single_mask] = I[idx0]
        w_sigma[single_mask] = S[idx0]

    # Build payload; use order/ranges instead of materialising groups with np.split
    out = []
    for gid in range(K):
        start, end = ranges[gid], ranges[gid + 1]
        members = order[start:end]
        intensities = I[members].tolist()
        sigmas = S[members].tolist()
        h, k, l = map(int, uniq_hkl[gid])
        out.append((h, k, l, 0,
                    intensities, sigmas,
                    float(wmean[gid]), float(w_sigma[gid]),
                    float(mean_sigma[gid])))
    return out
