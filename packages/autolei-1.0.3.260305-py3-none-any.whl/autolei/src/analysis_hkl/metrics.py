import numpy as np
import pandas as pd
from scipy.stats import t

slice_list = [
                 80.0, 20.0, 15.0, 10.2, 7.70, 6.67, 5.30, 4.62, 4.20, 3.90, 3.70, 3.46, 3.30,
                 3.14, 3.00, 2.90, 2.82, 2.76, 2.70, 2.63, 2.56, 2.48, 2.40, 2.34, 2.27,
                 2.20, 2.14, 2.07, 2.00, 1.90, 1.80, 1.70, 1.60, 1.50, 1.42, 1.35, 1.28,
                 1.23, 1.18, 1.14, 1.10, 1.07, 1.04, 1.02, 1.00, 0.98, 0.96, 0.93, 0.90,
                 0.87, 0.84] + np.round(np.arange(0.82, 0.15, -0.01), 2).tolist()


def slice_reflections(refls: list, d_max: float, d_min: float) -> list:
    """Slices reflections based on a d-spacing range.

    Args:
        refls (list): List of reflection data.
        d_max (float): Maximum d-spacing.
        d_min (float): Minimum d-spacing.

    Returns:
        list: Reflections within the specified d-spacing range.
    """
    return [
        refl for refl in refls
        if (d_min < refl[3] <= d_max)
    ]


def generate_slice_d(df: pd.DataFrame, num_slices: int = 15) -> list:
    """Generates slicing points for reflections based on the number of slices.

    Args:
        df (pd.DataFrame): DataFrame containing reflection data.
        num_slices (int, optional): Number of slices. Defaults to 15.

    Returns:
        list: Slicing points for the reflection data.
    """

    sorted_df = df.sort_values(by='d')
    slice_size = len(df) // num_slices + 1
    if slice_size < 40:
        slice_size = len(df) // 12 + 1
    if slice_size < 40:
        slice_size = len(df) // 9 + 1
    if slice_size < 40:
        slice_size = len(df) // 6 + 1
    slices = []

    for i in range(num_slices):
        start = i * slice_size
        end = start + slice_size if i < num_slices - 1 else len(df)
        slice_df = sorted_df.iloc[start:end]
        slices.append(slice_df)

    slicing_points = [slices[i]['d'].min() for i in range(num_slices)]

    adjusted_slicing_points = sorted({min(slice_list, key=lambda x: x >= point) for point in slicing_points},
                                     reverse=True)
    if len(adjusted_slicing_points) <= 3:
        return []
    if 80.0 not in adjusted_slicing_points:
        adjusted_slicing_points = ([80.0] + adjusted_slicing_points[:-1] +
                                   ([round(min(slicing_points), 2)]
                                    if adjusted_slicing_points[-2] != round(min(slicing_points), 2) else []))
    else:
        adjusted_slicing_points = (adjusted_slicing_points[:-1] +
                                   ([round(min(slicing_points), 2)]
                                    if adjusted_slicing_points[-2] != round(min(slicing_points), 2) else []))
    if adjusted_slicing_points[1] < 0.90:
        adjusted_slicing_points = [80.0, 1.0] + adjusted_slicing_points[1:]
    elif adjusted_slicing_points[1] < 0.84:
        adjusted_slicing_points = [80.0, 1.0, 0.90] + adjusted_slicing_points[1:]
    elif adjusted_slicing_points[1] < 0.80:
        adjusted_slicing_points = [80.0, 1.0, 0.90, 0.94] + adjusted_slicing_points[1:]

    return adjusted_slicing_points


def generate_slice_report(ideal_refl: list, refls: list, half1: pd.DataFrame) -> list:
    """Generates a report of reflection data slices.

    Args:
        ideal_refl (list): List of ideal reflections.
        refls (list): List of observed reflections.
        half1 (pd.DataFrame): Data for the first half of reflections.

    Returns:
        list: Slice report containing statistics for each resolution slice.
    """
    result_list = []
    resolution_slices = generate_slice_d(half1)

    for i in range(len(resolution_slices) - 1):
        low_res, high_res = resolution_slices[i], resolution_slices[i + 1]
        temp_refls = slice_reflections(refls, low_res, high_res)
        temp_ideals = slice_reflections(ideal_refl, low_res, high_res)
        if temp_refls > temp_ideals:
            temp_refls = temp_refls

        I_values = [row[4] for row in temp_refls]
        total_count = sum(len(I) if isinstance(I, list) else 1 for I in I_values)

        rint, rmeas, rexp = calculate_r_factors(temp_refls)

        cc12, cc_crit = calculate_cc_half(temp_refls)

        # Create a dictionary for the current slice
        result = {
            "low_res": low_res,
            "high_res": high_res,
            "N_obs": total_count,
            "N_uni": len(temp_refls),
            "ideal_N": len(temp_ideals),
            "completeness": round(100 * len(temp_refls) / len(temp_ideals), 2),
            "multiplicity": round(total_count / len(temp_refls), 2),
            "Isa_meas": calculate_mean_i_over_sigma(temp_refls),
            "R_int": rint,
            "R_meas": rmeas,
            "R_exp": rexp,
            "CC1/2": cc12,
            "CC_crit": cc_crit
        }
        result_list.append(result)
    return result_list


def accumulate_statistics(refls: list, reso: float) -> tuple:
    """Accumulates statistical data for reflections within a resolution limit.

    Args:
        refls (list): List of reflections.
        reso (float): Resolution limit.

    Returns:
        tuple: Statistical metrics (number of reflections, mean intensity,
            R factors, CC1/2).
    """
    temp_refls = slice_reflections(refls, 999, reso)
    return (len(temp_refls), calculate_mean_i_over_sigma(temp_refls), calculate_r_factors(temp_refls),
            calculate_cc_half(temp_refls))


def calculate_resolution_limit(unique_refls: list, half1: pd.DataFrame, p: float = 0.005) -> float:
    """Calculates the resolution limit based on CC, Rmeas and I/S.

    Args:
        unique_refls (list): List of unique reflections.
        half1 (pd.DataFrame): Data for the first half of reflections.
        p (float, optional): p-value for the correlation test. Defaults to 0.01.

    Returns:
        float: Resolution limit.
    """
    _list = generate_slice_d(half1)
    if len(_list) <= 3:
        return 999
    reso = 999
    for i in range(1, len(_list) - 1):
        cc12, cc_crit = calculate_cc_half(slice_reflections(unique_refls, _list[i], _list[i + 1]), p)
        if cc12 >= cc_crit:
            reso = _list[i + 1]
        elif cc12 < cc_crit:
            break
        r_int, _, _ = calculate_r_factors(slice_reflections(unique_refls, _list[i], _list[i + 1]))
        if abs(r_int) > 180:
            break
        elif r_int > 100 or r_int < 0:
            isa = calculate_mean_i_over_sigma(slice_reflections(unique_refls, _list[i], _list[i + 1]))
            if isa < 0.5:
                break
    return reso


def calculate_cc_half(uniq_refls: list, p_value: float = 0.005) -> tuple:
    """
    Returns (CC1/2[%], critical_CC1/2[%] for two-sided p).
    Expects uniq_refls items like:
      (h,k,l,d, [I...], [σ...], wmean, w_sigma, mean_sigma)
    """

    if not uniq_refls:
        raise ValueError("Empty input.")

    # One pass to collect multiplicities, means, and per-group w_sigma
    lengths = np.array([len(r[4]) for r in uniq_refls], dtype=np.int64)
    multi_mask = lengths > 1
    if not np.any(multi_mask):
        raise ValueError("No reflections with more than one intensity measurement found.")

    means = np.array([uniq_refls[i][6] for i, m in enumerate(multi_mask) if m], dtype=np.float64)
    sigmas = np.array([uniq_refls[i][7] for i, m in enumerate(multi_mask) if m], dtype=np.float64)

    if means.size < 2:
        return np.round(0.0, 2), np.nan

    sigma_I2 = np.var(means, ddof=1)  # Var(<I>_h)
    sigma_e2 = np.mean(sigmas * sigmas)  # <σ_e^2>

    denom = sigma_I2 + sigma_e2
    if denom <= 0.0:
        raise ValueError("Non-positive denominator in CC1/2 calculation.")
    cc_half = (sigma_I2 - sigma_e2) / denom

    # Significance threshold via t-to-r transform
    df = means.size - 2
    if df <= 0:
        cc_critical = np.nan
    else:
        tcrit = t.ppf(1 - p_value / 2.0, df)
        cc_critical = np.sqrt((tcrit * tcrit) / (tcrit * tcrit + df))

    return np.round(100.0 * cc_half, 2), np.round(100.0 * cc_critical, 2)


def calculate_r_factors(refls: list) -> tuple:
    """
    Calculates R_int, R_meas, and R_exp (percent).
    Expects each item like:
      (h,k,l,d, [I_i...], [σ_i...], wmean, w_sigma, mean_sigma)
    """
    from itertools import chain as _chain

    if not refls:
        return 100, 100, 100

    G = len(refls)

    # Multiplicities per group
    lengths = np.fromiter((len(r[4]) for r in refls), dtype=np.int64, count=G)

    # Flatten ALL intensities and sigmas in one pass (avoids per-group arrays)
    total_n = int(lengths.sum())
    if total_n == 0:
        return None, None, None

    all_I = np.fromiter(_chain.from_iterable((r[4] for r in refls)),
                        dtype=np.float64, count=total_n)
    all_S = np.fromiter(_chain.from_iterable((r[5] for r in refls)),
                        dtype=np.float64, count=total_n)

    sum_I = all_I.sum(dtype=np.float64)
    if sum_I == 0.0:
        return None, None, None
    r_exp = np.round(100.0 * (all_S.sum(dtype=np.float64) / sum_I), 2)

    # Restrict to groups with multiplicity > 1 for R_int/R_meas numerators
    multi_mask = lengths > 1
    if not np.any(multi_mask):
        return None, None, r_exp

    idx_multi = np.nonzero(multi_mask)[0]
    mult_lengths = lengths[idx_multi]

    # Per-group means (element 6)
    mult_means = np.fromiter((refls[i][6] for i in idx_multi),
                             dtype=np.float64, count=idx_multi.size)

    # Flatten only multi-measured intensity values
    n_multi = int(mult_lengths.sum())
    mult_vals = np.fromiter(_chain.from_iterable((refls[i][4] for i in idx_multi)),
                            dtype=np.float64, count=n_multi)

    # Denominator for R_meas: sum of multi-measured intensities (common choice)
    sum_I_multi = mult_vals.sum(dtype=np.float64)
    if sum_I_multi == 0.0:
        return None, None, r_exp

    # Start indices per group (for reduceat)
    starts = np.empty_like(mult_lengths)
    starts[0] = 0
    if starts.size > 1:
        np.cumsum(mult_lengths[:-1], out=starts[1:])

    # In-place residuals: |I - <I>|
    np.subtract(mult_vals, np.repeat(mult_means, mult_lengths), out=mult_vals)
    np.abs(mult_vals, out=mult_vals)

    # Per-group Σ|I-<I>| via segmented reduction
    group_abs = np.add.reduceat(mult_vals, starts)

    # Numerators
    sum_int_diff = mult_vals.sum(dtype=np.float64)  # R_int
    sum_meas_diff = (group_abs * np.sqrt(mult_lengths / (mult_lengths - 1.0))).sum()  # R_meas

    r_int = np.round(100.0 * (sum_int_diff / sum_I), 2)
    r_meas = np.round(100.0 * (sum_meas_diff / sum_I_multi), 2)

    return r_int, r_meas, r_exp


def calculate_mean_i_over_sigma(refls: list) -> float:
    """Calculates the mean intensity over sigma for reflection data.

    Args:
        refls (list): List of reflection data.

    Returns:
        float: Mean intensity over sigma.
    """
    valid_entries = [
        mean_intensity / mean_sigma
        for _, _, _, _, intensities, sigmas, mean_intensity, _, mean_sigma in refls
        if len(sigmas) > 0 and mean_sigma > 0
    ]

    if not valid_entries:
        return 0.0

    return float(np.round(np.mean(valid_entries), 4))
