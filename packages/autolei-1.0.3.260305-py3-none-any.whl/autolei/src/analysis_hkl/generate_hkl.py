import numpy as np


def _cell_to_metrics_np(uc):
    a, b, c, alpha, beta, gamma = uc
    ar, br, gr = np.radians([alpha, beta, gamma])
    G = np.array([
        [a * a, a * b * np.cos(gr), a * c * np.cos(br)],
        [a * b * np.cos(gr), b * b, b * c * np.cos(ar)],
        [a * c * np.cos(br), b * c * np.cos(ar), c * c],
    ], dtype=np.float64)
    Ginv = np.linalg.inv(G)
    g11, g22, g33 = Ginv[0, 0], Ginv[1, 1], Ginv[2, 2]
    g12, g13, g23 = Ginv[0, 1], Ginv[0, 2], Ginv[1, 2]

    # 2x2 block for (k,l)
    a22, b23, c33 = g22, g23, g33
    det_kl = a22 * c33 - b23 * b23
    if det_kl <= 0:
        Gkl_inv = np.linalg.inv(np.array([[g22, g23], [g23, g33]], dtype=np.float64))
        inv_a, inv_b, inv_c = Gkl_inv[0, 0], Gkl_inv[0, 1], Gkl_inv[1, 1]
    else:
        inv_a = c33 / det_kl
        inv_b = -b23 / det_kl
        inv_c = a22 / det_kl

    # v = [g12, g13], w = Gkl_inv @ v
    w0 = inv_a * g12 + inv_b * g13
    w1 = inv_b * g12 + inv_c * g13

    s_h = g11 - (g12 * w0 + g13 * w1)
    if s_h <= 0:
        s_h = float(np.linalg.eigvalsh(Ginv).min())

    # lam_min of [[g22,g23],[g23,g33]]
    tr = g22 + g33
    lam_min_kl = 0.5 * (tr - np.sqrt(max(tr * tr - 4.0 * det_kl, 0.0)))

    return g11, g22, g33, g12, g13, g23, w0, w1, s_h, lam_min_kl


def _concat_int_ranges(starts: np.ndarray, stops: np.ndarray) -> np.ndarray:
    """
    Concatenate integer ranges [starts[i], stops[i]] for all i into one 1D array.
    Assumes starts,stops are 1D int arrays and stops>=starts (already filtered).
    """
    lengths = (stops - starts + 1).astype(np.int64)
    total = int(lengths.sum())
    if total <= 0:
        return np.empty(0, dtype=np.int32)

    # Build a 0..len-1 "ramp" inside each block using a single arange + repeat trick
    offsets = np.cumsum(lengths) - lengths
    ramp = np.arange(total, dtype=np.int64) - np.repeat(offsets, lengths)
    out = ramp + np.repeat(starts.astype(np.int64), lengths)
    return out.astype(np.int32, copy=False)


def generate_complete_reflection_list(
        uc, d_min=0.79, MM=False, hemisphere=True, unique_friedel=False, eps=1e-12
):
    """
    Pure-NumPy generator of all integer (h,k,l) with h^T G* h <= 1/d_min^2.
    Returns ndarray of shape (N,3), dtype int32.
    """
    inv_d2_max = (1.0 / d_min) ** 2
    g11, g22, g33, g12, g13, g23, w0, _w1, s_h, lam_min_kl = _cell_to_metrics_np(uc)
    if lam_min_kl <= 0:
        # Guard against degenerate cells
        lam_min_kl = 1e-300

    # h bounds
    h_max = int(np.floor(np.sqrt(inv_d2_max / s_h) + eps))
    blocks = []

    for h in range(-h_max, h_max + 1):
        hh = float(h * h)
        delta = inv_d2_max - s_h * hh
        if delta < -eps:
            continue
        if delta < 0.0:
            delta = 0.0

        # k interval for this h (ellipse slice)
        k0 = -h * w0
        r = np.sqrt(delta / lam_min_kl)
        k_min = int(np.ceil(k0 - r - eps))
        k_max = int(np.floor(k0 + r + eps))
        if k_max < k_min:
            continue

        ks = np.arange(k_min, k_max + 1, dtype=np.int32)
        kk = ks.astype(np.float64)

        g13h = g13 * h
        g12h = g12 * h

        # Quadratic in l for each k
        c0 = g11 * hh + 2.0 * g12h * kk + g22 * (kk * kk)
        dlin = g13h + g23 * kk
        rem = inv_d2_max - c0
        disc = dlin * dlin + g33 * rem

        valid_disc = disc >= -eps
        if not np.any(valid_disc):
            continue

        disc = np.where(disc < 0.0, 0.0, disc)
        sqrt_disc = np.sqrt(disc)

        lminf = (-dlin - sqrt_disc) / g33
        lmaxf = (-dlin + sqrt_disc) / g33

        # Ensure order
        lminf, lmaxf = np.minimum(lminf, lmaxf), np.maximum(lminf, lmaxf)

        if hemisphere:
            lmin_i = np.maximum(0, np.ceil(lminf - eps).astype(np.int64))
            lmax_i = np.maximum(-1, np.floor(lmaxf + eps).astype(np.int64))
        else:
            lmin_i = np.ceil(lminf - eps).astype(np.int64)
            lmax_i = np.floor(lmaxf + eps).astype(np.int64)

        ok = valid_disc & (lmax_i >= lmin_i)
        if not np.any(ok):
            continue

        ks_ok = ks[ok]
        lmin_ok = lmin_i[ok].astype(np.int32)
        lmax_ok = lmax_i[ok].astype(np.int32)

        # Build all l for each surviving k, then tile k and fill h
        ls = _concat_int_ranges(lmin_ok, lmax_ok)
        if ls.size == 0:
            continue
        ks_rep = np.repeat(ks_ok, (lmax_ok - lmin_ok + 1).astype(np.int64))
        hs_rep = np.full(ls.shape, h, dtype=np.int32)

        # Apply unique Friedel reduction on l=0 plane (hemisphere only)
        if hemisphere:
            # Always drop (0,0,0)
            drop = (hs_rep == 0) & (ks_rep == 0) & (ls == 0)
            if unique_friedel:
                drop |= (ls == 0) & ((ks_rep < 0) | ((ks_rep == 0) & (hs_rep <= 0)))
            keep = ~drop
            if not np.all(keep):
                hs_rep = hs_rep[keep]
                ks_rep = ks_rep[keep]
                ls = ls[keep]

        block = np.stack([hs_rep, ks_rep, ls], axis=1)
        blocks.append(block)

    if not blocks:
        return np.empty((0, 3), dtype=np.int32)

    return np.ascontiguousarray(np.vstack(blocks), dtype=np.int32)


if __name__ == "__main__":
    import cProfile
    import pstats
    import io

    pr = cProfile.Profile()
    pr.enable()
    uc = [120, 79.9, 38.4, 90, 90, 120]
    refls = generate_complete_reflection_list(uc, d_min=0.79, MM=True)
    pr.disable()
    s = io.StringIO()
    sortby = 'cumulative'
    ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
    ps.print_stats()
    print(s.getvalue())
    print(f"Number of reflections: {len(refls)}")
