import numpy as np
from io import StringIO


def load_xdsascii_hkl(hkl_path: str) -> tuple:
    """Loads HKL data from an XDS ASCII file *fast*.

    Returns:
        (sg_no: int, unit_cell_constants: list[float], data: np.ndarray[float64, (N, 6)])
        Columns in data: h, k, l, I, SIGI, flag
    """
    sg_no = 1
    unit_cell_constants = None

    # -------- First pass (bytes): parse header and stop right at data --------
    with open(hkl_path, "rb") as f:
        for line_number, raw in enumerate(f, start=1):
            s = raw.strip()
            if s.startswith(b'!SPACE_GROUP_NUMBER='):
                try:
                    sg_no = int(s.split(b'=', 1)[1].split()[0])
                except Exception:
                    # keep default
                    sg_no = 1
            elif s.startswith(b'!UNIT_CELL_CONSTANTS='):
                vals = s.split(b'=', 1)[1].split()
                if len(vals) != 6:
                    raise ValueError("Unit cell constants must contain exactly 6 floating-point numbers.")
                unit_cell_constants = [float(v) for v in vals]
            elif s == b'!END_OF_HEADER':
                if not unit_cell_constants:
                    raise ValueError("Unit cell constants not found in the header.")
                # Read *only* the numeric block once
                data_bytes = f.read()
                break
        else:
            raise ValueError("!END_OF_HEADER not found in the file.")

    # -------- Fast path: C-tokenise all numbers once, then reshape/select --------
    if not data_bytes:
        raise ValueError("No reflection data found.")

    # Drop empty and comment lines quickly (lines starting with '#' or '!')
    # (bytes indexing is cheap; 35 == '#', 33 == '!')
    lines = [ln for ln in data_bytes.splitlines() if ln and ln[0] not in (35, 33)]
    if not lines:
        raise ValueError("No valid reflection data found.")

    # Determine column count from the first good line
    first_cols = lines[0].split()
    if len(first_cols) < 10:
        for ln in lines[1:]:
            c = ln.split()
            if len(c) >= 10:
                first_cols = c
                break
    ncols = len(first_cols)
    if ncols < 10:
        raise ValueError("Data lines have fewer than 10 columns.")

    # Parse the whole numeric block at once (very fast)
    text = b"\n".join(lines).decode("ascii", errors="ignore")
    nums = np.fromstring(text, sep=" ")
    rows = nums.size // ncols

    if rows * ncols == nums.size:
        mat = nums.reshape(rows, ncols)
        arr = mat[:, (0, 1, 2, 3, 4, 9)]
    else:
        # Rare fallback for ragged files: still avoid re-reading the file
        sio = StringIO(text)
        arr = np.loadtxt(sio, usecols=(0, 1, 2, 3, 4, 9), dtype=np.float64, comments="#")
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)

    # Keep only rows with positive SIGI (5th col in our selection)
    arr = arr[arr[:, 4] > 0.0]

    if arr.size == 0:
        raise ValueError("No valid reflection data found.")

    if arr.shape[1] != 6:
        raise ValueError(f"Expected 6 columns in data_array, but got {arr.shape[1]}.")

    return int(sg_no), unit_cell_constants, arr.astype(np.float64, copy=False)
