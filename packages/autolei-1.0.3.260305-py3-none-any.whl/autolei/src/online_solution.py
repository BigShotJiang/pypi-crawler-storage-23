from __future__ import annotations

import os
import shutil
import subprocess
from typing import List, Dict, Optional, Any

from .visualisation.html_report import create_html_file
from .xds_input import cell_correct_online
from .xds_runner import xdsrunner
from .xds_analysis import extract_run_result
from .xds_shelx import convert_to_shelx
from .symm_shelx.make_shelx_ins import write_shelxt_ins


def analysis_lattice(
        result: Dict[str, Any],
        max_r_meas_ratio: float = 1.6,
        max_cc12_ratio: float = 1.2,
) -> Optional[Dict[str, Any]]:
    """Analyses the lattice information from the result dictionary.

    Selects the highest-symmetry Bravais lattice (based on the order in
    result["lattice_choice"], ignoring 'mI') whose r_meas_ratio and
    cc12_ratio are both below the given thresholds.

    Args:
        result (dict): Result dictionary containing crystallographic data.
                       Must contain a "lattice_choice" key.
        max_r_meas_ratio (float): Upper limit for r_meas_ratio (strict <).
        max_cc12_ratio (float): Upper limit for cc12_ratio (strict <).

    Returns:
        dict | None: The selected lattice entry (one of the dicts inside
                     result["lattice_choice"][...]) or None if no
                     suitable lattice is found.
    """
    lattice_choice = result.get("lattice_choice")
    if not isinstance(lattice_choice, dict):
        return None

    for bravais_key, candidates in lattice_choice.items():
        # Skip mI entirely, as requested
        if bravais_key == "mI":
            continue

        if not isinstance(candidates, list):
            continue

        best_for_this_lattice: Optional[Dict[str, Any]] = None

        for cand in candidates:
            if not isinstance(cand, dict):
                continue

            r_ratio = cand.get("r_meas_ratio")
            cc_ratio = cand.get("cc12_ratio")

            if r_ratio is None or cc_ratio is None:
                continue

            # Apply thresholds (strictly less than)
            if r_ratio >= max_r_meas_ratio and cc_ratio >= max_cc12_ratio:
                continue

            # Within the same lattice type, pick the "best" candidate:
            # 1) smallest r_meas_ratio
            # 2) tie-break by smallest r_meas
            if best_for_this_lattice is None:
                best_for_this_lattice = cand
            else:
                prev_r_ratio = best_for_this_lattice.get("r_meas_ratio", float("inf"))
                prev_r_meas = best_for_this_lattice.get("r_meas", float("inf"))
                curr_r_meas = cand.get("r_meas", float("inf"))

                if (r_ratio, curr_r_meas) < (prev_r_ratio, prev_r_meas):
                    best_for_this_lattice = cand

        # If we found any acceptable candidate for this lattice type,
        # this is the highest symmetry one (due to order), so return it.
        if best_for_this_lattice is not None:
            return best_for_this_lattice

    # No suitable lattice found
    return None


def _find_shelxt_executable() -> str:
    for candidate in ("shelxt", "shelxt.exe"):
        path = shutil.which(candidate)
        if path:
            return path
    raise FileNotFoundError("SHELXT executable not found on PATH.")


def run_shelxt_ins(shelxt_exec, xds_dir: str) -> None:
    auto_dir = os.path.join(xds_dir, "auto")
    os.makedirs(auto_dir, exist_ok=True)

    for extension in ("ins", "HKL"):
        src = os.path.join(xds_dir, f"autolei.{extension}")
        # use lowercase extension in the auto folder
        dst_ext = extension.lower()
        dst = os.path.join(auto_dir, f"autolei.{dst_ext}")
        if not os.path.exists(src):
            raise FileNotFoundError(f"Missing file {src}")
        if os.path.exists(dst):
            os.remove(dst)
        shutil.move(src, dst)

    subprocess.run([shelxt_exec, "autolei"], cwd=auto_dir, check=True)


def online_solution(input_path: str, xds_path: str, compl_limit: float = 50, shelxt_exec: str = "shelxt",
                    composition: str = "C Cl"):
    """Performs online crystallographic solution for a single XDS dataset.

    Args:
        input_path (str): Path to the input directory.
        xds_path (str): Path to the XDS dataset identifier.
        shelxt_exec (str): Path to the SHELXT executable. Defaults to "shelxt".
        compl_limit (float, optional): Completeness limit for filtering results. Defaults to 0.6.
    Returns:
        None
    """
    xds_dir = os.path.dirname(xds_path)
    xdsrunner(input_path, [xds_path], True, False)
    xds_ascii = os.path.join(xds_dir, "XDS_ASCII.HKL")
    if not os.path.exists(xds_ascii):
        print(f"XDS auto-reduction failed for {xds_path}.")
        return
    result = extract_run_result(xds_dir)
    higher_lattice = analysis_lattice(result)
    if higher_lattice:
        cell_correct_online(xds_path, " ".join(str(x) for x in higher_lattice["cell_parameters"]),
                            str(higher_lattice.get("sg_no")))
        xdsrunner(input_path, [xds_path], True, False)
        if not os.path.exists(xds_ascii):
            print(f"XDS auto-reduction failed for {xds_path}.")
            return
        result = extract_run_result(xds_dir)
    if result.get('completeness', 0) < compl_limit:
        print(
            f"Dataset {xds_path} completeness {result.get('completeness', 0):.2f} below limit {compl_limit}. Skipping.")
        return
    convert_to_shelx(xds_dir)
    write_shelxt_ins(input_path=xds_dir, composition=composition, filename="autolei", merge=False)
    create_html_file(xds_dir, "single")
    run_shelxt_ins(shelxt_exec, xds_dir)


def online_solution_batch(input_path: str, xds_list: List[str], compl_limit: float = 50, composition: str = "C Cl"):
    """Performs online crystallographic solution for a batch of XDS datasets.

    Args:
        input_path (str): Path to the input directory.
        xds_list (List[str]): List of XDS dataset identifiers.
        compl_limit (float, optional): Completeness limit for filtering results. Defaults to 60%.
    Returns:
        None
    """
    shelxt_exec = _find_shelxt_executable()
    for xds_id in xds_list:
        try:
            online_solution(input_path, xds_id, compl_limit, shelxt_exec, composition)
        except Exception as e:
            print(f"Error processing {xds_id}: {e}")
    print("Batch processing completed.")


if __name__ == "__main__":
    # Example usage
    input_path = "/mnt/c/AutoLEI_demo"
    xds_list = ["path/to/xds1", "path/to/xds2"]
    online_solution_batch(input_path, xds_list, compl_limit=0.6)
