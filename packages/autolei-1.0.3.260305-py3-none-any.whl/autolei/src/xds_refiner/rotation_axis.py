from __future__ import annotations

import os
from typing import Tuple, Optional, Callable

import numpy as np

# ----------------------------------------------------------------------------
# External helpers from your code base
# ----------------------------------------------------------------------------
from ..xds_input import replace_value, extract_keywords

# ----------------------------------------------------------------------------
# Constants & speed knobs
# ----------------------------------------------------------------------------
_DEFAULT_HIST_BINS: Tuple[int, int] = (1024, 512)
_MAX_SAMPLE_PAIRS: int = 1_000_000

# Two-stage optimization (set to True for max speed)
_ENABLE_TWO_STAGE: bool = True
_COARSE_BIN_FACTOR: int = 2  # coarse bins = full_bins // this (2 => half bins)
_COARSE_PAIRS: int = 250_000  # pairs used in coarse stage
_COARSE_STEP_DEG: float = 2.0  # coarse grid step (deg)
_COARSE_TOL_DEG: float = 0.2  # coarse golden tolerance (deg)

_FINAL_TOL_DEG: float = 0.05  # final golden tolerance (deg)
_FINAL_BRACKET_HALF_DEG: float = 1.2  # half-width of final bracket around coarse optimum

# Use fast atan2 approx (True) or exact np.arctan2 (False). You can also mix (fast for coarse, exact for final).
_USE_FAST_ATAN2_COARSE: bool = True
_USE_FAST_ATAN2_FINAL: bool = True

# Use fast L1.5-norm approximation for sqrt(x^2 + y^2) (saves sqrt)
_USE_FAST_NORM: bool = True

# Numerical constants as float32 to avoid upcasting
_PI32 = np.float32(np.pi)
_HALF_PI32 = np.float32(np.pi / 2.0)
_INV_2PI32 = np.float32(1.0 / (2.0 * np.pi))
_INV_PI32 = np.float32(1.0 / np.pi)
_EPS32 = np.finfo(np.float32).eps


# ----------------------------------------------------------------------------
# Small helper functions (logic from your original; kept in float32)
# ----------------------------------------------------------------------------
def parse_xds_inp(fn: str) -> tuple:
    """
    Parses the XDS.INP file to extract key parameters.

    Returns:
        tuple: (beam_center, osc_angle, pixelsize, wavelength, omega_current)
    """
    with open(fn, "r") as f:
        params = extract_keywords(f.readlines())

    rotx, roty, rotz = map(float, params["ROTATION_AXIS"][0].split()[:3])
    omega_current = np.degrees(np.arctan2(roty, rotx))
    pixelsize = float(params["QX"][0]) / (
            float(params["DETECTOR_DISTANCE"][0]) * float(params["X-RAY_WAVELENGTH"][0])
    )

    return (
        (float(params["ORGX"][0]), float(params["ORGY"][0])),
        float(params["OSCILLATION_RANGE"][0]),
        pixelsize,
        float(params["X-RAY_WAVELENGTH"][0]),
        omega_current,
    )


def change_axis(xds_dir: str, axis_angle: float) -> None:
    """Rewrite *XDS.INP* with a new ROTATION_AXIS* line."""
    xds_path = os.path.join(xds_dir, "XDS.INP")
    with open(xds_path, "r+", encoding="utf-8") as fh:
        lines = fh.readlines()
        axis_str = f"{np.cos(np.radians(axis_angle)):.4f} {np.sin(np.radians(axis_angle)):.4f} 0"
        lines = replace_value(lines, "ROTATION_AXIS", [axis_str], comment=False)
        fh.seek(0)
        fh.writelines(lines)
        fh.truncate()


# ---------------- coordinate transforms -------------------------------------
def make_2d_rotmat(theta: float) -> np.ndarray:
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s], [s, c]], dtype=np.float32)


def make(arr: np.ndarray, omega: float, wavelength: float) -> np.ndarray:
    """Convert 2‑D spot coords + angle into reciprocal‑space XYZ."""
    reflections = arr[:, :2]
    angle = arr[:, 2]

    rotated = reflections @ make_2d_rotmat(np.radians(omega))
    y, x = rotated.T  # preserve original behaviour

    R = 1.0 / wavelength
    sqrt_val = np.sqrt(np.clip(R ** 2 - x ** 2 - y ** 2, 0.0, None))
    C = (R - sqrt_val)[:, None]

    sin_a = np.sin(angle)
    cos_a = np.cos(angle)

    xyz = np.column_stack((x * cos_a, y, -x * sin_a)) + C * np.column_stack(
        (-sin_a, np.zeros_like(angle), -cos_a)
    )
    return xyz.astype(np.float32)


# ----------------------------------------------------------------------------
# Fast 2D histogram on fixed grid (no searchsorted)
# ----------------------------------------------------------------------------
class _BinParams(tuple):
    __slots__ = ()
    # (bins_phi, bins_theta, min_phi, inv_dphi, min_theta, inv_dtheta)


def _make_bin_params(bins: Tuple[int, int]) -> _BinParams:
    bins_phi, bins_theta = int(bins[0]), int(bins[1])
    min_phi = -_PI32
    dphi = (np.float32(2.0) * _PI32) / np.float32(bins_phi)
    inv_dphi = np.float32(1.0) / dphi

    min_theta = -_HALF_PI32
    dtheta = (_PI32) / np.float32(bins_theta)
    inv_dtheta = np.float32(1.0) / dtheta

    return _BinParams((bins_phi, bins_theta, float(min_phi), float(inv_dphi), float(min_theta), float(inv_dtheta)))


def _bin_count_flat(flat_idx: np.ndarray, bins_phi: int, bins_theta: int) -> np.ndarray:
    H = np.bincount(flat_idx, minlength=bins_phi * bins_theta)
    return H.reshape(bins_phi, bins_theta).astype(np.int32, copy=False)


# ----------------------------------------------------------------------------
# Very fast, vectorized atan2 approximation and fast XY norm
# ----------------------------------------------------------------------------
def _fast_norm_xy(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    # Approx ||(x,y)|| ≈ a*max + b*min  (a,b tuned; max error < 3e-3*true_norm typical)
    ax = np.abs(x)
    ay = np.abs(y)
    mx = np.maximum(ax, ay)
    mn = np.minimum(ax, ay)
    # Coeffs from literature for L1.5-ish norm approx (float32)
    return (np.float32(0.96043387) * mx + np.float32(0.39782473) * mn).astype(np.float32, copy=False)


def _fast_atan2(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    """
    Cheap atan2 approximation:
      atan(y/x) ≈ t / (1 + 0.28 t^2), with standard octant/quadrant reduction.
    Typical abs error ~0.004–0.005 rad. Good for ≥0.5° bins.
    """
    ax = np.abs(x)
    ay = np.abs(y)

    # t = min(ax, ay) / max(ax, ay)
    m = np.maximum(ax, ay)
    t = np.where(m > 0.0, np.minimum(ax, ay) / (m + _EPS32), 0.0).astype(np.float32, copy=False)

    a = t / (np.float32(1.0) + np.float32(0.28) * t * t)  # ~atan(t)
    # If ax >= ay: angle ≈ a; else: angle ≈ π/2 - a
    angle = np.where(ax >= ay, a, _HALF_PI32 - a)

    # Quadrant fix
    angle = np.where(x < 0.0, _PI32 - angle, angle)
    angle = np.where(y < 0.0, -angle, angle)
    return angle.astype(np.float32, copy=False)


# ----------------------------------------------------------------------------
# Binning directly from pairwise deltas (avoids intermediate phi/theta arrays)
# ----------------------------------------------------------------------------
def _flat_indices_from_pairs(
        sx: np.ndarray,
        sy: np.ndarray,
        sz: np.ndarray,
        bins_phi: int,
        bins_theta: int,
        inv_dphi: float,
        inv_dtheta: float,
        use_fast_atan2: bool,
        use_fast_norm: bool,
) -> np.ndarray:
    # φ index
    if use_fast_atan2:
        phi = _fast_atan2(sy, sx)
    else:
        phi = np.arctan2(sy, sx).astype(np.float32, copy=False)
    bp_idx = np.floor((phi + _PI32) * np.float32(inv_dphi)).astype(np.int32, copy=False)

    # θ index
    if use_fast_norm:
        r_xy = _fast_norm_xy(sx, sy)
    else:
        r_xy = np.hypot(sx, sy).astype(np.float32, copy=False)

    if use_fast_atan2:
        theta = _fast_atan2(sz, r_xy)
    else:
        theta = np.arctan2(sz.astype(np.float32, copy=False), r_xy)
    bt_idx = np.floor((theta + _HALF_PI32) * np.float32(inv_dtheta)).astype(np.int32, copy=False)

    # Clamp to [0, bins-1] to handle right-edge cases
    np.clip(bp_idx, 0, bins_phi - 1, out=bp_idx)
    np.clip(bt_idx, 0, bins_theta - 1, out=bt_idx)

    return bp_idx * bins_theta + bt_idx


def _hist_from_pairs_indices(
        xyz: np.ndarray,
        bins: Tuple[int, int],
        i: np.ndarray,
        j: np.ndarray,
        *,
        use_fast_atan2: bool,
        use_fast_norm: bool,
        bp: Optional[_BinParams] = None,
) -> np.ndarray:
    if bp is None:
        bp = _make_bin_params(bins)

    bins_phi, bins_theta, _min_phi, inv_dphi, _min_theta, inv_dtheta = bp
    bins_phi = int(bins_phi)
    bins_theta = int(bins_theta)

    sx = (xyz[i, 0] - xyz[j, 0]).astype(np.float32, copy=False)
    sy = (xyz[i, 1] - xyz[j, 1]).astype(np.float32, copy=False)
    sz = (xyz[i, 2] - xyz[j, 2]).astype(np.float32, copy=False)

    flat = _flat_indices_from_pairs(
        sx, sy, sz, bins_phi, bins_theta, inv_dphi, inv_dtheta, use_fast_atan2, use_fast_norm
    )
    return _bin_count_flat(flat, bins_phi, bins_theta)


def _hist_exact(xyz: np.ndarray, bins: Tuple[int, int], *, use_fast_atan2: bool, use_fast_norm: bool) -> np.ndarray:
    n = xyz.shape[0]
    if n < 2:
        return np.zeros(bins, dtype=np.int32)
    i, j = np.triu_indices(n, k=1)
    return _hist_from_pairs_indices(xyz, bins, i, j, use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm)


def _hist_sample(
        xyz: np.ndarray, bins: Tuple[int, int], max_pairs: int, *, use_fast_atan2: bool, use_fast_norm: bool
) -> np.ndarray:
    n = len(xyz)
    total_pairs = n * (n - 1) // 2
    if total_pairs <= max_pairs:
        return _hist_exact(xyz, bins, use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm)
    rng = np.random.default_rng()
    i = rng.integers(0, n, size=max_pairs, dtype=np.int32)
    j = rng.integers(0, n, size=max_pairs, dtype=np.int32)
    keep = i != j
    return _hist_from_pairs_indices(
        xyz, bins, i[keep], j[keep], use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm
    )


def cylinder_histo(
        xyz: np.ndarray,
        bins: Tuple[int, int] = _DEFAULT_HIST_BINS,
        *,
        method: str = "auto",
        max_pairs: int = _MAX_SAMPLE_PAIRS,
        use_fast_atan2: bool = True,
        use_fast_norm: bool = True,
) -> np.ndarray:
    if method == "exact":
        return _hist_exact(xyz, bins, use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm)
    if method == "sample":
        return _hist_sample(xyz, bins, max_pairs, use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm)
    n = len(xyz)
    return (
        _hist_exact(xyz, bins, use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm)
        if n * (n - 1) // 2 <= max_pairs
        else _hist_sample(xyz, bins, max_pairs, use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm)
    )


# ----------------------------------------------------------------------------
# Faster omega-search (coarse + golden)
# ----------------------------------------------------------------------------
def _precompute_static(arr: np.ndarray, wavelength: float):
    """Values that don't depend on omega."""
    reflections = arr[:, :2].astype(np.float32, copy=False)
    angle = arr[:, 2].astype(np.float32, copy=False)
    sin_a = np.sin(angle)
    cos_a = np.cos(angle)
    R = np.float32(1.0 / wavelength)
    return reflections, sin_a, cos_a, R


def _make_from_precomp(
        reflections: np.ndarray, sin_a: np.ndarray, cos_a: np.ndarray, R: float, omega: float
) -> np.ndarray:
    """Vectorised version of `make`, using precomputed angle trig + R."""
    rot = make_2d_rotmat(np.radians(omega))
    rotated = reflections @ rot
    y, x = rotated.T  # preserve original convention
    sqrt_val = np.sqrt(np.clip(R * R - x * x - y * y, 0.0, None))
    C = (R - sqrt_val)[:, None]

    xyz = np.column_stack((x * cos_a, y, -x * sin_a)) + C * np.column_stack(
        (-sin_a, np.zeros_like(sin_a), -cos_a)
    )
    return xyz.astype(np.float32, copy=False)


def _make_sample_pairs(n: int, max_pairs: int, rng: Optional[np.random.Generator] = None) -> tuple[
    np.ndarray, np.ndarray]:
    """Pre-sample index pairs once and reuse across all omega values."""
    if rng is None:
        rng = np.random.default_rng()
    total_pairs = n * (n - 1) // 2
    if total_pairs <= max_pairs:
        i, j = np.triu_indices(n, k=1)
        return i.astype(np.int32), j.astype(np.int32)
    i = rng.integers(0, n, size=max_pairs, dtype=np.int32)
    j = rng.integers(0, n, size=max_pairs, dtype=np.int32)
    keep = i != j
    return i[keep], j[keep]


def _variance_for_omega(
        omega: float,
        reflections: np.ndarray,
        sin_a: np.ndarray,
        cos_a: np.ndarray,
        R: float,
        bins: Tuple[int, int],
        pair_idx: tuple[np.ndarray, np.ndarray],
        *,
        use_fast_atan2: bool,
        use_fast_norm: bool,
) -> float:
    xyz = _make_from_precomp(reflections, sin_a, cos_a, R, omega)
    H = _hist_from_pairs_indices(xyz, bins, *pair_idx, use_fast_atan2=use_fast_atan2, use_fast_norm=use_fast_norm)
    return float(np.var(H, ddof=1))


def _golden_maximise(
        f: Callable[[float], float],
        a: float,
        b: float,
        tol: float,
        max_iter: int = 60,
) -> float:
    """Golden-section search for a maximum on [a, b]."""
    gr = (np.sqrt(5.0) - 1.0) / 2.0  # ≈ 0.618
    c = b - gr * (b - a)
    d = a + gr * (b - a)
    fc = f(c)
    fd = f(d)
    it = 0
    while (b - a) > tol and it < max_iter:
        if fc < fd:  # we want maximum
            a, c, fc = c, d, fd
            d = a + gr * (b - a)
            fd = f(d)
        else:
            b, d, fd = d, c, fc
            c = b - gr * (b - a)
            fc = f(c)
        it += 1
    return 0.5 * (a + b)


def find_optimised_axis(
        arr: np.ndarray,
        omega_start: float,
        wavelength: float,
        plusminus: float,
        step: float,
        bins: Tuple[int, int] = _DEFAULT_HIST_BINS,
        *,
        sampling: bool = True,
        pair_idx: Optional[tuple[np.ndarray, np.ndarray]] = None,  # allow reuse across scans
        max_workers: int | None = None,  # kept for API compatibility; unused
) -> float:
    """Two-stage (coarse+final) search for best omega, fast by default."""
    # Precompute omega-independent values
    reflections, sin_a, cos_a, R = _precompute_static(arr, wavelength)

    # Prepare (or reuse) pair indices
    n = len(arr)
    if pair_idx is None:
        pair_idx_full = _make_sample_pairs(n, _MAX_SAMPLE_PAIRS if sampling else (1 << 62))
    else:
        pair_idx_full = pair_idx

    # Fallback: single-stage (original golden) if disabled
    if not _ENABLE_TWO_STAGE:
        bp_final = _make_bin_params(bins)
        f_final = lambda w: _variance_for_omega(
            w, reflections, sin_a, cos_a, R, bins, pair_idx_full,
            use_fast_atan2=_USE_FAST_ATAN2_FINAL, use_fast_norm=_USE_FAST_NORM
        )
        # Coarse grid to bracket
        grid = np.arange(omega_start - plusminus, omega_start + plusminus + step, step, dtype=np.float32)
        vals = np.array([f_final(float(w)) for w in grid], dtype=np.float64)
        k = int(np.argmax(vals))
        a = float(grid[max(0, k - 1)]) if k > 0 else float(grid[k]) - max(step, 0.5)
        b = float(grid[min(len(grid) - 1, k + 1)]) if k < len(grid) - 1 else float(grid[k]) + max(step, 0.5)
        return _golden_maximise(f_final, min(a, b), max(a, b), tol=_FINAL_TOL_DEG)

    # -------------------------
    # Stage 1: Coarse (small sample + half bins)
    # -------------------------
    coarse_bins = (max(8, bins[0] // _COARSE_BIN_FACTOR), max(8, bins[1] // _COARSE_BIN_FACTOR))
    pair_idx_coarse = _make_sample_pairs(n, min(_COARSE_PAIRS, _MAX_SAMPLE_PAIRS))

    f_coarse = lambda w: _variance_for_omega(
        w, reflections, sin_a, cos_a, R, coarse_bins, pair_idx_coarse,
        use_fast_atan2=_USE_FAST_ATAN2_COARSE, use_fast_norm=_USE_FAST_NORM
    )

    coarse_step = max(_COARSE_STEP_DEG, step)
    grid = np.arange(omega_start - plusminus, omega_start + plusminus + coarse_step, coarse_step, dtype=np.float32)
    vals = np.array([f_coarse(float(w)) for w in grid], dtype=np.float64)
    k = int(np.argmax(vals))
    # Bracket around best coarse point
    a_coarse = float(grid[max(0, k - 1)]) if k > 0 else float(grid[k]) - coarse_step
    b_coarse = float(grid[min(len(grid) - 1, k + 1)]) if k < len(grid) - 1 else float(grid[k]) + coarse_step
    if a_coarse > b_coarse:
        a_coarse, b_coarse = b_coarse, a_coarse

    w_coarse = _golden_maximise(f_coarse, a_coarse, b_coarse, tol=_COARSE_TOL_DEG)

    # -------------------------
    # Stage 2: Final (full bins + full sample, narrow bracket)
    # -------------------------
    pair_idx_final = pair_idx_full
    f_final = lambda w: _variance_for_omega(
        w, reflections, sin_a, cos_a, R, bins, pair_idx_final,
        use_fast_atan2=_USE_FAST_ATAN2_FINAL, use_fast_norm=_USE_FAST_NORM
    )
    a_final = w_coarse - _FINAL_BRACKET_HALF_DEG
    b_final = w_coarse + _FINAL_BRACKET_HALF_DEG
    w_best = _golden_maximise(f_final, a_final, b_final, tol=_FINAL_TOL_DEG)
    return w_best


# ----------------------------------------------------------------------------
# I/O helpers (unchanged logic)
# ----------------------------------------------------------------------------
def load_spot_xds(fn: str, beam_center: Tuple[float, float], osc_angle: float, pixelsize: float) -> np.ndarray | None:
    try:
        arr = np.loadtxt(fn)
    except OSError:
        return None
    if arr.size == 0:
        return None
    refl = arr[:, :2] - np.asarray(beam_center)
    angle = arr[:, 2] * np.radians(osc_angle)
    refl *= pixelsize
    return np.column_stack((refl, angle))


# ----------------------------------------------------------------------------
# Top-level driver
# ----------------------------------------------------------------------------
def refine_axis(xds_dir: str) -> bool:
    xds_inp = os.path.join(xds_dir, "XDS.INP")
    spot_xds = os.path.join(xds_dir, "SPOT.XDS")

    beam_center, osc_angle, pixelsize, wavelength, omega_current = parse_xds_inp(xds_inp)
    if omega_current > 180.0:
        omega_current -= 360.0

    arr = load_spot_xds(spot_xds, beam_center, osc_angle, pixelsize)
    if arr is None:
        print("No SPOT.XDS data – axis not refined.")
        return False

    # Reuse one pair set across stages (full sample), coarse stage uses its own small set
    pair_idx = _make_sample_pairs(len(arr), _MAX_SAMPLE_PAIRS)

    omega_best = find_optimised_axis(
        arr,
        omega_current,
        wavelength,
        plusminus=10.0,
        step=1.0,
        bins=_DEFAULT_HIST_BINS,
        sampling=True,
        pair_idx=pair_idx,
    )

    # Keep your printouts (negative sign convention retained)
    print(f"Best omega: {-omega_best:.3f}°")
    print(f"Rotation axis found: {-omega_best:.2f}° / {np.radians(-omega_best):.3f} rad")

    # update XDS.INP if change is modest (safety)
    if abs(omega_best - omega_current) < 10.0:
        change_axis(xds_dir, omega_best)
        print("Correct rotation axis … OK")
        return True

    print("Large deviation – not writing XDS.INP.")
    return False


# -----------------------------------------------------------------------------
# __main__  – simple CLI
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    import cProfile

    cProfile.run(
        "refine_axis(\"/mnt/c/Work/ED/dbb01554/C5/C5_Zn_TATZ_TPE_3/xds\")",
        sort="tottime",
    )
