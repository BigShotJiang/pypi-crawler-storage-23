"""TIFF→SMV (ADSC) batch converter

This module discovers TIFF/TIF image series, prompts the user (PyQt5) for
metadata (HV, pixel size, camera length, angle ranges), and converts the frames
into SMV (.img) using FabIO, with a robust Pillow fallback.

Key features
------------
- FabIO-first TIFF reading with Pillow fallback (grayscale, uint16).
- Safe header typing (floats), and pixel size unit conversion (μm → mm).
- Patterned filename support (e.g., zero-padded indexes with '?').
- Threaded conversion with progress bar.
- Conservative exception handling (no broad excepts).

Public entry points
-------------------
- grab_info_tiff2img(directory: str, path_filter: bool = False) -> tuple
- convert_tiff2img(feedback: dict, wl: float, px_size_mm: float) -> None

Notes
-----
- This module uses PyQt5 widgets. Ensure a QApplication exists in the caller
  before invoking dialog functions.
- The SMV header fields follow common conventions used by ADSC readers.
"""
from __future__ import annotations

import glob
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Tuple, Optional, List

import fabio
from PIL import Image, UnidentifiedImageError
from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QGridLayout,
    QPushButton,
    QScrollArea,
    QMessageBox,
    QWidget,
)
from fabio import adscimage
from tqdm import tqdm

# Project-local utilities
from ..util import *  # noqa: F401,F403  # (natural_sort_key, find_folders_with_images, extract_pattern, etc.)
from ..xds_input import extract_keywords

# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------
script_dir = os.path.dirname(os.path.dirname(__file__))
config = __import__("configparser").ConfigParser()  # defer to keep imports local
config.read(os.path.join(os.path.dirname(script_dir), "setting.ini"))

try:
    set_max_worker = int(config["General"]["max_core"])  # type: ignore[index]
except (KeyError, ValueError):
    set_max_worker = 4

# Wavelength (Å) for common electron accelerating voltages (keV)
WAVELENGTHS: Dict[str, float] = {
    "400": 0.016439,
    "300": 0.019687,
    "200": 0.025079,
    "150": 0.029570,
    "120": 0.033492,
    "100": 0.037014,
    # Sometimes users pass values in eV (e.g., "200000.0"). Accept those keys too.
    "400000.0": 0.016439,
    "300000.0": 0.019687,
    "200000.0": 0.025079,
    "150000.0": 0.029570,
    "120000.0": 0.033492,
    "100000.0": 0.037014,
}


# -----------------------------------------------------------------------------
# Pillow-backed TIFF loading helpers
# -----------------------------------------------------------------------------
def _pil_to_uint16_gray(img: Image.Image) -> np.ndarray:
    """Convert a PIL image to a 2-D uint16 grayscale array.

    Ensures the output shape is (H, W), regardless of input mode.
    """
    # Convert color/palette images to 8-bit grayscale first
    if img.mode in {"P", "RGB", "RGBA", "CMYK", "YCbCr"}:
        img = img.convert("L")

    if img.mode == "I;16":
        arr = np.array(img, dtype=np.uint16)
        return arr

    if img.mode == "I":
        arr32 = np.array(img, dtype=np.int32)
        arr32 = np.clip(arr32, 0, 65535)
        return arr32.astype(np.uint16)

    if img.mode == "L":
        arr8 = np.array(img, dtype=np.uint8)
        return arr8.astype(np.uint16) << 8

    # Fallback: convert again to 8-bit gray then upscale
    img = img.convert("L")
    arr8 = np.array(img, dtype=np.uint8)
    return arr8.astype(np.uint16) << 8


def load_tiff_to_array(file_path: str) -> Tuple[Optional[np.ndarray], str]:
    """Load a .tif/.tiff into a uint16 2-D array, returning (data, timestamp_str).

    The timestamp string is derived from file mtime ("YYYY-MM-DD HH:MM"). If the
    file does not exist, (None, timestamp) is returned.
    """
    ts = (
        0
        if not os.path.isfile(file_path)
        else datetime.fromtimestamp(os.path.getmtime(file_path)).strftime("%Y-%m-%d %H:%M")
    )

    if not os.path.isfile(file_path):
        return None, ts  # not an error: caller may choose to synthesize

    # 1) Try FabIO first (scientific TIFFs)
    try:
        fimg = fabio.open(file_path)
        data = fimg.data
        if data.ndim == 3:
            # Reduce potential RGB to first channel (rare for fabio)
            data = data[..., 0]
        if data.dtype != np.uint16:
            if np.issubdtype(data.dtype, np.integer):
                data = data.astype(np.uint16)
            else:
                data = np.clip(data, 0, 65535).astype(np.uint16)
        return data, ts
    except (OSError, ValueError):
        pass  # fall back to Pillow

    # 2) Pillow fallback; force grayscale and 2-D
    try:
        with Image.open(file_path) as img:
            try:
                if getattr(img, "n_frames", 1) > 1:
                    img.seek(0)
            except (EOFError, OSError):
                # Ignore multi-frame probing issues; continue with current frame
                pass
            data = _pil_to_uint16_gray(img)
            if data.ndim == 3:
                data = data[..., 0].astype(np.uint16)
            return data, ts
    except (UnidentifiedImageError, OSError, ValueError):
        return None, ts


def get_tiff_size(file_path: str) -> Tuple[int, int]:
    """Return image size as (height, width) with FabIO→Pillow fallback.

    Returns an empty tuple on failure.
    """
    # Try FabIO quickly
    try:
        t = fabio.open(file_path)
        h, w = t.data.shape[:2]
        return h, w
    except (OSError, ValueError):
        pass

    # Fallback: Pillow
    try:
        with Image.open(file_path) as img:
            w, h = img.size
            return h, w
    except (UnidentifiedImageError, OSError, ValueError):
        return 0, 0


# -----------------------------------------------------------------------------
# GUI
# -----------------------------------------------------------------------------
class MetadataDialog(QDialog):
    """Modal dialog to collect/confirm per-series metadata.

    Parameters
    ----------
    path_dict : dict
        Mapping from folder path to info dict produced by discovery.
    cl_default : str
        Default camera length (mm) to prefill.
    HV_default : str
        Default accelerating voltage (keV) to prefill.
    pixel_size_default : str
        Default detector pixel size (μm) to prefill.
    root_dir : str
        Root directory for the conversion session.
    parent : QWidget | None
        Optional parent widget.
    """

    def __init__(self, path_dict: dict, cl_default: str, HV_default: str,
                 pixel_size_default: str, root_dir: str, parent=None):
        super().__init__(parent)
        self.path_dict = path_dict
        self.cl_default = cl_default
        self.HV_default = HV_default
        self.pixel_size_default = pixel_size_default
        self.root_dir = root_dir
        self.result = (None, None, None)
        self.metadata_entries: Dict[str, Dict[str, QLineEdit]] = {}
        self.initUI()

    def initUI(self) -> None:
        """Initialize the dialog UI with metadata fields and buttons."""
        self.setStyleSheet(
            """
            QDialog { background-color: #ffffff; }
            QLabel { font-size: 14pt; color: #333; }
            QLineEdit { border: 1px solid #ccc; padding: 4px; border-radius: 4px; font-size: 14pt; }
            QPushButton { background-color: #0B76A0; color: white; border: none; padding: 6px 12px; border-radius: 4px; 
            font-size: 14pt; }
            QPushButton:hover { background-color: #005fa3; }
            QScrollArea { border: 1px solid #ccc; border-radius: 4px; background: #B7D9FF; }
            """
        )
        self.setWindowTitle("Metadata Input")
        self.setMinimumSize(750, 700)

        mainLayout = QVBoxLayout(self)
        mainLayout.setContentsMargins(15, 15, 15, 15)
        mainLayout.setSpacing(10)

        # --- Top layout for HV and Pixel Size ---
        topLayout = QHBoxLayout()
        labelHV = QLabel("HV (keV)")
        self.hvLineEdit = QLineEdit(self.HV_default)
        labelUnit = QLabel(",  Pixel Size")
        self.pixelSizeLineEdit = QLineEdit(self.pixel_size_default)
        labelPixelUnit = QLabel("mm")

        topLayout.addWidget(labelHV)
        topLayout.addWidget(self.hvLineEdit)
        topLayout.addWidget(labelUnit)
        topLayout.addWidget(self.pixelSizeLineEdit)
        topLayout.addWidget(labelPixelUnit)
        mainLayout.addLayout(topLayout)

        # --- Horizontal separator ---
        sepLine = QFrame()
        sepLine.setFrameShape(QFrame.HLine)
        sepLine.setFrameShadow(QFrame.Sunken)
        mainLayout.addWidget(sepLine)

        # --- Scroll area for metadata entries ---
        scrollArea = QScrollArea()
        scrollArea.setWidgetResizable(True)
        scrollArea.setMaximumHeight(600)

        scrollWidget = QWidget()
        gridLayout = QGridLayout(scrollWidget)
        gridLayout.setContentsMargins(10, 10, 10, 10)
        gridLayout.setSpacing(8)
        gridLayout.setAlignment(Qt.AlignTop)

        # Define column stretch factors
        gridLayout.setColumnStretch(0, 1)
        gridLayout.setColumnStretch(1, 0)
        gridLayout.setColumnStretch(2, 0)
        gridLayout.setColumnStretch(3, 0)
        gridLayout.setColumnStretch(4, 0)

        # Header row
        headers = ["Relative Path", "Frames  ", "Range Start", "Range End", "CL (mm)"]
        for col, header in enumerate(headers):
            headerLabel = QLabel(header)
            font = headerLabel.font()
            font.setBold(True)
            headerLabel.setFont(font)
            gridLayout.addWidget(headerLabel, 0, col)

        # Populate rows for each path entry
        row = 1
        for path, info in self.path_dict.items():
            relative_path = info.get("relative_path", "N/A")
            num_frames = int(info.get("num", 0))

            # Locate metadata file for default angles
            meta_path = ""
            if os.path.isfile(os.path.join(path, "metadata.txt")):
                meta_path = os.path.join(path, "metadata.txt")
            elif os.path.isfile(os.path.join(os.path.dirname(path), "metadata.txt")):
                meta_path = os.path.join(os.path.dirname(path), "metadata.txt")

            if meta_path:
                try:
                    with open(meta_path) as f:
                        metadata_dict = extract_keywords(f.readlines())
                except (OSError, UnicodeDecodeError):
                    metadata_dict = {}

                def _parse_float_first(key: str) -> float:
                    try:
                        return float(metadata_dict.get(key, [0])[0])
                    except (TypeError, ValueError):
                        return 0.0

                start_angle = _parse_float_first("START_ANGLE")
                end_angle = _parse_float_first("END_ANGLE")
                osc_angle = _parse_float_first("OSCILLATION_RANGE")

                if start_angle and (not end_angle) and osc_angle:
                    end_angle = round(start_angle + num_frames * osc_angle, 2)
                elif (not start_angle) and end_angle and osc_angle:
                    start_angle = round(end_angle - num_frames * osc_angle, 2)
                start_angle_str = str(start_angle) if start_angle else ""
                end_angle_str = str(end_angle) if end_angle else ""
            else:
                start_angle_str = ""
                end_angle_str = ""

            # Create row widgets
            labelRelPath = QLabel(relative_path)
            labelFrames = QLabel(str(num_frames))
            rangeStartEdit = QLineEdit(start_angle_str)
            rangeEndEdit = QLineEdit(end_angle_str)
            clEdit = QLineEdit(self.cl_default)

            gridLayout.addWidget(labelRelPath, row, 0)
            gridLayout.addWidget(labelFrames, row, 1)
            gridLayout.addWidget(rangeStartEdit, row, 2)
            gridLayout.addWidget(rangeEndEdit, row, 3)
            gridLayout.addWidget(clEdit, row, 4)

            self.metadata_entries[path] = {
                "range_start": rangeStartEdit,
                "range_end": rangeEndEdit,
                "cl": clEdit,
            }
            row += 1

        gridLayout.setRowStretch(row, 1)
        scrollArea.setWidget(scrollWidget)
        mainLayout.addWidget(scrollArea)

        # --- Buttons ---
        buttonLayout = QHBoxLayout()
        buttonLayout.addStretch()
        convertButton = QPushButton("CONVERT")
        cancelButton = QPushButton("CANCEL")
        convertButton.clicked.connect(self.on_convert)
        cancelButton.clicked.connect(self.on_cancel)
        buttonLayout.addWidget(convertButton)
        buttonLayout.addWidget(cancelButton)
        mainLayout.addLayout(buttonLayout)

    def on_convert(self) -> None:
        """Validate inputs and emit the result on successful conversion."""
        hv = self.hvLineEdit.text().strip()
        pixel_size_text = self.pixelSizeLineEdit.text().strip()

        if not hv or not pixel_size_text:
            QMessageBox.critical(self, "Error", "HV or Pixel Size is empty!")
            return

        if hv not in WAVELENGTHS:
            accepted = sorted({k.rstrip(".0") for k in WAVELENGTHS.keys()})
            QMessageBox.critical(self, "Error", f"HV must be one of {accepted} (keV).")
            return

        try:
            pixel_size_mm = float(pixel_size_text)
        except ValueError:
            QMessageBox.critical(self, "Error", "Pixel Size must be numeric (μm).")
            return

        updated_path_dict: Dict[str, dict] = {}
        for _path, _info in self.path_dict.items():
            updated_info = dict(_info)

            try:
                n_frames = int(_info.get("num", 0))
            except (TypeError, ValueError):
                n_frames = 0
            if n_frames <= 0:
                QMessageBox.critical(self, "Error", f"Invalid frame count for {_path}.")
                return

            if _path in self.metadata_entries:
                entries = self.metadata_entries[_path]
                range_start = entries["range_start"].text().strip()
                range_end = entries["range_end"].text().strip()
                cl = entries["cl"].text().strip()

                if not (range_start and range_end and cl):
                    QMessageBox.critical(self, "Error", f"Some entries in {_path} are empty!")
                    return

                try:
                    start_f = float(range_start)
                    end_f = float(range_end)
                    osc_range = round((end_f - start_f) / n_frames, 4)
                except ValueError as exc:
                    QMessageBox.critical(self, "Error", f"Error in {_path}: {exc}")
                    return

                updated_info.update({
                    "range_start": range_start,
                    "osc_range": str(osc_range),
                    "cl": cl,
                })
            updated_path_dict[_path] = updated_info

        self.result = (updated_path_dict, WAVELENGTHS[hv], pixel_size_mm)
        self.accept()

    def on_cancel(self) -> None:
        """Handle cancellation by closing the dialog."""
        self.result = (None, None, None)
        self.close()


# -----------------------------------------------------------------------------
# Dialog driver
# -----------------------------------------------------------------------------
def metadata_input(path_dict: dict, root_dir: str) -> Tuple[Optional[dict], Optional[float], Optional[float]]:
    """Launch the metadata dialog and return user selections.

    Parameters
    ----------
    path_dict : dict
        Discovered series information from `grab_info_tiff2img`.
    root_dir : str
        Root directory for the session; used to locate Input_parameters.txt.

    Returns
    -------
    (feedback, wavelength_A, pixel_size_mm)
        Populated values on success; `(None, None, None)` if cancelled.
    """
    # Defaults from Input_parameters.txt if available
    ip_path = os.path.join(root_dir, "Input_parameters.txt")
    if os.path.isfile(ip_path):
        try:
            with open(ip_path) as file:
                keyword = extract_keywords(file.readlines())
            cl_default = keyword.get("DETECTOR_DISTANCE", [""])[0]
            wavelength_default = keyword.get("X-RAY_WAVELENGTH", [""])[0]
            pixel_size_default = keyword.get("QX", [""])[0]
        except (OSError, UnicodeDecodeError):
            cl_default = wavelength_default = pixel_size_default = ""
    else:
        cl_default = wavelength_default = pixel_size_default = ""

    # Compute a default HV from wavelength, if present
    try:
        h, m0, c, e = 6.62607015e-34, 9.10938356e-31, 2.99792458e8, 1.602176634e-19
        wl_m = float(wavelength_default) * 1e-10
        voltage = (
                (np.sqrt((m0 * c ** 2) ** 2 + (h * c / wl_m) ** 2) - m0 * c ** 2) / e / 1e3
        )
        HV_default = str(int(round(voltage / 10.0) * 10))
    except (TypeError, ValueError, ZeroDivisionError):
        HV_default = ""

    dialog = MetadataDialog(path_dict, cl_default, HV_default, pixel_size_default, root_dir)
    dialog.exec()  # modal
    return dialog.result  # type: ignore[return-value]


# -----------------------------------------------------------------------------
# SMV writing
# -----------------------------------------------------------------------------
def write_smv_tiff(
        file_path: str,
        phi: float,
        osc_range: float,
        wavelength: float,
        camera_length_mm: float,
        pixel_size_mm: float,
        image_size: Optional[Tuple[int, int]]
) -> Tuple[str, bool]:
    """Write a TIFF frame as SMV (.img), using Pillow fallback when needed.

    Parameters
    ----------
    file_path : str
        Path to the source TIFF/TIF. If missing, a zero frame is synthesized
        using `image_size`.
    phi : float
        Start angle for this frame.
    osc_range : float
        Oscillation range per frame (deg).
    wavelength : float
        Electron wavelength (Å).
    camera_length_mm : float
        Detector distance / camera length in **mm**.
    pixel_size_mm : float
        Detector pixel size in **mm**.
    image_size : (int, int) | None
        Required when `file_path` is missing; (H, W).

    Returns
    -------
    (file_path, True)
        On success. Raises on irrecoverable failures.
    """
    if not os.path.isfile(file_path):
        if image_size is None:
            raise FileNotFoundError(f"{file_path} not found and no image_size provided")
        data = np.zeros(image_size, dtype=np.uint16)
        ts = 0
    else:
        data, ts = load_tiff_to_array(file_path)
        if data is None:
            if image_size is None:
                raise RuntimeError(f"Could not read {file_path} with either FabIO or Pillow")
            data = np.zeros(image_size, dtype=np.uint16)

    smv = adscimage.AdscImage(data=data.astype(np.uint16))

    base = os.path.splitext(os.path.basename(file_path))[0]
    out_dir = os.path.dirname(file_path)
    output_path = os.path.join(out_dir, f"{base}.img")

    smv.header = {
        "DIM": 2,
        "BYTE_ORDER": "little_endian",
        "TYPE": "unsigned_short",
        "HEADER_BYTES": 512,
        "DATE": ts,
        "WAVELENGTH": float(wavelength),
        "TIME": 0,
        "PHI": float(round(phi, 4)),
        "OSC_START": float(round(phi, 4)),
        "OSC_RANGE": float(osc_range),
        "PIXEL_SIZE": float(pixel_size_mm),  # mm
        "DISTANCE": float(camera_length_mm),  # mm
        "Data_type": "unsigned short int",
    }

    smv.write(output_path)
    return file_path, True


# -----------------------------------------------------------------------------
# Conversion driver
# -----------------------------------------------------------------------------
def conversion_tiff_file(
        info: dict,
        wl: float,
        px_size_mm: float,
        max_worker: int = set_max_worker,
) -> int:
    """Convert a single discovered series to SMV.

    Parameters
    ----------
    info : dict
        Series information: expects keys {"osc_range", "range_start", "image",
        "cl", "file_base_name", "first", "last", "num"}.
    wl : float
        Wavelength (Å).
    px_size_mm : float
        Pixel size (mm).
    max_worker : int
        Max worker threads.

    Returns
    -------
    int
        Count of successfully converted frames.
    """
    results: List[Tuple[str, bool]] = []
    osc_range = float(info["osc_range"])  # may raise KeyError/ValueError upstream if missing
    start_angle = float(info["range_start"])  # idem
    tiff_files: List[str] = list(info["image"])  # discovered paths
    cl_mm = float(info["cl"])  # ensure numeric
    file_base_name = str(info["file_base_name"])
    first = int(info["first"])  # inclusive
    last = int(info["last"])  # inclusive

    placeholder_count = file_base_name.count("?")
    if placeholder_count > 0:
        replacement_format = f"{{:0{placeholder_count}d}}"
        file_names = [
            file_base_name.replace("?" * placeholder_count, replacement_format.format(i))
            for i in range(first, last + 1)
        ]
    else:
        # No pattern; rely on the discovered list
        file_names = list(tiff_files)

    # Determine dimensions robustly
    probe_candidates: List[str] = []
    if file_names:
        probe_candidates.append(file_names[0])
    if tiff_files:
        probe_candidates.append(tiff_files[0])

    dims: Tuple[int, int] = (0, 0)
    for probe in probe_candidates:
        if os.path.isfile(probe):
            dims = get_tiff_size(probe)
            if dims:
                break
    if not dims:
        for probe in probe_candidates:
            if os.path.isfile(probe):
                try:
                    with Image.open(probe) as _im:
                        w, h = _im.size
                        dims = (h, w)
                    break
                except (UnidentifiedImageError, OSError, ValueError):
                    continue
    if not dims:
        raise RuntimeError("Could not determine image dimensions from any probe file")

    max_workers = max(1, min(int(max_worker), (os.cpu_count() or 4)))

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_tiff = {
            executor.submit(
                write_smv_tiff,
                image_path,
                start_angle + i * osc_range,
                osc_range,
                wl,
                cl_mm,
                px_size_mm,
                dims,
            ): image_path
            for i, image_path in enumerate(file_names)
        }
        for future in tqdm(as_completed(future_to_tiff), total=len(file_names), desc="Converting", ascii=True):
            tiff_path = future_to_tiff[future]
            try:
                results.append(future.result())
            except (OSError, ValueError, RuntimeError, FileNotFoundError) as exc:
                print(f"{tiff_path} generated an exception: {exc}")

    converted_count = sum(1 for _, ok in results if ok)
    print(f"{converted_count} of {len(file_names)} converted.\n")
    return converted_count


# -----------------------------------------------------------------------------
# Directory enumeration and top-level entry points
# -----------------------------------------------------------------------------
def grab_info_tiff2img(directory: str, path_filter: bool = False) -> Tuple[
    Optional[dict], Optional[float], Optional[float]]:
    """Discover TIFF/TIF series under a directory and prompt for metadata.

    The function scans for subfolders that contain `.tif/.tiff` files, groups
    by filename pattern, filters out folders that likely have already been
    converted (based on `.img` presence), and builds a `path_dict` describing
    each series. It then opens a dialog for the user to fill in angles, camera
    length, HV and pixel size.

    Parameters
    ----------
    directory : str
        Root directory to scan.
    path_filter : bool, optional
        If your `find_folders_with_images` supports it, applies additional
        filtering (default: False).

    Returns
    -------
    (feedback, wavelength_A, pixel_size_mm)
        Values to be passed into `convert_tiff2img` on success;
        `(None, None, None)` if nothing to convert or the user cancels.
    """
    if not directory:
        print("No directory selected. Exiting.")
        return None, None, None

    folder_paths_tiff = find_folders_with_images(directory, extension=".tiff", path_filter=path_filter)
    folder_paths_tif = find_folders_with_images(directory, extension=".tif", path_filter=path_filter)
    folder_paths = sorted(set(folder_paths_tiff) | set(folder_paths_tif))
    path_dict: Dict[str, dict] = {}

    for path in folder_paths:
        parent_folder = os.path.dirname(path)
        cred_log_path = os.path.join(parent_folder, "cRED_log.txt")

        # Skip likely already-processed folders
        if path.endswith("tiff_image") or os.path.isfile(cred_log_path):
            continue

        tiff_files = sorted(
            glob.glob(os.path.join(path, "*.tif")) +
            glob.glob(os.path.join(path, "*.tiff")),
            key=natural_sort_key,
        )

        # Group by extension/length to find the dominant series
        file_groups: Dict[Tuple[str, int], List[str]] = {}
        for file in tiff_files:
            filename = os.path.basename(file)
            if re.search(r"\d+\.(?:tif|tiff)$", filename, flags=re.IGNORECASE):
                ext = filename.rsplit(".", 1)[-1].lower()
                length = len(filename)
                key = (ext, length)
                file_groups.setdefault(key, []).append(file)

        max_group = max(file_groups.values(), key=len, default=[])
        tiff_files = sorted(max_group, key=natural_sort_key)

        # Determine if conversion seems already done (IMGs exist)
        img_files = sorted(glob.glob(os.path.join(os.path.join(parent_folder, "SMV", "data"), "*.img")),
                           key=natural_sort_key)
        if not img_files:
            img_files = sorted(glob.glob(os.path.join(path, "*.img")), key=natural_sort_key)
        if len(img_files) >= len(tiff_files) > 0:
            print(f"Directory {path} doesn't need conversion.")
            continue

        if not tiff_files:
            continue

        file_base_name, first, last = extract_pattern(tiff_files)
        path_dict[path] = {
            "relative_path": os.path.relpath(path, directory),
            "file_base_name": file_base_name,
            "first": first,
            "last": last,
            "num": last - first + 1,
            "frame": len(tiff_files),
            "image": tiff_files,
            "base_name": file_base_name,
        }

    if not path_dict:
        print("No valid tif/tiff documents. Exiting.")
        return None, None, None

    feedback, wl, px_size_mm = metadata_input(path_dict, directory)
    return feedback, wl, px_size_mm


def convert_tiff2img(feedback: dict, wl: float, px_size_mm: float) -> None:
    """Convert all discovered series to SMV using prior feedback values.

    Parameters
    ----------
    feedback : dict
        Output of `grab_info_tiff2img`/`metadata_input` representing per-series
        metadata (angles, camera length, etc.).
    wl : float
        Wavelength (Å) selected/derived in the dialog.
    px_size_mm : float
        Detector pixel size in **mm** (already converted).
    """
    print("********************************************")
    print("*            TIFF to SMV Image             *")
    print("********************************************\n")
    for path, info in feedback.items():
        print(f"Enter {path}")
        conversion_tiff_file(info, wl, px_size_mm)
    print("Conversion Finished.\n")
    return
