"""
XDS to SHELX Conversion Module
==============================

Utilities for converting crystallographic data from XDS format to SHELX format.

Key operations:
- Locate input HKL (single dataset: XDS_ASCII.HKL; multi-dataset: merge/all.hkl)
- Write XDSCONV.INP and run xdsconv
- Write .P4P and SHELXT .ins
- Update CIF/PCF metadata files (single dataset flow)

Authors:
    Yinlin Chen and Lei Wang

License:
    BSD 3-Clause
"""

from __future__ import annotations

import math
import os
import shutil
import subprocess
import warnings
from datetime import datetime
from math import asin
from pathlib import Path
from typing import Any, Optional, Union

from .cif_io import load_cif, print_pcf
from .symm_shelx.make_shelx_ins import write_shelxt_ins
from .util import find_files  # adjust if util exports under a different name
from .xds_analysis import (
    analysis_correct_lp,
    analysis_xscale_lp,
    extract_cluster_result,
    extract_run_result,
    get_avg_esd_cell,
)

warnings.simplefilter(action="ignore", category=FutureWarning)


# -----------------------------
# Helpers
# -----------------------------

def _as_path(p: Union[str, Path]) -> Path:
    return p if isinstance(p, Path) else Path(p)


def _normalise_short_name(info: dict[str, Any], default: str = "autolei") -> str:
    raw = info.get("short_name", default)
    if raw is None:
        return default
    s = str(raw).strip()
    if not s:
        return default
    return s.split()[0]  # enforce no spaces


def _parse_temperature_kelvin(value: Any, default_kelvin: int = 298) -> int:
    """
    Returns temperature in Kelvin as int.
    Accepts values like "298", "298(3)", 298, None.
    """
    if value is None:
        return default_kelvin
    s = str(value).strip()
    digits = "".join(ch for ch in s if ch.isdigit())
    if not digits:
        return default_kelvin
    try:
        return int(digits)
    except ValueError:
        return default_kelvin


def _accelerating_voltage_kv_from_wavelength_angstrom(wavelength_a: float) -> int:
    """
    Compute accelerating voltage (kV) from electron wavelength in Å using a relativistic relation.
    Preserves your rounding behaviour (nearest 10 kV).
    """
    h = 6.62607015e-34
    m0 = 9.10938356e-31
    c = 2.99792458e8
    e = 1.602176634e-19

    lam_m = float(wavelength_a) * 1e-10
    energy_j = math.sqrt((m0 * c ** 2) ** 2 + (h * c / lam_m) ** 2) - (m0 * c ** 2)
    voltage_v = energy_j / e
    voltage_kv = voltage_v / 1e3
    return int(round(voltage_kv / 10.0) * 10)


def _format_measurement_table(rows: list[list[Any]]) -> str:
    columns = ["#", "Type", "Start", "End", "Step", "t~exp~", "#Frames", "CL", "Reso.", "ISa", "CC1/2"]
    col_widths = [2, 4, 8, 8, 6, 9, 7, 8, 5, 5, 5]

    header_str = "  ".join(f"{h:<{w}}" for h, w in zip(columns, col_widths))
    sep = "-" * (len(header_str) + 2)

    row_strs = []
    for r in rows:
        row_strs.append("  ".join(f"{str(v):<{w}}" for v, w in zip(r, col_widths)))

    title = "List of Samples for Merging (Abbr. = Camera Length, Resolution):\n"
    table = f" {header_str}\n{sep}\n " + "\n ".join(row_strs)
    return title + table


def _ensure_xdsconv_available() -> None:
    if shutil.which("xdsconv") is None:
        raise FileNotFoundError("xdsconv not found in PATH. Install XDS and ensure xdsconv is accessible.")


# -----------------------------
# Main workflow
# -----------------------------

def find_hkl(input_path: str, xconv_folder: str = "merge") -> tuple[Path, Path, bool]:
    """
    Locate the HKL to convert and the working directory.

    Returns:
        work_dir (Path): where XDSCONV.INP is written and where xdsconv is run
        input_hkl (Path): the HKL file passed to xdsconv
        merge (bool): True if using merged all.hkl, False if single dataset
    """
    if not input_path:
        raise ValueError("No input path provided.")

    base_dir = Path(input_path)
    if not base_dir.exists():
        raise FileNotFoundError(f"Input path does not exist: {base_dir}")

    hkl_list = [Path(p) for p in (find_files(input_path, "XDS_ASCII.HKL") or [])]
    if not hkl_list:
        raise FileNotFoundError("No HKL files found (XDS_ASCII.HKL).")

    # Single dataset: convert in-place
    if len(hkl_list) == 1:
        input_hkl = hkl_list[0]
        if not input_hkl.exists():
            raise FileNotFoundError(f"HKL file does not exist: {input_hkl}")
        return input_hkl.parent, input_hkl, False

    # Multiple datasets: use <input>/<xconv_folder>/all.hkl (case-insensitive)
    work_dir = base_dir / xconv_folder
    if not work_dir.exists():
        raise FileNotFoundError(f"Merge folder does not exist: {work_dir}")

    all_hkl = next((p for p in work_dir.iterdir() if p.is_file() and p.name.lower() == "all.hkl"), None)
    if all_hkl is None:
        raise FileNotFoundError(f"all.hkl not found in: {work_dir}")

    return work_dir, all_hkl, True


def write_xconv(
        work_dir: Union[str, Path],
        input_hkl: Union[str, Path],
        *,
        output_prefix: str = "autolei",
        friedels_law: bool = True,
) -> Path:
    """
    Write XDSCONV.INP only. No file searching, no P4P, no .ins, no CIF.
    """
    work_dir = _as_path(work_dir)
    input_hkl = _as_path(input_hkl)

    if not work_dir.exists():
        raise FileNotFoundError(f"Working directory does not exist: {work_dir}")
    if not input_hkl.exists():
        raise FileNotFoundError(f"Input HKL does not exist: {input_hkl}")

    stats = extract_run_result(str(input_hkl.parent))  # ensure we can read the run result before writing INP
    max_res, min_res = (stats.get("max_res", 30) if stats.get("max_res", 30) > 20 else 20,
                        stats.get("resolution", 0.8))
    lines = [
        f"OUTPUT_FILE= {output_prefix}.hkl SHELX",
        f"INPUT_FILE= {input_hkl}     !format is XDS_ASCII by default",
        f"FRIEDEL'S_LAW= {'TRUE' if friedels_law else 'FALSE'}",
        f"INCLUDE_RESOLUTION_RANGE= {max_res + 0.1} {min_res}",
        "!MERGE= FALSE",
        "",
    ]
    (work_dir / "XDSCONV.INP").write_text("\n".join(lines), encoding="utf-8")
    return work_dir


def run_xdsconv(work_dir: Union[str, Path]) -> None:
    """Run xdsconv in the given directory with clearer diagnostics if it fails."""
    _ensure_xdsconv_available()
    work_dir = _as_path(work_dir)

    try:
        subprocess.run(
            ["xdsconv"],
            cwd=str(work_dir),
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as e:
        msg = (
            f"xdsconv failed in {work_dir}\n"
            f"Return code: {e.returncode}\n"
            f"STDOUT:\n{e.stdout or ''}\n"
            f"STDERR:\n{e.stderr or ''}"
        )
        raise RuntimeError(msg) from e


def write_shelx_post(
        work_dir: Union[str, Path],
        *,
        merge: bool,
        output_prefix: str = "autolei",
        composition: str = "C Cl",
) -> None:
    """Post-processing after xdsconv: write P4P and SHELXT .ins."""
    work_dir = _as_path(work_dir)
    output_content_P4P(str(work_dir), file_name=f"{output_prefix}.P4P", multi=merge)
    write_shelxt_ins(str(work_dir), composition=composition, filename=output_prefix, merge=merge)


def convert_to_shelx(
        input_path: str,
        xconv_folder: str = "merge",
        *,
        output_prefix: str = "autolei",
        composition: str = "C Cl",
) -> None:
    """
    Process order:
      find_hkl -> write_xconv -> run_xdsconv -> write ins (+P4P) -> write cif_od (single only)
    """
    work_dir, input_hkl, merge = find_hkl(input_path, xconv_folder=xconv_folder)

    write_xconv(work_dir, input_hkl, output_prefix=output_prefix)
    run_xdsconv(work_dir)

    # After conversion
    try:
        write_shelx_post(work_dir, merge=merge, output_prefix=output_prefix, composition=composition)
        if not merge:
            write_cif_od_single(input_path)
    except Exception as e:
        # Keep prior behaviour: non-fatal post-processing
        print(f"Warning: Post-processing failed: {e}")

    print(f"XDS.HKL has been converted under {work_dir}.\n")


# -----------------------------
# P4P generation
# -----------------------------

def output_content_P4P(file_folder: str, file_name: str = "autolei.p4p", multi: bool = True) -> None:
    """Generate a `.P4P` file with unit cell parameters and experimental details."""
    folder = Path(file_folder)
    if not folder.exists():
        raise FileNotFoundError(f"Folder does not exist: {folder}")

    if multi:
        try:
            avg_cell, esd_cell, wavelength = get_avg_esd_cell(str(folder), multi=True, mode="folder")
        except Exception:
            info_dict = extract_cluster_result(str(folder))
            try:
                avg_cell = info_dict["unit_cell"]
                esd_cell = info_dict["unit_cell_esd"]
            except Exception as e2:
                raise RuntimeError(f"Failed to obtain cell/wavelength for multi dataset in {folder}: {e2}") from e2
    else:
        correct_lp = folder / "CORRECT.LP"
        if not correct_lp.exists():
            raise FileNotFoundError(f"CORRECT.LP not found for single dataset: {correct_lp}")
        info_dict = analysis_correct_lp(str(correct_lp))
        avg_cell = info_dict["unit_cell"]
        esd_cell = info_dict["unit_cell_esd"]

    lines = [
        f"TITLE  AutoLEI P4P export at {datetime.now().strftime('%a %b %d %H:%M:%S %Y')}\n",
        "CHEM \n",
        "CELL  {:.4f}  {:.4f}  {:.4f}  {:.4f}  {:.4f}  {:.4f}\n".format(*avg_cell),
        "CELLSD  {:.4f}  {:.4f}  {:.4f}  {:.4f}  {:.4f}  {:.4f}\n".format(*esd_cell),
        "MORPH  nano-crystal\n",
    ]
    (folder / file_name).write_text("".join(lines), encoding="utf-8")


# -----------------------------
# INS / PCF / CIF-OD updates
# -----------------------------

def update_after_prep(ins_path: str, pcf_path: str, info_dict: dict[str, Any]) -> None:
    """Update `.ins` and `.pcf` files after SHELX preparation."""
    info_dict.update(analysis_xscale_lp(os.path.join(os.path.dirname(ins_path), "XSCALE.LP")))
    wavelength = update_pcf_file(ins_path, pcf_path, info_dict)

    short_name = _normalise_short_name(info_dict, default="autolei")
    temperature_k = _parse_temperature_kelvin(info_dict.get("temperature"), default_kelvin=298)
    update_ins(ins_path, wavelength=wavelength, name=short_name, temperature=str(temperature_k))


def write_cif_od_single(input_path: str) -> float:
    """Generate a CIF_OD file with unit cell and experimental details (single dataset)."""
    input_dir = Path(input_path)
    if not input_dir.exists():
        raise FileNotFoundError(f"Input directory does not exist: {input_dir}")

    short_name = "autolei"
    cif_od_dict: dict[str, Any] = {}

    scan_list = [extract_run_result(str(input_dir))]
    rows: list[list[Any]] = []

    cell_num = 0
    wavelength = float(scan_list[0].get("wavelength"))
    pixel = float(scan_list[0].get("pixel_size", 1.0))

    for i, item in enumerate(scan_list, start=1):
        cell_num += int(item.get("cell_rfl_num", 0))
        wavelength = float(item.get("wavelength", wavelength))
        pixel = float(item.get("pixel_size", pixel))

        rows.append(
            [
                i,
                "/a",
                item.get("start_angle", ""),
                item.get("end_angle", ""),
                item.get("step", ""),
                item.get("time", ""),
                item.get("frames", ""),
                item.get("camera_length", ""),
                item.get("resolution", "N/A"),
                item.get("ISa_meas", ""),
                item.get("cc12_reso", item.get("CC1/2", "")),
            ]
        )

    table_text = _format_measurement_table(rows)

    cif_od_dict["cell_measurement_reflns_used"] = cell_num
    cif_od_dict["cell_measurement_theta_min"] = "{:.4f}".format(
        57.2958 * asin(wavelength / (2 * float(scan_list[0].get("max_res", 20)))))
    cif_od_dict["cell_measurement_theta_max"] = "{:.4f}".format(
        57.2958 * asin(wavelength / (2 * float(scan_list[0].get("min_res", 0.8)))))

    cif_od_dict["exptl_crystal_description"] = "nano-crystal"
    cif_od_dict["diffrn_ambient_environment"] = "vacuum"
    cif_od_dict["diffrn_measurement_device_type"] = "TEM"
    cif_od_dict["diffrn_radiation_type"] = "electron"
    cif_od_dict["diffrn_radiation_source"] = "electron"
    cif_od_dict["diffrn_radiation_probe"] = "electron"
    cif_od_dict["diffrn_radiation_wavelength"] = wavelength
    cif_od_dict["diffrn_source"] = "electron microscope"
    cif_od_dict["diffrn_source_voltage"] = _accelerating_voltage_kv_from_wavelength_angstrom(wavelength)
    cif_od_dict["diffrn_measurement_device"] = "TEM"
    cif_od_dict["diffrn_measurement_method"] = "Continuous Rotation Electron Diffraction"
    cif_od_dict["diffrn_detector_area_resol_mean"] = "{:.4f}".format(1 / pixel)
    cif_od_dict["diffrn_measurement_details"] = table_text
    cif_od_dict["computing_cell_refinement"] = "XDS (Kabsch et al., 2010)"
    cif_od_dict["computing_data_reduction"] = "XDS (Kabsch et al., 2010)"

    # Determine data collection software (preserving your existing logic)
    cred_log = input_dir.parent / "cRED_log.txt"
    xml_folder = input_dir.parent
    if cred_log.exists():
        cif_od_dict["computing_data_collection"] = "Instamatic (Wang et al., 2019)"
    else:
        cif_od_dict["computing_data_collection"] = "EPU-D (Thermo Scientific, 2024)"
        for fn in os.listdir(str(xml_folder)):
            if fn.endswith(".xml"):
                xml_path = xml_folder / fn
                try:
                    xml_text = xml_path.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                if "EpuD" in xml_text:
                    cif_od_dict["computing_data_collection"] = "EPU-D (Thermo Scientific, 2024)"
                    break

    out_path = input_dir / f"{short_name}.cif_od"
    print_pcf(str(out_path), cif_od_dict, short_name)
    return wavelength


def update_pcf_file(ins_path: str, pcf_path: str, info_dict: dict[str, Any]) -> float:
    """Update a `.pcf`/`.cif_od` file with new metadata."""
    short_name = _normalise_short_name(info_dict, default="autolei")
    temperature_k = _parse_temperature_kelvin(info_dict.get("temperature"), default_kelvin=298)

    if pcf_path:
        loaded_data = extract_cluster_result(os.path.dirname(pcf_path))
    else:
        loaded_data = extract_cluster_result(os.path.dirname(ins_path))

    # Load existing cif/pcf if present; otherwise initialise defaults
    if pcf_path and os.path.exists(pcf_path):
        loaded = load_cif(pcf_path)
        cif_od_dict = loaded[next(iter(loaded))]  # first block
    else:
        cif_od_dict = {
            "cell_measurement_temperature": "?",
            "cell_measurement_reflns_used": "?",
            "cell_measurement_theta_min": "?",
            "cell_measurement_theta_max": "?",
            "exptl_crystal_description": "nano-crystal",
            "exptl_absorpt_correction_type": "none",
            "diffrn_ambient_temperature": "?",
            "diffrn_radiation_type": "electron",
            "computing_cell_refinement": "XDS (Kabsch et al., 2010)",
            "computing_data_reduction": "XDS (Kabsch et al., 2010)",
        }

    # Build scan list robustly
    inputs = loaded_data.get("input") or []
    inputs_statistics = loaded_data.get("input_statistics") or {}
    scan_list: list[dict[str, Any]] = []
    for p in inputs:
        item = inputs_statistics.get(p) or inputs_statistics.get(str(p))
        if item is None:
            continue
        scan_list.append(item)

    if not scan_list:
        raise RuntimeError("No scan statistics available to update CIF_OD (missing input_statistics).")

    rows: list[list[Any]] = []
    cell_num = 0
    wavelength = float(scan_list[0].get("wavelength"))
    pixel = float(scan_list[0].get("pixel_size", 1.0))

    for i, item in enumerate(scan_list, start=1):
        cell_num += int(item.get("cell_rfl_num", 0))
        wavelength = float(item.get("wavelength", wavelength))
        pixel = float(item.get("pixel_size", pixel))

        rows.append(
            [
                i,
                "/a",
                item.get("start_angle", ""),
                item.get("end_angle", ""),
                item.get("step", ""),
                item.get("time", ""),
                item.get("frames", ""),
                item.get("camera_length", ""),
                item.get("resolution", ""),
                item.get("ISa_meas", ""),
                item.get("CC1/2", ""),
            ]
        )

    table_text = _format_measurement_table(rows)

    # Names
    long_name = str(info_dict.get("long_name", "") or "").strip()
    if long_name:
        cif_od_dict["chemical_name_common"] = long_name
    elif short_name != "1":
        cif_od_dict["chemical_name_common"] = short_name

    # Temperature
    cif_od_dict["cell_measurement_temperature"] = f"{temperature_k}(3)"
    cif_od_dict["diffrn_ambient_temperature"] = f"{temperature_k}(3)"

    # Cell measurement
    cif_od_dict["cell_measurement_reflns_used"] = str(cell_num)
    cif_od_dict["cell_measurement_theta_min"] = "{:.4f}".format(57.2958 * asin(wavelength / (2 * 20)))
    cif_od_dict["cell_measurement_theta_max"] = "{:.4f}".format(
        57.2958 * asin(wavelength / (2 * float(info_dict.get("resolution", 5.0))))
    )

    # Experiment / instrument
    cif_od_dict["exptl_crystal_description"] = "nano-crystal"
    cif_od_dict["diffrn_ambient_environment"] = "vacuum"
    cif_od_dict["diffrn_measurement_device_type"] = "TEM"
    cif_od_dict["diffrn_radiation_type"] = "electron"
    cif_od_dict["diffrn_radiation_source"] = "electron"
    cif_od_dict["diffrn_radiation_probe"] = "electron"
    cif_od_dict["diffrn_radiation_wavelength"] = "{:.6f}".format(wavelength)
    cif_od_dict["diffrn_source"] = "electron microscope"
    cif_od_dict["diffrn_source_voltage"] = str(_accelerating_voltage_kv_from_wavelength_angstrom(wavelength))
    cif_od_dict["diffrn_detector"] = info_dict.get("detector", "?")
    cif_od_dict["diffrn_measurement_device"] = "TEM"
    cif_od_dict["diffrn_measurement_device_type"] = info_dict.get("instrument", "?")
    cif_od_dict["diffrn_measurement_method"] = "Continuous Rotation Electron Diffraction"
    cif_od_dict["diffrn_detector_area_resol_mean"] = "{:.4f}".format(1 / pixel)
    cif_od_dict["diffrn_measurement_details"] = table_text

    instrument = info_dict.get("instrument", "?")
    if instrument in ["JEOL-2100", "Themis Z"]:
        cif_od_dict["computing_data_collection"] = "Instamatic (Wang et al., 2019)"
    else:
        cif_od_dict["computing_data_collection"] = "EPU-D (Thermo Scientific, 2024)"

    cif_od_dict["computing_cell_refinement"] = "XDS (Kabsch et al., 2010)"
    cif_od_dict["computing_data_reduction"] = "XDS (Kabsch et al., 2010)"

    out_path = os.path.join(os.path.dirname(ins_path), f"{short_name}.cif_od")
    print_pcf(out_path, cif_od_dict, short_name)
    return wavelength


def update_ins(
        file_path: str,
        temperature: Optional[str] = None,
        wavelength: Optional[float] = None,
        name: Optional[str] = None,
) -> None:
    """
    Update a `.ins` file with new metadata.

    Notes:
    - SHELX TEMP expects Celsius.
    - This function assumes `temperature` is Kelvin (consistent with your pipeline).
    - Preserves behaviour: when `name` is set, it writes to <name>.ins in the same folder.
    """
    src = Path(file_path)
    if not src.exists():
        raise FileNotFoundError(f".ins file not found: {src}")

    lines = src.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)

    out_path = src
    if name:
        out_path = src.with_name(f"{name}.ins")

    temp_k = _parse_temperature_kelvin(temperature, default_kelvin=298) if temperature is not None else None
    temp_c = (temp_k - 273) if temp_k is not None else None

    new_lines: list[str] = []
    for line in lines:
        if line.startswith("TITL") and name:
            parts = line.split()
            if len(parts) >= 2:
                parts[1] = name
                new_lines.append("  ".join(parts) + "\n")
            else:
                new_lines.append(f"TITL {name}\n")
        elif line.startswith("CELL") and wavelength is not None:
            parts = line.split()
            if len(parts) >= 2:
                parts[1] = f"{float(wavelength):.6f}".rstrip("0").rstrip(".")
                new_lines.append("  ".join(parts) + "\n")
            else:
                new_lines.append(line)
            if temp_c is not None:
                new_lines.append(f"TEMP {int(temp_c)}\n")
        else:
            new_lines.append(line)

    out_path.write_text("".join(new_lines), encoding="utf-8")
    print(f"{out_path} is updated. Use this for structure solving.\n")


if __name__ == "__main__":
    pass
