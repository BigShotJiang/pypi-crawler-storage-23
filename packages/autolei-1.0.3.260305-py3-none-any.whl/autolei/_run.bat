@echo off
wsl -d Debian -e bash -i -c "python3 -m autolei"
