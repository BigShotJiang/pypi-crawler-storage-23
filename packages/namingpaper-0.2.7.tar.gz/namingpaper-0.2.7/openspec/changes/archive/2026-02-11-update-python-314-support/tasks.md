## 1. Implementation
- [x] 1.1 Update `requires-python` in `pyproject.toml` from `>=3.11,<3.14` to `>=3.11`
- [x] 1.2 Run `uv lock` to regenerate `uv.lock`
- [x] 1.3 Run `uv run pytest` to verify all tests pass
