"""Bundled configuration and framework documentation.

This package primarily contains Markdown reference files.
"""
