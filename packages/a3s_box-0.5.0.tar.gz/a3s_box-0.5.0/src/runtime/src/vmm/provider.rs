//! VmmProvider re-exported from `a3s-box-core`.

pub use a3s_box_core::vmm::VmmProvider;
