"""Textual agent workspace shell with split-pane layout (PR-C gated path)."""

from __future__ import annotations

import asyncio
import inspect
import json
import re
import shlex
import time
from collections.abc import Callable
from dataclasses import dataclass
from textwrap import wrap
from typing import TYPE_CHECKING, Any, Literal, cast

from rich.errors import MarkupError as _MarkupError
from rich.markup import escape as _escape_markup
from rich.table import Table as RichTable
from rich.text import Text as RichText

from glaip_sdk._version import __version__ as SDK_VERSION
from glaip_sdk.branding import ERROR as _DANGER_COLOR
from glaip_sdk.cli.constants import MASK_SENSITIVE_FIELDS
from glaip_sdk.cli.slash.tui.agent_workspace_foundation import (
    AGENT_WORKSPACE_LOGO_TEXT,
    AGENT_WORKSPACE_THEME,
    MODEL_LABEL_PLACEHOLDER,
    format_summary_rows,
    format_utc_timestamp,
    workspace_label,
)
from glaip_sdk.cli.slash.tui.agent_workspace_shell_styles import build_workspace_css
from glaip_sdk.cli.slash.tui.screenshot_capture import WorkspaceScreenshotCaptureMixin

try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.indicators import PulseIndicator as _PulseIndicator
except Exception:  # pragma: no cover - textual unavailable
    _PulseIndicator = None

try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.toast import ClipboardToastMixin as _ClipboardToastMixin

    ClipboardToastMixin = _ClipboardToastMixin  # type: ignore[assignment]
except Exception:  # pragma: no cover - textual unavailable

    class ClipboardToastMixin:  # type: ignore[no-redef]
        """Fallback mixin when Textual is unavailable."""

        def _copy_to_clipboard(self, text: str, *, label: str | None = None) -> None:
            """No-op fallback."""
            pass


try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.keybind_shortcuts import close_shortcuts as _close_shortcuts
except Exception:  # pragma: no cover - textual unavailable
    _close_shortcuts = None

if TYPE_CHECKING:  # pragma: no cover - typing only
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Container, Vertical
    from textual.events import Key
    from textual.widgets import Button, Input, Static
    from textual.worker import Worker, WorkerState
else:  # pragma: no cover - optional dependency guard
    try:
        from textual.app import App, ComposeResult
        from textual.binding import Binding
        from textual.containers import Container, Vertical
        from textual.widgets import Button, Input, Static
        from textual.worker import Worker, WorkerState
    except Exception:  # pragma: no cover - textual unavailable
        App = None  # type: ignore[assignment]
        ComposeResult = None  # type: ignore[assignment]
        Binding = None  # type: ignore[assignment]
        Button = None  # type: ignore[assignment]
        Container = None  # type: ignore[assignment]
        Vertical = None  # type: ignore[assignment]
        Input = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]
        Worker = None  # type: ignore[assignment]
        WorkerState = None  # type: ignore[assignment]


TEXTUAL_SUPPORTED = App is not None and Input is not None and Static is not None and Button is not None

APP_QUIT_ACTION = "app.quit"
COMPOSER_ID = "workspace-composer"
TRANSCRIPT_ID = "messages"
DETAILS_ID = "agent-info"
SIDEBAR_ID = "right-sidebar"
LEFT_COLUMN_ID = "left-column"
AGENT_CONTEXT_NAME_ID = "agent-context-name"
AGENT_CONTEXT_ACCOUNT_ID = "agent-context-account"
HEADER_ROW_ID = "header-row"
CONTEXT_BLOCK_ID = "context-block"
TRANSCRIPT_SCROLL_ID = "messages-scroll"
KEYBAR_ROW_ID = "keybar-row"
KEYBAR_LEFT_ID = "keybar-left"
KEYBAR_RIGHT_ID = "keybar-right"
COMMAND_LOADING_ID = "command-loading"
SLASH_WRAP_ID = "slash-wrap"
SLASH_ROWS_ID = "slash-rows"
TRANSCRIPT_MAX_LINES = 500

WorkspaceEventKind = Literal["message", "command", "exit"]
WorkspaceSlashRoute = Literal["transition", "inline_status", "exit"]
StatusSummaryProvider = Callable[[], list[str]] | Callable[[list[str]], list[str]]
DetailsProvider = Callable[[], list[str]]
TranscriptSink = Callable[[list[str]], None]
MessageRunProvider = Callable[..., str | tuple[str, list[str]] | None]

WORKSPACE_THEME = AGENT_WORKSPACE_THEME
WORKSPACE_CAPTURE_PATH_ENV = WorkspaceScreenshotCaptureMixin.CAPTURE_PATH_ENV
WORKSPACE_CAPTURE_DELAY_ENV = WorkspaceScreenshotCaptureMixin.CAPTURE_DELAY_ENV
COMMAND_TRANSITION_DELAY_SECONDS = 0.35
INLINE_RUNNING_TICK_SECONDS = 1.0
_ANSI_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
_MD_INLINE_CODE_RE = re.compile(r"`([^`\n]+)`")
_MD_BOLD_RE = re.compile(r"\*\*([^*\n]+)\*\*")
_MD_ITALIC_RE = re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)")
_WORKSPACE_EXIT_COMMAND = "/exit"
_DETAILS_COMMAND = "/details"
_PROMPT_COMMAND = "/prompt"
_HELP_COMMAND = "/help"
_RUNS_COMMAND = "/runs"
_SCHEDULES_COMMAND = "/schedules"
_STATUS_COMMAND = "/status"
_Q_EXIT_COMMAND = "/q"
_DETAILS_SENTINEL = "\u0000DETAILS\u0000"
_RUN_DIVIDER_SENTINEL = "\u0000RUN\u0000"
_DETAILS_KEY_COLOR = WORKSPACE_THEME["accent"]
_DETAILS_VALUE_DIM = WORKSPACE_THEME["info"]


@dataclass(frozen=True)
class _WorkspaceSlashCommand:
    """Slash command metadata for workspace routing and dropdown inventory."""

    name: str
    description: str
    route: WorkspaceSlashRoute = "transition"
    visible_in_dropdown: bool = True
    aliases: tuple[str, ...] = ()


_WORKSPACE_SLASH_COMMANDS: tuple[_WorkspaceSlashCommand, ...] = (
    _WorkspaceSlashCommand(_DETAILS_COMMAND, "Show selected agent details"),
    _WorkspaceSlashCommand(_PROMPT_COMMAND, "Edit selected agent prompt"),
    _WorkspaceSlashCommand(_RUNS_COMMAND, "Browse remote run history"),
    _WorkspaceSlashCommand(_SCHEDULES_COMMAND, "Manage recurring schedules"),
    _WorkspaceSlashCommand(_STATUS_COMMAND, "Show inline run status", route="inline_status"),
    _WorkspaceSlashCommand(_HELP_COMMAND, "Show slash command help", visible_in_dropdown=True, aliases=("/?",)),
    _WorkspaceSlashCommand(_WORKSPACE_EXIT_COMMAND, "Exit workspace context", route="exit"),
    _WorkspaceSlashCommand(_Q_EXIT_COMMAND, "Exit workspace context", route="exit"),
)


def _build_workspace_command_index(
    commands: tuple[_WorkspaceSlashCommand, ...],
) -> dict[str, _WorkspaceSlashCommand]:
    """Build token->command metadata map for routing and validation."""
    index: dict[str, _WorkspaceSlashCommand] = {}
    for command in commands:
        for token in (command.name, *command.aliases):
            lowered = token.lower()
            existing = index.get(lowered)
            if existing is not None and existing is not command:
                raise ValueError(f"Duplicate workspace slash command token: {token}")
            index[lowered] = command
    return index


_WORKSPACE_COMMAND_INDEX = _build_workspace_command_index(_WORKSPACE_SLASH_COMMANDS)

_WORKSPACE_ALLOWED_SLASH_COMMANDS = frozenset(
    token for token, command in _WORKSPACE_COMMAND_INDEX.items() if command.route != "exit"
)

_WORKSPACE_DROPDOWN_COMMANDS: tuple[tuple[str, str], ...] = tuple(
    (command.name, command.description)
    for command in sorted(
        (item for item in _WORKSPACE_SLASH_COMMANDS if item.visible_in_dropdown),
        key=lambda item: item.name.lower(),
    )
)

_TRANSCRIPT_USER_FG = "#d9e4f2"
_TRANSCRIPT_USER_BG = "#1a2431"
_TRANSCRIPT_USER_TEXT = "#d3dfed"
_TRANSCRIPT_COMMAND_FG = "#f2d7a7"
_TRANSCRIPT_COMMAND_BG = "#2a2118"
_TRANSCRIPT_STATUS_FG = "#c7d8ca"
_TRANSCRIPT_STATUS_BG = "#1c2a21"
_TRANSCRIPT_SYSTEM_FG = "#c7d0dc"
_TRANSCRIPT_SYSTEM_BG = "#1f2733"
_TRANSCRIPT_AGENT_FG = "#d7e3f4"
_TRANSCRIPT_AGENT_BG = "#1b2532"
_TRANSCRIPT_AGENT_TEXT = "#cfdcf1"
_TRANSCRIPT_AGENT_HERO_BG = "#22364d"
_TRANSCRIPT_AGENT_HERO_TEXT = "#eaf3ff"
_TRANSCRIPT_AGENT_CODE_FG = "#b9d7ff"
_TRANSCRIPT_AGENT_CODE_BG = "#152336"
_TRANSCRIPT_USER_LABEL = "USER>"
_TRANSCRIPT_AGENT_LABEL = "AGENT>"
_TRANSCRIPT_STEP_TOOL = "#8fc8e8"
_TRANSCRIPT_STEP_PARAM = "#8fa0b3"
_TRANSCRIPT_STEP_FINAL = "#8fc79f"
_TRANSCRIPT_STEP_KEY = "#a9d2ff"
_TRANSCRIPT_STEP_MUTED = "#8fa0b3"
_RUN_FAILED_PREFIX = "run failed:"
_MAX_VISIBLE_SLASH_ROWS = 9
_TOOL_PARAMS_MAX_LINES = 14
_TOOL_PARAMS_MAX_LINE_LEN = 220
_ACTIVITY_DETAIL_MAX_LEN = 260
_STREAM_STATUS_CALLBACK_ARG = "stream_status_callback"
_STREAM_REPLY_CALLBACK_ARG = "stream_reply_callback"
_SLASH_COMMAND_TOKEN_RE = re.compile(r"(?<![/\w])(/(?:[a-z?][a-z0-9_-]*))(?![\w-])", re.IGNORECASE)

WORKSPACE_TIP_TEXT = "Tip: type / for commands. ctrl+b toggles agent details."


def _get_workspace_label() -> str:
    return workspace_label()


def _highlight_slash_commands(text: str) -> str:
    """Highlight slash command tokens using the command chip palette."""
    escaped_text = str(text or "")
    if "/" not in escaped_text:
        return escaped_text

    def _replace(match: re.Match[str]) -> str:
        token = match.group(1)
        return f"[{_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]{token}[/]"

    return _SLASH_COMMAND_TOKEN_RE.sub(_replace, escaped_text)


def _escape_with_slash_highlights(text: str) -> str:
    """Escape Rich markup and apply slash-command highlighting."""
    return _highlight_slash_commands(_escape_markup(str(text or "")))


@dataclass(frozen=True)
class AgentWorkspaceDetails:
    """Resolved agent metadata shown in workspace shell."""

    id: str
    name: str
    account_id: str = ""
    description: str = ""
    type: str = ""
    framework: str = ""
    version: str = ""
    model_label: str = ""
    tools_summary: str = "0"
    mcps_summary: str = "0"
    sub_agents_summary: str = "0"
    tool_names: tuple[str, ...] = ()
    mcp_names: tuple[str, ...] = ()
    sub_agent_names: tuple[str, ...] = ()
    updated_at: str = ""


@dataclass(frozen=True)
class AgentWorkspaceEvent:
    """Result emitted by the workspace shell."""

    kind: WorkspaceEventKind
    value: str = ""


def _wrap_multiline(value: str, *, width: int, break_on_hyphens: bool = True) -> str:
    if not value:
        return "-"
    lines = wrap(value, width=width, break_long_words=True, break_on_hyphens=break_on_hyphens)
    return "\n".join(lines) if lines else value


def _summary_count(value: str) -> str:
    token = (value or "").strip().split(" ", 1)[0]
    return token if token.isdigit() else value.strip() or "0"


def _format_named_list(*, title: str, items: tuple[str, ...], color: str) -> str:
    heading = WORKSPACE_THEME["heading"]
    muted = WORKSPACE_THEME["muted"]
    value_color = WORKSPACE_THEME["info"]
    header = f"[bold {heading}]{_escape_markup(title)}[/]"
    if not items:
        return f"{header}\n[{muted}]- none[/]"

    max_items = 5
    rendered = [f"[{color}]•[/] [{value_color}]{_escape_markup(name)}[/]" for name in items[:max_items]]
    extra = len(items) - max_items
    if extra > 0:
        rendered.append(f"[{muted}]• +{extra} more[/]")
    return "\n".join([header, *rendered])


def _format_details_section(title: str, body: str) -> str:
    heading = WORKSPACE_THEME["heading"]
    return f"[bold {heading}]{_escape_markup(title)}[/]\n{body}"


def _format_details(details: AgentWorkspaceDetails) -> str:
    key_color = WORKSPACE_THEME["accent"]
    value_color = WORKSPACE_THEME["info"]
    model_label = _escape_markup(details.model_label or MODEL_LABEL_PLACEHOLDER)
    overview = format_summary_rows(
        [
            ("id", details.id or "-"),
            ("description", _escape_markup(details.description or "-")),
            ("type", details.type or "config"),
            ("framework", details.framework or "-"),
            ("version", details.version or "-"),
            ("model", model_label),
            ("updated_at", format_utc_timestamp(details.updated_at)),
        ],
        key_color=key_color,
        value_color=value_color,
    )

    tools = _format_named_list(
        title=f"Tools ({_summary_count(details.tools_summary)})",
        items=details.tool_names,
        color=WORKSPACE_THEME["tools"],
    )
    mcps = _format_named_list(
        title=f"MCPs ({_summary_count(details.mcps_summary)})",
        items=details.mcp_names,
        color=WORKSPACE_THEME["mcps"],
    )
    sub_agents = _format_named_list(
        title=f"Sub-agents ({_summary_count(details.sub_agents_summary)})",
        items=details.sub_agent_names,
        color=WORKSPACE_THEME["heading"],
    )
    return "\n\n".join([_format_details_section("Overview", overview), tools, mcps, sub_agents])


def _format_sidebar_header(details: AgentWorkspaceDetails) -> str:
    name = _escape_markup(details.name or "-")
    account = _wrap_multiline(_escape_markup(details.account_id or "-"), width=44)
    account_color = WORKSPACE_THEME["account"]
    heading = WORKSPACE_THEME["heading"]
    return f"[bold {heading}]{name}[/]\n[{account_color}]{account}[/]"


def _format_agent_context_name(details: AgentWorkspaceDetails) -> str:
    return _escape_markup(details.name or "-")


def _format_agent_context_account(details: AgentWorkspaceDetails) -> str:
    account_color = WORKSPACE_THEME["account"]
    return f"[{account_color}]{_escape_markup(details.account_id or '-')}[/]"


def _format_transcript(lines: list[str]) -> str:
    if not lines:
        return ""
    normalized: list[str] = []
    # Track details block state
    in_details_block = False
    details_title_found = False

    for raw in lines:
        cleaned = _ANSI_RE.sub("", str(raw))
        if cleaned.startswith(_DETAILS_SENTINEL):
            if not in_details_block:
                in_details_block = True
                details_title_found = False

            content = cleaned[len(_DETAILS_SENTINEL) :].strip()
            # First non-empty line that is not a section header is the title
            is_section_header = content.startswith("[") and content.endswith("]")
            if content and not details_title_found and not is_section_header:
                normalized.append(
                    _sanitize_transcript_markup(
                        _format_details_transcript_line(cleaned[len(_DETAILS_SENTINEL) :], is_title=True), cleaned
                    )
                )
                details_title_found = True
            else:
                normalized.append(
                    _sanitize_transcript_markup(
                        _format_details_transcript_line(cleaned[len(_DETAILS_SENTINEL) :], is_title=False), cleaned
                    )
                )
        else:
            in_details_block = False
            normalized.append(_sanitize_transcript_markup(_format_transcript_line(raw), cleaned))
    return "\n".join(normalized)


def _sanitize_transcript_markup(formatted: str, fallback_raw: str) -> str:
    """Guard transcript rendering against malformed Rich markup rows."""
    if not formatted:
        return ""
    try:
        RichText.from_markup(formatted)
        return formatted
    except _MarkupError:
        return _escape_markup(str(fallback_raw).strip())


def _activity_detail(activity: str) -> str:
    """Return activity row detail after the first ':' separator."""
    if ":" not in activity:
        return ""
    return activity.split(":", 1)[1].strip()


def _legacy_status_to_activity_line(raw_body: str) -> str:
    """Map legacy `Status:` rows into canonical activity prefixes."""
    body = _render_status_body(str(raw_body or "").strip())
    lowered = body.lower()
    if lowered in {"running", "[~] running"}:
        return "run: [~] running"

    if lowered.startswith("[ok] "):
        normalized = body.split("]", 1)[1].strip() if "]" in body else body
        return f"run_result: {normalized or 'completed'}"
    if lowered.startswith("[x] "):
        normalized = body.split("]", 1)[1].strip() if "]" in body else body
        return f"run_result: {normalized or f'{_RUN_FAILED_PREFIX} unknown error'}"

    if lowered.startswith(("completed in ", _RUN_FAILED_PREFIX, "token usage:")):
        return f"run_result: {body}"

    return f"status: {body}"


def _format_labeled_transcript_line(stripped: str) -> str | None:
    """Format transcript rows with fixed labels (You/Cmd/System/Agent)."""
    if stripped.startswith("You:"):
        body = _escape_with_slash_highlights(stripped[4:].strip())
        return (
            f"[bold {_TRANSCRIPT_USER_FG} on {_TRANSCRIPT_USER_BG}]{_TRANSCRIPT_USER_LABEL}[/]"
            f" [{_TRANSCRIPT_USER_TEXT} on {_TRANSCRIPT_USER_BG}] {body} [/]"
        )

    if stripped.startswith("Cmd:"):
        body = _escape_with_slash_highlights(stripped[4:].strip())
        return f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]Cmd:[/] [{_TRANSCRIPT_STEP_MUTED}]{body}[/]"

    if stripped.startswith("System:"):
        body_raw = stripped[7:].strip()
        body = _escape_with_slash_highlights(body_raw)
        if body_raw.startswith("/"):
            return (
                f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]Cmd:[/]"
                f" [{_TRANSCRIPT_STEP_MUTED}]{body}[/]"
            )
        return (
            f"[bold {_TRANSCRIPT_SYSTEM_FG} on {_TRANSCRIPT_SYSTEM_BG}]System:[/] [{_TRANSCRIPT_STEP_MUTED}]{body}[/]"
        )

    if stripped.startswith("Agent Final:"):
        body = _render_agent_markdown_inline(stripped[12:].strip())
        return (
            f"[bold {_TRANSCRIPT_AGENT_FG} on {_TRANSCRIPT_AGENT_HERO_BG}]{_TRANSCRIPT_AGENT_LABEL}[/]"
            f" [bold {_TRANSCRIPT_AGENT_HERO_TEXT}]{body}[/]"
        )

    if stripped.startswith("Agent:"):
        body = _render_agent_markdown_inline(stripped[6:].strip())
        return (
            f"[bold {_TRANSCRIPT_AGENT_FG} on {_TRANSCRIPT_AGENT_BG}]{_TRANSCRIPT_AGENT_LABEL}[/]"
            f" [{_TRANSCRIPT_AGENT_TEXT}]{body}[/]"
        )

    if stripped.startswith("Status:"):
        legacy_line = _legacy_status_to_activity_line(stripped[7:].strip())
        return _format_activity_transcript_line(legacy_line)

    return None


def _format_run_divider_line(value: str) -> str:
    """Render a subtle run-start divider before each user prompt."""
    label = _escape_markup(str(value or "").strip() or "Run")
    rail = "─" * 10
    return f"[{_TRANSCRIPT_STEP_MUTED}]{rail} {label} {rail}[/]"


def _format_activity_transcript_line(activity: str) -> str:
    """Format normalized activity rows using compact step renderer rules."""
    lowered = activity.lower()
    detail = _activity_detail(activity)
    if lowered.startswith("subagent:"):
        return _render_subagent_box(detail)
    if lowered.startswith("tool_params:"):
        return _render_tool_params_block(detail)

    normalized = _render_step_bullet(activity)
    color = _step_line_color(activity)
    highlighted = _highlight_slash_commands(_escape_markup(normalized))
    if lowered.startswith("tool_call:"):
        return f"[bold {color}]{highlighted}[/]"
    return f"[{color}]{highlighted}[/]"


def _format_transcript_line(raw: str) -> str:
    cleaned = _ANSI_RE.sub("", str(raw))

    if cleaned.startswith(_DETAILS_SENTINEL):
        return _format_details_transcript_line(cleaned[len(_DETAILS_SENTINEL) :])

    if cleaned.startswith(_RUN_DIVIDER_SENTINEL):
        return _format_run_divider_line(cleaned[len(_RUN_DIVIDER_SENTINEL) :])

    stripped = cleaned.strip()
    if not stripped:
        return ""

    labeled = _format_labeled_transcript_line(stripped)
    if labeled is not None:
        return labeled

    activity = _coerce_activity_line(stripped)
    if activity is None:
        return _escape_with_slash_highlights(stripped)

    return _format_activity_transcript_line(activity)


def _looks_like_uuid(value: str) -> bool:
    """Return True when string matches canonical UUID format."""
    cleaned = str(value or "").strip().lower()
    if len(cleaned) != 36:
        return False
    # 8-4-4-4-12
    parts = cleaned.split("-")
    if len(parts) != 5 or [len(p) for p in parts] != [8, 4, 4, 4, 12]:
        return False
    return all(ch in "0123456789abcdef" for ch in cleaned.replace("-", ""))


def _format_details_transcript_value(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return f"[{_DETAILS_VALUE_DIM}]-[/]"

    escaped = _escape_markup(raw)
    if raw.lower() in {"null", "none"}:
        return f"[{_DETAILS_VALUE_DIM}]null[/]"

    if _looks_like_uuid(raw):
        return f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}]{escaped}[/]"

    escaped = _highlight_slash_commands(escaped)

    if "open /" in raw:
        return f"[{_DETAILS_VALUE_DIM}]{escaped}[/]"

    if "(trimmed;" in raw:
        return f"[{_DETAILS_VALUE_DIM}]{escaped}[/]"

    if raw.startswith("/") or raw.startswith("https://"):
        # Use success color with underline for URLs (distinct from keys and UUIDs)
        # Use simple [/] to close to avoid MarkupError mismatches
        url_color = WORKSPACE_THEME["success"]
        return f"[{url_color} underline]{escaped}[/]"

    # Highlight UUIDs within the text (e.g., "catapa-prod (uuid)")
    uuid_pattern = r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"

    def replace_uuid(match: re.Match[str]) -> str:
        uuid = match.group(1)
        # Highlight UUID without extra padding inside the markup
        return f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}]{uuid}[/]"

    escaped_with_uuids = re.sub(uuid_pattern, replace_uuid, escaped, flags=re.IGNORECASE)

    # Regular values use dim color to differentiate from keys
    return f"[{_DETAILS_VALUE_DIM}]{escaped_with_uuids}[/]"


# Known section headers for details output
_DETAILS_SECTIONS = frozenset({"overview", "configuration", "tools", "mcps", "sub-agents", "metadata", "others"})


def _format_details_transcript_line(raw: str, *, is_title: bool = False) -> str:
    """Render a details-only transcript row.

    Input rows are tagged using `_DETAILS_SENTINEL` so this styling does not
    impact unrelated transcript content.
    """
    content = str(raw or "").rstrip("\n")
    if not content.strip():
        return ""

    stripped = content.strip()

    # Title line (agent name at the top)
    if is_title:
        heading = WORKSPACE_THEME["heading"]
        return f"[bold {heading}]{_escape_markup(stripped)}[/]"

    # Account line (special sentinel from agent_session)
    if "\u0000ACCOUNT\u0000" in content:
        account_val = content.split("\u0000ACCOUNT\u0000", 1)[1].strip()
        account_color = WORKSPACE_THEME["account"]
        return f"[{account_color}]{_escape_markup(account_val)}[/]"

    # Section headers ([Identity], [Behavior], etc.)
    if stripped.startswith("[") and stripped.endswith("]"):
        section_name = stripped[1:-1].lower()
        if section_name in _DETAILS_SECTIONS:
            heading = WORKSPACE_THEME["heading"]
            # Escape opening bracket so Rich/Textual renders literal [Section].
            literal_header = f"\\{stripped}"
            return f"[bold {heading}]{literal_header}[/]"

    if stripped.startswith("-"):
        return _format_details_bullet_line(content)

    if ":" not in stripped:
        return _escape_markup(stripped)

    key_raw, _, value_raw = stripped.partition(":")
    key = key_raw.strip()
    value = value_raw.lstrip()
    key_lower = key.lower()

    if key_lower in MASK_SENSITIVE_FIELDS:
        key_markup = f"[bold {_DANGER_COLOR}]{_escape_markup(key)}:[/]"
        value_markup = f"[{_DANGER_COLOR}]{_escape_markup(value) or '-'}[/]"
        return f"{key_markup} {value_markup}".rstrip()

    key_markup = f"[bold {_DETAILS_KEY_COLOR}]{_escape_markup(key)}:[/]"
    if not value:
        return f"{key_markup}"
    value_markup = _format_details_transcript_value(value)
    # Ensure exactly one space between key and value
    return f"{key_markup} {value_markup}".rstrip()


def _format_details_bullet_line(content: str) -> str:
    """Render hierarchical detail bullets with key/value coloring."""
    leading = len(content) - len(content.lstrip(" "))
    stripped = content.strip()
    body = stripped[1:].strip() if stripped.startswith("-") else stripped
    bullet_prefix = f"{' ' * leading}[{_DETAILS_VALUE_DIM}]-[/]"

    if not body:
        return bullet_prefix

    if ":" not in body:
        return f"{bullet_prefix} {_format_details_transcript_value(body)}"

    key_raw, _, value_raw = body.partition(":")
    key = key_raw.strip()
    value = value_raw.lstrip()

    if key.lower() in MASK_SENSITIVE_FIELDS:
        key_markup = f"[bold {_DANGER_COLOR}]{_escape_markup(key)}:[/]"
        if not value:
            return f"{bullet_prefix} {key_markup}"
        value_markup = f"[{_DANGER_COLOR}]{_escape_markup(value)}[/]"
        return f"{bullet_prefix} {key_markup} {value_markup}"

    key_markup = f"[bold {_DETAILS_KEY_COLOR}]{_escape_markup(key)}:[/]"
    if not value:
        return f"{bullet_prefix} {key_markup}"
    return f"{bullet_prefix} {key_markup} {_format_details_transcript_value(value)}"


def _render_agent_markdown_inline(text: str) -> str:
    """Render safe inline markdown subset in agent rows."""
    raw = str(text or "").strip()
    if not raw:
        return "-"

    code_spans: list[str] = []

    def _capture_code(match: re.Match[str]) -> str:
        index = len(code_spans)
        code_spans.append(_escape_markup(match.group(1).strip()))
        return f"\u0000CODE{index}\u0000"

    without_code = _MD_INLINE_CODE_RE.sub(_capture_code, raw)
    escaped = _escape_markup(without_code)
    escaped = _MD_BOLD_RE.sub(lambda m: f"[bold]{m.group(1)}[/]", escaped)
    escaped = _MD_ITALIC_RE.sub(lambda m: f"[italic]{m.group(1)}[/]", escaped)

    for index, code in enumerate(code_spans):
        token = f"\u0000CODE{index}\u0000"
        escaped = escaped.replace(token, f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}] {code} [/]")

    return escaped


def _render_status_body(raw_body: str) -> str:
    """Render status body with concise semantic markers."""
    body = str(raw_body or "").strip()
    lowered = body.lower()
    if lowered == "running":
        return "[~] running"
    if lowered.startswith("completed in "):
        return f"[ok] {body}"
    if lowered.startswith(_RUN_FAILED_PREFIX):
        return f"[x] {body}"
    return body


def _coerce_activity_line(text: str) -> str | None:
    """Normalize known activity rows into canonical prefix form."""
    candidate = str(text or "").strip()
    if not candidate:
        return None

    if candidate.startswith("-"):
        candidate = candidate.lstrip("- ").strip()
    if not candidate:
        return None

    lowered = candidate.lower()
    prefixes = (
        "step:",
        "tool:",
        "tool_call:",
        "tool_result:",
        "tool_params:",
        "tool_done:",
        "action:",
        "handoff:",
        "subagent:",
        "reasoning:",
        "status:",
        "run:",
        "run_result:",
        "final:",
    )
    if lowered.startswith(prefixes):
        return candidate
    return None


def _skip_space_chars(text: str, start: int) -> int:
    """Return next index after contiguous whitespace from start."""
    index = max(0, start)
    while index < len(text) and text[index].isspace():
        index += 1
    return index


def _find_unescaped_quote(text: str, start: int) -> int | None:
    """Find next unescaped double quote starting at index, else None."""
    escaped = False
    cursor = max(0, start)
    while cursor < len(text):
        char = text[cursor]
        if escaped:
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == '"':
            return cursor
        cursor += 1
    return None


def _split_tool_param_key_value(line: str) -> tuple[str, str, str] | None:
    """Parse one JSON-ish `"key": value` line without regex backtracking risk."""
    if not line:
        return None

    key_open = _skip_space_chars(line, 0)
    if key_open >= len(line) or line[key_open] != '"':
        return None

    key_start = key_open + 1
    key_end = _find_unescaped_quote(line, key_start)
    if key_end is None:
        return None

    colon_index = _skip_space_chars(line, key_end + 1)
    if colon_index >= len(line) or line[colon_index] != ":":
        return None

    value_start = _skip_space_chars(line, colon_index + 1)
    return line[:key_open], line[key_start:key_end], line[value_start:]


def _render_tool_params_line(raw_line: str) -> str:
    """Render one formatted params line with key/value emphasis when possible."""
    line = str(raw_line or "").rstrip()
    if not line:
        return ""
    if len(line) > _TOOL_PARAMS_MAX_LINE_LEN:
        line = f"{line[: _TOOL_PARAMS_MAX_LINE_LEN - 3]}..."

    parsed = _split_tool_param_key_value(line)
    if parsed is not None:
        indent, key_raw, value_raw = parsed
        key = _escape_markup(key_raw)
        value = value_raw.strip()
        if value:
            value_markup = f"[{_DETAILS_VALUE_DIM}]{_escape_markup(value)}[/]"
            return f"{indent}[bold {_TRANSCRIPT_STEP_KEY}]{key}[/]: {value_markup}"
        return f"{indent}[bold {_TRANSCRIPT_STEP_KEY}]{key}[/]:"

    return f"[{_DETAILS_VALUE_DIM}]{_escape_markup(line)}[/]"


def _truncate_activity_detail(detail: str, *, max_len: int = _ACTIVITY_DETAIL_MAX_LEN) -> str:
    """Keep activity detail readable by trimming noisy long payloads."""
    compact = " ".join(str(detail or "").split()).strip()
    if len(compact) <= max_len:
        return compact
    head = max(1, int(max_len * 0.74))
    tail = max(8, max_len - head - 5)
    return f"{compact[:head]} ... {compact[-tail:]}"


def _render_tool_params_block(detail: str) -> str:
    """Render params rows as structured JSON when possible."""
    raw = str(detail or "").strip()
    if not raw:
        return f"[{_TRANSCRIPT_STEP_PARAM}]params {{}}[/]"

    compact = " ".join(raw.split()).strip()
    try:
        parsed = json.loads(raw)
    except Exception:
        if len(compact) > _TOOL_PARAMS_MAX_LINE_LEN:
            compact = f"{compact[: _TOOL_PARAMS_MAX_LINE_LEN - 3]}..."
        return f"[{_TRANSCRIPT_STEP_PARAM}]params {_escape_markup(compact)}[/]"

    serialized = json.dumps(parsed, ensure_ascii=False, indent=2)
    lines = serialized.splitlines()
    overflow = max(0, len(lines) - _TOOL_PARAMS_MAX_LINES)
    visible_lines = lines[:_TOOL_PARAMS_MAX_LINES]

    rendered = [f"[{_TRANSCRIPT_STEP_PARAM}]params[/]"]
    for line in visible_lines:
        formatted = _render_tool_params_line(line)
        if formatted:
            rendered.append(formatted)
    if overflow > 0:
        rendered.append(f"[{_DETAILS_VALUE_DIM}]... +{overflow} lines[/]")
    return "\n".join(rendered)


def _render_subagent_box(detail: str) -> str:
    """Render sub-agent delegation in a dedicated transcript box."""
    raw = " ".join(str(detail or "").split()).strip()
    if raw.lower().startswith("sub-agent:"):
        raw = raw.split(":", 1)[1].strip()
    if raw.lower().startswith("sub agent:"):
        raw = raw.split(":", 1)[1].strip()
    label = raw or "unknown"
    content = f"sub-agent: {label}"

    max_width = 76
    if len(content) > max_width:
        content = f"{content[: max_width - 1]}…"
    inner_width = max(24, len(content))
    line = "─" * (inner_width + 2)
    padded = _escape_markup(content.ljust(inner_width))
    color = _TRANSCRIPT_STEP_MUTED
    return "\n".join(
        (
            f"[{color}]╭{line}╮[/]",
            f"[{color}]│ {padded} │[/]",
            f"[{color}]╰{line}╯[/]",
        )
    )


def _extract_prefixed_activity_detail(cleaned: str, prefix: str) -> str | None:
    """Return activity detail when row starts with `prefix`."""
    lowered = cleaned.lower()
    if not lowered.startswith(prefix):
        return None
    return cleaned[len(prefix) :].strip()


def _render_step_with_label(detail: str, label: str) -> str:
    """Render `<label> <detail>` with fallback to label only."""
    trimmed = _truncate_activity_detail(detail)
    return f"{label} {trimmed}" if trimmed else label


def _render_done_step(detail: str) -> str:
    """Render completion rows with explicit result marker."""
    return _render_step_with_label(detail, "result") if detail else "result finished"


def _render_tool_result_step(detail: str) -> str:
    """Render tool completion rows without repeating tool names."""
    cleaned = str(detail or "").strip()
    if not cleaned:
        return "result finished"

    if "|" in cleaned:
        _, outcome = cleaned.split("|", 1)
        parsed_outcome = _truncate_activity_detail(outcome.strip())
        if parsed_outcome:
            return f"result {parsed_outcome}"
    return _render_step_with_label(cleaned, "result")


def _render_params_step(detail: str) -> str:
    """Render params rows with object fallback marker."""
    return _render_step_with_label(detail, "params") if detail else "params {}"


def _render_delegate_step(detail: str) -> str:
    """Render delegate/handoff rows without repeating obvious prefixes."""
    cleaned = _truncate_activity_detail(detail)
    if not cleaned:
        return "delegate sub-agent"
    lowered = cleaned.lower()
    if lowered.startswith("delegate "):
        return cleaned
    if lowered.startswith("sub-agent:"):
        cleaned = cleaned.split(":", 1)[1].strip()
    if lowered.startswith("sub agent:"):
        cleaned = cleaned.split(":", 1)[1].strip()
    return f"delegate {cleaned}" if cleaned else "delegate sub-agent"


def _render_status_step(detail: str) -> str:
    """Render status rows using the detail body when present."""
    trimmed = _truncate_activity_detail(detail)
    return trimmed or "working"


def _render_run_step(detail: str) -> str:
    """Render run-state rows without the legacy Status label."""
    trimmed = _truncate_activity_detail(detail)
    return f"run {trimmed}" if trimmed else "run"


def _render_run_result_step(detail: str) -> str:
    """Render final run outcome rows in tool-result-like wording."""
    trimmed = _truncate_activity_detail(detail)
    if not trimmed:
        return "run result"
    lowered = trimmed.lower()
    if lowered.startswith(_RUN_FAILED_PREFIX):
        reason = trimmed.split(":", 1)[1].strip() if ":" in trimmed else ""
        return f"run result failed: {reason or 'unknown error'}"
    if lowered.startswith("run "):
        trimmed = trimmed[4:].strip() or trimmed
    if trimmed.lower().startswith("result "):
        return f"run {trimmed}"
    return f"run result {trimmed}"


_STEP_BULLET_RENDERERS: tuple[tuple[str, Callable[[str], str]], ...] = (
    ("step:", lambda detail: detail or "step"),
    ("tool:", lambda detail: _render_step_with_label(detail, "tool")),
    ("tool_call:", lambda detail: _render_step_with_label(detail, "tool")),
    ("tool_result:", _render_tool_result_step),
    ("tool_done:", _render_done_step),
    ("tool_params:", _render_params_step),
    ("action:", lambda detail: _render_step_with_label(detail, "action")),
    ("handoff:", _render_delegate_step),
    ("reasoning:", lambda detail: _render_step_with_label(detail, "thinking")),
    ("status:", _render_status_step),
    ("run:", _render_run_step),
    ("run_result:", _render_run_result_step),
    ("final:", lambda detail: _render_step_with_label(detail, "done") if detail else "done"),
)


def _render_step_bullet(body: str) -> str:
    """Render compact activity rows with semantic markers and spacing."""
    cleaned = str(body or "").strip()
    if not cleaned:
        return "-"

    for prefix, renderer in _STEP_BULLET_RENDERERS:
        detail = _extract_prefixed_activity_detail(cleaned, prefix)
        if detail is not None:
            return renderer(detail)

    return cleaned


def _line_has_failure_signal(lowered: str) -> bool:
    """Return True when detail text signals a failed outcome."""
    return "failed" in lowered or " error" in lowered


def _line_has_success_signal(lowered: str) -> bool:
    """Return True when detail text signals a successful completion."""
    return any(token in lowered for token in ("completed in", "finished in", "succeeded", "success"))


def _status_step_line_color(lowered: str) -> str:
    """Return semantic color token for canonical status rows."""
    if lowered.startswith(("status: [x]", f"status: {_RUN_FAILED_PREFIX}")) or "status: error" in lowered:
        return _DANGER_COLOR
    if lowered.startswith(("status: [ok]", "status: completed in")):
        return _TRANSCRIPT_STEP_FINAL
    return _TRANSCRIPT_STEP_MUTED


def _run_result_step_line_color(lowered: str) -> str:
    """Return semantic color token for run_result rows."""
    if _line_has_failure_signal(lowered):
        return _DANGER_COLOR
    if _line_has_success_signal(lowered):
        return _TRANSCRIPT_STEP_FINAL
    return _TRANSCRIPT_STEP_MUTED


def _run_step_line_color(lowered: str) -> str:
    """Return semantic color token for run rows."""
    if _line_has_failure_signal(lowered):
        return _DANGER_COLOR
    if "[~] running" in lowered or lowered.endswith("running"):
        return _TRANSCRIPT_STATUS_FG
    return _TRANSCRIPT_STEP_MUTED


def _tool_result_step_line_color(lowered: str) -> str:
    """Return semantic color token for tool_result/tool_done rows."""
    if _line_has_failure_signal(lowered):
        return _DANGER_COLOR
    if _line_has_success_signal(lowered):
        return _TRANSCRIPT_STEP_FINAL
    return _TRANSCRIPT_STEP_MUTED


def _step_line_color(body: str) -> str:
    """Return per-step color token for compact transcript rows."""
    lowered = str(body or "").strip().lower()
    dynamic_prefix_colors: tuple[tuple[str, Callable[[str], str]], ...] = (
        ("run_result:", _run_result_step_line_color),
        ("run:", _run_step_line_color),
        ("tool_result:", _tool_result_step_line_color),
        ("tool_done:", _tool_result_step_line_color),
        ("status:", _status_step_line_color),
    )
    for prefix, resolver in dynamic_prefix_colors:
        if lowered.startswith(prefix):
            return resolver(lowered)

    if lowered.startswith(("tool:", "tool_call:")):
        return _TRANSCRIPT_STEP_TOOL
    if lowered.startswith("tool_params:"):
        return _TRANSCRIPT_STEP_PARAM
    if lowered.startswith(("handoff:", "action:", "subagent:", "reasoning:")):
        return _TRANSCRIPT_STEP_MUTED
    if lowered.startswith("final:"):
        return _TRANSCRIPT_STEP_FINAL
    return _TRANSCRIPT_STEP_MUTED


if TEXTUAL_SUPPORTED:
    WORKSPACE_CSS = build_workspace_css(WORKSPACE_THEME)

    class AgentWorkspaceShellApp(App[AgentWorkspaceEvent | None], WorkspaceScreenshotCaptureMixin, ClipboardToastMixin):
        """Gated workspace shell for agent context with split-pane layout."""

        CSS = WORKSPACE_CSS

        # Disable Textual built-in command palette for this shell.
        ENABLE_COMMAND_PALETTE = False
        COMMAND_PALETTE_BINDING = ""

        BINDINGS = [
            *(
                _close_shortcuts(escape_action="close_overlay_or_exit", quit_action=APP_QUIT_ACTION)
                if _close_shortcuts is not None
                else (
                    Binding("escape", "close_overlay_or_exit", "Close", priority=True, show=True),
                    Binding("q", APP_QUIT_ACTION, "Close", priority=True, show=False),
                )
            ),
            Binding("ctrl+c", APP_QUIT_ACTION, "Quit", show=False),
            Binding("enter", "submit_composer", "Send", show=True),
            Binding("ctrl+b", "toggle_sidebar", "Agent Details", show=True, priority=True, key_display="ctrl+b"),
            Binding("pageup", "transcript_page_up", "Scroll Up", show=False),
            Binding("pagedown", "transcript_page_down", "Scroll Down", show=False),
            Binding("ctrl+p", "noop", "Palette", show=False, priority=True),
            Binding("ctrl+t", "transcript_hint", "Transcript", show=False),
            Binding("ctrl+shift+c", "copy_last_details", "Copy Details", show=False),
        ]

        CSS_NAME = ""

        def __init__(
            self,
            *,
            details: AgentWorkspaceDetails,
            transcript_lines: list[str] | None = None,
            composer_placeholder: str,
            status_summary_provider: StatusSummaryProvider | None = None,
            details_provider: DetailsProvider | None = None,
            transcript_sink: TranscriptSink | None = None,
            message_run_provider: MessageRunProvider | None = None,
        ) -> None:
            """Initialize app state for a single workspace interaction turn."""
            super().__init__()
            self._details = details
            self._transcript_lines = list(transcript_lines or [])[-TRANSCRIPT_MAX_LINES:]
            self._composer_placeholder = composer_placeholder
            self._status_summary_provider = status_summary_provider
            self._details_provider = details_provider
            self._transcript_sink = transcript_sink
            self._message_run_provider = message_run_provider
            self._sidebar_visible = False
            self._workspace_label = _get_workspace_label()
            self._pending_command_event: AgentWorkspaceEvent | None = None
            self._inline_status_running = False
            self._inline_details_running = False
            self._inline_message_running = False
            self._inline_running_started_at: float | None = None
            self._inline_running_status_index: int | None = None
            self._slash_selected_index = 0
            self._slash_filtered: list[tuple[str, str]] = []
            self._last_details_lines: list[str] | None = None
            self._composer_history: list[str] = []
            self._composer_history_index: int | None = None
            self._composer_history_draft = ""
            self._inline_streamed_status_lines: list[str] = []
            self._inline_streamed_status_set: set[str] = set()
            self._inline_streamed_status_counts: dict[str, int] = {}
            self._pending_inline_completion_line: str | None = None
            self._pending_inline_post_status_lines: list[str] = []
            self._inline_stream_reply_index: int | None = None
            self._inline_stream_reply_text = ""

        def compose(self) -> ComposeResult:
            """Render docked workspace mirroring demo_agent_context layout."""
            has_turns = bool(self._transcript_lines)
            with Container(id="root"):
                with Vertical(id=LEFT_COLUMN_ID):
                    with Container(id=HEADER_ROW_ID):
                        yield Static(f"{self._workspace_label}:agent", id="workspace")
                        with Vertical(id=CONTEXT_BLOCK_ID):
                            yield Static(_format_agent_context_name(self._details), id=AGENT_CONTEXT_NAME_ID)
                            yield Static(_format_agent_context_account(self._details), id=AGENT_CONTEXT_ACCOUNT_ID)

                    with Container(id="center-wrapper", classes="-has-turns" if has_turns else ""):
                        with Vertical(id="chat-column", classes="-has-turns" if has_turns else ""):
                            if not has_turns:
                                yield Static(AGENT_WORKSPACE_LOGO_TEXT, id="title")
                            with Container(id=TRANSCRIPT_SCROLL_ID, classes="-has-turns" if has_turns else ""):
                                yield Static(
                                    _format_transcript(self._transcript_lines),
                                    id=TRANSCRIPT_ID,
                                    classes="-has-turns" if has_turns else "",
                                )

                    with Container(id="prompt-row"):
                        with Container(id="composer-box"):
                            yield Input(
                                placeholder=self._composer_placeholder,
                                id=COMPOSER_ID,
                            )

                    yield Container(
                        Vertical(Static(id=SLASH_ROWS_ID), classes="slash-menu"),
                        id=SLASH_WRAP_ID,
                        classes="-hidden",
                    )

                    with Container(id="hints-row"):
                        yield Static(WORKSPACE_TIP_TEXT, id="tip")

                    with Container(id="footer-row"):
                        if _PulseIndicator is not None:
                            yield _PulseIndicator(
                                "Ready",
                                id=COMMAND_LOADING_ID,
                                variant="info",
                                width=30,
                                speed_ms=80,
                                low_motion=False,
                                pause_at_edges=True,
                                classes="-hidden",
                            )
                        else:
                            yield Static("Ready", id=COMMAND_LOADING_ID, classes="-hidden")
                        yield Static(f"GL AIP SDK v{SDK_VERSION}", id="footer-version")

                with Vertical(id=SIDEBAR_ID, classes="" if self._sidebar_visible else "-hidden"):
                    yield Static(_format_sidebar_header(self._details), id="sidebar-header")
                    yield Static(_format_details(self._details), id=DETAILS_ID)
                    yield Button("View Full Details", id="view-details-btn", variant="primary")

            with Container(id=KEYBAR_ROW_ID, classes="-hidden"):
                yield Static(self._keybar_left_text(), id=KEYBAR_LEFT_ID)
                yield Static("", id=KEYBAR_RIGHT_ID)

        def _keybar_left_text(self) -> str:
            """Render bottom keybar with explicit show/hide sidebar action."""
            details_action = "Hide Agent Details" if self._sidebar_visible else "Show Agent Details"
            return f"[bold #f2b266]esc[/] Close   [bold #f2b266]ctrl+b[/] {details_action}"

        def on_mount(self) -> None:
            """Focus composer input when the workspace opens."""
            self.query_one(f"#{COMPOSER_ID}", Input).focus()
            self._refresh_transcript_widget()
            self._refresh_chrome_visibility()
            self._refresh_slash_menu("")

        def _is_slash_open(self) -> bool:
            """Return True when slash suggestion dropdown is currently visible."""
            try:
                return not self.query_one(f"#{SLASH_WRAP_ID}", Container).has_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual query guard
                return False

        def _close_slash_menu(self) -> None:
            """Hide slash dropdown and clear selection state."""
            self._slash_filtered = []
            self._slash_selected_index = 0
            try:
                self.query_one(f"#{SLASH_WRAP_ID}", Container).add_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual query guard
                pass

        def _refresh_slash_menu(self, value: str) -> None:
            """Refresh slash dropdown suggestions from current composer text."""
            if self._pending_command_event is not None or self._inline_status_running or self._inline_message_running:
                self._close_slash_menu()
                return

            trimmed = value.lstrip()
            if not trimmed.startswith("/"):
                self._close_slash_menu()
                return

            query = trimmed[1:].strip().lower()
            if query:
                filtered = [
                    item
                    for item in _WORKSPACE_DROPDOWN_COMMANDS
                    if query in item[0][1:].lower() or query in item[1].lower()
                ]
            else:
                filtered = list(_WORKSPACE_DROPDOWN_COMMANDS)

            filtered.sort(key=lambda item: item[0].lower())

            self._slash_filtered = filtered[:_MAX_VISIBLE_SLASH_ROWS]
            self._slash_selected_index = 0
            self._refresh_slash_rows()
            self._position_slash_menu()
            try:
                self.query_one(f"#{SLASH_WRAP_ID}", Container).remove_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual query guard
                pass

        def _refresh_slash_rows(self) -> None:
            """Render slash dropdown rows with current highlight state."""
            try:
                rows = self.query_one(f"#{SLASH_ROWS_ID}", Static)
            except Exception:  # pragma: no cover - defensive Textual query guard
                return

            if not self._slash_filtered:
                rows.update(RichText("No matching slash commands", style=WORKSPACE_THEME["muted"]))
                return

            table = RichTable.grid(expand=True)
            table.add_column(ratio=1)
            table.add_column(ratio=2)

            for idx, (command, description) in enumerate(self._slash_filtered):
                if idx == self._slash_selected_index:
                    command_text = RichText(command, style="bold #2b1600 on #f2b266")
                    desc_text = RichText(description, style="bold #2b1600 on #f2b266")
                else:
                    command_text = RichText(command, style=WORKSPACE_THEME["text"])
                    desc_text = RichText(description, style=WORKSPACE_THEME["muted"])
                table.add_row(command_text, desc_text)

            rows.update(table)

        def _position_slash_menu(self) -> None:
            """Anchor slash dropdown near composer cursor location."""
            try:
                composer_box = self.query_one("#composer-box", Container)
                composer = self.query_one(f"#{COMPOSER_ID}", Input)
                slash_wrap = self.query_one(f"#{SLASH_WRAP_ID}", Container)

                region = composer_box.region
                menu_width = 72
                menu_height = self._estimate_slash_menu_height(len(self._slash_filtered))
                x, y = self._clamp_slash_menu_offset(
                    screen_width=int(self.size.width),
                    screen_height=int(self.size.height),
                    anchor_x=int(region.x + 2 + int(composer.cursor_position)),
                    anchor_y=int(region.y + region.height - 1),
                    composer_top=int(region.y),
                    menu_width=menu_width,
                    menu_height=menu_height,
                )
                slash_wrap.styles.offset = (x, y)
            except Exception:  # pragma: no cover - defensive Textual region guard
                pass

        @staticmethod
        def _estimate_slash_menu_height(row_count: int) -> int:
            """Estimate menu height from row count within CSS min/max bounds."""
            return min(11, max(5, int(row_count) + 2))

        @staticmethod
        def _clamp_slash_menu_offset(
            *,
            screen_width: int,
            screen_height: int,
            anchor_x: int,
            anchor_y: int,
            composer_top: int,
            menu_width: int,
            menu_height: int,
        ) -> tuple[int, int]:
            """Clamp slash menu offset to the visible viewport.

            When there isn't enough room below the composer, place the menu above it.
            """
            max_x = max(0, int(screen_width) - int(menu_width) - 2)
            x = min(max(int(anchor_x), 0), max_x)

            max_y = max(0, int(screen_height) - int(menu_height) - 1)
            y = max(0, int(anchor_y))
            if y > max_y:
                y = max(0, int(composer_top) - int(menu_height))
            y = min(y, max_y)
            return x, y

        def action_toggle_sidebar(self) -> None:
            """Toggle right sidebar visibility."""
            self._sidebar_visible = not self._sidebar_visible
            sidebar = self.query_one(f"#{SIDEBAR_ID}", Vertical)
            if self._sidebar_visible:
                sidebar.remove_class("-hidden")
            else:
                sidebar.add_class("-hidden")
            self._refresh_chrome_visibility()

        def action_close_overlay_or_exit(self) -> None:
            """Close slash dropdown first; otherwise exit workspace shell."""
            if self._is_slash_open():
                self._close_slash_menu()
                composer = self.query_one(f"#{COMPOSER_ID}", Input)
                composer.focus()
                return
            self.exit(None)

        def action_transcript_page_up(self) -> None:
            """Scroll transcript viewport upward by one page."""
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            scroll_page_up = getattr(transcript_scroll, "scroll_page_up", None)
            if callable(scroll_page_up):
                scroll_page_up(animate=False)

        def action_transcript_page_down(self) -> None:
            """Scroll transcript viewport downward by one page."""
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            scroll_page_down = getattr(transcript_scroll, "scroll_page_down", None)
            if callable(scroll_page_down):
                scroll_page_down(animate=False)

        def action_submit_composer(self) -> None:
            """Emit message/command/exit event from composer input."""
            if (
                self._pending_command_event is not None
                or self._inline_status_running
                or self._inline_details_running
                or self._inline_message_running
            ):
                return

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            value = (composer.value or "").strip()
            if not value:
                return

            if value.startswith("/") and self._is_slash_open() and self._slash_filtered:
                selected_idx = max(0, min(self._slash_selected_index, len(self._slash_filtered) - 1))
                selected_command, _ = self._slash_filtered[selected_idx]
                value = selected_command
                composer.value = selected_command

            self._close_slash_menu()
            self._remember_composer_history(value)
            self._reset_composer_history_navigation()

            if value.startswith("/"):
                self._handle_slash_submit(value)
                return

            if self._message_run_provider is not None:
                self._run_inline_message(value)
                return

            self.exit(AgentWorkspaceEvent(kind="message", value=value))

        def _handle_slash_submit(self, value: str) -> None:
            """Process a slash command submission."""
            command = value.split(maxsplit=1)[0].lower()
            command_meta = _WORKSPACE_COMMAND_INDEX.get(command)
            if command_meta is None:
                self._reject_workspace_command(value)
                return

            if command_meta.route == "exit":
                self.exit(AgentWorkspaceEvent(kind="exit", value=value))
                return

            if command_meta.route == "inline_status" and self._status_summary_provider is not None:
                self._run_inline_status(value)
                return

            if command in {_HELP_COMMAND, "/?"}:
                self._run_inline_help(value)
                return

            if command == _DETAILS_COMMAND and callable(self._details_provider):
                self._run_inline_details(value)
                return

            self._queue_command_transition(value)

        def _remember_composer_history(self, value: str) -> None:
            """Append submitted command/message into in-session composer history."""
            text = str(value or "").strip()
            if not text:
                return
            self._composer_history.append(text)

        def _reset_composer_history_navigation(self) -> None:
            """Reset composer history cursor after manual edits/submissions."""
            self._composer_history_index = None
            self._composer_history_draft = ""

        def _composer_has_focus(self) -> bool:
            """Return True when key events originate from the composer input."""
            focused = getattr(self, "focused", None)
            return isinstance(focused, Input) and focused.id == COMPOSER_ID

        def _navigate_composer_history(self, direction: str) -> bool:
            """Navigate command/query history using shell-style up/down keys."""
            if direction not in {"up", "down"}:
                return False
            if not self._composer_history:
                return False

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            index = self._composer_history_index
            if direction == "up":
                if index is None:
                    self._composer_history_draft = composer.value
                    index = len(self._composer_history) - 1
                else:
                    index = max(0, index - 1)
            else:
                if index is None:
                    return False
                if index >= len(self._composer_history) - 1:
                    composer.value = self._composer_history_draft
                    composer.cursor_position = len(composer.value)
                    self._composer_history_index = None
                    self._refresh_slash_menu(composer.value)
                    return True
                index += 1

            self._composer_history_index = index
            composer.value = self._composer_history[index]
            composer.cursor_position = len(composer.value)
            self._refresh_slash_menu(composer.value)
            return True

        def _run_inline_help(self, command_text: str) -> None:
            """Append descriptive help hints without leaving the workspace."""
            self._append_command_entry(command_text)

            visible_commands = [
                (name, description)
                for name, description in _WORKSPACE_DROPDOWN_COMMANDS
                if name not in {_HELP_COMMAND, _Q_EXIT_COMMAND}
            ]
            help_lines = [
                "System: Available Workspace Commands:",
                *[f"  {name:<11} - {description}" for name, description in visible_commands],
            ]

            for line in help_lines:
                self._append_transcript_line(line)

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()
            self._refresh_chrome_visibility()

        def _run_inline_details(self, command_text: str) -> None:
            """Execute details provider and keep users on the current workspace surface."""
            self._inline_details_running = True
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Loading {command_text}...")
            else:
                loading.update(f"Loading {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.run_worker(
                self._run_inline_details_task(command_text),
                name="workspace-inline-details",
                group="workspace-inline",
                exclusive=True,
            )

        async def _run_inline_details_task(self, command_text: str) -> None:
            """Run inline details provider in a Textual worker."""
            try:
                lines = await asyncio.to_thread(self._run_inline_details_provider)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                lines = [f"{_DETAILS_SENTINEL}details:", f"{_DETAILS_SENTINEL}  error: {exc}"]
            self._finalize_inline_details(command_text, lines)

        def _run_inline_details_provider(self) -> list[str]:
            """Collect details lines from the configured provider."""
            provider = self._details_provider
            if not callable(provider):
                return []
            return list(provider())

        def _finalize_inline_details(self, command_text: str, lines: list[str]) -> None:
            """Render details output, store for copy, and restore workspace controls."""
            self._last_details_lines = list(lines) if lines else None
            self._append_command_entry(command_text)
            if lines:
                for line in lines:
                    self._append_transcript_line(line)
            else:
                self._append_transcript_line("System: Details unavailable")

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            stop = getattr(loading, "stop", None)
            if callable(stop):
                stop()
            loading.remove_class("-active")
            loading.add_class("-hidden")

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

            self._inline_details_running = False
            self._refresh_chrome_visibility()
            self._schedule_followup_capture()

        def _run_inline_message(self, message_text: str) -> None:
            """Execute agent message run while keeping users on workspace surface."""
            self._append_user_entry(message_text)
            self._append_transcript_line("")
            self._append_transcript_line("run: [~] running")
            self._inline_running_started_at = time.monotonic()
            self._inline_running_status_index = len(self._transcript_lines) - 1
            self._inline_streamed_status_lines = []
            self._inline_streamed_status_set = set()
            self._inline_streamed_status_counts = {}
            self._pending_inline_completion_line = None
            self._pending_inline_post_status_lines = []
            self._inline_stream_reply_index = None
            self._inline_stream_reply_text = ""

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message("Running...")
            else:
                loading.update("Running...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self._inline_message_running = True
            self.set_timer(INLINE_RUNNING_TICK_SECONDS, self._tick_inline_running_status)
            self.run_worker(
                self._run_inline_message_task(message_text),
                name="workspace-inline-message",
                group="workspace-inline",
                exclusive=True,
            )

        def _tick_inline_running_status(self) -> None:
            """Update elapsed running time while inline message execution is active."""
            if not self._inline_message_running:
                return

            started_at = self._inline_running_started_at
            if started_at is not None:
                elapsed_seconds = max(1, int(time.monotonic() - started_at))
                elapsed_label = f"Running... {elapsed_seconds}s"
                try:
                    loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
                except Exception:  # pragma: no cover - defensive UI lifecycle guard
                    loading = None
                if loading is not None:
                    update_message = getattr(loading, "update_message", None)
                    if callable(update_message):
                        update_message(elapsed_label)
                    else:
                        loading.update(elapsed_label)

            if self._inline_message_running:
                self.set_timer(INLINE_RUNNING_TICK_SECONDS, self._tick_inline_running_status)

        async def _run_inline_message_task(self, message_text: str) -> None:
            """Run inline message provider in a Textual worker."""
            try:
                reply, status_lines = await asyncio.to_thread(self._run_inline_message_provider, message_text)
                self._finalize_inline_message(reply, status_lines)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                self._finalize_inline_message(None, [f"{_RUN_FAILED_PREFIX} {exc}"])

        def _run_inline_message_provider(self, message_text: str) -> tuple[str | None, list[str]]:
            """Execute message provider and normalize reply/status lines."""
            provider = self._message_run_provider
            if provider is None:
                return None, []

            if self._provider_accepts_stream_callbacks(provider):
                result = provider(
                    message_text,
                    **{
                        _STREAM_STATUS_CALLBACK_ARG: self._on_stream_status_line,
                        _STREAM_REPLY_CALLBACK_ARG: self._on_stream_reply_chunk,
                    },
                )
            else:
                result = provider(message_text)
            return self._parse_message_run_result(result)

        @staticmethod
        def _parse_message_run_result(result: str | tuple[str, list[str]] | None) -> tuple[str | None, list[str]]:
            """Normalize message provider return shape."""
            if result is None:
                return None, []
            if isinstance(result, tuple) and len(result) == 2:
                reply, status_lines = result
                return str(reply or "").strip() or None, [str(line) for line in status_lines if str(line).strip()]
            return str(result or "").strip() or None, []

        @staticmethod
        def _provider_accepts_stream_callbacks(provider: MessageRunProvider) -> bool:
            """Return True when provider supports stream callback keyword arguments."""
            try:
                params = inspect.signature(provider).parameters.values()
            except (TypeError, ValueError):
                return False

            names: set[str] = set()
            for parameter in params:
                if parameter.kind == inspect.Parameter.VAR_KEYWORD:
                    return True
                names.add(parameter.name)

            return {
                _STREAM_STATUS_CALLBACK_ARG,
                _STREAM_REPLY_CALLBACK_ARG,
            }.issubset(names)

        def _dispatch_inline_stream_callback(self, callback: Callable[..., None], *args: Any) -> None:
            """Dispatch stream updates from worker thread into the Textual app thread."""
            call_from_thread = getattr(self, "call_from_thread", None)
            if callable(call_from_thread):
                try:
                    call_from_thread(callback, *args)
                    return
                except Exception:
                    pass
            callback(*args)

        def _on_stream_status_line(self, line: str) -> None:
            """Queue one streamed status row from provider emissions."""
            self._dispatch_inline_stream_callback(self._append_stream_status_line, line)

        def _on_stream_reply_chunk(self, chunk: str) -> None:
            """Queue one streamed reply chunk from provider emissions."""
            self._dispatch_inline_stream_callback(self._append_stream_reply_chunk, chunk)

        def _append_stream_status_line(self, line: str) -> None:
            """Append one streamed status line while deduplicating noisy repeats."""
            cleaned = str(line or "").strip()
            if not cleaned:
                return

            normalized_completion = self._normalize_inline_completion_line(cleaned)
            if normalized_completion is not None:
                self._pending_inline_completion_line = normalized_completion
                return
            if AgentWorkspaceShellApp._is_post_response_status_line(cleaned):
                if cleaned not in self._pending_inline_post_status_lines:
                    self._pending_inline_post_status_lines.append(cleaned)
                return
            if self._is_noisy_inline_status_line(cleaned):
                return
            if self._is_failure_status_line(cleaned):
                return
            if cleaned in self._inline_streamed_status_set and not self._is_repeatable_inline_status_line(cleaned):
                return

            self._inline_streamed_status_set.add(cleaned)
            self._inline_streamed_status_lines.append(cleaned)
            self._inline_streamed_status_counts[cleaned] = self._inline_streamed_status_counts.get(cleaned, 0) + 1
            insert_at = self._inline_stream_reply_index
            spacer_lines = self._append_stream_event_spacer(cleaned, insert_at=insert_at)

            if insert_at is None:
                self._append_transcript_line(cleaned)
                return

            self._insert_transcript_line(insert_at + spacer_lines, cleaned)
            self._inline_stream_reply_index = insert_at + spacer_lines + 1

        def _append_stream_event_spacer(self, status_line: str, *, insert_at: int | None = None) -> int:
            """Insert one blank line between event groups while keeping blocks compact."""
            if not self._is_stream_event_boundary(status_line):
                return 0

            if insert_at is None:
                if not self._transcript_lines or not str(self._transcript_lines[-1]).strip():
                    return 0
            else:
                insert_at = max(0, min(insert_at, len(self._transcript_lines)))
                if insert_at > 0 and not str(self._transcript_lines[insert_at - 1]).strip():
                    return 0

            previous = self._latest_nonempty_transcript_line(before_index=insert_at)
            if previous is None:
                return 0

            if self._is_stream_event_boundary(previous) or previous.lower().startswith(
                ("tool_params:", "tool_done:", "tool_result:", "run: [~] running", "status: [~] running")
            ):
                if insert_at is None:
                    self._append_transcript_line("")
                else:
                    self._insert_transcript_line(insert_at, "")
                return 1

            return 0

        @staticmethod
        def _is_repeatable_inline_status_line(status_line: str) -> bool:
            """Return True for streamed status rows that may repeat across retries."""
            lowered = str(status_line or "").strip().lower()
            return lowered.startswith(("tool_call:", "tool_params:", "tool_result:", "handoff:"))

        def _latest_nonempty_transcript_line(self, *, before_index: int | None = None) -> str | None:
            """Return the latest non-empty transcript line, if any."""
            if before_index is None:
                candidates = self._transcript_lines
            else:
                before_index = max(0, min(before_index, len(self._transcript_lines)))
                candidates = self._transcript_lines[:before_index]

            for raw in reversed(candidates):
                cleaned = str(raw or "").strip()
                if cleaned:
                    return cleaned
            return None

        @staticmethod
        def _is_stream_event_boundary(line: str) -> bool:
            """Return True when streamed status line starts a new visual event block."""
            lowered = str(line or "").strip().lower()
            return lowered.startswith(("tool_call:", "handoff:", "subagent:", "reasoning:", "action:"))

        def _append_stream_reply_chunk(self, chunk: str) -> None:
            """Append streamed reply text in-place inside a single Agent row."""
            text = str(chunk or "")
            if not text:
                return

            if self._inline_stream_reply_index is None:
                if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                    self._append_transcript_line("")
                self._append_transcript_line("Agent Final: ")
                self._inline_stream_reply_index = len(self._transcript_lines) - 1

            self._inline_stream_reply_text += text
            self._replace_transcript_line(
                self._inline_stream_reply_index,
                f"Agent Final: {self._inline_stream_reply_text}",
            )

        def _replace_transcript_line(self, index: int | None, value: str) -> None:
            """Replace one transcript row in place and refresh the rendered widget."""
            if index is None:
                return
            if index < 0 or index >= len(self._transcript_lines):
                return
            self._transcript_lines[index] = value

            transcript_sink = self._transcript_sink
            if callable(transcript_sink):
                transcript_sink(list(self._transcript_lines))

            self._refresh_transcript_widget()
            self._refresh_chrome_visibility()

        def _insert_transcript_line(self, index: int, value: str) -> None:
            """Insert one transcript row at a specific index and refresh widgets."""
            insert_at = max(0, min(index, len(self._transcript_lines)))
            self._transcript_lines.insert(insert_at, value)

            transcript_sink = self._transcript_sink
            if callable(transcript_sink):
                transcript_sink(list(self._transcript_lines))

            self._refresh_transcript_widget()
            self._refresh_chrome_visibility()

        def _finalize_inline_message(self, reply: str | None, status_lines: list[str]) -> None:
            """Restore workspace controls and append final agent run summary lines."""
            failure_line = self._derive_inline_failure_status(reply, status_lines)

            completion_line, detail_lines, post_status_lines = self._split_inline_status_lines(
                status_lines,
                failure_line=failure_line,
            )
            if completion_line is None:
                completion_line = self._pending_inline_completion_line
            merged_post_status_lines = list(self._pending_inline_post_status_lines)
            merged_post_status_lines.extend(post_status_lines)
            token_usage_line, remaining_post_status_lines = self._split_token_usage_from_post_status(
                merged_post_status_lines
            )

            self._append_inline_message_detail_lines(detail_lines)
            self._finalize_inline_stream_reply_line(reply, failure_line=failure_line)
            self._append_inline_completion_line(
                completion_line,
                failure_line=failure_line,
                token_usage_line=token_usage_line,
            )
            self._append_inline_post_status_lines(remaining_post_status_lines)

            self._inline_streamed_status_lines = []
            self._inline_streamed_status_set = set()
            self._inline_streamed_status_counts = {}
            self._pending_inline_completion_line = None
            self._pending_inline_post_status_lines = []
            self._inline_stream_reply_index = None
            self._inline_stream_reply_text = ""
            self._inline_running_started_at = None
            self._inline_running_status_index = None
            self._inline_message_running = False
            self._finalize_inline_status()

        def _append_inline_message_detail_lines(self, detail_lines: list[str]) -> None:
            """Append post-run detail lines while avoiding duplicate streamed rows."""
            if self._inline_streamed_status_lines:
                for detail_line in detail_lines:
                    if self._consume_streamed_status_occurrence(detail_line):
                        continue
                    self._append_transcript_line(detail_line)
                return

            rendered_details = self._format_inline_detail_lines(detail_lines)
            for detail_line in rendered_details:
                self._append_transcript_line(detail_line)

        def _append_inline_completion_line(
            self,
            completion_line: str | None,
            *,
            failure_line: str | None = None,
            token_usage_line: str | None = None,
        ) -> None:
            """Append one canonical run-result footer row when available."""
            canonical_line = AgentWorkspaceShellApp._compose_inline_run_result_line(
                completion_line,
                failure_line=failure_line,
                token_usage_line=token_usage_line,
            )
            if canonical_line is None:
                return
            if self._transcript_lines and str(self._transcript_lines[-1]).strip() == canonical_line:
                return
            if self._transcript_lines:
                tail = str(self._transcript_lines[-1]).strip()
                if tail.lower().startswith("status:"):
                    legacy_line = _legacy_status_to_activity_line(tail.split(":", 1)[1].strip())
                    if legacy_line == canonical_line:
                        return
            if self._transcript_lines and str(self._transcript_lines[-1]).strip() == completion_line:
                return
            self._append_transcript_line(canonical_line)

        @staticmethod
        def _compose_inline_run_result_line(
            completion_line: str | None,
            *,
            failure_line: str | None,
            token_usage_line: str | None,
        ) -> str | None:
            """Compose one footer-like run result line using tool-result-style segments."""
            segments: list[str] = []
            if failure_line:
                segments.append(AgentWorkspaceShellApp._normalize_failure_status_line(failure_line))
            elif completion_line:
                segments.append(str(completion_line).strip())

            normalized_usage = AgentWorkspaceShellApp._normalize_token_usage_status_line(token_usage_line or "")
            if normalized_usage:
                if not segments:
                    segments.append(normalized_usage)
                elif normalized_usage not in segments:
                    segments.append(normalized_usage)

            if not segments:
                return None
            return f"run_result: {' | '.join(segments)}"

        @staticmethod
        def _split_token_usage_from_post_status(status_lines: list[str]) -> tuple[str | None, list[str]]:
            """Extract first token-usage footer and return remaining post-status rows."""
            seen: set[str] = set()
            token_usage_line: str | None = None
            remaining: list[str] = []
            for raw_line in status_lines:
                cleaned = AgentWorkspaceShellApp._prepare_post_status_line(raw_line, seen=seen)
                if cleaned is None:
                    continue
                normalized_usage = AgentWorkspaceShellApp._normalize_token_usage_status_line(cleaned)
                if normalized_usage is not None:
                    if token_usage_line is None:
                        token_usage_line = normalized_usage
                    continue
                remaining.append(cleaned)
            return token_usage_line, remaining

        @staticmethod
        def _normalize_token_usage_status_line(status_line: str) -> str | None:
            """Normalize token-usage status rows while tolerating legacy prefixes."""
            cleaned = str(status_line or "").strip()
            if not cleaned:
                return None
            lowered = cleaned.lower()
            if lowered.startswith("status:"):
                body = cleaned.split(":", 1)[1].strip()
                return AgentWorkspaceShellApp._normalize_token_usage_status_line(body)
            if lowered.startswith("token usage:"):
                return cleaned
            return None

        def _append_inline_post_status_lines(self, status_lines: list[str]) -> None:
            """Append post-response status footer rows while preserving order."""
            seen: set[str] = set()
            for raw_line in status_lines:
                cleaned = self._prepare_post_status_line(raw_line, seen=seen)
                if cleaned is None:
                    continue

                if self._consume_streamed_status_occurrence(cleaned):
                    continue

                line = self._canonical_post_status_line(cleaned)
                if self._transcript_ends_with_line(line):
                    continue
                self._append_transcript_line(line)

        @staticmethod
        def _prepare_post_status_line(raw_line: str, *, seen: set[str]) -> str | None:
            """Normalize one post-status candidate and dedupe by first-seen order."""
            cleaned = str(raw_line or "").strip()
            if not cleaned or cleaned in seen:
                return None
            seen.add(cleaned)
            return cleaned

        @staticmethod
        def _canonical_post_status_line(cleaned: str) -> str:
            """Render one post-status footer line without legacy `Status:` labels."""
            if cleaned.lower().startswith("status:"):
                body = cleaned.split(":", 1)[1].strip()
                return f"status: {body}" if body else "status:"
            lowered = cleaned.lower()
            if lowered.startswith(("status:", "run:", "run_result:", "tool_", "tool:", "handoff:", "reasoning:")):
                return cleaned
            return f"status: {cleaned}"

        def _transcript_ends_with_line(self, line: str) -> bool:
            """Return True when transcript tail already matches `line`."""
            return bool(self._transcript_lines and str(self._transcript_lines[-1]).strip() == line)

        def _consume_streamed_status_occurrence(self, line: str) -> bool:
            """Return True and decrement count when line already arrived via streaming."""
            cleaned = str(line or "").strip()
            if not cleaned:
                return False
            count = self._inline_streamed_status_counts.get(cleaned, 0)
            if count <= 0:
                return False
            if count == 1:
                self._inline_streamed_status_counts.pop(cleaned, None)
            else:
                self._inline_streamed_status_counts[cleaned] = count - 1
            return True

        def _finalize_inline_stream_reply_line(self, reply: str | None, *, failure_line: str | None) -> None:
            """Finalize the AGENT row using streamed chunks or terminal reply text."""
            if self._inline_stream_reply_index is None:
                self._append_inline_reply_line(reply, failure_line=failure_line)
                return

            final_reply = str(reply or self._inline_stream_reply_text).strip()
            if final_reply:
                self._replace_transcript_line(self._inline_stream_reply_index, f"Agent Final: {final_reply}")
                return
            if failure_line is None:
                self._replace_transcript_line(self._inline_stream_reply_index, "Agent: Run finished.")

        def _split_inline_status_lines(
            self,
            status_lines: list[str],
            *,
            failure_line: str | None,
        ) -> tuple[str | None, list[str], list[str]]:
            """Return completion label, detail rows, and post-response status footer rows."""
            completion_line: str | None = None
            detail_lines: list[str] = []
            post_status_lines: list[str] = []

            for raw_line in status_lines:
                cleaned = str(raw_line).strip()
                if not cleaned:
                    continue

                if self._is_noisy_inline_status_line(cleaned):
                    continue

                if AgentWorkspaceShellApp._is_post_response_status_line(cleaned):
                    post_status_lines.append(cleaned)
                    continue

                norm_completion = self._normalize_inline_completion_line(cleaned)
                if norm_completion is not None:
                    completion_line = norm_completion
                    continue

                if failure_line is not None and self._is_failure_status_line(cleaned):
                    continue
                detail_lines.append(cleaned)

            return completion_line, detail_lines, post_status_lines

        @staticmethod
        def _format_inline_detail_lines(detail_lines: list[str]) -> list[str]:
            """Group tool lifecycle rows into compact blocks with clear boundaries."""
            entries = AgentWorkspaceShellApp._parse_inline_detail_entries(detail_lines)
            rendered = AgentWorkspaceShellApp._render_inline_detail_entries(entries)
            while rendered and not rendered[-1].strip():
                rendered.pop()
            return rendered

        @staticmethod
        def _parse_inline_detail_entries(detail_lines: list[str]) -> list[str | dict[str, Any]]:
            """Parse inline detail rows into rendered text rows and structured blocks."""
            entries: list[str | dict[str, Any]] = []
            tool_blocks: list[dict[str, Any]] = []
            open_by_name: dict[str, list[dict[str, Any]]] = {}
            for raw_line in detail_lines:
                line = str(raw_line or "").strip()
                if not line:
                    continue
                AgentWorkspaceShellApp._consume_inline_detail_line(
                    line,
                    entries=entries,
                    tool_blocks=tool_blocks,
                    open_by_name=open_by_name,
                )
            return entries

        @staticmethod
        def _consume_inline_detail_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Consume one inline detail row into block entries."""
            lowered = line.lower()
            handlers: tuple[tuple[str, Callable[..., None]], ...] = (
                ("tool_call:", AgentWorkspaceShellApp._consume_tool_call_line),
                ("tool_params:", AgentWorkspaceShellApp._consume_tool_params_line),
                ("tool_result:", AgentWorkspaceShellApp._consume_tool_result_line),
                ("handoff:", AgentWorkspaceShellApp._consume_handoff_line),
            )
            for prefix, handler in handlers:
                if lowered.startswith(prefix):
                    handler(line, entries=entries, tool_blocks=tool_blocks, open_by_name=open_by_name)
                    return
            entries.append(line)

        @staticmethod
        def _consume_tool_call_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Start a tool lifecycle block from a tool_call row."""
            tool_name = line.split(":", 1)[1].strip() or "tool"
            block: dict[str, Any] = {
                "kind": "tool",
                "name": tool_name,
                "params": [],
                "completion": None,
            }
            tool_blocks.append(block)
            entries.append(block)
            key = AgentWorkspaceShellApp._normalize_tool_name(tool_name)
            open_by_name.setdefault(key, []).append(block)

        @staticmethod
        def _consume_tool_params_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Attach params rows to the latest open tool block when available."""
            del open_by_name
            params_value = line.split(":", 1)[1].strip()
            block = AgentWorkspaceShellApp._latest_open_tool_block(tool_blocks)
            if block is not None and params_value:
                block["params"].append(params_value)
                return
            entries.append(line)

        @staticmethod
        def _consume_tool_result_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Attach tool_result rows to matching tool_call blocks."""
            tool_name, outcome = AgentWorkspaceShellApp._parse_tool_result_line(line)
            block = AgentWorkspaceShellApp._pop_open_tool_block(open_by_name, tool_blocks, tool_name)
            if block is None:
                entries.append(f"tool_done: {outcome or 'finished'}")
                return
            block["completion"] = outcome or "finished"

        @staticmethod
        def _consume_handoff_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Append handoff rows as explicit sub-agent entries."""
            del tool_blocks, open_by_name
            handoff = line.split(":", 1)[1].strip() or "sub-agent"
            entries.append({"kind": "subagent", "title": handoff})

        @staticmethod
        def _render_inline_detail_entries(entries: list[str | dict[str, Any]]) -> list[str]:
            """Render parsed inline detail entries into transcript lines."""
            rendered: list[str] = []
            for entry in entries:
                chunk: list[str] = []
                if isinstance(entry, str):
                    line = entry.strip()
                    if line:
                        chunk.append(line)
                else:
                    AgentWorkspaceShellApp._append_rendered_inline_detail_block(entry, chunk)

                if not chunk:
                    continue

                if rendered and rendered[-1].strip():
                    rendered.append("")
                rendered.extend(chunk)
            return rendered

        @staticmethod
        def _append_rendered_inline_detail_block(block: dict[str, Any], rendered: list[str]) -> None:
            """Render one structured inline detail block."""
            kind = str(block.get("kind") or "")
            if kind == "subagent":
                rendered.append(f"subagent: {str(block.get('title') or '').strip()}")
                return

            completion = str(block.get("completion") or "").strip()
            if not completion:
                return

            rendered.append(f"tool: {block['name']}")
            for params_line in block.get("params", []):
                rendered.append(f"tool_params: {params_line}")
            rendered.append(f"tool_done: {completion}")

        @staticmethod
        def _normalize_tool_name(value: str) -> str:
            """Normalize tool names for call/result matching."""
            return " ".join(str(value or "").strip().lower().split())

        @staticmethod
        def _latest_open_tool_block(tool_blocks: list[dict[str, Any]]) -> dict[str, Any] | None:
            """Return the most recent tool block that has no completion yet."""
            for block in reversed(tool_blocks):
                if not block.get("completion"):
                    return block
            return None

        @staticmethod
        def _pop_open_tool_block(
            open_by_name: dict[str, list[dict[str, Any]]],
            tool_blocks: list[dict[str, Any]],
            tool_name: str,
        ) -> dict[str, Any] | None:
            """Pop the oldest open tool block for a matching tool name."""
            key = AgentWorkspaceShellApp._normalize_tool_name(tool_name)
            queue = open_by_name.get(key) or []
            if queue:
                block = queue.pop(0)
                if not queue:
                    open_by_name.pop(key, None)
                return block
            return AgentWorkspaceShellApp._latest_open_tool_block(tool_blocks)

        @staticmethod
        def _parse_tool_result_line(line: str) -> tuple[str, str | None]:
            """Parse tool_result rows into tool-name and normalized completion text."""
            detail = line.split(":", 1)[1].strip() if ":" in line else line.strip()
            if not detail:
                return "tool", "finished"

            tool_name = detail
            outcome: str | None = None
            if "|" in detail:
                left, right = detail.split("|", 1)
                tool_name = left.strip() or "tool"
                outcome = right.strip() or None

            lowered = (outcome or "").lower()
            if outcome is None:
                if "failed" in detail.lower():
                    outcome = "failed"
                else:
                    outcome = "finished"
            elif lowered.startswith("ok "):
                outcome = outcome[3:].strip()
            elif lowered in {"running", "in_progress"}:
                outcome = "finished"

            return tool_name, outcome

        def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
            """Track worker lifecycle for debugging and error handling."""
            worker = event.worker
            state = event.state
            if state == WorkerState.ERROR:
                self.log.error(f"Worker {worker.name} failed: {worker.error}")
            elif state == WorkerState.CANCELLED:
                self.log.warning(f"Worker {worker.name} was cancelled")
            elif state == WorkerState.SUCCESS:
                self.log.info(f"Worker {worker.name} completed successfully")

        def _append_inline_reply_line(self, reply: str | None, *, failure_line: str | None) -> None:
            """Append terminal reply line after status rows are rendered."""
            if reply:
                if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                    self._append_transcript_line("")
                self._append_transcript_line(f"Agent Final: {reply}")
                return
            if failure_line is None:
                if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                    self._append_transcript_line("")
                self._append_transcript_line("Agent: Run finished.")

        @staticmethod
        def _is_noisy_inline_status_line(status_line: str) -> bool:
            """Return True for noisy run-id rows that add little user value."""
            lowered = status_line.lower().strip()
            return bool(re.match(r"^run\s+[a-z0-9_-]+\s+(completed|finished|done)$", lowered))

        @staticmethod
        def _normalize_inline_completion_line(status_line: str) -> str | None:
            """Map duration/completion metadata rows into one canonical completion label."""
            lowered = status_line.lower().strip()
            if lowered.startswith("run_result:"):
                body = status_line.split(":", 1)[1].strip()
                return AgentWorkspaceShellApp._normalize_inline_completion_line(body)
            if lowered.startswith("run result "):
                body = status_line[len("run result ") :].strip()
                return AgentWorkspaceShellApp._normalize_inline_completion_line(body)
            if lowered.startswith("status:"):
                body = status_line.split(":", 1)[1].strip()
                normalized = AgentWorkspaceShellApp._normalize_inline_completion_line(body)
                if normalized is not None:
                    return normalized
            if lowered.startswith(("[ok] ", "[~] ", "[x] ")):
                body = status_line.split("]", 1)[1].strip() if "]" in status_line else ""
                normalized = AgentWorkspaceShellApp._normalize_inline_completion_line(body)
                if normalized is not None:
                    return normalized
            if lowered.startswith("completed in "):
                return status_line.strip()
            if lowered.startswith("duration:"):
                duration = status_line.split(":", 1)[1].strip()
                if duration:
                    return f"completed in {duration}"
            return None

        @staticmethod
        def _is_post_response_status_line(status_line: str) -> bool:
            """Return True when status row should render in the post-response footer."""
            return AgentWorkspaceShellApp._normalize_token_usage_status_line(status_line) is not None

        @staticmethod
        def _derive_inline_failure_status(reply: str | None, status_lines: list[str]) -> str | None:
            """Return a concise failure status row when inline run completed without a response."""
            text = (reply or "").strip()
            lowered = text.lower()

            if lowered.startswith(_RUN_FAILED_PREFIX):
                reason = text.split(":", 1)[1].strip() if ":" in text else ""
                return f"{_RUN_FAILED_PREFIX} {reason or 'unknown error'}"

            failure_detail = next(
                (line.strip() for line in status_lines if AgentWorkspaceShellApp._is_failure_status_line(line)),
                None,
            )
            if failure_detail is not None:
                return AgentWorkspaceShellApp._normalize_failure_status_line(failure_detail)

            if "no agent response received" in lowered or "no final response available" in lowered:
                return f"{_RUN_FAILED_PREFIX} no final response available"

            return None

        @staticmethod
        def _is_failure_status_line(status_line: str) -> bool:
            """Return True when a status line denotes a failed/aborted run."""
            lowered = status_line.lower().strip()
            return lowered.startswith(_RUN_FAILED_PREFIX) or lowered.startswith("error:") or lowered.startswith("abort")

        @staticmethod
        def _normalize_failure_status_line(status_line: str) -> str:
            """Convert a failure-like status row into canonical run-failed form."""
            cleaned = status_line.strip()
            lowered = cleaned.lower()

            if lowered.startswith(_RUN_FAILED_PREFIX):
                reason = cleaned.split(":", 1)[1].strip() if ":" in cleaned else ""
                return f"{_RUN_FAILED_PREFIX} {reason or 'unknown error'}"

            return f"{_RUN_FAILED_PREFIX} {cleaned}"

        def _reject_workspace_command(self, command_text: str) -> None:
            """Keep unsupported slash commands in-place with a concise inline hint."""
            self._append_command_entry(command_text)
            self._append_transcript_line("status: command unavailable in this workspace.")
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

        def _queue_command_transition(self, command_text: str) -> None:
            """Show in-page pulse before leaving to execute slash command."""
            self._append_command_entry(command_text)
            self._append_transcript_line(f"status: opening {command_text}...")
            self._pending_command_event = AgentWorkspaceEvent(kind="command", value=command_text)

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Opening {command_text}...")
            else:
                loading.update(f"Opening {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.set_timer(COMMAND_TRANSITION_DELAY_SECONDS, self._flush_pending_command)

        def _flush_pending_command(self) -> None:
            """Exit app with pending slash command event after pulse delay."""
            if self._pending_command_event is None:
                return
            event = self._pending_command_event
            self._pending_command_event = None
            self.exit(event)

        def _run_inline_status(self, command_text: str) -> None:
            """Execute /status and keep users on the current workspace surface."""
            self._inline_status_running = True
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Checking {command_text}...")
            else:
                loading.update(f"Checking {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.run_worker(
                self._run_inline_status_task(command_text),
                name="workspace-inline-status",
                group="workspace-inline",
                exclusive=True,
            )

        async def _run_inline_status_task(self, command_text: str) -> None:
            """Run inline status provider in a worker thread."""
            try:
                lines = await asyncio.to_thread(self._run_inline_status_provider, command_text)
            except Exception as exc:  # pragma: no cover - defensive
                lines = [f"Status unavailable: {exc}"]
            self._complete_inline_status(command_text, lines)

        def _run_inline_status_provider(self, command_text: str) -> list[str]:
            """Collect status lines from the configured status provider."""
            provider = self._status_summary_provider
            return self._collect_inline_status_lines(provider, command_text)

        def _complete_inline_status(self, command_text: str, lines: list[str]) -> None:
            """Finish inline /status execution and refresh transcript content."""
            self._append_command_entry(command_text)
            if lines:
                for line in lines:
                    self._append_transcript_line(f"status: {line}")
            else:
                self._append_transcript_line("status: unavailable")

            self._finalize_inline_status()

        @staticmethod
        def _collect_inline_status_lines(provider: StatusSummaryProvider | None, command_text: str) -> list[str]:
            """Collect inline status lines while preserving command arguments when supported."""
            if not callable(provider):
                return []

            if AgentWorkspaceShellApp._status_provider_accepts_args(provider):
                provider_with_args = cast(Callable[[list[str]], list[str]], provider)
                return list(provider_with_args(AgentWorkspaceShellApp._status_command_args(command_text)))

            provider_no_args = cast(Callable[[], list[str]], provider)
            return list(provider_no_args())

        @staticmethod
        def _status_provider_accepts_args(provider: StatusSummaryProvider) -> bool:
            """Return True when provider signature accepts one or more parameters."""
            try:
                return bool(inspect.signature(provider).parameters)
            except (TypeError, ValueError):
                return False

        @staticmethod
        def _status_command_args(command_text: str) -> list[str]:
            """Parse slash command text and return only argument tokens."""
            try:
                tokens = shlex.split(command_text)
            except ValueError:
                return []

            if len(tokens) <= 1:
                return []
            return list(tokens[1:])

        def _append_transcript_line(self, line: str) -> None:
            """Append one line and refresh transcript widget/state classes."""
            self._transcript_lines.append(line)
            if len(self._transcript_lines) > TRANSCRIPT_MAX_LINES:
                self._transcript_lines = self._transcript_lines[-TRANSCRIPT_MAX_LINES:]
            transcript_sink = self._transcript_sink
            if callable(transcript_sink):
                transcript_sink(list(self._transcript_lines))

            messages = self.query_one(f"#{TRANSCRIPT_ID}", Static)
            messages.update(_format_transcript(self._transcript_lines))
            messages.add_class("-has-turns")
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            transcript_scroll.add_class("-has-turns")
            scroll_end = getattr(transcript_scroll, "scroll_end", None)
            if callable(scroll_end):
                scroll_end(animate=False)

            chat = self.query_one("#chat-column", Vertical)
            chat.add_class("-has-turns")

            wrapper = self.query_one("#center-wrapper", Container)
            wrapper.add_class("-has-turns")

            title_nodes = list(self.query("#title"))
            for node in title_nodes:
                node.remove()

            self._refresh_chrome_visibility()

        def _refresh_transcript_widget(self) -> None:
            """Refresh transcript rendering and keep focus on the latest entries."""
            try:
                messages = self.query_one(f"#{TRANSCRIPT_ID}", Static)
            except Exception:
                return
            messages.update(_format_transcript(self._transcript_lines))
            if self._transcript_lines:
                messages.add_class("-has-turns")
            else:
                messages.remove_class("-has-turns")
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            if self._transcript_lines:
                transcript_scroll.add_class("-has-turns")
            else:
                transcript_scroll.remove_class("-has-turns")
            scroll_end = getattr(transcript_scroll, "scroll_end", None)
            if callable(scroll_end):
                scroll_end(animate=False)

        def _transcript_overflows_viewport(self) -> bool:
            """Return True when transcript lines likely exceed visible viewport."""
            if not self._transcript_lines:
                return False

            try:
                transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
                region_height = int(getattr(transcript_scroll.region, "height", 0) or 0)
                virtual_height = int(getattr(getattr(transcript_scroll, "virtual_size", None), "height", 0) or 0)
                if region_height <= 2 or virtual_height <= 0:
                    return len(self._transcript_lines) > 12
                return virtual_height > region_height
            except Exception:
                return len(self._transcript_lines) > 12

        def _refresh_chrome_visibility(self) -> None:
            """Show tip/keybar only when contextually useful."""
            has_turns = bool(self._transcript_lines)
            tip = self.query_one("#tip", Static)
            if has_turns:
                tip.add_class("-hidden")
            else:
                tip.remove_class("-hidden")

            context_name = self.query_one(f"#{AGENT_CONTEXT_NAME_ID}", Static)
            context_account = self.query_one(f"#{AGENT_CONTEXT_ACCOUNT_ID}", Static)
            if self._sidebar_visible:
                context_name.add_class("-hidden")
                context_account.add_class("-hidden")
            else:
                context_name.remove_class("-hidden")
                context_account.remove_class("-hidden")

            keybar_row = self.query_one(f"#{KEYBAR_ROW_ID}", Container)
            keybar_left = self.query_one(f"#{KEYBAR_LEFT_ID}", Static)
            keybar_right = self.query_one(f"#{KEYBAR_RIGHT_ID}", Static)
            overflow = self._transcript_overflows_viewport()
            keybar_row.remove_class("-hidden")
            keybar_left.update(self._keybar_left_text())

            if overflow:
                keybar_right.update("[#c4cede]pgup/pgdn scroll[/]")
            else:
                keybar_right.update("")

            if self._is_slash_open():
                self._position_slash_menu()

        def _append_command_entry(self, command_text: str) -> None:
            """Append a command line with spacing separation from prior entries."""
            if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                self._append_transcript_line("")
            self._append_transcript_line(f"Cmd: {command_text}")

        def _next_run_index(self) -> int:
            """Return the next user-run index based on transcript history."""
            run_count = sum(1 for line in self._transcript_lines if str(line).startswith("You:"))
            return run_count + 1

        def _append_user_entry(self, message_text: str) -> None:
            """Append a user message line with spacing separation from prior entries."""
            if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                self._append_transcript_line("")
            self._append_transcript_line(f"{_RUN_DIVIDER_SENTINEL}Run {self._next_run_index()}")
            self._append_transcript_line(f"You: {message_text}")

        def _finalize_inline_status(self) -> None:
            """Restore workspace controls after inline /status completes."""
            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            stop = getattr(loading, "stop", None)
            if callable(stop):
                stop()
            loading.remove_class("-active")
            loading.add_class("-hidden")

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

            self._inline_status_running = False
            self._refresh_chrome_visibility()
            self._schedule_followup_capture()

        def _schedule_followup_capture(self) -> None:
            """Re-capture screenshots after transcript updates when capture env is set."""
            self._schedule_screenshot_capture(allow_repeat=True)

        def on_key(self, event: Key) -> None:
            """Handle slash-menu navigation and shell-style composer history recall."""
            if self._is_slash_open():
                if event.key == "up" and self._slash_filtered:
                    self._slash_selected_index = (self._slash_selected_index - 1) % len(self._slash_filtered)
                    self._refresh_slash_rows()
                    event.stop()
                    return

                if event.key == "down" and self._slash_filtered:
                    self._slash_selected_index = (self._slash_selected_index + 1) % len(self._slash_filtered)
                    self._refresh_slash_rows()
                    event.stop()
                return

            if event.key in {"up", "down"} and self._composer_has_focus():
                if self._navigate_composer_history(event.key):
                    event.stop()

        def on_input_submitted(self, event: Input.Submitted) -> None:
            """Submit workspace composer when Enter is pressed inside the input."""
            if event.input.id != COMPOSER_ID:
                return
            event.stop()
            self.action_submit_composer()

        def on_input_changed(self, event: Input.Changed) -> None:
            """Refresh slash suggestions as the composer value changes."""
            if event.input.id != COMPOSER_ID:
                return
            self._refresh_slash_menu(event.value)

        def on_button_pressed(self, event: Button.Pressed) -> None:
            """Handle sidebar button presses."""
            if event.button.id == "view-details-btn":
                self._trigger_details_command()

        def _trigger_details_command(self) -> None:
            """Trigger the details command via the inline provider."""
            if self._details_provider is not None and callable(self._details_provider):
                self._run_inline_details(_DETAILS_COMMAND)
            else:
                # Fallback: set the composer text and submit
                composer = self.query_one(f"#{COMPOSER_ID}", Input)
                composer.value = _DETAILS_COMMAND
                self.action_submit_composer()

        def action_noop(self) -> None:
            """No-op action used to shadow disabled shortcuts."""

        def action_command_palette(self) -> None:
            """Disable Textual built-in command palette in this shell."""

        def action_transcript_hint(self) -> None:
            """Show transcript shortcut hint in the chat help area."""
            tip = self.query_one("#tip", Static)
            tip.update("Transcript viewer is unavailable in workspace mode.")
            tip.remove_class("-hidden")

        def action_copy_last_details(self) -> None:
            """Copy the last details output to clipboard."""
            if self._last_details_lines:
                # Remove sentinel markers and join lines
                clean_lines = []
                for line in self._last_details_lines:
                    clean = line.replace("\u0000DETAILS\u0000", "").strip()
                    if clean:
                        clean_lines.append(clean)
                text = "\n".join(clean_lines)
                self._copy_to_clipboard(text, label="Agent details")
            else:
                # Show hint that no details are available
                tip = self.query_one("#tip", Static)
                tip.update(f"Run {_DETAILS_COMMAND} first to copy agent configuration.")
                tip.remove_class("-hidden")


def run_agent_workspace_shell(
    *,
    details: AgentWorkspaceDetails,
    transcript_lines: list[str] | None,
    composer_placeholder: str,
    status_summary_provider: StatusSummaryProvider | None = None,
    details_provider: DetailsProvider | None = None,
    transcript_sink: TranscriptSink | None = None,
    message_run_provider: MessageRunProvider | None = None,
) -> AgentWorkspaceEvent | None:
    """Run workspace shell and return selected event.

    Returns None when Textual support is unavailable.
    """
    if not TEXTUAL_SUPPORTED:  # pragma: no cover - optional dependency
        return None

    app = AgentWorkspaceShellApp(
        details=details,
        transcript_lines=transcript_lines,
        composer_placeholder=composer_placeholder,
        status_summary_provider=status_summary_provider,
        details_provider=details_provider,
        transcript_sink=transcript_sink,
        message_run_provider=message_run_provider,
    )
    return app.run()
