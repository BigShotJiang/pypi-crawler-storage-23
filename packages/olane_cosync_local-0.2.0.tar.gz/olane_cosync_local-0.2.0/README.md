<!-- mcp-name: com.olane/cosync-local -->

# olane-cosync-local

**CoSync Local** — local encryption MCP plugin for [CoSync / Twin Brain](https://olane.io). Runs on the user's machine via stdio transport — **keys never leave the local environment**.

Part of the **Olane** MCP suite (`com.olane/*`):
- **`com.olane/cosync-local`** (this package) — Local encryption and session token generation
- **`com.olane/cosync-remote`** — Knowledge graph ontology and context retrieval

## Tools

| Tool | Description |
|------|-------------|
| `generate_session_token` | Wrap DEK with access-token-derived key to produce an opaque session token |
| `encrypt_payload` | AES-256-GCM encrypt a text payload |
| `encrypt_file` | AES-256-GCM encrypt a file's contents |

## Installation

From PyPI:

```bash
pip install olane-cosync-local
```

From source (monorepo):

```bash
pip install -e packages/olane-cosync-local
```

## Configuration

### Claude Desktop / Claude Code

Add to your MCP settings:

```json
{
  "mcpServers": {
    "cosync-local": {
      "command": "olane-cosync-local",
      "transport": "stdio"
    }
  }
}
```

### VS Code (Copilot MCP)

Add to `.vscode/mcp.json`:

```json
{
  "servers": {
    "cosync-local": {
      "command": "olane-cosync-local",
      "transport": "stdio"
    }
  }
}
```

## Usage

The CoSync Ontology MCP (remote) orchestrates calls to this local plugin:

1. **`generate_session_token`** — Called at session start with `master_key` and `access_token`. Returns an opaque session token.
2. **`encrypt_payload`** / **`encrypt_file`** — Called before each API request to encrypt data with AES-256-GCM.
3. The session token and encrypted payloads are forwarded to the Twin-Brain API.

## Development

```bash
# Install in editable mode
pip install -e packages/olane-cosync-local

# Run tests
cd packages/olane-cosync-local && pytest tests/ -v

# Run monorepo tests (re-export wrappers + drift guard)
pytest tests/test_mcp/test_crypto_plugin.py tests/test_api/test_session_token.py -v

# Run the server directly (waits for JSON-RPC on stdin)
python -m olane_cosync_local
```

## Publishing to MCP Registry

The package is published to **PyPI** and the **MCP Registry** (`com.olane/cosync-local`) via GitHub Actions on tag push.

### First-time setup (one-time, per namespace)

These steps claim the `com.olane/*` namespace. Only needed once — all future `com.olane/*` servers reuse the same credentials.

1. **Generate an Ed25519 signing keypair:**

   ```bash
   mkdir -p .olane/mcp-registry
   openssl genpkey -algorithm Ed25519 -out .olane/mcp-registry/key.pem
   ```

   > The key file is gitignored (`.olane/mcp-registry/`). Store a backup securely.

2. **Extract the public key for DNS:**

   ```bash
   echo "olane.com. IN TXT \"v=MCPv1; k=ed25519; p=$(openssl pkey -in .olane/mcp-registry/key.pem -pubout -outform DER | tail -c 32 | base64)\""
   ```

3. **Add a DNS TXT record** at your DNS provider:

   | Type | Host | Value |
   |------|------|-------|
   | TXT | `@` (or `olane.com`) | `v=MCPv1; k=ed25519; p=<base64 public key>` |

4. **Wait for DNS propagation** (usually 1–5 minutes), then verify:

   ```bash
   dig TXT olane.com +short
   ```

5. **Authenticate with the MCP Registry:**

   ```bash
   PRIVATE_KEY_HEX=$(openssl pkey -in .olane/mcp-registry/key.pem -outform DER | tail -c 32 | xxd -p -c 64)
   mcp-publisher login dns --domain=olane.com --private-key=$PRIVATE_KEY_HEX
   ```

6. **Publish:**

   ```bash
   cd packages/olane-cosync-local
   mcp-publisher publish
   ```

7. **Configure PyPI trusted publishing** on [pypi.org](https://pypi.org):
   - Create `olane-cosync-local` project
   - Add trusted publisher: repo `olane-labs/o-twin-data-pipeline`, workflow `publish-cosync-local.yml`

### Releasing a new version

1. Bump version in `pyproject.toml` and `src/olane_cosync_local/__init__.py`
2. Tag and push:

   ```bash
   git tag cosync-local-v0.2.0
   git push origin cosync-local-v0.2.0
   ```

3. GitHub Actions handles the rest:
   - Runs standalone tests
   - Publishes to PyPI (OIDC trusted publishing)
   - Updates the MCP Registry with the new version

### Publishing a new `com.olane/*` server

The DNS verification is namespace-wide. To add another server (e.g. `com.olane/cosync-remote`):

1. Create a new package under `packages/` with its own `server.json`
2. Set `"name": "com.olane/cosync-remote"` in `server.json`
3. Authenticate (reuse existing key):

   ```bash
   PRIVATE_KEY_HEX=$(openssl pkey -in .olane/mcp-registry/key.pem -outform DER | tail -c 32 | xxd -p -c 64)
   mcp-publisher login dns --domain=olane.com --private-key=$PRIVATE_KEY_HEX
   ```

4. Publish: `cd packages/olane-cosync-ontology && mcp-publisher publish`

## License

MIT
