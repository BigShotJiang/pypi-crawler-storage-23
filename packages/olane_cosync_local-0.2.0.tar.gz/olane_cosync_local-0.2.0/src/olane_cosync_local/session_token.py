"""
Client-side session token creation.

Wraps the DEK (derived from cosync_encryption_key) with a key derived from the
Supabase access token, producing an opaque base64 session token.

Token format: base64(iv[12] + encrypted_dek[32] + tag[16])

The backend API unwraps this using the same access token from the
Authorization header.
"""

import base64
import os

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from olane_cosync_local.constants import (
    WRAP_HKDF_SALT,
    WRAP_HKDF_INFO,
    DEK_HKDF_SALT,
    DEK_HKDF_INFO,
)


def _derive_wrap_key(access_token: str) -> bytes:
    """
    Derive a 256-bit wrap key from a Supabase access token using HKDF-SHA256.

    Uses the same HKDF parameters as the backend unwrapper to ensure
    symmetric key derivation.
    """
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=WRAP_HKDF_SALT,
        info=WRAP_HKDF_INFO,
    )
    return hkdf.derive(access_token.encode("utf-8"))


def _derive_dek(cosync_encryption_key: str) -> bytes:
    """
    Derive the DEK from a master key using HKDF-SHA256.

    Uses the same parameters as olane_crypto.py to ensure the same DEK.
    """
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=DEK_HKDF_SALT,
        info=DEK_HKDF_INFO,
    )
    return hkdf.derive(cosync_encryption_key.encode("utf-8"))


def create_session_token(cosync_encryption_key: str, access_token: str) -> str:
    """
    Create an opaque session token by wrapping the DEK with the access token.

    Steps:
    1. Derive DEK from cosync_encryption_key (same as olane_crypto.derive_dek)
    2. Derive wrap_key from access_token (HKDF with shared constants)
    3. AES-256-GCM encrypt DEK with wrap_key
    4. Return base64(iv + encrypted_dek + tag)
    """
    dek = _derive_dek(cosync_encryption_key)
    wrap_key = _derive_wrap_key(access_token)

    aesgcm = AESGCM(wrap_key)
    iv = os.urandom(12)
    ciphertext_with_tag = aesgcm.encrypt(iv, dek, None)
    encrypted_dek = ciphertext_with_tag[:32]
    tag = ciphertext_with_tag[32:]

    # Token format: iv (12) + encrypted_dek (32) + tag (16) = 60 bytes
    token_bytes = iv + encrypted_dek + tag
    return base64.b64encode(token_bytes).decode("ascii")
