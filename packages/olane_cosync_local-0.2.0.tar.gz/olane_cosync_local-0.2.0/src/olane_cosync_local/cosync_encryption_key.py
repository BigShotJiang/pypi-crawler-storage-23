"""Master key management for CoSync Security.

Provides check, generate, and set operations for the COSYNC_ENCRYPTION_KEY
stored in .olane/config.json or the environment.
"""

import json
import logging
import os
import uuid
from pathlib import Path

logger = logging.getLogger(__name__)

CONFIG_REL_PATH = ".olane/config.json"


def _resolve_config_path(project_path: str) -> Path:
    """Resolve the .olane/config.json path relative to project_path."""
    return Path(project_path) / CONFIG_REL_PATH


def _read_config(config_path: Path) -> dict:
    """Read and parse .olane/config.json, returning {} if missing or invalid."""
    if not config_path.exists():
        return {}
    try:
        return json.loads(config_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to read {config_path}: {e}")
        return {}


def _write_config(config_path: Path, config: dict) -> None:
    """Write config dict to .olane/config.json, creating parent dirs if needed."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")


def check_cosync_encryption_key(project_path: str) -> dict:
    """Check whether a master key is configured.

    Resolution order:
    1. COSYNC_ENCRYPTION_KEY environment variable
    2. .olane/config.json "cosync_encryption_key" field

    Returns:
        Dict with exists (bool) and source ("environment", "config", or None).
    """
    env_key = os.environ.get("COSYNC_ENCRYPTION_KEY", "")
    if env_key:
        return {"exists": True, "source": "environment"}

    config_path = _resolve_config_path(project_path)
    config = _read_config(config_path)
    if config.get("cosync_encryption_key"):
        return {"exists": True, "source": "config"}

    return {"exists": False, "source": None}


def generate_cosync_encryption_key(project_path: str) -> dict:
    """Generate a new UUID4 master key and write it to .olane/config.json.

    Will NOT overwrite an existing cosync_encryption_key in config or environment.

    Returns:
        Dict with cosync_encryption_key (the generated key) and source ("config").

    Raises:
        ValueError: If a master key already exists.
    """
    status = check_cosync_encryption_key(project_path)
    if status["exists"]:
        raise ValueError(
            f"Master key already exists (source: {status['source']}). "
            "Use set_cosync_encryption_key to replace it, or remove the existing key first."
        )

    key = str(uuid.uuid4())
    config_path = _resolve_config_path(project_path)
    config = _read_config(config_path)
    config["cosync_encryption_key"] = key
    _write_config(config_path, config)

    logger.info(f"Generated new master key and wrote to {config_path}")
    return {"cosync_encryption_key": key, "source": "config"}


def ensure_cosync_encryption_key(project_path: str) -> dict:
    """Ensure a master key exists, auto-generating one if needed.

    Resolution order:
    1. COSYNC_ENCRYPTION_KEY environment variable
    2. .olane/config.json "cosync_encryption_key" field
    3. Auto-generate UUID4 and write to config

    Returns:
        Dict with cosync_encryption_key (str), source ("environment" or "config"),
        and generated (bool).
    """
    env_key = os.environ.get("COSYNC_ENCRYPTION_KEY", "")
    if env_key:
        return {"cosync_encryption_key": env_key, "source": "environment", "generated": False}

    config_path = _resolve_config_path(project_path)
    config = _read_config(config_path)
    existing = config.get("cosync_encryption_key", "")
    if existing:
        return {"cosync_encryption_key": existing, "source": "config", "generated": False}

    # Auto-generate
    key = str(uuid.uuid4())
    config["cosync_encryption_key"] = key
    _write_config(config_path, config)
    logger.info(f"Auto-generated master key and wrote to {config_path}")
    return {"cosync_encryption_key": key, "source": "config", "generated": True}


def set_cosync_encryption_key(project_path: str, cosync_encryption_key: str) -> dict:
    """Write a user-provided master key to .olane/config.json.

    Overwrites any existing cosync_encryption_key in the config file.

    Args:
        project_path: Absolute path to the project root.
        cosync_encryption_key: The master key string to store.

    Returns:
        Dict with success (bool) and source ("config").
    """
    if not cosync_encryption_key or not cosync_encryption_key.strip():
        raise ValueError("cosync_encryption_key must be a non-empty string.")

    config_path = _resolve_config_path(project_path)
    config = _read_config(config_path)
    config["cosync_encryption_key"] = cosync_encryption_key.strip()
    _write_config(config_path, config)

    logger.info(f"Master key written to {config_path}")
    return {"success": True, "source": "config"}
