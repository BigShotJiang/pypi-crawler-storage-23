"""
olane-cosync-local -- Local encryption and setup MCP plugin for CoSync / Twin Brain.

Provides session token generation, AES-256-GCM encryption, project setup,
and master key management tools that run on the user's machine via stdio transport.
"""

__version__ = "0.2.0"

from olane_cosync_local.session_token import create_session_token, _derive_dek
from olane_cosync_local.encryption import _encrypt_aes_gcm
from olane_cosync_local.cosync_encryption_key import check_cosync_encryption_key, generate_cosync_encryption_key, set_cosync_encryption_key, ensure_cosync_encryption_key
from olane_cosync_local.setup import write_setup_files

__all__ = [
    "create_session_token",
    "_derive_dek",
    "_encrypt_aes_gcm",
    "check_cosync_encryption_key",
    "generate_cosync_encryption_key",
    "set_cosync_encryption_key",
    "ensure_cosync_encryption_key",
    "write_setup_files",
    "__version__",
]
