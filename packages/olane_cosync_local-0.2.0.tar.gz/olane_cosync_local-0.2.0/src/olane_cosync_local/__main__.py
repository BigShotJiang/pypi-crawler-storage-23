"""Allow running as `python -m olane_cosync_local`."""

from olane_cosync_local.server import main

main()
