"""Per-project configuration schema for CoSync setup.

Vendored from olane-cosync's config_project.py. Contains only the
generation parts (Pydantic models + generate_default_config_json).
Runtime loading (load_project_config) stays in olane-cosync.
"""

import json
from typing import List

from pydantic import BaseModel, Field, model_validator


class CosyncModelRouting(BaseModel):
    """Model routing by confidence tier."""

    high_confidence: str = "opus"
    medium_confidence: str = "opus"
    low_confidence: str = "opus"


class CosyncConfig(BaseModel):
    """CoSync score thresholds and model routing.

    Thresholds must be in descending order: silent > ask > block.
    """

    silent_threshold: float = Field(default=0.85, ge=0.0, le=1.0)
    ask_threshold: float = Field(default=0.60, ge=0.0, le=1.0)
    block_threshold: float = Field(default=0.30, ge=0.0, le=1.0)
    model_routing: CosyncModelRouting = Field(default_factory=CosyncModelRouting)

    @model_validator(mode="after")
    def thresholds_descending(self) -> "CosyncConfig":
        if not (self.silent_threshold > self.ask_threshold > self.block_threshold):
            raise ValueError(
                f"Thresholds must be strictly descending: "
                f"silent ({self.silent_threshold}) > ask ({self.ask_threshold}) > block ({self.block_threshold})"
            )
        return self


class IndexingConfig(BaseModel):
    """Project indexing settings."""

    auto_incremental: bool = True
    full_reindex_schedule: str = "weekly"
    max_file_size_kb: int = 100
    excluded_patterns: List[str] = Field(
        default_factory=lambda: [
            "node_modules",
            ".git",
            "__pycache__",
            "dist",
            "build",
        ]
    )


class HooksConfig(BaseModel):
    """Hook execution settings."""

    enabled: bool = True
    observation_mode: str = "async"
    local_fallback: bool = True


class ProjectConfig(BaseModel):
    """Top-level per-project configuration."""

    version: str = "1.0"
    cosync: CosyncConfig = Field(default_factory=CosyncConfig)
    indexing: IndexingConfig = Field(default_factory=IndexingConfig)
    hooks: HooksConfig = Field(default_factory=HooksConfig)


def generate_default_config_json(indent: int = 2) -> str:
    """Generate template JSON from model defaults.

    Always in sync with the Pydantic schema -- no separate template file.
    """
    return ProjectConfig().model_dump_json(indent=indent)
