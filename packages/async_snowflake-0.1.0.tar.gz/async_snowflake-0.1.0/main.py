def main():
    print("Hello from async-snowflake-connector-python!")


if __name__ == "__main__":
    main()
