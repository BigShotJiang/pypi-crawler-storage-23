# Async Snowflake Connector for Python

An async Python connector for Snowflake using JWT authentication.

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

### Credentials File

Create a `credentials.toml` file (do not commit to version control):

```toml
[default]
account = "YOUR_ACCOUNT"
user = "YOUR_USER"
private_key_path = "/path/to/private_key.pem"
region = "us-east-1"

# Multiple profiles supported
[production]
account = "PROD_ACCOUNT"
user = "admin"
private_key_path = "/path/to/prod_key.pem"
```

### Environment Variables

Alternatively, use environment variables:

```bash
export SNOWFLAKE_ACCOUNT="your_account"
export SNOWFLAKE_USER="your_user"
export SNOWFLAKE_PRIVATE_KEY_PATH="/path/to/key.pem"
export SNOWFLAKE_REGION="us-east-1"
```

## Usage

```python
from endpoints import SnowflakeClient
from authentication import SnowflakeJWTAuthClient
from authentication.credentials import CredentialsManager

# Option 1: Using credentials manager
credentials = CredentialsManager(profile="default").credentials

auth = SnowflakeJWTAuthClient(
    account=credentials.account,
    user=credentials.user,
    private_key_path=credentials.private_key_path,
)

client = await SnowflakeClient.create(
    base_url=credentials.base_url,
    auth_client=auth,
)

# Execute query
result = await client.query.execute("SELECT * FROM table")
print(result.data)

await client.close()

# Option 2: Using context manager
async with SnowflakeClient.create(base_url, auth) as client:
    result = await client.query.execute("SELECT 1")
```

## Fluent Interface

```python
# Account operations
await client.account.get_current_account()

# Database operations
await client.database.list()
await client.database.create("new_db")
await client.database.describe("my_db")

# Warehouse operations
await client.warehouse.list()
await client.warehouse.resume("warehouse_name")

# Query execution
result = await client.query.execute("SELECT * FROM table")
```

## Testing

```bash
# Run all tests
uv run pytest tests/ -v

# Run only unit tests
uv run pytest tests/unit/ -v

# Run only integration tests
uv run pytest tests/integration/ -v
```
