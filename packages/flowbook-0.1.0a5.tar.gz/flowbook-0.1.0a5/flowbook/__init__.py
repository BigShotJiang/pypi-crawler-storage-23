"""
Flowbook: plan runner and artifact store.

Public API (a1 minimum): Engine, Registry, RunSession, register_steps, discover_steps, and stores.
Use ``from flowbook import Engine, Registry, discover_steps, register_steps, ...``.
Everything else: ``flowbook.core.*``.
"""

from __future__ import annotations

from flowbook.core.artifacts.index import ArtifactIndex, IndexRow
from flowbook.core.artifacts.memory_index import InMemoryArtifactIndex
from flowbook.core.artifacts.memory_store import InMemoryArtifactsStore
from flowbook.core.artifacts.store import ArtifactsStore
from flowbook.core.configs.memory_store import InMemoryConfigStore
from flowbook.core.configs.null_store import NullConfigStore
from flowbook.core.engine.engine import Engine
from flowbook.core.engine.session import RunSession
from flowbook.core.registry.extensions import discover_steps, register_steps
from flowbook.core.registry.registry import Registry, UnknownOp
from flowbook.core.registry.step_decorator import register_from_steps, step
from flowbook.core.runtime.default_store import DefaultRunStore


def _version() -> str:
    try:
        import importlib.metadata as _metadata
    except ImportError:
        return "0.0.0"
    try:
        return _metadata.version("flowbook")
    except _metadata.PackageNotFoundError:
        return "0.0.0"


__version__ = _version()

__all__ = [
    "ArtifactIndex",
    "ArtifactsStore",
    "DefaultRunStore",
    "discover_steps",
    "Engine",
    "IndexRow",
    "InMemoryArtifactIndex",
    "InMemoryArtifactsStore",
    "InMemoryConfigStore",
    "NullConfigStore",
    "Registry",
    "RunSession",
    "UnknownOp",
    "register_from_steps",
    "register_steps",
    "step",
    "__version__",
]
