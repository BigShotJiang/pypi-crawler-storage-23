"""Bundled SQL schema for first-time DB setup."""
