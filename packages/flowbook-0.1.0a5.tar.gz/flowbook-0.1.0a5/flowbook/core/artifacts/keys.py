INSPECT_RESULT = "artifact:control/inspect_result"
READ_SPEC = "artifact:control/read_spec"
SOURCE_URI = "artifact:input/source_uri"
PLAN = "artifact:control/plan"
