# Extensions: excel, postgres, fastapi. Import only when needed to keep core light.
