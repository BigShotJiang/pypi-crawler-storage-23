"""CLI extensions for flowbook: db, hands-on, fixture, streamlit, artifacts (when flowbook[dev])."""
