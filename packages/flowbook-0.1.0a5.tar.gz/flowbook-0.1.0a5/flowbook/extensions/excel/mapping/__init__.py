from flowbook.extensions.excel.mapping.apply import apply_mapping_ops

__all__ = ["apply_mapping_ops"]
