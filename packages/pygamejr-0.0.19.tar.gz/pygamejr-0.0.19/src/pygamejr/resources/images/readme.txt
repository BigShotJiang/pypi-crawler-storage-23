These assets are a subset of what is available from Kenney.nl.
https://kenney.nl/