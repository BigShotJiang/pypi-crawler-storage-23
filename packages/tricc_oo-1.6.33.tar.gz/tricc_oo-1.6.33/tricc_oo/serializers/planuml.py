# we should not use the logger
import logging

plantuml = logging.getLogger("plantuml")


def print_plantuml(start_page):

    pass
