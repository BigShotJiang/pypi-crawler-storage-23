# 1.3
- Added new robot type: RtPureForwardOnlyV2
- Added HexCanApixxx messages for CAN forwarding.
