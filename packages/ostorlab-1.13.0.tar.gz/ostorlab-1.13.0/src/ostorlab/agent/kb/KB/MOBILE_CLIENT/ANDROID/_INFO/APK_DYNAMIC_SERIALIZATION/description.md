List of all Serialization methods used in the application.
