List of components potentially accepting user input:

* `service`: Service.
* `activity`: Activity.
* `receiver`: Broadcast Receiver
* `provider`: Content Provider