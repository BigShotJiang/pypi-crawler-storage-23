"""Training framework for BYOM models.

Provides a SageMaker Estimator-inspired Trainer hierarchy that unifies
the training lifecycle across all BYOM repositories, with first-class
ActionTracker integration.

Quick reference::

    from matrice_models.training import (
        Trainer,
        LoopTrainer,
        DelegatedTrainer,  # base classes
        TrainResult,
        TrainerError,  # data / exceptions
        TrainerCallback,  # callback base
        ActionTrackerCallback,  # built-in callbacks
        EarlyStoppingCallback,
        CheckpointCallback,
        EarlyStopping,  # standalone utilities
        AverageMeter,
        accuracy,
        sanitise_metrics,
        save_checkpoint,
        load_checkpoint,
        resolve_device,
        move_to_device,
    )
"""

from __future__ import annotations

from matrice_models.training.callbacks import (
    ActionTrackerCallback,
    CheckpointCallback,
    EarlyStoppingCallback,
    TrainerCallback,
    run_callbacks,
)
from matrice_models.training.checkpoint import load_checkpoint, save_checkpoint
from matrice_models.training.delegated_trainer import DelegatedTrainer
from matrice_models.training.device import move_to_device, resolve_device
from matrice_models.training.early_stopping import EarlyStopping
from matrice_models.training.loop_trainer import LoopTrainer
from matrice_models.training.model_loader import ModelLoadStrategies, load_model_with_strategies
from matrice_models.training.trainer import Trainer, TrainerError, TrainResult
from matrice_models.training.utils import AverageMeter, accuracy, sanitise_metrics


__all__ = [
    "ActionTrackerCallback",
    "AverageMeter",
    "CheckpointCallback",
    "DelegatedTrainer",
    "EarlyStopping",
    "EarlyStoppingCallback",
    "LoopTrainer",
    "TrainResult",
    "Trainer",
    "TrainerCallback",
    "TrainerError",
    "accuracy",
    "load_checkpoint",
    "load_model_with_strategies",
    "move_to_device",
    "resolve_device",
    "run_callbacks",
    "sanitise_metrics",
    "save_checkpoint",
    "ModelLoadStrategies",
]
