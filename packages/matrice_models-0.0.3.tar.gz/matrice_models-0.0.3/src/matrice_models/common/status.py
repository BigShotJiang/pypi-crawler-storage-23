"""Shared best-effort ActionTracker status/error helpers."""

from __future__ import annotations

from contextlib import suppress
from typing import Any


def safe_update_status(action_tracker: Any, step_code: str, status: str, description: str) -> None:
    """Submit status updates without propagating tracker exceptions.

    Args:
        action_tracker: Tracker-like object implementing ``update_status``.
        step_code: Lifecycle step identifier.
        status: Status level string such as ``OK`` or ``ERROR``.
        description: Human-readable status description.

    Returns:
        None.
    """
    with suppress(Exception):
        if hasattr(action_tracker, "update_status"):
            action_tracker.update_status(step_code, status, description)


def safe_log_error(action_tracker: Any, file_path: str, location: str, message: str) -> None:
    """Log an error entry without propagating tracker exceptions.

    Args:
        action_tracker: Tracker-like object implementing ``log_error``.
        file_path: Source file associated with the error event.
        location: Logical module or location string.
        message: Error detail to persist in tracking backend.

    Returns:
        None.
    """
    with suppress(Exception):
        if hasattr(action_tracker, "log_error"):
            action_tracker.log_error(file_path, location, message)
