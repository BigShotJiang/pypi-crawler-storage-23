"""Shared cross-package utilities for training, eval, predict, and deploy."""

from .device import (
    move_to_device,
    prepare_torch_model_for_inference,
    resolve_device,
    resolve_torch_device,
)
from .model_loading import (
    ModelLoaderCallable,
    ModelLoaderRegistry,
    ModelLoadStrategies,
    load_model_with_runtime,
    load_model_with_strategies,
)
from .splits import build_split_loader_map, evaluate_available_splits
from .status import safe_log_error, safe_update_status

__all__ = [
    "ModelLoaderCallable",
    "ModelLoaderRegistry",
    "ModelLoadStrategies",
    "build_split_loader_map",
    "evaluate_available_splits",
    "load_model_with_runtime",
    "load_model_with_strategies",
    "move_to_device",
    "prepare_torch_model_for_inference",
    "resolve_device",
    "resolve_torch_device",
    "safe_log_error",
    "safe_update_status",
]
