"""Typed prediction output schemas shared across BYOM runtimes."""

from __future__ import annotations

from typing import NotRequired, TypedDict


class BoundingBox(TypedDict):
    """Axis-aligned bounding box in absolute pixel coordinates."""

    xmin: int
    ymin: int
    xmax: int
    ymax: int


class ClassificationPrediction(TypedDict):
    """Single-label classification prediction."""

    category: str
    confidence: float


class DetectionPrediction(TypedDict):
    """Object detection prediction record."""

    category: str
    confidence: float
    bounding_box: BoundingBox
    track_id: NotRequired[int]


class ActionPrediction(TypedDict):
    """Per-frame action prediction for video recognition."""

    category: str
    confidence: float
    timestamp: str | float
    fps: int


FramewiseActionPredictions = dict[str, list[ActionPrediction]]
