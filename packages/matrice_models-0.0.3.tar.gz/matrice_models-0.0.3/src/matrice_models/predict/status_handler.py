"""Shared ActionTracker status helpers for prediction flows."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from matrice_models.common.status import safe_log_error as common_safe_log_error
from matrice_models.common.status import safe_update_status as common_safe_update_status


def safe_update_status(action_tracker: Any, step_code: str, status: str, description: str) -> None:
    """Submit status updates without propagating tracker exceptions.

    Args:
        action_tracker: Tracker-like object implementing ``update_status``.
        step_code: Prediction lifecycle step identifier.
        status: Status level such as ``OK`` or ``ERROR``.
        description: Human-readable status description.

    Returns:
        None.
    """
    common_safe_update_status(action_tracker, step_code, status, description)


def safe_log_error(action_tracker: Any, file_path: str, location: str, message: str) -> None:
    """Log prediction errors without propagating tracker exceptions.

    Args:
        action_tracker: Tracker-like object implementing ``log_error``.
        file_path: Source file associated with the error.
        location: Logical module or location string.
        message: Error details to persist.

    Returns:
        None.
    """
    common_safe_log_error(action_tracker, file_path, location, message)


@dataclass(frozen=True)
class PredictionStatusCodes:
    """Canonical prediction-related status step codes."""

    LOAD_ERROR: str = "MDL_PRED_ERR"
    PREDICT_ERROR: str = "MDL_PREDICT_ERR"


class PredictionStatusReporter:
    """Semantic status reporter for prediction error transitions."""

    def __init__(self, action_tracker: Any, codes: PredictionStatusCodes | None = None) -> None:
        """Create a reporter backed by an ActionTracker-like object.

        Args:
            action_tracker: Tracker-like object used for status updates.
            codes: Optional status code overrides.

        Returns:
            None.
        """
        self.action_tracker = action_tracker
        self.codes = codes or PredictionStatusCodes()

    def model_load_failed(self, msg: str = "Error in loading model") -> None:
        """Emit model-load failure status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.LOAD_ERROR, "ERROR", msg)

    def prediction_failed(self, msg: str = "Error during prediction") -> None:
        """Emit prediction failure status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.PREDICT_ERROR, "ERROR", msg)
