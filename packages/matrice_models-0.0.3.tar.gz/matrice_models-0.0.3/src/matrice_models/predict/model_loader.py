"""Shared model loading orchestration for predict pipelines."""

from __future__ import annotations

from typing import Any

from matrice_models.common.model_loading import ModelLoadStrategies, load_model_with_strategies
from matrice_models.common.status import safe_log_error, safe_update_status


def report_model_load_failure(
    action_tracker: Any,
    *,
    error: Exception,
    status_code: str,
    location: str,
    status_message: str,
    log_prefix: str,
) -> None:
    """Report model-load failure without raising secondary tracker exceptions.

    Args:
        action_tracker: Tracker-like object for status/error reporting.
        error: Original model-load exception.
        status_code: Status code used for tracker update.
        location: Logical location string used for error logging.
        status_message: Human-readable status message.
        log_prefix: Prefix used for tracker error message formatting.

    Returns:
        None.
    """
    safe_update_status(action_tracker, status_code, "ERROR", status_message)
    safe_log_error(action_tracker, __file__, location, f"{log_prefix}: {error!s}")
