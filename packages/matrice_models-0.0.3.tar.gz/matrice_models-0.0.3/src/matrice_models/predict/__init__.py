"""Shared prediction utilities for BYOM projects."""

from .io_utils import (
    download_remote_file,
    is_remote_path,
    prepare_torch_model_for_inference,
    resolve_torch_device,
    temporary_file_from_bytes,
)
from .model_loader import (
    ModelLoadStrategies,
    load_model_with_strategies,
    report_model_load_failure,
)
from .postprocessor import (
    classification_top1_from_raw_output,
    classification_top1_prediction,
    format_detection_from_normalized_tensors,
    framewise_action_results,
)
from .preprocessor import (
    ImagePreprocessConfig,
    get_model_device,
    load_rgb_image_from_bytes,
    preprocess_image_from_bytes,
    probe_video_fps,
)
from .status_handler import (
    PredictionStatusCodes,
    PredictionStatusReporter,
    safe_log_error,
    safe_update_status,
)
from .tensorrt_adapter import (
    TensorRTYOLOAdapterConfig,
    adapt_tensorrt_yolo_output,
)


__all__ = [
    "ImagePreprocessConfig",
    "ModelLoadStrategies",
    "PredictionStatusCodes",
    "PredictionStatusReporter",
    "TensorRTYOLOAdapterConfig",
    "adapt_tensorrt_yolo_output",
    "classification_top1_from_raw_output",
    "classification_top1_prediction",
    "download_remote_file",
    "format_detection_from_normalized_tensors",
    "framewise_action_results",
    "get_model_device",
    "is_remote_path",
    "load_model_with_strategies",
    "load_rgb_image_from_bytes",
    "prepare_torch_model_for_inference",
    "preprocess_image_from_bytes",
    "probe_video_fps",
    "report_model_load_failure",
    "resolve_torch_device",
    "safe_log_error",
    "safe_update_status",
    "temporary_file_from_bytes",
]
