"""matrice_models — shared library for Matrice BYOM model pipelines.

Provides configuration schemas, a Trainer hierarchy for training
orchestration, and common utilities used across all BYOM repositories.

Quick start::

    from matrice_models.config.base import ModelInfo, TrainConfig
    from matrice_models.training import LoopTrainer, DelegatedTrainer
"""

from __future__ import annotations
