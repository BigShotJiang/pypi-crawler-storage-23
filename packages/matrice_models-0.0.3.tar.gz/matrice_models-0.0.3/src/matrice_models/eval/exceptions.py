"""Custom exceptions for BYOM evaluation workflows."""

from __future__ import annotations


class EvaluationError(Exception):
    """Base class for evaluation-related failures."""


class RuntimeNotSupportedError(EvaluationError):
    """Raised when task/runtime mapping is not configured."""


class ModelLoadError(EvaluationError):
    """Raised when model artifact loading fails."""


class InferenceRunnerError(EvaluationError):
    """Raised when runner execution or output coercion fails."""


class PayloadFormatError(EvaluationError):
    """Raised when metric payload does not satisfy schema."""


class DatasetSplitError(EvaluationError):
    """Raised when expected dataset split directories/loaders are missing."""

