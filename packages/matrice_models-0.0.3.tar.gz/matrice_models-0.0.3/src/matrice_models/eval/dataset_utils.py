"""Dataset split helpers for BYOM evaluation."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matrice_models.common.splits import build_split_loader_map as common_build_split_loader_map


if TYPE_CHECKING:
    from collections.abc import Sequence


def build_split_loader_map(
    requested_splits: Sequence[str],
    train_loader: object | None,
    val_loader: object | None,
    test_loader: object | None,
) -> dict[str, object]:
    """Create split-to-loader map while skipping unavailable loaders.

    Args:
        requested_splits: Ordered split names requested by caller.
        train_loader: Optional loader for ``train`` split.
        val_loader: Optional loader for ``val`` split.
        test_loader: Optional loader for ``test`` split.

    Returns:
        Dictionary containing only requested splits that have non-``None`` loaders.
    """
    return common_build_split_loader_map(
        requested_splits=requested_splits,
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
    )
