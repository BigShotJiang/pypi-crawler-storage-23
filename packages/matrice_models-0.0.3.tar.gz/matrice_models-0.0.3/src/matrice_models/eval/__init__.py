"""Reusable evaluation utilities for BYOM repositories."""

from .classification_runtime_adapters import (
    get_onnx_inference_results as get_classification_onnx_inference_results,
    get_openvino_inference_results as get_classification_openvino_inference_results,
    get_pytorch_inference_results as get_classification_pytorch_inference_results,
    get_tensorrt_inference_results as get_classification_tensorrt_inference_results,
    load_classification_model,
)
from .common_classification import build_imagefolder_loaders
from .compat import ensure_metric_functions, make_legacy_split_evaluator
from .contracts import (
    ActionTrackerProtocol,
    InferenceRunnerProtocol,
    ModelLoaderProtocol,
    ResultFormatterProtocol,
    SplitEvaluatorProtocol,
)
from .dataset_utils import build_split_loader_map
from .eval_model_loader import ModelLoaderRegistry, load_model_with_runtime
from .evaluator import evaluate_available_splits
from .exceptions import (
    DatasetSplitError,
    EvaluationError,
    InferenceRunnerError,
    ModelLoadError,
    PayloadFormatError,
    RuntimeNotSupportedError,
)
from .inference_outputs import (
    ClassificationInferenceOutput,
    DetectionInferenceOutput,
    coerce_classification_output,
    coerce_detection_output,
)
from .inference_runners import InferenceRunnerRegistry, get_inference_runner
from .orchestrator import EvalContext, EvaluationOrchestrator, build_runtime_split_evaluator, load_model_from_registry
from .result_formatter import (
    format_classification_results,
    format_detection_results,
    format_keypoint_results,
    format_multilabel_results,
    format_ocr_results,
    format_tracking_results,
    format_yolo_results,
)
from .runtime_registry import RuntimeTaskRegistry
from .schemas import MetricPayload, MetricRecord, validate_metric_record, validate_payload
from .status_handler import EvaluationStatusCodes, EvaluationStatusReporter, safe_update_status


__all__ = [
    "ActionTrackerProtocol",
    "ClassificationInferenceOutput",
    "DatasetSplitError",
    "DetectionInferenceOutput",
    "EvalContext",
    "EvaluationError",
    "EvaluationOrchestrator",
    "EvaluationStatusCodes",
    "EvaluationStatusReporter",
    "InferenceRunnerError",
    "InferenceRunnerProtocol",
    "InferenceRunnerRegistry",
    "MetricPayload",
    "MetricRecord",
    "ModelLoadError",
    "ModelLoaderProtocol",
    "ModelLoaderRegistry",
    "PayloadFormatError",
    "ResultFormatterProtocol",
    "RuntimeNotSupportedError",
    "RuntimeTaskRegistry",
    "SplitEvaluatorProtocol",
    "build_imagefolder_loaders",
    "build_runtime_split_evaluator",
    "build_split_loader_map",
    "coerce_classification_output",
    "coerce_detection_output",
    "ensure_metric_functions",
    "evaluate_available_splits",
    "format_classification_results",
    "format_detection_results",
    "format_keypoint_results",
    "format_multilabel_results",
    "format_ocr_results",
    "format_tracking_results",
    "format_yolo_results",
    "get_classification_onnx_inference_results",
    "get_classification_openvino_inference_results",
    "get_classification_pytorch_inference_results",
    "get_classification_tensorrt_inference_results",
    "get_inference_runner",
    "load_classification_model",
    "load_model_from_registry",
    "load_model_with_runtime",
    "make_legacy_split_evaluator",
    "safe_update_status",
    "validate_metric_record",
    "validate_payload",
]
