"""Shared ActionTracker status helpers for evaluation flows."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from matrice_models.common.status import safe_update_status as common_safe_update_status


_LOGGER = logging.getLogger(__name__)


def safe_update_status(action_tracker: Any, step_code: str, status: str, description: str) -> None:
    """Submit status updates without propagating tracker exceptions.

    Args:
        action_tracker: Tracker-like object implementing ``update_status``.
        step_code: Evaluation lifecycle step identifier.
        status: Status level such as ``OK`` or ``ERROR``.
        description: Human-readable status description.

    Returns:
        None.
    """
    try:
        common_safe_update_status(action_tracker, step_code, status, description)
    except Exception as exc:
        _LOGGER.debug("Failed to update status for step %s: %s", step_code, exc)


@dataclass(frozen=True)
class EvaluationStatusCodes:
    """Canonical evaluation status step codes."""

    ACK: str = "MDL_EVL_ACK"
    DTL: str = "MDL_EVL_DTL"
    MDL: str = "MDL_EVL_MDL"
    STR: str = "MDL_EVL_STR"
    CMPL: str = "MDL_EVL_CMPL"
    ERR: str = "MDL_EVL_ERR"


class EvaluationStatusReporter:
    """Semantic status reporter for eval lifecycle transitions."""

    def __init__(self, action_tracker: Any, codes: EvaluationStatusCodes | None = None) -> None:
        """Initialize status reporter with tracker and optional code overrides.

        Args:
            action_tracker: Tracker-like object used for status updates.
            codes: Optional status code overrides for evaluation lifecycle.

        Returns:
            None.
        """
        self.action_tracker = action_tracker
        self.codes = codes or EvaluationStatusCodes()

    def acknowledged(self, msg: str = "Model Evaluation has acknowledged") -> None:
        """Publish acknowledgement status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.ACK, "OK", msg)

    def dataset_loaded(self, msg: str = "Evaluation dataset is loaded") -> None:
        """Publish dataset-ready status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.DTL, "OK", msg)

    def model_loaded(self, msg: str = "Model loaded for evaluation") -> None:
        """Publish model-loaded status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.MDL, "OK", msg)

    def started(self, msg: str = "Model Evaluation has started") -> None:
        """Publish evaluation-started status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.STR, "OK", msg)

    def completed(self, msg: str = "Model Evaluation is completed") -> None:
        """Publish evaluation-completed status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.CMPL, "SUCCESS", msg)

    def failed(self, msg: str) -> None:
        """Publish evaluation-failed status.

        Args:
            msg: Failure description for status tracking.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.ERR, "ERROR", msg)

