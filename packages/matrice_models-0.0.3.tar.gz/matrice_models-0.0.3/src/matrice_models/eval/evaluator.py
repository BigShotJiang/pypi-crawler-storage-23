"""Shared split-level evaluation orchestration helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matrice_models.common.splits import evaluate_available_splits as common_evaluate_available_splits


if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence


def evaluate_available_splits(
    requested_splits: Sequence[str],
    split_to_loader: Mapping[str, object],
    evaluate_split: Callable[[str, object], list[dict]],
) -> list[dict]:
    """Run split evaluator for available loaders and concatenate payload.

    Args:
        requested_splits: Ordered split names to evaluate.
        split_to_loader: Mapping from split name to loader object.
        evaluate_split: Callable that evaluates one split and returns payload records.

    Returns:
        Concatenated list of payload dictionaries from all available splits.
    """
    return common_evaluate_available_splits(
        requested_splits=requested_splits,
        split_to_loader=split_to_loader,
        evaluate_split=evaluate_split,
    )

