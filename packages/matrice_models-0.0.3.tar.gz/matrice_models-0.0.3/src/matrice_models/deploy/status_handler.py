"""Shared ActionTracker status helpers for deployment flows."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from matrice_models.common.status import safe_log_error as common_safe_log_error
from matrice_models.common.status import safe_update_status as common_safe_update_status


def safe_update_status(action_tracker: Any, step_code: str, status: str, description: str) -> None:
    """Submit a status update without propagating tracker exceptions.

    Args:
        action_tracker: Tracker-like object implementing ``update_status``.
        step_code: Lifecycle step identifier (for example ``MDL_DPY_ACK``).
        status: Status level string such as ``OK`` or ``ERROR``.
        description: Human-readable status description.

    Returns:
        None.
    """
    common_safe_update_status(action_tracker, step_code, status, description)


def safe_log_error(action_tracker: Any, file_path: str, location: str, message: str) -> None:
    """Log an error entry without propagating tracker exceptions.

    Args:
        action_tracker: Tracker-like object implementing ``log_error``.
        file_path: Source file associated with the error event.
        location: Logical module or location string.
        message: Error detail to persist in tracking backend.

    Returns:
        None.
    """
    common_safe_log_error(action_tracker, file_path, location, message)


@dataclass(frozen=True)
class DeployStatusCodes:
    """Canonical deployment status step codes."""

    ACK: str = "MDL_DPY_ACK"
    MODEL_READY: str = "MDL_DPY_MDL"
    STARTED: str = "MDL_DPY_STR"
    ERROR: str = "MDL_DPY_ERR"


class DeployStatusReporter:
    """Semantic status reporter for deploy lifecycle transitions."""

    def __init__(self, action_tracker: Any, codes: DeployStatusCodes | None = None) -> None:
        """Create a status reporter bound to tracker and status code set.

        Args:
            action_tracker: Tracker-like object used for status updates.
            codes: Optional deployment status code overrides.

        Returns:
            None.
        """
        self.action_tracker = action_tracker
        self.codes = codes or DeployStatusCodes()

    def acknowledged(self, msg: str = "Model Deployment has been acknowledged") -> None:
        """Emit deployment-acknowledged status.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.ACK, "OK", msg)

    def model_ready(self, msg: str = "Model loaded for deployment") -> None:
        """Emit model-ready status after loading succeeds.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.MODEL_READY, "OK", msg)

    def started(self, msg: str = "Model deployment started") -> None:
        """Emit deployment-started status after server boot.

        Args:
            msg: Optional status description override.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.STARTED, "OK", msg)

    def failed(self, msg: str) -> None:
        """Emit deployment-failed status with error context.

        Args:
            msg: Failure description for status tracking.

        Returns:
            None.
        """
        safe_update_status(self.action_tracker, self.codes.ERROR, "ERROR", msg)
