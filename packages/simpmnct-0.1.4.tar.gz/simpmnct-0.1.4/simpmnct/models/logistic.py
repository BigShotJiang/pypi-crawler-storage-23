from .base_model import BaseModel
import numpy as np

class logistic(BaseModel):

    def __init__(self,lr=0.01,epochs=1000):
        self.lr=lr
        self.epochs=epochs
    
    def sigmoid(self,z):
        return 1/(1+np.exp(-z))
    
    def fit(self,X,y):
        n_sample , n_feature = X.shape
        self.weight = np.zeros(n_feature)
        self.bias=0

        for i in range(self.epochs):
            y_pred = 1 / (1 + np.exp(-(X.dot(self.weight) + self.bias)))

            loss = (-1/n_sample) * np.sum(y*np.log(y_pred)+(1-y)*np.log(1-y_pred))
            
            dw = (1/n_sample)* X.T @ (y_pred-y)
            gd = (1/n_sample) * np.sum(y_pred-y)

            self.weight-= self.lr * dw
            self.bias-= self.lr * gd

    def predict(self,X):
        z = X.dot(self.weight) + self.bias
        y_pred = self.sigmoid(z)
        return (y_pred > 0.5).astype(int)

