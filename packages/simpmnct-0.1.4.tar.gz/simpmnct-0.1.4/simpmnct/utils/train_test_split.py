import numpy as np

def train_test_split(X,y,test_size=0.2):
    n_sample = X.shape[0]
    indices = np.arange(n_sample)
    np.random.shuffle(indices)
    n_test = int(n_sample*test_size)
    test_index = indices[:n_test]
    train_index = indices[n_test:]
    X_train = X[train_index]
    X_test = X[test_index]
    y_train = y[train_index]
    y_test = y[test_index]
    return X_train, X_test, y_train, y_test