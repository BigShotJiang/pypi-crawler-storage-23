simpmnct
đây là thư viện cho người mới học Machine learning , chạy hết đá số các trường hợp , có hàm có sẵn nhiều bạn sẽ phải tự xử lí bằng tay và gần như nó giúp bạn hiểu hơn về ML thay vì cứ họi hàm sẵn có.
dựa trên nền tẳng numpy , pickle , torch , torchvision , pillow 

This is a library for beginners in Machine Learning. It runs through most cases, has built-in functions, and many users will have to handle manually. It helps you understand ML better than just relying on ready-made functions.
It's based on NumPy, Pickle, Torch, TorchVision, and Pillow.

Thư viện hỗ trợ:
Linear Regression
Logistic Regression
Train/Test Split
Normalize dữ liệu (data)
Metrics cơ bản 
Save/Load model (.best)

Example 1 — Linear Regression
import numpy as np
from simpmnct.models.liner import Linear
from simpmnct.utils.train_test_split import train_test_split
X = np.random.rand(100,1)
y = 3*X + 2
X_train,X_test,y_train,y_test = train_test_split(X,y)
model = Linear(lr=0.01,epochs=1000)
model.fit(X_train,y_train)
pred = model.predict(X_test)
print(pred[:5])

Example 2 — Logistic Regression
import numpy as np
from simpmnct.models.logictic import Logistic
X = np.random.rand(100,2)
y = (X[:,0] + X[:,1] > 1).astype(int)
model = Logistic(lr=0.1,epochs=1000)
model.fit(X,y)
print(model.predict(X[:5]))

Train Test Split
from simpmnct.utils.train_test_split import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y)
Normalize
from simpmnct.utils.normalize import normalize
X_norm = normalize(X)

Metrics
from simpmnct.metrics.metrics import accuracy
from simpmnct.metrics.metrics import mse

Save Model
model.save("model.best")
File .best sẽ chứa toàn bộ model đã train.

Load Model
from simpmnct.models.liner import Linear
model = Linear.load("model.best")

Dataset Loader (Depth Estimation)
from simpmnct.dataset.depth_dataset import DepthDataset
dataset = DepthDataset(img_dir="images",depth_dir="depth")
img,depth = dataset[0]
Output:
image -> Tensor (3,H,W)
depth -> Tensor (1,H,W)

lưu ý : model này là do thằng sinh viên năm 2 viết ko dùng cho dự án lớn hay dẫn đường tên lửa , có thể sai số hoặc nhiều bug tiềm ẩn , chỉ sử dụng để học hoặc làm dự án nhỏ

Please note: this model was written by a second-year student and is not intended for large projects or missile guidance. It may contain errors or potential bugs; it is only for learning or small projects.