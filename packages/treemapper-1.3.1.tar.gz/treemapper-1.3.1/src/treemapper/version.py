__version__ = "1.3.1"  # This will be replaced during the build process
