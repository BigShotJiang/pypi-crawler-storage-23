"""
matrice_vss.utils
=================
Shared utility helpers for the VSS service.

Sub-modules
-----------
``errors`` module  *(stub — reserved for future custom exception types)*
    Intended to house domain-specific exception classes for the VSS service
    (e.g. ``VSSQueryError``, ``VSSTimeoutError``, ``VSSConfigError``).
    Currently empty; exceptions are raised inline in each component.

``logging`` module  *(stub — reserved for future logging utilities)*
    Intended for additional logging helpers beyond those already provided
    by :mod:`config.logging_config`.  Currently empty; all structured
    logging is handled in ``config/logging_config.py``.

Design note
-----------
Both source files are intentionally left as stubs so the package layout
follows the standard ML project structure from the outset.  Implement custom
exception types and logging utilities here as the service grows, keeping
domain logic out of the root ``matrice_vss`` namespace.

Usage
-----
.. code-block:: python

    # Future — once errors.py is populated:
    # from utils.errors import VSSQueryError, VSSTimeoutError

    # Future — once logging.py is populated:
    # from utils.logging import get_vss_logger
"""

from __future__ import annotations

__all__: list[str] = []
