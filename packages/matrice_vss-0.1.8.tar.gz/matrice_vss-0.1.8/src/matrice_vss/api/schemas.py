"""
VSS API Schemas
Request/Response Pydantic models.
"""

from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, ConfigDict, Field
from datetime import datetime


# === Requests ===

class QueryRequest(BaseModel):
    """Query request model."""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {"query": "How many people were counted yesterday?", "include_trace": False}
        }
    )

    query: str = Field(..., min_length=1, max_length=2000, description="Natural language question")
    include_trace: bool = Field(False, description="Include execution trace in response")


class QueryWithMediaRequest(BaseModel):
    """Query with image upload."""
    query: str = Field(..., min_length=1, max_length=2000)
    media_type: Literal["image"] = "image"
    media_base64: str = Field(..., description="Base64 encoded image")
    include_trace: bool = False


# === Responses ===

class QueryResponse(BaseModel):
    """Standard query response."""
    request_id: str
    status: Literal["success", "error"]
    response: str
    processing_time_ms: Optional[int] = None


class QueryResponseWithTrace(BaseModel):
    """Query response with execution trace."""
    request_id: str
    status: Literal["success", "error"]
    response: str
    processing_time_ms: Optional[int] = None
    trace: List[str] = []
    metadata: Dict[str, Any] = {}


class ErrorResponse(BaseModel):
    """Error response."""
    request_id: Optional[str] = None
    status: Literal["error"] = "error"
    error_code: str
    message: str


class HealthComponent(BaseModel):
    """Health check component."""
    status: Literal["ok", "error", "disabled"]
    message: Optional[str] = None


class HealthResponse(BaseModel):
    """Health check response."""
    status: Literal["healthy", "degraded", "unhealthy"]
    timestamp: datetime
    components: Dict[str, HealthComponent]