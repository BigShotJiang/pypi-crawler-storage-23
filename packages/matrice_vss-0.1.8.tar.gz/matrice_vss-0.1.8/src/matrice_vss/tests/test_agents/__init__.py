"""
matrice_vss.tests.test_agents
==============================
Unit tests for the ``agents`` sub-package.

Test modules
------------
``test_routing.py``
    :class:`~agents.routing_agent.RoutingAgent` — rule-based classification,
    async ``classify()`` path, LLM fallback, and the public
    :func:`~agents.routing_agent.classify_intent` LangGraph node.

``test_sql_agent.py``
    :class:`~agents.sql_agent.SQLAgent` — SQL generation, sanitization,
    retry logic, escalation, and the :func:`~agents.sql_agent.process_sql`
    bridge to :class:`~orchestration.state.VSSState`.

``test_llm_init.py``
    :class:`~inference.llm_client.OllamaClient` and
    :class:`~inference.llm_client.VLLMTextClient` — client construction,
    singleton behaviour, and health-check logic.

Running
-------
.. code-block:: bash

    # All tests in this package
    python -m unittest discover -s tests/test_agents -v

    # Single module
    python -m unittest tests/test_agents/test_routing.py -v
"""

from __future__ import annotations

__all__: list[str] = []
