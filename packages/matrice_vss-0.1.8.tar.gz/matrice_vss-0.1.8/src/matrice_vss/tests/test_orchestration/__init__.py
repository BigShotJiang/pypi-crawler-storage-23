"""
matrice_vss.tests.test_orchestration
======================================
Integration tests for the LangGraph orchestration layer.

Test modules
------------
``test_graph.py``
    :class:`~orchestration.graph.VSSOrchestrator` integration tests.
    Covers the following scenarios with mocked agent functions:

    * SQL path — normal completion, multi-attempt retry
    * VLM path — direct routing when media is attached
    * Escalation path — SQL returns no data → VLM fallback
    * Error path — agent raises exception → ``error`` node fires
    * Routing guards — VLM intent with ``vlm_enabled=False`` → SQL redirect
    * Trace integrity — every node appends entries; traces are merged

Running
-------
.. code-block:: bash

    # All orchestration tests
    python -m unittest discover -s tests/test_orchestration -v

    # Single module
    python -m unittest tests/test_orchestration/test_graph.py -v
"""

from __future__ import annotations

__all__: list[str] = []
