"""
tests/test_orchestration/test_graph.py
========================================
Orchestration graph tests are NOT included in the standard test run.

The full orchestrator (VSSOrchestrator) depends on both the SQL agent
AND the VLM agent. Since VLM testing is out of scope, these tests
have been intentionally omitted.

The API-level integration tests in  tests/test_e2e/test_api.py  cover
the observable behaviour of the orchestration pipeline end-to-end by
mocking the orchestrator boundary (VSSOrchestrator.run()), which is
sufficient for validating routing, SQL agent, and LLM paths.

If orchestration graph tests are needed in future, add them here using
unittest.IsolatedAsyncioTestCase and mock both process_sql and process_vlm.
"""
