"""
matrice_vss.tests
=================
Test suite for the VSS service.

Structure
---------
::

    tests/
    ├── conftest.py           pytest compatibility shim (adds vss/ to sys.path)
    ├── shared.py             Bootstrap: sys.path fix, logging, shared fixtures
    ├── run_tests.py          Standalone test runner (no pytest required)
    ├── test_agents/          Unit tests for each agent module
    │   ├── test_llm_init.py
    │   ├── test_routing.py
    │   └── test_sql_agent.py
    ├── test_e2e/             End-to-end API & pipeline tests
    │   ├── test_api.py
    │   └── test_mode1_flow.py
    └── test_orchestration/   LangGraph graph integration tests
        └── test_graph.py

Running tests
-------------
.. code-block:: bash

    # Standalone (no pytest dependency)
    python tests/run_tests.py

    # With pytest
    pytest tests/ -v

    # Single module
    python -m unittest tests/test_agents/test_routing.py -v

Shared utilities
----------------
Import :mod:`shared` at the top of every test file **before** any VSS
imports.  It ensures ``src/matrice_vss/`` is on :data:`sys.path` and
configures rotating test logs under ``tests/logs/``.

.. code-block:: python

    import shared
    from shared import make_state, make_mock_llm, make_sql_result
"""

from __future__ import annotations

__all__: list[str] = []
