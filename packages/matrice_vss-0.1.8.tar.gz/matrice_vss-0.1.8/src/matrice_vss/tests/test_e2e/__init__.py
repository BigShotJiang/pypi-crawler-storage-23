"""
matrice_vss.tests.test_e2e
===========================
End-to-end (E2E) tests for the VSS service.

These tests exercise the full request-to-response pipeline, typically by
calling the FastAPI application via ``httpx.AsyncClient`` (or the
``TestClient`` shim) with a mocked :class:`~orchestration.graph.VSSOrchestrator`.

Test modules
------------
``test_api.py``
    Tests for the FastAPI HTTP layer (``/api/v1/query``,
    ``/api/v1/query/media``, ``/api/v1/health``).  Uses
    ``fastapi.testclient.TestClient`` or ``httpx.AsyncClient`` with mocked
    orchestrator responses.

``test_mode1_flow.py``
    Full Mode 1 pipeline tests.  Instantiates the real
    :class:`~orchestration.graph.VSSOrchestrator` with mocked agent
    singletons (:func:`~agents.sql_agent.process_sql`,
    :func:`~agents.vlm_agent.process_vlm`) to verify graph routing,
    escalation, response composition, and trace population without
    requiring live service connections.

Running
-------
.. code-block:: bash

    # All e2e tests
    python -m unittest discover -s tests/test_e2e -v

    # Single module
    python -m unittest tests/test_e2e/test_api.py -v
"""

from __future__ import annotations

__all__: list[str] = []
