"""
tests/test_e2e/test_mode1_flow.py
===================================
This file has been superseded by  tests/test_e2e/test_api.py.

The new file uses stdlib unittest (no pytest) and TestClient (no server),
and covers only SQL + routing + LLM paths (VLM excluded).

Run the new tests:
    python tests/run_tests.py --module api
    python -m unittest tests/test_e2e/test_api.py -v
"""
