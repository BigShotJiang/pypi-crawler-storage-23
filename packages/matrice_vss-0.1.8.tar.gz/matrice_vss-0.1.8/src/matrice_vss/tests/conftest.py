"""
tests/conftest.py
==================
Minimal pytest compatibility shim.

All test logic and logging setup has moved to  tests/shared.py.
Tests are now run via  python tests/run_tests.py  (no pytest required).

This file is kept so that if pytest is accidentally invoked it won't
crash — it just adds  vss/  to sys.path, which is the only thing pytest
needs to find the source packages.
"""

import sys
from pathlib import Path

_VSS_ROOT = Path(__file__).resolve().parents[1]
if str(_VSS_ROOT) not in sys.path:
    sys.path.insert(0, str(_VSS_ROOT))
