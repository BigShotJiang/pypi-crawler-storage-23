"""Utility functions for posecheck-fast."""
