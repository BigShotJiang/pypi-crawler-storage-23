"""Internal implementation modules for random geometric perturbers."""
