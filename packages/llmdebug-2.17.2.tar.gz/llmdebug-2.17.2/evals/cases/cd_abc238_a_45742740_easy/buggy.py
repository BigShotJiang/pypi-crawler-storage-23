N = int(input())

if 2**N > N:
    print("Yes")
else:
    print("No")
