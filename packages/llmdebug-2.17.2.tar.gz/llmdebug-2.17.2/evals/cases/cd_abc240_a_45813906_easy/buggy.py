a, b = map(int, input().split())
if abs(a - b) == 1 or 9:
    print("Yes")
else:
    print("No")
