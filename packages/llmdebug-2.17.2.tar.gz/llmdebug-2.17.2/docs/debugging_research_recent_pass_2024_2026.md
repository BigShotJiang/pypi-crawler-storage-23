# Recent-Only Literature Pass (2024-2026): LLM-Enhanced Debugging, FL, APR, and Agentic Tooling

Date: 2026-02-16  
Scope: Separate pass restricted to recent publications (2024, 2025, 2026), with emphasis on LLM-enhanced processes and tools.

## Method

- Source strategy: direct arXiv API queries (`export.arxiv.org`) filtered by software-engineering categories (`cs.SE`, `cs.PL`) and debugging-relevant terms.
- Focus filter: LLM/agentic + debugging/fault-localization/program-repair/issue-resolution/regression/trace.
- Multi-pass workflow:
  1. Broad harvesting by axis keywords.
  2. Year-stratified selection (2026/2025/2024).
  3. Sub-agent synthesis passes for A/B, C/D/F, and E/G (process/tools).
- Auditable corpus export: `docs/recent_llm_debugging_papers_2024_2026.csv`.

## Executive Takeaways (Recent-Only)

1. Recent work strongly supports LLM-enhanced **hierarchical localization + retrieval + iterative repair** pipelines over one-shot patching.
2. Dynamic evidence helps, but **quality and compression** matter more than trace volume.
3. For your roadmap, the strongest 2025-2026 signal is: **localization quality, execution-informed iteration, and minimal reproduction/test reduction**.
4. Process/tooling papers show the same pattern repeatedly: **stage decomposition, observability, and verification loops** improve outcomes; complexity without information gain hurts.
5. Prompt/context handling is now a first-order variable: **order bias, pruning, and retrieval** can dominate results.
6. Patch quality is not “tests pass”: **validity and security gates** are increasingly treated as required infrastructure.
7. “Memory” helps only when it is **anchored and relevance-gated** (e.g., repository history), and can hurt when it is generic episodic recall.

## Representative Recent Papers (Curated)

### 2024 (foundation for LLM debugging/FL/APR process)
- AgentFL: [2403.16362](https://arxiv.org/abs/2403.16362)
- ChatDBG: [2403.16354](https://arxiv.org/abs/2403.16354)
- AutoCodeRover: [2404.05427](https://arxiv.org/abs/2404.05427)
- NExT: [2404.14662](https://arxiv.org/abs/2404.14662)
- UniDebugger: [2404.17153](https://arxiv.org/abs/2404.17153)
- Agentless: [2407.01489](https://arxiv.org/abs/2407.01489)
- Impact of LLMs on FL: [2408.09657](https://arxiv.org/abs/2408.09657)
- Multi-Agent FL via Graph Retrieval + Reflexion: [2409.13642](https://arxiv.org/abs/2409.13642)
- HyperAgent: [2409.16299](https://arxiv.org/abs/2409.16299)
- Integrating Software Artifacts for LLM Bug Localization/Repair: [2412.03905](https://arxiv.org/abs/2412.03905)

### 2025 (rapid scaling of APR/FL agent pipelines)
- Evaluating Agent-based Program Repair at Google: [2501.07531](https://arxiv.org/abs/2501.07531)
- Agentic Bug Reproduction at Google: [2502.01821](https://arxiv.org/abs/2502.01821)
- Bridging Bug Localization and Issue Fixing: [2502.15292](https://arxiv.org/abs/2502.15292)
- Thinking Longer, Not Larger: [2503.23803](https://arxiv.org/abs/2503.23803)
- Issue2Test (reproducer generation): [2503.16320](https://arxiv.org/abs/2503.16320)
- Agent That Debugs (dynamic-state-guided): [2504.07634](https://arxiv.org/abs/2504.07634)
- SWE-Synth: [2504.14757](https://arxiv.org/abs/2504.14757)
- Empirical Evaluation of Generalizable APR: [2506.03283](https://arxiv.org/abs/2506.03283)
- SE-Agent Traceability Study: [2506.08311](https://arxiv.org/abs/2506.08311)
- Black-Box FL for System-Level Test Code: [2506.19045](https://arxiv.org/abs/2506.19045)
- TSAPR: [2507.01827](https://arxiv.org/abs/2507.01827)
- Input Reduction Enhanced APR: [2507.15251](https://arxiv.org/abs/2507.15251)
- RePaCA (patch correctness assessment): [2507.22580](https://arxiv.org/abs/2507.22580)
- FaR-Loc (functionality-aware RAG for FL): [2509.20552](https://arxiv.org/abs/2509.20552)
- REFINE: [2510.03588](https://arxiv.org/abs/2510.03588)
- Regression-test impact on issue resolution: [2510.18270](https://arxiv.org/abs/2510.18270)
- LLMs for FL empirical study: [2510.20521](https://arxiv.org/abs/2510.20521)
- AutoCrashFL (industrial crash localization): [2510.22530](https://arxiv.org/abs/2510.22530)
- Time Travel behavior localization with git bisect: [2511.18854](https://arxiv.org/abs/2511.18854)
- DynaFix (iterative dynamic info): [2512.24635](https://arxiv.org/abs/2512.24635)

### 2026 (early wave; many preprints, mixed maturity)
- Improved Bug Localization with AI Agents: [2601.12522](https://arxiv.org/abs/2601.12522)
- Automatic Spec/Verification Annotation Generation: [2601.12845](https://arxiv.org/abs/2601.12845)
- RGFL: [2601.18044](https://arxiv.org/abs/2601.18044)
- SVRepair: [2602.06090](https://arxiv.org/abs/2602.06090)
- AgentStepper: [2602.06593](https://arxiv.org/abs/2602.06593)
- TraceCoder: [2602.06875](https://arxiv.org/abs/2602.06875)
- Agent-generated tests value study: [2602.07900](https://arxiv.org/abs/2602.07900)
- AgentTrace: [2602.10133](https://arxiv.org/abs/2602.10133)
- Agent-Diff (state-diff evaluation): [2602.11224](https://arxiv.org/abs/2602.11224)

## Additional Recent Publications (Extended)

This section lists additional 2024–2026 papers that tackle closely related problems and provide directly actionable ideas for improving `llmdebug`.

### Fault Localization, Retrieval, and Repo Navigation
- Order bias in FL prompts: [2412.18750](https://arxiv.org/abs/2412.18750) (evidence packaging matters; motivates robust prompt ordering + ablations).
- Issue localization agent pipeline: [2502.00350](https://arxiv.org/abs/2502.00350) (tool-using localization loop; aligns with hierarchical FL).
- Attention probing for scalable FL: [2502.13966](https://arxiv.org/abs/2502.13966) (alternative localization scoring signal).
- Iterative code-graph searching for localization: [2503.22424](https://arxiv.org/abs/2503.22424) (graph-guided exploration under context constraints).
- Code-change impact on localizability: [2504.04372](https://arxiv.org/abs/2504.04372) (FL brittleness; motivates robustness evals).
- Linux kernel bug localization benchmarks: [2505.19489](https://arxiv.org/abs/2505.19489) (large, real-world-ish localization dynamics).
- External memory + project context for FL: [2506.03585](https://arxiv.org/abs/2506.03585) (structured memory across iterations; caution: relevance gating).
- Crash report enhancement for better debugging: [2509.13535](https://arxiv.org/abs/2509.13535) (turn raw crash dumps into actionable summaries).
- Semantics-driven query reduction for bug localization: [2510.04468](https://arxiv.org/abs/2510.04468) (improves IR-style localization).
- Reformulate→retrieve→localize agents: [2512.07022](https://arxiv.org/abs/2512.07022) (explicit decomposition; retrieval as core operator).
- Knowledge-graph-enhanced defect localization (LLM integration): [2601.05539](https://arxiv.org/abs/2601.05539) (cross-artifact localization beyond code-only).

### Execution Evidence, Traces, Slicing, Debugger Integration
- Execution trace prompting tradeoffs: [2505.04441](https://arxiv.org/abs/2505.04441) (raw/long traces can hurt; filtering + budgeting is essential).
- Interactive debugger collaboration for repair: [2510.18327](https://arxiv.org/abs/2510.18327) (debugger-driven evidence collection; suggests “Level 3” instrumentation).
- Reasoning-trace errors in execution simulation: [2512.00215](https://arxiv.org/abs/2512.00215) (motivates tool-grounded traces over “imagined” ones).
- Trace abstraction + analysis via KGs + LLMs: [2601.02632](https://arxiv.org/abs/2601.02632) (summarize/structure traces; supports partial-trace design).
- LLM-powered static slicing at scale: [2507.18957](https://arxiv.org/abs/2507.18957) (supports provenance/slicing features as context compression).

### Repair Pipelines, Candidate Selection, and Cost/Compute Management
- Contrastive test pairs for conversational APR: [2403.01971](https://arxiv.org/abs/2403.01971) (fail+pass pairing as a strong repair signal).
- Aligning APR objectives (and when localization hurts): [2404.08877](https://arxiv.org/abs/2404.08877) (don’t over-constrain; keep escape hatches).
- Hybrid APR (LLMs + program analysis): [2406.00992](https://arxiv.org/abs/2406.00992) (analysis-guided context + repair).
- Practical APR framing for debugging: [2407.08958](https://arxiv.org/abs/2407.08958) (focus on usefulness, not just benchmark wins).
- Iterative repair optimization: [2505.02931](https://arxiv.org/abs/2505.02931) (patch-and-test/search style improvement).
- Intent-driven adversarial reasoning for repair: [2505.13008](https://arxiv.org/abs/2505.13008) (patch selection via intent inference).
- Cheap crash-site repair at scale: [2505.13103](https://arxiv.org/abs/2505.13103) (crash-site evidence as a repair anchor).
- ReAct-guided patch-and-test cycles: [2506.08173](https://arxiv.org/abs/2506.08173) (structured iterative loop; interpretable stages).
- Repair-ingredient search as retrieval prior: [2506.23100](https://arxiv.org/abs/2506.23100) (retrieve “ingredients” before generation).
- Fine-tuning impact on APR: [2507.19909](https://arxiv.org/abs/2507.19909) (helps decide between prompting vs finetune).
- Abstain + validate policies to reduce noise: [2510.03217](https://arxiv.org/abs/2510.03217) (treat abstention as a first-class outcome).
- Human-in-loop patch validity evaluation with LLM judges: [2511.10865](https://arxiv.org/abs/2511.10865) (tests-pass is insufficient; build judge/rubrics).
- History-aware APR using repo signals: [2511.01047](https://arxiv.org/abs/2511.01047) (anchored history can help; differs from generic “memory”).

### Reproduction, Minimization, Tests, and Oracles
- Property-based testing as validation bridge: [2506.18315](https://arxiv.org/abs/2506.18315) (cheap oracles when expected output is unclear).
- Passing-test inversion to reproduce bugs: [2507.17542](https://arxiv.org/abs/2507.17542) (generate pass first, then invert assertions).
- Execution-aware regression test generation: [2508.01255](https://arxiv.org/abs/2508.01255) (reduce context; add execution annotations).
- Static test-oracle generation for REST APIs: [2508.16318](https://arxiv.org/abs/2508.16318) (spec-derived oracles; highly actionable in API services).
- Tests beyond validation (tests as training/refinement signal): [2509.24148](https://arxiv.org/abs/2509.24148) (small high-yield suites; iterative refinement).
- Adversarial iterative refinement of tests and patches: [2511.16004](https://arxiv.org/abs/2511.16004) (co-evolve tests and fixes; selection matters).
- Dynamic co-generation of bug reproduction tests: [2601.19066](https://arxiv.org/abs/2601.19066) (ties reproduction into repair loop).
- Patch oracle inference from NL artifacts: [2602.05270](https://arxiv.org/abs/2602.05270) (pre/post differential assertions as a verifier).
- Benchmarking proactive bug discovery via test generation: [2602.10471](https://arxiv.org/abs/2602.10471) (how far “test-first” agents can really go).

### Safety, Robustness, and Benchmark/Measurement Pitfalls
- Episodic memory pitfalls in SE agents: [2505.23422](https://arxiv.org/abs/2505.23422) (memory can degrade due to distractors; motivates strict retrieval gating).
- SWE-bench leaderboard dissection: [2506.17208](https://arxiv.org/abs/2506.17208) (architecture vs model confounds; weak documentation).
- Adversarial bug reports as attack surface: [2509.05372](https://arxiv.org/abs/2509.05372) (treat issue text as untrusted input; need prompt-injection defenses).
- “Correct-but-vulnerable” patches / red teaming APR agents: [2509.25894](https://arxiv.org/abs/2509.25894) (tests-pass can still be unsafe).
- Intervention-driven debugging for multi-agent systems: [2512.06749](https://arxiv.org/abs/2512.06749) (measure recovery/progress, not just attribution).
- SWE-bench Verified contamination/memory signals: [2512.10218](https://arxiv.org/abs/2512.10218) (add contamination checks + context ablations).
- Goal-conditioned context pruning: [2601.16746](https://arxiv.org/abs/2601.16746) (token savings with equal/better success).
- Benchmark validity analysis (SWE-bench APR): [2602.04449](https://arxiv.org/abs/2602.04449) (benchmark design matters; interpret results carefully).
- Survey of LLM-based issue resolution: [2601.11655](https://arxiv.org/abs/2601.11655) (taxonomy and design patterns; good for gap-finding).

## Axis-by-Axis Findings (2024-2026 Only)

## A) Execution Traces & Provenance
- Strong positive trend for execution-aware repair/localization, especially with iterative use of runtime signals.
- Current best practice in recent papers: filtered dynamic evidence (variable/state slices, path cues, selective trace segments), not full raw traces.
- Practical implication for llmdebug: provenance should be compact, causal, and token-budgeted.
- Recent caution: raw/long traces can degrade performance; trace abstraction/summarization is a recurring mitigation.
- Recent direction: interactive debugger-backed evidence collection and LLM-powered slicing to compress context while keeping causal links.

## B) Fault Localization Signals
- FL quality remains the strongest predictor of downstream repair success in recent LLM pipelines.
- Hierarchical FL (file -> method -> line) plus retrieval/context ranking is repeatedly used.
- Industrial evidence exists (for example crash localization at scale), but most papers are still benchmark-first.
- Recent additions: order bias, query reduction, graph-guided search, crash report enhancement, and external-memory/local context improve practical FL pipelines.

## C) Constraint/Invariant Extraction
- Recent evidence is positive but domain-skewed (formal/spec-heavy settings, constrained benchmarks, verification-oriented tasks).
- Signals are useful as guidance and validation, but broad generalization to arbitrary production Python code is less settled.
- Practical implication: use invariant checks as ranked hints with confidence/support metadata.
- Recent practical angle: tests/oracles (OpenAPI-derived oracles, patch-oracles, and property-based checks) act as “lightweight invariants” for validation.

## D) State Diff & Regression Patterns
- Recent papers support state/behavior-difference workflows (semantic bisect, diff-based evaluation), but this area is less mature than FL/APR.
- Practical implication: first-divergence workflows are promising, but should be gated by deterministic replay.
- Recent RCA direction: hypothesis→verify loops and intervention-driven debugging (especially for distributed systems and agentic systems).

## E) Call Graph & Dependency Context
- Repository/context graphing and structure-aware retrieval appear frequently in successful agent pipelines.
- Practical implication: lightweight dependency context is useful; avoid heavy graph expansion unless ranking/pruning is strong.
- Recent direction: knowledge graphs and explicit “reformulate→retrieve→localize” loops to traverse cross-artifact dependencies.

## F) Minimal Reproduction
- Strong 2025 evidence that input/test reduction and reproducer generation materially improve repair pipelines.
- Practical implication: add minimization/reproducer capabilities earlier; this likely gives high ROI.
- Recent directions: pass-first-then-invert for reproducer tests, adversarial co-evolution of tests+patches, and execution-aware regression-test generation.

## G) Structured Prompting / Process / Tools
- The dominant process pattern in recent papers:
  1. Localize with structured retrieval.
  2. Generate candidate patches.
  3. Execute/validate.
  4. Refine with feedback (often multi-iteration).
- Tooling pattern: observability (traceability, trajectory logging, interactive debugging UI) improves reliability and operator trust.
- Recent guardrails: abstain/validate gates, patch validity judging beyond tests-pass, security hardening against adversarial issue text, and context pruning to control cost.

## Implications for `llmdebug` (Actionable)

1. Add a deterministic “localization pre-pass” that fuses traceback + IR/RAG retrieval + light project context, and returns ranked file/method candidates (helps both tool and eval introspection).
   - Relevant: query reduction, external memory/context, reformulate→retrieve→localize, crash report enhancement.
2. Implement trace/provenance as a **budgeted, structured artifact**, not a raw event dump.
   - Suggested levels: locals-only → line-path → state-deltas + shallow provenance → debugger-backed interactive evidence.
   - Relevant: execution-trace prompting tradeoffs, trace abstraction, reasoning-trace errors, slicing agents, debugger collaboration.
3. Move “minimal reproduction and reduction” earlier in the loop.
   - Add reducers for failing inputs and/or reduced test/context packets; include pass-first-then-invert for hard repro cases.
   - Relevant: Issue2Test, input reduction, AssertFlip, TestWeaver, TENET, dynamic reproduction tests.
4. Add patch-quality guardrails as first-class outcomes.
   - Track abstention, add a patch validity check beyond tests-pass (rubric/LLM judge + optional static checks), and treat issue text as untrusted input.
   - Relevant: abstain+validate policies, LLM-as-judge evaluation, adversarial issue reports, correct-but-vulnerable patch red teaming.
5. Be conservative with “memory”: prefer anchored repo history (blame/diff) over generic episodic recall, and enforce relevance gating + TTL/decay.
   - Relevant: history-aware APR vs negative results on episodic memory.
6. Add evaluation hygiene checks so we don’t overfit to benchmark quirks.
   - Prompt order robustness, contamination/memorization sensitivity, plausible-vs-valid sampling, and costed reliability curves.
   - Relevant: order bias in FL, SWE-bench validity/leaderboard analyses, enterprise APR evaluations, goal-conditioned pruning, test-time compute scaling.

## Updated Verdict on Your 8 Enhancements (Recent-Only)

| # | Enhancement | Recent-only support | Recommendation |
|---|---|---|---|
| 1 | Variable provenance | Moderate-strong (especially when compact/targeted) | Pilot |
| 2 | SBFL suspiciousness | Strong as a complementary ranking prior in modern FL stacks | Build now |
| 3 | First divergence point | Moderate, promising but less mature | Pilot (determinism-gated) |
| 4 | Violated invariant hints | Moderate; stronger in formal/spec domains | Build now as hinting layer |
| 5 | Partial execution trace | Mixed; helps when compressed and selective | Pilot behind flag |
| 6 | Call graph summary | Moderate-positive with structure-aware retrieval | Build now (scoped) |
| 7 | Branch decisions | Useful, but usually as part of execution-state packages | Defer standalone; bundle with trace pilot |
| 8 | Historical lesson capture | Mixed: anchored repo history can help; generic episodic memory can hurt | Pilot with strong retrieval gating + TTL/decay |

## Recommended Next Build Order (Recent-Only)

1. `#2 SBFL` + hierarchical FL output contract.
2. `#6 Call/dependency context` with strict ranking budget.
3. `#4 Invariant hint layer` (confidence + support counts).
4. `#F (new) Minimal reproduction/reduction pipeline` (Issue2Test/Input-reduction style).
5. `#1 Provenance slices` (compact and causal).
6. `#3 First divergence` (deterministic-only pilot).
7. `#8 Historical lessons` (curated memory).
8. `#5/#7` as a shared trace pilot.

## Maturity Note

- 2026 has many relevant preprints, but benchmark and external-validity maturity varies widely.
- For roadmap confidence, give more weight to:
  - replicated/industrial studies,
  - ablations with cost metrics,
  - settings beyond a single benchmark.
- In recent APR/agent work, treat these as mandatory “measurement hygiene” checks:
  - prompt order robustness checks,
  - contamination/memorization sensitivity checks,
  - security/adversarial input checks,
  - patch validity sampling beyond tests-pass.
