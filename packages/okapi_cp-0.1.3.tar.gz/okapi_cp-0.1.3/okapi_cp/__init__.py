# Copyright The OkapiCore Authors
# SPDX-License-Identifier: Apache-2.0

"""okapi-cp package."""

__all__ = ["__version__"]
__version__ = "0.1.0"
