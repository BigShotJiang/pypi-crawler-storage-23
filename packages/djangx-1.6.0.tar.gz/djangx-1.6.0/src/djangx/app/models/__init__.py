"""Models for base app."""

from .contactinfo import *
from .org import *
from .socialurls import *
