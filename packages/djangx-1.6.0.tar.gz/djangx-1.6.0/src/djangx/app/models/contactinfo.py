"""Contact info models."""

__all__: list[str] = []
