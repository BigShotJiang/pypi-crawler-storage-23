"""Social URL models."""

__all__: list[str] = []
