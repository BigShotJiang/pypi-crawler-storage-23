"""Organization admin."""

__all__: list[str] = []
