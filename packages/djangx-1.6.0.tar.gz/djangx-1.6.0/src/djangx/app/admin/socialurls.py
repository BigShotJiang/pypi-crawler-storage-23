"""Social URLs admin."""

__all__: list[str] = []
