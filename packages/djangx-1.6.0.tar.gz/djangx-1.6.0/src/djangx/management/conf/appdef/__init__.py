"""App definition settings."""

from .installed_apps import *
from .middleware import *
from .templates import *
