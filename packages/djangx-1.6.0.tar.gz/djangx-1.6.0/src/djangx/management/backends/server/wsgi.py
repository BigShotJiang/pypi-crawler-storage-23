"""WSGI configuration."""

from django.core.wsgi import get_wsgi_application

SERVER_APPLICATION = get_wsgi_application()
