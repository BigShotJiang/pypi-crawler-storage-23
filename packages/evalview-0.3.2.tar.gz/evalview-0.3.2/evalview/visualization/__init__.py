"""EvalView visualization — beautiful self-contained HTML reports."""

from evalview.visualization.generators import generate_visual_report

__all__ = ["generate_visual_report"]
