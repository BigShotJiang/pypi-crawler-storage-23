from __future__ import annotations

import json
from pathlib import Path
from typing import Any


STARTER_POLICY: dict[str, Any] = {
    "policy_key": "invoice_create_guard",
    "policy_version": 1,
    "effect": "allow",
    "rules": [
        {
            "rule_key": "require_currency",
            "rule_definition": {
                "type": "required_fields",
                "fields": ["currency"],
            },
            "reason_code": "required_currency",
            "reason_message": "currency is required.",
        },
        {
            "rule_key": "max_amount",
            "rule_definition": {
                "type": "max_value",
                "field": "amount",
                "max": 1000,
            },
            "reason_code": "amount_over_limit",
            "reason_message": "amount must be <= 1000.",
        },
    ],
}


def _base_execute_request() -> dict[str, Any]:
    return {
        "workspace_id": "workspace-demo",
        "principal": {
            "type": "token",
            "id": "api:ops-bot",
        },
        "object_type": "invoice",
        "operation": "create",
        "policy_context": {
            "governed": True,
            "selected_policies": [STARTER_POLICY],
        },
    }


def _json_text(payload: Any) -> str:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )


def _readme_text() -> str:
    return """# Kernite Starter Bundle

This bundle gives you a baseline write-path policy with deterministic deny/approve behavior.

## 1) Run the reference server

```bash
uvx kernite serve
```

## 2) Send denied request (blocked by policy)

```bash
curl -sS http://127.0.0.1:8000/v1/execute \\
  -H 'content-type: application/json' \\
  -H 'Idempotency-Key: starter-denied-001' \\
  -d @execute-request.denied.json
```

Expected outcome:

- `data.decision = "denied"`
- `data.reason_codes` contains `required_currency` and `amount_over_limit`

## 3) Send approved request (after fix)

```bash
curl -sS http://127.0.0.1:8000/v1/execute \\
  -H 'content-type: application/json' \\
  -H 'Idempotency-Key: starter-approved-001' \\
  -d @execute-request.approved.json
```

Expected outcome:

- `data.decision = "approved"`
- `data.reason_codes = []`

## 4) Write-path integration rule

Proceed with mutation only when:

- `data.decision == "approved"`

If denied:

- branch on `data.reason_codes` to remediate and retry

Persist governance evidence with your write/audit record:

- `ctx_id`
- `data.trace_hash`
- `data.idempotency_key`
"""


def _guard_text() -> str:
    return """from __future__ import annotations

from typing import Any, Callable

from kernite import evaluate_execute


def guard_and_write(
    request: dict[str, Any],
    mutate_fn: Callable[[], dict[str, Any]],
    *,
    idempotency_key: str | None = None,
) -> dict[str, Any]:
    result = evaluate_execute(request, idempotency_key=idempotency_key)
    data = result["data"]

    if data["decision"] != "approved":
        return {"ok": False, "governance": result}

    mutation = mutate_fn()
    return {"ok": True, "data": mutation, "governance": result}
"""


def _starter_files() -> dict[str, str]:
    denied_request = _base_execute_request()
    denied_request["payload"] = {"amount": 1200}

    approved_request = _base_execute_request()
    approved_request["payload"] = {"amount": 500, "currency": "USD"}

    return {
        "policy.json": _json_text(STARTER_POLICY),
        "execute-request.denied.json": _json_text(denied_request),
        "execute-request.approved.json": _json_text(approved_request),
        "guard.py": _guard_text(),
        "README.md": _readme_text(),
    }


def scaffold_starter_bundle(
    target_dir: str | Path = "kernite",
    *,
    force: bool = False,
) -> Path:
    target = Path(target_dir)

    if target.exists():
        if not target.is_dir():
            raise ValueError(f"Target path is not a directory: {target}")
        if any(target.iterdir()) and not force:
            raise FileExistsError(
                f"Target directory is not empty: {target}. Use --force to overwrite."
            )
    else:
        target.mkdir(parents=True, exist_ok=True)

    for file_name, content in _starter_files().items():
        (target / file_name).write_text(content, encoding="utf-8")

    return target
