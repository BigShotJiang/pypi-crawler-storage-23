# Documentation (Mintlify)

Kernite docs are now maintained in this repository under `docs/`.

## Local preview

From repository root:

```bash
cd docs
npm i -g mint
mint dev
```

## Hosting

Configure Mintlify Git integration to use this repository with root directory set to `docs`.

## Notes

- Existing contract and conformance sources remain in this same `docs/` tree.
- Public integration pages should reference the canonical compatibility contract.
