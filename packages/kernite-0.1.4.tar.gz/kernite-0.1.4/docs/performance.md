# Performance Notes

Kernite uses Python by design for early iteration speed, but optimization decisions should be benchmark-driven.

## Benchmark Harness

Run:

```bash
uv run python benchmarks/benchmark_execute.py --iterations 20000 --warmup 500
```

The script measures per-scenario latency and throughput for `evaluate_execute` without external dependencies.

## Latest Local Snapshot

Measured on February 19, 2026 with Python `3.11.10`:

| Scenario | Throughput (req/s) | p50 (ms) | p95 (ms) | p99 (ms) |
| --- | ---: | ---: | ---: | ---: |
| governed_no_matching_policy | 74,683.11 | 0.013209 | 0.014667 | 0.017791 |
| governed_missing_field_denied | 44,207.49 | 0.022334 | 0.025002 | 0.031842 |
| governed_approved | 46,366.11 | 0.021292 | 0.024209 | 0.031425 |
| out_of_scope_approved | 72,028.81 | 0.013375 | 0.015085 | 0.022833 |

These values are environment-specific. Use the same harness in CI/staging/prod-like environments for objective comparison over time.
