from __future__ import annotations

from kernite.contracts import load_execute_vectors_v1
from kernite.evaluator import evaluate_execute


def test_execute_conformance_vectors():
    vectors = load_execute_vectors_v1()
    assert vectors, "conformance vectors must not be empty"

    for vector in vectors:
        result = evaluate_execute(
            vector["request"],
            idempotency_key=vector.get("idempotency_key"),
        )

        assert "ctx_id" in result
        assert "message" in result
        data = result.get("data") or {}

        expected = vector["expect"]
        assert data.get("decision") == expected["decision"], vector["name"]
        assert data.get("reason_codes") == expected["reason_codes"], vector["name"]
        assert (
            data.get("policy_selection_reason_code")
            == expected["policy_selection_reason_code"]
        ), vector["name"]
        assert data.get("idempotency_key") == vector.get("idempotency_key")
        assert str(data.get("trace_hash") or "").startswith("sha256:"), vector["name"]
