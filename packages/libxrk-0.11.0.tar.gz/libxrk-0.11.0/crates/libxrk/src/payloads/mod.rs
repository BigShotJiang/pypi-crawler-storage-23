//! Payload struct definitions for header messages.

pub mod cal;
pub mod chs;
pub mod gps;
pub mod gpsr;
pub mod grp;
pub mod idn;
pub mod lap;
pub mod odo;
pub mod racm;
pub mod trk;
pub mod vet;
