"""Constants for the pym2v package."""

TOKEN_ROUTE = "/auth/realms/iiot-platform/protocol/openid-connect/token"  # noqa: S105
