document.addEventListener('DOMContentLoaded', function () {
    // Your code here. This will run after the DOM is fully loaded.
    console.log('DOM loaded');

    let list = document.getElementById('autocomplete')
    let searchTermInput = document.getElementById('filterSearchTerm')
    let addFilterBtn = document.getElementById('addFilterBtn');
    if (addFilterBtn)
        addFilterBtn.addEventListener('click', (evnt) => {
            evnt.preventDefault();
            AddFilter();
        });
    if (list) {
        searchTermInput.addEventListener('input', async (ev) => {
            ev.preventDefault();
            let value = searchTermInput.value;

            if (value.length >= 3) {
                let results = await getSearchList(value);
                list.innerHTML = '';

                if (results) {
                    searchResults = results;

                    for (let i = 0; i < results.length; i++) {
                        let option = document.createElement('option');
                        option.value = results[i].name;
                        option.dataset.id = results[i].id;
                        option.dataset.type = results[i].type;
                        option.dataset.name = results[i].name;
                        list.appendChild(option);
                    }
                }
            }
        });
    }
    document.querySelectorAll('.delete-filter-btn').forEach(elm => elm.addEventListener('click', e=> deleteFilterButtonHandler(e)));
});


async function deleteFilterButtonHandler(evnt) {
    evnt.preventDefault();
    if(await showConfirm(`Вы уверены, что хотите удалить фильтр для "${evnt.currentTarget.dataset.name}"?`))
      {  
        let result = await deleteFilter(evnt.target.dataset.id);
        if(result)
            evnt.target.closest('li').remove();
    
      }
}

function clearFilterForm(){
    let list = document.getElementById('autocomplete')
    let searchTermInput = document.getElementById('filterSearchTerm')
    list.innerHTML = '';
    searchTermInput.value = '';
}

async function getSearchList(term) {
    result = fetch(`/br_compensations/api/filter-term/find`, {
        method: 'POST',
        headers: {
            'Content-Type': 'text/plain',
            'X-CSRFToken': csrfToken,
        },
        body: term
    })
        .then(response => {
            if (!response.ok)
                throw new Error(`Response status code indicates error. Status code ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log(data);
            return data;
        })
        .catch(error => {
            console.error('Error: ', error);
        })

    return result;
}

async function AddFilter() {
    let term = document.getElementById('filterSearchTerm');

    if (!term)
        return;

    let value = term.value;
    let result = document.querySelector(`datalist option[value="${value}"]`);
    if (!result || result.dataset.id <= 0) {
        showAlert('Выбран некорректный фильтр. Проверьте введенные данные.');
        return;
    }

    let apiStatus = await addNewFilterRequest(result.dataset.id,result.dataset.type);

    if(!apiStatus){
        showAlert('Фильтр не добавлен. Попробоуйсте снова или обратитесь к администратору.');
        return;
    }

    let filterType = result.dataset.type;
    let li = document.createElement('li');
    let deleteBtn = document.createElement('button');
    li.classList.add('d-flex', 'justify-content-between', 'p-2', 'list-group-item');
    let filterContainer = document.createElement('div');
    let icon = document.createElement('img');

    switch (filterType) {
        case 'alliance':
            icon.setAttribute('src', `https://images.evetech.net/alliances/${result.dataset.id}/logo?size=32`);
            icon.setAttribute('alt', 'alliance');
            break;
        case 'corporation':
            icon.setAttribute('src', `https://images.evetech.net/corporations/${result.dataset.id}/logo?size=32`);
            icon.setAttribute('alt', 'corporation');
            break;
        case 'character':
            icon.setAttribute('src', `https://images.evetech.net/characters/${result.dataset.id}/portrait?size=32`);
            icon.setAttribute('alt', 'character');
            break;
    }

    icon.setAttribute('title', result.dataset.name);
    icon.setAttribute('width', '32');
    filterContainer.append(icon)
    filterContainer.innerHTML += result.dataset.name;
    li.append(filterContainer);

    deleteBtn.classList.add('delete-filter-btn','fa','fa-trash','btn','btn-danger');
    deleteBtn.addEventListener('click',e=>deleteFilterButtonHandler(e));
    deleteBtn.dataset.id = result.dataset.id;
    deleteBtn.dataset.type = result.dataset.type;
    deleteBtn.dataset.name = result.dataset.name;
    li.appendChild(deleteBtn);

    let list = document.querySelector('#filters-list');
    list.append(li);
    clearFilterForm();
}

async function deleteFilter(id){
    result = fetch(`/br_compensations/api/filters/${id}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        }
    })
        .then(response => {
            if (!response.ok)
                throw new Error(`Response status code indicates error. Status code ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log(data);
            return data;
        })
        .catch(error => {
            console.error('Error: ', error);
        })

    return result;
}

async function addNewFilterRequest(entry_id, type){
    result = fetch(`/br_compensations/api/filters/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify( {
            entity_id: entry_id,
            entity_type: type
        })
    })
        .then(response => {
            if (!response.ok)
                throw new Error(`Response status code indicates error. Status code ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log(data);
            return data;
        })
        .catch(error => {
            console.error('Error: ', error);
        })

    return result;
}