from ..models import FilterEntity,BattleReport,KillCompensation
from rest_framework import serializers
# from allianceauth.eveonline.models import EveCharacter, EveAllianceInfo, EveCorporationInfo
# from eveuniverse.models import EveType

class FilterEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = FilterEntity
        fields = [
            'entity_id', 'entity_type', 'added_at'
        ]

class BattleReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = BattleReport
        fields = [
            'report_id','link','added_at', 'comment', 'status', 'report_type', 'updatedAt'
        ]

class KillCompensationSrializer(serializers.ModelSerializer): 
    class Meta:
        model = KillCompensation
        fields = [
            'killmail_id',
            'hash',
            'character_id',
            'character_name',
            'alliance_id',
            'alliance_name',
            'corporation_id',
            'corporation_name',
            'loss_value',
            'timestamp',
            'activity_type',
            'ship_type',
            'ship_name',
            'system',
            'created_at',
            'comment',
            'status'
        ]

class UniverseSearchResultSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    type = serializers.CharField()

class UniverseSearchResponseSerializer(serializers.Serializer):
    result = UniverseSearchResultSerializer(many=True, required=False,allow_null=True,  default=[])