"""Fast query helpers (internal)."""
