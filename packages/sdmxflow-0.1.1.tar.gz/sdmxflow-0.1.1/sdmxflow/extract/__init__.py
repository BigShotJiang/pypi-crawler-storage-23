"""Extraction helpers (internal)."""
