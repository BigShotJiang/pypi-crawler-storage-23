"""Provider adapters (internal)."""
