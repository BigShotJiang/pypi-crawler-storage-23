"""Metadata schema + writer (internal)."""
