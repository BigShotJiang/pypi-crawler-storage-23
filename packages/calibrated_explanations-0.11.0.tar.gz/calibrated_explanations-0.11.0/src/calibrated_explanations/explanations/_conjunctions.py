# src/calibrated_explanations/explanations/_conjunctions.py
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np


class ConjunctionState:
    """Helper class to manage the state of conjunctive rules."""

    def __init__(
        self,
        initial_rules: Optional[Dict[str, Any]] = None,
        dedupe_by_feature_only: bool = True,
    ):
        """Initialize the state with existing rules."""
        self.dedupe_by_feature_only = dedupe_by_feature_only
        if initial_rules is None:
            self.state = {
                "base_predict": [],
                "base_predict_low": [],
                "base_predict_high": [],
                "predict": [],
                "predict_low": [],
                "predict_high": [],
                "weight": [],
                "weight_low": [],
                "weight_high": [],
                "value": [],
                "rule": [],
                "feature": [],
                "sampled_values": [],
                "feature_value": [],
                "is_conjunctive": [],
                "classes": [],
            }
        else:
            self.state = self._clone_payload(initial_rules)
            # Ensure is_conjunctive is present
            if "is_conjunctive" not in self.state:
                self.state["is_conjunctive"] = [False] * len(self.state["rule"])
        self._combination_keys = set()
        if self.state["feature"]:
            for i, feature in enumerate(self.state["feature"]):
                values = (
                    self.state["sampled_values"][i] if not self.dedupe_by_feature_only else None
                )
                key = self.get_normalization_key(feature, values)
                self._combination_keys.add(key)

    def _clone_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        cloned: Dict[str, Any] = {}
        for key, value in payload.items():
            if isinstance(value, list):
                cloned[key] = list(value)
            else:
                cloned[key] = value
        # normalize lengths
        num_rules = len(cloned.get("rule", []))
        # ensure fields exist with correct lengths
        for field in [
            "is_conjunctive",
            "feature",
            "sampled_values",
            "feature_value",
            "weight",
            "weight_low",
            "weight_high",
        ]:
            if field not in cloned:
                if field == "is_conjunctive":
                    cloned[field] = [False] * num_rules
                else:
                    cloned[field] = [None] * num_rules
        # normalize features
        normalized_features = []
        for feat in cloned["feature"]:
            if isinstance(feat, (list, tuple, np.ndarray)):
                normalized_features.append([int(v) for v in np.asarray(feat).ravel()])
            else:
                normalized_features.append(int(feat))
        cloned["feature"] = normalized_features
        # normalize sampled_values -> list or np.ndarray
        cloned["sampled_values"] = [
            v if isinstance(v, (list, tuple, np.ndarray)) else ([v] if v is not None else [None])
            for v in cloned["sampled_values"]
        ]
        # coerce weights to floats or np.nan
        for key in ["weight", "weight_low", "weight_high"]:
            cloned[key] = [float(x) if x is not None else float("nan") for x in cloned[key]]
        return cloned

    def set_base_prediction(self, predict, low, high):
        """Set the base prediction values."""
        self.state["base_predict"] = [predict]
        self.state["base_predict_low"] = [low]
        self.state["base_predict_high"] = [high]

    def add_rule(
        self,
        predict: float,
        low: float,
        high: float,
        base_predict: float,
        value: str,
        feature: List[int],
        sampled_values: List[Any],
        feature_value: Optional[List[Any]],
        rule_text: str,
        is_conjunctive: bool = True,
        weight: Optional[float] = None,
        weight_low: Optional[float] = None,
        weight_high: Optional[float] = None,
    ):
        """Add a new conjunctive rule to the state."""
        normalized_feature = self._coerce_feature_entry(feature)
        if isinstance(feature_value, np.ndarray):
            feature_value = feature_value.tolist()
        elif isinstance(feature_value, (list, tuple)):
            feature_value = list(feature_value)

        self.state["predict"].append(predict)
        self.state["predict_low"].append(low)
        self.state["predict_high"].append(high)

        if weight is not None:
            self.state["weight"].append(weight)
        else:
            self.state["weight"].append(predict - base_predict)

        if weight_low is not None:
            self.state["weight_low"].append(weight_low)
        else:
            self.state["weight_low"].append(low - base_predict if low != -np.inf else -np.inf)

        if weight_high is not None:
            self.state["weight_high"].append(weight_high)
        else:
            self.state["weight_high"].append(high - base_predict if high != np.inf else np.inf)

        self.state["value"].append(value)
        self.state["feature"].append(normalized_feature)
        self.state["sampled_values"].append(sampled_values)
        self.state["feature_value"].append(feature_value)
        self.state["rule"].append(rule_text)
        self.state["is_conjunctive"].append(is_conjunctive)

        values = sampled_values if not self.dedupe_by_feature_only else None
        self._combination_keys.add(self.get_normalization_key(normalized_feature, values))

    def get_state(self) -> Dict[str, Any]:
        """Return the current state."""
        return self.state

    def get_weights(self) -> np.ndarray:
        """Return weights as numpy array."""
        return np.asarray(self.state["weight"], dtype=float)

    def get_widths(self) -> np.ndarray:
        """Return widths (high - low) as numpy array."""
        return np.asarray(self.state["weight_high"], dtype=float) - np.asarray(
            self.state["weight_low"], dtype=float
        )

    def get_feature(self, index: int) -> Any:
        """Return the feature indices for the rule at ``index``."""
        return self.state["feature"][index]

    def get_sampled_values(self, index: int) -> Any:
        """Return the sampled feature values for the rule at ``index``."""
        return self.state["sampled_values"][index]

    def get_feature_value(self, index: int) -> Any:
        """Return the canonical feature value for the rule at ``index``."""
        return self.state["feature_value"][index]

    def get_value(self, index: int) -> str:
        """Return the rendered textual value for the rule at ``index``."""
        return self.state["value"][index]

    def get_rule(self, index: int) -> str:
        """Return the serialized rule string stored at ``index``."""
        return self.state["rule"][index]

    def is_conjunctive(self, index: int) -> bool:
        """Return ``True`` if the rule at ``index`` is conjunctive."""
        return self.state["is_conjunctive"][index]

    @staticmethod
    def _coerce_feature_entry(feature: Any) -> Union[int, List[int]]:
        if isinstance(feature, (list, tuple, np.ndarray)):
            return [int(v) for v in np.asarray(feature).ravel()]
        return int(feature)

    @staticmethod
    def _normalize_feature_entry(feature: Any) -> Tuple[int, ...]:
        if isinstance(feature, (list, tuple, np.ndarray)):
            return tuple(sorted(int(v) for v in np.asarray(feature).ravel()))
        return (int(feature),)

    @staticmethod
    def _normalize_value_entry(values: Any) -> Tuple[Any, ...]:
        """Normalize sampled values into a hashable signature."""
        if values is None:
            return (None,)
        if isinstance(values, (list, tuple, np.ndarray)):
            # Handle potentially nested structures or numpy types
            return tuple(
                ConjunctionState._normalize_value_entry(v)
                if isinstance(v, (list, tuple, np.ndarray))
                else (float(v) if isinstance(v, (float, np.floating)) else v)
                for v in np.asarray(values).ravel()
            )
        return (values,)

    def get_normalization_key(self, feature: Any, values: Optional[Any] = None) -> Tuple:
        """Create a canonical hashable key for deduplication."""
        f_key = self._normalize_feature_entry(feature)
        if self.dedupe_by_feature_only or values is None:
            return f_key
        v_key = self._normalize_value_entry(values)
        return (f_key, v_key)

    def has_combination_key(self, feature: Any, values: Optional[Any] = None) -> bool:
        """Return whether the combination has already been registered."""
        key = self.get_normalization_key(feature, values)
        return key in self._combination_keys

    def register_combination_key(self, feature: Any, values: Optional[Any] = None) -> None:
        """Register the combination so subsequent calls can test for duplicates."""
        key = self.get_normalization_key(feature, values)
        self._combination_keys.add(key)
