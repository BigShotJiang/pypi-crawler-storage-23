# Changelog / 変更履歴

## Unreleased

## 0.2.0
- (EN) Initial release
- (JA) 初期リリース
