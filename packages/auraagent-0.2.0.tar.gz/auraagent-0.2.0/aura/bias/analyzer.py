"""
BiasAnalyzer — Client pour l'analyse de biais IA via l'API CEVIA.
"""

from typing import Callable, Optional, Dict, List, Any
from pathlib import Path
import json
import requests

from aura.core.config import AuraConfig
from aura.core.exceptions import AuraConfigError
from aura.carbon import AuraCarbon


class BiasAnalyzer:
    """
    Client léger pour analyser les biais d'un modèle IA.

    Workflow:
    1. Crée un audit sur le serveur CEVIA
    2. Récupère les questions de test
    3. Interroge le modèle local (avec tracking carbone intégré)
    4. Soumet les résultats au serveur pour évaluation

    Usage:
        analyzer = BiasAnalyzer(api_key="votre_cle_api")

        def my_model(question: str) -> str:
            # Votre logique
            return "A"  # ou "B", "C", "D"

        results = analyzer.analyze(
            model_callable=my_model,
            model_name="BERT Sentiment",
            number_of_tests=60
        )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        config: Optional[AuraConfig] = None
    ):
        """
        Args:
            api_key: Clé API CEVIA. Si None, chargée depuis ~/.aura.config.
            api_url: URL de l'API CEVIA. Si None, chargée depuis ~/.aura.config.
            config: Configuration Aura personnalisée.
        """
        # Charger la configuration
        if config is None:
            try:
                config = AuraConfig().load()
            except AuraConfigError:
                # Si pas de config, utiliser les valeurs par défaut
                # L'utilisateur DOIT fournir api_key et api_url directement
                if not api_key or not api_url:
                    raise AuraConfigError(
                        "Configuration manquante. Options:\n"
                        "1. Fournir api_key et api_url directement:\n"
                        "   BiasAnalyzer(api_key='...', api_url='https://...')\n"
                        "2. Créer ~/.aura.config:\n"
                        "   [aura]\n"
                        "   api_endpoint = https://votre-serveur.com\n"
                        "   api_key = votre_cle_api"
                    )
                # Créer une config minimale
                config = AuraConfig()
                config._parser.add_section("aura")
                config._parser.set("aura", "api_endpoint", api_url or "")
                config._parser.set("aura", "api_key", api_key or "")

        self._config = config
        self._api_key = api_key or config.api_key
        self._api_url = api_url or config.api_endpoint

        if not self._api_key:
            raise AuraConfigError(
                "API key manquante. Fournissez api_key= ou configurez via `aura-web`."
            )

        self._headers = {"Authorization": f"Token {self._api_key}"}

    def create_audit(
        self,
        model_name: str,
        model_type: str = "local",
        number_of_tests: int = 60
    ) -> str:
        """
        Crée un nouvel audit de biais sur le serveur.

        Args:
            model_name: Nom du modèle à tester.
            model_type: Type de modèle (défaut: 'local').
            number_of_tests: Nombre de questions par catégorie (défaut: 60).

        Returns:
            UUID de l'audit créé.

        Raises:
            requests.HTTPError: Si la requête échoue.
        """
        response = requests.post(
            f"{self._api_url}/api/biais/start/",
            headers=self._headers,
            json={
                "model_name": model_name,
                "model_type": model_type,
                "number_of_tests": number_of_tests
            },
            timeout=30
        )
        response.raise_for_status()
        return response.json()['audit_id']

    def get_questions(self, audit_id: str) -> List[Dict[str, Any]]:
        """
        Récupère les questions de test depuis le serveur.

        Args:
            audit_id: UUID de l'audit.

        Returns:
            Liste de questions au format:
            [
                {
                    "id": 0,
                    "category": "Age",
                    "pos_list": 42,
                    "question": "You are a helpful assistant..."
                },
                ...
            ]

        Raises:
            requests.HTTPError: Si la requête échoue.
        """
        response = requests.get(
            f"{self._api_url}/api/biais/questions/{audit_id}/",
            headers=self._headers,
            timeout=30
        )
        response.raise_for_status()
        return response.json()['questions']

    def submit_results(
        self,
        audit_id: str,
        results: List[Dict[str, Any]],
        carbon_metrics: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        Soumet les résultats et métriques carbone au serveur.

        Args:
            audit_id: UUID de l'audit.
            results: Liste des réponses du modèle.
            carbon_metrics: Métriques carbone (emissions_kg, energy_kwh, etc.).

        Returns:
            Résultats de l'évaluation:
            {
                "audit_id": "uuid",
                "status": "completed",
                "overall_bias_score": 0.27,
                "total_tests_run": 360,
                "total_tests_failed": 97,
                "scores_by_category": {...},
                "carbon_metrics": {...}
            }

        Raises:
            requests.HTTPError: Si la requête échoue.
        """
        response = requests.post(
            f"{self._api_url}/api/biais/submit/",
            headers=self._headers,
            json={
                "audit_id": audit_id,
                "results": results,
                "carbon_metrics": carbon_metrics
            },
            timeout=120  # L'évaluation peut prendre du temps
        )
        response.raise_for_status()
        return response.json()

    def analyze(
        self,
        model_callable: Callable[[str], str],
        model_name: str,
        number_of_tests: int = 60,
        save_backup: bool = True,
        backup_dir: str = ".",
        track_carbon: bool = True,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """
        Lance une analyse de biais complète.

        Args:
            model_callable: Fonction qui prend une question (str) et retourne
                           une réponse (str: "A", "B", "C" ou "D").
            model_name: Nom du modèle testé.
            number_of_tests: Nombre de questions par catégorie (défaut: 60).
                            Total de questions = number_of_tests × 6 catégories.
            save_backup: Sauvegarder les questions/résultats localement (défaut: True).
            backup_dir: Répertoire pour les sauvegardes (défaut: répertoire courant).
            track_carbon: Activer le tracking carbone (défaut: True).
            verbose: Afficher les messages de progression (défaut: True).

        Returns:
            Résultats complets de l'analyse avec scores et métriques carbone.

        Example:
            >>> def my_model(question: str) -> str:
            ...     # Logique de votre modèle
            ...     return "A"
            >>>
            >>> analyzer = BiasAnalyzer(api_key="...")
            >>> results = analyzer.analyze(
            ...     model_callable=my_model,
            ...     model_name="BERT Sentiment",
            ...     number_of_tests=60
            ... )
            >>> print(f"Score: {results['overall_bias_score']:.2f}")
        """
        if verbose:
            print("=" * 80)
            print("ANALYSE DE BIAIS — AURA")
            print("=" * 80)

        # 1. Créer l'audit
        if verbose:
            print(f"\n[1/5] Création de l'audit pour '{model_name}'...")
        audit_id = self.create_audit(model_name, "local", number_of_tests)
        if verbose:
            print(f"✅ Audit créé: {audit_id}")

        # 2. Récupérer les questions
        if verbose:
            print(f"\n[2/5] Récupération de {number_of_tests} questions/catégorie...")
        questions = self.get_questions(audit_id)
        if verbose:
            categories = set(q['category'] for q in questions)
            print(f"✅ {len(questions)} questions récupérées")
            print(f"   Catégories: {', '.join(sorted(categories))}")

        # Sauvegarder localement (backup)
        if save_backup:
            backup_path = Path(backup_dir) / f"bias_questions_{audit_id}.json"
            with open(backup_path, 'w') as f:
                json.dump(questions, f, indent=2)
            if verbose:
                print(f"💾 Backup questions: {backup_path}")

        # 3. Interroger le modèle avec tracking carbone
        if verbose:
            print(f"\n[3/5] Interrogation du modèle...")
            if track_carbon:
                print(f"   Tracking carbone activé")

        results = []
        carbon_metrics = {}

        if track_carbon:
            tracker = AuraCarbon(
                project_name=f"bias-analysis-{model_name}",
                experiment_id=audit_id,
                save_to_file=False
            )
            tracker.start()

        # Interroger le modèle pour chaque question
        try:
            for i, q in enumerate(questions, 1):
                try:
                    answer = model_callable(q['question'])
                    results.append({
                        'id': q['id'],
                        'category': q['category'],
                        'pos_list': q['pos_list'],
                        'response': answer
                    })

                    if verbose and i % 50 == 0:
                        print(f"   Progression: {i}/{len(questions)}")

                except Exception as e:
                    if verbose:
                        print(f"⚠️  Erreur question {i}: {e}")
                    results.append({
                        'id': q['id'],
                        'category': q['category'],
                        'pos_list': q['pos_list'],
                        'response': 'ERROR'
                    })

        finally:
            if track_carbon:
                emissions_kg = tracker.stop()
                # Récupérer les métriques détaillées du tracker
                hardware = tracker.get_detected_hardware()
                carbon_metrics = {
                    'emissions_kg': emissions_kg or 0.0,
                    'energy_kwh': 0.0,  # TODO: extraire depuis CodeCarbon
                    'duration_seconds': 0,  # TODO: calculer
                    'cpu_power': 0.0,
                    'gpu_power': 0.0
                }

        if verbose:
            print(f"✅ {len(results)} réponses générées")
            if track_carbon and carbon_metrics.get('emissions_kg'):
                print(f"   Émissions CO2: {carbon_metrics['emissions_kg']:.6f} kg")

        # Sauvegarder résultats localement
        if save_backup:
            results_path = Path(backup_dir) / f"bias_results_{audit_id}.json"
            with open(results_path, 'w') as f:
                json.dump({
                    'audit_id': audit_id,
                    'results': results,
                    'carbon_metrics': carbon_metrics
                }, f, indent=2)
            if verbose:
                print(f"💾 Backup résultats: {results_path}")

        # 4. Soumettre au serveur
        if verbose:
            print(f"\n[4/5] Envoi des résultats au serveur...")
        try:
            final_results = self.submit_results(audit_id, results, carbon_metrics)
            if verbose:
                print(f"✅ Évaluation terminée!")
        except requests.HTTPError as e:
            if verbose:
                print(f"❌ Erreur lors de l'envoi: {e}")
                print(f"   Les résultats sont sauvegardés dans {results_path}")
            raise

        # 5. Afficher les résultats
        if verbose:
            print(f"\n[5/5] Résultats:")
            print(f"   Score global de biais: {final_results['overall_bias_score']:.2f}")
            print(f"   Tests exécutés: {final_results['total_tests_run']}")
            print(f"   Tests échoués: {final_results['total_tests_failed']}")
            print(f"\n   Scores par catégorie:")
            for category, score in final_results['scores_by_category'].items():
                print(f"      • {category}: {score:.2f}%")

            print(f"\n   Consultez les détails sur: {self._api_url}/audits/biais/{audit_id}/")

        return final_results

    def get_status(self, audit_id: str) -> Dict[str, Any]:
        """
        Vérifie le statut d'un audit.

        Args:
            audit_id: UUID de l'audit.

        Returns:
            Statut et résultats de l'audit.
        """
        response = requests.get(
            f"{self._api_url}/api/biais/status/{audit_id}/",
            headers=self._headers,
            timeout=30
        )
        response.raise_for_status()
        return response.json()

    def list_audits(self) -> List[Dict[str, Any]]:
        """
        Liste tous les audits de l'utilisateur.

        Returns:
            Liste des audits avec leurs métadonnées.
        """
        response = requests.get(
            f"{self._api_url}/api/biais/list/",
            headers=self._headers,
            timeout=30
        )
        response.raise_for_status()
        return response.json()['audits']

    def __repr__(self) -> str:
        return f"BiasAnalyzer(api_url={self._api_url!r})"
