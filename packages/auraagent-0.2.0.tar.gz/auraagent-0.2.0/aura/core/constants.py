"""
Constantes globales du package Aura.

AURA_SERVER_URL est l'unique point d'entrée hardcodé.
Toutes les autres URLs sont retournées par le serveur après authentification.

Pour tester en local ou sur un réseau privé, définir la variable d'environnement :
    export AURA_SERVER_URL=http://192.168.1.42:8000
avant de lancer aura-web, ou créer un fichier .env dans le répertoire courant.
"""

import os

# URL du serveur Aura — peut être surchargée par variable d'environnement
# Utile pour tester en local : export AURA_SERVER_URL=http://127.0.0.1:8000
AURA_SERVER_URL = os.environ.get("AURA_SERVER_URL", "https://cevia.ai")

# Endpoints relatifs (construits sur AURA_SERVER_URL)
AUTH_VERIFY_ENDPOINT      = "/api/auth/verify/"
MACHINE_REGISTER_ENDPOINT = "/api/machines/register/"

# Nom du fichier de configuration local
CONFIG_FILENAME = ".aura.config"
CONFIG_SECTION  = "aura"
