"""
Authentification avec le serveur Aura.

Flux complet :
    1. verify()         → POST /api/auth/verify/  (email + api_key)
                          Retourne : api_endpoint, user_id, organization, default_project

    2. register_machine() → POST /api/machines/register/  (infos machine)
                            Retourne : machine_id (UUID)

    3. login_and_save() → Orchestre les deux étapes et écrit ~/.aura.config
"""

import requests
from typing import Optional

from aura.core.constants import (
    AURA_SERVER_URL,
    AUTH_VERIFY_ENDPOINT,
    MACHINE_REGISTER_ENDPOINT,
)
from aura.core.config import AuraConfig
from aura.core.models import LoginRequest, LoginResponse, MachineInfo, MachineRegisterResponse
from aura.core.exceptions import AuraAuthError, AuraAPIError


class AuraAuth:
    """Client d'authentification vers le serveur Aura/Django."""

    def __init__(self, server_url: str = AURA_SERVER_URL):
        self.server_url = server_url.rstrip("/")
        self._verify_url   = f"{self.server_url}{AUTH_VERIFY_ENDPOINT}"
        self._register_url = f"{self.server_url}{MACHINE_REGISTER_ENDPOINT}"

    # ─── Étape 1 : vérification email + api_key ───────────────────────────────

    def verify(self, email: str, api_key: str) -> LoginResponse:
        """
        Vérifie les credentials et récupère la configuration depuis le serveur.

        Args:
            email:   Email de l'utilisateur
            api_key: Clé API générée depuis le dashboard

        Returns:
            LoginResponse contenant api_endpoint, user_id, organization, etc.

        Raises:
            AuraAuthError: Credentials invalides (401)
            AuraAPIError:  Erreur serveur ou réseau
        """
        payload = LoginRequest(email=email, api_key=api_key)

        try:
            response = requests.post(
                self._verify_url,
                json=payload.model_dump(),
                timeout=10,
            )
        except requests.ConnectionError:
            raise AuraAPIError(
                f"Impossible de joindre le serveur : {self.server_url}\n"
                "Vérifiez votre connexion internet."
            )
        except requests.Timeout:
            raise AuraAPIError("Le serveur n'a pas répondu (timeout).")

        if response.status_code == 401:
            raise AuraAuthError("Email ou clé API incorrect.")

        if not response.ok:
            raise AuraAPIError(
                f"Erreur serveur ({response.status_code})",
                status_code=response.status_code,
            )

        return LoginResponse(**response.json())

    # ─── Étape 2 : enregistrement de la machine ───────────────────────────────

    def register_machine(
        self,
        api_key: str,
        machine_info: Optional[MachineInfo] = None,
    ) -> MachineRegisterResponse:
        """
        Enregistre la machine locale sur le serveur.
        Si la machine est déjà connue (même hostname + OS), retourne son UUID existant.

        Args:
            api_key:      Clé API pour authentifier la requête
            machine_info: Infos machine. Si None, collectées automatiquement.

        Returns:
            MachineRegisterResponse avec machine_id (UUID)

        Raises:
            AuraAPIError: Erreur serveur ou réseau
        """
        if machine_info is None:
            machine_info = MachineInfo.collect()

        try:
            response = requests.post(
                self._register_url,
                json=machine_info.model_dump(),
                headers={"Authorization": f"Token {api_key}"},
                timeout=10,
            )
        except requests.ConnectionError:
            raise AuraAPIError("Impossible de joindre le serveur pour enregistrer la machine.")
        except requests.Timeout:
            raise AuraAPIError("Timeout lors de l'enregistrement de la machine.")

        if not response.ok:
            raise AuraAPIError(
                f"Erreur lors de l'enregistrement de la machine ({response.status_code})",
                status_code=response.status_code,
            )

        return MachineRegisterResponse(**response.json())

    # ─── Flux complet ─────────────────────────────────────────────────────────

    def login_and_save(
        self,
        email: str,
        api_key: str,
        config: Optional[AuraConfig] = None,
    ) -> AuraConfig:
        """
        Orchestre le flux complet de première connexion :
            1. Vérifie email + api_key → récupère config serveur
            2. Enregistre la machine → récupère machine_id
            3. Écrit ~/.aura.config

        Args:
            email:   Email de l'utilisateur
            api_key: Clé API générée depuis le dashboard
            config:  AuraConfig cible. Si None, utilise ~/.aura.config

        Returns:
            AuraConfig chargée et prête à l'emploi.
        """
        # Étape 1 — vérification
        login_response = self.verify(email=email, api_key=api_key)

        # Étape 2 — enregistrement machine
        machine_response = self.register_machine(api_key=api_key)

        # Étape 3 — écriture config
        if config is None:
            config = AuraConfig()

        config.write({
            "api_endpoint":    login_response.api_endpoint,
            "api_key":         api_key,
            "user_id":         login_response.user_id,
            "organization":    login_response.organization or "",
            "default_project": login_response.default_project or "",
            "machine_id":      machine_response.machine_id,
        })

        return config
