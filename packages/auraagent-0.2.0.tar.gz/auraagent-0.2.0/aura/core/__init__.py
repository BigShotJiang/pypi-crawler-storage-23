"""
aura.core — Utilitaires partagés entre les composants.

Modules :
    - config   : Lecture/écriture de ~/.aura.config
    - auth     : Authentification avec le serveur Aura
    - logging  : Configuration du logger aura
    - models   : Modèles de données Pydantic partagés
    - exceptions : Exceptions personnalisées
"""

from aura.core.config import AuraConfig
from aura.core.exceptions import AuraConfigError, AuraAuthError, AuraAPIError

__all__ = [
    "AuraConfig",
    "AuraConfigError",
    "AuraAuthError",
    "AuraAPIError",
]
