"""
Gestion de la configuration locale ~/.aura.config.

Format INI :
    [aura]
    api_endpoint    = http://192.168.1.42:8000/api
    api_key         = tok_xxxxxxxxxxxx
    user_id         = uuid-user
    machine_id      = uuid-machine
    organization    = CEVIA
    default_project = mon-projet
"""

import configparser
from pathlib import Path
from typing import Optional

from aura.core.exceptions import AuraConfigError

# Chemin du fichier de configuration
CONFIG_PATH = Path.home() / ".aura.config"
CONFIG_SECTION = "aura"


class AuraConfig:
    """Lecture et écriture de la configuration locale Aura."""

    def __init__(self, config_path: Path = CONFIG_PATH):
        self._path = config_path
        self._parser = configparser.ConfigParser()

    # ─── Chargement ───────────────────────────────────────────────────────────

    def load(self) -> "AuraConfig":
        """Charge le fichier de configuration. Lève AuraConfigError si absent."""
        if not self._path.exists():
            raise AuraConfigError(
                f"Fichier de configuration introuvable : {self._path}\n"
                "Créez un fichier ~/.aura.config avec :\n"
                "[aura]\n"
                "api_endpoint = http://192.168.1.42:8000/api\n"
                "api_key = votre_cle_api\n"
                "default_project = mon-projet"
            )
        self._parser.read(self._path)
        return self

    def exists(self) -> bool:
        """Retourne True si le fichier de config existe."""
        return self._path.exists()

    # ─── Accesseurs ───────────────────────────────────────────────────────────

    def get(self, key: str, fallback: Optional[str] = None) -> Optional[str]:
        """Lit une valeur de configuration."""
        return self._parser.get(CONFIG_SECTION, key, fallback=fallback)

    @property
    def api_endpoint(self) -> str:
        val = self.get("api_endpoint")
        if not val:
            raise AuraConfigError("api_endpoint manquant dans ~/.aura.config")
        return val

    @property
    def api_key(self) -> str:
        val = self.get("api_key")
        if not val:
            raise AuraConfigError("api_key manquant dans ~/.aura.config")
        return val

    @property
    def user_id(self) -> Optional[str]:
        return self.get("user_id")

    @property
    def organization(self) -> Optional[str]:
        return self.get("organization")

    @property
    def default_project(self) -> Optional[str]:
        return self.get("default_project")

    @property
    def machine_id(self) -> Optional[str]:
        return self.get("machine_id")

    # ─── Écriture ─────────────────────────────────────────────────────────────

    def write(self, data: dict) -> None:
        """
        Écrit la configuration depuis un dict.

        Args:
            data: Dictionnaire clé/valeur reçu du serveur après login.
                  Ex: { "api_endpoint": "...", "api_key": "...", ... }
        """
        if not self._parser.has_section(CONFIG_SECTION):
            self._parser.add_section(CONFIG_SECTION)

        for key, value in data.items():
            self._parser.set(CONFIG_SECTION, key, str(value))

        with open(self._path, "w") as f:
            self._parser.write(f)

    def save(self) -> None:
        """Sauvegarde la configuration courante dans le fichier."""
        with open(self._path, "w") as f:
            self._parser.write(f)

    def delete(self) -> None:
        """Supprime le fichier de configuration (logout)."""
        if self._path.exists():
            self._path.unlink()

    # ─── Représentation ───────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        """Retourne la config sous forme de dict (sans api_key en clair)."""
        if not self._parser.has_section(CONFIG_SECTION):
            return {}
        return {
            key: ("●●●●●●●●" if key == "api_key" else val)
            for key, val in self._parser.items(CONFIG_SECTION)
        }

    def __repr__(self) -> str:
        return f"AuraConfig(path={self._path}, exists={self.exists()})"
