"""
    AuraOutput — Sortie HTTP vers le serveur Aura/Django.

    Hérite de BaseOutput (CodeCarbon) et envoie les données
    d'émissions à l'endpoint /api/emissions/ du serveur.
"""

import requests
from typing import Optional

from codecarbon.output_methods.base_output import BaseOutput
from codecarbon.output_methods.emissions_data import EmissionsData

from aura.core.config import AuraConfig
from aura.core.exceptions import AuraAPIError


class AuraOutput(BaseOutput):
    """
        Output CodeCarbon qui envoie les données vers le serveur Aura.

        Appelé automatiquement par CodeCarbon à chaque :
            - live_out() : toutes les api_call_interval mesures (temps réel)
            - out()      : à stop() ou flush()
    """

    def __init__(self, config: Optional[AuraConfig] = None):
        """
            Args:
                config: AuraConfig chargée. Si None, chargée automatiquement
                        depuis ~/.aura.config.
        """
        if config is None:
            config = AuraConfig().load()

        self._endpoint = f"{config.api_endpoint.rstrip('/')}/emissions/"
        self._headers = {
            "Authorization": f"Token {config.api_key}",
            "Content-Type": "application/json",
        }

    # ─── Interface BaseOutput ─────────────────────────────────────────────────

    def out(self, total: EmissionsData, delta: EmissionsData) -> None:
        """Appelé à stop() ou flush() — envoie les données cumulatives."""
        self._send(total)

    def live_out(self, total: EmissionsData, delta: EmissionsData) -> None:
        """Appelé périodiquement pendant le run — envoie le delta."""
        self._send(delta)

    def task_out(self, data, experiment_name: str) -> None:
        """Appelé à stop() si des tâches ont été trackées."""
        # Optionnel : envoyer les tâches séparément
        pass

    def exit(self) -> None:
        """Cleanup à la fin du tracking."""
        pass

    # ─── Envoi HTTP ───────────────────────────────────────────────────────────

    def _send(self, data: EmissionsData) -> None:
        """
            Envoie un objet EmissionsData au serveur.

            En cas d'erreur réseau ou serveur, on logue sans planter
            le code utilisateur.
        """
        try:
            payload = self._to_dict(data)
            response = requests.post(
                self._endpoint,
                json=payload,
                headers=self._headers,
                timeout=10,
            )
            if not response.ok:
                print(
                    f"[Aura] Avertissement : l'envoi des émissions a échoué "
                    f"({response.status_code})"
                )
        except requests.ConnectionError:
            print("[Aura] Avertissement : impossible de joindre le serveur.")
        except requests.Timeout:
            print("[Aura] Avertissement : timeout lors de l'envoi des émissions.")
        except Exception as e:
            print(f"[Aura] Avertissement : erreur inattendue lors de l'envoi : {e}")

    @staticmethod
    def _to_dict(data: EmissionsData) -> dict:
        """Convertit EmissionsData en dict JSON-sérialisable."""
        return {
            "run_id": str(data.run_id),
            "project_name": data.project_name,
            "experiment_id": str(data.experiment_id) if data.experiment_id else None,
            "timestamp": data.timestamp,
            "duration": data.duration,
            "emissions": data.emissions,
            "emissions_rate": data.emissions_rate,
            "energy_consumed": data.energy_consumed,
            "cpu_power": data.cpu_power,
            "gpu_power": data.gpu_power,
            "ram_power": data.ram_power,
            "cpu_energy": data.cpu_energy,
            "gpu_energy": data.gpu_energy,
            "ram_energy": data.ram_energy,
            "cpu_utilization_percent": getattr(data, "cpu_utilization_percent", None),
            "gpu_utilization_percent": getattr(data, "gpu_utilization_percent", None),
            "ram_utilization_percent": getattr(data, "ram_utilization_percent", None),
            "ram_used_gb": getattr(data, "ram_used_gb", None),
            "country_name": data.country_name,
            "country_iso_code": data.country_iso_code,
            "region": data.region,
            "cloud_provider": data.cloud_provider,
            "cloud_region": data.cloud_region,
            "on_cloud": data.on_cloud,
            "os": data.os,
            "python_version": data.python_version,
            "codecarbon_version": data.codecarbon_version,
            "cpu_model": data.cpu_model,
            "cpu_count": data.cpu_count,
            "gpu_model": data.gpu_model,
            "gpu_count": data.gpu_count,
            "ram_total_size": data.ram_total_size,
            "tracking_mode": data.tracking_mode,
            "pue": data.pue,
            "wue": getattr(data, "wue", 0.0),
        }
