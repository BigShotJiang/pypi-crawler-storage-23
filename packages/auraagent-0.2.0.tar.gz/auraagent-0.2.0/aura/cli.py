"""
CLI Aura — commande `aura`

Commandes disponibles :
    aura init         → Configure Aura (API key, serveur)
    aura status       → Affiche la configuration courante
    aura logout       → Supprime la configuration locale
    aura version      → Affiche la version
"""

import click
import requests
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()


@click.group()
@click.version_option(package_name="aura", prog_name="aura")
def main():
    """Aura — Carbon tracking and AI bias analysis toolkit."""
    pass


@main.command()
def init():
    """Configure Aura (connexion au serveur CEVIA)."""
    from aura.core.config import AuraConfig
    from aura.core.exceptions import AuraConfigError

    console.print(Panel.fit(
        "[bold cyan]🔧 Configuration d'Aura — CEVIA[/bold cyan]",
        border_style="cyan"
    ))
    console.print()

    # Valeurs par défaut pour l'environnement de développement
    api_url = "http://localhost:8000"
    default_project = "aura-default"

    # Vérifier si une config existe déjà
    cfg = AuraConfig()
    if cfg.exists():
        console.print("[yellow]⚠️  Un fichier de configuration existe déjà.[/yellow]")
        if not click.confirm("Voulez-vous le mettre à jour ?", default=False):
            console.print("[dim]Configuration annulée.[/dim]")
            return
        console.print()

    # 1. Demander la clé API
    console.print("[bold]Étape 1/3[/bold] — Clé API")
    api_key = click.prompt("  Entrez votre clé API CEVIA", type=str)
    console.print()

    # 2. Vérifier la connexion avec le serveur
    console.print("[bold]Étape 2/3[/bold] — Vérification de la connexion")
    console.print(f"  URL du serveur : [cyan]{api_url}[/cyan]")

    try:
        with console.status("[bold cyan]Vérification en cours...[/bold cyan]"):
            response = requests.get(
                f"{api_url}/api/auth/verify-token/",
                headers={"Authorization": f"Token {api_key}"},
                timeout=10
            )

        if response.status_code == 200:
            console.print("  [green]✓[/green] Authentification réussie !")
            user_data = response.json()
            console.print(f"  [dim]Connecté en tant que : {user_data.get('username', 'N/A')}[/dim]")
            if user_data.get('organization'):
                console.print(f"  [dim]Organisation : {user_data.get('organization')}[/dim]")
        else:
            console.print(f"  [red]✗[/red] Erreur d'authentification (code {response.status_code})")
            console.print(f"  [dim]{response.text}[/dim]")
            if not click.confirm("\nContinuer malgré l'erreur ?", default=False):
                console.print("[yellow]Configuration annulée.[/yellow]")
                return

    except requests.exceptions.RequestException as e:
        console.print(f"  [red]✗[/red] Impossible de contacter le serveur")
        console.print(f"  [dim]Erreur : {e}[/dim]")
        if not click.confirm("\nContinuer malgré l'erreur ?", default=False):
            console.print("[yellow]Configuration annulée.[/yellow]")
            return

    console.print()

    # 3. Créer/mettre à jour ~/.aura.config
    console.print("[bold]Étape 3/3[/bold] — Sauvegarde de la configuration")

    try:
        # Créer la configuration
        if not cfg._parser.has_section("aura"):
            cfg._parser.add_section("aura")

        cfg._parser.set("aura", "api_endpoint", api_url)
        cfg._parser.set("aura", "api_key", api_key)
        cfg._parser.set("aura", "default_project", default_project)

        # Sauvegarder
        cfg.save()
        console.print(f"  [green]✓[/green] Configuration sauvegardée dans : [cyan]~/.aura.config[/cyan]")

    except Exception as e:
        console.print(f"  [red]✗[/red] Erreur lors de la sauvegarde : {e}")
        return

    console.print()

    # 4. Afficher un résumé
    console.print(Panel(
        f"[green]✓ Configuration terminée ![/green]\n\n"
        f"[bold]Résumé :[/bold]\n"
        f"  • URL API      : [cyan]{api_url}[/cyan]\n"
        f"  • Clé API      : [dim]{api_key[:10]}...[/dim]\n"
        f"  • Projet       : [cyan]{default_project}[/cyan]\n\n"
        f"[bold]Prochaines étapes :[/bold]\n"
        f"  • Tracking carbone  : [cyan]from aura import AuraCarbon[/cyan]\n"
        f"  • Analyse de biais  : [cyan]from aura import BiasAnalyzer[/cyan]\n"
        f"  • Voir la config    : [cyan]aura status[/cyan]",
        title="[bold green]Configuration réussie[/bold green]",
        border_style="green"
    ))


@main.command()
def status():
    """Affiche la configuration locale courante."""
    from aura.core.config import AuraConfig
    from aura.core.exceptions import AuraConfigError

    cfg = AuraConfig()
    if not cfg.exists():
        console.print("[yellow]Aucune configuration trouvée.[/yellow]")
        console.print("Lancez [bold]aura init[/bold] pour configurer Aura.")
        return

    cfg.load()
    data = cfg.to_dict()

    table = Table(title="Configuration Aura", show_header=False, border_style="dim")
    table.add_column("Clé", style="cyan")
    table.add_column("Valeur")
    for key, val in data.items():
        table.add_row(key, str(val))
    console.print(table)


@main.command()
def logout():
    """Supprime la configuration locale (déconnexion)."""
    from aura.core.config import AuraConfig

    cfg = AuraConfig()
    if not cfg.exists():
        console.print("[yellow]Aucune configuration à supprimer.[/yellow]")
        return

    if click.confirm("Supprimer la configuration locale (~/.aura.config) ?"):
        cfg.delete()
        console.print("[green]Déconnecté.[/green]")


if __name__ == "__main__":
    main()
