# Configuration - auraagent

## 📋 Méthodes de Configuration

Il existe **deux méthodes** pour configurer auraagent:

### Méthode 1: Fichier de configuration (Recommandé)

Créez un fichier `~/.aura.config` avec le contenu suivant:

```ini
[aura]
api_endpoint = https://cevia.ai
api_key = votre_cle_api_ici
default_project = mon-projet
```

**Avantages:**
- ✅ Configuration une seule fois
- ✅ Pas besoin de passer les paramètres à chaque fois
- ✅ Sécurisé (fichier local)

**Création du fichier:**

```bash
# Linux/macOS
cat > ~/.aura.config << EOF
[aura]
api_endpoint = https://cevia.ai
api_key = votre_cle_api
default_project = mon-projet
EOF

# Windows PowerShell
@"
[aura]
api_endpoint = https://cevia.ai
api_key = votre_cle_api
default_project = mon-projet
"@ | Out-File -FilePath "$env:USERPROFILE\.aura.config" -Encoding utf8
```

---

### Méthode 2: Paramètres directs

Passez les paramètres directement lors de l'initialisation:

```python
from aura.bias import BiasAnalyzer
from aura.carbon import AuraCarbon

# Analyse de biais
analyzer = BiasAnalyzer(
    api_key="votre_cle_api",
    api_url="https://cevia.ai"
)

# Tracking carbone (nécessite un config object)
from aura.core.config import AuraConfig

config = AuraConfig()
config._parser.add_section("aura")
config._parser.set("aura", "api_endpoint", "https://cevia.ai")
config._parser.set("aura", "api_key", "votre_cle_api")

tracker = AuraCarbon(config=config)
```

**Avantages:**
- ✅ Flexibilité (plusieurs configs)
- ✅ Pas de fichier à créer
- ✅ Idéal pour scripts/CI/CD

---

## 🔑 Obtenir une Clé API

1. Connectez-vous sur https://cevia.ai
2. Allez dans **Paramètres** → **API Keys**
3. Cliquez sur **Nouvelle clé API**
4. Copiez la clé (elle ne sera affichée qu'une fois)
5. Utilisez-la dans votre configuration

---

## 📝 Paramètres de Configuration

### Obligatoires

| Paramètre | Description | Exemple |
|-----------|-------------|---------|
| `api_endpoint` | URL du serveur CEVIA | `https://cevia.ai` |
| `api_key` | Clé d'authentification | `aura_abc123...` |

### Optionnels

| Paramètre | Description | Défaut |
|-----------|-------------|--------|
| `default_project` | Nom du projet par défaut | `"aura-default"` |
| `user_id` | ID utilisateur | Auto |
| `machine_id` | ID machine | Auto |
| `organization` | Nom organisation | Auto |

---

## ✅ Vérifier la Configuration

```python
from aura.core.config import AuraConfig

# Charger et vérifier
config = AuraConfig()
if config.exists():
    config.load()
    print("✅ Configuration OK")
    print(f"API Endpoint: {config.api_endpoint}")
    print(f"Default Project: {config.default_project}")
else:
    print("❌ Fichier ~/.aura.config introuvable")
```

---

## 🔒 Sécurité

**Bonnes pratiques:**

1. ✅ **Ne commitez JAMAIS** votre `.aura.config` dans git
2. ✅ Ajoutez `.aura.config` dans `.gitignore`
3. ✅ Utilisez des variables d'environnement en production:

```python
import os
from aura.bias import BiasAnalyzer

analyzer = BiasAnalyzer(
    api_key=os.getenv("AURA_API_KEY"),
    api_url=os.getenv("AURA_API_URL", "https://cevia.ai")
)
```

4. ✅ Révoquez les clés compromises immédiatement sur le dashboard CEVIA

---

## 🛠️ Dépannage

### Erreur: "Fichier de configuration introuvable"

**Solution 1:** Créez `~/.aura.config` (voir Méthode 1)

**Solution 2:** Passez les paramètres directement:
```python
BiasAnalyzer(api_key="...", api_url="https://...")
```

### Erreur: "api_key manquant"

Vérifiez que votre fichier contient:
```ini
[aura]
api_key = votre_cle_ici
```

### Erreur: "Authentication credentials were not provided"

- ✅ Vérifiez que votre clé API est valide
- ✅ Vérifiez qu'elle n'a pas expiré
- ✅ Testez avec `curl`:

```bash
curl -H "Authorization: Token votre_cle_api" https://cevia.ai/api/auth/verify/
```

---

## 📖 Exemples Complets

### Exemple 1: Configuration fichier + Bias Analysis

```python
from aura.bias import BiasAnalyzer

def my_model(question: str) -> str:
    return "A"

# Charge automatiquement depuis ~/.aura.config
analyzer = BiasAnalyzer()

results = analyzer.analyze(
    model_callable=my_model,
    model_name="Mon Modèle",
    number_of_tests=60
)
```

### Exemple 2: Configuration directe + Carbon Tracking

```python
from aura.carbon import AuraCarbon
from aura.core.config import AuraConfig

# Créer config programmatiquement
config = AuraConfig()
config._parser.add_section("aura")
config._parser.set("aura", "api_endpoint", "https://cevia.ai")
config._parser.set("aura", "api_key", "aura_abc123...")
config._parser.set("aura", "default_project", "mon-projet")

# Utiliser
tracker = AuraCarbon(config=config)
tracker.start()

# ... votre code ...

emissions = tracker.stop()
print(f"Émissions: {emissions} kg CO2")
```

### Exemple 3: CI/CD avec variables d'environnement

```python
import os
from aura.bias import BiasAnalyzer

# GitHub Actions, GitLab CI, etc.
analyzer = BiasAnalyzer(
    api_key=os.environ["CEVIA_API_KEY"],  # Secret configuré dans CI
    api_url="https://cevia.ai"
)
```

---

**Version:** auraagent 0.2.0
**Date:** 2026-02-20
