"""Tests du composant carbon."""

import pytest
from unittest.mock import patch, MagicMock
from aura.core.config import AuraConfig
from aura.core.exceptions import AuraConfigError


def test_aura_config_not_found(tmp_path):
    """AuraConfig lève AuraConfigError si le fichier est absent."""
    cfg = AuraConfig(config_path=tmp_path / ".aura.config")
    with pytest.raises(AuraConfigError):
        cfg.load()


def test_aura_config_write_and_read(tmp_path):
    """AuraConfig écrit et relit correctement."""
    path = tmp_path / ".aura.config"
    cfg = AuraConfig(config_path=path)
    cfg.write({
        "api_endpoint": "https://test.cevia.io/api",
        "api_key": "tok_test123",
        "user_id": "uuid-123",
    })
    cfg.load()
    assert cfg.api_endpoint == "https://test.cevia.io/api"
    assert cfg.api_key == "tok_test123"


def test_aura_config_to_dict_masks_api_key(tmp_path):
    """Le api_key ne doit pas apparaître en clair dans to_dict()."""
    path = tmp_path / ".aura.config"
    cfg = AuraConfig(config_path=path)
    cfg.write({"api_endpoint": "https://test.io", "api_key": "secret"})
    cfg.load()
    d = cfg.to_dict()
    assert d["api_key"] != "secret"
    assert "●" in d["api_key"]


def test_aura_config_delete(tmp_path):
    """AuraConfig.delete() supprime bien le fichier."""
    path = tmp_path / ".aura.config"
    cfg = AuraConfig(config_path=path)
    cfg.write({"api_key": "x"})
    assert cfg.exists()
    cfg.delete()
    assert not cfg.exists()
