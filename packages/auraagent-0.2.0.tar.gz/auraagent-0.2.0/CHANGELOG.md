# Changelog - auraagent

## [0.2.0] - 2026-02-20

### ✨ Nouveau module: Analyse de Biais

**Ajout du module `aura.bias` pour l'analyse de biais des modèles IA.**

#### Nouvelles fonctionnalités

- **BiasAnalyzer**: Client léger pour analyser les biais algorithmiques
  - Récupère automatiquement les questions depuis le serveur CEVIA
  - Interroge le modèle client localement (préserve la confidentialité)
  - Tracking carbone intégré pendant l'analyse
  - Évaluation serveur-side avec 6 catégories de biais:
    - Age
    - Gender_identity
    - Religion
    - Race_ethnicity
    - Sexual_orientation
    - Disability_status
  - Sauvegarde locale automatique (questions + résultats)
  - Interface simple: `analyzer.analyze(model_callable, model_name)`

#### Architecture simplifiée

- **Pas de fichiers JSONL dans le package** → Package léger (~34 KB)
- **Questions générées côté serveur** → Toujours à jour
- **Évaluation côté serveur** → Propriété intellectuelle préservée
- **Workflow client-serveur**:
  1. `POST /api/biais/start/` - Créer audit
  2. `GET /api/biais/questions/<uuid>/` - Récupérer questions
  3. Client interroge son modèle local
  4. `POST /api/biais/submit/` - Envoyer résultats + carbone
  5. Serveur évalue et stocke

#### Exemple d'utilisation

```python
from aura.bias import BiasAnalyzer

def my_model(question: str) -> str:
    # Votre logique de modèle IA
    return "A"  # ou "B", "C", "D"

analyzer = BiasAnalyzer(api_key="votre_cle_api")
results = analyzer.analyze(
    model_callable=my_model,
    model_name="Mon Modèle IA",
    number_of_tests=60
)

print(f"Score de biais: {results['overall_bias_score']:.2f}")
print(f"Émissions CO2: {results['carbon_metrics']['emissions_kg']:.4f} kg")
```

### 📝 Modifications

- `aura/__init__.py`: Ajout de `BiasAnalyzer` aux exports publics
- `pyproject.toml`:
  - Version 0.1.3 → 0.2.0
  - Description mise à jour
  - Keywords ajoutés: `bias`, `fairness`
- Nouveaux fichiers:
  - `aura/bias/__init__.py`
  - `aura/bias/analyzer.py` (450+ lignes)
  - `examples/bias_analysis_example.py`
  - `tests/test_bias_analyzer.py`

### 📦 Taille du package

- **v0.1.3**: 30 KB (wheel)
- **v0.2.0**: 34 KB (wheel) - **+4 KB seulement**

---

## [0.1.3] - 2026-02-17

### 🐛 Corrections

- Fix `aura_version` dans `output.py` (version("aura") → version("auraagent"))
- Fix authentification API avec `select_related('organization')`
- Fix `MachineSerializer` pour accepter `null` sur champs optionnels

### 📝 Modifications

- Préparation pour publication PyPI
- Documentation README mise à jour

---

## [0.1.0] - 2026-02-16

### 🎉 Release initiale

- Module `aura.carbon`: Tracking d'émissions CO2
- Module `aura.web`: Interface web locale (FastAPI)
- Module `aura.core`: Utilitaires (config, auth, logging)
- CLI `aura` et `aura-web`
- Intégration avec CodeCarbon
- Envoi automatique vers serveur CEVIA
