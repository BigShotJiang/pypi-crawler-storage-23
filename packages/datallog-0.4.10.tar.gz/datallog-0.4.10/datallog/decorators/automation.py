from functools import wraps
from typing import Callable
from datallog.utils import set_automation_callable


def automation() -> Callable:
    """
    Decorator to mark a function as a automation.
    """

    def decorator(func):
        set_automation_callable(func.__name__, func)

        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    return decorator
