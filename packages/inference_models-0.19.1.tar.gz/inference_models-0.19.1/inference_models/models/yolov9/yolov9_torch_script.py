from inference_models.models.yolov8.yolov8_object_detection_torch_script import (
    YOLOv8ForObjectDetectionTorchScript,
)


class YOLOv9ForObjectDetectionTorchScript(YOLOv8ForObjectDetectionTorchScript):
    pass
