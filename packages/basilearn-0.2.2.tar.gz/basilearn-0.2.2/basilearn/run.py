# basilearn/run.py

from basilearn.basilearn import Basilearn

def main():
    # Create an instance of the Basilearn class
    basilearn = Basilearn()

    # Call it to run the program
    basilearn()
