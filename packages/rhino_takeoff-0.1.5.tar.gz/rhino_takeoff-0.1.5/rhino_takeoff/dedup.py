import logging
from typing import List, Dict, Any, Optional

try:
    import Rhino.Geometry as rg  # type: ignore  # noqa: F401

    IS_RHINO = True
except ImportError:
    import rhino3dm as rg

    IS_RHINO = False

try:
    from shapely.geometry import box
    from shapely.ops import unary_union

    HAS_SHAPELY = True
except ImportError:
    HAS_SHAPELY = False

logger = logging.getLogger(__name__)


class Deduplicator:
    """
    Handles geometric Deduplication to remove overlapping quantities.
    Typically used to subtract Column areas/volumes from Slabs or Walls.
    """

    def __init__(self, tolerance: float = 1.0):
        """
        Args:
            tolerance: Tolerance value for intersection checks.
        """
        self.tolerance = tolerance
        self.report: Dict[str, Any] = {}

    def remove_overlap(
        self,
        targets: List[Any],
        cutters: List[Any],
        tolerance: Optional[float] = None,
    ) -> List[Any]:
        """
        Removes overlaps in `targets` caused by `cutters`.

        In RhinoCommon environment, this performs actual Boolean Difference.
        In rhino3dm environment, this falls back to 2D footprint intersection (Shapely) or AABB check.

        Args:
            targets: List of geometry objects to be modified/checked (e.g., Slabs).
            cutters: List of geometry objects that cut the targets (e.g., Columns).
            tolerance: Optional tolerance override.

        Returns:
            List of modified or annotated geometry objects.
        """
        tol = tolerance if tolerance is not None else self.tolerance

        if IS_RHINO:
            return self._remove_overlap_rhino(targets, cutters, tol)
        else:
            return self._remove_overlap_fallback(targets, cutters, tol)

    def _remove_overlap_rhino(self, targets, cutters, tolerance):
        """Implementation using RhinoCommon BooleanDifference."""
        results = []
        overlap_count = 0

        for t in targets:
            current = t
            for c in cutters:
                try:
                    diffs = rg.Brep.CreateBooleanDifference([current], [c], tolerance)
                    if diffs and len(diffs) > 0:
                        current = diffs[0]
                        overlap_count += 1
                except Exception as e:
                    logger.warning(
                        f"Boolean operation failed for {getattr(t, 'Id', '?')}: {e}"
                    )
            results.append(current)

        self.report = {
            "mode": "RhinoCommon Boolean",
            "overlap_count": overlap_count,
            "removed_area_m2": 0.0,
            "note": "Geometry modified directly",
        }
        return results

    def _remove_overlap_fallback(self, targets, cutters, tolerance):
        """Implementation using rhino3dm and Shapely (2D Approximation)."""
        touched_ids = []
        removed_area_total = 0.0

        if HAS_SHAPELY:
            cutter_polys = []
            for c in cutters:
                bbox = c.GetBoundingBox(True)
                poly = box(bbox.Min.X, bbox.Min.Y, bbox.Max.X, bbox.Max.Y)
                cutter_polys.append(poly)

            if not cutter_polys:
                self.report = {
                    "overlap_count": 0,
                    "removed_area_m2": 0.0,
                    "note": "No cutters",
                }
                return targets

            cutters_union = unary_union(cutter_polys)

            for t in targets:
                bbox_t = t.GetBoundingBox(True)
                poly_t = box(bbox_t.Min.X, bbox_t.Min.Y, bbox_t.Max.X, bbox_t.Max.Y)

                if poly_t.intersects(cutters_union):
                    intersection = poly_t.intersection(cutters_union)
                    if not intersection.is_empty:
                        inter_area = intersection.area
                        threshold = tolerance * tolerance

                        if inter_area > threshold:
                            deduced_m2 = inter_area / 1_000_000.0
                            if not hasattr(t, "UserDictionary"):
                                t.UserDictionary = {}

                            prev = t.UserDictionary.get("deducted_area_m2", 0.0)
                            t.UserDictionary["deducted_area_m2"] = prev + deduced_m2

                            removed_area_total += deduced_m2
                            touched_ids.append(getattr(t, "Id", "?"))

            self.report = {
                "mode": "Shapely 2D Footprint",
                "overlap_count": len(touched_ids),
                "removed_area_m2": round(removed_area_total, 4),
                "note": "Approximated via 2D",
            }
            return targets

        else:
            # AABB Fallback
            for t in targets:
                t_box = t.GetBoundingBox(True)
                for c in cutters:
                    c_box = c.GetBoundingBox(True)
                    intersection = rg.BoundingBox.Intersection(t_box, c_box)
                    if intersection.IsValid:
                        if not hasattr(t, "UserDictionary"):
                            t.UserDictionary = {}
                        t.UserDictionary["has_overlap"] = True
                        touched_ids.append(getattr(t, "Id", "??"))

            self.report = {
                "mode": "AABB only",
                "overlap_count": len(set(touched_ids)),
                "removed_area_m2": 0.0,
                "note": "No Shapely, rough AABB check only",
            }
            return targets

    def last_report(self) -> Dict[str, Any]:
        """Returns the report of the last operation."""
        return self.report

    def clean_model(
        self, classified_dict: Dict[str, List[Any]]
    ) -> Dict[str, List[Any]]:
        """
        Executes the full deduplication pipeline on a classified dictionary.
        Priority: Column cuts Wall & Slab; Wall cuts Slab.

        Args:
            classified_dict: Dictionary of classified objects (e.g., from Classifier).

        Returns:
            A new dictionary with overlaps handled (geometry modified or attributes updated).
        """
        cols = classified_dict.get("column", [])
        walls = classified_dict.get("wall", [])
        slabs = classified_dict.get("slab", [])

        # 1. Columns cut Walls
        if cols and walls:
            walls = self.remove_overlap(walls, cols)

        # 2. Columns cut Slabs
        if cols and slabs:
            slabs = self.remove_overlap(slabs, cols)

        # 3. Walls cut Slabs
        if walls and slabs:
            slabs = self.remove_overlap(slabs, walls)

        result = classified_dict.copy()
        result["wall"] = walls
        result["slab"] = slabs

        return result
