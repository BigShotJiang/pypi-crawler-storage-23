from typing import List, Dict, Any, Optional
import json
import os
import logging
from .models import ZEBEnvelope

logger = logging.getLogger(__name__)

# 건물 용도 문자열 → JSON 섹션 키 매핑
# 사용자가 "Residential", "주거", "아파트" 등 다양한 표현으로 입력할 수 있어
# 이를 내부적으로 "residential" 또는 "non_residential"로 정규화합니다.
_BUILDING_TYPE_ALIAS_MAP: Dict[str, str] = {
    # 주거
    "residential": "residential",
    "주거": "residential",
    "주택": "residential",
    "아파트": "residential",
    "공동주택": "residential",
    # 비주거
    "non_residential": "non_residential",
    "commercial": "non_residential",
    "비주거": "non_residential",
    "업무": "non_residential",
    "판매": "non_residential",
    "교육": "non_residential",
    "의료": "non_residential",
    "문화": "non_residential",
}


def _resolve_building_type(building_type: str) -> str:
    """사용자 입력 건물 유형 문자열을 내부 표준 키로 정규화합니다.

    Args:
        building_type: 사용자가 입력한 건물 유형 (예: "Residential", "아파트").

    Returns:
        "residential" 또는 "non_residential". 알 수 없는 값은 "residential"로
        폴백하며, WARNING 로그를 출력합니다.
    """
    key = building_type.strip().lower()
    resolved = _BUILDING_TYPE_ALIAS_MAP.get(key)
    if resolved is None:
        logger.warning(
            f"알 수 없는 건물 유형: '{building_type}'. "
            f"'주거(Residential)' 기준을 기본값으로 사용합니다. "
            f"지원 유형: {list(_BUILDING_TYPE_ALIAS_MAP.keys())}"
        )
        return "residential"
    return resolved


class ZEBReport:
    """한국 녹색건축 인증 기준(2025)에 따라 ZEB 등급 및 에너지 자립률을 계산합니다.

    주거와 비주거 건축물의 기준이 상이하므로, building_type 인자를
    올바르게 설정해야 정확한 등급 판정이 가능합니다.

    Attributes:
        project_name: 프로젝트명.
        building_type: 사용자가 입력한 건물 유형 문자열.
        _resolved_type: 내부 정규화된 건물 유형 키 ("residential" 또는 "non_residential").
        envelopes: 외피 요소 목록.
        primary_energy_kwh_m2_y: 연간 1차 에너지 소비량 (kWh/m²·y).
        renewable_prod_kwh_m2_y: 연간 신재생에너지 생산량 (kWh/m²·y).
        floor_area_m2: 연면적 (m²).
        standards: 로드된 ZEB 기준 JSON 데이터.
    """

    def __init__(self, project_name: str, building_type: str = "Residential") -> None:
        """ZEBReport를 초기화합니다.

        Args:
            project_name: 프로젝트명.
            building_type: 건물 유형. 주거("Residential", "주거", "아파트" 등) 또는
                           비주거("Commercial", "비주거", "업무" 등)를 지원합니다.
        """
        self.project_name = project_name
        self.building_type = building_type
        self._resolved_type: str = _resolve_building_type(building_type)

        self.envelopes: List[ZEBEnvelope] = []
        self.primary_energy_kwh_m2_y: float = 0.0
        self.renewable_prod_kwh_m2_y: float = 0.0
        self.floor_area_m2: float = 0.0

        self.standards: Dict[str, Any] = self._load_standards()

    def _load_standards(self) -> Dict[str, Any]:
        """패키지에 내장된 zeb_standards.json에서 ZEB 기준을 로드합니다.

        Returns:
            ZEB 기준 딕셔너리. 로드 실패 시 빈 딕셔너리.
        """
        base_dir = os.path.dirname(os.path.abspath(__file__))
        json_path = os.path.join(base_dir, "data", "zeb_standards.json")

        try:
            with open(json_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning(
                f"zeb_standards.json을 찾을 수 없습니다: {json_path}. 빈 기준으로 동작합니다."
            )
            return {}

    def _get_grades(self) -> Dict[str, Any]:
        """현재 건물 유형에 해당하는 ZEB 등급 기준을 반환합니다.

        Returns:
            등급명을 키로, 기준 딕셔너리를 값으로 갖는 딕셔너리.
        """
        return self.standards.get(self._resolved_type, {}).get("grades", {})

    def _get_common_requirements(self) -> Dict[str, Any]:
        """현재 건물 유형에 해당하는 공통 요건을 반환합니다.

        Returns:
            공통 요건 딕셔너리 (에너지 효율 등급, BEMS 필요 여부 등).
        """
        return self.standards.get(self._resolved_type, {}).get(
            "common_requirements", {}
        )

    def set_energy_consumption(
        self, primary_energy_kwh_m2_y: float, floor_area_m2: float
    ) -> None:
        """연간 1차 에너지 소비량과 연면적을 설정합니다.

        Args:
            primary_energy_kwh_m2_y: 단위 면적당 연간 1차 에너지 소비량 (kWh/m²·y).
            floor_area_m2: 건물 연면적 (m²).
        """
        self.primary_energy_kwh_m2_y = primary_energy_kwh_m2_y
        self.floor_area_m2 = floor_area_m2

    def set_renewable_production(
        self, renewable_primary_energy_kwh_m2_y: float
    ) -> None:
        """연간 신재생에너지 1차 에너지 환산 생산량을 설정합니다.

        Args:
            renewable_primary_energy_kwh_m2_y: 신재생에너지 생산량 (kWh/m²·y, 1차 에너지 환산).
        """
        self.renewable_prod_kwh_m2_y = renewable_primary_energy_kwh_m2_y

    def add_envelope(self, element: str, area_m2: float, u_value: float) -> None:
        """외피 요소(단열 검토 대상)를 추가합니다.

        Args:
            element: 외피 요소명 (예: "외벽", "지붕", "창호").
            area_m2: 외피 면적 (m²).
            u_value: 열관류율 (W/m²·K).
        """
        env = ZEBEnvelope(element=element, area_m2=area_m2, u_value=u_value)
        self.envelopes.append(env)

    def calc_energy_independence_rate(self) -> float:
        """에너지 자립률을 계산합니다.

        계산식: (신재생에너지 생산량 / 1차 에너지 소비량) × 100

        Returns:
            에너지 자립률 (%). 1차 에너지 소비량이 0 이하이면 0.0.
        """
        if self.primary_energy_kwh_m2_y <= 0:
            return 0.0

        rate = (self.renewable_prod_kwh_m2_y / self.primary_energy_kwh_m2_y) * 100.0
        return round(rate, 2)

    def check_compliance(self, standard: str = "ZEB_5") -> Dict[str, Any]:
        """특정 ZEB 등급 기준에 대한 적합성을 검사합니다.

        건물 용도(주거/비주거)에 따라 올바른 기준 섹션에서 데이터를 조회합니다.

        Args:
            standard: 검사할 ZEB 등급 식별자 (예: "ZEB_1", "ZEB_5", "ZEB_PLUS").

        Returns:
            적합성 결과 딕셔너리:
                - grade (str): 검사한 등급
                - building_type (str): 건물 유형
                - energy_independence_rate (float): 계산된 자립률
                - required_rate (float): 해당 등급의 최소 자립률
                - compliant (bool): 적합 여부
                - primary_energy_kwh_m2_y (float): 설정된 1차 에너지 소비량
                - max_primary_energy_kwh_m2_y (Optional[float]): 해당 등급의 최대 허용 소비량
                - energy_consumption_compliant (Optional[bool]): 소비량 기준 적합 여부
                - bems_required (bool): BEMS 필요 여부
                - details (dict): 추가 상세 정보
        """
        current_rate = self.calc_energy_independence_rate()
        grades = self._get_grades()
        target = grades.get(standard)

        if not target:
            logger.warning(
                f"알 수 없는 ZEB 등급: '{standard}'. "
                f"건물 유형 '{self._resolved_type}'에 유효한 등급: {list(grades.keys())}"
            )
            return {
                "compliant": False,
                "message": f"알 수 없는 등급: {standard}",
                "building_type": self._resolved_type,
            }

        required_rate = target["min_independence_rate"]
        rate_compliant = current_rate >= required_rate

        # 1차 에너지 소비량 기준 검사 (등급별 상한값이 있는 경우)
        max_consumption = target.get("max_primary_energy_kwh_m2_y")
        energy_consumption_compliant: Optional[bool] = None
        if max_consumption is not None:
            energy_consumption_compliant = (
                self.primary_energy_kwh_m2_y <= max_consumption
            )

        # ZEB_PLUS의 경우 실제 에너지 자립률이 100% "이상"이어야 하므로
        # rate_compliant만으로 충분. 소비량 기준은 null.
        compliant = rate_compliant
        if energy_consumption_compliant is not None:
            compliant = compliant and energy_consumption_compliant

        bems = self._get_common_requirements().get("bems_or_remote_meter", True)

        return {
            "grade": standard,
            "building_type": self._resolved_type,
            "energy_independence_rate": current_rate,
            "required_rate": required_rate,
            "compliant": compliant,
            "primary_energy_kwh_m2_y": self.primary_energy_kwh_m2_y,
            "max_primary_energy_kwh_m2_y": max_consumption,
            "energy_consumption_compliant": energy_consumption_compliant,
            "bems_required": bems,
            "details": {
                "renewable_production": self.renewable_prod_kwh_m2_y,
                "project": self.project_name,
                "description": target.get("description", ""),
            },
        }

    def get_achievable_grade(self) -> str:
        """현재 에너지 성능으로 달성 가능한 최고 ZEB 등급을 반환합니다.

        건물 용도에 맞는 기준 섹션에서 에너지 자립률과 1차 에너지 소비량
        두 조건을 모두 만족하는 최고 등급을 탐색합니다.

        Returns:
            등급명 (예: "ZEB_1", "ZEB_PLUS") 또는 기준 미달 시 "None".
        """
        current_rate = self.calc_energy_independence_rate()
        grades = self._get_grades()

        # 에너지 자립률 기준 내림차순 정렬 (높은 등급 우선 탐색)
        sorted_grades = sorted(
            grades.items(),
            key=lambda x: (x[1]["min_independence_rate"], x[0]),
            reverse=True,
        )

        for name, criteria in sorted_grades:
            rate_ok = current_rate >= criteria["min_independence_rate"]
            if not rate_ok:
                continue

            # 1차 에너지 소비량 기준이 있는 경우 추가 검사
            max_consumption = criteria.get("max_primary_energy_kwh_m2_y")
            if max_consumption is not None:
                if self.primary_energy_kwh_m2_y > max_consumption:
                    continue

            return name

        return "None"

    def export_summary(self) -> Dict[str, Any]:
        """프로젝트의 ZEB 상태 요약을 반환합니다.

        Returns:
            요약 딕셔너리 (프로젝트명, 자립률, 달성 등급, 외피 요소 수).
        """
        return {
            "project": self.project_name,
            "building_type": self._resolved_type,
            "energy_independence_rate": self.calc_energy_independence_rate(),
            "achieved_grade": self.get_achievable_grade(),
            "items_count": len(self.envelopes),
        }

    def export_excel(self, filepath: str) -> None:
        """ZEB 보고서를 Excel 파일로 저장합니다.

        ExcelWriter를 사용하여 에너지 성능 요약표와 외피 요소 목록을 작성합니다.

        생성되는 시트 구성:
            - "ZEB 요약": 주요 지표 (에너지 자립률, 등급, 건물 유형 등)
            - "외피 요소": 등록된 외피 요소 목록 (element, area_m2, u_value)

        Args:
            filepath: 저장할 Excel 파일 경로 (예: "ZEB_Report_2025.xlsx").
        """
        from .excel_io import ExcelWriter

        writer = ExcelWriter()

        # ── 시트 1: ZEB 요약 ────────────────────────────────────────────────
        summary_data = [
            {"항목": "프로젝트명", "값": self.project_name},
            {"항목": "건물 유형", "값": self._resolved_type},
            {"항목": "연면적 (m²)", "값": self.floor_area_m2},
            {
                "항목": "1차 에너지 소비량 (kWh/m²·y)",
                "값": self.primary_energy_kwh_m2_y,
            },
            {
                "항목": "신재생에너지 생산량 (kWh/m²·y)",
                "값": self.renewable_prod_kwh_m2_y,
            },
            {
                "항목": "에너지 자립률 (%)",
                "값": self.calc_energy_independence_rate(),
            },
            {"항목": "달성 가능 ZEB 등급", "값": self.get_achievable_grade()},
        ]
        writer.write_table(
            start_cell="A1",
            data=summary_data,
            headers=["항목", "값"],
            sheet_name="ZEB 요약",
        )

        # ── 시트 2: 외피 요소 ────────────────────────────────────────────────
        if self.envelopes:
            envelope_data = [
                {
                    "외피 요소": env.element,
                    "면적 m²": env.area_m2,
                    "열관류율 W/m²K": env.u_value,
                }
                for env in self.envelopes
            ]
            writer.write_table(
                start_cell="A1",
                data=envelope_data,
                headers=["외피 요소", "면적 m²", "열관류율 W/m²K"],
                sheet_name="외피 요소",
            )

        writer.save(filepath)
        logger.info(f"ZEB 보고서가 저장되었습니다: {filepath}")
