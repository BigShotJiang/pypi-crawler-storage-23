from pydantic import BaseModel, model_validator, Field
from typing import List, Optional, Dict
from enum import Enum


class ElementType(str, Enum):
    """건축 부재 유형 열거형.

    Attributes:
        SLAB: 슬라브.
        WALL: 벽.
        COLUMN: 기둥.
        BEAM: 보.
        OPENING: 개구부.
        FOUNDATION: 기초.
        UNKNOWN: 미분류.
    """

    SLAB = "slab"
    WALL = "wall"
    COLUMN = "column"
    BEAM = "beam"
    OPENING = "opening"
    FOUNDATION = "foundation"
    UNKNOWN = "unknown"


class BuildingElement(BaseModel):
    """기본 건축 부재 및 속성을 나타냅니다.

    Attributes:
        id: 객체 고유 식별자 (예: GUID).
        element_type: 부재 유형.
        layer: Rhino 레이어 경로 또는 이름.
        area_m2: 부재 면적 (m²).
        volume_m3: 부재 체적 (m³).
        length_m: 부재 길이 (m).
        floor_number: 해당 층 번호. None이면 층 미지정.
        notes: 추가 메모.
    """

    id: str = Field(..., description="객체 고유 식별자 (예: GUID)")
    element_type: ElementType = Field(..., description="부재 유형")
    layer: Optional[str] = Field(None, description="Rhino 레이어 경로 또는 이름")
    area_m2: Optional[float] = Field(None, description="면적 (m²)")
    volume_m3: Optional[float] = Field(None, description="체적 (m³)")
    length_m: Optional[float] = Field(None, description="길이 (m)")
    floor_number: Optional[int] = Field(None, description="층 번호")
    notes: Optional[str] = Field(None, description="추가 메모")


class TakeoffResult(BaseModel):
    """수량산출 결과 집합을 나타냅니다.

    개별 `BuildingElement` 목록을 집계하여 전체 면적·체적 합계를 자동 계산하고,
    층별·유형별 분석 메서드를 제공합니다.

    Attributes:
        project_name: 프로젝트명.
        elements: 건축 부재 목록.
        total_area_m2: 전체 면적 합계 (m²). model_validator가 자동 계산.
        total_volume_m3: 전체 체적 합계 (m³). model_validator가 자동 계산.
    """

    project_name: str
    elements: List[BuildingElement]
    total_area_m2: float = 0.0
    total_volume_m3: float = 0.0

    @model_validator(mode="after")
    def calc_totals(self) -> "TakeoffResult":
        """부재 목록에서 전체 면적·체적 합계를 계산합니다."""
        self.total_area_m2 = sum((e.area_m2 or 0.0) for e in self.elements)
        self.total_volume_m3 = sum((e.volume_m3 or 0.0) for e in self.elements)
        return self

    def by_floor(self) -> Dict[Optional[int], Dict[str, float]]:
        """층별 면적·체적 합계를 집계합니다.

        수량산출서에서 층별 집계표는 필수 항목입니다.
        `floor_number`가 None인 부재는 `None` 키로 묶입니다.

        Returns:
            층 번호를 키로, {"total_area_m2": float, "total_volume_m3": float}
            딕셔너리를 값으로 갖는 딕셔너리.

            예::

                {
                    1: {"total_area_m2": 200.0, "total_volume_m3": 60.0},
                    2: {"total_area_m2": 180.0, "total_volume_m3": 54.0},
                    None: {"total_area_m2": 50.0, "total_volume_m3": 0.0}
                }
        """
        result: Dict[Optional[int], Dict[str, float]] = {}
        for elem in self.elements:
            floor = elem.floor_number
            if floor not in result:
                result[floor] = {"total_area_m2": 0.0, "total_volume_m3": 0.0}
            result[floor]["total_area_m2"] += elem.area_m2 or 0.0
            result[floor]["total_volume_m3"] += elem.volume_m3 or 0.0
        return result

    def by_type(self) -> Dict[str, Dict[str, float]]:
        """부재 유형별 면적·체적 합계를 집계합니다.

        발주처 제출용 수량산출서에서 부재 유형별 소계는 필수 항목입니다.

        Returns:
            부재 유형 문자열을 키로, {"total_area_m2": float, "total_volume_m3": float,
            "count": int} 딕셔너리를 값으로 갖는 딕셔너리.

            예::

                {
                    "slab": {"total_area_m2": 300.0, "total_volume_m3": 90.0, "count": 3},
                    "column": {"total_area_m2": 0.0, "total_volume_m3": 15.0, "count": 12}
                }
        """
        result: Dict[str, Dict[str, float]] = {}
        for elem in self.elements:
            type_key = elem.element_type.value
            if type_key not in result:
                result[type_key] = {
                    "total_area_m2": 0.0,
                    "total_volume_m3": 0.0,
                    "count": 0,
                }
            result[type_key]["total_area_m2"] += elem.area_m2 or 0.0
            result[type_key]["total_volume_m3"] += elem.volume_m3 or 0.0
            result[type_key]["count"] += 1  # type: ignore[operator]
        return result

    def summary_table(self) -> List[Dict]:
        """Excel 출력에 적합한 플랫(flat) 형태의 수량산출 행 목록을 반환합니다.

        각 행은 하나의 `BuildingElement`에 해당하며, 모든 필드를 포함합니다.
        ExcelWriter.write_table()과 직접 연동하여 사용할 수 있습니다.

        Returns:
            딕셔너리 목록. 각 항목::

                {
                    "ID": str,
                    "유형": str,
                    "레이어": str | None,
                    "층": int | None,
                    "면적 (m²)": float,
                    "체적 (m³)": float,
                    "길이 (m)": float,
                    "메모": str | None
                }
        """
        rows = []
        for elem in self.elements:
            rows.append(
                {
                    "ID": elem.id,
                    "유형": elem.element_type.value,
                    "레이어": elem.layer,
                    "층": elem.floor_number,
                    "면적 (m²)": elem.area_m2 or 0.0,
                    "체적 (m³)": elem.volume_m3 or 0.0,
                    "길이 (m)": elem.length_m or 0.0,
                    "메모": elem.notes,
                }
            )
        return rows


class ZEBEnvelope(BaseModel):
    """ZEB 인증을 위한 외피 요소 데이터를 나타냅니다.

    Attributes:
        element: 외피 요소명 또는 유형 (예: "외벽", "지붕").
        area_m2: 외피 면적 (m²).
        u_value: 열관류율 (W/m²·K). 낮을수록 단열 성능이 우수합니다.
        compliant: 단열 기준 적합 여부. None이면 미검사 상태.
    """

    element: str
    area_m2: float
    u_value: float = Field(..., description="열관류율 (W/m²·K)")
    compliant: Optional[bool] = None
