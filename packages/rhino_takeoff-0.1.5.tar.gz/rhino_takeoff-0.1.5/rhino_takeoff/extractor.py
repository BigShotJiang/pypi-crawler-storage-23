import logging
import traceback
from typing import Any, List, Dict

try:
    import Rhino.Geometry as rg  # type: ignore  # noqa: F401

    IS_RHINO = True
except ImportError:
    import rhino3dm as rg

    IS_RHINO = False

logger = logging.getLogger(__name__)


def _triangle_area(a: tuple, b: tuple, c: tuple) -> float:
    """삼각형 세 꼭짓점의 3D 좌표로 넓이를 계산합니다.

    외적(cross product)의 크기가 평행사변형 넓이이므로 절반을 반환합니다.

    Args:
        a: 꼭짓점 A의 (x, y, z) 좌표.
        b: 꼭짓점 B의 (x, y, z) 좌표.
        c: 꼭짓점 C의 (x, y, z) 좌표.

    Returns:
        삼각형의 넓이.
    """
    ab = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
    ac = (c[0] - a[0], c[1] - a[1], c[2] - a[2])
    cross = (
        ab[1] * ac[2] - ab[2] * ac[1],
        ab[2] * ac[0] - ab[0] * ac[2],
        ab[0] * ac[1] - ab[1] * ac[0],
    )
    return 0.5 * (cross[0] ** 2 + cross[1] ** 2 + cross[2] ** 2) ** 0.5


def _signed_tet_volume(a: tuple, b: tuple, c: tuple) -> float:
    """원점과 삼각형으로 이루어진 사면체의 부호 있는 체적을 계산합니다.

    폐합 메시의 체적을 발산 정리(Divergence Theorem)로 계산할 때 사용합니다.
    각 삼각형 페이스에 대해 합산하면 실제 체적이 됩니다.

    참고: `V = (1/6) * dot(a, cross(b, c))`

    Args:
        a: 꼭짓점 A의 (x, y, z) 좌표.
        b: 꼭짓점 B의 (x, y, z) 좌표.
        c: 꼭짓점 C의 (x, y, z) 좌표.

    Returns:
        부호 있는 사면체 체적. 합산 후 절댓값을 취합니다.
    """
    return (
        a[0] * (b[1] * c[2] - b[2] * c[1])
        + a[1] * (b[2] * c[0] - b[0] * c[2])
        + a[2] * (b[0] * c[1] - b[1] * c[0])
    ) / 6.0


def _area_from_mesh(mesh: Any) -> float:
    """메시의 모든 페이스 넓이를 합산하여 총 표면적을 계산합니다.

    쿼드 페이스는 두 삼각형으로 분해하여 처리합니다.

    Args:
        mesh: 메시 객체 (rhino3dm.Mesh 또는 Rhino.Geometry.Mesh).

    Returns:
        메시 고유 단위(보통 mm²)의 총 표면적.
    """
    if not mesh:
        return 0.0

    total = 0.0
    faces = mesh.Faces
    vertices = mesh.Vertices

    for i in range(len(faces)):
        face = faces[i]
        idx_a, idx_b, idx_c, idx_d = face.A, face.B, face.C, face.D

        a = (vertices[idx_a].X, vertices[idx_a].Y, vertices[idx_a].Z)
        b = (vertices[idx_b].X, vertices[idx_b].Y, vertices[idx_b].Z)
        c = (vertices[idx_c].X, vertices[idx_c].Y, vertices[idx_c].Z)
        d = (vertices[idx_d].X, vertices[idx_d].Y, vertices[idx_d].Z)

        total += _triangle_area(a, b, c)
        if idx_c != idx_d:  # 쿼드 페이스
            total += _triangle_area(a, c, d)

    return total


def _volume_from_mesh(mesh: Any) -> float:
    """발산 정리(Divergence Theorem)를 활용해 폐합 메시의 체적을 계산합니다.

    BoundingBox 근사치와 달리 임의의 형상(L자, T자, 경사면 등)에서도
    정확한 체적을 산출합니다. 단, 메시가 물리적으로 폐합(watertight)되어
    있어야 정확한 결과를 보장합니다.

    수식: V = |Σ (1/6) * dot(a_i, cross(b_i, c_i))| for each triangle face

    Args:
        mesh: 폐합 메시 객체 (rhino3dm.Mesh 또는 Rhino.Geometry.Mesh).

    Returns:
        메시 고유 단위(보통 mm³)의 체적. 메시가 None이거나 페이스가 없으면 0.0.
    """
    if not mesh:
        return 0.0

    total_signed = 0.0
    faces = mesh.Faces
    vertices = mesh.Vertices

    if len(faces) == 0:
        return 0.0

    for i in range(len(faces)):
        face = faces[i]
        idx_a, idx_b, idx_c, idx_d = face.A, face.B, face.C, face.D

        a = (vertices[idx_a].X, vertices[idx_a].Y, vertices[idx_a].Z)
        b = (vertices[idx_b].X, vertices[idx_b].Y, vertices[idx_b].Z)
        c = (vertices[idx_c].X, vertices[idx_c].Y, vertices[idx_c].Z)
        d = (vertices[idx_d].X, vertices[idx_d].Y, vertices[idx_d].Z)

        # 삼각형 1: (a, b, c)
        total_signed += _signed_tet_volume(a, b, c)
        # 쿼드인 경우 삼각형 2: (a, c, d)
        if idx_c != idx_d:
            total_signed += _signed_tet_volume(a, c, d)

    return abs(total_signed)


class Extractor:
    """Rhino/Grasshopper 객체로부터 기하학적 수량(면적, 체적, 길이)을 추출합니다.

    RhinoCommon 환경과 rhino3dm 환경을 자동으로 감지하여 적절한 계산 방식을 사용합니다.

    Attributes:
        _volume_approximated: 마지막 `volume()` 호출이 BBox 근사치를 사용했는지 여부.
    """

    def __init__(self) -> None:
        self._volume_approximated: bool = False

    @property
    def last_volume_was_approximated(self) -> bool:
        """마지막 volume() 호출이 BBox 근사치 사용 여부를 반환합니다.

        Returns:
            True이면 BBox 근사치를 사용했으므로 결과를 주의해야 합니다.
        """
        return self._volume_approximated

    def area(self, geometry: Any, unit: str = "m2") -> float:
        """주어진 지오메트리의 면적을 계산합니다.

        RhinoCommon(AreaMassProperties)과 rhino3dm(Mesh 변환) 환경을 자동 지원합니다.

        Args:
            geometry: 측정할 지오메트리 객체.
            unit: 결과 단위 ("m2" 또는 "mm2"). 기본값은 "m2".

        Returns:
            지정된 단위의 면적. 계산 실패 시 0.0.
        """
        val_mm2 = 0.0

        if not geometry:
            return 0.0

        if IS_RHINO:
            try:
                amp = rg.AreaMassProperties.Compute(geometry)
                if amp:
                    val_mm2 = amp.Area
            except Exception as e:
                logger.warning(f"AreaMassProperties 계산 실패: {e}")
                val_mm2 = 0.0
        else:
            if isinstance(geometry, rg.Mesh):
                val_mm2 = _area_from_mesh(geometry)

            elif isinstance(geometry, rg.Brep):
                if hasattr(geometry, "GetMesh"):
                    m = geometry.GetMesh(rg.MeshType.Any)
                    if m:
                        val_mm2 = _area_from_mesh(m)
                else:
                    # GetMesh가 없는 경우 각 Face에서 메시 추출 (폴백)
                    temp_area = 0.0
                    for face in geometry.Faces:
                        m = face.GetMesh(rg.MeshType.Any)
                        if m:
                            temp_area += _area_from_mesh(m)
                    val_mm2 = temp_area

            elif isinstance(geometry, rg.Extrusion):
                if hasattr(geometry, "GetMesh"):
                    m = geometry.GetMesh(rg.MeshType.Any)
                    if m:
                        val_mm2 = _area_from_mesh(m)

            # 테스트/목업 환경용: UserDictionary에 mock_area가 설정된 경우 사용
            if (
                val_mm2 == 0.0
                and hasattr(geometry, "UserDictionary")
                and "mock_area" in geometry.UserDictionary
            ):
                val_mm2 = geometry.UserDictionary["mock_area"]

        if unit == "m2":
            final_m2 = val_mm2 / 1_000_000.0
            if hasattr(geometry, "UserDictionary"):
                deducted = geometry.UserDictionary.get("deducted_area_m2", 0.0)
                final_m2 -= deducted
            return max(0.0, final_m2)
        elif unit == "mm2":
            return val_mm2

        return val_mm2

    def volume(self, geometry: Any, unit: str = "m3") -> float:
        """주어진 지오메트리의 체적을 계산합니다.

        RhinoCommon 환경에서는 VolumeMassProperties로 정확하게 계산합니다.
        rhino3dm 환경에서는 Mesh 기반 발산 정리로 정확도를 최대화하며,
        메시를 얻을 수 없는 경우에만 BoundingBox 근사치를 사용합니다.
        BBox 근사치 사용 시 WARNING 로그가 출력되며 `last_volume_was_approximated`
        속성이 True로 설정됩니다.

        Args:
            geometry: 측정할 지오메트리 객체.
            unit: 결과 단위 ("m3" 또는 "mm3"). 기본값은 "m3".

        Returns:
            지정된 단위의 체적. L자, T자 등 복잡한 형상도 정확히 계산됩니다.

        Raises:
            없음. 계산 실패 시 0.0을 반환합니다.
        """
        val_mm3 = 0.0
        self._volume_approximated = False

        if IS_RHINO:
            try:
                vmp = rg.VolumeMassProperties.Compute(geometry)
                if vmp:
                    val_mm3 = vmp.Volume
            except Exception as e:
                logger.warning(f"VolumeMassProperties 계산 실패: {e}")
                val_mm3 = 0.0
        else:
            # 1순위: Mesh 직접 계산 (가장 정확)
            if isinstance(geometry, rg.Mesh):
                val_mm3 = _volume_from_mesh(geometry)
            else:
                # 2순위: Brep/Extrusion → Mesh 추출 후 계산
                mesh = None
                if hasattr(geometry, "GetMesh"):
                    mesh = geometry.GetMesh(rg.MeshType.Any)

                if mesh:
                    val_mm3 = _volume_from_mesh(mesh)
                else:
                    # 3순위 (최후 폴백): BoundingBox 근사 — 복잡한 형상에서 오차 발생 가능
                    self._volume_approximated = True
                    bbox = geometry.GetBoundingBox(True)
                    w = bbox.Max.X - bbox.Min.X
                    d = bbox.Max.Y - bbox.Min.Y
                    h = bbox.Max.Z - bbox.Min.Z
                    val_mm3 = w * d * h
                    logger.warning(
                        "BoundingBox 근사치를 사용하여 체적을 계산했습니다. "
                        "L자·T자형 등 복잡한 형상의 경우 실제 체적과 오차가 발생할 수 있습니다. "
                        "정확한 측정을 위해 RhinoCommon 환경을 사용하거나 Mesh로 변환하세요."
                    )

        if unit == "m3":
            return val_mm3 / 1_000_000_000.0
        return val_mm3

    def length(self, geometry: Any, unit: str = "m") -> float:
        """주어진 지오메트리(예: 곡선)의 길이를 계산합니다.

        Args:
            geometry: 측정할 지오메트리 객체.
            unit: 결과 단위 ("m" 또는 "mm"). 기본값은 "m".

        Returns:
            지정된 단위의 길이. `GetLength()` 메서드가 없으면 0.0.
        """
        val_mm = 0.0

        if hasattr(geometry, "GetLength"):
            val_mm = geometry.GetLength()

        if unit == "m":
            return val_mm / 1000.0
        return val_mm

    def batch(
        self, geometries: List[Any], measure: str = "area", unit: str = "m2"
    ) -> List[Dict[str, Any]]:
        """지오메트리 목록에 대해 일괄 수량 추출을 수행합니다.

        개별 객체 처리 중 예외가 발생해도 전체 배치가 중단되지 않으며,
        해당 항목에 `success=False`와 `error` 메시지가 기록됩니다.
        이를 통해 다수 객체를 처리할 때 조용한 실패(silent failure)를 방지합니다.

        Args:
            geometries: 지오메트리 객체 목록.
            measure: 측정 유형 ("area", "volume", "length").
            unit: 결과 단위 ("m2"/"mm2", "m3"/"mm3", "m"/"mm").

        Returns:
            각 객체의 결과 딕셔너리 목록.
            각 항목 구조:
                - id (str): 객체 ID 또는 "?"
                - measure (str): 측정 유형
                - value (float): 측정값 (실패 시 0.0)
                - unit (str): 단위
                - success (bool): 성공 여부
                - error (Optional[str]): 에러 메시지 (성공 시 None)
                - approximated (bool): BBox 근사 사용 여부 (volume 측정 시에만 유효)
        """
        results = []
        for geo in geometries:
            geo_id = str(getattr(geo, "Id", "?"))
            val = 0.0
            approximated = False

            try:
                if measure == "area":
                    val = self.area(geo, unit)
                elif measure == "volume":
                    val = self.volume(geo, unit)
                    approximated = self._volume_approximated
                elif measure == "length":
                    val = self.length(geo, unit)
                else:
                    raise ValueError(
                        f"지원하지 않는 measure 유형: '{measure}'. 'area', 'volume', 'length' 중 하나를 선택하세요."
                    )

                results.append(
                    {
                        "id": geo_id,
                        "measure": measure,
                        "value": val,
                        "unit": unit,
                        "success": True,
                        "error": None,
                        "approximated": approximated,
                    }
                )
            except Exception as e:
                error_detail = traceback.format_exc().strip().splitlines()[-1]
                logger.error(
                    f"batch() 처리 중 오류 발생 — id={geo_id}, measure={measure}: {e}"
                )
                results.append(
                    {
                        "id": geo_id,
                        "measure": measure,
                        "value": 0.0,
                        "unit": unit,
                        "success": False,
                        "error": error_detail,
                        "approximated": False,
                    }
                )

        return results
