import logging
import re
from typing import Any, Dict, List, Optional

try:
    import Rhino.Geometry as rg  # type: ignore  # noqa: F401

    IS_RHINO = True
except ImportError:
    IS_RHINO = False

logger = logging.getLogger(__name__)


class Classifier:
    """Rhino 객체를 레이어명 또는 형상 특성 기반으로 건축 부재로 분류합니다.

    분류 우선순위:
        1. 레이어명 기반 정규식 매핑 (한글 패턴 우선 → 영어 패턴)
        2. BoundingBox 비율 기반 기하학적 추론 (레이어 매핑 실패 시 폴백)

    Attributes:
        rules: 정규식 패턴과 카테고리명의 딕셔너리.
        _last_result: 마지막 classify_all() 호출의 카테고리별 개수.
    """

    def __init__(self, rules: Optional[Dict[str, str]] = None) -> None:
        """Classifier를 초기화합니다.

        Args:
            rules: 정규식 패턴 → 카테고리명 딕셔너리.
                   제공 시 기본 규칙 대신 사용됩니다.
                   예: { r"C\\d+": "column", r"S\\d+": "slab" }
        """
        self.rules = rules or self._default_rules()
        self._last_result: Dict[str, int] = {}

    def _default_rules(self) -> Dict[str, str]:
        """기본 분류 규칙을 반환합니다.

        국내 BIM/CAD 실무에서 사용되는 한글 레이어명 패턴을 우선 포함하며,
        영어 패턴(Revit, ArchiCAD 내보내기 기준)도 함께 지원합니다.

        한글 레이어 우선 → 영어/약어 순서로 정렬되어 있습니다.

        Returns:
            정규식 패턴을 키로, 카테고리명을 값으로 갖는 딕셔너리.
        """
        return {
            # ── 한글 패턴 (국내 BIM/CAD 실무 표준) ──────────────────────────────
            # 기둥: '기둥', 'RC기둥', 'SRC기둥' 등
            r"기둥": "column",
            # 슬라브: '슬라브', '슬래브' (오타 혼용 포함)
            r"슬라브|슬래브": "slab",
            # 벽: '벽', '구조벽', '전단벽', '외벽', '내벽'
            r"구조벽|전단벽|외벽|내벽|벽": "wall",
            # 보: '보', '큰보', '작은보', 'RC보'
            r"큰보|작은보|RC보|보": "beam",
            # 기초: '기초', '파일기초', '매트기초', '독립기초', '줄기초'
            r"파일기초|매트기초|독립기초|줄기초|기초": "foundation",
            # ── 영어/국제 BIM 표준 패턴 ──────────────────────────────────────────
            # 기둥: Column, COL, A-COLS (AutoCAD 레이어), S-COL (구조)
            r"(?i)\bA-COLS?\b": "column",
            r"(?i)\bS-COL\b": "column",
            r"(?i)\bCOL\b": "column",
            r"(?i)column": "column",
            # 슬라브: Slab, SL, A-SLAB, S-SLAB
            r"(?i)\bA-SLAB\b": "slab",
            r"(?i)\bS-SLAB\b": "slab",
            r"(?i)slab": "slab",
            # 벽: Wall, A-WALL, S-WALL (WALL_exterior 등 접미어가 붙는 형태도 포함)
            r"(?i)\bA-WALL\b": "wall",
            r"(?i)\bS-WALL\b": "wall",
            r"(?i)wall": "wall",
            # 보: Beam, A-BEAM, S-BEAM
            r"(?i)\bA-BEAM\b": "beam",
            r"(?i)\bS-BEAM\b": "beam",
            r"(?i)beam": "beam",
            # 기초: Foundation, FOUN, FD, PILE, MAT
            r"(?i)foun": "foundation",
            r"(?i)\b(PILE|MAT_FDN|MAT)\b": "foundation",
            r"(?i)\bFD\b": "foundation",
        }

    def classify(self, geometry: Any, layer_name: str = "") -> str:
        """단일 지오메트리 객체를 분류합니다.

        레이어명 기반 매칭을 우선으로 시도하고, 실패 시 형상 비율로 추론합니다.

        Args:
            geometry: Rhino 지오메트리 객체.
            layer_name: 객체가 속한 레이어의 이름.

        Returns:
            분류된 카테고리 문자열 ("column", "slab", "wall", "beam",
            "foundation", "unknown" 중 하나).
        """
        # 1단계: 레이어명 정규식 매핑
        if layer_name:
            for pattern, category in self.rules.items():
                if re.search(pattern, layer_name):
                    return category

        # 2단계: BoundingBox 비율 기반 기하학적 추론 (레이어명 실패 시)
        if geometry:
            try:
                bbox = geometry.GetBoundingBox(True)
                if bbox.IsValid:
                    dx = bbox.Max.X - bbox.Min.X
                    dy = bbox.Max.Y - bbox.Min.Y
                    dz = bbox.Max.Z - bbox.Min.Z

                    # 납작하고 넓은 형상 → 슬라브
                    if dz < dx * 0.2 and dz < dy * 0.2:
                        return "slab"
                    # 높고 좁은 형상 → 기둥
                    if dz > dx * 2 and dz > dy * 2:
                        return "column"
            except Exception as e:
                logger.warning(f"BoundingBox 기반 분류 중 오류: {e}")

        return "unknown"

    def classify_all(self, geometries: List[Any]) -> Dict[str, List[Any]]:
        """지오메트리 목록 전체를 분류합니다.

        각 객체의 UserDictionary에서 "layer_name" 키를 자동으로 읽어 분류합니다.

        Args:
            geometries: Rhino 지오메트리 객체 목록.

        Returns:
            카테고리를 키로, 해당 객체 목록을 값으로 갖는 딕셔너리.
            예: { "slab": [obj1, obj2], "column": [obj3] }
        """
        classified: Dict[str, List[Any]] = {
            "slab": [],
            "column": [],
            "wall": [],
            "beam": [],
            "foundation": [],
            "unknown": [],
        }

        for geo in geometries:
            layer = ""
            if hasattr(geo, "UserDictionary") and "layer_name" in geo.UserDictionary:
                layer = geo.UserDictionary["layer_name"]

            category = self.classify(geo, layer_name=layer)
            if category not in classified:
                classified[category] = []
            classified[category].append(geo)

        self._last_result = {k: len(v) for k, v in classified.items()}

        return classified

    def report(self) -> Dict[str, int]:
        """가장 최근 classify_all() 호출의 카테고리별 개수를 반환합니다.

        Returns:
            카테고리명을 키로, 분류된 객체 수를 값으로 갖는 딕셔너리.
            classify_all() 호출 전에는 빈 딕셔너리.
        """
        return self._last_result
