import logging
import os
from typing import List, Dict, Any, Optional
import openpyxl
from openpyxl.utils import cell as cell_utils

logger = logging.getLogger(__name__)


class SheetWrapper:
    """Excel 워크시트에 대한 향상된 접근 메서드를 제공하는 래퍼입니다."""

    def __init__(self, ws: Any) -> None:
        self.ws = ws

    def __getitem__(self, key: str) -> Any:
        return self.ws[key].value

    def column(self, header_name: str) -> List[Any]:
        """헤더명으로 열 데이터를 추출합니다.

        첫 번째 행을 헤더로 간주하고, 해당 열의 값(비어있지 않은 셀만) 목록을 반환합니다.

        Args:
            header_name: 열 헤더 이름.

        Returns:
            해당 열의 값 목록 (None 제외). 헤더를 찾지 못하면 빈 리스트.
        """
        target_col = -1
        for col in range(1, self.ws.max_column + 1):
            val = self.ws.cell(row=1, column=col).value
            if val == header_name:
                target_col = col
                break

        if target_col == -1:
            logger.warning(f"헤더 '{header_name}'를 찾을 수 없습니다.")
            return []

        return [
            self.ws.cell(row=r, column=target_col).value
            for r in range(2, self.ws.max_row + 1)
            if self.ws.cell(row=r, column=target_col).value is not None
        ]

    def row(self, index: int) -> Dict[str, Any]:
        """특정 행을 헤더 기반 딕셔너리로 반환합니다.

        Args:
            index: 1-based 행 인덱스.

        Returns:
            헤더를 키로, 셀 값을 값으로 갖는 딕셔너리.
        """
        headers = [
            self.ws.cell(row=1, column=c).value
            for c in range(1, self.ws.max_column + 1)
        ]
        values = [
            self.ws.cell(row=index, column=c).value
            for c in range(1, self.ws.max_column + 1)
        ]
        return dict(zip(headers, values))

    def to_dataframe(self) -> Any:
        """시트 내용을 Pandas DataFrame으로 변환합니다.

        Returns:
            pandas가 설치된 경우 pd.DataFrame, 그렇지 않으면 원시 행 목록.
        """
        try:
            import pandas as pd

            data = list(self.ws.values)
            if not data:
                return pd.DataFrame()
            return pd.DataFrame(data[1:], columns=data[0])
        except ImportError:
            logger.warning("pandas가 설치되지 않았습니다. 원시 값 목록을 반환합니다.")
            return list(self.ws.values)


class ExcelWriter:
    """Excel 파일 작성을 처리합니다. 템플릿 파일이 있으면 서식을 보존합니다."""

    def __init__(self, template_path: Optional[str] = None) -> None:
        """ExcelWriter를 초기화합니다.

        Args:
            template_path: 기존 Excel 파일 경로 (템플릿으로 사용).
                           경로가 주어졌으나 파일이 존재하지 않으면
                           WARNING 로그를 출력하고 새 워크북을 생성합니다.
        """
        if template_path:
            if os.path.exists(template_path):
                self.wb = openpyxl.load_workbook(template_path)
                self.filepath = template_path
            else:
                # 파일이 없으면 사용자에게 명확히 알리고 새 워크북 생성
                logger.warning(
                    f"템플릿 파일을 찾을 수 없습니다: '{template_path}'. "
                    "새 빈 워크북으로 대신 시작합니다. "
                    "경로가 올바른지 확인하세요."
                )
                self.wb = openpyxl.Workbook()
                self.filepath = "output.xlsx"
        else:
            self.wb = openpyxl.Workbook()
            self.filepath = "output.xlsx"

    def write(
        self, cell_address: str, value: Any, sheet_name: Optional[str] = None
    ) -> None:
        """특정 셀에 단일 값을 씁니다.

        Args:
            cell_address: Excel 셀 주소 (예: "A1").
            value: 기록할 값.
            sheet_name: 시트 이름. None이면 활성 시트 사용.
        """
        ws = self._get_sheet(sheet_name)
        try:
            ws[cell_address] = value
        except Exception as e:
            logger.error(f"셀 '{cell_address}'에 쓰기 실패: {e}")

    def write_table(
        self,
        start_cell: str,
        data: List[Dict[str, Any]],
        headers: List[str],
        sheet_name: Optional[str] = None,
    ) -> None:
        """딕셔너리 목록을 테이블 형태로 작성합니다.

        시작 셀부터 헤더 행을 쓰고, 그 아래에 데이터를 기록합니다.

        Args:
            start_cell: 테이블 시작 셀 주소 (예: "A1").
            data: 딕셔너리 목록.
            headers: 딕셔너리에서 추출할 키 목록 (헤더 행으로도 사용).
            sheet_name: 시트 이름.
        """
        ws = self._get_sheet(sheet_name)
        try:
            col_idx, row_idx = cell_utils.coordinate_from_string(start_cell)
            col_idx = cell_utils.column_index_from_string(col_idx)
        except ValueError:
            logger.error(f"유효하지 않은 시작 셀 주소: '{start_cell}'")
            return

        for i, header in enumerate(headers):
            ws.cell(row=row_idx, column=col_idx + i).value = header

        current_row = row_idx + 1
        for item in data:
            for i, header in enumerate(headers):
                val = item.get(header)
                cell = ws.cell(row=current_row, column=col_idx + i)
                if val is not None:
                    cell.value = val
            current_row += 1

    def write_dict(
        self, data: Dict[str, Any], sheet_name: Optional[str] = None
    ) -> None:
        """딕셔너리 데이터를 특정 셀 또는 헤더 열에 씁니다.

        키가 셀 주소(예: "B2")이면 해당 셀에 직접 씁니다.
        그 외에는 첫 번째 행의 헤더 이름과 일치하는 열에 씁니다.

        Args:
            data: 쓸 데이터 딕셔너리.
            sheet_name: 시트 이름.
        """
        ws = self._get_sheet(sheet_name)

        header_map: Dict[str, int] = {}
        headers_scanned = False

        def scan_headers() -> bool:
            for col in range(1, ws.max_column + 1):
                val = ws.cell(row=1, column=col).value
                if val:
                    header_map[str(val)] = col
            return True

        for k, v in data.items():
            is_coord = False
            if k and k[0].isalpha() and k[-1].isdigit():
                try:
                    cell_utils.coordinate_from_string(k)
                    is_coord = True
                except ValueError:
                    is_coord = False

            if is_coord:
                ws[k] = v
            else:
                if not headers_scanned:
                    headers_scanned = scan_headers()

                col_idx = header_map.get(k)
                if col_idx:
                    ws.cell(row=2, column=col_idx, value=v)
                else:
                    logger.warning(
                        f"키 '{k}'에 해당하는 열 헤더 또는 셀 주소를 찾을 수 없습니다."
                    )

    def save(self, filepath: Optional[str] = None) -> None:
        """워크북을 파일 시스템에 저장합니다.

        Args:
            filepath: 저장 경로. None이면 초기화 시 지정된 경로 또는 "output.xlsx".
        """
        path = filepath or self.filepath
        self.wb.save(path)

    def _get_sheet(self, sheet_name: Optional[str]) -> Any:
        """시트 이름으로 워크시트를 반환합니다. 없으면 새로 생성합니다."""
        if sheet_name:
            if sheet_name in self.wb.sheetnames:
                return self.wb[sheet_name]
            else:
                return self.wb.create_sheet(sheet_name)
        return self.wb.active


class ExcelReader:
    """Excel 파일에서 데이터를 읽습니다."""

    def __init__(self, filepath: str) -> None:
        """ExcelReader를 초기화합니다.

        Args:
            filepath: 읽을 Excel 파일 경로.

        Raises:
            FileNotFoundError: 파일이 존재하지 않을 경우.
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"파일을 찾을 수 없습니다: {filepath}")
        self.wb = openpyxl.load_workbook(filepath, data_only=True)

    def sheet(self, sheet_name: str) -> SheetWrapper:
        """지정된 시트의 SheetWrapper를 반환합니다.

        Args:
            sheet_name: 읽을 시트 이름.

        Returns:
            SheetWrapper 인스턴스.

        Raises:
            KeyError: 시트가 존재하지 않을 경우.
        """
        if sheet_name not in self.wb.sheetnames:
            raise KeyError(f"시트 '{sheet_name}'를 찾을 수 없습니다.")
        return SheetWrapper(self.wb[sheet_name])
