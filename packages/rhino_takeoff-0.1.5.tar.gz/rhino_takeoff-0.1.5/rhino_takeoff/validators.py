import logging
from typing import Dict

logger = logging.getLogger(__name__)


class UnitValidator:
    """건축 단위(mm, cm, m) 변환 및 검증을 처리합니다.

    Rhino 모델은 기본적으로 mm 단위를 사용하지만, 실무 도면이나
    입력 데이터는 다양한 단위 체계를 혼용합니다. 이 클래스는
    단위 변환의 일관성을 보장합니다.
    """

    def __init__(self) -> None:
        pass

    def to_mm(self, value: float, unit: str) -> float:
        """값을 밀리미터(mm)로 변환합니다.

        Args:
            value: 변환할 수치.
            unit: 현재 단위 ("mm", "cm", "m").

        Returns:
            밀리미터 단위로 변환된 값. 지원하지 않는 단위는 원본 값을 반환합니다.
        """
        unit = unit.lower().strip()
        if unit == "mm":
            return value
        elif unit == "cm":
            return value * 10.0
        elif unit == "m":
            return value * 1000.0
        else:
            logger.warning(
                f"지원하지 않는 길이 단위: '{unit}'. 원본 값을 반환합니다. "
                f"지원 단위: mm, cm, m"
            )
            return value

    def to_m(self, value: float, unit: str) -> float:
        """값을 미터(m)로 변환합니다.

        Args:
            value: 변환할 수치.
            unit: 현재 단위 ("mm", "cm", "m").

        Returns:
            미터 단위로 변환된 값. 지원하지 않는 단위는 원본 값을 반환합니다.
        """
        unit = unit.lower().strip()
        if unit == "m":
            return value
        elif unit == "cm":
            return value / 100.0
        elif unit == "mm":
            return value / 1000.0
        else:
            logger.warning(
                f"지원하지 않는 길이 단위: '{unit}'. 원본 값을 반환합니다. "
                f"지원 단위: mm, cm, m"
            )
            return value

    def to_m2(self, value: float, unit: str) -> float:
        """값을 제곱미터(m²)로 변환합니다.

        Args:
            value: 변환할 수치.
            unit: 현재 단위 ("m2", "cm2", "mm2").

        Returns:
            제곱미터 단위로 변환된 값. 지원하지 않는 단위는 원본 값을 반환합니다.
        """
        unit = unit.lower().strip()
        if unit == "m2":
            return value
        elif unit == "cm2":
            return value / 10_000.0
        elif unit == "mm2":
            return value / 1_000_000.0
        else:
            logger.warning(
                f"지원하지 않는 면적 단위: '{unit}'. 원본 값을 반환합니다. "
                f"지원 단위: m2, cm2, mm2"
            )
            return value

    def to_mm2(self, value: float, unit: str) -> float:
        """값을 제곱밀리미터(mm²)로 변환합니다.

        Args:
            value: 변환할 수치.
            unit: 현재 단위 ("m2", "cm2", "mm2").

        Returns:
            제곱밀리미터 단위로 변환된 값. 지원하지 않는 단위는 원본 값을 반환합니다.
        """
        unit = unit.lower().strip()
        if unit == "mm2":
            return value
        elif unit == "cm2":
            return value * 100.0
        elif unit == "m2":
            return value * 1_000_000.0
        else:
            logger.warning(
                f"지원하지 않는 면적 단위: '{unit}'. 원본 값을 반환합니다. "
                f"지원 단위: m2, cm2, mm2"
            )
            return value

    def detect_unit(self, value: float) -> str:
        """값의 크기를 기반으로 건축 단위를 추정합니다.

        Rhino 모델에서 추출된 수치의 단위가 불명확할 때 사용하는 휴리스틱 도우미입니다.
        추정 결과를 절대적으로 신뢰하지 말고, 반드시 원본 모델 단위를 확인하세요.

        추정 기준 (건축 치수 기반 경험칙):
            - 1,000,000 초과: mm²  (예: 바닥 면적 3,000,000 mm²)
            - 1,000 초과:     mm   (예: 벽 높이 2,700 mm)
            - 100 이상 1000 이하: cm  (예: 창문 폭 150 cm)
            - 100 미만:       m    (예: 층고 3.0 m)

        Args:
            value: 단위를 추정할 수치.

        Returns:
            추정 단위 문자열 ("mm", "mm2", "cm", "m"). 추정 불가 시 "unknown".
        """
        if value > 1_000_000:
            logger.info(f"값 {value}: mm²로 추정됩니다.")
            return "mm2"
        elif value > 1_000:
            logger.info(f"값 {value}: mm로 추정됩니다.")
            return "mm"
        elif value >= 100:
            # 100~1000 범위는 cm 단위로 주로 사용 (창호, 마감재 치수 등)
            logger.info(f"값 {value}: cm로 추정됩니다.")
            return "cm"
        elif value >= 0:
            return "m"

        logger.warning(f"값 {value}에 대한 단위를 추정할 수 없습니다.")
        return "unknown"

    def convert_all(
        self, data: Dict[str, float], from_unit: str, to_unit: str
    ) -> Dict[str, float]:
        """딕셔너리의 모든 수치 값을 일괄 변환합니다.

        길이 단위(mm, cm, m) 간 변환만 지원합니다.
        지원하지 않는 단위 조합의 경우 원본 값을 그대로 반환합니다.

        Args:
            data: 변환할 키-값 딕셔너리.
            from_unit: 입력 단위 ("mm", "cm", "m").
            to_unit: 출력 단위 ("mm", "cm", "m").

        Returns:
            변환된 값의 새 딕셔너리. 원본 딕셔너리는 변경되지 않습니다.
        """
        result = {}
        supported_length_units = {"mm", "cm", "m"}
        for k, v in data.items():
            if (
                from_unit in supported_length_units
                and to_unit in supported_length_units
            ):
                val_in_m = self.to_m(v, from_unit)
                if to_unit == "m":
                    result[k] = val_in_m
                elif to_unit == "mm":
                    result[k] = val_in_m * 1000.0
                elif to_unit == "cm":
                    result[k] = val_in_m * 100.0
            else:
                result[k] = v
        return result


class AreaValidator(UnitValidator):
    """면적 값의 범위 유효성을 검사하는 특화 검증기.

    일반적으로 건축 설계 범위(0 ~ 100,000 m²)를 벗어나는 값은
    단위 설정 오류(예: mm² → m² 변환 누락)일 가능성이 높습니다.
    """

    def check_range(self, value_m2: float) -> bool:
        """면적 값이 합리적인 범위 내에 있는지 검사합니다.

        Args:
            value_m2: 검사할 면적 값 (m²).

        Returns:
            True이면 유효한 범위 (0 이상 100,000 이하).
            False이면 음수이거나 과도하게 큰 값.
        """
        if value_m2 < 0:
            logger.warning(f"면적은 음수가 될 수 없습니다: {value_m2} m²")
            return False
        if value_m2 > 100_000.0:
            logger.warning(
                f"면적이 비정상적으로 큽니다: {value_m2} m². "
                "단위 오류(mm² → m² 변환 누락)를 확인하세요."
            )
            return False
        return True
