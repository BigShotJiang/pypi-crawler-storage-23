# Rhino-Takeoff

![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![Rhino](https://img.shields.io/badge/Rhino-7%2F8-black)
![License](https://img.shields.io/badge/license-MIT-green)

**Automated Quantity Takeoff & ZEB Certification Library for Grasshopper/Rhino 3D Models.**

`rhino-takeoff` automates the extraction of architectural quantities (Area, Volume, Length) from Rhino/Grasshopper models and generates Excel reports compliant with the **Korean ZEB (Zero Energy Building) Certification Standards (2025)**.

It is designed to bridge the gap between complex BIM geometry and standardized certification requirements, handling everything from geometry processing to validatable Excel output.

## Installation

```bash
pip install rhino-takeoff
```

For pandas support:
```bash
pip install "rhino-takeoff[pandas]"
```

## Usage

### 1. Extracting Quantities

Use the `Extractor` to calculate precise quantities from Rhino objects. It handles both mesh-based (rhino3dm) and solid-based (RhinoCommon) calculations automatically.

```python
import rhino3dm
from rhino_takeoff import Extractor, Classifier

# Load your model
model = rhino3dm.File3dm.Read("project.3dm")
objects = model.Objects

# 1. Classify objects by layer/geometry
clf = Classifier()
classified = clf.classify_all(objects)

# 2. Extract quantities (Area in m²)
ext = Extractor()
results = ext.batch(objects, measure="area", unit="m2")

for res in results[:3]:
    print(f"{res['id']}: {res['value']:.2f} m²")
```

### 2. Generating ZEB Reports

Generate a certification-ready report by combining extracted data with project energy metrics.

```python
from rhino_takeoff.zeb import ZEBReport

# Initialize report
report = ZEBReport(project_name="Gangnam Office Tower")

# Set energy performance metrics (kWh/m²/year)
report.set_energy_consumption(primary_energy_kwh_m2_y=150.0, floor_area_m2=3000.0)
report.set_renewable_production(renewable_primary_energy_kwh_m2_y=35.0)

# Calculate Energy Independence Rate
rate = report.calc_energy_independence_rate() # e.g., 23.33%
grade = report.get_achievable_grade()         # e.g., "ZEB_5"

print(f"Independence Rate: {rate}%, Grade: {grade}")

# report.export_excel("ZEB_Report_2025.xlsx")
```

## Features

- **Geometry Processing**: 
  - Accurate mesh area calculation using cross-product integration.
  - Automatic solid/mesh conversion depending on the environment (Rhino vs. CI/CD).
- **Smart Deduplication**: 
  - Automatically helps removing overlapping volume/area between standard building elements (e.g., Column vs. Wall).
  - Uses specialized 2D projection logic for performance.
- **ZEB Certification**: 
  - Built-in logic for the latest Korean ZEB certification standards.
  - Auto-grading (1 to 5) based on energy independence rates.
- **Excel Output**: 
  - Preserves existing formatting and formulas in template files.

## Project Structure

- `rhino_takeoff.extractor`: Geometry extraction core.
- `rhino_takeoff.dedup`: Geometry intersection and deduplication logic.
- `rhino_takeoff.zeb`: ZEB certification logic and standards data.
- `rhino_takeoff.excel_io`: Excel file handling.

## License

MIT License. See [LICENSE](LICENSE) for details.
