from rhino_takeoff.dedup import Deduplicator
from unittest.mock import MagicMock, patch


def test_dedup_shapely(mock_geometry):
    dedup = Deduplicator()
    t1 = mock_geometry("t1")
    c1 = mock_geometry("c1")

    # Shapely fallback logic
    # Tolerance logic check
    dedup.remove_overlap([t1], [c1])
    rpt = dedup.last_report()
    assert "Shapely" in rpt.get("mode", "")


def test_dedup_rhino_boolean():
    # IS_RHINO = True case
    with patch("rhino_takeoff.dedup.IS_RHINO", True):
        with patch("rhino_takeoff.dedup.rg") as mock_rg:
            dedup = Deduplicator()
            t1 = MagicMock()
            c1 = MagicMock()

            # Success Case
            # rg.Brep.CreateBooleanDifference returns [result_brep]
            res_brep = MagicMock()
            mock_rg.Brep.CreateBooleanDifference.return_value = [res_brep]

            res = dedup.remove_overlap([t1], [c1])
            assert res[0] == res_brep
            assert dedup.last_report()["overlap_count"] == 1

            # Failure Case (None or Empty)
            mock_rg.Brep.CreateBooleanDifference.return_value = None
            res_fail = dedup.remove_overlap([t1], [c1])
            assert res_fail[0] == t1  # Original returned
            # warning logged

            # Exception Case
            mock_rg.Brep.CreateBooleanDifference.side_effect = Exception("Fail")
            dedup.remove_overlap([t1], [c1])
            # Should not crash, return original


def test_clean_model(mock_geometry):
    dedup = Deduplicator()
    classified = {"slab": [mock_geometry("s")], "wall": [mock_geometry("w")]}
    cleaned = dedup.clean_model(classified)
    assert len(cleaned["slab"]) == 1
