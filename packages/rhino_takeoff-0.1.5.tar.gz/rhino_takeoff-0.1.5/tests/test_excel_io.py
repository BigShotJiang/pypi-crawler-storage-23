import pytest
import unittest.mock
from unittest.mock import MagicMock, patch
from rhino_takeoff.excel_io import ExcelWriter, SheetWrapper


def test_sheet_wrapper_functionality():
    """SheetWrapper의 column(), row(), __getitem__이 정상 동작하는지 검증합니다."""
    mock_ws = unittest.mock.MagicMock()

    def cell_side_effect(row, column):
        m = unittest.mock.MagicMock()
        val = None
        if row == 1:
            if column == 1:
                val = "ColA"
            if column == 2:
                val = "ColB"
        elif row == 2:
            if column == 1:
                val = 10
            if column == 2:
                val = 20
        elif row == 3:
            if column == 1:
                val = 30
            if column == 2:
                val = None
        m.value = val
        return m

    mock_ws.cell.side_effect = cell_side_effect
    mock_ws.max_column = 2
    mock_ws.max_row = 3
    mock_ws.__getitem__.return_value.value = "AccessVal"

    sw = SheetWrapper(mock_ws)

    assert sw["A1"] == "AccessVal"
    assert sw.column("ColA") == [10, 30]
    assert sw.column("ColB") == [20]
    assert sw.column("NoHeader") == []
    assert sw.row(2) == {"ColA": 10, "ColB": 20}

    # pandas 없는 환경
    import sys

    with unittest.mock.patch.dict(sys.modules, {"pandas": None}):
        mock_ws.values = [["H1", "H2"], [1, 2]]
        res = sw.to_dataframe()
        assert isinstance(res, list)
        assert res == [["H1", "H2"], [1, 2]]


def test_reader_sheet_returns_wrapper():
    """ExcelReader.sheet()가 SheetWrapper를 반환하는지 검증합니다."""
    with unittest.mock.patch("os.path.exists", return_value=True):
        from rhino_takeoff.excel_io import ExcelReader

        reader = ExcelReader("dummy.xlsx")
        reader.wb.sheetnames = ["S1"]

        s = reader.sheet("S1")
        assert isinstance(s, SheetWrapper)

        with pytest.raises(KeyError):
            reader.sheet("NonExistent")


def test_write_table_logic():
    """write_table()이 None 값 항목도 건너뛰며 정상 동작하는지 검증합니다."""
    writer = ExcelWriter()
    data = [{"ColA": 1}, {"ColA": None}]
    writer.write_table("A1", data, ["ColA"])


def test_write_dict_logic():
    """write_dict()가 헤더 기반 열 쓰기를 수행하는지 검증합니다."""
    writer = ExcelWriter()

    def cell_side_effect(row, column, value=None):
        m = MagicMock()
        if row == 1 and column == 1:
            m.value = "Head"
        else:
            m.value = None
        return m

    writer.wb.active.cell.side_effect = cell_side_effect
    writer.write_dict({"Head": "Val"})


# ── 템플릿 누락 경고 테스트 (핵심 개선사항) ─────────────────────────────────


def test_writer_missing_template_warns(caplog, tmp_path):
    """존재하지 않는 템플릿 경로를 지정하면 WARNING 로그를 출력하고 새 워크북을 생성하는지 검증합니다."""
    import logging

    nonexistent = str(tmp_path / "does_not_exist.xlsx")

    with caplog.at_level(logging.WARNING, logger="rhino_takeoff.excel_io"):
        writer = ExcelWriter(template_path=nonexistent)

    # WARNING 메시지가 로그에 포함되어야 함
    assert any(
        "템플릿 파일을 찾을 수 없습니다" in message for message in caplog.messages
    ), f"경고 메시지가 출력되지 않았습니다. 로그: {caplog.messages}"
    # 그럼에도 워크북은 생성되어야 함
    assert writer.wb is not None
    assert writer.filepath == "output.xlsx"


def test_writer_valid_template_no_warning(tmp_path, caplog):
    """올바른 템플릿 경로 입력 시 경고 없이 로드되는지 검증합니다.

    conftest에서 openpyxl이 전역 mock되므로, os.path.exists를 True로 patch하여
    '파일이 존재한다'는 조건을 시뮬레이션합니다.
    """
    import logging

    valid_template_path = "/some/real/looking/template.xlsx"

    with caplog.at_level(logging.WARNING, logger="rhino_takeoff.excel_io"):
        with patch("os.path.exists", return_value=True):
            writer = ExcelWriter(template_path=valid_template_path)

    warning_messages = [
        m for m in caplog.messages if "템플릿 파일을 찾을 수 없습니다" in m
    ]
    assert len(warning_messages) == 0, f"불필요한 경고 발생: {warning_messages}"
    assert writer.filepath == valid_template_path


def test_writer_no_template_no_warning(caplog):
    """template_path를 생략하면 경고 없이 새 워크북이 생성되는지 검증합니다."""
    import logging

    with caplog.at_level(logging.WARNING, logger="rhino_takeoff.excel_io"):
        writer = ExcelWriter()

    assert writer.filepath == "output.xlsx"
    warning_messages = [m for m in caplog.messages if "템플릿" in m]
    assert len(warning_messages) == 0
