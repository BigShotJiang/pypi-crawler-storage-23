from rhino_takeoff.zeb import ZEBReport, _resolve_building_type
from unittest.mock import patch


# ── 건물 유형 정규화 테스트 ──────────────────────────────────────────────────


def test_resolve_building_type_residential():
    """주거 관련 문자열이 'residential'로 정규화되는지 검증합니다."""
    for input_str in [
        "Residential",
        "residential",
        "주거",
        "주택",
        "아파트",
        "공동주택",
    ]:
        assert _resolve_building_type(input_str) == "residential", (
            f"'{input_str}' → 'residential' 기대"
        )


def test_resolve_building_type_non_residential():
    """비주거 관련 문자열이 'non_residential'로 정규화되는지 검증합니다."""
    for input_str in [
        "Commercial",
        "non_residential",
        "비주거",
        "업무",
        "판매",
        "교육",
    ]:
        assert _resolve_building_type(input_str) == "non_residential", (
            f"'{input_str}' → 'non_residential' 기대"
        )


def test_resolve_building_type_unknown_fallback(caplog):
    """알 수 없는 건물 유형은 'residential'로 폴백되고 WARNING을 출력하는지 검증합니다."""
    result = _resolve_building_type("unknown_type_xyz")
    assert result == "residential"


# ── 기존 기본 테스트 (회귀 방지) ────────────────────────────────────────────


def test_export_summary():
    """export_summary()가 올바른 필드와 값을 반환하는지 검증합니다."""
    zeb = ZEBReport("Summary Test")
    zeb.set_energy_consumption(100.0, 1000.0)
    zeb.set_renewable_production(50.0)
    zeb.add_envelope("Wall", 100.0, 0.2)

    summary = zeb.export_summary()
    assert summary["project"] == "Summary Test"
    assert summary["energy_independence_rate"] == 50.0
    assert summary["achieved_grade"] == "ZEB_4"
    assert summary["items_count"] == 1
    assert summary["building_type"] == "residential"


def test_energy_independence_calculation():
    """에너지 자립률 계산식이 정확한지 검증합니다."""
    zeb = ZEBReport("Test ZEB")
    zeb.set_energy_consumption(100.0, 1000.0)
    zeb.set_renewable_production(20.0)

    rate = zeb.calc_energy_independence_rate()
    assert rate == 20.0


def test_grade_boundaries():
    """ZEB 등급 경계값에서 compliant 판정이 정확한지 검증합니다."""
    zeb = ZEBReport("Boundaries")
    zeb.set_energy_consumption(100.0, 500.0)

    # ZEB_5 경계: 19.9% → 미달
    zeb.set_renewable_production(19.9)
    res = zeb.check_compliance("ZEB_5")
    assert not res["compliant"]
    assert zeb.get_achievable_grade() == "None"

    # ZEB_5 경계: 20.0% → 적합 (주거 ZEB_5 소비량 한도: 200 kWh, 100 ≤ 200 → OK)
    zeb.set_renewable_production(20.0)
    res = zeb.check_compliance("ZEB_5")
    assert res["compliant"]
    assert zeb.get_achievable_grade() == "ZEB_5"

    # ZEB_PLUS: 자립률 100%, 소비량 기준 null → 소비량 무관하게 compliant
    zeb.set_renewable_production(100.0)
    res = zeb.check_compliance("ZEB_PLUS")
    assert res["compliant"]
    assert res["max_primary_energy_kwh_m2_y"] is None  # ZEB_PLUS는 소비량 기준 없음
    assert zeb.get_achievable_grade() == "ZEB_PLUS"

    # ZEB_1: 자립률 100% + 소비량 ≤ 60 kWh/m²·y 충족 검사
    zeb.set_energy_consumption(60.0, 500.0)
    zeb.set_renewable_production(60.0)  # 자립률 100%
    res = zeb.check_compliance("ZEB_1")
    assert res["compliant"]


def test_unknown_standard():
    """알 수 없는 등급 검사 시 compliant=False를 반환하는지 검증합니다."""
    zeb = ZEBReport("Unknown")
    res = zeb.check_compliance("ZEB_UNKNOWN")
    assert not res["compliant"]


def test_zero_consumption():
    """1차 에너지 소비량이 0일 때 자립률 0.0을 반환하는지 검증합니다."""
    zeb = ZEBReport("Zero")
    zeb.set_energy_consumption(0.0, 100.0)
    assert zeb.calc_energy_independence_rate() == 0.0


# ── 용도별 기준 분리 테스트 ──────────────────────────────────────────────────


def test_building_type_residential_grades():
    """주거 건물은 주거 기준 섹션을 참조하는지 검증합니다."""
    zeb = ZEBReport("Apt", building_type="아파트")
    assert zeb._resolved_type == "residential"

    zeb.set_energy_consumption(100.0, 200.0)
    zeb.set_renewable_production(50.0)  # 50% → ZEB_4 (주거)

    grade = zeb.get_achievable_grade()
    assert grade == "ZEB_4"


def test_building_type_non_residential_grades():
    """비주거 건물은 비주거 기준 섹션을 참조하는지 검증합니다."""
    zeb = ZEBReport("Office", building_type="업무")
    assert zeb._resolved_type == "non_residential"

    zeb.set_energy_consumption(100.0, 500.0)
    zeb.set_renewable_production(50.0)  # 50% → ZEB_4 (비주거 기준도 동일)

    grade = zeb.get_achievable_grade()
    assert grade == "ZEB_4"


def test_check_compliance_returns_building_type():
    """check_compliance() 결과에 building_type 필드가 포함되는지 검증합니다."""
    zeb = ZEBReport("Test", building_type="Commercial")
    zeb.set_energy_consumption(100.0, 1000.0)
    zeb.set_renewable_production(25.0)

    res = zeb.check_compliance("ZEB_5")
    assert "building_type" in res
    assert res["building_type"] == "non_residential"


def test_primary_energy_consumption_limit():
    """1차 에너지 소비량 한도 초과 시 등급이 하향되는지 검증합니다.

    예: 주거 ZEB_1은 자립률 100% AND 소비량 ≤ 60 kWh/m²·y 조건.
    자립률은 충족하나 소비량이 초과하면 ZEB_1이 아닌 하위 등급이어야 합니다.
    """
    zeb = ZEBReport("HighEnergy", building_type="Residential")
    # 자립률 100% 충족하지만 소비량 200으로 ZEB_1 기준(60) 초과
    zeb.set_energy_consumption(200.0, 1000.0)
    zeb.set_renewable_production(200.0)

    res_zeb1 = zeb.check_compliance("ZEB_1")
    # 자립률 OK지만 소비량 초과 → non-compliant
    assert not res_zeb1["energy_consumption_compliant"]
    assert not res_zeb1["compliant"]

    # ZEB_PLUS는 소비량 기준 없음(null) → 자립률만 충족하면 됨
    res_plus = zeb.check_compliance("ZEB_PLUS")
    assert res_plus["energy_consumption_compliant"] is None
    assert res_plus["compliant"]


# ── export_excel() 테스트 ────────────────────────────────────────────────────


def test_export_excel_creates_file(tmp_path):
    """export_excel()이 지정 경로에 Excel 파일을 생성하는지 검증합니다."""
    zeb = ZEBReport("Excel Test", building_type="Residential")
    zeb.set_energy_consumption(120.0, 500.0)
    zeb.set_renewable_production(60.0)
    zeb.add_envelope("외벽", 200.0, 0.21)
    zeb.add_envelope("지붕", 150.0, 0.15)

    filepath = str(tmp_path / "zeb_report.xlsx")

    # export_excel은 내부에서 `from .excel_io import ExcelWriter`로 가져오지만,
    # 실제 맨모듈에서는 rhino_takeoff.excel_io.ExcelWriter로 패치해야 합니다.
    with patch("rhino_takeoff.excel_io.ExcelWriter") as MockWriter:
        mock_instance = MockWriter.return_value
        zeb.export_excel(filepath)

        # write_table이 최소 1회 호출되어야 함
        assert mock_instance.write_table.call_count >= 1
        mock_instance.save.assert_called_once_with(filepath)
