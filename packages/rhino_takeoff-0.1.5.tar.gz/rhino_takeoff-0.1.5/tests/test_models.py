from rhino_takeoff.models import BuildingElement, TakeoffResult, ElementType


def test_building_element_creation():
    """BuildingElement가 올바른 필드로 생성되는지 검증합니다."""
    be = BuildingElement(id="123", element_type=ElementType.SLAB, area_m2=100.0)
    assert be.id == "123"
    assert be.element_type == ElementType.SLAB
    assert be.area_m2 == 100.0


def test_takeoff_result_aggregation():
    """TakeoffResult의 total_area_m2, total_volume_m3 합산이 정확한지 검증합니다."""
    e1 = BuildingElement(
        id="1", element_type=ElementType.SLAB, area_m2=10.0, volume_m3=2.0
    )
    e2 = BuildingElement(
        id="2", element_type=ElementType.WALL, area_m2=20.0, volume_m3=5.0
    )

    tr = TakeoffResult(project_name="Test", elements=[e1, e2])

    assert tr.total_area_m2 == 30.0
    assert tr.total_volume_m3 == 7.0


# ── by_floor() 테스트 ────────────────────────────────────────────────────────


def test_by_floor_basic():
    """층별 면적·체적 집계가 정확한지 검증합니다."""
    elements = [
        BuildingElement(
            id="1",
            element_type=ElementType.SLAB,
            area_m2=100.0,
            volume_m3=30.0,
            floor_number=1,
        ),
        BuildingElement(
            id="2",
            element_type=ElementType.SLAB,
            area_m2=100.0,
            volume_m3=30.0,
            floor_number=2,
        ),
        BuildingElement(
            id="3",
            element_type=ElementType.WALL,
            area_m2=50.0,
            volume_m3=10.0,
            floor_number=1,
        ),
        BuildingElement(
            id="4",
            element_type=ElementType.COLUMN,
            area_m2=5.0,
            volume_m3=3.0,
            floor_number=2,
        ),
    ]
    tr = TakeoffResult(project_name="FloorTest", elements=elements)
    by_floor = tr.by_floor()

    # 1층: 슬라브 + 벽
    assert by_floor[1]["total_area_m2"] == 150.0
    assert by_floor[1]["total_volume_m3"] == 40.0

    # 2층: 슬라브 + 기둥
    assert by_floor[2]["total_area_m2"] == 105.0
    assert by_floor[2]["total_volume_m3"] == 33.0


def test_by_floor_none_key():
    """floor_number가 None인 부재는 None 키로 집계되는지 검증합니다."""
    elements = [
        BuildingElement(
            id="1", element_type=ElementType.WALL, area_m2=50.0, floor_number=None
        ),
        BuildingElement(
            id="2", element_type=ElementType.WALL, area_m2=30.0, floor_number=1
        ),
    ]
    tr = TakeoffResult(project_name="NoneFloor", elements=elements)
    by_floor = tr.by_floor()

    assert None in by_floor
    assert by_floor[None]["total_area_m2"] == 50.0
    assert by_floor[1]["total_area_m2"] == 30.0


def test_by_floor_empty():
    """요소가 없을 때 by_floor()는 빈 딕셔너리를 반환해야 합니다."""
    tr = TakeoffResult(project_name="Empty", elements=[])
    assert tr.by_floor() == {}


# ── by_type() 테스트 ─────────────────────────────────────────────────────────


def test_by_type_basic():
    """부재 유형별 집계가 정확한지 검증합니다."""
    elements = [
        BuildingElement(
            id="1", element_type=ElementType.SLAB, area_m2=100.0, volume_m3=30.0
        ),
        BuildingElement(
            id="2", element_type=ElementType.SLAB, area_m2=80.0, volume_m3=24.0
        ),
        BuildingElement(id="3", element_type=ElementType.COLUMN, volume_m3=2.0),
    ]
    tr = TakeoffResult(project_name="TypeTest", elements=elements)
    by_type = tr.by_type()

    assert by_type["slab"]["total_area_m2"] == 180.0
    assert by_type["slab"]["total_volume_m3"] == 54.0
    assert by_type["slab"]["count"] == 2

    assert by_type["column"]["total_area_m2"] == 0.0
    assert by_type["column"]["total_volume_m3"] == 2.0
    assert by_type["column"]["count"] == 1


def test_by_type_missing_areas():
    """area_m2/volume_m3가 None인 경우 0.0으로 처리되는지 검증합니다."""
    elements = [
        BuildingElement(id="1", element_type=ElementType.BEAM),
        BuildingElement(id="2", element_type=ElementType.BEAM, area_m2=10.0),
    ]
    tr = TakeoffResult(project_name="NoneTest", elements=elements)
    by_type = tr.by_type()

    assert by_type["beam"]["total_area_m2"] == 10.0
    assert by_type["beam"]["count"] == 2


# ── summary_table() 테스트 ───────────────────────────────────────────────────


def test_summary_table_structure():
    """summary_table()이 올바른 구조의 행 목록을 반환하는지 검증합니다."""
    elements = [
        BuildingElement(
            id="abc-123",
            element_type=ElementType.WALL,
            layer="S-WALL",
            area_m2=50.0,
            volume_m3=15.0,
            length_m=None,
            floor_number=3,
            notes="외벽",
        )
    ]
    tr = TakeoffResult(project_name="TableTest", elements=elements)
    rows = tr.summary_table()

    assert len(rows) == 1
    row = rows[0]
    assert row["ID"] == "abc-123"
    assert row["유형"] == "wall"
    assert row["레이어"] == "S-WALL"
    assert row["층"] == 3
    assert row["면적 (m²)"] == 50.0
    assert row["체적 (m³)"] == 15.0
    assert row["길이 (m)"] == 0.0  # None → 0.0
    assert row["메모"] == "외벽"


def test_summary_table_empty():
    """요소가 없을 때 summary_table()은 빈 리스트를 반환해야 합니다."""
    tr = TakeoffResult(project_name="Empty", elements=[])
    assert tr.summary_table() == []


def test_element_type_foundation_exists():
    """ElementType에 FOUNDATION이 정의되어 있는지 검증합니다."""
    assert hasattr(ElementType, "FOUNDATION")
    assert ElementType.FOUNDATION.value == "foundation"
