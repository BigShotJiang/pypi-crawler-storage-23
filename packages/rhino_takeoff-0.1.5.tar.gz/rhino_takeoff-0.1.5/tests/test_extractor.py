import pytest
from rhino_takeoff.extractor import Extractor, _area_from_mesh, _volume_from_mesh
from unittest.mock import MagicMock, patch


# ── _area_from_mesh 기존 테스트 ───────────────────────────────────────────────


def test_area_from_mesh():
    """삼각형 메시 1개의 넓이를 정확히 계산하는지 검증합니다."""
    import rhino3dm as rg

    mesh = rg.Mesh()
    mesh.AddVertex(0, 0, 0)
    mesh.AddVertex(10, 0, 0)
    mesh.AddVertex(0, 10, 0)
    mesh.AddFace(0, 1, 2)
    assert _area_from_mesh(mesh) == 50.0


# ── _volume_from_mesh 새 테스트 ───────────────────────────────────────────────


def _make_box_mesh(w: float, d: float, h: float):
    """발산 정리 체적 계산을 위한 폐합 직육면체 Mock Mesh를 생성합니다.

    conftest의 rhino3dm mock은 AddFace(a,b,c,d)를 삼각형으로 변환하므로
    쿼드 페이스를 사용할 수 없습니다. 대신 삼각형 페이스만으로 구성합니다.
    """

    class Pt:
        def __init__(self, x, y, z):
            self.X, self.Y, self.Z = x, y, z

    class TriFace:
        """삼각형 페이스 (D == C로 설정하면 삼각형으로 처리됨)."""

        def __init__(self, a, b, c):
            self.A, self.B, self.C, self.D = a, b, c, c  # D==C → 삼각형

    class BoxMesh:
        def __init__(self):
            self.Vertices = [
                Pt(0, 0, 0),  # 0
                Pt(w, 0, 0),  # 1
                Pt(w, d, 0),  # 2
                Pt(0, d, 0),  # 3
                Pt(0, 0, h),  # 4
                Pt(w, 0, h),  # 5
                Pt(w, d, h),  # 6
                Pt(0, d, h),  # 7
            ]
            # 6면 × 2삼각형 = 12 삼각형 페이스 (외향 법선 방향 통일)
            self.Faces = [
                TriFace(0, 2, 1),
                TriFace(0, 3, 2),  # 하면 (z=0, 내향)
                TriFace(4, 5, 6),
                TriFace(4, 6, 7),  # 상면 (z=h, 외향)
                TriFace(0, 1, 5),
                TriFace(0, 5, 4),  # 앞면 (y=0)
                TriFace(3, 6, 2),
                TriFace(3, 7, 6),  # 뒷면 (y=d)
                TriFace(0, 4, 7),
                TriFace(0, 7, 3),  # 좌면 (x=0)
                TriFace(1, 2, 6),
                TriFace(1, 6, 5),  # 우면 (x=w)
            ]

    return BoxMesh()


def test_volume_from_mesh_unit_cube():
    """단위 정육면체 메시(1x1x1)의 체적이 1.0과 일치하는지 검증합니다.

    발산 정리 기반 계산은 BoundingBox와 달리 형상이 복잡해도
    정확한 체적을 보장합니다. 이 테스트는 기본 정확도를 확인합니다.
    """
    mesh = _make_box_mesh(1.0, 1.0, 1.0)
    vol = _volume_from_mesh(mesh)
    assert abs(vol - 1.0) < 1e-9, f"단위 정육면체 체적 오차: {abs(vol - 1.0)}"


def test_volume_from_mesh_empty():
    """빈 메시는 0.0을 반환해야 합니다."""
    import rhino3dm as rg

    mesh = rg.Mesh()
    assert _volume_from_mesh(mesh) == 0.0


def test_volume_from_mesh_none():
    """None 메시는 0.0을 반환해야 합니다."""
    assert _volume_from_mesh(None) == 0.0


def test_volume_known_box():
    """10x5x2 직육면체 메시의 체적(100)이 정확한지 검증합니다."""
    W, D, H = 10.0, 5.0, 2.0
    mesh = _make_box_mesh(W, D, H)
    vol = _volume_from_mesh(mesh)
    expected = W * D * H  # 100.0
    assert abs(vol - expected) < 1e-6, f"직육면체 체적 오차: {abs(vol - expected)}"


# ── Extractor.volume() 개선 검증 ─────────────────────────────────────────────


def test_volume_uses_mesh_calculation():
    """rhino3dm 환경에서 _volume_from_mesh가 정확히 작동하는지 직접 검증합니다.

    Extractor.volume()은 isinstance(geometry, rg.Mesh) 체크를 통해 Mesh 경로를 사용합니다.
    BoxMesh 헬퍼는 conftest mock의 rg.Mesh 인스턴스가 아니므로, 편의를 위해
    핵심 함수인 _volume_from_mesh를 직접 검증합니다.
    """
    from rhino_takeoff.extractor import _volume_from_mesh as vfm

    # 1000x1000x500 mm 직육면체 = 500,000,000 mm³ = 0.5 m³
    mesh = _make_box_mesh(1000.0, 1000.0, 500.0)
    vol_mm3 = vfm(mesh)
    expected_mm3 = 1000.0 * 1000.0 * 500.0  # = 500,000,000
    assert abs(vol_mm3 - expected_mm3) < 1.0, (
        f"1000x1000x500 mm 체적 오차: {abs(vol_mm3 - expected_mm3)} mm³"
    )

    # m³ 변환 검증
    result_m3 = vol_mm3 / 1_000_000_000.0
    assert abs(result_m3 - 0.5) < 1e-6, f"m³ 변환 오차: {abs(result_m3 - 0.5)}"


def test_volume_bbox_fallback_sets_flag(mock_geometry):
    """메시 추출 불가 시 BBox 폴백 + approximated 플래그가 설정되는지 검증합니다."""
    ext = Extractor()
    # mock_geometry는 Mesh/Brep가 아니므로 BBox 폴백 경로를 탑니다.
    geo = mock_geometry("v1")

    result = ext.volume(geo, "m3")
    # BBox: 10000x10000x300 mm = 3e13 mm³ = 30 m³
    assert result == pytest.approx(30.0, rel=1e-6)
    assert ext.last_volume_was_approximated is True


# ── Extractor.area() 기존 테스트 ─────────────────────────────────────────────


def test_extractor_rhino3dm_modes():
    """Mesh, Brep 지오메트리의 면적 계산을 검증합니다."""
    ext = Extractor()
    import rhino3dm as rg

    mesh = rg.Mesh()
    mesh.AddVertex(0, 0, 0)
    mesh.AddVertex(1000, 0, 0)
    mesh.AddVertex(1000, 1000, 0)
    mesh.AddVertex(0, 1000, 0)
    mesh.AddFace(0, 1, 2, 3)
    assert ext.area(mesh, "m2") == 1.0

    brep = rg.Brep()

    def get_mesh_mock(t):
        return mesh

    brep.GetMesh = get_mesh_mock
    val_m2_brep = ext.area(brep, unit="m2")
    assert val_m2_brep == 1.0


def test_extractor_is_rhino_true():
    """RhinoCommon 환경에서 AreaMassProperties/VolumeMassProperties를 사용하는지 검증합니다."""
    with patch("rhino_takeoff.extractor.IS_RHINO", True):
        with patch("rhino_takeoff.extractor.rg") as mock_rg:
            mock_amp = MagicMock()
            mock_amp.Area = 123.0
            mock_rg.AreaMassProperties.Compute.return_value = mock_amp
            mock_vmp = MagicMock()
            mock_vmp.Volume = 456.0
            mock_rg.VolumeMassProperties.Compute.return_value = mock_vmp

            ext = Extractor()
            geo = MagicMock()

            assert ext.area(geo, "mm2") == 123.0
            assert ext.volume(geo, "raw") == 456.0

            mock_rg.AreaMassProperties.Compute.side_effect = Exception("Fail")
            assert ext.area(geo, "mm2") == 0.0

            mock_rg.AreaMassProperties.Compute.side_effect = None
            mock_rg.AreaMassProperties.Compute.return_value = None
            assert ext.area(geo, "mm2") == 0.0


def test_extractor_getmesh_none():
    """GetMesh()가 None을 반환하는 Brep에서 면적 0.0을 반환하는지 검증합니다."""
    ext = Extractor()
    import rhino3dm as rg

    class BadBrep(rg.Brep):
        def GetMesh(self, t):
            return None

    b = BadBrep()
    assert ext.area(b) == 0.0


def test_length_calc():
    """GetLength()가 있는 객체의 길이를 m 단위로 정확히 변환하는지 검증합니다."""
    ext = Extractor()
    c = MagicMock()
    c.GetLength.return_value = 1000.0
    assert ext.length(c) == 1.0


# ── batch() 에러 필드 테스트 ─────────────────────────────────────────────────


def test_batch_success_fields(mock_geometry):
    """정상 처리 시 success=True, error=None 필드가 반환되는지 검증합니다."""
    ext = Extractor()
    geo = mock_geometry("g1")
    results = ext.batch([geo], measure="area", unit="m2")
    assert len(results) == 1
    r = results[0]
    assert r["success"] is True
    assert r["error"] is None
    assert r["id"] == "g1"
    assert r["measure"] == "area"


def test_batch_error_fields():
    """처리 중 예외 발생 시 success=False, error 메시지가 기록되는지 검증합니다."""
    ext = Extractor()

    # area() 호출 시 예외를 발생시키는 가짜 지오메트리
    bad_geo = MagicMock()
    bad_geo.Id = "bad_id"
    bad_geo.UserDictionary = {}

    with patch.object(ext, "area", side_effect=RuntimeError("강제 오류")):
        results = ext.batch([bad_geo], measure="area", unit="m2")

    assert len(results) == 1
    r = results[0]
    assert r["success"] is False
    assert r["value"] == 0.0
    assert r["error"] is not None
    assert "RuntimeError" in r["error"] or "강제 오류" in r["error"]


def test_batch_invalid_measure():
    """지원하지 않는 measure 값 입력 시 success=False가 반환되는지 검증합니다."""
    ext = Extractor()
    geo = MagicMock()
    geo.Id = "test"
    geo.UserDictionary = {}

    results = ext.batch([geo], measure="invalid_measure", unit="m2")
    assert results[0]["success"] is False
    assert results[0]["error"] is not None


def test_batch_approximated_flag(mock_geometry):
    """BBox 폴백 발생 시 batch 결과의 approximated=True를 검증합니다."""
    ext = Extractor()
    geo = mock_geometry("v1")
    results = ext.batch([geo], measure="volume", unit="m3")
    assert results[0]["approximated"] is True


def test_batch_multiple_geometries(mock_geometry):
    """여러 지오메트리를 배치 처리할 때 모든 결과가 포함되는지 검증합니다."""
    ext = Extractor()
    geos = [mock_geometry(f"g{i}") for i in range(5)]
    results = ext.batch(geos, measure="area", unit="m2")
    assert len(results) == 5
    for r in results:
        assert r["success"] is True
