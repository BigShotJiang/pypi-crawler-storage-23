from rhino_takeoff.classifier import Classifier
from unittest.mock import MagicMock


def test_classifier_full(mock_geometry):
    """기본 영어 레이어명으로 분류가 정상 동작하는지 검증합니다."""
    clf = Classifier()

    s = mock_geometry("s", "SLAB")
    w = mock_geometry("w", "WALL")

    res = clf.classify_all([s, w])
    assert len(res["slab"]) == 1
    assert len(res["wall"]) == 1

    rpt = clf.report()
    assert rpt["slab"] == 1
    assert rpt["wall"] == 1


def test_classify_unknown_fallback(mock_geometry):
    """레이어명 미매칭 시 BoundingBox 비율 기반 폴백이 동작하는지 검증합니다."""
    clf = Classifier()
    u = mock_geometry("u", "UNK")

    # conftest의 기본 MockBBox는 납작한(slab-like) 형상
    assert clf.classify(u) == "slab"

    # 정육면체 비율로 override → unknown
    class MockBBoxCube:
        class Pt:
            def __init__(self, x, y, z):
                self.X, self.Y, self.Z = x, y, z

        def __init__(self):
            self.Min = self.Pt(0, 0, 0)
            self.Max = self.Pt(1000, 1000, 1000)
            self.IsValid = True

    u.GetBoundingBox = MagicMock(return_value=MockBBoxCube())
    assert clf.classify(u) == "unknown"


# ── 한글 레이어명 분류 테스트 ─────────────────────────────────────────────────


def test_korean_column_layer(mock_geometry):
    """한글 '기둥' 레이어명이 column으로 분류되는지 검증합니다."""
    clf = Classifier()
    geo = mock_geometry("k1", "3F-기둥")
    assert clf.classify(geo, layer_name="3F-기둥") == "column"


def test_korean_slab_layer(mock_geometry):
    """한글 '슬라브'/'슬래브' 레이어명이 slab으로 분류되는지 검증합니다."""
    clf = Classifier()
    assert clf.classify(mock_geometry("k2"), layer_name="B1-슬라브") == "slab"
    assert clf.classify(mock_geometry("k3"), layer_name="옥상-슬래브") == "slab"


def test_korean_wall_layer(mock_geometry):
    """한글 벽 관련 레이어명 변형들이 wall로 분류되는지 검증합니다."""
    clf = Classifier()
    for layer in ["구조벽", "전단벽", "외벽", "내벽", "벽"]:
        result = clf.classify(mock_geometry("kw"), layer_name=layer)
        assert result == "wall", f"'{layer}' → wall 기대, 실제: {result}"


def test_korean_beam_layer(mock_geometry):
    """한글 보 레이어명 변형들이 beam으로 분류되는지 검증합니다."""
    clf = Classifier()
    for layer in ["큰보", "작은보", "RC보", "보"]:
        result = clf.classify(mock_geometry("kb"), layer_name=layer)
        assert result == "beam", f"'{layer}' → beam 기대, 실제: {result}"


def test_korean_foundation_layer(mock_geometry):
    """한글 기초 레이어명 변형들이 foundation으로 분류되는지 검증합니다."""
    clf = Classifier()
    for layer in ["파일기초", "매트기초", "독립기초", "줄기초", "기초"]:
        result = clf.classify(mock_geometry("kf"), layer_name=layer)
        assert result == "foundation", f"'{layer}' → foundation 기대, 실제: {result}"


def test_autocad_bim_layer_standards(mock_geometry):
    """국내 AutoCAD BIM 표준 레이어명(A-COLS, S-WALL 등)이 정확히 분류되는지 검증합니다."""
    clf = Classifier()
    cases = [
        ("A-COLS", "column"),
        ("S-COL", "column"),
        ("COL", "column"),
        ("A-SLAB", "slab"),
        ("S-SLAB", "slab"),
        ("A-WALL", "wall"),
        ("S-WALL", "wall"),
        ("A-BEAM", "beam"),
        ("FD", "foundation"),
    ]
    for layer, expected in cases:
        result = clf.classify(mock_geometry("std"), layer_name=layer)
        assert result == expected, f"'{layer}' → {expected} 기대, 실제: {result}"


def test_english_patterns_still_work(mock_geometry):
    """기존 영어 패턴이 한글 패턴 추가 후에도 동작하는지 하위 호환성 검증합니다.

    \\bWALL\\b 패턴은 "WALL"이 독립 단어(언더스코어 경계 포함)인 경우 매핑됩니다.
    "column", "slab" 등 소문자도 (?i) 플래그로 매핑됩니다.
    """
    clf = Classifier()
    assert clf.classify(mock_geometry("e1"), layer_name="column_01") == "column"
    assert clf.classify(mock_geometry("e2"), layer_name="SLAB_ROOF") == "slab"
    # "WALL" 이 독립 단어로 포함된 케이스 (wall_exterior → \bWALL\b 매핑)
    assert clf.classify(mock_geometry("e3"), layer_name="WALL_exterior") == "wall"
    assert clf.classify(mock_geometry("e4"), layer_name="beam_main") == "beam"
    assert (
        clf.classify(mock_geometry("e5"), layer_name="foundation_mat") == "foundation"
    )


def test_custom_rules_override(mock_geometry):
    """사용자 정의 규칙이 기본 규칙을 올바르게 대체하는지 검증합니다."""
    custom_rules = {r"MY_COL": "column", r"MY_SL": "slab"}
    clf = Classifier(rules=custom_rules)
    assert clf.classify(mock_geometry("c1"), layer_name="MY_COL_01") == "column"
    assert clf.classify(mock_geometry("c2"), layer_name="MY_SL_2F") == "slab"
    # 기본 규칙은 비활성화됨
    assert (
        clf.classify(mock_geometry("c3"), layer_name="기둥") == "slab"
    )  # BBox 폴백(납작한 형상)
