import pytest
from rhino_takeoff.validators import UnitValidator, AreaValidator


def test_unit_conversion():
    """기본 단위 변환이 정확한지 검증합니다."""
    uv = UnitValidator()
    assert uv.to_mm(1.0, "m") == 1000.0
    assert uv.to_m(1000.0, "mm") == 1.0
    assert uv.to_mm(10.0, "cm") == 100.0


def test_to_m2_and_mm2():
    """면적 단위 변환 정확도를 검증합니다 (cm2 케이스 포함)."""
    uv = UnitValidator()
    assert uv.to_m2(1_000_000.0, "mm2") == 1.0
    assert uv.to_mm2(1.0, "m2") == 1_000_000.0

    # cm2 지원 검증
    assert uv.to_m2(10_000.0, "cm2") == pytest.approx(1.0, rel=1e-9)
    assert uv.to_mm2(1.0, "cm2") == pytest.approx(100.0, rel=1e-9)


def test_detect_unit_mm():
    """1000 초과 값이 'mm'로 추정되는지 검증합니다."""
    uv = UnitValidator()
    assert uv.detect_unit(5000) == "mm"
    assert uv.detect_unit(1001) == "mm"


def test_detect_unit_mm2():
    """1,000,000 초과 값이 'mm2'로 추정되는지 검증합니다."""
    uv = UnitValidator()
    assert uv.detect_unit(2_000_000) == "mm2"
    assert uv.detect_unit(1_000_001) == "mm2"


def test_detect_unit_cm():
    """100 이상 1000 이하 값이 'cm'로 추정되는지 검증합니다.

    이 범위는 창호 폭, 마감재 두께 등 cm 단위를 주로 사용하는 건축 치수에 해당합니다.
    """
    uv = UnitValidator()
    assert uv.detect_unit(150) == "cm"
    assert uv.detect_unit(100) == "cm"
    assert uv.detect_unit(999.9) == "cm"
    assert uv.detect_unit(500) == "cm"


def test_detect_unit_m():
    """100 미만 값이 'm'로 추정되는지 검증합니다."""
    uv = UnitValidator()
    assert uv.detect_unit(3.5) == "m"
    assert uv.detect_unit(0.0) == "m"
    assert uv.detect_unit(99.9) == "m"


def test_convert_all():
    """딕셔너리 일괄 단위 변환이 정확한지 검증합니다."""
    uv = UnitValidator()
    data = {"len1": 1000, "len2": 2000}

    res = uv.convert_all(data, "mm", "m")
    assert res["len1"] == 1.0
    assert res["len2"] == 2.0

    # cm 변환 포함
    res_cm = uv.convert_all({"a": 1.0}, "m", "cm")
    assert res_cm["a"] == 100.0


def test_area_validator():
    """AreaValidator.check_range()의 유효/무효 경계를 검증합니다."""
    av = AreaValidator()

    assert av.check_range(100.0) is True
    assert av.check_range(0.0) is True

    assert av.check_range(-10.0) is False
    assert av.check_range(200_000.0) is False


def test_validator_warnings():
    """지원하지 않는 단위는 원본 값을 반환하는지 검증합니다."""
    uv = UnitValidator()
    assert uv.to_mm(100, "km") == 100
    assert uv.to_m(100, "km") == 100
    assert uv.to_m2(100, "km2") == 100
    assert uv.to_mm2(100, "km2") == 100
