from .main import main, typer

typer.run(main)