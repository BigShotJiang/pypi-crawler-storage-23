# src/workpeg_sdk/runtime.py

import importlib
import json
import os
import sys
import traceback
from typing import Any, Callable, Dict, Tuple


DEFAULT_ENTRYPOINT = "app.main:main"


class FunctionRuntimeError(Exception):
    """Custom exception for runtime-level errors."""
    pass


def parse_entrypoint(entry: str) -> Tuple[str, str]:
    """
    Parse 'module.path:func_name' into (module, func).
    """
    try:
        module_name, func_name = entry.split(":", 1)
        module_name = module_name.strip()
        func_name = func_name.strip()
        if not module_name or not func_name:
            raise ValueError
        return module_name, func_name
    except ValueError:
        raise FunctionRuntimeError(
            f"Invalid FUNCTION_ENTRYPOINT format: '{entry}'. "
            "Expected 'module.path:func_name'."
        )


def _ensure_cwd_on_syspath() -> None:
    """
    Ensure current working directory is at the front of sys.path.

    This is critical when running via a console script installed by pip,
    because sys.path[0] is the script's directory (e.g. venv/bin),
    NOT the current working directory.
    """
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)


def load_function() -> Callable[[Dict[str, Any], Dict[str, Any]], Any]:
    """
    Load the user function based on env FUNCTION_ENTRYPOINT or default.
    """
    _ensure_cwd_on_syspath()

    entry = os.getenv("FUNCTION_ENTRYPOINT", DEFAULT_ENTRYPOINT)
    module_name, func_name = parse_entrypoint(entry)

    try:
        module = importlib.import_module(module_name)
    except Exception as exc:
        raise FunctionRuntimeError(
            f"Failed to import module '{module_name}' from '{entry}': {exc}"
        ) from exc

    try:
        fn = getattr(module, func_name)
    except AttributeError as exc:
        raise FunctionRuntimeError(
            f"Module '{module_name}'"
            f" does not define '{func_name}' from '{entry}'."
        ) from exc

    if not callable(fn):
        raise FunctionRuntimeError(
            f"'{entry}' is not callable. Expected a function."
        )

    return fn


def read_request() -> Dict[str, Any]:
    """
    Read a single JSON object from stdin.
    Expected format: {"context": {...}, "payload": {...}}
    """
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise FunctionRuntimeError("No input received on stdin.")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise FunctionRuntimeError("Input JSON must be a JSON object.")
        return data
    except json.JSONDecodeError as exc:
        raise FunctionRuntimeError(f"Invalid JSON input: {exc}") from exc


def run_once() -> int:
    """
    Run a single invocation:
      - load function
      - read request
      - call function
      - emit JSON result

    Returns exit code (0 on success, 1 on error).
    """
    try:
        fn = load_function()
        request = read_request()

        context = request.get("context", {})
        payload = request.get("payload", {})

        if not isinstance(context, dict):
            raise FunctionRuntimeError(
                "Field 'context' must be a JSON object.")
        if not isinstance(payload, dict):
            raise FunctionRuntimeError(
                "Field 'payload' must be a JSON object.")

        result = fn(context, payload)

        output = {
            "status": "success",
            "result": result,
        }
        print(json.dumps(output))
        return 0

    except FunctionRuntimeError as e:
        # Runtime / wiring error
        err_output = {
            "status": "error",
            "error_type": "runtime_error",
            "error": str(e),
        }
        # Send JSON to stdout (for the host)
        # and more detail to stderr (for logs)
        print(json.dumps(err_output))
        print(f"[workpeg-runtime] runtime_error: {e}", file=sys.stderr)
        return 1

    except Exception as e:
        # User code error
        trace = traceback.format_exc()
        err_output = {
            "status": "error",
            "error_type": "user_error",
            "error": str(e),
            "trace": trace,
        }
        print(json.dumps(err_output))
        print(f"[workpeg-runtime] user_error: {e}\n{trace}", file=sys.stderr)
        return 1


def main() -> None:
    """
    Console script entrypoint for 'workpeg-runtime'.
    """
    exit_code = run_once()
    sys.exit(exit_code)
