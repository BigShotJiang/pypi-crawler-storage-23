# Workpeg Function Project

This directory was created using **Workpeg SDK**.

It contains everything you need to build and run a single **Workpeg Function**, which can later be attached to a Peg inside Workpeg.

---

## Project Structure

```text
app/
  __init__.py
  main.py        # Your function: def main(context, payload) -> dict
requirements.txt # Python dependencies (must include workpeg)
Dockerfile       # Example container runtime using workpeg-runtime
```

---

## Function Contract

Your function **must** define:

```python
def main(context: dict, payload: dict) -> dict:
    ...
```

- `context` – execution metadata injected by Workpeg (user, peg, execution id, etc.)
- `payload` – input data sent by the caller
- return value – must be JSON serializable

By default, the runtime looks for `app.main:main`.
You can change this using the `FUNCTION_ENTRYPOINT` environment variable:

```bash
export FUNCTION_ENTRYPOINT="module.path:function_name"
```

---

## Running Locally

Make sure `workpeg` is installed (or use the generated `requirements.txt`):

```bash
pip install -r requirements.txt
```

Then run the function:

```bash
echo '{"context": {}, "payload": {"hello": "world"}}' | workpeg-runtime
```

Expected output:

```json
{ "status": "success", "result": { "hello": "world" } }
```

---

## Docker (Optional)

You can build and run the container using the included `Dockerfile`:

```bash
docker build -t my-workpeg-function .
echo '{"context": {}, "payload": {"hello": "world"}}' | docker run --rm -i my-workpeg-function
```

---

## More

This template is part of the official Workpeg SDK.

Repo: [https://gitlab.com/workpeg/workpeg](https://gitlab.com/workpeg/workpeg)
Full documentation and Peg integration guides are coming soon.
