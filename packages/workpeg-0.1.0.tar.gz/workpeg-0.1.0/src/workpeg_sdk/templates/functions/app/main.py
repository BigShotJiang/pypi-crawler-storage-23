def main(context, payload):
    return payload
