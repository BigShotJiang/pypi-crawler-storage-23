# src/workpeg_sdk/create_new.py
import argparse
import os
import shutil
from pathlib import Path
import importlib.resources as pkg_resources


class TemplateError(Exception):
    pass


def _copy_tree(src_root: Path, dst_root: Path, *, force: bool) -> None:
    """
    Recursively copy src_root directory contents into dst_root.
    """
    if not src_root.exists():
        raise TemplateError(f"Template root not found: {src_root}")

    dst_root.mkdir(parents=True, exist_ok=True)

    for item in src_root.rglob("*"):
        rel = item.relative_to(src_root)
        dst = dst_root / rel

        if item.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
            continue

        if dst.exists() and not force:
            raise TemplateError(f"Target file exists: {dst} (use --force)")

        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, dst)


def create_new_project(target_dir: str, *, force: bool = False) -> Path:
    """
    Copy the function template from workpeg_sdk/templates/functions/*
    into target_dir.
    """
    target = Path(target_dir).expanduser().resolve()

    # Get a Traversable pointing at .../workpeg_sdk/templates/functions
    traversable = (
        pkg_resources.files("workpeg_sdk") / "templates" / "functions"
    )

    # as_file() gives us a real filesystem path even if the package
    # is loaded from a wheel/zip. This completely avoids the old
    # "not available as a filesystem path" issue.
    with pkg_resources.as_file(traversable) as src_path:
        src_root = Path(src_path)
        _copy_tree(src_root, target, force=force)

    return target


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="workpeg-new-function",
        description="Create a new Workpeg function"
        " project from the built-in template.",
    )
    p.add_argument(
        "path",
        help="Target directory to create/populate (e.g. ./my-function).",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing files in the target directory.",
    )
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    try:
        out = create_new_project(args.path, force=args.force)
        print(str(out))
    except TemplateError as e:
        print(f"ERROR: {e}", file=os.sys.stderr)
        raise SystemExit(2)
