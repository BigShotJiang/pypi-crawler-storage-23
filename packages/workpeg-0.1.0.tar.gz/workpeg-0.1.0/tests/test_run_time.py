# tests/test_run_time.py

import importlib.resources as pkg_resources
import subprocess
import io
import json
import sys
from pathlib import Path

import pytest

from workpeg_sdk.runtime import (
    FunctionRuntimeError,
    parse_entrypoint,
    load_function,
    read_request,
    run_once,
)


# ------------------------------
# Helpers
# ------------------------------

def _clear_app_modules():
    """Remove any cached 'app' modules so imports see the new temp package."""
    to_delete = [name for name in sys.modules if name ==
                 "app" or name.startswith("app.")]
    for name in to_delete:
        del sys.modules[name]


def _write_simple_app(tmp_path: Path, body: str | None = None):
    """
    Create app/main.py in tmp_path.
    Default main just returns payload.
    """
    if body is None:
        body = """
def main(context, payload):
    return payload
"""

    app_dir = tmp_path / "app"
    app_dir.mkdir()
    (app_dir / "__init__.py").write_text("")
    (app_dir / "main.py").write_text(body)


# ------------------------------
# parse_entrypoint tests
# ------------------------------

def test_parse_entrypoint_valid():
    module, func = parse_entrypoint("my.module:handler")
    assert module == "my.module"
    assert func == "handler"


def test_parse_entrypoint_invalid_raises():
    with pytest.raises(FunctionRuntimeError):
        parse_entrypoint("no-colon")
    with pytest.raises(FunctionRuntimeError):
        parse_entrypoint(":missing_module")
    with pytest.raises(FunctionRuntimeError):
        parse_entrypoint("missing_func:")


# ------------------------------
# load_function tests
# ------------------------------

def test_load_function_uses_default_entrypoint(tmp_path, monkeypatch):
    """
    Ensure load_function() imports app.main:main
    from the current working directory.
    """
    _clear_app_modules()
    _write_simple_app(tmp_path)

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("FUNCTION_ENTRYPOINT", raising=False)

    fn = load_function()
    assert callable(fn)
    result = fn({"ctx": True}, {"hello": "world"})
    # main just returns payload
    assert result == {"hello": "world"}


def test_load_function_invalid_module_raises(monkeypatch):
    _clear_app_modules()
    monkeypatch.setenv("FUNCTION_ENTRYPOINT", "nonexistent.module:main")

    with pytest.raises(FunctionRuntimeError) as exc:
        load_function()
    assert "Failed to import module" in str(exc.value)


def test_load_function_invalid_attribute_raises(tmp_path, monkeypatch):
    """
    Module exists, but function attribute does not.
    """
    _clear_app_modules()

    mod_dir = tmp_path / "app"
    mod_dir.mkdir()
    (mod_dir / "__init__.py").write_text("")
    (mod_dir / "main.py").write_text(
        """
FOO = 123
"""
    )

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("FUNCTION_ENTRYPOINT", "app.main:missing_fn")

    with pytest.raises(FunctionRuntimeError) as exc:
        load_function()
    assert "does not define 'missing_fn'" in str(exc.value)


def test_load_function_not_callable_raises(tmp_path, monkeypatch):
    """
    Attribute exists but is not callable.
    """
    _clear_app_modules()

    mod_dir = tmp_path / "app"
    mod_dir.mkdir()
    (mod_dir / "__init__.py").write_text("")
    (mod_dir / "main.py").write_text(
        """
main = 123  # not callable
"""
    )

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("FUNCTION_ENTRYPOINT", raising=False)

    with pytest.raises(FunctionRuntimeError) as exc:
        load_function()
    assert "is not callable" in str(exc.value)


# ------------------------------
# read_request tests
# ------------------------------

def test_read_request_valid(monkeypatch):
    payload = {"context": {"a": 1}, "payload": {"b": 2}}
    stdin = io.StringIO(json.dumps(payload))
    monkeypatch.setattr(sys, "stdin", stdin)

    result = read_request()
    assert result == payload


def test_read_request_empty_raises(monkeypatch):
    monkeypatch.setattr(sys, "stdin", io.StringIO(""))
    with pytest.raises(FunctionRuntimeError) as exc:
        read_request()
    assert "No input received on stdin" in str(exc.value)


def test_read_request_invalid_json_raises(monkeypatch):
    monkeypatch.setattr(sys, "stdin", io.StringIO("{not-json}"))
    with pytest.raises(FunctionRuntimeError) as exc:
        read_request()
    assert "Invalid JSON input" in str(exc.value)


# ------------------------------
# run_once tests
# ------------------------------

def test_run_once_success(tmp_path, monkeypatch, capsys):
    """
    Full path: load_function + read_request + user main() succeed.
    """
    _clear_app_modules()
    _write_simple_app(tmp_path)

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("FUNCTION_ENTRYPOINT", raising=False)

    input_data = {"context": {"user": 1}, "payload": {"x": 10}}
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(input_data)))

    exit_code = run_once()
    captured = capsys.readouterr()

    assert exit_code == 0
    stdout_json = json.loads(captured.out)
    assert stdout_json["status"] == "success"
    # main returns payload unchanged
    assert stdout_json["result"] == input_data["payload"]
    assert "[workpeg-runtime]" not in captured.err


def test_run_once_runtime_error_invalid_context(tmp_path, monkeypatch, capsys):
    """
    If 'context' is not a dict, run_once should emit a runtime_error.
    """
    _clear_app_modules()
    _write_simple_app(tmp_path)

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("FUNCTION_ENTRYPOINT", raising=False)

    # context is a string, not an object
    input_data = {"context": "not-a-dict", "payload": {"x": 10}}
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(input_data)))

    exit_code = run_once()
    captured = capsys.readouterr()

    assert exit_code == 1

    stdout_json = json.loads(captured.out)
    assert stdout_json["status"] == "error"
    assert stdout_json["error_type"] == "runtime_error"
    assert "context' must be a JSON object" in stdout_json["error"]

    assert "[workpeg-runtime] runtime_error" in captured.err


def test_run_once_user_error_from_function(tmp_path, monkeypatch, capsys):
    """
    If user function raises, run_once should emit user_error.
    """
    _clear_app_modules()

    # main will raise ValueError
    _write_simple_app(
        tmp_path,
        body="""
def main(context, payload):
    raise ValueError("boom")
""",
    )

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("FUNCTION_ENTRYPOINT", raising=False)

    input_data = {"context": {}, "payload": {"x": 1}}
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(input_data)))

    exit_code = run_once()
    captured = capsys.readouterr()

    assert exit_code == 1

    stdout_json = json.loads(captured.out)
    assert stdout_json["status"] == "error"
    assert stdout_json["error_type"] == "user_error"
    assert "boom" in stdout_json["error"]
    assert "trace" in stdout_json
    assert "ValueError" in stdout_json["trace"]

    assert "[workpeg-runtime] user_error" in captured.err


def test_workpeg_runtime_template(tmp_path):
    """
    Test using SDK template function copied from package templates.
    """

    # --- 1. Create app directory ---
    app_dir = tmp_path / "app"
    app_dir.mkdir()

    # Make it a package
    (app_dir / "__init__.py").write_text("")

    # --- 2. Load template from installed package ---
    template_pkg = "workpeg_sdk.templates.functions.app"

    with pkg_resources.files(template_pkg).joinpath("main.py").open("r") as f:
        template_code = f.read()

    # --- 3. Write template main.py into temp app ---
    (app_dir / "main.py").write_text(template_code)

    # --- 4. Prepare input ---
    input_payload = {
        "context": {"user_id": 123},
        "payload": {"hello": "world", "x": 42},
    }

    # --- 5. Run CLI ---
    result = subprocess.run(
        ["workpeg-runtime"],
        input=json.dumps(input_payload),
        text=True,
        capture_output=True,
        cwd=tmp_path,
    )

    assert result.returncode == 0

    output = json.loads(result.stdout)

    assert output["status"] == "success"
    assert output["result"] == input_payload["payload"]
