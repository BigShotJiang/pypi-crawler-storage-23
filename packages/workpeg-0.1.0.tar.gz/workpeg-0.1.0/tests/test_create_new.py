import subprocess
import importlib.resources as pkg_resources


def test_create_new_copies_template(tmp_path):
    project_dir = tmp_path / "my-func"

    # Run the console script
    result = subprocess.run(
        ["workpeg-new-function", str(project_dir)],
        text=True,
        capture_output=True,
        cwd=tmp_path,
    )

    assert result.returncode == 0
    assert project_dir.exists()

    # Confirm expected files exist
    assert (project_dir / "app" / "__init__.py").exists()
    assert (project_dir / "app" / "main.py").exists()

    # Confirm main.py content matches template main.py
    template_pkg = "workpeg_sdk.templates.functions.app"
    template_main = pkg_resources.files(
        template_pkg).joinpath("main.py").read_text()

    created_main = (project_dir / "app" / "main.py").read_text()
    assert created_main == template_main


def test_create_new_refuses_overwrite_without_force(tmp_path):
    project_dir = tmp_path / "my-func"
    project_dir.mkdir()
    (project_dir / "app").mkdir()
    (project_dir / "app" / "main.py").write_text("existing")

    result = subprocess.run(
        ["workpeg-new-function", str(project_dir)],
        text=True,
        capture_output=True,
        cwd=tmp_path,
    )

    assert result.returncode == 2
    assert "use --force" in (result.stderr or "")


def test_create_new_overwrites_with_force(tmp_path):
    project_dir = tmp_path / "my-func"
    project_dir.mkdir(parents=True)
    (project_dir / "app").mkdir()
    (project_dir / "app" / "main.py").write_text("existing")

    result = subprocess.run(
        ["workpeg-new-function", str(project_dir), "--force"],
        text=True,
        capture_output=True,
        cwd=tmp_path,
    )

    assert result.returncode == 0

    # Ensure template main.py replaced the old content
    created_main = (project_dir / "app" / "main.py").read_text()
    assert created_main != "existing"
