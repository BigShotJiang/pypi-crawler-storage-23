# Workpeg SDK

SDK for building **Workpeg Pegs and Functions**.

Currently focused on:

- `workpeg-runtime` – function execution runtime
- `workpeg-new-function` – project scaffolding

Frontend features, Peg integrations, push & deployment tooling are coming soon.

---

## Installation

```bash
pip install workpeg
```

---

## Getting Started

### 1. Create a New Function

```bash
workpeg-new-function my-peg
cd my-peg
```

This generates:

```
my-peg/
  app/
    __init__.py
    main.py
  requirements.txt
  Dockerfile
```

---

### 2. Implement Your Function

Edit `app/main.py`:

```python
def main(context, payload):
    return payload
```

Every Workpeg Function must define:

```python
def main(context: dict, payload: dict) -> dict
```

- `context` → execution metadata (provided by Workpeg)
- `payload` → input data
- return value → must be JSON serializable

---

### 3. Run Locally

```bash
echo '{"context": {}, "payload": {"hello": "world"}}' | workpeg-runtime
```

Example output:

```json
{ "status": "success", "result": { "hello": "world" } }
```

---

## Runtime

`workpeg-runtime`:

1. Reads JSON from STDIN
2. Loads `app.main:main`
3. Executes the function
4. Writes structured JSON to STDOUT

Override entrypoint:

```bash
FUNCTION_ENTRYPOINT="module.path:function_name" workpeg-runtime
```

---

## Roadmap

- Peg-level integrations
- Frontend features (Streamlit/Reflex style)
- Push & deployment tooling
- Hosted execution

---

📘 Documentation coming soon.

MIT License
