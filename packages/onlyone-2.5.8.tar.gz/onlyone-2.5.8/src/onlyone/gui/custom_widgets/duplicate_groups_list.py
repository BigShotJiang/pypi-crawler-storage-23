"""
Copyright (c) 2025 initumX (initum.x@gmail.com)
Licensed under the MIT License

duplicate_groups_list.py

UI component for displaying and interacting with duplicate file groups.
Allows users to preview files, open them, reveal in explorer, or move to trash.

Emits signals instead of handling deletion directly, which keeps this widget reusable
and decoupled from business logic.
"""
from __future__ import annotations
import sys
from PySide6.QtWidgets import QListWidget, QListWidgetItem, QMenu, QAbstractItemView, QWidget
from PySide6.QtGui import QAction
from PySide6.QtCore import Qt, Signal
from onlyone.core.models import File, DuplicateGroup
from onlyone.services.file_service import FileService
from onlyone.core.measurer import  bytes_to_human


class DuplicateGroupsList(QListWidget):
    """
    A custom list widget that displays duplicate groups.

    Signals:
        file_selected (File): Emitted when a file item is clicked.
        delete_requested (list[str]): Emitted when files should be deleted.
    """
    file_selected = Signal(File)
    delete_requested = Signal(list)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)
        self.itemClicked.connect(self.on_item_clicked)
        self.currentItemChanged.connect(self._on_current_item_changed)
        self.current_groups = []

    def set_groups(self, groups: list[DuplicateGroup]):
        """Displays a list of duplicate groups in the UI."""
        self.current_groups = groups
        self._populate_list()

    def _populate_list(self):
        """Internal method to populate the list with current groups"""
        self.clear()

        # Global DEL file counter — does not reset between groups
        del_counter = 1

        for idx, group in enumerate(self.current_groups):
            # Sort: favorite directory files first (they will be "KEEP")
            group.files.sort(key=lambda f: not f.is_from_fav_dir)
            size_str = bytes_to_human(group.size)

            # Group header
            folder_title = f"📁 Group {idx + 1} | Size: {size_str}"
            folder_title_item = QListWidgetItem(folder_title)
            folder_title_item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.addItem(folder_title_item)

            for file_idx, file in enumerate(group.files):
                fav_marker = " ✅" if file.is_from_fav_dir else ""

                # First file = KEEP, others = DEL with global number
                is_keep = (file_idx == 0)

                if is_keep:
                    status_marker = " [KEEP]"
                    foreground_color = Qt.GlobalColor.darkGreen
                else:
                    status_marker = f" [DEL #{del_counter}]"
                    foreground_color = Qt.GlobalColor.darkRed
                    del_counter += 1  # Increment global counter

                item_text = f"     {file.name}{fav_marker}{status_marker}"
                tooltip_text = f"Path: {file.path}"

                item = QListWidgetItem(item_text)
                item.setToolTip(tooltip_text)
                item.setData(Qt.ItemDataRole.UserRole, file)
                item.setForeground(foreground_color)
                self.addItem(item)

            # Empty line between groups
            empty_item = QListWidgetItem("")
            empty_item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.addItem(empty_item)

    def on_item_clicked(self, item):
        """Emits signal when a file item is clicked."""
        file = item.data(Qt.ItemDataRole.UserRole)
        if file:
            self.file_selected.emit(file)

    def _on_current_item_changed(self, current, _previous):
        """Handles current item changes (via mouse or keyboard)."""
        if current:
            file = current.data(Qt.ItemDataRole.UserRole)
            if file:
                self.file_selected.emit(file)

    def show_context_menu(self, point):
        """Shows context menu on right-click."""
        selected_items = self.selectedItems()
        if not selected_items:
            return

        menu = QMenu(self)

        if len(selected_items) == 1:
            file = selected_items[0].data(Qt.ItemDataRole.UserRole)
            open_action = QAction("Open", self)
            reveal_action = QAction("Reveal in Explorer", self)
            delete_action = QAction("Move to Trash", self)

            open_action.triggered.connect(lambda _: FileService.open_file(file.path))
            reveal_action.triggered.connect(lambda _: FileService.reveal_in_explorer(file.path))
            delete_action.triggered.connect(lambda _: self.delete_selected_files([selected_items[0]]))

            menu.addAction(open_action)
            menu.addAction(reveal_action)
            menu.addSeparator()
            menu.addAction(delete_action)

        else:
            menu_text = f"Move {len(selected_items)} files to Trash"
            delete_action = QAction(menu_text, self)
            delete_action.triggered.connect(lambda _: self.delete_selected_files(selected_items))
            menu.addAction(delete_action)

        menu.exec(self.mapToGlobal(point))

    def delete_selected_files(self, selected_items):
        """Emits signal with file paths to be moved to trash."""
        file_paths = [item.data(Qt.ItemDataRole.UserRole).path for item in selected_items]
        self.delete_requested.emit(file_paths)

    def keyPressEvent(self, event):
        """
        Handles key press events for deleting selected files.
        Supports:
        - Delete / Backspace on all platforms
        - Cmd+Backspace on macOS (user expectation)
        """

        # --- 1. Handle Ctrl+Space for toggling selection ---
        # This allows keyboard-only users to select/deselect items without mouse
        if event.key() == Qt.Key.Key_Space and event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            current = self.currentItem()
            # Ensure we don't select header items (which have no UserRole data)
            if current and current.data(Qt.ItemDataRole.UserRole) is not None:
                # Toggle selection state
                current.setSelected(not current.isSelected())
                event.accept()
                return

        # --- 2. Handle Delete / Backspace for deletion ---
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            # macOS: Cmd+Backspace should also trigger deletion
            is_macos_cmd_backspace = (
                    sys.platform == 'darwin' and
                    event.key() == Qt.Key.Key_Backspace and
                    event.modifiers() & Qt.KeyboardModifier.MetaModifier
            )

            # Windows/Linux: standard Delete/Backspace behavior
            is_standard_delete = (
                    sys.platform != 'darwin' and
                    event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace)
            )

            if is_standard_delete or is_macos_cmd_backspace:
                selected_items = self.selectedItems()
                # Filter only items that contain file data (exclude group headers)
                file_items = [
                    item for item in selected_items
                    if item.data(Qt.ItemDataRole.UserRole) is not None
                ]
                if file_items:
                    self.delete_selected_files(file_items)
                    event.accept()
                    return

        # Pass all other key events to the parent class for default handling
        super().keyPressEvent(event)