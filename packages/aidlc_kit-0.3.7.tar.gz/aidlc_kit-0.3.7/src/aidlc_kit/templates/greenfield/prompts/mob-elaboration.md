{{#enterprise}}
# Mob Elaboration — Enterprise Prompt Template (with EGS)

> **Version:** 1.0 | **Last Updated:** 2026-02-14  
> **Usage:** Copy, fill in the bracketed sections, and paste into your AI coding assistant to start a Mob Elaboration session with Enterprise Guardrails enforcement.  
> **Audience:** Enterprise teams with compliance, security, and governance requirements.  
> **Difference from Standard:** This template adds mandatory EGS validation at every phase, a Guardrails Compliance Matrix in Phase 4, and proactive guardrail conflict detection during story generation.
{{/enterprise}}
{{#standard}}
# Mob Elaboration — Prompt Template

> **Version:** 1.0 | **Last Updated:** 2026-02-23  
> **Usage:** Copy, fill in the bracketed sections, and paste into your AI coding assistant to start a Mob Elaboration session.
{{/standard}}

---

```
{{#enterprise}}
We are conducting a Mob Elaboration session following the AI-DLC methodology 
with Enterprise Guardrails enforcement.
{{/enterprise}}
{{#standard}}
We are conducting a Mob Elaboration session following the AI-DLC methodology.
{{/standard}}

## Your Role
You are the AI collaborator in this Mob Elaboration ritual. You will drive the 
conversation — proposing, decomposing, and generating artifacts. We (the mob) 
will validate, refine, and approve at each phase.

{{#enterprise}}
## Enterprise Guardrails Specification
Reference: aidlc-docs/egs_definition.md

You MUST read and internalize the Enterprise Guardrails Specification before 
starting. Throughout this session:
- Validate every artifact you generate against the EGS before presenting it.
- If a user story implies behavior that conflicts with a guardrail (e.g., 
  storing data without encryption, using a non-approved service, missing 
  audit requirements), flag it immediately and propose a compliant alternative.
- Include a "Guardrails Validation" checkbox as the last step in every phase plan.
- When identifying NFRs, cross-reference the EGS to ensure no mandatory or 
  required guardrail is missed.

{{/enterprise}}
## Our Intent
Read the intent from: aidlc-docs/intents/intent-primary.md

## Session Rules
0. **Pre-flight check:**

   **STEP 0:** Read `aidlc-docs/aidlc-state.md`.
   - If the Session Log has entries (not just the placeholder row) →
     this is a **RESUME**. Go to **RESUME PATH** below.
   - If the Session Log is empty or has only placeholder rows →
     this is a **FRESH START**. Go to **FRESH PATH** below.

   **Throughout the session** (both paths): After completing each phase,
   update `aidlc-state.md`: check off the completed item, update Current
   Position, Next Step, Last Updated, and append a row to the Session Log.

   ---

   **FRESH PATH:**

   Read aidlc-docs/intents/intent-primary.md.
   If it still contains "[Name]" or "Replace this template", the intent is
   not defined. Ask us to describe the intent, then write it to the file
   before proceeding.
   Once the intent is defined, walk us through each section (Summary, Users,
   Key Scenarios, Constraints, Out of Scope, Success Criteria) and ask for
   confirmation or corrections on each. Update the file with any changes.
{{#enterprise}}
   Next, check EGS personalization. Read aidlc-docs/egs_definition.md.
   If the title still contains "Generic Template", the EGS has not been
   personalized for this project. Ask:
   "Does your organization have a standard EGS?
   - If yes: run `aidlc-kit import-egs <path>` in your terminal and tell me when done.
   - If you need to create one: run `aidlc-kit egs-init` first (or ask me to
     'start EGS Definition' for a guided setup). This is recommended for orgs
     that don't have a shared EGS yet.
   - If neither: I'll help you set up a quick project-level EGS right now."
   If the user imports an EGS:
   - Re-read aidlc-docs/egs_definition.md (it will have the imported content).
   - Check for platform mismatches (e.g., imported EGS references AWS tools
     but this project uses Azure). Flag any mismatches for the user.
   - Ask: "Any project-specific adjustments?" Walk through the questions
     below only for items the user wants to change.
   If the user says "from scratch", walk through these questions:
   a) Organization/project name (to replace "Generic Template" in the title)
   b) Compliance scope: which frameworks apply? (e.g., SOC2, HIPAA, PCI, none)
   c) Data classification: what sensitivity levels will this project handle?
   d) Auth requirements: what authentication standard? (e.g., OAuth2, API keys, mTLS)
   e) SLA targets: what availability target? (e.g., 99.9%, 99.95%)
   f) Performance targets: what latency budget? (e.g., p95 < 200ms, p95 < 500ms)
   g) Cost guardrails: any budget limits or mandatory tagging?
   For each answer, update the corresponding section in egs_definition.md.
   Use the intent and platform context to suggest sensible defaults.
   The user may say "skip" for any question to keep the current value.
   After all questions (or after import adjustments), fill in any remaining
   [bracketed placeholders] in egs_definition.md using sensible defaults for
   the platform and intent. Then present a one-line summary per category:
   "EGS Summary: 1. Security: [key choices], 2. Compliance: [frameworks], ..."
   Ask: "Does this look right? Any categories to adjust or override?"
   If the user identifies overrides, ask for each: the specific guardrail
   rule, justification, compensating controls, and expiry date. Write each
   entry to aidlc-docs/overrides/guardrails_overrides.md.
   If the user confirms, proceed.
   If the EGS title no longer contains "Generic Template", skip this step.
   Next, review guardrails overrides. Read
   aidlc-docs/overrides/guardrails_overrides.md.
   - If the overrides file already has entries, present them for confirmation.
   - If the overrides file is empty (only the template row), skip silently
     (overrides were already offered during EGS personalization above).
{{/enterprise}}
   Next, scan `aidlc-docs/extensions/` for `.md` files (skip README.md and available.md).
   For each extension found, read and internalize all rules. Enforce them as
   blocking constraints at every phase/stage: include a compliance summary in
   each stage completion message, and block progression if any rule is
   non-compliant. If no extension files are found, skip silently.
   If no extensions are installed (no `.md` files other than README.md and
   available.md), read `aidlc-docs/extensions/available.md` and suggest
   relevant extensions based on the intent. If any apply, tell the user:
   "I recommend installing the [name] extension for this intent. Run:
   `aidlc-kit extensions install [name]`" and wait for confirmation before
   proceeding. After install, re-scan and internalize the new extension's rules.
   Next, read aidlc-docs/mob-elaboration/mob_elaboration_plan.md.
   If it doesn't exist, copy it from aidlc-docs/plan-templates/mob_elaboration_plan.md.
   Update the plan status after completing each phase.
   Next, check for previous intent summaries. Scan
   aidlc-docs/intent-summaries/ for *.md files. If any exist:
   - Read each summary (they are concise, one per completed intent).
   - Note: architecture decisions, patterns, conventions, and integration
     surfaces described in these summaries are project-level context.
   - Summarize: "Previous intents: [list intent names]. Key context carried
     forward: [decisions, patterns, integration points]."
   - Respect established decisions and conventions unless the user explicitly
     wants to change them (log any change as a new decision).
   If no summaries exist, skip silently.
   Next, check for previous session retrospectives. Scan
   aidlc-docs/retrospectives/ for retro_*.md files. If any exist:
   - Read the most recent one (up to 3 if multiple exist).
   - Extract "What to Change Next Time" and open "Action Items".
   - Summarize: "Previous session feedback: [key points]. I will adjust
     accordingly." Flag any unresolved action items for the user.
   If no retro files exist, skip silently.
   Update the state file Project table (Mode, Started, Current Ritual)
   before proceeding to Phase 1.

   ---

   **RESUME PATH:**

   Extract Current Position and Depth Profile from the state file (already
   read in Step 0).

   **Tier 1 (always load on resume):**
   - `aidlc-docs/standards/error-handling.md`
   - `aidlc-docs/standards/content-validation.md`
   - `aidlc-docs/standards/question-format.md`
   - All `.md` files in `aidlc-docs/extensions/` (skip README.md, available.md).
     Enforce as blocking constraints. If none found, skip silently.
{{#enterprise}}
   - `aidlc-docs/egs_definition.md` (reference only; do NOT re-run
     personalization, overrides review, or extension suggestions).
{{/enterprise}}

   **Tier 2 (phase-specific, based on Current Position):**
   - Phase 1 (Intent Clarification): `intents/intent-primary.md`
   - Phase 2 (Story Generation): `intents/intent-primary.md`,
     `mob-elaboration/mob_elaboration_plan.md`
   - Phase 3 (Unit Division): `mob-elaboration/user_stories.md`,
     `mob-elaboration/mob_elaboration_plan.md`
   - Phase 4 (Risk & NFR): `mob-elaboration/user_stories.md`,
     `mob-elaboration/unit_definitions.md`,
     `mob-elaboration/mob_elaboration_plan.md`
   - Phase 5 (Bolt Planning): `mob-elaboration/user_stories.md`,
     `mob-elaboration/unit_definitions.md`, `mob-elaboration/risk_register.md`,
     `mob-elaboration/nfrs.md`, `mob-elaboration/mob_elaboration_plan.md`
{{#enterprise}}
   - Phase 5 also: `mob-elaboration/guardrails_compliance_matrix.md`
{{/enterprise}}
   Read only the files listed for the current phase. All paths relative
   to `aidlc-docs/`.

   **Tier 3 (on-demand, load only when needed during the session):**
   - `decisions/decision-log.md` — when a decision question arises
   - `retrospectives/retro_*.md` — when reflecting on process improvements
   - `intent-summaries/*.md` — when cross-intent context is needed
{{#enterprise}}
   - `overrides/guardrails_overrides.md` — when a guardrail conflict arises
{{/enterprise}}
   - `audit/audit-log.md` — when checking session history

   **Skip on resume:** intent walkthrough (section-by-section confirmation),
   EGS personalization, overrides review, extension suggestions, plan
   template copy. These were completed in a previous session.

   Present: "Welcome back. Resuming [Current Ritual], [Current Position].
   Depth: [Depth Profile]. Loaded: [list Tier 1 + Tier 2 files read].
   Ready to continue [phase name]?"

   Skip completed phases in the plan and continue from the current one.
1. Work through these phases IN ORDER. Do not advance without our explicit approval:

   - Phase 1: Intent Clarification
     Ask us clarifying questions to eliminate ambiguity.
{{#enterprise}}
     Include questions about compliance scope (which regulatory frameworks
     apply), data classification (what data will be processed and at what
     classification level), and deployment targets (which accounts/regions).
{{/enterprise}}
     Question categories to evaluate (do not skip any without justification):
     a) Functional boundaries: what is in scope vs. out of scope?
     b) User roles and access levels: who uses this and with what permissions?
     c) Data flows: what data enters, transforms, and exits the system?
     d) Integration points: what external systems or APIs are involved?
     e) NFR expectations: performance targets, availability, data retention?
     f) Deployment context: environments, regions, account structure?
     After we answer, analyze responses for vagueness. If any answer contains
     "depends", "maybe", "not sure", "probably", "I think", "mix of", or
     "somewhere between", create follow-up questions to resolve the ambiguity
     before proceeding. Do NOT move to Phase 2 with unresolved ambiguity.
     Check the intent **Type** field (feature, bugfix, or maintenance).
     If **bugfix**: focus clarification on root cause, affected components,
     and regression risk. Default to 1 story, 1 unit, 1 bolt unless scope
     clearly requires more. Include a regression test acceptance criterion
     on every story. Skip phases that produce no value (e.g., if there is
     only 1 story, skip Unit Division and go straight to Bolt Mapping).
     If **maintenance**: focus on change scope and blast radius. Default to
     minimal stories covering the change + verification. Same skip rules.

     **Complexity Assessment:** Now that the intent is clear, assess complexity:

     | Dimension | Assessment | Signal |
     |-----------|-----------|--------|
     | Scope breadth | narrow (1-2) / moderate (3-5) / broad (6+) | features or endpoints |
     | Entity complexity | low (1-2) / moderate (3-5) / high (complex graph) | domain entities |
     | Integration surface | isolated / moderate (1-2) / high (3+) | external dependencies |
     | Security sensitivity | low / moderate / high | PII, auth, payments, compliance |
     | Novelty | low (standard pattern) / moderate / high (novel) | pattern familiarity |

     Based on the assessment, recommend a depth profile:
     - **THOROUGH** (most dimensions moderate-high): every phase at full depth.
     - **STANDARD** (mixed): full phases but concise artifacts.
     - **LIGHTWEIGHT** (most dimensions low): phases abbreviated or merged.

     Present an execution plan showing each remaining phase with its
     recommended depth and a one-line explanation of what that depth means.
     Ask: "Here's my recommended execution plan. Proceed, or adjust any phase?"
     Record the confirmed depth profile in the session plan (Depth column).

     Depth rules per phase:
     - Phase 2 LIGHTWEIGHT: stories as brief descriptions, skip edge cases.
     - Phase 3 LIGHTWEIGHT: skip if ≤3 stories (1 unit, 1 bolt is obvious).
     - Phase 4 LIGHTWEIGHT: quick checklist (5 items max) instead of full register.
     - Phase 5 LIGHTWEIGHT: single bolt if ≤1 unit, skip dependency analysis.
     - Code Generation and Test (in Construction) are always FULL regardless.
     - Enterprise EGS gates are never skipped, but can be a checklist at LIGHTWEIGHT.

     If complexity turns out higher than assessed during a later phase, say:
     "This is more complex than initially assessed. I recommend upgrading
     remaining phases to [STANDARD/THOROUGH]." Wait for confirmation.
     The user can also say "go deeper on [phase]" to re-run any phase at
     full depth.

   - Phase 2: Story Generation
     Generate User Stories with Acceptance Criteria. For each story, 
{{#enterprise}}
     proactively validate against the EGS:
     a) Does this story involve data storage? → Verify encryption guardrails.
     b) Does this story involve user access? → Verify IAM/auth guardrails.
     c) Does this story involve external APIs? → Verify network security and 
        resilience guardrails.
     d) Does this story involve PII or sensitive data? → Verify data 
        classification and compliance guardrails.
     Flag any guardrail conflicts inline with the story.
{{/enterprise}}
     After presenting stories, ask: "Do these stories fully cover the intent?
     Any missing scenarios, edge cases, or error paths?" Do not proceed to
     Phase 3 until we confirm coverage is complete.

   - Phase 3: Unit Division
     Group stories into independent, loosely coupled Units. When grouping, 
{{#enterprise}}
     consider architectural guardrails (service boundaries, dependency 
     direction, no shared databases).
{{/enterprise}}

   - Phase 4: Risk, NFR & Guardrails Analysis
     a) Identify risks and measurement criteria.
{{#enterprise}}
     b) Generate NFRs by cross-referencing the EGS: security, observability, 
        DR, deployment, cost, and AI/GenAI guardrails that apply to this Intent.
     c) Generate a Guardrails Compliance Matrix: for each Unit, list every 
        applicable guardrail from the EGS and its expected compliance status.
     Save the matrix as: aidlc-docs/mob-elaboration/guardrails_compliance_matrix.md
{{/enterprise}}

   - Phase 5: Bolt Planning
     Suggest execution Bolts (hours/days) per Unit. Factor in time for:
{{#enterprise}}
     a) Security validation (SAST, SCA, IaC scanning)
     b) Compliance evidence generation
     c) Guardrails compliance report per Bolt
{{/enterprise}}
     For each Bolt, document its dependencies on other Bolts in the plan
     table (e.g., "Depends on: BE-1 API, BE-1 tables"). If a Bolt has
     no dependencies on previous Bolts, mark it "None (independent)".

2. All artifacts go in the aidlc-docs/ folder:
   - Requirements and stories → aidlc-docs/mob-elaboration/user_stories.md
   - Unit definitions → aidlc-docs/mob-elaboration/unit_definitions.md
{{#enterprise}}
   - Risk register, NFRs, and Guardrails Compliance Matrix → aidlc-docs/mob-elaboration/
{{/enterprise}}
{{#standard}}
   - Risk register and NFRs → aidlc-docs/mob-elaboration/
{{/standard}}
   - Session plan → aidlc-docs/mob-elaboration/mob_elaboration_plan.md
   - Decisions → append to aidlc-docs/decisions/decision-log.md
{{#enterprise}}
   - Guardrail exceptions → append to aidlc-docs/overrides/guardrails_overrides.md
{{/enterprise}}
   - Prompt templates → aidlc-docs/prompts/

{{#enterprise}}
3. For each phase, write a plan with checkboxes FIRST. The LAST checkbox in 
   every phase must be "Guardrails Validation: verify all artifacts from this 
   phase comply with the EGS." Wait for our approval before executing. Mark 
   checkboxes as you complete each step.
{{/enterprise}}
{{#standard}}
3. For each phase, write a plan with checkboxes FIRST. Wait for our approval
   before executing. Mark checkboxes as you complete each step.
{{/standard}}

4. Do NOT make critical decisions on your own. When you identify trade-offs, 
   present options and let us choose.
   After each approved decision, append an entry to 
   aidlc-docs/decisions/decision-log.md following the template format.
{{#enterprise}}
   When a Required guardrail gets an approved exception, also append it
   to aidlc-docs/overrides/guardrails_overrides.md with justification,
   compensating controls, approval, and expiry (max 6 months).
{{/enterprise}}

5. **Audit logging:** Append entries to aidlc-docs/audit/audit-log.md for:
   - SESSION_START when pre-flight begins (log intent name, mode, platform).
   - PRE_FLIGHT after pre-flight completes (log what was read, findings, EGS status).
   - PHASE_START / PHASE_COMPLETE at each phase boundary (log phase name, artifacts produced).
   - DECISION when user approves a trade-off (log decision summary, options considered).
{{#enterprise}}
   - GUARDRAIL_OVERRIDE when a Required guardrail exception is approved.
{{/enterprise}}
   - SESSION_END when the ritual completes or user pauses.
   Use ISO timestamps. Keep entries concise (2-4 lines each).

6. **Overconfidence prevention:** Default to asking. When in doubt about scope,
   boundaries, behavior, or requirements, ask a clarifying question rather than
   making an assumption. Red flags that indicate you should ask, not assume:
   - A phase completing without asking any questions on a complex intent.
   - Proceeding after a vague or ambiguous user response.
   - Inferring business rules not stated in the intent or EGS.
   - Skipping a question category because it "probably doesn't apply."
   When analyzing our answers, watch for vague language ("depends", "maybe",
   "not sure", "probably", "I think", "it varies"). Treat these as unresolved
   ambiguity: create targeted follow-up questions before proceeding.

7. **Content validation:** Before writing any artifact that contains diagrams
   or embedded code blocks, load and follow `aidlc-docs/standards/content-validation.md`.

8. **Error handling:** Load `aidlc-docs/standards/error-handling.md` at session start.
   Follow its severity levels, recovery procedures, and escalation rules when
   errors occur. Log all errors and recoveries in `audit/audit-log.md`.

9. **Question format:** Follow `aidlc-docs/standards/question-format.md` for all
   clarifying questions. Use multiple-choice in chat for ≤5 questions; create a
   question file for more. Check answers for contradictions before proceeding.

10. If any step needs our clarification, flag it explicitly and wait.

{{#enterprise}}
10. RESPONSIBLE AI VALIDATION: When the EGS includes Responsible AI guardrails, 
   validate against them as testable requirements, not category checkboxes:
   a) Fairness: flag any domain model that uses protected attributes (age, 
      gender, ethnicity, disability, zip code as proxy) as direct inputs to 
      decisioning without a documented fairness impact assessment.
   b) Explainability: for customer-facing decisions, require an audit record 
      with input data, decision logic, and output (retention per EGS).
   c) Transparency: flag any AI-generated content presented to end users 
      that lacks AI-generated disclosure labeling.
   d) Human oversight: for decisions classified as high-stakes in the risk 
      register, require a human approval step with approver identity and 
      timestamp in the audit trail.
{{/enterprise}}

11. Post-session retrospective. When all phases/stages for this session are
   complete, ask: "Ready for a quick session retrospective? (yes/skip)"
   If yes:
   - Read the template from aidlc-docs/retrospectives/session-retrospective.md.
   - Walk through the sections: AI Collaboration, Session Effectiveness,
     Output Quality, What to Change Next Time, and Action Items.
   - For Brownfield sessions, also cover the Brownfield additions.
   - Save the filled retrospective as
     aidlc-docs/retrospectives/retro_YYYY-MM-DD.md (use today's date).
   - Log any action items as entries in the decision log.
   If skip: log "Session retrospective skipped" in the decision log.

## Context
- Known constraints: [technical, compliance, timeline]
{{#enterprise}}
- Applicable regulatory frameworks: [SOC2, ISO 27001, HIPAA, PCI-DSS, GDPR, etc.]
- Data classification levels involved: [Public, Internal, Confidential, Restricted]
- Target AWS accounts/regions: [specify]
{{/enterprise}}
- For Brownfield: [reference existing code models if Code Elevation was done]

## Start
{{#enterprise}}
Begin by reading the Enterprise Guardrails Specification. Then start Phase 1: 
Ask your clarifying questions about our Intent, including compliance and data 
classification questions.
{{/enterprise}}
{{#standard}}
Begin with Phase 1: Ask your clarifying questions about our Intent.
{{/standard}}
```

---

## Notes

- **Greenfield:** Use the prompt as-is.
- **Brownfield:** Run Code Elevation first and reference those models in the Context section.
{{#enterprise}}
- The EGS reference is the key differentiator from the standard Mob Elaboration template. The AI proactively validates against guardrails rather than relying on the team to catch compliance gaps.
- The Guardrails Compliance Matrix generated in Phase 4 becomes a tracking artifact through Construction and into Operations.
- Phase 1 now includes compliance-specific clarifying questions that the standard template does not require.
{{/enterprise}}
