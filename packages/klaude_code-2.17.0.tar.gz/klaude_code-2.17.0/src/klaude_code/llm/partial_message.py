from __future__ import annotations

from klaude_code.llm.stream_parts import degrade_thinking_to_text

__all__ = ["degrade_thinking_to_text"]
