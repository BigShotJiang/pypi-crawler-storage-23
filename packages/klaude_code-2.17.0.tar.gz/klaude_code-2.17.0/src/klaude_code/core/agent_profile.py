from __future__ import annotations

import datetime
import shutil
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from klaude_code.config.config import Config

from klaude_code.config.sub_agent_model_helper import SubAgentModelHelper
from klaude_code.core.prompts.system_prompt import build_main_system_prompt, load_prompt_by_path
from klaude_code.core.reminders import (
    at_file_reader_reminder,
    empty_todo_reminder,
    image_reminder,
    last_path_memory_reminder,
    memory_reminder,
    skill_reminder,
    todo_not_used_recently_reminder,
)
from klaude_code.core.tool.report_back_tool import ReportBackTool
from klaude_code.core.tool.tool_registry import get_tool_schemas
from klaude_code.llm import LLMClientABC
from klaude_code.protocol import llm_param, message, tools
from klaude_code.protocol.model_id import (
    is_gpt5_model,
)
from klaude_code.protocol.sub_agent import AVAILABILITY_IMAGE_MODEL, get_sub_agent_profile
from klaude_code.session import Session

type Reminder = Callable[[Session], Awaitable[message.DeveloperMessage | None]]


@dataclass(frozen=True)
class AgentProfile:
    """Encapsulates the active LLM client plus prompts/tools/reminders."""

    llm_client: LLMClientABC
    system_prompt: str | None
    tools: list[llm_param.ToolSchema]
    reminders: list[Reminder]


COMMAND_DESCRIPTIONS: dict[str, str] = {
    "rg": "ripgrep - fast text search",
    "fd": "simple and fast alternative to find",
    "tree": "directory listing as a tree",
    "sg": "ast-grep - AST-aware code search",
    "jq": "command-line JSON processor",
    "jj": "jujutsu - Git-compatible version control system",
}

MAIN_AGENT_COMMON_BASE_TOOLS: list[str] = [tools.BASH, tools.READ]
MAIN_AGENT_GPT5_DIFF_TOOLS: list[str] = [tools.APPLY_PATCH, tools.UPDATE_PLAN]
MAIN_AGENT_NON_GPT5_DIFF_TOOLS: list[str] = [tools.EDIT, tools.WRITE, tools.TODO_WRITE]
MAIN_AGENT_COMMON_TOOLS: list[str] = [tools.REWIND, tools.TASK, tools.WEB_FETCH, tools.WEB_SEARCH, tools.MERMAID]


STRUCTURED_OUTPUT_PROMPT_FOR_SUB_AGENT = """\

# Structured Output
You have a `report_back` tool available. When you complete the task,\
you MUST call `report_back` with the structured result matching the required schema.\
Only the content passed to `report_back` will be returned to user.\
"""


def _build_env_info(model_name: str) -> str:
    """Build environment info section with dynamic runtime values."""

    cwd = Path.cwd()
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    is_git_repo = (cwd / ".git").exists()
    is_empty_dir = not any(cwd.iterdir())

    available_tools: list[str] = []
    for command, desc in COMMAND_DESCRIPTIONS.items():
        if shutil.which(command) is not None:
            available_tools.append(f"{command}: {desc}")

    cwd_display = f"{cwd} (empty)" if is_empty_dir else str(cwd)
    git_repo_line = (
        "Current directory is a git repo"
        if is_git_repo
        else "Current directory is not a git repo (Exercise caution when modifying files; back up when necessary)"
    )

    env_lines: list[str] = [
        "",
        "",
        "Here is useful information about the environment you are running in:",
        "<env>",
        f"Working directory: {cwd_display}",
        f"Today's Date: {today}",
        git_repo_line,
        f"You are powered by the model: {model_name}",
    ]

    if available_tools:
        env_lines.append("Available bash commands (use with `Bash` tool):")
        for tool in available_tools:
            env_lines.append(f"- {tool}")

    env_lines.append("</env>")
    return "\n".join(env_lines)


def load_system_prompt(
    model_name: str,
    protocol: llm_param.LLMClientProtocol,
    sub_agent_type: str | None = None,
    config: Config | None = None,
    available_tools: list[llm_param.ToolSchema] | None = None,
) -> str:
    """Get system prompt content for the given model and sub-agent type."""

    del protocol, config

    if sub_agent_type is not None:
        profile = get_sub_agent_profile(sub_agent_type)
        base_prompt = load_prompt_by_path(profile.prompt_file)
    else:
        base_prompt = build_main_system_prompt(model_name, available_tools or [])

    skills_prompt = ""
    if sub_agent_type is None:
        # Skills are progressive-disclosure: keep only metadata in the system prompt.
        from klaude_code.skill.manager import format_available_skills_for_system_prompt

        skills_prompt = format_available_skills_for_system_prompt()

    return base_prompt + _build_env_info(model_name) + skills_prompt


def load_agent_tools(
    model_name: str,
    sub_agent_type: tools.SubAgentType | None = None,
    config: Config | None = None,
) -> list[llm_param.ToolSchema]:
    """Get tools for an agent based on model and agent type.

    Args:
        model_name: The model name.
        sub_agent_type: If None, returns main agent tools. Otherwise returns sub-agent tools.
        config: Config for checking sub-agent availability (e.g., image model availability).
    """

    if sub_agent_type is not None:
        profile = get_sub_agent_profile(sub_agent_type)
        return get_tool_schemas(list(profile.tool_set))

    # Main agent tools = common + model-specific diff + common
    model_diff_tools = MAIN_AGENT_GPT5_DIFF_TOOLS if is_gpt5_model(model_name) else MAIN_AGENT_NON_GPT5_DIFF_TOOLS
    tool_names: list[str] = [
        *MAIN_AGENT_COMMON_BASE_TOOLS,
        *model_diff_tools,
        *MAIN_AGENT_COMMON_TOOLS,
    ]

    if config is not None:
        helper = SubAgentModelHelper(config)
        if helper.check_availability_requirement(AVAILABILITY_IMAGE_MODEL):
            tool_names.append(tools.IMAGE_GEN)
    else:
        tool_names.append(tools.IMAGE_GEN)

    return get_tool_schemas(tool_names)


def load_agent_reminders(
    model_name: str,
    sub_agent_type: str | None = None,
    available_tools: list[llm_param.ToolSchema] | None = None,
) -> list[Reminder]:
    """Get reminders for an agent based on model and agent type.

    Args:
        model_name: The model name.
        sub_agent_type: If None, returns main agent reminders. Otherwise returns sub-agent reminders.
        available_tools: Tools available to the active profile.
    """

    del model_name

    reminders: list[Reminder] = []
    tool_name_set = {tool_schema.name for tool_schema in (available_tools or [])}

    # Enable todo reminders only when TodoWrite is actually available.
    if sub_agent_type is None and tools.TODO_WRITE in tool_name_set:
        reminders.append(empty_todo_reminder)
        reminders.append(todo_not_used_recently_reminder)

    reminders.extend(
        [
            memory_reminder,
            at_file_reader_reminder,
            last_path_memory_reminder,
            image_reminder,
            skill_reminder,
        ]
    )

    return reminders


def with_structured_output(profile: AgentProfile, output_schema: dict[str, Any]) -> AgentProfile:
    report_back_tool_class = ReportBackTool.for_schema(output_schema)
    base_prompt = profile.system_prompt or ""
    return AgentProfile(
        llm_client=profile.llm_client,
        system_prompt=base_prompt + STRUCTURED_OUTPUT_PROMPT_FOR_SUB_AGENT,
        tools=[*profile.tools, report_back_tool_class.schema()],
        reminders=profile.reminders,
    )


class ModelProfileProvider(Protocol):
    """Strategy interface for constructing agent profiles."""

    def build_profile(
        self,
        llm_client: LLMClientABC,
        sub_agent_type: tools.SubAgentType | None = None,
        *,
        output_schema: dict[str, Any] | None = None,
    ) -> AgentProfile: ...


class DefaultModelProfileProvider(ModelProfileProvider):
    """Default provider backed by global prompts/tool/reminder registries."""

    def __init__(self, config: Config | None = None) -> None:
        self._config = config

    def build_profile(
        self,
        llm_client: LLMClientABC,
        sub_agent_type: tools.SubAgentType | None = None,
        *,
        output_schema: dict[str, Any] | None = None,
    ) -> AgentProfile:
        model_name = llm_client.model_name
        llm_config = llm_client.get_llm_config()

        # Image generation models should not have system prompt, tools, or reminders
        is_image_model = llm_config.modalities and "image" in llm_config.modalities
        if is_image_model:
            agent_system_prompt: str | None = None
            agent_tools: list[llm_param.ToolSchema] = []
            agent_reminders: list[Reminder] = [at_file_reader_reminder, image_reminder]
        else:
            agent_tools = load_agent_tools(model_name, sub_agent_type, config=self._config)
            agent_system_prompt = load_system_prompt(
                model_name,
                llm_client.protocol,
                sub_agent_type,
                config=self._config,
                available_tools=agent_tools,
            )
            agent_reminders = load_agent_reminders(model_name, sub_agent_type, available_tools=agent_tools)

        profile = AgentProfile(
            llm_client=llm_client,
            system_prompt=agent_system_prompt,
            tools=agent_tools,
            reminders=agent_reminders,
        )
        if output_schema:
            return with_structured_output(profile, output_schema)
        return profile


class VanillaModelProfileProvider(ModelProfileProvider):
    """Provider that strips prompts, reminders, and tools for vanilla mode."""

    def build_profile(
        self,
        llm_client: LLMClientABC,
        sub_agent_type: tools.SubAgentType | None = None,
        *,
        output_schema: dict[str, Any] | None = None,
    ) -> AgentProfile:
        del sub_agent_type
        profile = AgentProfile(
            llm_client=llm_client,
            system_prompt="You're an agent running in user's terminal",
            tools=get_tool_schemas([tools.BASH, tools.EDIT, tools.WRITE, tools.READ]),
            reminders=[],
        )
        if output_schema:
            return with_structured_output(profile, output_schema)
        return profile
