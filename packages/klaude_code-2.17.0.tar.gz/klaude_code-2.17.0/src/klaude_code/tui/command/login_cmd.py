import asyncio

import typer

from klaude_code.app.auth_flow import execute_login
from klaude_code.protocol import commands, events, message

from .auth_selector import select_provider
from .command_abc import Agent, CommandABC, CommandResult


class LoginCommand(CommandABC):
    """Login to OAuth providers or configure API keys."""

    @property
    def name(self) -> commands.CommandName:
        return commands.CommandName.LOGIN

    @property
    def summary(self) -> str:
        return "Login to provider or configure API key"

    @property
    def is_interactive(self) -> bool:
        return True

    @property
    def support_addition_params(self) -> bool:
        return True

    @property
    def placeholder(self) -> str:
        return "provider"

    async def run(self, agent: Agent, user_input: message.UserInputPayload) -> CommandResult:
        provider = user_input.text.strip() or None

        if provider is None:
            try:
                provider = await asyncio.to_thread(select_provider)
            except KeyboardInterrupt:
                provider = None
            if provider is None:
                return CommandResult(
                    events=[
                        events.CommandOutputEvent(
                            session_id=agent.session.id,
                            command_name=self.name,
                            content="(cancelled)",
                        )
                    ]
                )

        try:
            execute_login(provider)
        except (KeyboardInterrupt, typer.Abort):
            return CommandResult(
                events=[
                    events.CommandOutputEvent(
                        session_id=agent.session.id,
                        command_name=self.name,
                        content="(cancelled)",
                    )
                ]
            )
        except typer.Exit as e:
            if e.exit_code not in (None, 0):
                return CommandResult(
                    events=[
                        events.CommandOutputEvent(
                            session_id=agent.session.id,
                            command_name=self.name,
                            content=f"Login failed (exit code: {e.exit_code}).",
                            is_error=True,
                        )
                    ]
                )
            return CommandResult(
                events=[
                    events.CommandOutputEvent(
                        session_id=agent.session.id,
                        command_name=self.name,
                        content="(cancelled)",
                    )
                ]
            )

        return CommandResult(
            events=[
                events.CommandOutputEvent(
                    session_id=agent.session.id,
                    command_name=self.name,
                    content="Login flow completed.",
                )
            ]
        )
