from .base import Instrument
from .synthdef import SynthDefInstrument
from .midi import MidiInstrument
from .tone import ToneInstrument

__all__ = ['Instrument', 'SynthDefInstrument', 'MidiInstrument', 'ToneInstrument']