use std::collections::HashMap;
use ocg::{execute_with_params, PropertyGraph};

#[test]
fn test_temporal_values_return_as_strings() {
    let mut graph = PropertyGraph::new();
    let params = HashMap::new();

    // Test Date
    let result = execute_with_params(
        &mut graph,
        "RETURN date({year: 1984, month: 10, day: 11}) AS d",
        params.clone()
    ).unwrap();

    let date_val = result.rows[0].get("d").unwrap();
    println!("Date value: {:?}", date_val);
    println!("Date display: {}", date_val);

    // Test Duration
    let result = execute_with_params(
        &mut graph,
        "RETURN duration({months: 12, days: 5}) AS dur",
        params.clone()
    ).unwrap();

    let dur_val = result.rows[0].get("dur").unwrap();
    println!("Duration value: {:?}", dur_val);
    println!("Duration display: {}", dur_val);

    // Test arithmetic result
    let result = execute_with_params(
        &mut graph,
        "RETURN date({year: 1984, month: 10, day: 11}) + duration({months: 1, days: -14}) AS sum",
        params.clone()
    ).unwrap();

    let sum_val = result.rows[0].get("sum").unwrap();
    println!("Sum value: {:?}", sum_val);
    println!("Sum display: {}", sum_val);
}
