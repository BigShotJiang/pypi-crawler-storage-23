use std::collections::HashMap;
use ocg::{execute_with_params, CypherValue, PropertyGraph};

#[test]
fn test_reduce_basic() {
    let mut graph = PropertyGraph::new();
    let params = HashMap::new();

    println!("\n=== Test 1: Simple sum with reduce ===");
    let result = execute_with_params(
        &mut graph,
        "RETURN reduce(sum = 0, n IN [1,2,3,4,5] | sum + n) AS total",
        params.clone()
    ).unwrap();
    println!("reduce(sum = 0, n IN [1,2,3,4,5] | sum + n): {:?}", result.rows[0].get("total"));
    assert_eq!(result.rows[0].get("total"), Some(&CypherValue::Integer(15)));

    println!("\n=== Test 2: String concatenation with reduce ===");
    let result = execute_with_params(
        &mut graph,
        "RETURN reduce(s = '', x IN ['a', 'b', 'c'] | s + x) AS text",
        params.clone()
    ).unwrap();
    println!("reduce string concat: {:?}", result.rows[0].get("text"));
    assert_eq!(result.rows[0].get("text"), Some(&CypherValue::String("abc".to_string())));

    println!("\n=== Test 3: Product with reduce ===");
    let result = execute_with_params(
        &mut graph,
        "RETURN reduce(prod = 1, n IN [2,3,4] | prod * n) AS result",
        params.clone()
    ).unwrap();
    println!("reduce product: {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Integer(24)));

    println!("\n=== Test 4: Reduce with NULL list ===");
    let result = execute_with_params(
        &mut graph,
        "RETURN reduce(sum = 0, n IN null | sum + n) AS result",
        params.clone()
    ).unwrap();
    println!("reduce(null list): {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Null));

    println!("\n✅ All reduce() tests passing!");
}
