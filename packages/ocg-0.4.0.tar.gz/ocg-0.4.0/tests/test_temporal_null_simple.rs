use std::collections::HashMap;
use ocg::{execute_with_params, CypherValue, PropertyGraph};

#[test]
fn test_temporal_functions_with_top_level_null() {
    let mut graph = PropertyGraph::new();
    let params = HashMap::new();

    println!("\n=== Testing temporal functions with NULL argument ===");

    // Test date(null)
    let result = execute_with_params(
        &mut graph,
        "RETURN date(null) AS result",
        params.clone()
    ).unwrap();
    println!("date(null): {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Null));

    // Test time(null)
    let result = execute_with_params(
        &mut graph,
        "RETURN time(null) AS result",
        params.clone()
    ).unwrap();
    println!("time(null): {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Null));

    // Test datetime(null)
    let result = execute_with_params(
        &mut graph,
        "RETURN datetime(null) AS result",
        params.clone()
    ).unwrap();
    println!("datetime(null): {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Null));

    // Test localtime(null)
    let result = execute_with_params(
        &mut graph,
        "RETURN localtime(null) AS result",
        params.clone()
    ).unwrap();
    println!("localtime(null): {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Null));

    // Test localdatetime(null)
    let result = execute_with_params(
        &mut graph,
        "RETURN localdatetime(null) AS result",
        params.clone()
    ).unwrap();
    println!("localdatetime(null): {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Null));

    // Test duration(null)
    let result = execute_with_params(
        &mut graph,
        "RETURN duration(null) AS result",
        params.clone()
    ).unwrap();
    println!("duration(null): {:?}", result.rows[0].get("result"));
    assert_eq!(result.rows[0].get("result"), Some(&CypherValue::Null));

    println!("\n✅ All temporal functions correctly return NULL for NULL argument");
}
