use std::collections::HashMap;
use ocg::{execute_with_params, PropertyGraph};

#[test]
fn test_union_basic() {
    let mut graph = PropertyGraph::new();
    let params = HashMap::new();

    // Create some test data
    execute_with_params(
        &mut graph,
        "CREATE (:Person {name: 'Alice'}), (:Person {name: 'Bob'}), (:Person {name: 'Charlie'})",
        params.clone()
    ).unwrap();

    println!("\n=== Test 1: UNION (distinct) ===");
    let result = execute_with_params(
        &mut graph,
        "MATCH (p:Person) WHERE p.name = 'Alice' RETURN p.name AS name
         UNION
         MATCH (p:Person) WHERE p.name = 'Bob' RETURN p.name AS name",
        params.clone()
    );
    println!("UNION result: {:?}", result);

    if let Ok(r) = &result {
        println!("Row count: {}", r.rows.len());
        assert_eq!(r.rows.len(), 2, "UNION should return 2 rows");
    }

    println!("\n=== Test 2: UNION ALL (with duplicates) ===");
    let result = execute_with_params(
        &mut graph,
        "MATCH (p:Person) WHERE p.name = 'Alice' RETURN p.name AS name
         UNION ALL
         MATCH (p:Person) WHERE p.name = 'Alice' RETURN p.name AS name",
        params.clone()
    );
    println!("UNION ALL result: {:?}", result);

    if let Ok(r) = &result {
        println!("Row count: {}", r.rows.len());
        assert_eq!(r.rows.len(), 2, "UNION ALL should preserve duplicates");
    }

    println!("\n=== Test 3: UNION removes duplicates ===");
    let result = execute_with_params(
        &mut graph,
        "MATCH (p:Person) WHERE p.name = 'Alice' RETURN p.name AS name
         UNION
         MATCH (p:Person) WHERE p.name = 'Alice' RETURN p.name AS name",
        params.clone()
    );
    println!("UNION (duplicate removal) result: {:?}", result);

    if let Ok(r) = &result {
        println!("Row count: {}", r.rows.len());
        assert_eq!(r.rows.len(), 1, "UNION should remove duplicates");
    }
}

#[test]
fn test_union_simple_literals() {
    let mut graph = PropertyGraph::new();
    let params = HashMap::new();

    println!("\n=== Test: Simple UNION with literals ===");
    let result = execute_with_params(
        &mut graph,
        "RETURN 1 AS num UNION RETURN 2 AS num",
        params
    );
    println!("Result: {:?}", result);

    if let Ok(r) = &result {
        assert_eq!(r.rows.len(), 2, "Should return 2 rows");
    }
}
