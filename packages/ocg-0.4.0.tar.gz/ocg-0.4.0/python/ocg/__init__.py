"""
ocg: 99%+ openCypher-compliant graph database

OpenCypher Graph (OCG) is a high-performance, pure-Rust graph database
with Python bindings that executes openCypher queries against in-memory
property graphs.

Features:
- 99.0% openCypher TCK compliance (3,859/3,897 scenarios passing)
- 4 graph backends: PropertyGraph, NetworKitRust, RustworkxCore, Graphrs
- 31 graph algorithms (PageRank, betweenness, community detection, etc.)
- BulkLoader API for 57x faster batch graph construction
- Pure Rust implementation with Python bindings
- Memory-safe, minimal unsafe code

Example:
    >>> from ocg import Graph
    >>> graph = Graph()
    >>>
    >>> # Create nodes and relationships
    >>> graph.execute("CREATE (alice:Person {name: 'Alice', age: 30})")
    >>> graph.execute("CREATE (bob:Person {name: 'Bob', age: 25})")
    >>> graph.execute('''
    ...     MATCH (alice:Person {name: 'Alice'}), (bob:Person {name: 'Bob'})
    ...     CREATE (alice)-[:KNOWS]->(bob)
    ... ''')
    >>>
    >>> # Query the graph
    >>> result = graph.execute('''
    ...     MATCH (a:Person)-[:KNOWS]->(b:Person)
    ...     RETURN a.name AS from, b.name AS to
    ... ''')
    >>> for row in result:
    ...     print(f"{row['from']} knows {row['to']}")
    Alice knows Bob
"""

from ._ocg import Graph, NetworKitGraph, RustworkxGraph, GraphrsGraph, execute, __version__

# Optional pandas compatibility utilities (column-oriented format)
try:
    from .pandas_compat import (  # type: ignore[import]
        to_columns,
        to_rows,
        to_dataframe,
        ResultAdapter,
        add_pandas_methods,
    )
    _pandas_compat_available: bool = True
except ImportError:
    _pandas_compat_available: bool = False
    to_columns = None
    to_rows = None
    to_dataframe = None
    ResultAdapter = None
    add_pandas_methods = None

__all__ = [
    "Graph",
    "NetworKitGraph",
    "RustworkxGraph",
    "GraphrsGraph",
    "execute",
    "__version__",
    # Pandas compatibility (optional)
    "to_columns",
    "to_rows",
    "to_dataframe",
    "ResultAdapter",
    "add_pandas_methods",
]
