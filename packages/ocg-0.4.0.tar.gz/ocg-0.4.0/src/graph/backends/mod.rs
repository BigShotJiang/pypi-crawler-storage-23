//! Alternative graph backend implementations.
//!
//! All algorithms ported to `networkit_rust` are also available on the
//! `RustworkxCoreBackend` and `GraphrsBackend` via the shared
//! `PetgraphAlgorithms` trait defined in `petgraph_algorithms`.

pub mod networkit_rust;
pub mod rustworkx_core;
pub mod graphrs;
pub mod petgraph_algorithms;

pub use networkit_rust::NetworKitRustBackend;
pub use rustworkx_core::RustworkxCoreBackend;
pub use graphrs::GraphrsBackend;
pub use petgraph_algorithms::{PetgraphAlgorithms, CommunityInfo};
