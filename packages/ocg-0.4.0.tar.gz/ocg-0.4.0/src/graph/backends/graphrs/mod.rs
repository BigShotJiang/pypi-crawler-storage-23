// Copyright 2026 Gregorio Momm
// Licensed under the Apache License, Version 2.0
//
// This file implements GraphBackend for graphrs, a community detection and graph analysis library.
//
// graphrs: https://github.com/malcolmvr/graphrs (MIT License)

//! Graphrs backend - Community detection algorithms (Louvain, Leiden) built on petgraph.

mod backend;
mod algorithms;

pub use backend::GraphrsBackend;
