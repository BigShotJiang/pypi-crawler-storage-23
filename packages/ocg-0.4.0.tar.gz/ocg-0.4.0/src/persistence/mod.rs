//! Standalone persistence for PropertyGraph (WAL + Parquet snapshots).
//!
//! Available when the `persistence` feature is enabled (on by default).
//! This provides crash-safe durability for single-node graphs without
//! requiring the full `distributed` feature stack.

pub mod wal;
