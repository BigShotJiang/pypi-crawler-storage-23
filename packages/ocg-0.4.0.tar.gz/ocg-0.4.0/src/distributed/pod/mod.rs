//! Pod initialization and lifecycle management.
//!
//! Provides startup logic for partition pods: read configuration from
//! environment variables, load assigned partitions from object storage,
//! register in etcd, and start the Arrow Flight server and heartbeat service.

pub mod startup;

pub use startup::{PodConfig, PodStartup};
