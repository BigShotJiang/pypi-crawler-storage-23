//! Distributed graph backend implementations.

pub mod partitioned_backend;

pub use partitioned_backend::{CrossPartitionEdgeMetadata, PartitionedGraphBackend};
