//! Distributed query routing.
//!
//! Routes Cypher queries to the correct partition(s) based on the query
//! structure and partition metadata, then merges results.

pub mod partition_analyzer;
pub mod query_router;

pub use partition_analyzer::{PartitionAnalyzer, QueryDistribution};
pub use query_router::QueryRouter;
