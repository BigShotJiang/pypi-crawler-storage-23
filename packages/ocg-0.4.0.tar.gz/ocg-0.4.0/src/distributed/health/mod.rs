//! Pod health monitoring: heartbeat emission and failure detection.

pub mod failure_detector;
pub mod heartbeat;

pub use failure_detector::FailureDetector;
pub use heartbeat::HeartbeatService;
