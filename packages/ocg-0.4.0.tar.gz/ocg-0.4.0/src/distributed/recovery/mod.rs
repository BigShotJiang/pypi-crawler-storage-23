//! Partition recovery after pod failure.
//!
//! Monitors the partition location service for failed partitions and
//! orchestrates recovery: selecting a new pod, loading the partition
//! from object storage, and updating the metadata in etcd.

pub mod pod_selector;
pub mod recovery_manager;

pub use pod_selector::{PodInfo, PodSelector, StatefulOrdinalSelector};
pub use recovery_manager::RecoveryManager;
