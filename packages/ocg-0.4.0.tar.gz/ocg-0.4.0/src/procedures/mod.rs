//! Stored procedure system for ocg.
//!
//! Provides a plugin-based procedure registry compatible with Neo4j's CALL clause.
//! Supports runtime procedure registration, yield columns, and argument validation.

pub mod registry;
pub mod db;
pub mod dbms;

pub use registry::{
    Procedure, ProcedureContext, ProcedureInfo, ProcedureMode, ProcedureRegistry,
    ParameterInfo, YieldInfo,
};

pub use db::{DbLabels, DbRelationshipTypes, DbPropertyKeys};
pub use dbms::DbmsProcedures;
