from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import tarfile

from click.testing import CliRunner

from rawctx.cli import main


def _write_valid_package(base: Path) -> Path:
    package_dir = base / "example"
    models_dir = package_dir / "models"
    models_dir.mkdir(parents=True)

    (package_dir / "rawctx.yaml").write_text(
        """
name: "@demo/retail-analytics"
version: "1.0.0"
format: "osi"
description: "Retail analytics semantic model"
models:
  - models/sales_summary.osi.yaml
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (package_dir / "README.md").write_text("# Retail Analytics\n", encoding="utf-8")

    (models_dir / "sales_summary.osi.yaml").write_text(
        """
version: "1.0"
ai_context:
  intent: "retail reporting"
datasets:
  - name: sales_summary
    measures:
      - name: order_count
        expr: "count(*)"
    dimensions:
      - name: order_date
        expr: "order_date"
    relationships:
      - name: customer
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return package_dir


def test_validate_directory_success(tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    runner = CliRunner()

    result = runner.invoke(main, ["validate", str(package_dir)])

    assert result.exit_code == 0
    assert "validated 2 file(s)" in result.output
    assert "package: @demo/retail-analytics@1.0.0" in result.output


def test_validate_manifest_semver_failure(tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    manifest_path = package_dir / "rawctx.yaml"
    manifest_path.write_text(
        manifest_path.read_text(encoding="utf-8").replace('version: "1.0.0"', 'version: "1.0"'),
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(main, ["validate", str(package_dir)])

    assert result.exit_code == 1
    assert "SemVer" in result.output


def test_validate_osi_missing_required_field(tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    osi_path = package_dir / "models" / "sales_summary.osi.yaml"
    osi_path.write_text(
        """
datasets:
  - name: sales_summary
""".strip()
        + "\n",
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(main, ["validate", str(osi_path), "--format", "osi"])

    assert result.exit_code == 1
    assert "required property" in result.output.lower()


def test_pack_creates_expected_archive(tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    out_dir = tmp_path / "dist"
    runner = CliRunner()

    result = runner.invoke(main, ["pack", str(package_dir), "--output-dir", str(out_dir)])

    assert result.exit_code == 0
    archive = out_dir / "demo__retail-analytics-1.0.0.rawctx.tar.gz"
    assert archive.exists()

    with tarfile.open(archive, "r:gz") as tar:
        names = sorted(tar.getnames())
        assert names == [
            "package/README.md",
            "package/checksums.sha256",
            "package/models/sales_summary.osi.yaml",
            "package/rawctx.yaml",
        ]

        checksums = tar.extractfile("package/checksums.sha256")
        assert checksums is not None
        checksums_content = checksums.read().decode("utf-8")

        for name in [
            "package/README.md",
            "package/models/sales_summary.osi.yaml",
            "package/rawctx.yaml",
        ]:
            handle = tar.extractfile(name)
            assert handle is not None
            digest = sha256(handle.read()).hexdigest()
            assert f"{digest}  {name}" in checksums_content


def test_pack_is_deterministic(tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    out_dir = tmp_path / "dist"
    runner = CliRunner()

    first = runner.invoke(main, ["pack", str(package_dir), "--output-dir", str(out_dir)])
    archive = out_dir / "demo__retail-analytics-1.0.0.rawctx.tar.gz"
    first_bytes = archive.read_bytes()

    second = runner.invoke(main, ["pack", str(package_dir), "--output-dir", str(out_dir)])
    second_bytes = archive.read_bytes()

    assert first.exit_code == 0
    assert second.exit_code == 0
    assert first_bytes == second_bytes


def test_validate_auto_usage_error_for_unknown_file(tmp_path: Path) -> None:
    unknown = tmp_path / "model.yaml"
    unknown.write_text("foo: bar\n", encoding="utf-8")
    runner = CliRunner()

    result = runner.invoke(main, ["validate", str(unknown)])

    assert result.exit_code == 2
