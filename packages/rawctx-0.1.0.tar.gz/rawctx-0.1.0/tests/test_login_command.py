from __future__ import annotations

import base64
import json
from pathlib import Path

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.config import ConfigStore, RawctxConfig
from rawctx.registry.client import RegistryClient
from rawctx.registry.models import ApiTokenInfo, OAuthLoginInfo, OAuthSessionInfo


def _fake_jwt(payload: dict[str, object]) -> str:
    header = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode("utf-8")).decode("utf-8").rstrip("=")
    body = base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8").rstrip("=")
    return f"{header}.{body}.signature"


def test_login_saves_token(monkeypatch, tmp_path: Path) -> None:
    config_path = tmp_path / "rawctx" / "config.yaml"
    monkeypatch.setenv("RAWCTX_CONFIG", str(config_path))

    monkeypatch.setattr(
        RegistryClient,
        "oauth_login_github",
        lambda self: OAuthLoginInfo(authorize_url="https://auth.example/login", state="state123"),
    )

    def fake_create_api_token(self, *, id_token: str, name: str, expires_in_days: int | None = None) -> ApiTokenInfo:
        assert name == "rawctx-cli"
        assert expires_in_days is None
        assert id_token.count(".") == 2
        return ApiTokenInfo(
            id="token-id",
            name=name,
            token="rxctx_token",
            prefix="rxctx_",
            created_at="2026-02-28T00:00:00Z",
            expires_at=None,
        )

    monkeypatch.setattr(RegistryClient, "create_api_token", fake_create_api_token)

    runner = CliRunner()
    id_token = _fake_jwt({"preferred_username": "owner"})
    result = runner.invoke(main, ["login", "--registry", "https://registry.example", "--no-browser", "--id-token", id_token])

    assert result.exit_code == 0
    assert "Login succeeded" in result.output

    store = ConfigStore()
    config = store.load()
    assert config.registry == "https://registry.example"
    assert config.auth.token == "rxctx_token"
    assert config.auth.token_id == "token-id"
    assert config.profile.username == "owner"


def test_logout_revokes_token_and_clears_local(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    store = ConfigStore()
    config = RawctxConfig(registry="https://registry.example")
    config.auth.token = "rxctx_token"
    config.auth.token_id = "token-id"
    config.auth.token_name = "rawctx-cli"
    store.save(config)

    calls: list[str] = []

    def fake_revoke(self, token_id: str) -> bool:
        calls.append(token_id)
        return True

    monkeypatch.setattr(RegistryClient, "revoke_api_token", fake_revoke)

    runner = CliRunner()
    result = runner.invoke(main, ["logout"])

    assert result.exit_code == 0
    assert "Token revoked" in result.output
    assert calls == ["token-id"]

    loaded = store.load()
    assert loaded.auth.token is None
    assert loaded.auth.token_id is None


def test_login_auto_captures_oauth_id_token(monkeypatch, tmp_path: Path) -> None:
    config_path = tmp_path / "rawctx" / "config.yaml"
    monkeypatch.setenv("RAWCTX_CONFIG", str(config_path))

    expected_id_token = _fake_jwt({"preferred_username": "owner"})

    monkeypatch.setattr(
        RegistryClient,
        "oauth_login_github",
        lambda self: OAuthLoginInfo(
            authorize_url="https://auth.example/login",
            state="state123",
            session_id="sess123",
            poll_interval_seconds=1,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "oauth_login_session",
        lambda self, session_id: OAuthSessionInfo(
            session_id=session_id,
            status="ready",
            id_token=expected_id_token,
        ),
    )

    def fake_create_api_token(self, *, id_token: str, name: str, expires_in_days: int | None = None) -> ApiTokenInfo:
        assert id_token == expected_id_token
        return ApiTokenInfo(
            id="token-id",
            name=name,
            token="rxctx_token",
            prefix="rxctx_",
            created_at="2026-02-28T00:00:00Z",
            expires_at=None,
        )

    monkeypatch.setattr(RegistryClient, "create_api_token", fake_create_api_token)

    runner = CliRunner()
    result = runner.invoke(main, ["login", "--registry", "https://registry.example", "--no-browser"])

    assert result.exit_code == 0
    assert "Waiting for OAuth login to complete in browser" in result.output
    assert "Login succeeded" in result.output


def test_login_reports_oauth_session_error(monkeypatch, tmp_path: Path) -> None:
    config_path = tmp_path / "rawctx" / "config.yaml"
    monkeypatch.setenv("RAWCTX_CONFIG", str(config_path))

    monkeypatch.setattr(
        RegistryClient,
        "oauth_login_github",
        lambda self: OAuthLoginInfo(
            authorize_url="https://auth.example/login",
            state="state123",
            session_id="sess123",
            poll_interval_seconds=1,
        ),
    )
    monkeypatch.setattr(
        RegistryClient,
        "oauth_login_session",
        lambda self, session_id: OAuthSessionInfo(
            session_id=session_id,
            status="error",
            error="access_denied",
            error_description="User denied access",
        ),
    )

    runner = CliRunner()
    result = runner.invoke(main, ["login", "--registry", "https://registry.example", "--no-browser"])

    assert result.exit_code != 0
    assert "OAuth login failed: User denied access" in result.output
