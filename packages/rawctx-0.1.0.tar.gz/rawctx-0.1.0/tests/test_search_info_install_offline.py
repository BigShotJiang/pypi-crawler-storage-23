from __future__ import annotations

from io import BytesIO
from pathlib import Path
import tarfile

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.config import ConfigStore, load_package_cache, save_package_cache, upsert_cache_entry


def _archive_bytes(version: str) -> bytes:
    payload = BytesIO()
    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        rawctx_yaml = f"""name: \"@owner/sample\"\nversion: \"{version}\"\nformat: \"osi\"\nmodels:\n  - models/sample.osi.yaml\n"""
        model_yaml = """version: \"1.0\"\nai_context:\n  intent: \"test\"\ndatasets:\n  - name: ds\n    measures:\n      - name: m\n        expr: \"count(*)\"\n"""

        for name, content in {
            "package/rawctx.yaml": rawctx_yaml,
            "package/models/sample.osi.yaml": model_yaml,
        }.items():
            content_bytes = content.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(content_bytes)
            info.mtime = 0
            tar.addfile(info, BytesIO(content_bytes))

    return payload.getvalue()


def _seed_cache(tmp_path: Path, monkeypatch) -> ConfigStore:  # type: ignore[no-untyped-def]
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    store = ConfigStore()
    cache = load_package_cache(store.paths)
    upsert_cache_entry(
        cache,
        scope="owner",
        name="sample",
        package={
            "id": "pkg-1",
            "scope": "owner",
            "name": "sample",
            "description": "Sample package",
            "format": "osi",
            "source": "shopify",
            "domain": "commerce",
            "tags": ["demo"],
            "download_count": 3,
            "star_count": 2,
        },
        versions=[
            {
                "id": "ver-100",
                "version": "1.0.0",
                "status": "published",
                "search_index_status": "indexed",
                "file_size": 123,
                "checksum_sha256": "a" * 64,
                "model_summary": {"dataset_count": 1},
                "created_at": "2026-02-28T00:00:00Z",
                "published_at": "2026-02-28T00:00:00Z",
            },
            {
                "id": "ver-110",
                "version": "1.1.0",
                "status": "published",
                "search_index_status": "indexed",
                "file_size": 124,
                "checksum_sha256": "b" * 64,
                "model_summary": {"dataset_count": 1},
                "created_at": "2026-02-28T00:00:00Z",
                "published_at": "2026-02-28T00:00:00Z",
            },
        ],
    )
    save_package_cache(store.paths, cache)

    archive_path = store.paths.archive_path("owner", "sample", "1.1.0")
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    archive_path.write_bytes(_archive_bytes("1.1.0"))
    return store


def test_search_offline(monkeypatch, tmp_path: Path) -> None:
    _seed_cache(tmp_path, monkeypatch)
    runner = CliRunner()

    result = runner.invoke(main, ["search", "sample", "--offline"])

    assert result.exit_code == 0
    assert "@owner/sample" in result.output


def test_info_offline(monkeypatch, tmp_path: Path) -> None:
    _seed_cache(tmp_path, monkeypatch)
    runner = CliRunner()

    result = runner.invoke(main, ["info", "@owner/sample", "--offline"])

    assert result.exit_code == 0
    assert "Package: @owner/sample" in result.output
    assert "Versions:" in result.output


def test_install_offline_uses_latest_cached_version(monkeypatch, tmp_path: Path) -> None:
    store = _seed_cache(tmp_path, monkeypatch)
    runner = CliRunner()

    result = runner.invoke(main, ["install", "@owner/sample", "--offline"])

    assert result.exit_code == 0
    installed = store.paths.install_path("owner", "sample", "1.1.0")
    assert (installed / "rawctx.yaml").exists()
    assert (installed / "models" / "sample.osi.yaml").exists()
