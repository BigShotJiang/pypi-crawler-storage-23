from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.config import ConfigStore, cache_key, load_package_cache
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import PackageDetail, VersionInfo


def _write_valid_package(base: Path) -> Path:
    package_dir = base / "example"
    models_dir = package_dir / "models"
    models_dir.mkdir(parents=True)

    (package_dir / "rawctx.yaml").write_text(
        """
name: "@owner/sample"
version: "1.0.0"
format: "osi"
description: "Sample package"
tags:
  - demo
models:
  - models/sample.osi.yaml
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (package_dir / "README.md").write_text("# Sample\n", encoding="utf-8")

    (models_dir / "sample.osi.yaml").write_text(
        """
version: "1.0"
ai_context:
  intent: "test"
datasets:
  - name: ds
    measures:
      - name: m1
        expr: "count(*)"
    dimensions:
      - name: d1
        expr: "col"
    relationships:
      - name: rel
""".strip()
        + "\n",
        encoding="utf-8",
    )

    return package_dir


def _fake_version(version: str) -> VersionInfo:
    return VersionInfo(
        id="version-id",
        version=version,
        status="published",
        search_index_status="indexed",
        file_size=1024,
        checksum_sha256="a" * 64,
        model_summary={"dataset_count": 1},
        created_at="2026-02-28T00:00:00Z",
        published_at="2026-02-28T00:00:00Z",
    )


def _fake_package() -> PackageDetail:
    return PackageDetail(
        id="package-id",
        scope="owner",
        name="sample",
        description="Sample package",
        format="osi",
        source=None,
        domain=None,
        license=None,
        repository_url=None,
        readme="# Sample",
        tags=["demo"],
        is_private=False,
        download_count=0,
        star_count=0,
        owner=None,
    )


def test_publish_success_flow(monkeypatch, tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_test")

    calls: list[str] = []

    def fake_create_package(self, *, payload):  # type: ignore[no-untyped-def]
        calls.append("create_package")
        assert payload["scope"] == "owner"
        assert payload["name"] == "sample"
        return _fake_package()

    def fake_request_upload(self, **kwargs):  # type: ignore[no-untyped-def]
        calls.append("request_upload")
        assert kwargs["version"] == "1.0.0"
        return {
            "upload_url": "https://upload.example/rawctx",
            "version": "1.0.0",
            "version_id": "version-id",
            "status": "pending_upload",
            "s3_key": "packages/@owner/sample/1.0.0.rawctx.tar.gz",
            "expires_in": 900,
        }

    def fake_upload_bytes(self, *, upload_url: str, payload: bytes, content_type: str = "application/gzip") -> None:
        calls.append("upload_bytes")
        assert upload_url.startswith("https://")
        assert len(payload) > 0
        assert content_type == "application/gzip"

    def fake_complete(self, **kwargs):  # type: ignore[no-untyped-def]
        calls.append("complete_version")
        return _fake_version(kwargs["version"])

    def fake_get_package(self, *, scope: str, name: str) -> PackageDetail:
        calls.append("get_package")
        assert scope == "owner"
        assert name == "sample"
        return _fake_package()

    def fake_list_versions(self, *, scope: str, name: str, page: int = 1, size: int = 100):
        calls.append("list_versions")
        return [_fake_version("1.0.0")], {"page": page, "size": size, "total": 1}

    monkeypatch.setattr(RegistryClient, "create_package", fake_create_package)
    monkeypatch.setattr(RegistryClient, "request_version_upload", fake_request_upload)
    monkeypatch.setattr(RegistryClient, "upload_bytes", fake_upload_bytes)
    monkeypatch.setattr(RegistryClient, "complete_version", fake_complete)
    monkeypatch.setattr(RegistryClient, "get_package", fake_get_package)
    monkeypatch.setattr(RegistryClient, "list_versions", fake_list_versions)

    runner = CliRunner()
    result = runner.invoke(main, ["publish", str(package_dir), "--registry", "https://registry.example"])

    assert result.exit_code == 0
    assert "Published @owner/sample@1.0.0" in result.output
    assert calls == [
        "create_package",
        "request_upload",
        "upload_bytes",
        "complete_version",
        "get_package",
        "list_versions",
    ]

    store = ConfigStore()
    cache = load_package_cache(store.paths)
    assert cache_key("owner", "sample") in cache


def test_publish_requires_auth(monkeypatch, tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.delenv("RAWCTX_TOKEN", raising=False)

    runner = CliRunner()
    result = runner.invoke(main, ["publish", str(package_dir), "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "Authentication required" in result.output


def test_publish_existing_version_fails(monkeypatch, tmp_path: Path) -> None:
    package_dir = _write_valid_package(tmp_path)
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_test")

    monkeypatch.setattr(RegistryClient, "create_package", lambda self, payload: _fake_package())

    def fake_request_upload(self, **kwargs):  # type: ignore[no-untyped-def]
        raise RegistryError("version exists", status_code=409, detail="Version already exists")

    monkeypatch.setattr(RegistryClient, "request_version_upload", fake_request_upload)

    runner = CliRunner()
    result = runner.invoke(main, ["publish", str(package_dir), "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "Version already exists" in result.output
