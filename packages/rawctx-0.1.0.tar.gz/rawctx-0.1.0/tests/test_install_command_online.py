from __future__ import annotations

from io import BytesIO
from pathlib import Path
import tarfile

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.registry.client import RegistryClient
from rawctx.registry.models import PackageDetail, VersionInfo


def _archive_bytes(version: str) -> bytes:
    payload = BytesIO()
    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        rawctx_yaml = f"name: \"@owner/sample\"\nversion: \"{version}\"\nformat: \"osi\"\nmodels:\n  - models/sample.osi.yaml\n"
        model_yaml = "version: \"1.0\"\ndatasets:\n  - name: ds\n"
        for name, content in {
            "package/rawctx.yaml": rawctx_yaml,
            "package/models/sample.osi.yaml": model_yaml,
        }.items():
            content_bytes = content.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(content_bytes)
            info.mtime = 0
            tar.addfile(info, BytesIO(content_bytes))
    return payload.getvalue()


def test_install_online_selects_latest_semver(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )

    versions = [
        VersionInfo(
            id="v100",
            version="1.0.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="a" * 64,
            model_summary=None,
            created_at="2026-02-28T00:00:00Z",
            published_at="2026-02-28T00:00:00Z",
        ),
        VersionInfo(
            id="v120",
            version="1.2.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="b" * 64,
            model_summary=None,
            created_at="2026-02-28T00:00:00Z",
            published_at="2026-02-28T00:00:00Z",
        ),
    ]
    monkeypatch.setattr(RegistryClient, "list_versions", lambda self, scope, name, page=1, size=100: (versions, {"page": 1, "size": 100, "total": 2}))

    observed: dict[str, str] = {}

    def fake_request_download(self, *, scope: str, name: str, version: str):
        observed["version"] = version
        return {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900}

    monkeypatch.setattr(RegistryClient, "request_download", fake_request_download)
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.2.0"))

    runner = CliRunner()
    result = runner.invoke(main, ["install", "@owner/sample", "--registry", "https://registry.example"])

    assert result.exit_code == 0
    assert observed["version"] == "1.2.0"
    assert "@owner/sample@1.2.0" in result.output
