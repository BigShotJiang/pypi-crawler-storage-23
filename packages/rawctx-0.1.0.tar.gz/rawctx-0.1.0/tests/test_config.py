from __future__ import annotations

import json
from pathlib import Path

from rawctx.config import (
    AuthConfig,
    ConfigStore,
    RawctxConfig,
    cache_key,
    load_package_cache,
    resolve_registry,
    resolve_token,
    save_package_cache,
    upsert_cache_entry,
)


def test_config_store_save_and_load(monkeypatch, tmp_path: Path) -> None:
    config_path = tmp_path / "custom" / "config.yaml"
    monkeypatch.setenv("RAWCTX_CONFIG", str(config_path))

    store = ConfigStore()
    config = RawctxConfig()
    config.registry = "https://registry.example.com"
    config.auth = AuthConfig(
        token="rxctx_token",
        token_id="token-id",
        token_name="rawctx-cli",
        issued_at="2026-02-28T00:00:00+00:00",
    )
    config.profile.username = "owner"

    store.save(config)

    loaded = store.load()
    assert loaded.registry == "https://registry.example.com"
    assert loaded.auth.token == "rxctx_token"
    assert loaded.auth.token_id == "token-id"
    assert loaded.profile.username == "owner"


def test_resolve_registry_priority(monkeypatch) -> None:
    config = RawctxConfig(registry="https://config-registry.example")

    monkeypatch.setenv("RAWCTX_REGISTRY", "https://env-registry.example")
    assert resolve_registry(cli_registry="https://cli-registry.example", config=config) == "https://cli-registry.example"
    assert resolve_registry(cli_registry=None, config=config) == "https://env-registry.example"

    monkeypatch.delenv("RAWCTX_REGISTRY")
    assert resolve_registry(cli_registry=None, config=config) == "https://config-registry.example"


def test_resolve_token_priority(monkeypatch) -> None:
    config = RawctxConfig()
    config.auth.token = "rxctx_config"

    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_env")
    assert resolve_token(config) == "rxctx_env"

    monkeypatch.delenv("RAWCTX_TOKEN")
    assert resolve_token(config) == "rxctx_config"


def test_cache_roundtrip(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    store = ConfigStore()

    cache = load_package_cache(store.paths)
    assert cache == {}

    upsert_cache_entry(
        cache,
        scope="owner",
        name="sample",
        package={"scope": "owner", "name": "sample", "format": "osi"},
        versions=[{"version": "1.0.0", "status": "published"}],
    )
    save_package_cache(store.paths, cache)

    reloaded = load_package_cache(store.paths)
    entry = reloaded[cache_key("owner", "sample")]
    assert entry["package"]["format"] == "osi"
    assert entry["versions"][0]["version"] == "1.0.0"

    # cache is real JSON file
    parsed = json.loads(store.paths.package_index_path.read_text(encoding="utf-8"))
    assert cache_key("owner", "sample") in parsed
