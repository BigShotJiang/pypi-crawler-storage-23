from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.registry.client import RegistryClient, SearchResult
from rawctx.registry.models import SearchItem


def test_search_online_passes_filters(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    observed: dict[str, object] = {}

    def fake_search_packages(self, *, query, format, domain, source, tags, page, size):
        observed.update(
            {
                "query": query,
                "format": format,
                "domain": domain,
                "source": source,
                "tags": tags,
                "page": page,
                "size": size,
            }
        )
        return SearchResult(
            items=[
                SearchItem(
                    id="pkg-1",
                    scope="owner",
                    name="sample",
                    description="Sample",
                    format="osi",
                    source="shopify",
                    domain="finance",
                    tags=["demo"],
                    download_count=1,
                    star_count=2,
                )
            ],
            meta={"page": page, "size": size, "total": 1},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "search",
            "salesforce revenue",
            "--format",
            "osi",
            "--domain",
            "finance",
            "--source",
            "shopify",
            "--tags",
            "demo",
            "--page",
            "2",
            "--size",
            "10",
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code == 0
    assert observed == {
        "query": "salesforce revenue",
        "format": "osi",
        "domain": "finance",
        "source": "shopify",
        "tags": "demo",
        "page": 2,
        "size": 10,
    }
    assert "@owner/sample" in result.output
