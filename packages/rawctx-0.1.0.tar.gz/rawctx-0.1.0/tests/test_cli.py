from click.testing import CliRunner

from rawctx.cli import main


EXPECTED_COMMANDS = ["publish", "search", "install", "info", "validate", "pack"]
EXPECTED_COMMANDS.extend(["login", "logout"])


def test_help_shows_commands() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])

    assert result.exit_code == 0
    for command in EXPECTED_COMMANDS:
        assert command in result.output
