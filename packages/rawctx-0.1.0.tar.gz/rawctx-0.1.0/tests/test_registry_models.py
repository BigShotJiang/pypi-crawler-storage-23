from __future__ import annotations

import pytest

from rawctx.registry.models import OAuthLoginInfo, OAuthSessionInfo, choose_latest_version, parse_package_ref, semver_key


def test_parse_package_ref_with_and_without_version() -> None:
    parsed = parse_package_ref("@owner/sample")
    assert parsed.scope == "owner"
    assert parsed.name == "sample"
    assert parsed.version is None

    parsed_with_version = parse_package_ref("@owner/sample@1.2.3")
    assert parsed_with_version.scope == "owner"
    assert parsed_with_version.name == "sample"
    assert parsed_with_version.version == "1.2.3"


@pytest.mark.parametrize(
    "raw",
    [
        "owner/sample",
        "@Owner/sample",
        "@owner/Sample",
        "@owner/sample@1.2",
        "@owner",
    ],
)
def test_parse_package_ref_invalid(raw: str) -> None:
    with pytest.raises(ValueError):
        parse_package_ref(raw)


def test_choose_latest_version() -> None:
    assert choose_latest_version(["1.0.0", "1.2.0", "1.10.0", "2.0.0"]) == "2.0.0"
    assert choose_latest_version(["bad", "1.0", "1.0.0"]) == "1.0.0"
    assert choose_latest_version(["bad", "1.0"]) is None


def test_semver_key() -> None:
    assert semver_key("2.10.3") == (2, 10, 3)
    with pytest.raises(ValueError):
        semver_key("2.10")


def test_oauth_models_parse_optional_fields() -> None:
    login_info = OAuthLoginInfo.from_api(
        {
            "authorize_url": "https://auth.example/login",
            "state": "state123",
            "session_id": "sess123",
            "poll_interval_seconds": 1,
        }
    )
    assert login_info.session_id == "sess123"
    assert login_info.poll_interval_seconds == 1

    session_info = OAuthSessionInfo.from_api(
        {
            "session_id": "sess123",
            "status": "error",
            "error": "access_denied",
            "error_description": "User denied access",
        }
    )
    assert session_info.status == "error"
    assert session_info.error == "access_denied"
