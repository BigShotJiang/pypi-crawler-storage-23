from __future__ import annotations

import httpx
import pytest

from rawctx.registry.client import RegistryClient, RegistryError


def _make_client(handler) -> RegistryClient:  # type: ignore[no-untyped-def]
    transport = httpx.MockTransport(handler)
    http_client = httpx.Client(transport=transport, base_url="https://registry.test")
    return RegistryClient(registry="https://registry.test", client=http_client)


def test_create_api_token_sends_authorization_header() -> None:
    observed: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        observed["authorization"] = request.headers.get("Authorization", "")
        return httpx.Response(
            200,
            json={
                "id": "token-id",
                "name": "rawctx-cli",
                "token": "rxctx_abc",
                "prefix": "rxctx_abc",
                "created_at": "2026-02-28T00:00:00Z",
                "expires_at": None,
            },
        )

    client = _make_client(handler)
    try:
        token = client.create_api_token(id_token="jwt.id.token", name="rawctx-cli")
    finally:
        client.close()

    assert observed["authorization"] == "Bearer jwt.id.token"
    assert token.token == "rxctx_abc"


def test_oauth_login_and_session_parsing() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/api/auth/login/github"):
            return httpx.Response(
                200,
                json={
                    "authorize_url": "https://auth.example/login",
                    "state": "state-123",
                    "session_id": "sess-123",
                    "poll_interval_seconds": 1,
                },
            )
        if request.url.path.endswith("/api/auth/login/github/session/sess-123"):
            return httpx.Response(
                200,
                json={
                    "session_id": "sess-123",
                    "status": "ready",
                    "id_token": "jwt.token.value",
                },
            )
        return httpx.Response(404, json={"detail": "not found"})

    client = _make_client(handler)
    try:
        login_info = client.oauth_login_github()
        session = client.oauth_login_session("sess-123")
    finally:
        client.close()

    assert login_info.session_id == "sess-123"
    assert login_info.poll_interval_seconds == 1
    assert session.status == "ready"
    assert session.id_token == "jwt.token.value"


def test_registry_error_maps_status_and_detail() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(403, json={"detail": "Forbidden"})

    client = _make_client(handler)
    try:
        with pytest.raises(RegistryError) as exc:
            client.get_package(scope="owner", name="sample")
    finally:
        client.close()

    assert exc.value.status_code == 403
    assert "Forbidden" in str(exc.value)


def test_revoke_token_returns_false_on_404() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "Token not found"})

    client = _make_client(handler)
    try:
        assert client.revoke_api_token("missing-token") is False
    finally:
        client.close()


def test_upload_memory_scheme_is_rejected() -> None:
    client = _make_client(lambda request: httpx.Response(200, json={}))
    try:
        with pytest.raises(RegistryError) as exc:
            client.upload_bytes(upload_url="memory://bucket/key", payload=b"abc")
    finally:
        client.close()

    assert "memory://" in str(exc.value)


def test_download_rejects_non_http_scheme() -> None:
    client = _make_client(lambda request: httpx.Response(200, json={}))
    try:
        with pytest.raises(RegistryError) as exc:
            client.download_bytes(download_url="ftp://example.com/file")
    finally:
        client.close()

    assert "Unsupported" in str(exc.value)
