from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from ruamel.yaml import YAML
from ruamel.yaml.error import YAMLError

from rawctx.packaging.manifest import ValidationError


@dataclass(frozen=True)
class OsiSummary:
    datasets: int
    measures: int
    dimensions: int
    relationships: int
    has_ai_context: bool


def _schema_path() -> Path:
    return Path(__file__).resolve().parent.parent / "schemas" / "osi" / "v1.0" / "schema.json"


def _load_schema() -> dict[str, Any]:
    schema_file = _schema_path()
    try:
        with schema_file.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except OSError as exc:
        raise ValidationError("failed to load vendored OSI schema", schema_file) from exc


def _read_yaml(path: Path) -> dict[str, Any]:
    yaml = YAML(typ="safe")
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = yaml.load(handle)
    except YAMLError as exc:
        line = getattr(getattr(exc, "problem_mark", None), "line", None)
        col = getattr(getattr(exc, "problem_mark", None), "column", None)
        raise ValidationError(
            "invalid YAML syntax",
            path,
            line=None if line is None else line + 1,
            column=None if col is None else col + 1,
        ) from exc
    except OSError as exc:
        raise ValidationError("failed to read OSI file", path) from exc

    if not isinstance(data, dict):
        raise ValidationError("OSI document root must be a mapping", path)
    return data


def _first_schema_error(data: dict[str, Any], schema: dict[str, Any]) -> ValidationError | None:
    validator = Draft202012Validator(schema)
    for error in validator.iter_errors(data):
        field = ".".join(str(part) for part in error.absolute_path)
        return ValidationError(
            message=error.message,
            field=field or None,
        )
    return None


def _summary(data: dict[str, Any]) -> OsiSummary:
    datasets = data.get("datasets", [])
    dataset_count = len(datasets) if isinstance(datasets, list) else 0

    measures = 0
    dimensions = 0
    relationships = 0

    if isinstance(datasets, list):
        for dataset in datasets:
            if not isinstance(dataset, dict):
                continue
            dataset_measures = dataset.get("measures", [])
            dataset_dimensions = dataset.get("dimensions", [])
            dataset_relationships = dataset.get("relationships", [])
            if isinstance(dataset_measures, list):
                measures += len(dataset_measures)
            if isinstance(dataset_dimensions, list):
                dimensions += len(dataset_dimensions)
            if isinstance(dataset_relationships, list):
                relationships += len(dataset_relationships)

    return OsiSummary(
        datasets=dataset_count,
        measures=measures,
        dimensions=dimensions,
        relationships=relationships,
        has_ai_context="ai_context" in data,
    )


def validate_osi(path: Path) -> OsiSummary:
    data = _read_yaml(path)
    schema = _load_schema()
    schema_error = _first_schema_error(data, schema)
    if schema_error is not None:
        raise ValidationError(
            schema_error.message,
            file_path=path,
            field=schema_error.field,
        )
    return _summary(data)
