"""MetricFlow format support placeholder for later rounds."""
