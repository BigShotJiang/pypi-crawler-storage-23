"""Format parsers and validators (Round 0 scaffold)."""
