"""Converter base interfaces (Round 0 scaffold)."""
