"""MetricFlow -> OSI converter placeholder."""
