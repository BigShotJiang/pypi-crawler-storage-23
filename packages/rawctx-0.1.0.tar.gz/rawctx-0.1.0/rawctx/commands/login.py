from __future__ import annotations

import click

from rawctx.config import ConfigStore, resolve_registry, resolve_token
from rawctx.registry.auth import (
    login_with_id_token,
    logout_auth,
    start_oauth_login,
    wait_for_oauth_id_token,
)
from rawctx.registry.client import RegistryClient, RegistryError


@click.command()
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
@click.option("--id-token", default=None, help="JWT id_token from OAuth callback")
@click.option("--token-name", default="rawctx-cli", show_default=True, help="Name for the generated API token")
@click.option("--expires-in-days", type=int, default=None, help="Token expiration in days")
@click.option("--no-browser", is_flag=True, default=False, help="Do not open browser automatically")
def login(
    registry_override: str | None,
    id_token: str | None,
    token_name: str,
    expires_in_days: int | None,
    no_browser: bool,
) -> None:
    store = ConfigStore()
    config = store.load()
    registry = resolve_registry(cli_registry=registry_override, config=config)
    config.registry = registry

    client = RegistryClient(registry=registry)
    try:
        login_info = start_oauth_login(client=client, open_browser=not no_browser)
    except RegistryError as exc:
        client.close()
        raise click.ClickException(str(exc)) from exc

    click.echo(f"Open this URL and sign in with GitHub:\n{login_info.authorize_url}")

    provided_token = id_token.strip() if id_token else ""
    if not provided_token:
        if login_info.session_id:
            click.echo("Waiting for OAuth login to complete in browser...")
            try:
                provided_token = wait_for_oauth_id_token(
                    client=client,
                    session_id=login_info.session_id,
                    poll_interval_seconds=login_info.poll_interval_seconds,
                )
            except RegistryError as exc:
                raise click.ClickException(str(exc)) from exc
        else:
            click.echo("Automatic token capture is unavailable on this registry.")
            click.echo("After login, copy the id_token and paste it below.")
            provided_token = click.prompt("id_token", type=str).strip()

    if not provided_token:
        client.close()
        raise click.ClickException("id_token is required")

    try:
        token_info = login_with_id_token(
            client=client,
            store=store,
            config=config,
            id_token=provided_token,
            token_name=token_name,
            expires_in_days=expires_in_days,
        )
    except RegistryError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()

    click.echo(f"Login succeeded. API token saved to {store.paths.config_path}")
    click.echo(f"Token id: {token_info.id}")


@click.command()
@click.option("--local-only", is_flag=True, default=False, help="Delete local token only")
def logout(local_only: bool) -> None:
    store = ConfigStore()
    config = store.load()

    if not config.auth.token:
        click.echo("No local auth token found.")
        return

    registry = resolve_registry(cli_registry=None, config=config)
    token = resolve_token(config)

    client: RegistryClient | None = None
    if not local_only and token:
        client = RegistryClient(registry=registry, token=token)

    try:
        had_token, revoked = logout_auth(
            client=client,
            store=store,
            config=config,
            local_only=local_only,
        )
    except RegistryError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        if client is not None:
            client.close()

    if not had_token:
        click.echo("No local auth token found.")
        return

    if local_only:
        click.echo("Logged out locally.")
    elif revoked:
        click.echo("Token revoked on server and removed locally.")
    else:
        click.echo("Local token removed. Server token could not be revoked.")
