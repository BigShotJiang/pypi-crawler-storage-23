import click

from .common import not_implemented


@click.command()
def convert() -> None:
    not_implemented("convert")
