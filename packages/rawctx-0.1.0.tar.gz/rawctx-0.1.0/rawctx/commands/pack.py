from pathlib import Path

import click

from rawctx.commands.validate import validate_target
from rawctx.packaging.builder import build_package_archive
from rawctx.packaging.manifest import ValidationError


@click.command()
@click.argument("target_dir", required=False, default=".")
@click.option("--output-dir", default="dist", show_default=True)
def pack(target_dir: str, output_dir: str) -> None:
    target_path = Path(target_dir).expanduser().resolve()
    if not target_path.is_dir():
        raise click.UsageError("pack target must be a directory")

    try:
        validation_result = validate_target(target_path, "auto")
        if validation_result.manifest is None:
            raise click.ClickException("manifest validation did not produce a manifest")
        build = build_package_archive(target_path, Path(output_dir), manifest=validation_result.manifest)
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc

    click.echo(f"package created: {build.archive_path}")
