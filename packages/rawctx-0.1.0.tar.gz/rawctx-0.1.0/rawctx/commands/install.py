from __future__ import annotations

from dataclasses import asdict
from io import BytesIO
from pathlib import Path
import shutil
import tarfile
from typing import Any

import click

from rawctx.config import ConfigStore, cache_key, load_package_cache, resolve_registry, resolve_token, save_package_cache, upsert_cache_entry
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import choose_latest_version, is_valid_semver, parse_package_ref


@click.command()
@click.argument("package_ref", required=True)
@click.option("--dest", "dest_path", default=None, help="Install destination root")
@click.option("--offline", is_flag=True, default=False)
@click.option("--force", is_flag=True, default=False)
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def install(
    package_ref: str,
    dest_path: str | None,
    offline: bool,
    force: bool,
    registry_override: str | None,
) -> None:
    try:
        parsed = parse_package_ref(package_ref)
    except ValueError as exc:
        raise click.UsageError(str(exc)) from exc

    store = ConfigStore()
    config = store.load()
    cache = load_package_cache(store.paths)

    destination_root = Path(dest_path).expanduser().resolve() if dest_path else None
    if destination_root is not None:
        destination_root.mkdir(parents=True, exist_ok=True)

    selected_version: str
    archive_bytes: bytes | None = None
    archive_path: Path | None = None

    if offline:
        selected_version = _select_offline_version(cache, store.paths.archives_dir, parsed.scope, parsed.name, parsed.version)
        archive_path = store.paths.archive_path(parsed.scope, parsed.name, selected_version)
        if not archive_path.exists():
            raise click.ClickException(f"No cached archive found for @{parsed.scope}/{parsed.name}@{selected_version}")
    else:
        registry = resolve_registry(cli_registry=registry_override, config=config)
        token = resolve_token(config)
        client = RegistryClient(registry=registry, token=token)
        try:
            package = client.get_package(scope=parsed.scope, name=parsed.name)
            versions, _meta = client.list_versions(scope=parsed.scope, name=parsed.name, page=1, size=100)
            selected_version = parsed.version or _select_latest_version([item.version for item in versions])
            if not selected_version:
                raise click.ClickException(f"No installable version found for @{parsed.scope}/{parsed.name}")

            download = client.request_download(scope=parsed.scope, name=parsed.name, version=selected_version)
            download_url = str(download.get("download_url") or "")
            if not download_url:
                raise click.ClickException("Registry did not return download_url")

            archive_bytes = client.download_bytes(download_url=download_url)
            archive_path = store.paths.archive_path(parsed.scope, parsed.name, selected_version)
            archive_path.parent.mkdir(parents=True, exist_ok=True)
            archive_path.write_bytes(archive_bytes)

            upsert_cache_entry(
                cache,
                scope=parsed.scope,
                name=parsed.name,
                package=asdict(package),
                versions=[asdict(item) for item in versions],
            )
            save_package_cache(store.paths, cache)
        except RegistryError as exc:
            raise click.ClickException(str(exc)) from exc
        finally:
            client.close()

    if archive_path is None:
        raise click.ClickException("archive path resolution failed")

    install_target = store.paths.install_path(parsed.scope, parsed.name, selected_version, destination=destination_root)
    if install_target.exists():
        if not force:
            raise click.ClickException(f"Install target already exists: {install_target}. Use --force to overwrite.")
        shutil.rmtree(install_target)

    install_target.mkdir(parents=True, exist_ok=True)
    _extract_archive(
        archive_bytes=archive_bytes if archive_bytes is not None else archive_path.read_bytes(),
        target_dir=install_target,
    )

    click.echo(f"Installed @{parsed.scope}/{parsed.name}@{selected_version} -> {install_target}")


def _select_offline_version(
    cache: dict[str, dict[str, Any]],
    archives_root: Path,
    scope: str,
    name: str,
    preferred_version: str | None,
) -> str:
    if preferred_version:
        return preferred_version

    entry = cache.get(cache_key(scope, name), {})
    candidates: list[str] = []
    versions = entry.get("versions")
    if isinstance(versions, list):
        for item in versions:
            if isinstance(item, dict):
                candidate = item.get("version")
                if isinstance(candidate, str) and is_valid_semver(candidate):
                    candidates.append(candidate)

    archive_dir = archives_root / f"@{scope}" / name
    if archive_dir.exists():
        for file_path in archive_dir.glob("*.rawctx.tar.gz"):
            version = file_path.name.removesuffix(".rawctx.tar.gz")
            if is_valid_semver(version):
                candidates.append(version)

    selected = _select_latest_version(candidates)
    if not selected:
        raise click.ClickException(f"No cached versions found for @{scope}/{name}")
    return selected


def _select_latest_version(versions: list[str]) -> str | None:
    return choose_latest_version(versions)


def _extract_archive(*, archive_bytes: bytes, target_dir: Path) -> None:
    try:
        with tarfile.open(fileobj=BytesIO(archive_bytes), mode="r:gz") as tar:
            for member in tar.getmembers():
                if not member.name.startswith("package/"):
                    continue
                relative = Path(member.name).relative_to("package")
                if not relative.parts:
                    continue

                destination = (target_dir / relative).resolve()
                if target_dir not in destination.parents and destination != target_dir:
                    raise click.ClickException(f"Unsafe archive entry: {member.name}")

                if member.isdir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                extracted = tar.extractfile(member)
                if extracted is None:
                    continue
                destination.write_bytes(extracted.read())
    except tarfile.TarError as exc:
        raise click.ClickException(f"Invalid package archive: {exc}") from exc
