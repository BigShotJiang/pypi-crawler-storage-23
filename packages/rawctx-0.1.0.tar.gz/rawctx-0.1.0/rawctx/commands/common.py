import click


def not_implemented(command_name: str) -> None:
    click.echo(f"{command_name}: not implemented in Round 0")
