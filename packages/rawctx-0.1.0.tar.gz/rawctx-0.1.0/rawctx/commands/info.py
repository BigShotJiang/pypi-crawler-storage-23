from __future__ import annotations

from dataclasses import asdict
import json
from typing import Any

import click

from rawctx.config import ConfigStore, cache_key, load_package_cache, resolve_registry, resolve_token, save_package_cache, upsert_cache_entry
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import PackageDetail, VersionInfo, parse_package_ref


@click.command()
@click.argument("package_ref", required=True)
@click.option("--json", "json_output", is_flag=True, default=False)
@click.option("--offline", is_flag=True, default=False)
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def info(package_ref: str, json_output: bool, offline: bool, registry_override: str | None) -> None:
    try:
        parsed = parse_package_ref(package_ref)
    except ValueError as exc:
        raise click.UsageError(str(exc)) from exc

    store = ConfigStore()
    config = store.load()
    cache = load_package_cache(store.paths)

    package: PackageDetail
    versions: list[VersionInfo]

    if offline:
        package, versions = _load_offline(cache, parsed.scope, parsed.name)
    else:
        registry = resolve_registry(cli_registry=registry_override, config=config)
        token = resolve_token(config)
        client = RegistryClient(registry=registry, token=token)
        try:
            package = client.get_package(scope=parsed.scope, name=parsed.name)
            versions, _meta = client.list_versions(scope=parsed.scope, name=parsed.name, page=1, size=100)
            upsert_cache_entry(
                cache,
                scope=parsed.scope,
                name=parsed.name,
                package=asdict(package),
                versions=[asdict(item) for item in versions],
            )
            save_package_cache(store.paths, cache)
        except RegistryError as exc:
            raise click.ClickException(str(exc)) from exc
        finally:
            client.close()

    selected_version = None
    if parsed.version:
        selected_version = next((item for item in versions if item.version == parsed.version), None)
        if selected_version is None:
            raise click.ClickException(f"Version not found: {parsed.normalized}")

    if json_output:
        payload = {
            "package": asdict(package),
            "versions": [asdict(item) for item in versions],
            "selected_version": asdict(selected_version) if selected_version else None,
        }
        click.echo(json.dumps(payload, indent=2))
        return

    click.echo(f"Package: {package.package_name}")
    click.echo(f"Description: {package.description or '-'}")
    click.echo(f"Format: {package.format}")
    click.echo(f"Source: {package.source or '-'}  Domain: {package.domain or '-'}")
    click.echo(f"Downloads: {package.download_count}  Stars: {package.star_count}")
    click.echo(f"Tags: {', '.join(package.tags) if package.tags else '-'}")

    if selected_version:
        click.echo(f"Version: {selected_version.version} ({selected_version.status})")
        if selected_version.model_summary:
            summary = selected_version.model_summary
            click.echo(
                "Model summary: "
                f"datasets={summary.get('dataset_count', 0)} "
                f"measures={summary.get('measure_count', 0)} "
                f"dimensions={summary.get('dimension_count', 0)} "
                f"relationships={summary.get('relationship_count', 0)}"
            )
    else:
        if versions:
            click.echo("Versions: " + ", ".join(item.version for item in versions))
        else:
            click.echo("Versions: -")


def _load_offline(cache: dict[str, dict[str, Any]], scope: str, name: str) -> tuple[PackageDetail, list[VersionInfo]]:
    entry = cache.get(cache_key(scope, name))
    if not entry:
        raise click.ClickException(f"No cached package found for @{scope}/{name}")

    package_raw = entry.get("package")
    if not isinstance(package_raw, dict):
        raise click.ClickException(f"Cached package data is invalid for @{scope}/{name}")

    versions_raw = entry.get("versions")
    versions: list[VersionInfo] = []
    if isinstance(versions_raw, list):
        for item in versions_raw:
            if isinstance(item, dict):
                versions.append(VersionInfo.from_api(item))

    return PackageDetail.from_api(package_raw), versions
