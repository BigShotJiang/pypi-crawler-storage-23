from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import tempfile

import click

from rawctx.commands.validate import validate_target
from rawctx.config import ConfigStore, load_package_cache, resolve_registry, resolve_token, save_package_cache, upsert_cache_entry
from rawctx.packaging.builder import build_package_archive
from rawctx.packaging.manifest import ValidationError
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import parse_package_ref


@click.command()
@click.argument("target_dir", required=False, default=".")
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def publish(target_dir: str, registry_override: str | None) -> None:
    target_path = Path(target_dir).expanduser().resolve()
    if not target_path.is_dir():
        raise click.UsageError("publish target must be a directory")

    try:
        validation_result = validate_target(target_path, "auto")
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc

    manifest = validation_result.manifest
    if manifest is None:
        raise click.ClickException("manifest validation did not produce a manifest")

    readme_text: str | None = None
    readme_path = target_path / "README.md"
    if readme_path.is_file():
        readme_text = readme_path.read_text(encoding="utf-8")

    with tempfile.TemporaryDirectory(prefix="rawctx-publish-") as tmp_dir:
        build = build_package_archive(target_path, Path(tmp_dir), manifest=manifest)
        archive_bytes = build.archive_path.read_bytes()

    checksum = sha256(archive_bytes).hexdigest()

    store = ConfigStore()
    config = store.load()
    registry = resolve_registry(cli_registry=registry_override, config=config)
    token = resolve_token(config)
    if not token:
        raise click.ClickException("Authentication required. Run `rawctx login` first.")

    package_ref = parse_package_ref(manifest.name)

    payload = {
        "scope": package_ref.scope,
        "name": package_ref.name,
        "description": manifest.description,
        "format": manifest.format,
        "source": manifest.source,
        "domain": manifest.domain,
        "license": manifest.license,
        "repository_url": manifest.repository,
        "readme": readme_text,
        "tags": manifest.tags or [],
    }

    client = RegistryClient(registry=registry, token=token)
    try:
        try:
            client.create_package(payload=payload)
        except RegistryError as exc:
            if exc.status_code != 409:
                raise

        try:
            upload_data = client.request_version_upload(
                scope=package_ref.scope,
                name=package_ref.name,
                version=manifest.version,
                file_size=len(archive_bytes),
                checksum_sha256=checksum,
                content_type="application/gzip",
            )
        except RegistryError as exc:
            if exc.status_code == 409:
                raise click.ClickException(f"Version already exists: {package_ref.package_name}@{manifest.version}") from exc
            raise

        upload_url = str(upload_data.get("upload_url") or "")
        if not upload_url:
            raise click.ClickException("Registry did not return upload_url")

        client.upload_bytes(upload_url=upload_url, payload=archive_bytes, content_type="application/gzip")
        version_info = client.complete_version(
            scope=package_ref.scope,
            name=package_ref.name,
            version=manifest.version,
            checksum_sha256=checksum,
        )

        package_detail = client.get_package(scope=package_ref.scope, name=package_ref.name)
        versions, _meta = client.list_versions(scope=package_ref.scope, name=package_ref.name)

        cache = load_package_cache(store.paths)
        upsert_cache_entry(
            cache,
            scope=package_ref.scope,
            name=package_ref.name,
            package=asdict(package_detail),
            versions=[asdict(item) for item in versions],
        )
        save_package_cache(store.paths, cache)
    except click.ClickException:
        raise
    except RegistryError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()

    click.echo(f"Published {package_ref.package_name}@{version_info.version}")
