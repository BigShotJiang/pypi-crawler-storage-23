from __future__ import annotations

from dataclasses import asdict
from datetime import UTC, datetime
import json
from typing import Any

import click

from rawctx.config import ConfigStore, load_package_cache, resolve_registry, resolve_token, save_package_cache, upsert_cache_entry
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import SearchItem


@click.command()
@click.argument("query", required=False, default=None)
@click.option("--format", "format_filter", default=None)
@click.option("--domain", default=None)
@click.option("--source", default=None)
@click.option("--tags", default=None, help="Comma-separated tags")
@click.option("--page", default=1, type=int, show_default=True)
@click.option("--size", default=20, type=int, show_default=True)
@click.option("--json", "json_output", is_flag=True, default=False)
@click.option("--offline", is_flag=True, default=False)
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def search(
    query: str | None,
    format_filter: str | None,
    domain: str | None,
    source: str | None,
    tags: str | None,
    page: int,
    size: int,
    json_output: bool,
    offline: bool,
    registry_override: str | None,
) -> None:
    if page < 1:
        raise click.UsageError("--page must be >= 1")
    if size < 1 or size > 100:
        raise click.UsageError("--size must be between 1 and 100")

    store = ConfigStore()
    config = store.load()
    cache = load_package_cache(store.paths)

    if offline:
        items, meta = _search_cache(
            cache,
            query=query,
            format_filter=format_filter,
            domain=domain,
            source=source,
            tags=tags,
            page=page,
            size=size,
        )
    else:
        registry = resolve_registry(cli_registry=registry_override, config=config)
        token = resolve_token(config)
        client = RegistryClient(registry=registry, token=token)
        try:
            result = client.search_packages(
                query=query,
                format=format_filter,
                domain=domain,
                source=source,
                tags=tags,
                page=page,
                size=size,
            )
            items = result.items
            meta = result.meta

            for item in items:
                upsert_cache_entry(
                    cache,
                    scope=item.scope,
                    name=item.name,
                    package={
                        "id": item.id,
                        "scope": item.scope,
                        "name": item.name,
                        "description": item.description,
                        "format": item.format,
                        "source": item.source,
                        "domain": item.domain,
                        "tags": item.tags,
                        "download_count": item.download_count,
                        "star_count": item.star_count,
                    },
                )
            save_package_cache(store.paths, cache)
        except RegistryError as exc:
            raise click.ClickException(str(exc)) from exc
        finally:
            client.close()

    if json_output:
        click.echo(
            json.dumps(
                {
                    "items": [asdict(item) for item in items],
                    "meta": meta,
                },
                indent=2,
            )
        )
        return

    if not items:
        if offline:
            click.echo("No cached packages matched.")
        else:
            click.echo("No packages found.")
        return

    for item in items:
        description = (item.description or "").strip()
        click.echo(
            f"{item.package_name:<36} format={item.format:<8} "
            f"stars={item.star_count:<4} downloads={item.download_count:<6} {description}"
        )
    click.echo(f"page={meta.get('page', page)} size={meta.get('size', size)} total={meta.get('total', len(items))}")


def _search_cache(
    cache: dict[str, dict[str, Any]],
    *,
    query: str | None,
    format_filter: str | None,
    domain: str | None,
    source: str | None,
    tags: str | None,
    page: int,
    size: int,
) -> tuple[list[SearchItem], dict[str, int]]:
    tag_filters = [tag.strip().lower() for tag in (tags or "").split(",") if tag.strip()]
    normalized_query = (query or "").strip().lower()

    matched: list[SearchItem] = []
    for key, entry in cache.items():
        package = entry.get("package")
        if not isinstance(package, dict):
            continue

        scope = str(package.get("scope") or "")
        name = str(package.get("name") or "")
        if not scope or not name:
            try:
                scope_name = key[1:].split("/", 1) if key.startswith("@") else key.split("/", 1)
                scope, name = scope_name[0], scope_name[1]
            except Exception:
                continue

        package_tags = [str(tag).strip() for tag in package.get("tags", []) if str(tag).strip()]

        if normalized_query:
            haystack = " ".join(
                [
                    f"@{scope}/{name}",
                    str(package.get("description") or ""),
                    str(package.get("format") or ""),
                    str(package.get("source") or ""),
                    str(package.get("domain") or ""),
                    " ".join(package_tags),
                ]
            ).lower()
            if normalized_query not in haystack:
                continue

        if format_filter and str(package.get("format") or "").lower() != format_filter.lower():
            continue
        if domain and str(package.get("domain") or "").lower() != domain.lower():
            continue
        if source and str(package.get("source") or "").lower() != source.lower():
            continue
        if tag_filters:
            lowered_tags = {tag.lower() for tag in package_tags}
            if not set(tag_filters).issubset(lowered_tags):
                continue

        matched.append(
            SearchItem(
                id=str(package.get("id") or key),
                scope=scope,
                name=name,
                description=package.get("description") if isinstance(package.get("description"), str) else None,
                format=str(package.get("format") or "unknown"),
                source=package.get("source") if isinstance(package.get("source"), str) else None,
                domain=package.get("domain") if isinstance(package.get("domain"), str) else None,
                tags=package_tags,
                download_count=int(package.get("download_count") or 0),
                star_count=int(package.get("star_count") or 0),
            )
        )

    matched.sort(key=lambda item: (item.download_count, item.star_count, item.package_name), reverse=True)
    total = len(matched)
    start = (page - 1) * size
    end = start + size
    paged = matched[start:end]
    return paged, {"page": page, "size": size, "total": total, "cached_at": int(datetime.now(UTC).timestamp())}
