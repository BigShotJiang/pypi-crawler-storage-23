from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any

from ruamel.yaml import YAML
from ruamel.yaml.error import YAMLError


SEMVER_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")
PACKAGE_NAME_RE = re.compile(r"^@([a-z0-9][a-z0-9-]*)/([a-z0-9][a-z0-9-]*)$")
SUPPORTED_FORMATS = {"osi"}


@dataclass(frozen=True)
class ManifestAuthor:
    name: str
    org: str | None = None
    url: str | None = None


@dataclass(frozen=True)
class Manifest:
    name: str
    version: str
    format: str
    models: list[str]
    description: str | None = None
    license: str | None = None
    author: ManifestAuthor | None = None
    source: str | None = None
    domain: str | None = None
    tags: list[str] | None = None
    dependencies: list[str] | None = None
    repository: str | None = None


@dataclass(frozen=True)
class ValidationError(Exception):
    message: str
    file_path: Path | None = None
    field: str | None = None
    line: int | None = None
    column: int | None = None

    def __str__(self) -> str:
        location = []
        if self.file_path is not None:
            location.append(str(self.file_path))
        if self.line is not None:
            position = f"line {self.line}"
            if self.column is not None:
                position += f", column {self.column}"
            location.append(position)
        if self.field:
            location.append(f"field '{self.field}'")

        if location:
            return f"{self.message} ({', '.join(location)})"
        return self.message


def _as_str(value: Any, field: str, manifest_path: Path) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValidationError("expected non-empty string", manifest_path, field=field)
    return value


def _as_optional_str(value: Any, field: str, manifest_path: Path) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValidationError("expected string", manifest_path, field=field)
    cleaned = value.strip()
    return cleaned or None


def _as_str_list(
    value: Any,
    field: str,
    manifest_path: Path,
    *,
    allow_empty: bool,
) -> list[str]:
    if not isinstance(value, list):
        raise ValidationError("expected list", manifest_path, field=field)
    if not value and not allow_empty:
        raise ValidationError("expected non-empty list", manifest_path, field=field)
    items: list[str] = []
    for index, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            raise ValidationError(
                "expected non-empty string item",
                manifest_path,
                field=f"{field}[{index}]",
            )
        items.append(item)
    return items


def load_manifest(manifest_path: Path) -> Manifest:
    yaml = YAML(typ="safe")
    try:
        with manifest_path.open("r", encoding="utf-8") as handle:
            raw = yaml.load(handle)
    except YAMLError as exc:
        line = getattr(getattr(exc, "problem_mark", None), "line", None)
        col = getattr(getattr(exc, "problem_mark", None), "column", None)
        raise ValidationError(
            "invalid YAML syntax",
            manifest_path,
            line=None if line is None else line + 1,
            column=None if col is None else col + 1,
        ) from exc
    except OSError as exc:
        raise ValidationError("failed to read manifest", manifest_path) from exc

    if not isinstance(raw, dict):
        raise ValidationError("manifest root must be a mapping", manifest_path)

    author_value = raw.get("author")
    author: ManifestAuthor | None = None
    if author_value is not None:
        if not isinstance(author_value, dict):
            raise ValidationError("author must be an object", manifest_path, field="author")
        author = ManifestAuthor(
            name=_as_str(author_value.get("name"), "author.name", manifest_path),
            org=_as_optional_str(author_value.get("org"), "author.org", manifest_path),
            url=_as_optional_str(author_value.get("url"), "author.url", manifest_path),
        )

    tags_value = raw.get("tags")
    tags: list[str] | None = None
    if tags_value is not None:
        tags = _as_str_list(tags_value, "tags", manifest_path, allow_empty=True)

    dependencies_value = raw.get("dependencies")
    dependencies: list[str] | None = None
    if dependencies_value is not None:
        dependencies = _as_str_list(
            dependencies_value,
            "dependencies",
            manifest_path,
            allow_empty=True,
        )

    manifest = Manifest(
        name=_as_str(raw.get("name"), "name", manifest_path),
        version=_as_str(raw.get("version"), "version", manifest_path),
        format=_as_str(raw.get("format"), "format", manifest_path),
        models=_as_str_list(raw.get("models"), "models", manifest_path, allow_empty=False),
        description=_as_optional_str(raw.get("description"), "description", manifest_path),
        license=_as_optional_str(raw.get("license"), "license", manifest_path),
        author=author,
        source=_as_optional_str(raw.get("source"), "source", manifest_path),
        domain=_as_optional_str(raw.get("domain"), "domain", manifest_path),
        tags=tags,
        dependencies=dependencies,
        repository=_as_optional_str(raw.get("repository"), "repository", manifest_path),
    )
    return manifest


def validate_manifest(manifest: Manifest, base_dir: Path, manifest_path: Path | None = None) -> None:
    effective_path = manifest_path or base_dir / "rawctx.yaml"

    if not PACKAGE_NAME_RE.match(manifest.name):
        raise ValidationError(
            "name must match '@scope/package' using lowercase letters, numbers, and hyphen",
            effective_path,
            field="name",
        )

    if not SEMVER_RE.match(manifest.version):
        raise ValidationError(
            "version must be a SemVer string (X.Y.Z)",
            effective_path,
            field="version",
        )

    if manifest.format not in SUPPORTED_FORMATS:
        raise ValidationError(
            f"unsupported format '{manifest.format}', expected one of: {', '.join(sorted(SUPPORTED_FORMATS))}",
            effective_path,
            field="format",
        )

    for index, model_path in enumerate(manifest.models):
        model = Path(model_path)
        if model.is_absolute():
            raise ValidationError(
                "model path must be relative",
                effective_path,
                field=f"models[{index}]",
            )
        if ".." in model.parts:
            raise ValidationError(
                "model path must not contain '..'",
                effective_path,
                field=f"models[{index}]",
            )

        resolved = (base_dir / model).resolve()
        base_resolved = base_dir.resolve()
        try:
            resolved.relative_to(base_resolved)
        except ValueError as exc:
            raise ValidationError(
                "model path escapes package directory",
                effective_path,
                field=f"models[{index}]",
            ) from exc
        if not resolved.is_file():
            raise ValidationError(
                "model file not found",
                effective_path,
                field=f"models[{index}]",
            )
