from __future__ import annotations

from dataclasses import dataclass
import gzip
import hashlib
import io
from pathlib import Path
import tarfile

from rawctx.formats.osi import validate_osi
from rawctx.packaging.manifest import Manifest, ValidationError, load_manifest, validate_manifest


@dataclass(frozen=True)
class BuildResult:
    archive_path: Path
    included_files: list[str]


def _safe_package_name(package_name: str) -> str:
    normalized = package_name.lstrip("@").replace("/", "__")
    return normalized


def _read_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as exc:
        raise ValidationError("failed to read file for packaging", path) from exc


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _add_bytes(tar: tarfile.TarFile, arcname: str, data: bytes) -> None:
    info = tarfile.TarInfo(name=arcname)
    info.size = len(data)
    info.mtime = 0
    info.mode = 0o644
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    tar.addfile(info, io.BytesIO(data))


def _collect_files(target_dir: Path, manifest: Manifest) -> list[tuple[str, Path]]:
    files: list[tuple[str, Path]] = []
    files.append(("package/rawctx.yaml", target_dir / "rawctx.yaml"))

    readme_path = target_dir / "README.md"
    if readme_path.exists():
        files.append(("package/README.md", readme_path))

    for model in manifest.models:
        model_path = target_dir / model
        files.append((f"package/{model}", model_path))

    return sorted(files, key=lambda item: item[0])


def build_package_archive(
    target_dir: Path,
    output_dir: Path,
    manifest: Manifest | None = None,
) -> BuildResult:
    package_dir = target_dir.resolve()
    if not package_dir.is_dir():
        raise ValidationError("pack target must be a directory", package_dir)

    manifest_path = package_dir / "rawctx.yaml"
    manifest_obj = manifest if manifest is not None else load_manifest(manifest_path)
    validate_manifest(manifest_obj, package_dir, manifest_path=manifest_path)

    for model in manifest_obj.models:
        validate_osi(package_dir / model)

    output_dir.mkdir(parents=True, exist_ok=True)
    archive_name = f"{_safe_package_name(manifest_obj.name)}-{manifest_obj.version}.rawctx.tar.gz"
    archive_path = output_dir / archive_name

    files = _collect_files(package_dir, manifest_obj)
    checksums: list[str] = []
    file_payloads: list[tuple[str, bytes]] = []
    for arcname, file_path in files:
        content = _read_bytes(file_path)
        file_payloads.append((arcname, content))
        checksums.append(f"{_sha256(content)}  {arcname}")

    checksums_content = ("\n".join(checksums) + "\n").encode("utf-8")

    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.PAX_FORMAT) as tar:
        for arcname, content in file_payloads:
            _add_bytes(tar, arcname, content)
        _add_bytes(tar, "package/checksums.sha256", checksums_content)

    tar_bytes = tar_buffer.getvalue()
    with archive_path.open("wb") as handle:
        with gzip.GzipFile(filename="", mode="wb", fileobj=handle, mtime=0) as gz:
            gz.write(tar_bytes)

    included = [arcname for arcname, _ in file_payloads]
    included.append("package/checksums.sha256")
    return BuildResult(archive_path=archive_path, included_files=included)
