from __future__ import annotations

import base64
import json
import time
import webbrowser

from rawctx.config import ConfigStore, RawctxConfig
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import ApiTokenInfo, OAuthLoginInfo


def start_oauth_login(*, client: RegistryClient, open_browser: bool) -> OAuthLoginInfo:
    login_info = client.oauth_login_github()
    if open_browser:
        webbrowser.open(login_info.authorize_url)
    return login_info


def wait_for_oauth_id_token(
    *,
    client: RegistryClient,
    session_id: str,
    timeout_seconds: int = 300,
    poll_interval_seconds: int = 2,
) -> str:
    deadline = time.monotonic() + timeout_seconds
    poll_interval = max(1, poll_interval_seconds)

    while True:
        if time.monotonic() >= deadline:
            raise RegistryError("Timed out waiting for OAuth login completion. Retry `rawctx login`.")

        try:
            session = client.oauth_login_session(session_id)
        except RegistryError as exc:
            if exc.status_code == 404:
                raise RegistryError("OAuth login session expired. Retry `rawctx login`.") from exc
            raise

        status = session.status.strip().lower()
        if status == "ready":
            if session.id_token:
                return session.id_token
            raise RegistryError("OAuth login completed but id_token is missing.")

        if status == "error":
            reason = session.error_description or session.error or "OAuth login failed"
            raise RegistryError(f"OAuth login failed: {reason}")

        time.sleep(poll_interval)


def login_with_id_token(
    *,
    client: RegistryClient,
    store: ConfigStore,
    config: RawctxConfig,
    id_token: str,
    token_name: str,
    expires_in_days: int | None,
) -> ApiTokenInfo:
    token_info = client.create_api_token(id_token=id_token, name=token_name, expires_in_days=expires_in_days)
    username = extract_username_from_jwt(id_token)
    store.save_auth(
        config=config,
        token=token_info.token,
        token_id=token_info.id,
        token_name=token_info.name,
        username=username,
    )
    return token_info


def logout_auth(
    *,
    client: RegistryClient | None,
    store: ConfigStore,
    config: RawctxConfig,
    local_only: bool,
) -> tuple[bool, bool]:
    had_token = bool(config.auth.token)
    revoked = False

    if not local_only and had_token and client is not None and config.auth.token_id:
        revoked = client.revoke_api_token(config.auth.token_id)

    if had_token:
        store.clear_auth(config)
    return had_token, revoked


def extract_username_from_jwt(token: str) -> str | None:
    parts = token.split(".")
    if len(parts) < 2:
        return None

    payload_segment = parts[1]
    padding = "=" * (-len(payload_segment) % 4)

    try:
        decoded = base64.urlsafe_b64decode(payload_segment + padding)
        payload = json.loads(decoded.decode("utf-8"))
    except (ValueError, json.JSONDecodeError):
        return None

    if not isinstance(payload, dict):
        return None

    for key in ("preferred_username", "cognito:username", "username"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    email = payload.get("email")
    if isinstance(email, str) and "@" in email:
        local = email.split("@", 1)[0].strip()
        if local:
            return local

    return None
