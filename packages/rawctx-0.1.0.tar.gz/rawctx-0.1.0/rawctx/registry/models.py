from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Iterable


_SCOPE_RE = r"[a-z0-9][a-z0-9-]{0,49}"
_NAME_RE = r"[a-z0-9][a-z0-9-]{0,99}"
_SEMVER_RE = r"(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)"
_PACKAGE_REF_RE = re.compile(rf"^@(?P<scope>{_SCOPE_RE})/(?P<name>{_NAME_RE})(?:@(?P<version>{_SEMVER_RE}))?$")
_SEMVER_STRICT_RE = re.compile(rf"^{_SEMVER_RE}$")


@dataclass(frozen=True)
class PackageRef:
    scope: str
    name: str
    version: str | None = None

    @property
    def package_name(self) -> str:
        return f"@{self.scope}/{self.name}"

    @property
    def normalized(self) -> str:
        if self.version:
            return f"{self.package_name}@{self.version}"
        return self.package_name

    @classmethod
    def parse(cls, raw: str) -> "PackageRef":
        value = raw.strip()
        match = _PACKAGE_REF_RE.fullmatch(value)
        if not match:
            raise ValueError("package reference must be @scope/name or @scope/name@X.Y.Z")
        return cls(scope=match.group("scope"), name=match.group("name"), version=match.group("version"))


@dataclass(frozen=True)
class SearchItem:
    id: str
    scope: str
    name: str
    description: str | None
    format: str
    source: str | None
    domain: str | None
    tags: list[str]
    download_count: int
    star_count: int

    @property
    def package_name(self) -> str:
        return f"@{self.scope}/{self.name}"

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "SearchItem":
        return cls(
            id=str(data.get("id")),
            scope=str(data.get("scope")),
            name=str(data.get("name")),
            description=_optional_str(data.get("description")),
            format=str(data.get("format") or "unknown"),
            source=_optional_str(data.get("source")),
            domain=_optional_str(data.get("domain")),
            tags=_as_str_list(data.get("tags")),
            download_count=int(data.get("download_count") or 0),
            star_count=int(data.get("star_count") or 0),
        )


@dataclass(frozen=True)
class VersionInfo:
    id: str
    version: str
    status: str
    search_index_status: str
    file_size: int | None
    checksum_sha256: str | None
    model_summary: dict[str, Any] | None
    created_at: str | None
    published_at: str | None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "VersionInfo":
        return cls(
            id=str(data.get("id")),
            version=str(data.get("version")),
            status=str(data.get("status") or "unknown"),
            search_index_status=str(data.get("search_index_status") or "unknown"),
            file_size=int(data["file_size"]) if data.get("file_size") is not None else None,
            checksum_sha256=_optional_str(data.get("checksum_sha256")),
            model_summary=data.get("model_summary") if isinstance(data.get("model_summary"), dict) else None,
            created_at=_optional_str(data.get("created_at")),
            published_at=_optional_str(data.get("published_at")),
        )


@dataclass(frozen=True)
class PackageDetail:
    id: str
    scope: str
    name: str
    description: str | None
    format: str
    source: str | None
    domain: str | None
    license: str | None
    repository_url: str | None
    readme: str | None
    tags: list[str]
    is_private: bool
    download_count: int
    star_count: int
    owner: dict[str, Any] | None

    @property
    def package_name(self) -> str:
        return f"@{self.scope}/{self.name}"

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "PackageDetail":
        owner = data.get("owner") if isinstance(data.get("owner"), dict) else None
        return cls(
            id=str(data.get("id")),
            scope=str(data.get("scope")),
            name=str(data.get("name")),
            description=_optional_str(data.get("description")),
            format=str(data.get("format") or "unknown"),
            source=_optional_str(data.get("source")),
            domain=_optional_str(data.get("domain")),
            license=_optional_str(data.get("license")),
            repository_url=_optional_str(data.get("repository_url")),
            readme=_optional_str(data.get("readme")),
            tags=_as_str_list(data.get("tags")),
            is_private=bool(data.get("is_private", False)),
            download_count=int(data.get("download_count") or 0),
            star_count=int(data.get("star_count") or 0),
            owner=owner,
        )


@dataclass(frozen=True)
class ApiTokenInfo:
    id: str
    name: str
    token: str
    prefix: str
    created_at: str
    expires_at: str | None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "ApiTokenInfo":
        return cls(
            id=str(data.get("id")),
            name=str(data.get("name") or ""),
            token=str(data.get("token") or ""),
            prefix=str(data.get("prefix") or ""),
            created_at=str(data.get("created_at") or ""),
            expires_at=_optional_str(data.get("expires_at")),
        )


@dataclass(frozen=True)
class OAuthLoginInfo:
    authorize_url: str
    state: str
    session_id: str | None = None
    poll_interval_seconds: int = 2

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "OAuthLoginInfo":
        poll_interval = 2
        poll_interval_raw = data.get("poll_interval_seconds")
        if isinstance(poll_interval_raw, int):
            poll_interval = poll_interval_raw
        elif isinstance(poll_interval_raw, str) and poll_interval_raw.strip():
            try:
                poll_interval = int(poll_interval_raw.strip())
            except ValueError:
                poll_interval = 2
        if poll_interval < 1:
            poll_interval = 1
        return cls(
            authorize_url=str(data.get("authorize_url") or ""),
            state=str(data.get("state") or ""),
            session_id=_optional_str(data.get("session_id")),
            poll_interval_seconds=poll_interval,
        )


@dataclass(frozen=True)
class OAuthSessionInfo:
    session_id: str
    status: str
    id_token: str | None = None
    error: str | None = None
    error_description: str | None = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "OAuthSessionInfo":
        return cls(
            session_id=str(data.get("session_id") or ""),
            status=str(data.get("status") or "pending"),
            id_token=_optional_str(data.get("id_token")),
            error=_optional_str(data.get("error")),
            error_description=_optional_str(data.get("error_description")),
        )


def parse_package_ref(raw: str) -> PackageRef:
    return PackageRef.parse(raw)


def is_valid_semver(version: str) -> bool:
    return _SEMVER_STRICT_RE.fullmatch(version) is not None


def choose_latest_version(versions: Iterable[str]) -> str | None:
    valid_versions = [version for version in versions if is_valid_semver(version)]
    if not valid_versions:
        return None
    return max(valid_versions, key=semver_key)


def semver_key(version: str) -> tuple[int, int, int]:
    if not is_valid_semver(version):
        raise ValueError(f"invalid semver: {version}")
    major, minor, patch = version.split(".", 2)
    return int(major), int(minor), int(patch)


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def _as_str_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    out: list[str] = []
    for item in value:
        if isinstance(item, str) and item.strip():
            out.append(item.strip())
    return out
