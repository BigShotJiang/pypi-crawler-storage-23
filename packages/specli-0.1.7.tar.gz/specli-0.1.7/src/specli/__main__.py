"""Allow running as `python -m specli`."""

from specli.app import main

if __name__ == "__main__":
    main()
