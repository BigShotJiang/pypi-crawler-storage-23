"""Example specli plugin."""
