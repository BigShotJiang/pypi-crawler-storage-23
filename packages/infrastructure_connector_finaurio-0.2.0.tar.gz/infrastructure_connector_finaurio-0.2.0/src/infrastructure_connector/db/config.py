import os
from typing import Optional
from psycopg2 import pool
from dotenv import load_dotenv

load_dotenv()

class DatabaseConfig:
    """PostgreSQL database configuration and connection management."""

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        database: Optional[str] = None,
    ):
        """Initialize database configuration from parameters or environment variables.

        Args:
            host: Database host (uses DB_HOST from .env if not provided)
            port: Database port (uses DB_PORT from .env if not provided)
            user: Database user (uses DB_USER from .env if not provided)
            password: Database password (uses DB_PASSWORD from .env if not provided)
            database: Database name (uses DB_NAME from .env if not provided)

        Raises:
            ValueError: If any required environment variable is missing in .env
        """
        self.host = host or os.getenv("DB_HOST")
        db_port_str = os.getenv("DB_PORT")
        self.port = port or (int(db_port_str) if db_port_str else None)
        self.user = user or os.getenv("DB_USER")
        self.password = password or os.getenv("DB_PASSWORD")
        self.database = database or os.getenv("DB_NAME")

        self._validate_configuration()

    def _validate_configuration(self) -> None:
        """Validate that all required configuration values are set.

        Raises:
            ValueError: If any required configuration value is missing
        """
        missing_vars = []
        if not self.host:
            missing_vars.append("DB_HOST")
        if not self.port:
            missing_vars.append("DB_PORT")
        if not self.user:
            missing_vars.append("DB_USER")
        if self.password is None:
            missing_vars.append("DB_PASSWORD")
        if not self.database:
            missing_vars.append("DB_NAME")

        if missing_vars:
            raise ValueError(
                f"Missing required environment variables in .env file: {', '.join(missing_vars)}"
            )

    def get_connection_string(self) -> str:
        """Get the PostgreSQL connection string."""
        return (
            f"postgresql://{self.user}:{self.password}@{self.host}:"
            f"{self.port}/{self.database}"
        )

    def get_dsn(self) -> dict:
        """Get connection parameters as a dictionary (DSN format)."""
        return {
            "host": self.host,
            "port": self.port,
            "user": self.user,
            "password": self.password,
            "database": self.database,
        }


class DatabaseConnection:
    """Manages psycopg2 database connections with connection pooling."""

    _pool: Optional[pool.SimpleConnectionPool] = None
    _config: Optional[DatabaseConfig] = None

    @classmethod
    def initialize(
        cls,
        config: Optional[DatabaseConfig] = None,
        min_connections: int = 1,
        max_connections: int = 10,
    ) -> None:
        """Initialize the connection pool."""
        cls._config = config or DatabaseConfig()
        dsn = cls._config.get_dsn()

        try:
            cls._pool = pool.SimpleConnectionPool(
                min_connections,
                max_connections,
                **dsn,
            )
        except Exception as e:
            print(f"Failed to initialize connection pool: {e}")
            raise e

    @classmethod
    def get_connection(cls):
        """Get a connection from the pool."""
        if cls._pool is None:
            cls.initialize()
        if cls._pool is None:
            raise RuntimeError("Failed to initialize database connection pool")
        return cls._pool.getconn()

    @classmethod
    def return_connection(cls, conn) -> None:
        """Return a connection to the pool."""
        if cls._pool is not None:
            cls._pool.putconn(conn)

    @classmethod
    def close_all_connections(cls) -> None:
        """Close all connections in the pool."""
        if cls._pool is not None:
            cls._pool.closeall()

    @classmethod
    def execute_query(cls, query: str, params: Optional[tuple] = None) -> list:
        """Execute a SELECT query and return results."""
        conn = cls.get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(query, params or ())
            results = cursor.fetchall()
            cursor.close()
            return results
        finally:
            cls.return_connection(conn)

    @classmethod
    def execute_update(cls, query: str, params: Optional[tuple] = None) -> int:
        """Execute an INSERT, UPDATE, or DELETE query. Returns number of affected rows."""
        conn = cls.get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(query, params or ())
            affected_rows = cursor.rowcount
            conn.commit()
            cursor.close()
            return affected_rows
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            cls.return_connection(conn)

    @classmethod
    def test_connection(cls) -> bool:
        """Test the database connection."""
        try:
            conn = cls.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            cls.return_connection(conn)
            return True
        except Exception as e:
            print(f"Connection test failed: {e}")
            return False
