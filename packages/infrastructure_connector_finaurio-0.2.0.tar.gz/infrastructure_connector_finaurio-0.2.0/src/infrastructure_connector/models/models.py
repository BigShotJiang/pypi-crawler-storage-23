"""Database models reflected from PostgreSQL schema."""

from sqlalchemy import (
    Integer, String, Numeric, Boolean, 
    Text, Time, JSON, func
)
from datetime import datetime
from decimal import Decimal

from sqlalchemy.orm import declarative_base,Mapped,mapped_column
from sqlalchemy.sql import func

# Single Base instance used throughout the application
Base = declarative_base()

class SchemaVersion(Base):
    __tablename__ = "schema_version"
    version: Mapped[str] = mapped_column(primary_key=True)

    applied_at: Mapped[datetime] = mapped_column(
        server_default=func.now()
    )

class Agents(Base):
    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    type: Mapped[str] = mapped_column(String)


class AgentsSources(Base):
    __tablename__ = "agents_sources"

    agent_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    news_source_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    reliability_score: Mapped[Decimal] = mapped_column(Numeric)


class AlembicVersion(Base):
    __tablename__ = "alembic_version"

    version_num: Mapped[str] = mapped_column(String(32), primary_key=True, nullable=False)


class Alerts(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String(9))


class AnalysisArtifacts(Base):
    __tablename__ = "analysis_artifacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, nullable=False)
    artifact_type: Mapped[str] = mapped_column(String(8))
    uri: Mapped[str] = mapped_column(String)
    checksum: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(Time)


class AnalysisAssets(Base):
    __tablename__ = "analysis_assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, nullable=False)
    bias: Mapped[str] = mapped_column(String(7))
    expected_move_pct: Mapped[Decimal] = mapped_column(Numeric)
    expected_price_low: Mapped[Decimal] = mapped_column(Numeric)
    expected_price_high: Mapped[Decimal] = mapped_column(Numeric)
    expected_volatility: Mapped[Decimal] = mapped_column(Numeric)
    confidence_level: Mapped[Decimal] = mapped_column(Numeric)
    score: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)


class AnalysisHistory(Base):
    __tablename__ = "analysis_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)


class AnalysisIndicators(Base):
    __tablename__ = "analysis_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, nullable=False)
    indicator_id: Mapped[int] = mapped_column(Integer, nullable=False)
    raw_value: Mapped[Decimal] = mapped_column(Numeric)
    normalized_value: Mapped[Decimal] = mapped_column(Numeric)
    score: Mapped[Decimal] = mapped_column(Numeric)
    weight: Mapped[Decimal] = mapped_column(Numeric)
    signal: Mapped[str] = mapped_column(String(8))
    created_at: Mapped[datetime] = mapped_column(Time)


class AnalysisNewsSources(Base):
    __tablename__ = "analysis_news_sources"

    analysis_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    source_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)


class AssetSpecificExposures(Base):
    __tablename__ = "asset_specific_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, nullable=False)
    exposure: Mapped[Decimal] = mapped_column(Numeric)
    override: Mapped[bool] = mapped_column(Boolean)
    created_at: Mapped[datetime] = mapped_column(Time)
    updated_at: Mapped[datetime] = mapped_column(Time)


class Assets(Base):
    __tablename__ = "assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    symbol: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)
    asset_class: Mapped[str] = mapped_column(String(11))
    asset_subclass: Mapped[str] = mapped_column(String(8))
    currency: Mapped[str] = mapped_column(String)
    base_currency: Mapped[str] = mapped_column(String)
    quote_currency: Mapped[str] = mapped_column(String)
    lot_unit: Mapped[Decimal] = mapped_column(Numeric)
    price_tick: Mapped[Decimal] = mapped_column(Numeric)
    quantity_step: Mapped[Decimal] = mapped_column(Numeric)
    liquidity_profile: Mapped[str] = mapped_column(String(9))
    volatility_profile: Mapped[str] = mapped_column(String(6))
    trading_hours: Mapped[str] = mapped_column(String)
    market: Mapped[str] = mapped_column(String(3))


class AssetsAlerts(Base):
    __tablename__ = "assets_alerts"

    alert_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_price: Mapped[Decimal] = mapped_column(Numeric)


class BehavioralStats(Base):
    __tablename__ = "behavioral_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, nullable=False)
    trade_frequency: Mapped[Decimal] = mapped_column(Numeric)
    overtrading_score: Mapped[Decimal] = mapped_column(Numeric)
    avg_holding_time: Mapped[Decimal] = mapped_column(Numeric)
    deviation_from_expected_horizon: Mapped[Decimal] = mapped_column(Numeric)
    revenge_trading_score: Mapped[Decimal] = mapped_column(Numeric)
    consistency_score: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)


class EconomicCalendar(Base):
    __tablename__ = "economic_calendar"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    fundamental_indicator_id: Mapped[int] = mapped_column(Integer, nullable=False)
    previous_value: Mapped[Decimal] = mapped_column(Numeric)
    forecast_value: Mapped[Decimal] = mapped_column(Numeric)
    actual_value: Mapped[Decimal] = mapped_column(Numeric)
    event_name: Mapped[str] = mapped_column(String)
    country: Mapped[str] = mapped_column(String)
    impact_level: Mapped[str] = mapped_column(String)
    event_date: Mapped[datetime] = mapped_column(Time)


class ExecutionStats(Base):
    __tablename__ = "execution_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, nullable=False)
    avg_slippage: Mapped[Decimal] = mapped_column(Numeric)
    avg_fees: Mapped[Decimal] = mapped_column(Numeric)
    slippage_ratio: Mapped[Decimal] = mapped_column(Numeric)
    fill_rate: Mapped[Decimal] = mapped_column(Numeric)
    avg_time_to_execution: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)


class FundamentalIndicators(Base):
    __tablename__ = "fundamental_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    code: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String)
    sub_category: Mapped[str] = mapped_column(String)
    unit: Mapped[str] = mapped_column(String)
    value_type: Mapped[str] = mapped_column(String(6))
    directionality: Mapped[str] = mapped_column(String(5))
    typical_frequency: Mapped[str] = mapped_column(String(9))
    leading_status: Mapped[str] = mapped_column(String(7))
    created_at: Mapped[datetime] = mapped_column(Time)


class GeneratedAnalyses(Base):
    __tablename__ = "generated_analyses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, nullable=False)
    agent_id: Mapped[int] = mapped_column(Integer, nullable=False)
    analysis_type: Mapped[str] = mapped_column(String(8))
    time_horizon: Mapped[str] = mapped_column(String(8))
    global_score: Mapped[Decimal] = mapped_column(Numeric)
    confidence_level: Mapped[Decimal] = mapped_column(Numeric)
    bias: Mapped[str] = mapped_column(String(7))
    valid_from: Mapped[datetime] = mapped_column(Time)
    valid_until: Mapped[datetime] = mapped_column(Time)
    created_at: Mapped[datetime] = mapped_column(Time)


class IndicatorScores(Base):
    __tablename__ = "indicator_scores"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(Integer, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, nullable=False)
    publication_id: Mapped[int] = mapped_column(Integer, nullable=False)
    country_code: Mapped[str] = mapped_column(String)
    score_naive: Mapped[int] = mapped_column(Integer)
    score_weighted: Mapped[Decimal] = mapped_column(Numeric)
    signal_direction: Mapped[str] = mapped_column(String(5))
    created_at: Mapped[datetime] = mapped_column(Time)


class IndicatorScoresRules(Base):
    __tablename__ = "indicator_scores_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(Integer, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, nullable=False)
    score_naive: Mapped[int] = mapped_column(Integer)
    threshold_low: Mapped[Decimal] = mapped_column(Numeric)
    threshold_high: Mapped[Decimal] = mapped_column(Numeric)
    weight: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)
    updated_at: Mapped[datetime] = mapped_column(Time)


class MacroAssetClassExposures(Base):
    __tablename__ = "macro_asset_class_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, nullable=False)
    asset_class: Mapped[str] = mapped_column(String(11))
    default_exposure: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)
    updated_at: Mapped[datetime] = mapped_column(Time)


class MacroRegimes(Base):
    __tablename__ = "macro_regimes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    growth_trend: Mapped[str] = mapped_column(String(9))
    inflation_trend: Mapped[str] = mapped_column(String(7))
    monetary_policy: Mapped[str] = mapped_column(String(10))
    risk_appetite: Mapped[str] = mapped_column(String(8))
    expected_volatility: Mapped[str] = mapped_column(String(6))
    liquidity_level: Mapped[str] = mapped_column(String(6))
    confidence_score: Mapped[Decimal] = mapped_column(Numeric)
    valid_from: Mapped[datetime] = mapped_column(Time)
    valid_to: Mapped[datetime] = mapped_column(Time)


class NewsSources(Base):
    __tablename__ = "news_sources"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    category: Mapped[str] = mapped_column(String)
    country_code: Mapped[str] = mapped_column(String(3))


class ObjectiveHistory(Base):
    __tablename__ = "objective_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    objective_id: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)


class Objectives(Base):
    __tablename__ = "objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String)
    target_return: Mapped[Decimal] = mapped_column(Numeric)
    max_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    asset_class: Mapped[str] = mapped_column(String(11))
    exposure: Mapped[Decimal] = mapped_column(Numeric)
    time_horizon: Mapped[str] = mapped_column(String(8))
    priority: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(22))
    created_at: Mapped[datetime] = mapped_column(Time)


class OperationHistory(Base):
    __tablename__ = "operation_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    operation_id: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)


class Operations(Base):
    __tablename__ = "operations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer)
    opportunity_id: Mapped[int] = mapped_column(Integer)
    direction: Mapped[str] = mapped_column(String(5))
    operation_type: Mapped[str] = mapped_column(String(13))
    time_horizon: Mapped[str] = mapped_column(String(8))
    quantity: Mapped[Decimal] = mapped_column(Numeric)
    price: Mapped[Decimal] = mapped_column(Numeric)
    notional: Mapped[Decimal] = mapped_column(Numeric)
    stop_loss: Mapped[Decimal] = mapped_column(Numeric)
    take_profit: Mapped[Decimal] = mapped_column(Numeric)
    fees: Mapped[Decimal] = mapped_column(Numeric)
    slippage: Mapped[Decimal] = mapped_column(Numeric)
    status: Mapped[str] = mapped_column(String(8))
    executed_at: Mapped[datetime] = mapped_column(Time)
    created_at: Mapped[datetime] = mapped_column(Time)


class Opportunities(Base):
    __tablename__ = "opportunities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, nullable=False)
    direction: Mapped[str] = mapped_column(String(5))
    confidence_score: Mapped[Decimal] = mapped_column(Numeric)
    entry_price: Mapped[Decimal] = mapped_column(Numeric)
    stop_loss: Mapped[Decimal] = mapped_column(Numeric)
    take_profit: Mapped[Decimal] = mapped_column(Numeric)
    expected_return: Mapped[Decimal] = mapped_column(Numeric)
    risk_reward_ratio: Mapped[Decimal] = mapped_column(Numeric)
    status: Mapped[str] = mapped_column(String(9))
    valid_from: Mapped[datetime] = mapped_column(Time)
    valid_until: Mapped[datetime] = mapped_column(Time)
    detected_at: Mapped[datetime] = mapped_column(Time)
    closed_at: Mapped[datetime] = mapped_column(Time)


class OpportunityHistory(Base):
    __tablename__ = "opportunity_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    opportunity_id: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)


class PerformanceReturns(Base):
    __tablename__ = "performance_returns"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, nullable=False)
    period: Mapped[str] = mapped_column(String(8))
    total_return: Mapped[Decimal] = mapped_column(Numeric)
    win_rate: Mapped[Decimal] = mapped_column(Numeric)
    avg_win: Mapped[Decimal] = mapped_column(Numeric)
    avg_loss: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)


class PerformanceRisk(Base):
    __tablename__ = "performance_risk"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, nullable=False)
    volatility: Mapped[Decimal] = mapped_column(Numeric)
    max_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    avg_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    drawdown_duration: Mapped[int] = mapped_column(Integer)
    sharpe_ratio: Mapped[Decimal] = mapped_column(Numeric)
    sortino_ratio: Mapped[Decimal] = mapped_column(Numeric)
    calmar_ratio: Mapped[Decimal] = mapped_column(Numeric)
    tail_risk: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)


class PortfolioHistory(Base):
    __tablename__ = "portfolio_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)


class Portfolios(Base):
    __tablename__ = "portfolios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    base_currency: Mapped[str] = mapped_column(String)
    initial_capital: Mapped[Decimal] = mapped_column(Numeric)
    current_capital: Mapped[Decimal] = mapped_column(Numeric)
    risk_profile: Mapped[str] = mapped_column(String)
    benchmark: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(Time)
    updated_at: Mapped[datetime] = mapped_column(Time)


class PriceHistory(Base):
    __tablename__ = "price_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer)
    high: Mapped[Decimal] = mapped_column(Numeric)
    low: Mapped[Decimal] = mapped_column(Numeric)
    open: Mapped[Decimal] = mapped_column(Numeric)
    close: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time)
    time_unit: Mapped[str] = mapped_column(String)


class PublicationAlerts(Base):
    __tablename__ = "publication_alerts"

    alert_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    publication_id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    estimated_date: Mapped[datetime] = mapped_column(Time)


class Strategies(Base):
    __tablename__ = "strategies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    asset_class: Mapped[str] = mapped_column(String(11))
    strategy_type: Mapped[str] = mapped_column(String(13))
    creator_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(Time)
    max_position_size: Mapped[Decimal] = mapped_column(Numeric)
    expected_return: Mapped[Decimal] = mapped_column(Numeric)
    risk_estimate: Mapped[Decimal] = mapped_column(Numeric)
    leverage: Mapped[Decimal] = mapped_column(Numeric)


class StrategyHistory(Base):
    __tablename__ = "strategy_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)


class StrategyObjectives(Base):
    __tablename__ = "strategy_objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer, nullable=False)
    objective_id: Mapped[int] = mapped_column(Integer, nullable=False)
    correlation_ratio: Mapped[Decimal] = mapped_column(Numeric)


class Users(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False)
    password_hash: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(Time)

