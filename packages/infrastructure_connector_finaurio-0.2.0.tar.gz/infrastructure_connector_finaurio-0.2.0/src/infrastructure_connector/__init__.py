# src/infrastructure_connector/_connector.py
from .db.sqlalchemy_setup import (
    bootstrap_database,
    initialize_engine,
    get_engine,
    get_session,
    get_metadata,
    reflect_database,
    create_all_tables,
)
from .db.session_manager import get_db_session
from .db.schema_management import initialize_schema_version, verify_schema_compatibility
from .db.config import DatabaseConfig, DatabaseConnection
from .models import *  # expose toutes les classes
from ._connector import *
bootstrap_database()

__version__ = "0.1.2"
__schema_version__ = __version__

__all__ = [
    # DB functions
    "bootstrap_database",
    "initialize_engine",
    "get_engine",
    "get_session",
    "get_metadata",
    "reflect_database",
    "create_all_tables",
    "get_db_session",
    "DatabaseConfig",
    "DatabaseConnection",
    "initialize_schema_version",
    "verify_schema_compatibility",

    # Models (via models/__init__.py)
    "Base",
    "SchemaVersion",
    "Agents",
    "AgentsSources",
    "AlembicVersion",
    "Alerts",
    "AnalysisArtifacts",
    "AnalysisAssets",
    "AnalysisHistory",
    "AnalysisIndicators",
    "AnalysisNewsSources",
    "AssetSpecificExposures",
    "Assets",
    "AssetsAlerts",
    "BehavioralStats",
    "EconomicCalendar",
    "ExecutionStats",
    "FundamentalIndicators",
    "GeneratedAnalyses",
    "IndicatorScores",
    "IndicatorScoresRules",
    "MacroAssetClassExposures",
    "MacroRegimes",
    "NewsSources",
    "ObjectiveHistory",
    "Objectives",
    "OperationHistory",
    "Operations",
    "Opportunities",
    "OpportunityHistory",
    "PerformanceReturns",
    "PerformanceRisk",
    "PortfolioHistory",
    "Portfolios",
    "PriceHistory",
    "PublicationAlerts",
    "Strategies",
    "StrategyHistory",
    "StrategyObjectives",
    "Users",
]