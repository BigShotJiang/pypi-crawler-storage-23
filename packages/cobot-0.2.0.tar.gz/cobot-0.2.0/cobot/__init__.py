"""Cobot - Minimal self-sovereign AI agent.

A ~1000 LOC agent with:
- Nostr communication (NIP-04 encrypted DMs)
- Lightning wallet (npub.cash/Cashu)
- Plugin-based extensibility
- Tool execution (read/write/edit/exec/wallet)
"""

__version__ = "0.2.0"
