"""Soul plugin - reads SOUL.md from workspace for persona/tone."""

from .plugin import SoulPlugin, create_plugin

__all__ = ["SoulPlugin", "create_plugin"]
