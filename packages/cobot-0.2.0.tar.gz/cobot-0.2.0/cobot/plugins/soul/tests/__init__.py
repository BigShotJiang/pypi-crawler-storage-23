"""Tests for soul plugin."""
