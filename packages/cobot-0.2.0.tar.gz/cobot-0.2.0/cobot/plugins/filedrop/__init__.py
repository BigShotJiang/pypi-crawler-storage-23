"""FileDrop communication plugin."""

from .plugin import FileDropPlugin, create_plugin

__all__ = ["FileDropPlugin", "create_plugin"]
