"""Tests for config plugin."""
