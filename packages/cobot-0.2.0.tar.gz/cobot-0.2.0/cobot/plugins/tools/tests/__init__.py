"""Tests for tools plugin."""
