"""Tests for communication plugin."""
