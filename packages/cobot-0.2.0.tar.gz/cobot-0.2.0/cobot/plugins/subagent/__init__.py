"""Subagent plugin - spawn isolated sessions for delegated work."""

from .plugin import SubagentPlugin, SubagentProvider, SubagentResult, create_plugin

__all__ = ["SubagentPlugin", "SubagentProvider", "SubagentResult", "create_plugin"]
