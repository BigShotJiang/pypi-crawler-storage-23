"""Tests for the web plugin."""
