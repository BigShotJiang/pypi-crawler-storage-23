"""Tests for memory-files plugin."""
