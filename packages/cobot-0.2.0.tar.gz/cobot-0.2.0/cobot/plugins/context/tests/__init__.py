"""Tests for context plugin."""
