"""Tests for PPQ LLM plugin."""
