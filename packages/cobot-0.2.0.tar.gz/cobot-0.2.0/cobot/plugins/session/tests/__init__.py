"""Tests for session plugin."""
