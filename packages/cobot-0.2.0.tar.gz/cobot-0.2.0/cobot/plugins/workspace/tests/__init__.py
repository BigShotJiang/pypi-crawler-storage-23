"""Tests for workspace plugin."""
