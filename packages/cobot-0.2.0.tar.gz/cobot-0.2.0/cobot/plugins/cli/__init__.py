"""CLI plugin - extension point for CLI command registration."""

from .plugin import CLIPlugin

__all__ = ["CLIPlugin"]
