"""Tests for memory plugin."""
