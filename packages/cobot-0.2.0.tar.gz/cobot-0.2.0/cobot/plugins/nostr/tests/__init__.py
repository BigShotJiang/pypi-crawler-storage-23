"""Tests for Nostr communication plugin."""
