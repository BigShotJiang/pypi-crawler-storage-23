"""Trust context plugin — trusted/untrusted message distinction."""
