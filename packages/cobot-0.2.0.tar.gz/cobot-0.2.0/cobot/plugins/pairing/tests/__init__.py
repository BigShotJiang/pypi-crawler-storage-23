"""Tests for pairing plugin."""
