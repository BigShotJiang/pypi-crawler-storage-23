"""Pairing plugin - user authorization via pairing codes."""

# Don't import from plugin.py here - causes circular import
# Plugin loader uses create_plugin() directly from plugin.py
