"""Knowledge plugin - local vector search and long-term memory."""

# Don't import from plugin.py here - causes circular import
# Plugin loader uses create_plugin() directly from plugin.py
