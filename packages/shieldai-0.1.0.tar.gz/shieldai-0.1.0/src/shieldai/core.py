def hello() -> str:
    return "hello from shieldai"