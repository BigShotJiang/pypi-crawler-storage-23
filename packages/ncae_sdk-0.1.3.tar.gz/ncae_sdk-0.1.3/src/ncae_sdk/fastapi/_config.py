from __future__ import annotations

from functools import lru_cache

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def optional_prefix(name: str) -> AliasChoices:
    return AliasChoices(f"extapi_{name}", name)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="EXTAPI_",
        extra="ignore",
    )

    debug: bool = False

    # The following fields are preferably set with the "EXTAPI_" prefix, but can also be set without it for convenience.
    # This is especially useful as various older deployments tend to use the non-prefixed environment variables.
    ncae_base_url: str = Field(validation_alias=optional_prefix("ncae_base_url"))
    ncae_username: str = Field(validation_alias=optional_prefix("ncae_username"))
    ncae_password: str = Field(validation_alias=optional_prefix("ncae_password"))
    ncae_verify_tls: bool = Field(default=False, validation_alias=optional_prefix("ncae_verify_tls"))


@lru_cache
def get_settings() -> Settings:
    return Settings()
