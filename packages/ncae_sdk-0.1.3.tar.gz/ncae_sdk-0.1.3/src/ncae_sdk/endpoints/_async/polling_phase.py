from collections.abc import AsyncIterator
from typing import Final, Optional

from typing_extensions import Unpack

from ncae_sdk._async.endpoint import AsyncEndpoint
from ncae_sdk._resource import ResourceId
from ncae_sdk._util import map_async
from ncae_sdk.resources._schema import (
    PollingPhase,
    PollingPhaseCreate,
    PollingPhaseCreateModel,
    PollingPhaseFilter,
    PollingPhaseFilterModel,
    PollingPhaseUpdate,
    PollingPhaseUpdateModel,
)


class AsyncPollingPhaseEndpoint(AsyncEndpoint):
    BASE_PATH: Final[str] = "automation/v1/phase/polling-phase"

    async def list(self, **filters: Unpack[PollingPhaseFilter]) -> AsyncIterator[PollingPhase]:
        results = self._list(self.BASE_PATH, PollingPhaseFilterModel, filters)
        return map_async(PollingPhase.parse_api, results)

    async def find(self, **filters: Unpack[PollingPhaseFilter]) -> Optional[PollingPhase]:
        result = await self._get_by_filters(self.BASE_PATH, PollingPhaseFilterModel, filters)
        return PollingPhase.parse_api(result) if result else None

    async def get(self, rid: ResourceId) -> Optional[PollingPhase]:
        result = await self._get_by_id(self.BASE_PATH, rid)
        return PollingPhase.parse_api(result) if result else None

    async def create(self, **payload: Unpack[PollingPhaseCreate]) -> PollingPhase:
        result = await self._create(self.BASE_PATH, PollingPhaseCreateModel, payload)
        return PollingPhase.parse_api(result)

    async def update(self, rid: ResourceId, /, **payload: Unpack[PollingPhaseUpdate]) -> PollingPhase:
        result = await self._update(self.BASE_PATH, rid, PollingPhaseUpdateModel, payload)
        return PollingPhase.parse_api(result)

    async def delete(self, rid: ResourceId) -> bool:
        return await self._delete(self.BASE_PATH, rid)
