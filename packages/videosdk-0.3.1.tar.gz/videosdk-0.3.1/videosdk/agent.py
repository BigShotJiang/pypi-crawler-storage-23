import asyncio
import logging
from enum import Enum
from typing import Any, Dict, Optional

from ._events import Events, VideoSDKEvents
from .participant import Participant
from .room_client import RoomClient

logger = logging.getLogger(__name__)


class AgentState(Enum):
    IDLE = "idle"
    LISTENING = "listening"
    THINKING = "thinking"
    SPEAKING = "speaking"


class Agent(Participant):
    """
    Extends Participant with agent-specific capabilities for sending
    state changes, transcripts, and metrics over the signaling channel,
    and receiving corresponding events from the server.
    """

    def __init__(
        self,
        id: str,
        display_name: str = "",
        local: bool = False,
        mode: str = "",
        meta_data: Any = None,
        room_client: RoomClient = None,
        device: dict[str, Any] = None,
    ):
        super().__init__(
            id=id,
            display_name=display_name,
            local=local,
            mode=mode,
            meta_data=meta_data,
            room_client=room_client,
            device=device,
        )
        self.__agent_state: AgentState = AgentState.IDLE
        self.__internal_event_listeners: dict = {}
        self.__listen_agent_events()
        logger.debug(f"Agent initialized with ID: {id}")

    def __listen_agent_events(self):
        """
        Register internal event listeners for agent-specific room events.
        """

        @self._room_client.on(Events.AGENT_STATE_CHANGED)
        def on_agent_state_changed(data):
            logger.debug(f"Agent :: {self.id} :: agent-state-changed")
            self._Agent__emit_agent_event(
                VideoSDKEvents.EV_AGENT_STATE_CHANGED.value, data
            )

        self.__internal_event_listeners[Events.AGENT_STATE_CHANGED] = (
            on_agent_state_changed
        )

        @self._room_client.on(Events.AGENT_TRANSCRIPT)
        def on_agent_transcript(data):
            logger.debug(f"Agent :: {self.id} :: agent-transcript")
            self._Agent__emit_agent_event(
                VideoSDKEvents.EV_AGENT_TRANSCRIPT.value, data
            )

        self.__internal_event_listeners[Events.AGENT_TRANSCRIPT] = on_agent_transcript

        @self._room_client.on(Events.AGENT_METRICS)
        def on_agent_metrics(data):
            logger.debug(f"Agent :: {self.id} :: agent-metrics")
            self._Agent__emit_agent_event(
                VideoSDKEvents.EV_AGENT_METRICS.value, data
            )

        self.__internal_event_listeners[Events.AGENT_METRICS] = on_agent_metrics

    def __emit_agent_event(self, event_name, data=None):
        """
        Emit an agent event to all registered listeners.
        """
        for _listener in self.listeners:
            logger.debug(f"{self.id} :: Emitting Agent Event: {event_name}")
            _listener.handle_event(event_name, data)

    # --- Send methods (to server) ---

    def send_state_changed(self, state: AgentState):
        """
        Send agent state change to the server.

        Args:
            state (AgentState): The new agent state.
        """
        self.__agent_state = state
        self._room_client.send_agent_state_changed(state.value)

    async def async_send_state_changed(self, state: AgentState):
        """
        Asynchronously send agent state change to the server.

        Args:
            state (AgentState): The new agent state.
        """
        self.__agent_state = state
        await self._room_client.async_send_agent_state_changed(state.value)

    def send_transcript(
        self, text: str, peer_id: str, timestamp: str
    ):
        """
        Send agent transcript to the server.

        Args:
            text (str): The transcript text.
            peer_id (str): The peer ID associated with the transcript.
            timestamp (str): The timestamp of the transcript.
        """
        self._room_client.send_agent_transcript(
            {"text": text, "peerId": peer_id, "timestamp": timestamp}
        )

    async def async_send_transcript(
        self, text: str, peer_id: str, timestamp: str
    ):
        """
        Asynchronously send agent transcript to the server.

        Args:
            text (str): The transcript text.
            peer_id (str): The peer ID associated with the transcript.
            timestamp (str): The timestamp of the transcript.
        """
        await self._room_client.async_send_agent_transcript(
            {"text": text, "peerId": peer_id, "timestamp": timestamp}
        )

    def send_metrics(self, data: Dict[str, Any]):
        """
        Send agent metrics to the server.

        Args:
            data (dict): The metrics data (any object).
        """
        self._room_client.send_agent_metrics(data)

    async def async_send_metrics(self, data: Dict[str, Any]):
        """
        Asynchronously send agent metrics to the server.

        Args:
            data (dict): The metrics data (any object).
        """
        await self._room_client.async_send_agent_metrics(data)

    def _cleanup(self):
        """
        Clean up agent-specific and inherited resources.
        """
        for k, v in self.__internal_event_listeners.items():
            self._room_client.remove_listener(k, v)
        super()._cleanup()

    @property
    def agent_state(self) -> AgentState:
        return self.__agent_state
