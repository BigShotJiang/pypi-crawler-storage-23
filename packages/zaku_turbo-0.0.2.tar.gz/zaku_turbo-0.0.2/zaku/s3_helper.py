import asyncio
import uuid
from typing import Optional, Dict, List, AsyncGenerator
import aioboto3
from botocore.exceptions import ClientError
from datetime import datetime
from loguru import logger

logger.add(lambda msg: print(msg, end=""), level="DEBUG")


class S3ConnectionError(Exception):
    """S3 connection error"""
    pass


class RobustS3:
    """Robust asynchronous S3 client with retry and batch operations"""

    def __init__(self, session: aioboto3.Session, bucket_name: str,
                 region_name: str = "us-east-1"):
        self.session = session
        self.bucket_name = bucket_name
        self.region_name = region_name

    def _get_client(self):
        """Return async context manager for S3 client"""
        return self.session.client("s3", region_name=self.region_name)

    async def store_payload(self, key: str, payload: bytes,
                            metadata: Optional[Dict] = None) -> bool:
        """Store payload with retry logic"""
        s3_metadata = {}
        if metadata:
            for k, v in metadata.items():
                s3_metadata[str(k).lower().replace('_', '-')] = str(v)
        s3_metadata['created-at'] = datetime.utcnow().isoformat()

        max_retries = 3
        for attempt in range(max_retries):
            try:
                async with self._get_client() as client:
                    await client.put_object(
                        Bucket=self.bucket_name,
                        Key=key,
                        Body=payload,
                        Metadata=s3_metadata
                    )
                logger.debug(f"Stored payload {key} successfully.")
                return True
            except ClientError as e:
                logger.warning(
                    f"Attempt {attempt + 1} failed to store {key}: {e}")
                if attempt == max_retries - 1:
                    raise S3ConnectionError(
                        f"Failed to store payload after {max_retries} attempts: {e}")
                await asyncio.sleep(2 ** attempt)
        return False

    async def insert_payload_auto_id(self, prefix: str,
                                     payload: Optional[bytes],
                                     metadata: Optional[Dict] = None) -> str:
        """Insert payload with auto-generated UUID key"""
        job_id = str(uuid.uuid4())
        key = f"{prefix}/{job_id}"
        await self.store_payload(key, payload or b"", metadata)
        return job_id

    async def retrieve_payload(self, key: str) -> Optional[bytes]:
        """Retrieve payload with retry"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                async with self._get_client() as client:
                    response = await client.get_object(Bucket=self.bucket_name,
                                                       Key=key)
                    payload = await response['Body'].read()
                    logger.debug(f"Retrieved payload {key} successfully.")
                    return payload
            except ClientError as e:
                if e.response['Error']['Code'] == 'NoSuchKey':
                    logger.debug(f"Payload {key} not found.")
                    return None
                logger.warning(
                    f"Attempt {attempt + 1} failed to retrieve {key}: {e}")
                if attempt == max_retries - 1:
                    raise S3ConnectionError(
                        f"Failed to retrieve payload after {max_retries} attempts: {e}")
                await asyncio.sleep(2 ** attempt)
        return None

    async def delete_payload(self, key: str) -> bool:
        """Delete payload with retry"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                async with self._get_client() as client:
                    await client.delete_object(Bucket=self.bucket_name,
                                               Key=key)
                logger.debug(f"Deleted payload {key} successfully.")
                return True
            except ClientError as e:
                logger.warning(
                    f"Attempt {attempt + 1} failed to delete {key}: {e}")
                if attempt == max_retries - 1:
                    raise S3ConnectionError(
                        f"Failed to delete payload after {max_retries} attempts: {e}")
                await asyncio.sleep(2 ** attempt)
        return False

    async def bulk_delete_payloads(self, keys: List[str]) -> int:
        """Bulk delete payloads safely in batches of 1000"""
        if not keys:
            return 0

        max_retries = 3
        for attempt in range(max_retries):
            try:
                deleted_count = 0
                async with self._get_client() as client:
                    for i in range(0, len(keys), 1000):
                        batch = keys[i:i + 1000]
                        response = await client.delete_objects(
                            Bucket=self.bucket_name,
                            Delete={'Objects': [{'Key': k} for k in batch]}
                        )
                        deleted_count += len(response.get('Deleted', []))
                return deleted_count
            except ClientError as e:
                logger.warning(
                    f"Bulk delete attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    raise S3ConnectionError(
                        f"Failed bulk delete after {max_retries} attempts: {e}")
                await asyncio.sleep(2 ** attempt)
        return 0

    async def list_payloads(self, prefix: str = "") -> AsyncGenerator[
        str, None]:
        """List all keys with a prefix as an async generator"""
        try:
            # Ensure prefix ends with delimiter for S3 compatibility
            if prefix and not prefix.endswith('/'):
                prefix = prefix + '/'

            async with self._get_client() as client:
                paginator = client.get_paginator('list_objects_v2')
                async for page in paginator.paginate(Bucket=self.bucket_name,
                                                     Prefix=prefix):
                    for obj in page.get('Contents', []):
                        yield obj['Key']
        except ClientError as e:
            logger.warning(
                f"Failed to list payloads with prefix '{prefix}': {e}")
            raise S3ConnectionError(f"Failed to list payloads: {e}")

    async def clear_prefix(self, prefix: str) -> bool:
        """Delete all objects under a prefix"""
        try:
            keys_to_delete = [key async for key in self.list_payloads(prefix)]
            if keys_to_delete:
                await self.bulk_delete_payloads(keys_to_delete)
                logger.info(f"Cleared {len(keys_to_delete)} objects under "
                            f"prefix '{prefix}'")
            return True
        except ClientError as e:
            logger.warning(f"Failed to clear prefix '{prefix}': {e}")
            raise S3ConnectionError(f"Failed to clear prefix: {e}")

    async def health_check(self) -> bool:
        """Check if S3 bucket is accessible"""
        try:
            async with self._get_client() as client:
                await client.head_bucket(Bucket=self.bucket_name)
            return True
        except ClientError as e:
            logger.warning(f"S3 health check failed: {e}")
            return False

    async def close(self):
        """Placeholder for closing resources (not needed with aioboto3
        context manager)"""
        pass


class S3Manager:
    """Singleton S3 manager"""

    _session: Optional[aioboto3.Session] = None
    _robust_s3: Optional[RobustS3] = None

    @classmethod
    async def initialize(cls, bucket_name: str,
                         region_name: str = "us-east-1"):
        if cls._session is None:
            try:
                cls._session = aioboto3.Session()
                cls._robust_s3 = RobustS3(cls._session, bucket_name,
                                          region_name)
                if not await cls._robust_s3.health_check():
                    raise S3ConnectionError(
                        f"Cannot connect to bucket {bucket_name}")
                logger.info(f"S3 connected to bucket {bucket_name}")
            except Exception as e:
                logger.error(f"Failed to initialize S3: {e}")
                raise S3ConnectionError(f"Failed to initialize S3: {e}")

    @classmethod
    def get_client(cls) -> RobustS3:
        if cls._robust_s3 is None:
            raise S3ConnectionError("S3 not initialized. Call initialize() "
                                    "first.")
        return cls._robust_s3

    @classmethod
    async def close(cls):
        if cls._robust_s3:
            await cls._robust_s3.close()
            cls._robust_s3 = None
        cls._session = None
