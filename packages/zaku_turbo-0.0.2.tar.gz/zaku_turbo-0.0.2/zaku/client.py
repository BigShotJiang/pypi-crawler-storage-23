from contextlib import contextmanager, suppress
from typing import Dict, Optional, Tuple, Any
from uuid import uuid4
import logging as logger
import msgpack
import requests
import boto3
from botocore.exceptions import ClientError
from params_proto.v2.proto import PrefixProto, Proto, Flag
from bson import ObjectId

from zaku.interfaces import Payload


class TaskQ(PrefixProto, cli=False):
    """TaskQ Client (Synchronous with S3 Support)
    ----------------

    This is the synchronous client that interacts with the TaskQ server using S3 for payload storage.

    For async/high-performance scenarios, use `zaku.client_async.TaskQAsync` instead.

    We do not include the configs in the command line because the TaskServer is
    the primary entry point from the command line.

    We do provide the option to load environment variables for these
    configurations.

    Usage
    +++++

    .. code-block:: shell

        # Put this into an .env file (without the exports)
        export ZAKU_URI=http://localhost:9000
        export ZAKU_QUEUE_NAME=ZAKU_TEST:debug-queue-1
        export S3_BUCKET=zaku-payloads
        export S3_REGION=us-east-1

    Now you can create a queue like this:

    .. code-block:: python

        queue = TaskQ()

    ::

        Out[2]: {
            "uri": "http://localhost:9000",
            "name": "ZAKU_TEST:debug-queue-1",
            "s3_bucket": "zaku-payloads",
            "s3_region": "us-east-1"
        }

    Task Queue Configurations
    +++++++++++++++++++++++++

    .. autoattribute:: uri
    .. autoattribute:: name
    .. autoattribute:: s3_bucket
    .. autoattribute:: s3_region
    .. autoattribute:: ttl
    .. autoattribute:: no_init

    Helper Methods
    +++++++++++++++++++++++

    .. automethod:: print_info

    Queue Info
    +++++++++++++++++++++++

    .. automethod:: count
    .. automethod:: __len__

    Task Life-cycle Methods
    +++++++++++++++++++++++

    .. automethod:: init_queue
    .. automethod:: add
    .. automethod:: take
    .. automethod:: mark_done
    .. automethod:: mark_reset
    .. automethod:: pop
    .. automethod:: clear_queue
    .. automethod:: house_keeping

    PubSub and RPC Methods
    +++++++++++++++++++++++

    .. automethod:: publish
    .. automethod:: subscribe_one
    .. automethod:: subscribe_stream
    .. automethod:: rpc
    .. automethod:: rpc_stream

    Async Workflow
    +++++++++++++++

    .. automethod:: gather
    .. automethod:: gather_one
    """

    uri: str = Proto(
        "http://localhost:9000",
        env="ZAKU_URI",
        help="host end point, including protocol and port.",
    )
    """host endpoint uri, including protocol and port.

    .. code-block:: python

        uri: str = Proto(
            "http://localhost:9000",
            env="ZAKU_URI",
        )
    """

    name: str = Proto(
        f"jq-{uuid4()}",
        env="ZAKU_QUEUE_NAME",
        help="""This is the name of the queue. It is unique to the client.""",
    )
    """This is the name of the queue. It is unique to the client. Defaults to a random uuid
    to avoid collision, but you usually want to supply a name so that it is easier to find
    the queue. Zaku also reads from environment variables to side-load the configurations.

    .. code-block:: python

        name: str = Proto(
            f"jq-{uuid4()}",
            env="ZAKU_QUEUE_NAME",
        )
    """

    s3_bucket: str = Proto(
        "zaku-payloads",
        env="S3_BUCKET",
        help="S3 bucket name for storing payloads"
    )
    """S3 bucket name for storing large payloads"""

    s3_region: str = Proto(
        "us-east-1",
        env="S3_REGION",
        help="S3 region"
    )
    """S3 region (e.g., us-east-1, eu-west-1)"""

    ttl: float = Proto(5.0, "time to live in seconds. Defaults to 5.")
    """time to live in seconds. Defaults to 5."""
    no_init: bool = Flag("Flag for skipping the queue creation.")
    """Flag for skipping the queue creation."""

    verbose: bool = Flag("Flag printing the state of the queue")

    ZAKU_USER = Proto(env="ZAKU_USER", help="The user name for the queue.")
    ZAKU_KEY = Proto(env="ZAKU_KEY", help="The user name for the queue.")

    def __post_init__(self):
        # Load environment variables first
        from dotenv import load_dotenv
        import os
        load_dotenv()

        # Update S3 settings from environment (Proto may have loaded before .env)
        self.s3_bucket = os.getenv('S3_BUCKET', self.s3_bucket)
        self.s3_region = os.getenv('S3_REGION', self.s3_region)

        # Initialize S3 client with credentials from environment
        aws_access_key = os.getenv('AWS_ACCESS_KEY_ID')
        aws_secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')

        if aws_access_key and aws_secret_key:
            self.s3_client = boto3.client(
                's3',
                region_name=self.s3_region,
                aws_access_key_id=aws_access_key,
                aws_secret_access_key=aws_secret_key
            )
        else:
            # Fallback to default credentials chain
            self.s3_client = boto3.client('s3', region_name=self.s3_region)

        if not self.no_init:
            self.init_queue()

    def print_info(self):
        """Print the current configurations of the queue.

        Useful for debugging or when connection fails.
        """
        print("=============================")
        for k, v in vars(self).items():
            if k != 's3_client':  # Don't print boto3 client object
                print(f" {k} = {v}")
        print("=============================")

    def _upload_to_s3(self, payload_bytes: bytes, job_id: str) -> str:
        """Upload payload to S3 and return the S3 key

        Args:
            payload_bytes: Serialized payload
            job_id: Job ID to use in S3 key

        Returns:
            S3 key
        """
        s3_key = f"zaku/{self.name}/{job_id}"

        try:
            self.s3_client.put_object(
                Bucket=self.s3_bucket,
                Key=s3_key,
                Body=payload_bytes,
                Metadata={
                    "job-id": job_id,
                    "queue": self.name,
                    "size": str(len(payload_bytes))
                }
            )
            return s3_key
        except ClientError as e:
            raise Exception(f"Failed to upload to S3: {e}")

    def download_from_s3(self, s3_key: str) -> bytes:
        """Download payload from S3

        Args:
            s3_key: S3 object key

        Returns:
            Payload bytes
        """
        try:
            response = self.s3_client.get_object(
                Bucket=self.s3_bucket,
                Key=s3_key
            )
            return response['Body'].read()
        except ClientError as e:
            raise Exception(f"Failed to download from S3 (key={s3_key}): {e}")

    def download_payloads(self, s3_keys: list) -> list:
        """Concurrently download multiple payloads (using a thread pool).

        Args:
            s3_keys: List of S3 object keys to download.

        Returns:
            List of payload bytes in the same order as s3_keys.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def download_one(key):
            return self.download_from_s3(key)

        # 使用线程池并发下载
        with ThreadPoolExecutor(max_workers=min(len(s3_keys), 10)) as executor:
            futures = {executor.submit(download_one, key): i for i, key in
                       enumerate(s3_keys)}
            results = [None] * len(s3_keys)

            for future in as_completed(futures):
                idx = futures[future]
                results[idx] = future.result()

            return results

    def init_queue(self, name=None):
        """Create a new collection.

        :param name: (optional) The name of the queue.
        """
        if name:
            self.name = name

        if self.verbose:
            print("creating queue...", self.name)
            self.print_info()

        # Establish clean error traces for better debugging.
        with suppress(requests.exceptions.ConnectionError):
            res = requests.put(self.uri + "/queues", json={"name": self.name})
            return res.status_code == 200, "failed"

        self.print_info()
        raise ConnectionError(
            "Queue creation failed, check connection.").with_traceback(None)

    def publish(self, value: Dict, *, topic=None):
        """Append a job to the queue."""
        if topic is None:
            topic = str(uuid4())

        payload = Payload(**value)

        json = {
            "queue": self.name,
            "topic_id": topic,
            "payload": payload.serialize(),
            # published messages are ephemeral.
            # "ttl": self.ttl,
        }
        # ues msgpack to serialize the data. Bytes are the most efficient.
        res = requests.put(
            self.uri + "/publish",
            msgpack.packb(json, use_bin_type=True),
        )
        if res.status_code == 200:
            try:
                return int(res.text)
            except Exception:
                return None
        raise Exception(f"Failed to add job to {self.uri}.", res.content)

    def subscribe_one(self, topic: str, timeout=0.1):
        """subscribe to wait for one publishing event"""
        response = requests.post(
            self.uri + "/subscribe_one",
            json={"queue": self.name, "topic_id": topic, "timeout": timeout},
        )

        # todo: add timeout handling
        if response.status_code != 200:
            raise Exception(f"Failed to grab job from {self.uri}.",
                            response.content)

        if not response.content:
            return

        # subscription does not have a job container.
        return Payload.deserialize(response.content)

    def subscribe_stream(self, topic: str, timeout=0.1):
        """subscribe to collect all publishing events"""
        delimiter = b"\n"
        response = requests.post(
            self.uri + "/subscribe_stream",
            json={"queue": self.name, "topic_id": topic, "timeout": timeout},
            stream=True,
        )
        response.raise_for_status()  # Raise an exception for HTTP errors
        unpacker = msgpack.Unpacker()

        for chunk in response.iter_content(chunk_size=8192):
            unpacker.feed(chunk)
            for unpacked in unpacker:
                yield Payload.deserialize_unpacked(unpacked)

    def add(
        self,
        value: Dict,
        *,
        key=None,
        metadata: Dict = None,
    ) -> str:
        """Add a job to the queue with S3 storage.

        Args:
            value: Job payload (will be serialized and uploaded to S3)
            key: Optional custom job_id
            metadata: User-defined metadata dict (Any custom field，eg:
            task_name, submitted_by, git_repo...)

        Returns:
            job_id

        Example:
            # Training task
            queue.add(
                {"git_repo": "...", "branch": "main"},
                metadata={
                    "task_name": "walk-exp-v1",
                    "submitted_by": "charlie",
                    "git_repo": "https://...",
                    "git_branch": "main"
                }
            )

            # Other types of tasks
            queue.add(
                {"video_url": "..."},
                metadata={
                    "video_name": "demo.mp4",
                    "user_id": "123",
                    "project": "video-processing"
                }
            )
        """
        # 1. Serialize payload
        payload = Payload(**value)
        payload_bytes = payload.serialize()

        # 2. Generate job_id
        job_id = key if key is not None else str(ObjectId())

        # 3. Upload to S3
        s3_key = self._upload_to_s3(payload_bytes, job_id)

        # 4. Send to server with user metadata
        json = {
            "queue": self.name,
            "s3_key": s3_key,
            "s3_bucket": self.s3_bucket,
            "size": len(payload_bytes),
            "job_id": job_id,
            "metadata": metadata or {},  # User-defined metadata
        }

        res = requests.put(
            self.uri + "/tasks",
            msgpack.packb(json, use_bin_type=True),
        )

        if res.status_code == 200 and res.content:
            data = msgpack.loads(res.content)
            return data.get("job_id", job_id)

        raise Exception(f"Failed to add job to {self.uri}.", res.content)

    def count(self):
        """Count the number of available jobs in the queue.

        .. code-block:: python

            num_of_jobs = queue.count()

        :return None if the queue does not exist. This happens when there is no stale jobs.
                0 if the queue only contains stale jobs
                number if the queue contains open jobs (created)
        """
        response = requests.get(
            self.uri + "/tasks/counts",
            json={"queue": self.name},
        )

        if response.status_code != 200:
            raise RuntimeError(f"Failed to count job from {self.uri}.",
                               response.content)

        elif not response.content:
            return None

        data = msgpack.loads(response.content)
        return data.get("counts", None)

    def __len__(self):
        """Returns the number of available jobs in the queue.

        .. code-block:: python

            length = len(queue)


        .. hint::

            This is an alias of TaskQ.count.

        :return None if the queue does not exist. This happens when there is no stale jobs.
                0 if the queue only contains stale jobs
                number if the queue contains open jobs (created)
        """
        return self.count()

    def take(self) -> Optional[Tuple[str, Dict]]:
        """Take a job from the queue (returns metadata only, not payload).

        Returns:
            (job_id, metadata) tuple, or None if queue is empty
            metadata contains: {"_s3_key": "...", "_s3_bucket": "...", "_size": ...}

        Example:
            job_id, metadata = queue.take()
            if metadata:
                s3_key = metadata["_s3_key"]
                payload_bytes = queue.download_from_s3(s3_key)
                payload = msgpack.unpackb(payload_bytes, raw=False)
        """
        response = requests.post(
            self.uri + "/tasks",
            json={"queue": self.name},
        )

        if response.status_code != 200:
            raise RuntimeError(f"Failed to grab job from {self.uri}.",
                               response.content)

        elif not response.content:
            return None

        data = msgpack.loads(response.content)
        job_id = data.get("job_id")
        metadata = data.get("payload")  # This is metadata, not full payload

        if not metadata:
            return None

        # Check if metadata is already a dict or needs unpacking
        if isinstance(metadata, bytes):
            metadata_dict = msgpack.unpackb(metadata, raw=False)
        else:
            metadata_dict = metadata

        return job_id, metadata_dict

    def mark_done(self, job_id, status="completed", error=None):
        """Mark a job as completed or failed and keep in Redis for 15 days.

        Args:
            job_id: Job identifier
            status: Status to set ("completed" or "failed"), default "completed"
            error: Error message if status is "failed" (optional)

        Strategy:
        1. Update status in Redis metadata (keep for 15 days)
        2. Delete S3 payload (save costs)
        3. Move from processing to completed/failed zset
        """
        from time import time

        # Validate status
        if status not in ["completed", "failed"]:
            raise ValueError(f"Invalid status: {status}. Must be 'completed' or 'failed'")

        # Build request payload
        payload = {
            "queue": self.name,
            "job_id": job_id,
            "status": status,
            "completed_ts": time()
        }
        if error:
            payload["error"] = error

        # Update status via new API endpoint
        res = requests.put(
            self.uri + f"/tasks/{job_id}/complete",
            json=payload
        )
        if res.status_code != 200:
            raise Exception(f"Failed to mark job {job_id} as {status}", res.content)

        # Delete S3 payload to save costs
        s3_key = f"zaku/{self.name}/{job_id}"
        try:
            self.s3_client.delete_object(
                Bucket=self.s3_bucket,
                Key=s3_key
            )
            logger.debug(f"Deleted S3 payload for job {job_id}")
        except Exception as e:
            logger.warning(f"Failed to delete S3 object {s3_key}: {e}")

        return True

    def append_log(self, job_id: str, message: str) -> bool:
        """Append a log message to task logs.

        Args:
            job_id: Job identifier
            message: Log message to append

        Returns:
            True if successful

        Note:
            - Logs are stored in Redis (latest 100 lines)
            - Logs expire after 15 days
            - Timestamp is added automatically by server
        """
        try:
            res = requests.post(
                self.uri + f"/tasks/{job_id}/logs",
                json={
                    "queue": self.name,
                    "message": message
                }
            )
            if res.status_code == 200:
                return True
            else:
                logger.warning(f"Failed to append log: {res.text}")
                return False
        except Exception as e:
            logger.warning(f"Failed to append log for job {job_id}: {e}")
            return False

    def mark_reset(self, job_id):
        res = requests.post(
            self.uri + "/tasks/reset",
            json={"queue": self.name, "job_id": job_id},
        )
        if res.status_code == 200:
            return True

        raise Exception(f"Failed to reset job on {self.uri}.", res.content)

    def list_tasks(self, status: str = "all", limit: int = 20) -> dict:
        """List tasks from the queue.

        Args:
            status: Filter by status - "all", "pending", "in_progress", "completed", "failed" (default: "all")
            limit: Maximum number of tasks to return (default: 20)

        Returns:
            dict with keys: "tasks", "total", "queue", "status_filter"

        Example:
            result = queue.list_tasks(status="completed", limit=10)
            for task in result["tasks"]:
                print(task["job_id"], task["status"], task["metadata"])
        """
        try:
            res = requests.get(
                self.uri + "/tasks",
                params={
                    "queue": self.name,
                    "status": status,
                    "limit": limit
                }
            )
            if res.status_code == 200:
                return res.json()
            else:
                raise Exception(f"Failed to list tasks: {res.text}")
        except Exception as e:
            logger.error(f"Failed to list tasks: {e}")
            raise

    def get_task(self, job_id: str) -> dict:
        """Get a single task's metadata.

        Args:
            job_id: Job identifier

        Returns:
            Task dict with full metadata

        Example:
            task = queue.get_task("abc-123")
            print(task["status"], task["metadata"]["task_name"])
        """
        try:
            res = requests.get(
                self.uri + f"/tasks/{job_id}",
                params={"queue": self.name}
            )
            if res.status_code == 200:
                return res.json()
            elif res.status_code == 404:
                raise Exception(f"Task {job_id} not found")
            else:
                raise Exception(f"Failed to get task: {res.text}")
        except Exception as e:
            logger.error(f"Failed to get task {job_id}: {e}")
            raise

    def get_logs(self, job_id: str, lines: int = 100) -> str:
        """Get task logs.

        Args:
            job_id: Job identifier
            lines: Number of lines to retrieve (default: 100, max: 100)

        Returns:
            Log content as string

        Example:
            logs = queue.get_logs("abc-123", lines=50)
            print(logs)
        """
        try:
            res = requests.get(
                self.uri + f"/tasks/{job_id}/logs",
                params={
                    "queue": self.name,
                    "lines": lines
                }
            )
            if res.status_code == 200:
                return res.text
            else:
                raise Exception(f"Failed to get logs: {res.text}")
        except Exception as e:
            logger.error(f"Failed to get logs for job {job_id}: {e}")
            raise

    @contextmanager
    def pop(self):
        """Pop a job from the queue (auto-downloads payload).

        This is a convenience method that automatically downloads the payload from S3.

        Example:
            with queue.pop() as job:
                if job:
                    process(job)  # job is the deserialized payload
        """
        job_tuple = self.take()
        if not job_tuple:
            yield None
            return

        job_id, metadata = job_tuple

        # Download payload from S3
        s3_key = metadata.get("_s3_key")
        if not s3_key:
            raise RuntimeError(f"Missing _s3_key in metadata for job {job_id}")

        payload_bytes = self.download_from_s3(s3_key)
        job = Payload.deserialize(payload_bytes)

        try:
            yield job
        except SystemExit as e:
            # System exit: mark as completed (graceful shutdown)
            self.mark_done(job_id, status="completed")
            raise e
        except Exception as e:
            # Task failed: mark as failed with error message
            error_msg = f"{type(e).__name__}: {str(e)}"
            self.mark_done(job_id, status="failed", error=error_msg)
            raise e

        # Success: mark as completed
        self.mark_done(job_id, status="completed")

    def clear_s3_prefix(self, prefix: str = None) -> int:
        """Clear all S3 objects under a prefix (useful for cleanup)

        Args:
            prefix: S3 prefix to clear, defaults to zaku/{queue_name}/

        Returns:
            number of deleted objects
        """
        if prefix is None:
            prefix = f"zaku/{self.name}/"

        # List all objects under the prefix
        keys_to_delete = []
        paginator = self.s3_client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=self.s3_bucket, Prefix=prefix):
            for obj in page.get('Contents', []):
                keys_to_delete.append(obj['Key'])

        if not keys_to_delete:
            logger.info(f"No S3 objects found under prefix {prefix}")
            return 0

        logger.info(
            f"Found {len(keys_to_delete)} S3 objects to delete under prefix {prefix}")

        # Delete in batches of 1000 (S3 limit)
        deleted_count = 0
        for i in range(0, len(keys_to_delete), 1000):
            batch = keys_to_delete[i:i + 1000]
            batch_num = i // 1000 + 1

            try:
                response = self.s3_client.delete_objects(
                    Bucket=self.s3_bucket,
                    Delete={'Objects': [{'Key': k} for k in batch]}
                )
                deleted = len(response.get('Deleted', []))
                deleted_count += deleted
                logger.info(f"Deleted batch {batch_num}: {deleted} objects")
            except Exception as e:
                logger.error(f"Failed to delete batch {batch_num}: {e}")

        logger.info(
            f"Total deleted: {deleted_count}/{len(keys_to_delete)} S3 objects")
        return deleted_count

    def clear_queue(self):
        """Thoroughly clean the queue (all data in Redis + S3)

        Strategy:
        1. Delete all tasks in Redis via server API
        2. Delete all S3 objects under the queue prefix

        Returns:
            True if successful

        Raises:
            Exception if failed
        """
        # 1. First delete Redis data
        res = requests.delete(
            self.uri + "/tasks",
            json={"queue": self.name, "job_id": "*"},
        )
        if res.status_code != 200:
            raise Exception(f"Failed to clear Redis on {self.uri}.", res.content)

        logger.info(f"Redis cleanup success for queue '{self.name}'")

        # 2. Then delete S3 data
        s3_count = self.clear_s3_prefix()
        logger.info(f"Client-side S3 cleanup: {s3_count} objects deleted")

        logger.info(f"Queue '{self.name}' cleared: Redis=success, S3={s3_count}")
        return True

    def unstale_tasks(self, ttl=300):
        """Remove all jobs in a queue. Useful when stale jobs degrades performance."""
        res = requests.put(
            self.uri + "/tasks/unstale",
            json={
                "queue": self.name,
                "ttl": ttl,  # the ttl is not used.
            },
        )
        if res.status_code == 200:
            return True

        raise Exception(f"Failed to do house keeping on {self.uri}.",
                        res.content)

    def rpc(self, *args, _timeout=1.0, **kwargs):
        """
        This function is a synchronous RPC function that is used to
        send rendering requests to the rendering server and collect
        the response. This is a blocking function that waits for the
        response from the worker before returning.

        Args:
            response_topic: The pubsub topic to return the response to
            args: The positional arguments
            kwargs: The keyword arguments

        :return:
        """

        from uuid import uuid4

        request_id = uuid4()

        topic_name = f"rpc-{request_id}"

        # push the request to the queue
        self.add(
            {
                "_request_id": topic_name,
                "_args": args,
                **kwargs,
            }
        )

        return self.subscribe_one(topic_name, timeout=_timeout)

    def rpc_stream(
            self,
            *args,
            _timeout=1.0,
            **kwargs,
    ):
        """
        This function is a synchronous RPC function that is used to
        send rendering requests to the rendering server and collect
        the response. This is a blocking function that waits for the
        response from the worker before returning.

        Args:
            response_topic: The pubsub topic to return the response to
            args: The positional arguments
            kwargs: The keyword arguments

        :return:
        """

        from uuid import uuid4

        request_id = uuid4()

        topic_name = f"rpc-{request_id}"

        # push the request to the queue
        self.add(
            {
                "_request_id": topic_name,
                "_args": args,
                **kwargs,
            }
        )

        return self.subscribe_stream(topic_name, timeout=_timeout)

    def gather_one(self, job, gather_tokens=None, **kwargs):
        """Gather the jobs (not quite, will fix - Ge)

        Usage
        +++++

        .. code-block:: python

            queue = TaskQ()

            tokens = None
            for i in range(30):
                is_done, tokens = job_queue.gather_one(jobs, tokens)

            # this is blocking.
            if is_done():
                print("done")

        :param self:
        :type self: TaskQ
        :param jobs:
        :type jobs: dict
        :param gather_tokens: this is a singleton, a set that contains just one element, unless you pass in another token set.
        :type gather_tokens: Union[None, set]
        :param prefix:
        :type prefix: str
        :return: Union[Callable, set]
        :rtype:
        """
        return self.gather(jobs=[job], gather_tokens=gather_tokens, **kwargs)

    def gather(self, jobs: list, gather_tokens=None,
               prefix="{self.name}.return-queue"):
        """Gather the jobs (not quite, will fix - Ge)

        Usage
        +++++

        .. code-block:: python

            queue = TaskQ()

            jobs = [dict(seed=i) for i in range(30)]
            is_done, tokens = job_queue.gather(jobs)

            # this is blocking.
            if is_done():
                print("done")


        Now, to add jobs in batches:

        .. code-block:: python

            queue = TaskQ()

            jobs = [dict(seed=i) for i in range(30)]
            is_done, tokens = job_queue.gather(jobs)

            # add the second batch
            jobs = [dict(seed=i) for i in range(30, 50)]
            is_done, tokens = job_queue.gather(jobs, tokens)

            # now wait for done.
            if is_done():
                print("done")

        :param self:
        :type self: TaskQ
        :param jobs:
        :type jobs: dict
        :param gather_tokens: This is a set that you can add to, contains the list of tokens
        :type gather_tokens: Union[None, set]
        :param prefix:
        :type prefix: str
        :return: Union[Callable, set]
        :rtype:
        """
        from uuid import uuid4

        r_id = uuid4()
        r_queue_name = prefix.format(self=self, r_id=r_id)
        gather_queue = TaskQ(name=r_queue_name, s3_bucket=self.s3_bucket,
                             s3_region=self.s3_region)

        gather_tokens = gather_tokens or set()

        for job in jobs:
            # this casts it to string
            gather_token = f"gather-{uuid4()}"
            gather_tokens.add(gather_token)

            r_spec = {
                "_gather_id": r_queue_name,
                "_gather_token": gather_token,
            }

            # # after the set should contain all
            # for job in jobs:
            self.add({**r_spec, **job})

        def is_done(blocking=False, sleep=0.1):
            import time

            nonlocal gather_queue, gather_tokens

            job = True
            while gather_tokens and (blocking or job):
                # this is not ideal
                ret = gather_queue.take()
                if ret is None:
                    job = None
                    time.sleep(sleep)
                    continue

                job_id, metadata = ret

                # Download payload from S3
                s3_key = metadata.get("_s3_key")
                if s3_key:
                    payload_bytes = gather_queue.download_from_s3(s3_key)
                    job_data = Payload.deserialize(payload_bytes)
                else:
                    job_data = metadata

                gather_queue.mark_done(job_id)

                try:
                    gt = job_data["_gather_token"]
                except KeyError:
                    gather_queue.clear_queue()
                    raise

                try:
                    gather_tokens.remove(gt)
                except KeyError:
                    pass
                # no sleep here.

            return not gather_tokens

        return is_done, gather_tokens
