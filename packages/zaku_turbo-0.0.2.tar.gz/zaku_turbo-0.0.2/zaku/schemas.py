from dataclasses import dataclass
from typing import Optional


@dataclass
class TrainingJob:
    git_repo: str
    git_branch: str
    git_commit: Optional[str] = None
    github_token: Optional[str] = None
