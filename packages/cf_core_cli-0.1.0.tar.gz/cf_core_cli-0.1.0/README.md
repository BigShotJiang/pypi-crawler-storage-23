# cf-core-cli

Unified Cogniflow command-line interface.

Published distribution name:

```bash
pip install cf-core-cli
```

Console script:

```bash
cf --help
```

## Publishing

`cf_cli` is published with the dedicated Windows workflow:

- Workflow: `.github/workflows/cf_cli_windows_publish.yml`
- Package directory: `sandcastle/cf_cli`
- PyPI tag: `cf-core-cli-v<version>`
- TestPyPI tag: `cf-core-cli-v<version>-test`

Local preflight:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/mimic_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_cli_windows_publish.yml `
  -PackageDir sandcastle/cf_cli `
  -PythonExe py `
  -PythonVersion 3.13
```

Queue a dry-run dispatch:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/queue_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_cli_windows_publish.yml `
  -PackageDir sandcastle/cf_cli `
  -PublishTarget testpypi `
  -Ref main `
  -RequireLocalPass `
  -DryRun
```
