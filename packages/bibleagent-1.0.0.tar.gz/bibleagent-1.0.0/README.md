# biblemateagent
A headless version of BibleMate AI Agent Mode

## Installation

> pip install biblemateagent

## Set up data

> biblematedata

## Run BibleMate Agent

> biblemateagent "Your Bible Study Request"

or

> bibleagent "Your Bible Study Request"

## Help

> biblemateagent -h

or

> bibleagent -h