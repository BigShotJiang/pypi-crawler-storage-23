# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/12/28 16:21
# Description:

from silars.alphalens.report import get_report
from silars.plot import nv_plot, nvs_plot
import polars as pl
import mlflow
import plotly.graph_objects as go


# file_name = "factor_data.parquet"
file_name = "pnl.parquet"

if __name__ == '__main__':
    data = pl.read_parquet(file_name)
    # fig = get_report(data, factor_name="d_ewmmean(cs_moderate(sd), {'half_life': 20})", N=10)
    df_pd = data.to_pandas().set_index("date")
    fig, _ = nvs_plot(df_pd,
                      color_configs={
                          "long": "DarkOrange",
                          "short": "LightSkyBlue",
                          "long-short": "rgba(200, 0, 0, 1)",
                      },
                      mdd_name="long-short",
                      starting_nv=1.0)# ["long-short"])
    fig.show()

