from __future__ import annotations

from enum import Enum
from typing import Literal, NotRequired, TypedDict

from ..sensor import SensorType

PythonVersion = Literal["3.11", "3.12"]


class PluginRole(str, Enum):
    """Defines what role a plugin plays in the system."""

    Hub = "hub"  # Manages cameras and their connections
    SensorProvider = "sensorProvider"  # Provides detection sensors only
    CameraController = "cameraController"  # Controls camera hardware
    CameraAndSensorProvider = "cameraAndSensorProvider"  # Provides both cameras and sensors


class PluginInterface(str, Enum):
    """Detection/discovery capabilities a plugin can declare in its contract."""

    MotionDetection = "MotionDetection"
    ObjectDetection = "ObjectDetection"
    AudioDetection = "AudioDetection"
    DiscoveryProvider = "DiscoveryProvider"


class PluginContract(TypedDict):
    """Plugin contract declared in the plugin's manifest."""

    name: str
    role: PluginRole
    provides: list[SensorType]
    consumes: list[SensorType]
    interfaces: list[PluginInterface]
    pythonVersion: NotRequired[PythonVersion]
    dependencies: NotRequired[list[str]]
