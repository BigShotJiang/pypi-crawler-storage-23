"""Lightweight async-compatible event emitter."""

from __future__ import annotations

import asyncio
from collections import OrderedDict
from collections.abc import Callable
from typing import Any


class AsyncEventEmitter:
    """Lightweight async-compatible event emitter.

    Supports sync and async handlers. Async handlers are scheduled via
    ``ensure_future`` (fire-and-forget) and tracked so they can be
    cancelled with ``cancel()``.
    """

    def __init__(self) -> None:
        self._events: dict[str, OrderedDict[Callable[..., Any], Callable[..., Any]]] = {}
        self._waiting: set[asyncio.Future[Any]] = set()

    def on(self, event: str, f: Callable[..., Any]) -> Callable[..., Any]:
        """Register a listener for *event*."""
        listeners = self._events.get(event)
        if listeners is None:
            listeners = OrderedDict[Callable[..., Any], Callable[..., Any]]()
            self._events[event] = listeners
        listeners[f] = f
        return f

    def once(self, event: str, f: Callable[..., Any]) -> Callable[..., Any]:
        """Register a one-shot listener for *event*."""

        def wrapper(*args: Any, **kwargs: Any) -> Any:
            self.remove_listener(event, f)
            return f(*args, **kwargs)

        listeners = self._events.get(event)
        if listeners is None:
            listeners = OrderedDict[Callable[..., Any], Callable[..., Any]]()
            self._events[event] = listeners
        listeners[f] = wrapper
        return f

    def emit(self, event: str, *args: Any, **kwargs: Any) -> bool:
        """Emit *event*, calling all registered listeners.

        Returns ``True`` if *event* had listeners, ``False`` otherwise.
        Async handlers are scheduled as fire-and-forget tasks.
        """
        listeners = self._events.get(event)
        if not listeners:
            return False

        for handler in list(listeners.values()):
            result = handler(*args, **kwargs)
            if asyncio.iscoroutine(result):
                future = asyncio.ensure_future(result)
                self._waiting.add(future)
                future.add_done_callback(self._waiting.discard)

        return True

    def remove_listener(self, event: str, f: Callable[..., Any]) -> None:
        """Remove a specific listener for *event*."""
        listeners = self._events.get(event)
        if listeners is not None:
            listeners.pop(f, None)
            if not listeners:
                del self._events[event]

    def remove_all_listeners(self, event: str | None = None) -> None:
        """Remove all listeners, or all listeners for a specific *event*."""
        if event is not None:
            self._events.pop(event, None)
        else:
            self._events.clear()

    def cancel(self) -> None:
        """Cancel all pending async tasks."""
        for future in self._waiting:
            future.cancel()
        self._waiting.clear()
