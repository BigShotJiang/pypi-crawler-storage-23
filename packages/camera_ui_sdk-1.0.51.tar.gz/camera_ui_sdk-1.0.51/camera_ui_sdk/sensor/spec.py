from __future__ import annotations

from typing import Literal, Required

from typing_extensions import TypedDict


class VideoInputSpec(TypedDict):
    """Expected video input dimensions and format for a detector model."""

    width: int
    height: int
    format: Literal["rgb", "nv12", "gray"]


class ObjectModelSpec(TypedDict):
    """Model spec for object detectors (input dimensions only, labels are dynamic)."""

    input: VideoInputSpec


class ModelSpec(TypedDict):
    """Model spec for detectors with fixed output labels (face, classifier, license plate)."""

    input: VideoInputSpec
    outputLabels: list[str]
    triggerLabels: list[str]


class AudioInputSpec(TypedDict, total=False):
    """Expected audio input format for an audio detector model."""

    sampleRate: Required[int]
    channels: Required[int]
    format: Required[Literal["pcm16", "float32"]]
    samplesPerFrame: int
    """Number of samples per audio frame. The backend buffers audio to deliver exactly this many samples."""


class AudioModelSpec(TypedDict):
    """Model spec for audio detectors."""

    input: AudioInputSpec
    outputLabels: list[str]
