"""Version information for Copilot Session Dashboard."""

__version__ = "0.1.3"
__repository__ = "https://github.com/JeffSteinbok/ghcpCliSessionDashboard"
