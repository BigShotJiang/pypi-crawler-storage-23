# SPDX-FileCopyrightText: Copyright © 2025 Idiap Research Institute <contact@idiap.ch>
#
# SPDX-License-Identifier: GPL-3.0-or-later
import pathlib

from fairical.scores import Scores
from fairical.solutions import Solutions


def test_a_priori_metadata(datadir: pathlib.Path):
    scores = Scores.load(str(datadir / "data" / "sample" / "system_1.json"))
    prior_solutions = Solutions.load(str(datadir / "data" / "uc-1" / "system_2.json"))
    prior_solutions_nds = prior_solutions.non_dominated_solutions()[0]

    metric = list(prior_solutions.points.keys())

    solutions = scores.solutions_a_priori(metric, prior_solutions, dominated=False)

    expected_thr_ids_combinations = list(
        zip(
            prior_solutions_nds.metadata["thresholds"],
            prior_solutions_nds.metadata["identifiers"],
        )
    )
    thr_ids_combinations = list(
        zip(solutions.metadata["thresholds"], solutions.metadata["identifiers"])
    )

    for combination in thr_ids_combinations:
        assert combination in expected_thr_ids_combinations


def test_tabulate():
    sol = Solutions.fromarray(
        [[0.1, 0.9], [0.2, 0.2], [0.3, 0.3]], ("eod+race", "acc"), [0.6, 0.2, 0.3]
    )

    table = sol.tabulate()

    assert "(eod+race, acc)" in table
    assert "thresholds" in table
    assert "identifiers" in table
    assert "(0.1, 0.9)" in table
    assert "(0.2, 0.2)" in table
    assert "(0.3, 0.3)" in table
    assert "0.6" in table
    assert "0.2" in table
    assert "0.3" in table
    assert table.count("model-0") == 3
