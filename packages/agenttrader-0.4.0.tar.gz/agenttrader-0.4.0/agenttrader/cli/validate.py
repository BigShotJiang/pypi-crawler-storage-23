# DO NOT import pmxt here. Use agenttrader.data.pmxt_client only.
from __future__ import annotations

import ast
from pathlib import Path

import inspect

import click

from agenttrader.cli.utils import emit_json, json_errors
from agenttrader.core.base_strategy import BaseStrategy


def _base_strategy_methods() -> set[str]:
    """Derive allowed self.* methods from the actual BaseStrategy class."""
    return {
        name
        for name, _ in inspect.getmembers(BaseStrategy, predicate=inspect.isfunction)
        if not name.startswith("_")
    }

FORBIDDEN_IMPORTS = {
    # Network libraries
    "requests", "httpx", "aiohttp", "urllib",
    # System/process access
    "os", "subprocess", "shutil", "sys",
    # Low-level / dangerous
    "socket", "ctypes", "sqlite3",
    # Concurrency — can interfere with the daemon event loop or spawn threads
    "threading", "asyncio", "multiprocessing", "concurrent",
    # Dynamic import bypass
    "importlib",
    # Internal SDK
    "dome_api_sdk", "pmxt",
}


class StrategyValidator(ast.NodeVisitor):
    def __init__(self, file_path: Path):
        self.file_path = str(file_path)
        self.errors: list[dict] = []
        self.warnings: list[dict] = []
        self.strategy_classes: list[ast.ClassDef] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        for base in node.bases:
            if isinstance(base, ast.Name) and base.id == "BaseStrategy":
                self.strategy_classes.append(node)
            elif isinstance(base, ast.Attribute) and base.attr == "BaseStrategy":
                self.strategy_classes.append(node)
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            root = alias.name.split(".")[0]
            if root in FORBIDDEN_IMPORTS:
                self.errors.append(
                    {
                        "type": "ForbiddenImport",
                        "message": f"Import '{alias.name}' is forbidden in strategies.",
                        "file": self.file_path,
                        "line": node.lineno,
                    }
                )

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module:
            root = node.module.split(".")[0]
            if root in FORBIDDEN_IMPORTS:
                self.errors.append(
                    {
                        "type": "ForbiddenImport",
                        "message": f"Import '{node.module}' is forbidden in strategies.",
                        "file": self.file_path,
                        "line": node.lineno,
                    }
                )

    def visit_Call(self, node: ast.Call) -> None:
        # Detect __import__("module") calls — these bypass AST import checks
        if isinstance(node.func, ast.Name) and node.func.id == "__import__":
            self.errors.append(
                {
                    "type": "DynamicImport",
                    "message": "__import__() bypasses static import checks and is not allowed in strategies.",
                    "file": self.file_path,
                    "line": node.lineno,
                }
            )
        # Detect importlib.import_module() calls
        if isinstance(node.func, ast.Attribute) and node.func.attr == "import_module":
            self.errors.append(
                {
                    "type": "DynamicImport",
                    "message": "importlib.import_module() bypasses static import checks and is not allowed in strategies.",
                    "file": self.file_path,
                    "line": node.lineno,
                }
            )
        self.generic_visit(node)

    def validate_structure(self) -> None:
        if len(self.strategy_classes) != 1:
            self.errors.append(
                {
                    "type": "ClassDefinitionError",
                    "message": "File must define exactly one class that subclasses BaseStrategy.",
                    "file": self.file_path,
                    "line": 1,
                }
            )
            return

        cls = self.strategy_classes[0]
        method = None
        for item in cls.body:
            if isinstance(item, ast.FunctionDef) and item.name == "on_market_data":
                method = item
                break

        if method is None:
            self.errors.append(
                {
                    "type": "MissingMethod",
                    "message": "Strategy must implement on_market_data(self, market, price, orderbook).",
                    "file": self.file_path,
                    "line": cls.lineno,
                }
            )
            return

        # Check arity (4 args including self), not exact parameter names
        arg_count = len(method.args.args)
        if arg_count != 4:
            self.errors.append(
                {
                    "type": "InvalidSignature",
                    "message": f"on_market_data must accept exactly 4 arguments (self, market, price, orderbook), got {arg_count}.",
                    "file": self.file_path,
                    "line": method.lineno,
                }
            )

        # Collect methods defined in this class (helpers are allowed)
        class_defined_methods = {
            item.name
            for item in cls.body
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

        # Allowed self.* calls = BaseStrategy public API + class-defined methods
        allowed = _base_strategy_methods() | class_defined_methods

        for node in ast.walk(cls):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                owner = node.func.value
                if isinstance(owner, ast.Name) and owner.id == "self":
                    method_name = node.func.attr
                    if method_name.startswith("_"):
                        # Allow private/internal attribute access (e.g. self._ctx)
                        continue
                    if method_name not in allowed:
                        self.errors.append(
                            {
                                "type": "InvalidMethodCall",
                                "message": (
                                    f"Call to 'self.{method_name}()' is not part of the BaseStrategy API "
                                    f"and is not defined in this class."
                                ),
                                "file": self.file_path,
                                "line": node.lineno,
                            }
                        )


def validate_strategy_file(strategy_path: str) -> dict:
    path = Path(strategy_path)
    if not path.exists():
        return {
            "ok": True,
            "valid": False,
            "errors": [
                {
                    "type": "FileNotFoundError",
                    "message": f"Strategy file not found: {strategy_path}",
                    "file": strategy_path,
                    "line": 1,
                }
            ],
            "warnings": [],
        }

    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    validator = StrategyValidator(path)
    validator.visit(tree)
    validator.validate_structure()

    return {
        "ok": True,
        "valid": len(validator.errors) == 0,
        "errors": validator.errors,
        "warnings": validator.warnings,
    }


@click.command("validate")
@click.argument("strategy_path", type=click.Path(exists=True, dir_okay=False))
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON output")
@json_errors
def validate_cmd(strategy_path: str, json_output: bool) -> None:
    result = validate_strategy_file(strategy_path)
    if json_output:
        emit_json(result)
        return

    if result["valid"]:
        click.echo("Strategy validation passed")
        return

    click.echo("Validation errors:")
    for err in result["errors"]:
        click.echo(f"- {err['type']} line {err['line']}: {err['message']}")
    if result["warnings"]:
        click.echo("Warnings:")
        for warn in result["warnings"]:
            click.echo(f"- {warn['type']} line {warn['line']}: {warn['message']}")
    raise click.exceptions.Exit(1)
