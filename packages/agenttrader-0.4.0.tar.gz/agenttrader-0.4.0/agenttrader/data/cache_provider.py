"""MarketDataProvider backed by SQLite cache + file-based OrderBookStore."""
from __future__ import annotations

from agenttrader.data.models import (
    DataProvenance,
    Market,
    OrderBook,
    PricePoint,
)


class CacheProvider:
    """Wraps DataCache + OrderBookStore behind MarketDataProvider."""

    def __init__(self, cache, ob_store):
        self._cache = cache
        self._ob_store = ob_store

    def get_markets(self, platform="all", category=None, active_only=False, limit=1000) -> list[Market]:
        kwargs = {
            "platform": platform,
            "category": category,
            "limit": limit,
        }
        if active_only:
            kwargs["active_only"] = True
        return self._cache.get_markets(**kwargs)

    def get_markets_by_ids(self, market_ids: list[str], platform: str = "all") -> list[Market]:
        out = []
        for mid in market_ids:
            m = self._cache.get_market(mid)
            if m and (platform == "all" or m.platform.value == platform):
                out.append(m)
        return out

    def get_price_history(self, market_id, platform, start_ts, end_ts) -> list[PricePoint]:
        return self._cache.get_price_history(market_id, start_ts, end_ts, platform=platform)

    def get_latest_price(self, market_id, platform) -> PricePoint | None:
        return self._cache.get_latest_price(market_id, platform=platform)

    def get_orderbook(self, market_id, platform, timestamp) -> OrderBook | None:
        return self._ob_store.get_nearest(platform, market_id, timestamp)

    def get_provenance(self, market_id, platform) -> DataProvenance:
        return self._cache.get_provenance(market_id, platform)
