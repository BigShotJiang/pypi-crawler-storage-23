"""Multi-tool update checker for the Claude Code ecosystem."""

__version__ = "0.3.1"
