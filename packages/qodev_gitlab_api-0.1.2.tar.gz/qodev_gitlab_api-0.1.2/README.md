# qodev-gitlab-api

Python client for the GitLab API.

## Installation

```bash
pip install qodev-gitlab-api
```

## Usage

```python
from qodev_gitlab_api import GitLabClient

client = GitLabClient()
```
