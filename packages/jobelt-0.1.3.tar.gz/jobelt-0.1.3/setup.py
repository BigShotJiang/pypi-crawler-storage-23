from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="jobelt",
    version="0.1.3",
    description="Python ETL framework with Business Rule Validator for Databricks and PostgreSQL",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Complere Infosystem",
    author_email="puneet.taneja@complereinfosystem.com",
    packages=find_packages(exclude=["tests*", "build*", "dist*"]),
    include_package_data=True,
    install_requires=[
        "pandas>=1.3.0",
        "psycopg2-binary>=2.9.0",
        "sqlalchemy>=1.4.0",
        "pytz",
        "python-dotenv>=1.0.0",
        "retry>=0.9.2"
    ],
    extras_require={
        "databricks": ["databricks-sdk>=0.1.0"],
        "spark": ["pyspark>=3.0.0"]
    },
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "jobelt=jobelt.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
    ],
)