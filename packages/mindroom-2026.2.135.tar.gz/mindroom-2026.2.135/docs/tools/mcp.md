---
icon: lucide/plug
---

# MCP (Planned)

> [!WARNING]
> MindRoom does not currently support direct MCP server configuration in `config.yaml`.

MCP can still be used today through the plugin system by wrapping Agno `MCPTools` in a plugin tool factory.

See [Plugins](../plugins.md#mcp-via-plugins-advanced) for the current workaround and setup instructions.

This page remains as a compatibility pointer and will be expanded when native MCP support is added.
