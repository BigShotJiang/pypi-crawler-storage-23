"""
MCP Server for rapid-rag - Local RAG with semantic search and LLM queries.

Tools:
- rag_add: Add documents to a collection
- rag_search: Semantic search in a collection
- rag_query: RAG query with LLM answer
- rag_info: Get collection info
"""

import asyncio
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent


server = Server("rapid-rag")

# Cache RAG instances per collection
_rag_instances = {}


def get_rag(collection: str = "default"):
    """Get or create a RapidRAG instance for the collection."""
    if collection not in _rag_instances:
        from rapid_rag.core import RapidRAG
        _rag_instances[collection] = RapidRAG(collection)
    return _rag_instances[collection]


def get_tools() -> list[Tool]:
    """Return available tools."""
    return [
        Tool(
            name="rag_add",
            description="Add a file or directory to the RAG collection for semantic search. Supports .txt, .md, .pdf files.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to file or directory to add"
                    },
                    "collection": {
                        "type": "string",
                        "description": "Collection name (default: 'default')",
                        "default": "default"
                    },
                    "recursive": {
                        "type": "boolean",
                        "description": "Recursively add from directories (default: true)",
                        "default": True
                    },
                    "chunk_size": {
                        "type": "integer",
                        "description": "Characters per chunk (default: 1000)",
                        "default": 1000
                    }
                },
                "required": ["path"]
            }
        ),
        Tool(
            name="rag_add_text",
            description="Add raw text content directly to the RAG collection.",
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Text content to add"
                    },
                    "doc_id": {
                        "type": "string",
                        "description": "Document ID (auto-generated if not provided)"
                    },
                    "collection": {
                        "type": "string",
                        "description": "Collection name (default: 'default')",
                        "default": "default"
                    },
                    "source": {
                        "type": "string",
                        "description": "Optional source reference"
                    }
                },
                "required": ["text"]
            }
        ),
        Tool(
            name="rag_search",
            description="Semantic search in the RAG collection. Returns most relevant document chunks.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query"
                    },
                    "collection": {
                        "type": "string",
                        "description": "Collection name (default: 'default')",
                        "default": "default"
                    },
                    "num_results": {
                        "type": "integer",
                        "description": "Number of results to return (default: 5)",
                        "default": 5
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="rag_query",
            description="RAG query with LLM - searches documents and generates an AI answer based on the context. Requires Ollama running locally.",
            inputSchema={
                "type": "object",
                "properties": {
                    "question": {
                        "type": "string",
                        "description": "Question to answer based on documents"
                    },
                    "collection": {
                        "type": "string",
                        "description": "Collection name (default: 'default')",
                        "default": "default"
                    },
                    "model": {
                        "type": "string",
                        "description": "Ollama model to use (default: 'qwen2.5:7b')",
                        "default": "qwen2.5:7b"
                    },
                    "num_context": {
                        "type": "integer",
                        "description": "Number of context documents (default: 5)",
                        "default": 5
                    }
                },
                "required": ["question"]
            }
        ),
        Tool(
            name="rag_info",
            description="Get information about a RAG collection - document count, persist directory, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "collection": {
                        "type": "string",
                        "description": "Collection name (default: 'default')",
                        "default": "default"
                    }
                }
            }
        ),
        Tool(
            name="rag_list",
            description="List all available RAG collections.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="rag_clear",
            description="Clear all documents from a collection. Use with caution!",
            inputSchema={
                "type": "object",
                "properties": {
                    "collection": {
                        "type": "string",
                        "description": "Collection name to clear"
                    },
                    "confirm": {
                        "type": "boolean",
                        "description": "Must be true to confirm deletion"
                    }
                },
                "required": ["collection", "confirm"]
            }
        ),
    ]


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    return get_tools()


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""

    if name == "rag_add":
        return await handle_add(arguments)
    elif name == "rag_add_text":
        return await handle_add_text(arguments)
    elif name == "rag_search":
        return await handle_search(arguments)
    elif name == "rag_query":
        return await handle_query(arguments)
    elif name == "rag_info":
        return await handle_info(arguments)
    elif name == "rag_list":
        return await handle_list(arguments)
    elif name == "rag_clear":
        return await handle_clear(arguments)
    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def handle_add(args: dict[str, Any]) -> list[TextContent]:
    """Add file or directory to collection."""
    path = Path(args["path"]).expanduser().resolve()
    collection = args.get("collection", "default")
    recursive = args.get("recursive", True)
    chunk_size = args.get("chunk_size", 1000)

    if not path.exists():
        return [TextContent(type="text", text=f"Error: Path not found: {path}")]

    try:
        rag = get_rag(collection)

        if path.is_file():
            ids = rag.add_file(path, chunk_size=chunk_size)
            output = f"Added **{path.name}** to collection '{collection}'\n"
            output += f"- Chunks: {len(ids)}\n"
            output += f"- Total docs in collection: {rag.count()}"
        else:
            ids = rag.add_directory(path, recursive=recursive, chunk_size=chunk_size)
            output = f"Added directory **{path.name}** to collection '{collection}'\n"
            output += f"- Chunks: {len(ids)}\n"
            output += f"- Total docs in collection: {rag.count()}"

        return [TextContent(type="text", text=output)]

    except ImportError as e:
        return [TextContent(type="text", text=f"Error: rapid-rag not installed. Run: pip install rapid-rag\n{e}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error adding documents: {str(e)}")]


async def handle_add_text(args: dict[str, Any]) -> list[TextContent]:
    """Add raw text to collection."""
    text = args["text"]
    collection = args.get("collection", "default")
    doc_id = args.get("doc_id")
    source = args.get("source", "direct_input")

    try:
        rag = get_rag(collection)

        if doc_id:
            rag.add(doc_id, text, metadata={"source": source})
        else:
            doc_id = rag._generate_id(text)
            rag.add(doc_id, text, metadata={"source": source})

        output = f"Added text to collection '{collection}'\n"
        output += f"- Doc ID: {doc_id}\n"
        output += f"- Length: {len(text)} chars\n"
        output += f"- Total docs: {rag.count()}"

        return [TextContent(type="text", text=output)]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_search(args: dict[str, Any]) -> list[TextContent]:
    """Semantic search in collection."""
    query = args["query"]
    collection = args.get("collection", "default")
    num_results = args.get("num_results", 5)

    try:
        rag = get_rag(collection)

        if rag.count() == 0:
            return [TextContent(type="text", text=f"Collection '{collection}' is empty. Add documents first with rag_add.")]

        results = rag.search(query, n_results=num_results)

        if not results:
            return [TextContent(type="text", text="No results found.")]

        output = [f"# Search Results for: \"{query}\"\n"]
        output.append(f"Collection: {collection} | Found: {len(results)} results\n")

        for i, r in enumerate(results, 1):
            score = r["score"]
            source = r["metadata"].get("source", r["id"])
            # Truncate content for display
            content = r["content"][:500].replace("\n", " ").strip()
            if len(r["content"]) > 500:
                content += "..."

            output.append(f"\n## [{i}] {Path(source).name if '/' in source else source}")
            output.append(f"**Score:** {score:.3f}")
            output.append(f"```\n{content}\n```")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_query(args: dict[str, Any]) -> list[TextContent]:
    """RAG query with LLM answer."""
    question = args["question"]
    collection = args.get("collection", "default")
    model = args.get("model", "qwen2.5:7b")
    num_context = args.get("num_context", 5)

    try:
        rag = get_rag(collection)

        if rag.count() == 0:
            return [TextContent(type="text", text=f"Collection '{collection}' is empty. Add documents first.")]

        result = rag.query(question, n_results=num_context, model=model)

        output = [f"# RAG Answer\n"]
        output.append(f"**Question:** {question}\n")
        output.append(f"**Model:** {model}\n")
        output.append(f"\n## Answer\n")
        output.append(result["answer"])
        output.append(f"\n\n## Sources ({len(result['sources'])} documents)")

        for s in result["sources"]:
            source = s["metadata"].get("source", s["id"])
            name = Path(source).name if "/" in source else source
            output.append(f"- {name} (score: {s['score']:.3f})")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        error_msg = str(e)
        if "Connection refused" in error_msg or "11434" in error_msg:
            return [TextContent(type="text", text=f"Error: Ollama not running. Start Ollama first.\nOriginal error: {error_msg}")]
        return [TextContent(type="text", text=f"Error: {error_msg}")]


async def handle_info(args: dict[str, Any]) -> list[TextContent]:
    """Get collection info."""
    collection = args.get("collection", "default")

    try:
        rag = get_rag(collection)

        output = [
            f"# Collection: {collection}",
            f"",
            f"- **Documents:** {rag.count()}",
            f"- **Persist dir:** {rag.persist_dir}",
            f"- **Embedding model:** {rag.embedding_model}",
            f"- **Ollama URL:** {rag.ollama_url}",
        ]

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_list(args: dict[str, Any]) -> list[TextContent]:
    """List all collections."""
    try:
        from pathlib import Path
        import os

        base_dir = Path("./rapid_rag_data")
        if not base_dir.exists():
            return [TextContent(type="text", text="No collections found. Create one with rag_add.")]

        collections = []
        for item in base_dir.iterdir():
            if item.is_dir():
                # Try to get doc count
                try:
                    rag = get_rag(item.name)
                    count = rag.count()
                    collections.append(f"- **{item.name}**: {count} documents")
                except:
                    collections.append(f"- **{item.name}**: (unable to read)")

        if not collections:
            return [TextContent(type="text", text="No collections found.")]

        output = ["# RAG Collections\n"] + collections
        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_clear(args: dict[str, Any]) -> list[TextContent]:
    """Clear a collection."""
    collection = args["collection"]
    confirm = args.get("confirm", False)

    if not confirm:
        return [TextContent(type="text", text="Error: Set confirm=true to clear the collection.")]

    try:
        rag = get_rag(collection)
        count_before = rag.count()
        rag.clear()

        # Remove from cache
        if collection in _rag_instances:
            del _rag_instances[collection]

        return [TextContent(type="text", text=f"Cleared collection '{collection}' ({count_before} documents removed).")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


def main():
    """Run the MCP server."""
    asyncio.run(run_server())


async def run_server():
    """Run the server with stdio transport."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    main()
