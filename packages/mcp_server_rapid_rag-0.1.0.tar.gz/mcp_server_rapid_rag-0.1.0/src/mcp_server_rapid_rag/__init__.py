"""MCP Server for rapid-rag - Local RAG with semantic search and LLM queries."""
__version__ = "0.1.0"
