"""
Version Management
=====================
"""


__version__ = "1.6.92"

EP_VERSION = "24-2-0"
