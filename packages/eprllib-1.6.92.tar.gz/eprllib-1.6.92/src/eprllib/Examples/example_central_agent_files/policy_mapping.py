"""
Observation Functions
======================


"""
def policy_map_fn(agent_id, episode, worker, **kwargs):
    return "single_policy"
