eprllib.Utils.env\_utils
========================

.. automodule:: eprllib.Utils.env_utils

   
   .. rubric:: Functions

   .. autosummary::
   
      calculate_occupancy
      calculate_occupancy_forecast
   