eprllib.Utils.filter\_utils
===========================

.. automodule:: eprllib.Utils.filter_utils

   
   .. rubric:: Functions

   .. autosummary::
   
      desnormalization_minmax
      normalization_minmax
      to_sin_transformation
   