eprllib.PostProcess.Evaluation
==============================

.. automodule:: eprllib.PostProcess.Evaluation

   
   .. rubric:: Functions

   .. autosummary::
   
      generate_experience
      generate_experience_V2
   