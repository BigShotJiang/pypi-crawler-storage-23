"""Tests for CLI commands (install, uninstall, status, login, logout).

Uses Click's CliRunner with mocked BrokerClient and config functions.
All imports in main.py are lazy (inside function bodies), so patches target
the *source* modules, not ``specter_cli.main``.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from specter_cli.main import cli


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


# ---------------------------------------------------------------------------
# Shared patch helpers
# ---------------------------------------------------------------------------

_BROKER_CLIENT = "specter_cli.broker_client.BrokerClient"
_BROKER_URL = "specter_cli.broker_client.get_broker_url"
_REQUIRE_AUTH = "specter_cli.auth.require_auth"
_READ_SSH_KEY = "specter_cli.auth.read_ssh_public_key"
_HAS_SESSION = "specter_cli.config.has_active_session"
_SAVE_CONFIG = "specter_cli.config.save_remote_config"
_LOAD_CONFIG = "specter_cli.config.load_remote_config"
_CLEAR_CONFIG = "specter_cli.config.clear_remote_config"
_DETECT_VENV = "specter_cli.venv.detect_venv"
_PATCH_VENV = "specter_cli.venv.patch_venv"
_RESTORE_VENV = "specter_cli.venv.restore_venv"
_SYNC_DEPS = "specter_cli.deps.sync_deps"
_CHECK_PY_VERSION = "specter_cli.deps.check_python_version"
_CREATE_REMOTE_VENV = "specter_cli.deps.create_remote_venv"
_TIME_SLEEP = "time.sleep"

# Fake venv path returned by detect_venv in install tests.
_FAKE_VENV = Path("/home/user/project/.venv")


# ---------------------------------------------------------------------------
# install — happy path
# ---------------------------------------------------------------------------


class TestInstallHappyPath:
    """specter install <gpu> — provision succeeds, session reaches ready."""

    @patch(_TIME_SLEEP)
    @patch(_SYNC_DEPS, return_value=True)
    @patch(_CHECK_PY_VERSION, return_value=("3.12", "3.12"))
    @patch(_CREATE_REMOTE_VENV, return_value="~/.specter/venv")
    @patch(_PATCH_VENV)
    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_SAVE_CONFIG)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_READ_SSH_KEY, return_value="ssh-ed25519 AAAA test")
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_provisions_and_saves_config(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        _ssh_key: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        mock_save_config: MagicMock,
        _detect_venv: MagicMock,
        _patch_venv: MagicMock,
        _create_remote_venv: MagicMock,
        _check_py_version: MagicMock,
        mock_sync_deps: MagicMock,
        _sleep: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.provision.return_value = {
            "session_id": "sess_abc123",
            "status": "provisioning",
        }
        # First poll: provisioning, second: ready.
        client.get_session.side_effect = [
            {"status": "provisioning"},
            {
                "status": "ready",
                "ssh": {"host": "1.2.3.4", "port": 22, "user": "root"},
                "gpu_name": "NVIDIA GeForce RTX 5090",
            },
        ]

        result = runner.invoke(cli, ["install", "5090"])

        assert result.exit_code == 0, result.output
        assert "5090 GPU ready" in result.output
        assert "Virtual env detected" in result.output
        assert "Dependencies synced" in result.output

        # Verify provision was called correctly.
        client.provision.assert_called_once_with(
            gpu_type="5090",
            ssh_public_key="ssh-ed25519 AAAA test",
            gpu_count=1,
            disk_gb=20,
            image=None,
        )

        # Verify config was saved with venv_path, python versions, and remote_venv.
        mock_save_config.assert_called_once_with(
            host="1.2.3.4",
            user="root",
            ssh_port=22,
            session_id="sess_abc123",
            gpu_type="5090",
            venv_path=str(_FAKE_VENV),
            python_local="3.12",
            python_remote="3.12",
            remote_venv="~/.specter/venv",
        )

        # Verify deps were synced.
        mock_sync_deps.assert_called_once_with(
            _FAKE_VENV,
            host="1.2.3.4",
            user="root",
            port=22,
        )

        # Verify client was closed.
        client.close.assert_called_once()

    @patch(_TIME_SLEEP)
    @patch(_SYNC_DEPS, return_value=True)
    @patch(_CHECK_PY_VERSION, return_value=("3.12", "3.12"))
    @patch(_CREATE_REMOTE_VENV, return_value="~/.specter/venv")
    @patch(_PATCH_VENV)
    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_SAVE_CONFIG)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_READ_SSH_KEY, return_value="ssh-ed25519 AAAA test")
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_with_custom_options(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        _ssh_key: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        mock_save_config: MagicMock,
        _detect_venv: MagicMock,
        _patch_venv: MagicMock,
        _create_remote_venv: MagicMock,
        _check_py_version: MagicMock,
        _sync_deps: MagicMock,
        _sleep: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.provision.return_value = {"session_id": "sess_xyz", "status": "provisioning"}
        client.get_session.return_value = {
            "status": "ready",
            "ssh": {"host": "5.6.7.8", "port": 43237, "user": "root"},
        }

        result = runner.invoke(
            cli,
            ["install", "h100", "--gpu-count", "2", "--disk", "50", "--image", "custom:latest"],
        )

        assert result.exit_code == 0, result.output

        client.provision.assert_called_once_with(
            gpu_type="h100",
            ssh_public_key="ssh-ed25519 AAAA test",
            gpu_count=2,
            disk_gb=50,
            image="custom:latest",
        )

        mock_save_config.assert_called_once_with(
            host="5.6.7.8",
            user="root",
            ssh_port=43237,
            session_id="sess_xyz",
            gpu_type="h100",
            venv_path=str(_FAKE_VENV),
            python_local="3.12",
            python_remote="3.12",
            remote_venv="~/.specter/venv",
        )

    @patch(_TIME_SLEEP)
    @patch(_SYNC_DEPS, return_value=True)
    @patch(_CHECK_PY_VERSION, return_value=("3.12", "3.12"))
    @patch(_CREATE_REMOTE_VENV, return_value="~/.specter/venv")
    @patch(_PATCH_VENV)
    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_SAVE_CONFIG)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_READ_SSH_KEY, return_value="ssh-ed25519 AAAA test")
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_polls_multiple_times(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        _ssh_key: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        _save_config: MagicMock,
        _detect_venv: MagicMock,
        _patch_venv: MagicMock,
        _create_remote_venv: MagicMock,
        _check_py_version: MagicMock,
        _sync_deps: MagicMock,
        _sleep: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.provision.return_value = {"session_id": "sess_poll", "status": "provisioning"}
        # Simulate 5 polls before ready.
        client.get_session.side_effect = [
            {"status": "provisioning"},
            {"status": "provisioning"},
            {"status": "provisioning"},
            {"status": "provisioning"},
            {
                "status": "ready",
                "ssh": {"host": "10.0.0.1", "port": 22, "user": "root"},
            },
        ]

        result = runner.invoke(cli, ["install", "4090"])

        assert result.exit_code == 0, result.output
        assert client.get_session.call_count == 5


# ---------------------------------------------------------------------------
# install — error path
# ---------------------------------------------------------------------------


class TestInstallErrorPath:
    """specter install <gpu> — provisioning fails."""

    @patch(_DETECT_VENV, return_value=None)
    def test_install_no_venv_exits(
        self,
        _detect_venv: MagicMock,
        runner: CliRunner,
    ) -> None:
        result = runner.invoke(cli, ["install", "5090"])

        assert result.exit_code == 1
        assert "No active virtual environment" in result.output

    @patch(_TIME_SLEEP)
    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_READ_SSH_KEY, return_value="ssh-ed25519 AAAA test")
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_error_shows_message_and_exits(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        _ssh_key: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        _detect_venv: MagicMock,
        _sleep: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.provision.return_value = {"session_id": "sess_fail", "status": "provisioning"}
        client.get_session.return_value = {
            "status": "error",
            "error_message": "Failed to get pod with public IP after 3 attempts",
        }

        result = runner.invoke(cli, ["install", "5090"])

        assert result.exit_code == 1
        assert "Provisioning failed" in result.output
        assert "Failed to get pod with public IP" in result.output
        client.close.assert_called_once()

    @patch(_TIME_SLEEP)
    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_READ_SSH_KEY, return_value="ssh-ed25519 AAAA test")
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_error_with_no_message(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        _ssh_key: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        _detect_venv: MagicMock,
        _sleep: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.provision.return_value = {"session_id": "sess_fail2", "status": "provisioning"}
        client.get_session.return_value = {"status": "error"}

        result = runner.invoke(cli, ["install", "a100"])

        assert result.exit_code == 1
        assert "unknown error" in result.output

    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_READ_SSH_KEY, return_value="ssh-ed25519 AAAA test")
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_broker_error_shows_message(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        _ssh_key: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        _detect_venv: MagicMock,
        runner: CliRunner,
    ) -> None:
        from specter_cli.broker_client import BrokerError

        client = mock_broker_cls.return_value
        client.provision.side_effect = BrokerError(
            400, "invalid_gpu_type", "Unknown GPU type 'fake'"
        )

        result = runner.invoke(cli, ["install", "fake"])

        assert result.exit_code == 1
        assert "Broker error" in result.output
        client.close.assert_called_once()

    @patch(_TIME_SLEEP)
    @patch(_CHECK_PY_VERSION, return_value=("3.12", "3.12"))
    @patch(_CREATE_REMOTE_VENV, side_effect=Exception("SSH connection refused"))
    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_SAVE_CONFIG)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_READ_SSH_KEY, return_value="ssh-ed25519 AAAA test")
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_venv_creation_failure_exits(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        _ssh_key: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        _save_config: MagicMock,
        _detect_venv: MagicMock,
        _create_remote_venv: MagicMock,
        _check_py_version: MagicMock,
        _sleep: MagicMock,
        runner: CliRunner,
    ) -> None:
        """create_remote_venv failure should abort install (hard fatal)."""
        client = mock_broker_cls.return_value
        client.provision.return_value = {"session_id": "sess_venv_fail", "status": "provisioning"}
        client.get_session.return_value = {
            "status": "ready",
            "ssh": {"host": "1.2.3.4", "port": 22, "user": "root"},
        }

        result = runner.invoke(cli, ["install", "h100"])

        assert result.exit_code == 1
        assert "Failed to create remote venv" in result.output

    @patch(_DETECT_VENV, return_value=_FAKE_VENV)
    @patch(_READ_SSH_KEY)
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(_HAS_SESSION, return_value=False)
    def test_install_no_ssh_key_exits(
        self,
        _has_session: MagicMock,
        _auth: MagicMock,
        mock_ssh_key: MagicMock,
        _detect_venv: MagicMock,
        runner: CliRunner,
    ) -> None:
        mock_ssh_key.side_effect = FileNotFoundError("No SSH public key found")

        result = runner.invoke(cli, ["install", "5090"])

        assert result.exit_code == 1
        assert "No SSH public key found" in result.output


# ---------------------------------------------------------------------------
# uninstall
# ---------------------------------------------------------------------------


class TestUninstallCommand:
    """specter uninstall — tear down active session."""

    @patch(_RESTORE_VENV, return_value=True)
    @patch(_CLEAR_CONFIG)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(
        _LOAD_CONFIG,
        return_value={
            "session_id": "sess_active",
            "gpu_type": "5090",
            "host": "1.2.3.4",
            "venv_path": "/home/user/project/.venv",
        },
    )
    def test_uninstall_tears_down_and_cleans_up(
        self,
        _config: MagicMock,
        _auth: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        mock_clear_config: MagicMock,
        mock_restore_venv: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.destroy_session.return_value = {"session_id": "sess_active", "status": "terminated"}

        result = runner.invoke(cli, ["uninstall"])

        assert result.exit_code == 0, result.output
        assert "terminated" in result.output
        assert "Restored venv" in result.output
        client.destroy_session.assert_called_once_with("sess_active")
        mock_clear_config.assert_called_once()
        mock_restore_venv.assert_called_once_with(Path("/home/user/project/.venv"))
        client.close.assert_called_once()

    @patch(_LOAD_CONFIG, return_value={})
    def test_uninstall_no_active_session(self, _config: MagicMock, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["uninstall"])

        assert result.exit_code == 0
        assert "No active session" in result.output

    @patch(_CLEAR_CONFIG)
    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(
        _LOAD_CONFIG,
        return_value={
            "session_id": "sess_fail",
            "gpu_type": "a100",
            "host": "1.2.3.4",
            "venv_path": "/home/user/project/.venv",
        },
    )
    def test_uninstall_broker_error(
        self,
        _config: MagicMock,
        _auth: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        _clear_config: MagicMock,
        runner: CliRunner,
    ) -> None:
        from specter_cli.broker_client import BrokerError

        client = mock_broker_cls.return_value
        client.destroy_session.side_effect = BrokerError(404, "not_found", "Unknown session")

        result = runner.invoke(cli, ["uninstall"])

        assert result.exit_code == 1
        assert "Broker error" in result.output


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


class TestStatusCommand:
    """specter status — show session info."""

    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(
        _LOAD_CONFIG,
        return_value={"session_id": "sess_status", "host": "1.2.3.4"},
    )
    def test_status_shows_session_info(
        self,
        _config: MagicMock,
        _auth: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.get_session.return_value = {
            "session_id": "sess_status",
            "status": "ready",
            "gpu_type": "5090",
            "gpu_name": "NVIDIA GeForce RTX 5090",
            "provider": "runpod",
            "ssh": {"host": "1.2.3.4", "port": 43237, "user": "root"},
            "created_at": "2026-03-06T07:00:00Z",
        }

        result = runner.invoke(cli, ["status"])

        assert result.exit_code == 0, result.output
        assert "sess_status" in result.output
        assert "ready" in result.output
        assert "5090" in result.output
        assert "1.2.3.4" in result.output
        assert "43237" in result.output
        client.close.assert_called_once()

    @patch(_LOAD_CONFIG, return_value={})
    def test_status_no_active_session(self, _config: MagicMock, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["status"])

        assert result.exit_code == 0
        assert "No active session" in result.output

    @patch(_BROKER_URL, return_value="http://test-broker")
    @patch(_BROKER_CLIENT)
    @patch(_REQUIRE_AUTH, return_value="sk-test-1234")
    @patch(
        _LOAD_CONFIG,
        return_value={"session_id": "sess_no_ssh", "host": "1.2.3.4"},
    )
    def test_status_provisioning_no_ssh(
        self,
        _config: MagicMock,
        _auth: MagicMock,
        mock_broker_cls: MagicMock,
        _broker_url: MagicMock,
        runner: CliRunner,
    ) -> None:
        client = mock_broker_cls.return_value
        client.get_session.return_value = {
            "session_id": "sess_no_ssh",
            "status": "provisioning",
            "gpu_type": "4090",
            "provider": "runpod",
            "created_at": "2026-03-06T07:00:00Z",
        }

        result = runner.invoke(cli, ["status"])

        assert result.exit_code == 0, result.output
        assert "provisioning" in result.output
        # SSH info should not appear.
        assert "SSH Host" not in result.output


# ---------------------------------------------------------------------------
# login / logout
# ---------------------------------------------------------------------------


class TestLoginLogout:
    """specter login / logout commands."""

    @patch("specter_cli.auth.login_with_browser")
    def test_login_calls_browser_flow(self, mock_login: MagicMock, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["login"])

        assert result.exit_code == 0, result.output
        mock_login.assert_called_once()

    @patch("specter_cli.auth.login_with_browser", side_effect=Exception("auth failed"))
    def test_login_no_key_flag(self, mock_login: MagicMock, runner: CliRunner) -> None:
        """--key flag should not exist anymore."""
        result = runner.invoke(cli, ["login", "--key", "sk-test"])
        # Click should reject the unknown option
        assert result.exit_code != 0

    @patch("specter_cli.auth.logout")
    def test_logout(self, mock_logout: MagicMock, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["logout"])

        assert result.exit_code == 0, result.output
        mock_logout.assert_called_once()
