"""Tests for specter_cli.config — local configuration management."""

from __future__ import annotations

import json

import pytest

from specter_cli.config import (
    clear_auth,
    clear_remote_config,
    get_token,
    has_active_session,
    load_auth,
    load_remote_config,
    save_auth,
    save_remote_config,
)


@pytest.fixture(autouse=True)
def _isolated_config(tmp_path, monkeypatch):
    """Redirect all config files to a temp directory via SPECTER_HOME."""
    sd = tmp_path / ".specter"
    sd.mkdir()
    monkeypatch.setenv("SPECTER_HOME", str(sd))


class TestAuth:
    def test_no_auth_returns_empty(self):
        assert load_auth() == {}

    def test_get_token_returns_none_when_not_logged_in(self):
        assert get_token() is None

    def test_save_and_load_auth(self):
        save_auth("sk-test123")
        auth = load_auth()
        assert auth["token"] == "sk-test123"
        assert get_token() == "sk-test123"

    def test_save_auth_with_extras(self):
        save_auth("sk-test123", method="api_key", email="test@example.com")
        auth = load_auth()
        assert auth["token"] == "sk-test123"
        assert auth["method"] == "api_key"
        assert auth["email"] == "test@example.com"

    def test_clear_auth(self):
        save_auth("sk-test123")
        assert get_token() == "sk-test123"
        clear_auth()
        assert get_token() is None

    def test_clear_auth_when_no_auth(self):
        # Should not raise.
        clear_auth()

    def test_corrupted_auth_file(self):
        from specter_cli.config import auth_file

        auth_file().write_text("not json{{{")
        assert load_auth() == {}


class TestRemoteConfig:
    def test_no_config_returns_empty(self):
        assert load_remote_config() == {}

    def test_save_and_load_remote_config(self):
        save_remote_config(
            host="10.0.0.1",
            user="root",
            ssh_port=22,
            session_id="sess_abc",
            gpu_type="h100",
        )
        config = load_remote_config()
        assert config["host"] == "10.0.0.1"
        assert config["user"] == "root"
        assert config["ssh_port"] == 22
        assert config["session_id"] == "sess_abc"
        assert config["gpu_type"] == "h100"
        assert config["workspace"] == "~/.specter/workspace"

    def test_clear_remote_config(self):
        save_remote_config(
            host="10.0.0.1",
            user="root",
            session_id="sess_abc",
            gpu_type="h100",
        )
        assert load_remote_config() != {}
        clear_remote_config()
        assert load_remote_config() == {}

    def test_has_active_session(self):
        assert not has_active_session()
        save_remote_config(
            host="10.0.0.1",
            user="root",
            session_id="sess_abc",
            gpu_type="h100",
        )
        assert has_active_session()

    def test_has_active_session_missing_fields(self):
        from specter_cli.config import remote_file

        # Write config missing session_id.
        remote_file().write_text(json.dumps({"host": "10.0.0.1"}))
        assert not has_active_session()
