"""Workspace detection and sync for Specter.

Detects the project root (git repo, pyproject.toml, etc.) and syncs it
to the remote machine via rsync before execution.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

log = logging.getLogger(__name__)

# Markers that indicate a project root (checked in order).
_PROJECT_MARKERS = [
    ".git",
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "Makefile",
    "requirements.txt",
    ".specter.toml",
]

# Default excludes for rsync — large dirs that shouldn't be synced.
_DEFAULT_EXCLUDES = [
    ".git",
    "__pycache__",
    "*.pyc",
    ".venv",
    "venv",
    "env",
    "node_modules",
    ".tox",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "*.egg-info",
    "dist",
    "build",
    ".specter",
]


def find_project_root(start: Path | None = None) -> Path:
    """Walk up from *start* (default: cwd) to find the project root.

    Returns the directory containing the nearest project marker, or
    *start* itself if no marker is found.
    """
    current = (start or Path.cwd()).resolve()

    # Don't walk above home directory.
    home = Path.home()

    while True:
        for marker in _PROJECT_MARKERS:
            if (current / marker).exists():
                log.debug("project root: %s (found %s)", current, marker)
                return current
        parent = current.parent
        if parent == current or current == home:
            break
        current = parent

    # No marker found — use the starting directory.
    fallback = (start or Path.cwd()).resolve()
    log.debug("project root: %s (no marker found, using cwd)", fallback)
    return fallback


def load_specterignore(project_root: Path) -> list[str]:
    """Load additional exclude patterns from .specterignore if it exists.

    File format: one pattern per line, empty lines and #comments ignored.
    Patterns are rsync-compatible.
    """
    ignore_file = project_root / ".specterignore"
    if not ignore_file.is_file():
        return []

    patterns: list[str] = []
    for line in ignore_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            patterns.append(line)
    return patterns


def rsync_workspace(
    project_root: Path,
    rsync_ssh: str,
    remote_dest: str,
    remote_workspace: str = "~/.specter/workspace",
    *,
    delete: bool = True,
    extra_excludes: list[str] | None = None,
    timeout: int = 120,
) -> subprocess.CompletedProcess[str]:
    """Sync the project directory to the remote machine.

    Parameters
    ----------
    project_root:
        Local project root directory.
    rsync_ssh:
        Pre-built SSH command string for rsync's ``-e`` flag.
        Use :func:`specter_cli.ssh_config.rsync_ssh_args` to build this.
    remote_dest:
        SSH destination, e.g. "user@host".
    remote_workspace:
        Remote directory to sync into.
    delete:
        Remove extraneous files on remote.
    extra_excludes:
        Additional rsync exclude patterns.
    timeout:
        Seconds before killing rsync.

    Returns
    -------
    subprocess.CompletedProcess with stdout/stderr.

    Raises
    ------
    subprocess.CalledProcessError if rsync fails.
    """
    local_path = str(project_root).rstrip("/") + "/"

    excludes = _DEFAULT_EXCLUDES.copy()
    excludes.extend(load_specterignore(project_root))
    if extra_excludes:
        excludes.extend(extra_excludes)

    args = [
        "rsync",
        "-az",  # archive + compress
        "--info=stats1",  # summary stats only (not per-file noise)
        "-e",
        rsync_ssh,
    ]
    if delete:
        args.append("--delete")
    for pattern in excludes:
        args.extend(["--exclude", pattern])
    args.extend([local_path, f"{remote_dest}:{remote_workspace}/"])

    log.debug("rsync: %s", " ".join(args))
    result = subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if result.returncode != 0:
        log.error("rsync failed (exit %d): %s", result.returncode, result.stderr)
        raise subprocess.CalledProcessError(result.returncode, args, result.stdout, result.stderr)
    return result
