<div align="center">
  <img src="docs/banner.svg" alt="OpenSquad" width="720" />
</div>

<br>

OpenSquad is a local-first multi-agent collaboration framework. Multiple autonomous agents (PM, Coder, QA, etc.) communicate via group chat and coordinate through Blueprint-driven workflows, with a shared file workspace for cross-agent visibility.

---

## Key Features

- **Blueprint-Driven Collaboration**: Structured workflow protocols define role responsibilities, phase transitions, and communication rules. See `blueprints/software_dev/BLUEPRINT.md`.
- **Task Board + Auto-Sync**: Each agent maintains a personal Task Board (injected into their prompt). Changes are automatically synced to `workspace/collab/{agent_id}_tasks.md` for PM visibility.
- **Plugin Architecture**: Decorator-based plugin system supporting tool plugins, lifecycle hooks, platform adapters (Telegram, Feishu), and web dashboards.
- **Dynamic Skills**: Agents can hot-load skill packs at runtime from `skills/` directories.
- **Multi-Channel Access**: Web UI (React + WebSocket), Telegram bot, Feishu bot, External HTTP API.
- **MCP Support**: Dynamic MCP server management — agents can add/remove MCP servers at runtime.

---

## Quick Start

### Prerequisites
- Python 3.9+
- Node.js 18+ (for frontend)
- A compatible LLM API endpoint (GLM-4, DeepSeek, GPT-4, Claude, etc.)

### Installation
```bash
pip install -r requirements.txt
cd gateway/nexuschat-pro && npm install
```

### Configuration

Edit the system config file to set your LLM API keys, model selection, and service options. Each agent has its own config for independent model and tool assignments.

### Start All Services
```bash
scripts\start_all.bat
```

### Access
Open the Web UI in your browser after services are running. The URL is shown in your `system_config.json`.

---

## Documentation

| Document | Description |
|----------|-------------|
| [Architecture](docs/ARCHITECTURE.md) | System architecture, module responsibilities, data flow |
| [Collaboration](docs/COLLABORATION.md) | Multi-agent collaboration mechanism (Blueprint, TaskBoard, Auto-Sync) |
| [Plugin Development](docs/PLUGIN_DEVELOPMENT.md) | How to write plugins (tools, hooks, adapters) |
| [Agent Setup](docs/agent_setup.md) | Agent configuration and tag system |
| [Group Chat](docs/group_chat_agent.md) | Group chat integration guide |
| [MCP Guide](docs/MCP_DYNAMIC_SETUP.md) | Dynamic MCP server management |
| [Deployment](docs/multi_server_deployment.md) | Multi-server deployment guide |
| [Whisper](docs/WHISPER_GUIDE.md) | Speech-to-text service setup |

---

*Powered by OpenSquad Core*
