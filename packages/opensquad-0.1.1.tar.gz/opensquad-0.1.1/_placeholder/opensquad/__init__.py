# -*- coding: utf-8 -*-
"""
OpenSquad - Local-first Multi-Agent Collaboration Framework

Coming soon. https://github.com/opensquad/opensquad
"""

__version__ = "0.1.1"
__author__ = "OpenSquad Contributors"
