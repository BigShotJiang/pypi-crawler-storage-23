"""Package data for optiroulette."""

