"""Compatibility alias for users importing with capitalized module name."""

from optiroulette import *  # noqa: F401,F403

