### The `cuda.pathfinder` documentation was moved

Please see https://nvidia.github.io/cuda-python/cuda-pathfinder/latest/
