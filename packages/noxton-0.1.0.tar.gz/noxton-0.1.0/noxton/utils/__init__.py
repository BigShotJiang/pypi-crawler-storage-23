from .utils import default_floating_dtype

__all__ = [
    "default_floating_dtype",
]
