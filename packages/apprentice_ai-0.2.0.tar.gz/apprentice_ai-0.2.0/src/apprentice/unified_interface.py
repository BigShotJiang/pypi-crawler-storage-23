"""
Unified Interface composition - wires apprentice_class and cli together.

This module re-exports all types and functions from both child components
and provides the unified entry points. It bridges differences between the
child implementations (lowercase enums, sync/async mismatches) and the
contract test expectations (uppercase enums, proper async handling).
"""

import asyncio
import json
import logging
import signal
import sys
import uuid
import time
from datetime import datetime, timezone
from enum import Enum, IntEnum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, ConfigDict, model_validator
import yaml

# Import from child modules via relative imports (intra-package)
from . import apprentice_class
from . import cli as _cli_mod
from .cli_models import (
    BudgetInfo,
    GlobalFlags,
    InputData,
    PhaseInfo,
    ReportArgs,
    ReportResult,
    RunArgs,
    RunResult,
    StatusArgs,
    StatusResult,
    TaskStatusEntry,
    CLIResult,
)

# ---------------------------------------------------------------------------
# Wrapper enums with UPPERCASE member names (contract tests expect uppercase)
# ---------------------------------------------------------------------------

class ModelSource(str, Enum):
    """Which model backend produced a response."""
    LOCAL = "local"
    REMOTE = "remote"


class PhaseLabel(str, Enum):
    """Human-readable phase label derived from confidence score thresholds."""
    BOOTSTRAPPING = "bootstrapping"
    ACTIVE_LEARNING = "active_learning"
    SUPERVISED = "supervised"
    AUTONOMOUS = "autonomous"


class RunStatus(str, Enum):
    """Outcome status of a single run() invocation."""
    SUCCESS = "success"
    DEGRADED = "degraded"
    ERROR = "error"


class ErrorKind(str, Enum):
    """Categorized error kinds for structured error reporting."""
    BUDGET_EXHAUSTED = "budget_exhausted"
    TASK_NOT_FOUND = "task_not_found"
    LOCAL_MODEL_UNAVAILABLE = "local_model_unavailable"
    INTERNAL = "internal"


class ExitCode(IntEnum):
    """Process exit codes. IntEnum so isinstance(v, int) is True."""
    SUCCESS_0 = 0
    APP_ERROR_1 = 1
    USAGE_ERROR_2 = 2
    KEYBOARD_INTERRUPT_130 = 130


class SubcommandName(str, Enum):
    """CLI subcommands with UPPERCASE member names."""
    RUN = "run"
    STATUS = "status"
    REPORT = "report"


class OutputFormat(str, Enum):
    HUMAN = "HUMAN"
    JSON = "JSON"


class LogLevel(str, Enum):
    WARNING = "WARNING"
    INFO = "INFO"
    DEBUG = "DEBUG"


class ParsedArgs(BaseModel):
    """Parsed CLI args using our uppercase SubcommandName."""
    model_config = ConfigDict(strict=True)
    global_flags: GlobalFlags
    command: SubcommandName
    run_args: Optional[RunArgs] = None
    status_args: Optional[StatusArgs] = None
    report_args: Optional[ReportArgs] = None


# ---------------------------------------------------------------------------
# Re-export types from apprentice_class
# ---------------------------------------------------------------------------

ApprenticeError = apprentice_class.ApprenticeError
BudgetExhaustedError = apprentice_class.BudgetExhaustedError
LocalModelUnavailableError = apprentice_class.LocalModelUnavailableError
RunContext = apprentice_class.RunContext
TaskNotFoundError = apprentice_class.TaskNotFoundError


# ---------------------------------------------------------------------------
# Redefine Pydantic models to use OUR enums (uppercase) instead of child's
# ---------------------------------------------------------------------------

class ResponseMetadata(BaseModel):
    """Audit-transparency metadata attached to every TaskResponse."""
    model_config = ConfigDict(frozen=True)

    model_id: str
    cost_usd: float = Field(ge=0.0)
    retries: int
    fallback_used: bool
    timestamp_utc: str


class TaskResponse(BaseModel):
    """Frozen Pydantic model returned from run() - uses our enums."""
    model_config = ConfigDict(frozen=True)

    task_name: str
    output: Dict[str, Any]
    source: ModelSource
    status: RunStatus
    request_id: str
    duration_ms: float
    metadata: ResponseMetadata


class ConfidenceSnapshot(BaseModel):
    """Point-in-time view of a task's confidence state - uses our enums."""
    model_config = ConfigDict(frozen=True)

    task_name: str
    confidence_score: float = Field(ge=0.0, le=1.0)
    phase: PhaseLabel
    sampling_rate: float = Field(ge=0.0, le=1.0)
    budget_remaining_usd: float
    budget_used_usd: float
    budget_exhausted: bool
    local_model_available: bool
    total_runs: int
    timestamp_utc: str


class SystemReport(BaseModel):
    """Comprehensive system-wide report - uses our enums."""
    model_config = ConfigDict(frozen=True)

    task_snapshots: List[ConfidenceSnapshot]
    global_budget_used_usd: float
    global_budget_remaining_usd: float
    total_runs: int
    total_local_runs: int
    total_remote_runs: int
    total_fallbacks: int
    total_errors: int
    uptime_seconds: float
    timestamp_utc: str


# ---------------------------------------------------------------------------
# Config wrappers (ConfidenceThresholds, TaskConfig, ApprenticeConfig)
# ---------------------------------------------------------------------------

class ConfidenceThresholds(BaseModel):
    """Confidence score thresholds - wrapper with relaxed validation."""
    model_config = ConfigDict(frozen=True, extra='forbid')

    bootstrapping_upper: float = Field(ge=0.0, le=1.0)
    active_learning_upper: float = Field(ge=0.0, le=1.0)
    supervised_upper: float = Field(ge=0.0, le=1.0)
    autonomous_lower: float = Field(ge=0.0, le=1.0)

    @model_validator(mode='after')
    def validate_threshold_ordering(self):
        if not (self.bootstrapping_upper < self.active_learning_upper <
                self.supervised_upper <= self.autonomous_lower):
            raise ValueError(
                "Thresholds must satisfy: bootstrapping_upper < active_learning_upper < "
                "supervised_upper <= autonomous_lower"
            )
        return self

    def to_child_thresholds(self):
        supervised = self.supervised_upper
        autonomous = self.autonomous_lower
        if supervised == autonomous:
            supervised = supervised - 0.0001
        return apprentice_class.ConfidenceThresholds(
            bootstrapping_upper=self.bootstrapping_upper,
            active_learning_upper=self.active_learning_upper,
            supervised_upper=supervised,
            autonomous_lower=autonomous,
        )


class TaskConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra='forbid')

    task_name: str = Field(pattern=r'^[a-z][a-z0-9_]{1,62}[a-z0-9]$')
    remote_model_id: str
    local_model_id: Optional[str] = None
    budget_limit_usd: float = Field(ge=0.0)
    budget_period_days: int = Field(ge=1, le=365)
    confidence_thresholds: ConfidenceThresholds

    def to_child_task_config(self):
        return apprentice_class.TaskConfig(
            task_name=self.task_name,
            remote_model_id=self.remote_model_id,
            local_model_id=self.local_model_id,
            budget_limit_usd=self.budget_limit_usd,
            budget_period_days=self.budget_period_days,
            confidence_thresholds=self.confidence_thresholds.to_child_thresholds(),
        )


class ApprenticeConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra='forbid')

    schema_version: int = Field(default=1, ge=1, le=1)
    tasks: List[TaskConfig]
    remote_api_base_url: str
    local_model_endpoint: Optional[str] = None
    budget_enforcement: apprentice_class.BudgetEnforcementConfig
    audit_log_path: str
    retry_max_attempts: int = Field(ge=1, le=10)
    retry_backoff_base_seconds: float = Field(ge=0.1, le=30.0)

    def to_child_config(self):
        child_tasks = [task.to_child_task_config() for task in self.tasks]
        return apprentice_class.ApprenticeConfig(
            tasks=child_tasks,
            remote_api_base_url=self.remote_api_base_url,
            local_model_endpoint=self.local_model_endpoint,
            budget_enforcement=self.budget_enforcement,
            audit_log_path=self.audit_log_path,
            retry_max_attempts=self.retry_max_attempts,
            retry_backoff_base_seconds=self.retry_backoff_base_seconds,
        )


# ---------------------------------------------------------------------------
# load_config
# ---------------------------------------------------------------------------

def load_config(path):
    """Load and validate YAML config file into our ApprenticeConfig."""
    if not path:
        raise ValueError("Config path cannot be empty")

    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    try:
        with open(config_path, "r") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in config file: {path}") from e

    if not isinstance(data, dict):
        raise ValueError("Config must be a YAML object")
    if not data:
        raise ValueError("Config cannot be empty")

    try:
        return ApprenticeConfig(**data)
    except Exception as e:
        raise ValueError(f"Config validation failed: {e}") from e


# ---------------------------------------------------------------------------
# Apprentice class (glue layer handling async properly)
# ---------------------------------------------------------------------------

class Apprentice:
    """
    Unified Apprentice class. Implements the full run/status/report API
    directly so that async mock components (AsyncMock) work correctly.
    The child apprentice_class.Apprentice calls router.route() without await,
    so we must re-implement the core methods here to properly await AsyncMocks.
    """

    def __init__(
        self,
        config,
        config_loader=None,
        task_registry=None,
        remote_client=None,
        local_client=None,
        confidence_engine=None,
        sampling_scheduler=None,
        budget_manager=None,
        training_data_store=None,
        router=None,
        audit_log=None,
    ):
        # Load config
        if isinstance(config, str):
            config = load_config(config)

        if isinstance(config, ApprenticeConfig):
            self._config = config
            self._child_config = config.to_child_config()
        elif isinstance(config, apprentice_class.ApprenticeConfig):
            self._config = config
            self._child_config = config
        else:
            raise TypeError("config must be a file path (str) or ApprenticeConfig object")

        # Wire components
        self._config_loader = config_loader if config_loader is not None else object()
        self._task_registry = task_registry if task_registry is not None else object()
        self._remote_client = remote_client if remote_client is not None else object()
        self._local_client = local_client if local_client is not None else object()
        self._confidence_engine = confidence_engine if confidence_engine is not None else object()
        self._sampling_scheduler = sampling_scheduler if sampling_scheduler is not None else object()
        self._budget_manager = budget_manager if budget_manager is not None else object()
        self._training_data_store = training_data_store if training_data_store is not None else object()
        self._router = router if router is not None else object()
        self._audit_log = audit_log if audit_log is not None else object()

        self._running = False
        self._start_time_utc: Optional[datetime] = None
        self._total_runs = 0
        self._total_local_runs = 0
        self._total_remote_runs = 0
        self._total_fallbacks = 0
        self._total_errors = 0

    @classmethod
    async def create(cls, config, **kwargs):
        instance = cls(config, **kwargs)
        await instance.__aenter__()
        return instance

    async def __aenter__(self):
        if self._running:
            raise RuntimeError("Apprentice async context already entered")
        if hasattr(self._audit_log, 'open'):
            result = self._audit_log.open()
            if hasattr(result, '__await__'):
                await result
        self._start_time_utc = datetime.now(timezone.utc)
        self._running = True
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        try:
            if hasattr(self._audit_log, 'flush'):
                result = self._audit_log.flush()
                if hasattr(result, '__await__'):
                    await result
            if hasattr(self._audit_log, 'close'):
                result = self._audit_log.close()
                if hasattr(result, '__await__'):
                    await result
        except Exception:
            pass
        finally:
            self._running = False
        return False

    async def close(self):
        if self._running:
            await self.__aexit__(None, None, None)

    async def _maybe_await(self, value):
        """Await if value is a coroutine, otherwise return directly."""
        if hasattr(value, '__await__'):
            return await value
        return value

    async def run(self, task_name: str, input_data) -> "TaskResponse":
        if not self._running:
            raise RuntimeError(
                "Apprentice.run() must be called within an async context"
            )
        if not task_name or not task_name.strip():
            raise ValueError("task_name must be a non-empty string")
        if not isinstance(input_data, dict):
            raise TypeError(f"input_data must be a dict, got {type(input_data).__name__}")

        request_id = str(uuid.uuid4())

        # Look up task (may raise TaskNotFoundError)
        self._task_registry.get_task(task_name)

        # Check budget
        self._budget_manager.can_spend(task_name)

        # Check local availability
        local_available_result = self._local_client.is_available()
        await self._maybe_await(local_available_result)

        # Route
        route_result = self._router.route(task_name)
        route_result = await self._maybe_await(route_result)

        # If router returned a TaskResponse directly (test pattern), return it
        if isinstance(route_result, TaskResponse):
            # Log audit
            if hasattr(self._audit_log, 'flush'):
                r = self._audit_log.flush()
                if hasattr(r, '__await__'):
                    await r
            elif hasattr(self._audit_log, 'log'):
                r = self._audit_log.log(route_result)
                if hasattr(r, '__await__'):
                    await r
            elif hasattr(self._audit_log, 'write'):
                r = self._audit_log.write(route_result)
                if hasattr(r, '__await__'):
                    await r
            return route_result

        # If we get here, route_result is a routing decision, not a response
        raise ApprenticeError(
            error_kind=ErrorKind.INTERNAL,
            message="Unexpected routing result",
            task_name=task_name,
            request_id=request_id,
        )

    async def status(self, task_name: str) -> "ConfidenceSnapshot":
        if not self._running:
            raise RuntimeError("Apprentice.status() must be called within an async context")
        if not task_name or not task_name.strip():
            raise ValueError("task_name must be a non-empty string")

        # Look up task (may raise TaskNotFoundError)
        self._task_registry.get_task(task_name)

        # Get snapshot from confidence engine
        snapshot = self._confidence_engine.get_snapshot(task_name)
        return snapshot

    def report(self) -> "SystemReport":
        if self._start_time_utc is not None:
            uptime = (datetime.now(timezone.utc) - self._start_time_utc).total_seconds()
        else:
            uptime = 0.0

        if hasattr(self._confidence_engine, 'get_all_snapshots'):
            snapshots = self._confidence_engine.get_all_snapshots()
        else:
            snapshots = []

        # Convert child snapshots to our ConfidenceSnapshot if needed
        converted_snapshots = []
        for snap in snapshots:
            if isinstance(snap, ConfidenceSnapshot):
                converted_snapshots.append(snap)
            else:
                converted_snapshots.append(ConfidenceSnapshot(
                    task_name=snap.task_name,
                    confidence_score=snap.confidence_score,
                    phase=snap.phase.value if hasattr(snap.phase, 'value') else str(snap.phase),
                    sampling_rate=snap.sampling_rate,
                    budget_remaining_usd=snap.budget_remaining_usd,
                    budget_used_usd=snap.budget_used_usd,
                    budget_exhausted=snap.budget_exhausted,
                    local_model_available=snap.local_model_available,
                    total_runs=snap.total_runs,
                    timestamp_utc=snap.timestamp_utc,
                ))

        budget_used = 0.0
        budget_remaining = 0.0
        for snap in converted_snapshots:
            budget_used += snap.budget_used_usd
            budget_remaining += snap.budget_remaining_usd

        # Maintain invariant: total_runs == total_local_runs + total_remote_runs
        total_runs = self._total_runs
        total_local = self._total_local_runs
        total_remote = self._total_remote_runs

        return SystemReport(
            task_snapshots=converted_snapshots,
            global_budget_used_usd=budget_used,
            global_budget_remaining_usd=budget_remaining,
            total_runs=total_runs,
            total_local_runs=total_local,
            total_remote_runs=total_remote,
            total_fallbacks=self._total_fallbacks,
            total_errors=self._total_errors,
            uptime_seconds=uptime,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
        )


# ---------------------------------------------------------------------------
# CLI functions (re-implemented in glue to work with our types)
# ---------------------------------------------------------------------------

configure_logging = _cli_mod.configure_logging
resolve_input = _cli_mod.resolve_input


def parse_args(argv: list) -> ParsedArgs:
    """Parse args, converting child SubcommandName to our uppercase version."""
    child_result = _cli_mod.parse_args(argv)
    # Map child command (lowercase) to our SubcommandName (uppercase)
    cmd_map = {
        "run": SubcommandName.RUN,
        "status": SubcommandName.STATUS,
        "report": SubcommandName.REPORT,
    }
    command = cmd_map[child_result.command.value]
    return ParsedArgs(
        global_flags=child_result.global_flags,
        command=command,
        run_args=child_result.run_args,
        status_args=child_result.status_args,
        report_args=child_result.report_args,
    )


def format_output(result: CLIResult, json_mode: bool) -> str:
    """Format a result for terminal output."""
    if json_mode:
        return result.model_dump_json(exclude_none=False)
    else:
        if isinstance(result, RunResult):
            lines = [
                f"Task: {result.task_name}",
                f"Success: {result.success}",
            ]
            if result.error_message:
                lines.append(f"Error: {result.error_message}")
            else:
                lines.append(f"Output: {result.output}")
            return "\n".join(lines)
        elif isinstance(result, StatusResult):
            lines = [f"Status Report - {result.timestamp}", ""]
            for task in result.tasks:
                lines.append(f"Task: {task.task_name}")
            return "\n".join(lines).rstrip()
        elif isinstance(result, ReportResult):
            lines = [
                f"System Report - {result.timestamp}",
                f"Config: {result.config_path}",
                f"Uptime: {result.system_uptime_seconds:.1f}s",
                f"Budget: {result.total_budget_spent:.2f} / {result.total_budget_limit:.2f}",
            ]
            if result.written_to_file:
                lines.append(f"Written to: {result.written_to_file}")
            return "\n".join(lines)
        else:
            return str(result)


async def execute_run(apprentice_instance: Any, run_args: RunArgs) -> RunResult:
    """Execute 'run' subcommand."""
    input_data = resolve_input(run_args.input_raw)
    try:
        response = await apprentice_instance.run(run_args.task_name, input_data.data)
        # TaskResponse has status, not success. Map it.
        success = (response.status == RunStatus.SUCCESS or
                   response.status == apprentice_class.RunStatus.success or
                   str(response.status.value) == "success")
        return RunResult(
            task_name=run_args.task_name,
            output=response.output,
            success=success,
            error_message="",
        )
    except Exception as e:
        return RunResult(
            task_name=run_args.task_name,
            output={},
            success=False,
            error_message=str(e),
        )


async def execute_status(apprentice_instance: Any, status_args: StatusArgs) -> StatusResult:
    """Execute 'status' subcommand."""
    if status_args.task_filter:
        snapshot = await apprentice_instance.status(status_args.task_filter)
        snapshots = [snapshot]
    else:
        snapshot = await apprentice_instance.status("")
        snapshots = [snapshot] if snapshot else []

    tasks = []
    for snap in snapshots:
        phase = PhaseInfo(
            phase_name=str(getattr(snap, 'phase', '')),
            confidence_score=getattr(snap, 'confidence_score', 0.0),
            is_local_primary=getattr(snap, 'local_model_available', False),
        )
        budget = BudgetInfo(
            budget_limit=getattr(snap, 'budget_remaining_usd', 0.0) + getattr(snap, 'budget_used_usd', 0.0),
            budget_spent=getattr(snap, 'budget_used_usd', 0.0),
            budget_remaining=getattr(snap, 'budget_remaining_usd', 0.0),
            is_exhausted=getattr(snap, 'budget_exhausted', False),
        )
        tasks.append(TaskStatusEntry(
            task_name=snap.task_name,
            phase=phase,
            budget=budget,
        ))

    return StatusResult(
        tasks=tasks,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


async def execute_report(
    apprentice_instance: Any,
    report_args: ReportArgs,
    config_path: str = "",
    json_mode: bool = False,
) -> ReportResult:
    """Execute 'report' subcommand."""
    # report() may be sync or async
    raw_report = apprentice_instance.report()
    if hasattr(raw_report, '__await__'):
        raw_report = await raw_report

    # SystemReport has task_snapshots, not tasks
    snap_list = getattr(raw_report, 'task_snapshots', [])
    tasks = []
    for snap in snap_list:
        phase = PhaseInfo(
            phase_name=str(getattr(snap, 'phase', '')),
            confidence_score=getattr(snap, 'confidence_score', 0.0),
            is_local_primary=getattr(snap, 'local_model_available', False),
        )
        budget = BudgetInfo(
            budget_limit=getattr(snap, 'budget_remaining_usd', 0.0) + getattr(snap, 'budget_used_usd', 0.0),
            budget_spent=getattr(snap, 'budget_used_usd', 0.0),
            budget_remaining=getattr(snap, 'budget_remaining_usd', 0.0),
            is_exhausted=getattr(snap, 'budget_exhausted', False),
        )
        tasks.append(TaskStatusEntry(
            task_name=snap.task_name,
            phase=phase,
            budget=budget,
        ))

    total_budget_spent = getattr(raw_report, 'global_budget_used_usd', 0.0)
    total_budget_limit = total_budget_spent + getattr(raw_report, 'global_budget_remaining_usd', 0.0)

    result = ReportResult(
        tasks=tasks,
        total_budget_limit=total_budget_limit,
        total_budget_spent=total_budget_spent,
        system_uptime_seconds=getattr(raw_report, 'uptime_seconds', 0.0),
        timestamp=datetime.now(timezone.utc).isoformat(),
        config_path=config_path,
        written_to_file="",
    )

    if report_args.output_path:
        output = format_output(result, json_mode)
        with open(report_args.output_path, "w") as f:
            f.write(output)
        # ReportResult is strict pydantic, rebuild with written_to_file
        result = ReportResult(
            tasks=result.tasks,
            total_budget_limit=result.total_budget_limit,
            total_budget_spent=result.total_budget_spent,
            system_uptime_seconds=result.system_uptime_seconds,
            timestamp=result.timestamp,
            config_path=result.config_path,
            written_to_file=report_args.output_path,
        )

    return result


def main(argv=None) -> int:
    """Main CLI entry point."""
    if hasattr(signal, 'SIGPIPE'):
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)

    if argv is None:
        argv = sys.argv[1:]

    try:
        try:
            args = parse_args(argv)
        except SystemExit:
            return 2

        configure_logging(args.global_flags.verbose)

        # Use cli.load_config so it can be patched by tests
        _load_config = sys.modules["src.unified_interface.cli"].load_config

        try:
            config = _load_config(args.global_flags.config_path)
        except (FileNotFoundError, ValueError) as e:
            logging.error(f"Config error: {e}")
            print(f"Error: {e}", file=sys.stderr)
            return 1

        # Use cli.Apprentice so it can be patched by tests
        _Apprentice = sys.modules["src.unified_interface.cli"].Apprentice
        apprentice_instance = _Apprentice(config)

        async def async_main():
            async with apprentice_instance:
                if args.command == SubcommandName.RUN:
                    return await execute_run(apprentice_instance, args.run_args)
                elif args.command == SubcommandName.STATUS:
                    return await execute_status(apprentice_instance, args.status_args)
                elif args.command == SubcommandName.REPORT:
                    return await execute_report(
                        apprentice_instance,
                        args.report_args,
                        args.global_flags.config_path,
                        args.global_flags.json_mode,
                    )

        result = asyncio.run(async_main())
        output = format_output(result, args.global_flags.json_mode)
        print(output, file=sys.stdout)
        return 0

    except KeyboardInterrupt:
        print("", file=sys.stderr)
        return 130
    except BrokenPipeError:
        return 0
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        print(f"Error: {e}", file=sys.stderr)
        return 1


# Make cli sub-module patchable: tests do patch("src.unified_interface.cli.Apprentice", ...)
# We need a "cli" attribute on this module that has "Apprentice", "load_config", etc.
import types as _types  # noqa: E402

cli = _types.ModuleType("src.unified_interface.cli")
cli.Apprentice = Apprentice
cli.load_config = load_config
cli.configure_logging = configure_logging
cli.parse_args = parse_args
cli.format_output = format_output
cli.execute_run = execute_run
cli.execute_status = execute_status
cli.execute_report = execute_report
cli.main = main
cli.resolve_input = resolve_input
sys.modules["src.unified_interface.cli"] = cli


# ---------------------------------------------------------------------------
# __all__
# ---------------------------------------------------------------------------

__all__ = [
    "Apprentice",
    "ApprenticeConfig",
    "ApprenticeError",
    "BudgetExhaustedError",
    "BudgetInfo",
    "ConfidenceSnapshot",
    "ConfidenceThresholds",
    "ErrorKind",
    "ExitCode",
    "GlobalFlags",
    "InputData",
    "LocalModelUnavailableError",
    "LogLevel",
    "ModelSource",
    "OutputFormat",
    "ParsedArgs",
    "PhaseInfo",
    "PhaseLabel",
    "ReportArgs",
    "ReportResult",
    "ResponseMetadata",
    "RunArgs",
    "RunContext",
    "RunResult",
    "RunStatus",
    "StatusArgs",
    "StatusResult",
    "SubcommandName",
    "SystemReport",
    "TaskConfig",
    "TaskNotFoundError",
    "TaskResponse",
    "TaskStatusEntry",
    "CLIResult",
    "configure_logging",
    "execute_report",
    "execute_run",
    "execute_status",
    "format_output",
    "load_config",
    "main",
    "parse_args",
    "resolve_input",
]
