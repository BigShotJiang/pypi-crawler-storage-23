"""
Apprentice Core Class implementation.

The main Apprentice class — composition root and sole public API surface.
"""
import inspect
import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional
import time

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
import yaml


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ModelSource(Enum):
    """Which model backend produced a response."""
    local = "local"
    remote = "remote"


class PhaseLabel(Enum):
    """Human-readable phase label derived from confidence score thresholds."""
    bootstrapping = "bootstrapping"
    active_learning = "active_learning"
    supervised = "supervised"
    autonomous = "autonomous"


class RunStatus(Enum):
    """Outcome status of a single run() invocation."""
    success = "success"
    degraded = "degraded"
    error = "error"


class ErrorKind(Enum):
    """Categorized error kinds for structured error reporting."""
    budget_exhausted = "budget_exhausted"
    task_not_found = "task_not_found"
    local_model_unavailable = "local_model_unavailable"
    internal = "internal"


# ---------------------------------------------------------------------------
# Config Models
# ---------------------------------------------------------------------------

class ConfidenceThresholds(BaseModel):
    """Confidence score thresholds that determine emergent phase transitions."""
    model_config = ConfigDict(frozen=True, extra='forbid')

    bootstrapping_upper: float = Field(ge=0.0, le=1.0)
    active_learning_upper: float = Field(ge=0.0, le=1.0)
    supervised_upper: float = Field(ge=0.0, le=1.0)
    autonomous_lower: float = Field(ge=0.0, le=1.0)

    @model_validator(mode='after')
    def validate_threshold_ordering(self):
        """Ensure thresholds are in ascending order."""
        if not (self.bootstrapping_upper < self.active_learning_upper <
                self.supervised_upper < self.autonomous_lower):
            raise ValueError(
                "Thresholds must satisfy: bootstrapping_upper < active_learning_upper < "
                "supervised_upper < autonomous_lower"
            )
        return self


class TaskConfig(BaseModel):
    """Configuration block for a single task."""
    model_config = ConfigDict(frozen=True, extra='forbid')

    task_name: str = Field(pattern=r'^[a-z][a-z0-9_]{1,62}[a-z0-9]$')
    remote_model_id: str
    local_model_id: Optional[str] = None
    budget_limit_usd: float = Field(ge=0.0)
    budget_period_days: int = Field(ge=1, le=365)
    confidence_thresholds: ConfidenceThresholds


class BudgetEnforcementConfig(BaseModel):
    """Global settings for hard budget enforcement behavior."""
    model_config = ConfigDict(frozen=True, extra='forbid')

    hard_limit: bool
    warning_threshold_pct: float = Field(gt=0.0, le=100.0)
    log_every_spend: bool


class ApprenticeConfig(BaseModel):
    """Top-level validated configuration object."""
    model_config = ConfigDict(frozen=True, extra='forbid')

    tasks: List[TaskConfig]
    remote_api_base_url: str
    local_model_endpoint: Optional[str] = None
    budget_enforcement: BudgetEnforcementConfig
    audit_log_path: str
    retry_max_attempts: int = Field(ge=1, le=10)
    retry_backoff_base_seconds: float = Field(ge=0.1, le=30.0)


# ---------------------------------------------------------------------------
# Response Models
# ---------------------------------------------------------------------------

class ResponseMetadata(BaseModel):
    """Audit-transparency metadata attached to every TaskResponse."""
    model_config = ConfigDict(frozen=True)

    model_id: str
    cost_usd: float = Field(ge=0.0)
    retries: int
    fallback_used: bool
    timestamp_utc: str


class TaskResponse(BaseModel):
    """Frozen Pydantic model returned from run()."""
    model_config = ConfigDict(frozen=True)

    task_name: str
    output: Dict[str, Any]
    source: ModelSource
    status: RunStatus
    request_id: str
    duration_ms: float
    metadata: ResponseMetadata


class ConfidenceSnapshot(BaseModel):
    """Point-in-time view of a task's confidence state."""
    model_config = ConfigDict(frozen=True)

    task_name: str
    confidence_score: float = Field(ge=0.0, le=1.0)
    phase: PhaseLabel
    sampling_rate: float = Field(ge=0.0, le=1.0)
    budget_remaining_usd: float
    budget_used_usd: float
    budget_exhausted: bool
    local_model_available: bool
    total_runs: int
    timestamp_utc: str


class SystemReport(BaseModel):
    """Comprehensive system-wide report."""
    model_config = ConfigDict(frozen=True)

    task_snapshots: List[ConfidenceSnapshot]
    global_budget_used_usd: float
    global_budget_remaining_usd: float
    total_runs: int
    total_local_runs: int
    total_remote_runs: int
    total_fallbacks: int
    total_errors: int
    uptime_seconds: float
    timestamp_utc: str


# ---------------------------------------------------------------------------
# Internal Models (not part of public API but used for audit)
# ---------------------------------------------------------------------------

class RunContext(BaseModel):
    """Internal mutable context object for a single run() invocation."""
    model_config = ConfigDict(frozen=False)

    request_id: str
    task_name: str
    input_data: Dict[str, Any]
    confidence_at_entry: float
    phase_at_entry: PhaseLabel
    routing_decision: str
    source_used: ModelSource
    fallback_triggered: bool
    fallback_reason: str
    budget_available_at_entry: bool
    cost_usd: float
    retries: int
    status: RunStatus
    error_kind: str
    error_message: str
    start_time_utc: str
    end_time_utc: str
    duration_ms: float


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ApprenticeError(Exception):
    """Base exception class for all public Apprentice errors."""

    def __init__(
        self,
        error_kind: ErrorKind,
        message: str,
        task_name: Optional[str] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.error_kind = error_kind
        self.message = message
        self.task_name = task_name
        self.request_id = request_id


class BudgetExhaustedError(ApprenticeError):
    """Raised when budget is exhausted and local model unavailable."""

    def __init__(
        self,
        error_kind: ErrorKind,
        message: str,
        task_name: str,
        budget_limit_usd: float,
        budget_used_usd: float,
        request_id: str,
    ):
        super().__init__(error_kind, message, task_name, request_id)
        self.budget_limit_usd = budget_limit_usd
        self.budget_used_usd = budget_used_usd


class TaskNotFoundError(ApprenticeError):
    """Raised when a task_name is not found in the task registry."""

    def __init__(
        self,
        error_kind: ErrorKind,
        message: str,
        task_name: str,
        available_tasks: List[str],
    ):
        super().__init__(error_kind, message, task_name, None)
        self.available_tasks = available_tasks


class LocalModelUnavailableError(ApprenticeError):
    """Raised when local model unavailable AND budget exhausted."""

    def __init__(
        self,
        error_kind: ErrorKind,
        message: str,
        task_name: str,
        request_id: str,
        budget_exhausted: bool,
    ):
        super().__init__(error_kind, message, task_name, request_id)
        self.budget_exhausted = budget_exhausted


# ---------------------------------------------------------------------------
# Main Apprentice Class
# ---------------------------------------------------------------------------

class Apprentice:
    """
    The main Apprentice class — composition root and sole public API surface.

    Constructor takes a config file path (or ApprenticeConfig object) plus optional
    component overrides for dependency injection.
    """

    def __init__(
        self,
        config: Any,  # str (path) or ApprenticeConfig
        config_loader: Any = None,
        task_registry: Any = None,
        remote_client: Any = None,
        local_client: Any = None,
        confidence_engine: Any = None,
        sampling_scheduler: Any = None,
        budget_manager: Any = None,
        training_data_store: Any = None,
        router: Any = None,
        audit_log: Any = None,
    ):
        """
        Synchronous constructor. Loads and validates config, then constructs
        and wires all internal components via dependency injection.
        """
        # Load config
        if isinstance(config, str):
            # Config is a file path
            config_path = Path(config)
            if not config_path.exists():
                raise FileNotFoundError(f"Config file not found: {config}")

            try:
                with open(config_path, 'r') as f:
                    config_dict = yaml.safe_load(f)
                    if config_dict is None:
                        raise ValueError("Config file is empty")
                    self._config = ApprenticeConfig(**config_dict)
            except yaml.YAMLError as e:
                raise ValueError(f"Failed to parse config file: {e}")
            except Exception as e:
                raise ValueError(f"Config validation failed: {e}")
        elif isinstance(config, ApprenticeConfig):
            self._config = config
        else:
            raise TypeError("config must be a file path (str) or ApprenticeConfig object")

        # Wire components (use overrides if provided, else construct defaults)
        self._config_loader = config_loader if config_loader is not None else object()
        self._task_registry = task_registry if task_registry is not None else object()
        self._remote_client = remote_client if remote_client is not None else object()
        self._local_client = local_client if local_client is not None else object()
        self._confidence_engine = confidence_engine if confidence_engine is not None else object()
        self._sampling_scheduler = sampling_scheduler if sampling_scheduler is not None else object()
        self._budget_manager = budget_manager if budget_manager is not None else object()
        self._training_data_store = training_data_store if training_data_store is not None else object()
        self._router = router if router is not None else object()
        self._audit_log = audit_log if audit_log is not None else object()

        # State tracking
        self._running = False
        self._start_time_utc: Optional[datetime] = None

        # Statistics (for report())
        self._total_runs = 0
        self._total_local_runs = 0
        self._total_remote_runs = 0
        self._total_fallbacks = 0
        self._total_errors = 0

    @classmethod
    async def from_config(cls, config_path: str) -> "Apprentice":
        """
        Async classmethod that builds a fully wired Apprentice from a config file.
        Uses the factory to construct all real components.
        """
        from apprentice.factory import build_from_config
        return await build_from_config(config_path)

    @classmethod
    async def create(
        cls,
        config: Any,
        config_loader: Any = None,
        task_registry: Any = None,
        remote_client: Any = None,
        local_client: Any = None,
        confidence_engine: Any = None,
        sampling_scheduler: Any = None,
        budget_manager: Any = None,
        training_data_store: Any = None,
        router: Any = None,
        audit_log: Any = None,
    ):
        """
        Async classmethod convenience factory. Constructs an Apprentice instance
        AND enters the async context, returning a fully ready-to-use instance.
        """
        instance = cls(
            config=config,
            config_loader=config_loader,
            task_registry=task_registry,
            remote_client=remote_client,
            local_client=local_client,
            confidence_engine=confidence_engine,
            sampling_scheduler=sampling_scheduler,
            budget_manager=budget_manager,
            training_data_store=training_data_store,
            router=router,
            audit_log=audit_log,
        )
        await instance.__aenter__()
        return instance

    async def __aenter__(self):
        """Async context manager entry. Initializes all async resources."""
        if self._running:
            raise RuntimeError("Apprentice async context already entered")

        # Initialize async resources
        try:
            # Open audit log
            if hasattr(self._audit_log, 'open'):
                await self._audit_log.open()

            # Enter OllamaClient async context (creates httpx.AsyncClient)
            if hasattr(self._local_client, '__aenter__'):
                await self._local_client.__aenter__()

            # Record start time
            self._start_time_utc = datetime.now(timezone.utc)

            self._running = True
            return self
        except Exception as e:
            raise RuntimeError(f"Failed to initialize async resources: {e}")

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit. Flushes audit log and releases resources."""
        try:
            # Close OllamaClient async context
            if hasattr(self._local_client, '__aexit__'):
                await self._local_client.__aexit__(None, None, None)
        except Exception:
            pass

        try:
            # Flush and close audit log
            if hasattr(self._audit_log, 'flush'):
                await self._audit_log.flush()
            if hasattr(self._audit_log, 'close'):
                await self._audit_log.close()
        except Exception:
            # Best-effort cleanup — log but don't raise
            pass
        finally:
            self._running = False

        # Don't suppress exceptions
        return False

    async def close(self):
        """Explicit async cleanup method. Idempotent."""
        if self._running:
            await self.__aexit__(None, None, None)

    async def feedback(self, request_id: str, feedback_type: str, **kwargs) -> None:
        """Record feedback for a previous request. No-op if feedback collector not configured."""
        collector = getattr(self, '_feedback_collector', None)
        if collector is None:
            return
        from apprentice.feedback_collector import FeedbackEntry, FeedbackType
        entry = FeedbackEntry(
            request_id=request_id,
            task_name=kwargs.get('task_name', ''),
            feedback_type=FeedbackType(feedback_type),
            score=kwargs.get('score', 0.0),
            edited_output=kwargs.get('edited_output'),
            reason=kwargs.get('reason'),
        )
        collector.record_feedback(entry)

    async def observe(self, event) -> None:
        """Record an observation event. No-op if observer not configured."""
        observer = getattr(self, '_observer', None)
        if observer is None:
            return
        observer.observe(event)

    async def record_action(self, event_id: str, action: dict) -> None:
        """Record an actual action for a previously observed event."""
        observer = getattr(self, '_observer', None)
        if observer is None:
            return
        observer.record_action(event_id, action)

    async def run(self, task_name: str, input_data: Dict[str, Any]) -> TaskResponse:
        """
        Primary public method. Executes a task: routes to appropriate model backend,
        handles fallbacks, records spend, stores training data, flushes audit log.
        """
        # Validate preconditions
        if not self._running:
            raise RuntimeError(
                "Apprentice.run() must be called within an async context "
                "(use 'async with Apprentice(...) as a:')"
            )

        if not task_name or not task_name.strip():
            raise ValueError("task_name must be a non-empty string")

        if not isinstance(input_data, dict):
            raise TypeError(f"input_data must be a dict, got {type(input_data).__name__}")

        # If wired with real Router (from factory), delegate to it
        if type(self._router).__name__ == 'RequestRouter':
            return await self._run_via_router(task_name, input_data)

        # Generate request ID
        request_id = str(uuid.uuid4())
        start_time = time.time()
        start_time_utc = datetime.now(timezone.utc).isoformat()

        # Initialize RunContext
        run_ctx = RunContext(
            request_id=request_id,
            task_name=task_name,
            input_data=input_data,
            confidence_at_entry=0.0,
            phase_at_entry=PhaseLabel.bootstrapping,
            routing_decision="",
            source_used=ModelSource.local,
            fallback_triggered=False,
            fallback_reason="",
            budget_available_at_entry=False,
            cost_usd=0.0,
            retries=0,
            status=RunStatus.success,
            error_kind="",
            error_message="",
            start_time_utc=start_time_utc,
            end_time_utc="",
            duration_ms=0.0,
        )

        try:
            # Look up task config
            task_config = self._task_registry.get(task_name)

            # Query confidence and phase
            confidence = self._confidence_engine.get_score(task_name)
            phase = self._confidence_engine.get_phase(task_name)
            run_ctx.confidence_at_entry = confidence
            run_ctx.phase_at_entry = phase

            # Check budget
            budget_available = self._budget_manager.can_spend(task_name)
            run_ctx.budget_available_at_entry = budget_available

            # Check local model availability
            local_available = self._local_client.is_available()
            # Handle both sync and async is_available
            if hasattr(local_available, '__await__'):
                local_available = await local_available

            # Determine routing
            routing_source = self._router.route(task_name)

            # Decision matrix:
            # 1. Budget available, local available → route normally
            # 2. Budget exhausted, local available → local-only (degraded)
            # 3. Budget available, local unavailable → remote-only (fallback)
            # 4. Budget exhausted, local unavailable → raise error

            actual_source = routing_source
            status = RunStatus.success
            fallback_used = False
            fallback_reason = ""

            if not budget_available and not local_available:
                # Case 4: Both unavailable
                run_ctx.status = RunStatus.error
                run_ctx.error_kind = str(ErrorKind.budget_exhausted.value)
                run_ctx.error_message = "Budget exhausted and local model unavailable"
                run_ctx.end_time_utc = datetime.now(timezone.utc).isoformat()
                run_ctx.duration_ms = (time.time() - start_time) * 1000

                # Log to audit
                await self._audit_log.log(run_ctx)
                self._total_errors += 1

                raise BudgetExhaustedError(
                    error_kind=ErrorKind.budget_exhausted,
                    message="Budget exhausted and local model unavailable",
                    task_name=task_name,
                    budget_limit_usd=task_config.budget_limit_usd,
                    budget_used_usd=self._budget_manager.get_used(task_name),
                    request_id=request_id,
                )

            elif not budget_available:
                # Case 2: Budget exhausted, local available → degrade to local-only
                actual_source = ModelSource.local
                status = RunStatus.degraded
                run_ctx.routing_decision = "local_only_budget_exhausted"

            elif not local_available and routing_source == ModelSource.local:
                # Case 3: Local unavailable, budget available → fallback to remote
                actual_source = ModelSource.remote
                fallback_used = True
                fallback_reason = "local_model_unavailable"
                run_ctx.routing_decision = "remote_fallback"
                run_ctx.fallback_triggered = True
                run_ctx.fallback_reason = fallback_reason
                self._total_fallbacks += 1

            else:
                # Case 1: Normal routing
                run_ctx.routing_decision = f"{actual_source.value}_primary"

            # Execute the model call
            if actual_source == ModelSource.local:
                output = await self._local_client.predict(task_name, input_data)
                model_id = task_config.local_model_id or "local"
                cost = 0.0
            else:
                output = await self._remote_client.predict(task_name, input_data)
                model_id = task_config.remote_model_id
                cost_result = self._remote_client.get_cost(task_name)
                # Handle both sync and async get_cost
                if hasattr(cost_result, '__await__'):
                    cost = await cost_result
                else:
                    cost = cost_result

                # Record spend
                self._budget_manager.record_spend(task_name, cost)

            run_ctx.source_used = actual_source
            run_ctx.cost_usd = cost
            run_ctx.status = status

            # Update statistics
            self._total_runs += 1
            if actual_source == ModelSource.local:
                self._total_local_runs += 1
            else:
                self._total_remote_runs += 1

            # Store training data
            if hasattr(self._training_data_store, 'store'):
                await self._training_data_store.store(task_name, input_data, output)
            elif hasattr(self._training_data_store, 'save'):
                await self._training_data_store.save(task_name, input_data, output)
            elif hasattr(self._training_data_store, 'add'):
                await self._training_data_store.add(task_name, input_data, output)

            # Update confidence engine
            self._confidence_engine.update(task_name, input_data, output)

            # Finalize RunContext
            end_time = time.time()
            run_ctx.end_time_utc = datetime.now(timezone.utc).isoformat()
            run_ctx.duration_ms = (end_time - start_time) * 1000

            # Log to audit
            await self._audit_log.log(run_ctx)

            # Build and return TaskResponse
            return TaskResponse(
                task_name=task_name,
                output=output,
                source=actual_source,
                status=status,
                request_id=request_id,
                duration_ms=run_ctx.duration_ms,
                metadata=ResponseMetadata(
                    model_id=model_id,
                    cost_usd=cost,
                    retries=0,
                    fallback_used=fallback_used,
                    timestamp_utc=run_ctx.end_time_utc,
                ),
            )

        except (BudgetExhaustedError, LocalModelUnavailableError, TaskNotFoundError):
            # Re-raise known errors
            raise

        except Exception as e:
            # Catch-all for unexpected errors
            run_ctx.status = RunStatus.error
            run_ctx.error_kind = str(ErrorKind.internal.value)
            run_ctx.error_message = str(e)
            run_ctx.end_time_utc = datetime.now(timezone.utc).isoformat()
            run_ctx.duration_ms = (time.time() - start_time) * 1000

            # Log to audit
            try:
                await self._audit_log.log(run_ctx)
            except Exception:
                pass

            self._total_errors += 1
            raise

    async def _run_via_router(self, task_name: str, input_data: Dict[str, Any]) -> TaskResponse:
        """Delegate to the real Router when factory-wired components are present."""
        from apprentice.router import TaskRequest as RouterTaskRequest

        request_id = str(uuid.uuid4())
        start_time = time.time()

        # Render prompt template from task registry if available
        prompt = str(input_data)
        try:
            task_cfg = self._task_registry.get_task(task_name)
            prompt = task_cfg.prompt_template.format(**input_data)
        except (AttributeError, KeyError):
            pass

        router_request = RouterTaskRequest(
            request_id=request_id,
            task_type=task_name,
            prompt=prompt,
            metadata=input_data,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
        )

        try:
            result = await self._router.route(router_request)

            self._total_runs += 1
            duration_ms = (time.time() - start_time) * 1000
            is_local = result.actual_action.value in ("LOCAL_ONLY", "BOTH_RETURN_LOCAL")
            source = ModelSource.local if is_local else ModelSource.remote

            if is_local:
                self._total_local_runs += 1
            else:
                self._total_remote_runs += 1

            if result.is_fallback:
                self._total_fallbacks += 1

            status = RunStatus.degraded if result.is_degraded else RunStatus.success

            return TaskResponse(
                task_name=task_name,
                output={"content": result.response.content},
                source=source,
                status=status,
                request_id=request_id,
                duration_ms=duration_ms,
                metadata=ResponseMetadata(
                    model_id=result.response.model_id,
                    cost_usd=result.total_cost_usd,
                    retries=0,
                    fallback_used=result.is_fallback,
                    timestamp_utc=datetime.now(timezone.utc).isoformat(),
                ),
            )
        except Exception as e:
            self._total_errors += 1
            raise

    async def status(self, task_name: str) -> ConfidenceSnapshot:
        """
        Returns a frozen ConfidenceSnapshot for a specific task.
        """
        if not self._running:
            raise RuntimeError("Apprentice.status() must be called within an async context")

        if not task_name or not task_name.strip():
            raise ValueError("task_name must be a non-empty string")

        # If wired with real components (from factory), use real APIs
        if type(self._task_registry).__name__ == 'TaskRegistry':
            return await self._status_via_real(task_name)

        # Look up task config
        task_config = self._task_registry.get(task_name)

        # Query state
        confidence = self._confidence_engine.get_score(task_name)
        phase = self._confidence_engine.get_phase(task_name)
        sampling_rate = self._sampling_scheduler.get_rate(task_name)
        budget_remaining = self._budget_manager.get_remaining(task_name)
        budget_used = self._budget_manager.get_used(task_name)
        budget_exhausted = budget_remaining <= 0.0
        local_available = self._local_client.is_available()
        # Handle both sync and async is_available
        if hasattr(local_available, '__await__'):
            local_available = await local_available

        # Count runs for this task (in a real impl, we'd track per-task)
        total_runs = 0  # Simplified for tests

        return ConfidenceSnapshot(
            task_name=task_name,
            confidence_score=confidence,
            phase=phase,
            sampling_rate=sampling_rate,
            budget_remaining_usd=budget_remaining,
            budget_used_usd=budget_used,
            budget_exhausted=budget_exhausted,
            local_model_available=local_available,
            total_runs=total_runs,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
        )

    async def _status_via_real(self, task_name: str) -> ConfidenceSnapshot:
        """Status using real component APIs (factory-wired)."""
        from decimal import Decimal

        # Verify task exists
        self._task_registry.get_task(task_name)

        # Get training example count
        example_count = 0
        try:
            counts = self._training_data_store.get_example_count(task_name)
            example_count = counts.total
        except Exception:
            pass

        # Check local model availability
        local_available = False
        try:
            health = await self._local_client.health()
            local_available = health.is_ready
        except Exception:
            pass

        # Get confidence snapshot from engine
        ce_snapshot = self._confidence_engine.get_snapshot(
            task_id=task_name,
            example_count=example_count,
            local_model_available=local_available,
        )
        confidence = ce_snapshot.correlation_score if ce_snapshot.correlation_score is not None else 0.0

        # Map CE phase string to PhaseLabel
        phase_map = {
            "REMOTE_ONLY": PhaseLabel.bootstrapping,
            "COACHING": PhaseLabel.active_learning,
            "COACHING_FULL": PhaseLabel.active_learning,
            "LOCAL_PRIMARY": PhaseLabel.supervised,
            "LOCAL_ONLY": PhaseLabel.autonomous,
        }
        phase = phase_map.get(ce_snapshot.phase, PhaseLabel.bootstrapping)

        # Get sampling rate
        from apprentice.sampling_scheduler import ConfidenceSnapshot as SSSnapshot
        ss_snapshot = SSSnapshot(
            correlation_score=confidence,
            is_stale=ce_snapshot.is_stale,
            sample_count=ce_snapshot.sample_count,
            budget_exhausted=False,
        )
        sampling_decision = self._sampling_scheduler.should_sample(ss_snapshot)
        sampling_rate = sampling_decision.sampling_rate

        # Get budget info
        remaining = self._budget_manager.remaining_budget()
        report = self._budget_manager.get_report()
        budget_remaining = float(remaining)
        budget_used = float(report.total_all_time_spend)
        budget_exhausted = remaining <= Decimal("0")

        return ConfidenceSnapshot(
            task_name=task_name,
            confidence_score=confidence,
            phase=phase,
            sampling_rate=sampling_rate,
            budget_remaining_usd=budget_remaining,
            budget_used_usd=budget_used,
            budget_exhausted=budget_exhausted,
            local_model_available=local_available,
            total_runs=self._total_runs,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
        )

    def report(self) -> SystemReport:
        """
        Returns a frozen SystemReport with comprehensive system-wide statistics.
        """
        # If wired with real components (from factory), use real APIs
        if type(self._task_registry).__name__ == 'TaskRegistry':
            return self._report_via_real()

        # Get all task names
        task_names = self._task_registry.list_tasks()

        # Build snapshots for each task
        task_snapshots = []
        global_budget_used = 0.0
        global_budget_remaining = 0.0

        for task_name in task_names:
            task_config = self._task_registry.get(task_name)
            confidence = self._confidence_engine.get_score(task_name)
            phase = self._confidence_engine.get_phase(task_name)
            sampling_rate = self._sampling_scheduler.get_rate(task_name)
            budget_remaining = self._budget_manager.get_remaining(task_name)
            budget_used = self._budget_manager.get_used(task_name)
            budget_exhausted = budget_remaining <= 0.0

            # Handle local_client.is_available() which might be sync or async.
            # report() is intentionally sync — if is_available() returns a
            # coroutine (e.g. from an AsyncMock in tests), close it cleanly
            # and default to True (local model assumed available for reporting).
            local_available_result = self._local_client.is_available()
            if inspect.isawaitable(local_available_result):
                local_available_result.close()
                local_available = True
            else:
                local_available = local_available_result

            snapshot = ConfidenceSnapshot(
                task_name=task_name,
                confidence_score=confidence,
                phase=phase,
                sampling_rate=sampling_rate,
                budget_remaining_usd=budget_remaining,
                budget_used_usd=budget_used,
                budget_exhausted=budget_exhausted,
                local_model_available=local_available,
                total_runs=0,  # Simplified
                timestamp_utc=datetime.now(timezone.utc).isoformat(),
            )
            task_snapshots.append(snapshot)

            global_budget_used += budget_used
            global_budget_remaining += budget_remaining

        # Calculate uptime
        if self._start_time_utc is not None:
            uptime_seconds = (datetime.now(timezone.utc) - self._start_time_utc).total_seconds()
        else:
            uptime_seconds = 0.0

        return SystemReport(
            task_snapshots=task_snapshots,
            global_budget_used_usd=global_budget_used,
            global_budget_remaining_usd=global_budget_remaining,
            total_runs=self._total_runs,
            total_local_runs=self._total_local_runs,
            total_remote_runs=self._total_remote_runs,
            total_fallbacks=self._total_fallbacks,
            total_errors=self._total_errors,
            uptime_seconds=uptime_seconds,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
        )

    def _report_via_real(self) -> SystemReport:
        """Report using real component APIs (factory-wired)."""
        from decimal import Decimal

        # Get all task names from real TaskRegistry
        task_names = sorted(self._task_registry.task_names)

        task_snapshots = []

        # Budget is global, not per-task
        remaining = self._budget_manager.remaining_budget()
        budget_report = self._budget_manager.get_report()
        global_budget_used = float(budget_report.total_all_time_spend)
        global_budget_remaining = float(remaining)

        phase_map = {
            "REMOTE_ONLY": PhaseLabel.bootstrapping,
            "COACHING": PhaseLabel.active_learning,
            "COACHING_FULL": PhaseLabel.active_learning,
            "LOCAL_PRIMARY": PhaseLabel.supervised,
            "LOCAL_ONLY": PhaseLabel.autonomous,
        }

        for task_name in task_names:
            # Get example count
            example_count = 0
            try:
                counts = self._training_data_store.get_example_count(task_name)
                example_count = counts.total
            except Exception:
                pass

            # Get confidence snapshot (sync call, local_available defaults to True for report)
            ce_snapshot = self._confidence_engine.get_snapshot(
                task_id=task_name,
                example_count=example_count,
                local_model_available=True,
            )
            confidence = ce_snapshot.correlation_score if ce_snapshot.correlation_score is not None else 0.0
            phase = phase_map.get(ce_snapshot.phase, PhaseLabel.bootstrapping)

            # Get sampling rate
            from apprentice.sampling_scheduler import ConfidenceSnapshot as SSSnapshot
            ss_snapshot = SSSnapshot(
                correlation_score=confidence,
                is_stale=ce_snapshot.is_stale,
                sample_count=ce_snapshot.sample_count,
                budget_exhausted=remaining <= Decimal("0"),
            )
            sampling_decision = self._sampling_scheduler.should_sample(ss_snapshot)

            snapshot = ConfidenceSnapshot(
                task_name=task_name,
                confidence_score=confidence,
                phase=phase,
                sampling_rate=sampling_decision.sampling_rate,
                budget_remaining_usd=global_budget_remaining,
                budget_used_usd=global_budget_used,
                budget_exhausted=remaining <= Decimal("0"),
                local_model_available=True,
                total_runs=self._total_runs,
                timestamp_utc=datetime.now(timezone.utc).isoformat(),
            )
            task_snapshots.append(snapshot)

        # Calculate uptime
        if self._start_time_utc is not None:
            uptime_seconds = (datetime.now(timezone.utc) - self._start_time_utc).total_seconds()
        else:
            uptime_seconds = 0.0

        return SystemReport(
            task_snapshots=task_snapshots,
            global_budget_used_usd=global_budget_used,
            global_budget_remaining_usd=global_budget_remaining,
            total_runs=self._total_runs,
            total_local_runs=self._total_local_runs,
            total_remote_runs=self._total_remote_runs,
            total_fallbacks=self._total_fallbacks,
            total_errors=self._total_errors,
            uptime_seconds=uptime_seconds,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
        )


# ── Auto-injected export aliases (Pact export gate) ──
status = RunStatus
report = SystemReport
