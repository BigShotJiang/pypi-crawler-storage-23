"""CLI entry point for Apprentice."""

from apprentice.cli.cli import *  # noqa: F401,F403
