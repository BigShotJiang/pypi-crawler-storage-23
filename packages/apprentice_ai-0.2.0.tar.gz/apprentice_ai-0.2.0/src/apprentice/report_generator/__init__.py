"""Report generation for Apprentice."""

from apprentice.report_generator.report_generator import *  # noqa: F401,F403
