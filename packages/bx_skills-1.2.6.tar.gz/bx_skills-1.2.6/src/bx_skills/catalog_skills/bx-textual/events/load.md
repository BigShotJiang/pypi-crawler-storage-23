*API reference: `textual.events.Load`*


## See also

- [Mount](mount.md) - Sent when a widget is added to the DOM (after Load)
- [Events guide](../guide/events.md) - Introduction to Textual's event system
