*API reference: `textual.events.ScreenResume`*


## See also

- [ScreenSuspend](screen_suspend.md) - The complementary event sent when a screen is suspended
- [Screens guide](../guide/screens.md) - Guide to working with screens
- [Events guide](../guide/events.md) - Introduction to Textual's event system
