*API reference: `textual.content`*

## See also

- [Guide: Content](../guide/content.md) - In-depth guide to content rendering
