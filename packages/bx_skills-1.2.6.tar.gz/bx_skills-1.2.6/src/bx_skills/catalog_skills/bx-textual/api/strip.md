*API reference: `textual.strip`*
