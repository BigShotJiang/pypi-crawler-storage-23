*API reference: `textual.style`*

## See also

- [Guide: Styles](../guide/styles.md) - In-depth guide to styling in Textual
