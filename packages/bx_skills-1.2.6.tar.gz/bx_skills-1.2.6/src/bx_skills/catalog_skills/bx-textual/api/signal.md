*API reference: `textual.signal`*

## See also

- [Guide: Reactivity](../guide/reactivity.md) - In-depth guide to reactivity and signals
