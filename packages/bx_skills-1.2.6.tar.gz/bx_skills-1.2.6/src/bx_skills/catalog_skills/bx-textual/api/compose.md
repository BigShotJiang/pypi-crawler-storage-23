*API reference: `textual.compose.compose`*
