# On

*API reference: `textual.on`*

## See also

- [Guide: Events](../guide/events.md) - In-depth guide to the on decorator and event handling
