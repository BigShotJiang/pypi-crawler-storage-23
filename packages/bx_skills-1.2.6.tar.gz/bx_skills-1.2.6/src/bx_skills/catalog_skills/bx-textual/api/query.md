*API reference: `textual.css.query`*

## See also

- [Guide: Queries](../guide/queries.md) - In-depth guide to querying the DOM
