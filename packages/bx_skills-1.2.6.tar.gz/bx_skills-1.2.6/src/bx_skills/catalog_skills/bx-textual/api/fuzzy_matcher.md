*API reference: `textual.fuzzy`*
