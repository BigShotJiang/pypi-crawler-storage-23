*API reference: `textual.coordinate`*
