"""Models and schemas for agentic correction (to be implemented via TDD)."""

__all__ = []


