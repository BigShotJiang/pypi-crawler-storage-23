"""
open-stock-data: Core library for stock/crypto data with multi-source failover

提供股票、加密货币数据获取的核心库，支持多数据源自动故障转移。
"""

__version__ = "0.1.0"
