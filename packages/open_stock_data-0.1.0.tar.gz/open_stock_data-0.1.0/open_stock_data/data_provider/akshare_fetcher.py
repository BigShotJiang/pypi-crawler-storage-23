"""
Akshare 数据获取器 (优先级 2)
使用 akshare 库获取股票数据，支持多数据源（东财、新浪、腾讯）及多市场
"""

import logging
from typing import Optional, Dict, List

import pandas as pd
import akshare as ak
import requests.exceptions
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from .base import BaseFetcher, DataFetchError
from .types import (
    UnifiedRealtimeQuote,
    ChipDistribution,
    RealtimeSource,
    safe_float,
    is_etf_code,
    is_hk_code,
)

_LOGGER = logging.getLogger(__name__)


class AkshareFetcher(BaseFetcher):
    """Akshare 数据获取器"""

    name = "AkshareFetcher"
    priority = 2  # 多市场支持

    def __init__(self):
        super().__init__()

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, TimeoutError)),
        reraise=True
    )
    def _fetch_raw_data(
        self,
        stock_code: str,
        start_date: str,
        end_date: str
    ) -> Optional[pd.DataFrame]:
        """获取原始数据"""
        self.random_sleep(2.0, 5.0)

        try:
            if is_hk_code(stock_code):
                return self._fetch_hk_data(stock_code, start_date, end_date)
            elif is_etf_code(stock_code):
                return self._fetch_etf_data(stock_code, start_date, end_date)
            else:
                return self._fetch_stock_data(stock_code, start_date, end_date)
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取 {stock_code} 原始数据失败: {e}")
            raise DataFetchError(f"获取数据失败: {e}")

    def _fetch_stock_data(
        self,
        stock_code: str,
        start_date: str,
        end_date: str
    ) -> Optional[pd.DataFrame]:
        """获取 A 股数据"""
        try:
            df = ak.stock_zh_a_hist(
                symbol=stock_code,
                period="daily",
                start_date=start_date,
                end_date=end_date,
                adjust="qfq"  # 前复权
            )
            return df
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取 A 股数据失败: {e}")
            return None

    def _fetch_etf_data(
        self,
        stock_code: str,
        start_date: str,
        end_date: str
    ) -> Optional[pd.DataFrame]:
        """获取 ETF 数据"""
        try:
            df = ak.fund_etf_hist_em(
                symbol=stock_code,
                period="daily",
                start_date=start_date,
                end_date=end_date,
                adjust="qfq"
            )
            return df
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取 ETF 数据失败: {e}")
            return None

    def _fetch_hk_data(
        self,
        stock_code: str,
        start_date: str,
        end_date: str
    ) -> Optional[pd.DataFrame]:
        """获取港股数据"""
        try:
            # 清理港股代码
            code = stock_code.lower().replace('hk', '').lstrip('0')
            df = ak.stock_hk_hist(
                symbol=code,
                period="daily",
                start_date=start_date,
                end_date=end_date,
                adjust="qfq"
            )
            return df
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取港股数据失败: {e}")
            return None

    def _normalize_data(
        self,
        df: pd.DataFrame,
        stock_code: str
    ) -> pd.DataFrame:
        """标准化数据"""
        if df is None or df.empty:
            return pd.DataFrame()

        # Akshare 列名映射
        column_mapping = {
            '日期': 'date',
            '开盘': 'open',
            '收盘': 'close',
            '最高': 'high',
            '最低': 'low',
            '成交量': 'volume',
            '成交额': 'amount',
            '涨跌幅': 'pct_chg',
            '换手率': 'turnover_rate',
        }

        df = df.rename(columns=column_mapping)

        # 选择标准列
        result_cols = ['date', 'open', 'high', 'low', 'close', 'volume', 'amount', 'pct_chg']
        available_cols = [col for col in result_cols if col in df.columns]
        df = df[available_cols].copy()

        return df

    def get_realtime_quote(
        self,
        stock_code: str,
        source: str = "em"
    ) -> Optional[UnifiedRealtimeQuote]:
        """
        获取实时行情

        Args:
            stock_code: 股票代码
            source: 数据源，可选 "em"(东财), "sina"(新浪), "tencent"(腾讯)
        """
        try:
            self.random_sleep(0.5, 1.5)

            if is_hk_code(stock_code):
                return self._get_hk_realtime_quote(stock_code)
            elif is_etf_code(stock_code):
                return self._get_etf_realtime_quote(stock_code)
            else:
                if source == "sina":
                    return self._get_stock_realtime_quote_sina(stock_code)
                elif source == "tencent":
                    return self._get_stock_realtime_quote_tencent(stock_code)
                else:
                    return self._get_stock_realtime_quote_em(stock_code)

        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取 {stock_code} 实时行情失败: {e}")
            return None

    def _get_stock_realtime_quote_em(self, stock_code: str) -> Optional[UnifiedRealtimeQuote]:
        """从东财获取 A 股实时行情（完整数据）"""
        try:
            df = ak.stock_zh_a_spot_em()
            if df is None or df.empty:
                return None

            # 查找股票
            row = df[df['代码'] == stock_code]
            if row.empty:
                return None

            row = row.iloc[0]
            quote = UnifiedRealtimeQuote(
                code=stock_code,
                name=row.get('名称'),
                source=RealtimeSource.AKSHARE_EM,
                price=safe_float(row.get('最新价')),
                change_pct=safe_float(row.get('涨跌幅')),
                change_amount=safe_float(row.get('涨跌额')),
                volume=safe_float(row.get('成交量')),
                amount=safe_float(row.get('成交额')),
                volume_ratio=safe_float(row.get('量比')),
                turnover_rate=safe_float(row.get('换手率')),
                amplitude=safe_float(row.get('振幅')),
                open_price=safe_float(row.get('今开')),
                high=safe_float(row.get('最高')),
                low=safe_float(row.get('最低')),
                pre_close=safe_float(row.get('昨收')),
                pe_ratio=safe_float(row.get('市盈率-动态')),
                pb_ratio=safe_float(row.get('市净率')),
                total_mv=safe_float(row.get('总市值')),
                circ_mv=safe_float(row.get('流通市值')),
                change_60d=safe_float(row.get('60日涨跌幅')),
                high_52w=safe_float(row.get('52周最高')),
                low_52w=safe_float(row.get('52周最低')),
            )

            return quote

        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 东财实时行情获取失败: {e}")
            return None

    def _get_stock_realtime_quote_sina(self, stock_code: str) -> Optional[UnifiedRealtimeQuote]:
        """从新浪获取 A 股实时行情（轻量级）"""
        try:
            # 确定市场前缀
            if stock_code.startswith(('6', '9')):
                symbol = f"sh{stock_code}"
            else:
                symbol = f"sz{stock_code}"

            df = ak.stock_zh_a_spot()
            if df is None or df.empty:
                return None

            row = df[df['代码'] == stock_code]
            if row.empty:
                return None

            row = row.iloc[0]
            quote = UnifiedRealtimeQuote(
                code=stock_code,
                name=row.get('名称'),
                source=RealtimeSource.AKSHARE_SINA,
                price=safe_float(row.get('最新价')),
                change_pct=safe_float(row.get('涨跌幅')),
                change_amount=safe_float(row.get('涨跌额')),
                volume=safe_float(row.get('成交量')),
                amount=safe_float(row.get('成交额')),
                open_price=safe_float(row.get('今开')),
                high=safe_float(row.get('最高')),
                low=safe_float(row.get('最低')),
                pre_close=safe_float(row.get('昨收')),
            )

            return quote

        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 新浪实时行情获取失败: {e}")
            return None

    def _get_stock_realtime_quote_tencent(self, stock_code: str) -> Optional[UnifiedRealtimeQuote]:
        """从腾讯获取 A 股实时行情"""
        try:
            # 腾讯行情通过新浪接口代理
            return self._get_stock_realtime_quote_sina(stock_code)
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 腾讯实时行情获取失败: {e}")
            return None

    def _get_etf_realtime_quote(self, stock_code: str) -> Optional[UnifiedRealtimeQuote]:
        """获取 ETF 实时行情"""
        try:
            df = ak.fund_etf_spot_em()
            if df is None or df.empty:
                return None

            row = df[df['代码'] == stock_code]
            if row.empty:
                return None

            row = row.iloc[0]
            quote = UnifiedRealtimeQuote(
                code=stock_code,
                name=row.get('名称'),
                source=RealtimeSource.AKSHARE_EM,
                price=safe_float(row.get('最新价')),
                change_pct=safe_float(row.get('涨跌幅')),
                volume=safe_float(row.get('成交量')),
                amount=safe_float(row.get('成交额')),
                open_price=safe_float(row.get('今开')),
                high=safe_float(row.get('最高')),
                low=safe_float(row.get('最低')),
                pre_close=safe_float(row.get('昨收')),
            )

            return quote

        except Exception as e:
            _LOGGER.warning(f"[{self.name}] ETF 实时行情获取失败: {e}")
            return None

    def _get_hk_realtime_quote(self, stock_code: str) -> Optional[UnifiedRealtimeQuote]:
        """获取港股实时行情"""
        try:
            df = ak.stock_hk_spot_em()
            if df is None or df.empty:
                return None

            # 清理港股代码
            code = stock_code.lower().replace('hk', '').lstrip('0')
            row = df[df['代码'] == code]
            if row.empty:
                return None

            row = row.iloc[0]
            quote = UnifiedRealtimeQuote(
                code=stock_code,
                name=row.get('名称'),
                source=RealtimeSource.AKSHARE_EM,
                price=safe_float(row.get('最新价')),
                change_pct=safe_float(row.get('涨跌幅')),
                volume=safe_float(row.get('成交量')),
                amount=safe_float(row.get('成交额')),
                open_price=safe_float(row.get('今开')),
                high=safe_float(row.get('最高')),
                low=safe_float(row.get('最低')),
                pre_close=safe_float(row.get('昨收')),
            )

            return quote

        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 港股实时行情获取失败: {e}")
            return None

    def get_batch_realtime_quotes(
        self,
        stock_codes: List[str]
    ) -> Dict[str, UnifiedRealtimeQuote]:
        """
        批量获取实时行情，按类型分组后批量查询

        Args:
            stock_codes: 股票代码列表

        Returns:
            股票代码 -> UnifiedRealtimeQuote 的映射
        """
        result: Dict[str, UnifiedRealtimeQuote] = {}

        # 按类型分组
        etf_codes = [c for c in stock_codes if is_etf_code(c)]
        hk_codes = [c for c in stock_codes if is_hk_code(c)]
        a_codes = [c for c in stock_codes if not is_etf_code(c) and not is_hk_code(c)]

        # 批量获取 ETF
        if etf_codes:
            try:
                self.random_sleep(0.5, 1.5)
                df = ak.fund_etf_spot_em()
                if df is not None and not df.empty:
                    for code in etf_codes:
                        row = df[df['代码'] == code]
                        if not row.empty:
                            row = row.iloc[0]
                            quote = UnifiedRealtimeQuote(
                                code=code,
                                name=row.get('名称'),
                                source=RealtimeSource.AKSHARE_EM,
                                price=safe_float(row.get('最新价')),
                                change_pct=safe_float(row.get('涨跌幅')),
                                volume=safe_float(row.get('成交量')),
                                amount=safe_float(row.get('成交额')),
                                open_price=safe_float(row.get('开盘价')),
                                high=safe_float(row.get('最高价')),
                                low=safe_float(row.get('最低价')),
                                pre_close=safe_float(row.get('昨收')),
                            )
                            result[code] = quote
            except Exception as e:
                _LOGGER.warning(f"[{self.name}] 批量获取 ETF 实时行情失败: {e}")

        # 批量获取 A 股
        if a_codes:
            try:
                self.random_sleep(0.5, 1.5)
                df = ak.stock_zh_a_spot_em()
                if df is not None and not df.empty:
                    for code in a_codes:
                        row = df[df['代码'] == code]
                        if not row.empty:
                            row = row.iloc[0]
                            quote = UnifiedRealtimeQuote(
                                code=code,
                                name=row.get('名称'),
                                source=RealtimeSource.AKSHARE_EM,
                                price=safe_float(row.get('最新价')),
                                change_pct=safe_float(row.get('涨跌幅')),
                                change_amount=safe_float(row.get('涨跌额')),
                                volume=safe_float(row.get('成交量')),
                                amount=safe_float(row.get('成交额')),
                                volume_ratio=safe_float(row.get('量比')),
                                turnover_rate=safe_float(row.get('换手率')),
                                amplitude=safe_float(row.get('振幅')),
                                open_price=safe_float(row.get('今开')),
                                high=safe_float(row.get('最高')),
                                low=safe_float(row.get('最低')),
                                pre_close=safe_float(row.get('昨收')),
                                pe_ratio=safe_float(row.get('市盈率-动态')),
                                pb_ratio=safe_float(row.get('市净率')),
                                total_mv=safe_float(row.get('总市值')),
                                circ_mv=safe_float(row.get('流通市值')),
                            )
                            result[code] = quote
            except Exception as e:
                _LOGGER.warning(f"[{self.name}] 批量获取 A股 实时行情失败: {e}")

        # 批量获取港股
        if hk_codes:
            try:
                self.random_sleep(0.5, 1.5)
                df = ak.stock_hk_spot_em()
                if df is not None and not df.empty:
                    for code in hk_codes:
                        clean_code = code.lower().replace('hk', '').lstrip('0')
                        row = df[df['代码'] == clean_code]
                        if not row.empty:
                            row = row.iloc[0]
                            quote = UnifiedRealtimeQuote(
                                code=code,
                                name=row.get('名称'),
                                source=RealtimeSource.AKSHARE_EM,
                                price=safe_float(row.get('最新价')),
                                change_pct=safe_float(row.get('涨跌幅')),
                                volume=safe_float(row.get('成交量')),
                                amount=safe_float(row.get('成交额')),
                                open_price=safe_float(row.get('今开')),
                                high=safe_float(row.get('最高')),
                                low=safe_float(row.get('最低')),
                                pre_close=safe_float(row.get('昨收')),
                            )
                            result[code] = quote
            except Exception as e:
                _LOGGER.warning(f"[{self.name}] 批量获取港股实时行情失败: {e}")

        return result

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=3, min=3, max=30),
        retry=retry_if_exception_type((ConnectionError, TimeoutError, OSError)),
        reraise=True
    )
    def get_chip_distribution(self, stock_code: str) -> Optional[ChipDistribution]:
        """获取筹码分布（使用 @retry 装饰器）"""
        # 增加延迟避免反爬虫
        self.random_sleep(2.0, 4.0)

        try:
            df = ak.stock_cyq_em(symbol=stock_code)
            if df is None or df.empty:
                return None

            # 取最新一天数据
            latest = df.iloc[-1]

            chip = ChipDistribution(
                code=stock_code,
                date=str(latest.get('日期', '')),
                source="akshare",
                profit_ratio=safe_float(latest.get('获利比例')),
                avg_cost=safe_float(latest.get('平均成本')),
                cost_90_low=safe_float(latest.get('90成本-低')),
                cost_90_high=safe_float(latest.get('90成本-高')),
                concentration_90=safe_float(latest.get('90集中度')),
                cost_70_low=safe_float(latest.get('70成本-低')),
                cost_70_high=safe_float(latest.get('70成本-高')),
                concentration_70=safe_float(latest.get('70集中度')),
            )

            return chip
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取筹码分布失败: {e}")
            return None

    def get_fund_flow(self, stock_code: str) -> Optional[pd.DataFrame]:
        """获取资金流向"""
        try:
            self.random_sleep(1.0, 2.0)

            # 尝试上证
            df = None
            for market in ("sh", "sz"):
                try:
                    df = ak.stock_individual_fund_flow(stock=stock_code, market=market)
                    if df is not None and not df.empty:
                        break
                except Exception:  # 尝试另一个市场
                    continue

            return df
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取资金流向失败: {e}")
            return None

    def get_belong_board(self, stock_code: str) -> Optional[pd.DataFrame]:
        """获取所属板块（回退到全部行业板块列表）"""
        try:
            self.random_sleep(1.0, 2.0)

            industry_boards = ak.stock_board_industry_name_em()
            if industry_boards is not None and not industry_boards.empty:
                industry_boards.sort_values("涨跌幅", ascending=False, inplace=True)
                top_bottom = pd.concat([industry_boards.head(15), industry_boards.tail(15)])
                return top_bottom

            return None
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取板块信息失败: {e}")
            return None

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=2, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, TimeoutError, OSError, requests.exceptions.RequestException)),
        reraise=True
    )
    def get_board_cons(self, board_name: str, board_type: str = "industry") -> Optional[pd.DataFrame]:
        """获取板块成分股（先查找精确板块名再获取成分股，带重试机制）"""
        self.random_sleep(0.5, 1.5)

        # 1. 先获取板块列表，查找精确匹配的板块名
        if board_type == "concept":
            boards = ak.stock_board_concept_name_em()
        else:
            boards = ak.stock_board_industry_name_em()

        if boards is None or boards.empty:
            _LOGGER.warning(f"[{self.name}] 获取板块列表为空")
            return None

        # 2. 精确匹配或模糊匹配板块名
        exact_match = boards[boards["板块名称"] == board_name]
        if exact_match.empty:
            # 尝试模糊匹配
            fuzzy_match = boards[boards["板块名称"].str.contains(board_name, na=False)]
            if fuzzy_match.empty:
                _LOGGER.warning(f"[{self.name}] 未找到板块: {board_name}")
                return None
            matched_name = fuzzy_match.iloc[0]["板块名称"]
            _LOGGER.info(f"[{self.name}] 模糊匹配板块: {board_name} -> {matched_name}")
        else:
            matched_name = exact_match.iloc[0]["板块名称"]

        # 3. 使用精确板块名获取成分股
        self.random_sleep(0.5, 1.0)
        if board_type == "concept":
            df = ak.stock_board_concept_cons_em(symbol=matched_name)
        else:
            df = ak.stock_board_industry_cons_em(symbol=matched_name)

        return df

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=2, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, TimeoutError, OSError, requests.exceptions.RequestException)),
        reraise=True
    )
    def get_billboard(self, days: str = "5") -> Optional[pd.DataFrame]:
        """获取龙虎榜统计（带重试机制）"""
        self.random_sleep(1.0, 2.0)

        df = ak.stock_lhb_ggtj_sina(symbol=days)
        return df

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=2, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, TimeoutError, OSError, requests.exceptions.RequestException)),
        reraise=True
    )
    def get_margin_detail(self, stock_code: str, market: str = "sh") -> Optional[pd.DataFrame]:
        """
        获取融资融券明细（带重试机制）

        Args:
            stock_code: 股票代码
            market: 市场 'sh'(上交所) 或 'sz'(深交所)

        Returns:
            DataFrame 或 None
        """
        self.random_sleep(1.0, 2.0)

        try:
            if market == "sh":
                df = ak.stock_margin_detail_sse(date="")
                if df is not None and not df.empty and stock_code:
                    if "标的证券代码" in df.columns:
                        df = df[df["标的证券代码"].astype(str).str.contains(stock_code)]
                return df
            else:
                df = ak.stock_margin_detail_szse(date="")
                if df is not None and not df.empty and stock_code:
                    if "证券代码" in df.columns:
                        df = df[df["证券代码"].astype(str).str.contains(stock_code)]
                return df
        except TypeError as e:
            # akshare深交所接口bug: Expected file path name or file-like object, got <class 'bytes'> type
            _LOGGER.warning(f"[{self.name}] akshare深交所融资融券接口异常（可能是库版本bug）: {e}")
            return None

    def get_margin_ratio(self, stock_code: str) -> Optional[pd.DataFrame]:
        """获取融资融券比例（备用数据源）"""
        try:
            self.random_sleep(0.5, 1.5)
            df = ak.stock_margin_ratio_pa()
            if df is not None and not df.empty:
                if "证券代码" in df.columns:
                    filtered = df[df["证券代码"].astype(str).str.contains(stock_code)]
                    if not filtered.empty:
                        return filtered
            return None
        except Exception as e:
            _LOGGER.warning(f"[{self.name}] 获取融资融券比例失败: {e}")
            return None
