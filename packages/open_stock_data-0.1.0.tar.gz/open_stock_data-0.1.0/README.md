# open-stock-data

Core library for stock/crypto data with multi-source failover.

Provides 47 tool functions for A-stock, HK, US stock, and crypto data with automatic failover across 6 data sources.

## Install

```bash
pip install open-stock-data
```

## Usage

```python
from open_stock_data.tools import stock_prices, get_current_time

# Get stock prices
print(stock_prices(symbol="600519", market="sh", limit=5))

# Get current time
print(get_current_time())
```
