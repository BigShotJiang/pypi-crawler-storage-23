from bizyairsdk import tensor_to_bytesio

from .trd_nodes_base import BizyAirTrdApiBaseNode


class Sora_V2_I2V_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "Sora2 Image To Video"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"sora-2": "sora-2","sora-2-pro": "sora-2-pro"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Sora"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "image": ("IMAGE", {"tooltip": "首帧图片"}),
                "model": (["sora-2", "sora-2-pro"], {"default": "sora-2"}),
            },
            "optional": {
                "aspect_ratio": (
                    ["9:16", "16:9"],
                    {"default": "16:9"},
                ),
                "duration": ([10, 15], {"default": 10}),
                "size": (["small", "large"], {"default": "small"}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # 参数
        aspect_ratio = kwargs.get("aspect_ratio", "16:9")
        duration = kwargs.get("duration", 10)
        size = kwargs.get("size", "small")
        model = kwargs.get("model", "sora-2")
        prompt = kwargs.get("prompt", "")
        image = kwargs.get("image", None)
        if image is None:
            raise ValueError("Image is required")
        # 上传图片
        url = self.upload_file(
            tensor_to_bytesio(image=image, total_pixels=4096 * 4096),
            f"{prompt_id}.png",
            headers,
        )

        data = {
            "model": model,
            "aspect_ratio": aspect_ratio,
            "duration": duration,
            "size": size,
            "prompt": prompt,
            "url": url,
        }
        return data, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Sora_V2_T2V_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "Sora2 Text To Video"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"sora-2": "sora-2","sora-2-pro": "sora-2-pro"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Sora"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (["sora-2", "sora-2-pro"], {"default": "sora-2"}),
            },
            "optional": {
                "aspect_ratio": (
                    ["9:16", "16:9"],
                    {"default": "16:9"},
                ),
                "duration": ([10, 15], {"default": 10}),
                "size": (["small", "large"], {"default": "small"}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "sora-2")
        duration = kwargs.get("duration", 10)
        aspect_ratio = kwargs.get("aspect_ratio", "16:9")
        size = kwargs.get("size", "small")
        prompt = kwargs.get("prompt", "")
        data = {
            "model": model,
            "duration": duration,
            "size": size,
            "prompt": prompt,
            "aspect_ratio": aspect_ratio,
        }
        return data, model

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Sora_V2_OFFICIAL_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "Sora2 Official Generate Video"
    RETURN_TYPES = ("VIDEO", "STRING", "STRING", """{"sora-2": "sora-2-official"}""")
    RETURN_NAMES = ("video", "video_id", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Sora"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (["sora-2"], {"default": "sora-2"}),
            },
            "optional": {
                "image": ("IMAGE", {"tooltip": "首帧图片"}),
                "size": (
                    ["1280x720", "720x1280"],
                    {"default": "720x1280"},
                ),
                "duration": ([4, 8, 12], {"default": 4}),
                "remix_video_id": ("STRING",),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "sora-2")
        duration = kwargs.get("duration", 4)
        size = kwargs.get("size", "720x1280")
        prompt = kwargs.get("prompt", "")
        remix_video_id = kwargs.get("remix_video_id", "")
        image = kwargs.get("image", None)
        data = {
            "model": model,
            "duration": duration,
            "size": size,
            "prompt": prompt,
            "remix_video_id": remix_video_id,
        }
        if image is not None:
            # 上传图片
            url = self.upload_file(
                tensor_to_bytesio(image=image, total_pixels=4096 * 4096),
                f"{prompt_id}.png",
                headers,
            )
            data["url"] = url
        return data, "sora-2-official"

    def handle_outputs(self, outputs):
        video = outputs[0][0]
        text = ""
        if outputs[2]:
            text = outputs[2][0]
        urls_str = outputs[3]
        return (video, text, urls_str, "")
