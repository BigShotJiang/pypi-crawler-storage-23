# inscript/ast_nodes.py
# Phase 2: Abstract Syntax Tree Node Definitions
#
# Every construct in InScript source code maps to one of these nodes.
# The Parser builds a tree of these nodes. The Interpreter/Compiler walks the tree.
#
# Convention:
#   - Statement nodes  → classes ending in "Stmt"
#   - Expression nodes → classes ending in "Expr"
#   - Declaration nodes → classes ending in "Decl"
#   - Top-level node   → Program

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Any


# ─────────────────────────────────────────────────────────────────────────────
# BASE NODE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Node:
    line: int = field(default=0, repr=False, kw_only=True)
    col:  int = field(default=0, repr=False, kw_only=True)


# ─────────────────────────────────────────────────────────────────────────────
# PROGRAM  (root of every InScript file)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Program(Node):
    """Root node. Contains all top-level statements."""
    body: List[Node] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# TYPE ANNOTATIONS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TypeAnnotation(Node):
    name:      str
    generics:  List["TypeAnnotation"] = field(default_factory=list)
    is_array:  bool = False
    is_dict:   bool = False
    key_type:  Optional["TypeAnnotation"] = None
    nullable:  bool = False


# ─────────────────────────────────────────────────────────────────────────────
# LITERAL EXPRESSIONS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class IntLiteralExpr(Node):
    value: int

@dataclass
class FloatLiteralExpr(Node):
    value: float

@dataclass
class StringLiteralExpr(Node):
    value: str

@dataclass
class BoolLiteralExpr(Node):
    value: bool

@dataclass
class NullLiteralExpr(Node):
    pass

@dataclass
class ArrayLiteralExpr(Node):
    """[1, 2, 3]"""
    elements: List[Node] = field(default_factory=list)

@dataclass
class DictLiteralExpr(Node):
    """{"key": value, ...}  — list of (key_expr, value_expr) tuples"""
    pairs: List[tuple] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# IDENTIFIER + ACCESS EXPRESSIONS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class IdentExpr(Node):
    name: str

@dataclass
class GetAttrExpr(Node):
    """player.health"""
    obj:  Node
    attr: str

@dataclass
class SetAttrExpr(Node):
    """player.health = 100"""
    obj:   Node
    attr:  str
    value: Node

@dataclass
class IndexExpr(Node):
    """arr[0]"""
    obj:   Node
    index: Node

@dataclass
class SetIndexExpr(Node):
    """arr[0] = 5"""
    obj:   Node
    index: Node
    value: Node

@dataclass
class NamespaceAccessExpr(Node):
    """Color::RED"""
    namespace: str
    member:    str


# ─────────────────────────────────────────────────────────────────────────────
# OPERATOR EXPRESSIONS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BinaryExpr(Node):
    left:  Node
    op:    str
    right: Node

@dataclass
class UnaryExpr(Node):
    op:      str
    operand: Node

@dataclass
class TernaryExpr(Node):
    """condition ? then_expr : else_expr"""
    condition: Node
    then_expr: Node
    else_expr: Node


# ─────────────────────────────────────────────────────────────────────────────
# ASSIGNMENT EXPRESSIONS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AssignExpr(Node):
    """x = 5  |  x += 3  |  arr[0] = 9  |  obj.field = v"""
    target: Node
    op:     str
    value:  Node


# ─────────────────────────────────────────────────────────────────────────────
# CALL + LAMBDA
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Argument(Node):
    value: Node
    name:  Optional[str] = None   # None = positional

@dataclass
class CallExpr(Node):
    callee: Node
    args:   List[Argument] = field(default_factory=list)

@dataclass
class LambdaExpr(Node):
    """|x, y| x + y   or   |x: int| -> int { return x * 2 }"""
    params:      List["Param"]
    return_type: Optional[TypeAnnotation]
    body:        Node   # BlockStmt or single expression (implicit return)


# ─────────────────────────────────────────────────────────────────────────────
# RANGE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RangeExpr(Node):
    """0..10 (exclusive)  |  0..=10 (inclusive)"""
    start:     Node
    end:       Node
    inclusive: bool = False


# ─────────────────────────────────────────────────────────────────────────────
# STATEMENTS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BlockStmt(Node):
    body: List[Node] = field(default_factory=list)

@dataclass
class ExprStmt(Node):
    expr: Node

@dataclass
class ReturnStmt(Node):
    value: Optional[Node] = None

@dataclass
class BreakStmt(Node):
    pass

@dataclass
class ContinueStmt(Node):
    pass

@dataclass
class PrintStmt(Node):
    """Built-in print(...) statement."""
    args: List[Node] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# DECLARATIONS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class VarDecl(Node):
    """let x: int = 5   |   const MAX = 100   |   sync let pos: Vec2"""
    name:        str
    is_const:    bool
    type_ann:    Optional[TypeAnnotation]
    initializer: Optional[Node]
    is_sync:     bool = False

@dataclass
class Param(Node):
    """Function parameter: `name: type [= default]`"""
    name:     str
    type_ann: Optional[TypeAnnotation]
    default:  Optional[Node] = None

@dataclass
class FunctionDecl(Node):
    """fn name(params) -> return_type { body }"""
    name:        str
    params:      List[Param]
    return_type: Optional[TypeAnnotation]
    body:        "BlockStmt"
    is_method:   bool = False
    is_rpc:      bool = False

@dataclass
class StructField(Node):
    """health: int = 100"""
    name:     str
    type_ann: TypeAnnotation
    default:  Optional[Node] = None

@dataclass
class StructDecl(Node):
    """struct Player { fields... methods... }"""
    name:    str
    fields:  List[StructField]
    methods: List[FunctionDecl]

@dataclass
class StructInitExpr(Node):
    """Player { pos: Vec2(0, 0), health: 100 }"""
    struct_name: str
    fields:      List[tuple]   # [(field_name, value_expr), ...]


# ─────────────────────────────────────────────────────────────────────────────
# CONTROL FLOW
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class IfStmt(Node):
    """if cond { ... } else if ... { ... } else { ... }"""
    condition:   Node
    then_branch: "BlockStmt"
    else_branch: Optional[Node] = None   # IfStmt | BlockStmt | None

@dataclass
class WhileStmt(Node):
    condition: Node
    body:      "BlockStmt"

@dataclass
class ForInStmt(Node):
    """for item in iterable { body }"""
    var_name: str
    iterable: Node
    body:     "BlockStmt"

@dataclass
class MatchArm(Node):
    pattern: Optional[Node]   # None = wildcard _
    body:    "BlockStmt"

@dataclass
class MatchStmt(Node):
    subject: Node
    arms:    List[MatchArm]


# ─────────────────────────────────────────────────────────────────────────────
# SCENE DECLARATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LifecycleHook(Node):
    """on_start { }  |  on_update(dt: float) { }  |  on_draw { }"""
    hook_type: str          # "on_start" | "on_update" | "on_draw" | "on_exit"
    params:    List[Param]
    body:      "BlockStmt"

@dataclass
class SceneDecl(Node):
    """scene GameScene { vars... hooks... methods... }"""
    name:    str
    vars:    List[VarDecl]
    hooks:   List[LifecycleHook]
    methods: List[FunctionDecl]


# ─────────────────────────────────────────────────────────────────────────────
# AI DECLARATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AIState(Node):
    name:  str
    hooks: List[LifecycleHook]

@dataclass
class AIDecl(Node):
    """ai ZombieAI { state Idle { ... } state Chase { ... } }"""
    name:   str
    states: List[AIState]


# ─────────────────────────────────────────────────────────────────────────────
# SHADER DECLARATION
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ShaderUniform(Node):
    """uniform time: float = 0.0"""
    name:     str
    type_ann: TypeAnnotation
    default:  Optional[Node] = None

@dataclass
class ShaderDecl(Node):
    """shader GlowShader { uniforms... vertex { ... } fragment { ... } }"""
    name:     str
    uniforms: List[ShaderUniform]
    vertex:   Optional[FunctionDecl]
    fragment: Optional[FunctionDecl]


# ─────────────────────────────────────────────────────────────────────────────
# IMPORT
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ImportDecl(Node):
    """import "physics"  |  from "ui" import Button, Label  |  import "x" as X"""
    path:  str
    names: List[str]
    alias: Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# VISITOR PATTERN
# ─────────────────────────────────────────────────────────────────────────────

class Visitor:
    """
    Subclass this in the Interpreter, Analyzer, Compiler.
    Call `visit(node)` to dispatch to `visit_ClassName(node)`.
    """

    def visit(self, node: Node) -> Any:
        method = getattr(self, f"visit_{type(node).__name__}", self.generic_visit)
        return method(node)

    def generic_visit(self, node: Node) -> Any:
        raise NotImplementedError(
            f"{type(self).__name__} has no handler for node type '{type(node).__name__}'"
        )


# ─────────────────────────────────────────────────────────────────────────────
# ADDITIONAL NODES (added in review pass)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ThrowStmt(Node):
    """throw ErrorExpr"""
    value: Node

@dataclass
class TryCatchStmt(Node):
    """try { body } catch (e: Error) { handler }"""
    body:      "BlockStmt"
    catch_var: Optional[str]
    catch_type: Optional[TypeAnnotation]
    handler:   "BlockStmt"

@dataclass
class SpawnExpr(Node):
    """spawn Entity { components... }"""
    entity_name: str
    components:  List[tuple]   # [(component_name, {field: val}), ...]

@dataclass
class WaitStmt(Node):
    """wait(seconds)  — pause coroutine in scene hooks"""
    duration: Node

@dataclass
class EnumVariant(Node):
    name:  str
    value: Optional[Node] = None

@dataclass
class EnumDecl(Node):
    """enum Direction { North, South, East, West }"""
    name:     str
    variants: List[EnumVariant]

@dataclass
class InterfaceMethod(Node):
    name:        str
    params:      List["Param"]
    return_type: Optional["TypeAnnotation"]

@dataclass
class InterfaceDecl(Node):
    """interface Drawable { fn draw() }"""
    name:    str
    methods: List[InterfaceMethod]

@dataclass
class ImplDecl(Node):
    """impl Drawable for Player { fn draw() { ... } }"""
    trait_name:  str
    struct_name: str
    methods:     List["FunctionDecl"]

@dataclass
class RangeExpr(Node):
    """0..10 (exclusive)  |  0..=10 (inclusive)"""
    start:     Node
    end:       Node
    inclusive: bool = False

@dataclass
class LambdaExpr(Node):
    """|x, y| x + y   or   |x: int| -> int { return x * 2 }"""
    params:      List["Param"]
    return_type: Optional["TypeAnnotation"]
    body:        Node

@dataclass
class AsyncFnDecl(Node):
    """async fn fetch() -> string { await http.get(...) }"""
    fn: "FunctionDecl"

@dataclass
class AwaitExpr(Node):
    """await some_async_call()"""
    expr: Node
