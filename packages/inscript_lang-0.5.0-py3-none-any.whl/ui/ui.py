# inscript/ui/ui.py  —  Phase 17: UI System
#
# Build game UIs (menus, HUDs, inventory screens) declaratively.
#
# InScript UI syntax (mirrors this module):
#
#   ui MainMenuUI {
#       VStack(align: Center, gap: 20) {
#           Image("logo.png", width: 400)
#           Button("Play Game", on_click: || scene.load("GameScene"))
#           Button("Settings",  on_click: || ui.push(SettingsUI))
#           Button("Quit",      on_click: || app.quit())
#       }
#   }
#
#   ui HUD {
#       anchored(top_left) {
#           HealthBar(value: player.health, max: 100)
#           Text("Score: " + score, size: 24)
#       }
#       anchored(bottom_right) {
#           Minimap(world: current_world, size: 150)
#       }
#   }
#
# Features:
#   • Box model layout (flexbox-inspired)
#   • Widgets:    Text, Button, Image, Slider, Checkbox, Input,
#                 Dropdown, ScrollView, ProgressBar, Spacer, Separator,
#                 HealthBar, Minimap, Label, Icon, Tooltip
#   • Containers: VStack, HStack, Grid, Overlay, Panel, ScrollView
#   • Anchor system for HUD placement (9 anchor points)
#   • Theming:    UITheme with fonts, colors, border-radius, shadows
#   • Animations: fade, slide, scale, color tween (declarative)
#   • Events:     click, hover, focus, blur, change, key, scroll
#   • Gamepad nav:arrow-key / D-pad navigation between focusable widgets
#   • Accessibility: tab order, ARIA-like roles, high-contrast mode
#   • UIScreen:   full-screen UI root with push/pop navigation stack
#   • Render:     emit HTML, terminal ASCII, or dict (for engine renderers)
#
# Deliverable for ROADMAP_v2.md Phase 17.

from __future__ import annotations
import math, time, textwrap
from typing import Any, Callable, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum, auto


# ─────────────────────────────────────────────────────────────────────────────
# TYPES & ENUMS
# ─────────────────────────────────────────────────────────────────────────────

class Align(Enum):
    START  = "start"
    CENTER = "center"
    END    = "end"
    STRETCH = "stretch"

class Anchor(Enum):
    TOP_LEFT      = "top_left"
    TOP_CENTER    = "top_center"
    TOP_RIGHT     = "top_right"
    MIDDLE_LEFT   = "middle_left"
    CENTER        = "center"
    MIDDLE_RIGHT  = "middle_right"
    BOTTOM_LEFT   = "bottom_left"
    BOTTOM_CENTER = "bottom_center"
    BOTTOM_RIGHT  = "bottom_right"

class Axis(Enum):
    HORIZONTAL = "horizontal"
    VERTICAL   = "vertical"

class AnimEase(Enum):
    LINEAR    = "linear"
    EASE_IN   = "ease_in"
    EASE_OUT  = "ease_out"
    EASE_IO   = "ease_inout"
    BOUNCE    = "bounce"
    SPRING    = "spring"


@dataclass
class Rect:
    x: float = 0.; y: float = 0.; w: float = 0.; h: float = 0.
    def contains(self, px, py): return self.x<=px<=self.x+self.w and self.y<=py<=self.y+self.h
    def center(self): return (self.x+self.w/2, self.y+self.h/2)
    def __repr__(self): return f"Rect({self.x:.0f},{self.y:.0f},{self.w:.0f}×{self.h:.0f})"


@dataclass
class Color:
    r: float=1.; g: float=1.; b: float=1.; a: float=1.
    def to_hex(self):
        return '#{:02X}{:02X}{:02X}'.format(int(self.r*255),int(self.g*255),int(self.b*255))
    def to_rgba_css(self):
        return f"rgba({int(self.r*255)},{int(self.g*255)},{int(self.b*255)},{self.a:.2f})"
    def lerp(self, o, t):
        return Color(self.r+(o.r-self.r)*t, self.g+(o.g-self.g)*t,
                     self.b+(o.b-self.b)*t, self.a+(o.a-self.a)*t)
    @staticmethod
    def from_hex(h):
        h=h.lstrip('#')
        r,g,b=int(h[0:2],16)/255,int(h[2:4],16)/255,int(h[4:6],16)/255
        return Color(r,g,b)
    @staticmethod
    def WHITE():  return Color(1,1,1,1)
    @staticmethod
    def BLACK():  return Color(0,0,0,1)
    @staticmethod
    def TRANSPARENT(): return Color(0,0,0,0)
    @staticmethod
    def RED():    return Color(1,0,0,1)
    @staticmethod
    def GREEN():  return Color(0,0.8,0,1)
    @staticmethod
    def BLUE():   return Color(0.2,0.4,1,1)
    @staticmethod
    def GRAY():   return Color(0.5,0.5,0.5,1)
    def __repr__(self): return self.to_hex()


@dataclass
class EdgeInsets:
    top: float=0.; right: float=0.; bottom: float=0.; left: float=0.
    @staticmethod
    def all(v): return EdgeInsets(v,v,v,v)
    @staticmethod
    def symmetric(h=0., v=0.): return EdgeInsets(v,h,v,h)
    @property
    def horizontal(self): return self.left+self.right
    @property
    def vertical(self):   return self.top+self.bottom


# ─────────────────────────────────────────────────────────────────────────────
# THEME
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class UIFont:
    family: str  = "sans-serif"
    size:   float = 16.0
    bold:   bool = False
    italic: bool = False
    def css(self):
        style = "italic " if self.italic else ""
        weight = "bold " if self.bold else ""
        return f"{style}{weight}{self.size}px {self.family}"


@dataclass
class UITheme:
    # Colors
    bg:               Color = field(default_factory=lambda: Color(0.12,0.12,0.15,1))
    surface:          Color = field(default_factory=lambda: Color(0.18,0.18,0.22,1))
    surface_hover:    Color = field(default_factory=lambda: Color(0.24,0.24,0.30,1))
    surface_active:   Color = field(default_factory=lambda: Color(0.30,0.30,0.40,1))
    primary:          Color = field(default_factory=lambda: Color(0.25,0.55,1.0,1))
    primary_hover:    Color = field(default_factory=lambda: Color(0.35,0.65,1.0,1))
    accent:           Color = field(default_factory=lambda: Color(0.95,0.50,0.10,1))
    text:             Color = field(default_factory=lambda: Color(0.95,0.95,0.95,1))
    text_secondary:   Color = field(default_factory=lambda: Color(0.65,0.65,0.70,1))
    text_disabled:    Color = field(default_factory=lambda: Color(0.40,0.40,0.45,1))
    border:           Color = field(default_factory=lambda: Color(0.30,0.30,0.38,1))
    danger:           Color = field(default_factory=lambda: Color(0.90,0.25,0.25,1))
    success:          Color = field(default_factory=lambda: Color(0.20,0.78,0.40,1))
    warning:          Color = field(default_factory=lambda: Color(0.95,0.75,0.10,1))
    # Typography
    font_body:        UIFont = field(default_factory=lambda: UIFont("sans-serif",16))
    font_heading:     UIFont = field(default_factory=lambda: UIFont("sans-serif",24,bold=True))
    font_small:       UIFont = field(default_factory=lambda: UIFont("sans-serif",12))
    font_mono:        UIFont = field(default_factory=lambda: UIFont("monospace",14))
    # Geometry
    radius:           float = 6.0
    border_width:     float = 1.0
    shadow_blur:      float = 8.0
    shadow_offset:    Tuple = (0, 2)
    # Spacing
    padding:          EdgeInsets = field(default_factory=lambda: EdgeInsets.all(10))
    gap:              float = 8.0
    # Animation
    transition_ms:    float = 150.0

    @staticmethod
    def dark() -> "UITheme": return UITheme()

    @staticmethod
    def light() -> "UITheme":
        t = UITheme()
        t.bg             = Color(0.94,0.94,0.96,1)
        t.surface        = Color(1,1,1,1)
        t.surface_hover  = Color(0.92,0.92,0.96,1)
        t.surface_active = Color(0.85,0.85,0.95,1)
        t.text           = Color(0.08,0.08,0.12,1)
        t.text_secondary = Color(0.40,0.40,0.45,1)
        t.border         = Color(0.80,0.80,0.85,1)
        return t

    @staticmethod
    def high_contrast() -> "UITheme":
        t = UITheme()
        t.bg      = Color.BLACK()
        t.surface = Color(0,0,0,1)
        t.text    = Color.WHITE()
        t.primary = Color.WHITE()
        t.border  = Color.WHITE()
        return t

    @staticmethod
    def game_hud() -> "UITheme":
        t = UITheme()
        t.bg      = Color(0,0,0,0)
        t.surface = Color(0,0,0,0.6)
        t.text    = Color.WHITE()
        t.font_body = UIFont("monospace", 16)
        return t


_DEFAULT_THEME = UITheme()


# ─────────────────────────────────────────────────────────────────────────────
# ANIMATION SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

def _ease(t: float, ease: AnimEase) -> float:
    if ease == AnimEase.LINEAR:  return t
    if ease == AnimEase.EASE_IN: return t*t
    if ease == AnimEase.EASE_OUT:return t*(2-t)
    if ease == AnimEase.EASE_IO: return t*t*(3-2*t)
    if ease == AnimEase.BOUNCE:
        if t < 0.5: return 4*t*t*t
        p=2*t-2; return 0.5*p*p*p+1
    if ease == AnimEase.SPRING:
        return 1 - (math.cos(t*math.pi*4)*math.exp(-t*6))
    return t


@dataclass
class UIAnim:
    """Single property animation."""
    prop:     str
    start:    Any
    end:      Any
    duration: float          # seconds
    ease:     AnimEase = AnimEase.EASE_OUT
    delay:    float    = 0.
    loop:     bool     = False
    on_done:  Optional[Callable] = None
    _t:       float    = field(default=0., repr=False)
    _done:    bool     = field(default=False, repr=False)
    _started: float    = field(default_factory=time.time, repr=False)

    def update(self, dt: float) -> Any:
        if self._done: return self.end
        elapsed = time.time() - self._started - self.delay
        if elapsed < 0: return self.start
        self._t = min(elapsed / self.duration, 1.0)
        v = _ease(self._t, self.ease)
        if isinstance(self.start, (int, float)):
            result = self.start + (self.end - self.start) * v
        elif isinstance(self.start, Color):
            result = self.start.lerp(self.end, v)
        elif isinstance(self.start, tuple):
            result = tuple(s+(e-s)*v for s,e in zip(self.start,self.end))
        else:
            result = self.end if v > 0.5 else self.start
        if self._t >= 1.0:
            if self.loop: self._started = time.time()
            else:
                self._done = True
                if self.on_done: self.on_done()
        return result

    @property
    def done(self) -> bool: return self._done


class AnimController:
    """Manages multiple property animations on a widget."""

    def __init__(self):
        self._anims: Dict[str, UIAnim] = {}

    def play(self, prop: str, start: Any, end: Any, duration: float,
             ease: AnimEase = AnimEase.EASE_OUT, delay: float = 0.,
             loop: bool = False, on_done: Callable = None) -> "AnimController":
        self._anims[prop] = UIAnim(prop, start, end, duration, ease, delay, loop, on_done)
        return self

    def fade_in(self, duration: float = 0.2) -> "AnimController":
        return self.play('alpha', 0., 1., duration, AnimEase.EASE_OUT)

    def fade_out(self, duration: float = 0.2, on_done: Callable = None) -> "AnimController":
        return self.play('alpha', 1., 0., duration, AnimEase.EASE_IN, on_done=on_done)

    def slide_in(self, axis: Axis = Axis.VERTICAL, distance: float = 30.,
                 duration: float = 0.25) -> "AnimController":
        prop = 'offset_y' if axis == Axis.VERTICAL else 'offset_x'
        return self.play(prop, distance, 0., duration, AnimEase.EASE_OUT)

    def scale_in(self, duration: float = 0.2) -> "AnimController":
        return self.play('scale', 0., 1., duration, AnimEase.SPRING)

    def scale_bounce(self, target: float = 1.1, duration: float = 0.15) -> "AnimController":
        return self.play('scale', 1., target, duration/2, AnimEase.EASE_OUT,
                         on_done=lambda: self.play('scale', target, 1., duration/2, AnimEase.EASE_IN))

    def update(self, dt: float) -> Dict[str, Any]:
        values = {}
        done_keys = []
        for k, anim in self._anims.items():
            values[k] = anim.update(dt)
            if anim.done and not anim.loop: done_keys.append(k)
        for k in done_keys: del self._anims[k]
        return values

    def is_playing(self, prop: str = None) -> bool:
        if prop: return prop in self._anims
        return bool(self._anims)

    def stop(self, prop: str = None):
        if prop: self._anims.pop(prop, None)
        else: self._anims.clear()


# ─────────────────────────────────────────────────────────────────────────────
# EVENT SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class UIEvent:
    kind:   str           # 'click','hover','blur','focus','change','scroll','key'
    target: Any           # the widget that fired it
    data:   Any = None    # event-specific payload (e.g. new value, key code)
    x:      float = 0.
    y:      float = 0.
    consumed: bool = False

    def consume(self): self.consumed = True


class EventBus:
    """Simple pub/sub for UI events."""
    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = {}

    def on(self, event: str, fn: Callable) -> "EventBus":
        self._listeners.setdefault(event, []).append(fn); return self

    def off(self, event: str, fn: Callable = None):
        if fn: self._listeners.get(event,[]).remove(fn)
        else:  self._listeners.pop(event, None)

    def emit(self, event: UIEvent):
        for fn in self._listeners.get(event.kind, []):
            fn(event)
            if event.consumed: break


# ─────────────────────────────────────────────────────────────────────────────
# BASE WIDGET
# ─────────────────────────────────────────────────────────────────────────────

_widget_id = 0

class Widget:
    """
    Base class for all UI widgets.
    Subclasses override layout() and render_*() methods.
    """

    def __init__(self, theme: UITheme = None):
        global _widget_id
        _widget_id += 1
        self.id       = _widget_id
        self.theme    = theme or _DEFAULT_THEME

        # Layout
        self.rect     = Rect()
        self.min_w:   Optional[float] = None
        self.min_h:   Optional[float] = None
        self.max_w:   Optional[float] = None
        self.max_h:   Optional[float] = None
        self.flex:    float = 0.      # flex-grow (0 = fixed size)
        self.padding: EdgeInsets = EdgeInsets.all(0)
        self.margin:  EdgeInsets = EdgeInsets.all(0)
        self.visible: bool = True
        self.enabled: bool = True

        # Appearance
        self.alpha:   float = 1.
        self.scale:   float = 1.
        self.offset_x: float = 0.
        self.offset_y: float = 0.
        self.z_index: int = 0
        self.tooltip: Optional[str] = None
        self.aria_label: Optional[str] = None
        self.role:    str = "widget"

        # State
        self._hovered = False
        self._focused = False
        self._pressed = False
        self._tab_index: int = -1

        # Callbacks
        self.on_click:  Optional[Callable] = None
        self.on_hover:  Optional[Callable] = None
        self.on_blur:   Optional[Callable] = None
        self.on_focus:  Optional[Callable] = None
        self.on_change: Optional[Callable] = None
        self.on_key:    Optional[Callable] = None

        self.anim     = AnimController()
        self._bus     = EventBus()

        self.children: List[Widget] = []
        self.parent:   Optional[Widget] = None

        self.user_data: Any = None

    # ── Hierarchy ────────────────────────────────────────────────────────
    def add(self, child: "Widget") -> "Widget":
        child.parent = self
        if child.theme is _DEFAULT_THEME and self.theme is not _DEFAULT_THEME:
            child.theme = self.theme
        self.children.append(child)
        return child

    def remove(self, child: "Widget"):
        if child in self.children: self.children.remove(child); child.parent = None

    def clear(self):
        for c in self.children: c.parent = None
        self.children.clear()

    # ── Events ───────────────────────────────────────────────────────────
    def dispatch(self, event: UIEvent):
        """Route event to appropriate callback + bus."""
        if not self.visible or not self.enabled: return
        if event.kind == 'click'  and self.on_click:  self.on_click(event)
        if event.kind == 'hover'  and self.on_hover:  self.on_hover(event)
        if event.kind == 'focus'  and self.on_focus:  self.on_focus(event)
        if event.kind == 'blur'   and self.on_blur:   self.on_blur(event)
        if event.kind == 'change' and self.on_change: self.on_change(event)
        if event.kind == 'key'    and self.on_key:    self.on_key(event)
        self._bus.emit(event)

    def on(self, event: str, fn: Callable) -> "Widget":
        self._bus.on(event, fn); return self

    def hit_test(self, x: float, y: float) -> Optional["Widget"]:
        if not self.visible: return None
        for child in reversed(self.children):
            hit = child.hit_test(x, y)
            if hit: return hit
        if self.rect.contains(x, y): return self
        return None

    # ── Layout ───────────────────────────────────────────────────────────
    def measure(self) -> Tuple[float, float]:
        """Return (min_w, min_h) content size."""
        return (self.min_w or 0, self.min_h or 0)

    def layout(self, x: float, y: float, w: float, h: float):
        self.rect = Rect(x + self.margin.left + self.offset_x,
                         y + self.margin.top  + self.offset_y,
                         w - self.margin.horizontal,
                         h - self.margin.vertical)

    # ── Update ───────────────────────────────────────────────────────────
    def update(self, dt: float):
        values = self.anim.update(dt)
        for k, v in values.items():
            if hasattr(self, k): setattr(self, k, v)
        for child in self.children: child.update(dt)

    # ── Render (dict tree — renderer-agnostic) ───────────────────────────
    def render(self) -> Dict:
        return {
            'type': self.__class__.__name__,
            'id': self.id,
            'rect': (self.rect.x, self.rect.y, self.rect.w, self.rect.h),
            'alpha': self.alpha,
            'scale': self.scale,
            'visible': self.visible,
            'children': [c.render() for c in self.children if c.visible],
        }

    # ── CSS (for HTML renderer) ──────────────────────────────────────────
    def to_css(self) -> str:
        t = self.theme
        return (f"position:absolute;"
                f"left:{self.rect.x}px;top:{self.rect.y}px;"
                f"width:{self.rect.w}px;height:{self.rect.h}px;"
                f"opacity:{self.alpha};"
                f"transform:scale({self.scale});"
                f"box-sizing:border-box;")

    def to_html(self) -> str:
        inner = ''.join(c.to_html() for c in self.children if c.visible)
        return f'<div class="widget" style="{self.to_css()}">{inner}</div>'

    def __repr__(self): return f"{self.__class__.__name__}(id={self.id})"


# ─────────────────────────────────────────────────────────────────────────────
# LEAF WIDGETS
# ─────────────────────────────────────────────────────────────────────────────

class Text(Widget):
    """Static text label."""
    def __init__(self, text: str = "", size: float = 16., color: Color = None,
                 font: UIFont = None, align: Align = Align.START,
                 wrap: bool = False, max_width: float = None, theme: UITheme = None):
        super().__init__(theme)
        self.text      = text
        self.size      = size
        self.color     = color
        self.font      = font
        self.align     = align
        self.wrap      = wrap
        self.max_width = max_width
        self.role      = "text"

    def measure(self):
        chars = len(self.text); w = chars * self.size * 0.6
        if self.max_width: w = min(w, self.max_width)
        return (w, self.size * 1.4)

    def to_html(self):
        t = self.theme
        c = self.color or t.text
        f = self.font or t.font_body
        align_css = {'start':'left','center':'center','end':'right','stretch':'justify'}.get(self.align.value,'left')
        wrap_css  = "normal" if self.wrap else "nowrap"
        css = self.to_css() + (f"color:{c.to_rgba_css()};"
              f"font:{f.css()};font-size:{self.size}px;"
              f"text-align:{align_css};white-space:{wrap_css};"
              f"overflow:hidden;display:flex;align-items:center;")
        escaped = self.text.replace('<','&lt;').replace('>','&gt;')
        return f'<div style="{css}">{escaped}</div>'

    def __repr__(self): return f"Text({self.text!r})"


class Label(Text):
    """Alias for Text with slightly different defaults."""
    pass


class Button(Widget):
    """Clickable button widget."""
    def __init__(self, label: str = "Button", on_click: Callable = None,
                 icon: str = None, disabled: bool = False,
                 variant: str = "primary", theme: UITheme = None):
        super().__init__(theme)
        self.label    = label
        self.on_click = on_click
        self.icon     = icon
        self.enabled  = not disabled
        self.variant  = variant  # "primary" | "secondary" | "danger" | "ghost"
        self.role     = "button"
        self._tab_index = 0

    def measure(self):
        w = len(self.label) * 10 + 32
        return (max(w, 80), 40)

    def to_html(self):
        t = self.theme
        bg_map = {
            'primary':   t.primary.to_rgba_css(),
            'secondary': t.surface.to_rgba_css(),
            'danger':    t.danger.to_rgba_css(),
            'ghost':     'transparent',
        }
        bg = bg_map.get(self.variant, t.primary.to_rgba_css())
        border = f"1px solid {t.border.to_rgba_css()}" if self.variant in ('secondary','ghost') else "none"
        css = self.to_css() + (
            f"background:{bg};color:{t.text.to_rgba_css()};"
            f"border:{border};border-radius:{t.radius}px;"
            f"cursor:{'pointer' if self.enabled else 'not-allowed'};"
            f"display:flex;align-items:center;justify-content:center;"
            f"font:{t.font_body.css()};user-select:none;"
            f"padding:{t.padding.top}px {t.padding.right}px;"
            f"{'opacity:0.5;' if not self.enabled else ''}"
        )
        icon_html = f'<span style="margin-right:6px">{self.icon}</span>' if self.icon else ''
        return f'<button style="{css}" onclick="this.dispatchEvent(new CustomEvent(\'ui_click\',{{bubbles:true,detail:{{id:{self.id}}}}}))"> {icon_html}{self.label}</button>'

    def __repr__(self): return f"Button({self.label!r})"


class Image(Widget):
    """Image widget."""
    def __init__(self, src: str = "", width: float = None, height: float = None,
                 fit: str = "cover", border_radius: float = 0., theme: UITheme = None):
        super().__init__(theme)
        self.src    = src
        self.fit    = fit
        self.br     = border_radius
        if width:  self.min_w = width
        if height: self.min_h = height
        self.role   = "img"

    def measure(self): return (self.min_w or 64, self.min_h or 64)

    def to_html(self):
        css = self.to_css() + (f"object-fit:{self.fit};"
              f"border-radius:{self.br}px;overflow:hidden;")
        return f'<img src="{self.src}" alt="{self.aria_label or ''}" style="{css}">'


class Slider(Widget):
    """Horizontal (or vertical) slider."""
    def __init__(self, value: float = 0.5, min_val: float = 0., max_val: float = 1.,
                 step: float = 0., on_change: Callable = None,
                 axis: Axis = Axis.HORIZONTAL, theme: UITheme = None):
        super().__init__(theme)
        self._value  = float(value)
        self.min_val = float(min_val)
        self.max_val = float(max_val)
        self.step    = float(step)
        self.on_change = on_change
        self.axis    = axis
        self.role    = "slider"
        self._tab_index = 0
        self.min_w   = 120 if axis == Axis.HORIZONTAL else 20
        self.min_h   = 20  if axis == Axis.HORIZONTAL else 120

    @property
    def value(self) -> float: return self._value

    @value.setter
    def value(self, v: float):
        v = max(self.min_val, min(self.max_val, v))
        if self.step > 0: v = round(v / self.step) * self.step
        old = self._value; self._value = v
        if v != old and self.on_change:
            self.on_change(UIEvent('change', self, data=v))

    @property
    def fraction(self) -> float:
        r = self.max_val - self.min_val
        return (self._value - self.min_val) / r if r > 0 else 0.

    def measure(self): return (self.min_w or 120, self.min_h or 20)

    def to_html(self):
        t = self.theme; pct = self.fraction * 100
        css = self.to_css() + "display:flex;align-items:center;"
        track_css = (f"width:100%;height:4px;background:{t.border.to_rgba_css()};"
                     f"border-radius:2px;position:relative;")
        fill_css  = (f"position:absolute;left:0;top:0;height:4px;"
                     f"width:{pct}%;background:{t.primary.to_rgba_css()};"
                     f"border-radius:2px;")
        thumb_css = (f"position:absolute;left:{pct}%;top:50%;transform:translate(-50%,-50%);"
                     f"width:16px;height:16px;border-radius:50%;"
                     f"background:{t.primary.to_rgba_css()};cursor:pointer;")
        return (f'<div style="{css}"><div style="{track_css}">'
                f'<div style="{fill_css}"></div>'
                f'<div style="{thumb_css}"></div>'
                f'</div></div>')


class Checkbox(Widget):
    """Boolean checkbox."""
    def __init__(self, label: str = "", checked: bool = False,
                 on_change: Callable = None, theme: UITheme = None):
        super().__init__(theme)
        self.label   = label
        self._checked = bool(checked)
        self.on_change = on_change
        self.role    = "checkbox"
        self._tab_index = 0
        self.min_h   = 28

    @property
    def checked(self) -> bool: return self._checked

    @checked.setter
    def checked(self, v: bool):
        self._checked = bool(v)
        if self.on_change:
            self.on_change(UIEvent('change', self, data=v))

    def toggle(self): self.checked = not self._checked

    def to_html(self):
        t = self.theme
        css = self.to_css() + "display:flex;align-items:center;gap:8px;cursor:pointer;"
        check_css = (f"width:18px;height:18px;border:2px solid {t.primary.to_rgba_css()};"
                     f"border-radius:{t.radius/2}px;display:flex;align-items:center;"
                     f"justify-content:center;"
                     f"background:{''+t.primary.to_rgba_css() if self._checked else 'transparent'};")
        check = "✓" if self._checked else ""
        label_css = f"color:{t.text.to_rgba_css()};font:{t.font_body.css()};"
        return (f'<div style="{css}">'
                f'<div style="{check_css}" onclick="...">{check}</div>'
                f'<span style="{label_css}">{self.label}</span>'
                f'</div>')


class Input(Widget):
    """Single-line text input."""
    def __init__(self, value: str = "", placeholder: str = "",
                 on_change: Callable = None, password: bool = False,
                 max_length: int = 256, theme: UITheme = None):
        super().__init__(theme)
        self._value    = value
        self.placeholder = placeholder
        self.on_change = on_change
        self.password  = password
        self.max_length = max_length
        self.role      = "textbox"
        self._tab_index = 0
        self.min_h     = 38

    @property
    def value(self) -> str: return self._value
    @value.setter
    def value(self, v: str):
        self._value = v[:self.max_length]
        if self.on_change: self.on_change(UIEvent('change', self, data=self._value))

    def to_html(self):
        t = self.theme
        css = self.to_css() + (
            f"background:{t.surface.to_rgba_css()};"
            f"border:1px solid {t.border.to_rgba_css()};"
            f"border-radius:{t.radius}px;color:{t.text.to_rgba_css()};"
            f"font:{t.font_body.css()};padding:0 10px;"
            f"outline:none;box-sizing:border-box;"
        )
        typ = "password" if self.password else "text"
        safe_val = self._value.replace('"','&quot;')
        return (f'<input type="{typ}" value="{safe_val}" '
                f'placeholder="{self.placeholder}" style="{css}" '
                f'maxlength="{self.max_length}">')


class Dropdown(Widget):
    """Select/dropdown widget."""
    def __init__(self, options: List[str] = None, selected: int = 0,
                 on_change: Callable = None, theme: UITheme = None):
        super().__init__(theme)
        self.options   = options or []
        self._selected = selected
        self.on_change = on_change
        self.role      = "listbox"
        self._tab_index = 0
        self.min_h     = 38

    @property
    def value(self) -> str:
        return self.options[self._selected] if self.options else ""
    @property
    def selected_index(self) -> int: return self._selected
    @selected_index.setter
    def selected_index(self, i: int):
        self._selected = max(0, min(len(self.options)-1, i))
        if self.on_change: self.on_change(UIEvent('change', self, data=self.value))

    def to_html(self):
        t = self.theme
        css = self.to_css() + (
            f"background:{t.surface.to_rgba_css()};"
            f"border:1px solid {t.border.to_rgba_css()};"
            f"border-radius:{t.radius}px;color:{t.text.to_rgba_css()};"
            f"font:{t.font_body.css()};padding:0 10px;cursor:pointer;"
        )
        opts = ''.join(f'<option {"selected" if i==self._selected else ""}>{o}</option>'
                       for i,o in enumerate(self.options))
        return f'<select style="{css}">{opts}</select>'


class ProgressBar(Widget):
    """Horizontal progress/health bar."""
    def __init__(self, value: float = 1.0, max_val: float = 1.0,
                 color: Color = None, bg_color: Color = None,
                 height: float = 12., label: bool = False, theme: UITheme = None):
        super().__init__(theme)
        self.value     = float(value)
        self.max_val   = float(max_val)
        self._color    = color
        self._bg_color = bg_color
        self.bar_height = height
        self.show_label = label
        self.min_h     = height + 4

    @property
    def fraction(self) -> float:
        return _clamp(self.value / self.max_val if self.max_val > 0 else 0, 0, 1)

    def _bar_color(self) -> Color:
        if self._color: return self._color
        f = self.fraction
        t = self.theme
        if f > 0.6: return t.success
        if f > 0.3: return t.warning
        return t.danger

    def to_html(self):
        t  = self.theme; pct = self.fraction * 100
        bg = self._bg_color or t.surface
        fc = self._bar_color()
        css = self.to_css() + "display:flex;flex-direction:column;justify-content:center;"
        bar_bg  = f"width:100%;height:{self.bar_height}px;background:{bg.to_rgba_css()};border-radius:{self.bar_height/2}px;overflow:hidden;"
        bar_fill= f"height:100%;width:{pct}%;background:{fc.to_rgba_css()};transition:width 0.2s;"
        label_h = f'<span style="font:{t.font_small.css()};color:{t.text_secondary.to_rgba_css()};margin-top:2px;">{self.value:.0f}/{self.max_val:.0f}</span>' if self.show_label else ''
        return f'<div style="{css}"><div style="{bar_bg}"><div style="{bar_fill}"></div></div>{label_h}</div>'


class HealthBar(ProgressBar):
    """Game health bar (alias for ProgressBar with heart icon)."""
    def __init__(self, value=100., max_val=100., **kwargs):
        super().__init__(value, max_val, **kwargs)
        self.min_h = 20


class Spacer(Widget):
    """Flexible space filler."""
    def __init__(self, size: float = 0., theme: UITheme = None):
        super().__init__(theme)
        self.flex = 1.0 if size == 0 else 0.
        self.min_w = size; self.min_h = size

    def to_html(self): return f'<div style="{self.to_css()}"></div>'


class Separator(Widget):
    """Thin horizontal or vertical dividing line."""
    def __init__(self, axis: Axis = Axis.HORIZONTAL, color: Color = None, theme: UITheme = None):
        super().__init__(theme)
        self.axis  = axis
        self._color = color
        if axis == Axis.HORIZONTAL: self.min_h = 1; self.min_w = 0; self.flex = 0
        else: self.min_w = 1; self.min_h = 0; self.flex = 0

    def to_html(self):
        c = (self._color or self.theme.border).to_rgba_css()
        css = self.to_css()
        if self.axis == Axis.HORIZONTAL:
            css += f"background:{c};height:1px;width:100%;margin:4px 0;"
        else:
            css += f"background:{c};width:1px;height:100%;margin:0 4px;"
        return f'<div style="{css}"></div>'


class Tooltip(Widget):
    """Floating tooltip (shown on hover)."""
    def __init__(self, text: str, theme: UITheme = None):
        super().__init__(theme)
        self.text = text; self.visible = False

    def to_html(self):
        t = self.theme
        css = self.to_css() + (
            f"background:{t.surface.to_rgba_css()};"
            f"border:1px solid {t.border.to_rgba_css()};"
            f"border-radius:{t.radius}px;padding:6px 10px;"
            f"color:{t.text.to_rgba_css()};font:{t.font_small.css()};"
            f"white-space:nowrap;pointer-events:none;z-index:1000;"
        )
        return f'<div style="{css}">{self.text}</div>'


class Icon(Widget):
    """Unicode/emoji icon widget."""
    def __init__(self, icon: str = "★", size: float = 24., color: Color = None, theme: UITheme = None):
        super().__init__(theme)
        self.icon   = icon
        self.size   = size
        self._color = color
        self.min_w  = size; self.min_h = size

    def to_html(self):
        c = (self._color or self.theme.text).to_rgba_css()
        css = self.to_css() + (f"font-size:{self.size}px;color:{c};"
              "display:flex;align-items:center;justify-content:center;")
        return f'<div style="{css}">{self.icon}</div>'


# ─────────────────────────────────────────────────────────────────────────────
# CONTAINERS
# ─────────────────────────────────────────────────────────────────────────────

class Container(Widget):
    """Base for layout containers."""

    def __init__(self, *children: Widget, gap: float = 8.,
                 padding: EdgeInsets = None, theme: UITheme = None):
        super().__init__(theme)
        self.gap     = gap
        self.padding = padding or EdgeInsets.all(0)
        for child in children: self.add(child)

    def content_rect(self) -> Tuple[float,float,float,float]:
        return (self.rect.x + self.padding.left,
                self.rect.y + self.padding.top,
                self.rect.w - self.padding.horizontal,
                self.rect.h - self.padding.vertical)


class VStack(Container):
    """Vertical flex column."""
    def __init__(self, *children, align: Align = Align.STRETCH, gap: float = 8.,
                 padding: EdgeInsets = None, theme: UITheme = None):
        super().__init__(*children, gap=gap, padding=padding, theme=theme)
        self.align = align

    def measure(self):
        vis = [c for c in self.children if c.visible]
        if not vis: return (0, 0)
        ws = [c.measure()[0] + c.margin.horizontal for c in vis]
        hs = [c.measure()[1] + c.margin.vertical   for c in vis]
        total_h = sum(hs) + self.gap * (len(vis)-1) + self.padding.vertical
        total_w = max(ws) + self.padding.horizontal if ws else self.padding.horizontal
        return (total_w, total_h)

    def layout(self, x, y, w, h):
        super().layout(x, y, w, h)
        vis = [c for c in self.children if c.visible]
        if not vis: return
        cx, cy, cw, ch = self.content_rect()
        fixed_h  = sum(c.measure()[1]+c.margin.vertical for c in vis if c.flex==0)
        flex_sum = sum(c.flex for c in vis if c.flex > 0)
        avail_h  = ch - fixed_h - self.gap * (len(vis)-1)
        cur_y = cy
        for child in vis:
            cm = child.measure()
            if child.flex > 0 and flex_sum > 0:
                child_h = avail_h * (child.flex / flex_sum)
            else:
                child_h = cm[1] + child.margin.vertical
            if self.align == Align.STRETCH:
                child_w = cw
            elif self.align == Align.CENTER:
                child_w = cm[0]
            else:
                child_w = cm[0]
            cx_offset = {Align.CENTER: cx+(cw-child_w)/2,
                          Align.END:   cx+cw-child_w,
                          Align.START: cx}.get(self.align, cx)
            child.layout(cx_offset, cur_y, child_w, child_h)
            cur_y += child_h + self.gap

    def to_html(self):
        t = self.theme
        align_css = {'start':'flex-start','center':'center','end':'flex-end','stretch':'stretch'}.get(self.align.value,'stretch')
        css = self.to_css() + (f"display:flex;flex-direction:column;"
              f"align-items:{align_css};gap:{self.gap}px;"
              f"padding:{self.padding.top}px {self.padding.right}px "
              f"{self.padding.bottom}px {self.padding.left}px;"
              f"box-sizing:border-box;")
        inner = ''.join(c.to_html() for c in self.children if c.visible)
        return f'<div style="{css}">{inner}</div>'


class HStack(Container):
    """Horizontal flex row."""
    def __init__(self, *children, align: Align = Align.CENTER, gap: float = 8.,
                 padding: EdgeInsets = None, theme: UITheme = None):
        super().__init__(*children, gap=gap, padding=padding, theme=theme)
        self.align = align

    def measure(self):
        vis = [c for c in self.children if c.visible]
        if not vis: return (0, 0)
        ws = [c.measure()[0]+c.margin.horizontal for c in vis]
        hs = [c.measure()[1]+c.margin.vertical   for c in vis]
        total_w = sum(ws) + self.gap*(len(vis)-1) + self.padding.horizontal
        total_h = max(hs) + self.padding.vertical if hs else self.padding.vertical
        return (total_w, total_h)

    def layout(self, x, y, w, h):
        super().layout(x, y, w, h)
        vis = [c for c in self.children if c.visible]
        if not vis: return
        cx, cy, cw, ch = self.content_rect()
        fixed_w  = sum(c.measure()[0]+c.margin.horizontal for c in vis if c.flex==0)
        flex_sum = sum(c.flex for c in vis if c.flex > 0)
        avail_w  = cw - fixed_w - self.gap*(len(vis)-1)
        cur_x = cx
        for child in vis:
            cm = child.measure()
            if child.flex > 0 and flex_sum > 0:
                child_w = avail_w * (child.flex / flex_sum)
            else:
                child_w = cm[0] + child.margin.horizontal
            child_h = ch if self.align == Align.STRETCH else cm[1]
            cy_off  = {Align.CENTER: cy+(ch-child_h)/2,
                       Align.END:    cy+ch-child_h,
                       Align.START:  cy}.get(self.align, cy)
            child.layout(cur_x, cy_off, child_w, child_h)
            cur_x += child_w + self.gap

    def to_html(self):
        align_css = {'start':'flex-start','center':'center','end':'flex-end','stretch':'stretch'}.get(self.align.value,'center')
        css = self.to_css() + (f"display:flex;flex-direction:row;"
              f"align-items:{align_css};gap:{self.gap}px;"
              f"padding:{self.padding.top}px {self.padding.right}px "
              f"{self.padding.bottom}px {self.padding.left}px;"
              f"box-sizing:border-box;")
        inner = ''.join(c.to_html() for c in self.children if c.visible)
        return f'<div style="{css}">{inner}</div>'


class Grid(Container):
    """Fixed-column grid layout."""
    def __init__(self, *children, columns: int = 2, gap: float = 8.,
                 padding: EdgeInsets = None, theme: UITheme = None):
        super().__init__(*children, gap=gap, padding=padding, theme=theme)
        self.columns = columns

    def layout(self, x, y, w, h):
        super().layout(x, y, w, h)
        vis = [c for c in self.children if c.visible]
        cx, cy, cw, ch = self.content_rect()
        cell_w = (cw - self.gap*(self.columns-1)) / self.columns
        row_h  = max((c.measure()[1] for c in vis), default=40)
        for i, child in enumerate(vis):
            col = i % self.columns; row = i // self.columns
            bx = cx + col*(cell_w+self.gap)
            by = cy + row*(row_h+self.gap)
            child.layout(bx, by, cell_w, row_h)

    def to_html(self):
        css = self.to_css() + (f"display:grid;"
              f"grid-template-columns:repeat({self.columns},1fr);"
              f"gap:{self.gap}px;"
              f"padding:{self.padding.top}px {self.padding.right}px "
              f"{self.padding.bottom}px {self.padding.left}px;"
              f"box-sizing:border-box;")
        inner = ''.join(c.to_html() for c in self.children if c.visible)
        return f'<div style="{css}">{inner}</div>'


class Overlay(Container):
    """All children drawn at the same position (z-stacked)."""
    def layout(self, x, y, w, h):
        super().layout(x, y, w, h)
        for child in self.children:
            child.layout(x, y, w, h)

    def to_html(self):
        css = self.to_css() + "position:relative;"
        inner = ''.join(c.to_html() for c in self.children if c.visible)
        return f'<div style="{css}">{inner}</div>'


class Panel(Container):
    """Styled box container."""
    def __init__(self, *children, title: str = "", gap: float = 8.,
                 padding: EdgeInsets = None, shadow: bool = True,
                 theme: UITheme = None):
        super().__init__(*children, gap=gap, padding=padding or EdgeInsets.all(16), theme=theme)
        self.title  = title
        self.shadow = shadow

    def layout(self, x, y, w, h):
        super().layout(x, y, w, h)
        content_y = self.rect.y + self.padding.top + (30 if self.title else 0)
        vis = [c for c in self.children if c.visible]
        cx = self.rect.x + self.padding.left
        cw = self.rect.w - self.padding.horizontal
        cur_y = content_y
        for child in vis:
            cm = child.measure()
            child.layout(cx, cur_y, cw, cm[1])
            cur_y += cm[1] + self.gap

    def to_html(self):
        t = self.theme
        shadow = f"box-shadow:0 {t.shadow_offset[1]}px {t.shadow_blur}px rgba(0,0,0,0.3);" if self.shadow else ""
        css = self.to_css() + (f"background:{t.surface.to_rgba_css()};"
              f"border:1px solid {t.border.to_rgba_css()};"
              f"border-radius:{t.radius}px;{shadow}"
              f"padding:{self.padding.top}px {self.padding.right}px "
              f"{self.padding.bottom}px {self.padding.left}px;"
              f"box-sizing:border-box;")
        title_h = f'<div style="font:{t.font_heading.css()};color:{t.text.to_rgba_css()};margin-bottom:12px;">{self.title}</div>' if self.title else ''
        inner = ''.join(c.to_html() for c in self.children if c.visible)
        return f'<div style="{css}">{title_h}{inner}</div>'


class ScrollView(Container):
    """Scrollable container."""
    def __init__(self, *children, axis: Axis = Axis.VERTICAL, theme: UITheme = None):
        super().__init__(*children, theme=theme)
        self.axis = axis
        self._scroll = 0.

    @property
    def scroll(self) -> float: return self._scroll
    @scroll.setter
    def scroll(self, v: float): self._scroll = max(0, v)

    def to_html(self):
        over_x = "auto" if self.axis == Axis.HORIZONTAL else "hidden"
        over_y = "auto" if self.axis == Axis.VERTICAL   else "hidden"
        css = self.to_css() + f"overflow-x:{over_x};overflow-y:{over_y};"
        inner = ''.join(c.to_html() for c in self.children if c.visible)
        return f'<div style="{css}">{inner}</div>'


# ─────────────────────────────────────────────────────────────────────────────
# ANCHOR SYSTEM  (HUD placement)
# ─────────────────────────────────────────────────────────────────────────────

class AnchoredWidget(Widget):
    """Pins a widget to an anchor point within a parent."""
    def __init__(self, child: Widget, anchor: Anchor, margin: EdgeInsets = None,
                 theme: UITheme = None):
        super().__init__(theme)
        self.anchor  = anchor
        self.margin_ = margin or EdgeInsets.all(8)
        self.add(child)

    def layout(self, x, y, w, h):
        super().layout(x, y, w, h)
        if not self.children: return
        child = self.children[0]
        cw, ch = child.measure()
        a = self.anchor
        m = self.margin_
        ax = {Anchor.TOP_LEFT: x+m.left,     Anchor.TOP_CENTER:    x+(w-cw)/2,  Anchor.TOP_RIGHT:     x+w-cw-m.right,
              Anchor.MIDDLE_LEFT: x+m.left,  Anchor.CENTER:         x+(w-cw)/2,  Anchor.MIDDLE_RIGHT:  x+w-cw-m.right,
              Anchor.BOTTOM_LEFT: x+m.left,  Anchor.BOTTOM_CENTER:  x+(w-cw)/2,  Anchor.BOTTOM_RIGHT:  x+w-cw-m.right}.get(a, x)
        ay = {Anchor.TOP_LEFT: y+m.top,      Anchor.TOP_CENTER:    y+m.top,     Anchor.TOP_RIGHT:     y+m.top,
              Anchor.MIDDLE_LEFT: y+(h-ch)/2,Anchor.CENTER:         y+(h-ch)/2,  Anchor.MIDDLE_RIGHT:  y+(h-ch)/2,
              Anchor.BOTTOM_LEFT: y+h-ch-m.bottom, Anchor.BOTTOM_CENTER: y+h-ch-m.bottom, Anchor.BOTTOM_RIGHT: y+h-ch-m.bottom}.get(a, y)
        child.layout(ax, ay, cw, ch)

    def to_html(self):
        child_html = self.children[0].to_html() if self.children else ''
        return f'<div style="{self.to_css()}position:relative;">{child_html}</div>'


def anchored(child: Widget, anchor: Anchor, margin: EdgeInsets = None) -> AnchoredWidget:
    return AnchoredWidget(child, anchor, margin)


# ─────────────────────────────────────────────────────────────────────────────
# GAMEPAD NAVIGATION
# ─────────────────────────────────────────────────────────────────────────────

class GamepadNav:
    """
    Arrow-key / D-pad navigation between focusable widgets.
    Add all focusable widgets, then call navigate(direction).
    """

    def __init__(self):
        self._widgets: List[Widget] = []
        self._focus_idx: int = -1

    def register(self, widget: Widget) -> "GamepadNav":
        if widget._tab_index >= 0:
            self._widgets.append(widget)
            self._widgets.sort(key=lambda w: w._tab_index)
        return self

    def register_all(self, root: Widget) -> "GamepadNav":
        def walk(w):
            self.register(w)
            for c in w.children: walk(c)
        walk(root)
        return self

    def focus_next(self):
        if not self._widgets: return
        self._blur_current()
        self._focus_idx = (self._focus_idx + 1) % len(self._widgets)
        self._focus_current()

    def focus_prev(self):
        if not self._widgets: return
        self._blur_current()
        self._focus_idx = (self._focus_idx - 1) % len(self._widgets)
        self._focus_current()

    def navigate(self, direction: str):
        """direction: 'up'|'down'|'left'|'right'|'confirm'|'cancel'"""
        if direction in ('down', 'right'): self.focus_next()
        elif direction in ('up', 'left'):  self.focus_prev()
        elif direction == 'confirm':
            w = self.focused
            if w and w.on_click: w.on_click(UIEvent('click', w))

    def _blur_current(self):
        w = self.focused
        if w: w._focused = False; w.dispatch(UIEvent('blur', w))

    def _focus_current(self):
        w = self.focused
        if w: w._focused = True; w.dispatch(UIEvent('focus', w))

    @property
    def focused(self) -> Optional[Widget]:
        if 0 <= self._focus_idx < len(self._widgets):
            return self._widgets[self._focus_idx]
        return None


# ─────────────────────────────────────────────────────────────────────────────
# UI SCREEN  (full-screen root with navigation stack)
# ─────────────────────────────────────────────────────────────────────────────

class UIScreen:
    """
    A full-screen UI root. Manages layout, hit-testing, and updates.
    Supports push/pop screen navigation (like a router).

    Usage:
        class MainMenu(UIScreen):
            def build(self):
                return VStack(
                    Text("My Game", size=48),
                    Button("Play",  on_click=lambda e: self.manager.push(GameScreen())),
                    Button("Quit",  on_click=lambda e: app.quit()),
                    padding=EdgeInsets.all(40), gap=16
                )

        mgr = UIManager(800, 600)
        mgr.push(MainMenu())
        # game loop:
        mgr.update(dt)
        html = mgr.render_html()
    """

    def __init__(self, theme: UITheme = None):
        self.theme   = theme or _DEFAULT_THEME
        self.manager: Optional["UIManager"] = None
        self._root:   Optional[Widget] = None
        self._nav     = GamepadNav()

    def build(self) -> Widget:
        """Override to construct and return the widget tree."""
        return Widget(self.theme)

    def _build(self, w: float, h: float):
        self._root = self.build()
        if self._root.theme is _DEFAULT_THEME:
            self._root.theme = self.theme
        self._root.layout(0, 0, w, h)
        self._nav.register_all(self._root)

    def on_enter(self): pass
    def on_exit(self):  pass

    def update(self, dt: float):
        if self._root: self._root.update(dt)

    def handle_click(self, x: float, y: float):
        if not self._root: return
        hit = self._root.hit_test(x, y)
        if hit:
            evt = UIEvent('click', hit, x=x, y=y)
            hit.dispatch(evt)

    def navigate(self, direction: str):
        self._nav.navigate(direction)

    def render_html(self) -> str:
        if not self._root: return ''
        return self._root.to_html()

    def render_dict(self) -> Dict:
        if not self._root: return {}
        return self._root.render()

    def render_ascii(self, w: int = 80, h: int = 24) -> str:
        """Terminal ASCII art preview."""
        return _ascii_render(self._root, w, h) if self._root else ''


class UIManager:
    """
    Manages a stack of UIScreens and the overall render surface.

    Usage:
        mgr = UIManager(800, 600)
        mgr.push(MainMenuScreen())
        # in game loop:
        mgr.update(dt)
        mgr.handle_click(mx, my)
        html = mgr.render_html()
    """

    def __init__(self, width: float = 800., height: float = 600.,
                 theme: UITheme = None):
        self.width  = float(width)
        self.height = float(height)
        self.theme  = theme or _DEFAULT_THEME
        self._stack: List[UIScreen] = []
        self.on_empty: Optional[Callable] = None   # called when stack is empty

    def push(self, screen: UIScreen):
        screen.manager = self
        if screen.theme is _DEFAULT_THEME: screen.theme = self.theme
        screen._build(self.width, self.height)
        screen.on_enter()
        self._stack.append(screen)

    def pop(self) -> Optional[UIScreen]:
        if not self._stack: return None
        screen = self._stack.pop()
        screen.on_exit()
        if not self._stack and self.on_empty: self.on_empty()
        return screen

    def replace(self, screen: UIScreen):
        self.pop(); self.push(screen)

    def update(self, dt: float):
        if self._stack: self._stack[-1].update(dt)

    def handle_click(self, x: float, y: float):
        if self._stack: self._stack[-1].handle_click(x, y)

    def navigate(self, direction: str):
        if self._stack: self._stack[-1].navigate(direction)

    def render_html(self) -> str:
        if not self._stack: return ''
        t = self.theme
        pages = '\n'.join(s.render_html() for s in self._stack)
        return (f'<!DOCTYPE html><html><head>'
                f'<meta charset="UTF-8">'
                f'<style>*{{margin:0;padding:0;box-sizing:border-box}}'
                f'body{{background:{t.bg.to_rgba_css()};'
                f'width:{self.width}px;height:{self.height}px;overflow:hidden}}</style>'
                f'</head><body><div style="position:relative;width:{self.width}px;height:{self.height}px;">'
                f'{pages}</div></body></html>')

    def render_dict(self) -> Dict:
        return {'screens': [s.render_dict() for s in self._stack],
                'width': self.width, 'height': self.height}

    @property
    def current(self) -> Optional[UIScreen]:
        return self._stack[-1] if self._stack else None

    @property
    def depth(self) -> int: return len(self._stack)

    def __repr__(self):
        return f"UIManager({self.width}×{self.height}, depth={self.depth})"


# ─────────────────────────────────────────────────────────────────────────────
# ASCII RENDERER  (terminal preview)
# ─────────────────────────────────────────────────────────────────────────────

def _ascii_render(root: Widget, cols: int = 80, rows: int = 24) -> str:
    """Simple ASCII art render of a widget tree."""
    canvas = [[' '] * cols for _ in range(rows)]

    def fill_rect(r: Rect, ch: str = '─', v_ch: str = '│', corner: str = '┼'):
        x = int(r.x * cols / 800); y = int(r.y * rows / 600)
        w = max(2, int(r.w * cols / 800)); h = max(2, int(r.h * rows / 600))
        for dx in range(w):
            if 0 <= y < rows       and 0 <= x+dx < cols: canvas[y][x+dx] = ch
            if 0 <= y+h-1 < rows   and 0 <= x+dx < cols: canvas[y+h-1][x+dx] = ch
        for dy in range(1, h-1):
            if 0 <= y+dy < rows and 0 <= x < cols:     canvas[y+dy][x] = v_ch
            if 0 <= y+dy < rows and 0 <= x+w-1 < cols: canvas[y+dy][x+w-1] = v_ch
        for c,(cx,cy) in [(corner,(0,0)),(corner,(w-1,0)),(corner,(0,h-1)),(corner,(w-1,h-1))]:
            if 0<=y+cy<rows and 0<=x+cx<cols: canvas[y+cy][x+cx] = c

    def write_text(r: Rect, text: str):
        x = int(r.x * cols / 800); y = int(r.y * rows / 600)
        for i, ch in enumerate(text[:int(r.w * cols / 800) - 2]):
            if 0 <= y < rows and 0 <= x+1+i < cols:
                canvas[y][x+1+i] = ch

    def walk(w: Widget):
        if not w.visible: return
        if isinstance(w, (Button, Panel)):
            fill_rect(w.rect)
        if isinstance(w, (Text, Label, Button)):
            txt = getattr(w, 'text', '') or getattr(w, 'label', '')
            write_text(w.rect, txt)
        for c in w.children: walk(c)

    walk(root)
    return '\n'.join(''.join(row) for row in canvas)


# ─────────────────────────────────────────────────────────────────────────────
# FACTORY HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def make_manager(w: float = 800., h: float = 600., theme: UITheme = None) -> UIManager:
    return UIManager(w, h, theme)

def make_theme(variant: str = "dark") -> UITheme:
    return {'dark': UITheme.dark, 'light': UITheme.light,
            'hud': UITheme.game_hud, 'contrast': UITheme.high_contrast}.get(variant, UITheme.dark)()

def vstack(*children, **kw) -> VStack:   return VStack(*children, **kw)
def hstack(*children, **kw) -> HStack:   return HStack(*children, **kw)
def grid(*children, **kw)   -> Grid:     return Grid(*children, **kw)
def panel(*children, **kw)  -> Panel:    return Panel(*children, **kw)
def overlay(*children, **kw) -> Overlay: return Overlay(*children, **kw)

def text(t, **kw)           -> Text:       return Text(t, **kw)
def label(t, **kw)          -> Label:      return Label(t, **kw)
def button(t, **kw)         -> Button:     return Button(t, **kw)
def image(src, **kw)        -> Image:      return Image(src, **kw)
def slider(**kw)            -> Slider:     return Slider(**kw)
def checkbox(t='', **kw)    -> Checkbox:   return Checkbox(t, **kw)
def input_field(**kw)       -> Input:      return Input(**kw)
def dropdown(opts, **kw)    -> Dropdown:   return Dropdown(opts, **kw)
def progress(**kw)          -> ProgressBar: return ProgressBar(**kw)
def health_bar(**kw)        -> HealthBar:  return HealthBar(**kw)
def spacer(n=0)             -> Spacer:     return Spacer(n)
def separator(**kw)         -> Separator:  return Separator(**kw)
def icon(i, **kw)           -> Icon:       return Icon(i, **kw)
def tooltip(t, **kw)        -> Tooltip:    return Tooltip(t, **kw)
