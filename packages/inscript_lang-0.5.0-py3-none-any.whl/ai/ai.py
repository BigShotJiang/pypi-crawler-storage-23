# inscript/ai/ai.py  —  Phase 16: Game AI System
#
# Smart enemies and NPCs, built into InScript.
#
# InScript AI syntax (mirrors this module):
#
#   // Finite State Machine
#   ai Enemy {
#       state Idle {
#           on_update(dt) { if can_see(player) { switch_to(Chase) } }
#       }
#       state Chase {
#           on_update(dt) {
#               move_toward(player.pos, speed * dt)
#               if dist(pos, player.pos) < 60 { switch_to(Attack) }
#           }
#       }
#       state Attack {
#           on_enter { play_anim("attack") }
#           on_update(dt) { deal_damage(10) }
#           on_exit  { reset_cooldown() }
#       }
#   }
#
#   // Behavior Tree
#   btree EnemyBrain {
#       selector {
#           sequence {
#               condition { can_see(player) }
#               action    { move_toward(player) }
#               action    { attack(player) }
#           }
#           action { patrol(waypoints) }
#       }
#   }
#
#   // A* Pathfinding
#   let path = navmesh.find_path(enemy.pos, player.pos)
#   enemy.follow_path(path, speed: 120)
#
# Features:
#   • FSM    — Finite State Machine with enter/update/exit hooks
#   • BTree  — Behavior Tree: Selector, Sequence, Parallel, Decorator, Action, Condition
#   • NavMesh — Grid-based navigation mesh + A* pathfinding with funnel smoothing
#   • Boids   — Craig Reynolds flocking (separation, alignment, cohesion, avoidance)
#   • InfluenceMap — 2D heat map for tactical reasoning (threat, cover, resources)
#   • UtilityAI — Score-based action selection (replaces hard-coded if/else chains)
#   • GOAP    — Goal-Oriented Action Planning (A* over action graph)
#   • Perception — Line-of-sight, hearing radius, memory of last seen position
#   • Steering  — arrive, seek, flee, pursue, evade, path-follow, wander
#   • AIWorld   — Scene-level registry: registers agents, runs all updates
#
# Deliverable for ROADMAP_v2.md Phase 16.

from __future__ import annotations
import math, heapq, random, time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import deque


# ─────────────────────────────────────────────────────────────────────────────
# VEC2  (lightweight, no external deps)
# ─────────────────────────────────────────────────────────────────────────────

class Vec2:
    __slots__ = ('x','y')
    def __init__(self, x=0., y=0.): self.x=float(x); self.y=float(y)
    def __add__(self,o): return Vec2(self.x+o.x,self.y+o.y)
    def __sub__(self,o): return Vec2(self.x-o.x,self.y-o.y)
    def __mul__(self,s): return Vec2(self.x*s,self.y*s)
    def __truediv__(self,s): return Vec2(self.x/s,self.y/s)
    def __neg__(self): return Vec2(-self.x,-self.y)
    def __eq__(self,o): return isinstance(o,Vec2) and abs(self.x-o.x)<1e-6 and abs(self.y-o.y)<1e-6
    def __hash__(self): return hash((round(self.x,4),round(self.y,4)))
    def length(self): return math.sqrt(self.x*self.x+self.y*self.y)
    def length_sq(self): return self.x*self.x+self.y*self.y
    def normalized(self):
        l=self.length(); return Vec2(self.x/l,self.y/l) if l>1e-10 else Vec2(0,0)
    def dot(self,o): return self.x*o.x+self.y*o.y
    def dist(self,o): return (self-o).length()
    def dist_sq(self,o): return (self-o).length_sq()
    def lerp(self,o,t): return self*(1-t)+o*t
    def __repr__(self): return f"Vec2({self.x:.2f},{self.y:.2f})"
    @staticmethod
    def ZERO(): return Vec2(0,0)


def _clamp(v,lo,hi): return max(lo,min(hi,v))
def _angle_to(a,b): d=b-a; return math.atan2(d.y,d.x)


# ─────────────────────────────────────────────────────────────────────────────
# FINITE STATE MACHINE
# ─────────────────────────────────────────────────────────────────────────────

class State:
    """
    Base class for FSM states. Override on_enter, on_update, on_exit.
    Also supports transition guards via transitions dict.
    """
    name: str = "State"

    def on_enter(self, agent: "AIAgent"): pass
    def on_update(self, agent: "AIAgent", dt: float): pass
    def on_exit(self, agent: "AIAgent"):  pass

    def get_transitions(self, agent: "AIAgent") -> Optional[str]:
        """Return name of next state to switch to, or None to stay."""
        return None

    def __repr__(self): return f"State({self.name})"


class FSM:
    """
    Finite State Machine.

    Usage:
        fsm = FSM()
        fsm.add_state('idle',   IdleState())
        fsm.add_state('chase',  ChaseState())
        fsm.add_state('attack', AttackState())
        fsm.start('idle', agent)
        # each frame:
        fsm.update(agent, dt)
    """

    def __init__(self):
        self._states:  Dict[str, State] = {}
        self._current: Optional[State]  = None
        self._current_name: str = ''
        self._history: List[str] = []
        self._global_transitions: List[Callable] = []  # checked regardless of state
        self.on_transition: Optional[Callable] = None  # callback(from, to, agent)

    def add_state(self, name: str, state: State) -> "FSM":
        state.name = name
        self._states[name] = state
        return self

    def start(self, state_name: str, agent: "AIAgent"):
        if state_name not in self._states:
            raise KeyError(f"FSM: unknown state '{state_name}'")
        self._current_name = state_name
        self._current = self._states[state_name]
        self._current.on_enter(agent)

    def switch_to(self, state_name: str, agent: "AIAgent"):
        if state_name == self._current_name: return
        if state_name not in self._states:
            raise KeyError(f"FSM: unknown state '{state_name}'")
        prev = self._current_name
        if self._current: self._current.on_exit(agent)
        self._history.append(prev)
        self._current_name = state_name
        self._current = self._states[state_name]
        self._current.on_enter(agent)
        if self.on_transition: self.on_transition(prev, state_name, agent)

    def update(self, agent: "AIAgent", dt: float):
        if not self._current: return
        # Check global transitions first
        for guard in self._global_transitions:
            next_s = guard(agent)
            if next_s: self.switch_to(next_s, agent); return
        # Check state's own transitions
        next_s = self._current.get_transitions(agent)
        if next_s: self.switch_to(next_s, agent)
        if self._current: self._current.on_update(agent, dt)

    def add_global_transition(self, guard: Callable) -> "FSM":
        """Add a transition checked before any state update."""
        self._global_transitions.append(guard)
        return self

    def revert(self, agent: "AIAgent"):
        """Go back to the previous state."""
        if self._history:
            self.switch_to(self._history.pop(), agent)

    @property
    def current_state(self) -> str: return self._current_name

    @property
    def history(self) -> List[str]: return list(self._history)

    def __repr__(self): return f"FSM(current={self._current_name}, states={list(self._states)})"


# ─────────────────────────────────────────────────────────────────────────────
# BEHAVIOR TREE
# ─────────────────────────────────────────────────────────────────────────────

class BTStatus(Enum):
    SUCCESS = auto()
    FAILURE = auto()
    RUNNING = auto()


class BTNode:
    """Base behavior tree node."""
    def tick(self, agent: "AIAgent", dt: float) -> BTStatus:
        raise NotImplementedError
    def reset(self): pass


class BTAction(BTNode):
    """Leaf node: runs an action function. fn(agent, dt) → BTStatus or bool."""
    def __init__(self, fn: Callable, name: str = ""):
        self.fn = fn; self.name = name or fn.__name__
    def tick(self, agent, dt):
        result = self.fn(agent, dt)
        if isinstance(result, BTStatus): return result
        return BTStatus.SUCCESS if result else BTStatus.FAILURE
    def __repr__(self): return f"BTAction({self.name})"


class BTCondition(BTNode):
    """Leaf node: checks a condition. fn(agent) → bool."""
    def __init__(self, fn: Callable, name: str = ""):
        self.fn = fn; self.name = name or fn.__name__
    def tick(self, agent, dt):
        return BTStatus.SUCCESS if self.fn(agent) else BTStatus.FAILURE
    def __repr__(self): return f"BTCondition({self.name})"


class BTSequence(BTNode):
    """AND node: all children must succeed. Fails on first failure."""
    def __init__(self, *children: BTNode):
        self.children = list(children); self._idx = 0
    def tick(self, agent, dt):
        while self._idx < len(self.children):
            status = self.children[self._idx].tick(agent, dt)
            if status == BTStatus.FAILURE: self.reset(); return BTStatus.FAILURE
            if status == BTStatus.RUNNING: return BTStatus.RUNNING
            self._idx += 1
        self.reset(); return BTStatus.SUCCESS
    def reset(self): self._idx = 0; [c.reset() for c in self.children]
    def __repr__(self): return f"Sequence({len(self.children)})"


class BTSelector(BTNode):
    """OR node: succeeds on first success. Fails if all fail."""
    def __init__(self, *children: BTNode):
        self.children = list(children); self._idx = 0
    def tick(self, agent, dt):
        while self._idx < len(self.children):
            status = self.children[self._idx].tick(agent, dt)
            if status == BTStatus.SUCCESS: self.reset(); return BTStatus.SUCCESS
            if status == BTStatus.RUNNING: return BTStatus.RUNNING
            self._idx += 1
        self.reset(); return BTStatus.FAILURE
    def reset(self): self._idx = 0; [c.reset() for c in self.children]
    def __repr__(self): return f"Selector({len(self.children)})"


class BTParallel(BTNode):
    """All children run simultaneously. Policy controls when to stop."""
    def __init__(self, *children: BTNode, succeed_on: int = None, fail_on: int = 1):
        self.children  = list(children)
        self.succeed_on = succeed_on or len(children)
        self.fail_on   = fail_on
    def tick(self, agent, dt):
        successes = failures = 0
        for c in self.children:
            s = c.tick(agent, dt)
            if s == BTStatus.SUCCESS: successes += 1
            elif s == BTStatus.FAILURE: failures += 1
        if failures >= self.fail_on:  self.reset(); return BTStatus.FAILURE
        if successes >= self.succeed_on: self.reset(); return BTStatus.SUCCESS
        return BTStatus.RUNNING
    def reset(self): [c.reset() for c in self.children]


class BTDecorator(BTNode):
    """Wraps one child and modifies its result."""
    def __init__(self, child: BTNode): self.child = child
    def reset(self): self.child.reset()


class BTInvert(BTDecorator):
    """Inverts child result: SUCCESS↔FAILURE."""
    def tick(self, agent, dt):
        s = self.child.tick(agent, dt)
        if s == BTStatus.SUCCESS: return BTStatus.FAILURE
        if s == BTStatus.FAILURE: return BTStatus.SUCCESS
        return BTStatus.RUNNING


class BTRepeat(BTDecorator):
    """Repeats child N times (or forever if n=-1)."""
    def __init__(self, child, n: int = -1):
        super().__init__(child); self.n = n; self._count = 0
    def tick(self, agent, dt):
        s = self.child.tick(agent, dt)
        if s == BTStatus.RUNNING: return BTStatus.RUNNING
        if s == BTStatus.SUCCESS:
            self._count += 1
            if self.n > 0 and self._count >= self.n: self._count=0; return BTStatus.SUCCESS
            self.child.reset(); return BTStatus.RUNNING
        return BTStatus.FAILURE
    def reset(self): self._count=0; self.child.reset()


class BTSucceeder(BTDecorator):
    """Always returns SUCCESS regardless of child result."""
    def tick(self, agent, dt):
        self.child.tick(agent, dt); return BTStatus.SUCCESS


class BTCooldown(BTDecorator):
    """Runs child, then blocks for cooldown_s seconds."""
    def __init__(self, child, cooldown_s: float):
        super().__init__(child); self.cooldown=cooldown_s; self._ready_at=0.
    def tick(self, agent, dt):
        now = time.time()
        if now < self._ready_at: return BTStatus.FAILURE
        s = self.child.tick(agent, dt)
        if s != BTStatus.RUNNING: self._ready_at = now + self.cooldown
        return s


class BehaviorTree:
    """
    Behavior Tree runner.

    Usage:
        bt = BehaviorTree(
            BTSelector(
                BTSequence(
                    BTCondition(lambda a: a.can_see_player()),
                    BTAction(lambda a, dt: a.move_toward(a.target, dt)),
                    BTAction(lambda a, dt: a.attack()),
                ),
                BTAction(lambda a, dt: a.patrol(dt))
            )
        )
        bt.update(agent, dt)
    """
    def __init__(self, root: BTNode):
        self.root = root
        self._last_status = BTStatus.SUCCESS

    def update(self, agent: "AIAgent", dt: float) -> BTStatus:
        self._last_status = self.root.tick(agent, dt)
        return self._last_status

    @property
    def status(self) -> BTStatus: return self._last_status

    def reset(self): self.root.reset()


# ─────────────────────────────────────────────────────────────────────────────
# NAVIGATION MESH  (grid-based + A* + funnel smoothing)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class NavCell:
    x: int; y: int
    walkable: bool = True
    cost: float = 1.0          # movement cost multiplier (swamp = 3.0, road = 0.5)

    def __hash__(self): return hash((self.x, self.y))
    def __eq__(self, o): return isinstance(o, NavCell) and self.x==o.x and self.y==o.y
    def __lt__(self, o): return (self.x, self.y) < (o.x, o.y)


class NavMesh:
    """
    Grid-based navigation mesh.
    Supports A* pathfinding, dynamic obstacle marking, and path smoothing.

    Usage:
        nav = NavMesh(width=50, height=40, cell_size=32)
        nav.mark_obstacle(10, 15)
        path = nav.find_path(Vec2(64, 64), Vec2(800, 400))
        # path is a list of Vec2 waypoints
    """

    def __init__(self, width: int, height: int, cell_size: float = 32.0):
        self.width     = width
        self.height    = height
        self.cell_size = cell_size
        self._grid: List[List[NavCell]] = [
            [NavCell(x, y) for x in range(width)] for y in range(height)
        ]
        self._neighbors_8 = True  # 8-directional movement (vs 4)

    # ── Grid access ──────────────────────────────────────────────────────
    def cell(self, x: int, y: int) -> Optional[NavCell]:
        if 0 <= x < self.width and 0 <= y < self.height:
            return self._grid[y][x]
        return None

    def world_to_cell(self, pos: Vec2) -> Tuple[int, int]:
        return (int(pos.x / self.cell_size), int(pos.y / self.cell_size))

    def cell_to_world(self, cx: int, cy: int) -> Vec2:
        return Vec2((cx + 0.5) * self.cell_size, (cy + 0.5) * self.cell_size)

    def mark_obstacle(self, cx: int, cy: int, walkable: bool = False):
        c = self.cell(cx, cy)
        if c: c.walkable = walkable

    def mark_rect(self, x: int, y: int, w: int, h: int, walkable: bool = False):
        for dy in range(h):
            for dx in range(w):
                self.mark_obstacle(x+dx, y+dy, walkable)

    def set_cost(self, cx: int, cy: int, cost: float):
        c = self.cell(cx, cy)
        if c: c.cost = cost

    def is_walkable(self, cx: int, cy: int) -> bool:
        c = self.cell(cx, cy)
        return c is not None and c.walkable

    # ── A* Pathfinding ───────────────────────────────────────────────────
    def find_path(self, start: Vec2, goal: Vec2,
                  smooth: bool = True) -> List[Vec2]:
        """Find path from start to goal in world coordinates."""
        sx, sy = self.world_to_cell(start)
        gx, gy = self.world_to_cell(goal)

        start_cell = self.cell(sx, sy)
        goal_cell  = self.cell(gx, gy)
        if not start_cell or not goal_cell: return []
        if not goal_cell.walkable:
            # Find nearest walkable cell to goal
            goal_cell = self._nearest_walkable(gx, gy)
            if not goal_cell: return []

        raw = self._astar(start_cell, goal_cell)
        if not raw: return []

        world_path = [self.cell_to_world(c.x, c.y) for c in raw]
        # Replace start/end with exact world positions
        if world_path:
            world_path[0]  = start
            world_path[-1] = goal

        return self._smooth_path(world_path) if smooth else world_path

    def _astar(self, start: NavCell, goal: NavCell) -> List[NavCell]:
        def h(c): return math.sqrt((c.x-goal.x)**2+(c.y-goal.y)**2)

        open_heap = [(h(start), 0, start)]
        came_from: Dict = {}
        g_score: Dict = {start: 0.0}
        closed: Set   = set()

        while open_heap:
            _, g, current = heapq.heappop(open_heap)
            if current == goal:
                # Reconstruct path
                path = []; node = current
                while node in came_from: path.append(node); node = came_from[node]
                path.append(start); path.reverse(); return path
            if current in closed: continue
            closed.add(current)

            for nb in self._get_neighbors(current):
                if nb in closed: continue
                diag = nb.x != current.x and nb.y != current.y
                move_cost = (math.sqrt(2) if diag else 1.0) * nb.cost
                tentative = g_score[current] + move_cost
                if nb not in g_score or tentative < g_score[nb]:
                    came_from[nb]  = current
                    g_score[nb]    = tentative
                    f = tentative + h(nb)
                    heapq.heappush(open_heap, (f, tentative, nb))
        return []

    def _get_neighbors(self, c: NavCell) -> List[NavCell]:
        dirs = [(1,0),(-1,0),(0,1),(0,-1)]
        if self._neighbors_8:
            dirs += [(1,1),(-1,1),(1,-1),(-1,-1)]
        result = []
        for dx,dy in dirs:
            nb = self.cell(c.x+dx, c.y+dy)
            if nb and nb.walkable:
                if dx != 0 and dy != 0:  # diagonal — check both adjacent cells
                    if not self.is_walkable(c.x+dx, c.y) or not self.is_walkable(c.x, c.y+dy):
                        continue
                result.append(nb)
        return result

    def _nearest_walkable(self, cx: int, cy: int) -> Optional[NavCell]:
        for r in range(1, 10):
            for dx in range(-r, r+1):
                for dy in range(-r, r+1):
                    if abs(dx)==r or abs(dy)==r:
                        c = self.cell(cx+dx, cy+dy)
                        if c and c.walkable: return c
        return None

    def _smooth_path(self, path: List[Vec2]) -> List[Vec2]:
        """String-pull (funnel) smoothing: remove redundant waypoints."""
        if len(path) < 3: return path
        result = [path[0]]; i = 0
        while i < len(path) - 1:
            # Try to jump directly to furthest visible node
            for j in range(len(path)-1, i, -1):
                if self._line_of_sight(path[i], path[j]):
                    result.append(path[j]); i = j; break
            else:
                i += 1
        if result[-1] != path[-1]: result.append(path[-1])
        return result

    def _line_of_sight(self, a: Vec2, b: Vec2) -> bool:
        """Bresenham line-of-sight check."""
        x0, y0 = self.world_to_cell(a)
        x1, y1 = self.world_to_cell(b)
        dx = abs(x1-x0); dy = abs(y1-y0)
        sx = 1 if x0<x1 else -1; sy = 1 if y0<y1 else -1
        err = dx - dy
        while True:
            if not self.is_walkable(x0, y0): return False
            if x0==x1 and y0==y1: return True
            e2 = 2*err
            if e2 > -dy: err -= dy; x0 += sx
            if e2 <  dx: err += dx; y0 += sy

    def raycast(self, start: Vec2, direction: Vec2, max_dist: float) -> Optional[Vec2]:
        """Cast a ray, return first obstacle hit or None."""
        step = self.cell_size * 0.5
        d = direction.normalized()
        pos = Vec2(start.x, start.y)
        dist = 0.
        while dist < max_dist:
            pos = pos + d * step; dist += step
            cx, cy = self.world_to_cell(pos)
            if not self.is_walkable(cx, cy): return pos
        return None

    def __repr__(self):
        walkable = sum(1 for row in self._grid for c in row if c.walkable)
        return f"NavMesh({self.width}x{self.height}, walkable={walkable})"


# ─────────────────────────────────────────────────────────────────────────────
# PATH FOLLOWER
# ─────────────────────────────────────────────────────────────────────────────

class PathFollower:
    """Moves an agent along a list of Vec2 waypoints."""

    def __init__(self, path: List[Vec2], speed: float = 100.0,
                 arrival_radius: float = 8.0):
        self.path           = list(path)
        self.speed          = speed
        self.arrival_radius = arrival_radius
        self._idx           = 0
        self.done           = len(path) == 0

    def update(self, pos: Vec2, dt: float) -> Tuple[Vec2, bool]:
        """
        Returns (new_position, arrived_at_end).
        """
        if self.done or not self.path: return pos, True
        target = self.path[self._idx]
        dist   = pos.dist(target)
        if dist <= self.arrival_radius:
            self._idx += 1
            if self._idx >= len(self.path):
                self.done = True; return target, True
            target = self.path[self._idx]
        direction = (target - pos).normalized()
        new_pos   = pos + direction * self.speed * dt
        return new_pos, False

    def remaining_dist(self, pos: Vec2) -> float:
        if self.done: return 0.
        total = pos.dist(self.path[self._idx])
        for i in range(self._idx, len(self.path)-1):
            total += self.path[i].dist(self.path[i+1])
        return total

    @property
    def current_waypoint(self) -> Optional[Vec2]:
        if self._idx < len(self.path): return self.path[self._idx]
        return None


# ─────────────────────────────────────────────────────────────────────────────
# STEERING BEHAVIOURS
# ─────────────────────────────────────────────────────────────────────────────

class Steering:
    """
    Classic Craig Reynolds steering behaviours.
    All methods return a Vec2 steering force.
    """

    @staticmethod
    def seek(pos: Vec2, target: Vec2, speed: float) -> Vec2:
        """Steer directly toward target."""
        desired = (target - pos).normalized() * speed
        return desired

    @staticmethod
    def flee(pos: Vec2, threat: Vec2, speed: float) -> Vec2:
        """Steer directly away from threat."""
        desired = (pos - threat).normalized() * speed
        return desired

    @staticmethod
    def arrive(pos: Vec2, target: Vec2, speed: float,
               slow_radius: float = 80.0) -> Vec2:
        """Seek but decelerate on approach."""
        d  = target - pos
        dist = d.length()
        if dist < 1e-6: return Vec2()
        spd = speed if dist > slow_radius else speed * (dist / slow_radius)
        return d.normalized() * spd

    @staticmethod
    def pursue(pos: Vec2, vel: Vec2, target_pos: Vec2, target_vel: Vec2,
               speed: float) -> Vec2:
        """Predict target's future position and seek it."""
        dist = pos.dist(target_pos)
        t    = dist / (speed + 1e-6)
        future = target_pos + target_vel * t
        return Steering.seek(pos, future, speed)

    @staticmethod
    def evade(pos: Vec2, vel: Vec2, threat_pos: Vec2, threat_vel: Vec2,
              speed: float) -> Vec2:
        """Predict threat's position and flee from it."""
        dist = pos.dist(threat_pos)
        t    = dist / (speed + 1e-6)
        future = threat_pos + threat_vel * t
        return Steering.flee(pos, future, speed)

    @staticmethod
    def wander(pos: Vec2, facing: float, dt: float,
               wander_dist: float = 80.0, wander_radius: float = 40.0,
               jitter: float = 1.5) -> Tuple[Vec2, float]:
        """Random wandering. Returns (force, new_facing)."""
        facing += (random.random() - 0.5) * jitter * dt * 60
        circle_center = Vec2(math.cos(facing), math.sin(facing)) * wander_dist
        displacement  = Vec2(math.cos(facing + math.pi/2), math.sin(facing + math.pi/2)) * wander_radius
        target = pos + circle_center + displacement
        return Steering.seek(pos, target, 1.0), facing

    @staticmethod
    def separation(pos: Vec2, neighbors: List[Vec2],
                   min_dist: float = 40.0, strength: float = 200.0) -> Vec2:
        """Push away from nearby agents."""
        force = Vec2()
        for nb in neighbors:
            d = pos.dist(nb)
            if d < min_dist and d > 1e-6:
                push = (pos - nb).normalized() * (min_dist - d) / min_dist
                force = force + push * strength
        return force

    @staticmethod
    def align(vel: Vec2, neighbors: List[Vec2], speed: float) -> Vec2:
        """Match velocity direction with neighbors."""
        if not neighbors: return Vec2()
        avg = Vec2()
        for nv in neighbors: avg = avg + nv
        avg = (avg / len(neighbors)).normalized() * speed
        return avg - vel

    @staticmethod
    def cohesion(pos: Vec2, neighbor_positions: List[Vec2], speed: float) -> Vec2:
        """Steer toward center of neighbors."""
        if not neighbor_positions: return Vec2()
        center = Vec2()
        for np in neighbor_positions: center = center + np
        center = center / len(neighbor_positions)
        return Steering.seek(pos, center, speed)

    @staticmethod
    def avoid_obstacles(pos: Vec2, vel: Vec2, obstacles: List[Tuple[Vec2, float]],
                        look_ahead: float = 60.0, strength: float = 300.0) -> Vec2:
        """Steer to avoid circular obstacles. obstacles = [(center, radius), ...]"""
        force = Vec2()
        ahead = pos + vel.normalized() * look_ahead
        for (ob_pos, ob_r) in obstacles:
            if ahead.dist(ob_pos) < ob_r or pos.dist(ob_pos) < ob_r + 10:
                push = (ahead - ob_pos).normalized() * strength
                force = force + push
        return force


# ─────────────────────────────────────────────────────────────────────────────
# BOIDS  (flocking)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Boid:
    pos:     Vec2
    vel:     Vec2 = field(default_factory=Vec2.ZERO)
    id:      int  = 0
    group:   int  = 0   # boids with the same group number flock together

    # Tuning
    max_speed:      float = 120.0
    max_force:      float = 400.0
    sep_radius:     float = 30.0
    align_radius:   float = 80.0
    cohesion_radius:float = 100.0
    sep_weight:     float = 1.8
    align_weight:   float = 1.0
    cohesion_weight:float = 1.0
    seek_target:    Optional[Vec2] = None
    seek_weight:    float = 0.5

    def __hash__(self): return id(self)


class Flock:
    """
    Craig Reynolds Boids flocking simulation.

    Usage:
        flock = Flock()
        for i in range(20):
            flock.add(Boid(Vec2(random.uniform(0,800), random.uniform(0,600))))
        # each frame:
        flock.update(dt)
        for boid in flock.boids:
            draw_boid(boid.pos, boid.vel)
    """

    def __init__(self, bounds: Tuple[float,float,float,float] = None):
        self.boids: List[Boid] = []
        self.bounds = bounds   # (x0, y0, x1, y1) for wrapping
        self._obstacles: List[Tuple[Vec2, float]] = []
        self._id_counter = 0

    def add(self, boid: Boid) -> Boid:
        self._id_counter += 1
        boid.id = self._id_counter
        self.boids.append(boid)
        return boid

    def add_obstacle(self, center: Vec2, radius: float):
        self._obstacles.append((center, radius))

    def update(self, dt: float):
        for boid in self.boids:
            force = self._compute_force(boid)
            # Clamp and apply
            if force.length() > boid.max_force:
                force = force.normalized() * boid.max_force
            boid.vel = boid.vel + force * dt
            if boid.vel.length() > boid.max_speed:
                boid.vel = boid.vel.normalized() * boid.max_speed
            boid.pos = boid.pos + boid.vel * dt
            # Wrap bounds
            if self.bounds:
                x0,y0,x1,y1 = self.bounds
                if boid.pos.x < x0: boid.pos.x = x1
                elif boid.pos.x > x1: boid.pos.x = x0
                if boid.pos.y < y0: boid.pos.y = y1
                elif boid.pos.y > y1: boid.pos.y = y0

    def _compute_force(self, b: Boid) -> Vec2:
        sep_neighbors_pos = []
        align_neighbors_vel = []
        coh_neighbors_pos = []
        for o in self.boids:
            if o is b or o.group != b.group: continue
            d = b.pos.dist(o.pos)
            if d < b.sep_radius:     sep_neighbors_pos.append(o.pos)
            if d < b.align_radius:   align_neighbors_vel.append(o.vel)
            if d < b.cohesion_radius:coh_neighbors_pos.append(o.pos)

        force = Vec2()
        force = force + Steering.separation(b.pos, sep_neighbors_pos, b.sep_radius) * b.sep_weight
        force = force + Steering.align(b.vel, align_neighbors_vel, b.max_speed)    * b.align_weight
        force = force + Steering.cohesion(b.pos, coh_neighbors_pos, b.max_speed)   * b.cohesion_weight
        if self._obstacles:
            force = force + Steering.avoid_obstacles(b.pos, b.vel, self._obstacles)
        if b.seek_target:
            force = force + Steering.seek(b.pos, b.seek_target, b.max_speed) * b.seek_weight
        return force

    def set_target(self, target: Vec2, group: int = 0):
        for b in self.boids:
            if b.group == group: b.seek_target = target

    def __repr__(self):
        return f"Flock({len(self.boids)} boids)"


# ─────────────────────────────────────────────────────────────────────────────
# INFLUENCE MAP
# ─────────────────────────────────────────────────────────────────────────────

class InfluenceMap:
    """
    2D grid-based heat map for tactical AI reasoning.
    Used for: threat levels, cover detection, resource proximity, patrol preference.

    Usage:
        imap = InfluenceMap(50, 40, cell_size=32)
        imap.stamp(player_pos, influence=1.0, radius=5)   # player threat
        imap.propagate(decay=0.85, iterations=3)
        v = imap.value_at(enemy_pos)
        safest = imap.find_min_in_radius(enemy_pos, radius=200)
    """

    def __init__(self, width: int, height: int, cell_size: float = 32.0):
        self.width     = width
        self.height    = height
        self.cell_size = cell_size
        self._grid     = [[0.0] * width for _ in range(height)]
        self._prev     = [[0.0] * width for _ in range(height)]

    def clear(self, value: float = 0.0):
        for row in self._grid:
            for i in range(len(row)): row[i] = value

    def stamp(self, pos: Vec2, influence: float, radius: int = 3, falloff: str = 'linear'):
        """Paint influence at world position with radius (in cells)."""
        cx = int(pos.x / self.cell_size)
        cy = int(pos.y / self.cell_size)
        for dy in range(-radius, radius+1):
            for dx in range(-radius, radius+1):
                nx, ny = cx+dx, cy+dy
                if 0 <= nx < self.width and 0 <= ny < self.height:
                    dist = math.sqrt(dx*dx+dy*dy)
                    if dist <= radius:
                        if falloff == 'linear':
                            factor = 1.0 - dist/radius
                        elif falloff == 'gaussian':
                            factor = math.exp(-2.0*dist*dist/(radius*radius))
                        else:
                            factor = 1.0
                        self._grid[ny][nx] += influence * factor

    def propagate(self, decay: float = 0.85, iterations: int = 2):
        """Blur influence outward (simulates smell, visibility, etc)."""
        for _ in range(iterations):
            for y in range(self.height):
                for x in range(self.width):
                    v = self._grid[y][x]
                    for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
                        nx,ny = x+dx,y+dy
                        if 0<=nx<self.width and 0<=ny<self.height:
                            v += self._grid[ny][nx] * decay
                    self._prev[y][x] = v * 0.25
            self._grid, self._prev = self._prev, self._grid

    def value_at(self, pos: Vec2) -> float:
        cx = int(pos.x / self.cell_size)
        cy = int(pos.y / self.cell_size)
        if 0 <= cx < self.width and 0 <= cy < self.height:
            return self._grid[cy][cx]
        return 0.0

    def find_min_in_radius(self, pos: Vec2, radius: float) -> Vec2:
        """Find world position with lowest influence within radius."""
        cx = int(pos.x / self.cell_size)
        cy = int(pos.y / self.cell_size)
        cr = int(radius / self.cell_size) + 1
        best_v = float('inf'); best_pos = pos
        for dy in range(-cr, cr+1):
            for dx in range(-cr, cr+1):
                nx, ny = cx+dx, cy+dy
                if 0<=nx<self.width and 0<=ny<self.height:
                    d = math.sqrt(dx*dx+dy*dy)*self.cell_size
                    if d <= radius:
                        v = self._grid[ny][nx]
                        if v < best_v: best_v=v; best_pos=Vec2((nx+.5)*self.cell_size,(ny+.5)*self.cell_size)
        return best_pos

    def find_max_in_radius(self, pos: Vec2, radius: float) -> Vec2:
        cx = int(pos.x / self.cell_size)
        cy = int(pos.y / self.cell_size)
        cr = int(radius / self.cell_size) + 1
        best_v = float('-inf'); best_pos = pos
        for dy in range(-cr, cr+1):
            for dx in range(-cr, cr+1):
                nx, ny = cx+dx, cy+dy
                if 0<=nx<self.width and 0<=ny<self.height:
                    d = math.sqrt(dx*dx+dy*dy)*self.cell_size
                    if d <= radius:
                        v = self._grid[ny][nx]
                        if v > best_v: best_v=v; best_pos=Vec2((nx+.5)*self.cell_size,(ny+.5)*self.cell_size)
        return best_pos

    def add(self, other: "InfluenceMap") -> "InfluenceMap":
        """Add two maps together into a new map."""
        result = InfluenceMap(self.width, self.height, self.cell_size)
        for y in range(self.height):
            for x in range(self.width):
                result._grid[y][x] = self._grid[y][x] + other._grid[y][x]
        return result

    def normalize(self):
        mx = max(max(row) for row in self._grid)
        if mx > 1e-10:
            for y in range(self.height):
                for x in range(self.width):
                    self._grid[y][x] /= mx

    def __repr__(self):
        return f"InfluenceMap({self.width}x{self.height})"


# ─────────────────────────────────────────────────────────────────────────────
# UTILITY AI
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class UtilityAction:
    """A scored action for Utility AI."""
    name:     str
    score_fn: Callable  # fn(agent) → float in [0, 1]
    execute:  Callable  # fn(agent, dt)
    weight:   float = 1.0
    cooldown: float = 0.0  # minimum seconds between executions
    _last_exec: float = field(default=-999., repr=False)

    def score(self, agent) -> float:
        now = time.time()
        if self.cooldown > 0 and now - self._last_exec < self.cooldown:
            return 0.0
        return self.score_fn(agent) * self.weight

    def run(self, agent, dt: float):
        self._last_exec = time.time()
        self.execute(agent, dt)


class UtilityAI:
    """
    Score-based action selection — replaces hard-coded if/else chains.
    Each action has a score function; the highest scorer wins each frame.

    Usage:
        uai = UtilityAI()
        uai.add(UtilityAction(
            name='attack',
            score_fn = lambda a: 1.0 if a.can_attack() else 0.0,
            execute  = lambda a, dt: a.attack()
        ))
        uai.add(UtilityAction(
            name='heal',
            score_fn = lambda a: max(0, 1 - a.health/a.max_health),
            execute  = lambda a, dt: a.use_healthpack(),
            cooldown = 3.0
        ))
        uai.update(agent, dt)
    """

    def __init__(self, inertia: float = 0.05):
        self.actions:  List[UtilityAction] = []
        self._current: Optional[str] = None
        self.inertia   = inertia   # bonus to currently running action (prevents thrashing)

    def add(self, action: UtilityAction) -> "UtilityAI":
        self.actions.append(action); return self

    def update(self, agent, dt: float) -> Optional[str]:
        if not self.actions: return None
        best_score = -1; best_action = None
        for a in self.actions:
            s = a.score(agent)
            if a.name == self._current: s += self.inertia   # inertia bonus
            if s > best_score: best_score = s; best_action = a
        if best_action:
            self._current = best_action.name
            best_action.run(agent, dt)
        return self._current

    def get_scores(self, agent) -> Dict[str, float]:
        return {a.name: a.score(agent) for a in self.actions}

    def __repr__(self):
        return f"UtilityAI(actions={[a.name for a in self.actions]}, current={self._current})"


# ─────────────────────────────────────────────────────────────────────────────
# GOAP  (Goal-Oriented Action Planning)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class GOAPAction:
    """An action in a GOAP plan."""
    name:          str
    preconditions: Dict[str, bool]   # required world state
    effects:       Dict[str, bool]   # world state changes produced
    cost:          float = 1.0
    execute:       Optional[Callable] = None

    def is_applicable(self, world_state: Dict[str, bool]) -> bool:
        return all(world_state.get(k) == v for k, v in self.preconditions.items())

    def apply(self, world_state: Dict[str, bool]) -> Dict[str, bool]:
        new_state = dict(world_state)
        new_state.update(self.effects)
        return new_state


class GOAPPlanner:
    """
    Goal-Oriented Action Planner.
    Finds the cheapest sequence of actions to achieve a goal state from the current world state.

    Usage:
        planner = GOAPPlanner()
        planner.add(GOAPAction('pickup_weapon',
            preconditions={'has_weapon': False, 'weapon_nearby': True},
            effects={'has_weapon': True}, cost=1))
        planner.add(GOAPAction('attack',
            preconditions={'has_weapon': True, 'enemy_in_range': True},
            effects={'enemy_dead': True}, cost=1))
        plan = planner.plan(
            world={'has_weapon': False, 'weapon_nearby': True, 'enemy_in_range': True},
            goal={'enemy_dead': True}
        )
        # plan = ['pickup_weapon', 'attack']
    """

    def __init__(self):
        self.actions: List[GOAPAction] = []

    def add(self, action: GOAPAction) -> "GOAPPlanner":
        self.actions.append(action); return self

    def plan(self, world: Dict[str, bool], goal: Dict[str, bool]) -> List[str]:
        """A* search over the world state graph. Returns action name sequence."""
        def h(state): return sum(1 for k,v in goal.items() if state.get(k) != v)
        def goal_met(state): return all(state.get(k)==v for k,v in goal.items())

        start = (0.0, 0, world, [])  # (f, counter, state, plan)
        heap  = [start]; counter = 0
        visited: Set = set()

        while heap:
            f, _, state, plan = heapq.heappop(heap)
            state_key = frozenset(state.items())
            if state_key in visited: continue
            visited.add(state_key)
            if goal_met(state): return plan
            for a in self.actions:
                if a.is_applicable(state):
                    new_state = a.apply(state)
                    new_plan  = plan + [a.name]
                    g = sum(self.actions[self.actions.index(act)].cost
                            for act in self.actions if act.name in new_plan)
                    counter += 1
                    heapq.heappush(heap, (g + h(new_state), counter, new_state, new_plan))
        return []   # no plan found

    def __repr__(self): return f"GOAPPlanner({len(self.actions)} actions)"


# ─────────────────────────────────────────────────────────────────────────────
# PERCEPTION  (sight, hearing, memory)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PerceivedObject:
    obj:          Any
    last_seen_pos: Vec2
    last_seen_at:  float
    is_visible:   bool = False

    @property
    def age(self) -> float: return time.time() - self.last_seen_at


class Perception:
    """
    Sight, hearing, and memory for AI agents.

    Usage:
        perception = Perception(sight_range=250, sight_fov=120, hearing_range=150)
        visible = perception.get_visible(agent_pos, agent_facing, candidates)
        heard   = perception.get_heard(agent_pos, candidates)
        memory  = perception.get_memory('player')
    """

    def __init__(self, sight_range: float = 200.0, sight_fov: float = 120.0,
                 hearing_range: float = 150.0, memory_duration: float = 5.0,
                 navmesh: Optional[NavMesh] = None):
        self.sight_range    = sight_range
        self.sight_fov      = math.radians(sight_fov)
        self.hearing_range  = hearing_range
        self.memory_duration = memory_duration
        self.navmesh        = navmesh
        self._memory: Dict[Any, PerceivedObject] = {}

    def update(self, agent_pos: Vec2, agent_facing: float,
               candidates: List[Tuple[Any, Vec2]], dt: float):
        """
        Update perception. candidates = [(object, world_pos), ...]
        """
        # Expire old memories
        self._memory = {k: v for k, v in self._memory.items()
                        if v.age < self.memory_duration}

        for obj, pos in candidates:
            visible = self._can_see(agent_pos, agent_facing, pos)
            heard   = self._can_hear(agent_pos, pos)
            if visible or heard:
                self._memory[obj] = PerceivedObject(obj, pos, time.time(), visible)

    def _can_see(self, from_pos: Vec2, facing: float, target: Vec2) -> bool:
        d = target - from_pos
        dist = d.length()
        if dist > self.sight_range: return False
        angle_to_target = math.atan2(d.y, d.x)
        angle_diff = abs(math.atan2(math.sin(angle_to_target - facing),
                                    math.cos(angle_to_target - facing)))
        if angle_diff > self.sight_fov / 2: return False
        # Line-of-sight check via navmesh
        if self.navmesh:
            return self.navmesh._line_of_sight(from_pos, target)
        return True

    def _can_hear(self, from_pos: Vec2, target: Vec2) -> bool:
        return from_pos.dist(target) <= self.hearing_range

    def get_visible(self, agent_pos: Vec2, facing: float,
                    candidates: List[Tuple[Any, Vec2]]) -> List[Any]:
        return [obj for obj, pos in candidates
                if self._can_see(agent_pos, facing, pos)]

    def get_heard(self, agent_pos: Vec2,
                  candidates: List[Tuple[Any, Vec2]]) -> List[Any]:
        return [obj for obj, pos in candidates
                if self._can_hear(agent_pos, pos)]

    def get_memory(self, obj: Any) -> Optional[PerceivedObject]:
        return self._memory.get(obj)

    def knows_about(self, obj: Any) -> bool:
        return obj in self._memory

    def last_known_pos(self, obj: Any) -> Optional[Vec2]:
        m = self._memory.get(obj)
        return m.last_seen_pos if m else None

    def clear_memory(self, obj: Any = None):
        if obj: self._memory.pop(obj, None)
        else:   self._memory.clear()

    def __repr__(self):
        return f"Perception(sight={self.sight_range}, fov={math.degrees(self.sight_fov):.0f}°, memory={len(self._memory)})"


# ─────────────────────────────────────────────────────────────────────────────
# AI AGENT  (entity that uses all of the above)
# ─────────────────────────────────────────────────────────────────────────────

class AIAgent:
    """
    Base AI agent. Combine with FSM, BehaviorTree, UtilityAI, or GOAP.

    Usage:
        agent = AIAgent(pos=Vec2(100, 200), speed=120)
        agent.fsm = my_fsm
        agent.fsm.start('idle', agent)
        # each frame:
        agent.update(dt)
    """
    _id_counter = 0

    def __init__(self, pos: Vec2 = None, speed: float = 100.0):
        AIAgent._id_counter += 1
        self.id          = AIAgent._id_counter
        self.pos         = pos or Vec2()
        self.vel         = Vec2()
        self.facing      = 0.0    # radians
        self.speed       = speed
        self.health      = 100.0
        self.max_health  = 100.0
        self.tag         = ""
        self.user_data: Dict[str, Any] = {}

        # AI modules (all optional — attach what you need)
        self.fsm:        Optional[FSM]            = None
        self.btree:      Optional[BehaviorTree]   = None
        self.utility:    Optional[UtilityAI]      = None
        self.perception: Optional[Perception]     = None
        self.navmesh:    Optional[NavMesh]        = None
        self._path_follower: Optional[PathFollower] = None

        # Steering
        self._steering_force = Vec2()
        self._wander_angle   = random.uniform(0, math.pi * 2)

    # ── Update ───────────────────────────────────────────────────────────
    def update(self, dt: float):
        """Tick whichever AI module is attached."""
        if self.fsm:     self.fsm.update(self, dt)
        if self.btree:   self.btree.update(self, dt)
        if self.utility: self.utility.update(self, dt)
        # Apply path following
        if self._path_follower and not self._path_follower.done:
            new_pos, done = self._path_follower.update(self.pos, dt)
            self.vel = (new_pos - self.pos) / (dt + 1e-10)
            self.pos = new_pos
        elif self._steering_force.length() > 1e-6:
            self.vel = self.vel + self._steering_force * dt
            if self.vel.length() > self.speed:
                self.vel = self.vel.normalized() * self.speed
            self.pos = self.pos + self.vel * dt
            self._steering_force = Vec2()
        if self.vel.length() > 1e-6:
            self.facing = math.atan2(self.vel.y, self.vel.x)

    # ── Navigation ───────────────────────────────────────────────────────
    def navigate_to(self, target: Vec2, smooth: bool = True):
        """Request path to target via navmesh."""
        if self.navmesh:
            path = self.navmesh.find_path(self.pos, target, smooth)
            self._path_follower = PathFollower(path, self.speed)
        else:
            self._path_follower = PathFollower([self.pos, target], self.speed)

    def stop_navigation(self):
        self._path_follower = None; self.vel = Vec2()

    # ── Steering shorthands ──────────────────────────────────────────────
    def seek(self, target: Vec2):
        self._steering_force = self._steering_force + Steering.seek(self.pos, target, self.speed)

    def flee(self, threat: Vec2):
        self._steering_force = self._steering_force + Steering.flee(self.pos, threat, self.speed)

    def arrive(self, target: Vec2, slow_r: float = 80.0):
        self._steering_force = self._steering_force + Steering.arrive(self.pos, target, self.speed, slow_r)

    def wander(self, dt: float):
        force, self._wander_angle = Steering.wander(self.pos, self._wander_angle, dt)
        self._steering_force = self._steering_force + force * self.speed

    # ── Queries ──────────────────────────────────────────────────────────
    def dist_to(self, other: "AIAgent") -> float: return self.pos.dist(other.pos)
    def can_see(self, other: "AIAgent") -> bool:
        if self.perception: return self.perception._can_see(self.pos, self.facing, other.pos)
        return False
    def is_alive(self) -> bool: return self.health > 0
    def take_damage(self, amount: float): self.health = max(0, self.health - amount)
    def heal(self, amount: float): self.health = min(self.max_health, self.health + amount)

    def __repr__(self): return f"AIAgent(id={self.id}, pos={self.pos}, hp={self.health:.0f})"


# ─────────────────────────────────────────────────────────────────────────────
# AI WORLD  (scene registry + bulk update)
# ─────────────────────────────────────────────────────────────────────────────

class AIWorld:
    """
    Scene-level AI registry.
    Register all agents, then call world.update(dt) each frame.

    Usage:
        world = AIWorld()
        world.add(enemy1); world.add(enemy2)
        world.set_navmesh(nav)
        world.update(dt)
    """

    def __init__(self):
        self.agents:    List[AIAgent]          = []
        self.flocks:    List[Flock]            = []
        self.navmesh:   Optional[NavMesh]      = None
        self.influence: Optional[InfluenceMap] = None
        self.time       = 0.0

    def add(self, agent: AIAgent) -> AIAgent:
        self.agents.append(agent)
        if self.navmesh and not agent.navmesh:
            agent.navmesh = self.navmesh
        return agent

    def remove(self, agent: AIAgent):
        if agent in self.agents: self.agents.remove(agent)

    def add_flock(self, flock: Flock) -> Flock:
        self.flocks.append(flock); return flock

    def set_navmesh(self, nav: NavMesh):
        self.navmesh = nav
        for a in self.agents: a.navmesh = nav

    def set_influence_map(self, imap: InfluenceMap):
        self.influence = imap

    def update(self, dt: float):
        self.time += dt
        for agent in list(self.agents):
            if agent.is_alive(): agent.update(dt)
        for flock in self.flocks:
            flock.update(dt)

    def get_agents_in_radius(self, pos: Vec2, radius: float) -> List[AIAgent]:
        return [a for a in self.agents if a.pos.dist(pos) <= radius]

    def get_nearest(self, pos: Vec2, tag: str = "") -> Optional[AIAgent]:
        candidates = [a for a in self.agents if not tag or a.tag == tag]
        if not candidates: return None
        return min(candidates, key=lambda a: a.pos.dist(pos))

    def query_tag(self, tag: str) -> List[AIAgent]:
        return [a for a in self.agents if a.tag == tag]

    def alive_count(self) -> int:
        return sum(1 for a in self.agents if a.is_alive())

    def __repr__(self):
        return f"AIWorld(agents={len(self.agents)}, alive={self.alive_count()}, t={self.time:.1f}s)"


# ─────────────────────────────────────────────────────────────────────────────
# FACTORY HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def make_world() -> AIWorld:
    return AIWorld()

def make_navmesh(width: int, height: int, cell_size: float = 32.0) -> NavMesh:
    return NavMesh(width, height, cell_size)

def make_flock(n: int, bounds: Tuple = None, speed: float = 120.0) -> Flock:
    flock = Flock(bounds)
    if bounds:
        x0,y0,x1,y1 = bounds
        for _ in range(n):
            b = Boid(Vec2(random.uniform(x0,x1), random.uniform(y0,y1)))
            b.max_speed = speed; flock.add(b)
    else:
        for _ in range(n):
            b = Boid(Vec2(random.uniform(0,800), random.uniform(0,600)))
            b.max_speed = speed; flock.add(b)
    return flock

def make_fsm(*state_pairs) -> FSM:
    """make_fsm(('idle',IdleState()), ('chase',ChaseState()), ...)"""
    fsm = FSM()
    for name, state in state_pairs: fsm.add_state(name, state)
    return fsm

def make_btree(root: BTNode) -> BehaviorTree:
    return BehaviorTree(root)

def make_influence_map(width: int, height: int, cell_size: float = 32.0) -> InfluenceMap:
    return InfluenceMap(width, height, cell_size)

def make_utility_ai(*actions: UtilityAction) -> UtilityAI:
    u = UtilityAI()
    for a in actions: u.add(a)
    return u

def make_goap(*actions: GOAPAction) -> GOAPPlanner:
    g = GOAPPlanner()
    for a in actions: g.add(a)
    return g

def make_perception(sight: float = 200.0, fov: float = 120.0,
                    hearing: float = 150.0, nav: NavMesh = None) -> Perception:
    return Perception(sight, fov, hearing, navmesh=nav)
