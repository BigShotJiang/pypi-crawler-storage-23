# inscript/interpreter.py  — Phase 4: Tree-Walking Interpreter
#
# Walks the AST and executes every node.
# After Lexer → Parser → Analyzer pass, this is what runs InScript programs.

from __future__ import annotations
import math, random, time
from typing import Any, Dict, List, Optional

from ast_nodes import *
from environment import Environment
from stdlib_values import (
    Vec2, Vec3, Color, Rect,
    InScriptFunction, InScriptInstance, InScriptRange
)
import stdlib as _stdlib  # loads all built-in modules
from errors import (
    InScriptRuntimeError, NameError_, IndexError_,
    ReturnSignal, BreakSignal, ContinueSignal
)


# ─────────────────────────────────────────────────────────────────────────────
# INTERPRETER
# ─────────────────────────────────────────────────────────────────────────────

class Interpreter(Visitor):
    """
    Tree-walking interpreter.  Visits each AST node and returns a Python value.
    """

    def __init__(self, source_lines: List[str] = None):
        self._src   = source_lines or []
        self._globals = Environment(name="global")
        self._env     = self._globals
        self._call_depth = 0
        self._MAX_CALL_DEPTH = 500

        self._register_builtins()

    # ── utilities ─────────────────────────────────────────────────────────────

    def _src_line(self, line: int) -> str:
        return self._src[line-1] if self._src and 0 < line <= len(self._src) else ""

    def _error(self, msg: str, line: int = 0):
        raise InScriptRuntimeError(msg, line, 0, self._src_line(line))

    def _push(self, name="block") -> Environment:
        self._env = Environment(parent=self._env, name=name)
        return self._env

    def _pop(self):
        self._env = self._env.parent

    # ── entry point ───────────────────────────────────────────────────────────

    def run(self, program: Program) -> Any:
        """Execute a full program."""
        return self.visit(program)

    def execute(self, source: str) -> Any:
        """Convenience: lex, parse, and run source code directly."""
        from parser import parse
        prog = parse(source)
        return self.run(prog)

    # ── built-in functions ────────────────────────────────────────────────────

    def _register_builtins(self):
        """Populate the global scope with built-in callables and constants."""
        env = self._globals

        # ── I/O ──────────────────────────────────────────────────────────────
        def _print(*args):
            print(" ".join(_to_string(a) for a in args))
            return None

        def _input_fn(prompt=""):
            return input(prompt)

        # ── Math ─────────────────────────────────────────────────────────────
        def _clamp(v, lo, hi): return max(lo, min(hi, v))
        def _lerp(a, b, t): return a + (b - a) * t
        def _map_range(v, a1, b1, a2, b2):
            return a2 + (v - a1) / (b1 - a1) * (b2 - a2) if b1 != a1 else a2
        def _sign(v): return 1 if v > 0 else (-1 if v < 0 else 0)
        def _random_fn(*args):
            if len(args) == 0: return random.random()
            if len(args) == 1: return random.random() * args[0]
            return random.uniform(args[0], args[1])
        def _random_int(lo, hi): return random.randint(int(lo), int(hi))

        # ── Type conversions ─────────────────────────────────────────────────
        def _to_int(v):
            if isinstance(v, bool): return int(v)
            if isinstance(v, (int, float)): return int(v)
            if isinstance(v, str):
                try: return int(v)
                except ValueError: self._error(f"Cannot convert '{v}' to int")
            self._error(f"Cannot convert {type(v).__name__} to int")

        def _to_float(v):
            if isinstance(v, (int, float, bool)): return float(v)
            if isinstance(v, str):
                try: return float(v)
                except ValueError: self._error(f"Cannot convert '{v}' to float")
            self._error(f"Cannot convert {type(v).__name__} to float")

        def _to_string(v): return _inscript_str(v)
        def _to_bool(v):   return bool(v)

        # ── Game-type constructors ────────────────────────────────────────────
        def _vec2(*args):
            if len(args) == 0: return Vec2(0,0)
            if len(args) == 1: return Vec2(args[0], args[0])
            return Vec2(args[0], args[1])

        def _vec3(*args):
            if len(args) == 0: return Vec3(0,0,0)
            if len(args) == 3: return Vec3(*args)
            self._error("Vec3() takes 0 or 3 arguments")

        def _color(*args):
            if len(args) == 0: return Color(1,1,1,1)
            if len(args) == 3: return Color(args[0], args[1], args[2])
            if len(args) == 4: return Color(*args)
            self._error("Color() takes 0, 3, or 4 arguments")

        def _rect(*args):
            if len(args) == 4: return Rect(*args)
            self._error("Rect() takes 4 arguments (x, y, w, h)")

        # ── Array helpers ─────────────────────────────────────────────────────
        def _len(v):
            if isinstance(v, (list, str, dict)): return len(v)
            if isinstance(v, InScriptRange): return abs(v.end - v.start)
            self._error(f"len() does not support type {type(v).__name__}")

        # ── Time ──────────────────────────────────────────────────────────────
        def _time_now(): return time.time()

        # Register all
        native_fns = {
            "print":      _print,
            "input":      _input_fn,
            # math
            "sin":   math.sin,   "cos":  math.cos,   "tan":    math.tan,
            "asin":  math.asin,  "acos": math.acos,  "atan":   math.atan,
            "atan2": math.atan2, "sqrt": math.sqrt,  "log":    math.log,
            "log2":  math.log2,  "log10":math.log10, "exp":    math.exp,
            "abs":   abs,        "floor":math.floor, "ceil":   math.ceil,
            "round": round,      "pow":  pow,
            "clamp": _clamp,     "lerp": _lerp,
            "map_range": _map_range, "sign": _sign,
            "min":   min,        "max":  max,
            "random":      _random_fn,
            "random_int":  _random_int,
            # type conversion
            "int":    _to_int, "float": _to_float,
            "string": _to_string, "bool": _to_bool,
            # game types
            "Vec2":  _vec2, "Vec3":  _vec3,
            "Color": _color, "Rect": _rect,
            # array/string
            "len":   _len,
            # time
            "time":  _time_now,
        }
        for name, fn in native_fns.items():
            env.define(name, fn)

        # ── Namespace constants ───────────────────────────────────────────────
        color_ns = {
            "RED": Color.RED, "GREEN": Color.GREEN, "BLUE": Color.BLUE,
            "WHITE": Color.WHITE, "BLACK": Color.BLACK,
            "YELLOW": Color.YELLOW, "CYAN": Color.CYAN, "MAGENTA": Color.MAGENTA,
            "TRANSPARENT": Color.TRANSPARENT,
        }
        vec2_ns  = {
            "ZERO": Vec2.ZERO, "ONE": Vec2.ONE, "UP": Vec2.UP,
            "DOWN": Vec2.DOWN, "LEFT": Vec2.LEFT, "RIGHT": Vec2.RIGHT,
        }
        vec3_ns  = {
            "ZERO": Vec3.ZERO, "ONE": Vec3.ONE, "UP": Vec3.UP,
            "FORWARD": Vec3.FORWARD, "RIGHT": Vec3.RIGHT,
        }
        math_ns  = {
            "PI": math.pi, "TAU": math.tau, "E": math.e,
            "INF": math.inf, "NAN": math.nan,
        }
        env.define("_Color_ns",  color_ns)
        env.define("_Vec2_ns",   vec2_ns)
        env.define("_Vec3_ns",   vec3_ns)
        env.define("_Math_ns",   math_ns)

        # stub namespaces for game APIs (replaced by real renderers later)
        env.define("draw",    _StubNamespace("draw"))
        env.define("draw3d",  _StubNamespace("draw3d"))
        env.define("audio",   _StubNamespace("audio"))
        env.define("input",   _StubNamespace("input"))
        env.define("scene",   _StubNamespace("scene"))
        env.define("world",   _StubNamespace("world"))
        env.define("network", _StubNamespace("network"))
        env.define("physics", _StubNamespace("physics"))

    # ── Program & declarations ────────────────────────────────────────────────

    def visit_Program(self, node: Program) -> Any:
        result = None
        for stmt in node.body:
            result = self.visit(stmt)
        return result

    def visit_VarDecl(self, node: VarDecl) -> Any:
        value = self.visit(node.initializer) if node.initializer else None
        self._env.define(node.name, value, is_const=node.is_const)
        return value

    def visit_FunctionDecl(self, node: FunctionDecl) -> Any:
        fn = InScriptFunction(
            name    = node.name,
            params  = node.params,
            body    = node.body,
            closure = self._env,
        )
        self._env.define(node.name, fn)
        return fn

    def visit_StructDecl(self, node: StructDecl) -> Any:
        """Register the struct definition so instances can be created."""
        self._env.define(node.name, node)    # store the AST node as the "constructor"
        return None

    def visit_SceneDecl(self, node: SceneDecl) -> Any:
        """
        Executing a scene declaration runs on_start immediately,
        then simulates a few update + draw frames (headless mode).
        In full engine mode the renderer manages the loop.
        """
        self._push("scene:" + node.name)

        # Define scene-level vars
        for var in node.vars:
            self.visit(var)

        # Register scene methods
        for method in node.methods:
            self.visit(method)

        # Run on_start
        for hook in node.hooks:
            if hook.hook_type == "on_start":
                self._run_hook(hook, {})

        # Headless simulation: run on_update 1 frame at dt=1/60
        for hook in node.hooks:
            if hook.hook_type == "on_update":
                args = {}
                if hook.params:
                    args[hook.params[0].name] = 1.0/60.0
                self._run_hook(hook, args)

        # Run on_draw
        for hook in node.hooks:
            if hook.hook_type == "on_draw":
                self._run_hook(hook, {})

        self._pop()
        return None

    def _run_hook(self, hook: LifecycleHook, arg_vals: dict):
        self._push("hook:" + hook.hook_type)
        for name, val in arg_vals.items():
            self._env.define(name, val)
        try:
            self.visit(hook.body)
        except ReturnSignal:
            pass
        self._pop()

    def visit_ImportDecl(self, node: ImportDecl) -> Any:
        """
        import "math"             → bind all exports into current scope
        import "math" as M        → bind module dict as M
        from "math" import sin    → bind only listed names
        """
        try:
            mod = _stdlib.load_module(node.path)
        except ImportError:
            # Try loading as a file (Phase 26 adds full file loading)
            self._error(f"Module not found: '{node.path}'\n"
                        f"Built-in modules: {list(_stdlib._MODULES.keys())}",
                        node.line)
            return None

        if node.alias:
            # import "math" as M  → M is a dict
            self._env.define(node.alias, mod)
        elif node.names:
            # from "math" import sin, cos
            for name in node.names:
                if name not in mod:
                    self._error(f"Module '{node.path}' has no export '{name}'", node.line)
                self._env.define(name, mod[name])
        else:
            # import "math"  → bring all into scope
            for name, val in mod.items():
                self._env.define(name, val)
        return None

    def visit_EnumDecl(self, node: EnumDecl) -> Any:
        counter = 0
        enum_vals = {}
        for variant in node.variants:
            val = self.visit(variant.value) if variant.value else counter
            enum_vals[variant.name] = val
            counter = val + 1 if isinstance(val, int) else counter + 1
        # Register as a namespace
        self._env.define(node.name, enum_vals)
        return enum_vals

    # ── Statements ────────────────────────────────────────────────────────────

    def visit_BlockStmt(self, node: BlockStmt) -> Any:
        self._push("block")
        result = None
        try:
            for stmt in node.body:
                result = self.visit(stmt)
        finally:
            self._pop()
        return result

    def visit_ExprStmt(self, node: ExprStmt) -> Any:
        return self.visit(node.expr)

    def visit_PrintStmt(self, node: PrintStmt) -> Any:
        parts = [_inscript_str(self.visit(a)) for a in node.args]
        print(" ".join(parts))
        return None

    def visit_ReturnStmt(self, node: ReturnStmt) -> Any:
        val = self.visit(node.value) if node.value else None
        raise ReturnSignal(val)

    def visit_BreakStmt(self, node: BreakStmt) -> Any:
        raise BreakSignal()

    def visit_ContinueStmt(self, node: ContinueStmt) -> Any:
        raise ContinueSignal()

    def visit_IfStmt(self, node: IfStmt) -> Any:
        if _is_truthy(self.visit(node.condition)):
            return self.visit(node.then_branch)
        elif node.else_branch:
            return self.visit(node.else_branch)
        return None

    def visit_WhileStmt(self, node: WhileStmt) -> Any:
        while _is_truthy(self.visit(node.condition)):
            try:
                self._exec_block_no_scope(node.body)
            except BreakSignal:
                break
            except ContinueSignal:
                continue
        return None

    def visit_ForInStmt(self, node: ForInStmt) -> Any:
        iterable = self.visit(node.iterable)
        # Support list, range, InScriptRange, string, dict
        if isinstance(iterable, InScriptRange):
            it = iter(iterable)
        elif isinstance(iterable, (list, str, dict)):
            it = iter(iterable)
        else:
            self._error(f"Cannot iterate over {type(iterable).__name__}", node.line)

        for item in it:
            self._push("for")
            self._env.define(node.var_name, item)
            try:
                self._exec_block_no_scope(node.body)
            except BreakSignal:
                self._pop()
                break
            except ContinueSignal:
                self._pop()
                continue
            self._pop()
        return None

    def _exec_block_no_scope(self, block: BlockStmt):
        """Execute block body without pushing a new scope (caller manages scope)."""
        for stmt in block.body:
            self.visit(stmt)

    def visit_MatchStmt(self, node: MatchStmt) -> Any:
        subject = self.visit(node.subject)
        for arm in node.arms:
            if arm.pattern is None:          # wildcard _
                return self.visit(arm.body)
            pattern_val = self.visit(arm.pattern)
            if subject == pattern_val:
                return self.visit(arm.body)
        return None

    def visit_ThrowStmt(self, node: ThrowStmt) -> Any:
        val = self.visit(node.value)
        raise InScriptRuntimeError(str(val), node.line)

    def visit_TryCatchStmt(self, node: TryCatchStmt) -> Any:
        try:
            self.visit(node.body)
        except InScriptRuntimeError as e:
            self._push("catch")
            if node.catch_var:
                self._env.define(node.catch_var, str(e.message))
            self.visit(node.handler)
            self._pop()
        return None

    def visit_WaitStmt(self, node: WaitStmt) -> Any:
        # In headless mode just sleep; in engine mode this would yield
        dur = self.visit(node.duration)
        time.sleep(float(dur))
        return None

    def visit_AIDecl(self, node: AIDecl) -> Any:
        return None   # Phase 16

    def visit_ShaderDecl(self, node: ShaderDecl) -> Any:
        return None   # Phase 14

    # ── Expressions ───────────────────────────────────────────────────────────

    def visit_IntLiteralExpr(self,   n): return n.value
    def visit_FloatLiteralExpr(self, n): return n.value
    def visit_StringLiteralExpr(self,n): return n.value
    def visit_BoolLiteralExpr(self,  n): return n.value
    def visit_NullLiteralExpr(self,  n): return None

    def visit_IdentExpr(self, node: IdentExpr) -> Any:
        return self._env.get(node.name, node.line)

    def visit_ArrayLiteralExpr(self, node: ArrayLiteralExpr) -> Any:
        return [self.visit(e) for e in node.elements]

    def visit_DictLiteralExpr(self, node: DictLiteralExpr) -> Any:
        d = {}
        for k, v in node.pairs:
            d[self.visit(k)] = self.visit(v)
        return d

    def visit_BinaryExpr(self, node: BinaryExpr) -> Any:
        left = self.visit(node.left)
        op   = node.op

        # Short-circuit logical operators
        if op == "&&": return _is_truthy(left) and _is_truthy(self.visit(node.right))
        if op == "||": return _is_truthy(left) or  _is_truthy(self.visit(node.right))

        right = self.visit(node.right)

        if op == "+":
            # String concatenation: coerce right to string if left is string
            if isinstance(left, str):
                return left + _inscript_str(right)
            if isinstance(right, str):
                return _inscript_str(left) + right
            return left + right
        if op == "-":  return left - right
        if op == "*":  return left * right
        if op == "/":
            if right == 0: self._error("Division by zero", node.line)
            return left / right
        if op == "%":
            if right == 0: self._error("Modulo by zero", node.line)
            return left % right
        if op == "**": return left ** right
        if op == "==": return left == right
        if op == "!=": return left != right
        if op == "<":  return left <  right
        if op == ">":  return left >  right
        if op == "<=": return left <= right
        if op == ">=": return left >= right

        self._error(f"Unknown binary operator: '{op}'", node.line)

    def visit_UnaryExpr(self, node: UnaryExpr) -> Any:
        val = self.visit(node.operand)
        if node.op == "-": return -val
        if node.op == "!": return not _is_truthy(val)
        self._error(f"Unknown unary operator: '{node.op}'", node.line)

    def visit_AssignExpr(self, node: AssignExpr) -> Any:
        val = self.visit(node.value)
        op  = node.op
        target = node.target

        if op != "=":
            # Compound assignment: read current, apply op, write back
            cur = self.visit(target)
            sym_op = op[0]  # '+', '-', '*', '/'
            if sym_op == "+":
                val = (cur + _inscript_str(val)) if isinstance(cur, str) else cur + val
            elif sym_op == "-": val = cur - val
            elif sym_op == "*": val = cur * val
            elif sym_op == "/":
                if val == 0: self._error("Division by zero in compound assignment", node.line)
                val = cur / val
            elif sym_op == "%": val = cur % val

        # Write back to the target
        if isinstance(target, IdentExpr):
            self._env.set(target.name, val, node.line)
        elif isinstance(target, GetAttrExpr):
            obj = self.visit(target.obj)
            _set_attr(obj, target.attr, val, node.line)
        elif isinstance(target, IndexExpr):
            obj = self.visit(target.obj)
            idx = self.visit(target.index)
            try:
                obj[idx] = val
            except (IndexError, KeyError) as e:
                self._error(str(e), node.line)
        else:
            self._error("Invalid assignment target", node.line)
        return val

    def visit_SetAttrExpr(self, node: SetAttrExpr) -> Any:
        obj = self.visit(node.obj)
        val = self.visit(node.value)
        _set_attr(obj, node.attr, val, node.line)
        return val

    def visit_SetIndexExpr(self, node: SetIndexExpr) -> Any:
        obj = self.visit(node.obj)
        idx = self.visit(node.index)
        val = self.visit(node.value)
        try:
            obj[idx] = val
        except (IndexError, KeyError) as e:
            self._error(str(e), node.line)
        return val

    def visit_GetAttrExpr(self, node: GetAttrExpr) -> Any:
        obj = self.visit(node.obj)
        return _get_attr(obj, node.attr, node.line, self)

    def visit_IndexExpr(self, node: IndexExpr) -> Any:
        obj = self.visit(node.obj)
        idx = self.visit(node.index)
        try:
            return obj[idx]
        except (IndexError, KeyError, TypeError) as e:
            self._error(f"Index error: {e}", node.line)

    def visit_NamespaceAccessExpr(self, node: NamespaceAccessExpr) -> Any:
        """Color::RED, Vec2::ZERO, Math::PI, EnumName::Variant"""
        ns_map = {
            "Color": "_Color_ns", "Vec2": "_Vec2_ns",
            "Vec3": "_Vec3_ns",   "Math": "_Math_ns",
        }
        if node.namespace in ns_map:
            ns = self._env.get(ns_map[node.namespace], node.line)
            if node.member in ns:
                return ns[node.member]
            self._error(f"'{node.namespace}' has no member '{node.member}'", node.line)

        # Try user-defined enum
        try:
            ns = self._env.get(node.namespace, node.line)
            if isinstance(ns, dict) and node.member in ns:
                return ns[node.member]
        except Exception:
            pass
        self._error(f"Unknown namespace '{node.namespace}'", node.line)

    def visit_CallExpr(self, node: CallExpr) -> Any:
        # Resolve 'self' before evaluating callee so method calls bind the instance
        self_val = None
        if isinstance(node.callee, GetAttrExpr):
            obj = self.visit(node.callee.obj)
            if isinstance(obj, InScriptInstance):
                self_val = obj

        callee = self.visit(node.callee)

        # Evaluate arguments
        arg_vals = []
        arg_names = []
        for arg in node.args:
            arg_vals.append(self.visit(arg.value))
            arg_names.append(arg.name)

        # Native Python function
        if callable(callee) and not isinstance(callee, (InScriptFunction, type)):
            try:
                return callee(*arg_vals)
            except InScriptRuntimeError:
                raise
            except Exception as e:
                self._error(f"Error in built-in function: {e}", node.line)

        # Struct constructor (StructDecl node stored as value)
        if isinstance(callee, StructDecl):
            return self._create_struct(callee, arg_vals, arg_names, node.line)

        # User-defined InScript function (with optional 'self' binding for methods)
        if isinstance(callee, InScriptFunction):
            return self._call_function(callee, arg_vals, arg_names, node.line,
                                       self_instance=self_val)

        self._error(f"'{node.callee}' is not callable — got {type(callee).__name__}", node.line)

    def _create_struct(self, decl: StructDecl, arg_vals, arg_names, line) -> InScriptInstance:
        """Create a struct instance, applying defaults for omitted fields."""
        fields = {}
        # First apply defaults
        for field in decl.fields:
            if field.default:
                fields[field.name] = self.visit(field.default)
            else:
                fields[field.name] = None

        # Then apply provided args (by position or name)
        if arg_names and any(n is not None for n in arg_names):
            for name, val in zip(arg_names, arg_vals):
                if name: fields[name] = val
                else:
                    # positional among named — match by position
                    pos_idx = [i for i,n in enumerate(arg_names) if n is None].index(
                        arg_names.index(None))
                    fields[decl.fields[pos_idx].name] = val
        else:
            for i, val in enumerate(arg_vals):
                if i < len(decl.fields):
                    fields[decl.fields[i].name] = val

        # Register struct methods as bound functions
        inst = InScriptInstance(decl.name, fields)
        for method in decl.methods:
            bound = InScriptFunction(
                name    = method.name,
                params  = method.params,
                body    = method.body,
                closure = self._env,
            )
            inst.fields[method.name] = bound
        return inst

    def _call_function(self, fn: InScriptFunction, arg_vals, arg_names, line,
                       self_instance=None) -> Any:
        if self._call_depth >= self._MAX_CALL_DEPTH:
            self._error(f"Maximum call depth exceeded ({self._MAX_CALL_DEPTH}) — infinite recursion?", line)

        # Create new environment chained to closure
        call_env = Environment(parent=fn.closure, name=f"fn:{fn.name}")
        prev_env = self._env
        self._env = call_env
        self._call_depth += 1

        # Bind 'self' if this is a method call
        if self_instance is not None:
            call_env.define("self", self_instance)

        # Bind parameters
        if arg_names and any(n is not None for n in arg_names):
            # Named args
            name_to_val = {n: v for n, v in zip(arg_names, arg_vals) if n}
            pos_vals    = [v for n, v in zip(arg_names, arg_vals) if n is None]
            pos_idx     = 0
            for i, param in enumerate(fn.params):
                if param.name in name_to_val:
                    call_env.define(param.name, name_to_val[param.name])
                elif pos_idx < len(pos_vals):
                    call_env.define(param.name, pos_vals[pos_idx]); pos_idx += 1
                elif param.default:
                    call_env.define(param.name, self.visit(param.default))
                else:
                    call_env.define(param.name, None)
        else:
            for i, param in enumerate(fn.params):
                if i < len(arg_vals):
                    call_env.define(param.name, arg_vals[i])
                elif param.default:
                    call_env.define(param.name, self.visit(param.default))
                else:
                    call_env.define(param.name, None)

        # Execute body
        result = None
        try:
            for stmt in fn.body.body:
                self.visit(stmt)
        except ReturnSignal as r:
            result = r.value
        finally:
            self._env = prev_env
            self._call_depth -= 1

        return result

    def visit_StructInitExpr(self, node: StructInitExpr) -> Any:
        """Player { health: 50, pos: Vec2(0,0) }"""
        try:
            decl = self._env.get(node.struct_name, node.line)
        except Exception:
            self._error(f"Unknown struct '{node.struct_name}'", node.line)

        if not isinstance(decl, StructDecl):
            self._error(f"'{node.struct_name}' is not a struct", node.line)

        fields = {}
        # Defaults first
        for field in decl.fields:
            fields[field.name] = self.visit(field.default) if field.default else None

        # Then overrides from initializer
        for name, value_node in node.fields:
            fields[name] = self.visit(value_node)

        inst = InScriptInstance(decl.name, fields)
        for method in decl.methods:
            bound = InScriptFunction(method.name, method.params, method.body, self._env)
            inst.fields[method.name] = bound
        return inst

    def visit_LambdaExpr(self, node: LambdaExpr) -> Any:
        return InScriptFunction(
            name    = "<lambda>",
            params  = node.params,
            body    = node.body if isinstance(node.body, BlockStmt)
                      else BlockStmt(body=[ReturnStmt(value=node.body,
                                                       line=node.line, col=node.col)],
                                     line=node.line, col=node.col),
            closure = self._env,
        )

    def visit_RangeExpr(self, node: RangeExpr) -> Any:
        start = self.visit(node.start)
        end   = self.visit(node.end)
        return InScriptRange(start, end, node.inclusive)

    def visit_AwaitExpr(self, node: AwaitExpr) -> Any:
        return self.visit(node.expr)   # synchronous in Phase 4

    def visit_SpawnExpr(self, node: SpawnExpr) -> Any:
        return None   # Phase 6 (ECS)

    def visit_MatchArm(self, node: MatchArm) -> Any:
        return self.visit(node.body)

    def generic_visit(self, node: Node) -> Any:
        return None  # graceful fallthrough for unimplemented nodes


# ─────────────────────────────────────────────────────────────────────────────
# ATTRIBUTE ACCESS HELPERS
# Handle Vec2/Vec3/Color/Rect fields + InScriptInstance fields + method calls
# ─────────────────────────────────────────────────────────────────────────────

def _get_attr(obj: Any, name: str, line: int, interp: Interpreter) -> Any:
    # InScript instance (user struct)
    if isinstance(obj, InScriptInstance):
        if name in obj.fields:
            return obj.fields[name]
        # Check if it's a built-in method on the instance type
        interp._error(f"'{obj.struct_name}' has no attribute '{name}'", line)

    # Built-in game types
    if isinstance(obj, (Vec2, Vec3, Color, Rect)):
        try:
            return obj.get_attr(name)
        except AttributeError:
            pass

    # Lists: .length, .len, etc
    if isinstance(obj, list):
        return _list_method(obj, name, interp, line)

    # Dicts
    if isinstance(obj, dict):
        return _dict_method(obj, name, interp, line)

    # Strings
    if isinstance(obj, str):
        return _string_method(obj, name, interp, line)

    # Stub namespace fallthrough
    if isinstance(obj, _StubNamespace):
        return _StubMethod(obj.name, name)

    interp._error(f"Cannot access attribute '{name}' on {type(obj).__name__}", line)


def _set_attr(obj: Any, name: str, val: Any, line: int) -> None:
    if isinstance(obj, InScriptInstance):
        obj.set(name, val); return
    if isinstance(obj, (Vec2, Vec3, Color, Rect)):
        try: obj.set_attr(name, val); return
        except AttributeError: pass
    raise InScriptRuntimeError(f"Cannot set attribute '{name}'", line)


def _list_method(lst, name, interp, line):
    """Return a bound callable for list methods."""
    def push(val):    lst.append(val)
    def pop():        return lst.pop() if lst else None
    def pop_at(i):    return lst.pop(int(i))
    def insert(i, v): lst.insert(int(i), v)
    def remove(v):    lst.remove(v) if v in lst else None
    def contains(v):  return v in lst
    def reverse():    lst.reverse()
    def sort():       lst.sort(key=lambda x: (str(type(x)), x) if not isinstance(x, (int,float)) else (0, x))
    def clear():      lst.clear()
    def first():      return lst[0] if lst else None
    def last():       return lst[-1] if lst else None
    def slice_(a, b): return lst[int(a):int(b)]
    def join(sep=""):
        return sep.join(_inscript_str(x) for x in lst)
    def map_fn(fn):
        return [interp._call_function(fn, [x], [None], line)
                if isinstance(fn, InScriptFunction) else fn(x) for x in lst]
    def filter_fn(fn):
        return [x for x in lst
                if _is_truthy(interp._call_function(fn, [x], [None], line)
                              if isinstance(fn, InScriptFunction) else fn(x))]
    def reduce_fn(init, fn):
        acc = init
        for x in lst:
            acc = interp._call_function(fn, [acc, x], [None, None], line) \
                  if isinstance(fn, InScriptFunction) else fn(acc, x)
        return acc
    def find(fn):
        for x in lst:
            if _is_truthy(interp._call_function(fn, [x], [None], line)
                          if isinstance(fn, InScriptFunction) else fn(x)):
                return x
        return None
    def index_of(v): return lst.index(v) if v in lst else -1

    methods = {
        "push": push, "pop": pop, "pop_at": pop_at,
        "insert": insert, "remove": remove, "contains": contains,
        "reverse": reverse, "sort": sort, "clear": clear,
        "first": first, "last": last, "slice": slice_,
        "join": join, "map": map_fn, "filter": filter_fn,
        "reduce": reduce_fn, "find": find, "index_of": index_of,
        "length": len(lst), "len": len(lst),   # as properties
    }
    if name in methods:
        return methods[name]
    interp._error(f"Array has no method '{name}'", line)


def _dict_method(d, name, interp, line):
    def get(k, default=None): return d.get(k, default)
    def set_(k, v): d[k] = v
    def has(k):     return k in d
    def remove(k):
        if k in d: del d[k]
    def keys():     return list(d.keys())
    def values():   return list(d.values())
    def items():    return [[k,v] for k,v in d.items()]
    def clear():    d.clear()

    methods = {
        "get": get, "set": set_, "has": has, "remove": remove,
        "keys": keys, "values": values, "items": items, "clear": clear,
        "length": len(d), "len": len(d),
    }
    if name in methods:
        return methods[name]
    interp._error(f"Dict has no method '{name}'", line)


def _string_method(s, name, interp, line):
    methods = {
        "upper":       lambda: s.upper(),
        "lower":       lambda: s.lower(),
        "trim":        lambda: s.strip(),
        "trim_start":  lambda: s.lstrip(),
        "trim_end":    lambda: s.rstrip(),
        "split":       lambda sep=" ": s.split(sep),
        "starts_with": lambda prefix: s.startswith(prefix),
        "ends_with":   lambda suffix: s.endswith(suffix),
        "contains":    lambda sub: sub in s,
        "replace":     lambda old, new: s.replace(old, new),
        "to_int":      lambda: int(s),
        "to_float":    lambda: float(s),
        "chars":       lambda: list(s),
        "length": len(s), "len": len(s),
    }
    if name in methods:
        return methods[name]
    interp._error(f"String has no method '{name}'", line)


# ─────────────────────────────────────────────────────────────────────────────
# STUBS (game API namespaces — replaced by real backends in later phases)
# ─────────────────────────────────────────────────────────────────────────────

class _StubNamespace:
    """A namespace that accepts any attribute access and call without crashing."""
    def __init__(self, name): self.name = name
    def __repr__(self): return f"<{self.name}>"

class _StubMethod:
    """A callable stub for game API methods (draw.rect, audio.play, etc.)"""
    def __init__(self, ns, method): self.ns = ns; self.method = method
    def __call__(self, *args, **kwargs): return None  # no-op in headless mode
    def __repr__(self): return f"<{self.ns}.{self.method}>"


# ─────────────────────────────────────────────────────────────────────────────
# UTILITY FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def _is_truthy(val) -> bool:
    if val is None:   return False
    if val is False:  return False
    if val == 0:      return False
    if val == 0.0:    return False
    if isinstance(val, str)  and val == "": return False
    if isinstance(val, list) and len(val) == 0: return False
    return True

def _inscript_str(val) -> str:
    if val is None:  return "null"
    if val is True:  return "true"
    if val is False: return "false"
    if isinstance(val, float):
        return str(int(val)) if val == int(val) else str(val)
    return str(val)


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def run(source: str) -> Any:
    """Lex, parse, and run InScript source code. Returns last expression value."""
    from parser import parse
    prog = parse(source)
    interp = Interpreter(source.splitlines())
    return interp.run(prog)
