# inscript/network/network.py  —  Phase 15: Networking & Multiplayer
#
# Build multiplayer games without a backend team.
#
# InScript networking API (mirrors this module):
#
#   // Server
#   let srv = Network.create_server(port: 7777, max_clients: 16)
#   srv.on_connect = |client| { print("joined: " + client.id) }
#   srv.on_data    = |client, pkt| { srv.broadcast(pkt) }
#   srv.on_disconnect = |client| { print("left: " + client.id) }
#   srv.start()
#
#   // Client
#   let cli = Network.connect("127.0.0.1", port: 7777)
#   cli.on_connect = || { cli.send({ type: "hello", name: "Player1" }) }
#   cli.on_data    = |pkt| { handle(pkt) }
#
#   // Synced variables (auto-replicated state)
#   sync let player_pos: Vec2 = Vec2(0, 0)
#   sync let health: int = 100
#
#   // RPC — call a function on remote peers
#   @rpc
#   fn take_damage(amount: int) { health -= amount }
#
# Features:
#   • TCP server + client  (reliable, ordered)
#   • UDP socket           (fast, unreliable — for position updates)
#   • WebSocket server + client (for browser / web export)
#   • Packet system: serialize / deserialize (JSON + compact binary)
#   • SyncVar: auto-replicate state variables with delta compression
#   • RPC:     call remote functions with args, return values, reliable
#   • Lobby:   room create / join / list / leave
#   • Relay:   TURN-style relay for NAT traversal
#   • Lag compensation: snapshot interpolation + client-side prediction
#   • NetStats: bandwidth, RTT, packet loss per connection
#
# This is a pure-Python implementation that runs without any extra deps.
# In production pair with asyncio or a C extension for real throughput.

from __future__ import annotations
import socket, threading, time, json, struct, hashlib, random, queue
import asyncio, weakref
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import deque


# ─────────────────────────────────────────────────────────────────────────────
# PACKET SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

class PacketType(Enum):
    HANDSHAKE       = 0x01
    HANDSHAKE_ACK   = 0x02
    DISCONNECT      = 0x03
    PING            = 0x04
    PONG            = 0x05
    DATA            = 0x10   # user data (JSON)
    SYNC_VAR        = 0x11   # synced variable update
    RPC             = 0x12   # remote procedure call
    RPC_RESULT      = 0x13   # RPC return value
    LOBBY_JOIN      = 0x20
    LOBBY_LEAVE     = 0x21
    LOBBY_LIST      = 0x22
    LOBBY_INFO      = 0x23
    RELAY           = 0x30   # relay message through server


# Wire format (all big-endian):
#   [magic: 2B] [type: 1B] [seq: 4B] [length: 4B] [payload: length bytes]
MAGIC   = b'\xC1\xAD'   # 0xC1AD — "clade" (InScript's brand)
HEADER_SIZE = 2 + 1 + 4 + 4   # 11 bytes


def encode_packet(ptype: PacketType, payload: Any, seq: int = 0) -> bytes:
    """Serialize a packet to bytes."""
    if isinstance(payload, (dict, list)):
        body = json.dumps(payload, separators=(',', ':')).encode()
    elif isinstance(payload, str):
        body = payload.encode()
    elif isinstance(payload, bytes):
        body = payload
    else:
        body = json.dumps(payload, separators=(',', ':')).encode()

    header = MAGIC + struct.pack('>BII', ptype.value, seq, len(body))
    return header + body


def decode_packet(data: bytes) -> Optional[Tuple[PacketType, int, Any]]:
    """
    Deserialize a packet from bytes.
    Returns (PacketType, seq, payload) or None if invalid.
    """
    if len(data) < HEADER_SIZE: return None
    if data[:2] != MAGIC: return None
    ptype_val, seq, length = struct.unpack('>BII', data[2:HEADER_SIZE])
    if len(data) < HEADER_SIZE + length: return None
    body = data[HEADER_SIZE:HEADER_SIZE + length]
    try:
        ptype = PacketType(ptype_val)
    except ValueError:
        return None
    try:
        payload = json.loads(body)
    except Exception:
        payload = body
    return ptype, seq, payload


class PacketBuffer:
    """Accumulates incoming bytes and yields complete packets."""

    def __init__(self):
        self._buf = bytearray()

    def feed(self, data: bytes) -> List[Tuple[PacketType, int, Any]]:
        self._buf.extend(data)
        packets = []
        while len(self._buf) >= HEADER_SIZE:
            if self._buf[:2] != MAGIC:
                # Scan for magic
                idx = self._buf.find(MAGIC, 1)
                if idx < 0: self._buf.clear(); break
                del self._buf[:idx]
                continue
            _, _, length = struct.unpack('>BII', bytes(self._buf[2:HEADER_SIZE]))
            total = HEADER_SIZE + length
            if len(self._buf) < total: break
            pkt = decode_packet(bytes(self._buf[:total]))
            if pkt: packets.append(pkt)
            del self._buf[:total]
        return packets


# ─────────────────────────────────────────────────────────────────────────────
# NET STATS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class NetStats:
    """Per-connection network statistics."""
    bytes_sent:     int   = 0
    bytes_recv:     int   = 0
    packets_sent:   int   = 0
    packets_recv:   int   = 0
    packets_lost:   int   = 0
    rtt_ms:         float = 0.0   # round-trip time (milliseconds)
    rtt_samples:    List[float] = field(default_factory=list)
    connected_at:   float = field(default_factory=time.time)

    @property
    def uptime_s(self) -> float:
        return time.time() - self.connected_at

    @property
    def bandwidth_in_kbps(self) -> float:
        t = self.uptime_s; return (self.bytes_recv / t / 1024 * 8) if t > 0 else 0

    @property
    def bandwidth_out_kbps(self) -> float:
        t = self.uptime_s; return (self.bytes_sent / t / 1024 * 8) if t > 0 else 0

    @property
    def loss_pct(self) -> float:
        total = self.packets_sent + self.packets_lost
        return (self.packets_lost / total * 100) if total > 0 else 0.0

    def record_rtt(self, rtt_ms: float):
        self.rtt_samples.append(rtt_ms)
        if len(self.rtt_samples) > 20: self.rtt_samples.pop(0)
        self.rtt_ms = sum(self.rtt_samples) / len(self.rtt_samples)

    def __repr__(self):
        return (f"NetStats(rtt={self.rtt_ms:.1f}ms, "
                f"in={self.bandwidth_in_kbps:.1f}kbps, "
                f"out={self.bandwidth_out_kbps:.1f}kbps, "
                f"loss={self.loss_pct:.1f}%)")


# ─────────────────────────────────────────────────────────────────────────────
# CLIENT PEER  (server-side view of a connected client)
# ─────────────────────────────────────────────────────────────────────────────

class ClientPeer:
    """
    Represents one connected client from the server's perspective.
    Created by NetServer when a new TCP connection arrives.
    """
    _id_counter = 0

    def __init__(self, sock: socket.socket, addr: Tuple, server: "NetServer"):
        ClientPeer._id_counter += 1
        self.id:     str = f"client_{ClientPeer._id_counter}"
        self.sock    = sock
        self.addr    = addr
        self.server  = server
        self.stats   = NetStats()
        self._buf    = PacketBuffer()
        self._seq    = 0
        self._alive  = True
        self._ping_t: float = 0.0
        self.user_data: Dict = {}
        self.room:   Optional[str] = None

    def send(self, data: Any) -> bool:
        """Send a DATA packet to this client."""
        return self._send_packet(PacketType.DATA, data)

    def _send_packet(self, ptype: PacketType, payload: Any) -> bool:
        if not self._alive: return False
        self._seq += 1
        raw = encode_packet(ptype, payload, self._seq)
        try:
            self.sock.sendall(raw)
            self.stats.bytes_sent += len(raw)
            self.stats.packets_sent += 1
            return True
        except OSError:
            self._alive = False; return False

    def ping(self):
        self._ping_t = time.perf_counter()
        self._send_packet(PacketType.PING, {'t': self._ping_t})

    def disconnect(self, reason: str = ""):
        if self._alive:
            self._send_packet(PacketType.DISCONNECT, {'reason': reason})
            self._alive = False
            try: self.sock.close()
            except: pass

    @property
    def is_connected(self) -> bool: return self._alive

    def __repr__(self): return f"ClientPeer(id={self.id}, addr={self.addr})"


# ─────────────────────────────────────────────────────────────────────────────
# NET SERVER  (TCP)
# ─────────────────────────────────────────────────────────────────────────────

class NetServer:
    """
    TCP game server. Manages connections, broadcasts, rooms, RPC routing.

    Usage:
        srv = NetServer(port=7777, max_clients=16)
        srv.on_connect    = lambda client: print(f"{client.id} joined")
        srv.on_data       = lambda client, data: srv.broadcast(data)
        srv.on_disconnect = lambda client: print(f"{client.id} left")
        srv.start()   # non-blocking
        # game loop
        while running:
            srv.poll()   # process pending events on main thread
            time.sleep(0.016)
        srv.stop()
    """

    def __init__(self, port: int = 7777, max_clients: int = 16,
                 host: str = '0.0.0.0'):
        self.port        = port
        self.host        = host
        self.max_clients = max_clients
        self.clients:    Dict[str, ClientPeer] = {}
        self._rooms:     Dict[str, Set[str]]   = {}   # room → set of client ids
        self._rpc_handlers: Dict[str, Callable] = {}
        self._sync_vars: Dict[str, Any] = {}

        # Event callbacks
        self.on_connect:    Optional[Callable[[ClientPeer], None]] = None
        self.on_disconnect: Optional[Callable[[ClientPeer], None]] = None
        self.on_data:       Optional[Callable[[ClientPeer, Any], None]] = None
        self.on_error:      Optional[Callable[[ClientPeer, Exception], None]] = None

        self._sock:   Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._event_queue: queue.Queue = queue.Queue()
        self._lock = threading.Lock()
        self.stats = NetStats()

    def start(self) -> "NetServer":
        """Start accepting connections (non-blocking, spawns background threads)."""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._sock.listen(self.max_clients)
        self._sock.setblocking(False)
        self._running = True
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()
        return self

    def stop(self):
        """Stop the server and disconnect all clients."""
        self._running = False
        for c in list(self.clients.values()): c.disconnect("server_shutdown")
        if self._sock:
            try: self._sock.close()
            except: pass

    def poll(self):
        """
        Process pending network events on the main thread.
        Call this every frame in your game loop.
        """
        try:
            while True:
                event_type, *args = self._event_queue.get_nowait()
                if   event_type == 'connect'    and self.on_connect:    self.on_connect(args[0])
                elif event_type == 'data'       and self.on_data:       self.on_data(args[0], args[1])
                elif event_type == 'disconnect' and self.on_disconnect: self.on_disconnect(args[0])
        except queue.Empty:
            pass
        # Ping all clients every 2s
        now = time.time()
        for c in list(self.clients.values()):
            if now - c._ping_t > 2.0: c.ping()

    # ── Broadcast / Send ─────────────────────────────────────────────────
    def broadcast(self, data: Any, exclude: Optional[ClientPeer] = None):
        """Send data to all connected clients."""
        for c in list(self.clients.values()):
            if exclude and c is exclude: continue
            c.send(data)

    def broadcast_room(self, room: str, data: Any, exclude: Optional[str] = None):
        """Send data to all clients in a room."""
        for cid in list(self._rooms.get(room, set())):
            if cid == exclude: continue
            if cid in self.clients: self.clients[cid].send(data)

    def send_to(self, client_id: str, data: Any) -> bool:
        c = self.clients.get(client_id)
        return c.send(data) if c else False

    # ── Rooms / Lobby ────────────────────────────────────────────────────
    def join_room(self, client: ClientPeer, room: str):
        if client.room: self.leave_room(client)
        with self._lock:
            if room not in self._rooms: self._rooms[room] = set()
            self._rooms[room].add(client.id)
        client.room = room
        self.broadcast_room(room, {'__type':'room_join','client':client.id,'room':room})

    def leave_room(self, client: ClientPeer):
        if not client.room: return
        room = client.room
        with self._lock:
            self._rooms.get(room, set()).discard(client.id)
            if not self._rooms.get(room): self._rooms.pop(room, None)
        client.room = None
        self.broadcast_room(room, {'__type':'room_leave','client':client.id,'room':room})

    def list_rooms(self) -> Dict[str, int]:
        return {r: len(m) for r, m in self._rooms.items()}

    # ── Sync vars ────────────────────────────────────────────────────────
    def set_sync(self, name: str, value: Any, scope: str = 'global'):
        """Set a server-side sync variable and replicate to all clients."""
        self._sync_vars[name] = value
        self.broadcast({'__type': 'sync', 'name': name, 'value': value, 'scope': scope})

    # ── RPC ──────────────────────────────────────────────────────────────
    def register_rpc(self, name: str, fn: Callable):
        self._rpc_handlers[name] = fn

    def rpc_all(self, fn_name: str, *args):
        """Call an RPC on all connected clients."""
        self.broadcast({'__type': 'rpc', 'fn': fn_name, 'args': list(args)})

    def rpc_client(self, client_id: str, fn_name: str, *args):
        self.send_to(client_id, {'__type': 'rpc', 'fn': fn_name, 'args': list(args)})

    # ── Internal ─────────────────────────────────────────────────────────
    def _accept_loop(self):
        import select
        while self._running:
            try:
                rlist, _, _ = select.select([self._sock], [], [], 0.05)
                if rlist:
                    conn, addr = self._sock.accept()
                    if len(self.clients) >= self.max_clients:
                        conn.close(); continue
                    client = ClientPeer(conn, addr, self)
                    with self._lock: self.clients[client.id] = client
                    # Send handshake
                    client._send_packet(PacketType.HANDSHAKE_ACK, {
                        'id': client.id, 'server': 'InScript', 'version': '1.0'
                    })
                    self._event_queue.put(('connect', client))
                    t = threading.Thread(target=self._recv_loop, args=(client,), daemon=True)
                    t.start()
            except Exception:
                pass

    def _recv_loop(self, client: ClientPeer):
        while self._running and client.is_connected:
            try:
                data = client.sock.recv(4096)
                if not data:
                    break
                client.stats.bytes_recv += len(data)
                for ptype, seq, payload in client._buf.feed(data):
                    client.stats.packets_recv += 1
                    self._handle_packet(client, ptype, payload)
            except (ConnectionResetError, OSError):
                break
        # Disconnected
        client._alive = False
        with self._lock: self.clients.pop(client.id, None)
        self.leave_room(client)
        self._event_queue.put(('disconnect', client))

    def _handle_packet(self, client: ClientPeer, ptype: PacketType, payload: Any):
        if ptype == PacketType.PING:
            client._send_packet(PacketType.PONG, payload)
        elif ptype == PacketType.PONG:
            if isinstance(payload, dict) and 't' in payload:
                rtt = (time.perf_counter() - payload['t']) * 1000
                client.stats.record_rtt(rtt)
        elif ptype == PacketType.DATA:
            if isinstance(payload, dict) and '__type' in payload:
                self._handle_meta(client, payload)
            else:
                self._event_queue.put(('data', client, payload))
        elif ptype == PacketType.DISCONNECT:
            client._alive = False

    def _handle_meta(self, client: ClientPeer, pkt: dict):
        t = pkt.get('__type')
        if t == 'room_join':   self.join_room(client, pkt.get('room', 'default'))
        elif t == 'room_leave': self.leave_room(client)
        elif t == 'room_list':
            client.send({'__type': 'room_list', 'rooms': self.list_rooms()})
        elif t == 'rpc':
            fn = self._rpc_handlers.get(pkt.get('fn', ''))
            if fn:
                result = fn(client, *pkt.get('args', []))
                if result is not None:
                    client._send_packet(PacketType.RPC_RESULT, {'fn': pkt['fn'], 'result': result})
        elif t == 'relay':
            target = pkt.get('to')
            if target and target in self.clients:
                self.clients[target].send({'__type': 'relay', 'from': client.id, 'data': pkt.get('data')})
            else:
                self.broadcast(pkt, exclude=client)
        else:
            self._event_queue.put(('data', client, pkt))

    @property
    def client_count(self) -> int: return len(self.clients)

    def __repr__(self):
        return f"NetServer(port={self.port}, clients={self.client_count}/{self.max_clients})"


# ─────────────────────────────────────────────────────────────────────────────
# NET CLIENT  (TCP)
# ─────────────────────────────────────────────────────────────────────────────

class NetClient:
    """
    TCP game client.

    Usage:
        cli = NetClient()
        cli.on_connect = lambda: cli.send({'name': 'Alice'})
        cli.on_data    = lambda pkt: handle(pkt)
        cli.on_disconnect = lambda: print("lost connection")
        cli.connect("127.0.0.1", 7777)  # non-blocking
        # game loop
        while running:
            cli.poll()
            time.sleep(0.016)
        cli.disconnect()
    """

    def __init__(self):
        self.id:          Optional[str] = None
        self._sock:       Optional[socket.socket] = None
        self._buf         = PacketBuffer()
        self._seq         = 0
        self._alive       = False
        self._event_queue = queue.Queue()
        self._rpc_handlers: Dict[str, Callable] = {}
        self._sync_vars:    Dict[str, Any] = {}
        self._pending_rpcs: Dict[int, Callable] = {}
        self.stats        = NetStats()
        self._ping_t:     float = 0.0

        # Callbacks
        self.on_connect:    Optional[Callable[[], None]] = None
        self.on_disconnect: Optional[Callable[[], None]] = None
        self.on_data:       Optional[Callable[[Any], None]] = None
        self.on_sync:       Optional[Callable[[str, Any], None]] = None
        self.on_rpc:        Optional[Callable[[str, list], None]] = None

    def connect(self, host: str = '127.0.0.1', port: int = 7777,
                timeout: float = 5.0) -> "NetClient":
        """Connect to server (non-blocking after handshake)."""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(timeout)
        self._sock.connect((host, port))
        self._sock.settimeout(None)
        self._alive = True
        t = threading.Thread(target=self._recv_loop, daemon=True)
        t.start()
        return self

    def disconnect(self, reason: str = ""):
        if self._alive:
            self._send_packet(PacketType.DISCONNECT, {'reason': reason})
            self._alive = False
            try: self._sock.close()
            except: pass

    def send(self, data: Any) -> bool:
        return self._send_packet(PacketType.DATA, data)

    def _send_packet(self, ptype: PacketType, payload: Any) -> bool:
        if not self._alive: return False
        self._seq += 1
        raw = encode_packet(ptype, payload, self._seq)
        try:
            self._sock.sendall(raw)
            self.stats.bytes_sent += len(raw)
            self.stats.packets_sent += 1
            return True
        except OSError:
            self._alive = False; return False

    # ── Lobby ────────────────────────────────────────────────────────────
    def join_room(self, room: str):
        self.send({'__type': 'room_join', 'room': room})

    def leave_room(self):
        self.send({'__type': 'room_leave'})

    def list_rooms(self):
        self.send({'__type': 'room_list'})

    # ── Sync vars ────────────────────────────────────────────────────────
    def sync(self, name: str, value: Any, scope: str = 'global'):
        """Replicate a variable change to the server."""
        self.send({'__type': 'sync', 'name': name, 'value': value, 'scope': scope})

    def get_sync(self, name: str, default: Any = None) -> Any:
        return self._sync_vars.get(name, default)

    # ── RPC ──────────────────────────────────────────────────────────────
    def register_rpc(self, name: str, fn: Callable):
        self._rpc_handlers[name] = fn

    def call_rpc(self, fn_name: str, *args, callback: Callable = None):
        pkt = {'__type': 'rpc', 'fn': fn_name, 'args': list(args)}
        if callback:
            self._pending_rpcs[self._seq + 1] = callback
        self.send(pkt)

    def ping(self):
        self._ping_t = time.perf_counter()
        self._send_packet(PacketType.PING, {'t': self._ping_t})

    # ── Poll ─────────────────────────────────────────────────────────────
    def poll(self):
        """Process pending events on the main thread. Call every frame."""
        try:
            while True:
                event_type, *args = self._event_queue.get_nowait()
                if   event_type == 'connect'    and self.on_connect:    self.on_connect()
                elif event_type == 'data'       and self.on_data:       self.on_data(args[0])
                elif event_type == 'sync'       and self.on_sync:       self.on_sync(args[0], args[1])
                elif event_type == 'rpc':
                    fn = self._rpc_handlers.get(args[0])
                    if fn: fn(*args[1])
                    if self.on_rpc: self.on_rpc(args[0], args[1])
                elif event_type == 'disconnect' and self.on_disconnect: self.on_disconnect()
        except queue.Empty:
            pass

    # ── Internal ─────────────────────────────────────────────────────────
    def _recv_loop(self):
        while self._alive:
            try:
                data = self._sock.recv(4096)
                if not data: break
                self.stats.bytes_recv += len(data)
                for ptype, seq, payload in self._buf.feed(data):
                    self.stats.packets_recv += 1
                    self._handle_packet(ptype, seq, payload)
            except (ConnectionResetError, OSError):
                break
        self._alive = False
        self._event_queue.put(('disconnect',))

    def _handle_packet(self, ptype: PacketType, seq: int, payload: Any):
        if ptype == PacketType.HANDSHAKE_ACK:
            if isinstance(payload, dict):
                self.id = payload.get('id')
            self._event_queue.put(('connect',))
        elif ptype == PacketType.PING:
            self._send_packet(PacketType.PONG, payload)
        elif ptype == PacketType.PONG:
            if isinstance(payload, dict) and 't' in payload:
                rtt = (time.perf_counter() - payload['t']) * 1000
                self.stats.record_rtt(rtt)
        elif ptype == PacketType.DISCONNECT:
            self._alive = False
        elif ptype == PacketType.DATA:
            if isinstance(payload, dict) and '__type' in payload:
                self._handle_meta(payload)
            else:
                self._event_queue.put(('data', payload))
        elif ptype == PacketType.RPC_RESULT:
            if isinstance(payload, dict):
                cb = self._pending_rpcs.pop(seq, None)
                if cb: cb(payload.get('result'))

    def _handle_meta(self, pkt: dict):
        t = pkt.get('__type')
        if t == 'sync':
            name = pkt.get('name'); val = pkt.get('value')
            self._sync_vars[name] = val
            self._event_queue.put(('sync', name, val))
        elif t == 'rpc':
            self._event_queue.put(('rpc', pkt.get('fn', ''), pkt.get('args', [])))
        elif t in ('room_join', 'room_leave', 'room_list', 'room_info'):
            self._event_queue.put(('data', pkt))
        else:
            self._event_queue.put(('data', pkt))

    @property
    def is_connected(self) -> bool: return self._alive

    def __repr__(self):
        return f"NetClient(id={self.id}, connected={self._alive})"


# ─────────────────────────────────────────────────────────────────────────────
# UDP SOCKET  (fast unreliable — for position/state updates)
# ─────────────────────────────────────────────────────────────────────────────

class UDPSocket:
    """
    Low-level UDP socket for fast, unreliable game state updates.
    Packet format: [magic:2B] [type:1B] [seq:4B] [payload: JSON]

    Use for: player positions, rotations, velocity — anything that's
    updated frequently and can tolerate occasional packet loss.
    """

    def __init__(self, port: int = 0, bind_addr: str = '0.0.0.0'):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.bind((bind_addr, port))
        self._sock.setblocking(False)
        self._seq = 0
        self.on_data: Optional[Callable[[Any, Tuple], None]] = None

    @property
    def local_port(self) -> int:
        return self._sock.getsockname()[1]

    def send_to(self, data: Any, addr: Tuple[str, int]) -> bool:
        self._seq += 1
        raw = MAGIC + struct.pack('>BI', 0x10, self._seq)
        raw += json.dumps(data, separators=(',', ':')).encode()
        try:
            self._sock.sendto(raw, addr); return True
        except OSError: return False

    def poll(self):
        """Drain incoming UDP datagrams. Call every frame."""
        while True:
            try:
                data, addr = self._sock.recvfrom(65535)
                if data[:2] != MAGIC: continue
                body = data[7:]
                try:
                    payload = json.loads(body)
                    if self.on_data: self.on_data(payload, addr)
                except Exception: pass
            except (BlockingIOError, OSError):
                break

    def close(self):
        try: self._sock.close()
        except: pass


# ─────────────────────────────────────────────────────────────────────────────
# WEBSOCKET  (for browser / web export)
# ─────────────────────────────────────────────────────────────────────────────

class WebSocketClient:
    """
    Minimal WebSocket client (RFC 6455).
    Suitable for connecting a native InScript game to a web browser peer.
    """

    def __init__(self):
        self._sock: Optional[socket.socket] = None
        self._alive = False
        self._handshaked = False
        self._key: bytes = b''
        self._buf = bytearray()
        self._event_queue: queue.Queue = queue.Queue()
        self.on_connect:    Optional[Callable] = None
        self.on_data:       Optional[Callable] = None
        self.on_disconnect: Optional[Callable] = None

    def connect(self, host: str, port: int = 80, path: str = '/') -> "WebSocketClient":
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.connect((host, port))
        # HTTP upgrade handshake
        import base64, os
        self._key = base64.b64encode(os.urandom(16))
        handshake = (
            f'GET {path} HTTP/1.1\r\n'
            f'Host: {host}:{port}\r\n'
            f'Upgrade: websocket\r\n'
            f'Connection: Upgrade\r\n'
            f'Sec-WebSocket-Key: {self._key.decode()}\r\n'
            f'Sec-WebSocket-Version: 13\r\n\r\n'
        ).encode()
        self._sock.sendall(handshake)
        # Read response
        resp = b''
        while b'\r\n\r\n' not in resp:
            resp += self._sock.recv(1024)
        if b'101' in resp:
            self._handshaked = True; self._alive = True
            t = threading.Thread(target=self._recv_loop, daemon=True)
            t.start()
            self._event_queue.put(('connect',))
        return self

    def send(self, data: Any) -> bool:
        if not self._alive: return False
        msg = json.dumps(data).encode()
        # WebSocket frame: FIN=1, opcode=1 (text), mask=1
        import os
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(msg))
        ln = len(msg)
        if ln < 126:    header = bytes([0x81, 0x80 | ln]) + mask
        elif ln < 65536:header = bytes([0x81, 0xFE]) + struct.pack('>H', ln) + mask
        else:            header = bytes([0x81, 0xFF]) + struct.pack('>Q', ln) + mask
        try: self._sock.sendall(header + masked); return True
        except OSError: self._alive = False; return False

    def poll(self):
        try:
            while True:
                event_type, *args = self._event_queue.get_nowait()
                if event_type == 'connect' and self.on_connect: self.on_connect()
                elif event_type == 'data' and self.on_data: self.on_data(args[0])
                elif event_type == 'disconnect' and self.on_disconnect: self.on_disconnect()
        except queue.Empty:
            pass

    def disconnect(self):
        self._alive = False
        try:
            self._sock.sendall(bytes([0x88, 0x80, 0, 0, 0, 0]))  # close frame
            self._sock.close()
        except: pass

    def _recv_loop(self):
        while self._alive:
            try:
                chunk = self._sock.recv(4096)
                if not chunk: break
                self._buf.extend(chunk)
                self._process_frames()
            except OSError: break
        self._alive = False
        self._event_queue.put(('disconnect',))

    def _process_frames(self):
        while len(self._buf) >= 2:
            b0, b1 = self._buf[0], self._buf[1]
            masked = bool(b1 & 0x80); plen = b1 & 0x7F; offset = 2
            if plen == 126:
                if len(self._buf) < 4: break
                plen = struct.unpack('>H', bytes(self._buf[2:4]))[0]; offset = 4
            elif plen == 127:
                if len(self._buf) < 10: break
                plen = struct.unpack('>Q', bytes(self._buf[2:10]))[0]; offset = 10
            mask_key = b''
            if masked:
                mask_key = bytes(self._buf[offset:offset+4]); offset += 4
            total = offset + plen
            if len(self._buf) < total: break
            payload = bytes(self._buf[offset:total])
            if masked: payload = bytes(b ^ mask_key[i%4] for i,b in enumerate(payload))
            del self._buf[:total]
            opcode = b0 & 0x0F
            if opcode == 1:   # text
                try:
                    data = json.loads(payload.decode())
                    self._event_queue.put(('data', data))
                except: pass
            elif opcode == 8: self._alive = False; break  # close


# ─────────────────────────────────────────────────────────────────────────────
# SYNC VAR  (replicated game state)
# ─────────────────────────────────────────────────────────────────────────────

class SyncVar:
    """
    A variable that auto-replicates its value across all peers when changed.

    Usage (server):
        player_pos = SyncVar('player_pos', Vec2(0,0), server=srv)
        player_pos.set(Vec2(10, 5))   # broadcasts to all clients

    Usage (client):
        player_pos = SyncVar('player_pos', Vec2(0,0))
        # Register with client to receive updates
        cli.on_sync = lambda n, v: player_pos.receive(n, v)
        pos = player_pos.get()   # local read
    """

    def __init__(self, name: str, initial: Any = None,
                 server: Optional[NetServer] = None,
                 client: Optional[NetClient] = None,
                 scope: str = 'global'):
        self.name   = name
        self._value = initial
        self._server = server
        self._client = client
        self._scope  = scope
        self._dirty  = False
        self._callbacks: List[Callable] = []

    def set(self, value: Any):
        self._value = value
        self._dirty = True
        if self._server:
            self._server.set_sync(self.name, value, self._scope)
        elif self._client:
            self._client.sync(self.name, value, self._scope)
        for cb in self._callbacks: cb(value)

    def get(self) -> Any:
        return self._value

    def receive(self, name: str, value: Any):
        """Called when the server/peer broadcasts an update."""
        if name == self.name:
            self._value = value
            for cb in self._callbacks: cb(value)

    def on_change(self, fn: Callable) -> "SyncVar":
        self._callbacks.append(fn); return self

    def __repr__(self): return f"SyncVar({self.name}={self._value!r})"


# ─────────────────────────────────────────────────────────────────────────────
# RPC  (Remote Procedure Call)
# ─────────────────────────────────────────────────────────────────────────────

class RPC:
    """
    Decorator / wrapper for remote procedure calls.

    Usage:
        @RPC.register(server)
        def take_damage(client, amount: int):
            health -= amount
            server.rpc_all('update_health', health)
    """

    def __init__(self, fn: Callable, target: Any = None):
        self.fn     = fn
        self.name   = fn.__name__
        self.target = target
        if target:
            target.register_rpc(self.name, fn)

    @staticmethod
    def register(target: Any):
        def decorator(fn):
            r = RPC(fn, target)
            return r
        return decorator

    def call(self, *args) -> Any:
        return self.fn(*args)

    def call_remote(self, *args):
        if isinstance(self.target, NetServer):
            self.target.rpc_all(self.name, *args)
        elif isinstance(self.target, NetClient):
            self.target.call_rpc(self.name, *args)

    def __call__(self, *args, **kwargs):
        return self.fn(*args, **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# SNAPSHOT INTERPOLATION  (lag compensation)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Snapshot:
    timestamp: float
    state:     Dict[str, Any]


class SnapshotBuffer:
    """
    Stores N snapshots of game state and interpolates between them.
    Used for smooth rendering of remote entities despite network jitter.

    Usage:
        buf = SnapshotBuffer(delay_ms=100)
        # On receive:
        buf.push({'x': 10, 'y': 5}, timestamp=server_time)
        # On render:
        state = buf.get_interpolated(current_time)
    """

    def __init__(self, delay_ms: float = 100.0, max_snapshots: int = 32):
        self.delay   = delay_ms / 1000.0
        self._snaps: deque = deque(maxlen=max_snapshots)

    def push(self, state: Dict[str, Any], timestamp: float = None):
        ts = timestamp if timestamp is not None else time.time()
        self._snaps.append(Snapshot(ts, state))

    def get_interpolated(self, render_time: float = None) -> Optional[Dict]:
        if not self._snaps: return None
        t = (render_time or time.time()) - self.delay
        snaps = list(self._snaps)

        # Find surrounding snapshots
        for i in range(len(snaps) - 1):
            a, b = snaps[i], snaps[i+1]
            if a.timestamp <= t <= b.timestamp:
                alpha = (t - a.timestamp) / (b.timestamp - a.timestamp + 1e-10)
                return self._lerp_state(a.state, b.state, alpha)

        # Extrapolate from last
        if snaps and t > snaps[-1].timestamp:
            return snaps[-1].state
        if snaps:
            return snaps[0].state
        return None

    @staticmethod
    def _lerp_state(a: Dict, b: Dict, alpha: float) -> Dict:
        result = {}
        for k in a:
            av, bv = a[k], b.get(k, a[k])
            if isinstance(av, (int, float)) and isinstance(bv, (int, float)):
                result[k] = av + (bv - av) * alpha
            elif isinstance(av, list) and isinstance(bv, list):
                result[k] = [
                    (x + (y - x) * alpha if isinstance(x, (int, float)) else x)
                    for x, y in zip(av, bv)
                ]
            else:
                result[k] = bv if alpha > 0.5 else av
        return result


# ─────────────────────────────────────────────────────────────────────────────
# CLIENT-SIDE PREDICTION
# ─────────────────────────────────────────────────────────────────────────────

class PredictionBuffer:
    """
    Stores client input history for server reconciliation.

    Usage (client):
        pred = PredictionBuffer()
        # Apply input immediately (predict):
        pred.apply(input_seq=42, delta={'move': [1, 0]})
        player_pos += move
        # When server confirms seq 42:
        pred.ack(42)
        # Replay unconfirmed inputs from current server state:
        for inp in pred.unconfirmed():
            player_pos += inp['delta']['move']
    """

    def __init__(self, max_history: int = 128):
        self._history: Dict[int, Dict] = {}
        self._max = max_history
        self._last_acked = -1

    def apply(self, input_seq: int, delta: Dict):
        self._history[input_seq] = {'seq': input_seq, 'delta': delta, 'time': time.time()}
        if len(self._history) > self._max:
            oldest = min(self._history)
            del self._history[oldest]

    def ack(self, server_seq: int):
        """Server confirmed inputs up to server_seq."""
        self._last_acked = server_seq
        to_remove = [s for s in self._history if s <= server_seq]
        for s in to_remove: del self._history[s]

    def unconfirmed(self) -> List[Dict]:
        return sorted(self._history.values(), key=lambda x: x['seq'])

    @property
    def pending_count(self) -> int: return len(self._history)


# ─────────────────────────────────────────────────────────────────────────────
# LOBBY SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LobbyRoom:
    id:         str
    name:       str
    max_players: int = 8
    players:    Dict[str, dict] = field(default_factory=dict)
    is_private: bool = False
    password:   str = ''
    game_mode:  str = 'default'
    state:      str = 'waiting'  # waiting | starting | playing | ended
    metadata:   Dict = field(default_factory=dict)

    @property
    def is_full(self): return len(self.players) >= self.max_players
    @property
    def player_count(self): return len(self.players)
    def to_dict(self):
        return {'id': self.id, 'name': self.name, 'max': self.max_players,
                'players': self.player_count, 'state': self.state,
                'mode': self.game_mode, 'private': self.is_private}


class LobbyManager:
    """
    Server-side lobby/room manager. Integrates with NetServer.

    Usage:
        lobby = LobbyManager(server)
        lobby.create_room('Room 1', max_players=4)
        # Clients can join via: client.send({'__type':'lobby_join','room':'Room 1'})
    """

    def __init__(self, server: NetServer):
        self.server = server
        self._rooms: Dict[str, LobbyRoom] = {}
        server.register_rpc('lobby_create', self._rpc_create)
        server.register_rpc('lobby_join',   self._rpc_join)
        server.register_rpc('lobby_leave',  self._rpc_leave)
        server.register_rpc('lobby_list',   self._rpc_list)
        server.register_rpc('lobby_start',  self._rpc_start)

    def create_room(self, name: str, max_players: int = 8,
                    game_mode: str = 'default', is_private: bool = False,
                    password: str = '') -> LobbyRoom:
        room_id = hashlib.md5(f"{name}{time.time()}".encode()).hexdigest()[:8]
        room = LobbyRoom(room_id, name, max_players,
                         is_private=is_private, password=password, game_mode=game_mode)
        self._rooms[room_id] = room
        return room

    def list_rooms(self, include_private: bool = False) -> List[Dict]:
        return [r.to_dict() for r in self._rooms.values()
                if not r.is_private or include_private]

    def get_room(self, room_id: str) -> Optional[LobbyRoom]:
        return self._rooms.get(room_id)

    def _rpc_create(self, client: ClientPeer, name: str, max_p: int = 8):
        room = self.create_room(name, max_p)
        return room.to_dict()

    def _rpc_join(self, client: ClientPeer, room_id: str, password: str = ''):
        room = self._rooms.get(room_id)
        if not room: return {'error': 'room_not_found'}
        if room.is_full: return {'error': 'room_full'}
        if room.is_private and password != room.password: return {'error': 'wrong_password'}
        room.players[client.id] = {'id': client.id}
        self.server.join_room(client, room_id)
        return room.to_dict()

    def _rpc_leave(self, client: ClientPeer):
        for room in self._rooms.values():
            room.players.pop(client.id, None)
        self.server.leave_room(client)
        return {'ok': True}

    def _rpc_list(self, client: ClientPeer):
        return {'rooms': self.list_rooms()}

    def _rpc_start(self, client: ClientPeer, room_id: str):
        room = self._rooms.get(room_id)
        if not room: return {'error': 'room_not_found'}
        room.state = 'playing'
        self.server.broadcast_room(room_id, {'__type': 'game_start', 'room': room.to_dict()})
        return {'ok': True}


# ─────────────────────────────────────────────────────────────────────────────
# RELAY SERVER  (NAT traversal helper)
# ─────────────────────────────────────────────────────────────────────────────

class RelayServer(NetServer):
    """
    TURN-style relay that forwards packets between clients who can't
    connect directly (e.g. behind symmetric NAT).

    Clients connect to the relay and send:
        {'__type': 'relay', 'to': 'client_xyz', 'data': {...}}
    The relay forwards to the target client, tagging 'from' header.
    """

    def __init__(self, port: int = 7778, **kwargs):
        super().__init__(port, **kwargs)
        self.on_data = self._relay_data

    def _relay_data(self, sender: ClientPeer, data: Any):
        if isinstance(data, dict) and data.get('__type') == 'relay':
            target_id = data.get('to')
            if target_id and target_id in self.clients:
                self.clients[target_id].send({
                    '__type': 'relay', 'from': sender.id, 'data': data.get('data')
                })
            else:
                # Broadcast to all except sender
                self.broadcast({'__type': 'relay', 'from': sender.id, 'data': data.get('data')},
                               exclude=sender)


# ─────────────────────────────────────────────────────────────────────────────
# HIGH-LEVEL NETWORK MANAGER  (InScript game-facing API)
# ─────────────────────────────────────────────────────────────────────────────

class NetworkManager:
    """
    Top-level API mirroring the InScript `Network` namespace.

    Usage:
        net = NetworkManager()
        srv = net.create_server(port=7777, max_clients=16)
        cli = net.connect('127.0.0.1', port=7777)
        lobby = net.create_lobby(srv)
    """

    def __init__(self):
        self._servers: List[NetServer] = []
        self._clients: List[NetClient] = []

    def create_server(self, port: int = 7777, max_clients: int = 16,
                      host: str = '0.0.0.0') -> NetServer:
        srv = NetServer(port, max_clients, host)
        self._servers.append(srv)
        return srv

    def connect(self, host: str = '127.0.0.1', port: int = 7777) -> NetClient:
        cli = NetClient()
        cli.connect(host, port)
        self._clients.append(cli)
        return cli

    def create_relay(self, port: int = 7778) -> RelayServer:
        relay = RelayServer(port)
        self._servers.append(relay)
        return relay

    def create_lobby(self, server: NetServer) -> LobbyManager:
        return LobbyManager(server)

    def make_udp(self, port: int = 0) -> UDPSocket:
        return UDPSocket(port)

    def make_sync_var(self, name: str, initial: Any = None,
                      server: NetServer = None, client: NetClient = None) -> SyncVar:
        return SyncVar(name, initial, server, client)

    def make_snapshot_buffer(self, delay_ms: float = 100.0) -> SnapshotBuffer:
        return SnapshotBuffer(delay_ms)

    def make_prediction_buffer(self) -> PredictionBuffer:
        return PredictionBuffer()

    def poll_all(self):
        """Poll all servers and clients. Call once per frame."""
        for srv in self._servers: srv.poll()
        for cli in self._clients: cli.poll()

    def stop_all(self):
        for srv in self._servers: srv.stop()
        for cli in self._clients: cli.disconnect()

    def __repr__(self):
        return f"NetworkManager(servers={len(self._servers)}, clients={len(self._clients)})"


# Singleton-style global instance (mirrors InScript's `Network.xxx` API)
Network = NetworkManager()
