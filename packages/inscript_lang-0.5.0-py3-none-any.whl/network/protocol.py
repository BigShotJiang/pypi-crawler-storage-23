# inscript/network/protocol.py  —  Phase 15: Networking (core protocol)
#
# Wire format, message types, serialization, and peer state.
# Used by both client.py and server.py.
#
# Packet layout (binary, little-endian):
#   [4 bytes]  magic   = 0x494E5343  ("INSC")
#   [1 byte]   version = 1
#   [1 byte]   type    = MessageType
#   [2 bytes]  flags
#   [4 bytes]  seq     (sequence number)
#   [4 bytes]  ack     (last received seq)
#   [4 bytes]  length  (payload bytes)
#   [N bytes]  payload (JSON or raw bytes)
#
# Total header: 20 bytes

from __future__ import annotations
import struct, json, time, hashlib, random
from enum import IntEnum
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field


MAGIC   = 0x494E5343    # "INSC"
VERSION = 1
HEADER_SIZE = 20


class MessageType(IntEnum):
    # Connection lifecycle
    HELLO        = 0x01   # C→S: introduce + negotiate
    WELCOME      = 0x02   # S→C: assign peer_id, game state
    DISCONNECT   = 0x03   # either direction: graceful close
    HEARTBEAT    = 0x04   # keep-alive ping
    HEARTBEAT_ACK= 0x05

    # Reliable data
    RELIABLE     = 0x10   # guaranteed ordered delivery
    RELIABLE_ACK = 0x11   # ACK for reliable packet

    # Unreliable data (fast, lossy OK)
    UNRELIABLE   = 0x20   # fire-and-forget

    # RPC
    RPC          = 0x30   # call fn on remote peer
    RPC_RESPONSE = 0x31   # return value from RPC

    # Sync variables
    SYNC_FULL    = 0x40   # full state snapshot
    SYNC_DELTA   = 0x41   # changed variables only

    # Lobby
    LOBBY_LIST   = 0x50
    LOBBY_CREATE = 0x51
    LOBBY_JOIN   = 0x52
    LOBBY_LEAVE  = 0x53
    LOBBY_STATE  = 0x54

    # Errors
    ERROR        = 0xFF


class PacketFlags(IntEnum):
    NONE      = 0x0000
    COMPRESSED= 0x0001
    ENCRYPTED = 0x0002
    BROADCAST = 0x0004
    ORDERED   = 0x0008


@dataclass
class Packet:
    """A single network packet."""
    type:    MessageType
    payload: Any                # Python object (will be JSON-serialized)
    flags:   int = PacketFlags.NONE
    seq:     int = 0
    ack:     int = 0

    def encode(self) -> bytes:
        """Serialize to wire bytes."""
        raw = json.dumps(self.payload, separators=(',', ':')).encode('utf-8')
        header = struct.pack('<IBBHII I',
            MAGIC, VERSION, int(self.type), self.flags,
            self.seq, self.ack, len(raw))
        return header + raw

    @staticmethod
    def decode(data: bytes) -> Optional["Packet"]:
        """Deserialize from wire bytes. Returns None on malformed input."""
        if len(data) < HEADER_SIZE: return None
        magic, version, ptype, flags, seq, ack, length = struct.unpack('<IBBHIII', data[:HEADER_SIZE])
        if magic != MAGIC or version != VERSION: return None
        raw = data[HEADER_SIZE:HEADER_SIZE + length]
        try:
            payload = json.loads(raw.decode('utf-8'))
        except Exception:
            payload = raw
        try:
            mtype = MessageType(ptype)
        except ValueError:
            mtype = MessageType.ERROR
        return Packet(mtype, payload, flags, seq, ack)

    @staticmethod
    def make(ptype: MessageType, payload: Any = None, **kw) -> "Packet":
        return Packet(ptype, payload or {}, **kw)

    def __repr__(self): return f"Packet({self.type.name}, seq={self.seq})"


# ── Peer state ────────────────────────────────────────────────────────────────

class PeerState(IntEnum):
    DISCONNECTED = 0
    CONNECTING   = 1
    HANDSHAKING  = 2
    CONNECTED    = 3
    DISCONNECTING= 4


@dataclass
class PeerInfo:
    """Metadata about a connected peer."""
    id:          str
    address:     Tuple[str, int]
    state:       PeerState  = PeerState.DISCONNECTED
    ping_ms:     float      = 0.0
    last_seen:   float      = field(default_factory=time.monotonic)
    seq_out:     int        = 0
    seq_in:      int        = 0
    reliable_buf: List[Packet] = field(default_factory=list)  # unacked reliable packets
    user_data:   Dict       = field(default_factory=dict)

    def bump_seq(self) -> int:
        self.seq_out = (self.seq_out + 1) % 0xFFFFFFFF
        return self.seq_out

    def is_alive(self, timeout: float = 10.0) -> bool:
        return time.monotonic() - self.last_seen < timeout

    def touch(self): self.last_seen = time.monotonic()

    def __repr__(self):
        return f"PeerInfo(id={self.id!r}, {self.address}, {self.state.name}, ping={self.ping_ms:.1f}ms)"


def make_peer_id() -> str:
    """Generate a unique peer ID."""
    return hashlib.sha1(
        f"{time.monotonic()}{random.random()}".encode()
    ).hexdigest()[:12]
