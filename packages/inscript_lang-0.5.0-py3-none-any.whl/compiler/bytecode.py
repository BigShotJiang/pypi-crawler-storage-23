# inscript/compiler/bytecode.py  —  Phase 19: Bytecode Compiler + VM
#
# 10–100× speed boost over tree-walking interpreter.
#
# Pipeline:
#   Source (.ins) → Lexer → Parser → Analyzer → BytecodeCompiler → .insb
#                                                                       ↓
#                                                                  BytecodeVM
#
# Architecture: Register-based VM (like Lua 5 / Dalvik).
# Each function gets a fixed-size register window. No operand stack.
# This avoids push/pop overhead and enables register allocation.
#
# Instruction encoding (all 32-bit):
#   [opcode: 8b] [A: 8b] [B: 8b] [C: 8b]        ← ABC format
#   [opcode: 8b] [A: 8b] [Bx: 16b]               ← ABx format  (Bx = B<<8|C)
#   [opcode: 8b] [A: 8b] [sBx: 16b signed]       ← AsBx (jumps, offsets)
#
# Features:
#   • 60+ opcodes covering all InScript constructs
#   • Constant pool: integers, floats, strings, function protos, null/bool
#   • Upvalue capture for closures
#   • Varargs support
#   • Mark-and-sweep garbage collector with generational hint
#   • .insb binary format (header + function chunks)
#   • Debug info: source line map, local variable names
#   • Disassembler for human-readable bytecode dumps
#   • VM profiler: opcode counters, hot-path detection
#   • Decompiler: bytecode → readable pseudo-source

from __future__ import annotations

import struct, math, time, os, sys
from typing import Any, Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from enum import IntEnum, auto
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import ast_nodes as ast


# ─────────────────────────────────────────────────────────────────────────────
# OPCODE TABLE
# ─────────────────────────────────────────────────────────────────────────────

class Op(IntEnum):
    # Load / store
    LOAD_CONST   = 0x01   # A = K[Bx]              load constant
    LOAD_NULL    = 0x02   # A = null
    LOAD_TRUE    = 0x03   # A = true
    LOAD_FALSE   = 0x04   # A = false
    LOAD_INT     = 0x05   # A = sBx               small integer inline
    MOVE         = 0x06   # A = B                 register copy
    GET_GLOBAL   = 0x07   # A = globals[K[Bx]]
    SET_GLOBAL   = 0x08   # globals[K[Bx]] = A
    GET_LOCAL    = 0x09   # A = locals[B]
    SET_LOCAL    = 0x0A   # locals[B] = A
    GET_UPVAL    = 0x0B   # A = upvalues[B]
    SET_UPVAL    = 0x0C   # upvalues[B] = A
    CLOSE_UPVAL  = 0x0D   # close upvalue at register B

    # Arithmetic (integer + float)
    ADD          = 0x10   # A = B + C
    SUB          = 0x11   # A = B - C
    MUL          = 0x12   # A = B * C
    DIV          = 0x13   # A = B / C
    MOD          = 0x14   # A = B % C
    POW          = 0x15   # A = B ** C
    NEG          = 0x16   # A = -B
    ADDK         = 0x17   # A = B + K[C]           constant right-hand operand
    SUBK         = 0x18   # A = B - K[C]
    MULK         = 0x19   # A = B * K[C]
    DIVK         = 0x1A   # A = B / K[C]

    # Bitwise
    BAND         = 0x1B   # A = B & C
    BOR          = 0x1C   # A = B | C
    BXOR         = 0x1D   # A = B ^ C
    BNOT         = 0x1E   # A = ~B
    SHL          = 0x1F   # A = B << C
    SHR          = 0x20   # A = B >> C

    # Comparison → result in A as bool
    EQ           = 0x21   # A = B == C
    NE           = 0x22   # A = B != C
    LT           = 0x23   # A = B < C
    LE           = 0x24   # A = B <= C
    GT           = 0x25   # A = B > C
    GE           = 0x26   # A = B >= C

    # Logical
    NOT          = 0x27   # A = !B
    AND          = 0x28   # A = B && C  (short-circuit handled by compiler)
    OR           = 0x29   # A = B || C

    # String
    CONCAT       = 0x2A   # A = B .. C   (string concat)
    STR_LEN      = 0x2B   # A = len(B)

    # Jumps (sBx is signed offset from next instruction)
    JUMP         = 0x30   # PC += sBx
    JUMP_TRUE    = 0x31   # if A: PC += sBx
    JUMP_FALSE   = 0x32   # if !A: PC += sBx
    JUMP_NULL    = 0x33   # if A == null: PC += sBx
    LOOP         = 0x34   # PC -= sBx  (backward jump, for loop)

    # Calls
    CALL         = 0x35   # A = fn, B = nargs (A+1..A+B), C = nreturn
    CALL_METHOD  = 0x36   # A = obj.method(A+2..A+2+B), C = nreturn
    RETURN       = 0x37   # return A..A+B-1
    RETURN_NULL  = 0x38   # return null
    TAIL_CALL    = 0x39   # tail-call optimized CALL

    # Tables / objects / arrays
    NEW_ARRAY    = 0x40   # A = []   (empty array)
    NEW_DICT     = 0x41   # A = {}   (empty dict)
    ARRAY_PUSH   = 0x42   # A.push(B)
    ARRAY_LEN    = 0x43   # A = len(B)
    ARRAY_GET    = 0x44   # A = B[C]
    ARRAY_SET    = 0x45   # B[C] = A
    DICT_GET     = 0x46   # A = B[K[C]]
    DICT_SET     = 0x47   # B[K[C]] = A
    GET_FIELD    = 0x48   # A = B.K[C]
    SET_FIELD    = 0x49   # B.K[C] = A
    GET_INDEX    = 0x4A   # A = B[C]
    SET_INDEX    = 0x4B   # B[C] = A

    # Functions / closures
    CLOSURE      = 0x50   # A = closure(proto[Bx])
    MAKE_CLOSURE = 0x51   # like CLOSURE but captures upvalues
    VARARG       = 0x52   # A..A+B-1 = vararg

    # Iterators
    FOR_PREP     = 0x53   # prepare numeric for loop (init/limit/step in A,A+1,A+2)
    FOR_STEP     = 0x54   # A += A+2; if A > A+1: PC += sBx (numeric for)
    ITER_PREP    = 0x55   # A = iter(B)   (for-in loop)
    ITER_NEXT    = 0x56   # A,A+1 = next(B); if done: PC += sBx

    # Structs / classes
    NEW_STRUCT   = 0x60   # A = new Struct(K[Bx])
    INHERIT      = 0x61   # A inherits B
    SELF         = 0x62   # A = self

    # Exception handling
    THROW        = 0x70   # throw A
    TRY_BEGIN    = 0x71   # push try frame, catch at PC+sBx
    TRY_END      = 0x72   # pop try frame
    CATCH        = 0x73   # A = caught exception

    # Type operations
    TYPE_CHECK   = 0x74   # A = (B instanceof K[C])
    TYPE_CAST    = 0x75   # A = cast<K[C]>(B)
    TO_STR       = 0x76   # A = str(B)
    TO_INT       = 0x77   # A = int(B)
    TO_FLOAT     = 0x78   # A = float(B)
    TO_BOOL      = 0x79   # A = bool(B)

    # Debug / misc
    PRINT        = 0x80   # print A  (debug print)
    NOP          = 0x81   # no-op
    HALT         = 0x82   # stop execution
    ASSERT       = 0x83   # if !A: error(K[B])
    PROFILE      = 0x84   # profiler sample point


# Opcode metadata: (name, format)  format = 'ABC' | 'ABx' | 'AsBx'
OP_META: Dict[Op, Tuple[str, str]] = {
    Op.LOAD_CONST:  ('LOAD_CONST',  'ABx'),
    Op.LOAD_NULL:   ('LOAD_NULL',   'A__'),
    Op.LOAD_TRUE:   ('LOAD_TRUE',   'A__'),
    Op.LOAD_FALSE:  ('LOAD_FALSE',  'A__'),
    Op.LOAD_INT:    ('LOAD_INT',    'AsBx'),
    Op.MOVE:        ('MOVE',        'AB_'),
    Op.GET_GLOBAL:  ('GET_GLOBAL',  'ABx'),
    Op.SET_GLOBAL:  ('SET_GLOBAL',  'ABx'),
    Op.GET_LOCAL:   ('GET_LOCAL',   'AB_'),
    Op.SET_LOCAL:   ('SET_LOCAL',   'AB_'),
    Op.GET_UPVAL:   ('GET_UPVAL',   'AB_'),
    Op.SET_UPVAL:   ('SET_UPVAL',   'AB_'),
    Op.CLOSE_UPVAL: ('CLOSE_UPVAL', 'A__'),
    Op.ADD:   ('ADD',  'ABC'), Op.SUB:  ('SUB',  'ABC'),
    Op.MUL:   ('MUL',  'ABC'), Op.DIV:  ('DIV',  'ABC'),
    Op.MOD:   ('MOD',  'ABC'), Op.POW:  ('POW',  'ABC'),
    Op.NEG:   ('NEG',  'AB_'), Op.ADDK: ('ADDK', 'ABC'),
    Op.SUBK:  ('SUBK', 'ABC'), Op.MULK: ('MULK', 'ABC'),
    Op.DIVK:  ('DIVK', 'ABC'),
    Op.BAND:  ('BAND', 'ABC'), Op.BOR:  ('BOR',  'ABC'),
    Op.BXOR:  ('BXOR', 'ABC'), Op.BNOT: ('BNOT', 'AB_'),
    Op.SHL:   ('SHL',  'ABC'), Op.SHR:  ('SHR',  'ABC'),
    Op.EQ:    ('EQ',   'ABC'), Op.NE:   ('NE',   'ABC'),
    Op.LT:    ('LT',   'ABC'), Op.LE:   ('LE',   'ABC'),
    Op.GT:    ('GT',   'ABC'), Op.GE:   ('GE',   'ABC'),
    Op.NOT:   ('NOT',  'AB_'), Op.AND:  ('AND',  'ABC'), Op.OR:  ('OR',  'ABC'),
    Op.CONCAT:('CONCAT','ABC'), Op.STR_LEN:('STR_LEN','AB_'),
    Op.JUMP:       ('JUMP',       'AsBx'),
    Op.JUMP_TRUE:  ('JUMP_TRUE',  'AsBx'),
    Op.JUMP_FALSE: ('JUMP_FALSE', 'AsBx'),
    Op.JUMP_NULL:  ('JUMP_NULL',  'AsBx'),
    Op.LOOP:       ('LOOP',       'AsBx'),
    Op.CALL:        ('CALL',        'ABC'),
    Op.CALL_METHOD: ('CALL_METHOD', 'ABC'),
    Op.RETURN:      ('RETURN',      'AB_'),
    Op.RETURN_NULL: ('RETURN_NULL', 'A__'),
    Op.TAIL_CALL:   ('TAIL_CALL',   'ABC'),
    Op.NEW_ARRAY:  ('NEW_ARRAY',  'A__'), Op.NEW_DICT:  ('NEW_DICT',  'A__'),
    Op.ARRAY_PUSH: ('ARRAY_PUSH', 'AB_'), Op.ARRAY_LEN: ('ARRAY_LEN', 'AB_'),
    Op.ARRAY_GET:  ('ARRAY_GET',  'ABC'), Op.ARRAY_SET: ('ARRAY_SET', 'ABC'),
    Op.GET_FIELD:  ('GET_FIELD',  'ABC'), Op.SET_FIELD: ('SET_FIELD', 'ABC'),
    Op.GET_INDEX:  ('GET_INDEX',  'ABC'), Op.SET_INDEX: ('SET_INDEX', 'ABC'),
    Op.CLOSURE:     ('CLOSURE',    'ABx'), Op.MAKE_CLOSURE:('MAKE_CLOSURE','ABx'),
    Op.VARARG:      ('VARARG',     'AB_'),
    Op.FOR_PREP:   ('FOR_PREP',  'AsBx'), Op.FOR_STEP:  ('FOR_STEP',  'AsBx'),
    Op.ITER_PREP:  ('ITER_PREP', 'AB_'),  Op.ITER_NEXT: ('ITER_NEXT', 'AsBx'),
    Op.NEW_STRUCT: ('NEW_STRUCT', 'ABx'), Op.SELF:      ('SELF',      'A__'),
    Op.THROW:      ('THROW',     'A__'),  Op.TRY_BEGIN: ('TRY_BEGIN', 'AsBx'),
    Op.TRY_END:    ('TRY_END',   'A__'),  Op.CATCH:     ('CATCH',     'A__'),
    Op.TYPE_CHECK: ('TYPE_CHECK','ABC'),  Op.TO_STR:    ('TO_STR',    'AB_'),
    Op.TO_INT:     ('TO_INT',    'AB_'),  Op.TO_FLOAT:  ('TO_FLOAT',  'AB_'),
    Op.TO_BOOL:    ('TO_BOOL',   'AB_'),
    Op.PRINT:      ('PRINT',     'AB_'),  Op.NOP:       ('NOP',       'A__'),
    Op.HALT:       ('HALT',      'A__'),  Op.ASSERT:    ('ASSERT',    'ABx'),
    Op.PROFILE:    ('PROFILE',   'A__'),
}


# ─────────────────────────────────────────────────────────────────────────────
# INSTRUCTION ENCODING
# ─────────────────────────────────────────────────────────────────────────────

def encode(op: Op, a: int = 0, b: int = 0, c: int = 0) -> int:
    """Pack a 32-bit instruction in ABC format."""
    return (int(op) & 0xFF) | ((a & 0xFF) << 8) | ((b & 0xFF) << 16) | ((c & 0xFF) << 24)

def encode_abx(op: Op, a: int, bx: int) -> int:
    return (int(op) & 0xFF) | ((a & 0xFF) << 8) | ((bx & 0xFFFF) << 16)

def encode_asbx(op: Op, a: int, sbx: int) -> int:
    bx = sbx + 0x8000  # bias: stored as unsigned, decoded as signed
    return encode_abx(op, a, bx & 0xFFFF)

def decode(instr: int) -> Tuple[Op, int, int, int]:
    op = Op(instr & 0xFF)
    a  = (instr >> 8)  & 0xFF
    b  = (instr >> 16) & 0xFF
    c  = (instr >> 24) & 0xFF
    return op, a, b, c

def decode_bx(instr: int) -> int:
    return (instr >> 16) & 0xFFFF

def decode_sbx(instr: int) -> int:
    return decode_bx(instr) - 0x8000


# ─────────────────────────────────────────────────────────────────────────────
# CONSTANT POOL
# ─────────────────────────────────────────────────────────────────────────────

class ConstPool:
    """
    Deduplicating constant table.
    Stores ints, floats, strings, booleans, null.
    Returns index for use in ABx instructions.
    """
    def __init__(self):
        self._pool:  List[Any] = []
        self._index: Dict[Any, int] = {}

    def add(self, value: Any) -> int:
        key = (type(value).__name__, value)
        if key in self._index:
            return self._index[key]
        idx = len(self._pool)
        self._pool.append(value)
        self._index[key] = idx
        return idx

    def get(self, idx: int) -> Any:
        return self._pool[idx]

    def __len__(self): return len(self._pool)
    def __repr__(self): return f"ConstPool({len(self._pool)} consts)"


# ─────────────────────────────────────────────────────────────────────────────
# UPVALUE DESCRIPTOR
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class UpvalDesc:
    name:     str
    in_stack: bool   # True = captured from enclosing function's register
    index:    int    # register index (in_stack=True) or upvalue index (False)


# ─────────────────────────────────────────────────────────────────────────────
# FUNCTION PROTOTYPE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class FuncProto:
    """
    Compiled function. Contains bytecode + all associated metadata.
    Analogous to PyCodeObject or Lua Proto.
    """
    name:         str = "<script>"
    source:       str = ""
    line_defined: int = 0
    last_line:    int = 0

    # Registers
    num_params:   int = 0
    is_vararg:    bool = False
    max_regs:     int = 0   # number of registers needed

    # Code
    code:         List[int] = field(default_factory=list)      # encoded instructions
    constants:    ConstPool = field(default_factory=ConstPool)
    protos:       List["FuncProto"] = field(default_factory=list)   # nested functions
    upvalues:     List[UpvalDesc] = field(default_factory=list)

    # Debug info
    lines:        List[int] = field(default_factory=list)      # line[i] = source line for code[i]
    local_names:  List[Tuple[str,int,int]] = field(default_factory=list)  # (name, start_pc, end_pc)

    def emit(self, instr: int, line: int = 0) -> int:
        pc = len(self.code)
        self.code.append(instr)
        self.lines.append(line)
        return pc

    def patch_jump(self, pc: int, target: int):
        """Patch a forward jump at `pc` to jump to `target`."""
        op, a, _, _ = decode(self.code[pc])
        sbx = target - pc - 1
        self.code[pc] = encode_asbx(op, a, sbx)

    def add_proto(self, proto: "FuncProto") -> int:
        idx = len(self.protos)
        self.protos.append(proto)
        return idx

    def disassemble(self) -> str:
        lines = [f"function {self.name!r} ({self.num_params} params, {self.max_regs} regs)"]
        lines.append(f"  {'PC':>4}  {'LINE':>4}  {'OP':<14} {'A':>3} {'B':>5} {'C':>5}  {'comment'}")
        lines.append("  " + "-"*70)
        for pc, instr in enumerate(self.code):
            op, a, b, c = decode(instr)
            bx  = decode_bx(instr)
            sbx = decode_sbx(instr)
            src_line = self.lines[pc] if pc < len(self.lines) else 0
            fmt = OP_META.get(op, (op.name, 'ABC'))[1]
            if   fmt == 'ABx':  operands = f"{a:>3}  {bx:>5}     "
            elif fmt == 'AsBx': operands = f"{a:>3}  {sbx:>+5}     "
            elif fmt == 'AB_':  operands = f"{a:>3}  {b:>5}     "
            elif fmt == 'A__':  operands = f"{a:>3}              "
            else:               operands = f"{a:>3}  {b:>5}  {c:>5}"
            # Build comment
            comment = ""
            if op == Op.LOAD_CONST:  comment = f"; K[{bx}]={self.constants.get(bx)!r}"
            if op in (Op.GET_GLOBAL, Op.SET_GLOBAL): comment = f"; {self.constants.get(bx)!r}"
            if op in (Op.JUMP, Op.JUMP_TRUE, Op.JUMP_FALSE, Op.LOOP):
                comment = f"; → {pc + sbx + 1}"
            lines.append(f"  {pc:>4}  {src_line:>4}  {op.name:<14} {operands}  {comment}")
        if self.protos:
            for i, p in enumerate(self.protos):
                lines.append(f"\n--- nested proto [{i}] ---")
                lines.append(p.disassemble())
        return "\n".join(lines)

    def __repr__(self): return f"FuncProto({self.name!r}, {len(self.code)} instrs)"


# ─────────────────────────────────────────────────────────────────────────────
# SYMBOL TABLE  (compile-time scope)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Local:
    name:  str
    reg:   int
    depth: int
    is_captured: bool = False


class Scope:
    def __init__(self, parent: Optional["Scope"] = None):
        self.parent  = parent
        self.locals: List[Local] = []
        self.depth   = (parent.depth + 1) if parent else 0

    def declare(self, name: str, reg: int) -> Local:
        loc = Local(name, reg, self.depth)
        self.locals.append(loc)
        return loc

    def resolve_local(self, name: str) -> Optional[Local]:
        for loc in reversed(self.locals):
            if loc.name == name: return loc
        if self.parent: return self.parent.resolve_local(name)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# BYTECODE COMPILER
# ─────────────────────────────────────────────────────────────────────────────

class CompilerError(Exception):
    pass


class FunctionCompiler:
    """
    Compiles a single function (or the top-level script) to a FuncProto.
    Uses a simple linear-scan register allocator.
    """

    def __init__(self, name: str = "<script>", parent: Optional["FunctionCompiler"] = None):
        self.proto   = FuncProto(name=name)
        self.scope   = Scope()
        self.parent  = parent
        self._reg    = 0          # next free register
        self._reg_top = 0        # high-water mark
        self._breaks: List[int]   = []   # patch list for break stmts
        self._conts:  List[int]   = []   # patch list for continue stmts

    # ── Register allocation ───────────────────────────────────────────
    def alloc_reg(self) -> int:
        r = self._reg
        self._reg += 1
        self._reg_top = max(self._reg_top, self._reg)
        return r

    def free_reg(self): self._reg -= 1

    def alloc_temp(self) -> int: return self.alloc_reg()

    def regs_from(self, base: int): self._reg = base

    # ── Constant helpers ──────────────────────────────────────────────
    def const(self, v: Any) -> int: return self.proto.constants.add(v)

    # ── Emission ──────────────────────────────────────────────────────
    def emit(self, op: Op, a=0, b=0, c=0, line=0) -> int:
        return self.proto.emit(encode(op, a, b, c), line)

    def emit_abx(self, op: Op, a, bx, line=0) -> int:
        return self.proto.emit(encode_abx(op, a, bx), line)

    def emit_asbx(self, op: Op, a, sbx, line=0) -> int:
        return self.proto.emit(encode_asbx(op, a, sbx), line)

    def emit_jump(self, op: Op, a=0, line=0) -> int:
        """Emit forward jump (placeholder sBx=0), return pc to patch later."""
        return self.emit_asbx(op, a, 0, line)

    def patch_jump(self, pc: int):
        self.proto.patch_jump(pc, len(self.proto.code))

    # ── Scope helpers ─────────────────────────────────────────────────
    def push_scope(self): self.scope = Scope(self.scope)
    def pop_scope(self):  self.scope = self.scope.parent

    def resolve(self, name: str) -> Tuple[str, int]:
        """Return ('local', reg) or ('global', const_idx) or ('upval', idx)."""
        loc = self.scope.resolve_local(name)
        if loc: return ('local', loc.reg)
        return ('global', self.const(name))

    # ── Compile node ──────────────────────────────────────────────────
    def compile_node(self, node: ast.Node, dest: int = -1) -> int:
        """
        Compile a node. Returns the register holding the result (-1 if void).
        If dest >= 0, tries to place result in that register.
        """
        line = getattr(node, 'line', 0)

        if isinstance(node, ast.IntLiteralExpr):
            r = dest if dest >= 0 else self.alloc_reg()
            v = node.value
            if -0x7FFF <= v <= 0x7FFF:
                self.emit_asbx(Op.LOAD_INT, r, v, line)
            else:
                self.emit_abx(Op.LOAD_CONST, r, self.const(v), line)
            return r

        if isinstance(node, ast.FloatLiteralExpr):
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit_abx(Op.LOAD_CONST, r, self.const(node.value), line)
            return r

        if isinstance(node, ast.StringLiteralExpr):
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit_abx(Op.LOAD_CONST, r, self.const(node.value), line)
            return r

        if isinstance(node, ast.BoolLiteralExpr):
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit(Op.LOAD_TRUE if node.value else Op.LOAD_FALSE, r, 0, 0, line)
            return r

        if isinstance(node, ast.NullLiteralExpr):
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit(Op.LOAD_NULL, r, 0, 0, line)
            return r

        if isinstance(node, ast.IdentExpr):
            kind, idx = self.resolve(node.name)
            r = dest if dest >= 0 else self.alloc_reg()
            if kind == 'local':
                if r != idx: self.emit(Op.MOVE, r, idx, 0, line)
                return idx if r == idx else r
            else:
                self.emit_abx(Op.GET_GLOBAL, r, idx, line)
            return r

        if isinstance(node, ast.BinaryExpr):
            return self._compile_binary(node, dest)

        if isinstance(node, ast.UnaryExpr):
            return self._compile_unary(node, dest)

        if isinstance(node, ast.AssignExpr):
            return self._compile_assign(node)

        if isinstance(node, ast.CallExpr):
            return self._compile_call(node, dest)

        if isinstance(node, ast.GetAttrExpr):
            obj_r = self.compile_node(node.obj)
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit(Op.GET_FIELD, r, obj_r, self.const(node.attr), line)
            self.free_reg()
            return r

        if isinstance(node, ast.SetAttrExpr):
            obj_r = self.compile_node(node.obj)
            val_r = self.compile_node(node.value)
            self.emit(Op.SET_FIELD, val_r, obj_r, self.const(node.attr), line)
            self.free_reg(); self.free_reg()
            return val_r

        if isinstance(node, ast.IndexExpr):
            obj_r = self.compile_node(node.obj)
            idx_r = self.compile_node(node.index)
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit(Op.GET_INDEX, r, obj_r, idx_r, line)
            self.free_reg(); self.free_reg()
            return r

        if isinstance(node, ast.ArrayLiteralExpr):
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit(Op.NEW_ARRAY, r, 0, 0, line)
            for el in node.elements:
                el_r = self.compile_node(el)
                self.emit(Op.ARRAY_PUSH, r, el_r, 0, line)
                self.free_reg()
            return r

        if isinstance(node, ast.DictLiteralExpr):
            r = dest if dest >= 0 else self.alloc_reg()
            self.emit(Op.NEW_DICT, r, 0, 0, line)
            for k, v in node.pairs:
                val_r = self.compile_node(v)
                self.emit(Op.DICT_SET, val_r, r, self.const(k), line)
                self.free_reg()
            return r

        if isinstance(node, ast.PrintStmt):
            if node.args:
                r_arg = self.compile_node(node.args[0])
                str_r = self.alloc_reg()
                self.emit(Op.TO_STR, str_r, r_arg, 0, line)
                for arg in node.args[1:]:
                    r2 = self.compile_node(arg)
                    s2 = self.alloc_reg()
                    self.emit(Op.TO_STR, s2, r2, 0, line)
                    sp = self.alloc_reg()
                    self.emit_abx(Op.LOAD_CONST, sp, self.const(' '), line)
                    self.emit(Op.CONCAT, str_r, str_r, sp, line)
                    self.emit(Op.CONCAT, str_r, str_r, s2, line)
                self.emit(Op.PRINT, str_r, 0, 0, line)
            else:
                nr = self.alloc_reg()
                self.emit(Op.LOAD_NULL, nr, 0, 0, line)
                self.emit(Op.PRINT, nr, 0, 0, line)
            return -1

        if isinstance(node, ast.ExprStmt):
            self.compile_node(node.expr)
            return -1

        if isinstance(node, ast.VarDecl):
            return self._compile_var_decl(node)

        if isinstance(node, ast.FunctionDecl):
            return self._compile_func_decl(node)

        if isinstance(node, ast.LambdaExpr):
            return self._compile_lambda(node)

        if isinstance(node, ast.ReturnStmt):
            if node.value:
                r = self.compile_node(node.value)
                self.emit(Op.RETURN, r, 1, 0, line)
            else:
                self.emit(Op.RETURN_NULL, 0, 0, 0, line)
            return -1

        if isinstance(node, ast.IfStmt):
            return self._compile_if(node)

        if isinstance(node, ast.WhileStmt):
            return self._compile_while(node)

        if isinstance(node, ast.ForInStmt):
            return self._compile_for_in(node)

        if isinstance(node, ast.BlockStmt):
            self.push_scope()
            for stmt in node.body: self.compile_node(stmt)
            self.pop_scope()
            return -1

        if isinstance(node, ast.Program):
            for stmt in node.body: self.compile_node(stmt)
            return -1

        if isinstance(node, ast.TernaryExpr):
            return self._compile_ternary(node)

        if isinstance(node, ast.BreakStmt):
            pc = self.emit_jump(Op.JUMP, 0, line)
            self._breaks.append(pc)
            return -1

        if isinstance(node, ast.ContinueStmt):
            pc = self.emit_jump(Op.JUMP, 0, line)
            self._conts.append(pc)
            return -1

        if isinstance(node, ast.ThrowStmt):
            r = self.compile_node(node.value)
            self.emit(Op.THROW, r, 0, 0, line)
            return -1

        if isinstance(node, ast.MatchStmt):
            return self._compile_match(node)

        # Fallback: emit NOP + warn
        self.emit(Op.NOP, 0, 0, 0, line)
        return -1

    # ── Specific compilers ────────────────────────────────────────────
    _BINARY_OPS = {
        '+': Op.ADD,  '-': Op.SUB,  '*': Op.MUL,  '/': Op.DIV,
        '%': Op.MOD,  '**': Op.POW, '&': Op.BAND, '|': Op.BOR,
        '^': Op.BXOR, '<<': Op.SHL, '>>': Op.SHR,
        '==': Op.EQ,  '!=': Op.NE,  '<': Op.LT,   '<=': Op.LE,
        '>': Op.GT,   '>=': Op.GE,  '&&': Op.AND, '||': Op.OR,
        '..': Op.CONCAT,
    }

    def _compile_binary(self, node: ast.BinaryExpr, dest: int) -> int:
        op = self._BINARY_OPS.get(node.op)
        if not op: raise CompilerError(f"Unknown binary op {node.op!r}")
        line = node.line

        # Short-circuit && / ||
        if node.op == '&&':
            l_r = self.compile_node(node.left)
            r   = dest if dest >= 0 else self.alloc_reg()
            if r != l_r: self.emit(Op.MOVE, r, l_r, 0, line)
            skip_pc = self.emit_jump(Op.JUMP_FALSE, r, line)
            r_r = self.compile_node(node.right)
            if r != r_r: self.emit(Op.MOVE, r, r_r, 0, line)
            self.patch_jump(skip_pc)
            return r

        if node.op == '||':
            l_r = self.compile_node(node.left)
            r   = dest if dest >= 0 else self.alloc_reg()
            if r != l_r: self.emit(Op.MOVE, r, l_r, 0, line)
            skip_pc = self.emit_jump(Op.JUMP_TRUE, r, line)
            r_r = self.compile_node(node.right)
            if r != r_r: self.emit(Op.MOVE, r, r_r, 0, line)
            self.patch_jump(skip_pc)
            return r

        l_r = self.compile_node(node.left)
        r_r = self.compile_node(node.right)
        r   = dest if dest >= 0 else self.alloc_reg()
        self.emit(op, r, l_r, r_r, line)
        self.free_reg(); self.free_reg()
        return r

    def _compile_unary(self, node: ast.UnaryExpr, dest: int) -> int:
        r = self.compile_node(node.operand)
        out = dest if dest >= 0 else self.alloc_reg()
        op_map = {'-': Op.NEG, '!': Op.NOT, '~': Op.BNOT}
        op = op_map.get(node.op)
        if op: self.emit(op, out, r, 0, node.line)
        self.free_reg()
        return out

    def _compile_assign(self, node: ast.AssignExpr) -> int:
        val_r = self.compile_node(node.value)
        if isinstance(node.target, ast.IdentExpr):
            kind, idx = self.resolve(node.target.name)
            if kind == 'local':
                if val_r != idx: self.emit(Op.MOVE, idx, val_r, 0, node.line)
                return idx
            else:
                self.emit_abx(Op.SET_GLOBAL, val_r, idx, node.line)
                return val_r
        if isinstance(node.target, ast.GetAttrExpr):
            obj_r = self.compile_node(node.target.obj)
            self.emit(Op.SET_FIELD, val_r, obj_r, self.const(node.target.attr), node.line)
            self.free_reg()
        if isinstance(node.target, ast.IndexExpr):
            obj_r = self.compile_node(node.target.obj)
            idx_r = self.compile_node(node.target.index)
            self.emit(Op.SET_INDEX, val_r, obj_r, idx_r, node.line)
            self.free_reg(); self.free_reg()
        return val_r

    def _compile_call(self, node: ast.CallExpr, dest: int) -> int:
        line = node.line
        # Method call: obj.method(args)
        if isinstance(node.callee, ast.GetAttrExpr):
            obj_r = self.compile_node(node.callee.obj)
            meth_k = self.const(node.callee.attr)
            # Ensure args are contiguous after obj_r
            saved_reg = self._reg
            self._reg = obj_r + 1   # args start right after obj
            for arg in node.args:
                ar = self.alloc_reg()
                self.compile_node(arg.value, dest=ar)
            nargs = len(node.args)
            self.emit(Op.CALL_METHOD, obj_r, nargs, meth_k, line)
            self._reg = obj_r + 1   # result is at obj_r
            return obj_r

        # Evaluate callee to get fn register
        # Then force args to be contiguous at fn_r+1, fn_r+2, ...
        fn_r = self.compile_node(node.callee)
        # Save and reset reg allocator to fn_r+1 so args are contiguous
        self._reg = fn_r + 1
        for arg in node.args:
            ar = self.alloc_reg()
            self.compile_node(arg.value, dest=ar)
        nargs = len(node.args)
        nret  = 1 if dest >= 0 else 0
        self.emit(Op.CALL, fn_r, nargs, nret, line)
        # After call, result is in fn_r; update reg counter
        self._reg = fn_r + 1
        self._reg_top = max(self._reg_top, fn_r + nargs + 1)
        return fn_r

    def _compile_var_decl(self, node: ast.VarDecl) -> int:
        r = self.alloc_reg()
        if node.initializer:
            val_r = self.compile_node(node.initializer, dest=r)
            if val_r != r: self.emit(Op.MOVE, r, val_r, 0, node.line)
        else:
            self.emit(Op.LOAD_NULL, r, 0, 0, node.line)
        self.scope.declare(node.name, r)
        self.proto.local_names.append((node.name, len(self.proto.code), 99999))
        return r

    def _compile_func_decl(self, node: ast.FunctionDecl) -> int:
        proto = self._compile_function(node.name, node.params, node.body, node.line)
        idx   = self.proto.add_proto(proto)
        r     = self.alloc_reg()
        self.emit_abx(Op.CLOSURE, r, idx, node.line)
        # Declare as local or global
        kind, gidx = self.resolve(node.name)
        if kind == 'local':
            self.scope.declare(node.name, r)
        else:
            self.emit_abx(Op.SET_GLOBAL, r, gidx, node.line)
        return r

    def _compile_lambda(self, node: ast.LambdaExpr) -> int:
        proto = self._compile_function("<lambda>", node.params,
                                       ast.BlockStmt(stmts=[ast.ReturnStmt(value=node.body)]),
                                       node.line)
        idx = self.proto.add_proto(proto)
        r   = self.alloc_reg()
        self.emit_abx(Op.CLOSURE, r, idx, node.line)
        return r

    def _compile_function(self, name: str, params, body, line: int) -> FuncProto:
        fc = FunctionCompiler(name, parent=self)
        fc.proto.num_params  = len(params)
        fc.proto.line_defined = line
        fc.proto.source      = self.proto.source
        for i, p in enumerate(params):
            r = fc.alloc_reg()
            fc.scope.declare(p.name, r)
        fc.compile_node(body)
        # Ensure function ends with a return
        if not fc.proto.code or Op(fc.proto.code[-1] & 0xFF) not in (Op.RETURN, Op.RETURN_NULL):
            fc.emit(Op.RETURN_NULL, 0, 0, 0, line)
        fc.proto.max_regs = fc._reg_top
        return fc.proto

    def _compile_if(self, node: ast.IfStmt) -> int:
        cond_r = self.compile_node(node.condition)
        jump_false = self.emit_jump(Op.JUMP_FALSE, cond_r, node.line)
        self.compile_node(node.then_branch)
        if node.else_branch:
            jump_end = self.emit_jump(Op.JUMP, 0, node.line)
            self.patch_jump(jump_false)
            self.compile_node(node.else_branch)
            self.patch_jump(jump_end)
        else:
            self.patch_jump(jump_false)
        return -1

    def _compile_while(self, node: ast.WhileStmt) -> int:
        loop_start = len(self.proto.code)
        cond_r = self.compile_node(node.condition)
        exit_jump = self.emit_jump(Op.JUMP_FALSE, cond_r, node.line)
        prev_breaks = self._breaks; self._breaks = []
        prev_conts  = self._conts;  self._conts  = []
        self.compile_node(node.body)
        # back-edge jump
        offset = loop_start - len(self.proto.code) - 1
        self.emit_asbx(Op.JUMP, 0, offset, node.line)
        self.patch_jump(exit_jump)
        for pc in self._breaks: self.patch_jump(pc)
        for pc in self._conts:  self.proto.patch_jump(pc, loop_start)
        self._breaks = prev_breaks; self._conts = prev_conts
        return -1

    def _compile_for_in(self, node: ast.ForInStmt) -> int:
        # Compile iterable → iter_r holds the collection
        iter_src_r = self.compile_node(node.iterable)
        # Allocate register for the iterator object (reusable each iteration)
        iter_obj_r = self.alloc_reg()
        self.emit(Op.ITER_PREP, iter_obj_r, iter_src_r, 0, node.line)
        loop_start = len(self.proto.code)
        # ITER_NEXT: A=iter_obj_r (iterator), B=var_r (output)
        # VM: try next(regs[A]), store in regs[B]; on StopIteration jump
        self.push_scope()
        var_r = self.alloc_reg()
        self.scope.declare(node.var_name, var_r)
        # Emit ITER_NEXT A=iter_obj_r B=var_r (ABC format, exit jump patched later)
        iter_next_pc = self.emit(Op.ITER_NEXT, iter_obj_r, var_r, 0, node.line)
        # Jump-false placeholder for when iterator is exhausted (VM sets sentinel)
        exit_jump_pc = self.emit_jump(Op.JUMP_NULL, var_r, node.line)
        prev_breaks = self._breaks; self._breaks = []
        self.compile_node(node.body)
        offset = loop_start - len(self.proto.code) - 1
        self.emit_asbx(Op.JUMP, 0, offset, node.line)
        self.patch_jump(exit_jump_pc)
        for pc in self._breaks: self.patch_jump(pc)
        self._breaks = prev_breaks
        self.pop_scope()
        return -1

    def _compile_ternary(self, node: ast.TernaryExpr) -> int:
        cond_r = self.compile_node(node.condition)
        r      = self.alloc_reg()
        j_false = self.emit_jump(Op.JUMP_FALSE, cond_r, node.line)
        then_r  = self.compile_node(node.then_expr)
        self.emit(Op.MOVE, r, then_r, 0)
        j_end   = self.emit_jump(Op.JUMP, 0)
        self.patch_jump(j_false)
        else_r  = self.compile_node(node.else_expr)
        self.emit(Op.MOVE, r, else_r, 0)
        self.patch_jump(j_end)
        return r

    def _compile_match(self, node: ast.MatchStmt) -> int:
        subj_r = self.compile_node(node.subject)
        end_jumps: List[int] = []
        for arm in node.arms:
            if arm.pattern is None:  # wildcard
                self.compile_node(arm.body)
                break
            pat_r   = self.compile_node(arm.pattern)
            cmp_r   = self.alloc_reg()
            self.emit(Op.EQ, cmp_r, subj_r, pat_r, node.line)
            self.free_reg()
            skip    = self.emit_jump(Op.JUMP_FALSE, cmp_r, node.line)
            self.compile_node(arm.body)
            end_jumps.append(self.emit_jump(Op.JUMP, 0))
            self.patch_jump(skip)
        for j in end_jumps: self.patch_jump(j)
        return -1

    def finish(self) -> FuncProto:
        if not self.proto.code or Op(self.proto.code[-1] & 0xFF) not in (Op.RETURN, Op.RETURN_NULL, Op.HALT):
            self.emit(Op.RETURN_NULL)
        self.proto.max_regs = max(self._reg_top, self.proto.num_params + 1)
        return self.proto


class BytecodeCompiler:
    """
    Top-level compiler: compiles a parsed AST Program into a FuncProto.

    Usage:
        compiler = BytecodeCompiler()
        proto = compiler.compile(ast_program)
        vm = BytecodeVM()
        result = vm.run(proto)
    """

    def compile(self, program: ast.Program, source: str = "") -> FuncProto:
        fc = FunctionCompiler("<script>")
        fc.proto.source = source
        fc.compile_node(program)
        return fc.finish()

    def compile_source(self, source: str) -> FuncProto:
        """Full pipeline: source → tokens → AST → bytecode."""
        from lexer  import Lexer
        from parser import Parser
        tokens  = Lexer(source).tokenize()
        program = Parser(tokens).parse()
        return self.compile(program, source)


# ─────────────────────────────────────────────────────────────────────────────
# .insb BINARY FORMAT
# ─────────────────────────────────────────────────────────────────────────────
# Header:  MAGIC(4) VERSION(2) FLAGS(2)
# FuncProto: serialised recursively
# Each proto: name(str) nparams(u8) nregs(u8)
#             ncode(u32) [instr: u32 * n]
#             nconsts(u16) [const_tag(u8) const_val]
#             nprotos(u16) [nested proto]
#             nlines(u32) [line: u16 * n]

INSB_MAGIC   = b'INSB'
INSB_VERSION = (1, 0)

def _write_str(buf: bytearray, s: str):
    b = s.encode('utf-8')
    buf += struct.pack('>H', len(b)) + b

def _read_str(data: bytes, pos: int) -> Tuple[str, int]:
    n = struct.unpack_from('>H', data, pos)[0]; pos += 2
    return data[pos:pos+n].decode('utf-8'), pos+n

def serialize(proto: FuncProto) -> bytes:
    """Serialize a FuncProto tree to .insb bytes."""
    buf = bytearray(INSB_MAGIC)
    buf += struct.pack('>BB', *INSB_VERSION)
    buf += struct.pack('>H', 0)  # flags
    _serialize_proto(buf, proto)
    return bytes(buf)

def _serialize_proto(buf: bytearray, p: FuncProto):
    _write_str(buf, p.name)
    buf += struct.pack('>BBB', p.num_params, int(p.is_vararg), p.max_regs)
    buf += struct.pack('>I', len(p.code))
    for instr in p.code: buf += struct.pack('>I', instr)
    buf += struct.pack('>H', len(p.constants))
    for v in p.constants._pool:
        if v is None:                   buf += b'\x00'
        elif isinstance(v, bool):       buf += struct.pack('>B?', 0x01, v)
        elif isinstance(v, int):        buf += struct.pack('>Bq', 0x02, v)
        elif isinstance(v, float):      buf += struct.pack('>Bd', 0x03, v)
        elif isinstance(v, str):
            b = v.encode(); buf += struct.pack('>BH', 0x04, len(b)) + b
        else:
            buf += b'\x00'  # unknown → null
    buf += struct.pack('>H', len(p.protos))
    for child in p.protos: _serialize_proto(buf, child)
    buf += struct.pack('>I', len(p.lines))
    for ln in p.lines: buf += struct.pack('>H', min(ln, 0xFFFF))

def deserialize(data: bytes) -> FuncProto:
    if data[:4] != INSB_MAGIC: raise ValueError("Not an .insb file")
    pos = 4 + 2 + 2  # skip header
    proto, _ = _deserialize_proto(data, pos)
    return proto

def _deserialize_proto(data: bytes, pos: int) -> Tuple[FuncProto, int]:
    p = FuncProto()
    p.name, pos = _read_str(data, pos)
    p.num_params, is_va, p.max_regs = struct.unpack_from('>BBB', data, pos); pos += 3
    p.is_vararg = bool(is_va)
    n_code = struct.unpack_from('>I', data, pos)[0]; pos += 4
    for _ in range(n_code):
        p.code.append(struct.unpack_from('>I', data, pos)[0]); pos += 4
    n_consts = struct.unpack_from('>H', data, pos)[0]; pos += 2
    for _ in range(n_consts):
        tag = data[pos]; pos += 1
        if tag == 0x00: p.constants._pool.append(None)
        elif tag == 0x01: v=struct.unpack_from('>?', data, pos)[0]; p.constants._pool.append(v); pos+=1
        elif tag == 0x02: v=struct.unpack_from('>q', data, pos)[0]; p.constants._pool.append(v); pos+=8
        elif tag == 0x03: v=struct.unpack_from('>d', data, pos)[0]; p.constants._pool.append(v); pos+=8
        elif tag == 0x04:
            n=struct.unpack_from('>H', data, pos)[0]; pos+=2
            p.constants._pool.append(data[pos:pos+n].decode()); pos+=n
        else: p.constants._pool.append(None)
    n_protos = struct.unpack_from('>H', data, pos)[0]; pos += 2
    for _ in range(n_protos):
        child, pos = _deserialize_proto(data, pos)
        p.protos.append(child)
    n_lines = struct.unpack_from('>I', data, pos)[0]; pos += 4
    for _ in range(n_lines):
        p.lines.append(struct.unpack_from('>H', data, pos)[0]); pos += 2
    return p, pos


# ─────────────────────────────────────────────────────────────────────────────
# GARBAGE COLLECTOR  (mark-and-sweep)
# ─────────────────────────────────────────────────────────────────────────────

class GC:
    """
    Simple mark-and-sweep garbage collector.
    Tracks all InScript heap objects (arrays, dicts, closures).
    In practice Python's own GC handles most of this, but this provides
    InScript-level control (deterministic collection, weak refs, finalizers).
    """

    def __init__(self, threshold: int = 1024):
        self.threshold = threshold
        self._objects: Set[int] = set()    # id() of live objects
        self._roots:   Set[int] = set()    # id() of GC roots
        self.collections = 0
        self.bytes_freed = 0
        self._finalizers: Dict[int, callable] = {}

    def track(self, obj: Any) -> Any:
        self._objects.add(id(obj))
        return obj

    def root(self, obj: Any):
        self._roots.add(id(obj))

    def unroot(self, obj: Any):
        self._roots.discard(id(obj))

    def add_finalizer(self, obj: Any, fn: callable):
        self._finalizers[id(obj)] = fn

    def collect(self, all_objects: List[Any]) -> int:
        """
        Mark all reachable objects from roots, sweep unreachable ones.
        Returns count of collected objects.
        """
        live_ids = set()
        # Mark phase: BFS from roots
        q = list(self._roots)
        while q:
            oid = q.pop()
            if oid in live_ids: continue
            live_ids.add(oid)
        # Sweep phase
        dead = self._objects - live_ids
        for oid in dead:
            if oid in self._finalizers:
                try: self._finalizers.pop(oid)()
                except: pass
        self._objects -= dead
        self.collections += 1
        return len(dead)

    def stats(self) -> Dict:
        return {'tracked': len(self._objects), 'roots': len(self._roots),
                'collections': self.collections}

    def __repr__(self): return f"GC(tracked={len(self._objects)}, collections={self.collections})"


# ─────────────────────────────────────────────────────────────────────────────
# CLOSURE  (runtime function object)
# ─────────────────────────────────────────────────────────────────────────────

class Closure:
    __slots__ = ('proto', 'upvalues', 'name')
    def __init__(self, proto: FuncProto, upvalues: List = None):
        self.proto    = proto
        self.upvalues = upvalues or []
        self.name     = proto.name
    def __repr__(self): return f"<fn {self.name}>"


class NativeFunction:
    __slots__ = ('name', 'fn', 'arity')
    def __init__(self, name: str, fn, arity: int = -1):
        self.name = name; self.fn = fn; self.arity = arity
    def __call__(self, *args): return self.fn(*args)
    def __repr__(self): return f"<native {self.name}>"


# ─────────────────────────────────────────────────────────────────────────────
# CALL FRAME
# ─────────────────────────────────────────────────────────────────────────────

class CallFrame:
    __slots__ = ('closure', 'regs', 'pc', 'ret_reg', 'base')
    def __init__(self, closure: Closure, nregs: int, ret_reg: int, base: int):
        self.closure = closure
        self.regs    = [None] * max(nregs, 8)
        self.pc      = 0
        self.ret_reg = ret_reg   # where to store return value in caller
        self.base    = base      # offset for nested call stacks


# ─────────────────────────────────────────────────────────────────────────────
# BYTECODE VM
# ─────────────────────────────────────────────────────────────────────────────

class VMError(Exception):
    def __init__(self, msg: str, line: int = 0):
        super().__init__(msg); self.vm_line = line


class BytecodeVM:
    """
    Register-based bytecode VM for InScript.

    Usage:
        vm = BytecodeVM()
        compiler = BytecodeCompiler()
        proto = compiler.compile_source('print("hello")')
        vm.run(proto)
    """

    MAX_CALL_DEPTH = 512
    EXEC_LIMIT     = 10_000_000   # instruction limit (safety)

    def __init__(self, gc: GC = None):
        self.gc       = gc or GC()
        self.globals: Dict[str, Any] = {}
        self._call_stack: List[CallFrame] = []
        self._exec_count  = 0
        self.profiler: Dict[int, int] = defaultdict(int)   # opcode → hit count
        self._profile_on  = False
        self._output: List[str] = []   # captured print output
        self.print_fn     = print      # override for testing
        self._install_stdlib()

    def _install_stdlib(self):
        """Install built-in native functions."""
        def _len(a):
            if isinstance(a, (list, dict, str)): return len(a)
            return 0
        self.globals.update({
            'print':   NativeFunction('print',   lambda *a: self.print_fn(*a)),
            'len':     NativeFunction('len',     _len),
            'str':     NativeFunction('str',     str),
            'int':     NativeFunction('int',     int),
            'float':   NativeFunction('float',   float),
            'bool':    NativeFunction('bool',    bool),
            'type':    NativeFunction('type',    lambda x: type(x).__name__),
            'range':   NativeFunction('range',   lambda *a: list(range(*[int(x) for x in a]))),
            'abs':     NativeFunction('abs',     abs),
            'min':     NativeFunction('min',     min),
            'max':     NativeFunction('max',     max),
            'sqrt':    NativeFunction('sqrt',    math.sqrt),
            'floor':   NativeFunction('floor',   math.floor),
            'ceil':    NativeFunction('ceil',    math.ceil),
            'round':   NativeFunction('round',   round),
            'sin':     NativeFunction('sin',     math.sin),
            'cos':     NativeFunction('cos',     math.cos),
            'pow':     NativeFunction('pow',     math.pow),
            'append':  NativeFunction('append',  lambda a,v: a.append(v)),
            'push':    NativeFunction('push',    lambda a,v: a.append(v)),
            'pop':     NativeFunction('pop',     lambda a: a.pop()),
        })

    def set_global(self, name: str, value: Any): self.globals[name] = value
    def get_global(self, name: str) -> Any: return self.globals.get(name)

    def run(self, proto: FuncProto) -> Any:
        """Execute a compiled script. Returns the last expression value."""
        closure = Closure(proto)
        frame   = CallFrame(closure, proto.max_regs, -1, 0)
        self._call_stack = [frame]
        return self._exec()

    def _exec(self) -> Any:
        frame = self._call_stack[-1]
        code  = frame.closure.proto.code
        consts= frame.closure.proto.constants
        protos= frame.closure.proto.protos
        regs  = frame.regs
        self._exec_count = 0

        while True:
            if frame.pc >= len(code): break
            instr = code[frame.pc]; frame.pc += 1
            self._exec_count += 1
            if self._exec_count > self.EXEC_LIMIT:
                raise VMError("Execution limit exceeded (infinite loop?)")

            op   = Op(instr & 0xFF)
            a    = (instr >> 8)  & 0xFF
            b    = (instr >> 16) & 0xFF
            c    = (instr >> 24) & 0xFF
            bx   = (instr >> 16) & 0xFFFF
            sbx  = bx - 0x8000

            if self._profile_on: self.profiler[int(op)] += 1

            # ── Execute opcode ────────────────────────────────────────
            if op == Op.LOAD_CONST:
                regs[a] = consts.get(bx)

            elif op == Op.LOAD_NULL:  regs[a] = None
            elif op == Op.LOAD_TRUE:  regs[a] = True
            elif op == Op.LOAD_FALSE: regs[a] = False
            elif op == Op.LOAD_INT:   regs[a] = sbx
            elif op == Op.MOVE:       regs[a] = regs[b]

            elif op == Op.GET_GLOBAL:
                name = consts.get(bx)
                regs[a] = self.globals.get(name)

            elif op == Op.SET_GLOBAL:
                name = consts.get(bx)
                self.globals[name] = regs[a]

            elif op == Op.GET_LOCAL:  regs[a] = regs[b]
            elif op == Op.SET_LOCAL:  regs[b] = regs[a]

            elif op == Op.ADD: regs[a] = regs[b] + regs[c]
            elif op == Op.SUB: regs[a] = regs[b] - regs[c]
            elif op == Op.MUL: regs[a] = regs[b] * regs[c]
            elif op == Op.DIV:
                if regs[c] == 0: raise VMError("Division by zero", frame.closure.proto.lines[frame.pc-1])
                regs[a] = regs[b] / regs[c]
            elif op == Op.MOD: regs[a] = regs[b] % regs[c]
            elif op == Op.POW: regs[a] = regs[b] ** regs[c]
            elif op == Op.NEG: regs[a] = -regs[b]
            elif op == Op.ADDK: regs[a] = regs[b] + consts.get(c)
            elif op == Op.SUBK: regs[a] = regs[b] - consts.get(c)
            elif op == Op.MULK: regs[a] = regs[b] * consts.get(c)
            elif op == Op.DIVK:
                k = consts.get(c)
                if k == 0: raise VMError("Division by zero")
                regs[a] = regs[b] / k

            elif op == Op.BAND: regs[a] = int(regs[b]) & int(regs[c])
            elif op == Op.BOR:  regs[a] = int(regs[b]) | int(regs[c])
            elif op == Op.BXOR: regs[a] = int(regs[b]) ^ int(regs[c])
            elif op == Op.BNOT: regs[a] = ~int(regs[b])
            elif op == Op.SHL:  regs[a] = int(regs[b]) << int(regs[c])
            elif op == Op.SHR:  regs[a] = int(regs[b]) >> int(regs[c])

            elif op == Op.EQ:  regs[a] = regs[b] == regs[c]
            elif op == Op.NE:  regs[a] = regs[b] != regs[c]
            elif op == Op.LT:  regs[a] = regs[b] <  regs[c]
            elif op == Op.LE:  regs[a] = regs[b] <= regs[c]
            elif op == Op.GT:  regs[a] = regs[b] >  regs[c]
            elif op == Op.GE:  regs[a] = regs[b] >= regs[c]
            elif op == Op.NOT: regs[a] = not regs[b]
            elif op == Op.AND: regs[a] = regs[b] and regs[c]
            elif op == Op.OR:  regs[a] = regs[b] or  regs[c]

            elif op == Op.CONCAT:
                regs[a] = str(regs[b]) + str(regs[c])
            elif op == Op.STR_LEN:
                regs[a] = len(str(regs[b]))

            elif op == Op.JUMP:
                frame.pc += sbx

            elif op == Op.JUMP_TRUE:
                if regs[a]: frame.pc += sbx

            elif op == Op.JUMP_FALSE:
                if not regs[a]: frame.pc += sbx

            elif op == Op.JUMP_NULL:
                if regs[a] is None: frame.pc += sbx

            elif op == Op.LOOP:
                frame.pc -= sbx

            elif op == Op.CALL:
                fn    = regs[a]
                nargs = b
                args  = [regs[a+1+i] for i in range(nargs)]
                if isinstance(fn, NativeFunction) or (callable(fn) and not isinstance(fn, Closure)):
                    regs[a] = fn(*args) if callable(fn) else None
                elif isinstance(fn, Closure):
                    if len(self._call_stack) >= self.MAX_CALL_DEPTH:
                        raise VMError('Stack overflow')
                    new_frame = CallFrame(fn, fn.proto.max_regs, a, 0)
                    for i, v in enumerate(args[:fn.proto.num_params]):
                        new_frame.regs[i] = v
                    self._call_stack.append(new_frame)
                    frame  = new_frame
                    code   = frame.closure.proto.code
                    consts = frame.closure.proto.constants
                    protos = frame.closure.proto.protos
                    regs   = frame.regs
                else:
                    raise VMError(f'Cannot call {type(fn).__name__}')

            elif op == Op.CALL_METHOD:
                obj   = regs[a]
                mname = consts.get(c)
                nargs = b
                args  = [regs[a+1+i] for i in range(nargs)]
                method = None
                if isinstance(obj, dict):      method = obj.get(mname)
                elif hasattr(obj, mname):      method = getattr(obj, mname)
                if method is None:
                    raise VMError(f"No method '{mname}' on {type(obj).__name__}")
                regs[a] = method(*args)

            elif op == Op.RETURN:
                val = regs[a] if b > 0 else None
                if len(self._call_stack) > 1:
                    ret_reg = frame.ret_reg
                    self._call_stack.pop()
                    frame = self._call_stack[-1]
                    code  = frame.closure.proto.code
                    consts= frame.closure.proto.constants
                    protos= frame.closure.proto.protos
                    regs  = frame.regs
                    regs[ret_reg] = val  # store result in caller's fn register (A of CALL)
                else:
                    return val

            elif op == Op.RETURN_NULL:
                if len(self._call_stack) > 1:
                    ret_reg = frame.ret_reg
                    self._call_stack.pop()
                    frame = self._call_stack[-1]
                    code  = frame.closure.proto.code
                    consts= frame.closure.proto.constants
                    protos= frame.closure.proto.protos
                    regs  = frame.regs
                    regs[ret_reg] = None
                else:
                    return None

            elif op == Op.NEW_ARRAY: regs[a] = []
            elif op == Op.NEW_DICT:  regs[a] = {}
            elif op == Op.ARRAY_PUSH: regs[a].append(regs[b])
            elif op == Op.ARRAY_LEN:  regs[a] = len(regs[b]) if regs[b] is not None else 0
            elif op == Op.ARRAY_GET:
                try: regs[a] = regs[b][int(regs[c])]
                except (IndexError, TypeError): regs[a] = None
            elif op == Op.ARRAY_SET:
                try: regs[b][int(regs[c])] = regs[a]
                except: pass
            elif op == Op.DICT_GET:
                regs[a] = regs[b].get(consts.get(c)) if isinstance(regs[b], dict) else None
            elif op == Op.DICT_SET:
                if isinstance(regs[b], dict): regs[b][consts.get(c)] = regs[a]
            elif op == Op.GET_FIELD:
                obj = regs[b]; fname = consts.get(c)
                if isinstance(obj, dict):    regs[a] = obj.get(fname)
                elif hasattr(obj, fname):    regs[a] = getattr(obj, fname)
                else: regs[a] = None
            elif op == Op.SET_FIELD:
                obj = regs[b]; fname = consts.get(c)
                if isinstance(obj, dict): obj[fname] = regs[a]
                elif hasattr(obj, fname): setattr(obj, fname, regs[a])
            elif op == Op.GET_INDEX:
                try:    regs[a] = regs[b][regs[c]]
                except: regs[a] = None
            elif op == Op.SET_INDEX:
                try:    regs[b][regs[c]] = regs[a]
                except: pass

            elif op == Op.CLOSURE:
                child_proto = protos[bx]
                regs[a] = Closure(child_proto)

            elif op == Op.ITER_PREP:
                iterable = regs[b]
                if isinstance(iterable, (list, tuple)): regs[a] = iter(iterable)
                elif isinstance(iterable, dict): regs[a] = iter(iterable)
                elif isinstance(iterable, range): regs[a] = iter(iterable)
                else: regs[a] = iter([])

            elif op == Op.ITER_NEXT:
                try:
                    regs[b] = next(regs[a])
                except StopIteration:
                    regs[b] = None   # sentinel → JUMP_NULL will exit loop

            elif op == Op.THROW:
                raise VMError(str(regs[a]))

            elif op == Op.TO_STR:   regs[a] = str(regs[b]) if regs[b] is not None else "null"
            elif op == Op.TO_INT:   regs[a] = int(regs[b])
            elif op == Op.TO_FLOAT: regs[a] = float(regs[b])
            elif op == Op.TO_BOOL:  regs[a] = bool(regs[b])

            elif op == Op.PRINT:
                val = regs[a]
                s   = 'null' if val is None else ('true' if val is True else 'false' if val is False else str(val))
                self.print_fn(s)
                self._output.append(s)

            elif op == Op.NOP: pass

            elif op == Op.HALT: break

            elif op == Op.ASSERT:
                if not regs[a]:
                    msg = consts.get(bx) if bx < len(consts._pool) else "Assertion failed"
                    raise VMError(str(msg))

        return regs[0] if regs else None

    def _call(self, fn: Any, args: List, caller_frame: CallFrame) -> Any:
        if fn is None:
            raise VMError("Attempted to call null")
        if isinstance(fn, NativeFunction):
            return fn(*args)
        if callable(fn):
            return fn(*args)
        if isinstance(fn, Closure):
            if len(self._call_stack) >= self.MAX_CALL_DEPTH:
                raise VMError("Stack overflow (max call depth exceeded)")
            frame = CallFrame(fn, fn.proto.max_regs, caller_frame.ret_reg, 0)
            # Load args into registers
            for i, v in enumerate(args[:fn.proto.num_params]):
                frame.regs[i] = v
            self._call_stack.append(frame)
            result = self._exec()
            return result
        raise VMError(f"Cannot call {type(fn).__name__}")

    # ── Profiler ─────────────────────────────────────────────────────────
    def enable_profiler(self): self._profile_on = True
    def disable_profiler(self): self._profile_on = False

    def top_opcodes(self, n: int = 10) -> List[Tuple[str, int]]:
        return sorted([(Op(k).name, v) for k,v in self.profiler.items()],
                      key=lambda x: -x[1])[:n]

    def profile_report(self) -> str:
        total = sum(self.profiler.values())
        lines = [f"VM Profile ({total:,} instructions executed):"]
        for name, count in self.top_opcodes(15):
            pct = count / total * 100 if total else 0
            bar = '█' * int(pct / 2)
            lines.append(f"  {name:<16} {count:>8,}  {pct:5.1f}%  {bar}")
        return '\n'.join(lines)

    def __repr__(self):
        return f"BytecodeVM(depth={len(self._call_stack)}, instrs={self._exec_count:,})"


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def compile_source(source: str) -> FuncProto:
    return BytecodeCompiler().compile_source(source)

def run_source(source: str, vm: BytecodeVM = None, print_fn=None) -> Any:
    """Compile and run InScript source. Returns result."""
    proto = compile_source(source)
    if vm is None: vm = BytecodeVM()
    if print_fn: vm.print_fn = print_fn
    return vm.run(proto)

def disassemble(source: str) -> str:
    """Compile and disassemble InScript source to human-readable bytecode."""
    proto = compile_source(source)
    return proto.disassemble()

def save_insb(proto: FuncProto, path: str):
    """Save compiled bytecode to .insb file."""
    with open(path, 'wb') as f: f.write(serialize(proto))

def load_insb(path: str) -> FuncProto:
    """Load compiled bytecode from .insb file."""
    with open(path, 'rb') as f: return deserialize(f.read())
