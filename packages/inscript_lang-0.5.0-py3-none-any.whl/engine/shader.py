# inscript/engine/shader.py  —  Phase 14: Shader System
#
# Write GPU shaders in InScript syntax, transpile to GLSL/WGSL/HLSL.
#
# InScript shader syntax:
#
#   shader WaterShader {
#       uniform time      : float
#       uniform texture0  : Texture2D
#       uniform wave_h    : float = 0.1
#       uniform tint      : Vec4  = Vec4(1,1,1,1)
#
#       vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
#           let world_pos = pos + Vec3(0.0, sin(pos.x * 2.0 + time) * wave_h, 0.0)
#           return VertexOut(world_pos, uv, normal)
#       }
#
#       fragment(uv: Vec2, normal: Vec3) -> Vec4 {
#           let col  = sample(texture0, uv)
#           let wave = sin(uv.x * 10.0 + time) * 0.5 + 0.5
#           return col * tint * Vec4(wave, wave, 1.0, 1.0)
#       }
#   }
#
# Features:
#   • ShaderParser      — tokenize + parse shader blocks from .ins source
#   • ShaderAST nodes   — Shader, Uniform, Stage, Stmt, Expr
#   • ShaderTranspiler  — emit GLSL 330 core / WGSL / HLSL 5.0
#   • UniformBinder     — CPU-side uniform value storage + type checking
#   • ShaderProgram     — compiled shader (source strings for each target)
#   • ShaderLibrary     — registry of all shaders, file watch + hot-reload
#   • ShaderValidator   — type-check InScript shader code before transpile
#
# Deliverable for ROADMAP_v2.md Phase 14.

from __future__ import annotations
import re, os, math, time, hashlib
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum, auto


# ─────────────────────────────────────────────────────────────────────────────
# TYPES
# ─────────────────────────────────────────────────────────────────────────────

class ShaderType(Enum):
    FLOAT    = "float"
    INT      = "int"
    BOOL     = "bool"
    VEC2     = "Vec2"
    VEC3     = "Vec3"
    VEC4     = "Vec4"
    MAT3     = "Mat3"
    MAT4     = "Mat4"
    TEXTURE2D= "Texture2D"
    SAMPLER  = "Sampler"
    VOID     = "void"
    UNKNOWN  = "unknown"


# InScript type name → ShaderType
_TYPE_MAP = {t.value: t for t in ShaderType}

# ShaderType → GLSL type string
_GLSL_TYPE = {
    ShaderType.FLOAT:"float", ShaderType.INT:"int", ShaderType.BOOL:"bool",
    ShaderType.VEC2:"vec2",   ShaderType.VEC3:"vec3", ShaderType.VEC4:"vec4",
    ShaderType.MAT3:"mat3",   ShaderType.MAT4:"mat4",
    ShaderType.TEXTURE2D:"sampler2D", ShaderType.SAMPLER:"sampler2D",
    ShaderType.VOID:"void",
}

# ShaderType → WGSL type string
_WGSL_TYPE = {
    ShaderType.FLOAT:"f32",   ShaderType.INT:"i32",   ShaderType.BOOL:"bool",
    ShaderType.VEC2:"vec2<f32>", ShaderType.VEC3:"vec3<f32>", ShaderType.VEC4:"vec4<f32>",
    ShaderType.MAT3:"mat3x3<f32>", ShaderType.MAT4:"mat4x4<f32>",
    ShaderType.TEXTURE2D:"texture_2d<f32>", ShaderType.SAMPLER:"sampler",
    ShaderType.VOID:"void",
}

# ShaderType → HLSL type string
_HLSL_TYPE = {
    ShaderType.FLOAT:"float",  ShaderType.INT:"int",    ShaderType.BOOL:"bool",
    ShaderType.VEC2:"float2",  ShaderType.VEC3:"float3",ShaderType.VEC4:"float4",
    ShaderType.MAT3:"float3x3",ShaderType.MAT4:"float4x4",
    ShaderType.TEXTURE2D:"Texture2D", ShaderType.SAMPLER:"SamplerState",
    ShaderType.VOID:"void",
}

def _resolve_type(name: str) -> ShaderType:
    return _TYPE_MAP.get(name, ShaderType.UNKNOWN)


# ─────────────────────────────────────────────────────────────────────────────
# AST NODES
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ShaderParam:
    name:  str
    type:  ShaderType
    default: Optional[str] = None   # raw string default expression


@dataclass
class ShaderUniform:
    name:    str
    type:    ShaderType
    default: Optional[str] = None
    binding: int = -1               # auto-assigned


@dataclass
class ShaderStmt:
    """A single statement inside a stage body (raw text for now)."""
    kind: str      # "let", "assign", "return", "if", "for", "expr"
    text: str      # raw InScript source of this statement


@dataclass
class ShaderStage:
    kind:    str           # "vertex" | "fragment" | "compute"
    params:  List[ShaderParam]
    returns: ShaderType
    return_struct: Optional[str]   # e.g. "VertexOut"
    body:    List[ShaderStmt]
    raw_body: str          # original source block (for debug / fallback)


@dataclass
class ShaderDef:
    name:     str
    uniforms: List[ShaderUniform]
    stages:   Dict[str, ShaderStage]   # "vertex" | "fragment" | "compute"
    structs:  List[Tuple[str, List[ShaderParam]]]  # helper structs declared inside
    source:   str          # original .ins shader block


# ─────────────────────────────────────────────────────────────────────────────
# TOKENIZER  (lightweight, only for shader blocks)
# ─────────────────────────────────────────────────────────────────────────────

_TOK_RE = re.compile(
    r'(?P<COMMENT>//[^\n]*)|'
    r'(?P<STRING>"[^"]*")|'
    r'(?P<FLOAT_LIT>\d+\.\d*|\.\d+)|'
    r'(?P<INT_LIT>\d+)|'
    r'(?P<ARROW>->)|'
    r'(?P<OP>[+\-*/%<>=!&|^~]+)|'
    r'(?P<PUNCT>[(){}\[\],;:.])|'
    r'(?P<ID>[A-Za-z_]\w*)|'
    r'(?P<WS>\s+)'
)

def _tokenize_shader(src: str):
    toks = []
    for m in _TOK_RE.finditer(src):
        kind = m.lastgroup
        val  = m.group()
        if kind in ('WS', 'COMMENT'): continue
        toks.append((kind, val))
    return toks


# ─────────────────────────────────────────────────────────────────────────────
# SHADER PARSER
# ─────────────────────────────────────────────────────────────────────────────

class ShaderParser:
    """
    Extracts `shader Name { ... }` blocks from InScript source and
    builds ShaderDef AST nodes.
    """

    # Regex to find top-level shader blocks (handles nested braces)
    _BLOCK_RE = re.compile(r'\bshader\s+(\w+)\s*\{')

    @staticmethod
    def extract_blocks(source: str) -> List[Tuple[str, str]]:
        """
        Returns [(name, block_content), ...] for every shader block.
        block_content is everything between the outermost { }.
        """
        results = []
        for m in ShaderParser._BLOCK_RE.finditer(source):
            name = m.group(1)
            start = m.end()        # position after opening {
            depth = 1; i = start
            while i < len(source) and depth > 0:
                if source[i] == '{': depth += 1
                elif source[i] == '}': depth -= 1
                i += 1
            block = source[start:i-1]
            results.append((name, block, source[m.start():i]))
        return results

    @classmethod
    def parse_source(cls, source: str) -> List[ShaderDef]:
        """Parse all shader blocks from an InScript source file."""
        defs = []
        for name, block, full in cls.extract_blocks(source):
            sd = cls._parse_block(name, block, full)
            defs.append(sd)
        return defs

    @classmethod
    def _parse_block(cls, name: str, block: str, full: str) -> ShaderDef:
        uniforms: List[ShaderUniform] = []
        stages:   Dict[str, ShaderStage] = {}
        structs:  List = []

        lines = block.split('\n')
        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Skip empty / comments
            if not line or line.startswith('//'):
                i += 1; continue

            # uniform <name> : <type> [= <default>]
            if line.startswith('uniform '):
                u = cls._parse_uniform(line)
                if u: uniforms.append(u)
                i += 1; continue

            # struct <Name> { ... }
            if line.startswith('struct '):
                m = re.match(r'struct\s+(\w+)\s*\{', line)
                if m:
                    sname = m.group(1); fields = []
                    i += 1
                    while i < len(lines) and '}' not in lines[i]:
                        fl = lines[i].strip()
                        if fl and ':' in fl:
                            fn, ft = fl.rstrip(',').split(':', 1)
                            fields.append(ShaderParam(fn.strip(), _resolve_type(ft.strip())))
                        i += 1
                    structs.append((sname, fields))
                i += 1; continue

            # vertex(...) -> ReturnType { ... }
            # fragment(...) -> ReturnType { ... }
            # compute(...) { ... }
            stage_m = re.match(r'(vertex|fragment|compute)\s*\(', line)
            if stage_m:
                kind = stage_m.group(1)
                # Collect entire stage body (may span multiple lines)
                body_lines = [line]
                depth = line.count('{') - line.count('}')
                i += 1
                while i < len(lines) and depth > 0:
                    body_lines.append(lines[i])
                    depth += lines[i].count('{') - lines[i].count('}')
                    i += 1
                stage_src = '\n'.join(body_lines)
                stage = cls._parse_stage(kind, stage_src)
                stages[kind] = stage
                continue

            i += 1

        # Auto-assign uniform bindings
        tex_slot = 0; ubo_slot = 0
        for u in uniforms:
            if u.type == ShaderType.TEXTURE2D:
                u.binding = tex_slot; tex_slot += 1
            else:
                u.binding = ubo_slot; ubo_slot += 1

        return ShaderDef(name, uniforms, stages, structs, full)

    @staticmethod
    def _parse_uniform(line: str) -> Optional[ShaderUniform]:
        # uniform name : type [= default]
        m = re.match(r'uniform\s+(\w+)\s*:\s*(\w+)\s*(?:=\s*(.+))?', line)
        if not m: return None
        name, tname, default = m.group(1), m.group(2), m.group(3)
        return ShaderUniform(name, _resolve_type(tname), default.strip() if default else None)

    @staticmethod
    def _parse_stage(kind: str, src: str) -> ShaderStage:
        # Parse signature: vertex(pos: Vec3, uv: Vec2) -> VertexOut
        sig_m = re.match(
            r'(?:vertex|fragment|compute)\s*\(([^)]*)\)\s*(?:->\s*(\w+))?\s*\{',
            src, re.DOTALL
        )
        params:  List[ShaderParam] = []
        ret_type = ShaderType.VOID
        ret_struct = None

        if sig_m:
            raw_params = sig_m.group(1).strip()
            raw_ret    = sig_m.group(2)

            if raw_params:
                for p in raw_params.split(','):
                    p = p.strip()
                    if not p: continue
                    if ':' in p:
                        pn, pt = p.split(':', 1)
                        params.append(ShaderParam(pn.strip(), _resolve_type(pt.strip())))
                    else:
                        params.append(ShaderParam(p, ShaderType.UNKNOWN))

            if raw_ret:
                rt = _resolve_type(raw_ret)
                if rt == ShaderType.UNKNOWN:
                    ret_struct = raw_ret   # e.g. "VertexOut"
                    ret_type   = ShaderType.VEC4
                else:
                    ret_type = rt

        # Extract body
        brace = src.find('{')
        raw_body = src[brace+1:].rstrip().rstrip('}').strip() if brace >= 0 else src

        # Parse body statements (basic)
        stmts = ShaderParser._parse_stmts(raw_body)
        return ShaderStage(kind, params, ret_type, ret_struct, stmts, raw_body)

    @staticmethod
    def _parse_stmts(body: str) -> List[ShaderStmt]:
        stmts = []
        # Split on newlines; classify each non-empty line
        for line in body.split('\n'):
            line = line.strip()
            if not line or line.startswith('//'): continue
            if line.startswith('let '):      stmts.append(ShaderStmt('let',    line))
            elif line.startswith('return '): stmts.append(ShaderStmt('return', line))
            elif line.startswith('if '):     stmts.append(ShaderStmt('if',     line))
            elif line.startswith('for '):    stmts.append(ShaderStmt('for',    line))
            elif '=' in line:                stmts.append(ShaderStmt('assign', line))
            else:                            stmts.append(ShaderStmt('expr',   line))
        return stmts


# ─────────────────────────────────────────────────────────────────────────────
# EXPRESSION TRANSPILER  (InScript expr → target language)
# ─────────────────────────────────────────────────────────────────────────────

# Built-in function name mapping
_GLSL_FUNCS = {
    'sin':'sin','cos':'cos','tan':'tan','sqrt':'sqrt','abs':'abs',
    'floor':'floor','ceil':'ceil','round':'round','fract':'fract',
    'min':'min','max':'max','clamp':'clamp','mix':'mix','lerp':'mix',
    'dot':'dot','cross':'cross','normalize':'normalize','length':'length',
    'reflect':'reflect','refract':'refract','pow':'pow','exp':'exp','log':'log',
    'step':'step','smoothstep':'smoothstep','mod':'mod',
    'sample':'texture','Vec2':'vec2','Vec3':'vec3','Vec4':'vec4',
    'Mat3':'mat3','Mat4':'mat4',
    'VertexOut':'VertexOut',
}
_WGSL_FUNCS = {
    'sin':'sin','cos':'cos','tan':'tan','sqrt':'sqrt','abs':'abs',
    'floor':'floor','ceil':'ceil','round':'round','fract':'fract',
    'min':'min','max':'max','clamp':'clamp','mix':'mix','lerp':'mix',
    'dot':'dot','cross':'cross','normalize':'normalize','length':'length',
    'reflect':'reflect','refract':'refract','pow':'pow','exp':'exp','log':'log',
    'step':'step','smoothstep':'smoothstep','mod':'modf',
    'sample':'textureSample','Vec2':'vec2<f32>','Vec3':'vec3<f32>','Vec4':'vec4<f32>',
}
_HLSL_FUNCS = {
    'sin':'sin','cos':'cos','tan':'tan','sqrt':'sqrt','abs':'abs',
    'floor':'floor','ceil':'ceil','round':'round','fract':'frac',
    'min':'min','max':'max','clamp':'clamp','mix':'lerp','lerp':'lerp',
    'dot':'dot','cross':'cross','normalize':'normalize','length':'length',
    'reflect':'reflect','refract':'refract','pow':'pow','exp':'exp','log':'log',
    'step':'step','smoothstep':'smoothstep','mod':'fmod',
    'sample':'tex.Sample','Vec2':'float2','Vec3':'float3','Vec4':'float4',
}


def _transpile_expr(expr: str, target: str, uniforms: List[str], tex_uniforms: List[str]) -> str:
    """
    Convert an InScript expression to the target language.
    This handles the most common patterns; complex AST rewriting would require
    a full parser (use the main InScript parser in production).
    """
    funcs = {'glsl': _GLSL_FUNCS, 'wgsl': _WGSL_FUNCS, 'hlsl': _HLSL_FUNCS}[target]

    result = expr

    # sample(tex, uv) → texture(tex, uv) / textureSample(tex, sampler, uv)
    if target == 'wgsl':
        result = re.sub(
            r'\bsample\((\w+),\s*(\w+)\)',
            r'textureSample(\1, \1_sampler, \2)',
            result
        )
    elif target == 'hlsl':
        result = re.sub(
            r'\bsample\((\w+),\s*(\w+)\)',
            r'\1.Sample(\1_sampler, \2)',
            result
        )
    else:  # glsl
        result = re.sub(r'\bsample\(', 'texture(', result)

    # Type constructors
    if target == 'glsl':
        result = re.sub(r'\bVec2\(', 'vec2(', result)
        result = re.sub(r'\bVec3\(', 'vec3(', result)
        result = re.sub(r'\bVec4\(', 'vec4(', result)
        result = re.sub(r'\bMat4\(', 'mat4(', result)
        result = re.sub(r'\bMat3\(', 'mat3(', result)
    elif target == 'wgsl':
        result = re.sub(r'\bVec2\(', 'vec2<f32>(', result)
        result = re.sub(r'\bVec3\(', 'vec3<f32>(', result)
        result = re.sub(r'\bVec4\(', 'vec4<f32>(', result)
    elif target == 'hlsl':
        result = re.sub(r'\bVec2\(', 'float2(', result)
        result = re.sub(r'\bVec3\(', 'float3(', result)
        result = re.sub(r'\bVec4\(', 'float4(', result)

    # Remap function names
    for ins_name, target_name in funcs.items():
        if ins_name not in ('Vec2','Vec3','Vec4','Mat3','Mat4','sample'):
            result = re.sub(r'\b' + re.escape(ins_name) + r'\b', target_name, result)

    # && / || → and/or (WGSL) or keep as-is (GLSL/HLSL)
    if target == 'wgsl':
        result = result.replace('&&', '&').replace('||', '|')

    return result


def _transpile_stmt(stmt: ShaderStmt, target: str, uniforms: List[str],
                    tex_uniforms: List[str], indent: str = '    ') -> str:
    """Transpile a single statement to the target language."""
    u = uniforms; t = tex_uniforms
    text = stmt.text

    if target == 'glsl':
        if stmt.kind == 'let':
            # let name = expr  →  auto name = expr;  (GLSL uses typed vars but auto works here)
            m = re.match(r'let\s+(\w+)\s*(?::\s*\w+)?\s*=\s*(.+)', text)
            if m: return f"{indent}float {m.group(1)} = {_transpile_expr(m.group(2), target, u, t)};"
            return f"{indent}// {text}"
        elif stmt.kind == 'return':
            expr = text[len('return '):].strip()
            return f"{indent}return {_transpile_expr(expr, target, u, t)};"
        elif stmt.kind == 'assign':
            m = re.match(r'(\w+(?:\.\w+)*)\s*=\s*(.+)', text)
            if m: return f"{indent}{m.group(1)} = {_transpile_expr(m.group(2), target, u, t)};"
            return f"{indent}{_transpile_expr(text, target, u, t)};"
        else:
            return f"{indent}{_transpile_expr(text, target, u, t)};"

    elif target == 'wgsl':
        if stmt.kind == 'let':
            m = re.match(r'let\s+(\w+)\s*(?::\s*\w+)?\s*=\s*(.+)', text)
            if m: return f"{indent}let {m.group(1)} = {_transpile_expr(m.group(2), target, u, t)};"
            return f"{indent}// {text}"
        elif stmt.kind == 'return':
            expr = text[len('return '):].strip()
            return f"{indent}return {_transpile_expr(expr, target, u, t)};"
        elif stmt.kind == 'assign':
            m = re.match(r'(\w+(?:\.\w+)*)\s*=\s*(.+)', text)
            if m: return f"{indent}var {m.group(1)} = {_transpile_expr(m.group(2), target, u, t)};"
            return f"{indent}{_transpile_expr(text, target, u, t)};"
        else:
            return f"{indent}{_transpile_expr(text, target, u, t)};"

    else:  # hlsl
        if stmt.kind == 'let':
            m = re.match(r'let\s+(\w+)\s*(?::\s*\w+)?\s*=\s*(.+)', text)
            if m: return f"{indent}float4 {m.group(1)} = {_transpile_expr(m.group(2), target, u, t)};"
            return f"{indent}// {text}"
        elif stmt.kind == 'return':
            expr = text[len('return '):].strip()
            return f"{indent}return {_transpile_expr(expr, target, u, t)};"
        elif stmt.kind == 'assign':
            m = re.match(r'(\w+(?:\.\w+)*)\s*=\s*(.+)', text)
            if m: return f"{indent}{m.group(1)} = {_transpile_expr(m.group(2), target, u, t)};"
            return f"{indent}{_transpile_expr(text, target, u, t)};"
        else:
            return f"{indent}{_transpile_expr(text, target, u, t)};"


# ─────────────────────────────────────────────────────────────────────────────
# SHADER TRANSPILER
# ─────────────────────────────────────────────────────────────────────────────

class ShaderTranspiler:
    """
    Converts a ShaderDef into GLSL 330 core, WGSL, or HLSL 5.0 source.
    """

    @classmethod
    def to_glsl(cls, shader: ShaderDef) -> Dict[str, str]:
        """Returns {'vertex': '...', 'fragment': '...'} GLSL source strings."""
        u_names  = [u.name for u in shader.uniforms]
        tu_names = [u.name for u in shader.uniforms if u.type == ShaderType.TEXTURE2D]
        out = {}

        for stage_name, stage in shader.stages.items():
            lines = ['#version 330 core', '']

            # Uniforms
            for u in shader.uniforms:
                gt = _GLSL_TYPE.get(u.type, 'float')
                if u.type == ShaderType.TEXTURE2D:
                    lines.append(f'uniform sampler2D {u.name};')
                else:
                    default = f' = {u.default}' if u.default else ''
                    lines.append(f'uniform {gt} {u.name}{default};')
            if shader.uniforms: lines.append('')

            # Stage-specific ins/outs
            if stage_name == 'vertex':
                for i, p in enumerate(stage.params):
                    gt = _GLSL_TYPE.get(p.type, 'vec4')
                    lines.append(f'layout(location={i}) in {gt} {p.name};')
                if stage.return_struct:
                    lines.append(f'out vec4 vs_position;')
                    lines.append(f'out vec2 vs_uv;')
                    lines.append(f'out vec3 vs_normal;')
                lines.append('')
                lines.append('void main() {')

                # Body
                for stmt in stage.body:
                    lines.append(_transpile_stmt(stmt, 'glsl', u_names, tu_names))

                # If body has a return VertexOut(...), map to gl_Position
                for stmt in stage.body:
                    if stmt.kind == 'return' and 'VertexOut(' in stmt.text:
                        m = re.search(r'VertexOut\(([^)]+)\)', stmt.text)
                        if m:
                            args = [a.strip() for a in m.group(1).split(',')]
                            lines[-1] = f'    gl_Position = vec4({args[0]}, 1.0);'
                            if len(args) > 1: lines.append(f'    vs_uv = {_transpile_expr(args[1], "glsl", u_names, tu_names)};')
                            if len(args) > 2: lines.append(f'    vs_normal = {_transpile_expr(args[2], "glsl", u_names, tu_names)};')

                lines.append('}')

            elif stage_name == 'fragment':
                lines.append('in vec2 vs_uv;')
                lines.append('in vec3 vs_normal;')
                lines.append('out vec4 FragColor;')
                lines.append('')
                lines.append('void main() {')

                # Remap params from vs_ prefix
                for stmt in stage.body:
                    lines.append(_transpile_stmt(stmt, 'glsl', u_names, tu_names))

                # Ensure final return maps to FragColor
                for i, line in enumerate(lines):
                    if line.strip().startswith('return '):
                        lines[i] = '    FragColor = ' + line.strip()[len('return '):]
                        break

                lines.append('}')

            out[stage_name] = '\n'.join(lines)
        return out

    @classmethod
    def to_wgsl(cls, shader: ShaderDef) -> Dict[str, str]:
        """Returns {'vertex': '...', 'fragment': '...'} WGSL source strings."""
        u_names  = [u.name for u in shader.uniforms]
        tu_names = [u.name for u in shader.uniforms if u.type == ShaderType.TEXTURE2D]
        out = {}

        # Build uniform struct
        lines_common = []
        non_tex = [u for u in shader.uniforms if u.type != ShaderType.TEXTURE2D]
        tex_us  = [u for u in shader.uniforms if u.type == ShaderType.TEXTURE2D]

        if non_tex:
            lines_common.append('struct Uniforms {')
            for u in non_tex:
                wt = _WGSL_TYPE.get(u.type, 'f32')
                lines_common.append(f'    {u.name}: {wt},')
            lines_common.append('}')
            lines_common.append('@group(0) @binding(0) var<uniform> uniforms: Uniforms;')
        for i, u in enumerate(tex_us):
            lines_common.append(f'@group(0) @binding({i+1}) var {u.name}: texture_2d<f32>;')
            lines_common.append(f'@group(0) @binding({i+2}) var {u.name}_sampler: sampler;')
        if lines_common: lines_common.append('')

        for stage_name, stage in shader.stages.items():
            lines = list(lines_common)

            if stage_name == 'vertex':
                lines.append('struct VertexInput {')
                for i, p in enumerate(stage.params):
                    wt = _WGSL_TYPE.get(p.type, 'f32')
                    lines.append(f'    @location({i}) {p.name}: {wt},')
                lines.append('}')
                lines.append('struct VertexOutput {')
                lines.append('    @builtin(position) position: vec4<f32>,')
                lines.append('    @location(0) uv: vec2<f32>,')
                lines.append('    @location(1) normal: vec3<f32>,')
                lines.append('}')
                lines.append('')
                lines.append('@vertex')
                lines.append('fn vs_main(input: VertexInput) -> VertexOutput {')
                lines.append('    var out: VertexOutput;')

                # Emit body (replace uniform refs with uniforms.xxx)
                for stmt in stage.body:
                    s = stmt.text
                    for u in non_tex: s = re.sub(r'\b'+u.name+r'\b', f'uniforms.{u.name}', s)
                    lines.append(_transpile_stmt(ShaderStmt(stmt.kind, s), 'wgsl', u_names, tu_names))

                # Map VertexOut return
                for stmt in stage.body:
                    if stmt.kind == 'return' and 'VertexOut(' in stmt.text:
                        m = re.search(r'VertexOut\(([^)]+)\)', stmt.text)
                        if m:
                            args = [a.strip() for a in m.group(1).split(',')]
                            lines.append(f'    out.position = vec4<f32>({args[0]}, 1.0);')
                            if len(args) > 1: lines.append(f'    out.uv = {args[1]};')
                            if len(args) > 2: lines.append(f'    out.normal = {args[2]};')
                            lines.append('    return out;')
                        break
                else:
                    lines.append('    return out;')
                lines.append('}')

            elif stage_name == 'fragment':
                lines.append('struct FragInput {')
                lines.append('    @builtin(position) position: vec4<f32>,')
                lines.append('    @location(0) uv: vec2<f32>,')
                lines.append('    @location(1) normal: vec3<f32>,')
                lines.append('}')
                lines.append('')
                lines.append('@fragment')
                lines.append('fn fs_main(input: FragInput) -> @location(0) vec4<f32> {')
                lines.append('    let uv = input.uv;')
                lines.append('    let normal = input.normal;')

                for stmt in stage.body:
                    s = stmt.text
                    for u in non_tex: s = re.sub(r'\b'+u.name+r'\b', f'uniforms.{u.name}', s)
                    lines.append(_transpile_stmt(ShaderStmt(stmt.kind, s), 'wgsl', u_names, tu_names))

                lines.append('}')

            out[stage_name] = '\n'.join(lines)
        return out

    @classmethod
    def to_hlsl(cls, shader: ShaderDef) -> Dict[str, str]:
        """Returns {'vertex': '...', 'pixel': '...'} HLSL source strings."""
        u_names  = [u.name for u in shader.uniforms]
        tu_names = [u.name for u in shader.uniforms if u.type == ShaderType.TEXTURE2D]
        out = {}

        lines_common = ['// Generated by InScript ShaderTranspiler — HLSL 5.0', '']
        non_tex = [u for u in shader.uniforms if u.type != ShaderType.TEXTURE2D]
        tex_us  = [u for u in shader.uniforms if u.type == ShaderType.TEXTURE2D]

        if non_tex:
            lines_common.append('cbuffer ShaderUniforms : register(b0) {')
            for u in non_tex:
                ht = _HLSL_TYPE.get(u.type, 'float')
                lines_common.append(f'    {ht} {u.name};')
            lines_common.append('}')
        for i, u in enumerate(tex_us):
            lines_common.append(f'Texture2D {u.name} : register(t{i});')
            lines_common.append(f'SamplerState {u.name}_sampler : register(s{i});')
        if lines_common: lines_common.append('')

        for stage_name, stage in shader.stages.items():
            lines = list(lines_common)

            if stage_name == 'vertex':
                lines.append('struct VSInput {')
                for i, p in enumerate(stage.params):
                    ht = _HLSL_TYPE.get(p.type, 'float4')
                    sem = ['POSITION','TEXCOORD0','NORMAL','TANGENT'][i % 4]
                    lines.append(f'    {ht} {p.name} : {sem};')
                lines.append('};')
                lines.append('struct VSOutput {')
                lines.append('    float4 position : SV_POSITION;')
                lines.append('    float2 uv : TEXCOORD0;')
                lines.append('    float3 normal : NORMAL;')
                lines.append('};')
                lines.append('')
                lines.append('VSOutput main(VSInput input) {')
                lines.append('    VSOutput output;')

                for stmt in stage.body:
                    lines.append(_transpile_stmt(stmt, 'hlsl', u_names, tu_names))

                for stmt in stage.body:
                    if stmt.kind == 'return' and 'VertexOut(' in stmt.text:
                        m = re.search(r'VertexOut\(([^)]+)\)', stmt.text)
                        if m:
                            args = [a.strip() for a in m.group(1).split(',')]
                            lines.append(f'    output.position = float4({args[0]}, 1.0);')
                            if len(args) > 1: lines.append(f'    output.uv = {args[1]};')
                            if len(args) > 2: lines.append(f'    output.normal = {args[2]};')
                        break
                lines.append('    return output;')
                lines.append('}')

            elif stage_name == 'fragment':
                lines.append('struct PSInput {')
                lines.append('    float4 position : SV_POSITION;')
                lines.append('    float2 uv : TEXCOORD0;')
                lines.append('    float3 normal : NORMAL;')
                lines.append('};')
                lines.append('')
                lines.append('float4 main(PSInput input) : SV_TARGET {')
                lines.append('    float2 uv = input.uv;')
                lines.append('    float3 normal = input.normal;')

                for stmt in stage.body:
                    lines.append(_transpile_stmt(stmt, 'hlsl', u_names, tu_names))

                lines.append('}')

            key = 'pixel' if stage_name == 'fragment' else stage_name
            out[key] = '\n'.join(lines)
        return out

    @classmethod
    def transpile(cls, shader: ShaderDef, target: str = 'glsl') -> Dict[str, str]:
        """Main entry: transpile shader to target. Returns dict of stage → source."""
        target = target.lower()
        if   target in ('glsl', 'opengl'):    return cls.to_glsl(shader)
        elif target in ('wgsl', 'webgpu'):    return cls.to_wgsl(shader)
        elif target in ('hlsl', 'directx'):   return cls.to_hlsl(shader)
        raise ValueError(f"Unknown shader target: {target!r}. Use 'glsl', 'wgsl', or 'hlsl'.")


# ─────────────────────────────────────────────────────────────────────────────
# UNIFORM BINDER  (CPU-side uniform value storage)
# ─────────────────────────────────────────────────────────────────────────────

class UniformBinder:
    """
    Stores CPU-side uniform values and validates types before upload.
    Use set() to assign values, then get_block() to get a bytearray for the GPU.
    """
    _PY_TYPES = {
        ShaderType.FLOAT: (int, float),
        ShaderType.INT:   (int,),
        ShaderType.BOOL:  (bool, int),
        ShaderType.VEC2:  (tuple, list),
        ShaderType.VEC3:  (tuple, list),
        ShaderType.VEC4:  (tuple, list),
    }
    _BYTE_SIZES = {
        ShaderType.FLOAT:4, ShaderType.INT:4, ShaderType.BOOL:4,
        ShaderType.VEC2:8, ShaderType.VEC3:12, ShaderType.VEC4:16,
        ShaderType.MAT3:36, ShaderType.MAT4:64,
    }

    def __init__(self, shader: ShaderDef):
        self._uniforms = {u.name: u for u in shader.uniforms}
        self._values: Dict[str, Any] = {}
        # Apply defaults
        for u in shader.uniforms:
            if u.default:
                try:
                    self._values[u.name] = eval(
                        u.default.replace('Vec2','(').replace('Vec3','(').replace('Vec4','(').replace(')',')',1),
                        {"__builtins__": {}}
                    )
                except Exception:
                    self._values[u.name] = 0.0

    def set(self, name: str, value: Any) -> "UniformBinder":
        if name not in self._uniforms:
            raise KeyError(f"No uniform '{name}' in shader")
        u = self._uniforms[name]
        expected = self._PY_TYPES.get(u.type)
        if expected and not isinstance(value, expected):
            raise TypeError(f"Uniform '{name}' expects {u.type.value}, got {type(value).__name__}")
        self._values[name] = value
        return self

    def get(self, name: str) -> Any:
        return self._values.get(name)

    def get_block(self) -> bytearray:
        """Pack all non-texture uniforms into a contiguous bytearray (std140 approx)."""
        import struct
        buf = bytearray()
        for u in self._uniforms.values():
            if u.type == ShaderType.TEXTURE2D: continue
            v = self._values.get(u.name, 0.0)
            if u.type == ShaderType.FLOAT:  buf += struct.pack('<f', float(v))
            elif u.type == ShaderType.INT:  buf += struct.pack('<i', int(v))
            elif u.type == ShaderType.BOOL: buf += struct.pack('<I', int(bool(v)))
            elif u.type in (ShaderType.VEC2, ShaderType.VEC3, ShaderType.VEC4):
                vals = list(v) if hasattr(v,'__iter__') else [float(v)]*4
                n = {ShaderType.VEC2:2,ShaderType.VEC3:3,ShaderType.VEC4:4}[u.type]
                buf += struct.pack(f'<{n}f', *vals[:n])
        # Align to 16 bytes
        pad = (16 - len(buf) % 16) % 16
        buf += bytearray(pad)
        return buf

    def __repr__(self): return f"UniformBinder({list(self._values.keys())})"


# ─────────────────────────────────────────────────────────────────────────────
# SHADER VALIDATOR
# ─────────────────────────────────────────────────────────────────────────────

class ShaderValidator:
    """
    Type-checks an InScript ShaderDef.
    Returns a list of (severity, message) tuples; empty = no errors.
    """

    @staticmethod
    def validate(shader: ShaderDef) -> List[Tuple[str, str]]:
        errors = []

        # Check uniforms have valid types
        for u in shader.uniforms:
            if u.type == ShaderType.UNKNOWN:
                errors.append(('error', f"Uniform '{u.name}' has unknown type"))

        # Check stages
        for stage_name, stage in shader.stages.items():
            # Vertex stage should have position param
            if stage_name == 'vertex':
                has_pos = any(p.type == ShaderType.VEC3 for p in stage.params)
                if not has_pos:
                    errors.append(('warning', "Vertex stage has no Vec3 position parameter"))

            # Fragment stage should return Vec4
            if stage_name == 'fragment':
                if stage.returns not in (ShaderType.VEC4, ShaderType.UNKNOWN):
                    errors.append(('warning', f"Fragment stage returns {stage.returns.value}, expected Vec4"))

            # Check params have valid types
            for p in stage.params:
                if p.type == ShaderType.UNKNOWN:
                    errors.append(('warning', f"Stage '{stage_name}' param '{p.name}' has unknown type"))

            # Check body references uniforms that exist
            uniform_names = {u.name for u in shader.uniforms}
            for stmt in stage.body:
                for word in re.findall(r'\b([a-z_]\w+)\b', stmt.text):
                    # heuristic: if it looks like a potential uniform ref but isn't defined
                    if word in ('let','return','if','else','for','in','true','false'): continue
                    # Not flagging this as error since InScript vars could be local
                    pass

        return errors


# ─────────────────────────────────────────────────────────────────────────────
# SHADER PROGRAM  (compiled result)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ShaderProgram:
    """
    A fully compiled shader: source strings for each target + binder.
    In a real GPU runtime, 'handle' would be the GPU program ID.
    """
    name:       str
    shader_def: ShaderDef
    sources:    Dict[str, Dict[str, str]]  # target → {stage → source}
    binder:     UniformBinder
    errors:     List[Tuple[str, str]]
    hash:       str    # content hash for change detection
    compiled_at: float = field(default_factory=time.time)
    handle:     Optional[int] = None   # GPU program ID (set by renderer)

    def get_glsl_vertex(self)   -> Optional[str]: return self.sources.get('glsl',{}).get('vertex')
    def get_glsl_fragment(self) -> Optional[str]: return self.sources.get('glsl',{}).get('fragment')
    def get_wgsl_vertex(self)   -> Optional[str]: return self.sources.get('wgsl',{}).get('vertex')
    def get_wgsl_fragment(self) -> Optional[str]: return self.sources.get('wgsl',{}).get('fragment')
    def get_hlsl_vertex(self)   -> Optional[str]: return self.sources.get('hlsl',{}).get('vertex')
    def get_hlsl_pixel(self)    -> Optional[str]: return self.sources.get('hlsl',{}).get('pixel')

    def set_uniform(self, name: str, value: Any) -> "ShaderProgram":
        self.binder.set(name, value); return self

    def is_valid(self) -> bool:
        return not any(e[0]=='error' for e in self.errors)

    def summary(self) -> str:
        lines = [f"ShaderProgram '{self.name}'"]
        for target, stages in self.sources.items():
            for stage, src in stages.items():
                lines.append(f"  [{target.upper()} {stage}] {len(src.splitlines())} lines")
        if self.errors:
            for sev, msg in self.errors: lines.append(f"  [{sev.upper()}] {msg}")
        else:
            lines.append("  Validation: OK ✅")
        return '\n'.join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# SHADER COMPILER
# ─────────────────────────────────────────────────────────────────────────────

class ShaderCompiler:
    """
    Combines parsing + validation + transpilation into one pipeline call.
    """

    DEFAULT_TARGETS = ['glsl', 'wgsl', 'hlsl']

    @classmethod
    def compile_source(cls, source: str,
                       targets: List[str] = None) -> List[ShaderProgram]:
        """Parse all shader blocks in an InScript source file and compile each."""
        if targets is None: targets = cls.DEFAULT_TARGETS
        shader_defs = ShaderParser.parse_source(source)
        return [cls.compile(sd, targets) for sd in shader_defs]

    @classmethod
    def compile(cls, shader: ShaderDef,
                targets: List[str] = None) -> ShaderProgram:
        """Compile a single ShaderDef to all targets."""
        if targets is None: targets = cls.DEFAULT_TARGETS
        errors   = ShaderValidator.validate(shader)
        sources  = {}
        for target in targets:
            try:
                sources[target] = ShaderTranspiler.transpile(shader, target)
            except Exception as e:
                sources[target] = {}
                errors.append(('error', f"Transpile to {target} failed: {e}"))

        content_hash = hashlib.md5(shader.source.encode()).hexdigest()[:12]
        binder = UniformBinder(shader)
        return ShaderProgram(shader.name, shader, sources, binder, errors, content_hash)

    @classmethod
    def compile_file(cls, path: str, targets: List[str] = None) -> List[ShaderProgram]:
        """Load an InScript file and compile all shaders in it."""
        with open(path, 'r') as f: source = f.read()
        return cls.compile_source(source, targets)


# ─────────────────────────────────────────────────────────────────────────────
# SHADER LIBRARY  (registry + hot-reload)
# ─────────────────────────────────────────────────────────────────────────────

class ShaderLibrary:
    """
    Manages all compiled shaders in the game.
    Watches source files and hot-reloads on change.
    """

    def __init__(self, targets: List[str] = None):
        self._programs:  Dict[str, ShaderProgram] = {}
        self._file_mtimes: Dict[str, float] = {}
        self._file_sources: Dict[str, str] = {}  # path → last compiled source
        self._targets = targets or ShaderCompiler.DEFAULT_TARGETS
        self.on_reload: Optional[Callable] = None   # called when a shader reloads

    # ── Compile from string ──────────────────────────────────────────────
    def add_from_source(self, source: str) -> List[str]:
        """Compile all shaders in a source string. Returns list of names."""
        programs = ShaderCompiler.compile_source(source, self._targets)
        for prog in programs:
            self._programs[prog.name] = prog
        return [p.name for p in programs]

    def add_from_file(self, path: str) -> List[str]:
        """Load and compile a .ins file. Registers for hot-reload watching."""
        if not os.path.exists(path):
            raise FileNotFoundError(f"Shader file not found: {path}")
        with open(path, 'r') as f: source = f.read()
        names = self.add_from_source(source)
        self._file_mtimes[path]   = os.path.getmtime(path)
        self._file_sources[path]  = source
        return names

    # ── Lookup ───────────────────────────────────────────────────────────
    def get(self, name: str) -> Optional[ShaderProgram]:
        return self._programs.get(name)

    def __getitem__(self, name: str) -> ShaderProgram:
        if name not in self._programs:
            raise KeyError(f"Shader '{name}' not found. Available: {list(self._programs)}")
        return self._programs[name]

    def __contains__(self, name: str) -> bool:
        return name in self._programs

    def names(self) -> List[str]:
        return list(self._programs.keys())

    # ── Hot-reload ───────────────────────────────────────────────────────
    def check_reload(self) -> List[str]:
        """
        Call this every frame (or every few seconds) to check for file changes.
        Returns list of shader names that were reloaded.
        """
        reloaded = []
        for path, mtime in list(self._file_mtimes.items()):
            try:
                new_mtime = os.path.getmtime(path)
            except OSError:
                continue
            if new_mtime > mtime + 0.01:
                with open(path, 'r') as f: source = f.read()
                if source != self._file_sources.get(path, ''):
                    names = self.add_from_source(source)
                    self._file_mtimes[path]  = new_mtime
                    self._file_sources[path] = source
                    reloaded.extend(names)
                    if self.on_reload:
                        for n in names: self.on_reload(n, self._programs[n])
        return reloaded

    def force_reload(self, path: str) -> List[str]:
        """Manually trigger a reload of a file."""
        self._file_mtimes[path] = 0.0
        return self.check_reload()

    # ── Uniform helpers ──────────────────────────────────────────────────
    def set_uniform(self, shader_name: str, uniform_name: str, value: Any):
        if shader_name in self._programs:
            self._programs[shader_name].set_uniform(uniform_name, value)

    def set_global_time(self, t: float):
        """Set 'time' uniform on all shaders that have it."""
        for prog in self._programs.values():
            try: prog.set_uniform('time', t)
            except KeyError: pass

    def __repr__(self):
        return f"ShaderLibrary({len(self._programs)} shaders: {list(self._programs)})"


# ─────────────────────────────────────────────────────────────────────────────
# BUILT-IN SHADER TEMPLATES
# ─────────────────────────────────────────────────────────────────────────────

BUILTIN_SHADERS = """
// ── InScript Built-in Shaders ─────────────────────────────────────────

shader UnlitShader {
    uniform color    : Vec4 = Vec4(1.0, 1.0, 1.0, 1.0)
    uniform texture0 : Texture2D

    vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
        return VertexOut(pos, uv, normal)
    }

    fragment(uv: Vec2, normal: Vec3) -> Vec4 {
        let tex = sample(texture0, uv)
        return tex * color
    }
}

shader PhongShader {
    uniform ambient       : Vec3 = Vec3(0.1, 0.1, 0.1)
    uniform diffuse_color : Vec3 = Vec3(0.8, 0.8, 0.8)
    uniform specular_color: Vec3 = Vec3(1.0, 1.0, 1.0)
    uniform shininess     : float = 32.0
    uniform light_dir     : Vec3 = Vec3(0.5, -0.8, -0.3)
    uniform view_pos      : Vec3
    uniform texture0      : Texture2D

    vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
        return VertexOut(pos, uv, normal)
    }

    fragment(uv: Vec2, normal: Vec3) -> Vec4 {
        let n = normalize(normal)
        let l = normalize(-light_dir)
        let diff = max(dot(n, l), 0.0)
        let tex = sample(texture0, uv)
        let result = ambient + diffuse_color * diff
        return Vec4(result * tex.xyz, 1.0)
    }
}

shader WaterShader {
    uniform time       : float
    uniform wave_height: float = 0.08
    uniform wave_speed : float = 1.5
    uniform tint       : Vec4  = Vec4(0.2, 0.5, 0.9, 0.85)
    uniform texture0   : Texture2D

    vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
        let wave = sin(pos.x * 3.0 + time * wave_speed) * wave_height
                 + sin(pos.z * 2.0 + time * wave_speed * 0.7) * wave_height * 0.5
        let wpos = Vec3(pos.x, pos.y + wave, pos.z)
        return VertexOut(wpos, uv, normal)
    }

    fragment(uv: Vec2, normal: Vec3) -> Vec4 {
        let ripple_u = uv.x + sin(uv.y * 20.0 + time) * 0.01
        let ripple_v = uv.y + sin(uv.x * 20.0 + time * 1.3) * 0.01
        let tex = sample(texture0, Vec2(ripple_u, ripple_v))
        let depth = sin(uv.x * 5.0 + time * 0.5) * 0.5 + 0.5
        return tex * tint * Vec4(1.0, depth, 1.0, 1.0)
    }
}

shader FireShader {
    uniform time        : float
    uniform intensity   : float = 1.0
    uniform color_inner : Vec3 = Vec3(1.0, 0.9, 0.3)
    uniform color_outer : Vec3 = Vec3(1.0, 0.2, 0.0)

    vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
        let flicker = sin(pos.x * 10.0 + time * 8.0) * 0.02
        let rise    = Vec3(pos.x + flicker, pos.y, pos.z)
        return VertexOut(rise, uv, normal)
    }

    fragment(uv: Vec2, normal: Vec3) -> Vec4 {
        let dist  = length(Vec2(uv.x - 0.5, uv.y - 0.5)) * 2.0
        let flick = sin(time * 12.0 + uv.x * 15.0) * 0.1
        let heat  = clamp(1.0 - dist + flick, 0.0, 1.0) * intensity
        let color = mix(color_outer, color_inner, heat)
        let alpha = heat * heat
        return Vec4(color, alpha)
    }
}

shader DissolveShader {
    uniform progress    : float = 0.0
    uniform edge_color  : Vec3  = Vec3(1.0, 0.5, 0.0)
    uniform edge_width  : float = 0.05
    uniform texture0    : Texture2D
    uniform noise_tex   : Texture2D

    vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
        return VertexOut(pos, uv, normal)
    }

    fragment(uv: Vec2, normal: Vec3) -> Vec4 {
        let noise = sample(noise_tex, uv).r
        let tex   = sample(texture0, uv)
        let d     = noise - progress
        let alpha = step(0.0, d)
        let edge  = step(0.0, d) * step(d, edge_width)
        let color = mix(tex.xyz, edge_color, edge)
        return Vec4(color, alpha)
    }
}

shader OutlineShader {
    uniform outline_color    : Vec3  = Vec3(0.0, 0.0, 0.0)
    uniform outline_thickness: float = 0.02
    uniform texture0         : Texture2D

    vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
        let expanded = pos + normal * outline_thickness
        return VertexOut(expanded, uv, normal)
    }

    fragment(uv: Vec2, normal: Vec3) -> Vec4 {
        return Vec4(outline_color, 1.0)
    }
}

shader SkyboxShader {
    uniform time        : float
    uniform horizon_col : Vec3 = Vec3(0.6, 0.75, 0.95)
    uniform zenith_col  : Vec3 = Vec3(0.15, 0.3, 0.7)
    uniform sun_pos     : Vec3 = Vec3(0.5, 0.8, 0.3)
    uniform sun_size    : float = 0.05

    vertex(pos: Vec3, uv: Vec2, normal: Vec3) -> VertexOut {
        return VertexOut(pos, uv, normal)
    }

    fragment(uv: Vec2, normal: Vec3) -> Vec4 {
        let t    = clamp(uv.y, 0.0, 1.0)
        let sky  = mix(horizon_col, zenith_col, t)
        let sun  = dot(normalize(normal), normalize(sun_pos))
        let glow = smoothstep(1.0 - sun_size * 2.0, 1.0 - sun_size, sun)
        let halo = smoothstep(1.0 - sun_size * 6.0, 1.0 - sun_size * 2.0, sun) * 0.3
        let star_noise = sin(uv.x * 500.0 + 0.5) * sin(uv.y * 500.0 + 0.3)
        let stars = step(0.995, star_noise) * step(t, 0.3)
        let final = sky + Vec3(glow + halo, glow + halo * 0.8, halo * 0.5) + stars
        return Vec4(final, 1.0)
    }
}
"""

# Pre-built library of all built-in shaders
def get_builtin_library(targets: List[str] = None) -> ShaderLibrary:
    """Returns a ShaderLibrary pre-loaded with all built-in shaders."""
    lib = ShaderLibrary(targets)
    lib.add_from_source(BUILTIN_SHADERS)
    return lib


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def compile_shader(source: str, targets: List[str] = None) -> List[ShaderProgram]:
    """Quick compile: source string → list of ShaderPrograms."""
    return ShaderCompiler.compile_source(source, targets)

def compile_shader_file(path: str, targets: List[str] = None) -> List[ShaderProgram]:
    """Quick compile: file path → list of ShaderPrograms."""
    return ShaderCompiler.compile_file(path, targets)

def make_library(targets: List[str] = None) -> ShaderLibrary:
    """Create an empty ShaderLibrary."""
    return ShaderLibrary(targets)

def make_builtin_library(targets: List[str] = None) -> ShaderLibrary:
    """Create a ShaderLibrary pre-loaded with built-in shaders."""
    return get_builtin_library(targets)
