"""OpenAPI security metadata tests."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.security import HTTPBearer
from tests.conftest import Book, SessionFactory

from auen import AuthConfig, CrudRouterBuilder


def test_security_mode_includes_openapi_security(
    get_session: SessionFactory,
) -> None:
    """Security mode should mark operations as secured in OpenAPI."""
    app = FastAPI()
    auth = AuthConfig(dependency=HTTPBearer(), mode="security")
    app.include_router(
        CrudRouterBuilder.for_model(Book, get_session).with_auth(auth).build()
    )

    schema = app.openapi()
    operation = schema["paths"]["/books/"]["get"]
    assert "security" in operation
