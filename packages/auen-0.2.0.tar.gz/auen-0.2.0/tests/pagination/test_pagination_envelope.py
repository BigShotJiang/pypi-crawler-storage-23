"""Pagination envelope tests."""

from __future__ import annotations

from httpx import AsyncClient


async def test_pagination_envelope(
    envelope_pagination_client: AsyncClient,
) -> None:
    for title in ["A", "B", "C"]:
        await envelope_pagination_client.post(
            "/books/",
            json={"title": title, "isbn": f"ISBN-{title}"},
        )

    resp = await envelope_pagination_client.get("/books/?limit=2&sort=title")
    assert resp.status_code == 200
    payload = resp.json()
    assert set(payload.keys()) == {"items", "total", "limit", "offset"}
    assert payload["total"] == 3
    assert payload["limit"] == 2
    assert payload["offset"] == 0
    assert [b["title"] for b in payload["items"]] == ["A", "B"]
