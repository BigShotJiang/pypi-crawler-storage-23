# Row-Level Policies

Policies control which rows a user can access. The most critical method is `filter_list_query`, which prevents data leaks on LIST endpoints.

## Implementing a policy

```python
class OwnerPolicy:
    def can_create(self, user, obj_in):
        return True

    def can_read(self, user, db_obj):
        return db_obj.owner_id == user

    def can_update(self, user, db_obj, obj_in):
        return db_obj.owner_id == user

    def can_delete(self, user, db_obj):
        return db_obj.owner_id == user

    def filter_list_query(self, user, query):
        return query.where(Hero.owner_id == user)
```

## Default behavior

- **No auth + no policy**: all operations allowed
- **Auth + no policy**: all authenticated users can access everything
- **Auth + policy**: access controlled per-row
