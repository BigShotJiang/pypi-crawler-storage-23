# Authentication Hooks

Auen doesn't implement JWT, OAuth, or any auth protocol. Instead, it accepts a FastAPI dependency that returns the current user.

## Basic auth

```python
from fastapi import Header, HTTPException
from auen import AuthConfig

def get_current_user(authorization: str = Header()) -> str:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401)
    return authorization[7:]

auth = AuthConfig(dependency=get_current_user)
```

## Per-operation control

Allow anonymous access to specific operations:

```python
from auen import AuthConfig, Operation

auth = AuthConfig(
    dependency=get_current_user,
    allow_anonymous={Operation.LIST, Operation.READ},
)
```

## Security mode (OAuth2 scopes)

Use `mode="security"` to annotate OpenAPI with scope requirements:

```python
auth = AuthConfig(
    dependency=get_current_user,
    mode="security",
    scopes_by_operation={
        Operation.CREATE: ["heroes:write"],
        Operation.DELETE: ["heroes:admin"],
    },
)
```
