# Quickstart

## 1. Install

```bash
pip install auen
```

## 2. Define your model

```python
from sqlmodel import Field, SQLModel

class Hero(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str
    secret_name: str
    age: int | None = None
```

## 3. Create your app

```python
from fastapi import FastAPI
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel.ext.asyncio.session import AsyncSession
from auen import CrudRouterBuilder, derive_schemas

async_engine = create_async_engine("sqlite+aiosqlite:///heroes.db")

async def init_db() -> None:
    async with async_engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

async def get_session() -> AsyncSession:
    async with AsyncSession(async_engine) as session:
        yield session

app = FastAPI()
app.add_event_handler("startup", init_db)
app.include_router(
    CrudRouterBuilder.for_model(Hero, get_session)
    .with_schemas(derive_schemas(Hero))
    .build()
)
```

## 4. Run it

```bash
uvicorn app:app --reload
```

Visit `http://localhost:8000/docs` to see your auto-generated API.
