# auen

Auto-generate FastAPI CRUD endpoints from SQLModel models.

## Features

- **One-line CRUD**: `CrudRouterBuilder` generates POST, GET, PATCH, DELETE endpoints
- **Schema separation**: Explicit Create/Read/Update schemas prevent field leakage
- **Auth hooks**: Pluggable authentication via FastAPI dependencies
- **Row-level policies**: Filter LIST queries and gate access per-object
- **Pagination & filtering**: Configurable limits, sorting, and field filters
- **Typed**: Full type annotations with `py.typed` marker (PEP 561)

## Installation

```bash
pip install auen
```

## Quick Example

```python
from fastapi import FastAPI
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel import Field, SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession
from auen import CrudRouterBuilder, derive_schemas

class Hero(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str
    secret_name: str

async_engine = create_async_engine("sqlite+aiosqlite:///heroes.db")

async def init_db() -> None:
    async with async_engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

async def get_session() -> AsyncSession:
    async with AsyncSession(async_engine) as session:
        yield session

app = FastAPI()
app.add_event_handler("startup", init_db)
app.include_router(
    CrudRouterBuilder.for_model(Hero, get_session)
    .with_schemas(derive_schemas(Hero))
    .build()
)
```
