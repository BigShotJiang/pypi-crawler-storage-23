"""Auen - Auto-generate FastAPI CRUD endpoints from SQLModel models."""

from auen._version import __version__
from auen.config import (
    ALL_OPERATIONS,
    AuthConfig,
    FilterConfig,
    FilterFieldConfig,
    HooksConfig,
    Operation,
    PaginationConfig,
    SchemaConfig,
    SoftDeleteConfig,
)
from auen.exceptions import (
    AuenError,
    ConfigurationError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
)
from auen.policy import AllowAll, CrudPolicy
from auen.repository import AsyncCrudRepository, AsyncSqlModelRepository
from auen.router import CrudRouterBuilder, crud_router
from auen.schemas import derive_schemas

__all__ = [
    "ALL_OPERATIONS",
    "AllowAll",
    "AsyncCrudRepository",
    "AsyncSqlModelRepository",
    "AuenError",
    "AuthConfig",
    "ConfigurationError",
    "ConflictError",
    "CrudPolicy",
    "CrudRouterBuilder",
    "FilterConfig",
    "FilterFieldConfig",
    "ForbiddenError",
    "HooksConfig",
    "NotFoundError",
    "Operation",
    "PaginationConfig",
    "SchemaConfig",
    "SoftDeleteConfig",
    "__version__",
    "crud_router",
    "derive_schemas",
]
