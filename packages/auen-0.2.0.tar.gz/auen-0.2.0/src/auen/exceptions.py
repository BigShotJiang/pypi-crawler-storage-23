"""Auen exceptions."""

from __future__ import annotations

from fastapi import HTTPException, status

from auen.types import PKValue


class AuenError(Exception):
    """Base exception for auen."""


class ConfigurationError(AuenError):
    """Raised when auen configuration is invalid."""


class NotFoundError(HTTPException):
    """404 - resource not found."""

    def __init__(self, model_name: str, pk_field: str, pk: PKValue) -> None:
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"{model_name} with {pk_field} {pk!r} not found",
        )


class ConflictError(HTTPException):
    """409 - integrity constraint violation."""

    def __init__(self, detail: str = "Resource conflict") -> None:
        super().__init__(status_code=status.HTTP_409_CONFLICT, detail=detail)


class ForbiddenError(HTTPException):
    """403 - policy denied access."""

    def __init__(self, detail: str = "Forbidden") -> None:
        super().__init__(status_code=status.HTTP_403_FORBIDDEN, detail=detail)
