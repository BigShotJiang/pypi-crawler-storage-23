# Aivora

A Python package for generating interaction features.

## Installation

```bash
pip install aivora
```
