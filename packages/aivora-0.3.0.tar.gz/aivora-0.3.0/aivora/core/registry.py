_COMPONENTS = {}


def registry(name):
    def decorator(cls):
        _COMPONENTS[name] = cls
        return cls
    return decorator



def get_component(name):
    return _COMPONENTS.get(name)