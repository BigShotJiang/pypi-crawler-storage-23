import pandas as pd

class SKLearnTransformerWrapper:
    def __init__(self, transformer, columns=None):
        self.transformer = transformer
        self.columns = columns
        self.fitted = False

    def fit(self, X: pd.DataFrame, y=None):
        self.columns = self.columns or X.columns.tolist()
        self.transformer.fit(X[self.columns], y)
        self.fitted = True
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not self.fitted:
            raise ValueError("Transformer not fitted yet")
        X_t = self.transformer.transform(X[self.columns])
        return pd.DataFrame(X_t, columns=self.columns, index=X.index)

    def fit_transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        return self.fit(X, y).transform(X)