import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, StratifiedKFold
from ..core.component import AivoraComponent


class OOFModelGenerator(AivoraComponent):
    def __init__(self, model, columns=None, n_splits=5, random_state=42, classification=True):
        self.model = model
        self.columns = columns
        self.n_splits = n_splits
        self.random_state = random_state
        self.classification = classification

        self.models_ = []

    def fit(self, X, y):
        cols = self.columns if self.columns is not None else X.columns
        X_values = X[cols].to_numpy(dtype=float)
        n_samples = X.shape[0]

        if self.classification:
            splitter = StratifiedKFold(n_splits=self.n_splits, shuffle=True, random_state=self.random_state)
            n_classes = len(np.unique(y))
            oof_preds = np.zeros((n_samples, n_classes))
        else:
            splitter = KFold(n_splits=self.n_splits, shuffle=True, random_state=self.random_state)
            oof_preds = np.zeros(n_samples)

        self.models_ = []

        for train_idx, val_idx in splitter.split(X_values, y):
            X_tr, X_val = X_values[train_idx], X_values[val_idx]
            y_tr = y.iloc[train_idx] if isinstance(y, pd.Series) else y[train_idx]

            model_clone = self._clone_model(self.model)
            model_clone.fit(X_tr, y_tr)
            self.models_.append(model_clone)

            if self.classification:
                oof_preds[val_idx] = model_clone.predict_proba(X_val)
            else:
                oof_preds[val_idx] = model_clone.predict(X_val)

        self.oof_ = oof_preds
        self.columns_ = cols

        return self

    def transform(self, X):
        
        if not hasattr(self, "oof_"):
            raise ValueError("Model not fitted. Call fit() first.")

        X_values = X[self.columns_].to_numpy(dtype=float)
        
        if X_values.shape[0] == self.oof_.shape[0]:
            oof = self.oof_
            
        else:
            
            preds = []
            
            for model in self.models_:
                
                if self.classification:
                    preds.append(model.predict_proba(X_values))
                    
                else:
                    preds.append(model.predict(X_values).reshape(-1, 1))
                    
            oof = np.mean(preds, axis=0)

        if self.classification:
            class_names = self.models_[0].classes_
            cols = [f"oof_prob_class_{cls}" for cls in class_names]
            
        else:
            cols = [f"{self.columns_[0]}_pred"]

        return pd.DataFrame(oof, columns=cols, index=X.index)

    def fit_transform(self, X, y):
        return self.fit(X, y).transform(X)

    def _clone_model(self, model):
        from sklearn.base import clone
        return clone(model)
