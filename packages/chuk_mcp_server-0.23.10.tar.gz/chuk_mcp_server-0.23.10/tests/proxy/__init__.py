"""Tests for proxy module."""
