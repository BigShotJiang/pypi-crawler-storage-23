# sparse_grid.point

::: sparse_grid.point
