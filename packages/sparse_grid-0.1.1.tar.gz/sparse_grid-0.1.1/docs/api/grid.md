# sparse_grid.grid

::: sparse_grid.grid
