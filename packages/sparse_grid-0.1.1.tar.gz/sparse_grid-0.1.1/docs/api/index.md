# API Reference

API documentation is generated with `mkdocstrings` from module docstrings and
signatures.

Use the pages in this section for module-level details:

- `sparse_grid.grid`
- `sparse_grid.point`
- `sparse_grid.utils`
