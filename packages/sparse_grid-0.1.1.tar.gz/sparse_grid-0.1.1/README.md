# sparse_grid
A Python Sparse Grid Package
