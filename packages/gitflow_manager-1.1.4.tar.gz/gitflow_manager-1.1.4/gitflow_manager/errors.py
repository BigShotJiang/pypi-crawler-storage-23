class GitFlowManagerError(Exception):
    pass
