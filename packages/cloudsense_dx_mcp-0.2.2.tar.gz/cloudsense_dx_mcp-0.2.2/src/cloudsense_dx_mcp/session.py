"""
Session-level state for the CloudSense DX MCP server.

The MCP server runs as a long-lived process (one per chat session via stdio),
so module-level state naturally persists for the session lifetime.
"""

from typing import Optional

_session_org_alias: Optional[str] = None


def get_session_org() -> Optional[str]:
    """Return the org alias remembered from a previous tool call, or None."""
    return _session_org_alias


def set_session_org(alias: str) -> None:
    """Persist the resolved org alias for subsequent calls in this session."""
    global _session_org_alias
    _session_org_alias = alias
