"""Tests for Personaut prompts module."""
