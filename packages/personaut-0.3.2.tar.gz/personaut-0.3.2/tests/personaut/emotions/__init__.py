"""Tests for Personaut emotions module."""
