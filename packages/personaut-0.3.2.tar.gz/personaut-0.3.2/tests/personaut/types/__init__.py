"""Tests for Personaut types module."""
