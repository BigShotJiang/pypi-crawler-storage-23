"""Tests for Personaut masks module."""
