"""Tests for Personaut states module."""
