"""Version information for Personaut PDK."""

__version__ = "0.3.2"
