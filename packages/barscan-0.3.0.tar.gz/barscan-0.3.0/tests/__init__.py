"""Tests for BarScan."""
