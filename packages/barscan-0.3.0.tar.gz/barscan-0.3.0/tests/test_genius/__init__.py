"""Tests for genius module."""
