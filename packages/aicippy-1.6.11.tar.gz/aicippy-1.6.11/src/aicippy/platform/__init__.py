"""
AiVibe universal platform integration for AiCippy.

Provides HTTP clients for the centralized platform API (api.aivibe.cloud)
and app-specific API (api.aicippy.com), replacing direct DynamoDB access
with a universal tenant/plan/credit management layer.
"""

from __future__ import annotations

from aicippy.platform.app_client import AppClient
from aicippy.platform.client import PlatformClient
from aicippy.platform.models import PlatformSession, TenantInfo, TenantRole, TenantStatus

__all__ = [
    "AppClient",
    "PlatformClient",
    "PlatformSession",
    "TenantInfo",
    "TenantRole",
    "TenantStatus",
]
