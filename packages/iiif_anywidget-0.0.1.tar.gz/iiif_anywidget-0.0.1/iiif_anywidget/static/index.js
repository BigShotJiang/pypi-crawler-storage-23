export function createWidget() {
  return {
    name: "iiif-anywidget",
  };
}
