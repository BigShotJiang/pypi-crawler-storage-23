def main():
    print("IIIF widgets are coming to this repository.")


if __name__ == "__main__":
    main()