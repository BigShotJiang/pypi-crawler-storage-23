# iiif-anywidget

`anywidget`s for working with images served from IIIF sources.
