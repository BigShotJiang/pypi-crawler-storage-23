# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["MP4H265Param"]


class MP4H265Param(TypedDict, total=False):
    id: Required[Literal["mp4_h265"]]

    audio_bitrate: int
    """
    AudioBitrate specifies the audio bitrate in bits per second. Must be between
    32Kbps and 512Kbps.
    """

    bufsize: int
    """
    Bufsize specifies the video buffer size in bits. Must be between 100Kbps and
    50Mbps.
    """

    channels: Literal[1, 2, 5, 7]
    """
    Channels specifies the number of audio channels. Valid values: 1 (mono), 2
    (stereo), 5 (5.1), 7 (7.1)
    """

    crf: int
    """
    Crf (Constant Rate Factor) controls the quality of the output video. Lower
    values mean better quality but larger file size. Range: 16 to 35. Recommended
    values: 18-28 for high quality, 23-28 for good quality, 28-35 for acceptable
    quality.
    """

    disable_audio: bool
    """DisableAudio indicates whether to disable audio processing."""

    disable_video: bool
    """DisableVideo indicates whether to disable video processing."""

    duration: int
    """
    Duration specifies the duration to process in seconds. Must be a positive value.
    """

    framerate: float
    """
    Framerate specifies the output video frame rate. Must be between 15 and 120 fps.
    """

    gop: int
    """Gop specifies the Group of Pictures (GOP) size. Must be between 1 and 300."""

    height: int
    """Height specifies the output video height in pixels. Must be between -2 and 7680.

    Use -2 for automatic calculation while maintaining aspect ratio.
    """

    level: Literal[30, 31, 41]
    """Level specifies the H.265 profile level.

    Valid values: 30-31 (main), 41 (main10). Higher levels support higher
    resolutions and bitrates but require more processing power.
    """

    maxrate: int
    """
    Maxrate specifies the maximum video bitrate in bits per second. Must be between
    100Kbps and 50Mbps.
    """

    minrate: int
    """
    Minrate specifies the minimum video bitrate in bits per second. Must be between
    100Kbps and 50Mbps.
    """

    movflags: str

    pixfmt: Literal[
        "yuv410p",
        "yuv411p",
        "yuv420p",
        "yuv422p",
        "yuv440p",
        "yuv444p",
        "yuvJ411p",
        "yuvJ420p",
        "yuvJ422p",
        "yuvJ440p",
        "yuvJ444p",
        "yuv420p10le",
        "yuv422p10le",
        "yuv440p10le",
        "yuv444p10le",
        "yuv420p12le",
        "yuv422p12le",
        "yuv440p12le",
        "yuv444p12le",
        "yuv420p10be",
        "yuv422p10be",
        "yuv440p10be",
        "yuv444p10be",
        "yuv420p12be",
        "yuv422p12be",
        "yuv440p12be",
        "yuv444p12be",
    ]
    """PixFmt specifies the pixel format. Valid value: yuv420p"""

    preset: Literal["ultrafast", "superfast", "veryfast", "faster", "fast", "medium"]
    """Preset specifies the encoding speed preset.

    Valid values (from fastest to slowest):

    - ultrafast: Fastest encoding, lowest quality
    - superfast: Very fast encoding, lower quality
    - veryfast: Fast encoding, moderate quality
    - faster: Faster encoding, good quality
    - fast: Fast encoding, better quality
    - medium: Balanced preset, best quality
    """

    profilev: Literal["main", "main10", "mainstillpicture"]
    """Profilev specifies the H.265 profile. Valid values:

    - main: Main profile, good for most applications
    - main10: Main 10-bit profile, supports 10-bit color
    - mainstillpicture: Still picture profile, optimized for single images
    """

    seek: int
    """
    Seek specifies the timestamp to start processing from (in seconds). Must be a
    positive value.
    """

    video_bitrate: int
    """
    VideoBitrate specifies the video bitrate in bits per second. Must be between
    100Kbps and 50Mbps.
    """

    width: int
    """Width specifies the output video width in pixels. Must be between -2 and 7680.

    Use -2 for automatic calculation while maintaining aspect ratio.
    """

    x265_keyint: int
    """
    X265KeyInt specifies the maximum number of frames between keyframes for H.265
    encoding. Range: 1 to 300. Higher values can improve compression but may affect
    seeking.
    """
