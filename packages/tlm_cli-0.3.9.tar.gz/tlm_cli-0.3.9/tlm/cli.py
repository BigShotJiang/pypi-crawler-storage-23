"""
TLM CLI — Your AI Tech Lead + Manager

Getting started:
    tlm auth                          Sign up / authenticate (opens web page)
    tlm install                       One-time setup: scan, approve config, install hooks + CLAUDE.md

Commands:
    tlm auth                          Interactive: opens web sign-up, paste API key
    tlm auth <api_key> [--url <url>]  Direct: save API key (and optionally server URL)
    tlm logout                        Remove saved credentials
    tlm install                       One-time setup: scan, approve config, install hooks + CLAUDE.md
    tlm uninstall                     Remove TLM integration + project data
    tlm check [spec_path]             Mechanical checks + spec review before commit
    tlm status                        Project stats + enforcement status
    tlm specs                         List generated specs
    tlm learn                         Analyze recent commits, extract lessons
    tlm learn --all                   Full history analysis (archaeological dig)

Workflow:
    1. tlm auth                        (one-time: sign up + get API key)
    2. cd ~/your-project && tlm install   (per-project: scan, approve, install hooks)
    3. Open Claude Code               (TLM activates automatically on significant work)
    4. Work normally                   (TLM interviews, enforces TDD, checks compliance)
"""

import sys
import os
import stat
import json
import logging
import subprocess
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from tlm.engine import (
    Project, Scanner, DiscoveryEngine, ComplianceChecker,
    ConfigGenerator, DriftDetector, extract_gaps_from_profile,
)
from tlm.enforcer import Enforcer
from tlm.api_client import (
    save_credentials, load_credentials, get_client, TLMClient,
    TLMAuthError, TLMServerError, TLMConnectionError, TLMCreditsError,
    TLMProjectLimitError, DEFAULT_BASE_URL, DEFAULT_CREDENTIALS_DIR,
)

def _cleanup_stale_pip_script():
    """Remove stale pip-generated tlm script that conflicts with pipx."""
    pip_script = Path.home() / ".local" / "bin" / "tlm"
    if not pip_script.exists() or pip_script.is_symlink():
        return

    try:
        content = pip_script.read_text()[:500]
    except (OSError, UnicodeDecodeError):
        return

    if "from tlm" not in content and "import tlm" not in content:
        return

    # Don't self-destruct if we ARE the pip install (not pipx)
    exe = str(Path(sys.executable).resolve())
    if ".local/lib" in exe and "pipx" not in exe:
        return

    try:
        pip_script.unlink()
        print(f"{G}✓{X} Cleaned up old pip-installed tlm script at {pip_script}")
    except OSError:
        print(f"{D}Note: old tlm at {pip_script} may conflict. Remove with: rm {pip_script}{X}")


def _is_firebase_token(token: str) -> bool:
    """Check if a string looks like a Firebase JWT (base64 with dots)."""
    parts = token.split(".")
    return len(parts) == 3 and len(token) > 100


# ─── Colors ────────────────────────────────────────────────────
C = "\033[36m"    # cyan
P = "\033[35m"    # purple
G = "\033[32m"    # green
Y = "\033[33m"    # yellow
R = "\033[31m"    # red
D = "\033[2m"     # dim
B = "\033[1m"     # bold
X = "\033[0m"     # reset

OVERRIDE_PHRASE = "OVERRIDE"

logger = logging.getLogger(__name__)
logger.propagate = False  # Never print to stdout/stderr
logger.addHandler(logging.NullHandler())  # Swallow until file handler configured


# ─── Spinner ──────────────────────────────────────────────────

class Spinner:
    """Animated spinner for long operations. Skips animation in non-TTY (CI/pipe)."""

    FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, messages: list[str], rotate_interval: float = 8.0):
        self._messages = messages
        self._rotate_interval = rotate_interval
        self._stop_event = threading.Event()
        self._thread = None
        self._is_tty = sys.stdout.isatty()

    def __enter__(self):
        if self._is_tty:
            self._thread = threading.Thread(target=self._spin, daemon=True)
            self._thread.start()
        else:
            # Non-TTY: just print the first message
            if self._messages:
                print(f"  {self._messages[0]}")
        return self

    def __exit__(self, *exc):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=2)
        if self._is_tty:
            # Clear the spinner line
            sys.stdout.write("\r\033[K")
            sys.stdout.flush()

    def _spin(self):
        frame_idx = 0
        msg_idx = 0
        msg_start = time.monotonic()
        while not self._stop_event.is_set():
            msg = self._messages[msg_idx] if self._messages else ""
            frame = self.FRAMES[frame_idx % len(self.FRAMES)]
            sys.stdout.write(f"\r\033[K  {C}{frame}{X} {D}{msg}{X}")
            sys.stdout.flush()
            frame_idx += 1
            self._stop_event.wait(0.1)
            # Rotate message
            if (time.monotonic() - msg_start) >= self._rotate_interval and len(self._messages) > 1:
                msg_idx = (msg_idx + 1) % len(self._messages)
                msg_start = time.monotonic()


# ─── Error Helpers ────────────────────────────────────────────

_ERROR_MAP = {
    "LLM service unavailable": "AI analysis temporarily unavailable. Please try again in a moment.",
    "LLM rate limit exceeded, try again later": "Too many requests. Please wait a minute and try again.",
    "timed out": "Server took too long to respond — please try again.",
}


def _friendly_error(msg: str) -> str:
    """Map known server error messages to user-friendly ones."""
    for key, friendly in _ERROR_MAP.items():
        if key in str(msg):
            return friendly
    return "An internal error occurred. Please try again."


def _report_error(api_client, project_id: str, error: Exception, context: str = ""):
    """Best-effort error report to server. Never crashes."""
    try:
        if api_client and project_id:
            api_client.report_error(
                project_id,
                error_type=type(error).__name__,
                error_detail=str(error),
                context=context,
            )
    except Exception:
        pass


def _display_scan_summary(profile: str):
    """Show a compact one-liner per profile section instead of raw markdown dump."""
    if not isinstance(profile, str):
        return
    import re
    sections = re.split(r'^## ', profile, flags=re.MULTILINE)
    for section in sections:
        if not section.strip():
            continue
        lines = section.strip().split("\n")
        title = lines[0].strip()
        body_lines = [l.strip() for l in lines[1:] if l.strip() and not l.strip().startswith("---")]
        if title.lower().startswith("gap"):
            gap_count = sum(1 for l in body_lines if l.startswith("- **"))
            print(f"  {C}{title}:{X} {gap_count} gap(s) detected")
        elif body_lines:
            # Show first meaningful line as summary
            summary = body_lines[0][:80]
            if len(body_lines) > 1:
                summary += f" {D}(+{len(body_lines)-1} more){X}"
            print(f"  {C}{title}:{X} {summary}")


def logo():
    print(f"""
{C}{B} ████████╗██╗     ███╗   ███╗
 ╚══██╔══╝██║     ████╗ ████║
    ██║   ██║     ██╔████╔██║
    ██║   ██║     ██║╚██╔╝██║
    ██║   ███████╗██║ ╚═╝ ██║
    ╚═╝   ╚══════╝╚═╝     ╚═╝{X}
{D}  The annoying agent that makes
  Claude do the right thing.{X}
""")


def _get_backend(project: Project = None) -> tuple:
    """Get the LLM backend — TLM server API client.

    Returns: (claude, api_client, project_id)
    - Server mode: (None, TLMClient, "project_id")

    Auto-creates project on server if project exists locally but has no project_id.
    """
    client = get_client()
    if client:
        # Validate server connectivity and auth before proceeding
        try:
            client.me()
        except TLMConnectionError:
            print(f"{R}✗ Cannot reach TLM server.{X}")
            print(f"  Check your connection and try again.\n")
            sys.exit(1)
        except TLMAuthError:
            print(f"{R}✗ API key is invalid or expired.{X}")
            print(f"  Run {C}tlm auth{X} to re-authenticate.\n")
            sys.exit(1)
        except TLMServerError as e:
            print(f"{R}✗ TLM server error: {e}{X}")
            print(f"  The server may be experiencing issues. Try again later.\n")
            sys.exit(1)

        project_id = None
        if project and project.config_file.exists():
            try:
                config = json.loads(project.config_file.read_text())
                project_id = config.get("project_id")
            except (json.JSONDecodeError, OSError):
                config = {}

            # Validate project still exists and belongs to current user
            if project_id is not None:
                try:
                    client.sync(project_id)
                except TLMServerError as e:
                    if "404" in str(e) or "not found" in str(e).lower():
                        print(f"{Y}⚠ Project not found on server. Re-registering...{X}\n")
                        project_id = None
                    else:
                        raise

            if project_id is None:
                # Auto-register this project on the server
                import hashlib
                fingerprint = hashlib.sha256(
                    str(project.root).encode()
                ).hexdigest()[:16]
                result = client.create_project(
                    project.root.name, fingerprint
                )
                project_id = result["project_id"]
                # Save project_id locally
                config["project_id"] = project_id
                project.config_file.write_text(json.dumps(config, indent=2))

        return None, client, project_id

    print(f"{R}✗ Not authenticated.{X}")
    print(f"  Run {C}tlm auth{X} to sign up and get your API key.\n")
    sys.exit(1)


def require_auth():
    """Verify the user is authenticated with TLM server."""
    client = get_client()
    if client:
        return
    print(f"{R}✗ Not authenticated.{X}")
    print(f"  Run {C}tlm auth{X} to sign up and get your API key.\n")
    sys.exit(1)


def require_init(project: Project):
    if not project.initialized:
        print(f"{R}✗ Not a TLM project. Run `tlm install` first.{X}\n")
        sys.exit(1)


def require_approved_config(project: Project):
    if not project.enforcement.approved:
        print(f"{R}✗ No approved enforcement config.{X}")
        print(f"{D}  Run `tlm install` to scan your project and approve enforcement rules.{X}\n")
        sys.exit(1)


def _start_background_analysis(project: Project):
    """Start background history analysis if the project has commits."""
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", "HEAD"],
            capture_output=True, text=True, cwd=str(project.root), timeout=5,
        )
        if result.returncode == 0:
            commit_count = int(result.stdout.strip())
            if commit_count > 0:
                print(f"\n{C}TLM ▸ Analyzing {commit_count} commits in the background...{X}")
                print(f"  {D}Learning your project's patterns. Run `tlm status` to check progress.{X}\n")
                log_path = str(project.root / ".tlm" / "learn.log")
                subprocess.Popen(
                    ["tlm", "learn", "--all"],
                    stdout=open(log_path, "w"), stderr=subprocess.STDOUT,
                    cwd=str(project.root), start_new_session=True,
                )
    except Exception:
        pass  # No git, no problem


def _save_gaps_from_profile(project: Project, profile):
    """Extract gaps from profile and save to .tlm/gaps.json."""
    if not isinstance(profile, str):
        return
    gaps = extract_gaps_from_profile(profile)
    if gaps:
        gaps_file = project.tlm_dir / "gaps.json"
        # Preserve dismissed state from existing gaps
        if gaps_file.exists():
            try:
                existing = json.loads(gaps_file.read_text())
                old_gaps = {g["id"]: g for g in existing.get("gaps", [])}
                for gap in gaps:
                    old = old_gaps.get(gap["id"])
                    if old and old.get("dismissed"):
                        gap["dismissed"] = True
                        if old.get("dismiss_reason"):
                            gap["dismiss_reason"] = old["dismiss_reason"]
            except (json.JSONDecodeError, OSError):
                pass
        gaps_file.write_text(json.dumps({"gaps": gaps}, indent=2))


def _interactive_config_approval(config_gen: ConfigGenerator, config: dict, project: Project):
    """Present config to user, let them correct, then approve."""

    while True:
        _display_config(config)

        print(f"\n{B}Does this look right?{X}")
        print(f"  {G}1. yes{X}    — Approve and save (becomes your enforcement contract)")
        print(f"  {Y}2. correct{X} — Tell me what's wrong and I'll fix it")
        print(f"  {R}3. quit{X}   — Exit without saving\n")

        try:
            user_input = input(f"{G}You:{X} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{Y}Exiting without saving config.{X}\n")
            return

        if not user_input:
            continue

        if user_input in ("1",) or user_input.lower() in ("yes", "y", "approve", "looks good", "lgtm"):
            config_gen.save_approved(config)
            print(f"\n{G}✓ Enforcement config approved and saved.{X}")
            print(f"  {D}Saved to .tlm/enforcement.json{X}")
            print(f"\n  TLM is now active. Keep building normally through Claude —")
            print(f"  TLM kicks in automatically when needed.")
            print(f"\n  Run {C}tlm help{X} for more commands, or {C}tlm status{X} to check project health.\n")
            return

        if user_input in ("3",) or user_input.lower() in ("quit", "exit", "q"):
            print(f"\n{Y}Exiting without saving. Run `tlm install` again when ready.{X}\n")
            return

        if user_input == "2":
            # Prompt for correction text
            print(f"\n{Y}Type your correction:{X}")
            try:
                user_input = input(f"{G}You:{X} ").strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n{Y}Exiting without saving config.{X}\n")
                return
            if not user_input:
                continue

        # User is correcting — send feedback to LLM
        print(f"\n{C}TLM ▸ Updating config...{X}\n")
        try:
            config = config_gen.update_config(config, user_input)
        except Exception as e:
            print(f"{R}Error updating config: {e}{X}")
            print(f"{D}Try again with different wording.{X}\n")
            continue


def _display_config(config: dict):
    """Display the enforcement config in a readable format."""

    print(f"\n{'='*60}")
    print(f"  {B}TLM Enforcement Config{X}")
    print(f"{'='*60}")

    # Summary
    summary = config.get("project_summary", "")
    if summary:
        print(f"\n  {D}{summary}{X}")

    # Environments
    envs = config.get("environments", {})
    print(f"\n  {B}Environments ({len(envs)}):{X}")
    for name, env in envs.items():
        print(f"    {C}{name}{X}: {env.get('description', '')}")
        print(f"      {D}Check: {env.get('check_exists_command', 'none')}{X}")
        print(f"      {D}Deploy: {env.get('deploy_command', 'none')}{X}")
        if env.get('env_file'):
            print(f"      {D}Env file: {env['env_file']}{X}")

    # Checks
    checks = config.get("checks", [])
    print(f"\n  {B}Quality Checks ({len(checks)}):{X}")
    for check in checks:
        blocker_icon = f"{R}●{X}" if check.get("blocker") else f"{Y}○{X}"
        when = check.get("when", "")
        print(f"    {blocker_icon} {check.get('name', '?')} {D}[{when}]{X}")
        print(f"      {D}{check.get('command', 'no command')}{X}")
        if check.get("description"):
            print(f"      {D}{check['description']}{X}")

    # Coverage
    cov = config.get("coverage", {})
    if cov and cov.get("command"):
        print(f"\n  {B}Coverage:{X}")
        print(f"    {D}Command: {cov['command']}{X}")
        print(f"    {D}Min line: {cov.get('min_line_coverage', 50)}% | "
              f"Min branch: {cov.get('min_branch_coverage', 30)}%{X}")

    # Test patterns
    test_patterns = config.get("test_patterns", {})
    if test_patterns:
        dirs = test_patterns.get("directories", [])
        globs = test_patterns.get("file_globs", [])
        print(f"\n  {B}Test Patterns:{X}")
        if dirs:
            print(f"    {D}Directories: {', '.join(dirs)}{X}")
        if globs:
            print(f"    {D}File patterns: {', '.join(globs)}{X}")

    # Drift files
    drift = config.get("drift_files", [])
    if drift:
        print(f"\n  {B}Drift Detection:{X}")
        print(f"    {D}Watching: {', '.join(drift)}{X}")

    print(f"\n  {D}● = blocker (blocks commit)  ○ = warning{X}")
    print(f"{'='*60}")


# ─── BUILD ─────────────────────────────────────────────────────

def cmd_build(feature_request: str):
    """Discovery → spec → CLAUDE.md, with drift detection and enforcement."""
    logo()

    project = Project(".")
    if not project.initialized:
        print(f"{Y}No .tlm/ found. Run `tlm install` first.{X}\n")
        sys.exit(1)

    claude, api_client, project_id = _get_backend(project)

    # ─── LEARNING SCAN ──────────────────────────
    from tlm.learner import Learner
    learner = Learner(project, claude, api_client=api_client, project_id=project_id)
    commit_count = learner.get_commit_count_since_last_session()

    if commit_count > 0:
        print(f"{C}TLM ▸ Learning from {commit_count} commits since last session...{X}\n")

        def _learn_progress(current, total, hash_str, summary):
            print(f"  {D}[{current}/{total}]{X} {hash_str} — {summary[:60]}")

        synthesis = learner.learn_since_last_session(progress_callback=_learn_progress)

        if synthesis.get("total_commits", 0) > 0:
            accuracy = synthesis.get("spec_accuracy_percent", "?")
            bugs = len(synthesis.get("bug_patterns", []))
            unplanned_n = len(synthesis.get("unplanned_features", []))

            print(f"\n  {B}Learning Summary:{X}")
            print(f"  Spec accuracy: {accuracy}%")
            if bugs:
                print(f"  Bug patterns found: {bugs}")
                for bp in synthesis.get("bug_patterns", []):
                    print(f"    {Y}•{X} {bp.get('pattern', '?')} ({bp.get('frequency', '?')}x)")
            if unplanned_n:
                print(f"  Unplanned features: {unplanned_n}")
                for uf in synthesis.get("unplanned_features", []):
                    print(f"    {Y}•{X} {uf.get('what', '?')}")

            improvements = synthesis.get("interview_improvements", [])
            if improvements:
                print(f"\n  {G}Lessons injected into this interview:{X}")
                for imp in improvements[:5]:
                    print(f"    {C}→{X} {imp[:80]}")

            print()

    # ─── DRIFT DETECTION ─────────────────────────
    if project.enforcement.approved:
        print(f"{C}TLM ▸ Checking for config drift...{X}\n")
        detector = DriftDetector(project, claude, api_client=api_client, project_id=project_id)
        drift = detector.check()

        if drift.get("stale"):
            print(f"{R}{'='*60}{X}")
            print(f"{R}  ✗ ENFORCEMENT CONFIG IS STALE{X}")
            print(f"{R}{'='*60}{X}")
            print(f"\n  Changed files: {', '.join(drift['changed_files'])}")
            print(f"  Reason: {drift.get('reason', 'unknown')}")
            print(f"\n{R}  Your project has changed since you approved the enforcement config.{X}")
            print(f"  Run {C}tlm install{X} to re-scan and re-approve.\n")
            print(f"  {D}Or type {B}{OVERRIDE_PHRASE}{X}{D} to proceed anyway (at your own risk).{X}\n")

            try:
                user_input = input(f"{G}You:{X} ").strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n{Y}Aborting.{X}\n")
                sys.exit(1)

            if user_input.strip() != OVERRIDE_PHRASE:
                print(f"\n{R}Build blocked. Run `tlm install` to update your config.{X}\n")
                sys.exit(1)
            else:
                print(f"\n{Y}⚠ Override accepted. Proceeding with stale config.{X}\n")

        elif drift.get("drifted"):
            # Files changed but LLM says it's not meaningful
            print(f"  {D}Some files changed but config is still valid.{X}\n")
        else:
            print(f"  {G}✓{X} Config is current.\n")
    else:
        print(f"{R}✗ No approved enforcement config. Run `tlm install` first.{X}")
        print(f"{D}  Or type {B}{OVERRIDE_PHRASE}{X}{D} to proceed without enforcement.{X}\n")

        try:
            user_input = input(f"{G}You:{X} ").strip()
        except (KeyboardInterrupt, EOFError):
            sys.exit(1)

        if user_input.strip() != OVERRIDE_PHRASE:
            sys.exit(1)
        print(f"\n{Y}⚠ Override accepted. No enforcement active.{X}\n")

    # ─── PRE-BUILD ENFORCEMENT ────────────────────
    if project.enforcement.approved:
        print(f"{C}TLM ▸ Pre-build enforcement checks...{X}\n")
        enforcer = Enforcer(".")
        env_report = enforcer.run_environment_checks()

        for check in env_report.checks:
            print(str(check))
            for d in check.details:
                print(f"      {D}{d}{X}")

        if not env_report.passed:
            print(f"\n{R}✗ Environment checks failed.{X}")
            print(f"  Fix environment setup, or type {B}{OVERRIDE_PHRASE}{X} to proceed.\n")

            try:
                user_input = input(f"{G}You:{X} ").strip()
            except (KeyboardInterrupt, EOFError):
                sys.exit(1)

            if user_input.strip() != OVERRIDE_PHRASE:
                sys.exit(1)
            print(f"\n{Y}⚠ Override accepted.{X}\n")
        else:
            print(f"\n{G}✓ Environment checks passed.{X}\n")

        # Run pre_build checks
        build_report = enforcer.run_checks("pre_build")
        if build_report.checks:
            for check in build_report.checks:
                print(str(check))
            if not build_report.passed:
                print(f"\n{R}✗ Pre-build checks failed.{X}")
                print(f"  Fix issues above, or type {B}{OVERRIDE_PHRASE}{X} to proceed.\n")
                try:
                    user_input = input(f"{G}You:{X} ").strip()
                except (KeyboardInterrupt, EOFError):
                    sys.exit(1)
                if user_input.strip() != OVERRIDE_PHRASE:
                    sys.exit(1)
                print(f"\n{Y}⚠ Override accepted.{X}\n")

    # ─── DISCOVERY SESSION ────────────────────────
    config = project.get_config()
    print(f"{D}Sessions used: {config.get('sessions_used', 0)}{X}")

    print(f"\n{'='*60}")
    print(f"  {C}TLM ▸ Discovery Session{X}")
    print(f"  Feature: {B}{feature_request}{X}")
    print(f"{'='*60}\n")

    engine = DiscoveryEngine(project, claude, api_client=api_client, project_id=project_id)
    first_q = engine.start(feature_request)
    print(f"{P}TLM:{X} {first_q}\n")

    question_count = 1
    while True:
        try:
            user_input = input(f"{G}You:{X} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n{Y}Session interrupted.{X}")
            if question_count >= 3:
                print(f"{D}Generating spec with what we have...{X}\n")
                _finish_session(engine, project, feature_request)
            sys.exit(0)

        if not user_input:
            continue

        if user_input.lower() in ("done", "/done", "generate", "/generate", "spec"):
            print(f"\n{C}TLM ▸ Generating spec + instructions...{X}\n")
            _finish_session(engine, project, feature_request)
            return

        if user_input.lower() in ("quit", "exit", "/quit"):
            print(f"\n{Y}Session ended.{X}\n")
            return

        response = engine.respond(user_input)
        question_count += 1

        if engine.is_complete(response):
            print(f"\n{P}TLM:{X} {response}\n")
            print(f"{C}TLM ▸ Generating spec + TDD instructions...{X}\n")
            _finish_session(engine, project, feature_request)
            return

        print(f"\n{P}TLM:{X} {response}\n")


def _finish_session(engine: DiscoveryEngine, project: Project, feature_request: str):
    """Generate spec, CLAUDE.md, update knowledge base."""

    print(f"  {D}Generating feature spec...{X}")
    spec, instructions = engine.generate_outputs()

    spec_path = project.save_spec(feature_request, spec)
    print(f"  {G}✓{X} Spec saved → {spec_path}")

    claude_path = project.save_claude_md(instructions)
    print(f"  {G}✓{X} CLAUDE.md updated → {claude_path}")

    print(f"  {D}Updating knowledge base...{X}")
    knowledge = engine.extract_knowledge(spec)
    project.append_knowledge(knowledge)
    print(f"  {G}✓{X} Knowledge base updated")

    project.increment_sessions()

    # Preview spec
    print(f"\n{'='*60}")
    print(f"  {G}✓ Session Complete{X}")
    print(f"{'='*60}\n")

    lines = spec.split("\n")
    preview = "\n".join(lines[:30])
    print(f"{D}{'─'*60}{X}")
    print(preview)
    if len(lines) > 30:
        print(f"\n{D}  ... ({len(lines) - 30} more lines){X}")
    print(f"{D}{'─'*60}{X}")

    print(f"""
{B}What just happened:{X}

  1. {C}Spec{X} → {spec_path}
  2. {C}CLAUDE.md{X} → {claude_path}
  3. {C}Knowledge base{X} → .tlm/knowledge.md

{B}Enforcement (mechanical — runs real commands, checks exit codes):{X}

  Before you commit, {C}tlm check{X} will run every check from
  your approved enforcement config. Tests must pass. Coverage
  must meet thresholds. Linting, type checks, migrations —
  whatever your config includes. Hard pass/fail.

{B}Next steps:{X}

  1. Review the spec:  {D}cat {spec_path}{X}
  2. Open Claude Code:  {D}claude{X}
  3. Before committing:  {D}tlm check{X}
  4. Auto-enforce:  {D}tlm hook install{X}
""")


# ─── CHECK ─────────────────────────────────────────────────────

def cmd_check(spec_path: str = None):
    """Mechanical enforcement + spec review."""
    logo()
    project = Project(".")
    require_init(project)
    require_approved_config(project)

    claude, api_client, project_id = _get_backend(project)
    enforcer = Enforcer(".")

    # ─── PHASE 1: Mechanical checks from enforcement.json ─────
    print(f"{B}Phase 1: Mechanical Enforcement{X}\n")
    report = enforcer.run_checks("pre_commit")

    # Also run coverage
    cov_result = enforcer.run_coverage_check()
    report.checks.append(cov_result)

    print(report.summary())

    if not report.passed:
        print(f"\n{R}✗ Mechanical checks FAILED.{X}")
        for b in report.blockers:
            print(f"  {R}•{X} {b.name}: {b.message}")
        print(f"\n{D}Fix blockers above, then run `tlm check` again.{X}\n")
        sys.exit(1)

    print(f"\n{G}✓ Mechanical checks passed.{X}\n")

    # ─── PHASE 2: LLM spec compliance review ─────
    if spec_path:
        if not Path(spec_path).exists():
            print(f"{R}✗ Spec not found: {spec_path}{X}\n")
            sys.exit(1)
    else:
        specs = sorted(project.specs_dir.glob("*.md"), reverse=True)
        if specs:
            spec_path = str(specs[0])
            print(f"{D}Using latest spec: {spec_path}{X}")
        else:
            print(f"{Y}No specs found. Skipping spec review.{X}\n")
            print(f"{G}✓ All mechanical checks passed. Safe to commit.{X}\n")
            return

    print(f"\n{B}Phase 2: Spec Compliance Review{X}\n")
    checker = ComplianceChecker(project, claude, api_client=api_client, project_id=project_id)
    result = checker.check(spec_path)
    print(result)

    if "### Verdict: FAIL" in result:
        print(f"\n{R}✗ Spec review FAILED. Fix blockers before committing.{X}\n")
        sys.exit(1)
    elif "PASS WITH WARNINGS" in result:
        print(f"\n{Y}⚠ Passed with warnings.{X}\n")
    else:
        print(f"\n{G}✓ All checks passed. Safe to commit.{X}\n")


# ─── STATUS ────────────────────────────────────────────────────

def _credit_bar(used, total, width=20):
    """Render a credit usage bar like [████████░░░░] 850/1000."""
    remaining = total - used
    ratio = remaining / max(total, 1)
    filled = int(ratio * width)
    empty = width - filled
    bar = "█" * filled + "░" * empty
    return f"[{bar}] {remaining}/{total}"


def cmd_status():
    """Show project status + enforcement status."""
    logo()
    project = Project(".")
    require_init(project)

    # Server usage info
    api_client = get_client()
    if api_client:
        try:
            usage = api_client.usage()
            tier = usage.get("tier", "free").upper()
            credits_used = usage.get("credits_used", 0)
            credits_total = usage.get("credits_total", 0)
            credits_remaining = usage.get("credits_remaining", 0)

            print(f"  {B}Plan:{X}     {tier}")
            print(f"  {B}Credits:{X}  {_credit_bar(credits_used, credits_total)}")

            if credits_remaining <= 0:
                print(f"\n  {R}Credits exhausted.{X}")
            elif credits_remaining < credits_total * 0.1:
                print(f"\n  {Y}Credits running low ({credits_remaining} remaining).{X}")
            print()
        except Exception:
            pass  # Server unreachable — show local info only

    config = project.get_config()
    knowledge = project.get_knowledge()
    specs = list(project.specs_dir.glob("*.md"))

    facts = [l for l in knowledge.split("\n")
             if l.strip() and not l.startswith(("_", "#", "---"))]

    print(f"  {B}Project:{X}  {config.get('project_name', 'unknown')}")
    print(f"  {B}Created:{X}  {config.get('created', 'unknown')}")
    print()
    print(f"  {C}Sessions used:{X}     {config.get('sessions_used', 0)}")
    print(f"  {C}Specs generated:{X}   {len(specs)}")
    print(f"  {C}Knowledge facts:{X}   {len(facts)}")
    print()

    # Enforcement status
    print(f"  {B}Enforcement:{X}")

    has_claude_md = project.claude_md.exists()
    print(f"    CLAUDE.md:  {'%s✓ Exists%s' % (G, X) if has_claude_md else '%s✗ Missing%s' % (R, X)}")

    if project.enforcement.approved:
        ec = project.enforcement.load()
        envs = ec.get("environments", {})
        checks = ec.get("checks", [])
        blockers = [c for c in checks if c.get("blocker")]
        warnings = [c for c in checks if not c.get("blocker")]

        print(f"    Config:     {G}✓ Approved{X}")
        print(f"    Envs:       {len(envs)} configured ({', '.join(envs.keys())})")
        print(f"    Checks:     {len(blockers)} blockers, {len(warnings)} warnings")

        # Quick drift check (file-level only, no LLM)
        drift = project.enforcement.check_drift()
        if drift["drifted"]:
            print(f"    Drift:      {Y}⚠ Files changed: {', '.join(drift['changed_files'])}{X}")
        else:
            print(f"    Drift:      {G}✓ No drift{X}")
    else:
        print(f"    Config:     {R}✗ Not approved — run `tlm install`{X}")

    # Git hooks
    hook_path = project.root / ".git" / "hooks" / "pre-commit"
    has_hook = hook_path.exists() and "tlm check" in (hook_path.read_text() if hook_path.exists() else "")
    print(f"    Pre-commit: {'%s✓ Installed%s' % (G, X) if has_hook else '%s○ Not installed%s' % (D, X)}")

    post_hook_path = project.root / ".git" / "hooks" / "post-commit"
    has_post_hook = post_hook_path.exists() and "TLM" in (post_hook_path.read_text() if post_hook_path.exists() else "")
    print(f"    Post-commit: {'%s✓ Installed%s' % (G, X) if has_post_hook else '%s○ Not installed%s' % (D, X)}")

    # Project gaps
    gaps_file = project.tlm_dir / "gaps.json"
    if gaps_file.exists():
        try:
            gaps_data = json.loads(gaps_file.read_text())
            all_gaps = gaps_data.get("gaps", [])
            active_gaps = [g for g in all_gaps if not g.get("dismissed")]
            dismissed_count = len(all_gaps) - len(active_gaps)
            if active_gaps:
                print(f"\n  {B}Project Health:{X}")
                for g in active_gaps:
                    icon = f"{Y}⚠{X}" if g.get("severity") == "high" else f"{D}○{X}"
                    sev = g.get("severity", "medium")
                    print(f"    {icon} {g['description']}  {D}[{sev}]{X}")
                print(f"\n    {len(active_gaps)} gaps detected"
                      f"{f', {dismissed_count} dismissed' if dismissed_count else ''}."
                      f" Run {C}tlm gaps{X} for details.")
        except (json.JSONDecodeError, OSError):
            pass

    # Background learning status
    lockfile = project.tlm_dir / "learn.lock"
    if lockfile.exists():
        try:
            pid = int(lockfile.read_text().strip())
            os.kill(pid, 0)  # Check if process is alive (signal 0)
            print(f"    Learning:   {C}⏳ Analyzing history in background...{X}")
        except (ValueError, ProcessLookupError, PermissionError, OSError):
            # Stale lockfile — clean it up
            lockfile.unlink(missing_ok=True)

    # Learning metrics
    accuracy_history = config.get("spec_accuracy_history", [])
    total_analyzed = config.get("total_commits_analyzed", 0)

    if accuracy_history:
        latest = accuracy_history[-1]
        first = accuracy_history[0]
        trend = ""
        if len(accuracy_history) >= 2:
            delta = latest["accuracy"] - first["accuracy"]
            if delta > 0:
                trend = f" {G}(↑ from {first['accuracy']}% on first analysis){X}"
            elif delta < 0:
                trend = f" {R}(↓ from {first['accuracy']}%){X}"

        print(f"\n  {B}Learning:{X}")
        print(f"    Spec accuracy:      {latest['accuracy']}%{trend}")
        print(f"    Commits analyzed:   {total_analyzed}")
        print(f"    Learning sessions:  {len(accuracy_history)}")

    print()

    # Knowledge health
    health = min(100, len(facts) * 5)
    filled = int(health / 5)
    bar = f"{'█' * filled}{'░' * (20 - filled)}"
    print(f"  {B}Knowledge Health:{X} [{C}{bar}{X}] {health}%")

    if specs:
        print(f"\n  {B}Recent Specs:{X}")
        for s in sorted(specs, reverse=True)[:5]:
            print(f"    {D}•{X} {s.name}")

    print()


# ─── GAPS ─────────────────────────────────────────────────────

def cmd_gaps(action: str = None, args: list = None):
    """Show project gaps with options to dismiss."""
    project = Project(".")
    require_init(project)

    gaps_file = project.tlm_dir / "gaps.json"
    if not gaps_file.exists():
        print(f"\n{Y}No gaps data found. Run `tlm install` to scan your project.{X}\n")
        return

    gaps_data = json.loads(gaps_file.read_text())
    all_gaps = gaps_data.get("gaps", [])

    if action == "dismiss" and args:
        # Parse gap number
        try:
            num = int(args[0])
        except ValueError:
            print(f"{R}Usage: tlm gaps dismiss <number>{X}")
            return

        if num < 1 or num > len(all_gaps):
            print(f"{R}Invalid gap number. Must be 1-{len(all_gaps)}.{X}")
            return

        gap = all_gaps[num - 1]
        gap["dismissed"] = True

        # Check for --reason
        if "--reason" in args:
            reason_idx = args.index("--reason")
            if reason_idx + 1 < len(args):
                gap["dismiss_reason"] = args[reason_idx + 1]

        gaps_file.write_text(json.dumps(gaps_data, indent=2))
        print(f"{G}✓{X} Gap #{num} dismissed: {D}{gap['description']}{X}\n")
        return

    # Default: list all gaps
    active = [g for g in all_gaps if not g.get("dismissed")]
    dismissed = [g for g in all_gaps if g.get("dismissed")]

    print(f"\n  {B}Project Gaps ({len(active)} active, {len(dismissed)} dismissed){X}\n")

    if not active and not dismissed:
        print(f"  {G}No gaps detected. Nice!{X}\n")
        return

    # Group by severity
    high = [(i, g) for i, g in enumerate(all_gaps, 1) if g.get("severity") == "high" and not g.get("dismissed")]
    medium = [(i, g) for i, g in enumerate(all_gaps, 1) if g.get("severity") == "medium" and not g.get("dismissed")]
    low = [(i, g) for i, g in enumerate(all_gaps, 1) if g.get("severity") == "low" and not g.get("dismissed")]

    if high:
        print(f"  {R}HIGH SEVERITY:{X}")
        for num, gap in high:
            print(f"    {num}. {gap['description']}")
        print()

    if medium:
        print(f"  {Y}MEDIUM SEVERITY:{X}")
        for num, gap in medium:
            print(f"    {num}. {gap['description']}")
        print()

    if low:
        print(f"  {D}LOW SEVERITY:{X}")
        for num, gap in low:
            print(f"    {num}. {gap['description']}")
        print()

    if dismissed:
        print(f"  {D}{len(dismissed)} gap(s) dismissed.{X}\n")

    print(f"  Run {C}tlm gaps dismiss <number>{X} to acknowledge a gap.")
    print(f"  Run {C}tlm gaps dismiss <number> --reason \"handled externally\"{X} to add context.\n")


# ─── LEARN ────────────────────────────────────────────────────

def _run_learning(learner, project: Project, full_history: bool):
    """Execute the learning logic. Returns synthesis dict or None if nothing to do."""
    if full_history:
        try:
            result = subprocess.run(
                ["git", "rev-list", "--count", "HEAD"],
                capture_output=True, text=True, cwd=str(project.root), timeout=5,
            )
            total = int(result.stdout.strip())
        except Exception:
            total = "unknown number of"

        print(f"{C}TLM ▸ Archaeological dig: analyzing {total} commits...{X}")
        print(f"{D}  This will take a while. Getting smart about your project's history.{X}\n")

        def progress(current, total_n, hash_str, summary):
            print(f"  {D}[{current}/{total_n}]{X} {hash_str} — {summary[:60]}")

        return learner.learn_full_history(progress_callback=progress)
    else:
        commit_count = learner.get_commit_count_since_last_session()
        if commit_count == 0:
            print(f"{D}No new commits since last session.{X}\n")
            return None

        print(f"{C}TLM ▸ Analyzing {commit_count} commits since last session...{X}\n")

        def progress(current, total_n, hash_str, summary):
            print(f"  {D}[{current}/{total_n}]{X} {hash_str} — {summary[:60]}")

        return learner.learn_since_last_session(progress_callback=progress)


def cmd_learn(full_history: bool = False):
    """Analyze git commits and extract lessons."""
    logo()
    project = Project(".")
    require_init(project)
    claude, api_client, project_id = _get_backend(project)

    from tlm.learner import Learner
    learner = Learner(project, claude, api_client=api_client, project_id=project_id)

    # Lockfile for background detection
    lockfile = project.tlm_dir / "learn.lock"
    lockfile.write_text(str(os.getpid()))

    try:
        synthesis = _run_learning(learner, project, full_history)
    finally:
        if lockfile.exists():
            lockfile.unlink()

    if synthesis is None:
        return

    if synthesis.get("total_commits", 0) == 0:
        print(f"\n{D}Nothing to learn from.{X}\n")
        return

    # Display full results
    accuracy = synthesis.get("spec_accuracy_percent", "?")
    print(f"\n{'='*60}")
    print(f"  {B}Learning Report{X}")
    print(f"{'='*60}\n")

    print(f"  Commits analyzed:  {synthesis.get('total_commits', 0)}")
    print(f"  Planned work:      {synthesis.get('planned_commits', 0)}")
    print(f"  Unplanned work:    {synthesis.get('unplanned_commits', 0)}")
    print(f"  Spec accuracy:     {accuracy}%")

    for bp in synthesis.get("bug_patterns", []):
        print(f"\n  {R}Bug Pattern: {bp.get('pattern')}{X} ({bp.get('frequency', '?')}x, {bp.get('severity', '?')} severity)")
        print(f"  {D}{bp.get('lesson', '')}{X}")
        for q in bp.get("interview_questions", []):
            print(f"    {C}→{X} {q}")

    for uf in synthesis.get("unplanned_features", []):
        print(f"\n  {Y}Unplanned: {uf.get('what')}{X}")
        print(f"  {D}{uf.get('lesson', '')}{X}")

    for ae in synthesis.get("architecture_evolutions", []):
        print(f"\n  {P}Evolution: {ae.get('what')}{X}")
        print(f"  {D}{ae.get('lesson', '')}{X}")

    improvements = synthesis.get("interview_improvements", [])
    if improvements:
        print(f"\n  {B}Future Interview Improvements:{X}")
        for imp in improvements:
            print(f"    {G}→{X} {imp}")

    print(f"\n{G}✓ Lessons saved to knowledge base.{X}")
    print(f"{D}  These will be injected into your next `tlm build` interview.{X}\n")


# ─── RULES ────────────────────────────────────────────────────

def cmd_rules(action: str = None, args: list = None):
    """Manage TLM rules from knowledge.db."""
    project = Project(".")
    require_init(project)

    db = project.knowledge_db
    db.init_db()

    if action == "disable" and args:
        try:
            rule_id = int(args[0])
        except ValueError:
            print(f"{R}Usage: tlm rules disable <id>{X}")
            return
        rule = db.get_rule(rule_id)
        if not rule:
            print(f"{R}Rule #{rule_id} not found.{X}")
            return
        db.disable_rule(rule_id)
        print(f"{G}✓{X} Rule #{rule_id} disabled: {D}{rule['rule_text'][:60]}{X}\n")
        return

    if action == "enable" and args:
        try:
            rule_id = int(args[0])
        except ValueError:
            print(f"{R}Usage: tlm rules enable <id>{X}")
            return
        db.enable_rule(rule_id)
        print(f"{G}✓{X} Rule #{rule_id} enabled.\n")
        return

    if action == "add" and args:
        rule_text = " ".join(args)
        # Try to get embedding from server
        embedding = None
        client = get_client()
        if client:
            try:
                result = client.embed([rule_text])
                vectors = result.get("vectors", [])
                if vectors:
                    embedding = vectors[0]
            except Exception:
                pass  # Server unreachable or embedding unavailable

        rule_id = db.add_rule(rule_text, source="user_added", embedding=embedding)
        print(f"{G}✓{X} Rule #{rule_id} added: {rule_text[:60]}")
        if embedding:
            print(f"  {D}(with embedding for vector search){X}")
        print()
        return

    # Default: list all rules
    rules = db.list_rules(include_disabled=True)
    if not rules:
        print(f"\n{Y}No rules yet. They'll be created automatically as TLM learns from your project.{X}")
        print(f"{D}  Or add manually: tlm rules add \"Always write tests before implementation\"{X}\n")
        return

    print(f"\n  {B}TLM Rules ({len(rules)}):{X}\n")
    for r in rules:
        status = f"{G}active{X}" if r["approved"] else f"{R}disabled{X}"
        source = r.get("source", "unknown")
        tags = r.get("relevance_tags", [])
        tags_str = f" {D}[{', '.join(tags)}]{X}" if tags else ""

        print(f"  {C}#{r['id']}{X} [{status}] {r['rule_text'][:70]}")
        print(f"     {D}source: {source}{tags_str}{X}")

    print(f"\n  {D}Commands: tlm rules add \"...\", tlm rules disable <id>, tlm rules enable <id>{X}\n")


# ─── CONFIG ───────────────────────────────────────────────────

def cmd_config(action: str = None, args: list = None):
    """Manage TLM configuration."""
    project = Project(".")
    require_init(project)
    config = project.get_config()

    if action == "quality" and args:
        level = args[0].lower()
        if level not in ("high", "standard", "relaxed"):
            print(f"{R}Usage: tlm config quality <high|standard|relaxed>{X}")
            return
        config["quality_control"] = level
        project.config_file.write_text(json.dumps(config, indent=2))
        print(f"{G}✓{X} Quality control set to {B}{level}{X}\n")

        if level == "high":
            print(f"  {D}Spec gate: blocks  |  Commit review: blocks on issues{X}")
            print(f"  {D}Deployment gate: always blocks  |  Mechanical checks: always{X}")
        elif level == "standard":
            print(f"  {D}Spec gate: blocks  |  Commit review: warns on issues{X}")
            print(f"  {D}Deployment gate: always blocks  |  Mechanical checks: always{X}")
        else:
            print(f"  {D}Spec gate: blocks  |  Commit review: skipped{X}")
            print(f"  {D}Deployment gate: always blocks  |  Mechanical checks: always{X}")
        print()
        return

    if action == "session-learning" and args:
        value = args[0].lower()
        if value not in ("on", "off"):
            print(f"{R}Usage: tlm config session-learning <on|off>{X}")
            return
        config["session_learning"] = value == "on"
        project.config_file.write_text(json.dumps(config, indent=2))
        print(f"{G}✓{X} Session learning {'enabled' if value == 'on' else 'disabled'}.\n")
        return

    # Default: show config
    print(f"\n  {B}TLM Configuration:{X}\n")
    print(f"  {C}Project:{X}           {config.get('project_name', 'unknown')}")
    print(f"  {C}Quality control:{X}   {config.get('quality_control', 'standard')}")
    print(f"  {C}Session learning:{X}  {'on' if config.get('session_learning', True) else 'off'}")
    print(f"  {C}Sessions used:{X}     {config.get('sessions_used', 0)}")
    print(f"  {C}Commits analyzed:{X}  {config.get('total_commits_analyzed', 0)}")

    accuracy_history = config.get("spec_accuracy_history", [])
    if accuracy_history:
        latest = accuracy_history[-1]
        print(f"  {C}Spec accuracy:{X}    {latest['accuracy']}%")

    print(f"\n  {D}Commands: tlm config quality <high|standard|relaxed>{X}")
    print(f"  {D}          tlm config session-learning <on|off>{X}\n")


# ─── HISTORY ──────────────────────────────────────────────────

def cmd_history():
    """Show spec accuracy history from metrics."""
    project = Project(".")
    require_init(project)

    db = project.knowledge_db
    db.init_db()

    metrics = db.list_metrics(limit=20)
    if not metrics:
        print(f"\n{Y}No metrics yet. Run `tlm learn` to start tracking spec accuracy.{X}\n")
        return

    print(f"\n  {B}Spec Accuracy History:{X}\n")
    for m in reversed(metrics):
        accuracy = m.get("spec_accuracy", 0)
        total = m.get("total_commits", 0)
        planned = m.get("planned_commits", 0)
        unplanned = m.get("unplanned_commits", 0)
        bugs = m.get("bugs_caught_by_review", 0)
        week = m.get("week_number", "?")

        bar_len = int(accuracy / 5)
        bar = f"{'█' * bar_len}{'░' * (20 - bar_len)}"
        color = G if accuracy >= 70 else (Y if accuracy >= 40 else R)

        print(f"  {D}{week}{X}  [{color}{bar}{X}] {accuracy}%  "
              f"{D}({total} commits: {planned} planned, {unplanned} unplanned"
              f"{f', {bugs} bugs caught' if bugs else ''}){X}")

    print()


# ─── MIGRATE ─────────────────────────────────────────────────

def cmd_migrate():
    """Migrate v0.1.x flat files to SQLite knowledge.db."""
    logo()
    project = Project(".")
    if not project.initialized:
        print(f"{R}✗ Not a TLM project. Run `tlm install` first.{X}\n")
        sys.exit(1)

    from tlm.knowledge_db import KnowledgeDB
    db = KnowledgeDB(str(project.tlm_dir))
    db.init_db()

    # Check if already migrated
    existing_rules = db.list_rules()
    if existing_rules:
        print(f"{Y}Knowledge.db already has {len(existing_rules)} rules.{X}")
        print(f"{D}  Re-running migration will add new items only (no duplicates).{X}\n")

    imported = db.migrate_from_flat_files()
    db.close()

    total = sum(imported.values())
    if total == 0:
        print(f"{D}No flat files to migrate. Knowledge.db is up to date.{X}\n")
        return

    print(f"\n{G}✓ Migration complete:{X}")
    if imported.get("rules"):
        print(f"  Rules imported:   {imported['rules']}")
    if imported.get("specs"):
        print(f"  Specs imported:   {imported['specs']}")
    if imported.get("commits"):
        print(f"  Commits imported: {imported['commits']}")
    if imported.get("metrics"):
        print(f"  Metrics imported: {imported['metrics']}")
    print(f"\n{D}  Review with `tlm rules` and `tlm history`.{X}\n")


# ─── UPGRADE ──────────────────────────────────────────────────

def cmd_upgrade():
    """Open upgrade URL in browser."""
    import webbrowser
    url = "https://tlmforge.dev/#pricing"
    print(f"\n{C}Opening upgrade page...{X}")
    print(f"  {D}{url}{X}\n")
    webbrowser.open(url)


# ─── SPECS ─────────────────────────────────────────────────────

def cmd_specs():
    project = Project(".")
    require_init(project)

    specs = sorted(project.specs_dir.glob("*.md"), reverse=True)
    if not specs:
        print(f"\n{Y}No specs yet. Run `tlm build \"feature\"` to create one.{X}\n")
        return

    print(f"\n  {B}Generated Specs:{X}\n")
    for s in specs:
        title = s.read_text().split("\n")[0]
        size = len(s.read_text().split("\n"))
        print(f"  {C}•{X} {s.name} {D}({size} lines){X}")
        print(f"    {D}{title}{X}")
    print()


# ─── GIT HOOKS ─────────────────────────────────────────────────

PRE_COMMIT_HOOK = """#!/bin/sh
# TLM Pre-Commit Quality Gate
echo ""
echo "\\033[36mTLM ▸ Pre-commit quality gate...\\033[0m"
echo ""

if ! command -v tlm &> /dev/null; then
    echo "\\033[33m⚠ TLM not found in PATH. Skipping.\\033[0m"
    exit 0
fi

# Check for TLM server auth OR Anthropic key
if [ -z "$ANTHROPIC_API_KEY" ] && [ ! -f "$HOME/.tlm/credentials.json" ]; then
    echo "\\033[33m⚠ Not authenticated. Skipping TLM check.\\033[0m"
    exit 0
fi

if [ ! -f ".tlm/enforcement.json" ]; then
    echo "\\033[2mNo enforcement config. Skipping.\\033[0m"
    exit 0
fi

tlm check
exit $?
"""


POST_COMMIT_HOOK = """#!/bin/sh
# TLM Post-Commit Learner — analyzes commits in background
# This runs silently after every commit. Never blocks git.

if ! command -v tlm &> /dev/null; then
    exit 0
fi

if [ ! -d ".tlm" ]; then
    exit 0
fi

# Check for TLM server auth OR Anthropic key
if [ -z "$ANTHROPIC_API_KEY" ] && [ ! -f "$HOME/.tlm/credentials.json" ]; then
    exit 0
fi

# Run analysis in background — never block the developer
nohup tlm _analyze-last-commit > /dev/null 2>&1 &
"""


def _cmd_analyze_last_commit():
    """Internal command for post-commit hook. Silently analyzes the last commit."""
    try:
        project = Project(".")
        if not project.initialized:
            return

        client = get_client()
        if not client:
            return

        project_id = None
        if project.config_file.exists():
            try:
                config = json.loads(project.config_file.read_text())
                project_id = config.get("project_id")
            except (json.JSONDecodeError, OSError):
                pass

        from tlm.learner import Learner
        learner = Learner(project, api_client=client, project_id=project_id)
        learner.learn_last_commit()
    except Exception:
        pass  # Never crash, never block git


def _install_hook(hooks_dir: Path, hook_name: str, hook_content: str, description: str):
    """Install a single git hook with backup."""
    hook_path = hooks_dir / hook_name

    if hook_path.exists():
        existing = hook_path.read_text()
        if "TLM" in existing:
            print(f"  {Y}{hook_name} already installed.{X}")
            return
        backup = hooks_dir / f"{hook_name}.backup"
        hook_path.rename(backup)
        print(f"  {D}Existing {hook_name} backed up → {backup}{X}")

    hook_path.write_text(hook_content)
    hook_path.chmod(hook_path.stat().st_mode | stat.S_IEXEC)
    print(f"  {G}✓{X} {hook_name} installed — {description}")


def _uninstall_hook(hooks_dir: Path, hook_name: str):
    """Uninstall a single git hook with backup restore."""
    hook_path = hooks_dir / hook_name
    if hook_path.exists() and "TLM" in hook_path.read_text():
        hook_path.unlink()
        backup = hooks_dir / f"{hook_name}.backup"
        if backup.exists():
            backup.rename(hook_path)
        print(f"  {G}✓{X} {hook_name} removed.")
        return True
    return False


def cmd_hook(action: str):
    project = Project(".")
    git_dir = project.root / ".git"

    if not git_dir.exists():
        print(f"{R}✗ Not a git repository.{X}\n")
        sys.exit(1)

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)

    if action == "install":
        print(f"\n{Y}Note: `tlm hook install` is deprecated. Use `tlm install` instead.{X}")
        print(f"{D}  `tlm install` sets up everything: CLAUDE.md, Claude Code hooks, and git hooks.{X}\n")
        _install_hook(hooks_dir, "pre-commit", PRE_COMMIT_HOOK,
                       "runs `tlm check` before every commit")
        _install_hook(hooks_dir, "post-commit", POST_COMMIT_HOOK,
                       "analyzes commits in background for learning")
        print(f"\n{G}✓{X} Git hooks installed.\n")

    elif action == "uninstall":
        print(f"\n{Y}Note: `tlm hook uninstall` is deprecated. Use `tlm uninstall` instead.{X}\n")
        removed_pre = _uninstall_hook(hooks_dir, "pre-commit")
        removed_post = _uninstall_hook(hooks_dir, "post-commit")
        if removed_pre or removed_post:
            print(f"\n{G}✓{X} TLM hooks removed.\n")
        else:
            print(f"{Y}No TLM hooks found.{X}\n")
    else:
        print(f"{R}Usage: tlm hook [install|uninstall]{X}\n")


# ─── INSTALL / UNINSTALL ─────────────────────────────────────

def _validate_install_directory() -> Path:
    """Validate CWD is a suitable project directory for TLM installation."""
    cwd = Path.cwd().resolve()

    # 1. Must be a git repo
    if not (cwd / ".git").exists():
        print(f"{R}✗ Not a git repository.{X}")
        print(f"  {D}TLM must be installed in a git project root.{X}")
        print(f"  {D}Current directory: {cwd}{X}\n")
        sys.exit(1)

    # 2. Warn if Claude Code not detected (but don't block — user might install it after)
    has_claude = (cwd / ".claude").exists()
    if not has_claude:
        print(f"{Y}⚠ Claude Code not detected in this directory.{X}")
        print(f"  {D}TLM works best with Claude Code. Run `claude` here first to initialize it.{X}\n")

    # 3. Confirm directory with user
    print(f"  {B}Directory:{X} {cwd}")
    print(f"  {B}Project:{X}   {cwd.name}\n")
    try:
        answer = input(f"  Install TLM here? (Y/n): ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print(f"\n{Y}Cancelled.{X}\n")
        sys.exit(1)

    if answer and answer not in ("y", "yes"):
        print(f"\n{Y}Cancelled. cd to your project directory and run `tlm install` again.{X}\n")
        sys.exit(1)

    return cwd


def cmd_install():
    """Full TLM installation: scan + approve config + install hooks + CLAUDE.md."""
    logo()
    _validate_install_directory()

    # Auto-run auth if not authenticated
    if not get_client():
        print(f"{Y}Not authenticated yet. Let's fix that first.{X}\n")
        cmd_auth()
        # Verify auth succeeded
        if not get_client():
            return

    project = Project(".")
    project.init()
    claude, api_client, project_id = _get_backend(project)

    # ── Phase 1: Scan project ────────────────────────────────────
    # Check for cached scan (< 10 min old) to support retry after config gen failure
    profile = None
    try:
        profile_file = project.tlm_dir / "profile.md"
        if profile_file.exists():
            age_seconds = time.time() - profile_file.stat().st_mtime
            if age_seconds < 600:  # 10 minutes
                profile = profile_file.read_text()
                if profile and profile.strip():
                    print(f"{C}TLM ▸ Using recent scan results (cached {int(age_seconds)}s ago){X}\n")
                else:
                    profile = None
    except (OSError, TypeError, ValueError):
        profile = None

    if profile is None:
        print(f"{C}TLM ▸ Scanning your project...{X}\n")
        scanner = Scanner(project, claude, api_client=api_client, project_id=project_id)
        try:
            with Spinner([
                "Scanning files...",
                "Running local analysis...",
                "Analyzing with AI (this can take a minute)...",
                "Combining results...",
            ]):
                profile = scanner.scan()
        except Exception as e:
            logger.error("Scan failed: %s", e, exc_info=True)
            _report_error(api_client, project_id, e, context="install:scan")
            print(f"\n{R}✗ {_friendly_error(str(e))}{X}\n")
            return

    # Extract and save gaps
    _save_gaps_from_profile(project, profile)

    print(f"{G}✓{X} Project scanned\n")
    _display_scan_summary(profile)
    print()

    # ── Phase 2: Generate enforcement config ─────────────────────
    print(f"{C}TLM ▸ Generating enforcement rules...{X}\n")
    config_gen = ConfigGenerator(project, claude, api_client=api_client, project_id=project_id)
    try:
        with Spinner(["Generating enforcement config..."]):
            config = config_gen.generate()
    except Exception as e:
        logger.error("Config generation failed: %s", e, exc_info=True)
        _report_error(api_client, project_id, e, context="install:generate_config")
        print(f"\n{R}✗ {_friendly_error(str(e))}{X}")
        print(f"{D}  Your project scan was saved. Run `tlm install` again to retry.{X}\n")
        return

    # ── Phase 3: Interactive approval ────────────────────────────
    _interactive_config_approval(config_gen, config, project)

    # ── Phase 4: Install hooks + CLAUDE.md ───────────────────────
    if project.enforcement.approved:
        print(f"\n{C}TLM ▸ Installing Claude Code integration...{X}\n")
        try:
            from tlm.installer import Installer
            installer = Installer(".")
            installer.install()

            print(f"  {G}✓{X} CLAUDE.md generated with TLM rules")
            print(f"  {G}✓{X} Claude Code hooks installed (.claude/settings.json)")
            print(f"  {G}✓{X} Git post-commit hook installed (passive learning)")
            print(f"  {G}✓{X} State initialized (.tlm/state.json)")
        except Exception as e:
            logger.error("Hook installation failed: %s", e, exc_info=True)
            _report_error(api_client, project_id, e, context="install:hooks")
            print(f"\n{R}✗ Failed to install hooks: {_friendly_error(str(e))}{X}")
            print(f"{D}  Your config is saved. Run `tlm install` again to retry hook setup.{X}\n")
            return

    # ── Phase 5: Archaeological dig — auto-background analysis ───
    _start_background_analysis(project)

    print(f"""
{G}{'='*60}{X}
  {B}TLM is now installed.{X}
{G}{'='*60}{X}

  TLM is now an invisible layer inside Claude Code.
  Open Claude Code and start working — TLM activates automatically
  on any significant engineering activity.

  {B}What happens now:{X}
  - Ask to build a feature → TLM interviews you first
  - Ask about readiness → TLM does thorough assessment
  - Write code → TLM enforces TDD
  - Commit code → TLM checks spec compliance
  - Every commit → TLM learns in background

  {B}Manual commands (still available):{X}
  - {C}tlm check{X}      — Run quality gate manually
  - {C}tlm learn{X}      — Trigger learning manually
  - {C}tlm status{X}     — See project status
  - {C}tlm uninstall{X}  — Remove TLM integration
""")


def cmd_uninstall():
    """Remove TLM integration from project."""
    logo()

    project = Project(".")
    if not project.initialized:
        print(f"{Y}No TLM installation found.{X}\n")
        return

    from tlm.installer import Installer
    installer = Installer(".")
    installer.uninstall()

    # Wipe .tlm/ completely — fresh start on next install
    import shutil
    shutil.rmtree(project.tlm_dir, ignore_errors=True)

    print(f"  {G}✓{X} TLM rules removed from CLAUDE.md")
    print(f"  {G}✓{X} Claude Code hooks removed")
    print(f"  {G}✓{X} Git hooks removed")
    print(f"  {G}✓{X} Project data removed (.tlm/)")
    print(f"\n  {D}Run `tlm install` to start fresh.{X}\n")


# ─── AUTH ─────────────────────────────────────────────────────

def cmd_auth(api_key: str = None, base_url: str = None):
    """Authenticate with TLM — manual key or interactive web flow."""

    # Manual key: tlm auth <key>
    if api_key:
        if not api_key.startswith("tlm_sk_"):
            print(f"{R}✗ Invalid API key format. Keys start with 'tlm_sk_'{X}")
            sys.exit(1)
        save_credentials(api_key, base_url=base_url)
        print(f"{G}✓{X} API key saved to ~/.tlm/credentials.json")
        if base_url:
            print(f"  Server URL: {C}{base_url}{X}")
        print(f"{D}  You're authenticated. Run `tlm install` in your project.{X}\n")
        return

    # Interactive: tlm auth
    server_url = base_url or DEFAULT_BASE_URL

    # Already authenticated?
    client = get_client()
    if client:
        try:
            user_info = client.me()
            print(f"{G}✓{X} Already authenticated as {C}{user_info['email']}{X}")
            print(f"  Run {C}tlm logout{X} first to switch accounts.\n")
            return
        except Exception:
            pass  # stale creds, proceed to re-auth

    # Print URL + prompt for paste
    auth_url = "https://tlmforge.dev/auth"
    print(f"\n{C}TLM ▸ Authentication{X}\n")
    print(f"  Get your API key at: {B}{auth_url}{X}\n")

    try:
        token = input(f"  Paste your API key: ").strip()
    except (KeyboardInterrupt, EOFError):
        print(f"\n{Y}Cancelled.{X}\n")
        sys.exit(1)

    if token.startswith("tlm_sk_"):
        # Direct API key paste
        key = token
    elif _is_firebase_token(token):
        # Firebase ID token — exchange for TLM API key
        print(f"\n{D}  Exchanging token...{X}")
        exchange_client = TLMClient(api_key="", base_url=server_url)
        try:
            result = exchange_client.exchange_firebase_token(token)
            key = result["api_key"]
            email = result.get("email", "")
            if email:
                print(f"  {G}✓{X} Signed in as {C}{email}{X}")
        except (TLMServerError, TLMConnectionError, TLMAuthError) as e:
            print(f"{R}✗ Token exchange failed: {e}{X}")
            sys.exit(1)
    else:
        print(f"{R}✗ Invalid API key. Visit {auth_url} to get your key.{X}")
        sys.exit(1)

    save_credentials(key, base_url=server_url)
    print(f"\n{G}✓{X} API key saved to ~/.tlm/credentials.json")

    # Verify
    new_client = TLMClient(api_key=key, base_url=server_url)
    try:
        user_info = new_client.me()
        print(f"  Authenticated as {C}{user_info['email']}{X}")
    except Exception:
        print(f"  {D}Key saved. Could not verify (server may be unreachable).{X}")

    print(f"\n{D}  Run `tlm install` in your project to get started.{X}\n")


def cmd_logout():
    """Remove saved credentials."""
    cred_file = Path(DEFAULT_CREDENTIALS_DIR) / "credentials.json"
    if cred_file.exists():
        cred_file.unlink()
        print(f"{G}✓{X} Logged out. Credentials removed.")
        print(f"  Run {C}tlm auth{X} to sign in again.\n")
    else:
        print(f"{Y}Not logged in.{X}\n")


def cmd_signup():
    """Deprecated — redirects to cmd_auth."""
    print(f"\n{Y}Note: `tlm signup` is deprecated. Use `tlm auth` instead.{X}")
    print(f"{D}  `tlm auth` opens a web page for Google/email sign-up.{X}\n")
    cmd_auth()


# ─── HOOK HANDLERS ───────────────────────────────────────────

def _cmd_hook(hook_name: str):
    """Internal hook handler called by Claude Code hook scripts."""
    from tlm.hooks import (
        hook_session_start, hook_prompt_submit, hook_guard,
        hook_compliance_gate, hook_deployment_gate, hook_stop,
    )

    if hook_name == "session":
        # SessionStart: print context to stdout
        result = hook_session_start(".")
        print(result)

    elif hook_name == "prompt":
        # UserPromptSubmit: read stdin, return JSON to stdout
        try:
            stdin_data = json.loads(sys.stdin.read())
        except Exception:
            stdin_data = {}
        prompt_text = stdin_data.get("prompt", "")
        result = hook_prompt_submit(".", prompt_text=prompt_text)
        print(json.dumps(result))

    elif hook_name == "guard":
        # PreToolUse (Write/Edit): read tool input from stdin, return JSON
        try:
            stdin_data = json.loads(sys.stdin.read())
        except Exception:
            stdin_data = {}
        result = hook_guard(".", stdin_data)
        if result:
            print(json.dumps(result))

    elif hook_name == "compliance":
        # PreToolUse (Bash): check for git commit, inject compliance reminder
        try:
            stdin_data = json.loads(sys.stdin.read())
            tool_input = stdin_data.get("tool_input", stdin_data)
        except Exception:
            tool_input = {}
        result = hook_compliance_gate(".", tool_input)
        if result:
            print(json.dumps(result))

    elif hook_name == "deployment":
        # PreToolUse (Bash): block deploy commands
        try:
            stdin_data = json.loads(sys.stdin.read())
            tool_input = stdin_data.get("tool_input", stdin_data)
        except Exception:
            tool_input = {}
        result = hook_deployment_gate(".", tool_input)
        if result:
            print(json.dumps(result))

    elif hook_name == "stop":
        # Stop: session learning when Claude session ends
        try:
            stdin_data = json.loads(sys.stdin.read())
        except Exception:
            stdin_data = {}
        transcript_path = stdin_data.get("transcript_path", "")
        result = hook_stop(".", transcript_path=transcript_path)
        if result:
            print(json.dumps(result))

    else:
        sys.exit(1)


# ─── MAIN ─────────────────────────────────────────────────────

def _setup_file_logging():
    """Route all CLI logging to .tlm/cli.log. Never prints to terminal."""
    tlm_dir = Path.cwd() / ".tlm"
    if not tlm_dir.is_dir():
        return
    try:
        handler = logging.FileHandler(str(tlm_dir / "cli.log"), encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
    except OSError:
        pass  # Read-only fs, permissions, etc.


def main():
    _cleanup_stale_pip_script()
    _setup_file_logging()
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print(__doc__)
        return

    cmd = args[0]

    try:
        _dispatch(cmd, args)
    except KeyboardInterrupt:
        print(f"\n{Y}Interrupted.{X}")
        sys.exit(130)
    except TLMCreditsError as e:
        detail = e.args[0] if e.args else {}
        tier = detail.get("tier", "free") if isinstance(detail, dict) else "free"
        print(f"\n{R}You've used all {tier} credits.{X}")
        print(f"{D}Check your usage with: tlm status{X}\n")
        sys.exit(1)
    except TLMProjectLimitError as e:
        detail = e.args[0] if e.args else {}
        if isinstance(detail, dict):
            max_allowed = detail.get("max_allowed", 1)
            tier = detail.get("tier", "free")
        else:
            max_allowed = 1
            tier = "free"
        print(f"\n{R}Project limit reached. Your {tier} plan allows {max_allowed} project(s).{X}")
        print(f"{D}Run 'tlm status' to see your current usage.{X}\n")
        sys.exit(1)
    except TLMAuthError as e:
        print(f"\n{R}Authentication failed.{X}")
        print(f"{D}Run 'tlm auth' to sign in again.{X}\n")
        sys.exit(1)
    except TLMConnectionError:
        print(f"\n{R}Cannot reach TLM server.{X}")
        print(f"{D}Check your connection and try again.{X}\n")
        sys.exit(1)
    except TLMServerError as e:
        msg = str(e)
        # Extract just the useful part from "Server error (500): ..."
        if ": " in msg:
            msg = msg.split(": ", 1)[1]
        print(f"\n{R}{_friendly_error(msg)}{X}")
        print(f"{D}If this persists, check 'tlm status' or try again later.{X}\n")
        sys.exit(1)
    except Exception as e:
        logger.error("Unexpected error: %s", e, exc_info=True)
        print(f"\n{R}Something went wrong. Please try again.{X}")
        print(f"{D}Run with TLM_DEBUG=1 for full details.{X}\n")
        if os.environ.get("TLM_DEBUG"):
            import traceback
            traceback.print_exc()
        sys.exit(1)


def _dispatch(cmd, args):
    """Dispatch CLI commands."""
    # ─── New commands ─────────────────────────────
    if cmd == "auth":
        auth_url = None
        auth_key = None
        if "--url" in args:
            url_idx = args.index("--url")
            if url_idx + 1 < len(args):
                auth_url = args[url_idx + 1]
        # Find the API key (first non-flag arg after "auth")
        for a in args[1:]:
            if a == "--url":
                break
            if not a.startswith("--"):
                auth_key = a
                break
        cmd_auth(api_key=auth_key, base_url=auth_url)
    elif cmd == "logout":
        cmd_logout()
    elif cmd == "signup":
        cmd_signup()
    elif cmd == "install":
        cmd_install()
    elif cmd == "uninstall":
        cmd_uninstall()
    elif cmd == "_hook":
        if len(args) < 2:
            sys.exit(1)
        _cmd_hook(args[1])

    # ─── New v2 commands ─────────────────────────
    elif cmd == "rules":
        action = args[1] if len(args) > 1 else None
        extra = args[2:] if len(args) > 2 else []
        cmd_rules(action=action, args=extra)
    elif cmd == "gaps":
        action = args[1] if len(args) > 1 else None
        extra = args[2:] if len(args) > 2 else []
        cmd_gaps(action=action, args=extra)
    elif cmd == "config":
        action = args[1] if len(args) > 1 else None
        extra = args[2:] if len(args) > 2 else []
        cmd_config(action=action, args=extra)
    elif cmd == "history":
        cmd_history()
    elif cmd == "upgrade":
        cmd_upgrade()
    elif cmd == "migrate":
        cmd_migrate()

    # ─── Preserved commands ───────────────────────
    elif cmd == "check":
        cmd_check(args[1] if len(args) > 1 else None)
    elif cmd == "status":
        cmd_status()
    elif cmd == "specs":
        cmd_specs()
    elif cmd == "learn":
        full = "--all" in args or "--full" in args
        cmd_learn(full_history=full)
    elif cmd == "_analyze-last-commit":
        _cmd_analyze_last_commit()

    # ─── Deprecated commands (still work) ─────────
    elif cmd == "init":
        print(f"\n{Y}Note: `tlm init` is deprecated. Use `tlm install` instead.{X}")
        print(f"{D}  `tlm install` does everything init does, plus installs Claude Code hooks.{X}\n")
        cmd_install()
    elif cmd == "build":
        print(f"\n{Y}Note: `tlm build` is deprecated.{X}")
        print(f"{D}  Use `tlm install` then work in Claude Code directly.{X}")
        print(f"{D}  TLM now activates automatically on significant engineering activities.{X}\n")
        if len(args) < 2:
            print(f'{R}Usage: tlm build "feature description"{X}')
            sys.exit(1)
        cmd_build(" ".join(args[1:]).strip("\"'"))
    elif cmd == "hook":
        if len(args) < 2:
            print(f"{R}Usage: tlm hook [install|uninstall]{X}")
            sys.exit(1)
        cmd_hook(args[1])

    else:
        print(f"{R}Unknown command: {cmd}{X}")
        print(f"{D}Run `tlm --help` for usage.{X}")
        sys.exit(1)


if __name__ == "__main__":
    main()
