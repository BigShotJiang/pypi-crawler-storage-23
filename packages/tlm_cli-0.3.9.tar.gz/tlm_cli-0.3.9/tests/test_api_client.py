"""
Tests for TLM API Client — HTTP client for TLM server.

Uses unittest.mock to mock httpx calls. Tests all endpoint methods,
auth header injection, error handling, timeout behavior, and credential management.
"""

import json
import os
from pathlib import Path
from unittest.mock import patch, MagicMock, PropertyMock

import pytest

from tlm.api_client import (
    TLMClient,
    TLMAuthError,
    TLMServerError,
    TLMConnectionError,
    load_credentials,
    save_credentials,
    get_client,
)


# ─── Fixtures ─────────────────────────────────────────────────

@pytest.fixture
def credentials_dir(tmp_path):
    """Temporary directory for credentials."""
    cred_dir = tmp_path / ".tlm"
    cred_dir.mkdir()
    return cred_dir


@pytest.fixture
def mock_response():
    """Create a mock httpx response."""
    def _make(status_code=200, json_data=None, text=""):
        resp = MagicMock()
        resp.status_code = status_code
        resp.json.return_value = json_data or {}
        resp.text = text or json.dumps(json_data or {})
        resp.is_success = 200 <= status_code < 300
        resp.raise_for_status = MagicMock()
        if status_code >= 400:
            import httpx
            resp.raise_for_status.side_effect = httpx.HTTPStatusError(
                "error", request=MagicMock(), response=resp
            )
        return resp
    return _make


@pytest.fixture
def client():
    """Create a TLMClient with test credentials."""
    return TLMClient(api_key="tlm_sk_test123", base_url="https://api.test.tlmforge.dev")


# ─── Credential Management Tests ─────────────────────────────

class TestCredentials:
    def test_save_credentials(self, credentials_dir):
        cred_file = credentials_dir / "credentials.json"
        save_credentials("tlm_sk_abc123", credentials_dir=str(credentials_dir))
        assert cred_file.exists()
        data = json.loads(cred_file.read_text())
        assert data["api_key"] == "tlm_sk_abc123"

    def test_load_credentials(self, credentials_dir):
        cred_file = credentials_dir / "credentials.json"
        cred_file.write_text(json.dumps({"api_key": "tlm_sk_loaded"}))
        key = load_credentials(credentials_dir=str(credentials_dir))
        assert key == "tlm_sk_loaded"

    def test_load_credentials_missing_file(self, credentials_dir):
        key = load_credentials(credentials_dir=str(credentials_dir))
        assert key is None

    def test_load_credentials_corrupted(self, credentials_dir):
        cred_file = credentials_dir / "credentials.json"
        cred_file.write_text("not json")
        key = load_credentials(credentials_dir=str(credentials_dir))
        assert key is None

    def test_save_credentials_creates_dir(self, tmp_path):
        cred_dir = tmp_path / "nonexistent" / ".tlm"
        save_credentials("tlm_sk_new", credentials_dir=str(cred_dir))
        assert (cred_dir / "credentials.json").exists()

    def test_save_overwrite(self, credentials_dir):
        save_credentials("tlm_sk_first", credentials_dir=str(credentials_dir))
        save_credentials("tlm_sk_second", credentials_dir=str(credentials_dir))
        key = load_credentials(credentials_dir=str(credentials_dir))
        assert key == "tlm_sk_second"

    def test_save_preserves_other_fields(self, credentials_dir):
        cred_file = credentials_dir / "credentials.json"
        cred_file.write_text(json.dumps({"api_key": "old", "base_url": "https://custom.url"}))
        save_credentials("tlm_sk_new", credentials_dir=str(credentials_dir))
        data = json.loads(cred_file.read_text())
        assert data["api_key"] == "tlm_sk_new"
        assert data["base_url"] == "https://custom.url"


# ─── Client Construction Tests ────────────────────────────────

class TestClientConstruction:
    def test_creates_with_api_key(self):
        client = TLMClient(api_key="tlm_sk_test")
        assert client.api_key == "tlm_sk_test"

    def test_default_base_url(self):
        from tlm.api_client import DEFAULT_BASE_URL
        client = TLMClient(api_key="tlm_sk_test")
        assert client.base_url == DEFAULT_BASE_URL

    def test_custom_base_url(self):
        client = TLMClient(api_key="tlm_sk_test", base_url="https://custom.api.com")
        assert client.base_url == "https://custom.api.com"

    def test_get_client_with_saved_credentials(self, credentials_dir):
        save_credentials("tlm_sk_saved", credentials_dir=str(credentials_dir))
        client = get_client(credentials_dir=str(credentials_dir))
        assert client is not None
        assert client.api_key == "tlm_sk_saved"

    def test_get_client_no_credentials(self, credentials_dir):
        client = get_client(credentials_dir=str(credentials_dir))
        assert client is None


# ─── Auth Header Tests ────────────────────────────────────────

class TestAuthHeaders:
    def test_auth_header_included(self, client):
        headers = client._headers()
        assert "Authorization" in headers
        assert headers["Authorization"] == "Bearer tlm_sk_test123"

    def test_content_type_json(self, client):
        headers = client._headers()
        assert headers.get("Content-Type") == "application/json"

    def test_no_auth_header_when_api_key_empty(self):
        """TLMClient(api_key='') must NOT send Authorization header."""
        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        headers = c._headers()
        assert "Authorization" not in headers

    def test_no_auth_header_when_api_key_none(self):
        """TLMClient(api_key=None) must NOT send Authorization header."""
        c = TLMClient(api_key=None, base_url="https://test.tlmforge.dev")
        headers = c._headers()
        assert "Authorization" not in headers

    @patch("tlm.api_client.httpx")
    def test_signup_request_no_auth_header(self, mock_httpx):
        """signup() must not send a Bearer header (user has no key yet)."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"api_key": "tlm_sk_new", "user_id": 1, "email": "a@b.com"}
        mock_httpx.post.return_value = mock_resp

        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        c.signup("a@b.com", "pass")

        call_kwargs = mock_httpx.post.call_args
        sent_headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers", {})
        assert "Authorization" not in sent_headers


# ─── Auth Endpoint Tests ─────────────────────────────────────

class TestAuthEndpoints:
    @patch("tlm.api_client.httpx")
    def test_signup(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "api_key": "tlm_sk_new",
            "user_id": "usr_123",
            "email": "test@example.com",
        })
        result = client.signup("test@example.com", "password123")
        assert result["api_key"] == "tlm_sk_new"
        mock_httpx.post.assert_called_once()

    @patch("tlm.api_client.httpx")
    def test_login(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "api_key": "tlm_sk_existing",
            "user_id": "usr_456",
        })
        result = client.login("test@example.com", "password123")
        assert result["api_key"] == "tlm_sk_existing"

    @patch("tlm.api_client.httpx")
    def test_me(self, mock_httpx, client, mock_response):
        mock_httpx.get.return_value = mock_response(200, {
            "user_id": "usr_123",
            "email": "test@example.com",
            "tier": "free",
        })
        result = client.me()
        assert result["email"] == "test@example.com"

    @patch("tlm.api_client.httpx")
    def test_auth_error_on_401(self, mock_httpx, client, mock_response):
        mock_httpx.get.return_value = mock_response(401, {"detail": "Invalid API key"})
        with pytest.raises(TLMAuthError):
            client.me()


# ─── Project Endpoint Tests ──────────────────────────────────

class TestProjectEndpoints:
    @patch("tlm.api_client.httpx")
    def test_create_project(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "project_id": "proj_123",
            "name": "my-app",
            "fingerprint": "abc123",
        })
        result = client.create_project("my-app", "abc123")
        assert result["project_id"] == "proj_123"

    @patch("tlm.api_client.httpx")
    def test_list_projects(self, mock_httpx, client, mock_response):
        mock_httpx.get.return_value = mock_response(200, {
            "projects": [
                {"project_id": "proj_1", "name": "app1"},
                {"project_id": "proj_2", "name": "app2"},
            ]
        })
        result = client.list_projects()
        assert len(result["projects"]) == 2

    @patch("tlm.api_client.httpx")
    def test_delete_project(self, mock_httpx, client, mock_response):
        mock_httpx.delete.return_value = mock_response(200, {"deleted": True})
        result = client.delete_project("proj_123")
        assert result["deleted"] is True


# ─── Intelligence Endpoint Tests ─────────────────────────────

class TestIntelligenceEndpoints:
    @patch("tlm.api_client.httpx")
    def test_scan(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "profile": "## Stack\nPython, FastAPI",
        })
        result = client.scan("proj_123", "file_tree_here", "samples_here")
        assert "profile" in result

    @patch("tlm.api_client.httpx")
    def test_generate_config(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "config": {"checks": [], "environments": {}},
        })
        result = client.generate_config("proj_123", "profile", "tree", "samples")
        assert "config" in result

    @patch("tlm.api_client.httpx")
    def test_generate_config_with_local_config(self, mock_httpx, client, mock_response):
        """generate_config passes local_config in payload when provided."""
        mock_httpx.post.return_value = mock_response(200, {
            "config": {"checks": [], "environments": {}},
        })
        local = {"project_summary": "local attempt"}
        result = client.generate_config("proj_123", "profile", "tree", "samples", local_config=local)
        assert "config" in result
        sent_json = mock_httpx.post.call_args.kwargs.get("json") or mock_httpx.post.call_args[1].get("json", {})
        assert sent_json.get("local_config") == local

    @patch("tlm.api_client.httpx")
    def test_generate_config_without_local_config(self, mock_httpx, client, mock_response):
        """generate_config omits local_config from payload when None."""
        mock_httpx.post.return_value = mock_response(200, {
            "config": {"checks": [], "environments": {}},
        })
        client.generate_config("proj_123", "profile", "tree", "samples")
        sent_json = mock_httpx.post.call_args.kwargs.get("json") or mock_httpx.post.call_args[1].get("json", {})
        assert "local_config" not in sent_json

    @patch("tlm.api_client.httpx")
    def test_update_config(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "config": {"checks": [{"name": "test"}]},
        })
        result = client.update_config("proj_123", {"checks": []}, "add tests", "profile")
        assert "config" in result

    @patch("tlm.api_client.httpx")
    def test_approve_config(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {"approved": True})
        result = client.approve_config("proj_123", {"checks": []})
        assert result["approved"] is True

    @patch("tlm.api_client.httpx")
    def test_check_drift(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "stale": False,
            "drifted": False,
        })
        result = client.check_drift("proj_123", {"checks": []}, {"file": "hash"}, {})
        assert result["stale"] is False

    @patch("tlm.api_client.httpx")
    def test_compliance_check(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "review": "### Verdict: PASS",
        })
        result = client.compliance_check("proj_123", "spec content", "diff content", "profile", "config")
        assert "review" in result


# ─── Discovery Endpoint Tests ────────────────────────────────

class TestDiscoveryEndpoints:
    @patch("tlm.api_client.httpx")
    def test_discovery_start(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "session_id": "disc_123",
            "response": "Tell me about this feature...",
        })
        result = client.discovery_start("proj_123", "Add payments")
        assert result["session_id"] == "disc_123"
        assert "response" in result

    @patch("tlm.api_client.httpx")
    def test_discovery_respond(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "response": "Great, and what about error handling?",
            "is_complete": False,
        })
        result = client.discovery_respond("proj_123", "disc_123", "Use Stripe for processing")
        assert "response" in result

    @patch("tlm.api_client.httpx")
    def test_discovery_generate(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "spec": "# Payment Feature Spec",
            "instructions": "# TLM Engineering Rules",
            "knowledge": "New payment domain knowledge",
        })
        result = client.discovery_generate("proj_123", "disc_123")
        assert "spec" in result
        assert "instructions" in result


# ─── Learning Endpoint Tests ─────────────────────────────────

class TestLearningEndpoints:
    @patch("tlm.api_client.httpx")
    def test_analyze_commit(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "analysis": {
                "hash": "abc123",
                "category": "bug_fix",
                "planned": False,
            },
        })
        commit = {"hash": "abc123", "message": "fix bug", "author": "dev",
                  "date": "2026-02-15", "diff": "diff content"}
        result = client.analyze_commit("proj_123", commit)
        assert result["analysis"]["category"] == "bug_fix"

    @patch("tlm.api_client.httpx")
    def test_synthesize(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(200, {
            "synthesis": {
                "total_commits": 5,
                "spec_accuracy_percent": 80,
                "interview_improvements": ["Ask about edge cases"],
            },
        })
        result = client.synthesize("proj_123", [{"hash": "a"}])
        assert result["synthesis"]["total_commits"] == 5

    @patch("tlm.api_client.httpx")
    def test_learning_status(self, mock_httpx, client, mock_response):
        mock_httpx.get.return_value = mock_response(200, {
            "unprocessed_count": 3,
            "latest_synthesis": None,
        })
        result = client.learning_status("proj_123")
        assert result["unprocessed_count"] == 3


# ─── Sync Endpoint Tests ─────────────────────────────────────

class TestSyncEndpoint:
    @patch("tlm.api_client.httpx")
    def test_sync(self, mock_httpx, client, mock_response):
        mock_httpx.get.return_value = mock_response(200, {
            "knowledge": "# Knowledge Base\n- Uses PostgreSQL",
            "profile": "## Stack\nPython",
            "enforcement_config": {"checks": []},
            "latest_synthesis": None,
            "specs": [],
            "project_lessons": "",
        })
        result = client.sync("proj_123")
        assert "knowledge" in result
        assert "profile" in result
        assert "enforcement_config" in result

    @patch("tlm.api_client.httpx")
    def test_sync_timeout(self, mock_httpx, client):
        import httpx
        mock_httpx.get.side_effect = httpx.TimeoutException("timeout")
        with pytest.raises(TLMConnectionError):
            client.sync("proj_123", timeout=3.0)


# ─── Error Handling Tests ─────────────────────────────────────

class TestErrorHandling:
    @patch("tlm.api_client.httpx")
    def test_401_raises_auth_error(self, mock_httpx, client, mock_response):
        mock_httpx.get.return_value = mock_response(401, {"detail": "Unauthorized"})
        with pytest.raises(TLMAuthError):
            client.me()

    @patch("tlm.api_client.httpx")
    def test_500_raises_server_error(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(500, {"detail": "Internal error"})
        with pytest.raises(TLMServerError):
            client.scan("proj_123", "tree", "samples")

    @patch("tlm.api_client.httpx")
    def test_connection_error(self, mock_httpx, client):
        import httpx
        mock_httpx.post.side_effect = httpx.ConnectError("Connection refused")
        with pytest.raises(TLMConnectionError):
            client.scan("proj_123", "tree", "samples")

    @patch("tlm.api_client.httpx")
    def test_timeout_error(self, mock_httpx, client):
        import httpx
        mock_httpx.post.side_effect = httpx.TimeoutException("timeout")
        with pytest.raises(TLMConnectionError):
            client.scan("proj_123", "tree", "samples")

    @patch("tlm.api_client.httpx")
    def test_403_raises_auth_error(self, mock_httpx, client, mock_response):
        mock_httpx.get.return_value = mock_response(403, {"detail": "Forbidden"})
        with pytest.raises(TLMAuthError):
            client.me()

    @patch("tlm.api_client.httpx")
    def test_422_raises_server_error(self, mock_httpx, client, mock_response):
        mock_httpx.post.return_value = mock_response(422, {"detail": "Validation error"})
        with pytest.raises(TLMServerError):
            client.create_project("bad", "data")


# ─── Firebase Token Exchange Tests ───────────────────────────

class TestExchangeFirebaseToken:
    @patch("tlm.api_client.httpx")
    def test_exchange_returns_api_key(self, mock_httpx, mock_response):
        """exchange_firebase_token() returns server response with api_key."""
        mock_httpx.post.return_value = mock_response(200, {
            "api_key": "tlm_sk_from_firebase",
            "email": "user@example.com",
            "user_id": 1,
        })
        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        result = c.exchange_firebase_token("eyJhbGciOiJSUzI1Ni...")
        assert result["api_key"] == "tlm_sk_from_firebase"
        assert result["email"] == "user@example.com"

    @patch("tlm.api_client.httpx")
    def test_exchange_sends_firebase_token_in_body(self, mock_httpx, mock_response):
        """exchange_firebase_token() POSTs firebase_token in the request body."""
        mock_httpx.post.return_value = mock_response(200, {
            "api_key": "tlm_sk_new",
            "email": "a@b.com",
        })
        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        c.exchange_firebase_token("my_firebase_token_123")
        call_kwargs = mock_httpx.post.call_args
        sent_json = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json", {})
        assert sent_json == {"firebase_token": "my_firebase_token_123"}

    @patch("tlm.api_client.httpx")
    def test_exchange_no_auth_header(self, mock_httpx, mock_response):
        """exchange_firebase_token() must NOT send Authorization header."""
        mock_httpx.post.return_value = mock_response(200, {
            "api_key": "tlm_sk_new",
            "email": "a@b.com",
        })
        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        c.exchange_firebase_token("token")
        call_kwargs = mock_httpx.post.call_args
        sent_headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers", {})
        assert "Authorization" not in sent_headers

    @patch("tlm.api_client.httpx")
    def test_exchange_calls_correct_endpoint(self, mock_httpx, mock_response):
        """exchange_firebase_token() calls /api/v1/auth/firebase."""
        mock_httpx.post.return_value = mock_response(200, {"api_key": "tlm_sk_x"})
        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        c.exchange_firebase_token("token")
        url = mock_httpx.post.call_args[0][0]
        assert url == "https://test.tlmforge.dev/api/v1/auth/firebase"

    @patch("tlm.api_client.httpx")
    def test_exchange_server_error(self, mock_httpx, mock_response):
        """exchange_firebase_token() raises TLMServerError on 400."""
        mock_httpx.post.return_value = mock_response(400, {"detail": "Invalid token"})
        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        with pytest.raises(TLMServerError):
            c.exchange_firebase_token("bad_token")

    @patch("tlm.api_client.httpx")
    def test_exchange_connection_error(self, mock_httpx):
        """exchange_firebase_token() raises TLMConnectionError when server unreachable."""
        import httpx
        mock_httpx.post.side_effect = httpx.ConnectError("Connection refused")
        c = TLMClient(api_key="", base_url="https://test.tlmforge.dev")
        with pytest.raises(TLMConnectionError):
            c.exchange_firebase_token("token")


# ─── Scan Retry + Timeout Tests ──────────────────────────────

class TestScanRetry:
    """Tests for scan() retry logic and timeout configuration."""

    @patch("tlm.api_client.httpx")
    def test_scan_retries_on_timeout(self, mock_httpx, client):
        """scan() retries 2x on timeout before raising."""
        import httpx
        mock_httpx.post.side_effect = httpx.TimeoutException("timed out")
        with pytest.raises(TLMConnectionError, match="timed out"):
            client.scan("proj_123", "tree", "samples")
        assert mock_httpx.post.call_count == 3  # 1 initial + 2 retries

    @patch("tlm.api_client.httpx")
    def test_scan_succeeds_on_retry(self, mock_httpx, client, mock_response):
        """scan() succeeds on 2nd attempt after 1st times out."""
        import httpx
        mock_httpx.post.side_effect = [
            httpx.TimeoutException("timed out"),
            mock_response(200, {"profile": "## Stack\nPython"}),
        ]
        result = client.scan("proj_123", "tree", "samples")
        assert result["profile"] == "## Stack\nPython"
        assert mock_httpx.post.call_count == 2

    @patch("tlm.api_client.httpx")
    def test_scan_timeout_value(self, mock_httpx, client, mock_response):
        """scan() uses timeout=30.0."""
        mock_httpx.post.return_value = mock_response(200, {"profile": "test"})
        client.scan("proj_123", "tree", "samples")
        call_kwargs = mock_httpx.post.call_args
        assert call_kwargs.kwargs.get("timeout") == 30.0

    @patch("tlm.api_client.httpx")
    def test_scan_non_timeout_error_no_retry(self, mock_httpx, client):
        """scan() does NOT retry on non-timeout connection errors."""
        import httpx
        mock_httpx.post.side_effect = httpx.ConnectError("Connection refused")
        with pytest.raises(TLMConnectionError):
            client.scan("proj_123", "tree", "samples")
        assert mock_httpx.post.call_count == 1
