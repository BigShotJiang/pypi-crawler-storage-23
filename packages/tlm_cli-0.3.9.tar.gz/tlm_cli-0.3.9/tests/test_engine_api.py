"""
Tests for engine classes when using TLM API client (server-backed mode).

All engine classes (Scanner, ConfigGenerator, DriftDetector, DiscoveryEngine,
ComplianceChecker) should work identically whether backed by Claude (local)
or TLMClient (server). These tests verify the server-backed path.
"""

import json
from unittest.mock import MagicMock, patch
from pathlib import Path

import pytest

from tlm.engine import (
    Project, Scanner, ConfigGenerator, DriftDetector,
    DiscoveryEngine, ComplianceChecker,
)


SAMPLE_PROFILE = "## Stack\nPython, FastAPI\n## Testing\npytest"

SAMPLE_CONFIG = {
    "project_summary": "Python FastAPI app",
    "environments": {
        "staging": {"description": "Staging", "deploy_command": "deploy staging"},
        "production": {"description": "Production", "deploy_command": "deploy prod"},
    },
    "checks": [
        {"name": "Tests", "command": "pytest", "blocker": True, "when": "pre_commit"},
    ],
    "coverage": {"command": "pytest --cov", "min_line_coverage": 70},
    "drift_files": ["requirements.txt"],
}


@pytest.fixture
def project_with_tlm(tmp_path):
    project = Project(str(tmp_path))
    project.init()
    return project


@pytest.fixture
def mock_api_client():
    return MagicMock()


# ─── Scanner (API-backed) ────────────────────────────────────

class TestScannerAPI:
    def test_scan_calls_api_client(self, project_with_tlm, mock_api_client):
        mock_api_client.scan.return_value = {"profile": SAMPLE_PROFILE}
        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")

        profile = scanner.scan()

        assert profile == SAMPLE_PROFILE
        mock_api_client.scan.assert_called_once()

    def test_scan_saves_profile_locally(self, project_with_tlm, mock_api_client):
        mock_api_client.scan.return_value = {"profile": SAMPLE_PROFILE}
        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")

        scanner.scan()

        assert project_with_tlm.get_profile() == SAMPLE_PROFILE

    def test_scan_passes_file_tree_and_samples(self, project_with_tlm, mock_api_client):
        mock_api_client.scan.return_value = {"profile": "test"}
        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="42")

        scanner.scan()

        call_args = mock_api_client.scan.call_args
        assert call_args[0][0] == "42"  # project_id
        assert isinstance(call_args[0][1], str)  # file_tree
        assert isinstance(call_args[0][2], str)  # samples


# ─── ConfigGenerator (API-backed) ────────────────────────────

class TestConfigGeneratorAPI:
    def test_generate_calls_api_client(self, project_with_tlm, mock_api_client):
        project_with_tlm.save_profile(SAMPLE_PROFILE)
        mock_api_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")

        config = gen.generate()

        assert config == SAMPLE_CONFIG
        mock_api_client.generate_config.assert_called_once()

    def test_generate_passes_profile_and_files(self, project_with_tlm, mock_api_client):
        project_with_tlm.save_profile(SAMPLE_PROFILE)
        mock_api_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="42")

        gen.generate()

        call_args = mock_api_client.generate_config.call_args
        assert call_args[0][0] == "42"
        assert SAMPLE_PROFILE in call_args[0][1]  # profile

    def test_update_config_calls_api(self, project_with_tlm, mock_api_client):
        project_with_tlm.save_profile(SAMPLE_PROFILE)
        updated = {**SAMPLE_CONFIG, "project_summary": "Updated"}
        mock_api_client.update_config.return_value = {"config": updated}
        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")

        result = gen.update_config(SAMPLE_CONFIG, "Change the summary")

        assert result["project_summary"] == "Updated"
        mock_api_client.update_config.assert_called_once()

    def test_save_approved_still_works(self, project_with_tlm, mock_api_client):
        """save_approved is purely local — should work regardless of backend."""
        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")
        gen.save_approved(SAMPLE_CONFIG)

        assert project_with_tlm.enforcement.approved

    @patch("tlm.engine.ConfigGenerator._get_local_config", return_value={"project_summary": "local"})
    def test_generate_passes_local_config(self, mock_local, project_with_tlm, mock_api_client):
        """generate() calls _get_local_config and passes result to API."""
        project_with_tlm.save_profile(SAMPLE_PROFILE)
        mock_api_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")

        gen.generate()

        call_kwargs = mock_api_client.generate_config.call_args
        assert call_kwargs[1].get("local_config") == {"project_summary": "local"}

    @patch("tlm.engine.ConfigGenerator._get_local_config", return_value=None)
    def test_generate_works_without_local_config(self, mock_local, project_with_tlm, mock_api_client):
        """generate() works when local_config is None."""
        project_with_tlm.save_profile(SAMPLE_PROFILE)
        mock_api_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")

        config = gen.generate()
        assert config == SAMPLE_CONFIG


# ─── ConfigGenerator._get_local_config Tests ────────────────

class TestGetLocalConfig:
    @patch("tlm.engine.shutil.which", return_value=None)
    def test_claude_not_found(self, mock_which, project_with_tlm, mock_api_client):
        """When claude CLI not installed, returns None."""
        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_success_returns_parsed_json(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """On success, return parsed JSON config."""
        config = json.dumps(SAMPLE_CONFIG)
        mock_run.return_value = MagicMock(returncode=0, stdout=config)

        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = gen._get_local_config("profile", "tree", "samples")

        assert result == SAMPLE_CONFIG

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_timeout_returns_none(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Timeout returns None."""
        import subprocess
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=90)

        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_invalid_json_returns_none(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Invalid JSON output returns None."""
        mock_run.return_value = MagicMock(returncode=0, stdout="not valid json")

        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_nonzero_exit_returns_none(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Non-zero exit code returns None."""
        mock_run.return_value = MagicMock(returncode=1, stdout="")

        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_silent_execution(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Subprocess must run with capture_output=True."""
        mock_run.return_value = MagicMock(returncode=0, stdout=json.dumps(SAMPLE_CONFIG))

        gen = ConfigGenerator(project_with_tlm, api_client=mock_api_client, project_id="123")
        gen._get_local_config("profile", "tree", "samples")

        call_kwargs = mock_run.call_args
        assert call_kwargs.kwargs.get("capture_output") is True
        assert call_kwargs.kwargs.get("text") is True


# ─── DriftDetector (API-backed) ──────────────────────────────

class TestDriftDetectorAPI:
    def test_no_drift_returns_clean(self, project_with_tlm, mock_api_client):
        """When no files have drifted, should return clean result without API call."""
        project_with_tlm.enforcement.save(SAMPLE_CONFIG)
        project_with_tlm.enforcement.approve()

        detector = DriftDetector(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = detector.check()

        assert result["drifted"] is False
        assert result["stale"] is False
        mock_api_client.check_drift.assert_not_called()

    def test_drift_calls_api_client(self, project_with_tlm, mock_api_client):
        """When files have drifted, should call API to check if config is stale."""
        # Set up enforcement with drift_files
        config = {**SAMPLE_CONFIG, "drift_files": ["requirements.txt"]}
        project_with_tlm.enforcement.save(config)
        project_with_tlm.enforcement.approve()

        # Create the drift file after approval to trigger drift
        req_file = project_with_tlm.root / "requirements.txt"
        req_file.write_text("flask==3.0")

        mock_api_client.check_drift.return_value = {
            "stale": False,
            "drifted": True,
            "reason": "Minor change",
            "affected_sections": [],
        }

        detector = DriftDetector(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = detector.check()

        assert result["drifted"] is True
        mock_api_client.check_drift.assert_called_once()


# ─── DiscoveryEngine (API-backed) ────────────────────────────

class TestDiscoveryEngineAPI:
    def test_start_calls_api(self, project_with_tlm, mock_api_client):
        mock_api_client.discovery_start.return_value = {
            "session_id": "sess_1",
            "response": "What problem does this solve?",
        }
        engine = DiscoveryEngine(project_with_tlm, api_client=mock_api_client, project_id="123")

        response = engine.start("Add user auth")

        assert "What problem" in response
        mock_api_client.discovery_start.assert_called_once_with("123", "Add user auth")

    def test_respond_calls_api(self, project_with_tlm, mock_api_client):
        mock_api_client.discovery_start.return_value = {
            "session_id": "sess_1",
            "response": "Q1?",
        }
        mock_api_client.discovery_respond.return_value = {
            "response": "Q2?",
        }
        engine = DiscoveryEngine(project_with_tlm, api_client=mock_api_client, project_id="123")
        engine.start("Add auth")

        response = engine.respond("OAuth2")

        assert response == "Q2?"
        mock_api_client.discovery_respond.assert_called_once_with("123", "sess_1", "OAuth2")

    def test_generate_outputs_calls_api(self, project_with_tlm, mock_api_client):
        mock_api_client.discovery_start.return_value = {
            "session_id": "sess_1",
            "response": "Q1?",
        }
        mock_api_client.discovery_generate.return_value = {
            "spec": "# Auth Spec\n\nImplement OAuth2.",
            "instructions": "# TLM Engineering Rules\n\nTDD mandatory.",
            "knowledge": "Project uses OAuth2 for auth.",
        }
        engine = DiscoveryEngine(project_with_tlm, api_client=mock_api_client, project_id="123")
        engine.start("Add auth")

        spec, instructions = engine.generate_outputs()

        assert "Auth Spec" in spec
        assert "TLM Engineering Rules" in instructions
        mock_api_client.discovery_generate.assert_called_once_with("123", "sess_1")

    def test_extract_knowledge_from_generate(self, project_with_tlm, mock_api_client):
        """When using API, knowledge comes from generate response."""
        mock_api_client.discovery_start.return_value = {
            "session_id": "sess_1",
            "response": "Q1?",
        }
        mock_api_client.discovery_generate.return_value = {
            "spec": "# Spec",
            "instructions": "# Rules",
            "knowledge": "New knowledge about project.",
        }
        engine = DiscoveryEngine(project_with_tlm, api_client=mock_api_client, project_id="123")
        engine.start("Feature X")

        spec, instructions = engine.generate_outputs()
        knowledge = engine.extract_knowledge(spec)

        assert knowledge == "New knowledge about project."

    def test_is_complete_still_works(self, project_with_tlm, mock_api_client):
        """is_complete is a local string check — should work regardless of backend."""
        engine = DiscoveryEngine(project_with_tlm, api_client=mock_api_client, project_id="123")
        assert engine.is_complete("I have a complete picture now") is True
        assert engine.is_complete("What about error handling?") is False


# ─── ComplianceChecker (API-backed) ──────────────────────────

class TestComplianceCheckerAPI:
    def test_check_calls_api(self, project_with_tlm, mock_api_client):
        # Create a spec file
        spec_path = project_with_tlm.specs_dir / "test-spec.md"
        spec_path.write_text("# Test Spec\n\nMust have tests.")

        mock_api_client.compliance_check.return_value = {
            "result": "### Verdict: PASS\n\nAll changes match spec."
        }

        checker = ComplianceChecker(project_with_tlm, api_client=mock_api_client, project_id="123")

        with patch.object(checker, '_get_diff', return_value="diff --git a/foo.py"):
            result = checker.check(str(spec_path))

        assert "PASS" in result
        mock_api_client.compliance_check.assert_called_once()

    def test_check_no_diff_returns_message(self, project_with_tlm, mock_api_client):
        """No diff should return message without API call."""
        checker = ComplianceChecker(project_with_tlm, api_client=mock_api_client, project_id="123")

        with patch.object(checker, '_get_diff', return_value=""):
            result = checker.check()

        assert "No changes" in result
        mock_api_client.compliance_check.assert_not_called()
