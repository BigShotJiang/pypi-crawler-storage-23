"""Zeus energy optimizers."""
