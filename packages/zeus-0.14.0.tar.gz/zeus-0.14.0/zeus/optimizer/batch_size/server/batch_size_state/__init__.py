"""Batch size state models, repository, and commands.

Batch size state includes trials and GaussianTs states.
"""
