"""Models, commands, and repository for job states."""
