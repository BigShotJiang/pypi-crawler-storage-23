# pyntercept
python library &amp; utility to intercept i/o from interactive CLI/TUI programs.

# installation

## to install pyntercept as program

using pipx
```console
pipx install pyntercept
```

## to install pyntercept as library

```console
pip install pyntercept
```

# roadmap
1.  filters, different rendering stages and strategies to give an ability to
    pass data into wider spectre of the programs.
2.  wider support of external libraries, programs and use cases.
3.  accumulate differences (like cursor movement or character changes) to 
    optimize rendering and support more environments and use cases.
4.  support of Windows and other operating systems.
5.  add built-in ability to specify areas of the terminal where to render data.
