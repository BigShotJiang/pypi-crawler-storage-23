"""
Content Hash Tests for Vector SDK.

Tests the content hash computation for both the hash module and structuredEmbeddings
using shared fixtures to ensure parity with TypeScript SDK implementation.
"""

import json
from pathlib import Path

import pytest

from vector_sdk import compute_content_hash, extract_tool_text

# Path to shared fixtures
FIXTURES_PATH = (
    Path(__file__).parent.parent.parent.parent.parent
    / "proto"
    / "embedding_pipeline"
    / "content_hash_fixtures.json"
)


def load_fixtures():
    """Load test fixtures from JSON file."""
    with open(FIXTURES_PATH) as f:
        return json.load(f)


class TestContentHash:
    """Test content hash implementation against shared fixtures."""

    @pytest.fixture
    def fixtures(self):
        """Load fixtures for tests."""
        return load_fixtures()

    def test_fixtures_exist(self):
        """Verify fixtures file exists."""
        assert FIXTURES_PATH.exists(), f"Fixtures file not found at {FIXTURES_PATH}"

    def test_all_fixture_hashes(self, fixtures):
        """Run all fixture test cases for hash computation."""
        for case in fixtures["testCases"]:
            input_data = case["input"]
            tool_collection = input_data["toolCollection"]
            data = input_data["data"]
            expected_hash = case["expectedHash"]

            result = compute_content_hash(tool_collection, data)

            assert result == expected_hash, (
                f"Hash mismatch for {case['name']}\n"
                f"  Tool: {tool_collection}\n"
                f"  Data: {data}\n"
                f"  Expected: {expected_hash}\n"
                f"  Got: {result}"
            )

    def test_all_fixture_text_extraction(self, fixtures):
        """Run all fixture test cases for text extraction."""
        for case in fixtures["testCases"]:
            input_data = case["input"]
            tool_collection = input_data["toolCollection"]
            data = input_data["data"]
            expected_text = case["expectedText"]

            result = extract_tool_text(tool_collection, data)

            assert result == expected_text, (
                f"Text mismatch for {case['name']}\n"
                f"  Tool: {tool_collection}\n"
                f"  Data: {data}\n"
                f"  Expected: {expected_text}\n"
                f"  Got: {result}"
            )

    def test_basic_flashcard(self, fixtures):
        """Test basic flashcard hashing."""
        result = compute_content_hash(
            "FlashCard",
            {"term": "Hello", "definition": "World"},
        )
        expected = next(
            c["expectedHash"]
            for c in fixtures["testCases"]
            if c["name"] == "basic_flashcard"
        )
        assert result == expected

    def test_flashcard_type_defaults_to_basic(self):
        """Test that FlashCard without type defaults to BASIC."""
        with_type = compute_content_hash(
            "FlashCard",
            {"type": "BASIC", "term": "Hello", "definition": "World"},
        )
        without_type = compute_content_hash(
            "FlashCard",
            {"term": "Hello", "definition": "World"},
        )
        assert with_type == without_type

    def test_cloze_syntax_stripping(self, fixtures):
        """Test that cloze syntax is stripped correctly."""
        result = compute_content_hash(
            "FlashCard",
            {
                "type": "CLOZE",
                "term": "The {{mitochondria}} is the powerhouse",
                "definition": "Cell organelle",
            },
        )
        expected = next(
            c["expectedHash"]
            for c in fixtures["testCases"]
            if c["name"] == "flashcard_cloze_syntax"
        )
        assert result == expected

    def test_cloze_syntax_not_in_text(self):
        """Test that cloze syntax is removed from extracted text."""
        text = extract_tool_text(
            "FlashCard",
            {
                "type": "CLOZE",
                "term": "The {{answer}} is here",
                "definition": "Test",
            },
        )
        assert "{{" not in text
        assert "}}" not in text

    def test_multiple_choice_string_options(self, fixtures):
        """Test multiple choice with string options."""
        result = compute_content_hash(
            "FlashCard",
            {
                "type": "MULTIPLE_CHOICE",
                "term": "What is 2+2?",
                "multipleChoiceOptions": ["3", "4", "5", "6"],
            },
        )
        expected = next(
            c["expectedHash"]
            for c in fixtures["testCases"]
            if c["name"] == "flashcard_multiple_choice_strings"
        )
        assert result == expected

    def test_multiple_choice_object_options(self):
        """Test multiple choice with object options produces same hash as string options."""
        string_result = compute_content_hash(
            "FlashCard",
            {
                "type": "MULTIPLE_CHOICE",
                "term": "What is 2+2?",
                "multipleChoiceOptions": ["3", "4", "5", "6"],
            },
        )
        object_result = compute_content_hash(
            "FlashCard",
            {
                "type": "MULTIPLE_CHOICE",
                "term": "What is 2+2?",
                "multipleChoiceOptions": [
                    {"text": "3"},
                    {"text": "4"},
                    {"text": "5"},
                    {"text": "6"},
                ],
            },
        )
        assert string_result == object_result

    def test_test_question(self, fixtures):
        """Test TestQuestion hashing."""
        result = compute_content_hash(
            "TestQuestion",
            {
                "question": "What is the capital of France?",
                "answers": ["Paris", "London", "Berlin"],
                "explanation": "Paris is the capital.",
            },
        )
        expected = next(
            c["expectedHash"]
            for c in fixtures["testCases"]
            if c["name"] == "test_question_full"
        )
        assert result == expected

    def test_spaced_test_question_same_as_test_question(self):
        """Test that SpacedTestQuestion produces same hash as TestQuestion."""
        data = {
            "question": "What color is the sky?",
            "answers": ["Blue", "Green", "Red"],
        }
        test_q = compute_content_hash("TestQuestion", data)
        spaced_q = compute_content_hash("SpacedTestQuestion", data)
        assert test_q == spaced_q

    def test_audio_recap(self, fixtures):
        """Test AudioRecapV2Section hashing."""
        result = compute_content_hash(
            "AudioRecapV2Section",
            {"script": "Welcome to the audio recap."},
        )
        expected = next(
            c["expectedHash"]
            for c in fixtures["testCases"]
            if c["name"] == "audio_recap_section"
        )
        assert result == expected

    def test_empty_data_returns_empty_string(self):
        """Test that empty data returns empty string."""
        assert compute_content_hash("FlashCard", {}) == ""
        assert compute_content_hash("TestQuestion", {}) == ""
        assert compute_content_hash("AudioRecapV2Section", {}) == ""

    def test_whitespace_trimming(self):
        """Test that whitespace is trimmed from fields."""
        with_whitespace = compute_content_hash(
            "FlashCard",
            {"term": "  Hello  ", "definition": "  World  "},
        )
        without_whitespace = compute_content_hash(
            "FlashCard",
            {"term": "Hello", "definition": "World"},
        )
        assert with_whitespace == without_whitespace

    def test_hash_length(self):
        """Test that hash is 32 characters (MD5 hex)."""
        result = compute_content_hash(
            "FlashCard",
            {"term": "Test", "definition": "Value"},
        )
        assert len(result) == 32, f"Expected 32 char hash, got {len(result)}"

    def test_hash_is_deterministic(self):
        """Test that same input always produces same hash."""
        results = [
            compute_content_hash(
                "FlashCard",
                {"term": "Consistent", "definition": "Result"},
            )
            for _ in range(5)
        ]
        assert all(r == results[0] for r in results), "Hash should be deterministic"


class TestTextExtraction:
    """Test text extraction functionality."""

    def test_flashcard_basic_text(self):
        """Test basic flashcard text extraction."""
        text = extract_tool_text(
            "FlashCard",
            {"term": "Hello", "definition": "World"},
        )
        assert text == "Term: Hello Definition: World"

    def test_flashcard_term_only(self):
        """Test flashcard with only term."""
        text = extract_tool_text(
            "FlashCard",
            {"term": "Mitochondria"},
        )
        assert text == "Term: Mitochondria"

    def test_flashcard_multiple_choice_text(self):
        """Test multiple choice text extraction."""
        text = extract_tool_text(
            "FlashCard",
            {
                "type": "MULTIPLE_CHOICE",
                "term": "What is 2+2?",
                "multipleChoiceOptions": ["3", "4", "5", "6"],
            },
        )
        assert text == "Term: What is 2+2? Options: 3, 4, 5, 6"

    def test_test_question_text(self):
        """Test TestQuestion text extraction."""
        text = extract_tool_text(
            "TestQuestion",
            {
                "question": "What is 1+1?",
                "answers": ["2", "3"],
                "explanation": "Math!",
            },
        )
        assert text == "Question: What is 1+1? Answers: 2, 3 Explanation: Math!"

    def test_audio_recap_text(self):
        """Test AudioRecapV2Section text extraction."""
        text = extract_tool_text(
            "AudioRecapV2Section",
            {"script": "Hello world."},
        )
        assert text == "Script: Hello world."


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
