# Python SDK Reference

Complete reference for all exposed functions in the Vector SDK for Python.

## Table of Contents

- [Usage Patterns](#usage-patterns)
- [client.embeddings](#clientembeddings)
- [client.search](#clientsearch)
- [client.db](#clientdb)
- [client.structured_embeddings](#clientstructured_embeddings)
- [Type Reference](#type-reference)

---

## Usage Patterns

The SDK provides two main usage patterns for embedding and search operations:

### 🔄 Async Submission (Fire-and-forget)

Methods that return immediately with a request ID:
- `create()` - Submit embedding request
- `query()` - Submit search query
- `embed_*()` - Submit structured embedding
- `embed_*_batch()` - Submit batch embedding

**When to use:**
- Submitting multiple requests in parallel
- Doing other work before waiting for results
- Tracking request IDs separately

**Example:**
```python
# Submit multiple requests
id1 = client.embeddings.create(texts1, content_type="topic")
id2 = client.embeddings.create(texts2, content_type="flashcard")

# Do other work...

# Wait for results separately
result1 = client.embeddings.wait_for(id1)
result2 = client.embeddings.wait_for(id2)
```

### ⏳ Blocking Wait (Submit and wait)

Methods that block until completion:
- `create_and_wait()` - Submit and wait for embedding
- `query_and_wait()` - Submit and wait for search
- `embed_*_and_wait()` - Submit and wait for structured embedding
- `embed_*_batch_and_wait()` - Submit and wait for batch

**When to use:**
- Need the result immediately
- Simple, sequential operations
- Don't need to track request IDs

**Example:**
```python
# Submit and wait in one call
result = client.embeddings.create_and_wait(
    texts=[{"id": "doc1", "text": "Hello world"}],
    content_type="document",
)
print(f"Processed: {result.processed_count}")
```

### 🌐 HTTP Call (Database operations)

All `client.db` methods make synchronous HTTP calls that return results immediately. These do not use the async submission pattern.

---

## client.embeddings

Namespace for creating and managing vector embeddings.

### `create()`

🔄 **Async Submission** - Returns request ID immediately

Submit an embedding request and return immediately with a request ID. Use `wait_for()` to get the result.

**Signature:**
```python
def create(
    texts: list[dict[str, Any]],
    content_type: str,
    priority: str = "normal",
    storage: Optional[StorageConfig] = None,
    metadata: Optional[dict[str, str]] = None,
    request_id: Optional[str] = None,
    embedding_model: Optional[str] = None,
    embedding_dimensions: Optional[int] = None,
    allow_duplicates: bool = False,
) -> str
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `texts` | `list[dict]` | Yes | List of text inputs to embed | - |
| `content_type` | `str` | Yes | Type of content (e.g., "topic", "flashcard") | - |
| `priority` | `str` | No | Queue priority: "critical", "high", "normal", "low" | `"normal"` |
| `storage` | [`StorageConfig`](#storageconfig) | No | Storage configuration | `None` |
| `metadata` | `dict[str, str]` | No | Optional tracking metadata | `None` |
| `request_id` | `str` | No | Optional custom request ID | Auto-generated |
| `embedding_model` | `str` | No | Optional model override | `None` |
| `embedding_dimensions` | `int` | No | Optional dimensions override | `None` |
| `allow_duplicates` | `bool` | No | Skip deduplication checks | `False` |

**Returns:**
- **Type**: `str`
- **Description**: Request ID for tracking the embedding request

**Raises:**
- `ValueError` - If texts list is empty
- `ModelValidationError` - If embedding model is invalid

**Example:**
```python
request_id = client.embeddings.create(
    texts=[
        {"id": "doc1", "text": "Introduction to machine learning"},
        {"id": "doc2", "text": "Deep neural networks explained"},
    ],
    content_type="topic",
    priority="high",
    embedding_model="gemini-embedding-001",
)

# Do other work...

result = client.embeddings.wait_for(request_id)
```

---

### `wait_for()`

⏳ **Blocking Wait** - Waits for request completion

Wait for an embedding request to complete. Blocks until the result is available or timeout is reached.

**Signature:**
```python
def wait_for(
    request_id: str,
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `request_id` | `str` | Yes | The request ID to wait for | - |
| `timeout` | `int` | No | Maximum time to wait in seconds | `60` |

**Returns:**
- **Type**: [`EmbeddingResult`](#embeddingresult)
- **Description**: Embedding result with status, counts, errors, and timing

**Raises:**
- `TimeoutError` - If timeout is reached before result is available

**Example:**
```python
request_id = client.embeddings.create(texts, content_type="document")

# Wait up to 30 seconds
result = client.embeddings.wait_for(request_id, timeout=30)

if result.is_success:
    print(f"Successfully processed {result.processed_count} embeddings")
else:
    print(f"Failed: {len(result.errors)} errors")
```

---

### `create_and_wait()`

⏳ **Blocking Wait** - Submits request and waits for completion

Create embeddings and wait for the result in a single call. Combines `create()` and `wait_for()`.

**Signature:**
```python
def create_and_wait(
    texts: list[dict[str, Any]],
    content_type: str,
    priority: str = "normal",
    storage: Optional[StorageConfig] = None,
    metadata: Optional[dict[str, str]] = None,
    embedding_model: Optional[str] = None,
    embedding_dimensions: Optional[int] = None,
    allow_duplicates: bool = False,
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `texts` | `list[dict]` | Yes | List of text inputs to embed | - |
| `content_type` | `str` | Yes | Type of content | - |
| `priority` | `str` | No | Queue priority | `"normal"` |
| `storage` | [`StorageConfig`](#storageconfig) | No | Storage configuration | `None` |
| `metadata` | `dict[str, str]` | No | Optional metadata | `None` |
| `embedding_model` | `str` | No | Optional model override | `None` |
| `embedding_dimensions` | `int` | No | Optional dimensions override | `None` |
| `allow_duplicates` | `bool` | No | Skip deduplication checks | `False` |
| `timeout` | `int` | No | Maximum wait time in seconds | `60` |

**Returns:**
- **Type**: [`EmbeddingResult`](#embeddingresult)
- **Description**: Embedding result with status, counts, errors, and timing

**Raises:**
- `ValueError` - If texts list is empty
- `ModelValidationError` - If embedding model is invalid
- `TimeoutError` - If timeout is reached

**Example:**
```python
from vector_sdk import VectorClient, StorageConfig, TurboPufferStorage

client = VectorClient(redis_url="redis://localhost:6379")

result = client.embeddings.create_and_wait(
    texts=[
        {
            "id": "doc1",
            "text": "Vector embeddings are dense numerical representations",
            "document": {"source": "wiki", "category": "ml"},
        }
    ],
    content_type="document",
    priority="high",
    storage=StorageConfig(
        turbopuffer=TurboPufferStorage(
            namespace="documents",
            id_field="id",
            metadata=["source", "category"],
        )
    ),
)

print(f"Status: {result.status}")
print(f"Processed: {result.processed_count}, Failed: {result.failed_count}")
```

---

### `get_queue_depth()`

🌐 **HTTP Call** - Returns queue depth information

Get the current queue depth for each priority level (critical, high, normal, low).

**Signature:**
```python
def get_queue_depth() -> dict[str, int]
```

**Parameters:**
None

**Returns:**
- **Type**: `dict[str, int]`
- **Description**: Dictionary mapping stream names to pending message counts

**Raises:**
None - Returns 0 for streams that don't exist

**Example:**
```python
depths = client.embeddings.get_queue_depth()

print("Queue Depths:")
print(f"  Critical: {depths['embedding:critical']}")
print(f"  High: {depths['embedding:high']}")
print(f"  Normal: {depths['embedding:normal']}")
print(f"  Low: {depths['embedding:low']}")
```

---

## client.search

Namespace for vector similarity search operations.

### `query()`

🔄 **Async Submission** - Returns request ID immediately

Submit a vector search query and return immediately with a request ID. Use `wait_for()` to get the results.

**Signature:**
```python
def query(
    query_text: str,
    database: str,
    top_k: int = 10,
    min_score: Optional[float] = None,
    filters: Optional[dict[str, str]] = None,
    namespace: Optional[str] = None,
    collection: Optional[str] = None,
    database_name: Optional[str] = None,
    include_vectors: bool = False,
    include_metadata: bool = True,
    embedding_model: Optional[str] = None,
    embedding_dimensions: Optional[int] = None,
    priority: str = "normal",
    metadata: Optional[dict[str, str]] = None,
    request_id: Optional[str] = None,
    query_vector: Optional[list[float]] = None,
) -> str
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `query_text` | `str` | Yes* | The text to search for (will be embedded). *Can be empty if `query_vector` is provided. | - |
| `database` | `str` | Yes | Which database: "mongodb", "turbopuffer", "pinecone" | - |
| `top_k` | `int` | No | Number of results to return | `10` |
| `min_score` | `float` | No | Minimum similarity score (0.0-1.0) | `None` |
| `filters` | `dict[str, str]` | No | Metadata filters | `None` |
| `namespace` | `str` | No | Namespace for TurboPuffer/Pinecone | `None` |
| `collection` | `str` | No | Collection name for MongoDB | `None` |
| `database_name` | `str` | No | Database name for MongoDB | `None` |
| `include_vectors` | `bool` | No | Include vector values in response | `False` |
| `include_metadata` | `bool` | No | Include metadata in response | `True` |
| `embedding_model` | `str` | No | Optional model override | `None` |
| `embedding_dimensions` | `int` | No | Optional dimensions override | `None` |
| `priority` | `str` | No | Queue priority | `"normal"` |
| `metadata` | `dict[str, str]` | No | Optional tracking metadata | `None` |
| `request_id` | `str` | No | Optional custom request ID | Auto-generated |
| `query_vector` | `list[float]` | No | Pre-computed query vector (skips embedding generation) | `None` |

**Returns:**
- **Type**: `str`
- **Description**: Request ID for tracking the query

**Raises:**
- `ValueError` - If query_text is empty and query_vector is not provided
- `ModelValidationError` - If embedding model is invalid

**Example:**
```python
request_id = client.search.query(
    query_text="What is machine learning?",
    database="turbopuffer",
    namespace="topics",
    top_k=10,
    include_metadata=True,
)

# Do other work...

result = client.search.wait_for(request_id)
```

**Vector Passthrough Example:**
```python
# Generate embedding once (no storage = returns vectors)
embed_result = client.embeddings.create_and_wait(
    texts=[{"id": "query", "text": "What is machine learning?"}],
    content_type="query",
)
query_vector = embed_result.embeddings[0]

# Reuse vector across multiple namespaces
request_id = client.search.query(
    query_text="What is machine learning?",
    database="turbopuffer",
    namespace="topics",
    query_vector=query_vector,
)
```

---

### `wait_for()`

⏳ **Blocking Wait** - Waits for query completion

Wait for a search query to complete. Blocks until results are available or timeout is reached.

**Signature:**
```python
def wait_for(
    request_id: str,
    timeout: int = 30,
) -> QueryResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `request_id` | `str` | Yes | The request ID to wait for | - |
| `timeout` | `int` | No | Maximum time to wait in seconds | `30` |

**Returns:**
- **Type**: [`QueryResult`](#queryresult)
- **Description**: Query result with matching vectors and scores

**Raises:**
- `TimeoutError` - If timeout is reached before result is available

**Example:**
```python
request_id = client.search.query(query_text, database="turbopuffer", namespace="topics")

result = client.search.wait_for(request_id, timeout=30)

for match in result.matches:
    print(f"{match.id}: {match.score}")
```

---

### `query_and_wait()`

⏳ **Blocking Wait** - Submits query and waits for results

Submit a search query and wait for results in a single call. Combines `query()` and `wait_for()`.

**Signature:**
```python
def query_and_wait(
    query_text: str,
    database: str,
    top_k: int = 10,
    min_score: Optional[float] = None,
    filters: Optional[dict[str, str]] = None,
    namespace: Optional[str] = None,
    collection: Optional[str] = None,
    database_name: Optional[str] = None,
    include_vectors: bool = False,
    include_metadata: bool = True,
    embedding_model: Optional[str] = None,
    embedding_dimensions: Optional[int] = None,
    priority: str = "normal",
    metadata: Optional[dict[str, str]] = None,
    timeout: int = 30,
    query_vector: Optional[list[float]] = None,
) -> QueryResult
```

**Parameters:**
Same as `query()` plus:
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `timeout` | `int` | No | Maximum wait time in seconds | `30` |

**Returns:**
- **Type**: [`QueryResult`](#queryresult)
- **Description**: Query result with matching vectors and scores

**Raises:**
- `ValueError` - If query_text is empty and query_vector is not provided
- `ModelValidationError` - If embedding model is invalid
- `TimeoutError` - If timeout is reached

**Example:**
```python
result = client.search.query_and_wait(
    query_text="What is deep learning?",
    database="turbopuffer",
    namespace="topics",
    top_k=5,
    min_score=0.7,
    filters={"category": "machine-learning"},
    include_metadata=True,
)

print(f"Found {len(result.matches)} matches:")
for match in result.matches:
    print(f"- {match.id}: {match.score:.3f}")
    print(f"  Metadata: {match.metadata}")
```

**Vector Passthrough (search multiple namespaces with one embedding):**
```python
# Step 1: Generate embedding once (no storage = returns vectors)
embed_result = client.embeddings.create_and_wait(
    texts=[{"id": "query", "text": "What is machine learning?"}],
    content_type="query",
)
query_vector = embed_result.embeddings[0]

# Step 2: Search multiple namespaces with the same vector
topics = client.search.query_and_wait(
    query_text="What is machine learning?",
    database="turbopuffer",
    namespace="topic_vectors",
    query_vector=query_vector,
)

flashcards = client.search.query_and_wait(
    query_text="What is machine learning?",
    database="turbopuffer",
    namespace="flashcard_vectors",
    query_vector=query_vector,
)
```

---

## client.db

Namespace for direct database operations (no embedding required). Requires `http_url` to be configured.

### `get_by_ids()`

🌐 **HTTP Call** - Synchronous database lookup

Look up documents by their IDs using a direct HTTP call to the query gateway.

**Signature:**
```python
def get_by_ids(
    ids: list[str],
    database: str,
    namespace: Optional[str] = None,
    collection: Optional[str] = None,
    database_name: Optional[str] = None,
    include_vectors: bool = False,
    include_metadata: bool = True,
) -> LookupResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `ids` | `list[str]` | Yes | Document/vector IDs to retrieve (max 100) | - |
| `database` | `str` | Yes | Which database: "mongodb", "turbopuffer", "pinecone" | - |
| `namespace` | `str` | No | Namespace for TurboPuffer/Pinecone | `None` |
| `collection` | `str` | No | Collection name for MongoDB | `None` |
| `database_name` | `str` | No | Database name for MongoDB | `None` |
| `include_vectors` | `bool` | No | Include vector values in response | `False` |
| `include_metadata` | `bool` | No | Include metadata in response | `True` |

**Returns:**
- **Type**: [`LookupResult`](#lookupresult)
- **Description**: Retrieved documents with metadata and optional vectors

**Raises:**
- `ValueError` - If http_url is not configured
- `ValueError` - If ids list is empty or exceeds 100 items
- `requests.HTTPError` - If HTTP request fails

**Example:**
```python
result = client.db.get_by_ids(
    ids=["doc1", "doc2", "doc3"],
    database="turbopuffer",
    namespace="topics",
    include_metadata=True,
    include_vectors=False,
)

print(f"Found {len(result.documents)} documents")
for doc in result.documents:
    print(f"{doc.id}: {doc.metadata}")
```

---

### `find_by_metadata()`

🌐 **HTTP Call** - Search by metadata filters

Search for documents by metadata filters using a direct HTTP call to the query gateway.

**Signature:**
```python
def find_by_metadata(
    filters: dict[str, Any],
    database: str,
    namespace: Optional[str] = None,
    collection: Optional[str] = None,
    database_name: Optional[str] = None,
    limit: int = 100,
    include_vectors: bool = False,
) -> LookupResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `filters` | `dict[str, Any]` | Yes | Metadata key-value pairs to match | - |
| `database` | `str` | Yes | Which database to query | - |
| `namespace` | `str` | No | Namespace for TurboPuffer/Pinecone | `None` |
| `collection` | `str` | No | Collection name for MongoDB | `None` |
| `database_name` | `str` | No | Database name for MongoDB | `None` |
| `limit` | `int` | No | Maximum number of results (max: 1000) | `100` |
| `include_vectors` | `bool` | No | Include vector values | `False` |

**Returns:**
- **Type**: [`LookupResult`](#lookupresult)
- **Description**: Matched documents with metadata and optional vectors

**Raises:**
- `ValueError` - If http_url is not configured
- `ValueError` - If filters dict is empty
- `requests.HTTPError` - If HTTP request fails

**Example:**
```python
result = client.db.find_by_metadata(
    filters={"userId": "user123", "category": "science"},
    database="mongodb",
    collection="tool_vectors",
    database_name="events_new",
    limit=50,
    include_vectors=False,
)

print(f"Found {len(result.documents)} matching documents")
```

---

### `clone()`

🌐 **HTTP Call** - Clone document between namespaces

Clone a document from one TurboPuffer namespace to another. Includes vector and metadata.

**Signature:**
```python
def clone(
    id: str,
    source_namespace: str,
    destination_namespace: str,
) -> CloneResult
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `id` | `str` | Yes | Document ID to clone |
| `source_namespace` | `str` | Yes | Source namespace to clone from |
| `destination_namespace` | `str` | Yes | Destination namespace to clone to |

**Returns:**
- **Type**: [`CloneResult`](#cloneresult)
- **Description**: Clone result with success status and timing

**Raises:**
- `ValueError` - If http_url is not configured
- `ValueError` - If required parameters are missing
- `requests.HTTPError` - If HTTP request fails

**Example:**
```python
result = client.db.clone(
    id="doc123",
    source_namespace="production_topics",
    destination_namespace="staging_topics",
)

if result.success:
    print(f"Cloned {result.id} in {result.timing.total_ms}ms")
```

---

### `delete()`

🌐 **HTTP Call** - Delete document from namespace

Delete a document from a TurboPuffer namespace.

**Signature:**
```python
def delete(
    id: str,
    namespace: str,
) -> DeleteFromNamespaceResult
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `id` | `str` | Yes | Document ID to delete |
| `namespace` | `str` | Yes | Namespace to delete from |

**Returns:**
- **Type**: [`DeleteFromNamespaceResult`](#deletefromnamespaceresult)
- **Description**: Delete result with success status and timing

**Raises:**
- `ValueError` - If http_url is not configured
- `ValueError` - If required parameters are missing
- `requests.HTTPError` - If HTTP request fails

**Example:**
```python
result = client.db.delete(
    id="doc123",
    namespace="production_topics",
)

if result.success:
    print(f"Deleted {result.id} in {result.timing.total_ms}ms")
```

---

### `get_vectors_in_namespace()`

⏳ **Blocking Wait** - Export all vectors from namespace

Export all vectors from a TurboPuffer namespace. This method submits an export job to the query gateway and waits for completion. The gateway handles pagination automatically and returns all results at once.

**Signature:**
```python
def get_vectors_in_namespace(
    namespace: str,
    include_vectors: bool = True,
    include_metadata: bool = True,
    timeout_ms: int = 300000,
) -> GetVectorsInNamespaceResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `namespace` | `str` | Yes | TurboPuffer namespace to export from | - |
| `include_vectors` | `bool` | No | Include vectors in response | `True` |
| `include_metadata` | `bool` | No | Include metadata in response | `True` |
| `timeout_ms` | `int` | No | Maximum wait time in milliseconds | `300000` (5 min) |

**Returns:**
- **Type**: [`GetVectorsInNamespaceResult`](#getvectorsinnamespaceresult)
- **Description**: All documents in namespace with metadata

**Raises:**
- `ValueError` - If http_url is not configured or namespace is missing
- `TimeoutError` - If export timeout is reached
- `Exception` - If export fails on server
- `requests.HTTPError` - If HTTP request fails

**Example - Export entire namespace:**
```python
result = client.db.get_vectors_in_namespace(
    namespace="tool_vectors",
    include_vectors=True,
    include_metadata=True,
)

print(f"Status: {result.status}")
print(f"Exported {len(result.documents)} documents")
print(f"Namespace info: ~{result.metadata.approx_row_count} total rows")
print(f"Timing: metadata={result.timing.metadata_ms}ms, query={result.timing.query_ms}ms")

# Process documents
for doc in result.documents:
    print(f"{doc.id}:", doc.metadata)
    # doc.vector contains the embedding (if include_vectors=True)
```

**Example - Export without vectors (metadata only):**
```python
result = client.db.get_vectors_in_namespace(
    namespace="tool_vectors",
    include_vectors=False,  # Faster, smaller payload
    include_metadata=True,
)

print(f"Exported {len(result.documents)} documents (metadata only)")
```

**Note:** This operation may take several seconds to minutes for large namespaces. The gateway handles pagination automatically and returns all results at once.

---

## client.structured_embeddings

Namespace for type-safe embedding of known tool types with automatic text extraction, content hash computation, and database routing.

### FlashCard Methods

#### `embed_flashcard()`

🔄 **Async Submission** - Returns request ID immediately

Embed a flashcard and return the request ID.

**Signature:**
```python
def embed_flashcard(
    data: FlashCardData,
    metadata: ToolMetadata,
) -> str
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `data` | [`FlashCardData`](#flashcarddata) | Yes | FlashCard data (type, term, definition) |
| `metadata` | [`ToolMetadata`](#toolmetadata) | Yes | Tool metadata (tool_id, user_id, topic_id) |

**Returns:**
- **Type**: `str`
- **Description**: Request ID for tracking

**Example:**
```python
from vector_sdk import ToolMetadata

request_id = client.structured_embeddings.embed_flashcard(
    data={
        "type": "BASIC",
        "term": "Mitochondria",
        "definition": "The powerhouse of the cell",
    },
    metadata=ToolMetadata(
        tool_id="tool123",
        user_id="user456",
        topic_id="biology101",
    ),
)
```

---

#### `embed_flashcard_and_wait()`

⏳ **Blocking Wait** - Submits and waits for result

Embed a flashcard and wait for the result.

**Signature:**
```python
def embed_flashcard_and_wait(
    data: FlashCardData,
    metadata: ToolMetadata,
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `data` | [`FlashCardData`](#flashcarddata) | Yes | FlashCard data | - |
| `metadata` | [`ToolMetadata`](#toolmetadata) | Yes | Tool metadata | - |
| `timeout` | `int` | No | Maximum wait time in seconds | `60` |

**Returns:**
- **Type**: [`EmbeddingResult`](#embeddingresult)
- **Description**: Embedding result with status and counts

**Example:**
```python
result = client.structured_embeddings.embed_flashcard_and_wait(
    data={
        "type": "MULTIPLE_CHOICE",
        "term": "What is the capital of France?",
        "definition": "Paris",
        "multipleChoiceOptions": ["London", "Paris", "Berlin", "Madrid"],
    },
    metadata=ToolMetadata(tool_id="tool789", user_id="user123"),
)
```

---

#### `embed_flashcard_batch()`

🔄 **Async Submission** - Returns request ID for batch

Embed a batch of flashcards and return the request ID.

**Signature:**
```python
def embed_flashcard_batch(
    items: list[FlashCardBatchItem],
) -> str
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `items` | `list[`[`FlashCardBatchItem`](#flashcardbatchitem)`]` | Yes | Array of flashcard batch items |

**Returns:**
- **Type**: `str`
- **Description**: Request ID for tracking the batch

**Example:**
```python
from vector_sdk import FlashCardBatchItem, ToolMetadata

request_id = client.structured_embeddings.embed_flashcard_batch([
    FlashCardBatchItem(
        data={"type": "BASIC", "term": "ATP", "definition": "Adenosine triphosphate"},
        metadata=ToolMetadata(tool_id="tool1", user_id="user123"),
    ),
    FlashCardBatchItem(
        data={"type": "BASIC", "term": "DNA", "definition": "Deoxyribonucleic acid"},
        metadata=ToolMetadata(tool_id="tool2", user_id="user123"),
    ),
])
```

---

#### `embed_flashcard_batch_and_wait()`

⏳ **Blocking Wait** - Submits batch and waits for result

Embed a batch of flashcards and wait for the result.

**Signature:**
```python
def embed_flashcard_batch_and_wait(
    items: list[FlashCardBatchItem],
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `items` | `list[`[`FlashCardBatchItem`](#flashcardbatchitem)`]` | Yes | Array of flashcard batch items | - |
| `timeout` | `int` | No | Maximum wait time in seconds | `60` |

**Returns:**
- **Type**: [`EmbeddingResult`](#embeddingresult)
- **Description**: Embedding result for the entire batch

**Example:**
```python
result = client.structured_embeddings.embed_flashcard_batch_and_wait(
    items=[
        FlashCardBatchItem(
            data={"type": "CLOZE", "term": "The {{c1::mitochondria}} is the powerhouse of the cell"},
            metadata=ToolMetadata(tool_id="tool1", user_id="user123"),
        ),
        FlashCardBatchItem(
            data={"type": "FILL_IN_THE_BLANK", "term": "H2O is the chemical formula for ____", "definition": "water"},
            metadata=ToolMetadata(tool_id="tool2", user_id="user123"),
        ),
    ]
)

print(f"Batch processed: {result.processed_count}/{result.processed_count + result.failed_count}")
```

---

### TestQuestion Methods

#### `embed_test_question()`

🔄 **Async Submission** - Returns request ID immediately

Embed a test question and return the request ID.

**Signature:**
```python
def embed_test_question(
    data: TestQuestionInput,
    metadata: ToolMetadata,
) -> str
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `data` | [`TestQuestionInput`](#testquestioninput) | Yes | Question data with question_type |
| `metadata` | [`ToolMetadata`](#toolmetadata) | Yes | Tool metadata |

**Example:**
```python
from vector_sdk import TestQuestionInput, ToolMetadata

request_id = client.structured_embeddings.embed_test_question(
    data=TestQuestionInput(
        question="What is the capital of France?",
        answers=[
            {"text": "Paris", "correct": True},
            {"text": "London", "correct": False},
        ],
        question_type="multiplechoice",
        explanation="Paris is the capital and largest city of France",
    ),
    metadata=ToolMetadata(tool_id="q123", user_id="user456"),
)
```

---

#### `embed_test_question_and_wait()`

⏳ **Blocking Wait** - Submits and waits for result

Embed a test question and wait for the result.

**Signature:**
```python
def embed_test_question_and_wait(
    data: TestQuestionInput,
    metadata: ToolMetadata,
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `data` | [`TestQuestionInput`](#testquestioninput) | Yes | Question data | - |
| `metadata` | [`ToolMetadata`](#toolmetadata) | Yes | Tool metadata | - |
| `timeout` | `int` | No | Maximum wait time in seconds | `60` |

**Example:**
```python
result = client.structured_embeddings.embed_test_question_and_wait(
    data=TestQuestionInput(
        question="True or False: Water boils at 100°C at sea level",
        answers=[{"text": "True", "correct": True}, {"text": "False", "correct": False}],
        question_type="truefalse",
    ),
    metadata=ToolMetadata(tool_id="q456", user_id="user123"),
)
```

---

#### `embed_test_question_batch()`

🔄 **Async Submission** - Returns request ID for batch

Embed a batch of test questions and return the request ID.

**Signature:**
```python
def embed_test_question_batch(
    items: list[TestQuestionBatchItem],
) -> str
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `items` | `list[`[`TestQuestionBatchItem`](#testquestionbatchitem)`]` | Yes | Array of question batch items |

---

#### `embed_test_question_batch_and_wait()`

⏳ **Blocking Wait** - Submits batch and waits for result

Embed a batch of test questions and wait for the result.

**Signature:**
```python
def embed_test_question_batch_and_wait(
    items: list[TestQuestionBatchItem],
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `items` | `list[`[`TestQuestionBatchItem`](#testquestionbatchitem)`]` | Yes | Array of question batch items | - |
| `timeout` | `int` | No | Maximum wait time in seconds | `60` |

---

### SpacedTestQuestion Methods

#### `embed_spaced_test_question()`

🔄 **Async Submission** - Returns request ID immediately

Embed a spaced test question and return the request ID.

**Signature:**
```python
def embed_spaced_test_question(
    data: TestQuestionInput,
    metadata: ToolMetadata,
) -> str
```

---

#### `embed_spaced_test_question_and_wait()`

⏳ **Blocking Wait** - Submits and waits for result

Embed a spaced test question and wait for the result.

**Signature:**
```python
def embed_spaced_test_question_and_wait(
    data: TestQuestionInput,
    metadata: ToolMetadata,
    timeout: int = 60,
) -> EmbeddingResult
```

---

#### `embed_spaced_test_question_batch()`

🔄 **Async Submission** - Returns request ID for batch

Embed a batch of spaced test questions and return the request ID.

**Signature:**
```python
def embed_spaced_test_question_batch(
    items: list[TestQuestionBatchItem],
) -> str
```

---

#### `embed_spaced_test_question_batch_and_wait()`

⏳ **Blocking Wait** - Submits batch and waits for result

Embed a batch of spaced test questions and wait for the result.

**Signature:**
```python
def embed_spaced_test_question_batch_and_wait(
    items: list[TestQuestionBatchItem],
    timeout: int = 60,
) -> EmbeddingResult
```

---

### AudioRecap Methods

#### `embed_audio_recap()`

🔄 **Async Submission** - Returns request ID immediately

Embed an audio recap section and return the request ID.

**Signature:**
```python
def embed_audio_recap(
    data: AudioRecapSectionData,
    metadata: ToolMetadata,
) -> str
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `data` | [`AudioRecapSectionData`](#audiorecapsectiondata) | Yes | Audio recap data (script) |
| `metadata` | [`ToolMetadata`](#toolmetadata) | Yes | Tool metadata |

---

#### `embed_audio_recap_and_wait()`

⏳ **Blocking Wait** - Submits and waits for result

Embed an audio recap section and wait for the result.

**Signature:**
```python
def embed_audio_recap_and_wait(
    data: AudioRecapSectionData,
    metadata: ToolMetadata,
    timeout: int = 60,
) -> EmbeddingResult
```

---

#### `embed_audio_recap_batch()`

🔄 **Async Submission** - Returns request ID for batch

Embed a batch of audio recap sections and return the request ID.

**Signature:**
```python
def embed_audio_recap_batch(
    items: list[AudioRecapBatchItem],
) -> str
```

---

#### `embed_audio_recap_batch_and_wait()`

⏳ **Blocking Wait** - Submits batch and waits for result

Embed a batch of audio recap sections and wait for the result.

**Signature:**
```python
def embed_audio_recap_batch_and_wait(
    items: list[AudioRecapBatchItem],
    timeout: int = 60,
) -> EmbeddingResult
```

---

### Topic Methods

#### `embed_topic()`

🔄 **Async Submission** - Returns request ID immediately

Embed a topic and return the request ID. Uses `TopicMetadata` (all fields optional).

**Signature:**
```python
def embed_topic(
    data: TopicData,
    metadata: TopicMetadata,
) -> str
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `data` | [`TopicData`](#topicdata) | Yes | Topic data (id, topic, description) |
| `metadata` | [`TopicMetadata`](#topicmetadata) | Yes | Topic metadata (all fields optional) |

**Example:**
```python
from vector_sdk import TopicMetadata

request_id = client.structured_embeddings.embed_topic(
    data={
        "id": "topic-123",
        "topic": "Photosynthesis",
        "description": "The process by which plants convert sunlight into energy",
    },
    metadata=TopicMetadata(user_id="user456", topic_id="bio-101"),
)
```

---

#### `embed_topic_and_wait()`

⏳ **Blocking Wait** - Submits and waits for result

Embed a topic and wait for the result.

**Signature:**
```python
def embed_topic_and_wait(
    data: TopicData,
    metadata: TopicMetadata,
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `data` | [`TopicData`](#topicdata) | Yes | Topic data | - |
| `metadata` | [`TopicMetadata`](#topicmetadata) | Yes | Topic metadata | - |
| `timeout` | `int` | No | Maximum wait time in seconds | `60` |

**Example:**
```python
result = client.structured_embeddings.embed_topic_and_wait(
    data={
        "id": "topic-456",
        "topic": "Cell Division",
        "description": "The process by which cells reproduce",
    },
    metadata=TopicMetadata(user_id="user123"),
)
```

---

#### `embed_topic_batch()`

🔄 **Async Submission** - Returns request ID for batch

Embed a batch of topics and return the request ID.

**Signature:**
```python
def embed_topic_batch(
    items: list[TopicBatchItem],
) -> str
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `items` | `list[`[`TopicBatchItem`](#topicbatchitem)`]` | Yes | Array of topic batch items |

---

#### `embed_topic_batch_and_wait()`

⏳ **Blocking Wait** - Submits batch and waits for result

Embed a batch of topics and wait for the result.

**Signature:**
```python
def embed_topic_batch_and_wait(
    items: list[TopicBatchItem],
    timeout: int = 60,
) -> EmbeddingResult
```

**Parameters:**
| Name | Type | Required | Description | Default |
|------|------|----------|-------------|---------|
| `items` | `list[`[`TopicBatchItem`](#topicbatchitem)`]` | Yes | Array of topic batch items | - |
| `timeout` | `int` | No | Maximum wait time in seconds | `60` |

---

## Type Reference

### Request Types

#### TextInput

A single text to embed. Can be provided as a dict or `TextInput` dataclass.

```python
@dataclass
class TextInput:
    id: str                            # Unique identifier
    text: str                          # Text to embed
    document: Optional[dict[str, Any]] # Optional document to store
```

**Dict format:**
```python
{
    "id": "doc1",
    "text": "Hello world",
    "document": {"field": "value"}  # Optional
}
```

---

#### StorageConfig

Configuration for where to store embeddings.

```python
@dataclass
class StorageConfig:
    mongodb: Optional[MongoDBStorage] = None
    turbopuffer: Optional[TurboPufferStorage] = None
    pinecone: Optional[PineconeStorageConfig] = None

@dataclass
class MongoDBStorage:
    database: str                      # MongoDB database name
    collection: str                    # Collection name
    embedding_field: str               # Field name for vector
    upsert_key: str                    # Field for upsert (e.g., "contentHash")

@dataclass
class TurboPufferStorage:
    namespace: str                     # TurboPuffer namespace
    id_field: str                      # Document field to use as ID
    metadata: Optional[list[str]]      # Fields to include as metadata

@dataclass
class PineconeStorageConfig:
    index_name: str                    # Pinecone index name
    id_field: str                      # Document field to use as ID
    namespace: Optional[str]           # Optional namespace
    metadata: Optional[list[str]]      # Fields to include as metadata
```

---

#### ToolMetadata

Metadata for tool embeddings (FlashCard, TestQuestion, etc.). Requires `tool_id`.

```python
@dataclass
class ToolMetadata:
    tool_id: str                       # Required: Tool identifier
    user_id: Optional[str] = None      # Optional: User who owns the tool
    topic_id: Optional[str] = None     # Optional: Topic the tool belongs to
    extra: Optional[dict[str, Any]] = None  # Additional metadata fields
```

---

#### TopicMetadata

Metadata for topic embeddings. All fields are optional (no `tool_id` required).

```python
@dataclass
class TopicMetadata:
    user_id: Optional[str] = None      # Optional: User who owns the topic
    topic_id: Optional[str] = None     # Optional: Topic identifier
    extra: Optional[dict[str, Any]] = None  # Additional metadata fields
```

---

### Response Types

#### EmbeddingResult

Result of an embedding request.

```python
@dataclass
class EmbeddingResult:
    request_id: str                    # Original request ID
    status: str                        # "success", "partial", or "failed"
    processed_count: int               # Successfully processed embeddings
    failed_count: int                  # Failed embeddings
    errors: list[EmbeddingError]       # Details about failures
    embeddings: Optional[list[list[float]]]  # Generated vectors (only when no storage configured)
    timing: Optional[TimingBreakdown]  # Processing duration breakdown
    completed_at: datetime             # When processing finished
    
    @property
    def is_success(self) -> bool:     # status == "success"
    
    @property
    def is_partial(self) -> bool:     # status == "partial"
    
    @property
    def is_failed(self) -> bool:      # status == "failed"

@dataclass
class EmbeddingError:
    index: int                         # Position in texts array
    id: str                            # The TextInput.id that failed
    error: str                         # Error message
    retryable: bool                    # Can this be retried?

@dataclass
class TimingBreakdown:
    queue_wait_ms: int                 # Time waiting in queue
    vertex_ms: int                     # Time calling Vertex AI
    mongodb_ms: int                    # Time writing to MongoDB
    turbopuffer_ms: int                # Time writing to TurboPuffer
    total_ms: int                      # Total processing time
```

---

#### QueryResult

Result of a search query.

```python
@dataclass
class QueryResult:
    request_id: str                    # Original request ID
    status: str                        # "success" or "failed"
    matches: list[VectorMatch]         # Matching vectors with scores
    error: Optional[str]               # Error message if failed
    timing: Optional[QueryTiming]      # Processing duration breakdown
    completed_at: datetime             # When processing finished
    
    @property
    def is_success(self) -> bool:     # status == "success"
    
    @property
    def is_failed(self) -> bool:      # status == "failed"

@dataclass
class VectorMatch:
    id: str                            # Vector ID in database
    score: float                       # Similarity score (higher = more similar)
    metadata: Optional[dict[str, Any]] # Associated metadata
    vector: Optional[list[float]]      # Vector values (if requested)

@dataclass
class QueryTiming:
    queue_wait_ms: int                 # Time waiting in queue
    embedding_ms: int                  # Time generating query embedding
    search_ms: int                     # Time executing database search
    total_ms: int                      # Total processing time
```

---

#### LookupResult

Result of a database lookup or metadata search.

```python
@dataclass
class LookupResult:
    documents: list[Document]          # Retrieved documents
    timing: LookupTiming               # Timing information

@dataclass
class Document:
    id: str                            # Document/vector ID
    metadata: Optional[dict[str, Any]] # Document metadata
    vector: Optional[list[float]]      # Vector values (if requested)

@dataclass
class LookupTiming:
    total_ms: int                      # Total request duration
```

---

#### CloneResult

Result of a clone operation.

```python
@dataclass
class CloneResult:
    id: str                            # Document ID that was cloned
    success: bool                      # Whether clone succeeded
    timing: LookupTiming               # Timing information
```

---

#### DeleteFromNamespaceResult

Result of a delete operation.

```python
@dataclass
class DeleteFromNamespaceResult:
    id: str                            # Document ID that was deleted
    success: bool                      # Whether delete succeeded
    timing: LookupTiming               # Timing information
```

---

#### NamespaceMetadata

Namespace metadata from TurboPuffer.

```python
@dataclass
class NamespaceMetadata:
    schema: dict[str, Any]             # Schema information
    approx_row_count: int              # Approximate number of rows
    approx_logical_bytes: int          # Approximate logical bytes used
    created_at: str                    # When namespace was created
    updated_at: str                    # When namespace was last updated
```

---

#### ExportTiming

Timing breakdown for export operations.

```python
@dataclass
class ExportTiming:
    metadata_ms: int                   # Time to fetch metadata (ms)
    query_ms: int                      # Time to fetch all documents (ms)
    total_ms: int                      # Total export time (ms)
```

---

#### GetVectorsInNamespaceResult

Result of a namespace export operation.

```python
@dataclass
class GetVectorsInNamespaceResult:
    job_id: str                        # Job ID for the export
    status: str                        # Export status ("success" or "failed")
    documents: list[Document]          # All exported documents
    metadata: NamespaceMetadata        # Namespace metadata
    error: Optional[str]               # Error message if failed
    timing: ExportTiming               # Timing breakdown
    completed_at: str                  # When export completed (ISO 8601)
```

---

### Tool Data Types

#### FlashCardData

Data structure for flashcards. Provided as a dict.

```python
# Dict structure
{
    "type": str,                       # "BASIC" | "CLOZE" | "FILL_IN_THE_BLANK" | "MULTIPLE_CHOICE"
    "term": str,                       # Question/term
    "definition": str,                 # Answer/definition (optional)
    "multipleChoiceOptions": list[str] # Options for MULTIPLE_CHOICE type (optional)
}
```

---

#### TestQuestionInput

Data structure for test questions.

```python
@dataclass
class TestQuestionInput:
    question: str                      # The question text
    answers: list[dict[str, Any]]      # Answer options: [{"text": str, "correct": bool}]
    question_type: Optional[str] = None  # "multiplechoice", "truefalse", "shortanswer", "fillinblank", "frq"
    explanation: Optional[str] = None  # Optional explanation
```

---

#### AudioRecapSectionData

Data structure for audio recap sections. Provided as a dict.

```python
# Dict structure
{
    "script": str                      # Audio script text
}
```

---

#### TopicData

Data structure for topics. Provided as a dict.

```python
# Dict structure
{
    "id": str,                         # Topic ID (becomes TurboPuffer document ID)
    "topic": str,                      # Topic name
    "description": str                 # Topic description (optional)
}
```

---

### Batch Item Types

#### FlashCardBatchItem

```python
@dataclass
class FlashCardBatchItem:
    data: dict[str, Any]               # FlashCardData as dict
    metadata: ToolMetadata
```

---

#### TestQuestionBatchItem

```python
@dataclass
class TestQuestionBatchItem:
    data: TestQuestionInput
    metadata: ToolMetadata
```

---

#### AudioRecapBatchItem

```python
@dataclass
class AudioRecapBatchItem:
    data: dict[str, Any]               # AudioRecapSectionData as dict
    metadata: ToolMetadata
```

---

#### TopicBatchItem

```python
@dataclass
class TopicBatchItem:
    data: dict[str, Any]               # TopicData as dict
    metadata: TopicMetadata
```

---

### Model Configuration

#### Supported Models

```python
SUPPORTED_MODELS = {
    # Google Vertex AI
    "gemini-embedding-001": ModelConfig(
        name="gemini-embedding-001",
        provider=EmbeddingProvider.GOOGLE,
        default_dimensions=3072,
        max_dimensions=3072,
        supports_custom_dimensions=False,
    ),
    "text-embedding-004": ModelConfig(
        name="text-embedding-004",
        provider=EmbeddingProvider.GOOGLE,
        default_dimensions=768,
        max_dimensions=768,
        supports_custom_dimensions=False,
    ),
    "text-multilingual-embedding-002": ModelConfig(
        name="text-multilingual-embedding-002",
        provider=EmbeddingProvider.GOOGLE,
        default_dimensions=768,
        max_dimensions=768,
        supports_custom_dimensions=False,
    ),
    
    # OpenAI
    "text-embedding-3-small": ModelConfig(
        name="text-embedding-3-small",
        provider=EmbeddingProvider.OPENAI,
        default_dimensions=1536,
        max_dimensions=1536,
        supports_custom_dimensions=True,
    ),
    "text-embedding-3-large": ModelConfig(
        name="text-embedding-3-large",
        provider=EmbeddingProvider.OPENAI,
        default_dimensions=3072,
        max_dimensions=3072,
        supports_custom_dimensions=True,
    ),
}
```

---

## Constants

### Priority Constants

```python
PRIORITY_CRITICAL = "critical"
PRIORITY_HIGH = "high"
PRIORITY_NORMAL = "normal"
PRIORITY_LOW = "low"
```

### Stream Names

```python
STREAM_CRITICAL = "embedding:critical"
STREAM_HIGH = "embedding:high"
STREAM_NORMAL = "embedding:normal"
STREAM_LOW = "embedding:low"
```

### Query Stream Names

```python
QUERY_STREAM_CRITICAL = "query:critical"
QUERY_STREAM_HIGH = "query:high"
QUERY_STREAM_NORMAL = "query:normal"
QUERY_STREAM_LOW = "query:low"
```

---

## Error Types

### ModelValidationError

Raised when an embedding model is invalid or doesn't support the requested dimensions.

```python
class ModelValidationError(ValueError):
    pass
```

**Common causes:**
- Unsupported model name
- Dimensions exceed model's maximum
- Custom dimensions requested for model that doesn't support them

**Example:**
```python
from vector_sdk import ModelValidationError

try:
    client.embeddings.create(
        texts=[{"id": "doc1", "text": "test"}],
        content_type="document",
        embedding_model="invalid-model",
    )
except ModelValidationError as e:
    print(f"Invalid model: {e}")
```

---

### TimeoutError

Raised when a wait operation times out before the result is available.

```python
try:
    result = client.embeddings.create_and_wait(
        texts=[{"id": "doc1", "text": "test"}],
        content_type="document",
        timeout=5,  # Very short timeout
    )
except TimeoutError as e:
    print(f"Request timed out: {e}")
```
