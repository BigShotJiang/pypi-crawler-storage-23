"""
Vector SDK for Python

A client library for embedding generation, vector search, and database operations
via the Vector Gateway services.

Basic usage:
    from vector_sdk import VectorClient

    client = VectorClient(
        redis_url="redis://localhost:6379",
        http_url="http://localhost:8080",
    )

    # Create embeddings
    result = client.embeddings.create_and_wait(
        texts=[{"id": "doc1", "text": "Hello world"}],
        content_type="topic",
    )

    # Vector search
    search_result = client.search.query_and_wait(
        query_text="machine learning",
        database="turbopuffer",
        namespace="topics",
        top_k=10,
    )

    # Direct database lookup
    docs = client.db.get_by_ids(
        ids=["doc1"],
        database="turbopuffer",
        namespace="topics",
    )

    client.close()
"""

# ============================================================================
# Client Exports (New API)
# ============================================================================

from vector_sdk.client import EmbeddingClient, VectorClient

# ============================================================================
# Content Type Registry
# ============================================================================
from vector_sdk.content_types import (
    CONTENT_TYPE_CONFIGS,
    SUPPORTED_CONTENT_TYPES,
    ContentType,
    ContentTypeConfig,
    EmbeddingModel,
    MongoDBStorageConfig,
    Priority,
    TurboPufferStorageConfig,
    get_content_type_config,
    get_model_name,
    get_priority_string,
)

# ============================================================================
# Content Hash
# ============================================================================
from vector_sdk.hash import (
    AnswerObject,
    AudioRecapSectionData,
    FlashCardData,
    FlashCardType,
    MultipleChoiceOption,
    QuestionData,
    ToolCollection,
    TopicData,
    compute_content_hash,
    extract_tool_text,
)

# ============================================================================
# Namespace Exports
# ============================================================================
from vector_sdk.namespaces import (
    BaseNamespace,
    DBNamespace,
    EmbeddingsNamespace,
    SearchNamespace,
)

# ============================================================================
# Structured Embeddings
# ============================================================================
from vector_sdk.structured import (
    TOOL_CONFIGS,
    AudioRecapBatchItem,
    BatchItem,
    DatabaseRoutingError,
    DatabaseRoutingMode,
    FlashCardBatchItem,
    PineconeToolConfig,
    QuestionType,
    StructuredEmbeddingsNamespace,
    TestQuestionBatchItem,
    TestQuestionInput,
    ToolConfig,
    ToolDatabaseConfig,
    ToolMetadata,
    TopicBatchItem,
    TopicMetadata,
    TurboPufferToolConfig,
    build_storage_config,
    get_content_type,
    get_database_routing_mode,
    get_flashcard_namespace_suffix,
    get_pinecone_namespace,
    get_question_namespace_suffix,
    get_tool_config,
    get_turbopuffer_namespace,
    validate_database_routing,
)

# ============================================================================
# Types
# ============================================================================
from vector_sdk.types import (
    # Query stream constants
    QUERY_STREAM_CRITICAL,
    QUERY_STREAM_HIGH,
    QUERY_STREAM_LOW,
    QUERY_STREAM_NORMAL,
    # Model registry
    SUPPORTED_MODELS,
    VECTOR_DATABASE_MONGODB,
    VECTOR_DATABASE_PINECONE,
    VECTOR_DATABASE_TURBOPUFFER,
    # Types
    CallbackConfig,
    CloneResult,
    DeleteFromNamespaceResult,
    Document,
    EmbeddingConfigOverride,
    EmbeddingError,
    EmbeddingProvider,
    EmbeddingRequest,
    EmbeddingResult,
    ExportTiming,
    GetVectorsInNamespaceResult,
    LookupResult,
    LookupTiming,
    ModelConfig,
    ModelValidationError,
    MongoDBStorage,
    NamespaceMetadata,
    PineconeStorageConfig,
    # Query types
    QueryConfig,
    QueryRequest,
    QueryResult,
    QueryTiming,
    StorageConfig,
    TextInput,
    TimingBreakdown,
    TurboPufferStorage,
    VectorMatch,
    get_all_embedding_streams,
    get_embedding_response_key,
    get_google_models,
    get_model_config,
    get_namespace_export_key,
    get_openai_models,
    get_query_response_key,
    get_query_stream_for_priority,
    get_stream_for_priority,
    get_supported_models,
    is_model_supported,
    prefix_key,
    validate_model,
)

__version__ = "0.6.0"

__all__ = [
    # Clients (New API)
    "VectorClient",
    # Backward compatibility
    "EmbeddingClient",
    # Namespaces
    "BaseNamespace",
    "EmbeddingsNamespace",
    "SearchNamespace",
    "DBNamespace",
    # Embedding Request/Response types
    "EmbeddingRequest",
    "EmbeddingResult",
    "TextInput",
    "StorageConfig",
    "MongoDBStorage",
    "TurboPufferStorage",
    "PineconeStorageConfig",
    "CallbackConfig",
    "EmbeddingError",
    "TimingBreakdown",
    # Query types
    "QueryConfig",
    "QueryRequest",
    "QueryResult",
    "VectorMatch",
    "QueryTiming",
    "EmbeddingConfigOverride",
    # Lookup types
    "Document",
    "LookupResult",
    "LookupTiming",
    # Clone and Delete types
    "CloneResult",
    "DeleteFromNamespaceResult",
    # Export namespace types
    "GetVectorsInNamespaceResult",
    "NamespaceMetadata",
    "ExportTiming",
    # Query constants
    "QUERY_STREAM_CRITICAL",
    "QUERY_STREAM_HIGH",
    "QUERY_STREAM_NORMAL",
    "QUERY_STREAM_LOW",
    "VECTOR_DATABASE_MONGODB",
    "VECTOR_DATABASE_TURBOPUFFER",
    "VECTOR_DATABASE_PINECONE",
    "get_query_stream_for_priority",
    "get_stream_for_priority",
    "prefix_key",
    "get_all_embedding_streams",
    "get_embedding_response_key",
    "get_query_response_key",
    "get_namespace_export_key",
    # Model registry
    "SUPPORTED_MODELS",
    "EmbeddingProvider",
    "ModelConfig",
    "ModelValidationError",
    "is_model_supported",
    "get_model_config",
    "get_supported_models",
    "get_google_models",
    "get_openai_models",
    "validate_model",
    # Content type registry
    "ContentType",
    "EmbeddingModel",
    "Priority",
    "ContentTypeConfig",
    "MongoDBStorageConfig",
    "TurboPufferStorageConfig",
    "CONTENT_TYPE_CONFIGS",
    "SUPPORTED_CONTENT_TYPES",
    "get_content_type_config",
    "get_model_name",
    "get_priority_string",
    # Content hash
    "compute_content_hash",
    "extract_tool_text",
    "ToolCollection",
    "FlashCardType",
    "FlashCardData",
    "QuestionData",
    "AudioRecapSectionData",
    "TopicData",
    "MultipleChoiceOption",
    "AnswerObject",
    # Structured Embeddings
    "StructuredEmbeddingsNamespace",
    "ToolMetadata",
    "TopicMetadata",
    "TestQuestionInput",
    # Batch types
    "BatchItem",
    "FlashCardBatchItem",
    "TestQuestionBatchItem",
    "AudioRecapBatchItem",
    "TopicBatchItem",
    # Tool configuration
    "ToolConfig",
    "ToolDatabaseConfig",
    "TurboPufferToolConfig",
    "PineconeToolConfig",
    "QuestionType",
    "TOOL_CONFIGS",
    "get_tool_config",
    "get_flashcard_namespace_suffix",
    "get_question_namespace_suffix",
    "get_turbopuffer_namespace",
    "get_pinecone_namespace",
    "DatabaseRoutingMode",
    "DatabaseRoutingError",
    "get_database_routing_mode",
    "validate_database_routing",
    "build_storage_config",
    "get_content_type",
]
