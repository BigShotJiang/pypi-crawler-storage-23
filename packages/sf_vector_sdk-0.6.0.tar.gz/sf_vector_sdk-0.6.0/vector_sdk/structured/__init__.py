"""
Structured Embeddings Module.

Provides type-safe methods for embedding known tool types (FlashCard, TestQuestion, etc.)
with automatic text extraction, content hash computation, and database routing.
"""

from .router import (
    DatabaseRoutingError,
    DatabaseRoutingMode,
    build_storage_config,
    get_content_type,
    get_database_routing_mode,
    validate_database_routing,
)
from .structured_embeddings import (
    AudioRecapBatchItem,
    BatchItem,
    FlashCardBatchItem,
    StructuredEmbeddingsNamespace,
    TestQuestionBatchItem,
    TestQuestionInput,
    ToolMetadata,
    TopicBatchItem,
    TopicMetadata,
)
from .tool_config import (
    TOOL_CONFIGS,
    PineconeToolConfig,
    QuestionType,
    ToolConfig,
    ToolDatabaseConfig,
    TurboPufferToolConfig,
    get_flashcard_namespace_suffix,
    get_pinecone_namespace,
    get_question_namespace_suffix,
    get_tool_config,
    get_turbopuffer_namespace,
)

__all__ = [
    # Namespace class
    "StructuredEmbeddingsNamespace",
    # Types
    "ToolMetadata",
    "TopicMetadata",
    "TestQuestionInput",
    # Batch types
    "BatchItem",
    "FlashCardBatchItem",
    "TestQuestionBatchItem",
    "AudioRecapBatchItem",
    "TopicBatchItem",
    # Tool configuration
    "ToolConfig",
    "ToolDatabaseConfig",
    "TurboPufferToolConfig",
    "PineconeToolConfig",
    "QuestionType",
    "TOOL_CONFIGS",
    "get_tool_config",
    "get_flashcard_namespace_suffix",
    "get_question_namespace_suffix",
    "get_turbopuffer_namespace",
    "get_pinecone_namespace",
    # Database router
    "DatabaseRoutingMode",
    "DatabaseRoutingError",
    "get_database_routing_mode",
    "validate_database_routing",
    "build_storage_config",
    "get_content_type",
]
