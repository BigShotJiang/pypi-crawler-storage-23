"""
Structured Embeddings Namespace.

Provides type-safe methods for embedding known tool types (FlashCard, TestQuestion, etc.)
with automatic text extraction, content hash computation, and database routing.
"""

from dataclasses import dataclass
from typing import Any, Optional

from ..hash import (
    AudioRecapSectionData,
    FlashCardData,
    ToolCollection,
    TopicData,
    compute_content_hash,
    extract_tool_text,
)
from ..namespaces.base import BaseNamespace
from ..namespaces.embeddings import EmbeddingsNamespace
from ..types import EmbeddingResult
from .router import build_storage_config, get_content_type
from .tool_config import QuestionType, get_tool_config

# ============================================================================
# Types
# ============================================================================


@dataclass
class ToolMetadata:
    """Metadata to store alongside the embedding."""

    tool_id: str
    user_id: Optional[str] = None
    topic_id: Optional[str] = None
    extra: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for document storage."""
        result: dict[str, Any] = {"toolId": self.tool_id}
        if self.user_id:
            result["userId"] = self.user_id
        if self.topic_id:
            result["topicId"] = self.topic_id
        if self.extra:
            result.update(self.extra)
        return result


@dataclass
class TopicMetadata:
    """
    Metadata for topic embeddings.
    Unlike ToolMetadata, all fields are optional since topics don't have a toolId.
    """

    user_id: Optional[str] = None
    topic_id: Optional[str] = None
    extra: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for document storage."""
        result: dict[str, Any] = {}
        if self.user_id:
            result["userId"] = self.user_id
        if self.topic_id:
            result["topicId"] = self.topic_id
        if self.extra:
            result.update(self.extra)
        return result


@dataclass
class TestQuestionInput:
    """Extended question data with question type."""

    question: str
    answers: list[dict[str, Any]]
    question_type: Optional[QuestionType] = None
    explanation: Optional[str] = None

    def to_question_data(self) -> dict[str, Any]:
        """Convert to QuestionData-compatible dict."""
        result: dict[str, Any] = {
            "question": self.question,
            "answers": self.answers,
        }
        if self.explanation:
            result["explanation"] = self.explanation
        return result


@dataclass
class BatchItem:
    """Batch item for embedding multiple items of the same type."""

    data: dict[str, Any]
    metadata: ToolMetadata


@dataclass
class FlashCardBatchItem:
    """Batch item for FlashCard embeddings."""

    data: FlashCardData
    metadata: ToolMetadata


@dataclass
class TestQuestionBatchItem:
    """Batch item for TestQuestion embeddings."""

    data: TestQuestionInput
    metadata: ToolMetadata


@dataclass
class AudioRecapBatchItem:
    """Batch item for AudioRecap embeddings."""

    data: AudioRecapSectionData
    metadata: ToolMetadata


@dataclass
class TopicBatchItem:
    """Batch item for Topic embeddings."""

    data: TopicData
    metadata: TopicMetadata


# ============================================================================
# StructuredEmbeddingsNamespace
# ============================================================================


class StructuredEmbeddingsNamespace(BaseNamespace):
    """
    Namespace for structured tool embeddings.

    Provides type-safe methods for embedding known tool types with automatic:
    - Text extraction per tool spec
    - Content hash computation
    - Namespace derivation based on tool type and sub-type
    - Database routing based on environment configuration

    Example:
        ```python
        client = VectorClient("redis://localhost:6379")

        # Embed a flashcard
        result = client.structured_embeddings.embed_flashcard_and_wait(
            data={"type": "BASIC", "term": "Mitochondria", "definition": "..."},
            metadata=ToolMetadata(tool_id="tool123", user_id="user456"),
        )

        # SDK automatically extracts text, computes hash, and routes to correct database
        ```
    """

    def __init__(
        self,
        redis: Any,
        embeddings: EmbeddingsNamespace,
        http_url: Optional[str] = None,
        api_key: str = None,
    ):
        """
        Initialize the namespace.

        Args:
            redis: Redis client instance
            embeddings: EmbeddingsNamespace instance for submitting requests
            http_url: Optional HTTP URL for query-gateway
            api_key: API key for authentication
        """
        super().__init__(redis, http_url, api_key)
        self._embeddings = embeddings

    # ==========================================================================
    # FlashCard Methods
    # ==========================================================================

    def embed_flashcard(
        self,
        data: FlashCardData,
        metadata: ToolMetadata,
    ) -> str:
        """
        Embed a flashcard and return the request ID.

        Args:
            data: FlashCard data (type, term, definition, multiple_choice_options)
            metadata: Tool metadata (tool_id, user_id, topic_id, etc.)

        Returns:
            The request ID
        """
        card_type = data.get("type")
        return self._embed_tool("FlashCard", data, metadata, card_type)

    def embed_flashcard_and_wait(
        self,
        data: FlashCardData,
        metadata: ToolMetadata,
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a flashcard and wait for the result.

        Args:
            data: FlashCard data
            metadata: Tool metadata
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        card_type = data.get("type")
        return self._embed_tool_and_wait("FlashCard", data, metadata, card_type, timeout)

    def embed_flashcard_batch(
        self,
        items: list[FlashCardBatchItem],
    ) -> str:
        """
        Embed a batch of flashcards and return the request ID.
        All flashcards in the batch should have the same type for proper namespace routing.

        Args:
            items: List of FlashCardBatchItem objects

        Returns:
            The request ID
        """
        return self._embed_tool_batch(
            "FlashCard",
            [
                {
                    "data": item.data,
                    "metadata": item.metadata,
                    "sub_type": item.data.get("type") if isinstance(item.data, dict) else None,
                }
                for item in items
            ],
        )

    def embed_flashcard_batch_and_wait(
        self,
        items: list[FlashCardBatchItem],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a batch of flashcards and wait for the result.
        All flashcards in the batch should have the same type for proper namespace routing.

        Args:
            items: List of FlashCardBatchItem objects
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_tool_batch_and_wait(
            "FlashCard",
            [
                {
                    "data": item.data,
                    "metadata": item.metadata,
                    "sub_type": item.data.get("type") if isinstance(item.data, dict) else None,
                }
                for item in items
            ],
            timeout,
        )

    # ==========================================================================
    # TestQuestion Methods
    # ==========================================================================

    def embed_test_question(
        self,
        data: TestQuestionInput,
        metadata: ToolMetadata,
    ) -> str:
        """
        Embed a test question and return the request ID.

        Args:
            data: Question data (question, answers, explanation, question_type)
            metadata: Tool metadata

        Returns:
            The request ID
        """
        return self._embed_tool(
            "TestQuestion",
            data.to_question_data(),
            metadata,
            data.question_type,
        )

    def embed_test_question_and_wait(
        self,
        data: TestQuestionInput,
        metadata: ToolMetadata,
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a test question and wait for the result.

        Args:
            data: Question data
            metadata: Tool metadata
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_tool_and_wait(
            "TestQuestion",
            data.to_question_data(),
            metadata,
            data.question_type,
            timeout,
        )

    def embed_test_question_batch(
        self,
        items: list[TestQuestionBatchItem],
    ) -> str:
        """
        Embed a batch of test questions and return the request ID.
        All questions in the batch should have the same question_type for proper namespace routing.

        Args:
            items: List of TestQuestionBatchItem objects

        Returns:
            The request ID
        """
        return self._embed_tool_batch(
            "TestQuestion",
            [
                {
                    "data": item.data.to_question_data(),
                    "metadata": item.metadata,
                    "sub_type": item.data.question_type,
                }
                for item in items
            ],
        )

    def embed_test_question_batch_and_wait(
        self,
        items: list[TestQuestionBatchItem],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a batch of test questions and wait for the result.
        All questions in the batch should have the same question_type for proper namespace routing.

        Args:
            items: List of TestQuestionBatchItem objects
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_tool_batch_and_wait(
            "TestQuestion",
            [
                {
                    "data": item.data.to_question_data(),
                    "metadata": item.metadata,
                    "sub_type": item.data.question_type,
                }
                for item in items
            ],
            timeout,
        )

    # ==========================================================================
    # SpacedTestQuestion Methods
    # ==========================================================================

    def embed_spaced_test_question(
        self,
        data: TestQuestionInput,
        metadata: ToolMetadata,
    ) -> str:
        """
        Embed a spaced test question and return the request ID.

        Args:
            data: Question data
            metadata: Tool metadata

        Returns:
            The request ID
        """
        return self._embed_tool(
            "SpacedTestQuestion",
            data.to_question_data(),
            metadata,
            data.question_type,
        )

    def embed_spaced_test_question_and_wait(
        self,
        data: TestQuestionInput,
        metadata: ToolMetadata,
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a spaced test question and wait for the result.

        Args:
            data: Question data
            metadata: Tool metadata
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_tool_and_wait(
            "SpacedTestQuestion",
            data.to_question_data(),
            metadata,
            data.question_type,
            timeout,
        )

    def embed_spaced_test_question_batch(
        self,
        items: list[TestQuestionBatchItem],
    ) -> str:
        """
        Embed a batch of spaced test questions and return the request ID.
        All questions in the batch should have the same question_type for proper namespace routing.

        Args:
            items: List of TestQuestionBatchItem objects

        Returns:
            The request ID
        """
        return self._embed_tool_batch(
            "SpacedTestQuestion",
            [
                {
                    "data": item.data.to_question_data(),
                    "metadata": item.metadata,
                    "sub_type": item.data.question_type,
                }
                for item in items
            ],
        )

    def embed_spaced_test_question_batch_and_wait(
        self,
        items: list[TestQuestionBatchItem],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a batch of spaced test questions and wait for the result.
        All questions in the batch should have the same question_type for proper namespace routing.

        Args:
            items: List of TestQuestionBatchItem objects
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_tool_batch_and_wait(
            "SpacedTestQuestion",
            [
                {
                    "data": item.data.to_question_data(),
                    "metadata": item.metadata,
                    "sub_type": item.data.question_type,
                }
                for item in items
            ],
            timeout,
        )

    # ==========================================================================
    # AudioRecap Methods
    # ==========================================================================

    def embed_audio_recap(
        self,
        data: AudioRecapSectionData,
        metadata: ToolMetadata,
    ) -> str:
        """
        Embed an audio recap section and return the request ID.

        Args:
            data: Audio recap data (script)
            metadata: Tool metadata

        Returns:
            The request ID
        """
        return self._embed_tool("AudioRecapV2Section", data, metadata, None)

    def embed_audio_recap_and_wait(
        self,
        data: AudioRecapSectionData,
        metadata: ToolMetadata,
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed an audio recap section and wait for the result.

        Args:
            data: Audio recap data
            metadata: Tool metadata
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_tool_and_wait(
            "AudioRecapV2Section",
            data,
            metadata,
            None,
            timeout,
        )

    def embed_audio_recap_batch(
        self,
        items: list[AudioRecapBatchItem],
    ) -> str:
        """
        Embed a batch of audio recap sections and return the request ID.

        Args:
            items: List of AudioRecapBatchItem objects

        Returns:
            The request ID
        """
        return self._embed_tool_batch(
            "AudioRecapV2Section",
            [
                {
                    "data": item.data,
                    "metadata": item.metadata,
                    "sub_type": None,
                }
                for item in items
            ],
        )

    def embed_audio_recap_batch_and_wait(
        self,
        items: list[AudioRecapBatchItem],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a batch of audio recap sections and wait for the result.

        Args:
            items: List of AudioRecapBatchItem objects
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_tool_batch_and_wait(
            "AudioRecapV2Section",
            [
                {
                    "data": item.data,
                    "metadata": item.metadata,
                    "sub_type": None,
                }
                for item in items
            ],
            timeout,
        )

    # ==========================================================================
    # Topic Methods
    # ==========================================================================

    def embed_topic(
        self,
        data: TopicData,
        metadata: TopicMetadata,
    ) -> str:
        """
        Embed a topic and return the request ID.

        Args:
            data: Topic data (topic, description)
            metadata: Topic metadata (all fields optional)

        Returns:
            The request ID
        """
        return self._embed_topic_internal("Topic", data, metadata, None)

    def embed_topic_and_wait(
        self,
        data: TopicData,
        metadata: TopicMetadata,
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a topic and wait for the result.

        Args:
            data: Topic data
            metadata: Topic metadata (all fields optional)
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_topic_internal_and_wait("Topic", data, metadata, None, timeout)

    def embed_topic_batch(
        self,
        items: list[TopicBatchItem],
    ) -> str:
        """
        Embed a batch of topics and return the request ID.

        Args:
            items: List of TopicBatchItem objects

        Returns:
            The request ID
        """
        return self._embed_topic_batch_internal(items)

    def embed_topic_batch_and_wait(
        self,
        items: list[TopicBatchItem],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Embed a batch of topics and wait for the result.

        Args:
            items: List of TopicBatchItem objects
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        return self._embed_topic_batch_internal_and_wait(items, timeout)

    # ==========================================================================
    # Internal Topic Methods (using TopicMetadata)
    # ==========================================================================

    def _embed_topic_internal(
        self,
        tool_collection: ToolCollection,
        data: TopicData,
        metadata: TopicMetadata,
        sub_type: Optional[str],
    ) -> str:
        """Internal method to embed a topic with TopicMetadata."""
        # 1. Extract text using the spec
        text = extract_tool_text(tool_collection, data)
        if not text:
            raise ValueError(
                f"Failed to extract text from {tool_collection} - empty content"
            )

        # 2. Compute content hash
        content_hash = compute_content_hash(tool_collection, data)
        if not content_hash:
            raise ValueError(
                f"Failed to compute content hash for {tool_collection} - empty content"
            )

        # 3. Get tool config
        tool_config = get_tool_config(tool_collection)

        # 4. Build document with metadata (TopicMetadata doesn't have toolId)
        document = {
            **metadata.to_dict(),
            "id": data["id"],
            "toolCollection": tool_collection,
            "contentHash": content_hash,
        }

        # 5. Build storage config using router
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=sub_type,
            content_hash=content_hash,
            document_fields=document,
        )

        # 6. Build text input - use data["id"] as the TurboPuffer document ID
        text_input = {
            "id": data["id"],
            "text": text,
            "document": document,
        }

        # 7. Submit using embeddings namespace (topics allow duplicates - content may change for same ID)
        return self._embeddings.create(
            texts=[text_input],
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
            allow_duplicates=True,
        )

    def _embed_topic_internal_and_wait(
        self,
        tool_collection: ToolCollection,
        data: TopicData,
        metadata: TopicMetadata,
        sub_type: Optional[str],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """Internal method to embed a topic and wait for result."""
        # 1. Extract text using the spec
        text = extract_tool_text(tool_collection, data)
        if not text:
            raise ValueError(
                f"Failed to extract text from {tool_collection} - empty content"
            )

        # 2. Compute content hash
        content_hash = compute_content_hash(tool_collection, data)
        if not content_hash:
            raise ValueError(
                f"Failed to compute content hash for {tool_collection} - empty content"
            )

        # 3. Get tool config
        tool_config = get_tool_config(tool_collection)

        # 4. Build document with metadata
        document = {
            **metadata.to_dict(),
            "id": data["id"],
            "toolCollection": tool_collection,
            "contentHash": content_hash,
        }

        # 5. Build storage config using router
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=sub_type,
            content_hash=content_hash,
            document_fields=document,
        )

        # 6. Build text input - use data["id"] as the TurboPuffer document ID
        text_input = {
            "id": data["id"],
            "text": text,
            "document": document,
        }

        # 7. Submit and wait (topics allow duplicates - content may change for same ID)
        return self._embeddings.create_and_wait(
            texts=[text_input],
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
            allow_duplicates=True,
            timeout=timeout,
        )

    def _embed_topic_batch_internal(
        self,
        items: list[TopicBatchItem],
    ) -> str:
        """Internal method to embed a batch of topics."""
        if not items:
            raise ValueError("Batch cannot be empty")

        tool_collection: ToolCollection = "Topic"
        tool_config = get_tool_config(tool_collection)

        # Process each item
        text_inputs = []
        for item in items:
            data = item.data
            metadata = item.metadata

            # Extract text
            text = extract_tool_text(tool_collection, data)
            if not text:
                raise ValueError(
                    f"Failed to extract text from {tool_collection} - empty content"
                )

            # Compute content hash
            content_hash = compute_content_hash(tool_collection, data)
            if not content_hash:
                raise ValueError(
                    f"Failed to compute content hash for {tool_collection} - empty content"
                )

            # Build document with metadata (TopicMetadata doesn't have toolId)
            document = {
                **metadata.to_dict(),
                "id": data["id"],
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            }

            # Use data["id"] as the TurboPuffer document ID
            text_inputs.append({
                "id": data["id"],
                "text": text,
                "document": document,
            })

        # Build storage config using first item
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=None,
            content_hash=text_inputs[0]["document"]["contentHash"],
            document_fields=text_inputs[0]["document"],
        )

        # Submit batch to embeddings namespace (topics allow duplicates - content may change for same ID)
        return self._embeddings.create(
            texts=text_inputs,
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "batchSize": str(len(items)),
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
            allow_duplicates=True,
        )

    def _embed_topic_batch_internal_and_wait(
        self,
        items: list[TopicBatchItem],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """Internal method to embed a batch of topics and wait for result."""
        if not items:
            raise ValueError("Batch cannot be empty")

        tool_collection: ToolCollection = "Topic"
        tool_config = get_tool_config(tool_collection)

        # Process each item
        text_inputs = []
        for item in items:
            data = item.data
            metadata = item.metadata

            # Extract text
            text = extract_tool_text(tool_collection, data)
            if not text:
                raise ValueError(
                    f"Failed to extract text from {tool_collection} - empty content"
                )

            # Compute content hash
            content_hash = compute_content_hash(tool_collection, data)
            if not content_hash:
                raise ValueError(
                    f"Failed to compute content hash for {tool_collection} - empty content"
                )

            # Build document with metadata
            document = {
                **metadata.to_dict(),
                "id": data["id"],
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            }

            # Use data["id"] as the TurboPuffer document ID
            text_inputs.append({
                "id": data["id"],
                "text": text,
                "document": document,
            })

        # Build storage config using first item
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=None,
            content_hash=text_inputs[0]["document"]["contentHash"],
            document_fields=text_inputs[0]["document"],
        )

        # Submit batch and wait (topics allow duplicates - content may change for same ID)
        return self._embeddings.create_and_wait(
            texts=text_inputs,
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "batchSize": str(len(items)),
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
            allow_duplicates=True,
            timeout=timeout,
        )

    # ==========================================================================
    # Internal Methods
    # ==========================================================================

    def _embed_tool(
        self,
        tool_collection: ToolCollection,
        data: dict[str, Any],
        metadata: ToolMetadata,
        sub_type: Optional[str],
    ) -> str:
        """Internal method to embed any tool type."""
        # 1. Extract text using the spec
        text = extract_tool_text(tool_collection, data)
        if not text:
            raise ValueError(
                f"Failed to extract text from {tool_collection} - empty content"
            )

        # 2. Compute content hash
        content_hash = compute_content_hash(tool_collection, data)
        if not content_hash:
            raise ValueError(
                f"Failed to compute content hash for {tool_collection} - empty content"
            )

        # 3. Get tool config
        tool_config = get_tool_config(tool_collection)

        # 4. Build document with metadata
        document = {
            **metadata.to_dict(),
            "toolCollection": tool_collection,
            "contentHash": content_hash,
        }

        # 5. Build storage config using router
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=sub_type,
            content_hash=content_hash,
            document_fields=document,
        )

        # 6. Build text input
        text_input = {
            "id": content_hash,
            "text": text,
            "document": document,
        }

        # 7. Submit to embeddings namespace
        return self._embeddings.create(
            texts=[text_input],
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
        )

    def _embed_tool_and_wait(
        self,
        tool_collection: ToolCollection,
        data: dict[str, Any],
        metadata: ToolMetadata,
        sub_type: Optional[str],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """Internal method to embed any tool type and wait for result."""
        # 1. Extract text using the spec
        text = extract_tool_text(tool_collection, data)
        if not text:
            raise ValueError(
                f"Failed to extract text from {tool_collection} - empty content"
            )

        # 2. Compute content hash
        content_hash = compute_content_hash(tool_collection, data)
        if not content_hash:
            raise ValueError(
                f"Failed to compute content hash for {tool_collection} - empty content"
            )

        # 3. Get tool config
        tool_config = get_tool_config(tool_collection)

        # 4. Build document with metadata
        document = {
            **metadata.to_dict(),
            "toolCollection": tool_collection,
            "contentHash": content_hash,
        }

        # 5. Build storage config using router
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=sub_type,
            content_hash=content_hash,
            document_fields=document,
        )

        # 6. Build text input
        text_input = {
            "id": content_hash,
            "text": text,
            "document": document,
        }

        # 7. Submit and wait using embeddings namespace
        return self._embeddings.create_and_wait(
            texts=[text_input],
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
            timeout=timeout,
        )

    def _embed_tool_batch(
        self,
        tool_collection: ToolCollection,
        items: list[dict[str, Any]],
    ) -> str:
        """
        Internal method to embed a batch of items of the same tool type.

        Args:
            tool_collection: The tool collection type
            items: List of dicts with 'data', 'metadata', and optional 'sub_type' keys

        Returns:
            The request ID
        """
        if not items:
            raise ValueError("Batch cannot be empty")

        # Get tool config (same for all items)
        tool_config = get_tool_config(tool_collection)

        # Process each item
        text_inputs = []
        for item in items:
            data = item["data"]
            metadata = item["metadata"]

            # Extract text
            text = extract_tool_text(tool_collection, data)
            if not text:
                raise ValueError(
                    f"Failed to extract text from {tool_collection} - empty content"
                )

            # Compute content hash
            content_hash = compute_content_hash(tool_collection, data)
            if not content_hash:
                raise ValueError(
                    f"Failed to compute content hash for {tool_collection} - empty content"
                )

            # Build document with metadata
            document = {
                **metadata.to_dict(),
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            }

            text_inputs.append({
                "id": content_hash,
                "text": text,
                "document": document,
            })

        # Build storage config using first item's sub_type
        first_item = items[0]
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=first_item.get("sub_type"),
            content_hash=text_inputs[0]["id"],
            document_fields=text_inputs[0]["document"],
        )

        # Submit batch to embeddings namespace
        return self._embeddings.create(
            texts=text_inputs,
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "batchSize": str(len(items)),
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
        )

    def _embed_tool_batch_and_wait(
        self,
        tool_collection: ToolCollection,
        items: list[dict[str, Any]],
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Internal method to embed a batch of items and wait for result.

        Args:
            tool_collection: The tool collection type
            items: List of dicts with 'data', 'metadata', and optional 'sub_type' keys
            timeout: Timeout in seconds (default: 60)

        Returns:
            The embedding result
        """
        if not items:
            raise ValueError("Batch cannot be empty")

        # Get tool config (same for all items)
        tool_config = get_tool_config(tool_collection)

        # Process each item
        text_inputs = []
        for item in items:
            data = item["data"]
            metadata = item["metadata"]

            # Extract text
            text = extract_tool_text(tool_collection, data)
            if not text:
                raise ValueError(
                    f"Failed to extract text from {tool_collection} - empty content"
                )

            # Compute content hash
            content_hash = compute_content_hash(tool_collection, data)
            if not content_hash:
                raise ValueError(
                    f"Failed to compute content hash for {tool_collection} - empty content"
                )

            # Build document with metadata
            document = {
                **metadata.to_dict(),
                "toolCollection": tool_collection,
                "contentHash": content_hash,
            }

            text_inputs.append({
                "id": content_hash,
                "text": text,
                "document": document,
            })

        # Build storage config using first item's sub_type
        first_item = items[0]
        storage_config = build_storage_config(
            tool_collection=tool_collection,
            sub_type=first_item.get("sub_type"),
            content_hash=text_inputs[0]["id"],
            document_fields=text_inputs[0]["document"],
        )

        # Submit batch and wait
        return self._embeddings.create_and_wait(
            texts=text_inputs,
            content_type=get_content_type(tool_collection),
            priority=tool_config.default_priority,
            storage=storage_config,
            metadata={
                "toolCollection": tool_collection,
                "batchSize": str(len(items)),
            },
            embedding_model=tool_config.model,
            embedding_dimensions=tool_config.dimensions,
            timeout=timeout,
        )
