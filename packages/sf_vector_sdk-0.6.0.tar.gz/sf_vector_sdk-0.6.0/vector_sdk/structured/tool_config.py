"""
Tool Configuration for Structured Embeddings.

Defines the configuration for each tool type including:
- Embedding model and dimensions
- TurboPuffer namespace patterns
- Pinecone index and namespace patterns
- Enabled/disabled status for each database
"""

from dataclasses import dataclass
from typing import Literal, Optional

from ..hash import FlashCardType, ToolCollection
from ..types import PRIORITY_HIGH, PRIORITY_NORMAL

# ============================================================================
# Types
# ============================================================================


@dataclass(frozen=True)
class ToolDatabaseConfig:
    """Database-specific configuration for a tool type."""

    enabled: bool
    id_field: str
    metadata_fields: tuple[str, ...]


@dataclass(frozen=True)
class TurboPufferToolConfig(ToolDatabaseConfig):
    """TurboPuffer-specific configuration."""

    namespace_pattern: str


@dataclass(frozen=True)
class PineconeToolConfig(ToolDatabaseConfig):
    """Pinecone-specific configuration."""

    index_name: str
    namespace_pattern: str


@dataclass(frozen=True)
class ToolConfig:
    """Configuration for a tool collection type."""

    tool_collection: ToolCollection
    model: str
    dimensions: int
    default_priority: str
    turbopuffer: TurboPufferToolConfig
    pinecone: PineconeToolConfig


# ============================================================================
# Tool Configurations
# ============================================================================

_DEFAULT_METADATA_FIELDS = (
    "toolId",
    "toolCollection",
    "topicId",
    "userId",
    "contentHash",
)

TOOL_CONFIGS: dict[ToolCollection, ToolConfig] = {
    "FlashCard": ToolConfig(
        tool_collection="FlashCard",
        model="gemini-embedding-001",
        dimensions=3072,
        default_priority=PRIORITY_HIGH,
        turbopuffer=TurboPufferToolConfig(
            enabled=True,
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="flashcard_{type}_tool_embedding",
        ),
        pinecone=PineconeToolConfig(
            enabled=False,
            index_name="tool-vectors",
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="flashcard_{type}",
        ),
    ),
    "TestQuestion": ToolConfig(
        tool_collection="TestQuestion",
        model="gemini-embedding-001",
        dimensions=3072,
        default_priority=PRIORITY_HIGH,
        turbopuffer=TurboPufferToolConfig(
            enabled=True,
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="testquestion_{type}_tool_embedding",
        ),
        pinecone=PineconeToolConfig(
            enabled=False,
            index_name="tool-vectors",
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="testquestion_{type}",
        ),
    ),
    "SpacedTestQuestion": ToolConfig(
        tool_collection="SpacedTestQuestion",
        model="gemini-embedding-001",
        dimensions=3072,
        default_priority=PRIORITY_NORMAL,
        turbopuffer=TurboPufferToolConfig(
            enabled=True,
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="spacedtestquestion_{type}_tool_embedding",
        ),
        pinecone=PineconeToolConfig(
            enabled=False,
            index_name="tool-vectors",
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="spacedtestquestion_{type}",
        ),
    ),
    "AudioRecapV2Section": ToolConfig(
        tool_collection="AudioRecapV2Section",
        model="gemini-embedding-001",
        dimensions=3072,
        default_priority=PRIORITY_NORMAL,
        turbopuffer=TurboPufferToolConfig(
            enabled=True,
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="audiorecapv2section_tool_embedding",
        ),
        pinecone=PineconeToolConfig(
            enabled=False,
            index_name="tool-vectors",
            id_field="contentHash",
            metadata_fields=_DEFAULT_METADATA_FIELDS,
            namespace_pattern="audiorecapv2section",
        ),
    ),
    "Topic": ToolConfig(
        tool_collection="Topic",
        model="gemini-embedding-001",
        dimensions=3072,
        default_priority=PRIORITY_NORMAL,
        turbopuffer=TurboPufferToolConfig(
            enabled=True,
            id_field="id",
            metadata_fields=("toolId", "toolCollection", "topicId", "userId", "contentHash", "id"),
            namespace_pattern="topic_vectors",
        ),
        pinecone=PineconeToolConfig(
            enabled=False,
            index_name="tool-vectors",
            id_field="id",
            metadata_fields=("toolId", "toolCollection", "topicId", "userId", "contentHash", "id"),
            namespace_pattern="topic_vectors",
        ),
    ),
}


# ============================================================================
# Sub-type Mappings
# ============================================================================

QuestionType = Literal[
    "multiplechoice",
    "truefalse",
    "shortanswer",
    "fillinblank",
    "frq",
]


def get_flashcard_namespace_suffix(card_type: Optional[FlashCardType]) -> str:
    """Map FlashCardType to namespace suffix."""
    mapping = {
        "BASIC": "basic",
        "CLOZE": "cloze",
        "FILL_IN_THE_BLANK": "fillintheblank",
        "MULTIPLE_CHOICE": "multiplechoice",
        "IMAGE_OCCLUSION": "imageocclusion",
    }
    return mapping.get(card_type or "BASIC", "basic")


def get_question_namespace_suffix(question_type: Optional[str]) -> str:
    """
    Map question type string to namespace suffix.
    Normalizes input to lowercase to handle MongoDB formats like "multipleChoice", "trueFalse", etc.
    """
    if not question_type:
        return "multiplechoice"
    # Normalize: "multipleChoice" -> "multiplechoice", "trueFalse" -> "truefalse"
    return question_type.lower()


# ============================================================================
# Namespace Derivation
# ============================================================================


def get_turbopuffer_namespace(
    tool_collection: ToolCollection,
    sub_type: Optional[str] = None,
) -> str:
    """
    Derive the TurboPuffer namespace for a tool.

    Args:
        tool_collection: The tool collection type
        sub_type: The sub-type (FlashCardType or QuestionType)

    Returns:
        The derived namespace string
    """
    config = TOOL_CONFIGS[tool_collection]
    pattern = config.turbopuffer.namespace_pattern

    # AudioRecapV2Section and Topic don't have sub-types
    if tool_collection in ("AudioRecapV2Section", "Topic"):
        return pattern

    # Derive the type suffix
    if tool_collection == "FlashCard":
        type_suffix = get_flashcard_namespace_suffix(sub_type)  # type: ignore
    else:
        type_suffix = get_question_namespace_suffix(sub_type)  # type: ignore

    return pattern.replace("{type}", type_suffix)


def get_pinecone_namespace(
    tool_collection: ToolCollection,
    sub_type: Optional[str] = None,
) -> str:
    """
    Derive the Pinecone namespace for a tool.

    Args:
        tool_collection: The tool collection type
        sub_type: The sub-type (FlashCardType or QuestionType)

    Returns:
        The derived namespace string
    """
    config = TOOL_CONFIGS[tool_collection]
    pattern = config.pinecone.namespace_pattern

    # AudioRecapV2Section and Topic don't have sub-types
    if tool_collection in ("AudioRecapV2Section", "Topic"):
        return pattern

    # Derive the type suffix
    if tool_collection == "FlashCard":
        type_suffix = get_flashcard_namespace_suffix(sub_type)  # type: ignore
    else:
        type_suffix = get_question_namespace_suffix(sub_type)  # type: ignore

    return pattern.replace("{type}", type_suffix)


def get_tool_config(tool_collection: ToolCollection) -> ToolConfig:
    """
    Get the tool configuration for a tool collection.

    Args:
        tool_collection: The tool collection type

    Returns:
        The tool configuration
    """
    return TOOL_CONFIGS[tool_collection]
