"""
Database Router for Structured Embeddings.

Routes embedding writes to the appropriate databases based on:
- STRUCTURED_EMBEDDING_DATABASE_ROUTER environment variable
- Per-tool enabled/disabled configuration
"""

import os
from typing import Any, Literal, Optional

from ..hash import ToolCollection
from ..types import (
    PineconeStorageConfig,
    StorageConfig,
    TurboPufferStorage,
)
from .tool_config import (
    get_pinecone_namespace,
    get_tool_config,
    get_turbopuffer_namespace,
)

# ============================================================================
# Types
# ============================================================================

DatabaseRoutingMode = Literal["dual", "turbopuffer", "pinecone"]


class DatabaseRoutingError(Exception):
    """Error thrown when database routing fails."""

    pass


# ============================================================================
# Environment Variable
# ============================================================================

ENV_VAR_NAME = "STRUCTURED_EMBEDDING_DATABASE_ROUTER"


def get_database_routing_mode() -> DatabaseRoutingMode:
    """
    Get the database routing mode from environment variable.
    Defaults to 'turbopuffer' if not set.
    """
    env_value = os.environ.get(ENV_VAR_NAME)

    if not env_value:
        return "turbopuffer"

    mode = env_value.lower()

    if mode not in ("dual", "turbopuffer", "pinecone"):
        raise DatabaseRoutingError(
            f"Invalid {ENV_VAR_NAME} value: '{env_value}'. "
            "Must be 'dual', 'turbopuffer', or 'pinecone'."
        )

    return mode  # type: ignore


# ============================================================================
# Validation
# ============================================================================


def validate_database_routing(
    tool_collection: ToolCollection,
    mode: DatabaseRoutingMode,
) -> None:
    """
    Validate that the required databases are enabled for the routing mode.

    Args:
        tool_collection: The tool collection type
        mode: The database routing mode

    Raises:
        DatabaseRoutingError: If validation fails
    """
    config = get_tool_config(tool_collection)

    if mode == "turbopuffer":
        if not config.turbopuffer.enabled:
            raise DatabaseRoutingError(
                f"Database routing mode 'turbopuffer' requested but "
                f"turbopuffer.enabled is false for {tool_collection}"
            )

    elif mode == "pinecone":
        if not config.pinecone.enabled:
            raise DatabaseRoutingError(
                f"Database routing mode 'pinecone' requested but "
                f"pinecone.enabled is false for {tool_collection}"
            )

    elif mode == "dual":
        # In dual mode, at least one database must be enabled
        if not config.turbopuffer.enabled and not config.pinecone.enabled:
            raise DatabaseRoutingError(
                f"No databases enabled for {tool_collection}. "
                "At least one of turbopuffer or pinecone must be enabled."
            )


# ============================================================================
# Storage Config Builder
# ============================================================================


def build_storage_config(
    tool_collection: ToolCollection,
    sub_type: Optional[str],
    content_hash: str,
    document_fields: dict[str, Any],
) -> StorageConfig:
    """
    Build the storage configuration for a structured embedding request.

    This function:
    1. Gets the routing mode from environment
    2. Validates that required databases are enabled
    3. Builds the storage config with appropriate namespaces

    Args:
        tool_collection: Tool collection type
        sub_type: Sub-type (FlashCardType or QuestionType)
        content_hash: Content hash (used as vector ID)
        document_fields: Additional document fields to store

    Returns:
        StorageConfig for the embedding request

    Raises:
        DatabaseRoutingError: If validation fails
    """
    mode = get_database_routing_mode()
    validate_database_routing(tool_collection, mode)

    config = get_tool_config(tool_collection)

    # Build TurboPuffer config if enabled and requested
    turbopuffer = None
    include_turbopuffer = config.turbopuffer.enabled and mode in (
        "turbopuffer",
        "dual",
    )

    if include_turbopuffer:
        namespace = get_turbopuffer_namespace(tool_collection, sub_type)
        turbopuffer = TurboPufferStorage(
            namespace=namespace,
            id_field=config.turbopuffer.id_field,
            metadata=list(config.turbopuffer.metadata_fields),
        )

    # Build Pinecone config if enabled and requested
    pinecone = None
    include_pinecone = config.pinecone.enabled and mode in ("pinecone", "dual")

    if include_pinecone:
        namespace = get_pinecone_namespace(tool_collection, sub_type)
        pinecone = PineconeStorageConfig(
            index_name=config.pinecone.index_name,
            namespace=namespace,
            id_field=config.pinecone.id_field,
            metadata=list(config.pinecone.metadata_fields),
        )

    return StorageConfig(
        turbopuffer=turbopuffer,
        pinecone=pinecone,
    )


def get_content_type(tool_collection: ToolCollection) -> str:
    """
    Get the content type string for the embedding request.
    Maps tool collections to the contentType used in embedding requests.
    """
    mapping: dict[ToolCollection, str] = {
        "FlashCard": "flashcard",
        "TestQuestion": "testquestion",
        "SpacedTestQuestion": "spacedtestquestion",
        "AudioRecapV2Section": "audiorecap",
    }
    return mapping.get(tool_collection, "tool")
