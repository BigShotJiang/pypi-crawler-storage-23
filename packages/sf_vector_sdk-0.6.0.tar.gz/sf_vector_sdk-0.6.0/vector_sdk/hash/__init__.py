"""
Content Hash Module.

Generates deterministic content hashes for learning tools.
Mirrors the TypeScript implementation in packages/ts/vector-sdk/src/common/hash.ts

See docs/CONTENT-HASH-SPEC.md for the full specification.
"""

from .hasher import compute_content_hash, extract_tool_text
from .types import (
    AnswerObject,
    AudioRecapSectionData,
    FlashCardData,
    FlashCardType,
    MultipleChoiceOption,
    QuestionData,
    ToolCollection,
    TopicData,
)

__all__ = [
    "compute_content_hash",
    "extract_tool_text",
    "ToolCollection",
    "FlashCardType",
    "FlashCardData",
    "QuestionData",
    "AudioRecapSectionData",
    "TopicData",
    "MultipleChoiceOption",
    "AnswerObject",
]
