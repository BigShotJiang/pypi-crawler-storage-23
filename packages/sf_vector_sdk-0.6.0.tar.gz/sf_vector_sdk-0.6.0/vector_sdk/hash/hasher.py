"""
Content hash computation.

Generates deterministic content hashes for learning tools.
Mirrors the TypeScript implementation in packages/ts/vector-sdk/src/common/hash.ts
"""

import hashlib
import re
from typing import Union

from .types import (
    AudioRecapSectionData,
    FlashCardData,
    MultipleChoiceOption,
    QuestionData,
    ToolCollection,
    TopicData,
)

# Hash length in hex characters (128 bits = 32 hex chars)
HASH_LENGTH = 32


def compute_content_hash(
    tool_collection: ToolCollection,
    data: Union[FlashCardData, QuestionData, AudioRecapSectionData, TopicData, dict],
) -> str:
    """
    Compute a deterministic content hash for a learning tool.

    The hash is computed by:
    1. Extracting text content based on the tool collection type
    2. Computing SHA-256 hash of the text
    3. Truncating to first 32 hex characters (128 bits)

    For FlashCard, if no type is provided, defaults to "BASIC".
    Other tool collections (TestQuestion, SpacedTestQuestion, AudioRecapV2Section)
    do not have type variants.

    Args:
        tool_collection: The tool type (FlashCard, TestQuestion, etc.)
        data: Tool-specific data (can be Pydantic model or dict)

    Returns:
        The content hash (32 hex chars) or empty string if no content
    """
    text = extract_tool_text(tool_collection, data)
    if not text:
        return ""
    return _compute_hash(text)


def extract_tool_text(
    tool_collection: ToolCollection,
    data: Union[FlashCardData, QuestionData, AudioRecapSectionData, TopicData, dict],
) -> str:
    """
    Extract the text content from a learning tool for embedding.

    This function extracts the text that will be used for vector embedding
    based on the tool collection type. Use this when you need the raw text
    for embedding rather than the hash.

    Text extraction rules:
    - FlashCard (BASIC): "Term: {term} Definition: {definition}"
    - FlashCard (CLOZE/FILL_IN_THE_BLANK): Same as BASIC, with {{...}} syntax stripped
    - FlashCard (MULTIPLE_CHOICE): "Term: {term} Options: {opt1, opt2, ...}"
    - TestQuestion/SpacedTestQuestion: "Question: {question} Answers: {a1, a2, ...} Explanation: {explanation}"
    - AudioRecapV2Section: "Script: {script}"

    Args:
        tool_collection: The tool type (FlashCard, TestQuestion, etc.)
        data: Tool-specific data (can be Pydantic model or dict)

    Returns:
        The extracted text string or empty string if no content

    Example:
        >>> text = extract_tool_text(
        ...     "FlashCard",
        ...     {"type": "BASIC", "term": "Hello", "definition": "World"}
        ... )
        >>> # Returns: "Term: Hello Definition: World"
    """
    # Convert dict to appropriate model if needed
    if isinstance(data, dict):
        data_dict = data
    else:
        data_dict = data.model_dump(by_alias=True) if hasattr(data, "model_dump") else dict(data)

    if tool_collection == "FlashCard":
        return _extract_flashcard_text(data_dict)
    elif tool_collection in ("TestQuestion", "SpacedTestQuestion"):
        return _extract_question_text(data_dict)
    elif tool_collection == "AudioRecapV2Section":
        return _extract_audio_recap_text(data_dict)
    elif tool_collection == "Topic":
        return _extract_topic_text(data_dict)
    else:
        return ""


def _compute_hash(text: str) -> str:
    """Compute SHA-256 hash and truncate to HASH_LENGTH characters."""
    if not text:
        return ""
    hash_bytes = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return hash_bytes[:HASH_LENGTH]


def _extract_flashcard_text(data: dict) -> str:
    """
    Extract text from a FlashCard document.

    Handles all variants: BASIC, CLOZE, FILL_IN_THE_BLANK, MULTIPLE_CHOICE
    """
    parts: list[str] = []
    card_type = data.get("type") or "BASIC"

    # Extract term (all types have this)
    term = data.get("term")
    if term:
        clean_term = _strip_flashcard_syntax(term.strip())
        if clean_term:
            parts.append(f"Term: {clean_term}")

    # Handle definition/options based on type
    if card_type == "MULTIPLE_CHOICE":
        # Check both camelCase and snake_case keys
        options = data.get("multipleChoiceOptions") or data.get("multiple_choice_options")
        option_texts = _get_multiple_choice_options(options)
        if option_texts:
            parts.append(f"Options: {', '.join(option_texts)}")
    else:
        # BASIC, CLOZE, FILL_IN_THE_BLANK use definition
        definition = data.get("definition")
        if definition:
            clean_def = _strip_flashcard_syntax(definition.strip())
            if clean_def:
                parts.append(f"Definition: {clean_def}")

    return " ".join(parts)


def _extract_question_text(data: dict) -> str:
    """
    Extract text from TestQuestion or SpacedTestQuestion.

    Format: "Question: {question} Answers: {a1, a2, ...} Explanation: {explanation}"
    """
    parts: list[str] = []

    question = data.get("question")
    if question:
        trimmed = question.strip()
        if trimmed:
            parts.append(f"Question: {trimmed}")

    # Extract answers array
    answers = data.get("answers")
    answer_texts = _get_string_array(answers)
    if answer_texts:
        parts.append(f"Answers: {', '.join(answer_texts)}")

    explanation = data.get("explanation")
    if explanation:
        trimmed = explanation.strip()
        if trimmed:
            parts.append(f"Explanation: {trimmed}")

    return " ".join(parts)


def _extract_audio_recap_text(data: dict) -> str:
    """
    Extract text from AudioRecapV2Section.

    Format: "Script: {script}"
    """
    script = data.get("script")
    if script:
        trimmed = script.strip()
        if trimmed:
            return f"Script: {trimmed}"
    return ""


def _extract_topic_text(data: dict) -> str:
    """
    Extract text from Topic.

    Format: "Topic: {topic}. Description: {description}."
    """
    parts: list[str] = []

    topic = data.get("topic")
    if topic:
        trimmed = topic.strip()
        if trimmed:
            parts.append(f"Topic: {trimmed}.")

    description = data.get("description")
    if description:
        trimmed = description.strip()
        if trimmed:
            parts.append(f"Description: {trimmed}.")

    return " ".join(parts)


def _strip_flashcard_syntax(text: str) -> str:
    """
    Strip {{...}} markers from cloze/fill-in-blank text.

    Example: "The {{mitochondria}} is the powerhouse" -> "The mitochondria is the powerhouse"
    """
    if not text:
        return ""
    # Replace {{word}} with just word
    return re.sub(r"\{\{([^}]+)\}\}", r"\1", text)


def _get_multiple_choice_options(options: list | None) -> list[str]:
    """
    Extract option text from multiple choice options array.

    Options can be strings or objects with "text" or "option" fields.
    """
    if not options or not isinstance(options, list):
        return []

    result: list[str] = []
    for opt in options:
        text = _extract_option_text(opt)
        if text:
            result.append(text)
    return result


def _extract_option_text(item: str | dict | MultipleChoiceOption) -> str:
    """Extract text from a single option (string or object)."""
    if isinstance(item, str):
        return item.strip()

    if isinstance(item, dict):
        # Try "text" field first, then "option"
        text = item.get("text")
        if text and isinstance(text, str):
            return text.strip()
        option = item.get("option")
        if option and isinstance(option, str):
            return option.strip()

    if hasattr(item, "text") and item.text:
        return item.text.strip()
    if hasattr(item, "option") and item.option:
        return item.option.strip()

    return ""


def _get_string_array(answers: list | None) -> list[str]:
    """Extract string array from answers (handles both string[] and AnswerObject[])."""
    if not answers or not isinstance(answers, list):
        return []

    result: list[str] = []
    for ans in answers:
        if isinstance(ans, str):
            trimmed = ans.strip()
            if trimmed:
                result.append(trimmed)
        elif isinstance(ans, dict):
            text = ans.get("text")
            if text and isinstance(text, str):
                trimmed = text.strip()
                if trimmed:
                    result.append(trimmed)
        elif hasattr(ans, "text") and ans.text:
            trimmed = ans.text.strip()
            if trimmed:
                result.append(trimmed)

    return result
