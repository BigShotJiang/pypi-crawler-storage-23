"""
Type definitions for content hashing.

These types mirror the TypeScript SDK types and are derived from the proto definitions.
"""

from typing import Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field

# Tool collection types
ToolCollection = Literal["FlashCard", "TestQuestion", "SpacedTestQuestion", "AudioRecapV2Section", "Topic"]

# FlashCard type variants
FlashCardType = Literal["BASIC", "CLOZE", "FILL_IN_THE_BLANK", "MULTIPLE_CHOICE", "IMAGE_OCCLUSION"]


class MultipleChoiceOption(BaseModel):
    """Multiple choice option structure."""

    model_config = ConfigDict(extra="allow")

    text: Optional[str] = None
    option: Optional[str] = None


class AnswerObject(BaseModel):
    """Answer object structure (can be string or object with text field)."""

    model_config = ConfigDict(extra="allow")

    text: Optional[str] = None


class FlashCardData(BaseModel):
    """
    FlashCard data for content hashing.

    If type is not provided, defaults to "BASIC".
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    type: Optional[FlashCardType] = "BASIC"
    term: Optional[str] = None
    definition: Optional[str] = None
    multiple_choice_options: Optional[list[Union[str, MultipleChoiceOption, dict]]] = Field(
        default=None, alias="multipleChoiceOptions"
    )


class QuestionData(BaseModel):
    """Question data for TestQuestion and SpacedTestQuestion."""

    model_config = ConfigDict(extra="allow")

    question: Optional[str] = None
    answers: Optional[list[Union[str, AnswerObject, dict]]] = None
    explanation: Optional[str] = None


class AudioRecapSectionData(BaseModel):
    """AudioRecapV2Section data for content hashing."""

    model_config = ConfigDict(extra="allow")

    script: Optional[str] = None


class TopicData(BaseModel):
    """Topic data for content hashing."""

    model_config = ConfigDict(extra="allow")

    # Required - becomes TurboPuffer document ID
    id: str
    topic: Optional[str] = None
    description: Optional[str] = None
