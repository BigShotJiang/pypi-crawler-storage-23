"""
Content Type Registry

Defines the pre-configured embedding settings for each content type.
This ensures consistent model selection, dimensions, and storage across all SDK consumers.
"""

from dataclasses import dataclass
from enum import IntEnum


class ContentType(IntEnum):
    """Content types that can be embedded"""
    UNSPECIFIED = 0
    TOPIC = 1
    FLASHCARD = 2
    TEST_QUESTION = 3
    SPACED_TEST_QUESTION = 4
    AUDIO_RECAP = 5
    DOCUMENT = 6
    NOTE = 7


class EmbeddingModel(IntEnum):
    """Vertex AI embedding models"""
    UNSPECIFIED = 0
    GEMINI_001 = 1      # gemini-embedding-001 - 3072 dimensions
    TEXT_004 = 2        # text-embedding-004 - 768 dimensions
    MULTILINGUAL_002 = 3  # text-multilingual-embedding-002


class Priority(IntEnum):
    """Queue priority levels"""
    UNSPECIFIED = 0
    CRITICAL = 1  # Reserved quota, immediate processing
    HIGH = 2      # Processed before normal
    NORMAL = 3    # Standard processing
    LOW = 4       # Processed when capacity available


@dataclass
class MongoDBStorageConfig:
    """MongoDB storage configuration"""
    database: str
    collection: str
    embedding_field: str
    upsert_key: str


@dataclass
class TurboPufferStorageConfig:
    """TurboPuffer storage configuration"""
    namespace: str
    id_field: str
    metadata_fields: list[str]


@dataclass
class ContentTypeConfig:
    """Configuration for a content type's embedding settings"""
    content_type: ContentType
    model: EmbeddingModel
    dimensions: int
    default_priority: Priority
    mongodb: MongoDBStorageConfig
    turbopuffer: TurboPufferStorageConfig


# Pre-configured settings for all supported content types
CONTENT_TYPE_CONFIGS: dict[ContentType, ContentTypeConfig] = {
    ContentType.TOPIC: ContentTypeConfig(
        content_type=ContentType.TOPIC,
        model=EmbeddingModel.GEMINI_001,
        dimensions=3072,
        default_priority=Priority.NORMAL,
        mongodb=MongoDBStorageConfig(
            database="events_new",
            collection="topic_vectors",
            embedding_field="topicDescriptionEmbedding",
            upsert_key="combinationId",
        ),
        turbopuffer=TurboPufferStorageConfig(
            namespace="topic_vectors",
            id_field="_id",
            metadata_fields=["topicId", "userId", "contentHash"],
        ),
    ),
    ContentType.FLASHCARD: ContentTypeConfig(
        content_type=ContentType.FLASHCARD,
        model=EmbeddingModel.GEMINI_001,
        dimensions=3072,
        default_priority=Priority.HIGH,
        mongodb=MongoDBStorageConfig(
            database="events_new",
            collection="tool_vectors",
            embedding_field="toolEmbedding",
            upsert_key="contentHash",
        ),
        turbopuffer=TurboPufferStorageConfig(
            namespace="tool_vectors",
            id_field="_id",
            metadata_fields=["toolId", "toolCollection", "topicId", "userId"],
        ),
    ),
    ContentType.TEST_QUESTION: ContentTypeConfig(
        content_type=ContentType.TEST_QUESTION,
        model=EmbeddingModel.GEMINI_001,
        dimensions=3072,
        default_priority=Priority.HIGH,
        mongodb=MongoDBStorageConfig(
            database="events_new",
            collection="tool_vectors",
            embedding_field="toolEmbedding",
            upsert_key="contentHash",
        ),
        turbopuffer=TurboPufferStorageConfig(
            namespace="tool_vectors",
            id_field="_id",
            metadata_fields=["toolId", "toolCollection", "topicId", "userId"],
        ),
    ),
    ContentType.SPACED_TEST_QUESTION: ContentTypeConfig(
        content_type=ContentType.SPACED_TEST_QUESTION,
        model=EmbeddingModel.GEMINI_001,
        dimensions=3072,
        default_priority=Priority.NORMAL,
        mongodb=MongoDBStorageConfig(
            database="events_new",
            collection="tool_vectors",
            embedding_field="toolEmbedding",
            upsert_key="contentHash",
        ),
        turbopuffer=TurboPufferStorageConfig(
            namespace="tool_vectors",
            id_field="_id",
            metadata_fields=["toolId", "toolCollection", "topicId", "userId"],
        ),
    ),
    ContentType.AUDIO_RECAP: ContentTypeConfig(
        content_type=ContentType.AUDIO_RECAP,
        model=EmbeddingModel.GEMINI_001,
        dimensions=3072,
        default_priority=Priority.NORMAL,
        mongodb=MongoDBStorageConfig(
            database="events_new",
            collection="tool_vectors",
            embedding_field="toolEmbedding",
            upsert_key="contentHash",
        ),
        turbopuffer=TurboPufferStorageConfig(
            namespace="tool_vectors",
            id_field="_id",
            metadata_fields=["toolId", "toolCollection", "topicId", "userId"],
        ),
    ),
    ContentType.DOCUMENT: ContentTypeConfig(
        content_type=ContentType.DOCUMENT,
        model=EmbeddingModel.GEMINI_001,
        dimensions=3072,
        default_priority=Priority.NORMAL,
        mongodb=MongoDBStorageConfig(
            database="events_new",
            collection="document_vectors",
            embedding_field="documentEmbedding",
            upsert_key="documentId",
        ),
        turbopuffer=TurboPufferStorageConfig(
            namespace="document_vectors",
            id_field="_id",
            metadata_fields=["documentId", "userId", "sourceType"],
        ),
    ),
    ContentType.NOTE: ContentTypeConfig(
        content_type=ContentType.NOTE,
        model=EmbeddingModel.GEMINI_001,
        dimensions=3072,
        default_priority=Priority.LOW,
        mongodb=MongoDBStorageConfig(
            database="events_new",
            collection="note_vectors",
            embedding_field="noteEmbedding",
            upsert_key="noteId",
        ),
        turbopuffer=TurboPufferStorageConfig(
            namespace="note_vectors",
            id_field="_id",
            metadata_fields=["noteId", "userId", "topicId"],
        ),
    ),
}


def get_content_type_config(content_type: ContentType) -> ContentTypeConfig:
    """
    Get the configuration for a content type.

    Args:
        content_type: The content type to get config for

    Returns:
        The configuration for the content type

    Raises:
        ValueError: If the content type is not supported
    """
    if content_type not in CONTENT_TYPE_CONFIGS:
        raise ValueError(f"Unsupported content type: {content_type}")
    return CONTENT_TYPE_CONFIGS[content_type]


def get_model_name(model: EmbeddingModel) -> str:
    """Get the Vertex AI model name string"""
    model_names = {
        EmbeddingModel.GEMINI_001: "gemini-embedding-001",
        EmbeddingModel.TEXT_004: "text-embedding-004",
        EmbeddingModel.MULTILINGUAL_002: "text-multilingual-embedding-002",
    }
    return model_names.get(model, "gemini-embedding-001")


def get_priority_string(priority: Priority) -> str:
    """Get the priority string for Redis streams"""
    priority_strings = {
        Priority.CRITICAL: "critical",
        Priority.HIGH: "high",
        Priority.NORMAL: "normal",
        Priority.LOW: "low",
    }
    return priority_strings.get(priority, "normal")


# All supported content types (excluding UNSPECIFIED)
SUPPORTED_CONTENT_TYPES = [ct for ct in ContentType if ct != ContentType.UNSPECIFIED]
