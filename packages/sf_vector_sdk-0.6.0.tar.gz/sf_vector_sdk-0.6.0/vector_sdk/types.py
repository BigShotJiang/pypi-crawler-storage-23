"""
Type definitions for Vector SDK.

These types match the Go service's internal types and provide
type safety and documentation for Python users.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional

# ============================================================================
# Embedding Model Registry
# ============================================================================


class EmbeddingProvider(str, Enum):
    """Embedding service provider."""
    GOOGLE = "google"
    OPENAI = "openai"


@dataclass
class ModelConfig:
    """Configuration for a supported embedding model."""
    name: str
    provider: EmbeddingProvider
    default_dimensions: int
    max_dimensions: int
    supports_custom_dimensions: bool


# Registry of all supported embedding models
SUPPORTED_MODELS: dict[str, ModelConfig] = {
    # Google Vertex AI Models
    "gemini-embedding-001": ModelConfig(
        name="gemini-embedding-001",
        provider=EmbeddingProvider.GOOGLE,
        default_dimensions=3072,
        max_dimensions=3072,
        supports_custom_dimensions=False,
    ),
    "text-embedding-004": ModelConfig(
        name="text-embedding-004",
        provider=EmbeddingProvider.GOOGLE,
        default_dimensions=768,
        max_dimensions=768,
        supports_custom_dimensions=False,
    ),
    "text-multilingual-embedding-002": ModelConfig(
        name="text-multilingual-embedding-002",
        provider=EmbeddingProvider.GOOGLE,
        default_dimensions=768,
        max_dimensions=768,
        supports_custom_dimensions=False,
    ),
    # OpenAI Models
    "text-embedding-3-small": ModelConfig(
        name="text-embedding-3-small",
        provider=EmbeddingProvider.OPENAI,
        default_dimensions=1536,
        max_dimensions=1536,
        supports_custom_dimensions=True,
    ),
    "text-embedding-3-large": ModelConfig(
        name="text-embedding-3-large",
        provider=EmbeddingProvider.OPENAI,
        default_dimensions=3072,
        max_dimensions=3072,
        supports_custom_dimensions=True,
    ),
}


class ModelValidationError(ValueError):
    """Raised when model validation fails."""
    pass


def is_model_supported(model: str) -> bool:
    """Check if a model is supported."""
    return model in SUPPORTED_MODELS


def get_model_config(model: str) -> Optional[ModelConfig]:
    """Get the configuration for a model."""
    return SUPPORTED_MODELS.get(model)


def get_supported_models() -> list[str]:
    """Get all supported model names."""
    return list(SUPPORTED_MODELS.keys())


def get_google_models() -> list[str]:
    """Get all Google/Vertex AI model names."""
    return [
        name for name, cfg in SUPPORTED_MODELS.items()
        if cfg.provider == EmbeddingProvider.GOOGLE
    ]


def get_openai_models() -> list[str]:
    """Get all OpenAI model names."""
    return [
        name for name, cfg in SUPPORTED_MODELS.items()
        if cfg.provider == EmbeddingProvider.OPENAI
    ]


def validate_model(model: str, dimensions: Optional[int] = None) -> None:
    """
    Validate a model name and optional dimensions.

    Args:
        model: The model name to validate
        dimensions: Optional dimensions to validate

    Raises:
        ModelValidationError: If validation fails
    """
    config = SUPPORTED_MODELS.get(model)
    if config is None:
        supported_list = ", ".join(get_supported_models())
        raise ModelValidationError(
            f'Unsupported embedding model: "{model}". '
            f"Supported models are: {supported_list}"
        )

    if dimensions is not None and dimensions > 0:
        if dimensions > config.max_dimensions:
            raise ModelValidationError(
                f"Dimensions {dimensions} exceeds maximum "
                f"{config.max_dimensions} for model \"{model}\""
            )

        if not config.supports_custom_dimensions and dimensions != config.max_dimensions:
            raise ModelValidationError(
                f'Model "{model}" does not support custom dimensions '
                f"(requested {dimensions}, must be {config.max_dimensions})"
            )


# Priority constants
PRIORITY_CRITICAL = "critical"
PRIORITY_HIGH = "high"
PRIORITY_NORMAL = "normal"
PRIORITY_LOW = "low"

# Base stream names (use hash tags for Redis Cluster compatibility)
STREAM_CRITICAL = "{embedding}:critical"
STREAM_HIGH = "{embedding}:high"
STREAM_NORMAL = "{embedding}:normal"
STREAM_LOW = "{embedding}:low"


def prefix_key(env: str | None, key: str) -> str:
    """Add an environment prefix to a Redis key.

    If env is None or empty, the key is returned unchanged for backward compatibility.

    Args:
        env: Environment prefix (e.g., "staging", "production")
        key: The base Redis key

    Returns:
        The prefixed key, or the original key if no environment is set
    """
    if not env:
        return key
    return f"{env}:{key}"


def get_stream_for_priority(priority: str, env: str | None = None) -> str:
    """Get the Redis Stream name for a given priority.

    Optionally prefixed with an environment name (e.g., "staging", "production").
    """
    mapping = {
        PRIORITY_CRITICAL: STREAM_CRITICAL,
        PRIORITY_HIGH: STREAM_HIGH,
        PRIORITY_NORMAL: STREAM_NORMAL,
        PRIORITY_LOW: STREAM_LOW,
    }
    base = mapping.get(priority, STREAM_NORMAL)
    return prefix_key(env, base)


def get_all_embedding_streams(env: str | None = None) -> list[str]:
    """Get all embedding stream names for the given environment."""
    return [prefix_key(env, s) for s in [STREAM_CRITICAL, STREAM_HIGH, STREAM_NORMAL, STREAM_LOW]]


def get_embedding_response_key(request_id: str, env: str | None = None) -> str:
    """Get the embedding response list key for a request ID."""
    return prefix_key(env, f"embedding:response:{request_id}")


def get_query_response_key(request_id: str, env: str | None = None) -> str:
    """Get the query response list key for a request ID."""
    return prefix_key(env, f"query:response:{request_id}")


def get_namespace_export_key(job_id: str, env: str | None = None) -> str:
    """Get the namespace export key for a job ID."""
    return prefix_key(env, f"namespace-export:{job_id}")


@dataclass
class TextInput:
    """
    A single text to embed.

    Attributes:
        id: External identifier for correlation (e.g., toolId, topicId)
        text: The actual text content to embed
        document: Optional full document to store alongside the embedding
    """
    id: str
    text: str
    document: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {"id": self.id, "text": self.text}
        if self.document is not None:
            result["document"] = self.document
        return result


@dataclass
class MongoDBStorage:
    """
    Configuration for storing embeddings in MongoDB.

    Attributes:
        database: MongoDB database name (e.g., "events_new")
        collection: Collection name (e.g., "tool_vectors", "topic_vectors")
        embedding_field: Field name to store the embedding vector
        upsert_key: Field to use for upsert operations (e.g., "contentHash")
    """
    database: str
    collection: str
    embedding_field: str
    upsert_key: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "database": self.database,
            "collection": self.collection,
            "embeddingField": self.embedding_field,
            "upsertKey": self.upsert_key,
        }


@dataclass
class TurboPufferStorage:
    """
    Configuration for storing embeddings in TurboPuffer.

    Attributes:
        namespace: TurboPuffer namespace (e.g., "tool_vectors")
        id_field: Document field to use as the vector ID
        metadata: List of document fields to include as TurboPuffer metadata
    """
    namespace: str
    id_field: str
    metadata: Optional[list[str]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "namespace": self.namespace,
            "idField": self.id_field,
        }
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class PineconeStorageConfig:
    """
    Configuration for storing embeddings in Pinecone.

    Attributes:
        index_name: Pinecone index name
        namespace: Namespace within the index (optional)
        id_field: Document field to use as the vector ID
        metadata: List of document fields to include as Pinecone metadata
    """
    index_name: str
    id_field: str
    namespace: Optional[str] = None
    metadata: Optional[list[str]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "indexName": self.index_name,
            "idField": self.id_field,
        }
        if self.namespace:
            result["namespace"] = self.namespace
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class StorageConfig:
    """
    Configuration for where to store generated embeddings.

    If multiple storage backends are provided, embeddings are written to all.
    If none is provided, embeddings are only returned via callback.

    Attributes:
        mongodb: MongoDB storage configuration
        turbopuffer: TurboPuffer storage configuration
        pinecone: Pinecone storage configuration
    """
    mongodb: Optional[MongoDBStorage] = None
    turbopuffer: Optional[TurboPufferStorage] = None
    pinecone: Optional[PineconeStorageConfig] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {}
        if self.mongodb:
            result["mongodb"] = self.mongodb.to_dict()
        if self.turbopuffer:
            result["turbopuffer"] = self.turbopuffer.to_dict()
        if self.pinecone:
            result["pinecone"] = self.pinecone.to_dict()
        return result


@dataclass
class CallbackConfig:
    """
    Configuration for completion notifications.

    Attributes:
        type: Callback delivery method ("redis", "pubsub", "none")
        topic: Pub/Sub topic for "pubsub" type callbacks
        channel: Redis channel for "redis" type callbacks
    """
    type: str = "redis"
    topic: Optional[str] = None
    channel: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {"type": self.type}
        if self.topic:
            result["topic"] = self.topic
        if self.channel:
            result["channel"] = self.channel
        return result


@dataclass
class EmbeddingConfigOverride:
    """
    Configuration for overriding embedding model and dimensions.

    Attributes:
        model: Embedding model name (e.g., "gemini-embedding-001", "text-embedding-3-small")
        dimensions: Output embedding dimensions
    """
    model: Optional[str] = None
    dimensions: Optional[int] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {}
        if self.model:
            result["model"] = self.model
        if self.dimensions:
            result["dimensions"] = self.dimensions
        return result


@dataclass
class EmbeddingRequest:
    """
    A request to generate embeddings.

    Attributes:
        request_id: Unique identifier for tracking
        content_type: Type of content (e.g., "topic", "flashcard")
        priority: Queue priority ("critical", "high", "normal", "low")
        texts: List of texts to embed
        storage: Where to store the embeddings
        callback: How to notify completion
        embedding_config: Optional embedding model override
        metadata: Arbitrary key-value pairs for tracking
        created_at: When the request was created
    """
    request_id: str
    content_type: str
    priority: str
    texts: list[TextInput]
    storage: Optional[StorageConfig] = None
    callback: Optional[CallbackConfig] = None
    embedding_config: Optional[EmbeddingConfigOverride] = None
    metadata: dict[str, str] = field(default_factory=dict)
    allow_duplicates: bool = False
    created_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "requestId": self.request_id,
            "contentType": self.content_type,
            "priority": self.priority,
            "texts": [t.to_dict() for t in self.texts],
            "metadata": self.metadata,
            "createdAt": self.created_at.isoformat() + "Z",
        }
        if self.storage:
            result["storage"] = self.storage.to_dict()
        if self.callback:
            result["callback"] = self.callback.to_dict()
        if self.embedding_config:
            result["embeddingConfig"] = self.embedding_config.to_dict()
        if self.allow_duplicates:
            result["allowDuplicates"] = True
        return result


@dataclass
class EmbeddingError:
    """
    Details about a failed embedding.

    Attributes:
        index: Position in the original texts array
        id: The TextInput.id that failed
        error: Error message
        retryable: Whether this error can be retried
    """
    index: int
    id: str
    error: str
    retryable: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EmbeddingError":
        """Create from dictionary."""
        return cls(
            index=data["index"],
            id=data["id"],
            error=data["error"],
            retryable=data.get("retryable", False),
        )


@dataclass
class TimingBreakdown:
    """
    Processing duration breakdown.

    Attributes:
        queue_wait_ms: Time spent waiting in queue
        dedup_ms: Time spent on deduplication checks
        vertex_ms: Time spent calling Vertex AI
        mongodb_ms: Time spent writing to MongoDB
        turbopuffer_ms: Time spent writing to TurboPuffer
        total_ms: Total processing time
    """
    queue_wait_ms: int
    dedup_ms: int
    vertex_ms: int
    mongodb_ms: int
    turbopuffer_ms: int
    total_ms: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TimingBreakdown":
        """Create from dictionary."""
        return cls(
            queue_wait_ms=data.get("queueWaitMs", 0),
            dedup_ms=data.get("dedupMs", 0),
            vertex_ms=data.get("vertexMs", 0),
            mongodb_ms=data.get("mongodbMs", 0),
            turbopuffer_ms=data.get("turbopufferMs", 0),
            total_ms=data.get("totalMs", 0),
        )


@dataclass
class EmbeddingResult:
    """
    Result of processing an embedding request.

    Attributes:
        request_id: The original request ID
        status: "success", "partial", or "failed"
        processed_count: Number of successfully processed embeddings
        failed_count: Number of failed embeddings
        skipped_count: Number of items skipped due to deduplication
        errors: Details about failed items
        embeddings: Generated embedding vectors (only populated when no storage is configured)
        timing: Processing duration breakdown
        completed_at: When processing finished
    """
    request_id: str
    status: str
    processed_count: int
    failed_count: int
    skipped_count: int
    errors: list[EmbeddingError]
    embeddings: Optional[list[list[float]]]
    timing: Optional[TimingBreakdown]
    completed_at: datetime

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EmbeddingResult":
        """Create from dictionary."""
        errors = [EmbeddingError.from_dict(e) for e in data.get("errors", [])]
        timing = None
        if data.get("timing"):
            timing = TimingBreakdown.from_dict(data["timing"])

        return cls(
            request_id=data["requestId"],
            status=data["status"],
            processed_count=data["processedCount"],
            failed_count=data["failedCount"],
            skipped_count=data.get("skippedCount", 0),
            errors=errors,
            embeddings=data.get("embeddings"),
            timing=timing,
            completed_at=datetime.fromisoformat(data["completedAt"].replace("Z", "+00:00")),
        )

    @property
    def is_success(self) -> bool:
        """Check if the request was fully successful."""
        return self.status == "success"

    @property
    def is_partial(self) -> bool:
        """Check if the request was partially successful."""
        return self.status == "partial"

    @property
    def is_failed(self) -> bool:
        """Check if the request completely failed."""
        return self.status == "failed"


# ============================================================================
# Query Types
# ============================================================================

# Query stream names (use hash tags for Redis Cluster compatibility)
QUERY_STREAM_CRITICAL = "{query}:critical"
QUERY_STREAM_HIGH = "{query}:high"
QUERY_STREAM_NORMAL = "{query}:normal"
QUERY_STREAM_LOW = "{query}:low"


def get_query_stream_for_priority(priority: str, env: str | None = None) -> str:
    """Get the Redis Stream name for a query request.

    Optionally prefixed with an environment name (e.g., "staging", "production").
    """
    mapping = {
        PRIORITY_CRITICAL: QUERY_STREAM_CRITICAL,
        PRIORITY_HIGH: QUERY_STREAM_HIGH,
        PRIORITY_NORMAL: QUERY_STREAM_NORMAL,
        PRIORITY_LOW: QUERY_STREAM_LOW,
    }
    base = mapping.get(priority, QUERY_STREAM_NORMAL)
    return prefix_key(env, base)


# Vector database types
VECTOR_DATABASE_MONGODB = "mongodb"
VECTOR_DATABASE_TURBOPUFFER = "turbopuffer"
VECTOR_DATABASE_PINECONE = "pinecone"


@dataclass
class PineconeStorage:
    """
    Configuration for storing embeddings in Pinecone.

    Attributes:
        index_name: Pinecone index name
        namespace: Namespace within the index (optional)
        id_field: Document field to use as the vector ID
        metadata: List of document fields to include as Pinecone metadata
    """
    index_name: str
    id_field: str
    namespace: Optional[str] = None
    metadata: Optional[list[str]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "indexName": self.index_name,
            "idField": self.id_field,
        }
        if self.namespace:
            result["namespace"] = self.namespace
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class QueryConfig:
    """
    Configuration for query search parameters.

    Attributes:
        top_k: Number of results to return (default: 10)
        min_score: Minimum similarity score threshold (0.0 to 1.0)
        filters: Metadata filters for filtering results
        namespace: Namespace for Pinecone/TurboPuffer
        collection: Collection name for MongoDB
        database: Database name for MongoDB
        include_vectors: Whether to include vector values in response
        include_metadata: Whether to include metadata in response
    """
    top_k: int = 10
    min_score: Optional[float] = None
    filters: Optional[dict[str, str]] = None
    namespace: Optional[str] = None
    collection: Optional[str] = None
    database: Optional[str] = None
    include_vectors: bool = False
    include_metadata: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "topK": self.top_k,
            "includeVectors": self.include_vectors,
            "includeMetadata": self.include_metadata,
        }
        if self.min_score is not None:
            result["minScore"] = self.min_score
        if self.filters:
            result["filters"] = self.filters
        if self.namespace:
            result["namespace"] = self.namespace
        if self.collection:
            result["collection"] = self.collection
        if self.database:
            result["database"] = self.database
        return result


@dataclass
class QueryRequest:
    """
    A request to perform vector search.

    Attributes:
        request_id: Unique identifier for tracking
        query_text: The text to search for (will be embedded)
        database: Which vector database to search
        priority: Queue priority
        query_config: Query-specific configuration
        embedding_config: Optional embedding configuration override
        metadata: Arbitrary key-value pairs for tracking
        created_at: When the request was created
        query_vector: Optional pre-computed query vector (skips embedding generation if provided)
    """
    request_id: str
    query_text: str
    database: str
    priority: str
    query_config: QueryConfig
    embedding_config: Optional[EmbeddingConfigOverride] = None
    metadata: dict[str, str] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    query_vector: Optional[list[float]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "requestId": self.request_id,
            "queryText": self.query_text,
            "database": self.database,
            "priority": self.priority,
            "queryConfig": self.query_config.to_dict(),
            "metadata": self.metadata,
            "createdAt": self.created_at.isoformat() + "Z",
        }
        if self.embedding_config:
            result["embeddingConfig"] = self.embedding_config.to_dict()
        if self.query_vector:
            result["queryVector"] = self.query_vector
        return result


@dataclass
class VectorMatch:
    """
    A single vector search result.

    Attributes:
        id: Vector ID in the database
        score: Similarity score (higher is more similar)
        metadata: Associated metadata
        vector: The vector values (if requested)
    """
    id: str
    score: float
    metadata: Optional[dict[str, Any]] = None
    vector: Optional[list[float]] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "VectorMatch":
        """Create from dictionary."""
        return cls(
            id=data["id"],
            score=data["score"],
            metadata=data.get("metadata"),
            vector=data.get("vector"),
        )


@dataclass
class QueryTiming:
    """
    Processing duration breakdown for queries.

    Attributes:
        queue_wait_ms: Time spent waiting in queue
        embedding_ms: Time spent generating query embedding
        search_ms: Time spent executing database search
        total_ms: Total processing time
    """
    queue_wait_ms: int
    embedding_ms: int
    search_ms: int
    total_ms: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QueryTiming":
        """Create from dictionary."""
        return cls(
            queue_wait_ms=data.get("queueWaitMs", 0),
            embedding_ms=data.get("embeddingMs", 0),
            search_ms=data.get("searchMs", 0),
            total_ms=data.get("totalMs", 0),
        )


@dataclass
class QueryResult:
    """
    Result of a vector search query.

    Attributes:
        request_id: The original request ID
        status: "success" or "failed"
        matches: Matching vectors with scores
        error: Error message if status is "failed"
        timing: Processing duration breakdown
        completed_at: When processing finished
    """
    request_id: str
    status: str
    matches: list[VectorMatch]
    error: Optional[str]
    timing: Optional[QueryTiming]
    completed_at: datetime

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QueryResult":
        """Create from dictionary."""
        matches = [VectorMatch.from_dict(m) for m in data.get("matches", [])]
        timing = None
        if data.get("timing"):
            timing = QueryTiming.from_dict(data["timing"])

        return cls(
            request_id=data["requestId"],
            status=data["status"],
            matches=matches,
            error=data.get("error"),
            timing=timing,
            completed_at=datetime.fromisoformat(data["completedAt"].replace("Z", "+00:00")),
        )

    @property
    def is_success(self) -> bool:
        """Check if the query was successful."""
        return self.status == "success"

    @property
    def is_failed(self) -> bool:
        """Check if the query failed."""
        return self.status == "failed"


# ============================================================================
# Database Lookup Types (HTTP API)
# ============================================================================


@dataclass
class Document:
    """
    A document retrieved from the database.

    Attributes:
        id: Document/vector ID
        metadata: Document metadata
        vector: Vector values (if requested)
    """
    id: str
    metadata: Optional[dict[str, Any]] = None
    vector: Optional[list[float]] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Document":
        """Create from dictionary."""
        return cls(
            id=data["id"],
            metadata=data.get("metadata"),
            vector=data.get("vector"),
        )


@dataclass
class LookupTiming:
    """
    Timing information for lookup operations.

    Attributes:
        total_ms: Total request duration in milliseconds
    """
    total_ms: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LookupTiming":
        """Create from dictionary."""
        return cls(total_ms=data.get("totalMs", 0))


@dataclass
class LookupResult:
    """
    Result of a lookup or metadata search operation.

    Attributes:
        documents: Retrieved documents
        timing: Timing information
    """
    documents: list[Document]
    timing: LookupTiming

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LookupResult":
        """Create from dictionary."""
        documents = [Document.from_dict(d) for d in data.get("documents", [])]
        timing = LookupTiming.from_dict(data.get("timing", {}))
        return cls(documents=documents, timing=timing)


# ============================================================================
# Clone and Delete Types
# ============================================================================


@dataclass
class CloneResult:
    """
    Result of a clone operation.

    Attributes:
        id: Document ID that was cloned
        success: Whether the clone succeeded
        timing: Timing information
    """
    id: str
    success: bool
    timing: LookupTiming

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CloneResult":
        """Create from dictionary."""
        timing = LookupTiming.from_dict(data.get("timing", {}))
        return cls(
            id=data["id"],
            success=data["success"],
            timing=timing,
        )


@dataclass
class DeleteFromNamespaceResult:
    """
    Result of a delete operation.

    Attributes:
        id: Document ID that was deleted
        success: Whether the delete succeeded
        timing: Timing information
    """
    id: str
    success: bool
    timing: LookupTiming

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeleteFromNamespaceResult":
        """Create from dictionary."""
        timing = LookupTiming.from_dict(data.get("timing", {}))
        return cls(
            id=data["id"],
            success=data["success"],
            timing=timing,
        )


@dataclass
class NamespaceMetadata:
    """
    Namespace metadata from TurboPuffer.

    Attributes:
        schema: Schema information (dimensions, attributes)
        approx_row_count: Approximate number of rows in namespace
        approx_logical_bytes: Approximate logical bytes used
        created_at: When the namespace was created
        updated_at: When the namespace was last updated
    """
    schema: dict[str, Any]
    approx_row_count: int
    approx_logical_bytes: int
    created_at: str
    updated_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "NamespaceMetadata":
        """Create from dictionary."""
        return cls(
            schema=data["schema"],
            approx_row_count=data["approx_row_count"],
            approx_logical_bytes=data["approx_logical_bytes"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
        )


@dataclass
class ExportTiming:
    """
    Timing breakdown for export operations.

    Attributes:
        metadata_ms: Time to fetch namespace metadata (ms)
        query_ms: Time to fetch all documents (ms)
        total_ms: Total export time (ms)
    """
    metadata_ms: int
    query_ms: int
    total_ms: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExportTiming":
        """Create from dictionary."""
        return cls(
            metadata_ms=data["metadataMs"],
            query_ms=data["queryMs"],
            total_ms=data["totalMs"],
        )


@dataclass
class GetVectorsInNamespaceResult:
    """
    Result of a namespace export operation.

    Attributes:
        job_id: Job ID for the export
        status: Export status ("success" or "failed")
        documents: All exported documents
        metadata: Namespace metadata
        error: Error message if failed
        timing: Timing breakdown
        completed_at: When the export completed
    """
    job_id: str
    status: str
    documents: list[Document]
    metadata: NamespaceMetadata
    error: Optional[str]
    timing: ExportTiming
    completed_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GetVectorsInNamespaceResult":
        """Create from dictionary."""
        documents = [Document.from_dict(d) for d in data["documents"]]
        metadata = NamespaceMetadata.from_dict(data["metadata"])
        timing = ExportTiming.from_dict(data["timing"])
        return cls(
            job_id=data["jobId"],
            status=data["status"],
            documents=documents,
            metadata=metadata,
            error=data.get("error"),
            timing=timing,
            completed_at=data["completedAt"],
        )
