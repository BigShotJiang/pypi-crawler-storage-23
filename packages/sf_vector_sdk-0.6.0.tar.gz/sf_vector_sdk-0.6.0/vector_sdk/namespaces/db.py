"""
Database namespace for direct database operations (no embedding required).
"""

import json
import time
from typing import Any, Optional

import requests

from vector_sdk.namespaces.base import BaseNamespace
from vector_sdk.types import (
    CloneResult,
    DeleteFromNamespaceResult,
    GetVectorsInNamespaceResult,
    LookupResult,
    get_namespace_export_key,
)


class DBNamespace(BaseNamespace):
    """
    Namespace for direct database operations.

    These operations call the query-gateway HTTP API directly, bypassing
    the Redis Streams queue. They do not require embedding the query.

    Example:
        ```python
        client = VectorClient(
            redis_url="redis://localhost:6379",
            http_url="http://localhost:8080",
        )

        # Lookup documents by ID
        result = client.db.get_by_ids(
            ids=["doc1", "doc2"],
            database="turbopuffer",
            namespace="my_namespace",
        )

        # Find by metadata
        result = client.db.find_by_metadata(
            filters={"userId": "user123"},
            database="mongodb",
            collection="vectors",
            database_name="mydb",
        )
        ```
    """

    def get_by_ids(
        self,
        ids: list[str],
        database: str,
        namespace: Optional[str] = None,
        collection: Optional[str] = None,
        database_name: Optional[str] = None,
        include_vectors: bool = False,
        include_metadata: bool = True,
    ) -> LookupResult:
        """
        Look up documents by their IDs.

        Args:
            ids: List of document/vector IDs to retrieve
            database: Which vector database to query ("mongodb", "turbopuffer", "pinecone")
            namespace: Namespace for TurboPuffer/Pinecone
            collection: Collection name for MongoDB (also used as index name for Pinecone)
            database_name: Database name for MongoDB
            include_vectors: Whether to include vector values in response
            include_metadata: Whether to include metadata in response (default: True)

        Returns:
            LookupResult containing retrieved documents

        Raises:
            ValueError: If http_url is not configured or ids is empty
            requests.HTTPError: If the request fails
        """
        http_url = self._require_http_url("get_by_ids")

        if not ids:
            raise ValueError("ids list cannot be empty")

        if len(ids) > 100:
            raise ValueError("Maximum 100 IDs per request")

        url = f"{http_url}/v1/lookup/{database}"
        body = {
            "ids": ids,
            "namespace": namespace,
            "collection": collection,
            "database": database_name,
            "includeVectors": include_vectors,
            "includeMetadata": include_metadata,
        }

        headers = {
            "Content-Type": "application/json",
            **self._get_auth_headers(),
        }

        response = requests.post(url, json=body, headers=headers, timeout=30)
        response.raise_for_status()

        return LookupResult.from_dict(response.json())

    def find_by_metadata(
        self,
        filters: dict[str, Any],
        database: str,
        namespace: Optional[str] = None,
        collection: Optional[str] = None,
        database_name: Optional[str] = None,
        limit: int = 100,
        include_vectors: bool = False,
    ) -> LookupResult:
        """
        Search for documents by metadata filters.

        Args:
            filters: Metadata key-value pairs to match
            database: Which vector database to query ("mongodb", "turbopuffer", "pinecone")
            namespace: Namespace for TurboPuffer/Pinecone
            collection: Collection name for MongoDB (also used as index name for Pinecone)
            database_name: Database name for MongoDB
            limit: Maximum number of results (default: 100, max: 1000)
            include_vectors: Whether to include vector values in response

        Returns:
            LookupResult containing matched documents

        Raises:
            ValueError: If http_url is not configured or filters is empty
            requests.HTTPError: If the request fails
        """
        http_url = self._require_http_url("find_by_metadata")

        if not filters:
            raise ValueError("filters dict cannot be empty")

        url = f"{http_url}/v1/search/{database}"
        body = {
            "filters": filters,
            "namespace": namespace,
            "collection": collection,
            "database": database_name,
            "limit": min(limit, 1000),
            "includeVectors": include_vectors,
        }

        headers = {
            "Content-Type": "application/json",
            **self._get_auth_headers(),
        }

        response = requests.post(url, json=body, headers=headers, timeout=30)
        response.raise_for_status()

        return LookupResult.from_dict(response.json())

    def clone(
        self,
        id: str,
        source_namespace: str,
        destination_namespace: str,
    ) -> CloneResult:
        """
        Clone a document from one TurboPuffer namespace to another.

        This method fetches a document by ID from the source namespace (including
        its vector and metadata) and writes it to the destination namespace.
        Vectors are stored as f16 in the destination regardless of source format.

        Args:
            id: Document ID to clone
            source_namespace: Namespace to clone from
            destination_namespace: Namespace to clone to

        Returns:
            CloneResult containing success status and timing

        Raises:
            ValueError: If http_url is not configured or required params are missing
            requests.HTTPError: If the request fails
        """
        http_url = self._require_http_url("clone")

        if not id:
            raise ValueError("id is required")
        if not source_namespace:
            raise ValueError("source_namespace is required")
        if not destination_namespace:
            raise ValueError("destination_namespace is required")

        url = f"{http_url}/v1/clone/turbopuffer"
        body = {
            "id": id,
            "sourceNamespace": source_namespace,
            "destinationNamespace": destination_namespace,
        }

        headers = {
            "Content-Type": "application/json",
            **self._get_auth_headers(),
        }

        response = requests.post(url, json=body, headers=headers, timeout=30)
        response.raise_for_status()

        return CloneResult.from_dict(response.json())

    def delete(
        self,
        id: str,
        namespace: str,
    ) -> DeleteFromNamespaceResult:
        """
        Delete a document from a TurboPuffer namespace.

        Args:
            id: Document ID to delete
            namespace: Namespace to delete from

        Returns:
            DeleteFromNamespaceResult containing success status and timing

        Raises:
            ValueError: If http_url is not configured or required params are missing
            requests.HTTPError: If the request fails
        """
        http_url = self._require_http_url("delete")

        if not id:
            raise ValueError("id is required")
        if not namespace:
            raise ValueError("namespace is required")

        url = f"{http_url}/v1/delete/turbopuffer"
        body = {
            "id": id,
            "namespace": namespace,
        }

        headers = {
            "Content-Type": "application/json",
            **self._get_auth_headers(),
        }

        response = requests.post(url, json=body, headers=headers, timeout=30)
        response.raise_for_status()

        return DeleteFromNamespaceResult.from_dict(response.json())

    def get_vectors_in_namespace(
        self,
        namespace: str,
        include_vectors: bool = True,
        include_metadata: bool = True,
        timeout_ms: int = 300000,
    ) -> GetVectorsInNamespaceResult:
        """
        Export all vectors from a TurboPuffer namespace.

        This method submits an export job to the query gateway and waits for completion.
        The gateway handles pagination automatically and returns all results at once.

        Args:
            namespace: TurboPuffer namespace to export from
            include_vectors: Whether to include vectors in response (default: True)
            include_metadata: Whether to include metadata in response (default: True)
            timeout_ms: Maximum time to wait for export completion in milliseconds
                        (default: 300000ms = 5 minutes)

        Returns:
            GetVectorsInNamespaceResult containing all documents and namespace metadata

        Raises:
            ValueError: If http_url is not configured or namespace is missing
            TimeoutError: If export times out
            requests.HTTPError: If the request fails
            Exception: If the export fails on the server side

        Example:
            ```python
            result = client.db.get_vectors_in_namespace(
                namespace="tool_vectors",
                include_vectors=True,
                include_metadata=True,
            )

            print(f"Exported {len(result.documents)} documents")
            print(f"Namespace has ~{result.metadata.approx_row_count} total rows")
            ```
        """
        http_url = self._require_http_url("get_vectors_in_namespace")

        if not namespace:
            raise ValueError("namespace is required")

        # 1. Submit export job to gateway
        url = f"{http_url}/v1/export/turbopuffer"
        body = {
            "namespace": namespace,
            "includeVectors": include_vectors,
            "includeMetadata": include_metadata,
        }

        response = requests.post(url, json=body, timeout=30)
        response.raise_for_status()

        job_id = response.json()["jobId"]

        # 2. Poll Redis for result
        redis_key = get_namespace_export_key(job_id, self._environment)
        start_time = time.time()
        poll_interval = 1.0  # Poll every 1 second

        while (time.time() - start_time) * 1000 < timeout_ms:
            result_str = self.redis.get(redis_key)

            if result_str:
                result_dict = json.loads(result_str)
                result = GetVectorsInNamespaceResult.from_dict(result_dict)

                if result.status == "failed":
                    raise Exception(f"Export failed: {result.error}")

                return result

            # Wait before next poll
            time.sleep(poll_interval)

        raise TimeoutError(f"Export timeout after {timeout_ms}ms")
