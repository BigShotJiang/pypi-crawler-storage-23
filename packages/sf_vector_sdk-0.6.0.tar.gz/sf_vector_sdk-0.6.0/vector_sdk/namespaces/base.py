"""
Base namespace class providing shared context for all namespace implementations.
"""

from typing import Optional

from redis import Redis


class BaseNamespace:
    """
    Base class for all namespace implementations.
    Provides access to shared Redis and HTTP clients.
    """

    def __init__(
        self,
        redis: Redis,
        http_url: Optional[str] = None,
        api_key: str = None,
        environment: Optional[str] = None,
    ):
        """
        Initialize the base namespace.

        Args:
            redis: Redis client instance
            http_url: Optional HTTP URL for query-gateway API
            api_key: API key for authentication
            environment: Optional environment prefix for Redis queue names
                (e.g., "staging", "production")
        """
        self._redis = redis
        self._http_url = http_url
        self._api_key = api_key
        self._environment = environment

    def _require_http_url(self, method_name: str) -> str:
        """
        Helper to require http_url for HTTP-based operations.

        Args:
            method_name: Name of the method requiring http_url

        Returns:
            The http_url

        Raises:
            ValueError: If http_url is not configured
        """
        if not self._http_url:
            raise ValueError(
                f"http_url is required for {method_name}. "
                "Set it in VectorClient constructor."
            )
        return self._http_url

    def _get_auth_headers(self) -> dict[str, str]:
        """
        Helper to get Authorization header for HTTP requests.

        Returns:
            Dictionary with Authorization header
        """
        return {
            "Authorization": f"Bearer {self._api_key}"
        }
