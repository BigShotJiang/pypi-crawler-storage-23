"""Namespace exports for the Vector SDK."""

from vector_sdk.namespaces.base import BaseNamespace
from vector_sdk.namespaces.db import DBNamespace
from vector_sdk.namespaces.embeddings import EmbeddingsNamespace
from vector_sdk.namespaces.search import SearchNamespace

__all__ = [
    "BaseNamespace",
    "EmbeddingsNamespace",
    "SearchNamespace",
    "DBNamespace",
]
