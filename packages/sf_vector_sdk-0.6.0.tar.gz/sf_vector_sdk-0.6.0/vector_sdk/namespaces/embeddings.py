"""
Embeddings namespace for creating and managing vector embeddings.
"""

import json
import uuid
from datetime import datetime
from typing import Any, Optional

from vector_sdk.namespaces.base import BaseNamespace
from vector_sdk.types import (
    EmbeddingConfigOverride,
    EmbeddingRequest,
    EmbeddingResult,
    StorageConfig,
    TextInput,
    get_all_embedding_streams,
    get_embedding_response_key,
    get_stream_for_priority,
    validate_model,
)


class EmbeddingsNamespace(BaseNamespace):
    """
    Namespace for embedding generation operations.

    Example:
        ```python
        client = VectorClient("redis://localhost:6379")

        # Create embeddings asynchronously
        request_id = client.embeddings.create(
            texts=[{"id": "doc1", "text": "Hello world"}],
            content_type="document",
        )

        # Wait for the result
        result = client.embeddings.wait_for(request_id)

        # Or do both in one call
        result = client.embeddings.create_and_wait(
            texts=[{"id": "doc1", "text": "Hello world"}],
            content_type="document",
        )
        ```
    """

    def create(
        self,
        texts: list[dict[str, Any]],
        content_type: str,
        priority: str = "normal",
        storage: Optional[StorageConfig] = None,
        metadata: Optional[dict[str, str]] = None,
        request_id: Optional[str] = None,
        embedding_model: Optional[str] = None,
        embedding_dimensions: Optional[int] = None,
        allow_duplicates: bool = False,
    ) -> str:
        """
        Create embeddings for the given texts.

        This method submits an embedding request to the gateway and returns immediately
        with a request ID. Use `wait_for()` to get the result, or use `create_and_wait()`
        for a combined operation.

        Args:
            texts: List of text inputs. Each item should have:
                - id: Unique identifier for the text
                - text: The actual text content to embed
                - document: (optional) Full document to store with embedding
            content_type: Type of content being embedded (e.g., "topic", "flashcard")
            priority: Queue priority - one of "critical", "high", "normal", "low"
            storage: Configuration for where to store embeddings
            metadata: Optional key-value pairs for tracking
            request_id: Optional custom request ID (auto-generated if not provided)
            embedding_model: Optional embedding model override
            embedding_dimensions: Optional embedding dimensions override

        Returns:
            The request ID for tracking the request

        Raises:
            ValueError: If texts list is empty or invalid
            ModelValidationError: If embedding model is not supported
        """
        if not texts:
            raise ValueError("texts list cannot be empty")

        # Validate embedding model if specified
        if embedding_model:
            validate_model(embedding_model, embedding_dimensions)

        # Generate request ID if not provided
        if request_id is None:
            request_id = str(uuid.uuid4())

        # Convert text dicts to TextInput objects
        text_inputs = []
        for t in texts:
            if isinstance(t, TextInput):
                text_inputs.append(t)
            elif isinstance(t, dict):
                text_inputs.append(TextInput(
                    id=t["id"],
                    text=t["text"],
                    document=t.get("document"),
                ))
            else:
                raise ValueError(f"Invalid text input type: {type(t)}")

        # Build embedding config if model or dimensions specified
        embedding_config = None
        if embedding_model or embedding_dimensions:
            embedding_config = EmbeddingConfigOverride(
                model=embedding_model,
                dimensions=embedding_dimensions,
            )

        # Build request
        request = EmbeddingRequest(
            request_id=request_id,
            content_type=content_type,
            priority=priority,
            texts=text_inputs,
            storage=storage,
            embedding_config=embedding_config,
            metadata={
                **(metadata or {}),
                "apiKey": self._api_key,
            },
            allow_duplicates=allow_duplicates,
            created_at=datetime.utcnow(),
        )

        # Get the appropriate stream for this priority
        stream = get_stream_for_priority(priority, self._environment)

        # Serialize and publish to Redis Stream
        payload = json.dumps(request.to_dict())

        try:
            message_id = self._redis.xadd(stream, {"payload": payload})
            print(f"[VectorSDK] Embedding request sent to stream: {stream}, messageId: {message_id}, requestId: {request_id}")
        except Exception as e:
            print(f"[VectorSDK] Failed to send embedding request to {stream}: {e}")
            raise Exception(f"Failed to send embedding request to Redis: {e}")

        return request_id

    def wait_for(
        self,
        request_id: str,
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Wait for an embedding request to complete.

        Args:
            request_id: The request ID to wait for
            timeout: Maximum time to wait in seconds (default: 60)

        Returns:
            The embedding result

        Raises:
            TimeoutError: If no result is received within the timeout
        """
        list_key = get_embedding_response_key(request_id, self._environment)

        # BRPOP blocks until result is available or timeout
        result = self._redis.brpop(list_key, timeout=timeout)

        if result is None:
            raise TimeoutError(
                f"No result received for {request_id} within {timeout}s"
            )

        # result = (key, value)
        data = json.loads(result[1])
        # Cleanup the response list
        self._redis.delete(list_key)
        return EmbeddingResult.from_dict(data)

    def create_and_wait(
        self,
        texts: list[dict[str, Any]],
        content_type: str,
        priority: str = "normal",
        storage: Optional[StorageConfig] = None,
        metadata: Optional[dict[str, str]] = None,
        embedding_model: Optional[str] = None,
        embedding_dimensions: Optional[int] = None,
        allow_duplicates: bool = False,
        timeout: int = 60,
    ) -> EmbeddingResult:
        """
        Create embeddings and wait for the result.

        Uses BRPOP for efficient blocking wait - no race condition since the result
        is pushed to a list that persists until consumed.

        Args:
            texts: List of text inputs
            content_type: Type of content
            priority: Queue priority
            storage: Storage configuration
            metadata: Optional metadata
            embedding_model: Optional embedding model override
            embedding_dimensions: Optional embedding dimensions override
            timeout: Maximum time to wait in seconds

        Returns:
            The embedding result
        """
        request_id = str(uuid.uuid4())

        # Submit the request first
        self.create(
            texts=texts,
            content_type=content_type,
            priority=priority,
            storage=storage,
            metadata=metadata,
            request_id=request_id,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            allow_duplicates=allow_duplicates,
        )

        # Wait for result via BRPOP
        return self.wait_for(request_id, timeout)

    def get_queue_depth(self) -> dict[str, int]:
        """
        Get the current queue depth for each priority level.

        Returns:
            Dictionary mapping stream name to pending message count
        """
        streams = get_all_embedding_streams(self._environment)

        depths = {}
        for stream in streams:
            try:
                info = self._redis.xinfo_stream(stream)
                depths[stream] = info.get("length", 0)
            except Exception:
                depths[stream] = 0

        return depths
