"""Template module."""
