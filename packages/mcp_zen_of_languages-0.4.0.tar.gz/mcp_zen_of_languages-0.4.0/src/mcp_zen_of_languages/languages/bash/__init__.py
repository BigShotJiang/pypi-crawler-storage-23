"""Bash module."""

from mcp_zen_of_languages.languages.bash.analyzer import BashAnalyzer

__all__ = ["BashAnalyzer"]
