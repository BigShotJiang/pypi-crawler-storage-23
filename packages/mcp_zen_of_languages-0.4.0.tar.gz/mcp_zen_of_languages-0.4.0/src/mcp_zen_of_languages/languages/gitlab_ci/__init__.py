"""GitLab CI module."""

from mcp_zen_of_languages.languages.gitlab_ci.analyzer import GitLabCIAnalyzer

__all__ = ["GitLabCIAnalyzer"]
