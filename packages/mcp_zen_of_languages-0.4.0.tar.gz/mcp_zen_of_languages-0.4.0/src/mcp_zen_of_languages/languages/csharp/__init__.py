"""Csharp module."""

from mcp_zen_of_languages.languages.csharp.analyzer import CSharpAnalyzer

__all__ = ["CSharpAnalyzer"]
