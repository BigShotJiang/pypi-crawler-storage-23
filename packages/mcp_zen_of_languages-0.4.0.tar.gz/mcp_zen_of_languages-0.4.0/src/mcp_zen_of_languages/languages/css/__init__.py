"""CSS module."""

from mcp_zen_of_languages.languages.css.analyzer import CssAnalyzer

__all__ = ["CssAnalyzer"]
