"""Ruby module."""

from mcp_zen_of_languages.languages.ruby.analyzer import RubyAnalyzer

__all__ = ["RubyAnalyzer"]
