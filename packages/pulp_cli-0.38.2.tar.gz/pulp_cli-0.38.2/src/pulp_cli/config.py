import re
import sys
import typing as t
from pathlib import Path
from urllib.parse import urlparse

import click
import tomli_w

from pulp_glue.common.i18n import get_translation

from pulp_cli.generic import (
    HEADER_REGEX,
    REGISTERED_OUTPUT_FORMATTERS,
    _unset,
    chunk_size_callback,
    parse_size,
    pulp_group,
)

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


translation = get_translation(__package__)
_ = translation.gettext

_T = t.TypeVar("_T")
_AnyCallable = t.Callable[..., t.Any]
FC = t.TypeVar("FC", bound=_AnyCallable | click.Command)

CONFIG_LOCATIONS = [
    "/etc/pulp/cli.toml",
    str(Path(click.utils.get_app_dir("pulp"), "settings.toml")),
    str(Path(click.utils.get_app_dir("pulp"), "cli.toml")),
]
FORMAT_CHOICES = list(REGISTERED_OUTPUT_FORMATTERS.keys())
REQUIRED_SETTINGS = {
    "base_url",
    "api_root",
    "domain",
    "headers",
    "verify_ssl",
    "format",
    "dry_run",
    "timeout",
    "verbose",
}
OPTIONAL_SETTINGS = {
    "username",
    "password",
    "client_id",
    "client_secret",
    "cert",
    "key",
    "chunk_size",
    "plugins",
}
SETTINGS = REQUIRED_SETTINGS | OPTIONAL_SETTINGS


def headers_callback(
    ctx: click.Context, param: click.Parameter, value: t.Iterable[str]
) -> t.Iterable[str]:
    if value:
        header_regex = re.compile(HEADER_REGEX)
        failed_headers = ", ".join((item for item in value if not header_regex.match(item)))
        if failed_headers:
            raise click.BadParameter(f"format must be <header-name>:<value> \n{failed_headers}")

    default_map = ctx.default_map or {}
    headers: list[str] = default_map.get("headers", [])
    headers.extend(value)
    return headers


CONFIG_OPTIONS = [
    click.option("--base-url", default="https://localhost", help=_("API base url")),
    click.option(
        "--api-root",
        default="/pulp/",
        help=_("Absolute API base path on server (not including 'api/v3/')"),
    ),
    click.option("--domain", default="default", help=_("Domain to work in if feature is enabled")),
    click.option(
        "--header",
        "headers",
        multiple=True,
        help=_(
            "Custom header to add to each api call. "
            "Name and value are colon separated. "
            "Can be specified multiple times."
        ),
        callback=headers_callback,
    ),
    click.option("--username", default=None, help=_("Username on pulp server")),
    click.option("--password", default=None, help=_("Password on pulp server")),
    click.option("--client-id", default=None, help=_("OAuth2 client ID")),
    click.option("--client-secret", default=None, help=_("OAuth2 client secret")),
    click.option("--cert", default=None, help=_("Path to client certificate")),
    click.option(
        "--key",
        default=None,
        help=_("Path to client private key. Not required if client cert contains this."),
    ),
    click.option("--verify-ssl/--no-verify-ssl", default=True, help=_("Verify SSL connection")),
    click.option(
        "--format",
        type=click.Choice(FORMAT_CHOICES, case_sensitive=False),
        default="json",
        help=_("Format of the response"),
    ),
    click.option(
        "--chunk-size",
        help=_("Chunk size to break up {entity} into. Defaults to not chunking at all."),
        default=None,
        callback=chunk_size_callback,
    ),
    click.option(
        "--dry-run/--force",
        default=False,
        help=_("Trace commands without performing any unsafe HTTP calls"),
    ),
    click.option(
        "--timeout",
        "-T",
        type=int,
        default=0,
        help=_("Time to wait for background tasks, set to 0 to wait infinitely"),
    ),
    click.option(
        "-v",
        "--verbose",
        type=int,
        count=True,
        help=_("Increase verbosity; explain api calls as they are made"),
    ),
]


def not_none(value: _T | None, exc: Exception | None = None) -> _T:
    if value is None:
        raise exc or RuntimeError(_("Value cannot be None."))
    return value


def config_options(command: FC) -> FC:
    for option in reversed(CONFIG_OPTIONS):
        command = option(command)
    return command


def validate_config(config: dict[str, t.Any], strict: bool = False) -> None:
    """Validate, that the config provides the proper data types"""
    errors: list[str] = []
    if "base_url" in config:
        try:
            parsed_url = urlparse(config["base_url"])
            if (
                not parsed_url.scheme
                or not parsed_url.netloc
                or parsed_url.path
                or parsed_url.params
                or parsed_url.query
                or parsed_url.fragment
            ):
                errors.append(_("'base_url' should be of the form '<schema>://<netloc>'"))
        except ValueError:
            errors.append(_("Failed to parse the 'base_path'."))
    if "api_root" in config and (config["api_root"][0] != "/" or config["api_root"][-1] != "/"):
        errors.append(_("'api_root' must begin and end with '/'"))
    if "format" in config and config["format"].lower() not in FORMAT_CHOICES:
        errors.append(_("'format' is not one of {choices}").format(choices=FORMAT_CHOICES))
    if "verify_ssl" in config and not isinstance(config["verify_ssl"], bool):
        errors.append(_("'verify_ssl' is not a bool"))
    if "chunk_size" in config:
        try:
            parse_size(config["chunk_size"])
        except click.ClickException as e:
            errors.append(e.message)
    if "dry_run" in config and not isinstance(config["dry_run"], bool):
        errors.append(_("'dry_run' is not a bool"))
    if "timeout" in config and not isinstance(config["timeout"], int):
        errors.append(_("'timeout' is not an integer"))
    if "verbose" in config and not isinstance(config["verbose"], int):
        errors.append(_("'verbose' is not an integer"))
    if "domain" in config and not re.match(r"^[-a-zA-Z0-9_]+\Z", config["domain"]):
        errors.append(_("'domain' must be a slug string"))
    if "headers" in config:
        if not isinstance(config["headers"], list) or not all(
            (
                isinstance(header, str) and re.match(HEADER_REGEX, header)
                for header in config["headers"]
            )
        ):
            errors.append(_("'headers' must be a list of strings with a colon separator"))
    if "plugins" in config and not (
        isinstance(config["plugins"], list)
        and all((isinstance(item, str) for item in config["plugins"]))
    ):
        errors.append(_("'plugins' must be a list of strings"))
    unknown_settings = set(config.keys()) - SETTINGS
    if unknown_settings:
        errors.append(_("Unknown settings: '{}'.").format("','".join(unknown_settings)))
    if strict:
        missing_settings = REQUIRED_SETTINGS - set(config.keys())
        if missing_settings:
            errors.append(_("Missing settings: '{}'.").format("','".join(missing_settings)))
    if errors:
        raise ValueError("\n".join(errors))


def validate_settings(
    settings: t.MutableMapping[str, dict[str, t.Any]], strict: bool = False
) -> None:
    errors: list[str] = []
    if "cli" not in settings:
        errors.append(_("Could not locate default profile 'cli' setting"))

    for key, profile in settings.items():
        if key != "cli" and not key.startswith("cli-"):
            if strict:
                errors.append(_("Invalid profile '{key}'").format(key=key))
            continue
        try:
            validate_config(profile, strict=strict)
        except ValueError as e:
            errors.append(_("Profile {key}:").format(key=key))
            errors.append(str(e))
    if errors:
        raise ValueError("\n".join(errors))


@pulp_group(name="config", help=_("Manage pulp-cli config file"))
def config() -> None:
    pass


# This is a mypy bug getting confused with positional args
# https://github.com/python/mypy/issues/15037
@config.command(help=_("Create a pulp-cli config settings file"))  # type: ignore [arg-type]
@config_options
@click.option(
    "--plugin",
    "plugins",
    multiple=True,
    help=_("Select pluins supposed to be loaded. Can be specified multiple times"),
)
@click.option("--interactive", "-i", is_flag=True)
@click.option("--editor", "-e", is_flag=True, help=_("Edit the config file in an editor"))
@click.option("--overwrite", "-o", is_flag=True, help=_("Overwrite any existing config file"))
@click.option("--location", default=CONFIG_LOCATIONS[-1], type=click.Path(resolve_path=True))
@click.pass_context
def create(
    ctx: click.Context,
    /,
    interactive: bool,
    editor: bool,
    overwrite: bool,
    location: str,
    **kwargs: t.Any,
) -> None:
    def _check_location(location: str) -> None:
        if not overwrite and Path(location).exists():
            raise click.ClickException(
                _(
                    "File '{location}' already exists. Use --overwrite if you want to overwrite it."
                ).format(location=location)
            )

    def _prompt_config_option(name: str) -> t.Any:
        """Find the option from the root command and prompt."""
        option = next(p for p in ctx.command.params if p.name == name)
        if option.multiple:
            assert option.type == click.types.STRING
            assert _unset(option.default)
            result = []
            value = click.prompt(f"{name} (end with an empty line)", default="", type=option.type)
            while value:
                result.append(value)
                value = click.prompt(f"{name} (continued)", default="", type=option.type)
            return None if _unset(result) else result
        else:
            return click.prompt(name, default=option.default, type=option.type)

    settings: t.MutableMapping[str, t.Any] = kwargs
    if not settings["plugins"]:
        settings["plugins"] = None

    if interactive:
        location = click.prompt(_("Config file location"), default=location)
        _check_location(location)
        for setting in SETTINGS:
            settings[setting] = _prompt_config_option(setting)
    else:
        _check_location(location)

    # Sanitize
    settings = {k: v for k, v in settings.items() if v is not None}
    output: str = tomli_w.dumps({"cli": settings})

    if editor:
        output = not_none(
            click.edit(output), click.ClickException(_("No output from editor. Aborting."))
        )
    try:
        settings = tomllib.loads(output)
        validate_settings(settings)
    except (ValueError, tomllib.TOMLDecodeError) as e:
        raise click.ClickException(str(e))

    Path(location).parent.mkdir(parents=True, exist_ok=True)
    with Path(location).open("w") as sfile:
        sfile.write(output)

    click.echo(_("Created config file at '{location}'.").format(location=location))


@config.command(help=_("Open the settings config file in an editor"))
@click.option("--location", default=CONFIG_LOCATIONS[-1], type=click.Path(resolve_path=True))
def edit(location: str) -> None:
    if not Path(location).exists():
        raise click.ClickException(
            _(
                "File '{location}' does not exists. If you wish to create the file, use the pulp "
                "config create command."
            ).format(location=location)
        )

    with Path(location).open("r") as sfile:
        output: str = sfile.read()
    while True:
        output = not_none(
            click.edit(output), click.ClickException(_("No output from editor. Aborting."))
        )
        try:
            settings = tomllib.loads(output)
            validate_settings(settings)
            break
        except (ValueError, tomllib.TOMLDecodeError) as e:
            click.echo(str(e), err=True)
            click.confirm(_("Retry"), abort=True)
    with Path(location).open("w") as sfile:
        sfile.write(output)


@config.command(help=_("Validate a pulp-cli config file"))
@click.option("--location", default=CONFIG_LOCATIONS[-1], type=click.Path(resolve_path=True))
@click.option("--strict", is_flag=True, help=_("Validate that all settings are present"))
def validate(location: str, strict: bool) -> None:
    try:
        with open(location, "rb") as fp:
            settings = tomllib.load(fp)
    except tomllib.TOMLDecodeError:
        raise click.ClickException(_("Invalid toml file '{location}'.").format(location=location))

    try:
        validate_settings(settings, strict)
    except ValueError as e:
        raise click.ClickException(str(e))

    click.echo(_("File '{location}' is a valid pulp-cli config.").format(location=location))
