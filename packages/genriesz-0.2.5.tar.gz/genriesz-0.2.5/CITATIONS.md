# CITATIONS

This file collects the main bibliographic entries referenced from:

- `README.md` (especially **Table 1**), and
- the core **genriesz / GRR** paper(s).

If you notice a missing or better canonical link for an item, feel free to open a PR.

---

## genriesz / GRR papers

- [Masahiro Kato (2026). *Riesz Representer Fitting under Bregman Divergence: A Unified Framework for Debiased Machine Learning* (arXiv:2601.07752)](https://arxiv.org/abs/2601.07752)  
  - Note: this paper consolidates earlier related drafts: [arXiv:2509.22122](https://arxiv.org/abs/2509.22122), [arXiv:2510.26783](https://arxiv.org/abs/2510.26783), and [arXiv:2510.23534](https://arxiv.org/abs/2510.23534).
- [Masahiro Kato (2025). *Direct Bias-Correction Term Estimation for Propensity Scores and Average Treatment Effect Estimation* (arXiv:2509.22122)](https://arxiv.org/abs/2509.22122)
- [Masahiro Kato (2025). *Nearest Neighbor Matching as Least Squares Density Ratio Estimation and Riesz Regression* (arXiv:2510.24433)](https://arxiv.org/abs/2510.24433)

---

## Table 1 references (density-ratio / balancing / Riesz regression)

- [Kanamori, Hido & Sugiyama (2009)](https://jmlr.org/papers/v10/kanamori09a.html): “A Least-squares Approach to Direct Importance Estimation” (JMLR)
- [Kanamori et al. (2012)](https://link.springer.com/article/10.1007/s10994-011-5266-3): “Statistical analysis of kernel-based least-squares density-ratio estimation (KuLSIF)”
- [Chernozhukov et al. (2022)](https://arxiv.org/abs/2110.03031): “RieszNet and ForestRiesz”
- [Lee & Schuler (2025)](https://arxiv.org/abs/2501.04871): “RieszBoost: Gradient Boosting for Riesz Regression”
- [Singh (2021)](https://arxiv.org/abs/2102.11076): “Kernel Ridge Riesz Representers (KRRR)”
- [Lin, Ding & Han (2023)](https://arxiv.org/abs/2112.13506): “Estimation based on nearest neighbor matching: from density ratio to average treatment effect”
- [Wager & Athey (2018)](https://www.tandfonline.com/doi/abs/10.1080/01621459.2017.1319839): “Estimation and Inference of Heterogeneous Treatment Effects using Random Forests (causal forest)”
- [Gretton et al. (2009)](https://www.gatsby.ucl.ac.uk/~gretton/papers/covariateShiftChapter.pdf): “Covariate Shift by Kernel Mean Matching”
- [Chen & Christensen (2015)](https://www.jstor.org/stable/43616960): “Sieve Wald and QLR Inferences on Semiparametric Conditional Moment Models”
- [Zubizarreta (2015)](https://www.tandfonline.com/doi/abs/10.1080/01621459.2015.1023805): “Stable Weights that Balance Covariates for Estimation With Incomplete Outcome Data”
- [Bruns-Smith et al. (2025)](https://arxiv.org/abs/2304.14545): “Augmented balancing weights as linear regression”
- [Athey, Imbens & Wager (2018)](https://arxiv.org/abs/1604.07125): “Approximate Residual Balancing: Debiased Inference of Average Treatment Effects in High Dimensions”
- [Tarr & Imai (2025)](https://imai.fas.harvard.edu/research/files/causalsvm.pdf): “Estimating Average Treatment Effects With Support Vector Machines”
- [Nguyen, Wainwright & Jordan (2010)](https://arxiv.org/abs/0809.0853): “Estimating divergence functionals and the likelihood ratio by convex risk minimization”
- [Zhao (2019)](https://projecteuclid.org/journals/annals-of-statistics/volume-47/issue-2/Covariate-balancing-propensity-score-by-tailored-loss-functions/10.1214/18-AOS1698.full): “Covariate balancing propensity score by tailored loss functions”
- [Tan (2020)](https://academic.oup.com/biomet/article-abstract/107/1/137/5658668): “Regularized calibrated estimation of propensity scores with model misspecification and high-dimensional data”
- [Sugiyama et al. (2008)](https://www.ism.ac.jp/editsec/aism/60/699.pdf): “Direct importance estimation for covariate shift adaptation (KLIEP)”
- [Hainmueller (2012)](https://www.cambridge.org/core/journals/political-analysis/article/entropy-balancing-for-causal-effects-a-multivariate-reweighting-method-to-produce-balanced-samples-in-observational-studies/220E4FC838066552B53128E647E4FAA7): “Entropy Balancing for Causal Effects”
- [Qin (1998)](https://academic.oup.com/biomet/article-abstract/85/3/619/229087): “Inferences for case-control and semiparametric two-sample density ratio models”
- [Rhodes et al. (2020)](https://proceedings.neurips.cc/paper_files/paper/2020/hash/33d3b157ddc0896addfb22fa2a519097-Abstract.html): “Telescoping Density-Ratio Estimation (TRE)”
- [Sugiyama, Suzuki & Kanamori (2012)](https://www.cambridge.org/core/books/density-ratio-estimation-in-machine-learning/BCBEA6AEAADD66569B1E85DDDEAA7648): *Density Ratio Estimation in Machine Learning*
- [du Plessis, Niu & Sugiyama (2015)](https://proceedings.mlr.press/v37/plessis15.html): “Convex Formulation for Learning from Positive and Unlabeled Data”
- [Kiryo et al. (2017)](https://arxiv.org/abs/1703.00593): “Positive-Unlabeled Learning with Non-Negative Risk Estimator”
- [Kato & Teshima (2021)](https://proceedings.mlr.press/v139/kato21a.html): “Non-Negative Bregman Divergence Minimization for Deep Direct Density Ratio Estimation (D3RE)”
