Examples
========

This page lists runnable examples included in the repository.

Jupyter notebooks
-----------------

The notebooks below are shipped with the repo (see ``notebooks/``) and are
mirrored under ``docs/notebooks/`` for documentation builds.

.. toctree::
   :maxdepth: 1

   notebooks/ATE_example
   notebooks/ATT_example
   notebooks/DID_example
   notebooks/AME_example

Python scripts
--------------

The ``examples/`` directory contains small scripts that can be run directly.

- ``examples/ate_synthetic_glm.py``
- ``examples/ate_synthetic_glm_polynomial.py``
- ``examples/ate_synthetic_glm_rkhs_rff.py``
- ``examples/ate_synthetic_glm_rf_leaf_basis.py``
- ``examples/ate_synthetic_glm_nn_basis.py``
- ``examples/ate_synthetic_nn_matching.py``
- ``examples/att_synthetic_glm.py``
- ``examples/did_synthetic_glm.py``
- ``examples/ame_synthetic_glm.py``
