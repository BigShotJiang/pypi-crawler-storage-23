#!/bin/bash
# Git Bash Conda 初始化脚本

echo "🔧 正在设置 Git Bash 中的 Conda 支持..."

# 检测 conda 安装路径
CONDA_BASE=""
if command -v conda &> /dev/null; then
    CONDA_BASE=$(conda info --base 2>/dev/null)
fi

# 如果自动检测失败，尝试常见路径
if [ -z "$CONDA_BASE" ] || [ ! -d "$CONDA_BASE" ]; then
    # Windows 常见路径
    POSSIBLE_PATHS=(
        "/d/soft/miniconda3-py38"
        "/c/Users/$USER/miniconda3"
        "/c/Users/$USER/anaconda3"
        "/c/ProgramData/Miniconda3"
        "/c/ProgramData/Anaconda3"
    )
    
    for path in "${POSSIBLE_PATHS[@]}"; do
        if [ -d "$path" ]; then
            CONDA_BASE="$path"
            break
        fi
    done
fi

if [ -z "$CONDA_BASE" ] || [ ! -d "$CONDA_BASE" ]; then
    echo "❌ 未找到 conda 安装，请手动设置 CONDA_BASE 环境变量"
    echo "   例如: export CONDA_BASE=/d/soft/miniconda3-py38"
    exit 1
fi

echo "✅ 找到 Conda: $CONDA_BASE"

# 初始化 conda
if [ -f "$CONDA_BASE/etc/profile.d/conda.sh" ]; then
    . "$CONDA_BASE/etc/profile.d/conda.sh"
    echo "✅ Conda 已初始化（使用 conda.sh）"
elif command -v conda &> /dev/null; then
    eval "$(conda shell.bash hook)" 2>/dev/null && echo "✅ Conda 已初始化（使用 shell hook）" || {
        echo "⚠️  警告: conda shell hook 初始化失败"
    }
else
    echo "❌ 无法初始化 conda"
    exit 1
fi

# 激活环境（如果指定）
if [ -n "$1" ]; then
    if conda env list | grep -q "^$1 "; then
        conda activate "$1"
        echo "✅ 已激活环境: $1"
    else
        echo "⚠️  警告: 环境 '$1' 不存在"
        echo "可用环境列表:"
        conda env list
    fi
fi

echo ""
echo "💡 提示: 将以下内容添加到 ~/.bashrc 以永久启用:"
echo "   source $(pwd)/setup_gitbash_conda.sh"

