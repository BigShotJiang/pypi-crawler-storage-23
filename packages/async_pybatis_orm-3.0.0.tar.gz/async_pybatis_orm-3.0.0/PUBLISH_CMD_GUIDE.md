# 在 CMD 中执行发布脚本指南

## 🚀 快速开始

### 步骤 1: 打开 CMD

**方式 A: 从开始菜单**

- 按 `Win` 键，输入 `cmd`，回车

**方式 B: 从项目文件夹**

- 在项目文件夹中，按住 `Shift` 键，右键点击空白处
- 选择"在此处打开命令窗口"或"在此处打开 PowerShell 窗口"

**方式 C: 使用运行对话框**

- 按 `Win + R`
- 输入 `cmd`，回车

### 步骤 2: 切换到项目目录

```cmd
cd /d D:\code\python\async-pybatis-orm
```

**说明**：

- `cd` - 切换目录命令
- `/d` - 同时切换驱动器（如果目标在不同盘符）
- `D:\code\python\async-pybatis-orm` - 你的项目路径

### 步骤 3: 激活 Conda 环境（如果使用）

```cmd
conda activate async-pybatis-orm
```

**验证环境**：

```cmd
python --version
pip list
```

### 步骤 4: 执行发布脚本

```cmd
scripts\publish.bat
```

## 📋 完整命令示例

```cmd
REM 1. 打开 CMD 后，切换到项目目录
cd /d D:\code\python\async-pybatis-orm

REM 2. 激活 conda 环境
conda activate async-pybatis-orm

REM 3. 执行发布脚本
scripts\publish.bat
```

## 🔧 常见问题

### 问题 1: 找不到脚本

**错误**：`'scripts' 不是内部或外部命令`

**解决方案**：

```cmd
REM 确保在项目根目录
cd /d D:\code\python\async-pybatis-orm

REM 检查文件是否存在
dir scripts\publish.bat

REM 如果存在，使用完整路径
.\scripts\publish.bat
```

### 问题 2: Python 未找到

**错误**：`'python' 不是内部或外部命令`

**解决方案**：

```cmd
REM 方法 1: 激活 conda 环境
conda activate async-pybatis-orm

REM 方法 2: 使用完整路径
D:\soft\miniconda3-py38\envs\async-pybatis-orm\python.exe -m build

REM 方法 3: 添加 Python 到 PATH（临时）
set PATH=D:\soft\miniconda3-py38\envs\async-pybatis-orm;%PATH%
```

### 问题 3: Conda 命令未找到

**错误**：`'conda' 不是内部或外部命令`

**解决方案**：

```cmd
REM 初始化 conda（只需要执行一次）
call D:\soft\miniconda3-py38\Scripts\activate.bat D:\soft\miniconda3-py38

REM 或者添加到 PATH（临时）
set PATH=D:\soft\miniconda3-py38\Scripts;%PATH%

REM 然后激活环境
conda activate async-pybatis-orm
```

### 问题 4: 权限问题

**错误**：`拒绝访问` 或 `Permission denied`

**解决方案**：

- 以管理员身份运行 CMD：
  1. 右键点击 CMD
  2. 选择"以管理员身份运行"

## 💡 一键执行脚本

创建一个 `publish.cmd` 文件在项目根目录：

```cmd
@echo off
REM 一键发布脚本

REM 切换到脚本所在目录
cd /d %~dp0

REM 激活 conda 环境
call conda activate async-pybatis-orm

REM 执行发布脚本
call scripts\publish.bat

pause
```

然后直接双击 `publish.cmd` 即可。

## 🎯 推荐工作流程

### 方式 A: 手动执行（适合调试）

```cmd
REM 1. 打开 CMD
REM 2. 切换到项目目录
cd /d D:\code\python\async-pybatis-orm

REM 3. 激活环境
conda activate async-pybatis-orm

REM 4. 执行脚本
scripts\publish.bat
```

### 方式 B: 使用快捷方式

1. 创建 CMD 快捷方式
2. 右键 → 属性
3. 目标设置为：
   ```
   C:\Windows\System32\cmd.exe /k "cd /d D:\code\python\async-pybatis-orm && conda activate async-pybatis-orm"
   ```
4. 双击快捷方式，然后执行 `scripts\publish.bat`

### 方式 C: 使用批处理文件

在项目根目录创建 `quick_publish.bat`：

```cmd
@echo off
cd /d %~dp0
call conda activate async-pybatis-orm
call scripts\publish.bat
pause
```

然后双击 `quick_publish.bat` 即可。

## 📝 执行过程说明

执行 `scripts\publish.bat` 后，脚本会：

1. ✅ 检查 Python 是否安装
2. ✅ 检查并安装 `build` 和 `twine` 工具
3. 🧹 清理旧的构建文件（dist/, build/, \*.egg-info/）
4. 🔨 构建分发包（源码包和 wheel 包）
5. ✅ 检查构建的包
6. ❓ 询问是否先发布到 TestPyPI
7. 📤 上传到 PyPI（正式或测试）

## 🔐 认证信息

上传时会提示输入：

- **Username**: `__token__`
- **Password**: `<你的 PyPI API token>`

**获取 Token**：

1. 登录 https://pypi.org
2. Account settings → API tokens
3. 创建新 token
4. 复制并保存（只显示一次）

---

**提示**：如果遇到编码问题（中文显示乱码），可以执行：

```cmd
chcp 65001
```

这将 CMD 编码设置为 UTF-8。

