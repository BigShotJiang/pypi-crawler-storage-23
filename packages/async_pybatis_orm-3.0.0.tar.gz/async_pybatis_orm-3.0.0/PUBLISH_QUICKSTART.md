# PyPI 发布快速指南

## 🚀 快速发布步骤

### 1. 安装工具

```bash
pip install --upgrade build twine
```

### 2. 更新版本号

编辑 `pyproject.toml` 和 `async_pybatis_orm/__init__.py`，更新版本号。

### 3. 构建和发布

#### 方式 A: 使用脚本（推荐）

**Linux/Mac:**

```bash
chmod +x scripts/publish.sh
./scripts/publish.sh
```

**Windows:**

```cmd
scripts\publish.bat
```

#### 方式 B: 手动执行

```bash
# 1. 清理旧文件
rm -rf dist/ build/ *.egg-info/

# 2. 构建
python -m build

# 3. 检查
python -m twine check dist/*

# 4. 发布到测试 PyPI（可选）
python -m twine upload --repository testpypi dist/*

# 5. 发布到正式 PyPI
python -m twine upload dist/*
```

### 4. 配置认证

**方式 1: 环境变量（推荐）**

```bash
# Linux/Mac
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=your_api_token_here

# Windows PowerShell
$env:TWINE_USERNAME="__token__"
$env:TWINE_PASSWORD="your_api_token_here"
```

**方式 2: 交互式输入**

运行 `twine upload` 时会提示输入：

- Username: `__token__`
- Password: `<你的 PyPI API token>`

## 📝 发布前检查

- [ ] 版本号已更新
- [ ] 测试通过
- [ ] README 完整
- [ ] 代码已格式化

## 🔗 获取 PyPI Token

1. 登录 https://pypi.org
2. Account settings → API tokens
3. 创建新 token
4. 复制并保存（只显示一次）

## 📚 详细文档

查看 [PUBLISH.md](./PUBLISH.md) 获取完整说明。
