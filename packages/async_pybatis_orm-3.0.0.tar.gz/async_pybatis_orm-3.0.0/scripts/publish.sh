#!/bin/bash
# PyPI 发布脚本（支持 Git Bash）

set -e  # 遇到错误立即退出

echo "🚀 开始发布 async-pybatis-orm 到 PyPI"

# 在 Git Bash 中初始化 conda（如果需要）
if [ -n "$MSYSTEM" ] || [ -n "$MSYSTEM_PREFIX" ]; then
    if command -v conda &> /dev/null; then
        # 尝试初始化 conda
        eval "$(conda shell.bash hook)" 2>/dev/null || {
            echo "⚠️  警告: 无法初始化 conda，将使用系统 Python"
        }
    fi
fi

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查必要的工具
echo "📦 检查构建工具..."
if ! command -v python &> /dev/null; then
    echo -e "${RED}❌ Python 未安装${NC}"
    exit 1
fi

if ! python -m pip show build &> /dev/null; then
    echo -e "${YELLOW}⚠️  build 未安装，正在安装...${NC}"
    python -m pip install --upgrade build twine
fi

if ! python -m pip show twine &> /dev/null; then
    echo -e "${YELLOW}⚠️  twine 未安装，正在安装...${NC}"
    python -m pip install --upgrade twine
fi

# 清理旧的构建文件
echo "🧹 清理旧的构建文件..."
rm -rf dist/
rm -rf build/
rm -rf *.egg-info/
rm -rf async_pybatis_orm.egg-info/

# 构建分发包
echo "🔨 构建分发包..."
python -m build

# 检查构建的包
echo "✅ 检查构建的包..."
python -m twine check dist/*

# 询问是否发布到测试 PyPI
read -p "是否先发布到 TestPyPI? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "📤 上传到 TestPyPI..."
    python -m twine upload --repository testpypi dist/*
    echo -e "${GREEN}✅ 已上传到 TestPyPI${NC}"
    echo "测试安装: pip install --index-url https://test.pypi.org/simple/ async-pybatis-orm"
    read -p "是否继续发布到正式 PyPI? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "已取消发布到正式 PyPI"
        exit 0
    fi
fi

# 发布到正式 PyPI
echo "📤 上传到正式 PyPI..."
python -m twine upload dist/*

echo -e "${GREEN}🎉 发布成功！${NC}"
echo "验证安装: pip install async-pybatis-orm"

