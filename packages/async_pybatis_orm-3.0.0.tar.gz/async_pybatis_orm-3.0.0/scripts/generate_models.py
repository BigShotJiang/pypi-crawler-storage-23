#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""CLI for generating ORM models from MySQL tables."""

import argparse
import json
from typing import List, Optional

from async_pybatis_orm.codegen import (
    DBConfig,
    GenerateOptions,
    generate_models,
)


def _split_csv(value: Optional[str]) -> Optional[List[str]]:
    if not value:
        return None
    items = [item.strip() for item in value.split(",")]
    return [item for item in items if item]


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate models from MySQL tables.")
    parser.add_argument("--host", required=True, help="MySQL host")
    parser.add_argument("--port", type=int, default=3306, help="MySQL port")
    parser.add_argument("--user", required=True, help="MySQL user")
    parser.add_argument("--password", required=True, help="MySQL password")
    parser.add_argument("--database", required=True, help="Database name")
    parser.add_argument("--charset", default="utf8mb4", help="Connection charset")

    parser.add_argument("--output-dir", required=True, help="Output directory for generated files")
    parser.add_argument("--tables", help="Comma-separated table names")
    parser.add_argument("--include-tables", help="Comma-separated include tables")
    parser.add_argument("--exclude-tables", help="Comma-separated exclude tables")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing files")
    parser.add_argument(
        "--file-layout",
        choices=["per_table", "single_file"],
        default="per_table",
        help="Generated file layout",
    )
    parser.add_argument("--single-file-name", default="models.py", help="Single file name")
    parser.add_argument(
        "--base-class",
        choices=["CommonModel", "CRUDModel"],
        default="CommonModel",
        help="Base class used for generated models",
    )
    parser.add_argument("--no-init", action="store_true", help="Do not update __init__.py exports")
    parser.add_argument(
        "--filename-case",
        choices=["snake", "kebab", "pascal"],
        default="snake",
        help="Generated file name case",
    )
    parser.add_argument(
        "--class-name-case",
        choices=["pascal", "camel"],
        default="pascal",
        help="Generated class name case",
    )
    parser.add_argument("--file-name-prefix", default="", help="Prefix for generated file names")
    parser.add_argument("--file-name-suffix", default="", help="Suffix for generated file names")
    parser.add_argument("--class-name-prefix", default="", help="Prefix for generated class names")
    parser.add_argument("--class-name-suffix", default="", help="Suffix for generated class names")

    args = parser.parse_args()

    db = DBConfig(
        host=args.host,
        port=args.port,
        user=args.user,
        password=args.password,
        database=args.database,
        charset=args.charset,
    )
    options = GenerateOptions(
        output_dir=args.output_dir,
        tables=_split_csv(args.tables),
        include_tables=_split_csv(args.include_tables),
        exclude_tables=_split_csv(args.exclude_tables),
        overwrite=args.overwrite,
        file_layout=args.file_layout,
        single_file_name=args.single_file_name,
        base_class=args.base_class,
        add_init=not args.no_init,
        filename_case=args.filename_case,
        class_name_case=args.class_name_case,
        file_name_prefix=args.file_name_prefix,
        file_name_suffix=args.file_name_suffix,
        class_name_prefix=args.class_name_prefix,
        class_name_suffix=args.class_name_suffix,
    )

    result = generate_models(db, options)
    payload = {
        "generated": [
            {
                "table": item.table,
                "class_name": item.class_name,
                "file_path": item.file_path,
                "skipped": item.skipped,
                "reason": item.reason,
            }
            for item in result.generated
        ],
        "skipped": [
            {
                "table": item.table,
                "class_name": item.class_name,
                "file_path": item.file_path,
                "skipped": item.skipped,
                "reason": item.reason,
            }
            for item in result.skipped
        ],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

