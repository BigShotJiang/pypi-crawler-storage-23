# Git 提交规范（中文）

## 基本格式

```text
<type>(<scope>): <subject>

<body>

<footer>
```

- `<type>`：必填，提交类型
- `<scope>`：可选，模块或子系统
- `<subject>`：必填，一行简述
- `<body>`：可选，说明 why/what/how
- `<footer>`：可选，关联任务或破坏性说明

## type 列表

- `feat`：新增功能
- `fix`：修复 bug
- `docs`：仅文档变更
- `style`：代码风格变更（不改逻辑）
- `refactor`：重构（非新增、非修复）
- `perf`：性能优化
- `test`：测试相关变更
- `build`：构建系统或依赖调整
- `ci`：CI/CD 配置变更
- `chore`：杂项维护
- `revert`：回滚提交

## 头部规范

- `type` 使用小写英文
- `scope` 使用小写或 kebab-case
- `subject` 用中文祈使句，避免空泛描述
- `subject` 建议不超过 50-72 字符，不加句号
- 头部整行建议不超过 100 字符

示例：

```text
feat(user): 支持邮箱登录
fix(order): 修复空支付信息导致的异常
docs: 更新部署指南
```

## body 规范

在提交较大或有背景时填写 `body`，推荐包含：

- 为什么改（why）
- 改了什么（what）
- 如何改（how，可选）

建议使用中文，分段清晰，每行不超过约 80-100 字符。

## footer 规范

- 关联任务：`Fixes #123`、`Closes PROJ-456`
- 破坏性变更：`BREAKING CHANGE: ...`

示例：

```text
fix(order): 修复空支付信息导致的异常

新增支付对象空值判断，并记录异常上下文日志，
避免订单状态处理中断。

Fixes #231
```

## 团队建议

- 一次提交只做一类改动
- 跨模块改动必须拆分多次提交
- 跨模块且不可拆时，必须在 body 明确拆分原因
