#!/usr/bin/env python3
"""
Plan git commit groups from local repository changes.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from collections import defaultdict
from pathlib import Path


DOC_EXTS = {".md", ".rst", ".txt", ".adoc"}
BUILD_FILES = {
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "requirements.txt",
    "requirements-dev.txt",
    "poetry.lock",
    "pdm.lock",
    "uv.lock",
    "package.json",
    "package-lock.json",
}


def run(cmd: list[str]) -> str:
    try:
        return subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True).strip()
    except subprocess.CalledProcessError as exc:
        if cmd and cmd[0] == "git" and "-c" not in cmd:
            repo = str(Path.cwd()).replace("\\", "/")
            retry = ["git", "-c", f"safe.directory={repo}", *cmd[1:]]
            return subprocess.check_output(retry, stderr=subprocess.STDOUT, text=True).strip()
        raise


def list_changed_files() -> list[str]:
    files = set()
    for cmd in (
        ["git", "diff", "--name-only"],
        ["git", "diff", "--cached", "--name-only"],
        ["git", "ls-files", "--others", "--exclude-standard"],
    ):
        output = run(cmd)
        for line in output.splitlines():
            line = line.strip()
            if line:
                files.add(line)
    return sorted(files)


def is_doc_file(path: str) -> bool:
    p = Path(path)
    if p.suffix.lower() in DOC_EXTS:
        return True
    parts = {part.lower() for part in p.parts}
    return "docs" in parts


def is_ci_file(path: str) -> bool:
    p = path.replace("\\", "/").lower()
    return p.startswith(".github/workflows/") or p == "jenkinsfile"


def classify(path: str) -> tuple[str, str]:
    name = Path(path).name.lower()
    if is_doc_file(path):
        return ("docs", "docs")
    if is_ci_file(path):
        return ("ci", "ci")
    if name in BUILD_FILES:
        return ("build", "build")
    parts = Path(path).parts
    if parts and parts[0].lower() in {"tests", "test"}:
        return ("test", "tests")
    scope = parts[0].replace("_", "-").lower() if parts else "repo"
    return ("chore", scope)


def suggest_subject(group_type: str, scope: str, files: list[str]) -> str:
    if group_type == "docs":
        return "更新文档说明"
    if group_type == "build":
        return "调整构建与依赖配置"
    if group_type == "ci":
        return "调整持续集成配置"
    if group_type == "test":
        return "补充和调整测试用例"
    if len(files) == 1:
        return f"更新 {Path(files[0]).name}"
    return f"整理 {scope} 模块改动"


def build_groups(files: list[str]) -> list[dict]:
    bucket: dict[tuple[str, str], list[str]] = defaultdict(list)
    for f in files:
        key = classify(f)
        bucket[key].append(f)

    groups = []
    for (group_type, scope), grouped_files in sorted(bucket.items()):
        groups.append(
            {
                "type": group_type,
                "scope": scope,
                "subject": suggest_subject(group_type, scope, grouped_files),
                "files": sorted(grouped_files),
            }
        )
    return groups


def main() -> int:
    parser = argparse.ArgumentParser(description="Plan commit groups from local git changes.")
    parser.add_argument("--json", action="store_true", help="Output JSON.")
    args = parser.parse_args()

    try:
        files = list_changed_files()
    except subprocess.CalledProcessError as exc:
        print(exc.output, file=sys.stderr)
        return 1

    if not files:
        print("No local changes found.")
        return 0

    groups = build_groups(files)
    if args.json:
        print(json.dumps(groups, ensure_ascii=False, indent=2))
        return 0

    print(f"Detected {len(files)} changed files.")
    print(f"Proposed {len(groups)} commit group(s):")
    for idx, group in enumerate(groups, start=1):
        header = f"{group['type']}({group['scope']}): {group['subject']}"
        print(f"\n[{idx}] {header}")
        for file_path in group["files"]:
            print(f"  - {file_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
