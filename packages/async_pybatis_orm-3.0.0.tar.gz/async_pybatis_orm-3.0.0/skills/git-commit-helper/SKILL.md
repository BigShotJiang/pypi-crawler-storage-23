---
name: git-commit-helper
description: Analyze current git repository changes, split unrelated modifications into multiple commits by module/intent, and write Chinese conventional commit messages. Use when users ask to commit code, organize mixed changes, create clean commit history, or enforce commit message standards.
---

# Git Commit Helper

Use this skill to turn messy, mixed local changes into clean, reviewable commit history.

## Workflow

1. Inspect current changes before planning commits.

```bash
git status --short --branch
git diff --name-only
git diff --cached --name-only
```

2. Build commit groups by module and intent.

- Separate independent modules into different commits.
- Separate documentation-only changes (`*.md`, docs) from code changes.
- Separate dependency/build changes (`pyproject.toml`, `requirements*.txt`, `setup.py`, lock files) from feature/fix code.
- Keep each commit focused on one semantic purpose.

3. Use the planner script when grouping is unclear.

```bash
python skills/git-commit-helper/scripts/plan_commit_groups.py
```

4. Commit each group sequentially.

```bash
git add <group-file-1> <group-file-2>
git commit -m "<type>(<scope>): <subject>" -m "<body>" -m "<footer>"
```

5. Validate each commit and continue with remaining files.

```bash
git show --name-only --oneline -1
git status --short
```

## Commit Message Rules

- Follow Conventional Commits header format: `<type>(<scope>): <subject>`.
- Write `body` in Chinese for non-trivial commits.
- Write clear `subject` in Chinese imperative style, avoid vague text like `update` or `fix bug`.
- Keep header line within 100 chars; keep `subject` concise.
- If there are breaking changes, add `BREAKING CHANGE:` in footer.

Use full type list and examples from:

- `references/commit-spec-zh.md`

## Safety Constraints

- Never include unrelated files in a commit.
- Never run destructive git commands unless explicitly requested.
- If grouping is ambiguous, summarize options and choose the smallest-risk split.

## Output Contract

When executing this skill for a user request:

1. Show planned commit groups first (files + proposed type/scope/subject).
2. Execute commits one by one.
3. Report final commit list (`git log --oneline -n <count>`).
