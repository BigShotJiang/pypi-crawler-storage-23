# PyPI 发布指南

本文档说明如何将 `async-pybatis-orm` 打包并发布到 PyPI。

## 📋 前置准备

### 1. 安装必要的工具

```bash
# 安装构建工具
pip install --upgrade build twine

# 或者使用 uv
uv pip install build twine
```

### 2. 检查项目配置

确保 `pyproject.toml` 中的以下信息正确：

- `name`: 包名（已配置为 `async-pybatis-orm`）
- `version`: 版本号（当前为 `1.0.0`）
- `description`: 项目描述
- `authors`: 作者信息
- `license`: 许可证
- `dependencies`: 依赖项

### 3. 准备 PyPI 账号

- **PyPI 正式环境**: https://pypi.org/account/register/
- **PyPI 测试环境**: https://test.pypi.org/account/register/

注册账号后，需要创建 API Token：

1. 登录 PyPI
2. 进入 Account settings → API tokens
3. 创建新的 API token（作用域选择整个账户或特定项目）
4. 保存 token（只显示一次，请妥善保存）

## 🚀 发布流程

### 方法一：使用 build + twine（推荐）

#### 步骤 1: 清理旧的构建文件

```bash
# 删除旧的构建文件
rm -rf dist/
rm -rf build/
rm -rf *.egg-info/
rm -rf async_pybatis_orm.egg-info/
```

#### 步骤 2: 更新版本号

在 `pyproject.toml` 中更新版本号：

```toml
[project]
version = "1.0.1"  # 更新版本号
```

#### 步骤 3: 构建分发包

```bash
# 构建源码分发包和 wheel 包
python -m build

# 构建完成后，会在 dist/ 目录下生成：
# - async_pybatis_orm-1.0.1.tar.gz (源码分发包)
# - async_pybatis_orm-1.0.1-py3-none-any.whl (wheel 包)
```

#### 步骤 4: 检查构建的包

```bash
# 检查包的内容
twine check dist/*

# 应该看到类似输出：
# Checking dist/async_pybatis_orm-1.0.1-py3-none-any.whl: PASSED
# Checking dist/async_pybatis_orm-1.0.1.tar.gz: PASSED
```

#### 步骤 5: 测试发布到 TestPyPI（可选但推荐）

```bash
# 上传到测试 PyPI
twine upload --repository testpypi dist/*

# 会提示输入用户名和密码：
# Username: __token__
# Password: <你的 API token>
```

测试安装：

```bash
# 从测试 PyPI 安装
pip install --index-url https://test.pypi.org/simple/ async-pybatis-orm

# 或者使用 pipx
pip install -i https://test.pypi.org/simple/ async-pybatis-orm
```

#### 步骤 6: 发布到正式 PyPI

```bash
# 上传到正式 PyPI
twine upload dist/*

# 会提示输入用户名和密码：
# Username: __token__
# Password: <你的 API token>
```

#### 步骤 7: 验证发布

```bash
# 等待几分钟后，尝试安装
pip install async-pybatis-orm

# 验证安装
python -c "import async_pybatis_orm; print(async_pybatis_orm.__version__)"
```

### 方法二：使用 uv（如果使用 uv 管理项目）

```bash
# 使用 uv 构建
uv build

# 使用 uv 发布（需要配置 PyPI token）
uv publish
```

### 方法三：使用 setuptools（传统方法）

```bash
# 安装 setuptools 和 wheel
pip install setuptools wheel

# 构建
python setup.py sdist bdist_wheel

# 上传
twine upload dist/*
```

## 🔧 配置 PyPI Token（推荐方式）

为了避免每次输入密码，可以配置 token：

### 方式 1: 使用环境变量

```bash
# Linux/Mac
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=your_api_token_here

# Windows (PowerShell)
$env:TWINE_USERNAME="__token__"
$env:TWINE_PASSWORD="your_api_token_here"

# Windows (CMD)
set TWINE_USERNAME=__token__
set TWINE_PASSWORD=your_api_token_here
```

### 方式 2: 使用配置文件

创建 `~/.pypirc` 文件（Linux/Mac）或 `%USERPROFILE%\.pypirc`（Windows）：

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = your_api_token_here

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = your_testpypi_token_here
```

**注意**: 配置文件包含敏感信息，请确保：

- 不要将 `.pypirc` 提交到 Git
- 设置适当的文件权限（Linux/Mac: `chmod 600 ~/.pypirc`）

## 📝 发布检查清单

发布前请确认：

- [ ] 版本号已更新
- [ ] `README.md` 内容完整且准确
- [ ] 所有测试通过
- [ ] 代码已格式化（`black`, `isort`）
- [ ] 没有硬编码的敏感信息
- [ ] `__init__.py` 中的 `__version__` 已更新（如果有）
- [ ] 依赖项列表完整且版本正确
- [ ] 许可证文件存在（如果需要）
- [ ] 已构建并检查了分发包（`twine check`）

## 🎯 版本号规范

遵循 [语义化版本](https://semver.org/)：

- **主版本号（MAJOR）**: 不兼容的 API 修改
- **次版本号（MINOR）**: 向后兼容的功能新增
- **修订号（PATCH）**: 向后兼容的问题修复

示例：

- `1.0.0` → `1.0.1` (修复 bug)
- `1.0.0` → `1.1.0` (新功能)
- `1.0.0` → `2.0.0` (重大变更)

## 🔄 更新已发布的包

如果要更新已发布的包：

1. 更新 `pyproject.toml` 中的版本号
2. 重新构建：`python -m build`
3. 上传新版本：`twine upload dist/*`

**注意**: PyPI 不允许覆盖已发布的版本，必须使用新的版本号。

## 🐛 常见问题

### 1. 上传失败：包名已存在

如果包名已被占用，需要：

- 更换包名（修改 `pyproject.toml` 中的 `name`）
- 或者联系 PyPI 管理员

### 2. 上传失败：版本号已存在

必须使用新的版本号，不能覆盖已发布的版本。

### 3. 认证失败

- 检查 API token 是否正确
- 确认 token 没有过期
- 确认用户名使用 `__token__`（不是实际用户名）

### 4. 构建失败

- 检查 `pyproject.toml` 语法是否正确
- 确认所有依赖已安装
- 检查 Python 版本是否符合要求

## 📚 相关资源

- [PyPI 官方文档](https://packaging.python.org/)
- [Twine 文档](https://twine.readthedocs.io/)
- [Python 打包用户指南](https://packaging.python.org/guides/)
- [setuptools 文档](https://setuptools.readthedocs.io/)

## 🎉 发布后

发布成功后：

1. 在 GitHub 创建 Release 标签
2. 更新项目文档
3. 通知用户新版本发布
4. 监控 PyPI 下载统计

---

**祝发布顺利！** 🚀
