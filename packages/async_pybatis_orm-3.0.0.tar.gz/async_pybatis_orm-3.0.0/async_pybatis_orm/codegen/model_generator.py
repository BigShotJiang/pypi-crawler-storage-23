#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Generate ORM models from MySQL schema metadata."""

import asyncio
import os
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import aiomysql


@dataclass
class DBConfig:
    """Database connection config used by model generator."""

    host: str
    port: int
    user: str
    password: str
    database: str
    charset: str = "utf8mb4"


@dataclass
class GenerateOptions:
    """Generation behavior options."""

    output_dir: str
    tables: Optional[List[str]] = None
    include_tables: Optional[List[str]] = None
    exclude_tables: Optional[List[str]] = None
    overwrite: bool = False
    file_layout: str = "per_table"  # per_table | single_file
    single_file_name: str = "models.py"
    base_class: str = "CommonModel"  # CommonModel | CRUDModel
    add_init: bool = True
    filename_case: str = "snake"  # snake | kebab | pascal
    class_name_case: str = "pascal"  # pascal | camel
    file_name_prefix: str = ""
    file_name_suffix: str = ""
    class_name_prefix: str = ""
    class_name_suffix: str = ""
    custom_file_namer: Optional[Callable[[str], str]] = None
    custom_class_namer: Optional[Callable[[str], str]] = None


@dataclass
class GeneratedFile:
    """Result item for one table/model file."""

    table: str
    class_name: str
    file_path: str
    skipped: bool
    reason: Optional[str] = None


@dataclass
class GenerateResult:
    """Overall generation result."""

    generated: List[GeneratedFile] = field(default_factory=list)
    skipped: List[GeneratedFile] = field(default_factory=list)


@dataclass
class _ColumnMeta:
    column_name: str
    data_type: str
    column_type: str
    is_nullable: bool
    column_default: Any
    extra: str
    ordinal_position: int


def _normalize_case(name: str) -> str:
    return name.strip().lower().replace("-", "_")


def _to_words(raw: str) -> List[str]:
    value = raw.strip()
    value = re.sub(r"[^0-9A-Za-z]+", "_", value)
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", value)
    words = [part for part in value.split("_") if part]
    if not words:
        return ["model"]
    return [w.lower() for w in words]


def _to_snake(raw: str) -> str:
    return "_".join(_to_words(raw))


def _to_kebab(raw: str) -> str:
    return "-".join(_to_words(raw))


def _to_pascal(raw: str) -> str:
    return "".join(word.capitalize() for word in _to_words(raw))


def _to_camel(raw: str) -> str:
    pascal = _to_pascal(raw)
    return pascal[0].lower() + pascal[1:] if pascal else "model"


def _valid_py_identifier(name: str, fallback: str) -> str:
    normalized = re.sub(r"[^0-9A-Za-z_]", "_", name)
    if not normalized:
        normalized = fallback
    if normalized[0].isdigit():
        normalized = f"n_{normalized}"
    return normalized


def _render_file_name(table: str, options: GenerateOptions) -> str:
    if options.custom_file_namer is not None:
        base = options.custom_file_namer(table)
    elif options.filename_case == "kebab":
        base = _to_kebab(table)
    elif options.filename_case == "pascal":
        base = _to_pascal(table)
    else:
        base = _to_snake(table)
    base = f"{options.file_name_prefix}{base}{options.file_name_suffix}"
    base = _valid_py_identifier(base.replace("-", "_"), "model")
    return f"{base}.py"


def _render_class_name(table: str, options: GenerateOptions) -> str:
    if options.custom_class_namer is not None:
        base = options.custom_class_namer(table)
    elif options.class_name_case == "camel":
        base = _to_camel(table)
    else:
        base = _to_pascal(table)
    base = f"{options.class_name_prefix}{base}{options.class_name_suffix}"
    base = _valid_py_identifier(base, "Model")
    if base[0].islower():
        base = base[0].upper() + base[1:]
    return base


def _python_type(column: _ColumnMeta) -> Tuple[str, bool]:
    dt = column.data_type.lower()
    ct = column.column_type.lower()
    if dt == "tinyint" and ct.startswith("tinyint(1"):
        return "bool", False
    if dt in {"tinyint", "smallint", "mediumint", "int", "integer", "bigint"}:
        return "int", False
    if dt in {"decimal", "numeric"}:
        return "Decimal", True
    if dt in {"float", "double", "real"}:
        return "float", False
    if dt in {"char", "varchar", "text", "tinytext", "mediumtext", "longtext"}:
        return "str", False
    if dt in {"datetime", "timestamp"}:
        return "datetime", True
    if dt == "date":
        return "date", True
    if dt == "time":
        return "time", True
    if dt == "json":
        return "Dict[str, Any]", True
    if dt in {"binary", "varbinary", "blob", "tinyblob", "mediumblob", "longblob"}:
        return "bytes", False
    return "Any", True


def _is_dynamic_time_default(column: _ColumnMeta) -> bool:
    default = (str(column.column_default) if column.column_default is not None else "").lower()
    if "current_timestamp" in default or default == "now()":
        return True
    return False


def _column_default_literal(column: _ColumnMeta, py_type: str) -> Optional[str]:
    if column.column_default is None:
        return None
    if _is_dynamic_time_default(column):
        return None

    raw = column.column_default
    dt = column.data_type.lower()

    try:
        if py_type == "bool":
            value = bool(int(raw))
            return f"default={value!r}"
        if py_type == "int":
            return f"default={int(raw)!r}"
        if py_type == "float":
            return f"default={float(raw)!r}"
        if py_type == "Decimal":
            return f'default=Decimal("{str(raw)}")'
        if py_type == "str":
            return f"default={str(raw)!r}"
        if py_type in {"bytes", "Dict[str, Any]", "Any"}:
            return None
        if dt in {"date", "datetime", "timestamp", "time"}:
            return None
    except (TypeError, ValueError):
        return None
    return None


def _field_line(
    column: _ColumnMeta,
    primary_keys: Sequence[str],
) -> Tuple[str, List[str]]:
    imports: List[str] = []
    name = _valid_py_identifier(_to_snake(column.column_name), "field")
    py_type, requires_extra_import = _python_type(column)
    if py_type in {"datetime", "date", "time", "Decimal"}:
        imports.append(py_type)
    if py_type == "Dict[str, Any]":
        imports.extend(["Dict", "Any"])
    if py_type == "Any":
        imports.append("Any")
    if requires_extra_import:
        imports.append("Optional")

    annotation = py_type
    if column.is_nullable:
        annotation = f"Optional[{py_type}]"
        imports.append("Optional")

    args = [f'column_name="{column.column_name}"']
    if column.is_nullable:
        args.append("nullable=True")
    else:
        args.append("nullable=False")

    literal = _column_default_literal(column, py_type)
    if literal:
        args.append(literal)
    elif _is_dynamic_time_default(column):
        args.append("default_factory=datetime.now")
        imports.append("datetime")

    extra = (column.extra or "").lower()
    if "on update current_timestamp" in extra:
        args.append("auto_update=True")
        if "default_factory=datetime.now" not in args:
            args.append("default_factory=datetime.now")
            imports.append("datetime")

    is_pk = column.column_name in primary_keys
    if is_pk:
        pk_args = [f'column_name="{column.column_name}"']
        if "auto_increment" in extra:
            pk_args.append("auto_increment=True")
        if column.is_nullable:
            pk_args.append("nullable=True")
        line = f"    {name}: {annotation} = PrimaryKey({', '.join(pk_args)})"
    else:
        line = f"    {name}: {annotation} = Field({', '.join(args)})"
    return line, imports


def _render_model_content(
    class_name: str,
    table_name: str,
    columns: List[_ColumnMeta],
    primary_keys: List[str],
    base_class: str,
) -> str:
    import_tokens: List[str] = ["Optional"]
    field_lines: List[str] = []

    for col in columns:
        line, tokens = _field_line(col, primary_keys)
        field_lines.append(line)
        import_tokens.extend(tokens)

    typing_parts = [token for token in ["Any", "Dict", "Optional"] if token in set(import_tokens)]
    datetime_parts = [token for token in ["date", "datetime", "time"] if token in set(import_tokens)]
    need_decimal = "Decimal" in set(import_tokens)

    lines: List[str] = [
        "#!/usr/bin/env python3",
        "# -*- coding: utf-8 -*-",
        "",
        '"""Auto-generated ORM model. DO NOT EDIT MANUALLY."""',
        "",
    ]
    if typing_parts:
        lines.append(f"from typing import {', '.join(typing_parts)}")
    if datetime_parts:
        lines.append(f"from datetime import {', '.join(datetime_parts)}")
    if need_decimal:
        lines.append("from decimal import Decimal")
    if base_class == "CommonModel":
        lines.append("from async_pybatis_orm.base.common_model import CommonModel")
    else:
        lines.append("from async_pybatis_orm.crud.crud_model import CRUDModel")
    lines.append("from async_pybatis_orm.fields import Field, PrimaryKey")
    lines.append("")
    lines.append(f"class {class_name}({base_class}):")

    primary_key = primary_keys[0] if primary_keys else columns[0].column_name
    lines.append(
        f'    __table_meta__ = {{"table_name": "{table_name}", "primary_key": "{primary_key}"}}'
    )
    lines.append("")
    lines.extend(field_lines)
    lines.append("")
    return "\n".join(lines)


async def _fetch_tables(conn: aiomysql.Connection, db_name: str) -> List[str]:
    sql = """
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = %s
      AND table_type = 'BASE TABLE'
    ORDER BY table_name
    """
    async with conn.cursor(aiomysql.DictCursor) as cursor:
        await cursor.execute(sql, (db_name,))
        rows = await cursor.fetchall()
    return [str(row["table_name"]) for row in rows]


async def _fetch_columns(conn: aiomysql.Connection, db_name: str, table: str) -> List[_ColumnMeta]:
    sql = """
    SELECT
      column_name,
      data_type,
      column_type,
      is_nullable,
      column_default,
      extra,
      ordinal_position
    FROM information_schema.columns
    WHERE table_schema = %s
      AND table_name = %s
    ORDER BY ordinal_position
    """
    async with conn.cursor(aiomysql.DictCursor) as cursor:
        await cursor.execute(sql, (db_name, table))
        rows = await cursor.fetchall()
    result: List[_ColumnMeta] = []
    for row in rows:
        result.append(
            _ColumnMeta(
                column_name=str(row["column_name"]),
                data_type=str(row["data_type"]),
                column_type=str(row["column_type"]),
                is_nullable=str(row["is_nullable"]).upper() == "YES",
                column_default=row["column_default"],
                extra=str(row["extra"] or ""),
                ordinal_position=int(row["ordinal_position"]),
            )
        )
    return result


async def _fetch_primary_keys(conn: aiomysql.Connection, db_name: str, table: str) -> List[str]:
    sql = """
    SELECT kcu.column_name
    FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
     AND tc.table_schema = kcu.table_schema
     AND tc.table_name = kcu.table_name
    WHERE tc.table_schema = %s
      AND tc.table_name = %s
      AND tc.constraint_type = 'PRIMARY KEY'
    ORDER BY kcu.ordinal_position
    """
    async with conn.cursor(aiomysql.DictCursor) as cursor:
        await cursor.execute(sql, (db_name, table))
        rows = await cursor.fetchall()
    return [str(row["column_name"]) for row in rows]


def _select_tables(all_tables: List[str], options: GenerateOptions) -> List[str]:
    if options.tables:
        selected = [t for t in options.tables if t in all_tables]
        return sorted(set(selected))
    selected = set(all_tables)
    if options.include_tables:
        selected = selected.intersection(set(options.include_tables))
    if options.exclude_tables:
        selected = selected.difference(set(options.exclude_tables))
    return sorted(selected)


def _append_init_exports(output_dir: str, exports: List[Tuple[str, str]]) -> None:
    init_path = os.path.join(output_dir, "__init__.py")
    existing = ""
    if os.path.exists(init_path):
        with open(init_path, "r", encoding="utf-8") as f:
            existing = f.read()

    lines: List[str] = []
    if not existing.strip():
        lines.extend(
            [
                "#!/usr/bin/env python3",
                "# -*- coding: utf-8 -*-",
                "",
                '"""Auto-generated model exports."""',
                "",
            ]
        )
    else:
        lines.append(existing.rstrip())

    for mod, cls in exports:
        import_line = f"from .{mod} import {cls}"
        if import_line not in existing and import_line not in lines:
            lines.append(import_line)

    content = "\n".join(lines).strip() + "\n"
    with open(init_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def _validate_options(options: GenerateOptions) -> None:
    if options.file_layout not in {"per_table", "single_file"}:
        raise ValueError("file_layout 必须是 per_table 或 single_file")
    if options.base_class not in {"CommonModel", "CRUDModel"}:
        raise ValueError("base_class 必须是 CommonModel 或 CRUDModel")
    if options.filename_case not in {"snake", "kebab", "pascal"}:
        raise ValueError("filename_case 必须是 snake/kebab/pascal")
    if options.class_name_case not in {"pascal", "camel"}:
        raise ValueError("class_name_case 必须是 pascal/camel")


async def generate_models_async(db: DBConfig, options: GenerateOptions) -> GenerateResult:
    """Generate model files from MySQL schema asynchronously."""

    _validate_options(options)
    os.makedirs(options.output_dir, exist_ok=True)
    result = GenerateResult()

    conn = await aiomysql.connect(
        host=db.host,
        port=db.port,
        user=db.user,
        password=db.password,
        db=db.database,
        charset=db.charset,
        autocommit=True,
    )
    try:
        all_tables = await _fetch_tables(conn, db.database)
        selected_tables = _select_tables(all_tables, options)

        if options.file_layout == "single_file":
            target_path = os.path.join(options.output_dir, options.single_file_name)
            if os.path.exists(target_path) and not options.overwrite:
                for table in selected_tables:
                    class_name = _render_class_name(table, options)
                    item = GeneratedFile(
                        table=table,
                        class_name=class_name,
                        file_path=target_path,
                        skipped=True,
                        reason="file_exists",
                    )
                    result.skipped.append(item)
                return result

            blocks: List[str] = []
            exports: List[Tuple[str, str]] = []
            class_name_seen: Dict[str, int] = {}
            for table in selected_tables:
                class_name = _render_class_name(table, options)
                count = class_name_seen.get(class_name, 0) + 1
                class_name_seen[class_name] = count
                if count > 1:
                    class_name = f"{class_name}_{count}"
                columns = await _fetch_columns(conn, db.database, table)
                if not columns:
                    result.skipped.append(
                        GeneratedFile(
                            table=table,
                            class_name=class_name,
                            file_path=target_path,
                            skipped=True,
                            reason="empty_table_metadata",
                        )
                    )
                    continue
                pks = await _fetch_primary_keys(conn, db.database, table)
                blocks.append(
                    _render_model_content(
                        class_name=class_name,
                        table_name=table,
                        columns=columns,
                        primary_keys=pks,
                        base_class=options.base_class,
                    )
                )
                exports.append((os.path.splitext(options.single_file_name)[0], class_name))
                result.generated.append(
                    GeneratedFile(
                        table=table,
                        class_name=class_name,
                        file_path=target_path,
                        skipped=False,
                    )
                )
            content = "\n\n".join(blocks).strip() + "\n"
            with open(target_path, "w", encoding="utf-8", newline="\n") as f:
                f.write(content)
            if options.add_init and exports:
                _append_init_exports(options.output_dir, exports)
            return result

        exports: List[Tuple[str, str]] = []
        class_name_seen = {}
        for table in selected_tables:
            class_name = _render_class_name(table, options)
            count = class_name_seen.get(class_name, 0) + 1
            class_name_seen[class_name] = count
            if count > 1:
                class_name = f"{class_name}_{count}"

            file_name = _render_file_name(table, options)
            target_path = os.path.join(options.output_dir, file_name)
            if os.path.exists(target_path) and not options.overwrite:
                result.skipped.append(
                    GeneratedFile(
                        table=table,
                        class_name=class_name,
                        file_path=target_path,
                        skipped=True,
                        reason="file_exists",
                    )
                )
                continue

            columns = await _fetch_columns(conn, db.database, table)
            if not columns:
                result.skipped.append(
                    GeneratedFile(
                        table=table,
                        class_name=class_name,
                        file_path=target_path,
                        skipped=True,
                        reason="empty_table_metadata",
                    )
                )
                continue
            pks = await _fetch_primary_keys(conn, db.database, table)
            content = _render_model_content(
                class_name=class_name,
                table_name=table,
                columns=columns,
                primary_keys=pks,
                base_class=options.base_class,
            )
            with open(target_path, "w", encoding="utf-8", newline="\n") as f:
                f.write(content)
            exports.append((os.path.splitext(file_name)[0], class_name))
            result.generated.append(
                GeneratedFile(
                    table=table,
                    class_name=class_name,
                    file_path=target_path,
                    skipped=False,
                )
            )
        if options.add_init and exports:
            _append_init_exports(options.output_dir, exports)
        return result
    finally:
        conn.close()


def generate_models(db: DBConfig, options: GenerateOptions) -> GenerateResult:
    """Generate model files from MySQL schema synchronously."""
    return asyncio.run(generate_models_async(db, options))
