# Git Bash 中使用 Conda 环境

在 Git Bash 中使用 conda 需要特殊配置，因为 Git Bash 是 POSIX shell，而 conda 的激活脚本主要是为 Windows CMD 和 PowerShell 设计的。

## 🔧 解决方案

### 方法一：初始化 Conda（推荐）

在 Git Bash 中，需要先初始化 conda：

```bash
# 初始化 conda（只需要执行一次）
eval "$(conda shell.bash hook)"

# 然后就可以正常使用 conda 命令了
conda activate async-pybatis-orm
```

**永久配置**：将初始化命令添加到 `~/.bashrc` 或 `~/.bash_profile`：

```bash
# 编辑配置文件
nano ~/.bashrc
# 或
nano ~/.bash_profile

# 添加以下内容
eval "$(conda shell.bash hook)"
```

### 方法二：使用 conda 的完整路径

```bash
# 直接使用 conda 的完整路径
D:/soft/miniconda3-py38/Scripts/conda.exe activate async-pybatis-orm

# 或者添加到 PATH 后使用
export PATH="/d/soft/miniconda3-py38/Scripts:$PATH"
conda activate async-pybatis-orm
```

### 方法三：使用 conda run（不需要激活环境）

```bash
# 直接在指定环境中运行命令
conda run -n async-pybatis-orm python your_script.py

# 或者使用完整路径
D:/soft/miniconda3-py38/Scripts/conda.exe run -n async-pybatis-orm python your_script.py
```

### 方法四：直接使用环境中的 Python

```bash
# 直接使用虚拟环境中的 Python 解释器
/d/soft/miniconda3-py38/envs/async-pybatis-orm/python.exe your_script.py

# 或者添加到 PATH
export PATH="/d/soft/miniconda3-py38/envs/async-pybatis-orm/Scripts:$PATH"
python your_script.py
```

## 🚀 快速设置脚本

创建一个 `setup_gitbash.sh` 脚本：

```bash
#!/bin/bash
# Git Bash Conda 初始化脚本

# 检测 conda 安装路径
CONDA_BASE=$(conda info --base 2>/dev/null || echo "D:/soft/miniconda3-py38")

if [ -f "$CONDA_BASE/etc/profile.d/conda.sh" ]; then
    . "$CONDA_BASE/etc/profile.d/conda.sh"
    echo "✅ Conda 已初始化"
else
    echo "❌ 未找到 conda.sh，尝试使用 conda shell.bash hook"
    eval "$(conda shell.bash hook)"
fi

# 激活环境（如果指定）
if [ -n "$1" ]; then
    conda activate "$1"
    echo "✅ 已激活环境: $1"
fi
```

使用方法：

```bash
# 初始化 conda
source setup_gitbash.sh

# 初始化并激活环境
source setup_gitbash.sh async-pybatis-orm
```

## 📝 更新发布脚本

更新 `scripts/publish.sh` 以支持 Git Bash：

```bash
#!/bin/bash
# PyPI 发布脚本（支持 Git Bash）

set -e

# 初始化 conda（如果在 Git Bash 中）
if [ -n "$MSYSTEM" ] || [ -n "$MSYSTEM_PREFIX" ]; then
    # 检测 conda
    if command -v conda &> /dev/null; then
        eval "$(conda shell.bash hook)" 2>/dev/null || true
    fi
fi

# 其余代码保持不变...
```

## 🔍 常见问题

### 1. 错误：`conda: command not found`

**解决方案**：

```bash
# 添加 conda 到 PATH
export PATH="/d/soft/miniconda3-py38/Scripts:$PATH"
export PATH="/d/soft/miniconda3-py38:$PATH"
```

### 2. 错误：`UnicodeDecodeError` 或编码问题

**解决方案**：

```bash
# 设置正确的编码
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
```

### 3. 错误：`cygpath` 相关错误

**解决方案**：使用 `conda run` 而不是 `conda activate`：

```bash
conda run -n async-pybatis-orm python -m build
```

### 4. 路径转换问题

Git Bash 使用 Unix 风格路径，需要转换：

```bash
# Windows 路径: D:\soft\miniconda3-py38
# Git Bash 路径: /d/soft/miniconda3-py38 或 D:/soft/miniconda3-py38
```

## 💡 推荐工作流程

### 选项 A: 使用 conda run（最简单）

```bash
# 不需要激活环境，直接运行
conda run -n async-pybatis-orm python -m build
conda run -n async-pybatis-orm python -m twine upload dist/*
```

### 选项 B: 初始化后使用（最灵活）

```bash
# 在 ~/.bashrc 中添加
eval "$(conda shell.bash hook)"

# 每次打开 Git Bash 后
conda activate async-pybatis-orm
python -m build
```

### 选项 C: 使用 Windows CMD 或 PowerShell

如果 Git Bash 问题太多，可以直接使用：

```cmd
REM Windows CMD
conda activate async-pybatis-orm
python -m build
```

```powershell
# PowerShell
conda activate async-pybatis-orm
python -m build
```

## 🎯 针对发布脚本的建议

由于 Git Bash 中 conda 激活可能有问题，建议：

1. **使用 conda run**：修改脚本使用 `conda run` 而不是 `conda activate`
2. **直接使用 Python**：如果环境已安装，直接使用环境中的 Python
3. **使用 Windows 脚本**：在 Windows 上优先使用 `publish.bat`

---

**提示**：如果经常遇到问题，建议在 Windows CMD 或 PowerShell 中执行发布操作，这些环境对 conda 的支持更好。
