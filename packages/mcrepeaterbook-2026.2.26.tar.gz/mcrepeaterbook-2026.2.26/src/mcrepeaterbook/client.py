"""Async HTTP client for the RepeaterBook API.

Handles authentication (User-Agent + future API key), response caching
with bounded size, rate-limit backoff with retry, and graceful error
handling for non-JSON responses. Uses httpx (bundled with FastMCP).
"""

import asyncio
import json
import sys
import time
import urllib.parse

import httpx
from pydantic import ValidationError

from mcrepeaterbook.models import RepeaterBookResponse

MAX_CACHE_ENTRIES = 128
MAX_RETRIES = 3
RETRY_BASE_DELAY = 2.0  # seconds, doubled each attempt


class RepeaterBookClient:
    """Async wrapper around RepeaterBook's JSON export API."""

    BASE_URL = "https://www.repeaterbook.com/api"
    NA_ENDPOINT = "export.php"
    ROW_ENDPOINT = "exportROW.php"

    def __init__(
        self,
        contact_email: str = "",
        api_key: str | None = None,
        app_name: str = "mcrepeaterbook",
        cache_ttl: int = 3600,
    ):
        self.contact_email = contact_email
        self.api_key = api_key
        self.app_name = app_name
        self.cache_ttl = cache_ttl
        self._cache: dict[str, tuple[float, RepeaterBookResponse]] = {}
        self._http: httpx.AsyncClient | None = None

    async def _get_http(self) -> httpx.AsyncClient:
        """Lazily create a persistent httpx client for connection reuse."""
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(follow_redirects=True, timeout=30.0)
        return self._http

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        if self._http is not None and not self._http.is_closed:
            await self._http.aclose()
            self._http = None

    @property
    def _headers(self) -> dict[str, str]:
        headers = {"User-Agent": f"({self.app_name}, {self.contact_email})"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _cache_key(self, endpoint: str, params: dict[str, str]) -> str:
        return f"{endpoint}?{urllib.parse.urlencode(sorted(params.items()))}"

    def _sweep_cache(self) -> None:
        """Remove expired entries and enforce size limit."""
        now = time.time()
        expired = [k for k, (ts, _) in self._cache.items() if now - ts >= self.cache_ttl]
        for k in expired:
            del self._cache[k]
        # If still over limit, evict oldest entries
        if len(self._cache) > MAX_CACHE_ENTRIES:
            by_age = sorted(self._cache.items(), key=lambda kv: kv[1][0])
            for k, _ in by_age[: len(self._cache) - MAX_CACHE_ENTRIES]:
                del self._cache[k]

    def _get_cached(self, key: str) -> RepeaterBookResponse | None:
        if key in self._cache:
            ts, data = self._cache[key]
            if time.time() - ts < self.cache_ttl:
                return data
            del self._cache[key]
        return None

    async def _request(self, endpoint: str, params: dict[str, str]) -> RepeaterBookResponse:
        """Execute API request with caching, retry, and error handling."""
        # Strip empty/None values
        clean_params = {k: v for k, v in params.items() if v}

        cache_key = self._cache_key(endpoint, clean_params)
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        url = f"{self.BASE_URL}/{endpoint}"
        http = await self._get_http()
        last_error: Exception | None = None

        for attempt in range(MAX_RETRIES):
            try:
                resp = await http.get(url, params=clean_params, headers=self._headers)

                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", 30))
                    delay = min(retry_after, 60)
                    print(
                        f"RepeaterBook rate limit (429) — waiting {delay}s "
                        f"(attempt {attempt + 1}/{MAX_RETRIES})",
                        file=sys.stderr,
                    )
                    await asyncio.sleep(delay)
                    continue

                if resp.status_code >= 500:
                    delay = RETRY_BASE_DELAY * (2**attempt)
                    print(
                        f"RepeaterBook server error ({resp.status_code}) — "
                        f"retrying in {delay:.0f}s (attempt {attempt + 1}/{MAX_RETRIES})",
                        file=sys.stderr,
                    )
                    await asyncio.sleep(delay)
                    continue

                resp.raise_for_status()

                try:
                    raw = resp.json()
                except json.JSONDecodeError as exc:
                    raise RuntimeError(
                        f"RepeaterBook returned non-JSON response (HTTP {resp.status_code}). "
                        "The API may be temporarily unavailable."
                    ) from exc

                try:
                    data = RepeaterBookResponse.model_validate(raw)
                except ValidationError as exc:
                    raise RuntimeError(
                        f"RepeaterBook response has unexpected structure: {exc.error_count()} "
                        "validation errors. The API format may have changed."
                    ) from exc

                self._sweep_cache()
                self._cache[cache_key] = (time.time(), data)
                return data

            except (httpx.ConnectError, httpx.TimeoutException) as exc:
                last_error = exc
                delay = RETRY_BASE_DELAY * (2**attempt)
                print(
                    f"Network error ({type(exc).__name__}) — "
                    f"retrying in {delay:.0f}s (attempt {attempt + 1}/{MAX_RETRIES})",
                    file=sys.stderr,
                )
                await asyncio.sleep(delay)

        raise RuntimeError(
            "RepeaterBook API unreachable after retries. Check your network connection."
        ) from last_error

    async def search_na(self, **params: str) -> RepeaterBookResponse:
        """Search North American repeaters (US, Canada, Mexico)."""
        return await self._request(self.NA_ENDPOINT, params)

    async def search_row(self, **params: str) -> RepeaterBookResponse:
        """Search Rest-of-World repeaters."""
        return await self._request(self.ROW_ENDPOINT, params)
