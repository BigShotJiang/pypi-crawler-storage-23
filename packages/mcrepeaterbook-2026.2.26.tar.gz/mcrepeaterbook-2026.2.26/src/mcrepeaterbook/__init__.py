"""MCP server for querying amateur radio repeaters from RepeaterBook.com."""

__version__ = "2026.2.26"
