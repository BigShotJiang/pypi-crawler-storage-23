"""Persistent configuration for mcrepeaterbook.

Stores RepeaterBook credentials in ~/.config/mcrepeaterbook/config.json.
Loaded at startup, updated via MCP elicitation on first use if missing.
"""

import json
from pathlib import Path

from pydantic import BaseModel, Field

CONFIG_DIR = Path.home() / ".config" / "mcrepeaterbook"
CONFIG_FILE = CONFIG_DIR / "config.json"


class RepeaterBookCredentials(BaseModel):
    """Elicitation schema — what we ask the user for."""

    email: str = Field(description="Your RepeaterBook.com account email address")
    api_key: str = Field(
        default="",
        description="RepeaterBook API key (optional now, required after March 2026)",
    )


def load_config() -> dict[str, str]:
    """Load saved config, returning empty dict if none exists."""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(email: str, api_key: str = "") -> None:
    """Persist credentials to config file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config: dict[str, str] = {"email": email}
    if api_key:
        config["api_key"] = api_key
    CONFIG_FILE.write_text(json.dumps(config, indent=2) + "\n")
