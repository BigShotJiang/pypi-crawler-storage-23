"""Pydantic models for RepeaterBook API responses."""

from __future__ import annotations

from pydantic import BaseModel, Field, model_validator


class Repeater(BaseModel):
    """A single repeater record from RepeaterBook."""

    @model_validator(mode="before")
    @classmethod
    def coerce_to_strings(cls, data: dict) -> dict:
        """The API returns some fields as ints (Rptr ID, Precise, State ID).
        Coerce everything to str so the model stays uniform."""
        if isinstance(data, dict):
            return {k: (str(v) if isinstance(v, (int, float)) else v) for k, v in data.items()}
        return data

    state_id: str = Field(default="", alias="State ID")
    rptr_id: str = Field(default="", alias="Rptr ID")
    frequency: str = Field(default="", alias="Frequency")
    input_freq: str = Field(default="", alias="Input Freq")
    pl_tone: str = Field(default="", alias="PL")
    tsq: str = Field(default="", alias="TSQ")
    nearest_city: str = Field(default="", alias="Nearest City")
    landmark: str = Field(default="", alias="Landmark")
    county: str = Field(default="", alias="County")
    state: str = Field(default="", alias="State")
    country: str = Field(default="", alias="Country")
    latitude: str = Field(default="", alias="Lat")
    longitude: str = Field(default="", alias="Long")
    precise: str = Field(default="", alias="Precise")
    callsign: str = Field(default="", alias="Callsign")
    use: str = Field(default="", alias="Use")
    operational_status: str = Field(default="", alias="Operational Status")
    ares: str = Field(default="", alias="ARES")
    races: str = Field(default="", alias="RACES")
    skywarn: str = Field(default="", alias="SKYWARN")
    canwarn: str = Field(default="", alias="CANWARN")
    allstar_node: str = Field(default="", alias="AllStar Node")
    echolink_node: str = Field(default="", alias="EchoLink Node")
    irlp_node: str = Field(default="", alias="IRLP Node")
    wires_node: str = Field(default="", alias="Wires Node")
    fm_analog: str = Field(default="", alias="FM Analog")
    dmr: str = Field(default="", alias="DMR")
    dmr_color_code: str = Field(default="", alias="DMR Color Code")
    dmr_id: str = Field(default="", alias="DMR ID")
    dstar: str = Field(default="", alias="D-Star")
    nxdn: str = Field(default="", alias="NXDN")
    apco_p25: str = Field(default="", alias="APCO P-25")
    p25_nac: str = Field(default="", alias="P-25 NAC")
    m17: str = Field(default="", alias="M17")
    m17_can: str = Field(default="", alias="M17 CAN")
    tetra: str = Field(default="", alias="TETRA")
    tetra_mcc: str = Field(default="", alias="TETRA MCC")
    tetra_mnc: str = Field(default="", alias="TETRA MNC")
    system_fusion: str = Field(default="", alias="System Fusion")
    last_update: str = Field(default="", alias="Last Update")

    model_config = {"populate_by_name": True}

    @property
    def lat_float(self) -> float | None:
        try:
            return float(self.latitude)
        except (ValueError, TypeError):
            return None

    @property
    def lon_float(self) -> float | None:
        try:
            return float(self.longitude)
        except (ValueError, TypeError):
            return None

    @property
    def is_operational(self) -> bool:
        """Assume operational unless explicitly marked off-air.

        RepeaterBook uses values like "On-air", "Off-air", "Testing", etc.
        Negative matching is forward-compatible with new statuses.
        """
        return self.operational_status.strip().lower() not in ("off-air", "off air")

    @property
    def active_modes(self) -> list[str]:
        modes = []
        if self.fm_analog and self.fm_analog.strip().lower() == "yes":
            modes.append("FM Analog")
        if self.dmr and self.dmr.strip().lower() == "yes":
            modes.append(f"DMR CC{self.dmr_color_code}" if self.dmr_color_code else "DMR")
        if self.dstar and self.dstar.strip().lower() == "yes":
            modes.append("D-STAR")
        if self.system_fusion and self.system_fusion.strip().lower() == "yes":
            modes.append("System Fusion")
        if self.apco_p25 and self.apco_p25.strip().lower() == "yes":
            nac = f" NAC {self.p25_nac}" if self.p25_nac else ""
            modes.append(f"P-25{nac}")
        if self.nxdn and self.nxdn.strip().lower() == "yes":
            modes.append("NXDN")
        if self.m17 and self.m17.strip().lower() == "yes":
            modes.append("M17")
        if self.tetra and self.tetra.strip().lower() == "yes":
            modes.append("TETRA")
        return modes

    @property
    def linked_systems(self) -> list[str]:
        links = []
        if self.echolink_node:
            links.append(f"EchoLink:{self.echolink_node}")
        if self.allstar_node:
            links.append(f"AllStar:{self.allstar_node}")
        if self.irlp_node:
            links.append(f"IRLP:{self.irlp_node}")
        if self.wires_node:
            links.append(f"Wires-X:{self.wires_node}")
        return links

    @property
    def has_emergency_affiliation(self) -> bool:
        yes_vals = ("yes", "y", "true", "1")
        return (
            self.ares.strip().lower() in yes_vals
            or self.races.strip().lower() in yes_vals
            or self.skywarn.strip().lower() in yes_vals
            or self.canwarn.strip().lower() in yes_vals
        )

    def to_summary(self, distance_mi: float | None = None) -> dict:
        """Compact dict suitable for LLM consumption."""
        offset = ""
        try:
            freq = float(self.frequency)
            inp = float(self.input_freq)
            diff = inp - freq
            if diff != 0:
                offset = f"{diff:+.4f}".rstrip("0").rstrip(".")
        except (ValueError, TypeError):
            pass

        summary: dict = {
            "callsign": self.callsign,
            "frequency": self.frequency,
            "offset": offset,
            "city": self.nearest_city,
            "state": self.state,
            "county": self.county,
            "use": self.use,
            "modes": self.active_modes,
        }
        if self.pl_tone:
            summary["pl_tone"] = self.pl_tone
        if self.tsq:
            summary["tsq"] = self.tsq
        if self.linked_systems:
            summary["linked"] = self.linked_systems
        if self.has_emergency_affiliation:
            emg = []
            yes_vals = ("yes", "y", "true", "1")
            if self.ares.strip().lower() in yes_vals:
                emg.append("ARES")
            if self.races.strip().lower() in yes_vals:
                emg.append("RACES")
            if self.skywarn.strip().lower() in yes_vals:
                emg.append("SKYWARN")
            if self.canwarn.strip().lower() in yes_vals:
                emg.append("CANWARN")
            summary["emergency"] = emg
        if self.lat_float is not None and self.lon_float is not None:
            summary["latitude"] = self.lat_float
            summary["longitude"] = self.lon_float
        if distance_mi is not None:
            summary["distance_miles"] = round(distance_mi, 1)
        return summary


class RepeaterBookResponse(BaseModel):
    """Top-level API response wrapper."""

    count: int = 0
    results: list[Repeater] = Field(default_factory=list)
