"""Reference data: FIPS state codes, ham bands, and digital modes."""

# US State/Territory FIPS codes used by RepeaterBook's state_id parameter.
# Maps lowercase state name AND abbreviation to FIPS code string.
STATE_FIPS: dict[str, str] = {
    # Alabama
    "alabama": "01",
    "al": "01",
    # Alaska
    "alaska": "02",
    "ak": "02",
    # Arizona
    "arizona": "04",
    "az": "04",
    # Arkansas
    "arkansas": "05",
    "ar": "05",
    # California
    "california": "06",
    "ca": "06",
    # Colorado
    "colorado": "08",
    "co": "08",
    # Connecticut
    "connecticut": "09",
    "ct": "09",
    # Delaware
    "delaware": "10",
    "de": "10",
    # District of Columbia
    "district of columbia": "11",
    "dc": "11",
    # Florida
    "florida": "12",
    "fl": "12",
    # Georgia
    "georgia": "13",
    "ga": "13",
    # Hawaii
    "hawaii": "15",
    "hi": "15",
    # Idaho
    "idaho": "16",
    "id": "16",
    # Illinois
    "illinois": "17",
    "il": "17",
    # Indiana
    "indiana": "18",
    "in": "18",
    # Iowa
    "iowa": "19",
    "ia": "19",
    # Kansas
    "kansas": "20",
    "ks": "20",
    # Kentucky
    "kentucky": "21",
    "ky": "21",
    # Louisiana
    "louisiana": "22",
    "la": "22",
    # Maine
    "maine": "23",
    "me": "23",
    # Maryland
    "maryland": "24",
    "md": "24",
    # Massachusetts
    "massachusetts": "25",
    "ma": "25",
    # Michigan
    "michigan": "26",
    "mi": "26",
    # Minnesota
    "minnesota": "27",
    "mn": "27",
    # Mississippi
    "mississippi": "28",
    "ms": "28",
    # Missouri
    "missouri": "29",
    "mo": "29",
    # Montana
    "montana": "30",
    "mt": "30",
    # Nebraska
    "nebraska": "31",
    "ne": "31",
    # Nevada
    "nevada": "32",
    "nv": "32",
    # New Hampshire
    "new hampshire": "33",
    "nh": "33",
    # New Jersey
    "new jersey": "34",
    "nj": "34",
    # New Mexico
    "new mexico": "35",
    "nm": "35",
    # New York
    "new york": "36",
    "ny": "36",
    # North Carolina
    "north carolina": "37",
    "nc": "37",
    # North Dakota
    "north dakota": "38",
    "nd": "38",
    # Ohio
    "ohio": "39",
    "oh": "39",
    # Oklahoma
    "oklahoma": "40",
    "ok": "40",
    # Oregon
    "oregon": "41",
    "or": "41",
    # Pennsylvania
    "pennsylvania": "42",
    "pa": "42",
    # Rhode Island
    "rhode island": "44",
    "ri": "44",
    # South Carolina
    "south carolina": "45",
    "sc": "45",
    # South Dakota
    "south dakota": "46",
    "sd": "46",
    # Tennessee
    "tennessee": "47",
    "tn": "47",
    # Texas
    "texas": "48",
    "tx": "48",
    # Utah
    "utah": "49",
    "ut": "49",
    # Vermont
    "vermont": "50",
    "vt": "50",
    # Virginia
    "virginia": "51",
    "va": "51",
    # Washington
    "washington": "53",
    "wa": "53",
    # West Virginia
    "west virginia": "54",
    "wv": "54",
    # Wisconsin
    "wisconsin": "55",
    "wi": "55",
    # Wyoming
    "wyoming": "56",
    "wy": "56",
    # US Territories
    "american samoa": "60",
    "as": "60",
    "guam": "66",
    "gu": "66",
    "northern mariana islands": "69",
    "mp": "69",
    "puerto rico": "72",
    "pr": "72",
    "us virgin islands": "78",
    "virgin islands": "78",
    "vi": "78",
}

# Reverse lookup: FIPS code -> (full name, abbreviation)
FIPS_TO_STATE: dict[str, tuple[str, str]] = {
    "01": ("Alabama", "AL"),
    "02": ("Alaska", "AK"),
    "04": ("Arizona", "AZ"),
    "05": ("Arkansas", "AR"),
    "06": ("California", "CA"),
    "08": ("Colorado", "CO"),
    "09": ("Connecticut", "CT"),
    "10": ("Delaware", "DE"),
    "11": ("District of Columbia", "DC"),
    "12": ("Florida", "FL"),
    "13": ("Georgia", "GA"),
    "15": ("Hawaii", "HI"),
    "16": ("Idaho", "ID"),
    "17": ("Illinois", "IL"),
    "18": ("Indiana", "IN"),
    "19": ("Iowa", "IA"),
    "20": ("Kansas", "KS"),
    "21": ("Kentucky", "KY"),
    "22": ("Louisiana", "LA"),
    "23": ("Maine", "ME"),
    "24": ("Maryland", "MD"),
    "25": ("Massachusetts", "MA"),
    "26": ("Michigan", "MI"),
    "27": ("Minnesota", "MN"),
    "28": ("Mississippi", "MS"),
    "29": ("Missouri", "MO"),
    "30": ("Montana", "MT"),
    "31": ("Nebraska", "NE"),
    "32": ("Nevada", "NV"),
    "33": ("New Hampshire", "NH"),
    "34": ("New Jersey", "NJ"),
    "35": ("New Mexico", "NM"),
    "36": ("New York", "NY"),
    "37": ("North Carolina", "NC"),
    "38": ("North Dakota", "ND"),
    "39": ("Ohio", "OH"),
    "40": ("Oklahoma", "OK"),
    "41": ("Oregon", "OR"),
    "42": ("Pennsylvania", "PA"),
    "44": ("Rhode Island", "RI"),
    "45": ("South Carolina", "SC"),
    "46": ("South Dakota", "SD"),
    "47": ("Tennessee", "TN"),
    "48": ("Texas", "TX"),
    "49": ("Utah", "UT"),
    "50": ("Vermont", "VT"),
    "51": ("Virginia", "VA"),
    "53": ("Washington", "WA"),
    "54": ("West Virginia", "WV"),
    "55": ("Wisconsin", "WI"),
    "56": ("Wyoming", "WY"),
    # US Territories
    "60": ("American Samoa", "AS"),
    "66": ("Guam", "GU"),
    "69": ("Northern Mariana Islands", "MP"),
    "72": ("Puerto Rico", "PR"),
    "78": ("US Virgin Islands", "VI"),
}

# Amateur radio bands commonly found on RepeaterBook
BANDS: dict[str, dict[str, str]] = {
    "6m": {"range": "50-54 MHz", "repeater_sub": "51-54 MHz"},
    "2m": {"range": "144-148 MHz", "repeater_sub": "145.1-145.5, 146.6-147.4 MHz"},
    "1.25m": {"range": "222-225 MHz", "repeater_sub": "223.85-224.98 MHz"},
    "70cm": {"range": "420-450 MHz", "repeater_sub": "442-445 MHz (varies by region)"},
    "33cm": {"range": "902-928 MHz", "repeater_sub": "927-928 MHz"},
    "23cm": {"range": "1240-1300 MHz", "repeater_sub": "1282-1288 MHz"},
}

# Digital modes tracked by RepeaterBook
MODES: dict[str, str] = {
    "analog": "FM Analog — standard voice repeater",
    "dmr": "DMR (Digital Mobile Radio) — TDMA digital voice, uses color codes and talkgroups",
    "dstar": "D-STAR — Icom digital voice protocol, uses reflectors and gateways",
    "fusion": "System Fusion (C4FM) — Yaesu digital voice, supports Wires-X",
    "p25": "APCO P-25 — public safety digital standard, uses NAC codes",
    "nxdn": "NXDN — Kenwood/Icom digital narrowband protocol",
    "m17": "M17 — open-source digital voice protocol",
    "tetra": "TETRA — trunked radio standard (rare in amateur use)",
}


def resolve_state(state_input: str) -> str | None:
    """Resolve a state name, abbreviation, or FIPS code to a FIPS code.

    Returns the FIPS code string, or None if not recognized.
    """
    cleaned = state_input.strip()
    # Already a FIPS code?
    if cleaned in FIPS_TO_STATE:
        return cleaned
    # Zero-padded single digit?
    if cleaned.isdigit() and cleaned.zfill(2) in FIPS_TO_STATE:
        return cleaned.zfill(2)
    # Name or abbreviation lookup
    return STATE_FIPS.get(cleaned.lower())
