"""mcrepeaterbook — MCP server for RepeaterBook.com amateur radio repeater data.

Provides tools to search repeaters by location, callsign, mode, and proximity.
Data sourced from RepeaterBook.com (personal non-commercial use).
"""

import json
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastmcp import Context, FastMCP
from fastmcp.server.elicitation import AcceptedElicitation
from starlette.requests import Request
from starlette.responses import JSONResponse

from mcrepeaterbook.client import RepeaterBookClient
from mcrepeaterbook.config import RepeaterBookCredentials, load_config
from mcrepeaterbook.constants import BANDS, FIPS_TO_STATE, MODES, resolve_state
from mcrepeaterbook.geo import haversine_miles
from mcrepeaterbook.models import Repeater

load_dotenv()


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[dict]:
    cache_ttl = int(os.getenv("REPEATERBOOK_CACHE_TTL", "3600"))

    # Priority: env vars > config file > empty (will elicit later)
    email = os.getenv("REPEATERBOOK_EMAIL", "")
    api_key = os.getenv("REPEATERBOOK_API_KEY", "")

    if not email:
        cfg = load_config()
        email = cfg.get("email", "")
        api_key = api_key or cfg.get("api_key", "")

    if not email:
        print(
            "No credentials found — will ask via MCP elicitation on first tool call.",
            file=sys.stderr,
        )

    client = RepeaterBookClient(
        contact_email=email,
        api_key=api_key or None,
        cache_ttl=cache_ttl,
    )
    try:
        yield {"client": client}
    finally:
        await client.aclose()


mcp = FastMCP(
    "mcrepeaterbook",
    instructions=(
        "Query amateur radio repeaters from RepeaterBook.com. "
        "Use search_repeaters for North American lookups, "
        "search_repeaters_worldwide for international, "
        "find_nearby for proximity-based search, and "
        "find_emergency_repeaters for ARES/RACES/SKYWARN-linked repeaters. "
        "Always attribute data to RepeaterBook.com."
    ),
    lifespan=lifespan,
)


@mcp.custom_route("/health", methods=["GET"])
async def health(request: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "server": "mcrepeaterbook"})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_CRED_FALLBACK_MSG = (
    "RepeaterBook credentials required. Set REPEATERBOOK_EMAIL env var, "
    'or create ~/.config/mcrepeaterbook/config.json with {"email": "you@example.com"}'
)


async def _ensure_client(ctx: Context) -> RepeaterBookClient:
    """Get the API client, eliciting credentials from the user if needed.

    Resolution order: env var > config file > MCP elicitation.
    Elicited credentials are session-scoped only (not persisted to disk).
    """
    client: RepeaterBookClient = ctx.request_context.lifespan_context["client"]

    if client.contact_email:
        return client

    # Try elicitation — not all MCP clients support this
    try:
        result = await ctx.elicit(
            "mcrepeaterbook needs your RepeaterBook.com account email to access the API.\n"
            "Sign up free at https://www.repeaterbook.com if you don't have an account.\n"
            "API keys become mandatory after March 2026 — you can add one now or later.",
            RepeaterBookCredentials,
        )
    except Exception:
        # Client doesn't support elicitation
        raise RuntimeError(  # noqa: B904
            f"This MCP client does not support elicitation. {_CRED_FALLBACK_MSG}"
        )

    if isinstance(result, AcceptedElicitation):
        creds: RepeaterBookCredentials = result.data
        client.contact_email = creds.email
        if creds.api_key:
            client.api_key = creds.api_key
        await ctx.info("Credentials set for this session (not persisted to disk).")
        return client

    # Declined or cancelled
    raise RuntimeError(_CRED_FALLBACK_MSG)


def _build_result(
    repeaters: list[Repeater],
    limit: int = 50,
    distances: dict[str, float] | None = None,
) -> dict:
    """Build a result dict from a repeater list (no serialization)."""
    summaries = []
    for rptr in repeaters[:limit]:
        dist = distances.get(rptr.rptr_id) if distances else None
        summaries.append(rptr.to_summary(distance_mi=dist))

    result: dict = {
        "source": "RepeaterBook.com",
        "count": len(summaries),
        "total_matched": len(repeaters),
        "results": summaries,
    }
    if len(repeaters) > limit:
        result["note"] = (
            f"Showing {limit} of {len(repeaters)} results. "
            "Narrow your search for more specific results."
        )
    return result


def _format_results(
    repeaters: list[Repeater],
    limit: int = 50,
    distances: dict[str, float] | None = None,
) -> str:
    """Serialize repeater list to JSON string for LLM consumption."""
    return json.dumps(_build_result(repeaters, limit, distances), indent=2)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
async def search_repeaters(
    ctx: Context,
    state: str = "",
    city: str = "",
    callsign: str = "",
    frequency: str = "",
    mode: str = "",
    county: str = "",
    landmark: str = "",
    country: str = "United States",
) -> str:
    """Search amateur radio repeaters in North America (US, Canada, Mexico).

    Queries RepeaterBook's database and returns matching repeaters with frequency,
    tone, location, modes, and linking info.

    Use '%' as wildcard in callsign (e.g. 'K4%' matches all K4 calls).

    Args:
        state: State or province — name ('Oregon'), abbreviation ('OR'), or FIPS code ('41').
        city: City name to filter by.
        callsign: Repeater callsign. Supports '%' wildcards.
        frequency: Frequency in MHz (e.g. '146.940').
        mode: Filter by mode — 'analog', 'dmr', 'dstar', 'nxdn', 'p25', 'tetra'.
        county: County name.
        landmark: Geographic landmark near the repeater.
        country: Country — 'United States' (default), 'Canada', or 'Mexico'.
    """
    client = await _ensure_client(ctx)

    params: dict[str, str] = {}
    if state:
        fips = resolve_state(state)
        if fips:
            params["state_id"] = fips
        else:
            await ctx.warning(
                f"Could not resolve '{state}' to a known US state/territory. "
                "Passing raw value — results may be empty."
            )
            params["state_id"] = state
    if city:
        params["city"] = city
    if callsign:
        params["callsign"] = callsign
    if frequency:
        params["frequency"] = frequency
    if mode:
        params["mode"] = mode
    if county:
        params["county"] = county
    if landmark:
        params["landmark"] = landmark
    if country:
        params["country"] = country

    data = await client.search_na(**params)
    operational = [r for r in data.results if r.is_operational]
    return _format_results(operational)


@mcp.tool()
async def search_repeaters_worldwide(
    ctx: Context,
    country: str = "",
    callsign: str = "",
    city: str = "",
    frequency: str = "",
    mode: str = "",
    region: str = "",
) -> str:
    """Search amateur radio repeaters outside North America (Rest of World).

    Covers Europe, Asia, Oceania, South America, Africa, etc.

    Args:
        country: Country name (required for meaningful results).
        callsign: Repeater callsign. Supports '%' wildcards.
        city: City name.
        frequency: Frequency in MHz.
        mode: Filter by mode — 'analog', 'dmr', 'dstar', 'nxdn', 'p25', 'tetra'.
        region: Region or administrative area within the country.
    """
    client = await _ensure_client(ctx)

    params: dict[str, str] = {}
    if country:
        params["country"] = country
    if callsign:
        params["callsign"] = callsign
    if city:
        params["city"] = city
    if frequency:
        params["frequency"] = frequency
    if mode:
        params["mode"] = mode
    if region:
        params["region"] = region

    data = await client.search_row(**params)
    operational = [r for r in data.results if r.is_operational]
    return _format_results(operational)


@mcp.tool()
async def find_nearby(
    ctx: Context,
    latitude: float,
    longitude: float,
    state: str,
    radius_miles: float = 25.0,
    mode: str = "",
    limit: int = 25,
) -> str:
    """Find repeaters near a geographic coordinate, sorted by distance.

    This is the proximity search — RepeaterBook's API doesn't support geo queries
    natively, so this fetches state-level data and filters by Haversine distance.

    The calling LLM should determine the US state from the coordinates
    (e.g. 45.5/-122.7 is Oregon). For locations near state borders, call this
    tool once per adjacent state and merge results.

    Args:
        latitude: Latitude in decimal degrees (e.g. 45.5155).
        longitude: Longitude in decimal degrees (e.g. -122.6793).
        state: US state — name, abbreviation, or FIPS code. Required.
        radius_miles: Search radius in miles (default 25, max 200).
        mode: Optional mode filter — 'analog', 'dmr', 'dstar', 'nxdn', 'p25', 'tetra'.
        limit: Max results to return (default 25).
    """
    client = await _ensure_client(ctx)

    if not (-90.0 <= latitude <= 90.0):
        return json.dumps({"error": f"Invalid latitude {latitude}: must be between -90 and 90."})
    if not (-180.0 <= longitude <= 180.0):
        return json.dumps(
            {"error": f"Invalid longitude {longitude}: must be between -180 and 180."}
        )

    radius_miles = min(radius_miles, 200.0)
    limit = min(limit, 100)

    fips = resolve_state(state)
    if not fips:
        return json.dumps({"error": f"Could not resolve state '{state}' to FIPS code."})

    params: dict[str, str] = {"state_id": fips, "country": "United States"}
    if mode:
        params["mode"] = mode

    data = await client.search_na(**params)

    # Compute distances and filter
    nearby: list[tuple[Repeater, float]] = []
    for rptr in data.results:
        if not rptr.is_operational:
            continue
        lat = rptr.lat_float
        lon = rptr.lon_float
        if lat is None or lon is None:
            continue
        dist = haversine_miles(latitude, longitude, lat, lon)
        if dist <= radius_miles:
            nearby.append((rptr, dist))

    nearby.sort(key=lambda x: x[1])
    nearby = nearby[:limit]

    distances = {rptr.rptr_id: dist for rptr, dist in nearby}
    repeaters = [rptr for rptr, _ in nearby]

    result = _build_result(repeaters, limit=limit, distances=distances)
    state_name, state_abbr = FIPS_TO_STATE.get(fips, (state, ""))
    result["search"] = {
        "center": {"latitude": latitude, "longitude": longitude},
        "radius_miles": radius_miles,
        "state": f"{state_name} ({state_abbr})" if state_abbr else state,
    }
    return json.dumps(result, indent=2)


@mcp.tool()
async def find_emergency_repeaters(
    ctx: Context,
    state: str,
    country: str = "United States",
) -> str:
    """Find repeaters affiliated with ARES, RACES, SKYWARN, or CANWARN.

    Useful for emergency communications (EMCOMM) planning. Returns only
    repeaters that have at least one emergency service affiliation.

    Args:
        state: US state — name, abbreviation, or FIPS code.
        country: Country (default 'United States').
    """
    client = await _ensure_client(ctx)

    params: dict[str, str] = {"country": country}
    fips = resolve_state(state)
    if fips:
        params["state_id"] = fips
    else:
        await ctx.warning(
            f"Could not resolve '{state}' to a known US state/territory. "
            "Passing raw value — results may be empty."
        )
        params["state_id"] = state

    data = await client.search_na(**params)
    emcomm = [r for r in data.results if r.is_operational and r.has_emergency_affiliation]
    return _format_results(emcomm)


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------


@mcp.resource("repeaterbook://reference/states")
def resource_states() -> str:
    """US state FIPS codes for the RepeaterBook API state_id parameter."""
    rows = []
    for fips, (name, abbr) in sorted(FIPS_TO_STATE.items()):
        rows.append({"fips": fips, "name": name, "abbreviation": abbr})
    return json.dumps(rows, indent=2)


@mcp.resource("repeaterbook://reference/bands")
def resource_bands() -> str:
    """Amateur radio band plan reference — frequencies used for repeaters."""
    return json.dumps(BANDS, indent=2)


@mcp.resource("repeaterbook://reference/modes")
def resource_modes() -> str:
    """Digital voice modes tracked by RepeaterBook."""
    return json.dumps(MODES, indent=2)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


@mcp.prompt()
def travel_repeater_plan(
    origin: str,
    destination: str,
    bands: str = "2m, 70cm",
    modes: str = "analog",
) -> str:
    """Plan repeater coverage for a road trip between two locations.

    Produces a step-by-step guide for finding repeaters along a travel route.
    The LLM should use find_nearby at waypoints along the route.

    Args:
        origin: Starting location (city, state or coordinates).
        destination: Ending location (city, state or coordinates).
        bands: Bands to prioritize (default '2m, 70cm').
        modes: Modes to search for (default 'analog').
    """
    return (
        f"Plan repeater coverage for a road trip from {origin} to {destination}.\n\n"
        f"Preferred bands: {bands}\n"
        f"Preferred modes: {modes}\n\n"
        "Steps:\n"
        "1. Identify the states the route passes through.\n"
        "2. For each major waypoint (every 50-75 miles), use find_nearby to locate "
        "repeaters within 25 miles.\n"
        "3. Prioritize open-use repeaters with wide coverage.\n"
        "4. Note any gaps in coverage between waypoints.\n"
        "5. Include EchoLink/AllStar/IRLP-linked repeaters as backup for dead zones.\n"
        "6. Present results as a sequential travel guide with frequencies and tones "
        "ready to program into a radio.\n\n"
        "Format output as a table: Waypoint | Callsign | Frequency | Offset | "
        "PL Tone | Modes | Notes\n\n"
        "Always attribute data to RepeaterBook.com."
    )


@mcp.prompt()
def emcomm_prep(
    state: str,
    county: str = "",
    include_digital: bool = True,
) -> str:
    """Prepare an emergency communications (EMCOMM) repeater reference sheet.

    Generates a comprehensive guide for ARES/RACES/SKYWARN operations.

    Args:
        state: State to prepare for.
        county: Optional county to focus on.
        include_digital: Include DMR and other digital modes (default True).
    """
    area = f"{county} County, {state}" if county else state
    digital_note = (
        "Include both analog and digital (DMR, Fusion, D-STAR) repeaters."
        if include_digital
        else "Focus on FM analog repeaters only."
    )
    return (
        f"Create an emergency communications reference sheet for {area}.\n\n"
        f"{digital_note}\n\n"
        "Steps:\n"
        "1. Use find_emergency_repeaters to get all ARES/RACES/SKYWARN-affiliated "
        "repeaters in the state.\n"
        "2. If a county was specified, use find_nearby with the county seat coordinates "
        "to find additional non-flagged repeaters that local ARES groups may use.\n"
        "3. Organize by county, noting primary and backup frequencies.\n"
        "4. Highlight dual ARES+RACES machines (activated under both volunteer and "
        "government emergency systems).\n"
        "5. Note linked repeaters (EchoLink, AllStar, IRLP) for extended reach.\n"
        "6. Include the common PL tones — operators should pre-program these.\n\n"
        "Present as a printable reference: County | Primary Freq | Backup Freq | "
        "PL Tone | Affiliations | Linking | Notes\n\n"
        "Reminder: RepeaterBook's emergency flags are self-reported by trustees. "
        "Check with local ARES EC for actual net schedules.\n\n"
        "Always attribute data to RepeaterBook.com."
    )


@mcp.prompt()
def radio_programming(
    latitude: float,
    longitude: float,
    state: str,
    radius_miles: float = 30.0,
    radio_model: str = "",
) -> str:
    """Generate a channel list for programming a radio from nearby repeaters.

    Produces a formatted channel plan suitable for CHIRP or manual entry.

    Args:
        latitude: Your latitude in decimal degrees.
        longitude: Your longitude in decimal degrees.
        state: Your US state.
        radius_miles: Search radius (default 30).
        radio_model: Optional radio model for format-specific notes.
    """
    radio_note = (
        f"Target radio: {radio_model}. Include any model-specific programming notes."
        if radio_model
        else "Generate a generic channel plan suitable for any FM/digital radio."
    )
    return (
        f"Create a radio channel programming list for repeaters near "
        f"({latitude}, {longitude}) in {state}, within {radius_miles} miles.\n\n"
        f"{radio_note}\n\n"
        "Steps:\n"
        "1. Use find_nearby to get all repeaters within range.\n"
        "2. Organize by band (2m first, then 70cm, then others).\n"
        "3. Within each band, sort by distance (closest first).\n"
        "4. Assign channel numbers sequentially.\n"
        "5. Include: Channel # | Name (callsign) | RX Freq | TX Freq | "
        "Encode (PL) | Decode (TSQ) | Mode | Notes\n"
        "6. Use standard offset conventions (e.g., -0.6 MHz for 2m, +5 MHz for 70cm).\n"
        "7. Flag ARES/RACES repeaters and suggest putting them in a dedicated memory bank.\n\n"
        "Always attribute data to RepeaterBook.com."
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    transport = os.getenv("MCP_TRANSPORT", "stdio")
    if transport == "streamable-http":
        mcp.run(
            transport="streamable-http",
            host=os.getenv("MCP_HOST", "0.0.0.0"),
            port=int(os.getenv("MCP_PORT", "8000")),
        )
    else:
        mcp.run()
