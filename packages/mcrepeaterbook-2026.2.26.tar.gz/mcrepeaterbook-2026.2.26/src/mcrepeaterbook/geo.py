"""Haversine distance calculation for proximity search."""

import math


def haversine_miles(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two points in statute miles.

    Uses the Haversine formula — accurate for the distances involved in
    repeater coverage (sub-100 mile range). Earth radius is WGS-84 mean.
    The intermediate value 'a' is clamped to [0, 1] to prevent domain
    errors from floating-point imprecision at near-antipodal points.
    """
    earth_radius_mi = 3958.8  # WGS-84 mean radius in miles

    lat1_r = math.radians(lat1)
    lat2_r = math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)

    a = math.sin(dlat / 2) ** 2 + math.cos(lat1_r) * math.cos(lat2_r) * math.sin(dlon / 2) ** 2
    a = min(1.0, max(0.0, a))  # clamp for numerical safety
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return earth_radius_mi * c
