# mcrepeaterbook

MCP server for querying amateur radio repeaters from [RepeaterBook.com](https://www.repeaterbook.com).

## Install

```bash
uvx mcrepeaterbook
```

## Tools

| Tool | Description |
|------|-------------|
| `search_repeaters` | Search NA repeaters by state, city, callsign, frequency, mode |
| `search_repeaters_worldwide` | Search international repeaters (Rest of World) |
| `find_nearby` | Proximity search — find repeaters within N miles of coordinates |
| `find_emergency_repeaters` | Find ARES/RACES/SKYWARN-affiliated repeaters |

## Configuration

Set environment variables (or `.env` file):

| Variable | Required | Description |
|----------|----------|-------------|
| `REPEATERBOOK_EMAIL` | Yes | Your RepeaterBook account email |
| `REPEATERBOOK_API_KEY` | After March 2026 | API token |
| `REPEATERBOOK_CACHE_TTL` | No | Cache duration in seconds (default: 3600) |

## Add to Claude Code

```bash
claude mcp add mcrepeaterbook -- uvx mcrepeaterbook
```

## Data Attribution

All repeater data sourced from [RepeaterBook.com](https://www.repeaterbook.com). Personal, non-commercial use only.
