# mcrepeaterbook

MCP server wrapping the RepeaterBook.com API for amateur radio repeater lookups.

## Build & Run
```bash
uv sync
uv run mcrepeaterbook            # local dev
uvx mcrepeaterbook               # from PyPI (after publish)
```

## Add to Claude Code
```bash
claude mcp add mcrepeaterbook -- uv run --directory /home/rpm/claude/ham/repeaterbook mcrepeaterbook
```

## Environment
Copy `.env.example` to `.env` and fill in your RepeaterBook email. API key becomes mandatory March 2026.

## Testing
```bash
uv run pytest
```

## Lint
```bash
uv run ruff check src/ tests/
uv run ruff format src/ tests/
```

## Auth Strategy
Current: MCP Elicitation collects email on first tool call, session-scoped only (no disk write). Fallback chain: env var > config file > elicitation.

Future: Implement proper OAuth 2.0 flow for hosting as streamable-http MCP server on RepeaterBook.com itself:
- OAuth lets users authenticate with their RepeaterBook account directly
- Covers MCP clients that don't support elicitation
- Handles API key transition (mandatory after March 2026) gracefully
- Alternative: magic-link / email-code flow — elicit email, send verification code to that email, user enters code to confirm ownership. Simpler than full OAuth, still passwordless, and validates the email is real.

## API Reference
- Docs: https://www.repeaterbook.com/wiki/doku.php?id=api
- NA endpoint: `api/export.php` — params: state_id, city, callsign, frequency, mode, county, landmark, country
- ROW endpoint: `api/exportROW.php` — params: country, callsign, city, frequency, mode, region
- Auth: User-Agent header `(AppName, email)`, API token after March 2026
- Rate limit: HTTP 429 on abuse, wait 10-60s
- Data policy: personal non-commercial use only, must attribute RepeaterBook
