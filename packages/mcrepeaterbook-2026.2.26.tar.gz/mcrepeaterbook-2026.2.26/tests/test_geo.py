"""Tests for haversine distance calculation."""

from mcrepeaterbook.geo import haversine_miles


def test_same_point_is_zero():
    assert haversine_miles(45.5, -122.6, 45.5, -122.6) == 0.0


def test_known_distance_portland_to_seattle():
    # Portland OR to Seattle WA: ~145 miles
    dist = haversine_miles(45.5155, -122.6793, 47.6062, -122.3321)
    assert 140 < dist < 150


def test_known_distance_nyc_to_la():
    # NYC to LA: ~2,451 miles
    dist = haversine_miles(40.7128, -74.0060, 34.0522, -118.2437)
    assert 2400 < dist < 2500


def test_short_distance_repeater_range():
    # Two points ~5 miles apart in Portland
    dist = haversine_miles(45.5155, -122.6793, 45.5500, -122.6500)
    assert 2 < dist < 6


def test_antipodal_points_clamped():
    # Near-antipodal: should not raise math domain error
    dist = haversine_miles(0.0, 0.0, 0.0, 180.0)
    # Half the Earth's circumference: ~12,451 miles
    assert 12400 < dist < 12500


def test_negative_coordinates():
    # Southern hemisphere
    dist = haversine_miles(-33.8688, 151.2093, -37.8136, 144.9631)  # Sydney to Melbourne
    assert 400 < dist < 500
