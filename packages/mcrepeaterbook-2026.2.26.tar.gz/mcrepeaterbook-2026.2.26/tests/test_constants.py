"""Tests for state/FIPS resolution and reference data."""

from mcrepeaterbook.constants import BANDS, FIPS_TO_STATE, MODES, STATE_FIPS, resolve_state


def test_resolve_state_by_name():
    assert resolve_state("Oregon") == "41"
    assert resolve_state("oregon") == "41"
    assert resolve_state("OREGON") == "41"  # case-insensitive via .lower()


def test_resolve_state_by_abbreviation():
    assert resolve_state("OR") == "41"  # case-insensitive via .lower()
    assert resolve_state("or") == "41"
    assert resolve_state("wa") == "53"
    assert resolve_state("WA") == "53"


def test_resolve_state_by_fips():
    assert resolve_state("41") == "41"
    assert resolve_state("01") == "01"
    assert resolve_state("1") == "01"  # zero-padded


def test_resolve_state_unknown():
    assert resolve_state("Narnia") is None
    assert resolve_state("XX") is None
    assert resolve_state("99") is None


def test_resolve_state_strips_whitespace():
    assert resolve_state("  or  ") == "41"
    assert resolve_state(" 41 ") == "41"


def test_us_territories_in_fips():
    assert resolve_state("pr") == "72"
    assert resolve_state("puerto rico") == "72"
    assert resolve_state("guam") == "66"
    assert resolve_state("vi") == "78"
    assert resolve_state("as") == "60"
    assert resolve_state("mp") == "69"


def test_fips_to_state_reverse_lookup():
    assert FIPS_TO_STATE["41"] == ("Oregon", "OR")
    assert FIPS_TO_STATE["72"] == ("Puerto Rico", "PR")
    assert FIPS_TO_STATE["78"] == ("US Virgin Islands", "VI")


def test_state_fips_bidirectional_consistency():
    """Every FIPS code in FIPS_TO_STATE should be reachable via STATE_FIPS."""
    for fips, (name, abbr) in FIPS_TO_STATE.items():
        assert STATE_FIPS[name.lower()] == fips, f"{name} -> {fips}"
        assert STATE_FIPS[abbr.lower()] == fips, f"{abbr} -> {fips}"


def test_bands_reference_data():
    assert "2m" in BANDS
    assert "70cm" in BANDS
    assert "range" in BANDS["2m"]


def test_modes_reference_data():
    assert "dmr" in MODES
    assert "analog" in MODES
    assert "m17" in MODES
