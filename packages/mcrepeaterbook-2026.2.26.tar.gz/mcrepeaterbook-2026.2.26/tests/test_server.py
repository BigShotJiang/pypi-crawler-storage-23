"""Integration tests for the MCP server using FastMCP's in-process Client.

Uses respx to mock RepeaterBook API responses so tests run without network access.
Each test gets a fresh Client connection (and thus a fresh lifespan/httpx client),
which avoids event-loop binding issues from the module-level mcp singleton.
"""

import json
import os

import pytest
import respx
from fastmcp import Client
from httpx import Response

# --- Fixture data -----------------------------------------------------------

PORTLAND_REPEATER = {
    "State ID": 41,
    "Rptr ID": 10001,
    "Frequency": "146.840",
    "Input Freq": "146.240",
    "PL": "100.0",
    "TSQ": "",
    "Nearest City": "Portland",
    "Landmark": "",
    "County": "Multnomah",
    "State": "Oregon",
    "Country": "United States",
    "Lat": "45.5155",
    "Long": "-122.6793",
    "Precise": 1,
    "Callsign": "W7LT",
    "Use": "OPEN",
    "Operational Status": "On-air",
    "ARES": "Yes",
    "RACES": "No",
    "SKYWARN": "Yes",
    "CANWARN": "",
    "AllStar Node": "",
    "EchoLink Node": "54321",
    "IRLP Node": "",
    "Wires Node": "",
    "FM Analog": "Yes",
    "DMR": "No",
    "DMR Color Code": "",
    "DMR ID": "",
    "D-Star": "No",
    "NXDN": "No",
    "APCO P-25": "No",
    "P-25 NAC": "",
    "M17": "No",
    "M17 CAN": "",
    "TETRA": "No",
    "TETRA MCC": "",
    "TETRA MNC": "",
    "System Fusion": "No",
    "Last Update": "2024-06-15",
}

BEAVERTON_REPEATER = {
    **PORTLAND_REPEATER,
    "Rptr ID": 10002,
    "Frequency": "147.040",
    "Input Freq": "147.640",
    "PL": "114.8",
    "Nearest City": "Beaverton",
    "County": "Washington",
    "Lat": "45.4871",
    "Long": "-122.8037",
    "Callsign": "K7RPT",
    "ARES": "No",
    "SKYWARN": "No",
    "EchoLink Node": "",
}

OFFAIR_REPEATER = {
    **PORTLAND_REPEATER,
    "Rptr ID": 10003,
    "Frequency": "145.290",
    "Input Freq": "144.690",
    "Nearest City": "Gresham",
    "Callsign": "WA7OFF",
    "Operational Status": "Off-air",
    "ARES": "No",
    "SKYWARN": "No",
    "EchoLink Node": "",
}

DMR_REPEATER = {
    **PORTLAND_REPEATER,
    "Rptr ID": 10004,
    "Frequency": "442.550",
    "Input Freq": "447.550",
    "PL": "",
    "Nearest City": "Portland",
    "Callsign": "W7DMR",
    "FM Analog": "No",
    "DMR": "Yes",
    "DMR Color Code": "1",
    "DMR ID": "311234",
    "ARES": "No",
    "SKYWARN": "No",
    "EchoLink Node": "",
}

UK_REPEATER = {
    **PORTLAND_REPEATER,
    "State ID": 0,
    "Rptr ID": 20001,
    "Frequency": "145.7375",
    "Input Freq": "145.1375",
    "PL": "77.0",
    "Nearest City": "London",
    "County": "",
    "State": "",
    "Country": "United Kingdom",
    "Lat": "51.5074",
    "Long": "-0.1278",
    "Callsign": "GB3LM",
    "ARES": "No",
    "SKYWARN": "No",
    "EchoLink Node": "",
}

MOCK_NA_RESPONSE = {
    "count": 4,
    "results": [PORTLAND_REPEATER, BEAVERTON_REPEATER, OFFAIR_REPEATER, DMR_REPEATER],
}

MOCK_ROW_RESPONSE = {
    "count": 1,
    "results": [UK_REPEATER],
}


# --- Fixtures ----------------------------------------------------------------


@pytest.fixture(autouse=True)
def _set_test_email():
    """Ensure credentials are available so elicitation is skipped."""
    old = os.environ.get("REPEATERBOOK_EMAIL")
    os.environ["REPEATERBOOK_EMAIL"] = "test@example.com"
    yield
    if old is None:
        del os.environ["REPEATERBOOK_EMAIL"]
    else:
        os.environ["REPEATERBOOK_EMAIL"] = old


@pytest.fixture
async def mcp_client():
    """Connect to the MCP server in-process — no HTTP, no event-loop issues."""
    from mcrepeaterbook.server import mcp as server

    async with Client(server) as client:
        yield client


# --- Tool discovery ----------------------------------------------------------


async def test_tool_discovery(mcp_client: Client):
    tools = await mcp_client.list_tools()
    tool_names = {t.name for t in tools}
    assert "search_repeaters" in tool_names
    assert "search_repeaters_worldwide" in tool_names
    assert "find_nearby" in tool_names
    assert "find_emergency_repeaters" in tool_names


async def test_resource_discovery(mcp_client: Client):
    resources = await mcp_client.list_resources()
    uris = {str(r.uri) for r in resources}
    assert "repeaterbook://reference/states" in uris
    assert "repeaterbook://reference/bands" in uris
    assert "repeaterbook://reference/modes" in uris


async def test_prompt_discovery(mcp_client: Client):
    prompts = await mcp_client.list_prompts()
    prompt_names = {p.name for p in prompts}
    assert "travel_repeater_plan" in prompt_names
    assert "emcomm_prep" in prompt_names
    assert "radio_programming" in prompt_names


# --- search_repeaters --------------------------------------------------------


@respx.mock
async def test_search_repeaters_basic(mcp_client: Client):
    respx.get("https://www.repeaterbook.com/api/export.php").mock(
        return_value=Response(200, json=MOCK_NA_RESPONSE)
    )

    result = await mcp_client.call_tool("search_repeaters", {"state": "or"})
    data = json.loads(result.content[0].text)

    assert data["source"] == "RepeaterBook.com"
    # Off-air repeater should be filtered out
    assert data["count"] == 3
    callsigns = [r["callsign"] for r in data["results"]]
    assert "W7LT" in callsigns
    assert "K7RPT" in callsigns
    assert "WA7OFF" not in callsigns  # off-air


@respx.mock
async def test_search_repeaters_empty_result(mcp_client: Client):
    respx.get("https://www.repeaterbook.com/api/export.php").mock(
        return_value=Response(200, json={"count": 0, "results": []})
    )

    result = await mcp_client.call_tool(
        "search_repeaters", {"state": "or", "city": "Nowhereville"}
    )
    data = json.loads(result.content[0].text)

    assert data["count"] == 0
    assert data["results"] == []


# --- search_repeaters_worldwide ----------------------------------------------


@respx.mock
async def test_search_worldwide(mcp_client: Client):
    respx.get("https://www.repeaterbook.com/api/exportROW.php").mock(
        return_value=Response(200, json=MOCK_ROW_RESPONSE)
    )

    result = await mcp_client.call_tool(
        "search_repeaters_worldwide", {"country": "United Kingdom"}
    )
    data = json.loads(result.content[0].text)

    assert data["count"] == 1
    assert data["results"][0]["callsign"] == "GB3LM"
    assert data["results"][0]["city"] == "London"


# --- find_nearby -------------------------------------------------------------


@respx.mock
async def test_find_nearby_basic(mcp_client: Client):
    respx.get("https://www.repeaterbook.com/api/export.php").mock(
        return_value=Response(200, json=MOCK_NA_RESPONSE)
    )

    result = await mcp_client.call_tool("find_nearby", {
        "latitude": 45.52,
        "longitude": -122.68,
        "state": "or",
        "radius_miles": 25.0,
    })
    data = json.loads(result.content[0].text)

    assert "search" in data
    assert data["search"]["state"] == "Oregon (OR)"
    assert data["search"]["radius_miles"] == 25.0
    # All operational repeaters with coords should be within 25mi of downtown Portland
    assert data["count"] >= 1
    # Results should be sorted by distance
    if data["count"] > 1:
        distances = [r["distance_miles"] for r in data["results"]]
        assert distances == sorted(distances)


@respx.mock
async def test_find_nearby_invalid_latitude(mcp_client: Client):
    result = await mcp_client.call_tool("find_nearby", {
        "latitude": 95.0,
        "longitude": -122.0,
        "state": "or",
    })
    data = json.loads(result.content[0].text)
    assert "error" in data
    assert "latitude" in data["error"].lower()


@respx.mock
async def test_find_nearby_invalid_longitude(mcp_client: Client):
    result = await mcp_client.call_tool("find_nearby", {
        "latitude": 45.0,
        "longitude": -200.0,
        "state": "or",
    })
    data = json.loads(result.content[0].text)
    assert "error" in data
    assert "longitude" in data["error"].lower()


@respx.mock
async def test_find_nearby_unknown_state(mcp_client: Client):
    result = await mcp_client.call_tool("find_nearby", {
        "latitude": 45.0,
        "longitude": -122.0,
        "state": "Narnia",
    })
    data = json.loads(result.content[0].text)
    assert "error" in data
    assert "FIPS" in data["error"]


# --- find_emergency_repeaters ------------------------------------------------


@respx.mock
async def test_find_emergency_repeaters(mcp_client: Client):
    respx.get("https://www.repeaterbook.com/api/export.php").mock(
        return_value=Response(200, json=MOCK_NA_RESPONSE)
    )

    result = await mcp_client.call_tool("find_emergency_repeaters", {"state": "or"})
    data = json.loads(result.content[0].text)

    # Only W7LT has ARES=Yes and SKYWARN=Yes
    assert data["count"] == 1
    assert data["results"][0]["callsign"] == "W7LT"
    assert "ARES" in data["results"][0]["emergency"]
    assert "SKYWARN" in data["results"][0]["emergency"]


# --- Resources ---------------------------------------------------------------


async def test_resource_states(mcp_client: Client):
    content = await mcp_client.read_resource("repeaterbook://reference/states")
    data = json.loads(content[0].text)

    # Should include all 50 states + DC + territories
    fips_codes = {entry["fips"] for entry in data}
    assert "41" in fips_codes  # Oregon
    assert "72" in fips_codes  # Puerto Rico
    assert len(fips_codes) >= 51  # 50 states + DC minimum


async def test_resource_bands(mcp_client: Client):
    content = await mcp_client.read_resource("repeaterbook://reference/bands")
    data = json.loads(content[0].text)
    assert "2m" in data
    assert "70cm" in data


async def test_resource_modes(mcp_client: Client):
    content = await mcp_client.read_resource("repeaterbook://reference/modes")
    data = json.loads(content[0].text)
    assert "dmr" in data
    assert "analog" in data


# --- Prompts -----------------------------------------------------------------


async def test_prompt_travel_plan(mcp_client: Client):
    result = await mcp_client.get_prompt(
        "travel_repeater_plan",
        arguments={"origin": "Portland, OR", "destination": "Seattle, WA"},
    )
    text = result.messages[0].content.text
    assert "Portland, OR" in text
    assert "Seattle, WA" in text
    assert "find_nearby" in text


async def test_prompt_emcomm(mcp_client: Client):
    result = await mcp_client.get_prompt(
        "emcomm_prep",
        arguments={"state": "Oregon", "county": "Multnomah"},
    )
    text = result.messages[0].content.text
    assert "Multnomah County, Oregon" in text
    assert "ARES" in text


async def test_prompt_radio_programming(mcp_client: Client):
    result = await mcp_client.get_prompt(
        "radio_programming",
        arguments={
            "latitude": "45.5155",
            "longitude": "-122.6793",
            "state": "Oregon",
            "radio_model": "Baofeng UV-5R",
        },
    )
    text = result.messages[0].content.text
    assert "Baofeng UV-5R" in text
    assert "45.5155" in text
