"""Tests for Pydantic models and data transformations."""

from mcrepeaterbook.models import Repeater, RepeaterBookResponse

SAMPLE_REPEATER = {
    "State ID": 41,
    "Rptr ID": 12345,
    "Frequency": "146.840",
    "Input Freq": "146.240",
    "PL": "100.0",
    "TSQ": "",
    "Nearest City": "Portland",
    "Landmark": "",
    "County": "Multnomah",
    "State": "Oregon",
    "Country": "United States",
    "Lat": "45.5155",
    "Long": "-122.6793",
    "Precise": 1,
    "Callsign": "W7LT",
    "Use": "OPEN",
    "Operational Status": "On-air",
    "ARES": "Yes",
    "RACES": "No",
    "SKYWARN": "No",
    "CANWARN": "",
    "AllStar Node": "",
    "EchoLink Node": "12345",
    "IRLP Node": "",
    "Wires Node": "",
    "FM Analog": "Yes",
    "DMR": "No",
    "DMR Color Code": "",
    "DMR ID": "",
    "D-Star": "No",
    "NXDN": "No",
    "APCO P-25": "No",
    "P-25 NAC": "",
    "M17": "No",
    "M17 CAN": "",
    "TETRA": "No",
    "TETRA MCC": "",
    "TETRA MNC": "",
    "System Fusion": "No",
    "Last Update": "2024-01-15",
}


def test_coerce_numeric_fields():
    """API returns State ID, Rptr ID, Precise as ints — model coerces to str."""
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    assert rptr.state_id == "41"
    assert rptr.rptr_id == "12345"
    assert rptr.precise == "1"


def test_lat_lon_float_properties():
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    assert rptr.lat_float == 45.5155
    assert rptr.lon_float == -122.6793


def test_lat_lon_float_empty():
    data = {**SAMPLE_REPEATER, "Lat": "", "Long": ""}
    rptr = Repeater.model_validate(data)
    assert rptr.lat_float is None
    assert rptr.lon_float is None


def test_is_operational_on_air():
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    assert rptr.is_operational is True


def test_is_operational_off_air():
    data = {**SAMPLE_REPEATER, "Operational Status": "Off-air"}
    rptr = Repeater.model_validate(data)
    assert rptr.is_operational is False


def test_is_operational_off_air_variant():
    data = {**SAMPLE_REPEATER, "Operational Status": "Off air"}
    rptr = Repeater.model_validate(data)
    assert rptr.is_operational is False


def test_is_operational_empty_status():
    """Empty status defaults to operational (negative matching)."""
    data = {**SAMPLE_REPEATER, "Operational Status": ""}
    rptr = Repeater.model_validate(data)
    assert rptr.is_operational is True


def test_is_operational_testing():
    """Testing status should be treated as operational."""
    data = {**SAMPLE_REPEATER, "Operational Status": "Testing"}
    rptr = Repeater.model_validate(data)
    assert rptr.is_operational is True


def test_active_modes_fm():
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    assert rptr.active_modes == ["FM Analog"]


def test_active_modes_dmr_with_color_code():
    data = {**SAMPLE_REPEATER, "DMR": "Yes", "DMR Color Code": "3"}
    rptr = Repeater.model_validate(data)
    assert "DMR CC3" in rptr.active_modes


def test_active_modes_multiple():
    data = {
        **SAMPLE_REPEATER,
        "FM Analog": "Yes",
        "D-Star": "Yes",
        "System Fusion": "Yes",
    }
    rptr = Repeater.model_validate(data)
    assert "FM Analog" in rptr.active_modes
    assert "D-STAR" in rptr.active_modes
    assert "System Fusion" in rptr.active_modes


def test_linked_systems():
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    assert rptr.linked_systems == ["EchoLink:12345"]


def test_has_emergency_affiliation_ares():
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    assert rptr.has_emergency_affiliation is True  # ARES=Yes


def test_has_emergency_affiliation_none():
    data = {**SAMPLE_REPEATER, "ARES": "No"}
    rptr = Repeater.model_validate(data)
    assert rptr.has_emergency_affiliation is False


def test_to_summary_basic():
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    summary = rptr.to_summary()
    assert summary["callsign"] == "W7LT"
    assert summary["frequency"] == "146.840"
    assert summary["offset"] == "-0.6"
    assert summary["city"] == "Portland"
    assert summary["state"] == "Oregon"
    assert summary["pl_tone"] == "100.0"
    assert "ARES" in summary["emergency"]
    assert summary["linked"] == ["EchoLink:12345"]


def test_to_summary_with_distance():
    rptr = Repeater.model_validate(SAMPLE_REPEATER)
    summary = rptr.to_summary(distance_mi=3.7)
    assert summary["distance_miles"] == 3.7


def test_repeaterbook_response_model():
    resp = RepeaterBookResponse.model_validate({
        "count": 1,
        "results": [SAMPLE_REPEATER],
    })
    assert resp.count == 1
    assert len(resp.results) == 1
    assert resp.results[0].callsign == "W7LT"


def test_repeaterbook_response_empty():
    resp = RepeaterBookResponse.model_validate({"count": 0, "results": []})
    assert resp.count == 0
    assert resp.results == []
