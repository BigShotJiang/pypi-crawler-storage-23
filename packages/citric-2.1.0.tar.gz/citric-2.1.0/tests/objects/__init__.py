"""Unit tests for citric objects."""

from __future__ import annotations
