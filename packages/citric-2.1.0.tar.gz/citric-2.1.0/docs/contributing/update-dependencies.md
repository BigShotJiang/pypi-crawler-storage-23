# Updating dependencies

The easiest way to update dependencies is to use the the [`just`][just] command. This command will update all dependencies to the latest version.

[just]: https://just.systems/man/en/prerequisites.html
