# Building the documentation

If you've already [set up your environment][environment], you can build the
documentation site and watch the repo for changes:

```shell
nox -s docs-serve
```

[environment]: /contributing/environment
