# Credits

## Development Lead

- Edgar Ramírez Mondragón edgarrm358@gmail.com

## Contributors

None yet. Why not be the first?
