"""Smoke tests — verify the neng-wifi-tools package is importable and well-formed."""

from __future__ import annotations

import re


def test_package_version():
    from neng_wifi_tools import __version__

    assert re.match(r"^\d+\.\d+\.\d+", __version__), (
        f"Version string {__version__!r} does not look like semver"
    )


# ---------------------------------------------------------------------------
# device_scanner
# ---------------------------------------------------------------------------
def test_import_device_scanner():
    from neng_wifi_tools.device_scanner import (  # noqa: F401
        check_port,
        get_all_local_networks,
        get_local_network,
        scan_network,
        verify_neng_device,
    )


def test_format_table_no_devices():
    from neng_wifi_tools.device_scanner import format_table

    out = format_table([])
    assert "No SCPI devices found" in out


def test_format_json():
    import json

    from neng_wifi_tools.device_scanner import format_json

    out = format_json([("192.168.1.10", 5025, "NEnG,TMP117,v1.0")])
    data = json.loads(out)
    assert data["count"] == 1
    assert data["devices"][0]["ip"] == "192.168.1.10"
    assert data["devices"][0]["port"] == 5025


def test_format_simple():
    from neng_wifi_tools.device_scanner import format_simple

    out = format_simple([("10.0.0.1", 5025, "id1"), ("10.0.0.2", 5025, "id2")])
    assert out == "10.0.0.1\n10.0.0.2"


# ---------------------------------------------------------------------------
# ota_client
# ---------------------------------------------------------------------------
def test_import_ota_client():
    from neng_wifi_tools.ota_client import (  # noqa: F401
        GitDeployManager,
        GitToDeviceMapper,
        OTAClient,
        deploy_from_git,
    )


def test_ota_client_main_callable():
    from neng_wifi_tools.ota_client import main

    assert callable(main)


def test_git_to_device_mapper_profiles():
    from neng_wifi_tools.ota_client import GitToDeviceMapper

    for device in ("TMP117", "3Dmag", "BTS7960", "RelayBank16", "RTDMax31865"):
        mapper = GitToDeviceMapper(device=device)
        assert mapper.source_base


def test_git_to_device_mapper_invalid():
    import pytest

    from neng_wifi_tools.ota_client import GitToDeviceMapper

    with pytest.raises(ValueError, match="Unknown device"):
        GitToDeviceMapper(device="INVALID_DEVICE")


# ---------------------------------------------------------------------------
# wifi_config_gui
# ---------------------------------------------------------------------------
def test_import_wifi_config_gui():
    from neng_wifi_tools.wifi_config_gui import main  # noqa: F401

    assert callable(main)


# ---------------------------------------------------------------------------
# ota_manager_gui
# ---------------------------------------------------------------------------
def test_import_ota_manager_gui():
    from neng_wifi_tools.ota_manager_gui import OTAManagerGUI  # noqa: F401

    assert callable(OTAManagerGUI)


# ---------------------------------------------------------------------------
# Entry-point wrappers
# ---------------------------------------------------------------------------
def test_scanner_entry_callable():
    from neng_wifi_tools.scanner import main

    assert callable(main)


def test_wifi_gui_entry_callable():
    from neng_wifi_tools.wifi_gui import main

    assert callable(main)


def test_ota_entry_callable():
    from neng_wifi_tools.ota_entry import main

    assert callable(main)


def test_ota_gui_entry_callable():
    from neng_wifi_tools.ota_gui import main

    assert callable(main)


# ---------------------------------------------------------------------------
# No stale relative imports to old location
# ---------------------------------------------------------------------------
def test_no_temp_logger_imports():
    """Ensure no file in neng_wifi_tools imports from temp_logger."""
    import pathlib

    pkg_dir = pathlib.Path(__file__).resolve().parent.parent / "src" / "neng_wifi_tools"
    for py_file in pkg_dir.glob("*.py"):
        source = py_file.read_text()
        assert "from temp_logger" not in source, (
            f"{py_file.name} still imports from temp_logger"
        )
        assert "import temp_logger" not in source, (
            f"{py_file.name} still imports temp_logger"
        )
