#!/usr/bin/env python3
# -*- coding: utf-8 -*-
PROG_VERSION = "Time-stamp: <2025-02-04 16:38:41 vk>"

from mastodon import Mastodon
from datetime import datetime, timedelta, timezone
import sys
import pytz
import pypandoc
import argparse   # for handling command line arguments
import logging

SEPARATOR = '\n' + '—'*80 + '\n'
NOW = datetime.now(timezone.utc)
PROG_VERSION_DATE = PROG_VERSION[13:23]


DESCRIPTION = "This tool prints a brief statistics about your Mastodon messages of the latest DAYNUMBER days.\n\
\n\
The output constist of:\n\
- timestamp (now)\n\
- number of toots retrieved\n\
- your current number of followers\n\
- top COUNTNUMBER most boosted messages (or less if no more found)\n\
- top COUNTNUMBER most favored messages (or less if no more found)\n\
- top COUNTNUMBER most replied messages (or less if no more found)\n\
\n\
\n\
Example usages:\n\
  poetry run python3 PATH/TO/tootsnoop/__init__.py --days 7 --count 10\n\
      … prints the topmost 10 entries for the last 7 days\n\
\n\
\n\
One-time setup:\n\
\n\
1. Configure you access token:\n\
   - Login to your Mastodon instance in your web browser.\n\
   - Go to Preference → Development and click on \"New Application\".\n\
   - Enter \"tootsnoop\" as the name of the new application and modify the scopes:\n\
     - You will need only read permissions, no write permissions.\n\
   - Submit and click on \"tootsnoop\".\n\
   - Copy your new Access Token.\n\
   - Paste this Access Token into a \"access_token.txt\" file in the main directory of this tool.\n\
2. Configure your mastodon instance:\n\
   - Paste the main URL of your Mastodon instance into a \"instance_url.txt\" file in the main\n\
     directory of this tool.\n\
     - It looks like: \"https://graz.social\""

EPILOG = u"\n\
:copyright: (c) by Karl Voit <tools@Karl-Voit.at>\n\
:license: GPL v3 or any later version\n\
:URL: https://gitlab.com/publicvoit/tootsnoop\n\
:bugreports: via https://gitlab.com/publicvoit/tootsnoop/-/issues\n\
:version: " + PROG_VERSION_DATE + "\n·\n"


parser = argparse.ArgumentParser(prog=sys.argv[0],
                                 # keep line breaks in EPILOG and such
                                 formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog=EPILOG,
                                 description=DESCRIPTION)

parser.add_argument("--days",
                    dest="days",
                    nargs=1,
                    type=int,
                    metavar='DAYNUMBER',
                    required=True,
                    help="Number of days to look back")

parser.add_argument("--count",
                    dest="count",
                    nargs=1,
                    type=int,
                    metavar='COUNTNUMBER',
                    required=True,
                    help="Number of topmost entries to show")

parser.add_argument("--inactive",
                    dest="inactive", action="store_true",
                    help="Generate inactive time-stamps instead of active (using square brackets instead of angle brackets)")

parser.add_argument("--verbose",
                    dest="verbose", action="store_true",
                    help="Enable verbose mode")

options = parser.parse_args()


def handle_logging():
    """Log handling and configuration"""

    if options.verbose:
        FORMAT = "%(levelname)-8s %(asctime)-15s %(message)s"
        logging.basicConfig(level=logging.DEBUG, format=FORMAT)
    else:
        FORMAT = "%(levelname)-8s %(message)s"
        logging.basicConfig(level=logging.INFO, format=FORMAT)


def error_exit(errorcode, text):
    """exits with return value of errorcode and prints to stderr"""

    sys.stdout.flush()
    logging.error(text)

    sys.exit(errorcode)



# Function to authenticate with the Mastodon API
def authenticate():
    with open('access_token.txt', 'r') as file:
        access_token = file.read().strip()
    with open('instance_url.txt', 'r') as file:
        instance_url = file.read().strip()
    mastodon = Mastodon(
        access_token = access_token,
        api_base_url = instance_url
    )
    return mastodon

# Function to get messages from the last 'x' days
def get_messages(mastodon, days):


    # Get your user ID
    user = mastodon.account_verify_credentials()
    user_id = user['id']

    # Fetch your own statuses (toots) within the last `days` days
    now = NOW

    since_date = now - timedelta(days=days)
    logging.debug(f"{since_date= }")
    logging.debug(f"{now= }")
    logging.debug(f"{timedelta(days=days)= }")

    # Get statuses (toots) from your own account.
    # The Mastodon API returns at most 40 per page, so we must paginate.
    all_messages = []
    page = mastodon.account_statuses(user_id, limit=40)
    while page:
        for msg in page:
            if msg['created_at'] >= since_date:
                all_messages.append(msg)
            else:
                # Messages are in reverse chronological order; stop once we pass the date range
                return all_messages
        page = mastodon.fetch_next(page)

    return all_messages


# Function to clean up HTML content and return plain text
def clean_content(content):
    #logging.debug('DEBUG: content:==============\n' + content + '\n=================\n')
    return pypandoc.convert_text(content, 'org', format='html').replace('\n\n\n\n', ' • ').replace('\n\n\n', ' • ').replace('\n\n', ' • ').replace('\n', ' ')


# Function to sort and get top 10 most boosted, interacted, and favored messages
def get_top_messages(messages, count):
    sorted_by_boosts = sorted(messages, key=lambda x: x['reblogs_count'], reverse=True)[:count]
    sorted_by_favorites = sorted(messages, key=lambda x: x['favourites_count'], reverse=True)[:count]
    sorted_by_replies = sorted(messages, key=lambda x: x['replies_count'], reverse=True)[:count]
    
    return sorted_by_boosts, sorted_by_favorites, sorted_by_replies


# Function to get follower count change
def get_follower_change(mastodon, days):
    # Get current follower count
    current_followers = mastodon.account_verify_credentials()['followers_count']
    
    # Fetch account activity over the last 'x' days
    messages = get_messages(mastodon, days)
    
    # Get the follower count from a few days ago (for simplicity, assume change is tracked manually or from previous data)
    # For now, we’ll assume that there’s no history tracking, so current is the only data available.
    
    return current_followers


def datetime_to_orgdown_timestamp(mydatetime, inactive=False):
    if options.inactive or inactive:
        return mydatetime.strftime('[%Y-%m-%d %a %H:%M]')    
    else:
        return mydatetime.strftime('<%Y-%m-%d %a %H:%M>')    
            

def print_top_line(top_type, count_type, line_prefix):

    for msg in top_type:
        if msg[count_type] > 0:  # Only print if reblogs_count > 0
            cleaned_content = clean_content(msg['content'])
            
            if len(cleaned_content) < 1:
                #logging.debug(str(msg))
                # msg['media_attachments'][0]['description']
                if 'media_attachments' in msg.keys():
                    cleaned_content += msg['uri'] + ' • '
                    for attachment in msg['media_attachments']:
                        cleaned_content += ' ' + attachment['description']
                else:
                    cleaned_content = msg['uri']
                    print('ERROR: zero content and no media_attachment found')
                #logging.debug(msg['uri'] + formatteddescription)

            print(f"- {msg[count_type]:3d} {line_prefix}: [[{msg['uri']}][{datetime_to_orgdown_timestamp(msg['created_at'])}]] {cleaned_content}")


def print_heading(text):
    #print(SEPARATOR + '*' + text + '*\n')
    print('\n*' + text + '*\n')

    
# Main function to generate summary
def generate_summary(count, days):
    mastodon = authenticate()
    messages = get_messages(mastodon, days)
    
    top_boosted, top_favored, top_replied = get_top_messages(messages, count)
    
    follower_change = get_follower_change(mastodon, days)
    
    print(f"{datetime_to_orgdown_timestamp(NOW)} Summary of Mastodon Activity over the last {days} days:\n")
    print(f"- Toots retrieved: {len(messages)}")
    print(f"- Current number of followers: {follower_change}")

    print_heading(f'Top {str(count)} Most Boosted Messages')
    print_top_line(top_boosted, 'reblogs_count', 'Boosts')
    
    print_heading(f'Top {str(count)} Most Favored Messages')
    print_top_line(top_favored, 'favourites_count', 'Favorites')

    print_heading(f'Top {str(count)} Most Replied Messages')
    print_top_line(top_replied, 'replies_count', 'Replies')

    
def main():
    """Main function"""

    handle_logging()

    generate_summary(options.count[0], options.days[0])


# Check if the script is being executed directly
if __name__ == "__main__":
    main()
