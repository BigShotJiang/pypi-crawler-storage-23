from rich.console import Console

console = Console()
log = console.log
