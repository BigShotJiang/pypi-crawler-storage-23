"""Partisipa app package."""

default_app_config = "testproject.partisipa.apps.PartisipaConfig"
