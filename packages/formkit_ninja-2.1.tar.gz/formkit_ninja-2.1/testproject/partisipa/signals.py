"""
Signal handlers for partisipa app.

These handlers automatically populate Django models from FormKit submissions.
"""
