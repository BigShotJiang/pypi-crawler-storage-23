"""
Partisipa models package.

This package contains generated Django models for TF611 and other forms.
"""

from .tf611 import (
    Tf611,
    Tf611MeetinginformationAbstract,
    Tf611ProjectbeneficiariesAbstract,
    Tf611ProjectdetailsAbstract,
    Tf611ProjecttimeframeAbstract,
    Tf611Repeaterprojectoutput,
)

__all__ = [
    "Tf611",
    "Tf611MeetinginformationAbstract",
    "Tf611ProjectbeneficiariesAbstract",
    "Tf611ProjectdetailsAbstract",
    "Tf611ProjecttimeframeAbstract",
    "Tf611Repeaterprojectoutput",
]
