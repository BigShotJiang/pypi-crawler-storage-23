from .personalinfo import PersonalInfoAdmin  # noqa: F401

__all__ = ["PersonalInfoAdmin"]
