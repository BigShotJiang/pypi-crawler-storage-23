"""
Signal handlers for sample_app app.

These handlers automatically populate Django models from FormKit submissions.
"""
