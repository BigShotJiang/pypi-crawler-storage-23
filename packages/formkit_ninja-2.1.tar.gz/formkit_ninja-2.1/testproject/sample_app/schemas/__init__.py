from .personalinfo import PersonalInfoSchema  # noqa: F401

__all__ = ["PersonalInfoSchema"]
