"""
Signal handlers for complex_app app.

These handlers automatically populate Django models from FormKit submissions.
"""
