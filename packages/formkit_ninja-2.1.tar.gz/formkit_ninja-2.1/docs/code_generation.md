# Code Generation Guide

formkit-ninja provides a powerful code generation system that automatically creates Django models, Pydantic schemas, admin classes, and API endpoints from your FormKit schemas.

> **🆕 New in v0.8.1**: Database-driven code generation! Configure type mappings and field overrides through Django admin without writing Python code. See [Database-Driven Code Generation](database_code_generation.md) for details.

## Table of Contents

- [Basic Usage](#basic-usage)
- [Programmatic Usage](#programmatic-usage)
- [Database-Driven Configuration](#database-driven-configuration) ⭐ NEW
- [Extensibility](#extensibility)
  - [Custom Type Converters](#custom-type-converters)
  - [Custom NodePath](#custom-nodepath)
  - [Plugin System](#plugin-system)
  - [Custom Templates](#custom-templates)

## Basic Usage

### Management Command

The simplest way to generate code is using the Django management command:

```bash
./manage.py generate_code --app-name myapp --output-dir ./myapp/generated
```

**Arguments:**

- `--app-name` (required): Name of the Django app
- `--output-dir` (required): Directory where generated code will be written
- `--schema-label` (optional): Generate code for a specific schema label. If omitted, generates for all schemas

**Example:**

```bash
# Generate code for all schemas
./manage.py generate_code --app-name forms --output-dir ./forms/generated

# Generate code for a specific schema
./manage.py generate_code --app-name forms --output-dir ./forms/generated --schema-label "Contact Form"
```

### Generated Files

The code generator creates the following files in the output directory:

1. **models.py** - Django models for groups and repeaters
2. **schemas.py** - Django Ninja output schemas
3. **schemas_in.py** - Django Ninja input schemas (Pydantic BaseModel)
4. **admin.py** - Django admin classes
5. **api.py** - Django Ninja API endpoints

### Code Generation Flow

```mermaid
graph TD
    Schema[FormKit Schema JSON/DB] --> Generator[CodeGenerator]
    Config[GeneratorConfig] --> Generator
    Templates[Jinja2 Templates] --> Generator
    
    subgraph "CodeGenerator Process"
        Generator --> Parser{Node Parser}
        Parser --> NodePath[NodePath Objects]
        NodePath --> Models[models.py]
        NodePath --> Schemas[schemas.py] 
        NodePath --> Admin[admin.py]
        NodePath --> API[api.py]
    end
    
    Models --> OutputDir[Output Directory]
    Schemas --> OutputDir
    Admin --> OutputDir
    API --> OutputDir
```

## Programmatic Usage

You can also use the code generator programmatically:

```python
from pathlib import Path
from formkit_ninja.parser import (
    CodeGenerator,
    GeneratorConfig,
    DefaultTemplateLoader,
    CodeFormatter,
)

# Create configuration
config = GeneratorConfig(
    app_name="myapp",
    output_dir=Path("./myapp/generated"),
)

# Initialize components
template_loader = DefaultTemplateLoader()
formatter = CodeFormatter()
generator = CodeGenerator(
    config=config,
    template_loader=template_loader,
    formatter=formatter,
)

# Generate code from a schema (list of dicts or FormKitSchema object)
schema = [...]  # Your FormKit schema
generator.generate(schema)
```

## Database-Driven Configuration

⭐ **NEW in v0.8.1** - Configure code generation through Django admin!

Instead of writing custom Python classes, you can now configure type mappings and field overrides through the Django admin interface or settings. This allows for:

- **Zero-code configuration** - Make changes through the admin UI
- **Dynamic updates** - No redeployment needed
- **Priority system** - Fine-grained control over rules
- **Settings fallback** - Support for `settings.py` configuration

### Quick Example

Configure a foreign key relationship through the admin:

```python
# Via Django Admin → Code generation configs:
formkit_type = "text"
node_name = "district"
django_type = "ForeignKey"
django_args = {"to": "pnds_data.zDistrict", "on_delete": "models.CASCADE"}
```

This automatically generates:

```python
# models/myform.py
district = models.ForeignKey("pnds_data.zDistrict", on_delete=models.CASCADE)
```

### Learn More

See the complete guide: **[Database-Driven Code Generation](database_code_generation.md)**

Key topics covered:
- Priority cascade system
- Admin interface guide
- Common use cases (ForeignKeys, Decimals, Enums)
- Django settings configuration
- Migration from custom NodePath classes

## Extensibility

formkit-ninja provides multiple extension points for customizing code generation to fit your project's needs.

### Architecture Overview

```mermaid
classDiagram
    class CodeGenerator {
        +generate()
    }
    
    class NodePath {
        +to_django_type()
        +to_pydantic_type()
        +get_validators()
        +extra_attribs
    }
    
    class TypeConverter {
        +can_convert(node)
        +to_pydantic_type(node)
    }
    
    class GeneratorPlugin {
        +register_converters()
        +extend_node_path()
        +get_template_packages()
    }
    
    CodeGenerator --> NodePath : Uses
    NodePath ..> TypeConverter : Uses
    CodeGenerator ..> GeneratorPlugin : Loads
    
    class CustomNodePath {
        +to_django_type()
        +get_django_args_extra()
    }
    
    NodePath <|-- CustomNodePath : Inherits
```

### Custom Type Converters

Type converters determine how FormKit nodes are converted to Pydantic types. You can create custom converters for new node types or override existing behavior.

The TypeConverterRegistry supports three matching strategies (checked in order):
1. **FormKit-based matching**: `can_convert(node)` - matches by `formkit` attribute (existing behavior)
2. **Name-based matching**: `can_convert_by_name(node_name)` - matches by `name` attribute (new in v0.9+)
3. **Options-based matching**: `can_convert_by_options(options)` - matches by `options` attribute pattern (new in v0.9+)

**Example: Custom Converter for a "currency" Node (FormKit-based)**

```python
from formkit_ninja.parser import TypeConverter, TypeConverterRegistry
from formkit_ninja.formkit_schema import FormKitType

class CurrencyConverter:
    """Converter for currency FormKit nodes."""
    
    def can_convert(self, node: FormKitType) -> bool:
        """Check if this converter can handle the node."""
        return hasattr(node, "formkit") and node.formkit == "currency"
    
    def to_pydantic_type(self, node: FormKitType) -> str:
        """Convert the node to a Pydantic type string."""
        return "Decimal"

# Register the converter
registry = TypeConverterRegistry()
registry.register(CurrencyConverter(), priority=10)  # Higher priority = checked first
```

**Example: Name-based Converter**

```python
from formkit_ninja.parser.converters_examples import FieldNameConverter

# Match nodes by field name
converter = FieldNameConverter(
    names={"district", "suco", "aldeia"},
    pydantic_type="int"
)
registry.register(converter)
```

**Example: Options-based Converter**

```python
from formkit_ninja.parser.converters_examples import OptionsPatternConverter

# Match nodes by options pattern (e.g., IDA options)
converter = OptionsPatternConverter(
    pattern="$ida(",
    pydantic_type="int"
)
registry.register(converter)
```

**Using a Custom Registry:**

```python
from formkit_ninja.parser import NodePath, TypeConverterRegistry

# Create registry with custom converters
registry = TypeConverterRegistry()
registry.register(CurrencyConverter(), priority=10)

# Use with NodePath
nodepath = NodePath(node, type_converter_registry=registry)
pydantic_type = nodepath.to_pydantic_type()
```

### Custom NodePath

You can subclass `NodePath` to add project-specific logic, validators, imports, or filter clauses.

**Example: Custom NodePath with Validators**

```python
from formkit_ninja.parser import NodePath
from formkit_ninja.formkit_schema import FormKitType

class CustomNodePath(NodePath):
    """Custom NodePath with project-specific extensions."""
    
    def get_validators(self) -> list[str]:
        """Return custom validators for this node."""
        validators = []
        
        # Add currency validator for currency fields
        if hasattr(self.node, "formkit") and self.node.formkit == "currency":
            validators.append("@field_validator('currency_field')")
            validators.append("def validate_currency(cls, v):")
            validators.append("    if v < 0:")
            validators.append("        raise ValueError('Currency must be positive')")
            validators.append("    return v")
        
        return validators
    
    def get_extra_imports(self) -> list[str]:
        """Return extra imports for schema files."""
        imports = []
        
        if hasattr(self.node, "formkit") and self.node.formkit == "currency":
            imports.append("from decimal import Decimal")
            imports.append("from pydantic import field_validator")
        
        return imports
    
    def get_custom_imports(self) -> list[str]:
        """Return custom imports for models.py."""
        imports = []
        
        if hasattr(self.node, "formkit") and self.node.formkit == "currency":
            imports.append("from django.db.models import DecimalField")
        
        return imports
    
    @property
    def filter_clause(self) -> str:
        """Return custom filter clause class name."""
        # Override default "SubStatusFilter" with your custom filter
        return "CustomStatusFilter"
```

**Using Custom NodePath:**

```python
from formkit_ninja.parser import GeneratorConfig

# Configure generator to use custom NodePath
config = GeneratorConfig(
    app_name="myapp",
    output_dir=Path("./myapp/generated"),
    node_path_class=CustomNodePath,  # Use custom class
)
```

### Plugin System

The plugin system allows you to bundle multiple extensions (converters, templates, NodePath) together in a single plugin class.

**Example: Complete Plugin**

```python
from formkit_ninja.parser import (
    GeneratorPlugin,
    TypeConverterRegistry,
    NodePath,
    register_plugin,
)
from typing import Type

class MyProjectPlugin(GeneratorPlugin):
    """Plugin for my project's custom extensions."""
    
    def register_converters(self, registry: TypeConverterRegistry) -> None:
        """Register custom type converters."""
        registry.register(CurrencyConverter(), priority=10)
        registry.register(CustomDateConverter(), priority=5)
    
    def get_template_packages(self) -> list[str]:
        """Return template packages (checked in order)."""
        return [
            "myapp.templates",  # Project templates (highest priority)
            "formkit_ninja.parser",  # Base templates (fallback)
        ]
    
    def extend_node_path(self) -> Type[NodePath] | None:
        """Return custom NodePath subclass."""
        return CustomNodePath

# Register the plugin (automatically registered when imported)
@register_plugin
class MyProjectPlugin(GeneratorPlugin):
    # ... implementation ...
```

**Using Plugins Programmatically:**

```python
from formkit_ninja.parser import (
    PluginRegistry,
    GeneratorConfig,
    ExtendedTemplateLoader,
    CodeGenerator,
    CodeFormatter,
)

# Create plugin registry
registry = PluginRegistry()
registry.register(MyProjectPlugin())

# Get NodePath class from plugins
node_path_class = registry.get_node_path_class() or NodePath

# Collect template packages
template_packages = registry.collect_template_packages()

# Create configuration
config = GeneratorConfig(
    app_name="myapp",
    output_dir=Path("./myapp/generated"),
    node_path_class=node_path_class,
    template_packages=template_packages,
)

# Create template loader with plugin packages
template_loader = ExtendedTemplateLoader(template_packages)

# Create generator
generator = CodeGenerator(
    config=config,
    template_loader=template_loader,
    formatter=CodeFormatter(),
)

# Apply plugin converters to registry
converter_registry = TypeConverterRegistry()
registry.apply_converters(converter_registry)
```

### Custom Templates

You can override the default Jinja2 templates by providing your own template packages.

**Template Structure:**

```
myapp/
  templates/
    models.py.jinja2
    schemas.py.jinja2
    schemas_in.py.jinja2
    admin.py.jinja2
    api.py.jinja2
```

**Using Custom Templates:**

```python
from formkit_ninja.parser import ExtendedTemplateLoader

# Templates are checked in order (first match wins)
template_loader = ExtendedTemplateLoader([
    "myapp.templates",  # Your custom templates
    "formkit_ninja.parser",  # Base templates (fallback)
])
```

**Template Variables:**

Templates receive the following variables:

- `nodepaths`: List of NodePath instances (groups and repeaters)
- `app_name`: Django app name
- `config`: GeneratorConfig instance

**Example: Custom Template Override**

```jinja2
{# myapp/templates/models.py.jinja2 #}
from django.db import models
{% for nodepath in nodepaths %}
class {{ nodepath.classname }}(models.Model):
    # Your custom model definition
    pass
{% endfor %}
```

## Default Type Converters

formkit-ninja includes the following default type converters:

- **TextConverter**: Handles `text`, `textarea`, `email`, `password`, `hidden`, `select`, `dropdown`, `radio`, `autocomplete` → `str`
- **NumberConverter**: Handles `number`, `tel` → `int` or `float` (based on `step` attribute)
- **DateConverter**: Handles `datepicker` → `datetime`, `date` → `date`
- **BooleanConverter**: Handles `checkbox` → `bool`
- **UuidConverter**: Handles `uuid` → `UUID`
- **CurrencyConverter**: Handles `currency` → `Decimal`

These are automatically registered in the default registry and checked in registration order.

## NodePath Extension Points

The `NodePath` class provides several extension points that can be overridden in subclasses:

- **`get_validators()`**: Return list of validator strings for Pydantic schemas
- **`get_extra_imports()`**: Return extra imports for schema files (`schemas.py`, `schemas_in.py`)
- **`get_custom_imports()`**: Return custom imports for `models.py`
- **`filter_clause`**: Property returning filter clause class name for admin/API (default: `"SubStatusFilter"`)
- **`extra_attribs`**: Property returning list of extra field definitions for models.py
- **`get_django_args_extra()`**: Method returning additional Django field arguments (new in v0.9+)
- **`to_django_type()`**: Method returning Django field type string
- **`to_django_args()`**: Method returning Django field arguments string

### Helper Methods

NodePath also provides helper methods for common node attribute checks:

- **`has_option(pattern: str) -> bool`**: Check if node options starts with a pattern
- **`matches_name(names: set[str] | list[str]) -> bool`**: Check if node name is in a set/list
- **`get_option_value() -> str | None`**: Get options attribute value as string

These helpers make it easier to write clean, readable customizations without directly accessing node attributes.

## Extension Points Reference

### `extra_attribs` Property

Add extra fields to generated models. This is useful for adding relationships, custom fields, or project-specific fields.

**Example: Adding Submission Relationship**

```python
class PartisipaNodePath(NodePath):
    @property
    def extra_attribs(self):
        """Add submission relationship to all models."""
        attribs = []
        if self.is_group or self.is_repeater:
            if self.is_group and not self.is_child:
                # Parent model: submission field (not primary key)
                attribs.append(
                    'submission = models.OneToOneField('
                    '"form_submission.SeparatedSubmission", '
                    'on_delete=models.CASCADE, primary_key=True)'
                )
            else:
                # Repeater model: nullable submission
                attribs.append(
                    'submission = models.OneToOneField('
                    '"form_submission.SeparatedSubmission", '
                    'on_delete=models.CASCADE, null=True)'
                )
        return attribs
```

**Note:** If you want `submission` without `primary_key=True`, use:
```python
attribs.append(
    'submission = models.OneToOneField('
    '"form_submission.SeparatedSubmission", '
    'on_delete=models.CASCADE, null=True, blank=True)'
)
```

**Example: Adding Custom Fields (e.g., "Project")**

```python
class PartisipaNodePath(NodePath):
    @property
    def extra_attribs(self):
        """Add submission and project fields to models."""
        attribs = []
        if self.is_group or self.is_repeater:
            # Add submission field
            if self.is_group and not self.is_child:
                attribs.append(
                    'submission = models.OneToOneField('
                    '"form_submission.SeparatedSubmission", '
                    'on_delete=models.CASCADE, null=True, blank=True)'
                )
            
            # Add project field to specific models (e.g., root-level groups)
            if self.is_group and not self.is_child:
                # Check if this is a model that should have a project field
                # You can customize this logic based on classname, field names, etc.
                if "project" in self.classname.lower() or "Project" in self.classname:
                    attribs.append(
                        'project = models.ForeignKey('
                        'ida_options.Project, '
                        'on_delete=models.PROTECT, null=True, blank=True)'
                    )
        return attribs
```

### `to_django_type()` Method

Override the Django field type for specific nodes. Useful for converting TextFields to ForeignKeys based on business logic.

**Example: ForeignKey Detection for Option Models (ida_options)**

```python
class PartisipaNodePath(NodePath):
    def to_django_type(self) -> str:
        """Convert option-based fields to ForeignKeys to ida_options models."""
        # Map field names to ida_options models
        model_name = self._map_field_to_ida_options_model()
        if model_name:
            return "ForeignKey"
        return super().to_django_type()
    
    def to_django_args(self) -> str:
        """Provide args for ForeignKey fields to ida_options."""
        model_name = self._map_field_to_ida_options_model()
        if model_name:
            # Determine on_delete based on field type
            on_delete = "models.CASCADE" if self._is_required_field() else "models.DO_NOTHING"
            return f'"{model_name}", on_delete={on_delete}, null=True, blank=True'
        return super().to_django_args()
    
    def _map_field_to_ida_options_model(self) -> str | None:
        """Map field name to ida_options Django model name."""
        if not hasattr(self.node, "name"):
            return None
        
        field_name = self.node.name.lower()
        
        # Map field names to ida_options models
        # This is project-specific logic - customize based on your schema
        field_mappings = {
            'district': 'ida_options.Munisipiu',
            'administrative_post': 'ida_options.PostuAdministrativu',
            'suco': 'ida_options.Suku',
            'aldeia': 'ida_options.Aldeia',
            'project_status': 'ida_options.SubProjectStatus1',
            'project_sector': 'ida_options.Sector',
            'project_sub_sector': 'ida_options.SubSector',
            'project_name': 'ida_options.Output',
            'objective': 'ida_options.Objective',
            'is_women_priority': 'ida_options.YesNo',
            'woman_priority': 'ida_options.YesNo',
            'women_priority': 'ida_options.YesNo',
            'output': 'ida_options.Output',
            'activity': 'ida_options.Activity',
            'unit': 'ida_options.Unit',
        }
        
        return field_mappings.get(field_name)
    
    def _is_required_field(self) -> bool:
        """Determine if field should use CASCADE (required) vs DO_NOTHING (optional)."""
        # Customize this logic based on your requirements
        # For example, location fields might be CASCADE, while status fields are DO_NOTHING
        if not hasattr(self.node, "name"):
            return False
        
        required_fields = {'district', 'administrative_post', 'suco', 'aldeia'}
        return self.node.name.lower() in required_fields
```

### `get_django_args_extra()` Method (New in v0.9+)

Add additional Django field arguments without overriding the entire `to_django_args()` method. This extension point allows you to add custom arguments (model references, custom decimal places, on_delete behavior) while preserving the base arguments.

**Example: Adding Model References**

```python
class PartisipaNodePath(NodePath):
    def get_django_args_extra(self) -> list[str]:
        """Add model references for ForeignKey fields."""
        extra_args = []
        
        # Check if this is a district field
        if self.matches_name({"district"}):
            extra_args.append("pnds_data.zDistrict")
            extra_args.append("on_delete=models.CASCADE")
        
        # Check if this is an IDA option field
        if self.has_option("$ida("):
            ida_model = self._get_ida_model()
            if ida_model:
                extra_args.append(ida_model)
                extra_args.append("on_delete=models.DO_NOTHING")
        
        return extra_args
```

**Benefits:**
- Preserves base arguments (null=True, blank=True, etc.)
- Easier to maintain than full `to_django_args()` override
- Can combine multiple custom arguments

### `to_django_args()` Method

Override Django field arguments. Useful for adding constraints, custom on_delete behavior, or other field options.

**Example: UUID Unique Constraint (Full Override)**

```python
class PartisipaNodePath(NodePath):
    def to_django_args(self) -> str:
        """Add unique=True to UUID fields."""
        if self.to_pydantic_type() == "UUID":
            return "editable=False, unique=True, null=True, blank=True"
        return super().to_django_args()
```

**Note:** For most cases, prefer `get_django_args_extra()` over full `to_django_args()` override.

## Enhanced Type Conversion with Multi-Attribute Matching

The TypeConverterRegistry now supports matching converters by multiple attributes, making it easier to handle complex customization scenarios like those in Partisipa.

**Matching Priority:**
1. FormKit attribute (`can_convert(node)`) - highest priority
2. Name attribute (`can_convert_by_name(node_name)`)
3. Options attribute (`can_convert_by_options(options)`) - lowest priority

**Example: Using Example Converters**

```python
from formkit_ninja.parser.converters import TypeConverterRegistry
from formkit_ninja.parser.converters_examples import (
    OptionsPatternConverter,
    FieldNameConverter,
)

# Create custom registry
registry = TypeConverterRegistry()

# Register IDA options converter (matches $ida(...) patterns)
registry.register(
    OptionsPatternConverter(pattern="$ida(", pydantic_type="int"),
    priority=20  # High priority for IDA options
)

# Register field name converter (matches specific field names)
registry.register(
    FieldNameConverter(
        names={"district", "suco", "aldeia", "latitude", "longitude"},
        pydantic_type="int"
    ),
    priority=15
)

# Use with NodePath
from formkit_ninja.parser.type_convert import NodePath

node = ...  # Your FormKit node
path = NodePath(node, type_converter_registry=registry)
pydantic_type = path.to_pydantic_type()  # Uses enhanced registry
```

## Complete Partisipa-Specific Extensions Example

Here's a complete example of a Partisipa-specific NodePath that implements all the customizations, using the new extension points:

```python
from formkit_ninja.parser import NodePath
from formkit_ninja.formkit_schema import FormKitType

class PartisipaNodePath(NodePath):
    """
    Partisipa-specific NodePath extensions.
    
    Adds:
    - Submission relationship to all models (without primary_key)
    - Project field to specific models
    - ForeignKey detection for ida_options models
    - UUID unique constraint
    - DateField for datepicker nodes (default behavior)
    """
    
    @property
    def extra_attribs(self):
        """Add submission and project fields to models."""
        attribs = []
        if self.is_group or self.is_repeater:
            # Add submission field (not as primary key)
            if self.is_group and not self.is_child:
                # Root-level group: submission field
                attribs.append(
                    'submission = models.OneToOneField('
                    '"form_submission.SeparatedSubmission", '
                    'on_delete=models.CASCADE, primary_key=True)'
                )
            elif self.is_repeater:
                # Repeater: nullable submission
                attribs.append(
                    'submission = models.OneToOneField('
                    '"form_submission.SeparatedSubmission", '
                    'on_delete=models.CASCADE, null=True)'
                )
            
            # Add project field to root-level groups
            if self.is_group and not self.is_child:
                # Customize this condition based on your needs
                # For example, add to all root groups or specific ones
                attribs.append(
                    'project = models.ForeignKey('
                    'ida_options.Project, '
                    'on_delete=models.PROTECT, null=True, blank=True)'
                )
        return attribs
    
    def to_django_type(self) -> str:
        """Convert option-based fields to ForeignKeys to ida_options models."""
        model_name = self._map_field_to_ida_options_model()
        if model_name:
            return "ForeignKey"
        return super().to_django_type()
    
    def get_django_args_extra(self) -> list[str]:
        """Add model references and custom arguments using extension point."""
        extra_args = []
        
        # Map field to IDA options model
        model_name = self._map_field_to_ida_options_model()
        if model_name:
            extra_args.append(f'"{model_name}"')
            on_delete = "models.CASCADE" if self._is_required_field() else "models.DO_NOTHING"
            extra_args.append(f"on_delete={on_delete}")
            # Add related_name="+" for YesNo fields
            if "YesNo" in model_name:
                extra_args.append('related_name="+"')
        
        # Custom decimal places for latitude/longitude
        if self.matches_name({"latitude", "longitude"}):
            # Note: This would override base Decimal args, so handle in to_django_args if needed
            pass
        
        return extra_args
    
    def to_django_args(self) -> str:
        """Provide args for ForeignKey fields to ida_options."""
        # Use helper methods for cleaner code
        if self.has_option("$ida("):
            # Handle IDA options via get_django_args_extra
            extra_args = self.get_django_args_extra()
            if extra_args:
                base_args = "null=True, blank=True"
                return ", ".join([*extra_args, base_args])
        
        # UUID fields get unique=True
        if self.to_pydantic_type() == "UUID":
            return "editable=False, unique=True, null=True, blank=True"
        
        # Use extension point for other customizations
        extra_args = self.get_django_args_extra()
        if extra_args:
            base_args = super().to_django_args()
            return ", ".join([*extra_args, base_args])
        
        return super().to_django_args()
    
    def _map_field_to_ida_options_model(self) -> str | None:
        """Map field name to ida_options Django model name."""
        if not hasattr(self.node, "name"):
            return None
        
        field_name = self.node.name.lower()
        
        # Map field names to ida_options models
        field_mappings = {
            'district': 'ida_options.Munisipiu',
            'administrative_post': 'ida_options.PostuAdministrativu',
            'suco': 'ida_options.Suku',
            'aldeia': 'ida_options.Aldeia',
            'project_status': 'ida_options.SubProjectStatus1',
            'project_sector': 'ida_options.Sector',
            'project_sub_sector': 'ida_options.SubSector',
            'project_subsector': 'ida_options.SubSector',
            'project_name': 'ida_options.Output',
            'objective': 'ida_options.Objective',
            'is_women_priority': 'ida_options.YesNo',
            'woman_priority': 'ida_options.YesNo',
            'women_priority': 'ida_options.YesNo',
            'output': 'ida_options.Output',
            'activity': 'ida_options.Activity',
            'unit': 'ida_options.Unit',
        }
        
        return field_mappings.get(field_name)
    
    def _is_required_field(self) -> bool:
        """Determine if field should use CASCADE (required) vs DO_NOTHING (optional)."""
        if not hasattr(self.node, "name"):
            return False
        
        # Location fields typically use CASCADE
        required_fields = {'district', 'administrative_post', 'suco', 'aldeia'}
        return self.node.name.lower() in required_fields
```

**Using PartisipaNodePath:**

```python
from formkit_ninja.parser import GeneratorConfig

config = GeneratorConfig(
    app_name="partisipa",
    output_dir=Path("./partisipa/generated"),
    node_path_class=PartisipaNodePath,  # Use Partisipa extensions
)
```

## Migration Example: Simplifying PartisipaNodePath

Here's how PartisipaNodePath could be simplified using the new features:

**Before (Full Method Overrides):**

```python
class PartisipaNodePath(NodePath):
    def to_pydantic_type(self):
        if getattr(self.node, "options", "") == "$ida(yesno)":
            return "bool"
        if self.node.name in {"district", "suco"}:
            return "int"
        return super().to_pydantic_type()
    
    def to_django_args(self):
        # Complex logic mixing base and custom args
        if self.node.name == "district":
            return "pnds_data.zDistrict, on_delete=models.CASCADE, null=True, blank=True"
        return super().to_django_args()
```

**After (Using Enhanced Features):**

```python
from formkit_ninja.parser.converters import TypeConverterRegistry
from formkit_ninja.parser.converters_examples import (
    OptionsPatternConverter,
    FieldNameConverter,
)

# Create custom registry with converters
custom_registry = TypeConverterRegistry()
custom_registry.register(OptionsPatternConverter(pattern="$ida(yesno)", pydantic_type="bool"))
custom_registry.register(FieldNameConverter(names={"district", "suco"}, pydantic_type="int"))

class PartisipaNodePath(NodePath):
    def __init__(self, *args, **kwargs):
        # Use custom registry
        if "type_converter_registry" not in kwargs:
            kwargs["type_converter_registry"] = custom_registry
        super().__init__(*args, **kwargs)
    
    def get_django_args_extra(self) -> list[str]:
        """Use extension point instead of full override."""
        extra_args = []
        if self.matches_name({"district"}):
            extra_args.append("pnds_data.zDistrict")
            extra_args.append("on_delete=models.CASCADE")
        return extra_args
```

**Benefits:**
- Cleaner code: Converters handle type conversion logic
- Easier maintenance: Extension points instead of full overrides
- Better separation: Type conversion vs. Django args customization
- Reusable: Converters can be shared across projects

## Best Practices

1. **Use Plugins for Multiple Extensions**: If you need custom converters, templates, and NodePath extensions, bundle them in a plugin.

2. **Priority Order**: When registering converters, use higher priorities for more specific converters. Converters are checked in priority order (higher first).

3. **Prefer Extension Points**: Use `get_django_args_extra()` instead of full `to_django_args()` override when possible.

4. **Use Helper Methods**: Use `has_option()`, `matches_name()`, and `get_option_value()` for cleaner attribute checks.

5. **Template Inheritance**: Use `ExtendedTemplateLoader` with your project templates first, then base templates, to allow selective overrides.

6. **Type Hints**: Always use type hints in your custom code for better IDE support and type checking.

7. **Testing**: Test your custom converters and NodePath extensions with the same test patterns used in formkit-ninja's test suite.

## Examples

See the test files in `tests/parser/` for more examples:

- `test_converters.py` - Type converter examples
- `test_plugins.py` - Plugin system examples
- `test_generator.py` - Code generation examples
- `test_template_loader.py` - Template loading examples
