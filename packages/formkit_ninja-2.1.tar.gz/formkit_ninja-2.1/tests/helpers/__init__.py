"""Helper utilities for Partisipa schema reproduction tests."""
