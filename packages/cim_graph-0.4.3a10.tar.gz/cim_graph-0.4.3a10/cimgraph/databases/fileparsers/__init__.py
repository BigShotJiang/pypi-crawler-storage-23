from cimgraph.databases.fileparsers.json_ld_parser import JSONLDFile
from cimgraph.databases.fileparsers.xml_parser import XMLFile
