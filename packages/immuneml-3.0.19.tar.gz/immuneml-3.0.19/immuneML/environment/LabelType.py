from enum import Enum


class LabelType(Enum):
    CLASSIFICATION = 1
    REGRESSION = 2
