from enum import Enum


class ReductionMethod(Enum):

    SUM = 1
    AVG = 2
