from enum import Enum


class BooleanType(Enum):

    AND = 0
    OR = 1
