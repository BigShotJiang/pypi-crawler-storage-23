from enum import Enum


class CacheType(Enum):

    PRODUCTION = "production"
    TEST = "test"
