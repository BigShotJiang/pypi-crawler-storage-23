from enum import Enum


class CacheObjectType(Enum):

    ENCODING_STEP = 0
    ENCODING = 1
    OTHER = 2
