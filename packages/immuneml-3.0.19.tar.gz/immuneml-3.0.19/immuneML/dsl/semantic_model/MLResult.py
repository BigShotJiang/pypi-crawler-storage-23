class MLResult:

    def __init__(self, path):
        self.path = path
