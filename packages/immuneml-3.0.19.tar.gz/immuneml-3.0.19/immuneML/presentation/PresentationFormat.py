from enum import Enum


class PresentationFormat(Enum):
    HTML = "HTML"
