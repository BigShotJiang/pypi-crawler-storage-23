from enum import Enum


class SequenceMatchingSummaryType(Enum):

    COUNT = 0
    CLONAL_PERCENTAGE = 1
    PERCENTAGE = 2