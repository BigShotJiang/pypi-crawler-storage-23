from enum import Enum


class ModelType(Enum):

    SEQUENCE = 1
    KMER_PAIR = 2
