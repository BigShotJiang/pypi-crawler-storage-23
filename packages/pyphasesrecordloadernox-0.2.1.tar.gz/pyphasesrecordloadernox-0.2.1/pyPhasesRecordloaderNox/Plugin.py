from pyPhases import PluginAdapter
from pyPhasesRecordloader import RecordLoader


class Plugin(PluginAdapter):
    defaultConfig = "config.yaml"

    def initPlugin(self):
        # self.project.loadConfig(self.project.loadConfig(pathlib.Path(__file__).parent.absolute().joinpath("config.yaml")))
        module = "pyPhasesRecordloaderNox"
        rlPath = f"{module}.recordLoaders"
        RecordLoader.registerRecordLoader("RecordLoaderNox", rlPath)
        RecordLoader.registerRecordLoader("NoxAnnotationLoader", rlPath)
        noxPath = self.getConfig("nox-path")
        self.project.setConfig("loader.nox.filePath", noxPath)
