"""
AfriLink Model Registry Module

Manages model and dataset resources from HuggingFace repositories.
Provides a catalog of available models with their configurations.

Key Features:
- Model catalog with HuggingFace IDs and local snapshot paths
- Dataset catalog with preprocessing info
- Version tracking
- Offline-compatible: all models pre-downloaded to aggregated HF repo
- CINECA-compatible: no internet required at runtime

Models are aggregated into a single HuggingFace repository for:
1. Simplified distribution
2. Offline compatibility on HPC clusters
3. Consistent versioning across users
"""

import os
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum


class ModelSize(Enum):
    """Model size categories"""
    TINY = "tiny"        # < 500M parameters
    SMALL = "small"      # 500M - 3B parameters
    MEDIUM = "medium"    # 3B - 13B parameters
    LARGE = "large"      # > 13B parameters


class ModelArchitecture(Enum):
    """Supported model architectures"""
    QWEN = "qwen"
    LLAVA = "llava"
    MOONDREAM = "moondream"
    GEMMA = "gemma"
    FLORENCE = "florence"
    MISTRAL = "mistral"
    LLAMA = "llama"
    SMOLVLM = "smolvlm"
    DEEPSEEK = "deepseek"
    INTERNVL = "internvl"
    CUSTOM = "custom"


class ModelType(Enum):
    """Model modality types"""
    TEXT = "text"           # Text-only LLM
    VISION = "vision"       # Vision-Language Model (VLM)
    MULTIMODAL = "multimodal"  # Multiple modalities


@dataclass
class ModelInfo:
    """Information about a registered model"""
    model_id: str
    name: str
    architecture: ModelArchitecture
    model_type: ModelType
    size_category: ModelSize
    parameters_b: float  # Billions of parameters
    context_length: int
    description: str

    # HuggingFace source (original repo)
    huggingface_id: str

    # Aggregated repo path (within AfriLink HF repo)
    # Switch the org name back to [dataspires] when the official org is created
    # Format: "dataspires/afrilink-models/{model_id}"
    aggregated_path: Optional[str] = None

    # Resource requirements
    min_gpu_memory_gb: int = 8
    recommended_gpus: int = 1

    # Training configuration hints
    lora_target_modules: List[str] = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj"
    ])
    supports_flash_attention: bool = True
    supports_quantization: bool = True

    # Special requirements
    requires_vision_encoder: bool = False
    vision_encoder_id: Optional[str] = None

    # License
    license: str = "unknown"


@dataclass
class DatasetInfo:
    """Information about a registered dataset"""
    dataset_id: str
    name: str
    description: str

    # HuggingFace source
    huggingface_id: str

    # Aggregated path
    aggregated_path: Optional[str] = None

    # Schema information
    file_format: str = "parquet"  # jsonl, parquet, csv
    text_column: str = "text"
    instruction_column: Optional[str] = None
    response_column: Optional[str] = None

    # Size information
    num_examples: Optional[int] = None
    size_mb: Optional[float] = None

    # Preprocessing
    needs_preprocessing: bool = False
    preprocessing_script: Optional[str] = None

    # Languages
    languages: List[str] = field(default_factory=lambda: ["en"])


class ModelRegistry:
    """
    Registry of available models for finetuning.

    Provides a catalog of models with their configurations
    and download instructions. All models are pre-aggregated
    into a single HuggingFace repository for offline HPC use.
    """

    # AfriLink's HuggingFace organization
    # Using [ianomungaTesting] for now but will switch to [dataspires] later
    # Models are stored as separate repos: {ORG}/afrilink-{model_id}
    # Datasets are stored as: {ORG}/afrilink-dataset-{dataset_id}
    AGGREGATED_ORG = "ianomungaTesting"

    @classmethod
    def get_model_repo(cls, model_id: str) -> str:
        """Get the HuggingFace repo ID for a model"""
        return f"{cls.AGGREGATED_ORG}/afrilink-{model_id}"

    @classmethod
    def get_dataset_repo(cls, dataset_id: str) -> str:
        """Get the HuggingFace repo ID for a dataset"""
        return f"{cls.AGGREGATED_ORG}/afrilink-dataset-{dataset_id}"

    # Built-in model catalog - actual models you specified
    MODELS: Dict[str, ModelInfo] = {
        # ═══════════════════════════════════════════════════════════════════
        # TEXT-ONLY MODELS (LLMs)
        # ═══════════════════════════════════════════════════════════════════

        "qwen2.5-0.5b": ModelInfo(
            model_id="qwen2.5-0.5b",
            name="Qwen 2.5 0.5B",
            architecture=ModelArchitecture.QWEN,
            model_type=ModelType.TEXT,
            size_category=ModelSize.TINY,
            parameters_b=0.5,
            context_length=32768,
            description="Alibaba's Qwen 2.5 0.5B - efficient tiny model with long context",
            huggingface_id="Qwen/Qwen2.5-0.5B",
            aggregated_path="ianomungaTesting/afrilink-qwen2.5-0.5b",
            min_gpu_memory_gb=4,
            recommended_gpus=1,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            license="apache-2.0",
        ),

        "gemma-3-270m": ModelInfo(
            model_id="gemma-3-270m",
            name="Gemma 3 270M",
            architecture=ModelArchitecture.GEMMA,
            model_type=ModelType.TEXT,
            size_category=ModelSize.TINY,
            parameters_b=0.27,
            context_length=8192,
            description="Google's Gemma 3 270M - ultra-lightweight model",
            huggingface_id="google/gemma-3-270m",
            aggregated_path="ianomungaTesting/afrilink-gemma-3-270m",
            min_gpu_memory_gb=2,
            recommended_gpus=1,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
            license="gemma",
        ),

        "ministral-3b": ModelInfo(
            model_id="ministral-3b",
            name="Ministral 3B Reasoning",
            architecture=ModelArchitecture.MISTRAL,
            model_type=ModelType.TEXT,
            size_category=ModelSize.SMALL,
            parameters_b=3.3,
            context_length=32768,
            description="Mistral AI's Ministral 3B with reasoning capabilities",
            huggingface_id="mistralai/Ministral-3-3B-Reasoning-2512",
            aggregated_path="ianomungaTesting/afrilink-ministral-3b",
            min_gpu_memory_gb=8,
            recommended_gpus=1,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            license="apache-2.0",
        ),

        "llama-3.2-1b": ModelInfo(
            model_id="llama-3.2-1b",
            name="Llama 3.2 1B",
            architecture=ModelArchitecture.LLAMA,
            model_type=ModelType.TEXT,
            size_category=ModelSize.SMALL,
            parameters_b=1.0,
            context_length=128000,
            description="Meta's Llama 3.2 1B - small but capable with 128K context",
            huggingface_id="meta-llama/Llama-3.2-1B",
            aggregated_path="ianomungaTesting/afrilink-llama-3.2-1b",
            min_gpu_memory_gb=4,
            recommended_gpus=1,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            license="llama3.2",
        ),

        "deepseek-r1-1.5b": ModelInfo(
            model_id="deepseek-r1-1.5b",
            name="DeepSeek R1 Distill Qwen 1.5B",
            architecture=ModelArchitecture.DEEPSEEK,
            model_type=ModelType.TEXT,
            size_category=ModelSize.SMALL,
            parameters_b=1.5,
            context_length=32768,
            description="DeepSeek R1 distilled to Qwen 1.5B - reasoning capabilities",
            huggingface_id="deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B",
            aggregated_path="ianomungaTesting/afrilink-deepseek-r1-1.5b",
            min_gpu_memory_gb=6,
            recommended_gpus=1,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            license="deepseek",
        ),

        # ═══════════════════════════════════════════════════════════════════
        # VISION-LANGUAGE MODELS (VLMs)
        # ═══════════════════════════════════════════════════════════════════

        "llava-1.5-7b": ModelInfo(
            model_id="llava-1.5-7b",
            name="LLaVA 1.5 7B",
            architecture=ModelArchitecture.LLAVA,
            model_type=ModelType.VISION,
            size_category=ModelSize.MEDIUM,
            parameters_b=7.0,
            context_length=4096,
            description="LLaVA 1.5 7B - powerful vision-language model",
            huggingface_id="liuhaotian/llava-v1.5-7b",
            aggregated_path="ianomungaTesting/afrilink-llava-1.5-7b",
            min_gpu_memory_gb=16,
            recommended_gpus=1,
            requires_vision_encoder=True,
            vision_encoder_id="openai/clip-vit-large-patch14-336",
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
            license="llama2",
        ),

        "moondream2": ModelInfo(
            model_id="moondream2",
            name="Moondream 2",
            architecture=ModelArchitecture.MOONDREAM,
            model_type=ModelType.VISION,
            size_category=ModelSize.SMALL,
            parameters_b=1.9,
            context_length=2048,
            description="Moondream 2 - efficient vision-language model",
            huggingface_id="vikhyatk/moondream2",
            aggregated_path="ianomungaTesting/afrilink-moondream2",
            min_gpu_memory_gb=8,
            recommended_gpus=1,
            requires_vision_encoder=True,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
            license="apache-2.0",
        ),

        "florence-2-base": ModelInfo(
            model_id="florence-2-base",
            name="Florence 2 Base",
            architecture=ModelArchitecture.FLORENCE,
            model_type=ModelType.VISION,
            size_category=ModelSize.TINY,
            parameters_b=0.23,
            context_length=4096,
            description="Microsoft Florence 2 Base - versatile vision foundation model",
            huggingface_id="microsoft/Florence-2-base",
            aggregated_path="ianomungaTesting/afrilink-florence-2-base",
            min_gpu_memory_gb=4,
            recommended_gpus=1,
            requires_vision_encoder=True,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
            license="mit",
        ),

        "smolvlm-256m": ModelInfo(
            model_id="smolvlm-256m",
            name="SmolVLM 256M Instruct",
            architecture=ModelArchitecture.SMOLVLM,
            model_type=ModelType.VISION,
            size_category=ModelSize.TINY,
            parameters_b=0.256,
            context_length=4096,
            description="HuggingFace SmolVLM 256M - tiny but capable VLM",
            huggingface_id="HuggingFaceTB/SmolVLM-256M-Instruct",
            aggregated_path="ianomungaTesting/afrilink-smolvlm-256m",
            min_gpu_memory_gb=2,
            recommended_gpus=1,
            requires_vision_encoder=True,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
            license="apache-2.0",
        ),

        "internvl2-1b": ModelInfo(
            model_id="internvl2-1b",
            name="InternVL2 1B",
            architecture=ModelArchitecture.INTERNVL,
            model_type=ModelType.VISION,
            size_category=ModelSize.SMALL,
            parameters_b=1.0,
            context_length=4096,
            description="OpenGVLab InternVL2 1B - strong vision understanding",
            huggingface_id="OpenGVLab/InternVL2-1B",
            aggregated_path="ianomungaTesting/afrilink-internvl2-1b",
            min_gpu_memory_gb=4,
            recommended_gpus=1,
            requires_vision_encoder=True,
            lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
            license="mit",
        ),
    }

    # Built-in dataset catalog
    DATASETS: Dict[str, DatasetInfo] = {
        "multilingual-thinking": DatasetInfo(
            dataset_id="multilingual-thinking",
            name="Multilingual Thinking",
            description="HuggingFace H4 Multilingual Thinking dataset for reasoning",
            huggingface_id="HuggingFaceH4/Multilingual-Thinking",
            aggregated_path="ianomungaTesting/afrilink-dataset-multilingual-thinking",
            file_format="parquet",
            languages=["en", "zh", "es", "fr", "de", "ja", "ko", "pt", "ru", "ar"],
        ),

        "alpaca": DatasetInfo(
            dataset_id="alpaca",
            name="Stanford Alpaca",
            description="52K instruction-following examples",
            huggingface_id="tatsu-lab/alpaca",
            aggregated_path="ianomungaTesting/afrilink-dataset-alpaca",
            text_column="text",
            instruction_column="instruction",
            response_column="output",
            num_examples=52000,
        ),

        "dolly": DatasetInfo(
            dataset_id="dolly",
            name="Databricks Dolly 15K",
            description="15K human-generated instruction examples",
            huggingface_id="databricks/databricks-dolly-15k",
            aggregated_path="ianomungaTesting/afrilink-dataset-dolly",
            text_column="text",
            instruction_column="instruction",
            response_column="response",
            num_examples=15000,
        ),

        # Placeholder for user-provided datasets
        "custom": DatasetInfo(
            dataset_id="custom",
            name="Custom Dataset",
            description="User-provided dataset",
            huggingface_id="",
        ),
    }

    def __init__(
        self,
        aggregated_org: Optional[str] = None,
        use_local_cache: bool = True,
    ):
        """
        Initialize registry.

        Args:
            aggregated_org: HuggingFace organization containing aggregated models
            use_local_cache: Use local HF cache if available
        """
        self.aggregated_org = aggregated_org or self.AGGREGATED_ORG
        self.use_local_cache = use_local_cache

        # Allow dynamic registration
        self._custom_models: Dict[str, ModelInfo] = {}
        self._custom_datasets: Dict[str, DatasetInfo] = {}

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """
        Get model information by ID.

        Args:
            model_id: Model identifier

        Returns:
            ModelInfo or None if not found
        """
        # Check custom models first
        if model_id in self._custom_models:
            return self._custom_models[model_id]

        return self.MODELS.get(model_id)

    def get_dataset(self, dataset_id: str) -> Optional[DatasetInfo]:
        """
        Get dataset information by ID.

        Args:
            dataset_id: Dataset identifier

        Returns:
            DatasetInfo or None if not found
        """
        if dataset_id in self._custom_datasets:
            return self._custom_datasets[dataset_id]

        return self.DATASETS.get(dataset_id)

    def list_models(
        self,
        size_filter: ModelSize = None,
        type_filter: ModelType = None,
    ) -> List[ModelInfo]:
        """
        List available models.

        Args:
            size_filter: Optional filter by size category
            type_filter: Optional filter by model type (text/vision)

        Returns:
            List of ModelInfo
        """
        all_models = list(self.MODELS.values()) + list(self._custom_models.values())

        if size_filter:
            all_models = [m for m in all_models if m.size_category == size_filter]

        if type_filter:
            all_models = [m for m in all_models if m.model_type == type_filter]

        return all_models

    def list_datasets(self) -> List[DatasetInfo]:
        """
        List available datasets.

        Returns:
            List of DatasetInfo
        """
        return list(self.DATASETS.values()) + list(self._custom_datasets.values())

    def register_model(self, model_info: ModelInfo):
        """
        Register a custom model.

        Args:
            model_info: Model information
        """
        self._custom_models[model_info.model_id] = model_info

    def register_dataset(self, dataset_info: DatasetInfo):
        """
        Register a custom dataset.

        Args:
            dataset_info: Dataset information
        """
        self._custom_datasets[dataset_info.dataset_id] = dataset_info

    def get_model_path(
        self,
        model_id: str,
        use_aggregated: bool = True,
    ) -> str:
        """
        Get the path/ID to use for loading a model.

        Args:
            model_id: Model identifier
            use_aggregated: Use aggregated repo path if available

        Returns:
            HuggingFace model path or local path
        """
        model = self.get_model(model_id)
        if not model:
            raise ValueError(f"Model '{model_id}' not found in registry")

        if use_aggregated and model.aggregated_path:
            return model.aggregated_path
        return model.huggingface_id

    def get_dataset_path(
        self,
        dataset_id: str,
        use_aggregated: bool = True,
    ) -> str:
        """
        Get the path/ID to use for loading a dataset.

        Args:
            dataset_id: Dataset identifier
            use_aggregated: Use aggregated repo path if available

        Returns:
            HuggingFace dataset path
        """
        dataset = self.get_dataset(dataset_id)
        if not dataset:
            raise ValueError(f"Dataset '{dataset_id}' not found in registry")

        if use_aggregated and dataset.aggregated_path:
            return dataset.aggregated_path
        return dataset.huggingface_id

    def get_download_command(self, model_id: str, use_aggregated: bool = True) -> str:
        """
        Get command to download model.

        Args:
            model_id: Model identifier
            use_aggregated: Use aggregated repo

        Returns:
            Shell command to download model
        """
        model = self.get_model(model_id)
        if not model:
            return f"# Model '{model_id}' not found in registry"

        path = self.get_model_path(model_id, use_aggregated)
        return f"huggingface-cli download {path} --local-dir ./models/{model_id}"

    def get_resource_requirements(self, model_id: str, training_mode: str = "low") -> Dict[str, Any]:
        """
        Get recommended resource requirements for training.

        Args:
            model_id: Model identifier
            training_mode: Training mode (low, medium, high)

        Returns:
            Dict with resource recommendations
        """
        model = self.get_model(model_id)
        if not model:
            return {"error": f"Model '{model_id}' not found"}

        # Base requirements from model
        gpus = model.recommended_gpus
        memory = model.min_gpu_memory_gb

        # Adjust based on training mode
        if training_mode == "low":
            # QLoRA - can run on smaller GPUs
            memory = min(memory, 8)
        elif training_mode == "medium":
            # LoRA - standard requirements
            pass
        elif training_mode == "high":
            # Full finetune - need more resources
            gpus = max(gpus, 2)
            memory = memory * 2

        return {
            "model": model_id,
            "model_type": model.model_type.value,
            "training_mode": training_mode,
            "recommended_gpus": gpus,
            "min_memory_gb": memory,
            "parameters_b": model.parameters_b,
            "context_length": model.context_length,
            "requires_vision_encoder": model.requires_vision_encoder,
        }


# Global registry instance
_registry: Optional[ModelRegistry] = None


def get_registry() -> ModelRegistry:
    """Get the global model registry instance"""
    global _registry
    if _registry is None:
        _registry = ModelRegistry()
    return _registry


def list_models(
    size: str = None,
    model_type: str = None,
) -> List[Dict[str, Any]]:
    """
    List available models.

    Args:
        size: Filter by size (tiny, small, medium, large)
        model_type: Filter by type (text, vision, multimodal)

    Returns:
        List of model info dicts
    """
    registry = get_registry()
    size_filter = ModelSize(size) if size else None
    type_filter = ModelType(model_type) if model_type else None
    models = registry.list_models(size_filter, type_filter)

    return [
        {
            "id": m.model_id,
            "name": m.name,
            "type": m.model_type.value,
            "size": m.size_category.value,
            "parameters_b": m.parameters_b,
            "description": m.description,
            "huggingface_id": m.huggingface_id,
            "min_gpu_memory_gb": m.min_gpu_memory_gb,
        }
        for m in models
    ]


def list_datasets() -> List[Dict[str, Any]]:
    """
    List available datasets.

    Returns:
        List of dataset info dicts
    """
    registry = get_registry()
    datasets = registry.list_datasets()

    return [
        {
            "id": d.dataset_id,
            "name": d.name,
            "description": d.description,
            "huggingface_id": d.huggingface_id,
            "num_examples": d.num_examples,
        }
        for d in datasets
    ]
