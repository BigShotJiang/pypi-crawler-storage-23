"""
AfriLink Session Management Module

Manages HPC sessions including:
- Job submission to SLURM
- Session state tracking
- Job status polling
- Session termination
"""

import os
import time
import uuid
from typing import Optional, Dict, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

try:
    import requests
except ImportError:
    requests = None
    import urllib.request
    import urllib.error
    import json as _json


class SessionState(Enum):
    """Possible states for an HPC session"""
    CREATED = "created"
    SUBMITTING = "submitting"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class SessionInfo:
    """Information about an HPC session"""
    session_id: str
    user_id: str
    state: SessionState = SessionState.CREATED
    job_id: Optional[str] = None
    node: Optional[str] = None
    partition: str = "dcgp"
    queue_position: int = 0
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    duration_minutes: float = 0.0
    cost_usd: float = 0.0
    tunnel_url: Optional[str] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class AfriLinkSession:
    """
    HPC Session manager for AfriLink SDK.
    Communicates with the Cloudflare Worker API for job management.
    """

    # Rate per minute in USD ($2.50/hour)
    RATE_PER_MINUTE = 0.0417

    def __init__(
        self,
        auth_client,
        worker_url: str = None,
        ssh_proxy_url: str = None,
    ):
        """
        Initialize session manager.

        Args:
            auth_client: Authenticated AfriLinkAuth client
            worker_url: Cloudflare Worker API URL
            ssh_proxy_url: SSH proxy URL (falls back to auth_client)
        """
        self.auth = auth_client
        self.worker_url = worker_url or os.environ.get(
            'AFRICOLAB_WORKER_URL',
            'https://africolab-leonardo.dataspires.workers.dev'
        )
        self.ssh_proxy_url = ssh_proxy_url or auth_client.ssh_proxy_url
        self.agent_token = auth_client.agent_token

        self._active_session: Optional[SessionInfo] = None
        self._poll_interval = 5  # seconds

    def _make_request(
        self,
        method: str,
        url: str,
        data: dict = None,
        headers: dict = None,
        timeout: int = 60
    ) -> dict:
        """Make HTTP request with proper headers"""
        _headers = {
            'Content-Type': 'application/json',
            'X-Agent-Token': self.agent_token,
        }
        if headers:
            _headers.update(headers)

        if requests:
            resp = requests.request(
                method,
                url,
                json=data,
                headers=_headers,
                timeout=timeout
            )
            result = resp.json() if resp.text else {}
            if resp.status_code >= 400:
                raise Exception(result.get('error', f'HTTP {resp.status_code}'))
            return result
        else:
            req = urllib.request.Request(
                url,
                data=_json.dumps(data).encode('utf-8') if data else None,
                headers=_headers,
                method=method
            )
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    body = resp.read().decode('utf-8')
                    return _json.loads(body) if body else {}
            except urllib.error.HTTPError as e:
                body = e.read().decode('utf-8')
                try:
                    error = _json.loads(body)
                except Exception:
                    error = {'error': body}
                raise Exception(error.get('error', f'HTTP {e.code}'))

    def launch(
        self,
        partition: str = "dcgp",
        time_limit: str = "01:00:00",
        cpus: int = 1,
        memory: str = "16G",
        gpus: int = 0,
        **kwargs
    ) -> SessionInfo:
        """
        Launch a new HPC session.

        Args:
            partition: SLURM partition (dcgp, boost_usr_prod)
            time_limit: Maximum job time (HH:MM:SS)
            cpus: Number of CPUs
            memory: Memory allocation (e.g., "16G")
            gpus: Number of GPUs
            **kwargs: Additional job parameters

        Returns:
            SessionInfo with job details
        """
        if not self.auth.is_authenticated:
            raise Exception("Not authenticated. Call authenticate() first.")

        if self._active_session and self._active_session.state == SessionState.RUNNING:
            raise Exception("Session already active. End current session first.")

        session_id = str(uuid.uuid4())
        self._active_session = SessionInfo(
            session_id=session_id,
            user_id=self.auth.user_id,
            state=SessionState.SUBMITTING,
            partition=partition,
        )

        print(f"Launching HPC session...")
        print(f"  Partition: {partition}")
        print(f"  Resources: {cpus} CPU, {memory} RAM, {gpus} GPU")
        print(f"  Time limit: {time_limit}")

        try:
            result = self._make_request(
                'POST',
                self.worker_url,
                data={
                    'user_id': self.auth.user_id,
                    'session_id': session_id,
                    'partition': partition,
                    'time_limit': time_limit,
                    'cpus': cpus,
                    'memory': memory,
                    'gpus': gpus,
                    **kwargs
                }
            )

            if result.get('status') == 'queued' or result.get('job_id'):
                self._active_session.state = SessionState.QUEUED
                self._active_session.job_id = result.get('job_id')
                self._active_session.started_at = datetime.utcnow().isoformat() + 'Z'
                print(f"Job submitted: {self._active_session.job_id}")
                print(f"Session ID: {session_id}")
            elif result.get('public_url'):
                self._active_session.state = SessionState.RUNNING
                self._active_session.tunnel_url = result.get('public_url')
                self._active_session.job_id = result.get('job_id')
                self._active_session.node = result.get('node')
                self._active_session.started_at = datetime.utcnow().isoformat() + 'Z'
                print(f"Session ready: {result.get('public_url')}")

            return self._active_session

        except Exception as e:
            self._active_session.state = SessionState.FAILED
            self._active_session.error = str(e)
            raise

    def get_status(self, session_id: str = None) -> SessionInfo:
        """
        Get current session status.

        Args:
            session_id: Session ID (default: active session)

        Returns:
            Updated SessionInfo
        """
        sid = session_id or (self._active_session.session_id if self._active_session else None)
        if not sid:
            raise Exception("No session ID provided")

        result = self._make_request(
            'GET',
            f"{self.worker_url}/queue-status?session_id={sid}"
        )

        if self._active_session and self._active_session.session_id == sid:
            state_map = {
                'PENDING': SessionState.QUEUED,
                'RUNNING': SessionState.RUNNING,
                'COMPLETED': SessionState.COMPLETED,
                'FAILED': SessionState.FAILED,
                'CANCELLED': SessionState.CANCELLED,
            }
            self._active_session.state = state_map.get(
                result.get('state', 'PENDING'),
                SessionState.QUEUED
            )
            self._active_session.queue_position = result.get('position', 0)
            self._active_session.node = result.get('node')

            if result.get('tunnel_url'):
                self._active_session.tunnel_url = result.get('tunnel_url')
                self._active_session.state = SessionState.RUNNING

            return self._active_session

        return SessionInfo(
            session_id=sid,
            user_id=self.auth.user_id,
            state=SessionState.QUEUED,
            queue_position=result.get('position', 0),
        )

    def wait_for_ready(self, timeout: int = 600, poll_interval: int = 5) -> SessionInfo:
        """
        Wait for session to be ready (running with tunnel URL).

        Args:
            timeout: Maximum wait time in seconds
            poll_interval: Seconds between status checks

        Returns:
            SessionInfo when ready
        """
        if not self._active_session:
            raise Exception("No active session")

        start_time = time.time()
        last_position = -1

        while time.time() - start_time < timeout:
            status = self.get_status()

            if status.state == SessionState.RUNNING and status.tunnel_url:
                print(f"\nSession ready!")
                print(f"  URL: {status.tunnel_url}")
                return status

            if status.state == SessionState.FAILED:
                raise Exception(f"Session failed: {status.error}")

            if status.state == SessionState.CANCELLED:
                raise Exception("Session was cancelled")

            # Show queue position updates
            if status.queue_position != last_position:
                if status.queue_position > 0:
                    print(f"Queue position: {status.queue_position}")
                else:
                    print("Job is starting...")
                last_position = status.queue_position

            time.sleep(poll_interval)

        raise Exception(f"Timeout waiting for session after {timeout}s")

    def end(self, session_id: str = None) -> SessionInfo:
        """
        End a session and calculate costs.

        Args:
            session_id: Session ID to end (default: active session)

        Returns:
            Final SessionInfo with duration and cost
        """
        sid = session_id or (self._active_session.session_id if self._active_session else None)
        if not sid:
            raise Exception("No session to end")

        print(f"Ending session {sid}...")

        result = self._make_request(
            'POST',
            self.worker_url,
            data={
                'end_session': True,
                'user_id': self.auth.user_id,
                'session_id': sid,
            }
        )

        if self._active_session and self._active_session.session_id == sid:
            self._active_session.state = SessionState.COMPLETED
            self._active_session.ended_at = datetime.utcnow().isoformat() + 'Z'
            self._active_session.duration_minutes = result.get('duration_minutes', 0)
            self._active_session.cost_usd = result.get('cost_usd', 0)

            print(f"Session ended.")
            print(f"  Duration: {self._active_session.duration_minutes:.2f} minutes")
            print(f"  Cost: ${self._active_session.cost_usd:.4f}")

            ended = self._active_session
            self._active_session = None
            return ended

        return SessionInfo(
            session_id=sid,
            user_id=self.auth.user_id,
            state=SessionState.COMPLETED,
            duration_minutes=result.get('duration_minutes', 0),
            cost_usd=result.get('cost_usd', 0),
        )

    def cancel(self, session_id: str = None) -> bool:
        """
        Cancel a queued or running session (calls scancel).

        Args:
            session_id: Session ID to cancel (default: active session)

        Returns:
            True if cancelled successfully
        """
        sid = session_id or (self._active_session.session_id if self._active_session else None)
        if not sid:
            raise Exception("No session to cancel")

        job_id = None
        if self._active_session and self._active_session.session_id == sid:
            job_id = self._active_session.job_id

        if not job_id:
            # Try to get job ID from status
            status = self.get_status(sid)
            job_id = status.job_id

        if not job_id:
            raise Exception("No job ID found for session")

        print(f"Cancelling job {job_id}...")

        # Execute scancel via SSH proxy
        result = self._make_request(
            'POST',
            f"{self.ssh_proxy_url}/execute",
            data={
                'command': f'scancel {job_id}',
                'timeout': 30000,
            }
        )

        if result.get('code', 0) == 0:
            if self._active_session and self._active_session.session_id == sid:
                self._active_session.state = SessionState.CANCELLED
            print(f"Job {job_id} cancelled.")
            return True

        raise Exception(f"Failed to cancel job: {result.get('stderr', 'unknown error')}")

    def execute_command(self, command: str, timeout: int = 60000) -> Dict[str, Any]:
        """
        Execute a command on the HPC login node via SSH proxy.

        Args:
            command: Shell command to execute
            timeout: Timeout in milliseconds

        Returns:
            Dict with stdout, stderr, code
        """
        return self._make_request(
            'POST',
            f"{self.ssh_proxy_url}/execute",
            data={
                'command': command,
                'timeout': timeout,
            }
        )

    @property
    def active_session(self) -> Optional[SessionInfo]:
        """Get the currently active session"""
        return self._active_session

    @property
    def is_active(self) -> bool:
        """Check if there's an active session"""
        return self._active_session is not None and self._active_session.state in [
            SessionState.QUEUED,
            SessionState.RUNNING,
        ]
