"""Common fixtures for tests."""
