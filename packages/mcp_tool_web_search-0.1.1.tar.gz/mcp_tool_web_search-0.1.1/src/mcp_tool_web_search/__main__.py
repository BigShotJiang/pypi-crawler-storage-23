from mcp_web_search.server import run

def main():
    run()

if __name__ == "__main__":
    main()