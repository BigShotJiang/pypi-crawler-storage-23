"""SportVision: Real-time sports analytics toolkit."""

__version__ = "0.1.0"

from sportvision.pipeline import SportVisionPipeline

__all__ = ["SportVisionPipeline"]
