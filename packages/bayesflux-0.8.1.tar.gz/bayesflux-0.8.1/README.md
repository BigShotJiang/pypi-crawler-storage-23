# BayesFlux

BayesFlux is a JAX Python package that provides Fast Linear algebra sUbspace eXtraction for Bayesian inverse problems built off https://github.com/joshuawchen/randLAX.

## Features

- Active Subspace for parameter dimension reduction
- Informative Output Subspace for data dimension reduction

## Installation

### Core Installation (JAX-only functionality)

You can install the core BayesFlux package using pip:

    pip install bayesflux

This installs the JAX-based functionality only and does not require Fenics or hippylib.

### Installation with hippylib Support (Requires Fenics)

Some BayesFlux functionality depends on hippylib, which requires Fenics 2019.1.

Fenics has system-level dependencies and cannot be reliably installed via pip alone.
You must first create a conda environment.

Step 1 — Create a Fenics environment

    conda create -n fenics-2019.1_env -c conda-forge fenics==2019.1.0
    conda activate fenics-2019.1_env

Step 2 — Install BayesFlux with the hippylib extra

    pip install bayesflux[hippylib]

This installs:
- hippylib
- hickle
- bayesflux

Make sure the conda environment is activated before running pip install.

## For Developers

If your software depends on BayesFlux with hippylib functionality, declare the dependency in your pyproject.toml as:

    dependencies = [
        "bayesflux[hippylib]>=<minimum_version>"
    ]

However, your users must still create the Fenics conda environment before installing your software:

    conda create -n fenics-2019.1_env -c conda-forge fenics==2019.1.0
    conda activate fenics-2019.1_env
    pip install your_package

Important: pip cannot install Fenics. Any software depending on bayesflux[hippylib] must document the required conda environment setup.

## Requirements

- Python 3.9
