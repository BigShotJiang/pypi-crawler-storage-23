from ...compare_utils import create_new_name,get_last_comp_list

