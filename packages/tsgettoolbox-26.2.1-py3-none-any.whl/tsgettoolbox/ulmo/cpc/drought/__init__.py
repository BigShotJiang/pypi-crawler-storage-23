"""
`Climate Prediction Center`_ `Weekly Drought Index`_ dataset


.. _Climate Prediction Center: http://www.cpc.ncep.noaa.gov/
.. _Weekly Drought Index: http://www.cpc.ncep.noaa.gov/products/analysis_monitoring/cdus/palmer_drought/
"""

__all__ = ["get_data"]
from .core import get_data
