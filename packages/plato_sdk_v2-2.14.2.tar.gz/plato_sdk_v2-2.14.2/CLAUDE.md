# Python SDK

Before modifying SDK code, read:

**→ [docs/sdk/agent.md](../docs/sdk/agent.md)**

This directory contains the primary Python SDK (`plato-sdk-v2`) with async/sync clients, Chronos integration, and CLI commands.
