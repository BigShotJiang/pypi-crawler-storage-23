"""Agent runtime implementations."""

from plato.agents.runtime.base import Runtime
from plato.agents.runtime.docker import DockerRuntime
from plato.agents.runtime.vm import PlatoVMRuntime

# Keep VMRuntime as alias for backwards compatibility
VMRuntime = PlatoVMRuntime

__all__ = ["Runtime", "DockerRuntime", "PlatoVMRuntime", "VMRuntime"]
