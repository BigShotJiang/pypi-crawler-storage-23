"""Agent runner - run agents in Docker containers or VMs."""

from __future__ import annotations

import asyncio
import base64
import inspect
import json
import logging
import os
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import TYPE_CHECKING

from plato.agents.runtime import DockerRuntime, PlatoVMRuntime
from plato.agents.runtime.base import AgentContext, PreparedAgent, Runtime
from plato.agents.runtime.vm import VMConfig
from plato.runtime import VMRuntimeConfig

if TYPE_CHECKING:
    from plato.v2.async_.session import Session
    from plato.worlds.config import AgentConfig

logger = logging.getLogger(__name__)


def create_runtime(
    agent: AgentConfig,
    session: Session | None = None,
    ssh_key_path: Path | None = None,
) -> Runtime:
    """Create a runtime instance based on agent config."""
    runtime_cfg = agent.runtime
    if runtime_cfg.type == "vm":
        if session is None:
            raise ValueError("session is required for VM mode")
        if not isinstance(runtime_cfg, VMRuntimeConfig):
            raise ValueError("VMRuntimeConfig required for VM mode")
        return PlatoVMRuntime(
            session=session,
            ssh_key_path=ssh_key_path,
            vm_config=VMConfig(
                cpus=runtime_cfg.vm.cpus,
                memory=runtime_cfg.vm.memory,
                disk=runtime_cfg.vm.disk,
                timeout=runtime_cfg.vm.timeout,
            ),
        )
    else:
        return DockerRuntime()


class AgentRunner:
    """Builder for running agents with optional lifecycle hooks.

    Usage:
        # One-shot (simple)
        await AgentRunner(agent_config, runtime).run(instruction)

        # Two-phase with hooks
        await (
            AgentRunner(agent_config, runtime)
            .on_prepare(async_login_fn)
            .run(instruction, workspace="/workspace")
        )

    Execution: prepare() → hooks (if any) → execute() → cleanup.
    """

    def __init__(
        self,
        agent: AgentConfig,
        runtime: Runtime,
        agent_containers: list[str] | None = None,
    ):
        self._agent = agent
        self._runtime = runtime
        self._prepare_hooks: list[Callable[[PreparedAgent], Awaitable[None]]] = []
        self._agent_containers = agent_containers

    def on_prepare(self, fn: Callable[[PreparedAgent], Awaitable[None]]) -> AgentRunner:
        """Register a hook that runs after the environment is ready but before the agent task.

        The hook receives a PreparedAgent with hostname for networking
        (e.g., to connect to Chrome CDP at `http://{prepared.hostname}:9224`).
        """
        self._prepare_hooks.append(fn)
        return self

    async def run(self, instruction: str, workspace: str | None = None) -> str:
        """Run the agent: prepare → hooks → execute → cleanup.

        Returns the agent_id (container name or VM job ID).
        """
        runtime_dict = self._agent.runtime.model_dump()
        prep_ctx = AgentContext(
            image=self._agent.image,
            config=self._agent.config,
            instruction="",
            workspace=workspace,
            runtime=runtime_dict,
        )
        prepared = await self._runtime.prepare(prep_ctx)

        try:
            for hook in self._prepare_hooks:
                await hook(prepared)

            exec_ctx = AgentContext(
                image=self._agent.image,
                config=self._agent.config,
                instruction=instruction,
                workspace=workspace,
                runtime=runtime_dict,
            )
            await self._runtime.execute(prepared, exec_ctx)
        except Exception:
            await self._runtime.cleanup(prepared.agent_id, error=True)
            raise
        else:
            await self._runtime.cleanup(prepared.agent_id)

        return prepared.agent_id


async def run_agent(
    agent: AgentConfig,
    instruction: str,
    workspace: str | None = None,
    session: Session | None = None,
    ssh_key_path: Path | None = None,
    local_agent_path: Path | None = None,
) -> str:
    """Run an agent in a Docker container or VM (one-shot convenience function).

    Args:
        agent: Agent configuration (image, runtime, config)
        instruction: Task instruction for the agent
        workspace: Docker volume name (docker) or path to sync (vm)
        session: Plato session (required for VM mode)
        ssh_key_path: SSH key for rsync to VM (vm mode)
        local_agent_path: Path to agent code on world VM for syncing (vm mode)

    Returns:
        Container name (docker) or job ID (vm)
    """
    ctx = AgentContext(
        image=agent.image,
        config=agent.config,
        instruction=instruction,
        workspace=workspace,
        agent_code_path=local_agent_path,
    )
    runtime = create_runtime(agent, session=session, ssh_key_path=ssh_key_path)
    return await runtime.run(ctx)


# =============================================================================
# CLI for running agents inside VMs
# =============================================================================


def discover_agents() -> None:
    """Discover and load installed agent packages via entry points."""
    from plato.utils.discovery import discover_plugins

    discover_plugins("plato.agents")


async def _run_agent_cli(instruction: str, tools_path: str | None = None) -> None:
    """Run an agent with config from environment."""
    from plato.agents.base import get_agent, get_registered_agents
    from plato.otel import instrument, shutdown_tracing

    # Debug: show OTEL config
    otel_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    session_id = os.environ.get("SESSION_ID")
    print(f"[agent-runner] OTEL_EXPORTER_OTLP_ENDPOINT={otel_endpoint}", flush=True)
    print(f"[agent-runner] SESSION_ID={session_id}", flush=True)

    # Initialize OTEL tracing if configured
    instrument("agent")

    # Load config from env
    config_b64 = os.environ.get("AGENT_CONFIG_B64")
    if not config_b64:
        raise ValueError("AGENT_CONFIG_B64 environment variable required")

    config_dict = json.loads(base64.b64decode(config_b64).decode())

    # Discover agents
    discover_agents()

    # Get agent class
    agents = get_registered_agents()
    if not agents:
        raise ValueError("No agents registered")

    # Use first registered agent (typically only one per package)
    agent_name = list(agents.keys())[0]
    agent_cls = get_agent(agent_name)
    if not agent_cls:
        raise ValueError(f"Agent '{agent_name}' not found")

    # Create agent and set config
    agent = agent_cls()
    config_class = agent_cls.get_config_class()
    agent.config = config_class(**config_dict)

    try:
        sig = inspect.signature(agent.run)
        if "tools_path" in sig.parameters:
            await agent.run(instruction, tools_path=tools_path)
        else:
            await agent.run(instruction)
    finally:
        shutdown_tracing()


def main() -> None:
    """CLI entry point for plato-agent-runner."""
    import argparse

    parser = argparse.ArgumentParser(description="Run Plato agents")
    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="Run an agent")
    run_parser.add_argument("--instruction", "-i", help="Task instruction")
    run_parser.add_argument("--instruction-b64", help="Base64 encoded instruction")
    run_parser.add_argument("--tools-path", help="Path to pickled plato tools (.pkl)")
    run_parser.add_argument("--verbose", "-v", action="store_true", help="Verbose logging")

    args = parser.parse_args()

    if args.command == "run":
        log_level = logging.DEBUG if args.verbose else logging.INFO
        logging.basicConfig(
            level=log_level,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )
        # Silence noisy httpx logs
        logging.getLogger("httpx").setLevel(logging.WARNING)

        # Get instruction (b64 takes precedence)
        if args.instruction_b64:
            instruction = base64.b64decode(args.instruction_b64).decode()
        elif args.instruction:
            instruction = args.instruction
        else:
            parser.error("--instruction or --instruction-b64 required")

        asyncio.run(_run_agent_cli(instruction, tools_path=args.tools_path))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
