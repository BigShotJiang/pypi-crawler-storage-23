"""REST API for SecretZero."""

from secretzero.api.app import create_app

__all__ = ["create_app"]
