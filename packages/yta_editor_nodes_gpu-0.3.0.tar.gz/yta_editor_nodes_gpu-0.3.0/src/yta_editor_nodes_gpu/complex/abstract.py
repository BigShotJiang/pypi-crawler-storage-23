class _NodeComplexGPU:
    """
    Just a class to be able to identify the children
    as complex nodes. These are nodes that are built
    by using different nodes in a specific way and 
    at the same time.
    """

    pass