from yta_video_opengl.opengl_nodes import _BaseAndOverlayTexturesOpenGLNode


class _NodeCompositorGPU(_BaseAndOverlayTexturesOpenGLNode):
    """
    Just a class to be able to identify the children
    as compositor nodes.
    """

    pass