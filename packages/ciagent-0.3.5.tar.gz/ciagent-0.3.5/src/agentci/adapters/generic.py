"""
Generic Python Function Adapter.
"""
from .base import BaseAdapter

class GenericAdapter(BaseAdapter):
    pass
