#!/usr/bin/env python3
"""
Smart Table CLI

Agent-friendly command-line helper for Smart Table API automation.

Features:
- Capabilities discovery
- Table and column management
- Row creation and cell patching
- Column run + estimate
- Table webhook token + ingest helpers
- Bulk-job polling
- Optional Mongo-backed status/watch helpers

Environment variables:
- SMARTTABLE_API_URL   (default: https://app.autotouch.ai)
- SMARTTABLE_TOKEN     (developer key or JWT bearer, or pass --token)
- MONGODB_URI          (for status when using direct DB aggregation)
- MONGODB_DB_NAME      (default: autotouch)
"""

from __future__ import annotations

import argparse
import csv
import getpass
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

try:
    from pymongo import MongoClient  # type: ignore
except Exception:  # pragma: no cover
    MongoClient = None  # type: ignore

try:
    from dotenv import load_dotenv  # type: ignore
except Exception:  # pragma: no cover
    load_dotenv = None  # type: ignore


DEFAULT_API_URL = "https://app.autotouch.ai"
DEFAULT_TIMEOUT_SECONDS = 30
TERMINAL_JOB_STATUSES = {
    "completed",
    "partial",
    "error",
    "cancelled",
    "failed",
    "completed_with_errors",
}
CONFIG_ENV_KEY = "AUTOTOUCH_CONFIG_PATH"
CONFIG_DIR_NAME = "autotouch"
CONFIG_FILE_NAME = "config.json"
OUTPUT_MODE = "json"
ANSI_PURPLE = "\033[38;5;141m"
ANSI_RESET = "\033[0m"
SETUP_BANNER = r"""
 █████  ██    ██ ████████  ██████  ████████  ██████  ██    ██  ██████ ██   ██
██   ██ ██    ██    ██    ██    ██    ██    ██    ██ ██    ██ ██      ██   ██
███████ ██    ██    ██    ██    ██    ██    ██    ██ ██    ██ ██      ███████
██   ██ ██    ██    ██    ██    ██    ██    ██    ██ ██    ██ ██      ██   ██
██   ██  ██████     ██     ██████     ██     ██████   ██████   ██████ ██   ██

                         AI CLI SETUP
"""

COLUMN_RECIPE_TYPES = [
    "email_finder",
    "phone_finder",
    "lead_finder",
    "llm_enrichment",
    "add_to_crm",
]

COLUMN_CREATE_RECIPES: Dict[str, Dict[str, Any]] = {
    "email_finder": {
        "key": "work_email",
        "label": "Work Email",
        "kind": "enrichment",
        "dataType": "json",
        "origin": "email_finder",
        "autoRun": "never",
        "config": {
            "provider": "smart_email_finder",
            "strategy": "cost_optimized",
            "lookupStrategy": "linkedin",
            "linkedinOnly": True,
            "enableProfileFallback": False,
            "linkedinUrl": "linkedin_url",
        },
    },
    "phone_finder": {
        "key": "mobile_phone",
        "label": "Mobile Phone",
        "kind": "enrichment",
        "dataType": "json",
        "origin": "phone_finder",
        "autoRun": "never",
        "config": {
            "provider": "smart_phone_finder",
            "firstName": "first_name",
            "lastName": "last_name",
            "company": "company",
            "linkedinUrl": "linkedin_url",
        },
    },
    "lead_finder": {
        "key": "lead_contacts",
        "label": "Lead Contacts",
        "kind": "enrichment",
        "dataType": "json",
        "origin": "ai",
        "autoRun": "never",
        "config": {
            "provider": "lead_finder",
            "sourceMode": "bulk_companies",
            "companyDomain": "domain",
            "strictness": "flexible_roles",
            "storeAsLeads": True,
            "autoEnrichEmails": True,
            "autoEnrichPhones": False,
            "jobTitles": ["Head of Sales", "VP Sales"],
            "locations": ["United States"],
            "maxResults": 10,
        },
    },
    "llm_enrichment": {
        "key": "company_research",
        "label": "Company Research",
        "kind": "enrichment",
        "dataType": "json",
        "origin": "ai",
        "autoRun": "never",
        "config": {
            "prompt": "Research this company and return JSON with icp_fit, summary, and risks.",
            "mode": "agent",
            "temperature": 0.7,
            "batchSize": 50,
            "promptSource": "manual",
            "structuredOutput": True,
            "useAutoSchema": True,
        },
    },
    "add_to_crm": {
        "key": "add_to_leads",
        "label": "Add to Leads",
        "kind": "enrichment",
        "dataType": "json",
        "origin": "manual",
        "autoRun": "onSourceUpdate",
        "config": {
            "provider": "add_to_crm",
            "leadSource": "research_table_export",
            "fieldMappings": {
                "mode": "single",
                "linkedinUrl": "linkedin_url",
                "companyDomain": "domain",
                "firstName": "first_name",
                "lastName": "last_name",
                "title": "title",
                "companyName": "company",
                "emailAddresses": [{"column": "work_email", "type": "work"}],
                "phoneNumbers": [{"column": "mobile_phone", "type": "mobile"}],
            },
            "sourceColumns": [
                "linkedin_url",
                "domain",
                "first_name",
                "last_name",
                "title",
                "company",
                "work_email",
                "mobile_phone",
            ],
        },
    },
}

COLUMN_RECIPE_NOTES: Dict[str, List[str]] = {
    "email_finder": [
        "For non-LinkedIn lookup, use lookupStrategy=domain/company with firstName+lastName+domain/company fields.",
    ],
    "phone_finder": [
        "You can use linkedinUrl or email/workEmail/personalEmail inputs.",
    ],
    "lead_finder": [
        "Add more targeting keys as needed (jobFunctions, seniorities, keywords, excludeKeywords, skills).",
    ],
    "llm_enrichment": [
        "Agent mode is JSON-oriented.",
        "Basic mode can be text or JSON; JSON requires dataType=json.",
    ],
    "add_to_crm": [
        "LinkedIn URL + company domain mappings are required for eligibility.",
        "Add to CRM is optional and non-billable.",
    ],
}

RUN_SOP_GUIDE: Dict[str, Any] = {
    "title": "Credit-safe enrichment SOP",
    "rules": [
        "Filter first before running billable columns.",
        "Estimate first with the same payload you plan to run.",
        "Start with a small firstN pilot before scaling.",
        "Keep unprocessedOnly enabled unless you intentionally reprocess rows.",
    ],
    "clarifications": [
        "Email/phone enrichment does not require add_to_crm.",
        "add_to_crm is an optional export action to Leads CRM (non-billable).",
    ],
    "default_run_payload": {
        "scope": "filtered",
        "filters": {
            "mode": "and",
            "filters": [
                {"columnKey": "linkedin_url", "operator": "isNotEmpty"},
                {"columnKey": "country", "operator": "equals", "value": "United States"},
            ],
        },
        "unprocessedOnly": True,
        "firstN": 25,
    },
}


def _load_env_files() -> None:
    if load_dotenv is None:
        return
    script_root = Path(__file__).resolve().parent.parent
    candidates = [Path.cwd() / ".env", script_root / ".env"]
    seen = set()
    for candidate in candidates:
        path = candidate.resolve()
        if path in seen:
            continue
        seen.add(path)
        if path.exists():
            load_dotenv(path, override=False)


_load_env_files()


def _config_path() -> Path:
    override = os.environ.get(CONFIG_ENV_KEY)
    if override:
        return Path(override).expanduser()
    xdg_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_home:
        return Path(xdg_home).expanduser() / CONFIG_DIR_NAME / CONFIG_FILE_NAME
    return Path.home() / ".config" / CONFIG_DIR_NAME / CONFIG_FILE_NAME


def _load_config() -> Dict[str, Any]:
    path = _config_path()
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _save_config(data: Dict[str, Any]) -> Path:
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return path


def _mask_api_key(value: Optional[str]) -> str:
    token = str(value or "").strip()
    if not token:
        return ""
    if len(token) <= 8:
        return "*" * len(token)
    return f"{token[:6]}...{token[-4:]}"


def _api_url(value: Optional[str] = None) -> str:
    if value:
        return str(value).rstrip("/")
    env_base = os.environ.get("SMARTTABLE_API_URL") or os.environ.get("AUTOTOUCH_API_URL")
    if env_base:
        return str(env_base).rstrip("/")
    cfg = _load_config()
    cfg_base = cfg.get("base_url")
    if cfg_base:
        return str(cfg_base).rstrip("/")
    return DEFAULT_API_URL.rstrip("/")


def _resolve_token(explicit_token: Optional[str], required: bool = True) -> Optional[str]:
    tok = (
        explicit_token
        or os.environ.get("SMARTTABLE_TOKEN")
        or os.environ.get("AUTOTOUCH_API_KEY")
        or os.environ.get("AUTOTOUCH_TOKEN")
    )
    if not tok:
        cfg = _load_config()
        tok = cfg.get("api_key")
    if not tok:
        if required:
            print(
                "ERROR: missing token. Pass --token, set SMARTTABLE_TOKEN/AUTOTOUCH_API_KEY, or run `autotouch auth set-key`.",
                file=sys.stderr,
            )
            sys.exit(2)
        return None
    return tok


def _auth_headers(token: Optional[str], use_x_api_key: bool = False) -> Dict[str, str]:
    if not token:
        return {}
    if use_x_api_key:
        return {"X-API-Key": token}
    return {"Authorization": f"Bearer {token}"}


def _set_output_mode(mode: Optional[str]) -> None:
    global OUTPUT_MODE
    normalized = str(mode or "json").strip().lower()
    OUTPUT_MODE = normalized if normalized in {"json", "human"} else "json"


def _supports_color() -> bool:
    return bool(sys.stdout.isatty()) and os.environ.get("NO_COLOR") is None


def _as_display(value: Any) -> str:
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (int, float, str)):
        return str(value)
    return json.dumps(value, default=str)


def _print_human(data: Any) -> None:
    if isinstance(data, dict):
        width = max((len(str(k)) for k in data.keys()), default=0)
        for key, value in data.items():
            print(f"{str(key).ljust(width)} : {_as_display(value)}")
        return
    if isinstance(data, list):
        if not data:
            print("No results.")
            return
        if all(isinstance(item, dict) for item in data):
            for idx, item in enumerate(data, 1):
                title = item.get("name") or item.get("title") or item.get("id") or f"item-{idx}"
                print(f"[{idx}] {title}")
                width = max((len(str(k)) for k in item.keys()), default=0)
                for key, value in item.items():
                    print(f"  {str(key).ljust(width)} : {_as_display(value)}")
                if idx < len(data):
                    print("")
            return
        for idx, item in enumerate(data, 1):
            print(f"{idx}. {_as_display(item)}")
        return
    print(_as_display(data))


def _print_json(data: Any, compact: bool = False) -> None:
    if OUTPUT_MODE == "human":
        _print_human(data)
        return
    if compact:
        print(json.dumps(data, separators=(",", ":"), default=str))
        return
    print(json.dumps(data, indent=2, default=str))


def _parse_json_string(raw: str, context: str) -> Any:
    try:
        return json.loads(raw)
    except Exception as exc:
        print(f"ERROR: invalid JSON for {context}: {exc}", file=sys.stderr)
        sys.exit(2)


def _load_json_input(
    *,
    inline_json: Optional[str],
    file_path: Optional[str],
    context: str,
    default: Any = None,
) -> Any:
    if inline_json and file_path:
        print(f"ERROR: pass either --{context}-json or --{context}-file, not both", file=sys.stderr)
        sys.exit(2)
    if inline_json:
        return _parse_json_string(inline_json, context)
    if file_path:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            print(f"ERROR: failed to read {context} file '{file_path}': {exc}", file=sys.stderr)
            sys.exit(2)
    return default


def _request_api(
    method: str,
    path: str,
    *,
    base_url: str,
    token: Optional[str],
    use_x_api_key: bool = False,
    params: Optional[Dict[str, Any]] = None,
    payload: Optional[Any] = None,
    extra_headers: Optional[Dict[str, str]] = None,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    verbose: bool = False,
) -> Any:
    url = f"{_api_url(base_url)}{path if path.startswith('/') else f'/{path}'}"
    headers = _auth_headers(token, use_x_api_key=use_x_api_key)
    if extra_headers:
        headers = {
            **headers,
            **{str(k): str(v) for k, v in extra_headers.items() if k and v is not None},
        }
    if verbose:
        print(f"[HTTP] {method.upper()} {url}", file=sys.stderr)
        if params:
            print(f"[HTTP] params={json.dumps(params, default=str)}", file=sys.stderr)
        if payload is not None:
            print(f"[HTTP] payload={json.dumps(payload, default=str)}", file=sys.stderr)

    try:
        response = requests.request(
            method=method.upper(),
            url=url,
            headers=headers,
            params=params,
            json=payload,
            timeout=max(1, int(timeout or DEFAULT_TIMEOUT_SECONDS)),
        )
    except requests.RequestException as exc:
        print(f"ERROR: request failed: {exc}", file=sys.stderr)
        sys.exit(1)

    content_type = response.headers.get("content-type", "").lower()
    body: Any
    if "application/json" in content_type:
        try:
            body = response.json()
        except Exception:
            body = response.text
    else:
        body = response.text

    if response.status_code >= 300:
        print(f"ERROR: API {response.status_code}", file=sys.stderr)
        if isinstance(body, (dict, list)):
            _print_json(body, compact=False)
        else:
            print(str(body), file=sys.stderr)
        sys.exit(1)
    return body


def _request_multipart_api(
    method: str,
    path: str,
    *,
    base_url: str,
    token: Optional[str],
    file_path: str,
    file_field: str = "file",
    form_fields: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    use_x_api_key: bool = False,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    verbose: bool = False,
) -> Any:
    url = f"{_api_url(base_url)}{path if path.startswith('/') else f'/{path}'}"
    headers = _auth_headers(token, use_x_api_key=use_x_api_key)
    form_payload = {
        str(k): (str(v).lower() if isinstance(v, bool) else str(v))
        for k, v in (form_fields or {}).items()
        if k is not None and v is not None
    }

    if verbose:
        print(f"[HTTP] {method.upper()} {url}", file=sys.stderr)
        if params:
            print(f"[HTTP] params={json.dumps(params, default=str)}", file=sys.stderr)
        if form_payload:
            print(f"[HTTP] form={json.dumps(form_payload, default=str)}", file=sys.stderr)

    try:
        with open(file_path, "rb") as f:
            files = {file_field: (Path(file_path).name, f, "text/csv")}
            response = requests.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                data=form_payload,
                files=files,
                timeout=max(1, int(timeout or DEFAULT_TIMEOUT_SECONDS)),
            )
    except FileNotFoundError:
        print(f"ERROR: file not found: {file_path}", file=sys.stderr)
        sys.exit(2)
    except requests.RequestException as exc:
        print(f"ERROR: request failed: {exc}", file=sys.stderr)
        sys.exit(1)

    content_type = response.headers.get("content-type", "").lower()
    body: Any
    if "application/json" in content_type:
        try:
            body = response.json()
        except Exception:
            body = response.text
    else:
        body = response.text

    if response.status_code >= 300:
        print(f"ERROR: API {response.status_code}", file=sys.stderr)
        if isinstance(body, (dict, list)):
            _print_json(body, compact=False)
        else:
            print(str(body), file=sys.stderr)
        sys.exit(1)
    return body


def _normalize_run_payload(args: argparse.Namespace) -> Dict[str, Any]:
    # If an explicit payload was provided, use it verbatim.
    explicit_payload = _load_json_input(
        inline_json=getattr(args, "data_json", None),
        file_path=getattr(args, "data_file", None),
        context="data",
        default=None,
    )
    if explicit_payload is not None:
        if not isinstance(explicit_payload, dict):
            print("ERROR: run payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        return explicit_payload

    scope = str(getattr(args, "scope", "all") or "all")
    payload: Dict[str, Any] = {"scope": scope}
    row_ids = [r.strip() for r in (getattr(args, "row_ids", None) or []) if r and str(r).strip()]

    if scope == "row":
        if getattr(args, "row_id", None):
            payload["rowIds"] = [str(args.row_id)]
        elif row_ids:
            payload["rowIds"] = [str(row_ids[0])]
        else:
            print("ERROR: --row-id or --row-ids is required for scope=row", file=sys.stderr)
            sys.exit(2)

    if scope == "subset":
        if not row_ids:
            print("ERROR: --row-ids required for scope=subset", file=sys.stderr)
            sys.exit(2)
        payload["rowIds"] = row_ids

    if scope == "firstN":
        first_n = getattr(args, "first_n", None)
        if not first_n or int(first_n) <= 0:
            print("ERROR: --first-n must be > 0 for scope=firstN", file=sys.stderr)
            sys.exit(2)
        payload["firstN"] = int(first_n)

    filters = _load_json_input(
        inline_json=getattr(args, "filters_json", None),
        file_path=getattr(args, "filters_file", None),
        context="filters",
        default=None,
    )
    if filters is not None:
        payload["filters"] = filters

    if getattr(args, "unprocessed_only", False):
        payload["unprocessedOnly"] = True

    return payload


def _resolve_column_key(
    *,
    table_id: str,
    column_id: str,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
) -> str:
    columns_raw = _request_api(
        "GET",
        f"/api/tables/{table_id}/columns",
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        verbose=verbose,
    )
    if isinstance(columns_raw, list):
        columns = columns_raw
    elif isinstance(columns_raw, dict):
        columns = columns_raw.get("columns") or columns_raw.get("items") or columns_raw.get("data") or []
    else:
        columns = []

    target = str(column_id)
    for col in columns:
        if not isinstance(col, dict):
            continue
        cid = str(col.get("id") or col.get("_id") or "")
        if cid != target:
            continue
        key = str(col.get("key") or "").strip()
        if key:
            return key
        break

    print(f"ERROR: failed to resolve column key for column_id={column_id}", file=sys.stderr)
    sys.exit(1)


def _is_processed_cell_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    if isinstance(value, (list, tuple, set, dict)):
        return len(value) > 0
    return True


def _select_next_row_ids(
    *,
    table_id: str,
    column_id: str,
    count: int,
    filters: Optional[Dict[str, Any]],
    unprocessed_only: bool,
    page_size: int,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
) -> Dict[str, Any]:
    if count <= 0:
        return {"row_ids": [], "requested": 0, "selected": 0, "scanned_rows": 0}

    column_key = _resolve_column_key(
        table_id=table_id,
        column_id=column_id,
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        verbose=verbose,
    )

    selected: List[str] = []
    seen: set[str] = set()
    scanned_rows = 0
    page_count = 0
    cursor: Optional[str] = None

    effective_page_size = max(1, min(int(page_size or 200), 1000))
    filters_payload = filters if isinstance(filters, dict) else None

    while len(selected) < count:
        page_count += 1
        params: Dict[str, Any] = {"page_size": effective_page_size}
        if cursor:
            params["cursor"] = cursor
        if filters_payload:
            params["filters"] = json.dumps(filters_payload, separators=(",", ":"))

        page = _request_api(
            "GET",
            f"/api/tables/{table_id}/rows",
            base_url=base_url,
            token=token,
            use_x_api_key=use_x_api_key,
            params=params,
            timeout=timeout,
            verbose=verbose,
        )
        if not isinstance(page, dict):
            print(f"ERROR: unexpected rows response: {page}", file=sys.stderr)
            sys.exit(1)

        rows = page.get("rows") or []
        if not isinstance(rows, list):
            print(f"ERROR: rows payload is not a list: {type(rows).__name__}", file=sys.stderr)
            sys.exit(1)

        for row in rows:
            if not isinstance(row, dict):
                continue
            scanned_rows += 1
            row_id = str(row.get("_id") or row.get("id") or row.get("rowId") or "").strip()
            if not row_id or row_id in seen:
                continue
            seen.add(row_id)

            if unprocessed_only and _is_processed_cell_value(row.get(column_key)):
                continue

            selected.append(row_id)
            if len(selected) >= count:
                break

        has_more = bool(page.get("hasMore") if "hasMore" in page else page.get("has_more"))
        next_cursor = page.get("nextCursor") if page.get("nextCursor") is not None else page.get("next_cursor")
        if len(selected) >= count:
            break
        if not has_more or not next_cursor:
            break
        cursor = str(next_cursor)

    return {
        "row_ids": selected,
        "requested": int(count),
        "selected": len(selected),
        "scanned_rows": scanned_rows,
        "pages_scanned": page_count,
        "column_key": column_key,
        "used_filters": bool(filters_payload),
        "unprocessed_only": bool(unprocessed_only),
    }


def _execute_run_flow(
    *,
    args: argparse.Namespace,
    token: str,
    payload: Dict[str, Any],
    context: Optional[Dict[str, Any]] = None,
) -> None:
    estimate_data: Optional[Dict[str, Any]] = None
    should_estimate = bool(args.show_estimate or args.max_credits is not None or args.dry_run)
    if should_estimate:
        estimate_raw = _request_api(
            "POST",
            f"/api/tables/{args.table_id}/columns/{args.column_id}/estimate",
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            payload=payload,
            timeout=args.timeout,
            verbose=args.verbose,
        )
        if not isinstance(estimate_raw, dict):
            print(f"ERROR: unexpected estimate response: {estimate_raw}", file=sys.stderr)
            sys.exit(1)
        estimate_data = estimate_raw

    if args.max_credits is not None:
        if estimate_data is None:
            print("ERROR: failed to compute estimate for --max-credits guard", file=sys.stderr)
            sys.exit(1)
        limit = float(args.max_credits)
        estimated_max = estimate_data.get("estimated_credits_max")
        estimated_min = float(estimate_data.get("estimated_credits_min") or 0.0)

        if estimated_max is None and not bool(args.allow_unknown_max):
            output = {
                "blocked": True,
                "reason": "estimated_credits_max is unknown; pass --allow-unknown-max to proceed",
                "max_credits_limit": limit,
                "estimate": estimate_data,
            }
            if context is not None:
                output["context"] = context
            _print_json(output, compact=args.compact)
            sys.exit(3)

        compare_value = float(estimated_max if estimated_max is not None else estimated_min)
        if compare_value > limit:
            output = {
                "blocked": True,
                "reason": "estimated credits exceed max-credits limit",
                "max_credits_limit": limit,
                "estimate_compare_value": compare_value,
                "estimate": estimate_data,
            }
            if context is not None:
                output["context"] = context
            _print_json(output, compact=args.compact)
            sys.exit(3)

    if args.dry_run:
        output = {
            "dry_run": True,
            "run_payload": payload,
            "estimate": estimate_data,
        }
        if context is not None:
            output["context"] = context
        _print_json(output, compact=args.compact)
        return

    run_data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns/{args.column_id}/run",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    if not isinstance(run_data, dict):
        output_non_dict: Any = run_data
        if context is not None:
            output_non_dict = {"context": context, "run": run_data}
        _print_json(output_non_dict, compact=args.compact)
        return

    if args.wait:
        job_id = run_data.get("job_id") or run_data.get("jobId")
        if not job_id:
            print("ERROR: run response missing job_id; cannot wait", file=sys.stderr)
            output = run_data if context is None else {"context": context, "run": run_data}
            _print_json(output, compact=args.compact)
            sys.exit(1)
        if not args.quiet_wait:
            _print_json(
                {
                    "job_id": str(job_id),
                    "status": "polling_started",
                    "hint": "polling /api/bulk-jobs/{job_id}",
                },
                compact=args.compact,
            )

        poll_result = _poll_job(
            job_id=str(job_id),
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            interval_seconds=int(args.poll_interval or 2),
            wait_timeout_seconds=int(args.wait_timeout or 0),
            request_timeout_seconds=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
            verbose=args.verbose,
            compact=args.compact,
            once=False,
            print_updates=not args.quiet_wait,
        )
        final_job = poll_result.get("job") or {}
        timed_out = bool(poll_result.get("timed_out"))
        output = {
            "run": run_data,
            "estimate": estimate_data if args.show_estimate or args.max_credits is not None else None,
            "final_job": final_job,
            "timed_out": timed_out,
            "polls": int(poll_result.get("polls") or 0),
        }
        if context is not None:
            output["context"] = context
        _print_json(output, compact=args.compact)

        if timed_out:
            sys.exit(4)
        final_status = str((final_job or {}).get("status") or "").lower()
        if args.fail_on_error and final_status in {"error", "cancelled"}:
            sys.exit(1)
        if args.fail_on_partial and final_status == "partial":
            sys.exit(1)
        return

    output_any: Any = run_data
    if estimate_data is not None and args.show_estimate:
        output_any = {"estimate": estimate_data, "run": run_data}
    if context is not None:
        output_any = {"context": context, "result": output_any}
    _print_json(output_any, compact=args.compact)


def _create_rows_and_patch_records(
    *,
    table_id: str,
    records: Optional[List[Dict[str, Any]]],
    blank_count: int,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
    detect_types: bool,
) -> Dict[str, Any]:
    created_row_ids: List[str] = []
    patch_updates: List[Dict[str, Any]] = []

    if records is not None:
        for idx, record in enumerate(records):
            if not isinstance(record, dict):
                print(f"ERROR: record at index {idx} is not a JSON object", file=sys.stderr)
                sys.exit(2)
            row_result = _request_api(
                "POST",
                f"/api/tables/{table_id}/rows",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                timeout=timeout,
                verbose=verbose,
            )
            row_id = (row_result or {}).get("rowId") if isinstance(row_result, dict) else None
            if not row_id:
                print(f"ERROR: row create response missing rowId: {row_result}", file=sys.stderr)
                sys.exit(1)
            row_id = str(row_id)
            created_row_ids.append(row_id)
            for key, value in record.items():
                patch_updates.append({"rowId": row_id, "key": str(key), "value": value})
    else:
        count = max(0, int(blank_count or 0))
        if count <= 0:
            print("ERROR: --count must be > 0", file=sys.stderr)
            sys.exit(2)
        for _ in range(count):
            row_result = _request_api(
                "POST",
                f"/api/tables/{table_id}/rows",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                timeout=timeout,
                verbose=verbose,
            )
            row_id = (row_result or {}).get("rowId") if isinstance(row_result, dict) else None
            if not row_id:
                print(f"ERROR: row create response missing rowId: {row_result}", file=sys.stderr)
                sys.exit(1)
            created_row_ids.append(str(row_id))

    patch_result: Optional[Any] = None
    if patch_updates:
        params = {"detect_types": "true"} if detect_types else None
        patch_result = _request_api(
            "PATCH",
            f"/api/tables/{table_id}/cells",
            base_url=base_url,
            token=token,
            use_x_api_key=use_x_api_key,
            payload={"updates": patch_updates},
            params=params,
            timeout=timeout,
            verbose=verbose,
        )

    return {
        "created": len(created_row_ids),
        "rowIds": created_row_ids,
        "updatedCells": len(patch_updates),
        "patchResult": patch_result,
    }


def _read_records_from_csv(
    file_path: str,
    *,
    delimiter: str = ",",
    encoding: str = "utf-8",
    trim_headers: bool = True,
    trim_values: bool = False,
    empty_as_null: bool = True,
    skip_empty_rows: bool = True,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    try:
        with open(file_path, "r", encoding=encoding, newline="") as f:
            reader = csv.DictReader(f, delimiter=delimiter)
            if not reader.fieldnames:
                print("ERROR: CSV file has no header row", file=sys.stderr)
                sys.exit(2)

            normalized_headers = []
            for header in reader.fieldnames:
                key = (header or "")
                key = key.strip() if trim_headers else key
                normalized_headers.append(key)
            reader.fieldnames = normalized_headers

            for raw_row in reader:
                row_obj: Dict[str, Any] = {}
                for key, value in (raw_row or {}).items():
                    col_key = str(key or "").strip() if trim_headers else str(key or "")
                    if not col_key:
                        continue
                    cell_value: Any = value
                    if isinstance(cell_value, str) and trim_values:
                        cell_value = cell_value.strip()
                    if empty_as_null and (cell_value is None or (isinstance(cell_value, str) and cell_value.strip() == "")):
                        cell_value = None
                    row_obj[col_key] = cell_value

                if skip_empty_rows:
                    has_value = any(
                        value is not None and (not isinstance(value, str) or value.strip() != "")
                        for value in row_obj.values()
                    )
                    if not has_value:
                        continue

                records.append(row_obj)
                if limit is not None and limit > 0 and len(records) >= limit:
                    break
    except FileNotFoundError:
        print(f"ERROR: CSV file not found: {file_path}", file=sys.stderr)
        sys.exit(2)
    except Exception as exc:
        print(f"ERROR: failed to read CSV '{file_path}': {exc}", file=sys.stderr)
        sys.exit(2)
    return records


def _job_snapshot(job_doc: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "job_id": job_doc.get("job_id") or job_doc.get("jobId"),
        "status": job_doc.get("status"),
        "provider": job_doc.get("provider"),
        "processed_rows": int(job_doc.get("processed_rows") or 0),
        "total_rows": int(job_doc.get("total_rows") or 0),
        "error_rows": int(job_doc.get("error_rows") or 0),
        "credits_used": float(job_doc.get("credits_used") or 0.0),
        "billable": bool(job_doc.get("billable", False)),
        "updated_at": job_doc.get("updated_at"),
    }


def _poll_job(
    *,
    job_id: str,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    interval_seconds: int,
    wait_timeout_seconds: int,
    request_timeout_seconds: int,
    verbose: bool,
    compact: bool,
    once: bool = False,
    print_updates: bool = True,
) -> Dict[str, Any]:
    interval = max(1, int(interval_seconds or 2))
    max_wait = max(0, int(wait_timeout_seconds or 0))
    started = time.monotonic()
    polls = 0
    heartbeat_every_polls = 5
    max_consecutive_poll_errors = 6
    consecutive_poll_errors = 0
    last_status: Optional[str] = None
    url = f"{_api_url(base_url)}/api/bulk-jobs/{job_id}"
    headers = _auth_headers(token, use_x_api_key=use_x_api_key)

    while True:
        polls += 1
        if verbose:
            print(f"[HTTP] GET {url}", file=sys.stderr)
        try:
            response = requests.get(
                url,
                headers=headers,
                timeout=max(1, int(request_timeout_seconds or DEFAULT_TIMEOUT_SECONDS)),
            )
        except requests.RequestException as exc:
            consecutive_poll_errors += 1
            if print_updates and (consecutive_poll_errors == 1 or consecutive_poll_errors % 3 == 0):
                _print_json(
                    {
                        "job_id": job_id,
                        "status": "polling_error",
                        "polls": polls,
                        "consecutive_errors": consecutive_poll_errors,
                        "error": str(exc),
                    },
                    compact=compact,
                )
            if max_wait > 0 and (time.monotonic() - started) >= max_wait:
                return {
                    "job": {"job_id": job_id, "status": "polling_error", "error": str(exc)},
                    "polls": polls,
                    "timed_out": True,
                }
            if consecutive_poll_errors >= max_consecutive_poll_errors:
                print(
                    f"ERROR: polling job {job_id} failed repeatedly ({consecutive_poll_errors} consecutive errors)",
                    file=sys.stderr,
                )
                sys.exit(1)
            time.sleep(interval)
            continue

        if response.status_code >= 500:
            consecutive_poll_errors += 1
            if print_updates and (consecutive_poll_errors == 1 or consecutive_poll_errors % 3 == 0):
                _print_json(
                    {
                        "job_id": job_id,
                        "status": "polling_error",
                        "polls": polls,
                        "consecutive_errors": consecutive_poll_errors,
                        "error": f"server_error_{response.status_code}",
                    },
                    compact=compact,
                )
            if max_wait > 0 and (time.monotonic() - started) >= max_wait:
                return {
                    "job": {
                        "job_id": job_id,
                        "status": "polling_error",
                        "error": f"server_error_{response.status_code}",
                    },
                    "polls": polls,
                    "timed_out": True,
                }
            if consecutive_poll_errors >= max_consecutive_poll_errors:
                print(
                    f"ERROR: polling job {job_id} returned repeated server errors ({response.status_code})",
                    file=sys.stderr,
                )
                sys.exit(1)
            time.sleep(interval)
            continue

        consecutive_poll_errors = 0

        if response.status_code == 404 and not once:
            job_doc = {
                "job_id": job_id,
                "status": "queued",
                "provider": None,
                "processed_rows": 0,
                "total_rows": 0,
                "error_rows": 0,
                "credits_used": 0.0,
                "billable": False,
                "updated_at": None,
            }
        else:
            content_type = response.headers.get("content-type", "").lower()
            if "application/json" in content_type:
                try:
                    parsed_body: Any = response.json()
                except Exception:
                    parsed_body = response.text
            else:
                parsed_body = response.text

            if response.status_code >= 300:
                print(f"ERROR: API {response.status_code}", file=sys.stderr)
                if isinstance(parsed_body, (dict, list)):
                    _print_json(parsed_body, compact=False)
                else:
                    print(str(parsed_body), file=sys.stderr)
                sys.exit(1)

            if not isinstance(parsed_body, dict):
                print(f"ERROR: unexpected bulk job response: {parsed_body}", file=sys.stderr)
                sys.exit(1)
            job_doc = parsed_body

        status = str(job_doc.get("status") or "").lower()
        snapshot = _job_snapshot(job_doc)
        snapshot["polls"] = polls
        snapshot["elapsed_seconds"] = int(max(0.0, time.monotonic() - started))

        should_print = print_updates and (
            once
            or polls == 1
            or status != last_status
            or (polls % heartbeat_every_polls == 0)
        )
        if should_print:
            _print_json(snapshot, compact=compact)
        last_status = status

        if once:
            return {"job": job_doc, "polls": polls, "timed_out": False}
        if status in TERMINAL_JOB_STATUSES:
            return {"job": job_doc, "polls": polls, "timed_out": False}
        if max_wait > 0 and (time.monotonic() - started) >= max_wait:
            return {"job": job_doc, "polls": polls, "timed_out": True}

        time.sleep(interval)


def _poll_import_status(
    *,
    table_id: str,
    task_id: str,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    interval_seconds: int,
    wait_timeout_seconds: int,
    request_timeout_seconds: int,
    verbose: bool,
    compact: bool,
) -> Dict[str, Any]:
    interval = max(1, int(interval_seconds or 2))
    max_wait = max(0, int(wait_timeout_seconds or 0))
    started = time.monotonic()
    polls = 0
    last_signature: Optional[str] = None

    while True:
        polls += 1
        status_body = _request_api(
            "GET",
            f"/api/tables/{table_id}/import-status/{task_id}",
            base_url=base_url,
            token=token,
            use_x_api_key=use_x_api_key,
            timeout=request_timeout_seconds,
            verbose=verbose,
        )

        if not isinstance(status_body, dict):
            print(f"ERROR: unexpected import status response: {status_body}", file=sys.stderr)
            sys.exit(1)

        status = str(status_body.get("status") or "").lower()
        signature = json.dumps(
            {
                "status": status,
                "progress": status_body.get("progress"),
                "total": status_body.get("total"),
                "progress_percent": status_body.get("progress_percent"),
                "stage": status_body.get("stage"),
                "message": status_body.get("message"),
            },
            sort_keys=True,
            default=str,
        )

        if signature != last_signature:
            _print_json(status_body, compact=compact)
            last_signature = signature

        if status in {"completed", "failed"}:
            return {"status": status_body, "polls": polls, "timed_out": False}
        if max_wait > 0 and (time.monotonic() - started) >= max_wait:
            return {"status": status_body, "polls": polls, "timed_out": True}

        time.sleep(interval)


def _print_setup_banner() -> None:
    banner = SETUP_BANNER.rstrip()
    if _supports_color():
        for line in banner.splitlines():
            if line.strip():
                print(f"{ANSI_PURPLE}{line}{ANSI_RESET}")
            else:
                print("")
    else:
        print(banner)
    print("Preview: configure your key once, then drive Smart Table from CLI or agents.")
    print("")


def _resolve_setup_api_key(args: argparse.Namespace) -> str:
    explicit = str(getattr(args, "api_key", "") or "").strip()
    if explicit:
        return explicit
    env_token = (
        os.environ.get("SMARTTABLE_TOKEN")
        or os.environ.get("AUTOTOUCH_API_KEY")
        or os.environ.get("AUTOTOUCH_TOKEN")
    )
    if env_token:
        return str(env_token).strip()

    cfg = _load_config()
    existing = str(cfg.get("api_key") or "").strip()
    if existing:
        return existing

    if sys.stdin.isatty():
        entered = getpass.getpass("Paste developer API key (stk_...): ").strip()
        if entered:
            return entered

    print(
        "ERROR: missing api key. Pass --api-key, set AUTOTOUCH_API_KEY, or run interactively.",
        file=sys.stderr,
    )
    sys.exit(2)


def cmd_setup(args: argparse.Namespace) -> None:
    if OUTPUT_MODE == "human" and not args.no_banner:
        _print_setup_banner()

    cfg = _load_config()
    existing_key = str(cfg.get("api_key") or "").strip()
    api_key = _resolve_setup_api_key(args)
    base_url = str(args.base_url or cfg.get("base_url") or _api_url()).rstrip("/")

    if existing_key and existing_key != api_key and not args.overwrite:
        print(
            "ERROR: config already has an API key. Pass --overwrite to replace it.",
            file=sys.stderr,
        )
        sys.exit(2)

    capabilities = _request_api(
        "GET",
        "/api/capabilities",
        base_url=base_url,
        token=api_key,
        use_x_api_key=bool(args.use_x_api_key),
        timeout=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
        verbose=bool(args.verbose),
    )

    cfg["api_key"] = api_key
    cfg["base_url"] = base_url
    cfg["updated_at_epoch"] = int(time.time())
    path = _save_config(cfg)

    output = {
        "setup_complete": True,
        "base_url": base_url,
        "auth_header_mode": "x-api-key" if args.use_x_api_key else "authorization",
        "config_path": str(path),
        "api_key_masked": _mask_api_key(api_key),
        "api_version": capabilities.get("api_version") if isinstance(capabilities, dict) else None,
        "recommended_next_steps": [
            "autotouch capabilities --output human",
            "autotouch tables create --name \"CLI Contacts\" --output human",
            "autotouch rows import-csv --table-id <TABLE_ID> --file contacts.csv --detect-types",
            "autotouch columns run --table-id <TABLE_ID> --column-id <COLUMN_ID> --scope all --show-estimate --wait",
        ],
    }

    if OUTPUT_MODE == "human":
        print("✓ Key validated")
        print(f"✓ Config saved: {path}")
        print(f"✓ Base URL: {base_url}")
        print("")
        print("Next steps:")
        for line in output["recommended_next_steps"]:
            print(f"  {line}")
        return

    _print_json(output, compact=args.compact)


def cmd_auth_check(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    body = _request_api(
        "GET",
        "/api/capabilities",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    output = {
        "ok": True,
        "base_url": _api_url(args.base_url),
        "api_version": body.get("api_version") if isinstance(body, dict) else None,
        "auth_header_mode": "x-api-key" if args.use_x_api_key else "authorization",
    }
    _print_json(output, compact=args.compact)


def cmd_auth_set_key(args: argparse.Namespace) -> None:
    api_key = (args.api_key or "").strip() if getattr(args, "api_key", None) else None
    if not api_key:
        api_key = _resolve_token(None, required=False)
    if not api_key:
        print("ERROR: missing api key. Pass --api-key or set AUTOTOUCH_API_KEY/SMARTTABLE_TOKEN.", file=sys.stderr)
        sys.exit(2)

    cfg = _load_config()
    if cfg.get("api_key") and not args.overwrite:
        print(
            "ERROR: config already has an API key. Pass --overwrite to replace it.",
            file=sys.stderr,
        )
        sys.exit(2)

    base_url = str(args.base_url or cfg.get("base_url") or _api_url()).rstrip("/")
    cfg["api_key"] = api_key
    cfg["base_url"] = base_url
    cfg["updated_at_epoch"] = int(time.time())
    path = _save_config(cfg)

    _print_json(
        {
            "saved": True,
            "config_path": str(path),
            "base_url": base_url,
            "api_key_masked": _mask_api_key(api_key),
        },
        compact=args.compact,
    )


def cmd_auth_show(args: argparse.Namespace) -> None:
    cfg = _load_config()
    api_key = str(cfg.get("api_key") or "").strip()
    base_url = str(cfg.get("base_url") or _api_url()).rstrip("/")
    path = _config_path()
    output = {
        "config_path": str(path),
        "config_exists": path.exists(),
        "has_api_key": bool(api_key),
        "api_key_masked": _mask_api_key(api_key) if api_key else None,
        "base_url": base_url,
        "updated_at_epoch": cfg.get("updated_at_epoch"),
    }
    _print_json(output, compact=args.compact)


def cmd_auth_clear(args: argparse.Namespace) -> None:
    cfg = _load_config()
    changed = False
    if args.all:
        cfg = {}
        changed = True
    else:
        if "api_key" in cfg:
            cfg.pop("api_key", None)
            changed = True
        if args.clear_base_url and "base_url" in cfg:
            cfg.pop("base_url", None)
            changed = True
        if "updated_at_epoch" in cfg:
            cfg["updated_at_epoch"] = int(time.time())
            changed = True

    path = _save_config(cfg) if changed else _config_path()
    _print_json(
        {
            "cleared": changed,
            "config_path": str(path),
            "remaining_keys": sorted(list(cfg.keys())),
        },
        compact=args.compact,
    )


def cmd_capabilities(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "GET",
        "/api/capabilities",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    if OUTPUT_MODE == "human" and isinstance(data, dict):
        execution = data.get("execution_policies") if isinstance(data.get("execution_policies"), dict) else {}
        llm = execution.get("llm") if isinstance(execution.get("llm"), dict) else {}
        output_contract = llm.get("output_contract") if isinstance(llm.get("output_contract"), dict) else {}
        agent_contract = output_contract.get("agent") if isinstance(output_contract.get("agent"), dict) else {}
        basic_contract = output_contract.get("basic") if isinstance(output_contract.get("basic"), dict) else {}

        print(f"API version : {_as_display(data.get('api_version'))}")
        print(f"Base URL    : {_as_display(data.get('base_url'))}")

        auth = data.get("authentication") if isinstance(data.get("authentication"), dict) else {}
        scopes = auth.get("scopes")
        if isinstance(scopes, list):
            print(f"Scopes      : {', '.join(str(s) for s in scopes)}")

        print("")
        print("LLM output modes")
        print("----------------")
        print(
            "agent : JSON-oriented structured output"
            + (
                f" (default_data_type={agent_contract.get('default_data_type')})"
                if agent_contract.get("default_data_type")
                else ""
            )
        )
        basic_types = basic_contract.get("supported_data_types")
        basic_types_str = ", ".join(str(t) for t in basic_types) if isinstance(basic_types, list) else "text/json"
        print(f"basic : {basic_types_str} (JSON requires dataType=json)")
        print("")
        print("Tip: use `autotouch columns projections` + formatter columns for JSON pipeline chaining.")
        return

    _print_json(data, compact=args.compact)


def _recipe_payload(recipe_type: str) -> Dict[str, Any]:
    payload = COLUMN_CREATE_RECIPES.get(recipe_type)
    if not payload:
        print(f"ERROR: unsupported recipe type '{recipe_type}'", file=sys.stderr)
        sys.exit(2)
    # Safe deep copy for mutable nested payloads.
    return json.loads(json.dumps(payload))


def cmd_columns_recipe(args: argparse.Namespace) -> None:
    selected_type = str(args.type or "all")
    if selected_type == "all":
        recipes = {name: _recipe_payload(name) for name in COLUMN_RECIPE_TYPES}
        output = {
            "recipes": recipes,
            "notes": COLUMN_RECIPE_NOTES,
            "usage": "autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>",
        }
        if args.out_file:
            with open(args.out_file, "w", encoding="utf-8") as f:
                json.dump(output, f, indent=2)
        if OUTPUT_MODE == "human":
            print("Column create payload recipes")
            print("-----------------------------")
            for name in COLUMN_RECIPE_TYPES:
                print(f"\n[{name}]")
                print(json.dumps(recipes[name], indent=2))
                notes = COLUMN_RECIPE_NOTES.get(name) or []
                for note in notes:
                    print(f"- {note}")
            print("\nUse with:")
            print("autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>")
            if args.out_file:
                print(f"\nSaved: {args.out_file}")
            return
        _print_json(output, compact=args.compact)
        return

    payload = _recipe_payload(selected_type)
    output_single = {
        "type": selected_type,
        "payload": payload,
        "notes": COLUMN_RECIPE_NOTES.get(selected_type) or [],
        "usage": "autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>",
    }
    if args.out_file:
        with open(args.out_file, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)

    if OUTPUT_MODE == "human":
        print(f"{selected_type} payload")
        print("----------------")
        print(json.dumps(payload, indent=2))
        notes = COLUMN_RECIPE_NOTES.get(selected_type) or []
        if notes:
            print("")
            for note in notes:
                print(f"- {note}")
        print("\nUse with:")
        print("autotouch columns create --table-id <TABLE_ID> --data-file <payload.json>")
        if args.out_file:
            print(f"\nSaved payload file: {args.out_file}")
        return

    _print_json(output_single, compact=args.compact)


def cmd_sop(args: argparse.Namespace) -> None:
    if args.out_file:
        with open(args.out_file, "w", encoding="utf-8") as f:
            json.dump(RUN_SOP_GUIDE, f, indent=2)

    if OUTPUT_MODE == "human":
        print(RUN_SOP_GUIDE["title"])
        print("-" * len(RUN_SOP_GUIDE["title"]))
        print("Rules:")
        for idx, rule in enumerate(RUN_SOP_GUIDE["rules"], start=1):
            print(f"{idx}. {rule}")
        print("\nClarifications:")
        for note in RUN_SOP_GUIDE["clarifications"]:
            print(f"- {note}")
        print("\nDefault run payload:")
        print(json.dumps(RUN_SOP_GUIDE["default_run_payload"], indent=2))
        if args.out_file:
            print(f"\nSaved: {args.out_file}")
        return

    _print_json(RUN_SOP_GUIDE, compact=args.compact)


def cmd_tables_list(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    params: Dict[str, Any] = {}
    if args.view_mode:
        params["view_mode"] = args.view_mode
    data = _request_api(
        "GET",
        "/api/tables",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        params=params or None,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_tables_create(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data_payload = _load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if data_payload is not None:
        if not isinstance(data_payload, dict):
            print("ERROR: table create payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        payload = data_payload
    else:
        if not args.name:
            print("ERROR: --name is required when --data-* is not provided", file=sys.stderr)
            sys.exit(2)
        metadata = _load_json_input(
            inline_json=args.metadata_json,
            file_path=args.metadata_file,
            context="metadata",
            default={},
        )
        if metadata is None:
            metadata = {}
        if not isinstance(metadata, dict):
            print("ERROR: metadata must be a JSON object", file=sys.stderr)
            sys.exit(2)
        payload = {"name": args.name, "metadata": metadata}

    data = _request_api(
        "POST",
        "/api/tables",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_rows_add(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    records_payload = _load_json_input(
        inline_json=args.records_json,
        file_path=args.records_file,
        context="records",
        default=None,
    )

    if records_payload is not None:
        records: List[Dict[str, Any]]
        if isinstance(records_payload, dict):
            if isinstance(records_payload.get("records"), list):
                records = records_payload.get("records")  # type: ignore[assignment]
            else:
                records = [records_payload]
        elif isinstance(records_payload, list):
            records = records_payload
        else:
            print("ERROR: records payload must be an object, list, or {records:[...]}", file=sys.stderr)
            sys.exit(2)

    else:
        records = None

    output = _create_rows_and_patch_records(
        table_id=args.table_id,
        records=records,
        blank_count=int(args.count or 1),
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
        detect_types=bool(args.detect_types),
    )
    _print_json(output, compact=args.compact)


def cmd_rows_delete(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "DELETE",
        f"/api/tables/{args.table_id}/rows/{args.row_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_rows_import_csv(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    transport = str(getattr(args, "transport", "optimized") or "optimized").strip().lower()

    if transport == "direct":
        records = _read_records_from_csv(
            args.file,
            delimiter=args.delimiter,
            encoding=args.encoding,
            trim_headers=bool(args.trim_headers),
            trim_values=bool(args.trim_values),
            empty_as_null=bool(args.empty_as_null),
            skip_empty_rows=bool(args.skip_empty_rows),
            limit=(int(args.limit) if args.limit else None),
        )
        if not records:
            output = {
                "created": 0,
                "rowIds": [],
                "updatedCells": 0,
                "patchResult": None,
                "recordsParsed": 0,
                "source": args.file,
            }
            _print_json(output, compact=args.compact)
            return

        output = _create_rows_and_patch_records(
            table_id=args.table_id,
            records=records,
            blank_count=0,
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            timeout=args.timeout,
            verbose=args.verbose,
            detect_types=bool(args.detect_types),
        )
        output["recordsParsed"] = len(records)
        output["source"] = args.file
        output["transport"] = "direct"
        _print_json(output, compact=args.compact)
        return

    field_mappings = _load_json_input(
        inline_json=getattr(args, "field_mappings_json", None),
        file_path=getattr(args, "field_mappings_file", None),
        context="field-mappings",
        default=None,
    )
    if field_mappings is not None and not isinstance(field_mappings, dict):
        print("ERROR: field mappings must be a JSON object", file=sys.stderr)
        sys.exit(2)

    form_fields: Dict[str, Any] = {
        "origin": str(getattr(args, "origin", "csv") or "csv"),
        "check_company_blacklist": bool(getattr(args, "check_company_blacklist", True)),
        "check_email_blacklist": bool(getattr(args, "check_email_blacklist", False)),
    }
    if field_mappings is not None:
        form_fields["field_mappings"] = json.dumps(field_mappings)

    use_async = bool(getattr(args, "use_async", True))
    params = {"use_async": "true" if use_async else "false"}
    response = _request_multipart_api(
        "POST",
        f"/api/tables/{args.table_id}/import-optimized",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        file_path=args.file,
        file_field="file",
        form_fields=form_fields,
        params=params,
        timeout=args.timeout,
        verbose=args.verbose,
    )

    # Sync optimized path returns final payload directly.
    if not use_async:
        if isinstance(response, dict):
            response["transport"] = "optimized-sync"
        _print_json(response, compact=args.compact)
        return

    # Async path returns a task_id; optionally wait via status endpoint.
    if not isinstance(response, dict):
        _print_json(response, compact=args.compact)
        return

    task_id = response.get("task_id") or response.get("taskId")
    if not task_id:
        _print_json(response, compact=args.compact)
        return

    if not getattr(args, "wait", False):
        response["transport"] = "optimized-async"
        response["next"] = f"autotouch rows import-status --table-id {args.table_id} --task-id {task_id}"
        _print_json(response, compact=args.compact)
        return

    poll_result = _poll_import_status(
        table_id=args.table_id,
        task_id=str(task_id),
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        interval_seconds=int(args.poll_interval or 2),
        wait_timeout_seconds=int(args.wait_timeout or 0),
        request_timeout_seconds=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
        verbose=args.verbose,
        compact=args.compact,
    )
    final_status = poll_result.get("status") or {}
    timed_out = bool(poll_result.get("timed_out"))
    output = {
        "transport": "optimized-async",
        "task_id": str(task_id),
        "queued": response,
        "final_status": final_status,
        "timed_out": timed_out,
        "polls": int(poll_result.get("polls") or 0),
    }
    _print_json(output, compact=args.compact)

    if timed_out:
        sys.exit(4)
    if str((final_status or {}).get("status") or "").lower() == "failed":
        sys.exit(1)


def cmd_rows_import_status(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    if getattr(args, "wait", False):
        poll_result = _poll_import_status(
            table_id=args.table_id,
            task_id=args.task_id,
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            interval_seconds=int(args.poll_interval or 2),
            wait_timeout_seconds=int(args.wait_timeout or 0),
            request_timeout_seconds=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
            verbose=args.verbose,
            compact=args.compact,
        )
        final_status = poll_result.get("status") or {}
        timed_out = bool(poll_result.get("timed_out"))
        output = {
            "task_id": args.task_id,
            "final_status": final_status,
            "timed_out": timed_out,
            "polls": int(poll_result.get("polls") or 0),
        }
        _print_json(output, compact=args.compact)
        if timed_out:
            sys.exit(4)
        if str((final_status or {}).get("status") or "").lower() == "failed":
            sys.exit(1)
        return

    data = _request_api(
        "GET",
        f"/api/tables/{args.table_id}/import-status/{args.task_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_cells_patch(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=args.updates_json,
        file_path=args.updates_file,
        context="updates",
        default=None,
    )
    if payload is None:
        print("ERROR: provide --updates-json or --updates-file", file=sys.stderr)
        sys.exit(2)
    if isinstance(payload, list):
        payload = {"updates": payload}
    if not isinstance(payload, dict) or not isinstance(payload.get("updates"), list):
        print("ERROR: updates payload must be a list or an object with an 'updates' list", file=sys.stderr)
        sys.exit(2)

    params = {"detect_types": "true"} if args.detect_types else None
    data = _request_api(
        "PATCH",
        f"/api/tables/{args.table_id}/cells",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        params=params,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_list(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "GET",
        f"/api/tables/{args.table_id}/columns",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_create(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if not isinstance(payload, dict):
        print("ERROR: column create requires --data-json/--data-file with a JSON object", file=sys.stderr)
        sys.exit(2)
    data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_update(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if not isinstance(payload, dict):
        print("ERROR: column update requires --data-json/--data-file with a JSON object", file=sys.stderr)
        sys.exit(2)
    data = _request_api(
        "PATCH",
        f"/api/tables/{args.table_id}/columns/{args.column_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_projections(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if not isinstance(payload, dict):
        print("ERROR: projection create requires --data-json/--data-file with a JSON object", file=sys.stderr)
        sys.exit(2)
    data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns/projections",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_run(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _normalize_run_payload(args)
    _execute_run_flow(args=args, token=token, payload=payload, context=None)


def cmd_columns_run_next(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    requested_count = int(args.count or 0)
    if requested_count <= 0:
        print("ERROR: --count must be > 0", file=sys.stderr)
        sys.exit(2)

    filters = _load_json_input(
        inline_json=getattr(args, "filters_json", None),
        file_path=getattr(args, "filters_file", None),
        context="filters",
        default=None,
    )
    if filters is not None and not isinstance(filters, dict):
        print("ERROR: filters payload must be a JSON object", file=sys.stderr)
        sys.exit(2)

    selection = _select_next_row_ids(
        table_id=args.table_id,
        column_id=args.column_id,
        count=requested_count,
        filters=filters,
        unprocessed_only=bool(args.unprocessed_only),
        page_size=int(args.page_size or 200),
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    row_ids = selection.get("row_ids") or []
    if not row_ids:
        output = {
            "queued": False,
            "reason": "no eligible rows found for run-next selection",
            "selection": selection,
        }
        _print_json(output, compact=args.compact)
        if args.fail_if_empty:
            sys.exit(3)
        return

    payload: Dict[str, Any] = {"scope": "subset", "rowIds": row_ids}
    if args.unprocessed_only:
        payload["unprocessedOnly"] = True

    context = {
        "mode": "run-next",
        "selection": {k: v for k, v in selection.items() if k != "row_ids"},
        "row_ids": row_ids,
    }
    _execute_run_flow(args=args, token=token, payload=payload, context=context)


def cmd_columns_estimate(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _normalize_run_payload(args)
    data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns/{args.column_id}/estimate",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_jobs_get(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "GET",
        f"/api/bulk-jobs/{args.job_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_jobs_watch(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    poll_result = _poll_job(
        job_id=args.job_id,
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        interval_seconds=int(args.interval or 2),
        wait_timeout_seconds=int(args.wait_timeout or 0),
        request_timeout_seconds=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
        verbose=args.verbose,
        compact=args.compact,
        once=bool(args.once),
        print_updates=True,
    )
    final_job = poll_result.get("job") or {}
    timed_out = bool(poll_result.get("timed_out"))

    if args.once:
        return

    final_summary = {
        "job_id": final_job.get("job_id") or final_job.get("jobId") or args.job_id,
        "status": final_job.get("status"),
        "timed_out": timed_out,
        "polls": int(poll_result.get("polls") or 0),
    }
    _print_json(final_summary, compact=args.compact)

    if timed_out:
        sys.exit(4)
    status = str(final_job.get("status") or "").lower()
    if args.fail_on_error and status in {"error", "cancelled"}:
        sys.exit(1)
    if args.fail_on_partial and status == "partial":
        sys.exit(1)


def cmd_webhooks_get(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "GET",
        f"/api/tables/{args.table_id}/webhook",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_webhooks_rotate(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/webhook",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_webhooks_ingest(args: argparse.Namespace) -> None:
    payload = _load_json_input(
        inline_json=args.records_json,
        file_path=args.records_file,
        context="records",
        default=None,
    )
    if payload is None:
        print("ERROR: provide --records-json or --records-file", file=sys.stderr)
        sys.exit(2)

    webhook_token = (
        str(args.webhook_token or "").strip()
        or str(os.environ.get("AUTOTOUCH_WEBHOOK_TOKEN") or "").strip()
        or str(os.environ.get("SMARTTABLE_WEBHOOK_TOKEN") or "").strip()
    )
    if not webhook_token:
        print(
            "ERROR: missing webhook token. Pass --webhook-token or set AUTOTOUCH_WEBHOOK_TOKEN.",
            file=sys.stderr,
        )
        sys.exit(2)

    data = _request_api(
        "POST",
        f"/api/webhooks/tables/{args.table_id}/ingest",
        base_url=args.base_url,
        token=None,
        payload=payload,
        extra_headers={"x-autotouch-token": webhook_token},
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def _mongo_client(uri: Optional[str], db_name: Optional[str]):
    if MongoClient is None:
        print("ERROR: pymongo not installed. Install requirements and retry.", file=sys.stderr)
        sys.exit(2)
    _uri = uri or os.environ.get("MONGODB_URI")
    if not _uri:
        print("ERROR: MONGODB_URI not set. Export MONGODB_URI or pass --mongo-uri", file=sys.stderr)
        sys.exit(2)
    _db = (db_name or os.environ.get("MONGODB_DB_NAME") or "autotouch")
    client = MongoClient(_uri)
    return client[_db]


def _status_counts(db, table_id: str, column_id: str) -> Dict[str, int]:
    row_ids = [str(r["_id"]) for r in db["rows"].find({"table_id": table_id}, {"_id": 1})]
    if not row_ids:
        return {"pending": 0, "done": 0, "error": 0}
    pipeline = [
        {"$match": {"column_id": column_id, "row_id": {"$in": row_ids}}},
        {"$group": {"_id": {"$ifNull": ["$status", "missing"]}, "count": {"$sum": 1}}},
    ]
    res = list(db["cells"].aggregate(pipeline))
    m = {d.get("_id"): int(d.get("count") or 0) for d in res}
    for k in ("pending", "done", "error"):
        m.setdefault(k, 0)
    return {k: m[k] for k in ("pending", "done", "error")}


def cmd_status(args: argparse.Namespace) -> None:
    db = _mongo_client(args.mongo_uri, args.db_name)
    counts = _status_counts(db, args.table_id, args.column_id)
    total = sum(counts.values())
    _print_json(
        {"pending": counts["pending"], "done": counts["done"], "error": counts["error"], "totalCells": total},
        compact=False,
    )


def cmd_watch(args: argparse.Namespace) -> None:
    db = _mongo_client(args.mongo_uri, args.db_name)
    interval = max(1, int(args.interval or 5))
    try:
        while True:
            counts = _status_counts(db, args.table_id, args.column_id)
            total = sum(counts.values())
            print(f"pending={counts['pending']} done={counts['done']} error={counts['error']} total={total}")
            sys.stdout.flush()
            time.sleep(interval)
    except KeyboardInterrupt:
        pass


def _add_api_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--base-url", default=_api_url(), help=f"API base URL (default: {DEFAULT_API_URL})")
    parser.add_argument("--token", help="Developer API key / JWT token")
    parser.add_argument("--use-x-api-key", action="store_true", help="Send token via X-API-Key header")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="HTTP timeout in seconds")
    parser.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    parser.add_argument("--compact", action="store_true", help="Print compact JSON")
    parser.add_argument("--verbose", action="store_true", help="Print request metadata to stderr")


def _add_run_scope_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--scope", choices=["all", "subset", "row", "firstN", "filtered"], default="all")
    parser.add_argument("--row-id", help="Single row ID for scope=row")
    parser.add_argument("--row-ids", nargs="*", help="Row IDs for subset/row scopes")
    parser.add_argument(
        "--first-n",
        type=int,
        help="First N rows (for scope=firstN). Use with --unprocessed-only to process the next rows without reruns",
    )
    parser.add_argument(
        "--unprocessed-only",
        action="store_true",
        help="Only process rows without values (recommended with scope=firstN)",
    )
    parser.add_argument("--filters-json", help="JSON object for scope=filtered")
    parser.add_argument("--filters-file", help="Path to JSON file for scope=filtered")
    parser.add_argument("--data-json", help="Explicit RunRequest payload JSON (overrides scope flags)")
    parser.add_argument("--data-file", help="Path to RunRequest payload JSON file (overrides scope flags)")


def _add_run_execution_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--show-estimate", action="store_true", help="Include estimate response in output")
    parser.add_argument("--dry-run", action="store_true", help="Only estimate; do not execute run")
    parser.add_argument("--max-credits", type=float, help="Block run when estimate exceeds this value")
    parser.add_argument(
        "--allow-unknown-max",
        action="store_true",
        help="Allow run when estimated_credits_max is null (max-credits guard uses min estimate)",
    )
    parser.add_argument(
        "--wait",
        action="store_true",
        help="Wait for bulk job terminal status by polling /api/bulk-jobs/{job_id}",
    )
    parser.add_argument("--quiet-wait", action="store_true", help="Suppress per-poll output in --wait mode")
    parser.add_argument("--poll-interval", type=int, default=2, help="Polling interval seconds for --wait")
    parser.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
    parser.add_argument("--fail-on-error", action="store_true", help="Exit non-zero when final status is error/cancelled")
    parser.add_argument("--fail-on-partial", action="store_true", help="Exit non-zero when final status is partial")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="autotouch", description="Smart Table CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    # setup
    psetup = sub.add_parser("setup", help="First-run setup with key validation")
    psetup.add_argument("--api-key", help="Developer API key (stk_...)")
    psetup.add_argument("--base-url", default=_api_url(), help=f"API base URL (default: {DEFAULT_API_URL})")
    psetup.add_argument("--overwrite", action="store_true", help="Replace existing stored API key")
    psetup.add_argument("--use-x-api-key", action="store_true", help="Validate using X-API-Key header")
    psetup.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="HTTP timeout in seconds")
    psetup.add_argument("--output", choices=["json", "human"], default="human", help="Output mode")
    psetup.add_argument("--compact", action="store_true", help="Print compact JSON")
    psetup.add_argument("--verbose", action="store_true", help="Print request metadata to stderr")
    psetup.add_argument("--no-banner", action="store_true", help="Skip banner in human mode")
    psetup.set_defaults(func=cmd_setup)

    # auth
    auth = sub.add_parser("auth", help="Auth helpers")
    auth_sub = auth.add_subparsers(dest="auth_cmd", required=True)
    pa = auth_sub.add_parser("check", help="Validate token against /api/capabilities")
    _add_api_common_arguments(pa)
    pa.set_defaults(func=cmd_auth_check)

    pask = auth_sub.add_parser("set-key", help="Persist API key/base URL to user config")
    pask.add_argument("--api-key", help="Developer API key to store (defaults from env if omitted)")
    pask.add_argument("--base-url", help=f"Default API base URL (default: {DEFAULT_API_URL})")
    pask.add_argument("--overwrite", action="store_true", help="Replace existing stored API key")
    pask.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    pask.add_argument("--compact", action="store_true", help="Print compact JSON")
    pask.set_defaults(func=cmd_auth_set_key)

    pashow = auth_sub.add_parser("show", help="Show current auth config")
    pashow.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    pashow.add_argument("--compact", action="store_true", help="Print compact JSON")
    pashow.set_defaults(func=cmd_auth_show)

    paclear = auth_sub.add_parser("clear", help="Clear stored auth config")
    paclear.add_argument("--all", action="store_true", help="Clear all config keys")
    paclear.add_argument("--clear-base-url", action="store_true", help="Also clear stored base_url")
    paclear.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    paclear.add_argument("--compact", action="store_true", help="Print compact JSON")
    paclear.set_defaults(func=cmd_auth_clear)

    # capabilities
    pc = sub.add_parser("capabilities", help="Get machine-readable API capabilities")
    _add_api_common_arguments(pc)
    pc.set_defaults(func=cmd_capabilities)

    # tables
    pt = sub.add_parser("tables", help="Table operations")
    tables_sub = pt.add_subparsers(dest="tables_cmd", required=True)
    ptl = tables_sub.add_parser("list", help="List tables")
    ptl.add_argument("--view-mode", choices=["org", "user", "all"], default="org")
    _add_api_common_arguments(ptl)
    ptl.set_defaults(func=cmd_tables_list)

    ptc = tables_sub.add_parser("create", help="Create a table")
    ptc.add_argument("--name", help="Table name")
    ptc.add_argument("--metadata-json", help="Metadata JSON object")
    ptc.add_argument("--metadata-file", help="Metadata JSON file path")
    ptc.add_argument("--data-json", help="Explicit TableCreate payload JSON")
    ptc.add_argument("--data-file", help="Explicit TableCreate payload file")
    _add_api_common_arguments(ptc)
    ptc.set_defaults(func=cmd_tables_create)

    # rows
    pr = sub.add_parser("rows", help="Row operations")
    rows_sub = pr.add_subparsers(dest="rows_cmd", required=True)
    pra = rows_sub.add_parser("add", help="Add rows (blank count or records payload)")
    pra.add_argument("--table-id", required=True)
    pra.add_argument("--count", type=int, default=1, help="Blank rows to create (ignored if records provided)")
    pra.add_argument("--records-json", help="Object, list, or {records:[...]} payload")
    pra.add_argument("--records-file", help="Path to JSON file containing records payload")
    pra.add_argument("--detect-types", action="store_true", help="Enable detect_types when patching record values")
    _add_api_common_arguments(pra)
    pra.set_defaults(func=cmd_rows_add)

    pric = rows_sub.add_parser("import-csv", help="Import CSV rows by creating rows + patching cells")
    pric.add_argument("--table-id", required=True)
    pric.add_argument("--file", required=True, help="CSV file path")
    pric.add_argument(
        "--transport",
        choices=["optimized", "direct"],
        default="optimized",
        help="Import transport: optimized uses /import-optimized (recommended); direct uses row/cell API loop",
    )
    pric.add_argument("--delimiter", default=",", help="CSV delimiter (default: ,)")
    pric.add_argument("--encoding", default="utf-8", help="File encoding (default: utf-8)")
    pric.add_argument("--limit", type=int, help="Optional max records to import")
    pric.add_argument("--no-trim-headers", dest="trim_headers", action="store_false", help="Do not trim header whitespace")
    pric.add_argument("--trim-values", action="store_true", help="Trim cell string values")
    pric.add_argument("--no-empty-as-null", dest="empty_as_null", action="store_false", help="Preserve empty strings instead of null")
    pric.add_argument("--no-skip-empty-rows", dest="skip_empty_rows", action="store_false", help="Keep fully empty rows")
    pric.add_argument("--detect-types", action="store_true", help="Enable detect_types while patching")
    pric.add_argument("--origin", default="csv", help="Column origin tag for optimized import")
    pric.add_argument("--field-mappings-json", help="Field mappings JSON object for optimized import")
    pric.add_argument("--field-mappings-file", help="Field mappings JSON file for optimized import")
    pric.add_argument(
        "--no-check-company-blacklist",
        dest="check_company_blacklist",
        action="store_false",
        help="Disable company blacklist filtering for optimized import",
    )
    pric.add_argument(
        "--check-email-blacklist",
        dest="check_email_blacklist",
        action="store_true",
        help="Enable email blacklist filtering for optimized import",
    )
    pric.add_argument(
        "--sync",
        dest="use_async",
        action="store_false",
        help="Use synchronous /import-optimized processing instead of background task mode",
    )
    pric.add_argument("--wait", action="store_true", help="Wait for async optimized import to complete")
    pric.add_argument("--poll-interval", type=int, default=2, help="Polling interval seconds for --wait")
    pric.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
    pric.set_defaults(trim_headers=True, empty_as_null=True, skip_empty_rows=True)
    pric.set_defaults(check_company_blacklist=True, check_email_blacklist=False, use_async=True)
    _add_api_common_arguments(pric)
    pric.set_defaults(func=cmd_rows_import_csv)

    pris = rows_sub.add_parser("import-status", help="Get or watch async CSV import status")
    pris.add_argument("--table-id", required=True)
    pris.add_argument("--task-id", required=True)
    pris.add_argument("--wait", action="store_true", help="Poll until completed/failed")
    pris.add_argument("--poll-interval", type=int, default=2, help="Polling interval seconds for --wait")
    pris.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
    _add_api_common_arguments(pris)
    pris.set_defaults(func=cmd_rows_import_status)

    prd = rows_sub.add_parser("delete", help="Delete a single row")
    prd.add_argument("--table-id", required=True)
    prd.add_argument("--row-id", required=True)
    _add_api_common_arguments(prd)
    prd.set_defaults(func=cmd_rows_delete)

    # cells
    pcell = sub.add_parser("cells", help="Cell operations")
    cells_sub = pcell.add_subparsers(dest="cells_cmd", required=True)
    pcp = cells_sub.add_parser("patch", help="Patch cells in batch")
    pcp.add_argument("--table-id", required=True)
    pcp.add_argument("--updates-json", help="JSON list or {updates:[...]} object")
    pcp.add_argument("--updates-file", help="Path to JSON file with updates payload")
    pcp.add_argument("--detect-types", action="store_true", help="Set detect_types=true query flag")
    _add_api_common_arguments(pcp)
    pcp.set_defaults(func=cmd_cells_patch)

    # columns
    pcol = sub.add_parser("columns", help="Column operations")
    col_sub = pcol.add_subparsers(dest="columns_cmd", required=True)

    pcl = col_sub.add_parser("list", help="List table columns")
    pcl.add_argument("--table-id", required=True)
    _add_api_common_arguments(pcl)
    pcl.set_defaults(func=cmd_columns_list)

    pcc = col_sub.add_parser("create", help="Create a column")
    pcc.add_argument("--table-id", required=True)
    pcc.add_argument("--data-json", help="ColumnCreate payload JSON")
    pcc.add_argument("--data-file", help="ColumnCreate payload file path")
    _add_api_common_arguments(pcc)
    pcc.set_defaults(func=cmd_columns_create)

    pcu = col_sub.add_parser("update", help="Update a column")
    pcu.add_argument("--table-id", required=True)
    pcu.add_argument("--column-id", required=True)
    pcu.add_argument("--data-json", help="ColumnUpdate payload JSON")
    pcu.add_argument("--data-file", help="ColumnUpdate payload file path")
    _add_api_common_arguments(pcu)
    pcu.set_defaults(func=cmd_columns_update)

    pcpj = col_sub.add_parser("projections", help="Create JSON projection columns")
    pcpj.add_argument("--table-id", required=True)
    pcpj.add_argument("--data-json", help="CreateProjectionsRequest payload JSON")
    pcpj.add_argument("--data-file", help="CreateProjectionsRequest payload file path")
    _add_api_common_arguments(pcpj)
    pcpj.set_defaults(func=cmd_columns_projections)

    pcr = col_sub.add_parser("run", help="Run a column")
    pcr.add_argument("--table-id", required=True)
    pcr.add_argument("--column-id", required=True)
    _add_run_scope_arguments(pcr)
    _add_run_execution_arguments(pcr)
    _add_api_common_arguments(pcr)
    pcr.set_defaults(func=cmd_columns_run)

    pcrn = col_sub.add_parser("run-next", help="Run exactly N selected rows using subset scope")
    pcrn.add_argument("--table-id", required=True)
    pcrn.add_argument("--column-id", required=True)
    pcrn.add_argument("--count", type=int, required=True, help="Exact number of rows to queue")
    pcrn.add_argument("--filters-json", help="Optional JSON object to select from filtered rows")
    pcrn.add_argument("--filters-file", help="Optional JSON file to select from filtered rows")
    pcrn.add_argument("--page-size", type=int, default=200, help="Rows page size while selecting candidates (max 1000)")
    pcrn.add_argument(
        "--include-processed",
        dest="unprocessed_only",
        action="store_false",
        help="Include rows that already have output in candidate selection",
    )
    pcrn.add_argument("--fail-if-empty", action="store_true", help="Exit non-zero when no eligible rows are selected")
    pcrn.set_defaults(unprocessed_only=True)
    _add_run_execution_arguments(pcrn)
    _add_api_common_arguments(pcrn)
    pcrn.set_defaults(func=cmd_columns_run_next)

    pce = col_sub.add_parser("estimate", help="Estimate a column run")
    pce.add_argument("--table-id", required=True)
    pce.add_argument("--column-id", required=True)
    _add_run_scope_arguments(pce)
    _add_api_common_arguments(pce)
    pce.set_defaults(func=cmd_columns_estimate)

    pcre = col_sub.add_parser("recipe", help="Print copy-ready ColumnCreate payload templates")
    pcre.add_argument("--type", choices=["all", *COLUMN_RECIPE_TYPES], default="all")
    pcre.add_argument("--out-file", help="Write template JSON to file (single type writes payload only)")
    pcre.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    pcre.add_argument("--compact", action="store_true", help="Print compact JSON")
    pcre.set_defaults(func=cmd_columns_recipe)

    # jobs
    pj = sub.add_parser("jobs", help="Bulk job operations")
    jobs_sub = pj.add_subparsers(dest="jobs_cmd", required=True)
    pjg = jobs_sub.add_parser("get", help="Get bulk job details")
    pjg.add_argument("--job-id", required=True)
    _add_api_common_arguments(pjg)
    pjg.set_defaults(func=cmd_jobs_get)

    pjw = jobs_sub.add_parser("watch", help="Poll bulk job status until terminal (or once)")
    pjw.add_argument("--job-id", required=True)
    pjw.add_argument("--once", action="store_true", help="Fetch once and exit")
    pjw.add_argument("--interval", type=int, default=2, help="Polling interval seconds")
    pjw.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
    pjw.add_argument("--fail-on-error", action="store_true", help="Exit non-zero on error/cancelled")
    pjw.add_argument("--fail-on-partial", action="store_true", help="Exit non-zero on partial")
    _add_api_common_arguments(pjw)
    pjw.set_defaults(func=cmd_jobs_watch)

    # webhooks
    pwh = sub.add_parser("webhooks", help="Table webhook operations")
    wh_sub = pwh.add_subparsers(dest="webhooks_cmd", required=True)

    pwhg = wh_sub.add_parser("get", help="Get webhook config for a table")
    pwhg.add_argument("--table-id", required=True)
    _add_api_common_arguments(pwhg)
    pwhg.set_defaults(func=cmd_webhooks_get)

    pwhr = wh_sub.add_parser("rotate", help="Create/rotate webhook token for a table")
    pwhr.add_argument("--table-id", required=True)
    _add_api_common_arguments(pwhr)
    pwhr.set_defaults(func=cmd_webhooks_rotate)

    pwhi = wh_sub.add_parser("ingest", help="Ingest records using table webhook token")
    pwhi.add_argument("--table-id", required=True)
    pwhi.add_argument("--webhook-token", help="x-autotouch-token (or AUTOTOUCH_WEBHOOK_TOKEN)")
    pwhi.add_argument("--records-json", help="Object, list, or {records:[...]} payload JSON")
    pwhi.add_argument("--records-file", help="Path to JSON file containing records payload")
    pwhi.add_argument("--base-url", default=_api_url(), help=f"API base URL (default: {DEFAULT_API_URL})")
    pwhi.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="HTTP timeout in seconds")
    pwhi.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    pwhi.add_argument("--compact", action="store_true", help="Print compact JSON")
    pwhi.add_argument("--verbose", action="store_true", help="Print request metadata to stderr")
    pwhi.set_defaults(func=cmd_webhooks_ingest)

    # Backward-compatible aliases
    # run
    palias_run = sub.add_parser("run", help="Alias for: columns run")
    palias_run.add_argument("--table-id", required=True)
    palias_run.add_argument("--column-id", required=True)
    _add_run_scope_arguments(palias_run)
    _add_run_execution_arguments(palias_run)
    _add_api_common_arguments(palias_run)
    palias_run.set_defaults(func=cmd_columns_run)

    palias_run_next = sub.add_parser("run-next", help="Alias for: columns run-next")
    palias_run_next.add_argument("--table-id", required=True)
    palias_run_next.add_argument("--column-id", required=True)
    palias_run_next.add_argument("--count", type=int, required=True, help="Exact number of rows to queue")
    palias_run_next.add_argument("--filters-json", help="Optional JSON object to select from filtered rows")
    palias_run_next.add_argument("--filters-file", help="Optional JSON file to select from filtered rows")
    palias_run_next.add_argument("--page-size", type=int, default=200, help="Rows page size while selecting candidates (max 1000)")
    palias_run_next.add_argument(
        "--include-processed",
        dest="unprocessed_only",
        action="store_false",
        help="Include rows that already have output in candidate selection",
    )
    palias_run_next.add_argument("--fail-if-empty", action="store_true", help="Exit non-zero when no eligible rows are selected")
    palias_run_next.set_defaults(unprocessed_only=True)
    _add_run_execution_arguments(palias_run_next)
    _add_api_common_arguments(palias_run_next)
    palias_run_next.set_defaults(func=cmd_columns_run_next)

    # status
    ps = sub.add_parser("status", help="Show pending/done/error counts for a table/column (Mongo)")
    ps.add_argument("--table-id", required=True)
    ps.add_argument("--column-id", required=True)
    ps.add_argument("--mongo-uri", help="Override MONGODB_URI")
    ps.add_argument("--db-name", help="Override MONGODB_DB_NAME")
    ps.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    ps.set_defaults(func=cmd_status)

    # watch
    pw = sub.add_parser("watch", help="Watch status periodically (Mongo)")
    pw.add_argument("--table-id", required=True)
    pw.add_argument("--column-id", required=True)
    pw.add_argument("--interval", type=int, default=5)
    pw.add_argument("--mongo-uri", help="Override MONGODB_URI")
    pw.add_argument("--db-name", help="Override MONGODB_DB_NAME")
    pw.set_defaults(func=cmd_watch)

    # SOP guidance for agents/users (packaged with CLI)
    psop = sub.add_parser("sop", help="Print credit-safe execution SOP + default filtered run payload")
    psop.add_argument("--out-file", help="Write SOP JSON to file")
    psop.add_argument("--output", choices=["json", "human"], default="json", help="Output mode")
    psop.add_argument("--compact", action="store_true", help="Print compact JSON")
    psop.set_defaults(func=cmd_sop)

    return p


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    _set_output_mode(getattr(args, "output", "json"))
    args.func(args)


if __name__ == "__main__":
    main()
