
import asyncio
import os
import sys
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Load env vars
load_dotenv()

from apps.api.services.notifications.task_error_logger import task_error_logger

async def test_logging():
    print(f"Testing Task Error Logger...")
    print(f"Webhook URL: {task_error_logger.webhook_url[:10]}... (len={len(task_error_logger.webhook_url)})")
    print(f"Channel: {task_error_logger.channel}")
    print(f"Enabled: {task_error_logger.enabled}")

    success = await task_error_logger.log_error(
        error_message="Test Error from Antigravity Verification Script",
        error_details={
            "script": "scripts/test_task_error_logger.py",
            "reason": "Verifying Slack Integration",
            "stack": "Fake stack trace\n  at test_logging (scripts/test_task_error_logger.py:20)\n  at asyncio.run (asyncio/events.py:123)"
        },
        user_context={
            "user_id": "test_user_123",
            "email": "test@example.com"
        },
        browser_info={
            "user_agent": "Python/3.10 Aiohttp/3.8",
            "url": "http://localhost:test"
        }
    )

    if success:
        print("✅ Successfully sent log to Slack!")
    else:
        print("❌ Failed to send log to Slack.")

if __name__ == "__main__":
    asyncio.run(test_logging())
