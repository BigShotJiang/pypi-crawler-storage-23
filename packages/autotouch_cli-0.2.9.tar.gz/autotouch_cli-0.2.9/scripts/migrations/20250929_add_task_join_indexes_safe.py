#!/usr/bin/env python3
"""
Add indexes to support efficient MongoDB joins for task live data architecture
SAFE VERSION: Only runs on localhost, handles existing indexes gracefully
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "smart_table")


async def add_task_join_indexes():
    """Add indexes to support efficient task queue $lookup operations"""

    # Safety check: Only run on local development environment
    if "localhost" not in MONGODB_URI and "127.0.0.1" not in MONGODB_URI:
        logger.error("❌ SAFETY CHECK: This migration should only run on local development environment!")
        logger.error(f"Current MONGODB_URI: {MONGODB_URI}")
        logger.error("Refusing to run on production database. Use localhost MongoDB for development.")
        return

    logger.info(f"✅ Running on local development environment: {MONGODB_URI}")

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    # Helper function to safely create index if it doesn't exist
    async def create_index_if_not_exists(collection, index_spec, index_name=None):
        existing_indexes = await collection.list_indexes().to_list(length=None)

        # Check if an index with the same fields already exists
        for idx in existing_indexes:
            if 'key' in idx and list(idx['key'].items()) == index_spec:
                logger.info(f"✅ Index with same fields already exists: {idx['name']}")
                return

        # Create index if not exists
        try:
            await collection.create_index(index_spec, name=index_name)
            logger.info(f"✅ Created index: {index_name or 'unnamed'}")
        except Exception as e:
            if "already exists" in str(e) or "IndexOptionsConflict" in str(e):
                logger.info(f"ℹ️ Index already exists, skipping: {index_name}")
            else:
                logger.error(f"❌ Error creating index {index_name}: {e}")

    try:
        logger.info("🚀 Starting task join indexes migration...")

        # 1. Essential JOIN indexes for task live data
        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("lead_id", ASCENDING)
        ], "task_lead_join_index")

        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("company_id", ASCENDING)
        ], "task_company_join_index")

        # 2. Task filtering indexes
        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("assigned_to", ASCENDING)
        ], "task_assigned_to_index")

        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("task_status", ASCENDING)
        ], "task_status_index")

        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("due_date", ASCENDING)
        ], "task_due_date_index")

        # 3. Leads and companies JOIN optimization
        await create_index_if_not_exists(db.leads, [
            ("organization_id", ASCENDING),
            ("_id", ASCENDING)
        ], "leads_join_index")

        await create_index_if_not_exists(db.companies, [
            ("organization_id", ASCENDING),
            ("_id", ASCENDING)
        ], "companies_join_index")

        logger.info("✅ Task join indexes migration completed successfully!")

    except Exception as e:
        logger.error(f"❌ Error during migration: {e}")
        raise
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(add_task_join_indexes())