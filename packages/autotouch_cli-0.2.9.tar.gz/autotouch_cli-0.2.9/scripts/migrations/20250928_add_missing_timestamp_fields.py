#!/usr/bin/env python3
"""
Migration script to add missing timestamp fields to existing leads.

This migration handles:
1. Adding created_at field to leads that don't have it (using updated_at as fallback)
2. Adding imported_at field to leads that don't have it (using updated_at as fallback)
3. Ensuring all existing leads have proper timestamp fields for API compliance

Usage:
    python scripts/migrations/20250928_add_missing_timestamp_fields.py

Environment variables:
    MONGODB_URI: MongoDB connection string (default: mongodb://localhost:27017)
    MONGODB_DB_NAME: Database name (default: autotouch)
    DRY_RUN: Set to 'true' to preview changes without applying them (default: false)
"""

import os
import asyncio
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "autotouch")
DRY_RUN = os.getenv("DRY_RUN", "false").lower() == "true"

async def migrate_timestamp_fields():
    """Add missing timestamp fields to existing leads"""

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        logger.info("Starting timestamp field migration for leads...")

        # Count total leads
        total_leads = await db.leads.count_documents({})
        logger.info(f"Total leads in database: {total_leads}")

        if total_leads == 0:
            logger.info("No leads found. Migration complete.")
            return

        # Find leads missing created_at field
        leads_missing_created_at = await db.leads.count_documents({"created_at": {"$exists": False}})
        logger.info(f"Leads missing created_at field: {leads_missing_created_at}")

        # Find leads missing imported_at field
        leads_missing_imported_at = await db.leads.count_documents({"imported_at": {"$exists": False}})
        logger.info(f"Leads missing imported_at field: {leads_missing_imported_at}")

        # Migration 1: Add created_at field
        if leads_missing_created_at > 0:
            logger.info(f"Adding created_at field to {leads_missing_created_at} leads...")

            if DRY_RUN:
                logger.info("DRY_RUN: Would update created_at field for all leads missing it")
            else:
                # Use updated_at as fallback, or current time if neither exists
                result = await db.leads.update_many(
                    {"created_at": {"$exists": False}},
                    [{
                        "$set": {
                            "created_at": {
                                "$ifNull": ["$updated_at", datetime.utcnow()]
                            }
                        }
                    }]
                )
                logger.info(f"Updated created_at field for {result.modified_count} leads")

        # Migration 2: Add imported_at field
        if leads_missing_imported_at > 0:
            logger.info(f"Adding imported_at field to {leads_missing_imported_at} leads...")

            if DRY_RUN:
                logger.info("DRY_RUN: Would update imported_at field for all leads missing it")
            else:
                # Use updated_at as fallback, or current time if neither exists
                result = await db.leads.update_many(
                    {"imported_at": {"$exists": False}},
                    [{
                        "$set": {
                            "imported_at": {
                                "$ifNull": ["$updated_at", datetime.utcnow()]
                            }
                        }
                    }]
                )
                logger.info(f"Updated imported_at field for {result.modified_count} leads")

        # Verification: Check final counts
        logger.info("Migration verification:")
        final_leads_with_created_at = await db.leads.count_documents({"created_at": {"$exists": True}})
        final_leads_with_imported_at = await db.leads.count_documents({"imported_at": {"$exists": True}})

        logger.info(f"Final count - Leads with created_at: {final_leads_with_created_at}")
        logger.info(f"Final count - Leads with imported_at: {final_leads_with_imported_at}")

        if final_leads_with_created_at == total_leads and final_leads_with_imported_at == total_leads:
            logger.info("✅ Migration completed successfully! All leads now have timestamp fields.")
        else:
            logger.warning("⚠️  Migration incomplete. Some leads still missing timestamp fields.")

        # Show sample of updated records
        sample_leads = await db.leads.find({}).limit(2).to_list(2)
        logger.info("Sample updated leads:")
        for i, lead in enumerate(sample_leads, 1):
            logger.info(f"  Lead {i}: created_at={lead.get('created_at')}, imported_at={lead.get('imported_at')}")

    except Exception as e:
        logger.error(f"Error during migration: {e}")
        raise
    finally:
        client.close()

async def main():
    """Main migration function"""
    if DRY_RUN:
        logger.info("🔍 DRY_RUN mode enabled - no changes will be made")
    else:
        logger.info("🚀 Executing migration - changes will be applied")

    await migrate_timestamp_fields()

if __name__ == "__main__":
    asyncio.run(main())