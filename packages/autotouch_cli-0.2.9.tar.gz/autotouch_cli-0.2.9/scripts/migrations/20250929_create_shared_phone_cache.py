#!/usr/bin/env python3
"""
Create shared phone cache collection and indexes for cross-customer phone result sharing
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING
import logging
from datetime import datetime, timedelta

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "smart_table")


async def create_shared_phone_cache():
    """Create shared phone cache collection with proper indexes and sample data"""

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        logger.info("🚀 Creating shared phone cache collection and indexes...")

        # Create the collection (MongoDB creates it automatically on first insert)
        collection = db.shared_phone_cache

        # Create indexes for performance
        indexes = [
            # Primary cache key lookup (unique)
            ("cache_key", ASCENDING),

            # LinkedIn URL normalization lookup
            ("linkedin_url_normalized", ASCENDING),

            # TTL index for automatic expiration
            ("expires_at", ASCENDING),

            # Frequently used filters
            ("created_at", DESCENDING),
            ("privacy_level", ASCENDING),
            ("discovery_metadata.successful_provider", ASCENDING),
            ("last_accessed", DESCENDING),

            # Compound indexes for common queries
            (["privacy_level", "linkedin_url_normalized"], None),
            (["created_at", "discovery_metadata.successful_provider"], None),
        ]

        for index_spec in indexes:
            if isinstance(index_spec, tuple) and len(index_spec) == 2:
                field, direction = index_spec
                if isinstance(field, list):
                    # Compound index
                    index_fields = [(f, ASCENDING) for f in field]
                    index_name = f"compound_{'_'.join(field)}"
                else:
                    # Single field index
                    index_fields = [(field, direction)]
                    index_name = f"{field}_index"
            else:
                continue

            try:
                # Check if index already exists
                existing_indexes = await collection.list_indexes().to_list(length=None)
                index_exists = any(
                    idx.get('name') == index_name or
                    list(idx.get('key', {}).items()) == index_fields
                    for idx in existing_indexes
                )

                if not index_exists:
                    if field == "expires_at":
                        # TTL index with automatic expiration
                        await collection.create_index(
                            index_fields,
                            name=index_name,
                            expireAfterSeconds=0  # MongoDB uses the expires_at field value
                        )
                    elif field == "cache_key":
                        # Unique index for cache keys
                        await collection.create_index(
                            index_fields,
                            name=index_name,
                            unique=True
                        )
                    else:
                        # Regular index
                        await collection.create_index(index_fields, name=index_name)

                    logger.info(f"✅ Created index: {index_name}")
                else:
                    logger.info(f"ℹ️ Index already exists: {index_name}")

            except Exception as e:
                logger.error(f"❌ Error creating index {index_name}: {e}")

        # Create phone finder usage stats collection
        stats_collection = db.phone_finder_usage_stats

        # Create index for daily stats
        try:
            await stats_collection.create_index([("date", ASCENDING)], unique=True, name="date_unique_index")
            logger.info("✅ Created usage stats collection with date index")
        except Exception as e:
            if "already exists" in str(e).lower():
                logger.info("ℹ️ Usage stats index already exists")
            else:
                logger.error(f"❌ Error creating usage stats index: {e}")

        # Insert sample cache entry to validate schema
        sample_entry = {
            "cache_key": "linkedin_phone_shared:in/sample-profile",
            "linkedin_url_normalized": "in/sample-profile",
            "linkedin_url_original": "https://www.linkedin.com/in/sample-profile",

            "phone_numbers": [
                {
                    "number": "+1234567890",
                    "provider": "contactout",
                    "type": "mobile",
                    "verified": True,
                    "confidence": 0.95,
                    "discovered_at": datetime.utcnow(),
                    "formatted": "+1 (234) 567-8900",
                    "country": "US",
                    "carrier": "Sample Carrier"
                }
            ],
            "primary_phone": "+1234567890",

            "discovery_metadata": {
                "successful_provider": "contactout",
                "providers_attempted": ["leadmagic", "prospeo", "contactout"],
                "total_cost": 15,
                "search_duration_ms": 2350,
                "success_rate": 0.33
            },

            "profile_data": {
                "full_name": "Sample User",
                "job_title": "Software Engineer",
                "company_name": "Sample Company",
                "location": "San Francisco, CA"
            },

            "created_at": datetime.utcnow(),
            "last_accessed": datetime.utcnow(),
            "access_count": 1,
            "expires_at": datetime.utcnow() + timedelta(days=365),  # 1 year

            "privacy_level": "shared",
            "data_source": "public_profile",
            "compliance_flags": {
                "gdpr_compliant": True,
                "ccpa_compliant": True,
                "consent_required": False
            }
        }

        # Insert sample entry if it doesn't exist
        existing_sample = await collection.find_one({"cache_key": "linkedin_phone_shared:in/sample-profile"})
        if not existing_sample:
            await collection.insert_one(sample_entry)
            logger.info("✅ Inserted sample cache entry for schema validation")
        else:
            logger.info("ℹ️ Sample cache entry already exists")

        # Initialize daily usage stats
        today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        sample_stats = {
            "date": today,
            "cache_hits": 0,
            "cache_misses": 0,
            "total_searches": 0,
            "hit_ratio": 0.0,
            "cost_savings": 0,
            "unique_linkedin_profiles": 0,
            "top_cached_profiles": []
        }

        # Insert today's stats if they don't exist
        existing_stats = await stats_collection.find_one({"date": today})
        if not existing_stats:
            await stats_collection.insert_one(sample_stats)
            logger.info("✅ Initialized daily usage stats")
        else:
            logger.info("ℹ️ Daily usage stats already exist")

        logger.info("✅ Shared phone cache setup completed successfully!")

        # Print collection info
        cache_count = await collection.count_documents({})
        stats_count = await stats_collection.count_documents({})

        logger.info(f"📊 Cache entries: {cache_count}")
        logger.info(f"📊 Stats entries: {stats_count}")

    except Exception as e:
        logger.error(f"❌ Error during shared phone cache setup: {e}")
        raise
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(create_shared_phone_cache())