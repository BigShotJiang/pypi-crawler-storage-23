#!/usr/bin/env python3
"""E2E test: Instantly bulk sequence enrollment.

Flow:
 1) Connect to MongoDB (MONGODB_URI or k8s prod URI).
 2) Resolve org + user from USER_EMAIL.
 3) Ensure a lead document for TEST_RECIPIENT_EMAIL.
 4) Pick an Instantly campaign (INSTANTLY_CAMPAIGN_ID env or first from API).
 5) Insert a bulk sequence (mode='bulk', bulkProvider='instantly').
 6) Enroll the lead via create_enrollments().
 7) Inspect enrollment to confirm provider metadata and Instantly lead add success.

Environment:
  MONGODB_URI            - MongoDB connection string
  USER_EMAIL             - User in this org (e.g. nic@autotouch.ai)
  TEST_RECIPIENT_EMAIL   - Lead email to enroll
  INSTANTLY_CAMPAIGN_ID  - Optional; if not set, script fetches campaigns from Instantly and picks the first.
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime
from typing import Any, Dict, Optional

import httpx
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient


async def _utcnow() -> datetime:
    return datetime.utcnow()


async def _ensure_org_and_user(db, user_email: str) -> tuple[str, str]:
    user = await db.users.find_one({"email": user_email})
    if not user:
        raise RuntimeError(f"User not found: {user_email}")
    org_id = user.get("organization_id")
    if not org_id:
        raise RuntimeError("User missing organization_id")
    return str(org_id), str(user.get("_id"))


async def _ensure_lead(db, organization_id: str, recipient_email: str) -> str:
    lead = await db.leads.find_one(
        {
            "organization_id": organization_id,
            "$or": [
                {"email": recipient_email},
                {"email_addresses.address": recipient_email},
                {"email_addresses.email": recipient_email},
            ],
        }
    )
    if lead:
        return str(lead.get("_id"))
    doc: Dict[str, Any] = {
        "organization_id": organization_id,
        "email": recipient_email,
        "email_addresses": [{"address": recipient_email}],
        "first_name": "E2E",
        "last_name": "Instantly",
        "created_at": await _utcnow(),
        "updated_at": await _utcnow(),
    }
    res = await db.leads.insert_one(doc)
    return str(res.inserted_id)


async def _get_instantly_api_key(db, organization_id: str) -> str:
    # Mirror get_org_provider_api_key logic (but inline to avoid import tangle)
    doc = await db.autotouch.api_keys.find_one(
        {"organization_id": organization_id, "$or": [{"service": "instantly"}, {"provider": "instantly"}]}
    )
    if not doc:
        raise RuntimeError("No Instantly API key configured for org")
    for key in ("api_key", "key", "token"):
        val = doc.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    creds = doc.get("credentials") or {}
    if isinstance(creds, dict):
        for key in ("api_key", "key", "token"):
            val = creds.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
    raise RuntimeError("Instantly API key present but no usable credential field found")


async def _pick_instantly_campaign(api_key: str) -> str:
    # Use Instantly v2 campaigns endpoint as in sequences_phase3 docs
    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        resp = await client.get(
            "https://api.instantly.ai/api/v2/campaigns",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            params={"limit": "50"},
        )
        resp.raise_for_status()
        data = resp.json()
        items = []
        if isinstance(data, dict):
            if "items" in data:
                items = data.get("items", [])
            elif "data" in data:
                items = (data.get("data") or {}).get("items", [])
        if not items:
            raise RuntimeError("No Instantly campaigns returned; cannot pick a campaignId")
        # Prefer the first active campaign; fallback to first
        for it in items:
            if (it or {}).get("status") in (1, "active", "ACTIVE"):
                return str(it.get("id") or it.get("uuid") or it.get("campaign_id"))
        first = items[0]
        cid = first.get("id") or first.get("uuid") or first.get("campaign_id")
        if not cid:
            raise RuntimeError("Instantly campaign object missing id")
        return str(cid)


async def _insert_bulk_sequence(
    db,
    organization_id: str,
    user_id: str,
    name: str,
    provider: str,
    campaign_id: str,
) -> str:
    now = await _utcnow()
    seq: Dict[str, Any] = {
        "organization_id": organization_id,
        "user_id": user_id,
        "name": name,
        "description": "E2E Instantly bulk test sequence",
        "status": "ACTIVE",
        "schedule": {
            "workingDays": [0, 1, 2, 3, 4, 5, 6],
            "dailyWindowStart": "00:00",
            "dailyWindowEnd": "23:59",
            "timezone": "UTC",
            "skipHolidays": False,
        },
        "emailDelivery": {
            "mode": "bulk",
            "bulkProvider": provider,
            "providerConfig": {
                provider: {"campaignId": campaign_id}
            },
        },
        "steps": [
            {
                "id": "step-1",
                "kind": "EMAIL",
                "emailSendMode": "AUTOMATED",
                "emailIsReply": False,
                "waitDays": 0,
                "waitHours": 0,
                "subjectTemplate": "E2E Instantly test",
                "bodyTemplate": "<p>Hello from Autotouch (Instantly E2E test).</p>",
            }
        ],
        "exitRules": {"stopOnReply": True, "stopOnBounce": True, "stopOnManualOptOut": True},
        "created_at": now,
        "updated_at": now,
    }
    res = await db.sequences.insert_one(seq)
    return str(res.inserted_id)


async def _enroll(db, organization_id: str, sequence_id: str, user_id: str, lead_id: str) -> Dict[str, Any]:
    import os as _os, sys as _sys

    root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
    if root not in _sys.path:
        _sys.path.insert(0, root)

    from apps.api.services.workflow.sequences.sequence_enrollment_service import create_enrollments

    result = await create_enrollments(
        db=db,
        organization_id=organization_id,
        user_id=user_id,
        sequence_id=sequence_id,
        lead_ids=[lead_id],
        start_date=None,
        research_context=None,
    )
    return result


async def main() -> None:
    db_uri = os.getenv("MONGODB_URI") or "mongodb://localhost:27017/autotouch"
    user_email = os.getenv("USER_EMAIL", "nic@autotouch.ai")
    recipient_email = os.getenv("TEST_RECIPIENT_EMAIL")
    seq_name = os.getenv("TEST_SEQUENCE_NAME", "E2E Instantly Bulk Test")
    explicit_campaign_id = os.getenv("INSTANTLY_CAMPAIGN_ID")

    if not recipient_email:
        raise RuntimeError("TEST_RECIPIENT_EMAIL env must be set")

    client = AsyncIOMotorClient(db_uri)
    db = client.get_default_database()

    org_id, user_id = await _ensure_org_and_user(db, user_email)
    print(f"Resolved organization_id={org_id} user_id={user_id}")

    lead_id = await _ensure_lead(db, org_id, recipient_email)
    print(f"Using lead_id={lead_id} for {recipient_email}")

    api_key = await _get_instantly_api_key(db, org_id)
    print("Instantly API key found for org.")

    campaign_id = explicit_campaign_id
    if not campaign_id:
        campaign_id = await _pick_instantly_campaign(api_key)
        print(f"Selected Instantly campaign_id={campaign_id} from API")
    else:
        print(f"Using provided Instantly campaign_id={campaign_id}")

    seq_id = await _insert_bulk_sequence(db, org_id, user_id, seq_name, "instantly", campaign_id)
    print(f"Created sequence_id={seq_id}")

    enroll_result = await _enroll(db, org_id, seq_id, user_id, lead_id)
    print("Enrollment result:", enroll_result)

    # Inspect enrollment to verify provider meta
    enr = await db.sequence_enrollments.find_one({
        "organization_id": org_id,
        "sequence_id": seq_id,
        "lead_id": lead_id,
    })
    if not enr:
        print("No enrollment found after create_enrollments")
    else:
        print("Enrollment provider fields:", {
            "provider": enr.get("provider"),
            "provider_campaign_id": enr.get("provider_campaign_id"),
            "provider_lead_id": enr.get("provider_lead_id"),
            "provider_lead_email": enr.get("provider_lead_email"),
            "provider_enroll_result_ok": (enr.get("provider_enroll_result") or {}).get("ok"),
            "provider_enroll_result_status": (enr.get("provider_enroll_result") or {}).get("status"),
        })


if __name__ == "__main__":
    asyncio.run(main())
