from typing import Any, Dict, List
from datetime import datetime

import pytest

from apps.api.models.lead import Lead
from apps.api.services.leads.ingest.lead_data_normalizer import LeadDataNormalizer
from apps.workers.tasks import lead_import


class FakeInsertResult:
    def __init__(self, inserted_id: str):
        self.inserted_id = inserted_id


class FakeCompaniesCollection:
    def __init__(self):
        self.storage: List[Dict[str, Any]] = []

    def find(self, query):
        domain_filter = set(query.get("domain", {}).get("$in", []))
        org_id = query.get("organization_id")
        return [doc for doc in self.storage if doc.get("domain") in domain_filter and doc.get("organization_id") == org_id]

    def insert_one(self, doc):
        new_doc = dict(doc)
        new_doc.setdefault("_id", f"company_{len(self.storage) + 1}")
        self.storage.append(new_doc)
        return FakeInsertResult(new_doc["_id"])


class FakeDB:
    def __init__(self):
        self.companies = FakeCompaniesCollection()


def _base_payload() -> dict:
    return {
        "company_domain": "example.com",
        "linkedin_url": "https://linkedin.com/in/test-user",
        "first_name": "Test",
        "last_name": "User",
    }


def test_missing_company_domain_raises_value_error():
    payload = _base_payload()
    payload.pop("company_domain")

    with pytest.raises(ValueError, match="Missing required field: company_domain"):
        Lead.from_import_data(payload, created_by_user_id="tester", organization_id="org")


def test_invalid_company_domain_rejected():
    payload = _base_payload()
    payload["company_domain"] = "not a domain"

    with pytest.raises(ValueError, match="Invalid company domain"):
        Lead.from_import_data(payload, created_by_user_id="tester", organization_id="org")


def test_missing_linkedin_url_raises_value_error():
    payload = _base_payload()
    payload.pop("linkedin_url")

    with pytest.raises(ValueError, match="Missing required field: linkedin_url"):
        Lead.from_import_data(payload, created_by_user_id="tester", organization_id="org")


def test_invalid_linkedin_url_rejected():
    payload = _base_payload()
    payload["linkedin_url"] = "https://example.com/profile"

    with pytest.raises(ValueError, match="Invalid LinkedIn URL"):
        Lead.from_import_data(payload, created_by_user_id="tester", organization_id="org")


def test_normalizer_produces_valid_payload_for_api():
    raw_payload = {
        "company_domain": "HTTPS://WWW.Example.com/about",
        "linkedin_url": "linkedin.com/in/test-user/",
        "first_name": "Test",
        "last_name": "User",
        "lead_source": "manual",
    }

    normalized = LeadDataNormalizer.normalize_from_api_payload(raw_payload)
    lead = Lead.from_import_data(normalized, created_by_user_id="tester", organization_id="org")

    assert lead.company_domain == "example.com"
    assert lead.linkedin_url == "https://linkedin.com/in/test-user"


def test_process_domain_matches_without_domain_does_not_create_company():
    db = FakeDB()
    leads = [{"company_name": "Example"}]

    results = lead_import._process_domain_matches(db, leads, organization_id="org", created_by_user_id="tester")

    assert results[0]["success"] is False
    assert len(db.companies.storage) == 0


def test_process_name_matches_without_domain_does_not_create_company():
    db = FakeDB()
    leads = [{"company_name": "Example"}]

    results = lead_import._process_name_matches(db, leads, organization_id="org", created_by_user_id="tester")

    assert results[0]["success"] is False
    assert len(db.companies.storage) == 0


def test_to_dict_includes_defaults_and_status():
    lead = Lead.from_import_data(_base_payload(), created_by_user_id="tester", organization_id="org")
    payload = lead.to_dict()

    # Defaults should be present for persistence
    assert payload["created_at"] and isinstance(payload["created_at"], datetime)
    assert payload["updated_at"] and isinstance(payload["updated_at"], datetime)
    assert payload["imported_at"] and isinstance(payload["imported_at"], datetime)
    assert payload["lead_status"] == "new"
