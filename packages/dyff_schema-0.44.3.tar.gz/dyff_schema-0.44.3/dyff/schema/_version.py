__version__ = version = "0.44.3"
__version_tuple__ = version_tuple = (0, 44, 3)
