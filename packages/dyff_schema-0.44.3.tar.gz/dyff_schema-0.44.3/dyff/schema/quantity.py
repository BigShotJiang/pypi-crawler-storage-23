# SPDX-FileCopyrightText: 2024 UL Research Institutes
# SPDX-License-Identifier: Apache-2.0

import decimal
from decimal import Decimal, InvalidOperation
from typing import Any


# The parse_quantity() function has the following license:
#
# Copyright 2019 The Kubernetes Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
def parse_quantity(quantity: Any) -> Decimal:
    """Parse a kubernetes canonical form quantity like 200Mi to a decimal number.

    Supported SI suffixes:
    base1024: Ki | Mi | Gi | Ti | Pi | Ei
    base1000: n | u | m | "" | k | M | G | T | P | E

    See https://github.com/kubernetes/apimachinery/blob/master/pkg/api/resource/quantity.go

    :param quantity: Kubernetes canonical form quantity. If it is not a numeric
        type, it will be converted to a string and parsed.
    :type quantity: Any
    :returns: A Decimal containing the numeric value of the quantity.
    :rtype: Decimal
    :raises: ValueError on invalid or unknown input
    """
    if isinstance(quantity, (int, float, Decimal)):
        return Decimal(quantity)

    exponents = {
        "n": -3,
        "u": -2,
        "m": -1,
        "K": 1,
        "k": 1,
        "M": 2,
        "G": 3,
        "T": 4,
        "P": 5,
        "E": 6,
    }

    quantity = str(quantity)
    number = quantity
    suffix = None
    if len(quantity) >= 2 and quantity[-1] == "i":
        if quantity[-2] in exponents:
            number = quantity[:-2]
            suffix = quantity[-2:]
    elif len(quantity) >= 1 and quantity[-1] in exponents:
        number = quantity[:-1]
        suffix = quantity[-1:]

    try:
        number = Decimal(number)
    except InvalidOperation:
        raise ValueError("Invalid number format: {}".format(number))

    if suffix is None:
        return number

    if suffix.endswith("i"):
        base = 1024
    elif len(suffix) == 1:
        base = 1000
    else:
        raise ValueError("{} has unknown suffix".format(quantity))

    # handle SI inconsistency
    if suffix == "ki":
        raise ValueError("{} has unknown suffix".format(quantity))

    if suffix[0] not in exponents:
        raise ValueError("{} has unknown suffix".format(quantity))

    exponent = Decimal(exponents[suffix[0]])
    return number * (base**exponent)


def parse_quantity_as_int(quantity: Any) -> int:
    """Parse a kubernetes canonical form quantity like 200Mi to an ``int``.

    Supported SI suffixes:
    base1024: Ki | Mi | Gi | Ti | Pi | Ei
    base1000: n | u | m | "" | k | M | G | T | P | E

    See https://github.com/kubernetes/apimachinery/blob/master/pkg/api/resource/quantity.go

    :param quantity: Kubernetes canonical form quantity. If it is not a numeric
        type, it will be converted to a string and parsed.
    :type quantity: Any
    :returns: An int containing the numeric value of the quantity.
    :rtype: int
    :raises: ValueError on invalid or unknown input, or if the quantity cannot
        be represented exactly by an int.
    """
    decimal_quantity = parse_quantity(quantity)
    with decimal.localcontext() as ctx:
        try:
            ctx.traps[decimal.Inexact] = True
            return int(decimal_quantity.to_integral_exact())
        except decimal.Inexact:
            raise ValueError("non-integer quantity")
