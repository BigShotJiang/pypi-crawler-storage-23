"""Entry point for python -m kattis2canvas."""

from kattis2canvas.cli import top

if __name__ == "__main__":
    top()
