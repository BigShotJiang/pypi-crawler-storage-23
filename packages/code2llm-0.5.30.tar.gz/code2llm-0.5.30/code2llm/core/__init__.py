"""Core analysis components for code2llm."""

from .config import Config, FAST_CONFIG, PerformanceConfig, FilterConfig
from .models import (
    AnalysisResult, FlowNode, FlowEdge, 
    FunctionInfo, ClassInfo, ModuleInfo, Pattern
)

__all__ = [
    'ProjectAnalyzer',
    'StreamingAnalyzer',
    'IncrementalAnalyzer',
    'ScanStrategy',
    'SmartPrioritizer',
    'STRATEGY_QUICK',
    'STRATEGY_STANDARD',
    'STRATEGY_DEEP',
    'FileCache',
    'FastFileFilter',
    'Config',
    'FAST_CONFIG',
    'AnalysisResult',
    'FunctionInfo',
    'ClassInfo',
    'ModuleInfo',
]


def __getattr__(name):
    """Lazy import heavy modules on first access."""
    _analyzer_names = {'ProjectAnalyzer', 'FileCache', 'FastFileFilter'}
    if name in _analyzer_names:
        from . import analyzer as _mod
        return getattr(_mod, name)
    
    _streaming_names = {
        'StreamingAnalyzer', 'IncrementalAnalyzer', 'ScanStrategy',
        'SmartPrioritizer', 'STRATEGY_QUICK', 'STRATEGY_STANDARD', 'STRATEGY_DEEP',
    }
    if name in _streaming_names:
        from . import streaming_analyzer as _mod
        return getattr(_mod, name)
    
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")