from .main import mcp

def main():
    mcp.run(transport='stdio')

__version__ = "0.1.0"
