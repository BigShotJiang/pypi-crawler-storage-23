# Generated from UVLPythonParser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,63,433,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,1,0,3,0,78,8,0,1,0,
        3,0,81,8,0,1,0,3,0,84,8,0,1,0,3,0,87,8,0,1,0,3,0,90,8,0,1,0,3,0,
        93,8,0,1,0,3,0,96,8,0,1,0,3,0,99,8,0,1,0,3,0,102,8,0,1,0,1,0,1,1,
        1,1,1,1,1,1,5,1,110,8,1,10,1,12,1,113,9,1,1,1,1,1,1,2,1,2,1,2,1,
        3,1,3,1,3,1,4,1,4,1,4,1,4,5,4,127,8,4,10,4,12,4,130,9,4,1,4,1,4,
        1,5,1,5,1,5,3,5,137,8,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,7,1,7,
        1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,157,8,7,1,8,1,8,1,8,4,8,162,
        8,8,11,8,12,8,163,1,8,1,8,1,9,3,9,169,8,9,1,9,1,9,3,9,173,8,9,1,
        9,3,9,176,8,9,1,9,1,9,1,9,4,9,181,8,9,11,9,12,9,182,1,9,1,9,3,9,
        187,8,9,1,10,1,10,1,10,1,11,1,11,1,11,1,11,5,11,196,8,11,10,11,12,
        11,199,9,11,3,11,201,8,11,1,11,1,11,1,12,1,12,3,12,207,8,12,1,13,
        1,13,3,13,211,8,13,1,14,1,14,1,15,1,15,1,15,1,15,1,15,1,15,3,15,
        221,8,15,1,16,1,16,1,16,1,16,5,16,227,8,16,10,16,12,16,230,9,16,
        3,16,232,8,16,1,16,1,16,1,17,1,17,1,17,1,17,3,17,240,8,17,1,18,1,
        18,1,18,1,18,5,18,246,8,18,10,18,12,18,249,9,18,3,18,251,8,18,1,
        18,1,18,1,19,1,19,1,19,1,19,5,19,259,8,19,10,19,12,19,262,9,19,1,
        19,1,19,1,20,1,20,1,20,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,
        21,3,21,278,8,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,
        21,1,21,1,21,5,21,292,8,21,10,21,12,21,295,9,21,1,22,1,22,1,22,1,
        22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,
        22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,3,22,321,8,22,1,23,1,23,1,
        24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,5,24,334,8,24,10,24,12,
        24,337,9,24,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,5,25,348,
        8,25,10,25,12,25,351,9,25,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,
        1,26,3,26,362,8,26,1,27,1,27,1,27,1,27,3,27,368,8,27,1,28,1,28,1,
        28,1,28,1,28,3,28,375,8,28,1,28,1,28,1,28,1,29,1,29,1,29,1,29,1,
        29,3,29,385,8,29,1,29,1,29,1,29,1,30,1,30,1,30,1,30,1,30,1,31,1,
        31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,405,8,31,1,32,1,
        32,1,32,5,32,410,8,32,10,32,12,32,413,9,32,1,32,1,32,1,33,1,33,1,
        34,1,34,1,35,1,35,1,35,1,35,3,35,425,8,35,3,35,427,8,35,1,36,1,36,
        1,37,1,37,1,37,0,3,42,48,50,38,0,2,4,6,8,10,12,14,16,18,20,22,24,
        26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,
        70,72,74,0,4,1,0,60,61,1,0,20,23,2,0,21,21,29,30,1,0,31,34,461,0,
        77,1,0,0,0,2,105,1,0,0,0,4,116,1,0,0,0,6,119,1,0,0,0,8,122,1,0,0,
        0,10,133,1,0,0,0,12,140,1,0,0,0,14,156,1,0,0,0,16,158,1,0,0,0,18,
        168,1,0,0,0,20,188,1,0,0,0,22,191,1,0,0,0,24,206,1,0,0,0,26,208,
        1,0,0,0,28,212,1,0,0,0,30,220,1,0,0,0,32,222,1,0,0,0,34,239,1,0,
        0,0,36,241,1,0,0,0,38,254,1,0,0,0,40,265,1,0,0,0,42,277,1,0,0,0,
        44,320,1,0,0,0,46,322,1,0,0,0,48,324,1,0,0,0,50,338,1,0,0,0,52,361,
        1,0,0,0,54,367,1,0,0,0,56,369,1,0,0,0,58,379,1,0,0,0,60,389,1,0,
        0,0,62,404,1,0,0,0,64,411,1,0,0,0,66,416,1,0,0,0,68,418,1,0,0,0,
        70,420,1,0,0,0,72,428,1,0,0,0,74,430,1,0,0,0,76,78,3,6,3,0,77,76,
        1,0,0,0,77,78,1,0,0,0,78,80,1,0,0,0,79,81,5,9,0,0,80,79,1,0,0,0,
        80,81,1,0,0,0,81,83,1,0,0,0,82,84,3,2,1,0,83,82,1,0,0,0,83,84,1,
        0,0,0,84,86,1,0,0,0,85,87,5,9,0,0,86,85,1,0,0,0,86,87,1,0,0,0,87,
        89,1,0,0,0,88,90,3,8,4,0,89,88,1,0,0,0,89,90,1,0,0,0,90,92,1,0,0,
        0,91,93,5,9,0,0,92,91,1,0,0,0,92,93,1,0,0,0,93,95,1,0,0,0,94,96,
        3,12,6,0,95,94,1,0,0,0,95,96,1,0,0,0,96,98,1,0,0,0,97,99,5,9,0,0,
        98,97,1,0,0,0,98,99,1,0,0,0,99,101,1,0,0,0,100,102,3,38,19,0,101,
        100,1,0,0,0,101,102,1,0,0,0,102,103,1,0,0,0,103,104,5,0,0,1,104,
        1,1,0,0,0,105,106,5,12,0,0,106,107,5,9,0,0,107,111,5,10,0,0,108,
        110,3,4,2,0,109,108,1,0,0,0,110,113,1,0,0,0,111,109,1,0,0,0,111,
        112,1,0,0,0,112,114,1,0,0,0,113,111,1,0,0,0,114,115,5,11,0,0,115,
        3,1,0,0,0,116,117,3,70,35,0,117,118,5,9,0,0,118,5,1,0,0,0,119,120,
        5,15,0,0,120,121,3,64,32,0,121,7,1,0,0,0,122,123,5,14,0,0,123,124,
        5,9,0,0,124,128,5,10,0,0,125,127,3,10,5,0,126,125,1,0,0,0,127,130,
        1,0,0,0,128,126,1,0,0,0,128,129,1,0,0,0,129,131,1,0,0,0,130,128,
        1,0,0,0,131,132,5,11,0,0,132,9,1,0,0,0,133,136,3,64,32,0,134,135,
        5,16,0,0,135,137,3,64,32,0,136,134,1,0,0,0,136,137,1,0,0,0,137,138,
        1,0,0,0,138,139,5,9,0,0,139,11,1,0,0,0,140,141,5,13,0,0,141,142,
        5,9,0,0,142,143,5,10,0,0,143,144,3,18,9,0,144,145,5,11,0,0,145,13,
        1,0,0,0,146,147,5,35,0,0,147,157,3,16,8,0,148,149,5,36,0,0,149,157,
        3,16,8,0,150,151,5,37,0,0,151,157,3,16,8,0,152,153,5,38,0,0,153,
        157,3,16,8,0,154,155,5,39,0,0,155,157,3,16,8,0,156,146,1,0,0,0,156,
        148,1,0,0,0,156,150,1,0,0,0,156,152,1,0,0,0,156,154,1,0,0,0,157,
        15,1,0,0,0,158,159,5,9,0,0,159,161,5,10,0,0,160,162,3,18,9,0,161,
        160,1,0,0,0,162,163,1,0,0,0,163,161,1,0,0,0,163,164,1,0,0,0,164,
        165,1,0,0,0,165,166,5,11,0,0,166,17,1,0,0,0,167,169,3,68,34,0,168,
        167,1,0,0,0,168,169,1,0,0,0,169,170,1,0,0,0,170,172,3,64,32,0,171,
        173,3,20,10,0,172,171,1,0,0,0,172,173,1,0,0,0,173,175,1,0,0,0,174,
        176,3,22,11,0,175,174,1,0,0,0,175,176,1,0,0,0,176,177,1,0,0,0,177,
        186,5,9,0,0,178,180,5,10,0,0,179,181,3,14,7,0,180,179,1,0,0,0,181,
        182,1,0,0,0,182,180,1,0,0,0,182,183,1,0,0,0,183,184,1,0,0,0,184,
        185,5,11,0,0,185,187,1,0,0,0,186,178,1,0,0,0,186,187,1,0,0,0,187,
        19,1,0,0,0,188,189,5,19,0,0,189,190,5,39,0,0,190,21,1,0,0,0,191,
        200,5,5,0,0,192,197,3,24,12,0,193,194,5,58,0,0,194,196,3,24,12,0,
        195,193,1,0,0,0,196,199,1,0,0,0,197,195,1,0,0,0,197,198,1,0,0,0,
        198,201,1,0,0,0,199,197,1,0,0,0,200,192,1,0,0,0,200,201,1,0,0,0,
        201,202,1,0,0,0,202,203,5,6,0,0,203,23,1,0,0,0,204,207,3,26,13,0,
        205,207,3,34,17,0,206,204,1,0,0,0,206,205,1,0,0,0,207,25,1,0,0,0,
        208,210,3,28,14,0,209,211,3,30,15,0,210,209,1,0,0,0,210,211,1,0,
        0,0,211,27,1,0,0,0,212,213,3,66,33,0,213,29,1,0,0,0,214,221,5,57,
        0,0,215,221,5,55,0,0,216,221,5,56,0,0,217,221,5,62,0,0,218,221,3,
        22,11,0,219,221,3,32,16,0,220,214,1,0,0,0,220,215,1,0,0,0,220,216,
        1,0,0,0,220,217,1,0,0,0,220,218,1,0,0,0,220,219,1,0,0,0,221,31,1,
        0,0,0,222,231,5,3,0,0,223,228,3,30,15,0,224,225,5,58,0,0,225,227,
        3,30,15,0,226,224,1,0,0,0,227,230,1,0,0,0,228,226,1,0,0,0,228,229,
        1,0,0,0,229,232,1,0,0,0,230,228,1,0,0,0,231,223,1,0,0,0,231,232,
        1,0,0,0,232,233,1,0,0,0,233,234,5,4,0,0,234,33,1,0,0,0,235,236,5,
        17,0,0,236,240,3,42,21,0,237,238,5,18,0,0,238,240,3,36,18,0,239,
        235,1,0,0,0,239,237,1,0,0,0,240,35,1,0,0,0,241,250,5,3,0,0,242,247,
        3,42,21,0,243,244,5,58,0,0,244,246,3,42,21,0,245,243,1,0,0,0,246,
        249,1,0,0,0,247,245,1,0,0,0,247,248,1,0,0,0,248,251,1,0,0,0,249,
        247,1,0,0,0,250,242,1,0,0,0,250,251,1,0,0,0,251,252,1,0,0,0,252,
        253,5,4,0,0,253,37,1,0,0,0,254,255,5,18,0,0,255,256,5,9,0,0,256,
        260,5,10,0,0,257,259,3,40,20,0,258,257,1,0,0,0,259,262,1,0,0,0,260,
        258,1,0,0,0,260,261,1,0,0,0,261,263,1,0,0,0,262,260,1,0,0,0,263,
        264,5,11,0,0,264,39,1,0,0,0,265,266,3,42,21,0,266,267,5,9,0,0,267,
        41,1,0,0,0,268,269,6,21,-1,0,269,278,3,44,22,0,270,278,3,64,32,0,
        271,272,5,1,0,0,272,273,3,42,21,0,273,274,5,2,0,0,274,278,1,0,0,
        0,275,276,5,40,0,0,276,278,3,42,21,5,277,268,1,0,0,0,277,270,1,0,
        0,0,277,271,1,0,0,0,277,275,1,0,0,0,278,293,1,0,0,0,279,280,10,4,
        0,0,280,281,5,41,0,0,281,292,3,42,21,5,282,283,10,3,0,0,283,284,
        5,42,0,0,284,292,3,42,21,4,285,286,10,2,0,0,286,287,5,44,0,0,287,
        292,3,42,21,3,288,289,10,1,0,0,289,290,5,43,0,0,290,292,3,42,21,
        2,291,279,1,0,0,0,291,282,1,0,0,0,291,285,1,0,0,0,291,288,1,0,0,
        0,292,295,1,0,0,0,293,291,1,0,0,0,293,294,1,0,0,0,294,43,1,0,0,0,
        295,293,1,0,0,0,296,297,3,46,23,0,297,298,5,45,0,0,298,299,3,46,
        23,0,299,321,1,0,0,0,300,301,3,46,23,0,301,302,5,46,0,0,302,303,
        3,46,23,0,303,321,1,0,0,0,304,305,3,46,23,0,305,306,5,48,0,0,306,
        307,3,46,23,0,307,321,1,0,0,0,308,309,3,46,23,0,309,310,5,47,0,0,
        310,311,3,46,23,0,311,321,1,0,0,0,312,313,3,46,23,0,313,314,5,49,
        0,0,314,315,3,46,23,0,315,321,1,0,0,0,316,317,3,46,23,0,317,318,
        5,50,0,0,318,319,3,46,23,0,319,321,1,0,0,0,320,296,1,0,0,0,320,300,
        1,0,0,0,320,304,1,0,0,0,320,308,1,0,0,0,320,312,1,0,0,0,320,316,
        1,0,0,0,321,45,1,0,0,0,322,323,3,48,24,0,323,47,1,0,0,0,324,325,
        6,24,-1,0,325,326,3,50,25,0,326,335,1,0,0,0,327,328,10,3,0,0,328,
        329,5,53,0,0,329,334,3,50,25,0,330,331,10,2,0,0,331,332,5,54,0,0,
        332,334,3,50,25,0,333,327,1,0,0,0,333,330,1,0,0,0,334,337,1,0,0,
        0,335,333,1,0,0,0,335,336,1,0,0,0,336,49,1,0,0,0,337,335,1,0,0,0,
        338,339,6,25,-1,0,339,340,3,52,26,0,340,349,1,0,0,0,341,342,10,3,
        0,0,342,343,5,52,0,0,343,348,3,52,26,0,344,345,10,2,0,0,345,346,
        5,51,0,0,346,348,3,52,26,0,347,341,1,0,0,0,347,344,1,0,0,0,348,351,
        1,0,0,0,349,347,1,0,0,0,349,350,1,0,0,0,350,51,1,0,0,0,351,349,1,
        0,0,0,352,362,5,55,0,0,353,362,5,56,0,0,354,362,5,62,0,0,355,362,
        3,54,27,0,356,362,3,64,32,0,357,358,5,1,0,0,358,359,3,46,23,0,359,
        360,5,2,0,0,360,362,1,0,0,0,361,352,1,0,0,0,361,353,1,0,0,0,361,
        354,1,0,0,0,361,355,1,0,0,0,361,356,1,0,0,0,361,357,1,0,0,0,362,
        53,1,0,0,0,363,368,3,56,28,0,364,368,3,58,29,0,365,368,3,60,30,0,
        366,368,3,62,31,0,367,363,1,0,0,0,367,364,1,0,0,0,367,365,1,0,0,
        0,367,366,1,0,0,0,368,55,1,0,0,0,369,370,5,25,0,0,370,374,5,1,0,
        0,371,372,3,64,32,0,372,373,5,58,0,0,373,375,1,0,0,0,374,371,1,0,
        0,0,374,375,1,0,0,0,375,376,1,0,0,0,376,377,3,64,32,0,377,378,5,
        2,0,0,378,57,1,0,0,0,379,380,5,26,0,0,380,384,5,1,0,0,381,382,3,
        64,32,0,382,383,5,58,0,0,383,385,1,0,0,0,384,381,1,0,0,0,384,385,
        1,0,0,0,385,386,1,0,0,0,386,387,3,64,32,0,387,388,5,2,0,0,388,59,
        1,0,0,0,389,390,5,24,0,0,390,391,5,1,0,0,391,392,3,64,32,0,392,393,
        5,2,0,0,393,61,1,0,0,0,394,395,5,27,0,0,395,396,5,1,0,0,396,397,
        3,64,32,0,397,398,5,2,0,0,398,405,1,0,0,0,399,400,5,28,0,0,400,401,
        5,1,0,0,401,402,3,64,32,0,402,403,5,2,0,0,403,405,1,0,0,0,404,394,
        1,0,0,0,404,399,1,0,0,0,405,63,1,0,0,0,406,407,3,66,33,0,407,408,
        5,59,0,0,408,410,1,0,0,0,409,406,1,0,0,0,410,413,1,0,0,0,411,409,
        1,0,0,0,411,412,1,0,0,0,412,414,1,0,0,0,413,411,1,0,0,0,414,415,
        3,66,33,0,415,65,1,0,0,0,416,417,7,0,0,0,417,67,1,0,0,0,418,419,
        7,1,0,0,419,69,1,0,0,0,420,426,3,72,36,0,421,424,5,59,0,0,422,425,
        3,74,37,0,423,425,5,52,0,0,424,422,1,0,0,0,424,423,1,0,0,0,425,427,
        1,0,0,0,426,421,1,0,0,0,426,427,1,0,0,0,427,71,1,0,0,0,428,429,7,
        2,0,0,429,73,1,0,0,0,430,431,7,3,0,0,431,75,1,0,0,0,46,77,80,83,
        86,89,92,95,98,101,111,128,136,156,163,168,172,175,182,186,197,200,
        206,210,220,228,231,239,247,250,260,277,291,293,320,333,335,347,
        349,361,367,374,384,404,411,424,426
    ]

class UVLPythonParser ( Parser ):

    grammarFileName = "UVLPythonParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "'['", "']'", "'{'", "'}'", 
                     "'/*'", "'*/'", "<INVALID>", "'<INDENT>'", "'<DEDENT>'", 
                     "'include'", "'features'", "'imports'", "'namespace'", 
                     "'as'", "'constraint'", "'constraints'", "'cardinality'", 
                     "'String'", "'Boolean'", "'Integer'", "'Real'", "'len'", 
                     "'sum'", "'avg'", "'floor'", "'ceil'", "'Type'", "'Arithmetic'", 
                     "'group-cardinality'", "'feature-cardinality'", "'aggregate-function'", 
                     "'string-constraints'", "'or'", "'alternative'", "'optional'", 
                     "'mandatory'", "<INVALID>", "'!'", "'&'", "'|'", "'<=>'", 
                     "'=>'", "'=='", "'<'", "'<='", "'>'", "'>='", "'!='", 
                     "'/'", "'*'", "'+'", "'-'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "','", "'.'" ]

    symbolicNames = [ "<INVALID>", "OPEN_PAREN", "CLOSE_PAREN", "OPEN_BRACK", 
                      "CLOSE_BRACK", "OPEN_BRACE", "CLOSE_BRACE", "OPEN_COMMENT", 
                      "CLOSE_COMMENT", "NEWLINE", "INDENT", "DEDENT", "INCLUDE_KEY", 
                      "FEATURES_KEY", "IMPORTS_KEY", "NAMESPACE_KEY", "AS_KEY", 
                      "CONSTRAINT_KEY", "CONSTRAINTS_KEY", "CARDINALITY_KEY", 
                      "STRING_KEY", "BOOLEAN_KEY", "INTEGER_KEY", "REAL_KEY", 
                      "LEN_KEY", "SUM_KEY", "AVG_KEY", "FLOOR_KEY", "CEIL_KEY", 
                      "TYPE_KEY", "ARITHMETIC_KEY", "GROUP_CARDINALITY_KEY", 
                      "FEATURE_CARDINALITY_KEY", "AGGREGATE_KEY", "STRING_CONSTRAINTS_KEY", 
                      "ORGROUP", "ALTERNATIVE", "OPTIONAL", "MANDATORY", 
                      "CARDINALITY", "NOT", "AND", "OR", "EQUIVALENCE", 
                      "IMPLICATION", "EQUAL", "LOWER", "LOWER_EQUALS", "GREATER", 
                      "GREATER_EQUALS", "NOT_EQUALS", "DIV", "MUL", "ADD", 
                      "SUB", "FLOAT", "INTEGER", "BOOLEAN", "COMMA", "DOT", 
                      "ID_NOT_STRICT", "ID_STRICT", "STRING", "SKIP_" ]

    RULE_featureModel = 0
    RULE_includes = 1
    RULE_includeLine = 2
    RULE_namespace = 3
    RULE_imports = 4
    RULE_importLine = 5
    RULE_features = 6
    RULE_group = 7
    RULE_groupSpec = 8
    RULE_feature = 9
    RULE_featureCardinality = 10
    RULE_attributes = 11
    RULE_attribute = 12
    RULE_valueAttribute = 13
    RULE_key = 14
    RULE_value = 15
    RULE_vector = 16
    RULE_constraintAttribute = 17
    RULE_constraintList = 18
    RULE_constraints = 19
    RULE_constraintLine = 20
    RULE_constraint = 21
    RULE_equation = 22
    RULE_expression = 23
    RULE_additiveExpression = 24
    RULE_multiplicativeExpression = 25
    RULE_primaryExpression = 26
    RULE_aggregateFunction = 27
    RULE_sumAggregateFunction = 28
    RULE_avgAggregateFunction = 29
    RULE_stringAggregateFunction = 30
    RULE_numericAggregateFunction = 31
    RULE_reference = 32
    RULE_id = 33
    RULE_featureType = 34
    RULE_languageLevel = 35
    RULE_majorLevel = 36
    RULE_minorLevel = 37

    ruleNames =  [ "featureModel", "includes", "includeLine", "namespace", 
                   "imports", "importLine", "features", "group", "groupSpec", 
                   "feature", "featureCardinality", "attributes", "attribute", 
                   "valueAttribute", "key", "value", "vector", "constraintAttribute", 
                   "constraintList", "constraints", "constraintLine", "constraint", 
                   "equation", "expression", "additiveExpression", "multiplicativeExpression", 
                   "primaryExpression", "aggregateFunction", "sumAggregateFunction", 
                   "avgAggregateFunction", "stringAggregateFunction", "numericAggregateFunction", 
                   "reference", "id", "featureType", "languageLevel", "majorLevel", 
                   "minorLevel" ]

    EOF = Token.EOF
    OPEN_PAREN=1
    CLOSE_PAREN=2
    OPEN_BRACK=3
    CLOSE_BRACK=4
    OPEN_BRACE=5
    CLOSE_BRACE=6
    OPEN_COMMENT=7
    CLOSE_COMMENT=8
    NEWLINE=9
    INDENT=10
    DEDENT=11
    INCLUDE_KEY=12
    FEATURES_KEY=13
    IMPORTS_KEY=14
    NAMESPACE_KEY=15
    AS_KEY=16
    CONSTRAINT_KEY=17
    CONSTRAINTS_KEY=18
    CARDINALITY_KEY=19
    STRING_KEY=20
    BOOLEAN_KEY=21
    INTEGER_KEY=22
    REAL_KEY=23
    LEN_KEY=24
    SUM_KEY=25
    AVG_KEY=26
    FLOOR_KEY=27
    CEIL_KEY=28
    TYPE_KEY=29
    ARITHMETIC_KEY=30
    GROUP_CARDINALITY_KEY=31
    FEATURE_CARDINALITY_KEY=32
    AGGREGATE_KEY=33
    STRING_CONSTRAINTS_KEY=34
    ORGROUP=35
    ALTERNATIVE=36
    OPTIONAL=37
    MANDATORY=38
    CARDINALITY=39
    NOT=40
    AND=41
    OR=42
    EQUIVALENCE=43
    IMPLICATION=44
    EQUAL=45
    LOWER=46
    LOWER_EQUALS=47
    GREATER=48
    GREATER_EQUALS=49
    NOT_EQUALS=50
    DIV=51
    MUL=52
    ADD=53
    SUB=54
    FLOAT=55
    INTEGER=56
    BOOLEAN=57
    COMMA=58
    DOT=59
    ID_NOT_STRICT=60
    ID_STRICT=61
    STRING=62
    SKIP_=63

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class FeatureModelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(UVLPythonParser.EOF, 0)

        def namespace(self):
            return self.getTypedRuleContext(UVLPythonParser.NamespaceContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.NEWLINE)
            else:
                return self.getToken(UVLPythonParser.NEWLINE, i)

        def includes(self):
            return self.getTypedRuleContext(UVLPythonParser.IncludesContext,0)


        def imports(self):
            return self.getTypedRuleContext(UVLPythonParser.ImportsContext,0)


        def features(self):
            return self.getTypedRuleContext(UVLPythonParser.FeaturesContext,0)


        def constraints(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintsContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_featureModel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatureModel" ):
                listener.enterFeatureModel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatureModel" ):
                listener.exitFeatureModel(self)




    def featureModel(self):

        localctx = UVLPythonParser.FeatureModelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_featureModel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==15:
                self.state = 76
                self.namespace()


            self.state = 80
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 79
                self.match(UVLPythonParser.NEWLINE)


            self.state = 83
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==12:
                self.state = 82
                self.includes()


            self.state = 86
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.state = 85
                self.match(UVLPythonParser.NEWLINE)


            self.state = 89
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==14:
                self.state = 88
                self.imports()


            self.state = 92
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.state = 91
                self.match(UVLPythonParser.NEWLINE)


            self.state = 95
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 94
                self.features()


            self.state = 98
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==9:
                self.state = 97
                self.match(UVLPythonParser.NEWLINE)


            self.state = 101
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 100
                self.constraints()


            self.state = 103
            self.match(UVLPythonParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INCLUDE_KEY(self):
            return self.getToken(UVLPythonParser.INCLUDE_KEY, 0)

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def includeLine(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.IncludeLineContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.IncludeLineContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_includes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncludes" ):
                listener.enterIncludes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncludes" ):
                listener.exitIncludes(self)




    def includes(self):

        localctx = UVLPythonParser.IncludesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_includes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self.match(UVLPythonParser.INCLUDE_KEY)
            self.state = 106
            self.match(UVLPythonParser.NEWLINE)
            self.state = 107
            self.match(UVLPythonParser.INDENT)
            self.state = 111
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1612709888) != 0):
                self.state = 108
                self.includeLine()
                self.state = 113
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 114
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludeLineContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def languageLevel(self):
            return self.getTypedRuleContext(UVLPythonParser.LanguageLevelContext,0)


        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_includeLine

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncludeLine" ):
                listener.enterIncludeLine(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncludeLine" ):
                listener.exitIncludeLine(self)




    def includeLine(self):

        localctx = UVLPythonParser.IncludeLineContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_includeLine)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.languageLevel()
            self.state = 117
            self.match(UVLPythonParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NamespaceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NAMESPACE_KEY(self):
            return self.getToken(UVLPythonParser.NAMESPACE_KEY, 0)

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_namespace

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNamespace" ):
                listener.enterNamespace(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNamespace" ):
                listener.exitNamespace(self)




    def namespace(self):

        localctx = UVLPythonParser.NamespaceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_namespace)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 119
            self.match(UVLPythonParser.NAMESPACE_KEY)
            self.state = 120
            self.reference()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImportsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IMPORTS_KEY(self):
            return self.getToken(UVLPythonParser.IMPORTS_KEY, 0)

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def importLine(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ImportLineContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ImportLineContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_imports

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImports" ):
                listener.enterImports(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImports" ):
                listener.exitImports(self)




    def imports(self):

        localctx = UVLPythonParser.ImportsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_imports)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self.match(UVLPythonParser.IMPORTS_KEY)
            self.state = 123
            self.match(UVLPythonParser.NEWLINE)
            self.state = 124
            self.match(UVLPythonParser.INDENT)
            self.state = 128
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==60 or _la==61:
                self.state = 125
                self.importLine()
                self.state = 130
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 131
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImportLineContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.ns = None # ReferenceContext
            self.alias = None # ReferenceContext

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def reference(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ReferenceContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,i)


        def AS_KEY(self):
            return self.getToken(UVLPythonParser.AS_KEY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_importLine

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImportLine" ):
                listener.enterImportLine(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImportLine" ):
                listener.exitImportLine(self)




    def importLine(self):

        localctx = UVLPythonParser.ImportLineContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_importLine)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            localctx.ns = self.reference()
            self.state = 136
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==16:
                self.state = 134
                self.match(UVLPythonParser.AS_KEY)
                self.state = 135
                localctx.alias = self.reference()


            self.state = 138
            self.match(UVLPythonParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeaturesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FEATURES_KEY(self):
            return self.getToken(UVLPythonParser.FEATURES_KEY, 0)

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def feature(self):
            return self.getTypedRuleContext(UVLPythonParser.FeatureContext,0)


        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_features

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatures" ):
                listener.enterFeatures(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatures" ):
                listener.exitFeatures(self)




    def features(self):

        localctx = UVLPythonParser.FeaturesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_features)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 140
            self.match(UVLPythonParser.FEATURES_KEY)
            self.state = 141
            self.match(UVLPythonParser.NEWLINE)
            self.state = 142
            self.match(UVLPythonParser.INDENT)
            self.state = 143
            self.feature()
            self.state = 144
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_group

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AlternativeGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ALTERNATIVE(self):
            return self.getToken(UVLPythonParser.ALTERNATIVE, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAlternativeGroup" ):
                listener.enterAlternativeGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAlternativeGroup" ):
                listener.exitAlternativeGroup(self)


    class OptionalGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPTIONAL(self):
            return self.getToken(UVLPythonParser.OPTIONAL, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionalGroup" ):
                listener.enterOptionalGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionalGroup" ):
                listener.exitOptionalGroup(self)


    class MandatoryGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def MANDATORY(self):
            return self.getToken(UVLPythonParser.MANDATORY, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMandatoryGroup" ):
                listener.enterMandatoryGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMandatoryGroup" ):
                listener.exitMandatoryGroup(self)


    class CardinalityGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CARDINALITY(self):
            return self.getToken(UVLPythonParser.CARDINALITY, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCardinalityGroup" ):
                listener.enterCardinalityGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCardinalityGroup" ):
                listener.exitCardinalityGroup(self)


    class OrGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ORGROUP(self):
            return self.getToken(UVLPythonParser.ORGROUP, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrGroup" ):
                listener.enterOrGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrGroup" ):
                listener.exitOrGroup(self)



    def group(self):

        localctx = UVLPythonParser.GroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_group)
        try:
            self.state = 156
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [35]:
                localctx = UVLPythonParser.OrGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 146
                self.match(UVLPythonParser.ORGROUP)
                self.state = 147
                self.groupSpec()
                pass
            elif token in [36]:
                localctx = UVLPythonParser.AlternativeGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 148
                self.match(UVLPythonParser.ALTERNATIVE)
                self.state = 149
                self.groupSpec()
                pass
            elif token in [37]:
                localctx = UVLPythonParser.OptionalGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 150
                self.match(UVLPythonParser.OPTIONAL)
                self.state = 151
                self.groupSpec()
                pass
            elif token in [38]:
                localctx = UVLPythonParser.MandatoryGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 152
                self.match(UVLPythonParser.MANDATORY)
                self.state = 153
                self.groupSpec()
                pass
            elif token in [39]:
                localctx = UVLPythonParser.CardinalityGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 154
                self.match(UVLPythonParser.CARDINALITY)
                self.state = 155
                self.groupSpec()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def feature(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.FeatureContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.FeatureContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_groupSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupSpec" ):
                listener.enterGroupSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupSpec" ):
                listener.exitGroupSpec(self)




    def groupSpec(self):

        localctx = UVLPythonParser.GroupSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_groupSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(UVLPythonParser.NEWLINE)
            self.state = 159
            self.match(UVLPythonParser.INDENT)
            self.state = 161 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 160
                self.feature()
                self.state = 163 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 3458764513836269568) != 0)):
                    break

            self.state = 165
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def featureType(self):
            return self.getTypedRuleContext(UVLPythonParser.FeatureTypeContext,0)


        def featureCardinality(self):
            return self.getTypedRuleContext(UVLPythonParser.FeatureCardinalityContext,0)


        def attributes(self):
            return self.getTypedRuleContext(UVLPythonParser.AttributesContext,0)


        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def group(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.GroupContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.GroupContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_feature

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeature" ):
                listener.enterFeature(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeature" ):
                listener.exitFeature(self)




    def feature(self):

        localctx = UVLPythonParser.FeatureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_feature)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 168
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 15728640) != 0):
                self.state = 167
                self.featureType()


            self.state = 170
            self.reference()
            self.state = 172
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==19:
                self.state = 171
                self.featureCardinality()


            self.state = 175
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 174
                self.attributes()


            self.state = 177
            self.match(UVLPythonParser.NEWLINE)
            self.state = 186
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 178
                self.match(UVLPythonParser.INDENT)
                self.state = 180 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 179
                    self.group()
                    self.state = 182 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 1065151889408) != 0)):
                        break

                self.state = 184
                self.match(UVLPythonParser.DEDENT)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureCardinalityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CARDINALITY_KEY(self):
            return self.getToken(UVLPythonParser.CARDINALITY_KEY, 0)

        def CARDINALITY(self):
            return self.getToken(UVLPythonParser.CARDINALITY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_featureCardinality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatureCardinality" ):
                listener.enterFeatureCardinality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatureCardinality" ):
                listener.exitFeatureCardinality(self)




    def featureCardinality(self):

        localctx = UVLPythonParser.FeatureCardinalityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_featureCardinality)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 188
            self.match(UVLPythonParser.CARDINALITY_KEY)
            self.state = 189
            self.match(UVLPythonParser.CARDINALITY)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_BRACE(self):
            return self.getToken(UVLPythonParser.OPEN_BRACE, 0)

        def CLOSE_BRACE(self):
            return self.getToken(UVLPythonParser.CLOSE_BRACE, 0)

        def attribute(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.AttributeContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.AttributeContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.COMMA)
            else:
                return self.getToken(UVLPythonParser.COMMA, i)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_attributes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributes" ):
                listener.enterAttributes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributes" ):
                listener.exitAttributes(self)




    def attributes(self):

        localctx = UVLPythonParser.AttributesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_attributes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            self.match(UVLPythonParser.OPEN_BRACE)
            self.state = 200
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3458764513820934144) != 0):
                self.state = 192
                self.attribute()
                self.state = 197
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==58:
                    self.state = 193
                    self.match(UVLPythonParser.COMMA)
                    self.state = 194
                    self.attribute()
                    self.state = 199
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 202
            self.match(UVLPythonParser.CLOSE_BRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def valueAttribute(self):
            return self.getTypedRuleContext(UVLPythonParser.ValueAttributeContext,0)


        def constraintAttribute(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintAttributeContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_attribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttribute" ):
                listener.enterAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttribute" ):
                listener.exitAttribute(self)




    def attribute(self):

        localctx = UVLPythonParser.AttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_attribute)
        try:
            self.state = 206
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [60, 61]:
                self.enterOuterAlt(localctx, 1)
                self.state = 204
                self.valueAttribute()
                pass
            elif token in [17, 18]:
                self.enterOuterAlt(localctx, 2)
                self.state = 205
                self.constraintAttribute()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueAttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def key(self):
            return self.getTypedRuleContext(UVLPythonParser.KeyContext,0)


        def value(self):
            return self.getTypedRuleContext(UVLPythonParser.ValueContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_valueAttribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueAttribute" ):
                listener.enterValueAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueAttribute" ):
                listener.exitValueAttribute(self)




    def valueAttribute(self):

        localctx = UVLPythonParser.ValueAttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_valueAttribute)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 208
            self.key()
            self.state = 210
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4863887597560135720) != 0):
                self.state = 209
                self.value()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KeyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self):
            return self.getTypedRuleContext(UVLPythonParser.IdContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_key

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKey" ):
                listener.enterKey(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKey" ):
                listener.exitKey(self)




    def key(self):

        localctx = UVLPythonParser.KeyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_key)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 212
            self.id_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOOLEAN(self):
            return self.getToken(UVLPythonParser.BOOLEAN, 0)

        def FLOAT(self):
            return self.getToken(UVLPythonParser.FLOAT, 0)

        def INTEGER(self):
            return self.getToken(UVLPythonParser.INTEGER, 0)

        def STRING(self):
            return self.getToken(UVLPythonParser.STRING, 0)

        def attributes(self):
            return self.getTypedRuleContext(UVLPythonParser.AttributesContext,0)


        def vector(self):
            return self.getTypedRuleContext(UVLPythonParser.VectorContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValue" ):
                listener.enterValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValue" ):
                listener.exitValue(self)




    def value(self):

        localctx = UVLPythonParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_value)
        try:
            self.state = 220
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [57]:
                self.enterOuterAlt(localctx, 1)
                self.state = 214
                self.match(UVLPythonParser.BOOLEAN)
                pass
            elif token in [55]:
                self.enterOuterAlt(localctx, 2)
                self.state = 215
                self.match(UVLPythonParser.FLOAT)
                pass
            elif token in [56]:
                self.enterOuterAlt(localctx, 3)
                self.state = 216
                self.match(UVLPythonParser.INTEGER)
                pass
            elif token in [62]:
                self.enterOuterAlt(localctx, 4)
                self.state = 217
                self.match(UVLPythonParser.STRING)
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 5)
                self.state = 218
                self.attributes()
                pass
            elif token in [3]:
                self.enterOuterAlt(localctx, 6)
                self.state = 219
                self.vector()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VectorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_BRACK(self):
            return self.getToken(UVLPythonParser.OPEN_BRACK, 0)

        def CLOSE_BRACK(self):
            return self.getToken(UVLPythonParser.CLOSE_BRACK, 0)

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ValueContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ValueContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.COMMA)
            else:
                return self.getToken(UVLPythonParser.COMMA, i)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_vector

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVector" ):
                listener.enterVector(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVector" ):
                listener.exitVector(self)




    def vector(self):

        localctx = UVLPythonParser.VectorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_vector)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            self.match(UVLPythonParser.OPEN_BRACK)
            self.state = 231
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4863887597560135720) != 0):
                self.state = 223
                self.value()
                self.state = 228
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==58:
                    self.state = 224
                    self.match(UVLPythonParser.COMMA)
                    self.state = 225
                    self.value()
                    self.state = 230
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 233
            self.match(UVLPythonParser.CLOSE_BRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintAttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraintAttribute

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ListConstraintAttributeContext(ConstraintAttributeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintAttributeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONSTRAINTS_KEY(self):
            return self.getToken(UVLPythonParser.CONSTRAINTS_KEY, 0)
        def constraintList(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListConstraintAttribute" ):
                listener.enterListConstraintAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListConstraintAttribute" ):
                listener.exitListConstraintAttribute(self)


    class SingleConstraintAttributeContext(ConstraintAttributeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintAttributeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONSTRAINT_KEY(self):
            return self.getToken(UVLPythonParser.CONSTRAINT_KEY, 0)
        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSingleConstraintAttribute" ):
                listener.enterSingleConstraintAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSingleConstraintAttribute" ):
                listener.exitSingleConstraintAttribute(self)



    def constraintAttribute(self):

        localctx = UVLPythonParser.ConstraintAttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_constraintAttribute)
        try:
            self.state = 239
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [17]:
                localctx = UVLPythonParser.SingleConstraintAttributeContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 235
                self.match(UVLPythonParser.CONSTRAINT_KEY)
                self.state = 236
                self.constraint(0)
                pass
            elif token in [18]:
                localctx = UVLPythonParser.ListConstraintAttributeContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 237
                self.match(UVLPythonParser.CONSTRAINTS_KEY)
                self.state = 238
                self.constraintList()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_BRACK(self):
            return self.getToken(UVLPythonParser.OPEN_BRACK, 0)

        def CLOSE_BRACK(self):
            return self.getToken(UVLPythonParser.CLOSE_BRACK, 0)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.COMMA)
            else:
                return self.getToken(UVLPythonParser.COMMA, i)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraintList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraintList" ):
                listener.enterConstraintList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraintList" ):
                listener.exitConstraintList(self)




    def constraintList(self):

        localctx = UVLPythonParser.ConstraintListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_constraintList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 241
            self.match(UVLPythonParser.OPEN_BRACK)
            self.state = 250
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8178538023336542210) != 0):
                self.state = 242
                self.constraint(0)
                self.state = 247
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==58:
                    self.state = 243
                    self.match(UVLPythonParser.COMMA)
                    self.state = 244
                    self.constraint(0)
                    self.state = 249
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 252
            self.match(UVLPythonParser.CLOSE_BRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONSTRAINTS_KEY(self):
            return self.getToken(UVLPythonParser.CONSTRAINTS_KEY, 0)

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def constraintLine(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintLineContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintLineContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraints" ):
                listener.enterConstraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraints" ):
                listener.exitConstraints(self)




    def constraints(self):

        localctx = UVLPythonParser.ConstraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_constraints)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 254
            self.match(UVLPythonParser.CONSTRAINTS_KEY)
            self.state = 255
            self.match(UVLPythonParser.NEWLINE)
            self.state = 256
            self.match(UVLPythonParser.INDENT)
            self.state = 260
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 8178538023336542210) != 0):
                self.state = 257
                self.constraintLine()
                self.state = 262
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 263
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintLineContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)


        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraintLine

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraintLine" ):
                listener.enterConstraintLine(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraintLine" ):
                listener.exitConstraintLine(self)




    def constraintLine(self):

        localctx = UVLPythonParser.ConstraintLineContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_constraintLine)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 265
            self.constraint(0)
            self.state = 266
            self.match(UVLPythonParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraint

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class OrConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def OR(self):
            return self.getToken(UVLPythonParser.OR, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrConstraint" ):
                listener.enterOrConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrConstraint" ):
                listener.exitOrConstraint(self)


    class EquationConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def equation(self):
            return self.getTypedRuleContext(UVLPythonParser.EquationContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEquationConstraint" ):
                listener.enterEquationConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEquationConstraint" ):
                listener.exitEquationConstraint(self)


    class LiteralConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralConstraint" ):
                listener.enterLiteralConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralConstraint" ):
                listener.exitLiteralConstraint(self)


    class ParenthesisConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParenthesisConstraint" ):
                listener.enterParenthesisConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParenthesisConstraint" ):
                listener.exitParenthesisConstraint(self)


    class NotConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(UVLPythonParser.NOT, 0)
        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNotConstraint" ):
                listener.enterNotConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNotConstraint" ):
                listener.exitNotConstraint(self)


    class AndConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def AND(self):
            return self.getToken(UVLPythonParser.AND, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAndConstraint" ):
                listener.enterAndConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAndConstraint" ):
                listener.exitAndConstraint(self)


    class EquivalenceConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def EQUIVALENCE(self):
            return self.getToken(UVLPythonParser.EQUIVALENCE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEquivalenceConstraint" ):
                listener.enterEquivalenceConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEquivalenceConstraint" ):
                listener.exitEquivalenceConstraint(self)


    class ImplicationConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def IMPLICATION(self):
            return self.getToken(UVLPythonParser.IMPLICATION, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImplicationConstraint" ):
                listener.enterImplicationConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImplicationConstraint" ):
                listener.exitImplicationConstraint(self)



    def constraint(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = UVLPythonParser.ConstraintContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 42
        self.enterRecursionRule(localctx, 42, self.RULE_constraint, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 277
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,30,self._ctx)
            if la_ == 1:
                localctx = UVLPythonParser.EquationConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 269
                self.equation()
                pass

            elif la_ == 2:
                localctx = UVLPythonParser.LiteralConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 270
                self.reference()
                pass

            elif la_ == 3:
                localctx = UVLPythonParser.ParenthesisConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 271
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 272
                self.constraint(0)
                self.state = 273
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass

            elif la_ == 4:
                localctx = UVLPythonParser.NotConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 275
                self.match(UVLPythonParser.NOT)
                self.state = 276
                self.constraint(5)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 293
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,32,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 291
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,31,self._ctx)
                    if la_ == 1:
                        localctx = UVLPythonParser.AndConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 279
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 280
                        self.match(UVLPythonParser.AND)
                        self.state = 281
                        self.constraint(5)
                        pass

                    elif la_ == 2:
                        localctx = UVLPythonParser.OrConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 282
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 283
                        self.match(UVLPythonParser.OR)
                        self.state = 284
                        self.constraint(4)
                        pass

                    elif la_ == 3:
                        localctx = UVLPythonParser.ImplicationConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 285
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 286
                        self.match(UVLPythonParser.IMPLICATION)
                        self.state = 287
                        self.constraint(3)
                        pass

                    elif la_ == 4:
                        localctx = UVLPythonParser.EquivalenceConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 288
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 289
                        self.match(UVLPythonParser.EQUIVALENCE)
                        self.state = 290
                        self.constraint(2)
                        pass

             
                self.state = 295
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class EquationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_equation

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class EqualEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def EQUAL(self):
            return self.getToken(UVLPythonParser.EQUAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualEquation" ):
                listener.enterEqualEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualEquation" ):
                listener.exitEqualEquation(self)


    class LowerEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def LOWER(self):
            return self.getToken(UVLPythonParser.LOWER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLowerEquation" ):
                listener.enterLowerEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLowerEquation" ):
                listener.exitLowerEquation(self)


    class LowerEqualsEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def LOWER_EQUALS(self):
            return self.getToken(UVLPythonParser.LOWER_EQUALS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLowerEqualsEquation" ):
                listener.enterLowerEqualsEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLowerEqualsEquation" ):
                listener.exitLowerEqualsEquation(self)


    class GreaterEqualsEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def GREATER_EQUALS(self):
            return self.getToken(UVLPythonParser.GREATER_EQUALS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGreaterEqualsEquation" ):
                listener.enterGreaterEqualsEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGreaterEqualsEquation" ):
                listener.exitGreaterEqualsEquation(self)


    class GreaterEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def GREATER(self):
            return self.getToken(UVLPythonParser.GREATER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGreaterEquation" ):
                listener.enterGreaterEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGreaterEquation" ):
                listener.exitGreaterEquation(self)


    class NotEqualsEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def NOT_EQUALS(self):
            return self.getToken(UVLPythonParser.NOT_EQUALS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNotEqualsEquation" ):
                listener.enterNotEqualsEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNotEqualsEquation" ):
                listener.exitNotEqualsEquation(self)



    def equation(self):

        localctx = UVLPythonParser.EquationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_equation)
        try:
            self.state = 320
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                localctx = UVLPythonParser.EqualEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 296
                self.expression()
                self.state = 297
                self.match(UVLPythonParser.EQUAL)
                self.state = 298
                self.expression()
                pass

            elif la_ == 2:
                localctx = UVLPythonParser.LowerEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 300
                self.expression()
                self.state = 301
                self.match(UVLPythonParser.LOWER)
                self.state = 302
                self.expression()
                pass

            elif la_ == 3:
                localctx = UVLPythonParser.GreaterEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 304
                self.expression()
                self.state = 305
                self.match(UVLPythonParser.GREATER)
                self.state = 306
                self.expression()
                pass

            elif la_ == 4:
                localctx = UVLPythonParser.LowerEqualsEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 308
                self.expression()
                self.state = 309
                self.match(UVLPythonParser.LOWER_EQUALS)
                self.state = 310
                self.expression()
                pass

            elif la_ == 5:
                localctx = UVLPythonParser.GreaterEqualsEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 312
                self.expression()
                self.state = 313
                self.match(UVLPythonParser.GREATER_EQUALS)
                self.state = 314
                self.expression()
                pass

            elif la_ == 6:
                localctx = UVLPythonParser.NotEqualsEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 316
                self.expression()
                self.state = 317
                self.match(UVLPythonParser.NOT_EQUALS)
                self.state = 318
                self.expression()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def additiveExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.AdditiveExpressionContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)




    def expression(self):

        localctx = UVLPythonParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self.additiveExpression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_additiveExpression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class MultiplicativeExprContext(AdditiveExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AdditiveExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def multiplicativeExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.MultiplicativeExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicativeExpr" ):
                listener.enterMultiplicativeExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicativeExpr" ):
                listener.exitMultiplicativeExpr(self)


    class AddExpressionContext(AdditiveExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AdditiveExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def additiveExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.AdditiveExpressionContext,0)

        def ADD(self):
            return self.getToken(UVLPythonParser.ADD, 0)
        def multiplicativeExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.MultiplicativeExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAddExpression" ):
                listener.enterAddExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAddExpression" ):
                listener.exitAddExpression(self)


    class SubExpressionContext(AdditiveExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AdditiveExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def additiveExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.AdditiveExpressionContext,0)

        def SUB(self):
            return self.getToken(UVLPythonParser.SUB, 0)
        def multiplicativeExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.MultiplicativeExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSubExpression" ):
                listener.enterSubExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSubExpression" ):
                listener.exitSubExpression(self)



    def additiveExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = UVLPythonParser.AdditiveExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 48
        self.enterRecursionRule(localctx, 48, self.RULE_additiveExpression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = UVLPythonParser.MultiplicativeExprContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 325
            self.multiplicativeExpression(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 335
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,35,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 333
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
                    if la_ == 1:
                        localctx = UVLPythonParser.AddExpressionContext(self, UVLPythonParser.AdditiveExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_additiveExpression)
                        self.state = 327
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 328
                        self.match(UVLPythonParser.ADD)
                        self.state = 329
                        self.multiplicativeExpression(0)
                        pass

                    elif la_ == 2:
                        localctx = UVLPythonParser.SubExpressionContext(self, UVLPythonParser.AdditiveExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_additiveExpression)
                        self.state = 330
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 331
                        self.match(UVLPythonParser.SUB)
                        self.state = 332
                        self.multiplicativeExpression(0)
                        pass

             
                self.state = 337
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,35,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class MultiplicativeExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_multiplicativeExpression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class PrimaryExpressionExpressionContext(MultiplicativeExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.MultiplicativeExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def primaryExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.PrimaryExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimaryExpressionExpression" ):
                listener.enterPrimaryExpressionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimaryExpressionExpression" ):
                listener.exitPrimaryExpressionExpression(self)


    class DivExpressionContext(MultiplicativeExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.MultiplicativeExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def multiplicativeExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.MultiplicativeExpressionContext,0)

        def DIV(self):
            return self.getToken(UVLPythonParser.DIV, 0)
        def primaryExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.PrimaryExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDivExpression" ):
                listener.enterDivExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDivExpression" ):
                listener.exitDivExpression(self)


    class MulExpressionContext(MultiplicativeExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.MultiplicativeExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def multiplicativeExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.MultiplicativeExpressionContext,0)

        def MUL(self):
            return self.getToken(UVLPythonParser.MUL, 0)
        def primaryExpression(self):
            return self.getTypedRuleContext(UVLPythonParser.PrimaryExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMulExpression" ):
                listener.enterMulExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMulExpression" ):
                listener.exitMulExpression(self)



    def multiplicativeExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = UVLPythonParser.MultiplicativeExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 50
        self.enterRecursionRule(localctx, 50, self.RULE_multiplicativeExpression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = UVLPythonParser.PrimaryExpressionExpressionContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 339
            self.primaryExpression()
            self._ctx.stop = self._input.LT(-1)
            self.state = 349
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,37,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 347
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,36,self._ctx)
                    if la_ == 1:
                        localctx = UVLPythonParser.MulExpressionContext(self, UVLPythonParser.MultiplicativeExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_multiplicativeExpression)
                        self.state = 341
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 342
                        self.match(UVLPythonParser.MUL)
                        self.state = 343
                        self.primaryExpression()
                        pass

                    elif la_ == 2:
                        localctx = UVLPythonParser.DivExpressionContext(self, UVLPythonParser.MultiplicativeExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_multiplicativeExpression)
                        self.state = 344
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 345
                        self.match(UVLPythonParser.DIV)
                        self.state = 346
                        self.primaryExpression()
                        pass

             
                self.state = 351
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class PrimaryExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_primaryExpression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class BracketExpressionContext(PrimaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.PrimaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBracketExpression" ):
                listener.enterBracketExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBracketExpression" ):
                listener.exitBracketExpression(self)


    class AggregateFunctionExpressionContext(PrimaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.PrimaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def aggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.AggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggregateFunctionExpression" ):
                listener.enterAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggregateFunctionExpression" ):
                listener.exitAggregateFunctionExpression(self)


    class FloatLiteralExpressionContext(PrimaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.PrimaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FLOAT(self):
            return self.getToken(UVLPythonParser.FLOAT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloatLiteralExpression" ):
                listener.enterFloatLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloatLiteralExpression" ):
                listener.exitFloatLiteralExpression(self)


    class StringLiteralExpressionContext(PrimaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.PrimaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(UVLPythonParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringLiteralExpression" ):
                listener.enterStringLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringLiteralExpression" ):
                listener.exitStringLiteralExpression(self)


    class IntegerLiteralExpressionContext(PrimaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.PrimaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INTEGER(self):
            return self.getToken(UVLPythonParser.INTEGER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntegerLiteralExpression" ):
                listener.enterIntegerLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntegerLiteralExpression" ):
                listener.exitIntegerLiteralExpression(self)


    class LiteralExpressionContext(PrimaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.PrimaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralExpression" ):
                listener.enterLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralExpression" ):
                listener.exitLiteralExpression(self)



    def primaryExpression(self):

        localctx = UVLPythonParser.PrimaryExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_primaryExpression)
        try:
            self.state = 361
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [55]:
                localctx = UVLPythonParser.FloatLiteralExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 352
                self.match(UVLPythonParser.FLOAT)
                pass
            elif token in [56]:
                localctx = UVLPythonParser.IntegerLiteralExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 353
                self.match(UVLPythonParser.INTEGER)
                pass
            elif token in [62]:
                localctx = UVLPythonParser.StringLiteralExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 354
                self.match(UVLPythonParser.STRING)
                pass
            elif token in [24, 25, 26, 27, 28]:
                localctx = UVLPythonParser.AggregateFunctionExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 355
                self.aggregateFunction()
                pass
            elif token in [60, 61]:
                localctx = UVLPythonParser.LiteralExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 356
                self.reference()
                pass
            elif token in [1]:
                localctx = UVLPythonParser.BracketExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 357
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 358
                self.expression()
                self.state = 359
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_aggregateFunction

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class NumericAggregateFunctionExpressionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def numericAggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.NumericAggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumericAggregateFunctionExpression" ):
                listener.enterNumericAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumericAggregateFunctionExpression" ):
                listener.exitNumericAggregateFunctionExpression(self)


    class StringAggregateFunctionExpressionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def stringAggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.StringAggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringAggregateFunctionExpression" ):
                listener.enterStringAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringAggregateFunctionExpression" ):
                listener.exitStringAggregateFunctionExpression(self)


    class AvgAggregateFunctionExpressionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def avgAggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.AvgAggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAvgAggregateFunctionExpression" ):
                listener.enterAvgAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAvgAggregateFunctionExpression" ):
                listener.exitAvgAggregateFunctionExpression(self)


    class SumAggregateFunctionExpressionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sumAggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.SumAggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSumAggregateFunctionExpression" ):
                listener.enterSumAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSumAggregateFunctionExpression" ):
                listener.exitSumAggregateFunctionExpression(self)



    def aggregateFunction(self):

        localctx = UVLPythonParser.AggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_aggregateFunction)
        try:
            self.state = 367
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [25]:
                localctx = UVLPythonParser.SumAggregateFunctionExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 363
                self.sumAggregateFunction()
                pass
            elif token in [26]:
                localctx = UVLPythonParser.AvgAggregateFunctionExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 364
                self.avgAggregateFunction()
                pass
            elif token in [24]:
                localctx = UVLPythonParser.StringAggregateFunctionExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 365
                self.stringAggregateFunction()
                pass
            elif token in [27, 28]:
                localctx = UVLPythonParser.NumericAggregateFunctionExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 366
                self.numericAggregateFunction()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SumAggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SUM_KEY(self):
            return self.getToken(UVLPythonParser.SUM_KEY, 0)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)

        def reference(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ReferenceContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,i)


        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def COMMA(self):
            return self.getToken(UVLPythonParser.COMMA, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_sumAggregateFunction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSumAggregateFunction" ):
                listener.enterSumAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSumAggregateFunction" ):
                listener.exitSumAggregateFunction(self)




    def sumAggregateFunction(self):

        localctx = UVLPythonParser.SumAggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_sumAggregateFunction)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 369
            self.match(UVLPythonParser.SUM_KEY)
            self.state = 370
            self.match(UVLPythonParser.OPEN_PAREN)
            self.state = 374
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.state = 371
                self.reference()
                self.state = 372
                self.match(UVLPythonParser.COMMA)


            self.state = 376
            self.reference()
            self.state = 377
            self.match(UVLPythonParser.CLOSE_PAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AvgAggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AVG_KEY(self):
            return self.getToken(UVLPythonParser.AVG_KEY, 0)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)

        def reference(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ReferenceContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,i)


        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def COMMA(self):
            return self.getToken(UVLPythonParser.COMMA, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_avgAggregateFunction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAvgAggregateFunction" ):
                listener.enterAvgAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAvgAggregateFunction" ):
                listener.exitAvgAggregateFunction(self)




    def avgAggregateFunction(self):

        localctx = UVLPythonParser.AvgAggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_avgAggregateFunction)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 379
            self.match(UVLPythonParser.AVG_KEY)
            self.state = 380
            self.match(UVLPythonParser.OPEN_PAREN)
            self.state = 384
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,41,self._ctx)
            if la_ == 1:
                self.state = 381
                self.reference()
                self.state = 382
                self.match(UVLPythonParser.COMMA)


            self.state = 386
            self.reference()
            self.state = 387
            self.match(UVLPythonParser.CLOSE_PAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringAggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_stringAggregateFunction

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class LengthAggregateFunctionContext(StringAggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.StringAggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LEN_KEY(self):
            return self.getToken(UVLPythonParser.LEN_KEY, 0)
        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLengthAggregateFunction" ):
                listener.enterLengthAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLengthAggregateFunction" ):
                listener.exitLengthAggregateFunction(self)



    def stringAggregateFunction(self):

        localctx = UVLPythonParser.StringAggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_stringAggregateFunction)
        try:
            localctx = UVLPythonParser.LengthAggregateFunctionContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 389
            self.match(UVLPythonParser.LEN_KEY)
            self.state = 390
            self.match(UVLPythonParser.OPEN_PAREN)
            self.state = 391
            self.reference()
            self.state = 392
            self.match(UVLPythonParser.CLOSE_PAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumericAggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_numericAggregateFunction

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class CeilAggregateFunctionContext(NumericAggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.NumericAggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CEIL_KEY(self):
            return self.getToken(UVLPythonParser.CEIL_KEY, 0)
        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCeilAggregateFunction" ):
                listener.enterCeilAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCeilAggregateFunction" ):
                listener.exitCeilAggregateFunction(self)


    class FloorAggregateFunctionContext(NumericAggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.NumericAggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FLOOR_KEY(self):
            return self.getToken(UVLPythonParser.FLOOR_KEY, 0)
        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloorAggregateFunction" ):
                listener.enterFloorAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloorAggregateFunction" ):
                listener.exitFloorAggregateFunction(self)



    def numericAggregateFunction(self):

        localctx = UVLPythonParser.NumericAggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_numericAggregateFunction)
        try:
            self.state = 404
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [27]:
                localctx = UVLPythonParser.FloorAggregateFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 394
                self.match(UVLPythonParser.FLOOR_KEY)
                self.state = 395
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 396
                self.reference()
                self.state = 397
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            elif token in [28]:
                localctx = UVLPythonParser.CeilAggregateFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 399
                self.match(UVLPythonParser.CEIL_KEY)
                self.state = 400
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 401
                self.reference()
                self.state = 402
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.IdContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.IdContext,i)


        def DOT(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.DOT)
            else:
                return self.getToken(UVLPythonParser.DOT, i)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_reference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReference" ):
                listener.enterReference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReference" ):
                listener.exitReference(self)




    def reference(self):

        localctx = UVLPythonParser.ReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_reference)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 411
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,43,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 406
                    self.id_()
                    self.state = 407
                    self.match(UVLPythonParser.DOT) 
                self.state = 413
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,43,self._ctx)

            self.state = 414
            self.id_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID_STRICT(self):
            return self.getToken(UVLPythonParser.ID_STRICT, 0)

        def ID_NOT_STRICT(self):
            return self.getToken(UVLPythonParser.ID_NOT_STRICT, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterId" ):
                listener.enterId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitId" ):
                listener.exitId(self)




    def id_(self):

        localctx = UVLPythonParser.IdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_id)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 416
            _la = self._input.LA(1)
            if not(_la==60 or _la==61):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING_KEY(self):
            return self.getToken(UVLPythonParser.STRING_KEY, 0)

        def INTEGER_KEY(self):
            return self.getToken(UVLPythonParser.INTEGER_KEY, 0)

        def BOOLEAN_KEY(self):
            return self.getToken(UVLPythonParser.BOOLEAN_KEY, 0)

        def REAL_KEY(self):
            return self.getToken(UVLPythonParser.REAL_KEY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_featureType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatureType" ):
                listener.enterFeatureType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatureType" ):
                listener.exitFeatureType(self)




    def featureType(self):

        localctx = UVLPythonParser.FeatureTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_featureType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 418
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 15728640) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LanguageLevelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def majorLevel(self):
            return self.getTypedRuleContext(UVLPythonParser.MajorLevelContext,0)


        def DOT(self):
            return self.getToken(UVLPythonParser.DOT, 0)

        def minorLevel(self):
            return self.getTypedRuleContext(UVLPythonParser.MinorLevelContext,0)


        def MUL(self):
            return self.getToken(UVLPythonParser.MUL, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_languageLevel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLanguageLevel" ):
                listener.enterLanguageLevel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLanguageLevel" ):
                listener.exitLanguageLevel(self)




    def languageLevel(self):

        localctx = UVLPythonParser.LanguageLevelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_languageLevel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 420
            self.majorLevel()
            self.state = 426
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 421
                self.match(UVLPythonParser.DOT)
                self.state = 424
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [31, 32, 33, 34]:
                    self.state = 422
                    self.minorLevel()
                    pass
                elif token in [52]:
                    self.state = 423
                    self.match(UVLPythonParser.MUL)
                    pass
                else:
                    raise NoViableAltException(self)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MajorLevelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOOLEAN_KEY(self):
            return self.getToken(UVLPythonParser.BOOLEAN_KEY, 0)

        def ARITHMETIC_KEY(self):
            return self.getToken(UVLPythonParser.ARITHMETIC_KEY, 0)

        def TYPE_KEY(self):
            return self.getToken(UVLPythonParser.TYPE_KEY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_majorLevel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMajorLevel" ):
                listener.enterMajorLevel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMajorLevel" ):
                listener.exitMajorLevel(self)




    def majorLevel(self):

        localctx = UVLPythonParser.MajorLevelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_majorLevel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 428
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1612709888) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MinorLevelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP_CARDINALITY_KEY(self):
            return self.getToken(UVLPythonParser.GROUP_CARDINALITY_KEY, 0)

        def FEATURE_CARDINALITY_KEY(self):
            return self.getToken(UVLPythonParser.FEATURE_CARDINALITY_KEY, 0)

        def AGGREGATE_KEY(self):
            return self.getToken(UVLPythonParser.AGGREGATE_KEY, 0)

        def STRING_CONSTRAINTS_KEY(self):
            return self.getToken(UVLPythonParser.STRING_CONSTRAINTS_KEY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_minorLevel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMinorLevel" ):
                listener.enterMinorLevel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMinorLevel" ):
                listener.exitMinorLevel(self)




    def minorLevel(self):

        localctx = UVLPythonParser.MinorLevelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_minorLevel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 430
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 32212254720) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[21] = self.constraint_sempred
        self._predicates[24] = self.additiveExpression_sempred
        self._predicates[25] = self.multiplicativeExpression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def constraint_sempred(self, localctx:ConstraintContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 1)
         

    def additiveExpression_sempred(self, localctx:AdditiveExpressionContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 2)
         

    def multiplicativeExpression_sempred(self, localctx:MultiplicativeExpressionContext, predIndex:int):
            if predIndex == 6:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 2)
         




