try:
    from .main import get_tree
except ImportError:
    pass
