Allgemeinbildender Unterricht

- Religionslehre
- Deutsch und Kommunikation
- Politik und Gesellschaft
- Sport

Fachlicher Unterricht

- Betriebswirtschaftslehre
- Ernährung und Verpflegung
- Dienstleistung und Service
- Wohn- und Funktionsbereiche
- Personenbetreuung
- Textillehre
- Englisch

Wahlpflichtfächer

- Großhaushalt
- Landwirtschaftlicher Unternehmerhaushalt/Gehobener Privathaushalt
- Gastronomie und Hotellerie
- Grundversorgung und Betreuung alter, erkrankter Menschen
- Grundversorgung, Bildung und Erziehung von Kindern
- Projektorientiertes Arbeiten

Wahlfach

- Englisch
