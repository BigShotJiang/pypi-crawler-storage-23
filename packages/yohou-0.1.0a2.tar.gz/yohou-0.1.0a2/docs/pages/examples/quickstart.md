# Quickstart

### Yohou Quickstart ([View](/examples/quickstart/) | [Editable](/examples/quickstart/edit/))

**End-to-End Time Series Forecasting with a Scikit-Learn API**

Start here for a complete tour of Yohou's capabilities. This notebook walks through data loading, building baseline forecasters, preprocessing pipelines, decomposition, cross-validation, scoring, panel data, time-weighted training, incremental learning, and interval forecasting. By the end, you'll understand how Yohou bridges scikit-learn's tabular ML ecosystem with time series forecasting.
