# Plotting

### Exploration ([View](/examples/plotting/exploration/) | [Editable](/examples/plotting/exploration/edit/))

**Exploratory Time Series Visualization**

`plot_time_series`, `plot_rolling_statistics`, `plot_boxplot`, and `plot_missing_data` across univariate, multivariate, and panel datasets.

### Correlation ([View](/examples/plotting/correlation/) | [Editable](/examples/plotting/correlation/edit/))

**Correlation and Scatter Diagnostics**

`plot_correlation_heatmap`, `plot_scatter_matrix`, `plot_cross_correlation`, and `plot_lag_scatter` for correlation analysis.

### Seasonal ([View](/examples/plotting/seasonal/) | [Editable](/examples/plotting/seasonal/edit/))

**Seasonal and Frequency Domain Analysis**

`plot_seasonality`, `plot_subseasonality`, `plot_autocorrelation`, `plot_partial_autocorrelation`, and `plot_periodogram` for seasonal diagnostics.

### Decomposition ([View](/examples/plotting/decomposition/) | [Editable](/examples/plotting/decomposition/edit/))

**STL Decomposition Visualization**

`plot_stl_components` with different component selections, robustness settings, and window parameters.

### Forecasting Visualization ([View](/examples/plotting/forecasting_visualization/) | [Editable](/examples/plotting/forecasting_visualization/edit/))

**Forecast and Prediction Interval Plots**

`plot_forecast`, `plot_components`, and `plot_time_weight` with varied parameters and configurations.

### Evaluation ([View](/examples/plotting/evaluation/) | [Editable](/examples/plotting/evaluation/edit/))

**Model Evaluation Plots**

Residual diagnostics, score time series, per-horizon analysis, model comparison bars, and calibration plots.

### Model Selection ([View](/examples/plotting/model_selection/) | [Editable](/examples/plotting/model_selection/edit/))

**CV and Hyperparameter Search Visualization**

`plot_splits` and `plot_cv_results_scatter` for cross-validation and search result visualization.

### Signal Processing ([View](/examples/plotting/signal_processing/) | [Editable](/examples/plotting/signal_processing/edit/))

**Spectrum and Phase Analysis**

`plot_spectrum` and `plot_phase` before and after Butterworth filtering. For frequency-domain diagnostics on filtered signals.

### Similarity Heatmap ([View](/examples/plotting/similarity_heatmap/) | [Editable](/examples/plotting/similarity_heatmap/edit/))

**Similarity Heatmap Visualization**

Visualize similarity matrices for distance-based weighting in conformal prediction.
