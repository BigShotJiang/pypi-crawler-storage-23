# Datasets

### Air Passengers ([View](/examples/datasets/air_passengers/) | [Editable](/examples/datasets/air_passengers/edit/))

**Classic Trend + Monthly Seasonality**

The canonical time series dataset. Explore trend and seasonal patterns with `plot_time_series`, `plot_rolling_statistics`, and `plot_seasonality`.

### Sunspots ([View](/examples/datasets/sunspots/) | [Editable](/examples/datasets/sunspots/edit/))

**Long-Term Cyclic Patterns**

Monthly sunspot counts from 1749–1984. Demonstrates autocorrelation analysis and spectrum visualization for identifying the ~11-year solar cycle.

### Australian Tourism ([View](/examples/datasets/australian_tourism/) | [Editable](/examples/datasets/australian_tourism/edit/))

**Quarterly Panel Data (8 States)**

Australian tourism demand from 1998–2017. Demonstrates `inspect_locality`, panel plotting, and boxplots for multi-group exploration.

### Australian Tourism Forecasting ([View](/examples/datasets/australian_tourism_forecasting/) | [Editable](/examples/datasets/australian_tourism_forecasting/edit/))

**Panel Forecasting Workflow**

End-to-end panel forecasting on Australian tourism: fit, predict, observe-predict, scoring, and per-group analysis across 8 states.

### Victoria Electricity ([View](/examples/datasets/vic_electricity/) | [Editable](/examples/datasets/vic_electricity/edit/))

**High-Frequency Multivariate Analysis**

30-minute demand and temperature data. Demonstrates cross-correlation, rolling statistics, and high-frequency diagnostics.

### Store Sales ([View](/examples/datasets/store_sales/) | [Editable](/examples/datasets/store_sales/edit/))

**Daily Retail Panel Data**

3 stores × 3 items over 1826 daily observations. Demonstrates panel inspection, boxplots, and seasonality analysis for retail data.

### Walmart Sales ([View](/examples/datasets/walmart_sales/) | [Editable](/examples/datasets/walmart_sales/edit/))

**Branch-Level Panel Analysis**

Walmart branches A/B/C with 89 daily observations. Explores panel inspection, boxplots, and seasonality patterns.

### Walmart Forecasting ([View](/examples/datasets/walmart_forecasting/) | [Editable](/examples/datasets/walmart_forecasting/edit/))

**Multi-Target Panel Forecasting**

Multi-target forecasting (sales + ratings) across 3 branches. Per-branch evaluation with selective group observe-predict.

### ETT-M1 ([View](/examples/datasets/ett_m1/) | [Editable](/examples/datasets/ett_m1/edit/))

**Electricity Transformer Temperature**

Multivariate analysis of 7 features at 15-minute intervals. Demonstrates cross-correlation and seasonality for industrial sensor data.

### ETT-M1 Multivariate Forecasting ([View](/examples/datasets/ett_m1_multivariate/) | [Editable](/examples/datasets/ett_m1_multivariate/edit/))

**Multivariate Forecasting with Exogenous Features**

Forecast electricity transformer temperature using `ForecastedFeatureForecaster` with exogenous features. Demonstrates the full multivariate reduction workflow.
