# yohou.model_selection

Time series cross-validation splitters and hyperparameter search.

**User guide**: See the [Model Selection](../user-guide/model-selection.md) section for further details.

## Splitters

::: yohou.model_selection.BaseSplitter
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.model_selection.ExpandingWindowSplitter
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.model_selection.SlidingWindowSplitter
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Search

::: yohou.model_selection.GridSearchCV
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.model_selection.RandomizedSearchCV
    options:
      show_root_heading: true
      show_source: true
      members_order: source
