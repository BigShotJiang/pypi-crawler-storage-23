# yohou.base

Base classes for building time series transformers and forecasters.

**User guide**: See the [Core Concepts](../user-guide/core-concepts.md) section for further details.

## Transformers

::: yohou.base.BaseTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Forecasters

::: yohou.base.BaseForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.base.BaseStandardForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.base.BasePanelForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Reduction

::: yohou.base.BaseReductionForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Types

::: yohou.base.PredictionType
    options:
      show_root_heading: true
      show_source: false
