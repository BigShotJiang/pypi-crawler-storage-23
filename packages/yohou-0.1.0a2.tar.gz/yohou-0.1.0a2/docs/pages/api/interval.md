# yohou.interval

Interval forecasters for generating prediction intervals with uncertainty quantification.

**User guide**: See the [Interval Forecasting](../user-guide/interval-forecasting.md) section for further details.

## Base

::: yohou.interval.BaseIntervalForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Similarity

::: yohou.interval.BaseSimilarity
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.interval.DistanceSimilarity
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Reduction

::: yohou.interval.IntervalReductionForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Conformal

::: yohou.interval.SplitConformalForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source
