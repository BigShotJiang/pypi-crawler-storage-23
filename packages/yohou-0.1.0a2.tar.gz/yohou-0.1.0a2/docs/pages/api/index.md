# API Reference

Complete API reference for all Yohou modules. Each page documents every public class and function with parameters, return values, and examples auto-generated from docstrings.

| Module | Description |
|--------|-------------|
| [`yohou.base`](base.md) | Base classes for transformers, forecasters, and the reduction pattern |
| [`yohou.compose`](compose.md) | Pipelines, feature unions, column transformers, and decomposition |
| [`yohou.point`](point.md) | Point forecasters: naive baselines and reduction-based |
| [`yohou.interval`](interval.md) | Interval forecasters: conformal, reduction, and similarity-based |
| [`yohou.metrics`](metrics.md) | Point, interval, and conformity scorers |
| [`yohou.model_selection`](model-selection.md) | Cross-validation splitters and hyperparameter search |
| [`yohou.preprocessing`](preprocessing.md) | Time series transformers, sklearn wrappers, imputation, and outlier handling |
| [`yohou.stationarity`](stationarity.md) | Trend, seasonality, and stationarity transforms |
| [`yohou.plotting`](plotting.md) | Plotly-based visualization functions |
| [`yohou.datasets`](datasets.md) | Bundled time series dataset loaders |
| [`yohou.utils`](utils.md) | Validation, panel data, weighting, tags, and discovery utilities |
| [`yohou.testing`](testing.md) | Systematic check functions for testing custom estimators |
