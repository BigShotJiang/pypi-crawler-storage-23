# yohou.point

Point forecasters for generating single-value predictions.

**User guide**: See the [Forecasting](../user-guide/forecasting.md) section for further details.

## Base

::: yohou.point.BasePointForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Naive

::: yohou.point.SeasonalNaive
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Reduction

::: yohou.point.PointReductionForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source
