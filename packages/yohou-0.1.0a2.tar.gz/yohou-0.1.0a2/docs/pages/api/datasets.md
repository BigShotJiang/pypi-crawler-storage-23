# yohou.datasets

Bundled time series dataset loaders. Each function returns a `polars.DataFrame` with a `"time"` column.

**User guide**: See the [Core Concepts](../user-guide/core-concepts.md) section for data format details.

## Dataset Loaders

::: yohou.datasets.load_air_passengers
    options:
      show_root_heading: true
      show_source: false

::: yohou.datasets.load_sunspots
    options:
      show_root_heading: true
      show_source: false

::: yohou.datasets.load_australian_tourism
    options:
      show_root_heading: true
      show_source: false

::: yohou.datasets.load_vic_electricity
    options:
      show_root_heading: true
      show_source: false

::: yohou.datasets.load_store_sales
    options:
      show_root_heading: true
      show_source: false

::: yohou.datasets.load_walmart_sales
    options:
      show_root_heading: true
      show_source: false

::: yohou.datasets.load_ett_m1
    options:
      show_root_heading: true
      show_source: false
