# yohou.utils

Validation, panel data, weighting, tags, discovery, and other utility functions.

**User guide**: See the [Advanced Topics](../user-guide/advanced.md) and [Core Concepts](../user-guide/core-concepts.md) sections for further details.

## Tags

::: yohou.utils.Tags
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.utils.InputTags
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.utils.TargetTags
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.utils.ForecasterTags
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.utils.TransformerTags
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.utils.SplitterTags
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Discovery

::: yohou.utils.all_estimators
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.all_displays
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.all_functions
    options:
      show_root_heading: true
      show_source: false

## Panel Data

::: yohou.utils.inspect_locality
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.get_group_df
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.select_panel_columns
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.dict_to_panel
    options:
      show_root_heading: true
      show_source: false

## Tabularization

::: yohou.utils.tabularize
    options:
      show_root_heading: true
      show_source: false

## Polars Utilities

::: yohou.utils.cast
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.get_numeric_columns
    options:
      show_root_heading: true
      show_source: false

## Validation

::: yohou.utils.check_time_column
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_interval_consistency
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_continuity
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_schema
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_inputs
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_sufficient_rows
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_exogenous_required
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_forecasting_horizon_positive
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_panel_group_names
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_panel_group_names_exist
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_panel_groups_match
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_panel_internal_consistency
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.check_scorer_column_selection
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_column_names
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_search_data
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_forecaster_data
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_plotting_data
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_scorer_data
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_splitter_data
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_time_weight
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_transformer_data
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.add_interval
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.parse_interval
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.interval_to_timedelta
    options:
      show_root_heading: true
      show_source: false

## Weighting

::: yohou.utils.exponential_decay_weight
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.linear_decay_weight
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.seasonal_emphasis_weight
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.compose_weights
    options:
      show_root_heading: true
      show_source: false

::: yohou.utils.validate_callable_signature
    options:
      show_root_heading: true
      show_source: false
