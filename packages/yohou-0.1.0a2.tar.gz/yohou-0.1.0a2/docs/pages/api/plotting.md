# yohou.plotting

Interactive time series visualization functions using Plotly. All plotting functions support panel data via the `panel_group_names` parameter.

**User guide**: See the [Visualization](../user-guide/visualization.md) section for further details.

## Exploration

::: yohou.plotting.plot_time_series
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_rolling_statistics
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_boxplot
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_missing_data
    options:
      show_root_heading: true
      show_source: false

## Diagnostics

::: yohou.plotting.plot_autocorrelation
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_partial_autocorrelation
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_correlation_heatmap
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_seasonality
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_lag_scatter
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_cross_correlation
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_scatter_matrix
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_stl_components
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_subseasonality
    options:
      show_root_heading: true
      show_source: false

## Forecasting

::: yohou.plotting.plot_forecast
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_components
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_time_weight
    options:
      show_root_heading: true
      show_source: false

## Evaluation

::: yohou.plotting.plot_residual_time_series
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_calibration
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_score_time_series
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_model_comparison_bar
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_score_distribution
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_score_per_horizon
    options:
      show_root_heading: true
      show_source: false

## Model Selection

::: yohou.plotting.plot_splits
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_cv_results_scatter
    options:
      show_root_heading: true
      show_source: false

## Signal

::: yohou.plotting.plot_spectrum
    options:
      show_root_heading: true
      show_source: false

::: yohou.plotting.plot_phase
    options:
      show_root_heading: true
      show_source: false

## Utilities

::: yohou.plotting.palette_yohou
    options:
      show_root_heading: true
      show_source: false
