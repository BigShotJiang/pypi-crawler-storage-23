# yohou.compose

Composition classes for combining forecasters and transformers into complex workflows.

**User guide**: See the [Forecasting](../user-guide/forecasting.md), [Preprocessing](../user-guide/preprocessing.md), and [Stationarity](../user-guide/stationarity.md) sections for further details.

## Pipelines

::: yohou.compose.FeaturePipeline
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.compose.FeatureUnion
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Column Operations

::: yohou.compose.ColumnTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.compose.ColumnForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Decomposition

::: yohou.compose.DecompositionPipeline
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Feature Forecasting

::: yohou.compose.ForecastedFeatureForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Panel Forecasting

::: yohou.compose.LocalPanelForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source
