# yohou.preprocessing

Time series transformers for feature engineering, scaling, imputation, outlier handling, and resampling.

**User guide**: See the [Preprocessing](../user-guide/preprocessing.md) section for further details.

## Function Transformers

::: yohou.preprocessing.FunctionTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Window Transformers

::: yohou.preprocessing.RollingStatisticsTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.ExponentialMovingAverage
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.LagTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.SlidingWindowFunctionTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Signal Processing

::: yohou.preprocessing.NumericalFilter
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.NumericalDifferentiator
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.NumericalIntegrator
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Resampling

::: yohou.preprocessing.Downsampler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.Upsampler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Sklearn Scalers

::: yohou.preprocessing.SklearnScaler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.StandardScaler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.MinMaxScaler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.RobustScaler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.MaxAbsScaler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Sklearn Transformers

::: yohou.preprocessing.SklearnTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.Normalizer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.PolynomialFeatures
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.PowerTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.QuantileTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.SplineTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Imputation

::: yohou.preprocessing.SimpleImputer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.TransformedSpaceKNNImputer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.SimpleTimeImputer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.SeasonalImputer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Outlier Handling

::: yohou.preprocessing.OutlierThresholdHandler
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.preprocessing.OutlierPercentileHandler
    options:
      show_root_heading: true
      show_source: true
      members_order: source
