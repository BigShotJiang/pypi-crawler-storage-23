# yohou.stationarity

Trend and seasonality estimation, stationarity transforms, and decomposition components.

**User guide**: See the [Stationarity](../user-guide/stationarity.md) section for further details.

## Stationarity Transforms

::: yohou.stationarity.SeasonalDifferencing
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.stationarity.SeasonalLogDifferencing
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.stationarity.SeasonalReturn
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.stationarity.AbsoluteSeasonalReturn
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.stationarity.LogTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.stationarity.BoxCoxTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.stationarity.ASinhTransformer
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Trend Forecasters

::: yohou.stationarity.PolynomialTrendForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

## Seasonality Forecasters

::: yohou.stationarity.FourierSeasonalityForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source

::: yohou.stationarity.PatternSeasonalityForecaster
    options:
      show_root_heading: true
      show_source: true
      members_order: source
