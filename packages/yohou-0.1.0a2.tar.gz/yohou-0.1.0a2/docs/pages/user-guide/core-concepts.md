# Core Concepts

This chapter introduces the foundational concepts that underpin all of Yohou. Understanding these concepts is essential for working effectively with the library.

!!! info "Under Development"
    This chapter is being written. Section headings show the planned structure.

**API Reference**: [`yohou.base`](../api/base.md) · [`yohou.utils`](../api/utils.md)

## Data Format

### The Time Column

### Polars DataFrames

### Univariate vs. Multivariate

### Panel Data Convention

## The Forecasting Lifecycle

### fit

### predict

### observe

### rewind

### observe_predict

## Observation Horizon

## Tags and Metadata

### Estimator Tags

### Input and Target Tags

## Working with Your Own Data

### From CSV

### From Pandas

### Expected Schema
