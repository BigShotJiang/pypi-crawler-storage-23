# Interval Forecasting

This chapter covers prediction intervals, quantifying uncertainty in forecasts through conformal prediction, similarity-based weighting, and coverage rate control.

!!! info "Under Development"
    This chapter is being written. Section headings show the planned structure.

**API Reference**: [`yohou.interval`](../api/interval.md)
**Examples**: [Interval Forecasting](../examples/interval.md)

## Interval Forecasting Overview

## Split Conformal Prediction

### Calibration and Coverage

### Conformity Scorers

## Reduction-Based Intervals

### IntervalReductionForecaster

## Similarity-Based Weighting

### DistanceSimilarity

### Weighted Quantiles

## Coverage Rates

### Setting Coverage Rates

### Evaluating Calibration
