# Advanced Topics

This chapter covers advanced capabilities for power users: panel data workflows, metadata routing, time weighting, and extending Yohou with custom estimators.

!!! info "Under Development"
    This chapter is being written. Section headings show the planned structure.

**API Reference**: [`yohou.utils`](../api/utils.md) · [`yohou.base`](../api/base.md) · [`yohou.testing`](../api/testing.md)

## Panel Data

### Column Naming Convention

### inspect_locality and get_group_df

### Panel-Aware Forecasting

### Panel-Aware Scoring

### Panel-Aware Visualization

## Metadata Routing

### How Routing Works

### time_weight Support

### Custom Routing

## Time Weighting

### exponential_decay_weight

### linear_decay_weight

### seasonal_emphasis_weight

### compose_weights

## Custom Estimators

### Creating a Custom Forecaster

### Creating a Custom Transformer

### Creating a Custom Scorer

### Creating a Custom Splitter

### Testing with Systematic Checks
