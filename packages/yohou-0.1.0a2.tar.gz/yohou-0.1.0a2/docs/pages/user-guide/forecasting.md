# Forecasting

This chapter covers point forecasting in Yohou, from simple naive baselines to reduction-based forecasters that leverage any sklearn regressor, including multi-column and feature forecasting compositions.

!!! info "Under Development"
    This chapter is being written. Section headings show the planned structure.

**API Reference**: [`yohou.point`](../api/point.md) · [`yohou.compose`](../api/compose.md)
**Examples**: [Point Forecasting](../examples/point.md) · [Quick Start](../examples/quickstart.md)

## Point Forecasting Overview

## Seasonal Naive

## Reduction Forecasting

### Tabularization

### Window Length

### Recursive Prediction

### Choosing an sklearn Estimator

## Column Forecasting

### ColumnForecaster

### Separate Forecasters per Column

### Remainder Handling

## Feature Forecasting

### ForecastedFeatureForecaster

### Chaining Target and Feature Forecasters

## Exogenous Features
