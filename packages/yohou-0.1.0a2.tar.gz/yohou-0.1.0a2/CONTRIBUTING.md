# Contributing

Please see [docs/contributing.md](docs/development/contributing.md) for detailed contribution guidelines.
