"""Tests for yohou.testing check functions."""
