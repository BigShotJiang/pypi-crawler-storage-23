"""Init file for compose submodule tests."""
