"""Metrics and scorers examples."""
