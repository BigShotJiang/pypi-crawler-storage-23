"""Interval forecaster examples."""
