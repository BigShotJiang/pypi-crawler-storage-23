"""Stationarity and decomposition examples."""
