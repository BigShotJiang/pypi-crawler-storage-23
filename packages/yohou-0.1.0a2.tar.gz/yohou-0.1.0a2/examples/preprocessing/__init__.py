"""Preprocessing transformer examples."""
