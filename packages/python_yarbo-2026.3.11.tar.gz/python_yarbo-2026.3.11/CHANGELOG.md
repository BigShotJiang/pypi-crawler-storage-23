See [docs/CHANGELOG.md](docs/CHANGELOG.md) for the full changelog.

Release notes for each version are in [docs/releases/](docs/releases/).
