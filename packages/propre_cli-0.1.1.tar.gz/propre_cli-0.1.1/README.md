# Propre CLI

**Propre** is a post-vibe-coding cleanup and hardening CLI.

It analyzes AI-generated or rapidly prototyped codebases and prepares them for real-world use by detecting structural issues, unsafe patterns, and production blockers — then optionally fixing them.

> From messy prototype → production-ready project.

---

## Installation

```bash
pip install propre-cli
```

---

## Quick Start

Analyze a project:

```bash
propre scan .
```

Auto-fix safe issues:

```bash
propre fix .
```

Check production readiness:

```bash
propre ship .
```

Generate a report:

```bash
propre report . -o report.md
```

---

## Commands

| Command                        | Description                    |
| ------------------------------ | ------------------------------ |
| `propre scan [path]`           | Full analysis (no changes)     |
| `propre fix [path]`            | Auto-fix safe issues           |
| `propre res [path]`            | Project restructuring only     |
| `propre sec [path]`            | Secret scanning only           |
| `propre ship [path]`           | Production readiness checklist |
| `propre report [path] -o file` | Export full report             |

---

## Common Workflows

### Before committing AI-generated code

```bash
propre scan .
```

### Before opening a pull request

```bash
propre fix .
propre ship .
```

### CI safety check

```bash
propre scan . --ci
```

### Security audit

```bash
propre sec . --deep-scan
```

---

## Global Flags

| Flag                  | Description                            |      |        |               |
| --------------------- | -------------------------------------- | ---- | ------ | ------------- |
| `--dry-run`           | Preview changes without applying       |      |        |               |
| `--verbose` / `-v`    | Detailed output                        |      |        |               |
| `--config propre.yml` | Custom rules                           |      |        |               |
| `--fix`               | Apply safe fixes outside `fix` command |      |        |               |
| `--ignore <pattern>`  | Exclude paths                          |      |        |               |
| `--ci`                | Exit non-zero if blockers found        |      |        |               |
| `--format terminal    | md                                     | json | sarif` | Output format |

---

## Configuration

Create a `propre.yml` at your project root:

```yaml
stack: auto

restructure:
    enabled: true
    confirm: true

secrets:
    deep_scan: false
    severity_threshold: medium

rules:
    dead_code: warn
    console_logs: error
    missing_types: warn
    hardcoded_config: error

ignore:
    - node_modules/
    - .git/
    - dist/
```

---

## What Propre Detects

- Dead code & unused files
- Debug logs & leftover prints
- Missing typing
- Hardcoded configuration
- Project structure issues
- Secrets & credentials
- Production blockers

---

## CI Integration

Example GitHub Action step:

```bash
propre scan . --ci
```

The command exits with a non-zero code if blocking issues are found.

---

## Philosophy

Modern coding workflows generate code faster than they validate it.

Propre acts as the **final safety layer** between experimentation and deployment:

- AI coding assistants create
- Developers iterate
- **Propre hardens**

---

## License

MIT
