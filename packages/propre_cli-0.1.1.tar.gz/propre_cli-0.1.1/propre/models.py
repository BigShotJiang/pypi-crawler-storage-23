from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class OutputFormat(str, Enum):
    TERMINAL = "terminal"
    MD = "md"
    JSON = "json"
    SARIF = "sarif"


SEVERITY_ORDER: dict[Severity, int] = {
    Severity.CRITICAL: 5,
    Severity.HIGH: 4,
    Severity.MEDIUM: 3,
    Severity.LOW: 2,
    Severity.INFO: 1,
}


@dataclass(slots=True)
class Finding:
    phase: str
    title: str
    message: str
    severity: Severity
    file_path: str | None = None
    line: int | None = None
    recommendation: str | None = None
    category: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "phase": self.phase,
            "title": self.title,
            "message": self.message,
            "severity": self.severity.value,
            "file_path": self.file_path,
            "line": self.line,
            "recommendation": self.recommendation,
            "category": self.category,
        }


@dataclass(slots=True)
class FixAction:
    phase: str
    description: str
    path: str | None = None
    applied: bool = False
    safe: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class CheckItem:
    name: str
    passed: bool
    details: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class PhaseResult:
    name: str
    findings: list[Finding] = field(default_factory=list)
    fixes: list[FixAction] = field(default_factory=list)
    checks: list[CheckItem] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    duration_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "findings": [f.to_dict() for f in self.findings],
            "fixes": [f.to_dict() for f in self.fixes],
            "checks": [c.to_dict() for c in self.checks],
            "metadata": self.metadata,
            "errors": self.errors,
            "duration_ms": self.duration_ms,
        }


@dataclass(slots=True)
class PropreReport:
    project_path: str
    phases: list[PhaseResult] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    started_at: datetime = field(default_factory=datetime.utcnow)
    ended_at: datetime | None = None

    def add_phase(self, phase: PhaseResult) -> None:
        self.phases.append(phase)

    def all_findings(self) -> list[Finding]:
        findings: list[Finding] = []
        for phase in self.phases:
            findings.extend(phase.findings)
        return findings

    def all_fixes(self) -> list[FixAction]:
        fixes: list[FixAction] = []
        for phase in self.phases:
            fixes.extend(phase.fixes)
        return fixes

    def total_checks(self) -> tuple[int, int]:
        passed = 0
        total = 0
        for phase in self.phases:
            for check in phase.checks:
                total += 1
                if check.passed:
                    passed += 1
        return passed, total

    def has_blockers(self) -> bool:
        findings = self.all_findings()
        if any(SEVERITY_ORDER[f.severity] >= SEVERITY_ORDER[Severity.HIGH] for f in findings):
            return True
        return any(phase.errors for phase in self.phases)

    def to_dict(self) -> dict[str, Any]:
        passed, total = self.total_checks()
        return {
            "project_path": self.project_path,
            "metadata": self.metadata,
            "started_at": self.started_at.isoformat(),
            "ended_at": self.ended_at.isoformat() if self.ended_at else None,
            "checks": {"passed": passed, "total": total},
            "phases": [phase.to_dict() for phase in self.phases],
        }


def coerce_severity(value: str | None, default: Severity = Severity.MEDIUM) -> Severity:
    if not value:
        return default
    upper = value.upper()
    for sev in Severity:
        if sev.value == upper:
            return sev
    return default
