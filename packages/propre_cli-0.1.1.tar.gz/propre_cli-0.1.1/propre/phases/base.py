from __future__ import annotations

from abc import ABC, abstractmethod

from propre.context import RunContext
from propre.models import PhaseResult, PropreReport


class PhasePlugin(ABC):
    name: str

    @abstractmethod
    def run(self, ctx: RunContext, report: PropreReport) -> PhaseResult:
        raise NotImplementedError
