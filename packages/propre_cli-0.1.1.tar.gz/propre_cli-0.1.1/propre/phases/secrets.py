from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from propre.context import RunContext
from propre.models import Finding, FixAction, PhaseResult, PropreReport, Severity, coerce_severity
from propre.phases.base import PhasePlugin
from propre.utils.entropy import looks_like_secret_token
from propre.utils.fs import iter_files, read_text, relative_path
from propre.utils.process import run_command


@dataclass(slots=True)
class SecretPattern:
    title: str
    regex: re.Pattern[str]
    severity: Severity


SECRET_PATTERNS = [
    SecretPattern("Private key material", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"), Severity.CRITICAL),
    SecretPattern("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b"), Severity.HIGH),
    SecretPattern("JWT token", re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-.]{10,}\.[A-Za-z0-9_\-.]{10,}\b"), Severity.HIGH),
    SecretPattern(
        "Credential-like assignment",
        re.compile(r"(?i)\b(api[_-]?key|token|secret|password)\b\s*[:=]\s*['\"][^'\"\n]{8,}['\"]"),
        Severity.HIGH,
    ),
    SecretPattern("Database connection string", re.compile(r"(?i)\b(postgres|mysql|mongodb|redis)://[^\s'\"]+"), Severity.HIGH),
    SecretPattern(
        "Internal IP address",
        re.compile(r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})\b"),
        Severity.MEDIUM,
    ),
    SecretPattern("Cloud resource identifier", re.compile(r"\barn:aws:[^\s'\"]+"), Severity.MEDIUM),
]

TOKEN_RE = re.compile(r"\b[A-Za-z0-9_\-+=/]{20,}\b")
PROCESS_ENV_RE = re.compile(r"\bprocess\.env\.([A-Z][A-Z0-9_]{2,})\b")
OS_GETENV_RE = re.compile(r"\bos\.getenv\(\s*['\"]([A-Z][A-Z0-9_]{2,})['\"]\s*\)")
OS_ENVIRON_RE = re.compile(r"\bos\.environ\[\s*['\"]([A-Z][A-Z0-9_]{2,})['\"]\s*\]")
ENV_LINE_RE = re.compile(r"^([A-Z][A-Z0-9_]{2,})\s*=", re.MULTILINE)


def _severity_at_least(value: Severity, threshold: Severity) -> bool:
    order = {
        Severity.CRITICAL: 5,
        Severity.HIGH: 4,
        Severity.MEDIUM: 3,
        Severity.LOW: 2,
        Severity.INFO: 1,
    }
    return order[value] >= order[threshold]


def _collect_env_vars(path: Path, text: str) -> set[str]:
    vars_found = set(PROCESS_ENV_RE.findall(text))
    vars_found.update(OS_GETENV_RE.findall(text))
    vars_found.update(OS_ENVIRON_RE.findall(text))
    if path.name.startswith(".env"):
        vars_found.update(ENV_LINE_RE.findall(text))
    return vars_found


def _append_gitignore_entries(project_path: Path, entries: list[str]) -> int:
    gitignore_path = project_path / ".gitignore"
    existing = set()
    if gitignore_path.exists():
        existing = {line.strip() for line in gitignore_path.read_text(encoding="utf-8").splitlines()}

    missing = [entry for entry in entries if entry not in existing]
    if not missing:
        return 0

    with gitignore_path.open("a", encoding="utf-8") as handle:
        if existing:
            handle.write("\n")
        for entry in missing:
            handle.write(entry + "\n")
    return len(missing)


def _update_env_example(project_path: Path, env_vars: set[str]) -> bool:
    if not env_vars:
        return False

    env_example = project_path / ".env.example"
    lines: list[str] = []
    if env_example.exists():
        lines = env_example.read_text(encoding="utf-8", errors="ignore").splitlines()

    existing_keys = {
        line.split("=", 1)[0].strip()
        for line in lines
        if "=" in line and not line.strip().startswith("#")
    }

    additions = sorted(var for var in env_vars if var not in existing_keys)
    if not additions:
        return False

    if lines and lines[-1].strip():
        lines.append("")
    lines.extend([f"{name}=changeme" for name in additions])
    env_example.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return True


def _scan_git_history(project_path: Path, threshold: Severity) -> list[Finding]:
    findings: list[Finding] = []
    rc, stdout, _ = run_command(
        ["git", "log", "--all", "-p", "-n", "200", "--no-color"],
        cwd=project_path,
        timeout=45,
    )
    if rc != 0:
        return findings

    for pattern in SECRET_PATTERNS:
        if not _severity_at_least(pattern.severity, threshold):
            continue
        matches = list(pattern.regex.finditer(stdout))
        for _ in matches[:20]:
            findings.append(
                Finding(
                    phase="secrets",
                    title=f"Historical secret: {pattern.title}",
                    message="Potential secret-like value found in git history diff output.",
                    severity=pattern.severity,
                    file_path="git-history",
                    recommendation="Rotate exposed credentials and consider history rewriting if needed.",
                    category="secrets",
                )
            )
    return findings


class SecretsPhase(PhasePlugin):
    name = "secrets"

    def run(self, ctx: RunContext, report: PropreReport) -> PhaseResult:
        result = PhaseResult(name=self.name)

        threshold = coerce_severity(ctx.config.secrets.severity_threshold, default=Severity.MEDIUM)
        findings: list[Finding] = []
        dedupe: set[tuple[str, str, int | None]] = set()
        env_vars: set[str] = set()

        for path in iter_files(ctx.project_path, ctx.merged_ignores()):
            text = read_text(path)
            if text is None:
                continue

            rel = relative_path(path, ctx.project_path)
            env_vars.update(_collect_env_vars(path, text))

            lines = text.splitlines()
            for line_no, line in enumerate(lines, start=1):
                for pattern in SECRET_PATTERNS:
                    if not _severity_at_least(pattern.severity, threshold):
                        continue
                    if not pattern.regex.search(line):
                        continue
                    key = (pattern.title, rel, line_no)
                    if key in dedupe:
                        continue
                    dedupe.add(key)
                    findings.append(
                        Finding(
                            phase=self.name,
                            title=pattern.title,
                            message="Potential secret or sensitive value detected.",
                            severity=pattern.severity,
                            file_path=rel,
                            line=line_no,
                            recommendation="Move value to environment variables and rotate credentials.",
                            category="secrets",
                        )
                    )

                for token in TOKEN_RE.findall(line):
                    if not looks_like_secret_token(token):
                        continue
                    key = ("High entropy token", rel, line_no)
                    if key in dedupe:
                        continue
                    dedupe.add(key)
                    entropy_finding = Finding(
                        phase=self.name,
                        title="High entropy token",
                        message="Suspicious high-entropy token detected; may be obfuscated secret.",
                        severity=Severity.MEDIUM,
                        file_path=rel,
                        line=line_no,
                        recommendation="Verify token origin; relocate secrets to secure env vars.",
                        category="secrets",
                    )
                    if _severity_at_least(entropy_finding.severity, threshold):
                        findings.append(entropy_finding)

        if ctx.effective_deep_scan():
            findings.extend(_scan_git_history(ctx.project_path, threshold))

        result.findings.extend(findings)

        secret_ignore_entries: set[str] = set()
        for candidate in [
            ".env",
            ".env.local",
            ".env.production",
            "*.pem",
            "*.key",
            "id_rsa",
        ]:
            if candidate.startswith("*"):
                secret_ignore_entries.add(candidate)
                continue
            if (ctx.project_path / candidate).exists():
                secret_ignore_entries.add(candidate)

        if ctx.options.apply_changes and not ctx.options.dry_run:
            if _update_env_example(ctx.project_path, env_vars):
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description="Updated .env.example with detected environment variables",
                        path=".env.example",
                        applied=True,
                    )
                )
            elif env_vars:
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description=".env.example already contained detected environment variables",
                        path=".env.example",
                        applied=True,
                    )
                )

            appended = _append_gitignore_entries(ctx.project_path, sorted(secret_ignore_entries))
            if appended:
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description=f"Added {appended} secret-related entries to .gitignore",
                        path=".gitignore",
                        applied=True,
                    )
                )
        else:
            if env_vars:
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description="Would update .env.example with detected environment variables",
                        path=".env.example",
                        applied=False,
                    )
                )
            if secret_ignore_entries:
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description="Would add secret-related file patterns to .gitignore",
                        path=".gitignore",
                        applied=False,
                    )
                )

        return result
