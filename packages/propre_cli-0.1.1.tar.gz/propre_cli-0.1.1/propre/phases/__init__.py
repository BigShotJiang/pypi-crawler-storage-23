from __future__ import annotations

from propre.phases.base import PhasePlugin
from propre.phases.harden import HardenPhase
from propre.phases.restructure import RestructurePhase
from propre.phases.scan import ScanPhase
from propre.phases.secrets import SecretsPhase
from propre.phases.ship import ShipPhase


def build_default_plugins() -> list[PhasePlugin]:
    return [
        ScanPhase(),
        RestructurePhase(),
        SecretsPhase(),
        HardenPhase(),
        ShipPhase(),
    ]
