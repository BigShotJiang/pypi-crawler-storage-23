from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from propre.constants import FRAMEWORK_DEPENDENCIES, MANIFEST_FILES, SOURCE_SUFFIXES
from propre.context import RunContext
from propre.models import Finding, PhaseResult, PropreReport, Severity
from propre.phases.base import PhasePlugin
from propre.utils.fs import iter_files, read_text, relative_path
from propre.utils.imports import extract_imports

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib


def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def detect_stacks(project_path: Path) -> list[str]:
    stacks: set[str] = set()
    if (project_path / "package.json").exists():
        stacks.add("node")
    if (project_path / "pyproject.toml").exists() or (project_path / "requirements.txt").exists():
        stacks.add("python")
    if (project_path / "Cargo.toml").exists():
        stacks.add("rust")
    if (project_path / "go.mod").exists():
        stacks.add("go")
    if (project_path / "Gemfile").exists():
        stacks.add("ruby")
    return sorted(stacks)


def collect_dependencies(project_path: Path, stacks: list[str]) -> dict[str, list[str]]:
    dependencies: dict[str, list[str]] = {}

    if "node" in stacks and (project_path / "package.json").exists():
        package_json = _read_json(project_path / "package.json")
        deps = set(package_json.get("dependencies", {}).keys())
        deps.update(package_json.get("devDependencies", {}).keys())
        dependencies["node"] = sorted(deps)

    if "python" in stacks:
        pyproject = project_path / "pyproject.toml"
        requirements = project_path / "requirements.txt"

        dep_set: set[str] = set()
        if pyproject.exists():
            try:
                parsed = tomllib.loads(pyproject.read_text(encoding="utf-8"))
                project_deps = parsed.get("project", {}).get("dependencies", [])
                for dep in project_deps:
                    if isinstance(dep, str):
                        dep_set.add(dep.split("[")[0].split("=")[0].split("<")[0].split(">")[0].strip())
            except Exception:  # noqa: BLE001
                pass
        if requirements.exists():
            for line in requirements.read_text(encoding="utf-8", errors="ignore").splitlines():
                clean = line.strip()
                if not clean or clean.startswith("#"):
                    continue
                dep_set.add(clean.split("=")[0].split("<")[0].split(">")[0].strip())
        dependencies["python"] = sorted(d for d in dep_set if d)

    return dependencies


def detect_framework(project_path: Path, dependencies: dict[str, list[str]]) -> str:
    dep_index = {d.lower() for values in dependencies.values() for d in values}

    for framework, markers in FRAMEWORK_DEPENDENCIES.items():
        if any(marker.lower() in dep_index for marker in markers):
            return framework

    # file-system hints
    if (project_path / "next.config.js").exists() or (project_path / "next.config.mjs").exists():
        return "nextjs"
    if (project_path / "manage.py").exists():
        return "django"
    if (project_path / "app" / "routers").exists():
        return "fastapi"
    return "unknown"


def detect_project_type(project_path: Path, stacks: list[str], framework: str) -> str:
    if (project_path / "packages").exists() or (project_path / "apps").exists():
        return "monorepo"

    if framework in {"fastapi", "express", "django", "flask"}:
        return "api"
    if framework in {"nextjs", "sveltekit", "rails"}:
        return "full-stack web app"

    if (project_path / "bin").exists() or (project_path / "main.py").exists():
        return "cli tool"
    if (project_path / "src").exists() and (project_path / "tests").exists():
        return "library/package"

    if len(stacks) > 1:
        return "polyglot project"
    return "application"


def build_module_map(ctx: RunContext) -> tuple[dict[str, list[str]], int]:
    module_graph: dict[str, list[str]] = {}
    count = 0

    for file_path in iter_files(ctx.project_path, ctx.merged_ignores()):
        if file_path.suffix.lower() not in SOURCE_SUFFIXES:
            continue
        source = read_text(file_path)
        if source is None:
            continue
        rel = relative_path(file_path, ctx.project_path)
        module_graph[rel] = extract_imports(file_path, source)
        count += 1

    return module_graph, count


class ScanPhase(PhasePlugin):
    name = "scan"

    def run(self, ctx: RunContext, report: PropreReport) -> PhaseResult:
        result = PhaseResult(name=self.name)

        manifests = [name for name in MANIFEST_FILES if (ctx.project_path / name).exists()]
        stacks = detect_stacks(ctx.project_path)
        dependencies = collect_dependencies(ctx.project_path, stacks)
        framework = detect_framework(ctx.project_path, dependencies)
        project_type = detect_project_type(ctx.project_path, stacks, framework)

        module_map, source_count = build_module_map(ctx)

        root_source_files = [
            p.name
            for p in ctx.project_path.iterdir()
            if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES
        ]

        if not stacks:
            result.findings.append(
                Finding(
                    phase=self.name,
                    title="Unknown stack",
                    message="No known stack manifest detected (package.json, pyproject.toml, Cargo.toml, etc.).",
                    severity=Severity.LOW,
                    recommendation="Add a manifest file or configure stack override in propre.yml.",
                    category="detection",
                )
            )

        if len(root_source_files) >= 12:
            result.findings.append(
                Finding(
                    phase=self.name,
                    title="Flat root structure",
                    message="Many source files are located at project root, suggesting weak separation of concerns.",
                    severity=Severity.MEDIUM,
                    recommendation="Run `propre res` to plan canonical folder layout.",
                    category="architecture",
                )
            )

        if framework == "unknown":
            result.findings.append(
                Finding(
                    phase=self.name,
                    title="Framework not identified",
                    message="Framework detection was inconclusive; stack-specific restructuring may be limited.",
                    severity=Severity.LOW,
                    recommendation="Set `stack` explicitly in propre.yml for stricter recommendations.",
                    category="detection",
                )
            )

        result.metadata = {
            "manifests": manifests,
            "stacks": stacks,
            "framework": framework,
            "project_type": project_type,
            "source_file_count": source_count,
            "dependencies": dependencies,
            "module_graph": module_map,
        }
        return result
