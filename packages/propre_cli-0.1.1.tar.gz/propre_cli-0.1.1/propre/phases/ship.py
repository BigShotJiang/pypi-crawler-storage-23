from __future__ import annotations

import re
from pathlib import Path

from propre.context import RunContext
from propre.models import CheckItem, Finding, PhaseResult, PropreReport, Severity
from propre.phases.base import PhasePlugin
from propre.utils.fs import iter_files, read_text, relative_path


def _all_text_files(root: Path, ignore_patterns: list[str]) -> list[tuple[str, str]]:
    files: list[tuple[str, str]] = []
    for path in iter_files(root, ignore_patterns):
        text = read_text(path)
        if text is None:
            continue
        files.append((relative_path(path, root), text))
    return files


def _contains_any(files: list[tuple[str, str]], patterns: list[str], flags: int = re.IGNORECASE) -> bool:
    for _, text in files:
        for pattern in patterns:
            if re.search(pattern, text, flags):
                return True
    return False


class ShipPhase(PhasePlugin):
    name = "ship"

    def run(self, ctx: RunContext, report: PropreReport) -> PhaseResult:
        result = PhaseResult(name=self.name)
        files = _all_text_files(ctx.project_path, ctx.merged_ignores())

        checks: list[CheckItem] = []

        checks.append(
            CheckItem(
                name="HTTPS/TLS configuration",
                passed=_contains_any(files, [r"https://", r"ssl", r"tls", r"force_https"]),
                details="Project mentions TLS/HTTPS-related configuration.",
            )
        )

        cors_configured = _contains_any(files, [r"cors", r"CORS"])
        cors_wildcard = _contains_any(files, [r"Access-Control-Allow-Origin\s*[:=]\s*['\"]\*['\"]", r"origin\s*:\s*['\"]\*['\"]"])
        checks.append(
            CheckItem(
                name="CORS configured safely",
                passed=cors_configured and not cors_wildcard,
                details="CORS appears configured and wildcard policy not detected.",
            )
        )

        checks.append(
            CheckItem(
                name="Rate limiting",
                passed=_contains_any(files, [r"rate[-_ ]?limit", r"slowapi", r"throttle", r"django-ratelimit"]),
                details="Rate limiting middleware or library usage detected.",
            )
        )

        checks.append(
            CheckItem(
                name="Authentication/authorization middleware",
                passed=_contains_any(files, [r"jwt", r"passport", r"auth", r"oauth", r"middleware.*auth"]),
                details="Auth-related middleware or checks detected.",
            )
        )

        checks.append(
            CheckItem(
                name="Versioned migrations",
                passed=(ctx.project_path / "migrations").exists()
                or (ctx.project_path / "alembic").exists()
                or (ctx.project_path / "prisma" / "migrations").exists(),
                details="Migration directory detected.",
            )
        )

        dockerfile = ctx.project_path / "Dockerfile"
        docker_ok = False
        if dockerfile.exists():
            text = dockerfile.read_text(encoding="utf-8", errors="ignore")
            docker_ok = "USER " in text and "latest" not in text.lower()
        checks.append(
            CheckItem(
                name="Docker/deployment config best-practice",
                passed=docker_ok,
                details="Dockerfile exists and appears to avoid root/latest anti-patterns.",
            )
        )

        cicd_exists = (ctx.project_path / ".github" / "workflows").exists() or (ctx.project_path / ".gitlab-ci.yml").exists()
        checks.append(
            CheckItem(
                name="CI/CD pipeline configuration",
                passed=cicd_exists,
                details="GitHub Actions or GitLab CI configuration detected.",
            )
        )

        tests_exist = (ctx.project_path / "tests").exists() or (ctx.project_path / "test").exists()
        coverage_config = _contains_any(files, [r"coverage", r"--cov", r"coverageThreshold"])
        checks.append(
            CheckItem(
                name="Tests with coverage threshold",
                passed=tests_exist and coverage_config,
                details="Tests folder and coverage-related config found.",
            )
        )

        linter_exists = any(
            (ctx.project_path / name).exists()
            for name in [".eslintrc", ".eslintrc.js", "ruff.toml", "pyproject.toml", ".flake8", "pylintrc"]
        )
        checks.append(
            CheckItem(
                name="Linter configuration",
                passed=linter_exists,
                details="Lint configuration file detected.",
            )
        )

        formatter_exists = _contains_any(files, [r"prettier", r"black", r"ruff\s+format", r"rustfmt"])
        checks.append(
            CheckItem(
                name="Formatter configuration",
                passed=formatter_exists,
                details="Formatting tooling appears configured.",
            )
        )

        checks.append(
            CheckItem(
                name="LICENSE file",
                passed=(ctx.project_path / "LICENSE").exists() or (ctx.project_path / "LICENSE.md").exists(),
                details="License file present.",
            )
        )

        checks.append(
            CheckItem(
                name="Environment example file",
                passed=(ctx.project_path / ".env.example").exists(),
                details=".env.example present.",
            )
        )

        checks.append(
            CheckItem(
                name="Secret files ignored",
                passed=(ctx.project_path / ".gitignore").exists()
                and ".env" in (ctx.project_path / ".gitignore").read_text(encoding="utf-8", errors="ignore"),
                details=".gitignore appears to include secret file patterns.",
            )
        )

        checks.append(
            CheckItem(
                name="Health endpoint present",
                passed=_contains_any(files, [r"/health", r"healthcheck", r"readyz", r"livez"]),
                details="Healthcheck endpoint indicators found.",
            )
        )

        checks.append(
            CheckItem(
                name="Dependency lockfile",
                passed=any(
                    (ctx.project_path / name).exists()
                    for name in [
                        "package-lock.json",
                        "pnpm-lock.yaml",
                        "yarn.lock",
                        "poetry.lock",
                        "Pipfile.lock",
                        "Cargo.lock",
                        "go.sum",
                    ]
                ),
                details="Dependency lockfile present.",
            )
        )

        result.checks.extend(checks)

        for check in checks:
            if not check.passed:
                result.findings.append(
                    Finding(
                        phase=self.name,
                        title=f"Production check failed: {check.name}",
                        message=check.details,
                        severity=Severity.MEDIUM,
                        recommendation="Address this item before production rollout.",
                        category="production-readiness",
                    )
                )

        passed = sum(1 for item in checks if item.passed)
        result.metadata["production_readiness_score"] = f"{passed}/{len(checks)}"
        return result
