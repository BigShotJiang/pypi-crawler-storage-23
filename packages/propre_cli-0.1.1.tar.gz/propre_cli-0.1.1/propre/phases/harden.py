from __future__ import annotations

import ast
import json
import re
from pathlib import Path

from propre.context import RunContext
from propre.models import Finding, FixAction, PhaseResult, PropreReport, Severity
from propre.phases.base import PhasePlugin
from propre.utils.fs import iter_files, read_text, relative_path
from propre.utils.process import run_command

ROUTE_HINT_RE = re.compile(r"\b(app|router)\.(get|post|put|patch|delete)\s*\(")
SQL_HINT_RE = re.compile(r"\b(SELECT|INSERT|UPDATE|DELETE)\b", re.IGNORECASE)
VAGUE_NAME_RE = re.compile(r"\b(data|temp|x|foo|bar|handle)\b\s*=")
HARDCODED_URL_RE = re.compile(r"https?://[^\s'\"`]+")


def _language_from_suffix(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".py":
        return "python"
    if suffix in {".js", ".jsx", ".ts", ".tsx"}:
        return "javascript"
    return "other"


def _apply_text_fix(path: Path, original: str, modified: str) -> bool:
    if original == modified:
        return False
    path.write_text(modified, encoding="utf-8")
    return True


def _check_python_type_hints(source: str) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    missing = 0
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and not node.name.startswith("_"):
            has_return = node.returns is not None
            has_param_annotations = all(
                arg.annotation is not None for arg in node.args.args if arg.arg != "self"
            )
            if not has_return or not has_param_annotations:
                missing += 1
    return missing


def _check_docstrings(source: str) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    missing = 0
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and not node.name.startswith("_"):
            if ast.get_docstring(node) is None:
                missing += 1
    return missing


def _first_matching_line(source: str, pattern: re.Pattern[str]) -> int | None:
    for idx, line in enumerate(source.splitlines(), start=1):
        if pattern.search(line):
            return idx
    return None


def _dependency_hygiene(result: PhaseResult, ctx: RunContext, report: PropreReport) -> None:
    metadata = report.metadata
    dependencies = metadata.get("dependencies", {})
    module_graph = metadata.get("module_graph", {})

    if isinstance(dependencies, dict) and isinstance(module_graph, dict):
        imported_packages: set[str] = set()
        for imports in module_graph.values():
            if not isinstance(imports, list):
                continue
            for entry in imports:
                if not isinstance(entry, str):
                    continue
                if entry.startswith(".") or entry.startswith("/"):
                    continue
                imported_packages.add(entry.split("/")[0].split(".")[0].lower())

        for ecosystem, deps in dependencies.items():
            if not isinstance(deps, list):
                continue
            for dep in deps:
                normalized = dep.split("/")[-1].lower()
                primary = normalized.split("-")[0]
                if primary and primary not in imported_packages and normalized not in imported_packages:
                    result.findings.append(
                        Finding(
                            phase="harden",
                            title="Potential unused dependency",
                            message=f"Dependency '{dep}' does not appear in static imports.",
                            severity=Severity.LOW,
                            recommendation="Verify usage and remove unused dependencies.",
                            category=f"dependency:{ecosystem}",
                        )
                    )

    if (ctx.project_path / "package.json").exists():
        rc, stdout, stderr = run_command(["npm", "audit", "--json"], cwd=ctx.project_path, timeout=45)
        if rc in {0, 1} and stdout.strip():
            try:
                payload = json.loads(stdout)
                vulns = payload.get("metadata", {}).get("vulnerabilities", {})
                critical = int(vulns.get("critical", 0))
                high = int(vulns.get("high", 0))
                if critical or high:
                    result.findings.append(
                        Finding(
                            phase="harden",
                            title="NPM vulnerabilities",
                            message=f"npm audit reported {critical} critical and {high} high vulnerabilities.",
                            severity=Severity.CRITICAL if critical else Severity.HIGH,
                            recommendation="Upgrade or patch vulnerable dependencies.",
                            category="dependency",
                        )
                    )
            except Exception:  # noqa: BLE001
                pass
        elif rc == 127:
            result.findings.append(
                Finding(
                    phase="harden",
                    title="npm audit unavailable",
                    message=stderr.strip() or "npm is not installed.",
                    severity=Severity.LOW,
                    category="dependency",
                )
            )

    if (ctx.project_path / "requirements.txt").exists() or (ctx.project_path / "pyproject.toml").exists():
        rc, stdout, stderr = run_command(["pip-audit", "-f", "json"], cwd=ctx.project_path, timeout=45)
        if rc in {0, 1} and stdout.strip().startswith("["):
            try:
                payload = json.loads(stdout)
                if isinstance(payload, list) and payload:
                    result.findings.append(
                        Finding(
                            phase="harden",
                            title="Python vulnerabilities",
                            message=f"pip-audit reported vulnerabilities in {len(payload)} packages.",
                            severity=Severity.HIGH,
                            recommendation="Upgrade vulnerable Python dependencies.",
                            category="dependency",
                        )
                    )
            except Exception:  # noqa: BLE001
                pass
        elif rc == 127:
            result.findings.append(
                Finding(
                    phase="harden",
                    title="pip-audit unavailable",
                    message=stderr.strip() or "pip-audit is not installed.",
                    severity=Severity.LOW,
                    category="dependency",
                )
            )

    if (ctx.project_path / "Cargo.toml").exists():
        rc, stdout, stderr = run_command(["cargo", "audit", "--json"], cwd=ctx.project_path, timeout=45)
        if rc in {0, 1} and stdout.strip():
            try:
                payload = json.loads(stdout)
                vulnerabilities = payload.get("vulnerabilities", {}).get("list", [])
                if vulnerabilities:
                    result.findings.append(
                        Finding(
                            phase="harden",
                            title="Rust vulnerabilities",
                            message=f"cargo audit reported {len(vulnerabilities)} vulnerabilities.",
                            severity=Severity.HIGH,
                            recommendation="Upgrade affected Rust crates.",
                            category="dependency",
                        )
                    )
            except Exception:  # noqa: BLE001
                pass
        elif rc == 127:
            result.findings.append(
                Finding(
                    phase="harden",
                    title="cargo-audit unavailable",
                    message=stderr.strip() or "cargo-audit is not installed.",
                    severity=Severity.LOW,
                    category="dependency",
                )
            )


class HardenPhase(PhasePlugin):
    name = "harden"

    def run(self, ctx: RunContext, report: PropreReport) -> PhaseResult:
        result = PhaseResult(name=self.name)

        for path in iter_files(ctx.project_path, ctx.merged_ignores()):
            language = _language_from_suffix(path)
            if language == "other":
                continue

            source = read_text(path)
            if source is None:
                continue
            rel = relative_path(path, ctx.project_path)
            lines = source.splitlines()
            updated_lines = list(lines)
            changed = False

            if (
                ROUTE_HINT_RE.search(source)
                and SQL_HINT_RE.search(source)
                and any(token in rel.lower() for token in ["controller", "route", "handler"])
            ):
                result.findings.append(
                    Finding(
                        phase=self.name,
                        title="Business/data logic in route layer",
                        message="SQL-like query in routing/controller file suggests poor separation of concerns.",
                        severity=Severity.MEDIUM,
                        file_path=rel,
                        recommendation="Move data access logic into service/repository layer.",
                        category="architecture",
                    )
                )

            if language == "javascript" and "req.body" in source and not re.search(
                r"(zod|joi|yup|express-validator|schema|validator)",
                source,
                re.IGNORECASE,
            ):
                line_no = _first_matching_line(source, re.compile(r"req\.body")) or 1
                result.findings.append(
                    Finding(
                        phase=self.name,
                        title="Missing input validation",
                        message="Route handler uses request body without obvious schema validation.",
                        severity=Severity.HIGH,
                        file_path=rel,
                        line=line_no,
                        recommendation="Validate and sanitize request input before use.",
                        category="input-validation",
                    )
                )

            if re.search(r"return\s+.+\n\s+[A-Za-z_]", source):
                result.findings.append(
                    Finding(
                        phase=self.name,
                        title="Potential unreachable code",
                        message="Detected statements immediately after return; review control flow.",
                        severity=Severity.LOW,
                        file_path=rel,
                        recommendation="Remove dead paths and unreachable blocks.",
                        category="dead-code",
                    )
                )

            for index, line in enumerate(lines, start=1):
                stripped = line.strip()

                if language == "python" and re.match(r"^\s*except\s*:\s*$", line):
                    result.findings.append(
                        Finding(
                            phase=self.name,
                            title="Bare except",
                            message="Bare except clause can hide critical errors.",
                            severity=Severity.HIGH,
                            file_path=rel,
                            line=index,
                            recommendation="Use `except Exception as exc` and handle explicitly.",
                            category="error-handling",
                        )
                    )
                    if ctx.options.apply_changes:
                        updated_lines[index - 1] = line.replace("except:", "except Exception:")
                        changed = True
                        result.fixes.append(
                            FixAction(
                                phase=self.name,
                                description="Replaced bare except with explicit exception type",
                                path=rel,
                                applied=True,
                            )
                        )

                if VAGUE_NAME_RE.search(line):
                    result.findings.append(
                        Finding(
                            phase=self.name,
                            title="Vague variable naming",
                            message="Detected generic variable name; clarity may be reduced.",
                            severity=Severity.LOW,
                            file_path=rel,
                            line=index,
                            recommendation="Use domain-specific names.",
                            category="naming",
                        )
                    )

                if language == "javascript" and "console.log(" in stripped:
                    result.findings.append(
                        Finding(
                            phase=self.name,
                            title="Debug logging",
                            message="console.log found in source; use structured logging in production.",
                            severity=Severity.LOW,
                            file_path=rel,
                            line=index,
                            recommendation="Replace console.log with a logger abstraction.",
                            category="logging",
                        )
                    )
                    if ctx.options.apply_changes and not stripped.startswith("//"):
                        indent = line[: len(line) - len(line.lstrip())]
                        updated_lines[index - 1] = f"{indent}// propre: {stripped}"
                        changed = True
                        result.fixes.append(
                            FixAction(
                                phase=self.name,
                                description="Commented out console.log statement",
                                path=rel,
                                applied=True,
                            )
                        )

                if language == "python" and re.match(r"^\s*print\(.+\)\s*$", stripped):
                    result.findings.append(
                        Finding(
                            phase=self.name,
                            title="Debug print",
                            message="print() found in source; use logging module in production.",
                            severity=Severity.LOW,
                            file_path=rel,
                            line=index,
                            recommendation="Replace print() with logger calls.",
                            category="logging",
                        )
                    )
                    if ctx.options.apply_changes and not stripped.startswith("#"):
                        indent = line[: len(line) - len(line.lstrip())]
                        updated_lines[index - 1] = f"{indent}# propre: {stripped}"
                        changed = True
                        result.fixes.append(
                            FixAction(
                                phase=self.name,
                                description="Commented out debug print statement",
                                path=rel,
                                applied=True,
                            )
                        )

                if HARDCODED_URL_RE.search(line) and "localhost" not in line and "127.0.0.1" not in line:
                    result.findings.append(
                        Finding(
                            phase=self.name,
                            title="Hardcoded URL/config",
                            message="Potential hardcoded environment-specific URL detected.",
                            severity=Severity.MEDIUM,
                            file_path=rel,
                            line=index,
                            recommendation="Load URLs via environment variables/config management.",
                            category="env-config",
                        )
                    )

            if language == "javascript" and path.suffix.lower() in {".ts", ".tsx"} and re.search(
                r"(:\s*any\b|\bas\s+any\b)",
                source,
            ):
                result.findings.append(
                    Finding(
                        phase=self.name,
                        title="Weak TypeScript typing",
                        message="`any` usage detected; type-safety may be reduced.",
                        severity=Severity.MEDIUM,
                        file_path=rel,
                        recommendation="Replace `any` with explicit domain types.",
                        category="types",
                    )
                )

            if language == "python":
                missing_hints = _check_python_type_hints(source)
                if missing_hints:
                    result.findings.append(
                        Finding(
                            phase=self.name,
                            title="Missing Python type hints",
                            message=f"Detected {missing_hints} public function(s) with incomplete type hints.",
                            severity=Severity.MEDIUM,
                            file_path=rel,
                            recommendation="Add parameter and return annotations.",
                            category="types",
                        )
                    )

                missing_docs = _check_docstrings(source)
                if missing_docs:
                    result.findings.append(
                        Finding(
                            phase=self.name,
                            title="Missing docstrings",
                            message=f"Detected {missing_docs} public function(s) without docstrings.",
                            severity=Severity.LOW,
                            file_path=rel,
                            recommendation="Add concise docstrings to public functions.",
                            category="documentation",
                        )
                    )

            if changed and ctx.options.apply_changes and not ctx.options.dry_run:
                updated = "\n".join(updated_lines)
                if source.endswith("\n"):
                    updated += "\n"
                _apply_text_fix(path, source, updated)

        readme = ctx.project_path / "README.md"
        required_sections = ["Installation", "Usage", "Configuration"]
        missing_sections: list[str] = []
        if readme.exists():
            readme_text = readme.read_text(encoding="utf-8", errors="ignore")
            for section in required_sections:
                if section.lower() not in readme_text.lower():
                    missing_sections.append(section)
        else:
            missing_sections = required_sections

        if missing_sections:
            result.findings.append(
                Finding(
                    phase=self.name,
                    title="Missing README sections",
                    message=f"README is missing sections: {', '.join(missing_sections)}.",
                    severity=Severity.LOW,
                    recommendation="Document installation, usage, and configuration.",
                    category="documentation",
                )
            )
            if ctx.options.apply_changes and not ctx.options.dry_run:
                existing = readme.read_text(encoding="utf-8", errors="ignore") if readme.exists() else "# Project\n"
                additions = "\n\n".join([f"## {section}\n\nTODO" for section in missing_sections])
                readme.write_text(existing.rstrip() + "\n\n" + additions + "\n", encoding="utf-8")
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description="Appended missing README sections",
                        path="README.md",
                        applied=True,
                    )
                )

        _dependency_hygiene(result, ctx, report)

        return result
