from __future__ import annotations

import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from rich.prompt import Confirm

from propre.constants import CANONICAL_LAYOUTS, SOURCE_SUFFIXES
from propre.context import RunContext
from propre.models import Finding, FixAction, PhaseResult, PropreReport, Severity
from propre.phases.base import PhasePlugin
from propre.phases.scan import collect_dependencies, detect_framework, detect_stacks
from propre.utils.fs import iter_files, read_text, relative_path
from propre.utils.transaction import FileTransaction


@dataclass(slots=True)
class MovePlan:
    source: Path
    destination: Path


def _recommended_layout(framework: str, stacks: list[str]) -> list[str]:
    if framework in CANONICAL_LAYOUTS:
        return CANONICAL_LAYOUTS[framework]
    if "python" in stacks:
        return CANONICAL_LAYOUTS.get("python", ["src", "tests"])
    if "node" in stacks:
        return CANONICAL_LAYOUTS.get("node", ["src", "tests"])
    return ["src", "tests"]


def _plan_file_moves(root: Path, framework: str, stacks: list[str]) -> list[MovePlan]:
    plans: list[MovePlan] = []
    protected = {
        "main.py",
        "manage.py",
        "app.py",
        "wsgi.py",
        "asgi.py",
        "server.js",
        "index.js",
        "pyproject.toml",
        "package.json",
    }

    root_sources = [
        path
        for path in root.iterdir()
        if path.is_file() and path.suffix.lower() in SOURCE_SUFFIXES and path.name not in protected
    ]

    for source in root_sources:
        name = source.name.lower()
        destination: Path

        if framework == "express":
            if "route" in name:
                destination = root / "src" / "routes" / source.name
            elif "controller" in name:
                destination = root / "src" / "controllers" / source.name
            elif "middleware" in name:
                destination = root / "src" / "middleware" / source.name
            elif "model" in name:
                destination = root / "src" / "models" / source.name
            elif "util" in name or "helper" in name:
                destination = root / "src" / "utils" / source.name
            else:
                destination = root / "src" / source.name
        elif framework == "fastapi":
            if "router" in name:
                destination = root / "app" / "routers" / source.name
            elif "schema" in name:
                destination = root / "app" / "schemas" / source.name
            elif "model" in name:
                destination = root / "app" / "models" / source.name
            elif "service" in name:
                destination = root / "app" / "services" / source.name
            elif "config" in name or "core" in name:
                destination = root / "app" / "core" / source.name
            else:
                destination = root / "app" / source.name
        else:
            if "python" in stacks or "node" in stacks:
                destination = root / "src" / source.name
            else:
                continue

        if destination != source:
            plans.append(MovePlan(source=source, destination=destination))

    return plans


def _module_name(root: Path, path: Path) -> str:
    rel = path.relative_to(root)
    return rel.with_suffix("").as_posix().replace("/", ".")


def _rewrite_imports(root: Path, moves: list[MovePlan], ignore_patterns: list[str]) -> int:
    python_map: dict[str, str] = {}
    for move in moves:
        if move.source.suffix == ".py" and move.destination.suffix == ".py":
            python_map[_module_name(root, move.source)] = _module_name(root, move.destination)

    if not python_map:
        return 0

    changed_files = 0
    for file_path in iter_files(root, ignore_patterns):
        if file_path.suffix != ".py":
            continue
        source = read_text(file_path)
        if source is None:
            continue

        rewritten = source
        for old_mod, new_mod in python_map.items():
            rewritten = re.sub(
                rf"\bfrom\s+{re.escape(old_mod)}\s+import\b",
                f"from {new_mod} import",
                rewritten,
            )
            rewritten = re.sub(
                rf"\bimport\s+{re.escape(old_mod)}\b",
                f"import {new_mod}",
                rewritten,
            )

        if rewritten != source:
            file_path.write_text(rewritten, encoding="utf-8")
            changed_files += 1

    return changed_files


class RestructurePhase(PhasePlugin):
    name = "restructure"

    def run(self, ctx: RunContext, report: PropreReport) -> PhaseResult:
        result = PhaseResult(name=self.name)

        stacks = report.metadata.get("stacks")
        framework = report.metadata.get("framework")
        if not isinstance(stacks, list):
            stacks = detect_stacks(ctx.project_path)
        if not isinstance(framework, str):
            framework = detect_framework(
                ctx.project_path,
                collect_dependencies(ctx.project_path, stacks),
            )

        layout = _recommended_layout(framework, stacks)
        missing_dirs = [d for d in layout if not (ctx.project_path / d).exists()]
        moves = _plan_file_moves(ctx.project_path, framework, stacks)

        result.metadata.update(
            {
                "framework": framework,
                "recommended_layout": layout,
                "planned_directories": missing_dirs,
                "planned_moves": [
                    {
                        "source": relative_path(move.source, ctx.project_path),
                        "destination": relative_path(move.destination, ctx.project_path),
                    }
                    for move in moves
                ],
            }
        )

        if not missing_dirs and not moves:
            result.findings.append(
                Finding(
                    phase=self.name,
                    title="Structure already aligned",
                    message="No restructuring changes were needed for the detected stack.",
                    severity=Severity.INFO,
                    category="architecture",
                )
            )
            return result

        if not ctx.options.apply_changes:
            result.findings.append(
                Finding(
                    phase=self.name,
                    title="Restructure plan generated",
                    message="Review the planned directory and move operations, then run with --fix to apply.",
                    severity=Severity.LOW,
                    recommendation="Run `propre res . --fix` or `propre fix .`.",
                    category="architecture",
                )
            )
            for directory in missing_dirs:
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description=f"Create directory {directory}",
                        path=directory,
                        applied=False,
                    )
                )
            for move in moves:
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description=(
                            f"Move {relative_path(move.source, ctx.project_path)} -> "
                            f"{relative_path(move.destination, ctx.project_path)}"
                        ),
                        path=relative_path(move.destination, ctx.project_path),
                        applied=False,
                    )
                )
            return result

        if ctx.config.restructure.confirm and sys.stdin.isatty() and not ctx.options.dry_run:
            proceed = Confirm.ask(
                f"Apply restructuring plan with {len(missing_dirs)} directories and {len(moves)} file moves?",
                default=True,
            )
            if not proceed:
                result.findings.append(
                    Finding(
                        phase=self.name,
                        title="Restructure skipped",
                        message="User declined applying the restructuring plan.",
                        severity=Severity.INFO,
                        category="architecture",
                    )
                )
                return result

        transaction = FileTransaction(ctx.project_path)
        try:
            for directory in missing_dirs:
                target = ctx.project_path / directory
                if not ctx.options.dry_run:
                    transaction.mkdir(target)
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description=f"Create directory {directory}",
                        path=directory,
                        applied=not ctx.options.dry_run,
                    )
                )

            for move in moves:
                if not ctx.options.dry_run:
                    transaction.move(move.source, move.destination)
                result.fixes.append(
                    FixAction(
                        phase=self.name,
                        description=(
                            f"Move {relative_path(move.source, ctx.project_path)} -> "
                            f"{relative_path(move.destination, ctx.project_path)}"
                        ),
                        path=relative_path(move.destination, ctx.project_path),
                        applied=not ctx.options.dry_run,
                    )
                )

            rewritten = 0
            if not ctx.options.dry_run:
                rewritten = _rewrite_imports(ctx.project_path, moves, ctx.merged_ignores())
                if rewritten:
                    result.fixes.append(
                        FixAction(
                            phase=self.name,
                            description=f"Updated Python imports in {rewritten} files",
                            applied=True,
                        )
                    )

            if not ctx.options.dry_run and moves:
                undo_script = ctx.project_path / f".propre-undo-{int(time.time())}.sh"
                transaction.write_undo_script(undo_script)
                result.metadata["undo_script"] = undo_script.name

            if ctx.options.dry_run:
                result.findings.append(
                    Finding(
                        phase=self.name,
                        title="Dry run",
                        message="Restructure plan was computed but not applied.",
                        severity=Severity.INFO,
                        category="architecture",
                    )
                )

        except Exception as exc:  # noqa: BLE001
            transaction.rollback()
            result.errors.append(str(exc))
            result.findings.append(
                Finding(
                    phase=self.name,
                    title="Restructure failed",
                    message="Restructuring operation failed and was rolled back.",
                    severity=Severity.CRITICAL,
                    recommendation="Review conflicts and rerun in --dry-run mode.",
                    category="architecture",
                )
            )

        return result
