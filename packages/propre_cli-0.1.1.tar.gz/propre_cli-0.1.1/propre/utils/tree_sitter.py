from __future__ import annotations

from typing import Any

try:
    from tree_sitter_languages import get_parser
except Exception:  # noqa: BLE001
    get_parser = None


TREE_SITTER_AVAILABLE = get_parser is not None


def parse_source(language: str, source: str) -> Any | None:
    if get_parser is None:
        return None
    try:
        parser = get_parser(language)
        return parser.parse(source.encode("utf-8"))
    except Exception:  # noqa: BLE001
        return None
