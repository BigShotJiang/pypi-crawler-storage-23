from __future__ import annotations

import math
from collections import Counter


def shannon_entropy(value: str) -> float:
    if not value:
        return 0.0
    counts = Counter(value)
    length = len(value)
    entropy = 0.0
    for count in counts.values():
        probability = count / length
        entropy -= probability * math.log2(probability)
    return entropy


def looks_like_secret_token(token: str, min_length: int = 20, threshold: float = 4.1) -> bool:
    if len(token) < min_length:
        return False
    if token.lower().startswith(("http", "file", "npm", "sha256", "sha1", "md5")):
        return False
    if token.isdigit():
        return False
    return shannon_entropy(token) >= threshold
