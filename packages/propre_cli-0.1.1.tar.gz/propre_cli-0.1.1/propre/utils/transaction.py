from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class MoveRecord:
    source: Path
    destination: Path


class FileTransaction:
    """Best-effort reversible move transaction for restructuring."""

    def __init__(self, root: Path):
        self.root = root
        self.moves: list[MoveRecord] = []

    def mkdir(self, path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)

    def move(self, source: Path, destination: Path) -> None:
        if not source.exists():
            return
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            raise FileExistsError(f"Destination already exists: {destination}")
        shutil.move(str(source), str(destination))
        self.moves.append(MoveRecord(source=source, destination=destination))

    def rollback(self) -> None:
        for move in reversed(self.moves):
            if move.destination.exists() and not move.source.exists():
                move.source.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(move.destination), str(move.source))

    def write_undo_script(self, output_path: Path) -> Path:
        lines = ["#!/usr/bin/env bash", "set -euo pipefail", ""]
        for move in reversed(self.moves):
            src = move.destination.relative_to(self.root).as_posix()
            dest = move.source.relative_to(self.root).as_posix()
            lines.append(f"mkdir -p \"$(dirname '{dest}')\"")
            lines.append(f"mv \"{src}\" \"{dest}\"")
        output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        output_path.chmod(0o755)
        return output_path
