from __future__ import annotations

import ast
import re
from pathlib import Path

JS_IMPORT_RE = re.compile(
    r"(?:import\s+(?:.+?\s+from\s+)?|require\()\s*['\"]([^'\"]+)['\"]",
    re.MULTILINE,
)


def extract_imports(path: Path, source: str) -> list[str]:
    suffix = path.suffix.lower()
    if suffix == ".py":
        return _extract_python_imports(source)
    if suffix in {".js", ".jsx", ".ts", ".tsx"}:
        return sorted({m.group(1) for m in JS_IMPORT_RE.finditer(source)})
    return []


def _extract_python_imports(source: str) -> list[str]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module)
    return sorted(imports)
