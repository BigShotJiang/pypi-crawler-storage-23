"""Utility helpers for Propre."""
