from __future__ import annotations

import subprocess
from pathlib import Path


def run_command(args: list[str], cwd: Path, timeout: int = 30) -> tuple[int, str, str]:
    try:
        completed = subprocess.run(
            args,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError:
        return 127, "", f"Command not found: {args[0]}"
    except subprocess.TimeoutExpired:
        return 124, "", f"Timed out: {' '.join(args)}"

    return completed.returncode, completed.stdout, completed.stderr
