from __future__ import annotations

import fnmatch
import os
from pathlib import Path
from typing import Iterator, Sequence


def relative_path(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def should_ignore(relative: str, patterns: Sequence[str]) -> bool:
    rel = relative.strip("/")
    for raw in patterns:
        pattern = raw.strip()
        if not pattern:
            continue
        if pattern.endswith("/"):
            prefix = pattern.strip("/")
            if rel == prefix or rel.startswith(prefix + "/"):
                return True
        if fnmatch.fnmatch(rel, pattern):
            return True
        base = rel.split("/")[-1]
        if fnmatch.fnmatch(base, pattern):
            return True
    return False


def iter_files(root: Path, ignore_patterns: Sequence[str]) -> Iterator[Path]:
    for current, dirs, files in os.walk(root):
        current_path = Path(current)

        pruned_dirs: list[str] = []
        for dir_name in dirs:
            rel_dir = relative_path(current_path / dir_name, root)
            if should_ignore(rel_dir, ignore_patterns):
                continue
            pruned_dirs.append(dir_name)
        dirs[:] = pruned_dirs

        for filename in files:
            full = current_path / filename
            rel_file = relative_path(full, root)
            if should_ignore(rel_file, ignore_patterns):
                continue
            yield full


def is_binary(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            chunk = handle.read(1024)
    except OSError:
        return True
    return b"\0" in chunk


def read_text(path: Path, max_bytes: int = 2_000_000) -> str | None:
    try:
        if path.stat().st_size > max_bytes or is_binary(path):
            return None
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None
