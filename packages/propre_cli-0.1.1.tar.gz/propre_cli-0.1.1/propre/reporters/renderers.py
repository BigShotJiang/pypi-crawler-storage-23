from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from propre.models import PropreReport, Severity


def emit_report(report: PropreReport, output_format: str, console: Console, output_path: Path | None = None) -> None:
    payload: str
    if output_format == "terminal":
        render_terminal(report, console)
        if output_path:
            payload = to_markdown(report)
            output_path.write_text(payload, encoding="utf-8")
        return

    if output_format == "md":
        payload = to_markdown(report)
    elif output_format == "json":
        payload = to_json(report)
    elif output_format == "sarif":
        payload = to_sarif(report)
    else:
        raise ValueError(f"Unsupported format: {output_format}")

    if output_path:
        output_path.write_text(payload, encoding="utf-8")
    else:
        console.print(payload)


def render_terminal(report: PropreReport, console: Console) -> None:
    findings = report.all_findings()
    fixes = report.all_fixes()
    passed, total = report.total_checks()

    header = (
        f"Project: {report.project_path}\n"
        f"Findings: {len(findings)} | Fixes: {len(fixes)} | "
        f"Production Readiness: {passed}/{total}"
    )
    console.print(Panel(header, title="Propre Report"))

    table = Table(title="Findings", show_header=True, header_style="bold magenta")
    table.add_column("Phase", style="cyan")
    table.add_column("Severity", style="red")
    table.add_column("Title")
    table.add_column("File", style="green")

    if findings:
        sorted_findings = sorted(findings, key=lambda f: _severity_rank(f.severity), reverse=True)
        for finding in sorted_findings:
            table.add_row(
                finding.phase,
                finding.severity.value,
                finding.title,
                finding.file_path or "-",
            )
    else:
        table.add_row("-", "-", "No findings", "-")

    console.print(table)

    if any(phase.errors for phase in report.phases):
        err_table = Table(title="Phase Errors", show_header=True)
        err_table.add_column("Phase", style="cyan")
        err_table.add_column("Errors", style="red")
        for phase in report.phases:
            if phase.errors:
                err_table.add_row(phase.name, "\n".join(phase.errors))
        console.print(err_table)


def to_markdown(report: PropreReport) -> str:
    lines: list[str] = []
    findings = report.all_findings()
    fixes = report.all_fixes()
    passed, total = report.total_checks()

    lines.append("# Propre Report")
    lines.append("")
    lines.append(f"- Project: `{report.project_path}`")
    lines.append(f"- Findings: **{len(findings)}**")
    lines.append(f"- Fixes: **{len(fixes)}**")
    lines.append(f"- Production Readiness: **{passed}/{total}**")
    lines.append("")

    lines.append("## Findings")
    lines.append("")
    if not findings:
        lines.append("No findings.")
    else:
        for finding in sorted(findings, key=lambda f: _severity_rank(f.severity), reverse=True):
            location = f" ({finding.file_path}:{finding.line})" if finding.file_path and finding.line else ""
            lines.append(
                f"- [{finding.severity.value}] **{finding.phase}** `{finding.title}`{location}: {finding.message}"
            )
    lines.append("")

    lines.append("## Production Readiness Checklist")
    lines.append("")
    for phase in report.phases:
        for check in phase.checks:
            marker = "x" if check.passed else " "
            lines.append(f"- [{marker}] {check.name} - {check.details}")

    return "\n".join(lines)


def to_json(report: PropreReport) -> str:
    return json.dumps(report.to_dict(), indent=2)


def to_sarif(report: PropreReport) -> str:
    rules: dict[str, dict[str, Any]] = {}
    results: list[dict[str, Any]] = []

    for finding in report.all_findings():
        rule_id = f"{finding.phase}.{finding.title}".replace(" ", "_").lower()
        if rule_id not in rules:
            rules[rule_id] = {
                "id": rule_id,
                "shortDescription": {"text": finding.title},
                "fullDescription": {"text": finding.message},
                "defaultConfiguration": {"level": _sarif_level(finding.severity)},
            }

        result: dict[str, Any] = {
            "ruleId": rule_id,
            "level": _sarif_level(finding.severity),
            "message": {"text": finding.message},
        }
        if finding.file_path:
            location = {
                "physicalLocation": {
                    "artifactLocation": {"uri": finding.file_path},
                }
            }
            if finding.line:
                location["physicalLocation"]["region"] = {"startLine": finding.line}
            result["locations"] = [location]
        results.append(result)

    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "propre",
                        "rules": list(rules.values()),
                    }
                },
                "results": results,
            }
        ],
    }
    return json.dumps(sarif, indent=2)


def _severity_rank(severity: Severity) -> int:
    return {
        Severity.CRITICAL: 5,
        Severity.HIGH: 4,
        Severity.MEDIUM: 3,
        Severity.LOW: 2,
        Severity.INFO: 1,
    }[severity]


def _sarif_level(severity: Severity) -> str:
    if severity in {Severity.CRITICAL, Severity.HIGH}:
        return "error"
    if severity == Severity.MEDIUM:
        return "warning"
    return "note"
