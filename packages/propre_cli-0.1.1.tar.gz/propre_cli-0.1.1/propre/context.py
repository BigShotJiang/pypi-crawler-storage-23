from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console

from propre.config import LoadedConfig
from propre.models import OutputFormat


@dataclass(slots=True)
class RuntimeOptions:
    command: str
    dry_run: bool = False
    verbose: bool = False
    auto_fix: bool = False
    ci: bool = False
    output_format: OutputFormat = OutputFormat.TERMINAL
    output_path: Path | None = None
    ignore: list[str] = field(default_factory=list)
    deep_scan: bool | None = None

    @property
    def apply_changes(self) -> bool:
        return self.auto_fix and not self.dry_run


@dataclass(slots=True)
class RunContext:
    project_path: Path
    loaded_config: LoadedConfig
    options: RuntimeOptions
    console: Console = field(default_factory=Console)

    @property
    def config(self):
        return self.loaded_config.config

    def merged_ignores(self) -> list[str]:
        merged = list(self.config.ignore)
        merged.extend(self.options.ignore)
        # preserve order while removing duplicates
        seen: set[str] = set()
        out: list[str] = []
        for pattern in merged:
            if pattern not in seen:
                seen.add(pattern)
                out.append(pattern)
        return out

    def effective_deep_scan(self) -> bool:
        if self.options.deep_scan is not None:
            return self.options.deep_scan
        return self.config.secrets.deep_scan
