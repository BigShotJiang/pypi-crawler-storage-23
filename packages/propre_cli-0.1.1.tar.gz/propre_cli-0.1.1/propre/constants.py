from __future__ import annotations

MANIFEST_FILES = [
    "package.json",
    "requirements.txt",
    "pyproject.toml",
    "Cargo.toml",
    "go.mod",
    "Gemfile",
    "docker-compose.yml",
    "docker-compose.yaml",
    "Makefile",
]

FRAMEWORK_DEPENDENCIES: dict[str, set[str]] = {
    "nextjs": {"next"},
    "express": {"express"},
    "fastapi": {"fastapi"},
    "django": {"django"},
    "rails": {"rails"},
    "sveltekit": {"@sveltejs/kit"},
    "flask": {"flask"},
    "nestjs": {"@nestjs/core"},
}

CANONICAL_LAYOUTS: dict[str, list[str]] = {
    "nextjs": ["app", "components", "lib", "hooks", "types", "public"],
    "fastapi": ["app", "app/routers", "app/models", "app/schemas", "app/services", "app/core"],
    "express": ["src", "src/controllers", "src/routes", "src/middleware", "src/models", "src/utils"],
    "django": ["apps", "config", "templates", "static"],
    "python": ["src", "tests"],
    "node": ["src", "tests"],
}

SOURCE_SUFFIXES = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".go",
    ".rs",
    ".java",
    ".rb",
}
