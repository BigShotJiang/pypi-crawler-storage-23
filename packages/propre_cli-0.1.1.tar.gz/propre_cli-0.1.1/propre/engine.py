from __future__ import annotations

import time
from datetime import datetime

from propre.context import RunContext
from propre.models import PhaseResult, PropreReport
from propre.phases import build_default_plugins


class PropreEngine:
    def __init__(self, context: RunContext):
        self.context = context
        self.plugins = {plugin.name: plugin for plugin in build_default_plugins()}

    def run(self, selected_phases: list[str]) -> PropreReport:
        report = PropreReport(project_path=str(self.context.project_path))

        for phase_name in selected_phases:
            plugin = self.plugins.get(phase_name)
            if not plugin:
                report.add_phase(
                    PhaseResult(name=phase_name, errors=[f"Unknown phase plugin: {phase_name}"])
                )
                continue

            started = time.perf_counter()
            try:
                phase_result = plugin.run(self.context, report)
            except Exception as exc:  # noqa: BLE001
                phase_result = PhaseResult(name=phase_name, errors=[str(exc)])
            phase_result.duration_ms = int((time.perf_counter() - started) * 1000)
            report.add_phase(phase_result)

            # Carry forward high-level scan metadata as report metadata.
            if phase_name == "scan" and phase_result.metadata:
                report.metadata.update(phase_result.metadata)

        report.ended_at = datetime.utcnow()
        return report
