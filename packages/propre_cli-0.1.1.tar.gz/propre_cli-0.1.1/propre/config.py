from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass(slots=True)
class RestructureConfig:
    enabled: bool = True
    confirm: bool = True


@dataclass(slots=True)
class SecretsConfig:
    deep_scan: bool = False
    severity_threshold: str = "medium"


@dataclass(slots=True)
class RulesConfig:
    dead_code: str = "warn"
    console_logs: str = "error"
    missing_types: str = "warn"
    hardcoded_config: str = "error"


@dataclass(slots=True)
class PropreConfig:
    stack: str = "auto"
    restructure: RestructureConfig = field(default_factory=RestructureConfig)
    secrets: SecretsConfig = field(default_factory=SecretsConfig)
    rules: RulesConfig = field(default_factory=RulesConfig)
    ignore: list[str] = field(
        default_factory=lambda: ["node_modules/", ".git/", "dist/", "build/", "venv/", ".venv/"]
    )


@dataclass(slots=True)
class LoadedConfig:
    source: Path | None
    config: PropreConfig


def _bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, str):
        lowered = value.lower().strip()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
    return default


def _str(value: Any, default: str) -> str:
    return value if isinstance(value, str) and value.strip() else default


def _list_str(value: Any, default: list[str]) -> list[str]:
    if not isinstance(value, list):
        return default
    out: list[str] = []
    for item in value:
        if isinstance(item, str) and item.strip():
            out.append(item.strip())
    return out or default


def load_config(project_path: Path, config_path: Path | None = None) -> LoadedConfig:
    selected = config_path or project_path / "propre.yml"
    if not selected.exists():
        return LoadedConfig(source=None, config=PropreConfig())

    payload = yaml.safe_load(selected.read_text(encoding="utf-8")) or {}
    if not isinstance(payload, dict):
        return LoadedConfig(source=selected, config=PropreConfig())

    restructure = payload.get("restructure", {})
    secrets = payload.get("secrets", {})
    rules = payload.get("rules", {})

    config = PropreConfig(
        stack=_str(payload.get("stack"), "auto"),
        restructure=RestructureConfig(
            enabled=_bool(restructure.get("enabled"), True),
            confirm=_bool(restructure.get("confirm"), True),
        ),
        secrets=SecretsConfig(
            deep_scan=_bool(secrets.get("deep_scan"), False),
            severity_threshold=_str(secrets.get("severity_threshold"), "medium"),
        ),
        rules=RulesConfig(
            dead_code=_str(rules.get("dead_code"), "warn"),
            console_logs=_str(rules.get("console_logs"), "error"),
            missing_types=_str(rules.get("missing_types"), "warn"),
            hardcoded_config=_str(rules.get("hardcoded_config"), "error"),
        ),
        ignore=_list_str(payload.get("ignore"), PropreConfig().ignore),
    )
    return LoadedConfig(source=selected, config=config)
