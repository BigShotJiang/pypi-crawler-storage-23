from __future__ import annotations

from pathlib import Path
from typing import Any

import typer

from propre.config import load_config
from propre.context import RunContext, RuntimeOptions
from propre.engine import PropreEngine
from propre.models import OutputFormat
from propre.reporters.renderers import emit_report

app = typer.Typer(
    add_completion=False,
    help="Propre: post-vibe-coding architecture cleanup and hardening CLI.",
)


def _resolve_phases(command: str, restructure_enabled: bool) -> list[str]:
    if command in {"scan", "report"}:
        phases = ["scan"]
        if restructure_enabled:
            phases.append("restructure")
        phases.extend(["secrets", "harden", "ship"])
        return phases
    if command == "fix":
        phases = ["scan"]
        if restructure_enabled:
            phases.append("restructure")
        phases.extend(["secrets", "harden", "ship"])
        return phases
    if command == "restructure":
        return ["scan", "restructure"]
    if command == "secrets":
        return ["secrets"]
    if command == "ship":
        return ["ship"]
    raise ValueError(f"Unknown command: {command}")


def _build_context(
    command: str,
    path: Path,
    global_options: dict[str, Any],
    output_path: Path | None,
    deep_scan: bool | None,
) -> RunContext:
    project_path = path.resolve()
    config_path = Path(global_options["config"]).resolve() if global_options.get("config") else None
    loaded = load_config(project_path, config_path)

    auto_fix = bool(global_options["fix"] or command in {"fix", "restructure"})

    runtime = RuntimeOptions(
        command=command,
        dry_run=bool(global_options["dry_run"]),
        verbose=bool(global_options["verbose"]),
        auto_fix=auto_fix,
        ci=bool(global_options["ci"]),
        output_format=OutputFormat(global_options["format"]),
        output_path=output_path,
        ignore=list(global_options["ignore"]),
        deep_scan=deep_scan,
    )

    return RunContext(project_path=project_path, loaded_config=loaded, options=runtime)


def _run(
    ctx: typer.Context,
    command: str,
    path: Path,
    output_path: Path | None = None,
    deep_scan: bool | None = None,
) -> None:
    runtime_ctx = _build_context(command, path, ctx.obj, output_path, deep_scan)

    if runtime_ctx.options.verbose:
        config_source = runtime_ctx.loaded_config.source or "defaults"
        runtime_ctx.console.print(f"[cyan]Config:[/cyan] {config_source}")

    engine = PropreEngine(runtime_ctx)
    phases = _resolve_phases(command, runtime_ctx.config.restructure.enabled)
    report = engine.run(phases)

    emit_report(
        report,
        output_format=runtime_ctx.options.output_format.value,
        console=runtime_ctx.console,
        output_path=runtime_ctx.options.output_path,
    )

    if runtime_ctx.options.ci:
        failed_checks = any(not check.passed for phase in report.phases for check in phase.checks)
        if report.has_blockers() or failed_checks:
            raise typer.Exit(code=1)


@app.callback()
def common_options(
    ctx: typer.Context,
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without applying them."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
    config: Path | None = typer.Option(None, "--config", help="Path to propre.yml config file."),
    fix: bool = typer.Option(False, "--fix", help="Auto-apply safe fixes."),
    ignore: list[str] = typer.Option([], "--ignore", help="Ignore glob/prefix pattern."),
    ci: bool = typer.Option(False, "--ci", help="Exit non-zero on failures/blockers."),
    format: OutputFormat = typer.Option(OutputFormat.TERMINAL, "--format", help="Output format."),
) -> None:
    ctx.obj = {
        "dry_run": dry_run,
        "verbose": verbose,
        "config": str(config) if config else None,
        "fix": fix,
        "ignore": ignore,
        "ci": ci,
        "format": format.value,
    }


@app.command()
def scan(
    ctx: typer.Context,
    path: Path = typer.Argument(Path("."), exists=True, file_okay=False, dir_okay=True),
    deep_scan: bool | None = typer.Option(
        None,
        "--deep-scan/--no-deep-scan",
        help="Also scan git history for secrets.",
    ),
) -> None:
    """Full analysis, no changes unless --fix is set."""
    _run(ctx, "scan", path, deep_scan=deep_scan)


@app.command()
def fix(
    ctx: typer.Context,
    path: Path = typer.Argument(Path("."), exists=True, file_okay=False, dir_okay=True),
    deep_scan: bool | None = typer.Option(
        None,
        "--deep-scan/--no-deep-scan",
        help="Also scan git history for secrets.",
    ),
) -> None:
    """Auto-fix safe issues where possible."""
    _run(ctx, "fix", path, deep_scan=deep_scan)


@app.command("res")
def restructure(
    ctx: typer.Context,
    path: Path = typer.Argument(Path("."), exists=True, file_okay=False, dir_okay=True),
) -> None:
    """Folder restructuring only."""
    _run(ctx, "restructure", path)


@app.command("sec")
def secrets(
    ctx: typer.Context,
    path: Path = typer.Argument(Path("."), exists=True, file_okay=False, dir_okay=True),
    deep_scan: bool | None = typer.Option(
        None,
        "--deep-scan/--no-deep-scan",
        help="Also scan git history for secrets.",
    ),
) -> None:
    """Secret scanning only."""
    _run(ctx, "secrets", path, deep_scan=deep_scan)


@app.command()
def ship(
    ctx: typer.Context,
    path: Path = typer.Argument(Path("."), exists=True, file_okay=False, dir_okay=True),
) -> None:
    """Production readiness checklist."""
    _run(ctx, "ship", path)


@app.command()
def report(
    ctx: typer.Context,
    path: Path = typer.Argument(Path("."), exists=True, file_okay=False, dir_okay=True),
    output: Path = typer.Option(Path("report.md"), "-o", "--output", help="Write report to this file."),
    deep_scan: bool | None = typer.Option(
        None,
        "--deep-scan/--no-deep-scan",
        help="Also scan git history for secrets.",
    ),
) -> None:
    """Export a full report file."""
    _run(ctx, "report", path, output_path=output, deep_scan=deep_scan)


def run() -> None:
    app()


if __name__ == "__main__":
    run()
