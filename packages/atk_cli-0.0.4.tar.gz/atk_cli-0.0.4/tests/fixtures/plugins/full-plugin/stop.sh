#!/bin/bash
# Stop script for Full Plugin
echo "[Full Plugin] Stopping service..."
echo "[Full Plugin] Graceful shutdown initiated..."
echo "[Full Plugin] Service stopped."

