from ._version import __version__
from .client import SkilldockClient

__all__ = ["SkilldockClient", "__version__"]

