__all__ = ["__version__"]

# NOTE: PEP 440 will normalize this version (e.g. 2026.02 -> 2026.2),
# but keeping the requested format here is useful for humans.
__version__ = "2026.02.250748"

