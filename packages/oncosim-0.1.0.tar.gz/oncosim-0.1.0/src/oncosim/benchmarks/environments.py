"""Benchmark environment configurations across difficulty tiers."""

from __future__ import annotations

BENCHMARK_CONFIGS = {
    "BeamSelection": {
        "trivial": {"difficulty": "easy", "kwargs": {"oar_weight": 0.1}},
        "easy": {"difficulty": "easy", "kwargs": {"oar_weight": 0.3}},
        "medium": {"difficulty": "medium", "kwargs": {"oar_weight": 0.5}},
        "hard": {"difficulty": "hard", "kwargs": {"oar_weight": 0.5}},
        "expert": {"difficulty": "hard", "kwargs": {"oar_weight": 0.8}},
    },
    "DoseFractionation": {
        "trivial": {"difficulty": "radiosensitive", "kwargs": {"ntcp_weight": 1.0}},
        "easy": {"difficulty": "radiosensitive", "kwargs": {"ntcp_weight": 2.0}},
        "medium": {"difficulty": "standard", "kwargs": {"ntcp_weight": 2.0}},
        "hard": {"difficulty": "radioresistant", "kwargs": {"ntcp_weight": 2.0}},
        "expert": {"difficulty": "radioresistant", "kwargs": {"ntcp_weight": 3.0}},
    },
    "AdaptiveRT": {
        "trivial": {"difficulty": "stable", "kwargs": {"replan_cost": 0.1}},
        "easy": {"difficulty": "stable", "kwargs": {"replan_cost": 0.3}},
        "medium": {"difficulty": "moderate", "kwargs": {"replan_cost": 0.3}},
        "hard": {"difficulty": "variable", "kwargs": {"replan_cost": 0.3}},
        "expert": {"difficulty": "variable", "kwargs": {"replan_cost": 0.5}},
    },
}

ENV_ID_MAP = {
    "BeamSelection": "oncosim/BeamSelection-v0",
    "DoseFractionation": "oncosim/DoseFractionation-v0",
    "AdaptiveRT": "oncosim/AdaptiveRT-v0",
}
