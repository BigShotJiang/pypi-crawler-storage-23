"""Gymnasium environment registration for OncoSim."""

from __future__ import annotations

import gymnasium as gym


def register_envs() -> None:
    """Register all OncoSim environments with Gymnasium."""
    gym.register(
        id="oncosim/BeamSelection-v0",
        entry_point="oncosim.envs.beam_selection:BeamSelectionEnv",
        max_episode_steps=9,
    )
    gym.register(
        id="oncosim/DoseFractionation-v0",
        entry_point="oncosim.envs.dose_fractionation:DoseFractionationEnv",
        max_episode_steps=35,
    )
    gym.register(
        id="oncosim/AdaptiveRT-v0",
        entry_point="oncosim.envs.adaptive_rt:AdaptiveRTEnv",
        max_episode_steps=30,
    )
