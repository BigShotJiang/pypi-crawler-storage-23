"""Random baseline agent for OncoSim environments."""

from __future__ import annotations

import gymnasium as gym
import numpy as np


class RandomAgent:
    """Agent that takes uniformly random actions."""

    def __init__(self, env: gym.Env):
        self.action_space = env.action_space

    def act(self, obs: dict | np.ndarray) -> np.ndarray | int:
        return self.action_space.sample()


def evaluate_random(
    env: gym.Env, n_episodes: int = 100, seed: int = 42
) -> dict[str, float]:
    """Evaluate random agent performance.

    Returns:
        Dict with mean_reward, std_reward, min_reward, max_reward.
    """
    agent = RandomAgent(env)
    rewards = []
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        total_reward = 0.0
        done = False
        while not done:
            action = agent.act(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            done = terminated or truncated
        rewards.append(total_reward)

    return {
        "mean_reward": float(np.mean(rewards)),
        "std_reward": float(np.std(rewards)),
        "min_reward": float(np.min(rewards)),
        "max_reward": float(np.max(rewards)),
    }
