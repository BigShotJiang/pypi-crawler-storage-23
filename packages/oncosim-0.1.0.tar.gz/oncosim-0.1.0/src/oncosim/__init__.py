"""OncoSim: Gymnasium-compatible RL environments for radiation therapy treatment planning."""

__version__ = "0.1.0"

from oncosim.envs import register_envs

register_envs()
