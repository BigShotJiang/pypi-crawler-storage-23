"""Training pipeline for OncoSim agents."""
