"""drp CLI — command-line tool for drp."""

__version__ = '0.2.11'
DEFAULT_HOST = 'https://drp.vicnas.me'