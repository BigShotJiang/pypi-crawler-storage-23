#include <gtest/gtest.h>

TEST(SanityCheck, BasicArithmetic) { EXPECT_EQ(2, 1 + 1); }
