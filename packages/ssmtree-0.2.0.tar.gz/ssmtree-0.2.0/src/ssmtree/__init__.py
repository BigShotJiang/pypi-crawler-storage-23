"""ssmtree — Render AWS SSM Parameter Store as a colorized terminal tree."""

__version__ = "0.2.0"
