import os
import getpass
import shutil
from colorama import Fore, Style


class Home:
    """
    Displays a styled ASCII banner / home screen in the terminal.

    Usage:
        home = Home(
            title="MYAPP",
            subtitle="The coolest tool ever",
            credits="by karenhoyoshi",
            adinfo1="v1.0.0",
            adinfo2="github.com/karen",
        )
        home.display()
    """

    # Gradient colors (ANSI 256)
    _GRADIENT = [
        "\033[38;5;196m",  # red
        "\033[38;5;202m",
        "\033[38;5;208m",
        "\033[38;5;214m",
        "\033[38;5;220m",
        "\033[38;5;226m",
        "\033[38;5;190m",
        "\033[38;5;154m",
        "\033[38;5;118m",
        "\033[38;5;82m",   # green
        "\033[38;5;46m",
        "\033[38;5;47m",
        "\033[38;5;48m",
        "\033[38;5;51m",   # cyan
        "\033[38;5;45m",
        "\033[38;5;39m",
        "\033[38;5;33m",
        "\033[38;5;27m",   # blue
        "\033[38;5;57m",
        "\033[38;5;93m",   # purple
    ]

    def __init__(
        self,
        title: str = "LOGKAREN",
        subtitle: str = "Advanced Python Logger",
        credits: str | None = None,
        adinfo1: str | None = None,
        adinfo2: str | None = None,
        clear: bool = True,
    ):
        self.title = title
        self.subtitle = subtitle
        self.credits = credits
        self.adinfo1 = adinfo1
        self.adinfo2 = adinfo2
        self.clear = clear
        self.username = getpass.getuser()

    # ── Public ────────────────────────────────────────────────────────────────

    def display(self):
        if self.clear:
            os.system("cls" if os.name == "nt" else "clear")

        width = shutil.get_terminal_size().columns

        self._print_banner(width)
        self._print_subtitle(width)
        self._print_divider(width)
        self._print_welcome(width)
        self._print_adinfo(width)
        self._print_divider(width)
        print()

    # ── Internal ──────────────────────────────────────────────────────────────

    def _gradient_line(self, line: str, index: int) -> str:
        color = self._GRADIENT[index % len(self._GRADIENT)]
        return f"{color}{line}{Style.RESET_ALL}"

    def _print_banner(self, width: int):
        # Big block-letter banner using box-drawing characters
        lines = self._build_big_text(self.title)
        for i, line in enumerate(lines):
            centered = line.center(width)
            print(self._gradient_line(centered, i))

    def _print_subtitle(self, width: int):
        print()
        subtitle_colored = f"\033[38;5;141m{self.subtitle.center(width)}{Style.RESET_ALL}"
        print(subtitle_colored)
        print()

    def _print_divider(self, width: int):
        divider = "═" * width
        print(self._gradient_line(divider, 5))

    def _print_welcome(self, width: int):
        welcome = f"Welcome, {self.username}"
        if self.credits:
            welcome += f"  |  {self.credits}"
        tilde = "~" * len(welcome)

        print(self._gradient_line(welcome.center(width), 10))
        print(self._gradient_line(tilde.center(width), 12))

    def _print_adinfo(self, width: int):
        parts = [p for p in [self.adinfo1, self.adinfo2] if p]
        if not parts:
            return
        info_str = "   ·   ".join(parts)
        print(self._gradient_line(info_str.center(width), 8))

    @staticmethod
    def _build_big_text(text: str) -> list[str]:
        """Render text using hardcoded box-drawing ASCII art."""
        BANNER = r"""
██╗  ██╗ █████╗ ██████╗ ███████╗███╗   ██╗██╗███████╗███╗   ███╗███████╗
██║ ██╔╝██╔══██╗██╔══██╗██╔════╝████╗  ██║██║██╔════╝████╗ ████║██╔════╝
█████╔╝ ███████║██████╔╝█████╗  ██╔██╗ ██║██║███████╗██╔████╔██║█████╗  
██╔═██╗ ██╔══██║██╔══██╗██╔══╝  ██║╚██╗██║██║╚════██║██║╚██╔╝██║██╔══╝  
██║  ██╗██║  ██║██║  ██║███████╗██║ ╚████║██║███████║██║ ╚═╝ ██║███████╗
╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚═╝╚══════╝╚═╝     ╚═╝╚══════╝"""
        return [line for line in BANNER.splitlines() if line.strip()]