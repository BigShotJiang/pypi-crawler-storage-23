from __future__ import annotations

from functools import partial
from pathlib import Path
from re import MULTILINE, escape, search
from typing import TYPE_CHECKING

from click import command
from utilities.click import CONTEXT_SETTINGS
from utilities.core import is_pytest, normalize_multi_line_str
from utilities.pydantic import extract_secret
from utilities.types import PathLike

from pre_commit_hooks.click import (
    index_name_option,
    index_password_option,
    index_username_option,
    native_tls_flag,
    paths_argument,
    python_flag,
    version_option,
)
from pre_commit_hooks.constants import ENVRC, PYTHON_VERSION
from pre_commit_hooks.utilities import merge_paths, run_all_maybe_raise, yield_text_file

if TYPE_CHECKING:
    from collections.abc import Callable, MutableSet
    from pathlib import Path

    from utilities.types import PathLike, SecretLike


@command(**CONTEXT_SETTINGS)
@paths_argument
@python_flag
@index_name_option
@index_username_option
@index_password_option
@native_tls_flag
@version_option
def _main(
    *,
    paths: tuple[Path, ...],
    python: bool,
    index_name: str | None,
    index_username: str | None,
    index_password: SecretLike | None,
    native_tls: bool,
    version: str | None,
) -> None:
    if is_pytest():
        return
    paths_use = merge_paths(*paths, target=ENVRC)
    funcs: list[Callable[[], bool]] = [
        partial(
            _run,
            path=p,
            python=python,
            index_name=index_name,
            index_username=index_username,
            index_password=index_password,
            native_tls=native_tls,
            version=version,
        )
        for p in paths_use
    ]
    run_all_maybe_raise(*funcs)


def _run(
    *,
    path: PathLike = ENVRC,
    python: bool = False,
    index_name: str | None = None,
    index_username: str | None = None,
    index_password: SecretLike | None = None,
    native_tls: bool = False,
    version: str | None = None,
) -> bool:
    modifications: set[Path] = set()
    with yield_text_file(path, modifications=modifications) as context:
        text = normalize_multi_line_str("""
            #!/usr/bin/env sh
            # shellcheck source=/dev/null

            # echo
            echo_date() { echo "[$(date +'%Y-%m-%d %H:%M:%S')] $*" >&2; }
        """)
        if search(escape(text), context.output, flags=MULTILINE) is None:
            context.output += f"\n\n{text}"
    if python:
        _add_python(
            path=path,
            index_name=index_name,
            index_username=index_username,
            index_password=index_password,
            modifications=modifications,
            native_tls=native_tls,
            version=version,
        )
    return len(modifications) == 0


def _add_python(
    *,
    path: PathLike = ENVRC,
    modifications: MutableSet[Path] | None = None,
    index_name: str | None = None,
    index_username: str | None = None,
    index_password: SecretLike | None = None,
    native_tls: bool = False,
    version: str | None = None,
) -> None:
    with yield_text_file(path, modifications=modifications) as context:
        text = _get_text(
            index_name=index_name,
            index_username=index_username,
            index_password=index_password,
            native_tls=native_tls,
            version=version,
        )
        if search(escape(text), context.output, flags=MULTILINE) is None:
            context.output += f"\n\n{text}"


def _get_text(
    *,
    index_name: str | None = None,
    index_username: str | None = None,
    index_password: SecretLike | None = None,
    native_tls: bool = False,
    version: str | None = None,
) -> str:
    lines: list[str] = ["# uv"]
    if index_name is not None:
        if index_username is not None:
            lines.append(
                f"export UV_INDEX_{index_name.upper()}_USERNAME='{index_username}'"
            )
        if index_password is not None:
            value = extract_secret(index_password)
            lines.append(f"export UV_INDEX_{index_name.upper()}_PASSWORD='{value}'")
    lines.append("export UV_MANAGED_PYTHON='true'")
    if native_tls:
        lines.append("export UV_NATIVE_TLS='true'")
    version_use = PYTHON_VERSION if version is None else version
    lines.extend([
        "export UV_PRERELEASE='disallow'",
        f"export UV_PYTHON='{version_use}'",
        "export UV_RESOLUTION='highest'",
        "export UV_VENV_CLEAR='true'",
        normalize_multi_line_str("""\
            if ! command -v uv >/dev/null 2>&1; then
            \techo_date "ERROR: 'uv' not found" && exit 1
            fi
        """).rstrip("\n"),
        "activate='.venv/bin/activate'",
        normalize_multi_line_str("""\
            if [ -f $activate ]; then
            \t. $activate
            else
            \tuv venv
            fi
        """).rstrip("\n"),
        "uv sync --all-extras --all-groups --active --locked",
    ])
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    _main()
