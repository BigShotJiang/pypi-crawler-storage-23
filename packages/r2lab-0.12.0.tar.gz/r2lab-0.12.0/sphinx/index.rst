.. r2lab documentation master file, created by
   sphinx-quickstart on Sat Nov 19 16:28:13 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to r2lab's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 3

   README
   API

History:

.. toctree::
   :maxdepth: 1

   CHANGELOG

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
