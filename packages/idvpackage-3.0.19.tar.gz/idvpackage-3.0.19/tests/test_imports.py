"""Test package imports and basic structure."""

import pytest


@pytest.mark.unit
def test_import_ocr():
    """Test that ocr module can be imported."""
    from idvpackage import ocr
    assert ocr is not None


@pytest.mark.unit
def test_import_blur_detection():
    """Test that blur_detection module can be imported."""
    from idvpackage import blur_detection
    assert blur_detection is not None


@pytest.mark.unit
def test_import_common():
    """Test that common module can be imported."""
    from idvpackage import common
    assert common is not None


@pytest.mark.unit
def test_import_constants():
    """Test that constants module can be imported."""
    from idvpackage import constants
    assert constants is not None


@pytest.mark.unit
def test_import_liveness_spoofing():
    """Test that liveness_spoofing_v2 module can be imported."""
    from idvpackage import liveness_spoofing_v2
    assert liveness_spoofing_v2 is not None


@pytest.mark.unit
def test_identity_verification_class_exists():
    """Test that IdentityVerification class exists."""
    from idvpackage.ocr import IdentityVerification
    assert IdentityVerification is not None


@pytest.mark.unit
def test_identity_verification_has_required_methods():
    """Test that IdentityVerification has all required methods."""
    from idvpackage.ocr import IdentityVerification

    required_methods = [
        'extract_document_info',
        'check_document_quality',
        'extract_ocr_info',
    ]

    for method_name in required_methods:
        assert hasattr(IdentityVerification, method_name), \
            f"IdentityVerification missing method: {method_name}"


@pytest.mark.unit
def test_face_recognition_models_available():
    """Test that face_recognition_models is available and can be imported."""
    import face_recognition_models

    assert face_recognition_models is not None
    assert hasattr(face_recognition_models, '__version__')
    # Test that it has the expected face model function
    assert hasattr(face_recognition_models, 'face_recognition_model_location')

    # Verify version exists and is not empty
    assert face_recognition_models.__version__
    print(f"face_recognition_models version: {face_recognition_models.__version__}")


@pytest.mark.unit
def test_country_extraction_modules():
    """Test that country-specific extraction modules can be imported."""
    country_modules = [
        'iraq_id_extraction_withopenai',
        'jor_passport_extraction',
        'lebanon_id_extraction',
        'pse_passport_extraction',
        'qatar_id_extraction',
        'sudan_passport_extraction',
        'syr_passport_extraction',
        'uae_id_extraction',
    ]

    for module_name in country_modules:
        module = __import__(f'idvpackage.{module_name}', fromlist=[module_name])
        assert module is not None, f"Failed to import {module_name}"
