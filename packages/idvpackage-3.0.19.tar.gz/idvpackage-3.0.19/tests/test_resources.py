"""Test that package resources are properly included."""

from pathlib import Path

import pytest


@pytest.mark.unit
def test_spoof_resources_module():
    """Test that spoof_resources module exists."""
    from idvpackage import spoof_resources
    assert spoof_resources is not None


@pytest.mark.unit
def test_model_files_exist():
    """Test that required model files are included in the package."""
    from idvpackage import spoof_resources

    resource_path = Path(spoof_resources.__file__).parent

    expected_models = [
        '2.7_80x80_MiniFASNetV2.pth',
        '4_0_0_80x80_MiniFASNetV1SE.pth',
    ]

    for model_file in expected_models:
        model_path = resource_path / model_file
        assert model_path.exists(), f"Model file {model_file} not found"
        assert model_path.stat().st_size > 0, f"Model file {model_file} is empty"


@pytest.mark.unit
def test_icon_files_included():
    """Test that icon files are included in the package."""
    from pathlib import Path

    import idvpackage

    # Get the package directory
    package_dir = Path(idvpackage.__file__).parent
    icon_dir = package_dir / 'icons'

    # Check that icons directory exists
    assert icon_dir.exists(), "Icons directory not found"

    # Check for icon files
    icon_files = list(icon_dir.glob('*.png'))
    assert len(icon_files) > 0, "No icon files found in package"

    # Check for expected icon files
    icon_names = [f.name for f in icon_files]
    expected_icons = ['battery1.png', 'wifi1.png', 'network1.png']

    for icon in expected_icons:
        assert icon in icon_names, f"Expected icon {icon} not found"


@pytest.mark.unit
def test_spoof_resources_modules():
    """Test that spoof_resources submodules can be imported."""
    from idvpackage.spoof_resources import (
        MiniFASNet,
        functional,
        generate_patches,
        transform,
    )

    assert MiniFASNet is not None
    assert functional is not None
    assert generate_patches is not None
    assert transform is not None


@pytest.mark.unit
def test_no_pycache_in_package():
    """Test that __pycache__ directories are not included in the installed package."""
    import idvpackage

    # Get the installed package location (site-packages or editable install)
    package_dir = Path(idvpackage.__file__).parent

    # Find all __pycache__ directories in the installed package
    pycache_dirs = list(package_dir.rglob('__pycache__'))

    # In development (editable install), __pycache__ will exist after imports
    # This is expected and can be ignored
    # But if this is a proper installed package (from wheel), there should be none
    # We can check if we're in an editable install by looking for site-packages in path

    if 'site-packages' in str(package_dir):
        # This is a proper installed package, not editable
        assert len(pycache_dirs) == 0, (
            f"Found {len(pycache_dirs)} __pycache__ directories in installed package. "
            f"Build configuration should exclude them: {pycache_dirs}"
        )
    else:
        # Editable install - __pycache__ is expected, verify config exists
        pyproject_path = Path(__file__).parent.parent / 'pyproject.toml'

        if pyproject_path.exists():
            content = pyproject_path.read_text()
            # Simple check that the configuration mentions __pycache__ exclusion
            assert '__pycache__' in content, (
                "pyproject.toml should have __pycache__ exclusion configuration"
            )
