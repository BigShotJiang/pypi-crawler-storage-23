
import time
from io import BytesIO
import cv2

from openai import OpenAI
from pydantic import BaseModel, Field
import logging


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)



PROMPT_FRONT = """
Extract ALL fields from this UAE National ID **front side** image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

- id_number: The ID number exactly as shown on the card example: 784-1999-1234567-1 but return without dashes (i.e., 784199912345671)
- name: Full name as shown on the card (extract exactly as written on the card).
- first_name: Only the First name, as shown on the card (extract exactly as written on the card).
- last_name: Only the Last name, as shown on the card (extract exactly as written on the card).
- dob: Extract date of birth exactly as shown on card. Convert date to format DD-MM-YYYY If there is no date of birth, return an empty string.
- nationality: Extract the nationality exactly as printed on the card Convert nationality to ISO 3166-1 alpha-3 code. e.g. EGY for Egypt, IND for India.
- issue_date: Extract issue date exactly as shown on card. Convert date to format DD-MM-YYYY If there is no issue date, return an empty string.
- expiry_date: Extract the expiry date exactly as shown on card. Convert date to format DD-MM-YYYY If there is no expiry date, return an empty string.
- gender: Extract gender exactly as printed on the card. If there is no gender, return an empty string. If gender is M, return "Male". If gender is F, return "Female".
- header_verified: Return True if one of the texts present in the image UNITED ARAB EMIRATES else return False.

Instructions:
- Do NOT guess or hallucinate any values. If unclear, return empty string.
- Only use information visible on the card.
- Return the result as a single JSON object matching the schema above.
"""


PROMPT_BACK = """
Extract ALL fields from this UAE National ID **back side** image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

- employer: Employer name as shown in the image (English version; extract exactly as written on the card). If the employer is not present, return an empty string.
- occupation: Occupation as shown in the image (English version; extract exactly as written on the card). If the occupation is not present, return an empty string.
- family_sponsor : Family sponsor name as show in the image English Version(extract exactly as written on the card) If the family sponsor is not present, return an empty string.
- expiry_date: Extract the expiry date exactly as shown on card. Convert date to format DD-MM-YYYY If there is no expiry date, return an empty string.
- dob: Extract date of birth date exactly as shown on card. Convert date to format DD-MM-YYYY If there is no date of birth, return an empty string
- gender: Extract gender exactly as shown on card. If it is M, return Male If it is F, return Female If there is no gender on the card, return an empty string.
- card_number: Card number as shown on the card (extract exactly as written, e.g., 119887248)
- issuing_place: Issuing place as shown in the image (extract exactly as written on the card). If the issuing place is not present, return an empty string.
- back_header_verified: Return True if one of the texts present in the image is "ILARE" or "IDLARE"; otherwise False.
- mrz1: First line of the MRZ
- mrz2: Second line of the MRZ
- mrz3: Third line of the MRZ
- family_sponsor: Family sponsor name as shown in the image (English version; extract exactly as written on the card). If the family sponsor is not present, return an empty string.
- dob_mrz: Date of birth extracted from MRZ line 2 in DD-MM-YYYY format.
- gender_mrz: Gender extracted from MRZ line 2: 'M' for Male, 'F' for Female.
- expiry_date_mrz: Expiry date extracted from MRZ line 2 in DD-MM-YYYY format.

Instructions:
- Do NOT guess or hallucinate any values. If unclear, return empty string.
- Only use information visible on the card.
- Return the result as a single JSON object matching the schema above.
- If any of the fields are not present on the card, return empty strings for those fields.
"""

class UAEFront(BaseModel):

    id_number: str = Field(...,min_length=15, maximum=15,
        description = "The ID number exactly as shown on the card example: 784-1999-1234567-1 but return without dashes (i.e., 784199912345671)",
    )

    name: str = Field(..., description="Full name as shown on the card (extract exactly as written on the card).")

    first_name: str = Field(..., description="First name as shown on the card (extract exactly only the first name as written on the card).")

    last_name: str = Field(..., description="Last name as shown on the card (extract exactly only the last name as written on the card).")

    dob: str = Field(..., description="Extract date of birth exactly as shown on card."
                                      "Convert date to format dd-mm-yyyy"
                                      "If there is no date of birth, return an empty string.")

    nationality: str = Field(..., description="Extract the nationality exactly as printed on the card"
                                              "Convert nationality to ISO 3166-1 alpha-3 code. e.g. EGY for Egypt, IND for India.")

    issue_date: str = Field(..., description="Extract issue date exactly as shown on card."
                                             "Convert date to format dd-mm-yyyy"
                                             "If there is no issue date, return an empty string.")

    expiry_date: str = Field(..., description="Extract the expiry date exactly as shown on card."
                                              "Convert date to format dd-mm-yyyy"
                                              "If there is no expiry date, return an empty string.")

    gender: str = Field(..., description="Extract gender exactly as printed on the card."
                                         "If there is no gender, return an empty string.")

    
    header_verified: bool = Field(
        ...,
        description=" Return True if one of the texts present in the image UNITED ARAB EMIRATES else return False.",
    )

class UAEBack(BaseModel):

    employer: str = Field(...,
        description = "Employer name as shown in the image English Version(extract exactly as written on the card)"
                      "If the employer is not present, return an empty string."
    )

    occupation: str = Field(...,
        description = "Occupation as shown in the image English version(extract exactly as written on the card)"
                      "If the occupation is not present, return an empty string."
    )

    family_sponsor : str = Field(...,
        description="Family sponsor name as show in the image English Version(extract exactly as written on the card)"
                    "If the family sponsor is not present, return an empty string."
    )

    expiry_date: str = Field(..., description="Extract the expiry date exactly as shown on card."
                                              "Convert date to format dd-mm-yyyy"
                                              "If there is no expiry date, return an empty string.")

    dob: str = Field(..., description="Extract date of birth date exactly as shown on card."
                                      "Convert date to format dd-mm-yyyy"
                                      "If there is no date of birth, return an empty string.")

    gender: str = Field(..., description="Extract gender exactly as shown on card."
                                         "If it is M, return Male"
                                         "If it is F, return Female"
                                         "If there is no gender on the card, return an empty string.")

    card_number: str = Field(...,min_length=9, max_length=9,
        description = "9-digit Card number extract exactly as written on the card, example: 119887248"
    )

    issuing_place: str = Field(...,
        description = "Issuing place as show in the image (extract exactly as written on the card)",
    )

    back_header_verified: bool = Field(
        ...,
        description=" Return True if one of the texts present in the image: ILARE or IDARE else return False  ",
    )

    mrz1: str = Field(..., 
        description="First line of the MRZ, exactly as printed on the card."
    )

    mrz2: str = Field(..., 
        description="Second line of the MRZ, exactly as printed on the card."
    )

    mrz3: str = Field(..., 
        description="Third line of the MRZ, exactly as printed on the card."
    )
    dob_mrz: str = Field(...,
        description="Date of birth extracted from MRZ line 2 in dd-mm-yyyy format."
    )
    gender_mrz: str = Field(...,
        description="Gender extracted from MRZ line 2: 'M' for Male, 'F' for female."       
    )
    expiry_date_mrz: str = Field(...,
        description="Expiry date extracted from MRZ line 2 in dd-mm-yyyy format."
    )


def process_image(side):

    if side == "front":
        prompt = PROMPT_FRONT
        model = UAEFront
    
    elif side == "back":
        prompt =  PROMPT_BACK
        model = UAEBack

    else:
        raise ValueError("Invalid document side specified. please upload front side of passport'.")

    return model, prompt

def get_openai_response(prompt: str, model_type, image: str, genai_key):

    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {"role": "system", "content": "You are an expert at extracting information from identity documents."},
                    {"role": "user", "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_image", "image_url": f"data:image/jpeg;base64,{image}", "detail": "low"},
                    ]},
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None

def get_response_from_openai_uae(image, side, country, openai_key):

    logging.info("Processing image for UAE National ID extraction OPENAI......")
    logging.info(f" and type: {type(image)}")
    try:
        model, prompt = process_image(side)
        logging.info(f"Using model: {model.__name__} and prompt {prompt[:100]}")
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}

    try:
        response = get_openai_response(prompt, model, image, openai_key)
    except Exception as e:
        logging.error(f"Error during OpenAI request: {e}")
        return {"error": "OpenAI request failed"}

    response_data = vars(response)
    logging.info(f"Openai response: {response}")
    return response_data