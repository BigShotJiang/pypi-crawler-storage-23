
import cv2
import numpy as np
from PIL import Image
import logging
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed


# Global variables to store lazily loaded modules
_deepface = None
_face_recognition = None

def get_deepface():
    """Lazy loading of DeepFace"""
    global _deepface
    if _deepface is None:
        from deepface import DeepFace
        _deepface = DeepFace
    return _deepface

def get_face_recognition():
    """Lazy loading of face_recognition"""
    global _face_recognition
    if _face_recognition is None:
        import face_recognition
        _face_recognition = face_recognition
    return _face_recognition



def deepface_to_dlib_rgb(face):
    """
    Convert DeepFace face output to uint8 RGB for face_recognition
    """
    # face may be float32 [0,1]
    if face.dtype != np.uint8:
        face = (face * 255).clip(0, 255).astype(np.uint8)

    # ensure shape is (H, W, 3)
    if face.ndim != 3 or face.shape[2] != 3:
        raise ValueError(f"Invalid face shape: {face.shape}")

    return face

def load_and_process_image_deepface_topup(image_input):
    DeepFace = get_deepface()  # Only load when needed
    face_recognition = get_face_recognition()  # Only load when needed

    def process_angle(img, angle):
        try:
            # Create a view instead of copy when possible
            if angle != 0:
                # Minimize memory usage during rotation
                with np.errstate(all='ignore'):
                    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                    img_pil = Image.fromarray(img_rgb)
                    # Use existing buffer when possible
                    rotated = np.ascontiguousarray(img_pil.rotate(angle, expand=True))
                    img_to_process = cv2.cvtColor(rotated, cv2.COLOR_RGB2BGR)
                    # Clear references to intermediate arrays
                    del img_rgb, img_pil, rotated
            else:
                img_to_process = img

            # Extract faces with memory optimization
            face_objs = DeepFace.extract_faces(
                img_to_process,
                detector_backend='retinaface',
                enforce_detection=False,
                align=True
            )

            logging.info(f"Faces detected at {angle} degrees: confidence levels {[face.get('confidence', 0) for face in face_objs]}")

            if face_objs and len(face_objs) > 0:
                confidence = face_objs[0].get('confidence', 0)
                # print(f"Face detected at {angle} degrees with confidence {confidence}")

                return face_objs, img_to_process, confidence

            # Clear memory if no face found
            if 'img_to_process' in locals():
                del img_to_process
            return None, None, 0
        except Exception as e:
            logging.info(f"Error processing angle {angle}: {e}")
            return None, None, 0
        finally:
            # Ensure memory is cleared
            if 'img_to_process' in locals():
                del img_to_process

    try:
        # Process input image efficiently
        logging.info("Processing image at angle 0")
        if isinstance(image_input, np.ndarray):
            # Use view when possible
            image = np.ascontiguousarray(image_input)
            if image.dtype != np.uint8:
                image = image.astype(np.uint8, copy=False)
        elif isinstance(image_input, str):
            # Decode base64 directly to numpy array
            image_data = base64.b64decode(image_input)
            image = cv2.imdecode(np.frombuffer(image_data, np.uint8), cv2.IMREAD_COLOR)
            del image_data  # Clear decoded data
        else:
            logging.info(f"Unexpected input type: {type(image_input)}")
            return [], []

        if image is None or image.size == 0:
            logging.info("Empty image")
            return [], []

        logging.info("Image conversion is completed successfully......")

        CONFIDENCE_THRESHOLD = 0.97

        # Try original orientation first to avoid unnecessary processing
        face_objs, processed_image, confidence = process_angle(image, 0)

        logging.info("Processing image at angle 0 is completed ......")
        if face_objs is not None and confidence >= CONFIDENCE_THRESHOLD:
            logging.info(f"Face detected in at angle 0 orientation with confidence {confidence}")
            try:
                biggest_face = max(face_objs, key=lambda face: face['facial_area']['w'] * face['facial_area']['h'])
                cropped_aligned_face = biggest_face['face']
                cropped_face = deepface_to_dlib_rgb(cropped_aligned_face)
                h, w = cropped_face.shape[:2]
                face_locations = [(0, w, h, 0)]  # (top, right, bottom, left)
                face_encodings = face_recognition.face_encodings(cropped_face,face_locations)
                logging.info(f"Length of face_encoding's list: {len(face_encodings)}")



                if face_encodings:
                    logging.info(f"Shape of face_encodigns: {face_encodings[0].shape}")
                    return  face_encodings
            finally:
                print(f"Done processing angle 0.")

        # Try other angles in parallel only if needed
        # print("Trying other angles in parallel...")
        angles = [270, 180, 90]
        best_confidence = confidence if face_objs is not None else 0
        best_face_objs = face_objs
        best_image = processed_image

        # Use context manager to ensure proper cleanup
        with ThreadPoolExecutor(max_workers=3) as executor:
            # Submit tasks
            futures = {
                executor.submit(process_angle, image, angle): angle
                for angle in angles
            }

            try:
                for future in as_completed(futures):
                    face_objs, processed_image, confidence = future.result()
                    if face_objs is not None:
                        if confidence >= CONFIDENCE_THRESHOLD:
                            # Cancel remaining tasks
                            for f in futures:
                                if not f.done():
                                    f.cancel()
                            best_face_objs = face_objs
                            best_image = processed_image
                            best_confidence = confidence
                            break
                        elif confidence > best_confidence:
                            # Update best result
                            best_confidence = confidence
                            best_face_objs = face_objs
                            best_image = processed_image
            finally:
                # Ensure all futures are cancelled
                for future in futures:
                    future.cancel()

        logging.info(f"Using best detected face with confidence {best_confidence}")
        try:
            image_rgb = None
            biggest_face = max(best_face_objs, key=lambda face: face['facial_area']['w'] * face['facial_area']['h'])
            cropped_aligned_face = biggest_face['face']
            cropped_face = deepface_to_dlib_rgb(cropped_aligned_face)

            h, w = cropped_face.shape[:2]
            face_locations = [(0, w, h, 0)]  # (top, right, bottom, left)
            face_encodings = face_recognition.face_encodings(cropped_face, face_locations)
            logging.info(f"Length of face_encoding's list: {len(face_encodings)}")

            if face_encodings:
                logging.info(f"Shape of face_encodigns: {face_encodings[0].shape}")
                return  face_encodings

            
            else: #fall back if detector failed to detect face in all angles
                logging.info("All 4 angles failed to detect image, sending whole image for encodings")
                image_rgb = cv2.cvtColor(processed_image, cv2.COLOR_BGR2RGB)
                h, w = image_rgb.shape[:2]
                face_locations = [(0, w, h, 0)]
                # logging.info(f"image_rgb.shape {image_rgb.shape}" )
                face_encodings = face_recognition.face_encodings(image_rgb, face_locations)
                logging.info(f"Length of face_encoding's: {len(face_encodings)}")

                return face_encodings

            logging.info("Failed to extract face encodings")
            return [], []
        finally:
            # Clear final processing memory
            del image_rgb, best_image, best_face_objs

    except Exception as e:
        logging.info(f"Error in face detection: {e}")
        return [], []
    finally:
        # Ensure main image is cleared
        if 'image' in locals():
            del image
        if 'face_objs' in locals():
            del face_objs
        if 'processed_image' in locals():
            del processed_image


def load_and_process_image_deepface(image_input, country=None):
    DeepFace = get_deepface()
    face_recognition = get_face_recognition()

    CONFIDENCE_THRESHOLD = 0.90 if country == "SDN" else 0.97

    def process_angle(img, angle):
        img_to_process = None
        img_rgb = None
        img_pil = None
        rotated = None

        try:
            # Rotate only if needed
            if angle != 0:
                img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                img_pil = Image.fromarray(img_rgb)
                rotated = np.ascontiguousarray(
                    img_pil.rotate(angle, expand=True)
                )
                img_to_process = cv2.cvtColor(rotated, cv2.COLOR_RGB2BGR)
            else:
                img_to_process = img

            face_objs = DeepFace.extract_faces(
                img_to_process,
                detector_backend="fastmtcnn",
                enforce_detection=False,
                align=True,
            )

            if not face_objs:
                return None, None, 0.0

            #get largest face
            biggest_face = max(
                face_objs,
                key=lambda f: f["facial_area"]["w"] * f["facial_area"]["h"],
            )

            facial_area = biggest_face["facial_area"]
            confidence = biggest_face.get("confidence", 0.0)

            logging.info(f"Angle {angle}: Detected face with confidence {confidence}")

            if country == "SDN":
                if confidence < CONFIDENCE_THRESHOLD:
                    logging.info(f"Low confidence for SDN at angle: {confidence} at angle {angle}")
                    return None, None, 0.0
            else:
                if confidence < 0.95:
                    logging.info(f"Low confidence: for country : {country} -> {confidence} at angle {angle}")
                    return None, None, 0.0

            # Size validation (only when confidence < 1)
            w, h = facial_area["w"], facial_area["h"]
            if country == "SDN":
                if w < 40 or h < 50:
                    logging.info(f"Face too small for SDN: w={w}, h={h}")
                    return None, None, 0.0
            # else:
            #     if w < 80 or h < 90:
            #         logging.info(f"Face too small: w={w}, h={h}")
            #         return None, None, 0.0

            # All checks passed
            return biggest_face, img_to_process, confidence

        except Exception as e:
            print(f"[DeepFace] Error at angle {angle}: {e}")
            return None, None, 0.0

        finally:
            # Aggressive memory cleanup
            if img_rgb is not None:
                del img_rgb
            if img_pil is not None:
                del img_pil
            if rotated is not None:
                del rotated

    # -------------------- INPUT HANDLING --------------------

    try:
        if isinstance(image_input, np.ndarray):
            image = np.ascontiguousarray(image_input)
            if image.dtype != np.uint8:
                image = image.astype(np.uint8, copy=False)

        elif isinstance(image_input, str):
            image_data = base64.b64decode(image_input)
            image = cv2.imdecode(
                np.frombuffer(image_data, np.uint8),
                cv2.IMREAD_COLOR,
            )
            del image_data

        else:
            print("Unsupported image input type")
            return [], []

        if image is None or image.size == 0:
            print("Empty image input")
            return [], []

        # -------------------- ANGLE LOOP (NO THREADS) --------------------

        best_face_objs = None
        best_image = None
        best_confidence = 0.0

        for angle in (0, 90, 180, 270):
            face_objs, processed_image, confidence = process_angle(image, angle)

            if confidence > best_confidence:
                best_face_objs = face_objs
                best_image = processed_image
                best_confidence = confidence
                best_angle = angle

            if face_objs is None:
                continue
            else:
                break  # Exit loop on first valid detection

            # Keep best fallback (just in case)


        #remove best_confidence < CONFIDENCE_THRESHOLD to take best of all angles when confidence is less than threshold
        if best_face_objs is None:
            print(f"No valid face found (threshold={CONFIDENCE_THRESHOLD})")
            return [], []

        # -------------------- FINAL ENCODING --------------------

        
        logging.info(f"Using best angle: {best_angle} detected with confidence {best_confidence} for encodings")
        fa = best_face_objs["facial_area"]
        x, y, w, h = fa["x"], fa["y"], fa["w"], fa["h"]

        image_rgb = cv2.cvtColor(best_image, cv2.COLOR_BGR2RGB)
        face_locations = [(y, x + w, y + h, x)]
        face_encodings = face_recognition.face_encodings(
            image_rgb, face_locations
        )

        if not face_encodings:
            return [], []

        return face_locations, face_encodings

    except Exception as e:
        print(f"[FacePipeline] Fatal error: {e}")
        return [], []

    finally:
        # Final memory cleanup
        if "image_rgb" in locals():
            del image_rgb
        if "best_image" in locals():
            del best_image
        if "best_face_objs" in locals():
            del best_face_objs
        if "image" in locals():
            del image


def calculate_similarity(face_encoding1, face_encoding2):
    face_recognition = get_face_recognition()
    similarity_score = 1 - face_recognition.face_distance([face_encoding1], face_encoding2)[0]

    return round(similarity_score + 0.25, 2)

def extract_face_and_compute_similarity(front_face_locations, front_face_encodings, back_face_locations, back_face_encodings):
    largest_face_index1 = front_face_locations.index(max(front_face_locations, key=lambda loc: (loc[2] - loc[0]) * (loc[3] - loc[1])))
    largest_face_index2 = back_face_locations.index(max(back_face_locations, key=lambda loc: (loc[2] - loc[0]) * (loc[3] - loc[1])))

    face_encoding1 = front_face_encodings[largest_face_index1]
    face_encoding2 = back_face_encodings[largest_face_index2]

    similarity_score = calculate_similarity(face_encoding1, face_encoding2)

    return min(1, similarity_score)

