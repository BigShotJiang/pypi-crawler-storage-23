


import base64
import time
from io import BytesIO
from typing import Optional
import cv2

from openai import OpenAI
from pydantic import BaseModel, Field
import logging


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)

PROMPT_FRONT = """
Extract ALL fields from this Syrian Passport front side image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

- first_name: Given Name (extract exactly as written on the card)
- last_name: Surname (extract exactly as written on the card)
- father_name: Father's Name (extract exactly as written on the card)
- mother_name: Mother's Name (extract exactly as written on the card)
- dob: Date of birth exactly as shown on the card (preserve original format)
- passport_number: Passport number as printed beside N° or No (exactly 9 characters) above side of the photo
- place_of_birth: Place of birth in English (extract exactly as written on the card)
- mrz1: First line of the MRZ, exactly 44 characters, pad with '<' at the end if shorter
- mrz2: Second line of the MRZ, exactly 44 characters
- gender: Gender as either MALE or FEMALE (extract exactly as printed)
- header_verified: True if both 'SYRIAN ARAB REPUBLIC' and 'PASSPORT' are clearly visible, else False
- country_code: Country code as printed below the text 'country code' (extract exactly as written)
- issue_number: Issue number as printed on the card as 'Issue no' (extract exactly as written)
- passport_number_mrz: Passport number as extracted from MRZ present in starting of mrz line 1
- dob_mrz: Date of birth as extracted from MRZ in DD/MM/YYYY format
- gender_mrz: Gender as extracted from MRZ (M or F) if M return MALE else if F return FEMALE
- expiry_date_mrz: Expiry date as extracted from MRZ line 2 in DD/MM/YYYY format

Instructions:
- Do NOT guess or hallucinate any values. If unclear, return null.
- Only use information visible on the card.
- Return the result as a single JSON object matching the schema above.
"""

PROMPT_BACK = """
Extract ALL fields from this Syrian Passport back side image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

- issue_date: Issue date in DD/MM/YYYY format (extract exactly as printed)
- place_of_issue: Place of issue as printed on the card
- expiry_date: Expiry date in DD/MM/YYYY format (extract exactly as printed)
- national_number: National number as printed on the card (example: 123-12345678)

Instructions:
- Do NOT guess or hallucinate any values. If a field is faint, blurry, or unclear, return null.
- Only use information visible on the card.
- Return the result as a single JSON object matching the schema above.
"""


class SyriaPassportFront(BaseModel):
   

    first_name: str = Field(...,
                             description = "Name of the person ( printed as Given Name, extract exactly as written on the card)")
    
    last_name: str = Field(...,
                            description = "Surname of the person ( printed as Surname. extract exactly as written on the card)")
    
    father_name: str = Field(
        ...,
        description="Father's Name of the person (printed as Father Name, extract exactly as written on the card)",
    )

    mother_name: str = Field(
        ...,
        description="Mother's Name of the person (printed as Mother Name, extract exactly as written on the card)",
    )
    
    dob: str = Field(
        ...,
        description="The date of birth exactly as shown on the card (preserve original format)",
    )
    
    passport_number : str = Field(
        ..., min_length=9, max_length=9,
        description="Passport number as printed beside N° or No (exactly 9 characters) present above side of the photo",
    )

    place_of_birth: str = Field(
        ...,
        description = "The place of birth in english(printed as Birth Place, extract exactly as written on the card)",
    )


    mrz1: str = Field(..., min_length=44, max_length=44,
        description="First line of the MRZ, exactly 44 characters, padded with '<' at the end if shorter"
    )

    mrz2: str = Field(..., min_length=44, max_length=44,
        description="Second line of the MRZ, exactly 44 characters"
    )

    gender: str = Field(..., description="Gender as either MALE or FEMALE (printed as Sex on the card)")


    header_verified: bool = Field(
        ...,
        description="Whether the standard header text (SYRIAN ARAB REPUBLIC) is present in the image.",
    )

    country_code: str = Field(
        ...,
        description="The country code,(value is printed below the text country code, extract exactly as written on the card)",
    )

    issue_number: str = Field(  
        ...,
        min_length=14, max_length=14, description="Issue number as printed on the card as 'Issue no' extract exactly as written on the card",
    )
    
    
    passport_number_mrz: str = Field(
        ...,min_length = 9, max_length = 9, description="Passport number as extracted from MRZ present in starting of mrz line 1"
    )
    dob_mrz: str = Field(
        ..., description="Date of birth as extracted from MRZ (in DD/MM/YYYY format)"
    )
    gender_mrz: str = Field(
        ..., description="Gender as extracted from MRZ (M or F) if M return MALE else if F return FEMALE"
    )
    expiry_date_mrz: str = Field(
        ..., description="Expiry date as extracted from MRZ line 2(in DD/MM/YYYY format)"
    )
    
class SyriaPassportBack(BaseModel):
    issue_date: str = Field(..., description="Issue date in DD/MM/YYYY format")
    place_of_issue: str = Field(..., description="Place of issue as printed on the card")
    expiry_date: str = Field(..., description="Expiry date in DD/MM/YYYY format")
    national_number: str = Field(..., description="national number as printed on the card example: 123-12345678")

def process_image(side):

    if side == "first" or side == "page1":
        prompt = PROMPT_FRONT
        model = SyriaPassportFront

    elif side == "back" or side == "page2":
        prompt = PROMPT_BACK
        model = SyriaPassportBack

    else:
        raise ValueError("Invalid document side specified. Use 'front', 'back', or 'passport'.")

    return model, prompt

def get_openai_response(prompt: str, model_type, image: BytesIO, openai_key):
    b64_image = base64.b64encode(image.getvalue()).decode("utf-8")
    for attempt in range(3):
        try:
            client = OpenAI(api_key=openai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {"role": "system", "content": "You are an expert at extracting information from identity documents."},
                    {"role": "user", "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_image", "image_url": f"data:image/jpeg;base64,{b64_image}", "detail": "high"},
                    ]},
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None
def _image_to_jpeg_bytesio(image) -> BytesIO:
    """
    Accepts: numpy.ndarray (OpenCV BGR), PIL.Image.Image, bytes/bytearray, or io.BytesIO
    Returns: io.BytesIO containing JPEG bytes (ready for get_openai_response)
    """
    import numpy as np

    if isinstance(image, BytesIO):
        image.seek(0)
        return image

    if isinstance(image, (bytes, bytearray)):
        return BytesIO(image)

    try:
        from PIL.Image import Image as _PILImage

        if isinstance(image, _PILImage):
            buf = BytesIO()
            image.convert("RGB").save(buf, format="JPEG", quality=95)
            buf.seek(0)
            return buf
    except Exception:
        pass

    if isinstance(image, np.ndarray):
        success, enc = cv2.imencode(".jpg", image)
        if not success:
            raise ValueError("cv2.imencode failed")
        return BytesIO(enc.tobytes())

    raise TypeError(
        "Unsupported image type. Provide numpy.ndarray, PIL.Image.Image, bytes, or io.BytesIO."
    )

def get_response_from_openai_syr(image, side, country, openai_key):

    logging.info("Processing image for Syria passport extraction OPENAI......")
    logging.info(f" and type: {type(image)}")
    try:
        image = _image_to_jpeg_bytesio(image)
    except Exception as e:
        logging.error(f"Error encoding image: {e}")
        return {"error": "Image encoding failed"}
    try:
        model, prompt = process_image(side)
        logging.info(f"Using model: {model.__name__} and prompt {prompt[:100]}")
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}

    try:
        response = get_openai_response(prompt, model, image, openai_key)
    except Exception as e:
        logging.error(f"Error during OpenAI request: {e}")
        return {"error": "OpenAI request failed"}

    response_data = vars(response)
    logging.info(f"Openai response: {response}")
    return response_data