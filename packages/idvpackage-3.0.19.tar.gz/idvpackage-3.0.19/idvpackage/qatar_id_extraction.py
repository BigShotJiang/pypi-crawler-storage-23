

import base64
import time
from io import BytesIO

import cv2

from openai import OpenAI
from pydantic import BaseModel, Field
import logging


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)





ON_SCREEN_VS_PHYSICAL_PROMPT = """

ROUTINE: Determine Whether Image is On-Screen or a Physical Card

OVERVIEW:
Use a hierarchy-based approach. Prioritize exclusive on-screen indicators first.
Do not classify as physical based on weak or shared indicators such as minor perspective distortion or slight lighting variation.

--------------------------------------------------

STEP 1 — Detect Exclusive On-Screen Indicators (High Priority)

Examine the image for indicators strongly associated with photographed digital displays, including:

1A i: **If ANY moiré patterns or pixel grid artifacts are visible**:
→ IMMEDIATELY classify as: screen
→ STOP. Do not evaluate physical indicators. Proceed to STEP 3.

1A ii: **If ANY signs of LCD Backlight are visible**:
→ IMMEDIATELY classify as: screen
→ STOP. Do not evaluate physical indicators. Proceed to STEP 3.


1B: OTHERWISE, analyze for the following indicators:
- **moiré patterns or pixel grid artifacts are visible
- ** Subpixel structure or vertical scan lines
- ** Uniform LCD/LED backlight glow
- ** Screen refresh artifacts
- ** Visible device bezels or monitor frame
- ** UI overlays (status bar, battery, time, app UI, cursor)
- ** Glass reflections consistent with flat displays
- ** Perfect edge-to-edge digital framing with no measurable depth
- ** A shadow only counts as a physical indicator if it is cast onto a visible environmental surface (table, fabric, hand, etc.) with measurable depth separation.
- ** A uniform gray gradient background without surface texture is NOT environmental context.
- ** Rounded corners and drop shadows embedded in the graphic design do NOT indicate physical depth.


If ANY of the above indicators are clearly present:
→ Classify the image as: screen
→ STOP. Do not continue to physical-card analysis. Proceed to STEP 3.

--------------------------------------------------

STEP 2 — Detect Strong Physical-Card Indicators

Only evaluate this step if NO strong on-screen indicators were detected.

Look for TRUE physical depth evidence, including:

- ** Clearly visible card thickness or layered edge
- ** Card casting a shadow onto a real surface
- ** Surface texture (matte grain, gloss highlights, wear marks, scratches)
- ** Environmental background (table, hand holding card, fabric, etc.)
- ** Depth-of-field blur separating card from background
- ** Slight corner bending, warping, or physical imperfections
- ** Uneven lighting across the card consistent with a 3D object

**IMPORTANT**:
The following do NOT count as strong physical indicators:
- ** Slight perspective skew
- ** Minor lighting variation
- ** Camera softness
- ** Dark background without visible surface
- ** Cropping shadows
- ** General evidence that the image was photographed
- **Textured backgrounds that could be digital wallpaper (fabric, wood grain, etc.) 
  WITHOUT visible depth separation or card-to-surface interaction**


If TWO OR MORE strong physical indicators are clearly present:
→ Classify the image as: physical
→ STOP. Proceed to STEP 3.

--------------------------------------------------

STEP 3 — Conflict Resolution

If both screen and physical indicators appear:

- ** If moiré, pixel grid artifacts, or LCD backlight glow are present → classify as: screen
- ** If visible card thickness AND environmental surface interaction are present → classify as: physical
- ** If uncertainty remains → default to: screen

--------------------------------------------------

FINAL OUTPUT:

If On-Screen Digital Image:
return the word "screen" only.

If Physical Card:
return the word "physical" only.


"""

PROMPT_FRONT = """
Extract ALL fields from this Qatar National ID **front side** image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

    - id_number: The ID number exactly as shown on the card (preserve original format)
    - dob: Date of birth exactly as shown on the card, but always return in DD/MM/YYYY format (e.g., '15/06/1990'). If the card shows a different format, convert it to DD/MM/YYYY.
    - expiry_date: Date of expiry exactly as shown on the card, but always return in DD/MM/YYYY format (e.g., '15/06/1990'). If the card shows a different format, convert it to DD/MM/YYYY.
    - name: Full name in English as printed on the card (extract exactly as written)
    - name_ar: Full name in Arabic as printed on the card (extract exactly as written)
    - first_name: First name extracted from the full name (use the first word from the English name)
    - last_name: Last name extracted from the full name (use the last word from the English name)
    - nationality: Nationality as printed on the card and return ISO 3166-1 alpha-3 code (e.g., QAT)
    - occupation_ar: Occupation in Arabic as printed on the card (extract exactly as written)
    - occupation_en: Translate the Arabic occupation to English (e.g., طالب → Student, عامل → Worker, موظف → Employee)
    - header_verified: Return True if one of the texts present in the image is "State of Qatar" or "Residency Permit"; otherwise False.

Instructions:
    - Do NOT guess or hallucinate any values. If unclear, return empty string.
    - Only use information visible on the card.
    - Return the result as a single JSON object matching the schema above.
"""



PROMPT_BACK = """
Extract ALL fields from this Qatar National ID **back side** image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

- employer: Employer name in Arabic as printed on the card (extract exactly as written)
- employer_en: Translate the Arabic employer name to English 
- passport_number: Passport number as printed on the card (extract exactly as written)
- passport_expiry: Passport expiry date  always in DD/MM/YYYY format.
- back_header_verified: Return True if one of the texts present in the image is "Director General of the General Department" or "Directorate of Passports" or "Passport number" or "Serial"; otherwise False.
- card_number: Serial number exactly as shown on the card (preserve original format)

Instructions:
- Do NOT guess or hallucinate any values. If unclear, return empty string.
- Only use information visible on the card.
- Return the result as a single JSON object matching the schema above.
"""


class QatarFront(BaseModel):
   
    id_number: str = Field(...,min_length=11, max_length=11,
        description = "The ID number exactly as shown on the card (preserve original format)",
    )
    
    dob: str = Field(...,
        description = "The date of birth exactly as shown on the card ((preserve (dd/mm/yyyy) format))",
    )

    expiry_date: str = Field(...,
        description = "The date of expiry exactly as shown on the card (preserve (dd/mm/yyyy) format)",
    )

   
    name: str = Field(...,
                      description="Full name as printed on the card (extract exactly as written on the card)"
                      )

    name_ar: str = Field(...,
                      description="Full name in Arabic as printed on the card (extract exactly as written on the card)"
                      )
    
    first_name: str = Field(...,
        description="First name extracted from full_name",
    )

    last_name: str = Field(...,
        description="Last name extracted from full_name",
    )
    
    nationality: str = Field(...,
                      description="Nationality as printed on the card and return ISO 3166-1 alpha-3, e.g., BGD"
    )

    occupation: str = Field(
        ...,
        description="The occupation in Arabic (extract exactly as written on the card)",
    )

    occupation_en: str = Field(
        ...,
        description="TRANSLATE the Arabic occupation to English (e.g., طالب → Student, عامل → Worker, موظف → Employee)",
    )
    

    header_verified: bool = Field(
        ...,
        description=" Return True if one of the texts present in the image State of Qatar or Residency Permit",
    )
class QatarBack(BaseModel):
    employer: str = Field(...,
        description = "Employer name in Arabic (extract exactly as written on the card) return empty string if not present",
    )

    employer_en: str = Field(...,
        description = "TRANSLATE the Arabic  employer name to English, if employer is not present return empty string",

    )

    passport_number: str = Field(...,
        description = "Passport number  extract exactly as written on the card, return empty string if not present",
    )

    passport_expiry: str = Field(...,
        description = "Passport expiry date exactly as shown on the card (preserve (dd/mm/yyyy) format), return empty string if not present",
    )

    back_header_verified: bool = Field(
        ...,
        description=" Return True if one of the texts present in the image Director General of the General Department or Directorate of Passports or Passport number or Serial else return False",
    )

    card_number: str = Field(...,
        description = "Serial number exactly as shown on the card (preserve original format), return empty string if not present",
    )


def process_image(side):

    if side == "front":
        prompt = PROMPT_FRONT
        model = QatarFront
    
    elif side == "back":
        prompt =  PROMPT_BACK
        model = QatarBack
    
    else:
        raise ValueError("Invalid document side specified. please upload front side of passport'.")

    return model, prompt

def get_openai_response(prompt: str, model_type, image: BytesIO, genai_key):
    b64_image = base64.b64encode(image.getvalue()).decode("utf-8")
    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {"role": "system", "content": "You are an expert at extracting information from identity documents."},
                    {"role": "user", "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_image", "image_url": f"data:image/jpeg;base64,{b64_image}", "detail": "low"},
                    ]},
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None

def _image_to_jpeg_bytesio(image) -> BytesIO:
    """
    Accepts: numpy.ndarray (OpenCV BGR), PIL.Image.Image, bytes/bytearray, or io.BytesIO
    Returns: io.BytesIO containing JPEG bytes (ready for get_openai_response)
    """
    import numpy as np

    if isinstance(image, BytesIO):
        image.seek(0)
        return image

    if isinstance(image, (bytes, bytearray)):
        return BytesIO(image)

    try:
        from PIL.Image import Image as _PILImage

        if isinstance(image, _PILImage):
            buf = BytesIO()
            image.convert("RGB").save(buf, format="JPEG", quality=95)
            buf.seek(0)
            return buf
    except Exception:
        pass

    if isinstance(image, np.ndarray):
        success, enc = cv2.imencode(".jpg", image)
        if not success:
            raise ValueError("cv2.imencode failed")
        return BytesIO(enc.tobytes())

    raise TypeError(
        "Unsupported image type. Provide numpy.ndarray, PIL.Image.Image, bytes, or io.BytesIO."
    )

def get_response_from_openai_qat(image, side, country, openai_key):

    logging.info("Processing image for Qatari NID extraction OPENAI......")
    logging.info(f" and type: {type(image)}")
    try:
        image = _image_to_jpeg_bytesio(image)
    except Exception as e:
        logging.error(f"Error encoding image: {e}")
        return {"error": "Image encoding failed"}
    try:
        model, prompt = process_image(side)
        logging.info(f"Using model: {model.__name__} and prompt {prompt[:100]}")
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}

    try:
        response = get_openai_response(prompt, model, image, openai_key)
    except Exception as e:
        logging.error(f"Error during OpenAI request: {e}")
        return {"error": "OpenAI request failed"}

    response_data = vars(response)
    logging.info(f"Openai response: {response}")
    return response_data


def is_physical_card(base64_image,genai_key):
    """
    Analyzes a base64-encoded image to determine if it's a picture of a physical card or a screen.

    Args:
        base64_image: Base64-encoded image string.
    Returns:
        True if the image is determined to be of a physical card.
        False if the image is determined to be of a card on a screen.
        {'error': 'bad_image'} if an exception occurs.
    """


    try:
        client = OpenAI(api_key=genai_key)
        response = client.chat.completions.create(
            model="gpt-5.2",
            max_completion_tokens=10,
            temperature=1,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": ON_SCREEN_VS_PHYSICAL_PROMPT},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{base64_image}",
                                "detail": "high"
                            },
                        },
                    ],
                }
            ]
        )
        decision = response.choices[0].message.content.lower().strip()

        if isinstance(decision,str):
            if decision=='screen':
                return False
            elif decision=='physical':
                return True
        else:
            return {'error':'bad_image', 'error_details':'Unexpected response format from OpenAI when detecting on-screen or physical image.'}

    except Exception as e:
        return {'error': 'bad_image', 'error_details': f'Exception Thrown while calling OpenAI API for on-screen vs physical card detection: str{e}.'}