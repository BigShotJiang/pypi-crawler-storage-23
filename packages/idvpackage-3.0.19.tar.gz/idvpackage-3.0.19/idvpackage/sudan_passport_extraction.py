
import base64
import time
from io import BytesIO
from typing import Optional
import cv2

from openai import OpenAI
from pydantic import BaseModel, Field
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)

PROMPT_FRONT = """
Extract ALL fields from this Sudanese National ID Card **front side** image with high accuracy.

1. Extract:
   - Full name in Arabic (`name_ar`) exactly as printed
   - Full name transliterated into English (`name`) in the same structure
   - Split both Arabic and English names into:
     - `first_name`, `middle_name`, `last_name`
     - `first_name_ar`, `middle_name_ar`, `last_name_ar`
     - If no middle name exists, return `null` for middle fields

2. Extract:
   - `id_number`: exactly 11 digits as printed (do not alter)
   - `dob`: date of birth in original format as printed (usually DD/MM/YYYY or similar)
   - `place_of_birth`: Arabic, exactly as printed
   - `place_of_birth_en`: transliteration of the Arabic place name (e.g., كسلا → Kassala)

3. Extract:
   - `occupation_ar`: exactly as written in Arabic
   - `occupation_en`: accurate English transliteration (e.g., طالب → Student)

4. Check if the header is present:
   - Must contain both 'SDN' and 'Republic of the Sudan Ministry of Interior'
   - Set `header_verified = true` only if both are clearly visible

5. Do NOT guess or hallucinate any values. If unclear, return empty string.

6. Return structured JSON output as per schema only.
"""

PROMPT_BACK = """
You are an expert in reading Sudanese National ID Cards. Extract the following fields from the **back side** of the ID image.

1. **Extract MRZ lines (Machine Readable Zone):**
   - Each line must be exactly 30 characters.
   - Return as a list of exactly 3 strings (`mrz`), in order.
   - Keep each line exactly as printed (no padding, no fixing).
   - Remove all whitespace and punctuation.
   - Return exact number of '<' characters in each line of mrz.

2. **Verify IDSDN prefix:**
   - If the first line of MRZ starts with 'IDSDN', return `idsdn_verified` as true. Otherwise, false.

3. **Extract name from back side:**
   - If printed name field is present (e.g., `NAME: ADNAN MAKI FADLALLAH MUSA`), use it.
   - Else, fallback to MRZ line 3 (name line).
   - Set `full_name_generic` exactly as it appears in the best available source (printed or MRZ).
   - Split the name as follows:
     - `first_name`: first word
     - `last_name`: last word
     - `middle_name`: all words in between (or `null` if none)

4. **Extract and format these fields:**
   - `dob_back`, `issue_date`, `expiry_date` in **DD/MM/YYYY** format.
   - `gender`: return `MALE` or `FEMALE`
   - `nationality`: return 3-letter ISO code (e.g., SDN)

5. **Extract data from mrz lines:**
   Ensure that the fields `mrz1` and `mrz2` strictly follow the below format for national id back:

    - each mrz line must be exactly 30 characters long.
    - `mrz1`,`mrz2`, `mrz3`    extract values as it is printed on card.
    - Use the `<` symbol for padding, **not spaces or any other characters**.
    - There should be **no commas, no spaces**, and only uppercase English alphabets, digits, and `<` characters are allowed.
    - If the line is shorter than 30 characters, pad it **only with `<` symbols at the end**, **except**:
    - In `mrz2`, the final character is a **check digit** (usually numeric) and must remain the last character. Padding with `<` should be applied **before** this digit.
    - Do not introduce extra characters to make the string 30 characters. Do not insert `<` between letters or numbers — only at the end (or just before the check digit in `mrz2`).
    - Do not append any punctuation like commas, periods, or symbols or spaces.
    - gender_mrz: extract gender from MRZ line 2 if M return `MALE`, if F return `FEMALE`
    - expiry_date_mrz: extract expiry date from MRZ line 2 and convert to DD/MM/YYYY
    - date_of_birth_mrz: extract date of birth from MRZ line 2 and convert to DD/MM/YYYY
   

6. **DO NOT GUESS.**
   - If a field is faint, blurry, or unclear, return empty string.

7. Return output as JSON according to the defined schema.
"""

PROMPT_PASSPORT = """
Extract ALL fields from this Sudanese Passport image with high accuracy.

1. Extract name in both Arabic and English if available:
   - name_en: full English name as printed
   - name_ar: full Arabic name as printed
   - Split name_en and name_ar into first, middle, last name components
   - If name_ar is present but has a different word count than name_en, translate name_en into Arabic and use it for name_ar and Arabic name components.

2. Parse and extract:
   - place_of_birth
   - place_of_issue
   - gender: either MALE or FEMALE
   - dob, issue_date, expiry_date → all in DD/MM/YYYY format
   - passport_number: must start with one uppercase letter followed by 8 digits
   - Extract the `national_number` (e.g., 119-0817-4259).
   - nationality: use 3-letter ISO format (e.g., SDN)

3. If only two locations are visible (e.g., 'OMDURMAN' and 'PORT SUDAN'), assign the first to place_of_birth and second to place_of_issue.

4. Ensure that the fields `mrz1` and `mrz2` strictly follow the below format for passports:

    - Both `mrz1` and `mrz2` must be exactly 44 characters long.
    - Use the `<` symbol for padding, **not spaces or any other characters**.
    - There should be **no commas, no spaces**, and only uppercase English alphabets, digits, and `<` characters are allowed.
    - If the line is shorter than 44 characters, pad it **only with `<` symbols at the end**, **except**:
        - In `mrz2`, the final character is a **check digit** (usually numeric) and must remain the last character. Padding with `<` should be applied **before** this digit.
    - Do not introduce extra characters to make the string 44 characters. Do not insert `<` between letters or numbers — only at the end (or just before the check digit in `mrz2`).
    - Do not append any punctuation like commas, periods, or symbols.
    - date of birth and expiry dates in MRZ must be in the format DD/MM/YYYY without any separators.
    - passport number in MRZ must be exactly 9 characters (1 letter + 8 digits), padded with `<` if necessary.
    - gender_mrz: extract gender from MRZ line 2 if M return `MALE`, if F return `FEMALE`
    Return the lines exactly as shown, with **no trailing whitespace** or formatting.


   
5. Do not guess or invent any value. If a field is unclear or missing, return empty string.

6. Output MUST be a structured JSON following the defined schema.
"""

class SudaneseIDCardFront(BaseModel):
    id_number: str = Field(
        ...,
        description="The national ID number (exactly as shown, 11 digits)",
        min_length=11,
        max_length=11,
    )

    first_name: str = Field(..., description = "First name from the full name, Transliterate to English")
    middle_name: str = Field(..., description = "Middle name(s) Transliterate to English, if any")
    last_name: str = Field(..., description = "Last name from the full name, Transliterate to English")

    first_name_ar: str = Field(None, description = "Arabic first name")
    middle_name_ar: str = Field(None, description = "Arabic middle name(s),  if any")
    last_name_ar: str = Field(None, description = "Arabic last name")

    
    occupation_ar: str = Field(
        ...,
        description="The occupation in Arabic (extract exactly as written on the card)",
    )
    occupation_en: str = Field(
        ...,
        description="TRANSLATE the Arabic occupation to English (e.g., طالب → Student, عامل → Worker, موظف → Employee)",
    )
    place_of_birth: str = Field(
        ...,
        description="The place of birth in Arabic (extract exactly as written on the card)",
    )
    place_of_birth_en: str = Field(
        ...,
        description="TRANSLITERATE the Arabic place name to English (e.g., كسلا → Kassala, ام درمان → Omdurman, الجزيرة → Al Jazirah)",
    )
    dob: str = Field(
        ...,
        description="The date of birth exactly as shown on the card (preserve original format)",
    )
    name_ar: str = Field(
        ...,
        description="The full name in Arabic (extract exactly as written on the card)",
        min_length=3,
    )
    name: str = Field(
        ...,
        description="TRANSLITERATE the Arabic name to English (e.g., عمر → Omar, محمد → Mohamed, عبدالله → Abdullah). Preserve the full name structure.",
    )

    header_verified: bool = Field(
        ...,
        description="Whether the standard header text ('SDN', 'Republic of the Sudan') is present in the image.",
    )

class SudaneseIDCardBack(BaseModel):
    
    full_name_generic: str = Field(
        ..., description="Full name exactly as printed on the back (prefer NAME field over MRZ)."
    )
    first_name: str = Field(..., description="First name parsed from full name")
    middle_name: Optional[str] = Field(None, description="Middle name(s), if present")
    last_name: str = Field(..., description="Last name parsed from full name")

    dob_back: str = Field(..., description="Date of birth in DD/MM/YYYY format")
    issue_date: str = Field(..., description="Issue date in DD/MM/YYYY format")
    expiry_date: str = Field(..., description="Expiry date in DD/MM/YYYY format")

    nationality: str = Field(..., description="3-letter nationality code (e.g., SDN)")
    gender: str = Field(..., description="Gender as either MALE or FEMALE")
    
    gender_mrz: str = Field(
        ..., description="Gender as extracted from MRZ (M or F) if M return MALE else if F return FEMALE"
    )
    date_of_birth_mrz: str = Field(
        ..., description="Date of birth as extracted from MRZ (in DD/MM/YYYY format)"
    )
    
    expiry_date_mrz: str = Field(
        ..., description="Expiry date as extracted from MRZ (in DD/MM/YYYY format)"
    )
    idsdn_verified: bool = Field(
        ..., description="True if the first MRZ line starts with 'IDSDN'"
    )
    mrz1: str = Field(..., min_length=30, max_length=30,
        description="First line of the MRZ, exactly 30 characters, padded with '<' at the end if shorter"
    )
    mrz2: str = Field(..., min_length=30, max_length=30,
        description="Second line of the MRZ, exactly 30 characters. Padding with '<' must be inserted before the final check digit."
    )
    mrz3: str = Field(..., min_length=30, max_length=30,
        description="Third line of the MRZ, exactly 30 characters, padded with '<' at the end if shorter"
    )
    


 
class SudanesePassport(BaseModel):
    name_ar: str = Field(
        ...,
        description=(
            "The full name in Arabic exactly as printed on the document. "
            "If name_ar is found but does not have the same number of words as name_en, "
            "translate name_en to Arabic and overwrite name_ar with the aligned translation."
        )
    )
    name_en: str = Field(
        ..., description="The full English name exactly as printed on the document"
    )
    place_of_birth: str = Field(
        ..., description="Place of birth in English as printed"
    )
    place_of_issue: str = Field(
        ..., description="Place of passport issuance in English"
    )
    gender: str = Field(
        ..., description="Gender: MALE or FEMALE"
    )
    mrz1: str = Field(..., min_length=44, max_length=44,
        description="First line of the MRZ, exactly 44 characters, padded with '<' at the end if shorter"
    )
    mrz2: str = Field(..., min_length=44, max_length=44,
        description="Second line of the MRZ, exactly 44 characters. Padding with '<' must be inserted before the final check digit."
    )
    passport_number: str = Field(
        ..., pattern=r"^[A-Z][0-9]{8}$", description="Passport number: one uppercase letter followed by 8 digits"
    )
    national_number: str = Field(
        ..., pattern=r"^\d{3}-\d{4}-\d{4}$", description="The 11-digit national number, often in the format XXX-XXXX-XXXX. Return null if not present."
    )
    dob: str = Field(
        ..., description="Date of birth in DD/MM/YYYY format"
    )
    issue_date: str = Field(
        ..., description="Issue date in DD/MM/YYYY format"
    )
    expiry_date: str = Field(
        ..., description="Expiry date in DD/MM/YYYY format"
    )
    nationality: str = Field(
        ..., description="Nationality in ISO 3166-1 alpha-3 format (e.g., SDN)"
    )
    first_name: str = Field(
        ..., description="First name from the English full name (first word)"
    )
    middle_name: Optional[str] = Field(
        None, description="Middle name(s) from English name (all words between first and last)"
    )
    last_name: str = Field(
        ..., description="Last name from English name (last word)"
    )
    first_name_ar: str = Field(..., description="Arabic first name (aligned with English first name)")
    middle_name_ar: str = Field(..., description="Arabic middle name(s)")
    last_name_ar: str = Field(..., description="Arabic last name (aligned with English last name)")

    header_verified: bool = Field(
        ..., description="True if document header ('SDN', 'Republic of the Sudan') is detected"
    )
    dob_mrz: str = Field(
        ..., description="Date of birth as extracted from MRZ (in DD/MM/YYYY format)"
    )
    passport_number_mrz: str = Field(
        ..., description="Passport number as extracted from MRZ"
    )
    expiry_date_mrz: str = Field(
        ..., description="Expiry date as extracted from MRZ (in DD/MM/YYYY format)"
    )
    gender_mrz: str = Field(
        ..., description="Gender as extracted from MRZ (M or F) if M return MALE else if F return FEMALE"
    )
  

def get_openai_response(prompt: str, model_type, image: BytesIO, genai_key):
    b64_image = base64.b64encode(image.getvalue()).decode("utf-8")
    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {
                        "role": "system",
                        "content": "You are an expert at extracting information from identity documents.",
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "input_text", "text": prompt},
                            {
                                "type": "input_image",
                                "image_url": f"data:image/jpeg;base64,{b64_image}",
                                "detail": "low",
                            },
                        ],
                    },
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None


def _image_to_jpeg_bytesio(image) -> BytesIO:
    """
    Accepts: numpy.ndarray (OpenCV BGR), PIL.Image.Image, bytes/bytearray, or io.BytesIO
    Returns: io.BytesIO containing JPEG bytes (ready for get_openai_response)
    """
    import numpy as np

    if isinstance(image, BytesIO):
        image.seek(0)
        return image

    if isinstance(image, (bytes, bytearray)):
        return BytesIO(image)

    try:
        from PIL.Image import Image as _PILImage

        if isinstance(image, _PILImage):
            buf = BytesIO()
            image.convert("RGB").save(buf, format="JPEG", quality=95)
            buf.seek(0)
            return buf
    except Exception:
        pass

    if isinstance(image, np.ndarray):
        success, enc = cv2.imencode(".jpg", image)
        if not success:
            raise ValueError("cv2.imencode failed")
        return BytesIO(enc.tobytes())

    raise TypeError(
        "Unsupported image type. Provide numpy.ndarray, PIL.Image.Image, bytes, or io.BytesIO."
    )

def process_image(side):
    if side == "front":
        prompt = PROMPT_FRONT
        model = SudaneseIDCardFront

    elif side == "back":
        prompt = PROMPT_BACK
        model = SudaneseIDCardBack

    elif side == "passport":
        prompt = PROMPT_PASSPORT
        model = SudanesePassport
    else:
        raise ValueError("Invalid document side specified. Use 'front', 'back', or 'passport'.")

    return model, prompt

def get_response_from_openai_sdn(image, side, openai_key):
    logging.info("Processing image for Sudanese id extraction OPENAI......")
    logging.info(f" and type: {type(image)}")
    try:
        image = _image_to_jpeg_bytesio(image)
    except Exception as e:
        logging.error(f"Error encoding image: {e}")
        return {"error": "Image encoding failed"}
    try:
        model, prompt = process_image(side)
        logging.info(f"Using model: {model.__name__} and prompt {prompt[:100]}")
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}

    try:
        response = get_openai_response(prompt, model, image, openai_key)
    except Exception as e:
        logging.error(f"Error during OpenAI request: {e}")
        return {"error": "OpenAI request failed"}

    response_data = vars(response)
    logging.info(f"Openai response: {response}")
    return response_data






