import base64
import json
import logging
import time


from openai import OpenAI
from pydantic import BaseModel, Field



PROMPT_PASSPORT_IRQ = """
You are given an image of an Iraqi passport. Your task is to read the passport and return ONLY a valid JSON object matching the IraqiPassport schema.

Follow all rules exactly. Do NOT guess or invent any value.

================================================
1. LANGUAGE RULES
================================================

- Read all visible text in English, Arabic, and Kurdish.
- Prefer English if it exists.
- If the **field label is in English but the VALUE is in Arabic/Kurdish**, 
  → transliterate the VALUE into English letters.
- If a field appears ONLY in Arabic/Kurdish:
  → transliterate it to English letters (romanization).
- Do NOT translate or change meaning.
- If any value is unreadable or missing → return "".

================================================
2. FIELDS TO EXTRACT (IraqiPassport schema)
================================================

You must fill ALL fields:

1) Names:
   - `full_name`: English full name exactly as printed.
   - `last_name`: English surname exactly as printed.
   - `mother_name`: Mother's name in English.
   - If any of these appear only in Arabic/Kurdish → transliterate the value.

2) Place of Birth:
   - `place_of_birth`:
       - If English value exists → return it exactly.
       - If value is shown in Arabic/Kurdish (even beside English label) 
         → transliterate only the VALUE into English letters.

3) Issuing Authority:
   - `Issuing_authority`:
       - If English value exists → return exactly.
       - If the value under the English label is Arabic/Kurdish 
         → transliterate only the VALUE into English letters.

4) Issuing Country:
   - `issuing_country`: Use English country name or code (e.g. IRQ).
   - If only Arabic/Kurdish appears → transliterate and map correctly.

5) Gender:
   - `gender_letter`: “M” or “F” only.

6) Dates:
   - `dob`, `issue_date`, `expiry_date`:
       - Convert to DD/MM/YYYY format.
       - If unclear → return empty string.

7) Passport Number:
   - `id_number`: Must be 1 uppercase letter + 8 digits.
   - If not clearly readable → return "".

8) Nationality:
   - `nationality`: Use 3-letter ISO format (e.g., IRQ).
   - If only Arabic/Kurdish appears (e.g. “عراقي”) → transliterate then map.

9) Fallback rule:
   - If ONLY two locations appear (in Arabic/Kurdish) without labels:
       - 1st → place_of_birth
       - 2nd → issuing_authority

10) Header:
  -  Return True if document is a valid Iraqi Passport" 
            "It should contain Arabic/Kurdish text like: جمهورية العراق, کۆماری عێراق and English Text: Republic of Iraq"
            "Return False otherwise.
================================================
3. MRZ RULES
================================================

- `mrz1` and `mrz2` must be EXACTLY 44 characters.
- Allowed: A–Z, 0–9, `<`.
- No spaces or punctuation.
- If a line is shorter → pad with `<` at the END.
- In `mrz2`: final char is check digit; pad BEFORE it.
- Do not add, remove, or modify characters except padding.
- date of birth and expiry dates in MRZ must be in the format DD/MM/YYYY without any separators.
- passport number in MRZ must be exactly 9 characters (1 letter + 8 digits), padded with `<` if necessary.
- gender_mrz: extract gender from MRZ line 2 if M return `MALE`, if F return `FEMALE`
- expiry_date_mrz: extract expiry date from MRZ line 2 in DD/MM/YYYY format
================================================
4. NO GUESSING & FINAL OUTPUT
================================================

- If any field is missing or unreadable → return an empty string.
- Do NOT infer values.
- Output ONLY a single JSON object matching the IraqiPassport schema.

 
"""
class IraqiPassport(BaseModel):
    # ocr_text: str = Field(..., description="Full OCR extracted text from the Iraqi Passport image.")    
    full_name: str = Field(..., description="The Full Name, in English, exactly as printed on the document")
    last_name: str = Field(..., description="Surname of the person on the passport")
    place_of_birth: str = Field(..., description=("If Place of Birth is in English, return exactly as printed."
                                                  "If not present in English, look at the right-hand side of the passport, where it says 'Place of Birth'."
                                                  "Transliterate to English if value of Place of Birth is only in Arabic"))

    issuing_authority: str = Field(..., description=("Place of passport issuing authority in English"
                                                     "Transliterate to English if issuing authority is only in Arabic"))
    issuing_country: str = Field(..., description="Issuing Country/Country Code (e.g. 'IRQ', 'JOR')", example='IRQ')
    mother_name: str = Field(..., description="Mother's full name in English, exactly as printed.")
    gender_letter: str = Field(..., description="Sex: M or F")
    mrz1: str = Field(..., min_length=44, max_length=44,
                      description="First line of the MRZ, exactly 44 characters, padded with '<' at the end if shorter")
    mrz2: str = Field(..., min_length=44, max_length=44,
                      description="Second line of the MRZ, exactly 44 characters. Padding with '<' must be inserted before the final check digit.")
    id_number: str = Field(..., pattern=r"^[A-Z][0-9]{8}$",
                           description="Passport number: one uppercase letter followed by 8 digits")

    dob: str = Field(
        ..., description="Date of birth in DD/MM/YYYY format"
    )
    issue_date: str = Field(
        ..., description="Issue date in DD/MM/YYYY format"
    )
    expiry_date: str = Field(
        ..., description="Expiry date in DD/MM/YYYY format"
    )
    nationality: str = Field(
        ..., description="Nationality in ISO 3166-1 alpha-3 format (e.g., SDN)"
    )

    header_verified: bool = Field(
        ..., description="Return True if document is a valid Iraqi Passport" 
            "It should contain Arabic/Kurdish text like: جمهورية العراق, کۆماری عێراق and English Text: Republic of Iraq"
            "Return False otherwise."
    )
    dob_mrz: str = Field(
        ..., description="Date of birth as extracted from MRZ (in DD/MM/YYYY format)"
    )
    id_number_mrz: str = Field(
        ..., min_length=9, max_length=9, description="ID number as extracted from MRZ"
    )
    expiry_date_mrz: str = Field(
        ..., description="Expiry date as extracted from MRZ (in DD/MM/YYYY format)"
    )
    gender_mrz: str = Field(
        ..., description="Gender as extracted from MRZ (M or F) if M return MALE else if F return FEMALE"
    )

PROMPT_FRONT_IRQ = """
You will receive an image of the **front side** of an Iraqi National ID Card.
Follow ALL steps strictly. Do NOT skip, modify, assume, or guess any information.

1.OCR (MANDATORY)
Perform full OCR on the entire image.
Extract ALL visible Arabic, Kurdish, numbers, and symbols EXACTLY as printed.
Keep line breaks, spacing, spelling, diacritics, and punctuation.
Do NOT correct, normalize, or reorder text.
Return the full OCR text in: raw_ocr_text.

2.PERSONAL DETAILS EXTRACTION AND ALL THE INFORMATION REQUESTED IS PRESENT ON THE FRONT SIDE OF THE ID CARD.
From the OCR text, extract the following fields EXACTLY as printed:
Extract these fields EXACTLY as printed. 
The ID card contains only Arabic/Kurdish text, so the *_en fields must be generated by transliterating the Arabic/Kurdish name into its English form.
This transliteration is REQUIRED and is NOT considered guessing.
Only leave *_en fields empty if the Arabic field itself is empty.
Do NOT translate or change meaning.

- first_name: Arabic first name
- first_name_en: transliterate the first name into English 
- father_name: Arabic father name
- father_name_en: transliterate the father name into English            
- third_name: Arabic paternal grandfather name
- third_name_en: transliterate the paternal grandfather name into English
- last_name: Arabic family/tribal name (empty string if missing)
- last_name_en: transliterate the family/tribal name into English (empty string if missing)
- mother_first_name: Arabic mother first name
- mother_first_name_en: transliterate the mother first name into English
- mother_last_name: Arabic maternal grandfather/mother’s last name
- mother_last_name_en: transliterate the maternal grandfather/mother’s last name into English

3.Gender:
You MUST read gender ONLY from the Arabic field labeled "الجنس" or "جنس".
Do NOT infer gender from the name or photo.

- gender_ar: ذكر o
r أنثى
- gender: Male or Female

4.DOCUMENT DETAILS EXTRACTION
Extract all document identifiers exactly as printed:
- id_number: 12-digit National ID Number
- card_number: 9-character card/document number
- serial_number: 6-character serial is present vertically (empty if missing)
- blood_type: e.g., O+, A-, AB+ (empty if missing)

5.HEADER VERIFICATION
 Check if the header is present:
   - Must contain at least one of the following Arabic/Kurdish issuing authority texts:
       "جمهورية العراق"
       "وزارة الداخلية"
       "مديرية الأحوال المدنية والجوازات والاقامة"
       "کوماری عیراق"
       "وه زاره تی ناوخو"
       "پریود به را بائی باری شارستانی و پاسپورت و نیشنگه"
   - Set `header_verified = true` only if at least one appears clearly.
   - Otherwise set `header_verified = false`.

6.VALIDATION RULES

- Do NOT guess, assume, or hallucinate.
- If a field is missing, unclear, faint, or unreadable → return empty string.
- Output MUST match the schema exactly.


7.OUTPUT FORMAT

Return ONLY structured JSON.  
No explanations. No commentary.
"""



PROMPT_BACK_IRQ = """
You will be provided with an image showing the **front side of an Iraqi National ID Card**.
Follow every instruction with absolute precision. Do NOT infer, assume, or guess any information.

Extract EVERY visible Arabic, Kurdish, English, number, and symbol EXACTLY as printed.
You MUST capture even faint, blurred, low-contrast, small, or partially visible text.

O1.oCR Requirements:
- Preserve original line breaks and spacing
- Preserve punctuation, diacritics, and character shapes
- Preserve text even if rotated, tilted, or near the edges
- Do NOT correct spelling or normalize text
- Do NOT merge or reorder lines
- Do NOT skip faint or partial text

Return the full raw OCR output exactly as extracted in: raw_ocr_text.

2. MRZ (Machine Readable Zone)
- mrz1: first MRZ line (exactly as printed, 30 characters, keep '<', remove spaces around it)
- mrz2: second MRZ line (same rule, 30 characters)
- mrz3: third MRZ line (same rule, 30 characters)
If any MRZ line is missing, set it to "".

3.HEADER VERIFICATION
- header_verified:  true if "IDIRQ" appears anywhere in mrz1, otherwise false.

4. DATE FIELDS (DD/MM/YYYY)
From raw_ocr_text, extract:
- dob: date of birth
- issue_date
- expiry_date
Dates must be in DD/MM/YYYY format.
If a date is missing or unclear, return "" for that field.

5.ISSUING AUTHORITY
- issuing_authority_ar: Arabic text of the issuing authority exactly as printed
  (often like "مديرية الأحوال المدنية - [City]")
- issuing_authority_en: English translation of the issuing authority

6. PLACE OF BIRTH

- place_of_birth: Arabic text
- place_of_birth_en: translation

7. NAMES FROM MRZ LINE 3
From mrz3 (if present):
- last_name_back: the text before '<<'
- first_name_back: the text after '<<'
If mrz3 is empty, both fields must be "".

8.FAMILY NUMBER
- family_number: 18-character alphanumeric value if present in raw_ocr_text, else "".
-family number_en: same as family_number.   

9. NATIONALITY
- nationality: 3-letter code (e.g., "IRQ") if present, else "".
10.GENDER FROM MRZ LINE 2
- gender_mrz: 'M' or 'F' extracted from mrz2. If mrz2 is missing, return "".
11.dob_mrz: date of birth from mrz2 in DD/MM/YYYY format.first six characters from second line mrz. If mrz2 is missing, return "".    
12.expiry_date_mrz: expiry date from mrz2 in DD/MM/YYYY format. If mrz2 is missing, return "".
13.card_number_mrz: document number from mrz1. If mrz1 is missing, return "".

RULES:
- Never guess or infer. If something is not clearly present in raw_ocr_text, return "".
- Return ONLY a JSON object matching the schema exactly.

"""
class Iraq_National_ID_front(BaseModel):
    """Extract the fields from the OCR extracted text of an Iraqi National ID's front side. Front Side has names, (like father name, mother name etc.), national id numbers but has no dates.
      Translate wherever required."""
    ocr_text: str = Field(..., description="Full OCR extracted text from the Iraqi National ID front side image.")  
    first_name: str = Field(..., description="First name (الاسم / ناو) in Arabic.")
    first_name_en: str = Field(..., description="First name (الاسم / ناو), transliterated to English.")
    father_name: str = Field(..., description="Father's name (الأب / باوك) in Arabic.")
    father_name_en: str = Field(..., description="Father's name (الأب / باوك), transliterated to English.")
    third_name: str = Field(..., description="Paternal grandfather's name (الجد / بابير) in Arabic.")
    third_name_en: str = Field(..., description="Paternal grandfather's name (الجد / بابير), transliterated to English.")
    last_name: str = Field(
        "",
        description=(
            "Family/tribal name (اللقب / نازناو) in Arabic. "
            "OCR extracts various versions of 'نازناو' like الزناو, الزنار; do not interpret them as the family name."
        )
    )
    last_name_en: str = Field(
        "",
        description=(
            "Family/tribal name (اللقب / نازناو), transliterated to English. "
            "OCR extracts various versions of 'نازناو' like الزناو, الزنار; do not interpret them as the family name."
        )
    )
    mother_first_name: str = Field(..., description="Mother's name (الام/ دابك) in Arabic.")
    mother_first_name_en: str = Field(..., description="Mother's name (الام/ دابك), transliterated to English.")
    mother_last_name: str = Field(..., description="Maternal grandfather's name (الجد / بابير) in Arabic.")
    mother_last_name_en: str = Field(..., description="Maternal grandfather's name (الجد / بابير), transliterated to English.")
    gender_ar: str = Field(..., description="Gender (الجنس / ردگار): ذكر (Male) or أنثى (Female).")
    gender: str = Field(..., description="Gender (الجنس / ردگار), translated to English male or female ")
    id_number: str = Field(...,min_length=12, max_length=12, description="12-digit national ID number.Must be exactly 12 digits.")
    card_number: str = Field(...,min_length=9, max_length=9, description="9-character alphanumeric document number.Must be exactly 9 characters.")
    serial_number: str = Field("", min_length = 6, max_length=6, description="6-digit card serial number present vertical, its the last thing present in ocr text extracted.")
    blood_type: str = Field(None, description="Blood type (e.g., O+, A-).")
    header_verified: bool = Field(..., description="whether document is a valid Iraqi National ID's front side."
                                                   "It should strictly contain at least one of the following Arabic/Kurdish texts:"
                                                   " جمهورية العراق / وزارة الداخلية"
                                                   "مديرية الأحوال المدنية والجوازات والاقامة"
                                                   "کوماری عیراق / وه زاره تی ناوخو"
                                                   "پریود به را بائی باری شارستانی و پاسپورت و نیشنگه"
                                                   "جمهورية العراق / وزارة الداخلية"
                                                   "کوماری عیراق / وه زاره تی ناوخو")

    
class Iraq_National_ID_back(BaseModel):
    """Extract only the Arabic fields from the OCR text of an Iraqi National ID's back side. A back side has fields like dates: issue, expiry, birth. Translate where required."""
    ocr_text: str = Field(..., description="Full OCR extracted text from the Iraqi National ID back side image.")   
    issuing_authority: str = Field(..., description="Issuing authority (جهة الاصدار / لايانى ددرجوون) in Arabic")
    issuing_authority_en: str = Field(..., description="Issuing authority (جهة الاصدار / لايانى ددرجوون), translated to English")
    issue_date: str = Field(..., description="Date of issue")
    expiry_date: str = Field(..., description="Date of expiry")
    place_of_birth: str = Field(..., description="Place of birth in Arabic.")
    place_of_birth_en: str = Field(..., description="Place of birth, translated to English.")
    dob: str = Field(..., description="Date of birth")
    family_number: str = Field(..., min_length=18, max_length=18, description='18-character alphanumeric Family number (الرقم العائلي / ژمارەى خێزانی)')
    family_number_en: str = Field(..., min_length=18, max_length=18, description='18-character alphanumeric Family number same as family number (الرقم العائلي / ژمارەى خێزانی)')
    mrz1: str = Field(...,description="MRZ Line 1: Includes document type (ID), issuing country code (IRQ), document number, and check digits. Example: 'IDIRQAL36266736200026108063<<<'")
    mrz2: str = Field(...,description="MRZ Line 2: Encodes date of birth (YYMMDD), gender (M/F), expiry date (YYMMDD), and nationality code (IRQ) and check digit at the end of '<<<<<<'. Example: '0007191M2811280IRQ<<<<<<<<<<<7'")
    mrz3: str = Field(...,description="MRZ Line 3: Contains surname and given name(s), separated by '<<'. Given names may include multiple parts separated by '<'. If no surname is present, it starts with '<<'. Example: 'AHMED<<ALI<HASSAN' or '<<ALI'")
    gender_mrz: str = Field(...,description="Gender extracted from MRZ line 2: 'M' for Male, 'F' for female.")  
    expiry_date_mrz: str = Field(...,description="Expiry date extracted from MRZ line 2 in DD/MM/YYYY format.")
    dob_mrz: str = Field(...,description="Date of birth as extracted from MRZ (in DD/MM/YYYY format) first six characters of mrz2")
    last_name_back: str = Field(...,description="Surname extracted from MRZ line 3, before the '<<' separator.")
    first_name_back: str = Field(...,description="Given name extracted from MRZ line 3, after the '<<' seperator.")
    header_verified: bool = Field(..., description="if header contains in mrz1 'IDIRQ' then true else false")
    card_number_mrz: str = Field(..., min_length = 9, max_length=9, description="Document number as extracted from MRZ line 1")




def process_image_irq(side):
    if side == "front":
        prompt = PROMPT_FRONT_IRQ
        model = Iraq_National_ID_front

    elif side == "back":
        prompt = PROMPT_BACK_IRQ
        model = Iraq_National_ID_back

    elif side == "page1":
        prompt = PROMPT_PASSPORT_IRQ
        model = IraqiPassport
    else:
        raise ValueError("Invalid document side specified. Use 'front', 'back', or 'passport'.")

    return model, prompt



def get_openai_response_irq(prompt: str, model_type, image: str, genai_key):
    # covert byte io to utf-8 string
    
    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {
                        "role": "system",
                        "content": "You are an expert at extracting information from identity documents.",
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "input_text", "text": prompt},
                            {
                                "type": "input_image",
                                "image_url": f"data:image/jpeg;base64,{image}",
                                "detail": "high",
                            },
                        ],
                    },
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None



def get_response_from_openai_irq(image, side, openai_key):
    logging.info(f"Processing Iraqi document side: {side}")
    image_bytes = base64.b64encode(image).decode('utf-8') 
    try:
        model, prompt = process_image_irq(side)
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}       
    logging.info(f"Using prompt for side and prompt {side} selected.{prompt[:50]}...")
    try:
        start_time = time.time()
        response = get_openai_response_irq(prompt, model,image_bytes, openai_key)
        elapsed_time = time.time() - start_time
        logging.info(f"OpenAI extraction took {elapsed_time:.2f} seconds")
    except Exception as e:
        logging.error(f"Error during OCR extraction: {e}")
        return {"error": "OCR extraction failed."}  
    response_data = response.dict() if response else {}
    
    logging.info(f"Openai response: {json.dumps(response_data, ensure_ascii=False, indent=2)}")
    return response_data        

