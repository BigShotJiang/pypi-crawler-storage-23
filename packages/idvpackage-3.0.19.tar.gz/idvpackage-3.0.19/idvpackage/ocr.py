import base64
import io
import json
import logging
import os
import tempfile
import time
from datetime import datetime, timedelta
from io import BytesIO

import cv2
import face_recognition
import numpy as np
import pycountry
from google.cloud import vision_v1
from google.oauth2.service_account import Credentials
from PIL import Image, ImageEnhance

from idvpackage.constants import BLUR_THRESHOLD, BRIGHTNESS_THRESHOLD


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    force=True,
)

google_client_dict = {}


class IdentityVerification:
    def __init__(self, credentials_string,  api_key=None, genai_key=None):
        """
        This is the initialization function of a class that imports a spoof model and loads an OCR
        reader.
        """
        try:
            st = time.time()
            credentials_dict = json.loads(credentials_string)
            credentials = Credentials.from_service_account_info(credentials_dict)
            self.client = google_client_dict.get(credentials)

            if not self.client:
                self.client = vision_v1.ImageAnnotatorClient(credentials=credentials)
                google_client_dict[credentials] = self.client

            self.openai_key = genai_key

            self.iso_nationalities = [country.alpha_3 for country in pycountry.countries]
            logging.info(f"\nInitialization time inside IDV Package: {time.time() - st}")
        
        except Exception as e:
            logging.error(f"Error during initialization: {e}")

    def image_conversion(self, image):
        """
        This function decodes a base64 string data and returns an image object.
        If the image is in RGBA mode, it is converted to RGB mode.
        :return: an Image object that has been created from a base64 encoded string.
        """
        # Decode base64 String Data
        # img = Image.open(io.BytesIO(base64.decodebytes(bytes(image, "utf-8"))))

        img_data = io.BytesIO(base64.decodebytes(bytes(image, "utf-8")))
        with Image.open(img_data) as img:
            if img.mode == "RGBA":
                # Create a blank background image
                background = Image.new("RGB", img.size, (255, 255, 255))
                # Paste the image on the background.
                background.paste(img, mask=img.split()[3])  # 3 is the alpha channel
                img = background
            else:
                img = img.copy()
            return img

   
        """
        Convert an RGB image to YUV format.
        """
        try:
            img = np.array(img)
            return cv2.cvtColor(img, cv2.COLOR_RGB2YUV)
        except Exception as e:
            raise Exception(f"Error: {e}")

    def is_blurry(self, image):
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        laplacian_variance = cv2.Laplacian(gray_image, cv2.CV_64F).var()
        return laplacian_variance
    
    def sharpen_image(self, image):
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
        return cv2.filter2D(image, -1, kernel)

    def adjust_contrast(self, image, factor):
        pil_image = Image.fromarray(image)
        enhancer = ImageEnhance.Contrast(pil_image)
        enhanced_image = enhancer.enhance(factor)
        return np.array(enhanced_image)

    def adjust_brightness(self, image, factor):
        pil_image = Image.fromarray(image)
        enhancer = ImageEnhance.Brightness(pil_image)
        enhanced_image = enhancer.enhance(factor)
        return np.array(enhanced_image)

    def check_document_quality(self, data):
        
        video_quality = {"error": ""}
        temp_video_file = tempfile.NamedTemporaryFile(delete=False)
        temp_video_file_path = temp_video_file.name

        try:
            # Write video bytes to the temporary file and flush
            temp_video_file.write(data)
            temp_video_file.flush()
            temp_video_file.close()  # Close the file to ensure it can be accessed by other processes

            video_capture = cv2.VideoCapture(temp_video_file.name)

            if video_capture.isOpened():
                video_capture.set(cv2.CAP_PROP_POS_FRAMES, 0)

            selfie_result = self.extract_selfie_from_video(video_capture)
            if isinstance(selfie_result, dict):
                video_quality["error"] = selfie_result["error"]

            else:
                (
                    selfie_blurry_result,
                    selfie_bright_result,
                ) = self.get_blurred_and_glared_for_doc(selfie_result)
                if (
                        selfie_blurry_result == "consider"
                        or selfie_bright_result == "consider"
                ):
                    video_quality["error"] = "face_not_clear_in_video"
                else:
                    video_quality["selfie"] = selfie_result
                    video_quality["shape"] = selfie_result.shape

            return video_quality
    
        except Exception as e:
            logging.exception("check_document_quality failed")
            video_quality["error"] = "face_not_clear_in_video"
            return video_quality
        
        finally:
            if video_capture is not None:
                try:
                    video_capture.release()
                except Exception:
                    pass
                del video_capture
            # Remove temp file
            if temp_video_file_path and os.path.exists(temp_video_file_path):
                try:
                    os.remove(temp_video_file_path)
                except Exception:
                    logging.warning("Failed to delete temp file %s", temp_video_file_path)

            # Force cleanup of OpenCV / numpy memory
            import gc
            gc.collect()

    def extract_selfie_from_video(self, video_capture):
        """Extract the best quality selfie from video with speed optimizations for frontal faces."""
        video_dict = {'error': ''}
        try:
            # Get rotation metadata from video
            try:
                rotation = int(video_capture.get(cv2.CAP_PROP_ORIENTATION_META))
            except Exception as e:
                logging.info(f"Defaulting to Rotation=0, Exception Thrown while getting rotation metadata from video.{e}")
                rotation=0
            logging.info(f"Video rotation metadata: {rotation}°")


            
            total_frames = int(video_capture.get(cv2.CAP_PROP_FRAME_COUNT))
            if total_frames <= 0:
                video_dict['error'] = 'invalid_video_frame_count'
                return video_dict

            # Check only 6 frames - 2 at start, 2 in the middle, 2 at the end
            frame_positions = [
                int(total_frames * 0.05),
                int(total_frames * 0.15),
                int(total_frames * 0.45),
                int(total_frames * 0.55),
                int(total_frames * 0.85),
                int(total_frames * 0.95)
            ]

            best_face = None
            best_score = -1
            best_frame = None

            logging.info(f"Analyzing video with {total_frames} frames")
            logging.info(f"Checking {len(frame_positions)} strategic frames")
            logging.info(f"Frame positions to analyze: {frame_positions}")

            for target_frame in frame_positions:
                if target_frame >= total_frames:
                    target_frame = total_frames - 1
                if target_frame < 0:
                    target_frame = 0

                logging.info(f"Processing frame {target_frame}")
                video_capture.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
                ret, frame = video_capture.read()
                if not ret or frame is None or frame.size == 0:
                    continue

                # Apply rotation correction based on video metadata
                if rotation == 90:
                    frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
                elif rotation == 180:
                    frame = cv2.rotate(frame, cv2.ROTATE_180)
                elif rotation == 270:
                    frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)

                try:
                    scale = 0.7
                    small_frame = cv2.resize(frame, (0, 0), fx=scale, fy=scale)

                    encode_params = [cv2.IMWRITE_JPEG_QUALITY, 90]
                    _, buffer = cv2.imencode(".jpg", small_frame, encode_params)

                    image_bytes = buffer.tobytes()
                    del buffer

                    image = vision_v1.Image(content=image_bytes)
                    response = self.client.face_detection(image=image, max_results=2)
                    del image_bytes

                    faces = response.face_annotations

                    if not faces:
                        continue

                    frame_best_face = None
                    frame_best_score = -1

                    for face in faces:
                        vertices = [(int(vertex.x / scale), int(vertex.y / scale))
                                  for vertex in face.bounding_poly.vertices]

                        left = min(v[0] for v in vertices)
                        upper = min(v[1] for v in vertices)
                        right = max(v[0] for v in vertices)
                        lower = max(v[1] for v in vertices)

                        # Validate face coordinates
                        if not (0 <= left < right <= frame.shape[1] and 0 <= upper < lower <= frame.shape[0]):
                            continue

                        # Calculate face metrics
                        face_width = right - left
                        face_height = lower - upper
                        face_area = (face_width * face_height) / (frame.shape[0] * frame.shape[1])

                        # Reject small faces
                        if face_area < 0.05:
                            continue

                        # Calculate how centered the face is
                        face_center_x = (left + right) / 2
                        face_center_y = (upper + lower) / 2
                        frame_center_x = frame.shape[1] / 2
                        frame_center_y = frame.shape[0] / 2

                        center_dist_x = abs(face_center_x - frame_center_x) / (frame.shape[1] / 2)
                        center_dist_y = abs(face_center_y - frame_center_y) / (frame.shape[0] / 2)
                        center_score = 1.0 - (center_dist_x + center_dist_y) / 2

                        # For frontal faces, left and right eye/ear should be roughly symmetric
                        if len(face.landmarks) > 0:
                            # Head rotation detection
                            roll, pan, tilt = 0, 0, 0
                            if hasattr(face, 'roll_angle'):
                                roll = abs(face.roll_angle)
                            if hasattr(face, 'pan_angle'):
                                pan = abs(face.pan_angle)
                            if hasattr(face, 'tilt_angle'):
                                tilt = abs(face.tilt_angle)

                            head_angle_penalty = (roll + pan + tilt) / 180.0

                            # Symmetry detection from face bounding box
                            left_half = face_center_x - left
                            right_half = right - face_center_x
                            width_ratio = min(left_half, right_half) / max(left_half, right_half)

                            # Frontal-face score: higher for more frontal faces
                            # Perfect frontal face would be 1.0
                            frontal_score = width_ratio * (1.0 - head_angle_penalty)
                        else:
                            # No landmarks, estimate from bounding box
                            left_half = face_center_x - left
                            right_half = right - face_center_x
                            frontal_score = min(left_half, right_half) / max(left_half, right_half)

                        # Combined score weights different factors
                        # More weight for frontal-ness and face confidence
                        score = (
                            face.detection_confidence * 0.3 +
                            face_area * 0.2 +
                            center_score * 0.2 +
                            frontal_score * 0.3
                        )

                        # Heavy bonus for very frontal faces (nearly symmetric)
                        if frontal_score > 0.8:
                            score *= 1.5

                        # Extra bonus for centered faces
                        if center_score > 0.8:
                            score *= 1.2

                        if score > frame_best_score:
                            # Add margins for the face
                            margin_x = int(face_width * 0.2)
                            margin_y_top = int(face_height * 0.3)
                            margin_y_bottom = int(face_height * 0.1)

                            left_with_margin = max(0, left - margin_x)
                            upper_with_margin = max(0, upper - margin_y_top)
                            right_with_margin = min(frame.shape[1], right + margin_x)
                            lower_with_margin = min(frame.shape[0], lower + margin_y_bottom)

                            # Store the best face info
                            frame_best_score = score
                            frame_best_face = {
                                'face': face,
                                'left': left_with_margin,
                                'upper': upper_with_margin,
                                'right': right_with_margin,
                                'lower': lower_with_margin,
                                'frontal_score': frontal_score,
                                'center_score': center_score,
                                'confidence': face.detection_confidence,
                                'frame': target_frame
                            }

                    if frame_best_face is not None:
                        logging.info(f"Frame {target_frame}: Best face score {frame_best_score:.2f} "
                                     f"(Frontal: {frame_best_face['frontal_score']:.2f}, "
                                     f"Center: {frame_best_face['center_score']:.2f}, "
                                     f"Confidence: {frame_best_face['confidence']:.2f})")

                        if frame_best_score > best_score:
                            logging.info(f"New best face found at frame {target_frame} with score {frame_best_score:.2f}")
                            best_score = frame_best_score
                            best_face = frame_best_face
                            best_frame = frame.copy()

                except Exception as e:
                    logging.info(f"Error processing frame {target_frame}: {e}")
                    continue
                
            if best_face and best_frame is not None:
                try:
                    left = best_face['left']
                    upper = best_face['upper']
                    right = best_face['right']
                    lower = best_face['lower']

                    # Convert to RGB and crop
                    rgb_frame = cv2.cvtColor(best_frame, cv2.COLOR_BGR2RGB)
                    cropped_face = rgb_frame[upper:lower, left:right]

                    # Validate cropped face
                    if cropped_face is None or cropped_face.size == 0:
                        video_dict['error'] = 'invalid_cropped_face'
                        return video_dict

                    logging.info(f"Face shape: {cropped_face.shape}")
                    return cropped_face

                except Exception as e:
                    video_dict['error'] = 'error_processing_detected_face'
                    return video_dict
            else:
                video_dict['error'] = 'no_suitable_face_detected_in_video'
                return video_dict

        except Exception as e:
            logging.info(f"Exception in extract_selfie_from_video: {e}")
            video_dict['error'] = 'video_processing_error'
            return video_dict

    def is_colored(self, base64_image):
        img = self.image_conversion(base64_image)
        img = np.array(img)

        return len(img.shape) == 3 and img.shape[2] >= 3

    def get_blurred_and_glared_for_doc(
        self,
        image,
        brightness_threshold=BRIGHTNESS_THRESHOLD,
        blur_threshold=BLUR_THRESHOLD,
    ):
        blurred = "clear"
        glare = "clear"

        blurry1 = self.is_blurry(image)
        if blurry1 < blur_threshold:
            blurred = "consider"

        brightness1 = np.average(image[..., 0])
        if brightness1 > brightness_threshold:
            glare = "consider"

        return blurred, glare

    
    def check_nationality_in_iso_list(self, nationality):
        try:
            if len(nationality) > 3:
                try:
                    country = pycountry.countries.lookup(nationality)
                    nationality = country.alpha_3
                except:
                    return "consider"
            ## Handling case for OMN as it comes as MN, due to O being considered as 0
            if nationality.upper() == "MN":
                nationality = "OMN"
            if nationality.upper() in self.iso_nationalities:
                return "clear"
            else:
                return "consider"
        except:
            return "consider"

    def calculate_similarity(self, face_encoding1, face_encoding2):
        similarity_score = (
            1 - face_recognition.face_distance([face_encoding1], face_encoding2)[0]
        )
        return round(similarity_score + 0.25, 2)


    def extract_face_and_compute_similarity(
        self, selfie, front_face_locations, front_face_encodings
    ):
        from idvpackage.common import load_and_process_image_deepface

        try:
            if selfie is None:
                logging.info("Error: Selfie image is None")
                return 0

            # Ensure the input array is contiguous and in the correct format
            if not selfie.flags["C_CONTIGUOUS"]:
                selfie = np.ascontiguousarray(selfie)

            # Convert array to uint8 if needed
            if selfie.dtype != np.uint8:
                if selfie.max() > 255:
                    selfie = (selfie / 256).astype(np.uint8)
                else:
                    selfie = selfie.astype(np.uint8)

            face_locations1, face_encodings1 = load_and_process_image_deepface(selfie)
            
            if not face_locations1 or not face_encodings1:
                logging.info("No face detected in Selfie Video by DeepFace")
                return 0
            face_locations2, face_encodings2 = (
                front_face_locations,
                front_face_encodings,
            )
            
            if not face_encodings2.any():
                logging.info("No face detected in front ID")
                return 0

            similarity_score = self.calculate_similarity(face_encodings1[0], face_encodings2[0])
            logging.info(f"Similarity score between selfie and front ID: {similarity_score}")
            return min(1, similarity_score)

        except Exception as e:
            logging.info(f"Error in extract_face_and_compute_similarity: {e}")
            
            return 0


    def check_for_liveness(self, video_bytes):
        st = time.time()
        from idvpackage.liveness_spoofing_v2 import test

        # Create a temporary file that will not be deleted automatically
        temp_video_file = tempfile.NamedTemporaryFile(delete=False)
        temp_video_file_path = temp_video_file.name

        try:
            # Write video bytes to the temporary file and flush
            temp_video_file.write(video_bytes)
            temp_video_file.flush()
            temp_video_file.close()  # Close the file to ensure it can be accessed by other processes

            try:
                result = test(temp_video_file_path)
                if result:
                    return result
            except Exception as e:
                logging.info(f"\nError in Liveness: {e}")
                return None

        finally:
            # Ensure the temporary file is deleted
            if os.path.exists(temp_video_file_path):
                os.remove(temp_video_file_path)
                # logging.info(f"Temporary file {temp_video_file_path} has been deleted.")
            logging.info(
                f"--------------Time taken for Liveness and Spoofing in IDV package: {time.time() - st} seconds\n"
            )

    def get_ocr_results(self, processed_image, country=None, side=None):
        
        logging.info(f"Getting OCR results for country: {country}, side: {side}")

        if country == "QAT" or country == "LBN" or country == "IRQ" or country == "SDN":
            image = vision_v1.types.Image(content=processed_image)

        else:
            compressed_image = BytesIO()
            processed_image.save(
                compressed_image, format="JPEG", quality=60, optimize=True
            )
            compressed_image_data = compressed_image.getvalue()
            image = vision_v1.types.Image(content=compressed_image_data)

        response = self.client.text_detection(image=image)
        id_infos = response.text_annotations

        return id_infos

    def extract_document_info(
        self, image, side, document_type, country, nationality, step_data=None
    ):
        st = time.time()
        document_data = {}
        
        logging.info(f"Starting extraction for document_type: {document_type}, country: {country}, side: {side}, nationality: {nationality}, \n step data: {step_data}")

        if country == "IRQ":
            document_data = self.agent_extraction(
                image, country,document_type, nationality, side, step_data
            )
            logging.info(
                f"--------------Time taken for {side} ID Extraction in IDV package: {time.time() - st} seconds\n"
            )
            return document_data

        if document_type == "national_id" and side == "front":
            document_data = self.extract_front_id_info(image, country, nationality)
            logging.info(
                f"--------------Time taken for {side} ID Extraction in IDV package: {time.time() - st} seconds\n"
            )
            return document_data

        if document_type == "national_id" and side == "back":
            document_data = self.extract_back_id_info(image, country, nationality, step_data)
            logging.info(
                f"--------------Time taken for {side} ID Extraction in IDV package: {time.time() - st} seconds\n"
            )

        if document_type == "passport" and (
            side == "first" or side == "page1" or side == ""
        ):
            logging.info(f"Starting passport extraction for side: {side} country: {country} nationality: {nationality}")
            document_data = self.extract_passport_info(
                image, country, nationality, step_data
            )
            logging.info(
                f"--------------Time taken for Passport Extraction in IDV package: {time.time() - st} seconds\n"
            )

        if document_type == "passport" and (side == "last" or side == "page2"):
            document_data = self.exract_passport_info_back(image, country, nationality, step_data)
            logging.info(
                f"--------------Time taken for Passport Extraction in IDV package: {time.time() - st} seconds\n"
            )

        if document_type == "driving_license":
            pass

        return document_data

    def agent_extraction(self, image, country, document_type, nationality=None, side=None, step_data=None):


          #Handling non-iraqi passports
        if nationality is not None and nationality != "IRQ" and (side == "page1" or side == "first"):
            logging.info(f"Starting non-iraqi passport extraction for side: {side} country: {country} nationality: {nationality}")
            data = self.extract_passport_info(image, country, nationality, step_data)
            return data

        elif nationality is not None and nationality != "IRQ" and (side == "page2" or side == "last"):
            logging.info(f"Starting non-iraqi passport extraction for side: {side} country: {country} nationality: {nationality}")
            data = self.extract_passport_info_back(image, country, nationality, step_data)
            return data
        

        # Handling Iraqi National ID Front
        elif  document_type == "national_id" and side == "front":
            data = self.extract_front_id_info(image, country, nationality)
            return data
        
        #Handling Iraqi National ID Back
        elif document_type == "national_id" and side == "back":
            data = self.extract_back_id_info(image, country, nationality, step_data)
            return data
        
        #handling Iraqi passport 
        elif document_type == "passport" and (side == "first" or side == "page1"):
            data = self.extract_passport_info(image, country, nationality, step_data)
            return data

    def image_conversion_and_compression(self, image):
        """
        This function decodes a base64 string data and returns an image object.
        If the image is in RGBA mode, it is converted to RGB mode.
        :return: an Image object that has been created from a base64 encoded string.
        """
    
        img_data = io.BytesIO(base64.decodebytes(bytes(image, "utf-8")))
        with Image.open(img_data) as img:
            if img.mode == "RGBA":
                # Create a blank background image
                background = Image.new("RGB", img.size, (255, 255, 255))
                # Paste the image on the background.
                background.paste(img, mask=img.split()[3])  # 3 is the alpha channel
                img = background
            else:
                img = img.copy()

        compressed_image = BytesIO()
        img.save(
            compressed_image, format="JPEG", quality=75, optimize=True
        )
        compressed_image_data = compressed_image.getvalue()

        return img,compressed_image_data

    def extract_front_id_info(self, front_id, country, nationality=None,):

        if country == "UAE":
            try:

                from idvpackage.common import load_and_process_image_deepface

                from idvpackage.uae_id_extraction import get_response_from_openai_uae

                front_data = {"error": "", "doc_type": "national_identity_card"}

                start_time = time.time()
                logging.info(f"Starting extraction for UAE front ID")
                output = get_response_from_openai_uae(front_id, "front", country, self.openai_key)
                logging.info(f"Time taken for UAE front ID extraction: {time.time() - start_time} seconds")
                
                logging.info(f"UAE front ID extraction output: {json.dumps(output, ensure_ascii=False, indent=2)}")
                front_data.update(output)
                
                if not output.get("header_verified", False):
                    front_data["error"] = "not_front_id"
                    return front_data

                dob = front_data.get('dob', '')
                try:
                    if  dob:
                        logging.info(f"Extracted DOB for age verification: {dob}")
                        from idvpackage.ocr_utils import is_age_18_above
                        is_legal_age = is_age_18_above(dob)
                        logging.info(f"Is legal age (18+): {is_legal_age}")
                        if not is_legal_age:
                            front_data['error'] = 'under_age'
                            return front_data

                except Exception as e:
                    logging.info(f"Error in age calculation: {e}")
                    
                    
                expiry_date = front_data.get('expiry_date', '')
                try:
                    if expiry_date:
                        logging.info(f"Extracted Expiry Date for expiry verification: {expiry_date}")
                        from idvpackage.ocr_utils import is_expired_id
                        if is_expired_id(expiry_date):
                            front_data['error'] = 'expired_id'
                            logging.info(f"ID is expired with expiry date: {expiry_date}")
                            return front_data
                except Exception as e:
                    logging.info(f"Error in expiry date calculation: {e}")

                        

                front_face_locations, front_face_encodings = (
                    load_and_process_image_deepface(front_id)
                )

                if front_face_encodings is None or len(front_face_encodings) == 0:
                    front_data['error'] = 'face_not_detected'
                    logging.info("No face detected in front image")
                    return front_data


                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )


                front_data_update = {
                    "id_number_front": output.get("id_number", ""),
                    "front_extracted_data": "front_extracted_data",
                    "front_coloured": True,
                    "front_doc_on_pp": "clear",
                    "front_logo_result": 'clear',
                    "front_screenshot_result": "clear",
                    "front_photo_on_screen_result": "clear",
                    "front_blurred": "clear",
                    "front_glare": "clear",
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                    "front_tampered_result": "clear",
                }

                front_data.update(front_data_update)

                non_optional_keys = [
                    "front_face_locations",
                    "front_face_encodings",
                    "id_number_front",
                ]
                empty_string_keys = [
                    key
                    for key, value in front_data.items()
                    if key in non_optional_keys and value == ""
                ]

                if empty_string_keys:
                    front_data["error"] = "missing_key_fields"
                    logging.info(f"Empty string fields found in front_data: {empty_string_keys}")
                    return front_data

                
            except Exception as e:
                front_data["error"] = "bad_image"
                logging.info(f"Exception in UAE front ID extraction: {e}")
                front_data["error_details"] = e

            return front_data

        if country == "IRQ":
            logging.info("-------------Working on IRQ \n")
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.iraq_id_extraction_withopenai import (
                get_response_from_openai_irq,
            )
            from idvpackage.ocr_utils import (
                detect_photo_on_screen,
                detect_screenshot,
                document_on_printed_paper,
            )

            result = {"error": "", "doc_type": "national_identity_card"}

            try:
                st = time.time()
                processed_front_id, compressed_image_data = self.image_conversion_and_compression(front_id)
                logging.info(f'----------------Time taken for image conversion: {time.time() - st} seconds\n')
                
                
                logging.info(f"starting the extraction using openai for IRQ front_id")
                st = time.time()

                front_data = get_response_from_openai_irq(compressed_image_data, openai_key=self.openai_key,side="front")
                

                logging.info(f'----------------Time taken for OpenAI and  final extraction front_id: {time.time() - st} seconds\n')

                logging.info(f"front_data: {json.dumps(front_data, ensure_ascii=False, indent=2)}")
                

                if not front_data.get('header_verified', False):
                    result["error"] = "not_front_id"
                    return result

                if not front_data.get("id_number", '').isdigit() and len(front_data.get("id_number", '')) == 12:
                    result["error"] = "invalid_national_number"
                    logging.info(f" invalid_national_number number found in front_data: {front_data.get('id_number')}")
                    return result

                if len(front_data.get("card_number", '')) != 9:
                    result["error"] = "invalid_document_number"
                    logging.info(f" invalid_document_number number found in front_data: {front_data.get('card_number')}")
                    return result

                if front_data.get("gender", '').lower() not in ['male', 'female']:
                    logging.info(f" invalid_gender found in front_data: {front_data.get('gender')}")
                    front_data["gender"] = ""

                image= np.array(processed_front_id)

                if not front_data['last_name'] or not front_data['last_name_en']:

                    front_data['name'] = front_data.get('first_name', '') + " " + front_data.get('father_name', '')
                    front_data['name_en']= front_data.get('first_name_en', '') + " " + front_data.get('father_name_en', '')

                else:
                    front_data['name'] = front_data.get('first_name', '') + " " + front_data.get('father_name','') + " " + front_data.get('last_name', '')
                    front_data['name_en'] = front_data.get('first_name_en', '') + " " + front_data.get('father_name_en', '') + " " + front_data.get("last_name_en", '')

                st = time.time()
                from idvpackage.common import load_and_process_image_deepface
                front_face_locations, front_face_encodings = load_and_process_image_deepface(front_id)
                logging.info(f'----------------Time taken for face extraction: {time.time() - st} seconds\n')


                if front_face_encodings is None or len(front_face_encodings) == 0:
                    result['error'] = 'face_not_detected'
                    logging.info("No face detected in front image")
                    return result

                front_face_locations_str = json.dumps([tuple(face_loc) for face_loc in front_face_locations])
                front_face_encodings_str = json.dumps([face_enc.tolist() for face_enc in front_face_encodings])
                
                # optional_fields = ('last_name', 'last_name_en','serial_number','blood_type','gender','gender_ar')
                non_optional_keys = ['id_number_front',
                                    'card_number_front',
                                    'first_name',
                                    'first_name_en',
                                    'father_name',
                                    'father_name_en',
                                    'third_name',
                                    'third_name_en',
                                    'mother_first_name',
                                    'mother_first_name_en',
                                    'mother_last_name',
                                    'mother_last_name_en',
                                    'doc_type',
                                    'nationality',
                                    'nationality_en']
                #check if any non optional key has empty string value
                empty_string_keys = [ key for key, value in front_data.items() if key in non_optional_keys and (value == "" or value == [] or value == "[]")]
                logging.info(f"Empty string keys in back_data: {empty_string_keys}")

                if empty_string_keys:
                    result['error'] = 'missing_key_fields'
                    logging.info(f"Empty string fields found in front_data: {empty_string_keys}")
                    return result

                data_temp = {
                        'front_extracted_data': '',
                        'translated_front_id_text':'',
                        'front_coloured': True,
                        'back_coloured':True,
                        'nationality': 'IRQ',
                        'nationality_en': 'IRQ',
                        "doc_on_pp_result": "clear",
                        "template_result": "clear",
                        "logo_result": "clear",
                        'front_doc_on_pp': "clear",
                        'front_logo_result': "clear",
                        'front_template_result': "clear",
                        'front_screenshot_result': "clear",
                        'front_photo_on_screen_result': "clear",
                        'front_blurred': "clear",
                        'front_glare': "clear",
                        'front_face_locations': front_face_locations_str,
                        'front_face_encodings': front_face_encodings_str,
                        'front_tampered_result': 'clear',
                        'issuing_country':'IRQ',
                        'valid_nationality': "clear"
                    }
                front_data.update(data_temp)
                result.update(front_data)
                return result


            except Exception as e:
                result["error"] = "bad_image"
                result["error_details"] = e
                return result

        if country == "QAT":
            logging.info(f"Working on QAT NID ....")
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.ocr_utils import document_on_printed_paper
            from idvpackage.qatar_id_extraction import get_response_from_openai_qat, is_physical_card

            result = {"error": "", "doc_type": "national_identity_card"}

            try:
                is_physical_card_result = is_physical_card(front_id, self.openai_key)

                if isinstance(is_physical_card_result, bool):
                    if not is_physical_card_result:
                        result["error"] = "photo_on_screen"
                        logging.info("Document appears to be a photo on screen based on OpenAI analysis.")
                        return result

                else:
                    return is_physical_card_result # Returns error and error_details dictionary


                processed_front_id ,compressed_image_data= self.image_conversion_and_compression(front_id)
                st = time.time()
                
                front_data = get_response_from_openai_qat(
                    compressed_image_data, "front", country, self.openai_key
                )
                logging.info(f"----------------Time taken for vision front: {time.time() - st} seconds\n")
                logging.info(f"front_data: {json.dumps(front_data, indent=2, ensure_ascii=False)}")

                front_data['issuing_country'] = 'QAT'

                if not front_data.get("header_verified", False):
                    result["error"] = "not_front_id"
                    return result

                logging.info(  f"----------------Time taken for qatar OpenAI and  final extraction front: {time.time() - st} seconds\n")

                expiry_date = front_data.get("expiry_date", "")
                try:
                    if expiry_date:
                        logging.info(f"Extracted Expiry Date for expiry verification: {expiry_date}")
                        from idvpackage.ocr_utils import is_expired_id
                        if is_expired_id(expiry_date):
                            result['error'] = 'expired_id'
                            logging.info(f"ID is expired with expiry date: {expiry_date}")
                            return result
                except Exception as e:
                    logging.info(f"Error in expiry date calculation: {e}")

                image = np.array(processed_front_id)
                doc_on_pp_result = document_on_printed_paper(image)

                st = time.time()
                front_face_locations, front_face_encodings = (
                    load_and_process_image_deepface(front_id, country="QAT")
                )

                
                if front_face_encodings is None or len(front_face_encodings) == 0:
                    result['error'] = 'face_not_detected'
                    logging.info("No face detected in front image")
                    return result
                
                logging.info(f"----------------Time taken for face extraction front: {time.time() - st} seconds\n")

                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )            
                front_data_temp = {
                    "front_extracted_data": "",
                    "valid_nationality": "clear",
                    "front_coloured": True,
                    "front_doc_on_pp": "clear",
                    "front_logo_result": "clear",
                    "front_template_result": "clear",
                    "front_screenshot_result": "clear",
                    "front_photo_on_screen_result": "clear",
                    "front_blurred": "clear",
                    "front_glare": "clear",
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                }

                front_data.update(front_data_temp)
                result.update(front_data)
                
                required_keys = ["expiry_date", "name", "id_number"]
                empty_string_keys = [
                    key
                    for key, value in front_data.items()
                    if key in required_keys and value == ""
                ]

                if empty_string_keys:
                    result["error"] = "missing_key_fields"

                if front_data.get("error"):
                    return result


            except Exception as e:
                logging.info(f"exception in QAT front ID extraction: {e}")
                result["error"] = "bad_image"
                result["error_details"] = e

            return result

        if country == "LBN":
            logging.info("----------------Working on LBN\n")
            from idvpackage.blur_detection import is_image_blur
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.lebanon_id_extraction import lebanon_id_extraction_from_text
            from idvpackage.ocr_utils import detect_screenshot, document_on_printed_paper

            result = {"error": "", "doc_type": "national_identity_card"}

            try:
                st = time.time()
                processed_front_id ,compressed_image_data= self.image_conversion_and_compression(front_id)
                logging.info(f"----------------Time taken for image conversion front: {time.time() - st} seconds\n")

                st = time.time()    
                front_id_text = self.get_ocr_results(
                    compressed_image_data, country="LBN"
                )
                front_id_text_desc = front_id_text[0].description
                logging.info(f"Extracted LBN front OCR text: {front_id_text_desc}")
                logging.info(f"----------------Time taken for vision front: {time.time() - st} seconds\n")

                # Check for blur using the new comprehensive method
                image = np.array(processed_front_id)
                if is_image_blur(
                    image,
                    laplace_threshold=30,
                    canny_threshold=1500,
                    fft_threshold=120,
                    bright_reflection_min_area=1.0,
                ):
                    logging.info(
                        f"Blur/Brightness issue detected in front image, marking as covered photo"
                    )
                    result["error"] = "blur_photo"
                    return result

                st = time.time()
                front_data = lebanon_id_extraction_from_text(front_id_text_desc, compressed_image_data, 'front', self.openai_key)

                logging.info(f"----------------Time taken for OpenAI and  final extraction front: {time.time() - st} seconds\n")
                logging.info(f"Extracted LBN front data fields: {json.dumps(front_data, indent=2, ensure_ascii=False)}")

                if not front_data.get("header_verified", False):
                    result["error"] = "not_front_id"
                    return result   
                
                if 'id_number' in front_data:
                    id_number = front_data['id_number']
                    if id_number and len(id_number) < 12:
                        front_data['id_number'] = id_number.zfill(12)
                        
                logging.info(f"ID Number after padding: {front_data.get('id_number', '')}")
                
                if 'id_number_ar' in front_data:
                    id_number_ar = front_data['id_number_ar']
                    if id_number_ar and len(id_number_ar) < 12:
                        front_data['id_number_ar'] = id_number_ar.rjust(12, '٠')
                
                logging.info(f"ID Number AR after padding: {front_data.get('id_number_ar', '')}")

                full_name = (front_data.get("mother_name") or "").strip().split()
                front_data["mother_first_name"] = full_name[0] if full_name else ""
                front_data["mother_last_name"] = " ".join(full_name[1:]) if len(full_name) > 1 else ""

                full_name_en = (front_data.get("mother_name_en") or "").strip().split()
                front_data["mother_first_name_en"] = full_name_en[0] if full_name_en else ""
                front_data["mother_last_name_en"] = " ".join(full_name_en[1:]) if len(full_name_en) > 1 else ""
                
                
                front_data['issuing_country'] = 'LBN'
                front_data['nationality'] = 'LBN'
                required_keys = [
                    "name",
                    "dob",
                    "dob_ar",
                    "place_of_birth_ar",
                    "id_number",
                ]

                dob = front_data.get('dob', '')
                logging.info(f"Extracted DOB for age verification: {dob}")
                try:
                    if  dob:
                        from idvpackage.ocr_utils import is_age_18_above
                        is_legal_age = is_age_18_above(dob)
                        logging.info(f"Is legal age (18+): {is_legal_age}")
                        if not is_legal_age:
                            front_data['error'] = 'under_age'
                            return front_data
                
                except Exception as e:
                    logging.info(f"Error in age calculation: {e}")

                empty_string_keys = [
                    key
                    for key, value in front_data.items()
                    if key in required_keys
                    and (value == "" or value == "[]" or value == [] or not value)
                ]

                if empty_string_keys:
                    result["error"] = "missing_key_fields"
                    logging.info(
                        f"Missing required keys in LBN front data: {empty_string_keys}"
                    )
                    return result
                image = np.array(processed_front_id)

                st = time.time()
                doc_on_pp_result = "clear"
                logo_result = "clear"
                template_result = "clear"
                screenshot_result = detect_screenshot(self.client, front_id)
                photo_on_screen_result = "clear"
                front_blurred, front_glare = self.get_blurred_and_glared_for_doc(image)
                logging.info(
                    f"----------------Time taken for fraud detection attributes front: {time.time() - st} seconds\n"
                )

                st = time.time()
                front_face_locations, front_face_encodings = (
                    load_and_process_image_deepface(front_id)
                )
                logging.info(
                    f"----------------Time taken for face extraction front: {time.time() - st} seconds\n"
                )

                if front_face_encodings is None or len(front_face_encodings) == 0:
                    result['error'] = 'face_not_detected'
                    logging.info("No face detected in front image")
                    return result

                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )


                result_temp = {
                    "front_extracted_data": "",
                    "translated_front_id_text": "",
                    "front_coloured": True,
                    "front_doc_on_pp": doc_on_pp_result,
                    "front_logo_result": logo_result,
                    "front_template_result": template_result,
                    "front_screenshot_result": screenshot_result,
                    "front_photo_on_screen_result": photo_on_screen_result,
                    "front_blurred": front_blurred,
                    "front_glare": front_glare,
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                }

                result.update(result_temp)
                result.update(front_data)

                required_keys = [
                    "front_face_locations",
                    "front_face_encodings",
                    "name",
                    "dob",
                    "dob_ar",
                    "place_of_birth_ar",
                    "id_number",
                ]

                empty_string_keys = [
                    key
                    for key, value in result.items()
                    if key in required_keys
                    and (value == "" or value == "[]" or value == [] or not value)
                ]

                if empty_string_keys:
                    result["error"] = "missing_key_fields"
                    logging.info(
                        f"Missing required keys in LBN front data after update: {empty_string_keys}"
                    )

            except Exception as e:
                result["error"] = "bad_image"
                result["error_details"] = e

            return result

        if country == "SDN":
            logging.info("----------------Working on SDN\n")
            from idvpackage.blur_detection import is_image_blur
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.ocr_utils import (
                detect_screenshot,
                document_on_printed_paper,
            )
            from idvpackage.sudan_passport_extraction import (
                get_response_from_openai_sdn,
            )

            result = {"error": "", "doc_type": "national_identity_card"}

            try:
                st = time.time()
                processed_front_id,compressed_image_data = self.image_conversion_and_compression(front_id)
                logging.info(f"----------------Time taken for image conversion front: {time.time() - st} seconds\n")
                
                st = time.time()
                image = np.array(processed_front_id)
                doc_on_pp_result = "clear"
                logo_result = "clear"
                template_result = "clear"
               
                front_data = get_response_from_openai_sdn(compressed_image_data, 'front', self.openai_key)

                logging.info(f"Extracted SDN front data fields: {json.dumps(front_data, indent=2, ensure_ascii=False)}")
                logging.info(f"----------------Time taken for OpenAI and  final extraction front: {time.time() - st} seconds\n")

                if not front_data.get("header_verified", False):
                    front_data['error'] = 'not_front_id'
                    logging.error(f"ID not verified in the document data: {front_data['header_verified']}")
                    return front_data

                dob = front_data.get('dob', '')
                
                if dob:
                    try:
                        from idvpackage.ocr_utils import is_age_18_above
                        is_legal_age = is_age_18_above(dob)
                        if not is_legal_age:
                            front_data['error'] = 'under_age'
                            return front_data
                    
                    except Exception as e:
                        logging.error(f"Error in age calculation: {e}")
                        

                front_data['occupation'] = front_data.get('occupation_en', '')
               
                st = time.time()
                screenshot_result = detect_screenshot(self.client, front_id)
                photo_on_screen_result = "clear"
                front_blurred, front_glare = self.get_blurred_and_glared_for_doc(image)
                
                logging.info(
                    f"----------------Time taken for fraud detection attributes front: {time.time() - st} seconds\n"
                )

                st = time.time()
                front_face_locations, front_face_encodings = (
                    load_and_process_image_deepface(front_id, country="SDN")
                )
                
                if front_face_encodings is None or len(front_face_encodings) == 0:
                    result['error'] = 'face_not_detected'
                    logging.info("No face detected in front image")
                    return result
                
                logging.info(
                    f"----------------Time taken for face extraction front: {time.time() - st} seconds\n"
                )

                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )

                result_temp = {
                    "front_extracted_data": "",
                    "translated_front_id_text": "",
                    "front_coloured": True,
                    "front_doc_on_pp": doc_on_pp_result,
                    "front_logo_result": logo_result,
                    "front_template_result": template_result,
                    "front_screenshot_result": screenshot_result,
                    "front_photo_on_screen_result": photo_on_screen_result,
                    "front_blurred": front_blurred,
                    "front_glare": front_glare,
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                }

                front_data.update(result_temp)
                result.update(front_data)

                required_keys = [
                    "front_face_locations",
                    "id_number",
                    "front_face_encodings",
                    "full_name",
                    "dob",
                ]
                empty_string_keys = [
                    key
                    for key, value in result.items()
                    if key in required_keys and value == ""
                ]

                if empty_string_keys:
                    result["error"] = "missing_key_fields"

            except Exception as e:
                result["error"] = "bad_image"
                logging.info(f"-------------->> Something went wrong error trace:: {e}")
                result["error_details"] = e

            

            try:
                names_list = result["name_ar"].split(" ")
                filtered_names = [name for name in names_list if len(name) > 1]
                if len(filtered_names) >= 2:
                    result["first_name_ar"] = filtered_names[0]
                    result["last_name_ar"] = filtered_names[-1]
                    result["middle_name_ar"] = " ".join(filtered_names[1:-1])
                else:
                    result["first_name_ar"] = result["name_ar"]
                    result["last_name_ar"] = ""
                    result["middle_name_ar"] = ""

            except Exception as e:
                result["first_name_ar"] = ""
                result["last_name_ar"] = ""
                result["middle_name_ar"] = ""

            return result

    def extract_back_id_info(self, back_id, country, nationality, step_data):
        
        step_data = step_data if step_data is not None else {}

        if country == 'UAE':
            try:
                from idvpackage.ocr_utils import (
                    detect_photo_on_screen,
                    detect_screenshot,
                    document_on_printed_paper,
                    
                )
                from idvpackage.uae_id_extraction import get_response_from_openai_uae
                back_data = {"error": "", "doc_type": "national_identity_card"}
                back_data['country'] = "UAE"
                
                st = time.time()
                output = get_response_from_openai_uae(back_id, 'back', 'UAE', self.openai_key)
                logging.info(f"Time Taken to get back id raw output from openai: {time.time() - st}")
                
                logging.info(f"back_data output from openai: {json.dumps(output, indent=2, ensure_ascii=False)}")
                
                if not output.get('back_header_verified', False):
                    back_data['error'] = 'not_back_id'
                    return back_data

                update_doe_dob_gender_from_back_data = {
                    "dob": step_data.get('dob', '') if step_data.get('dob', '') != '' else output.get('dob', ''),
                    "expiry_date": step_data.get('expiry_date', '') if step_data.get('expiry_date',
                                                                                     '') != '' else output.get(
                        'expiry_date', ''),
                    "gender": step_data.get('gender', '') if step_data.get('gender', '') != '' else output.get('gender', '')
                    }

                back_date_update_from_stepdata = {
                    "name": step_data.get('name', ''),
                    "first_name": step_data.get('first_name', ''),
                    "last_name": step_data.get('last_name', ''),
                    "nationality": step_data.get('nationality', '')
                }

                logging.info("Time Taken to get back id info from openai: {}".format(time.time() - st))

                back_data.update(output)
                back_data.update(update_doe_dob_gender_from_back_data)
                back_data.update(back_date_update_from_stepdata)
                
                # hard-coded as per Ola and Maryem's request.
                back_data["issuing_country"] = "ARE"
                
                from idvpackage.ocr_utils import (
                    normalize_date_generic,
                    normalize_mrz_date
                )

                dob = back_data.get('dob', '')
                try:
                    if  dob:
                        logging.info(f"Extracted DOB for age verification: {dob}")
                        from idvpackage.ocr_utils import is_age_18_above
                        is_legal_age = is_age_18_above(dob)
                        logging.info(f"Is legal age (18+): {is_legal_age}")
                        if not is_legal_age:
                            back_data['error'] = 'under_age'
                            return back_data

                except Exception as e:
                    logging.info(f"Error in age calculation: {e}")


                expiry_date = back_data.get('expiry_date', '')
                try:
                    if expiry_date:
                        logging.info(f"Extracted Expiry Date for expiry verification: {expiry_date}")
                        from idvpackage.ocr_utils import is_expired_id
                        if is_expired_id(expiry_date):
                            back_data['error'] = 'expired_id'
                            logging.info(f"ID is expired with expiry date: {expiry_date}")
                            return back_data
                except Exception as e:
                    logging.info(f"Error in expiry date calculation: {e}")
                    
                back_data['mrz'] = [
                    back_data.get('mrz1', '') + back_data.get('mrz2', '') + back_data.get('mrz3', '')]

                mrz1 = back_data.get('mrz1', '')
                
                mrz1 = mrz1.strip()
                back_data['id_number_mrz'] = mrz1[-15:]
                back_data['card_number_mrz'] = mrz1[5:14]


                try:
                    front_id_number = step_data.get("id_number", "")
                    back_id_number = back_data.get("id_number_mrz", "")

                    logging.info(
                        f"Front ID number: {front_id_number}, Back ID number: {back_id_number}"
                    )
                    if front_id_number != back_id_number:
                        # would help with debugging to store front_id_number
                        back_data["front_id_number"] = front_id_number

                        back_data["error"] = "front_back_mismatch"
                        return back_data

                except Exception as e:
                    logging.info(
                        f"Exception Thrown while comparing front id number with back id number: {e}"
                    )
                    return {
                        "error": "bad_image",
                        "error_details": f"Exception Thrown while comparing front id number with back id number: {e}",
                    }

                back_data['id_number_front_back_mrz_match'] = False
                back_data["card_number_back_mrz_match"] = False
                back_data['dob_mrz_match']= False
                back_data['expiry_date_mrz_match']= False
                back_data['gender_mrz_match']= False
                back_data['name_mrz_match']= False
        
                back_data['place_of_issuance'] = output.get('issuing_place'," ")
                
                id_number_mrz_str = back_data.get('id_number_mrz', '')
                id_number_str= step_data.get('id_number', '')
                logging.info(f"ID Number from front: {id_number_str} ID Number from MRZ: {id_number_mrz_str}")
                if id_number_mrz_str and id_number_str and id_number_mrz_str == id_number_str:
                    back_data['id_number_front_back_mrz_match'] = True
                
                card_number_mrz_str = back_data.get('card_number_mrz', '')
                card_number_str= back_data.get('card_number', '')
                
                logging.info(f"Card Number from back: {card_number_str} Card Number from MRZ: {card_number_mrz_str}")
                if card_number_mrz_str and card_number_str and card_number_mrz_str == card_number_str:
                    back_data['card_number_back_mrz_match'] = True

                dob_back_str = back_data.get("dob", "")
                dob_back_mrz_str = back_data.get("dob_mrz", "")
                dob_back = normalize_date_generic(dob_back_str)
                dob_back_mrz = normalize_date_generic(dob_back_mrz_str)

                logging.info(f"Normalized DOB from back: {dob_back}, from MRZ: {dob_back_mrz}")

                if dob_back == dob_back_mrz:
                    back_data['dob_mrz_match']= True

                exp_back_str = back_data.get("expiry_date", "")
                exp_back_mrz_str = back_data.get("expiry_date_mrz", "")
                exp_back = normalize_date_generic(exp_back_str)
                exp_back_mrz = normalize_date_generic(exp_back_mrz_str)
                logging.info(f"Normalized Expiry Date from back: {exp_back}, from MRZ: {exp_back_mrz}")
                if exp_back == exp_back_mrz_str:
                    back_data['expiry_date_mrz_match']= True

                 
                if back_data.get('gender_mrz','')=='M':
                    back_data['gender_mrz'] = 'Male'
                elif back_data.get('gender_mrz','')=='F':
                    back_data['gender_mrz'] = 'Female'

                gender_mrz = back_data.get("gender_mrz", "")
                gender_back = back_data.get('gender', '')
                logging.info(f"Gender from card {gender_back} and gender from mrz: {gender_mrz}")
                if gender_back == gender_mrz:
                    logging.info(f"Gender from back: {gender_back}, gender from MRZ: {gender_mrz}")
                    back_data['gender_mrz_match'] = True


                from idvpackage.ocr_utils import get_name_match_mrz

                back_data["is_name_match_mrz"],back_data["name_mrz"] = get_name_match_mrz(back_data,'national_identity_card')
                logging.info(f"Name from back: {back_data.get('name','')}, name from MRZ: {back_data.get('name_mrz','')}")

                img = self.image_conversion(back_id)
                image = np.array(img)

                doc_on_pp_result = document_on_printed_paper(image)
                screenshot_result = detect_screenshot(self.client, back_id)
                photo_on_screen_result = detect_photo_on_screen(self.client, back_id)
                back_blurred, back_glare = self.get_blurred_and_glared_for_doc(image)

                valid_nationality_result = self.check_nationality_in_iso_list(
                    back_data.get("nationality")
                )

                back_data_update = {
                    "back_extracted_data":"back_extracted_data",
                    "valid_nationality": valid_nationality_result,
                    "back_extracted_data": 'original_text',
                    "back_coloured": True,

                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "back_blurred": back_blurred,
                    "back_glare": back_glare,
                }

                back_data.update(back_data_update)


                non_optional_keys = [
                    "id_number",
                    "card_number",
                    "name",
                    "dob",
                    "expiry_date",
                    "gender",
                    "nationality",
                    "mrz",
                    "mrz1",
                    "mrz2",
                    "mrz3",
                ]
                empty_string_keys = [
                    key
                    for key, value in back_data.items()
                    if key in non_optional_keys and value == ""
                ]

                if empty_string_keys:
                    back_data["error"] = "missing_key_fields"
                    logging.info(f"Missing fields: {empty_string_keys}")


            except Exception as e:
                back_data = {"error": "bad_image"}
                back_data["error_details"] = f"Exception Thrown: {e}"
                return back_data

            return back_data

        if country == "IRQ":
            result = {"error": "", "doc_type": "national_identity_card"}
            from idvpackage.iraq_id_extraction_withopenai import (
                get_response_from_openai_irq,
            )
            from idvpackage.ocr_utils import (
                detect_photo_on_screen,
                detect_screenshot,
                document_on_printed_paper,
            )
            try:
                st = time.time()
                processed_back_id,compressed_image_data = self.image_conversion_and_compression(back_id)
                logging.info(f'----------------Time taken for image conversion: {time.time() - st} seconds\n')
                
                logging.info(f"starting the extraction using openai for IRQ back id")
                st = time.time()
                back_data = get_response_from_openai_irq(compressed_image_data, openai_key=self.openai_key,side="back")
                logging.info(f'----------------Time taken for OpenAI and  final extraction back id: {time.time() - st} seconds\n')

                logging.info(f"back_data: {json.dumps(back_data, ensure_ascii=False, indent=2)}")
                if not back_data.get('header_verified', False):
                    back_data["error"] = "not_back_id"
                    return back_data
                
                doc_on_pp_result="clear"
                
                from idvpackage.ocr_utils import (
                    normalize_date_generic,
                )

                if back_data.get('dob', None):
                    from idvpackage.ocr_utils import is_age_18_above
                    if not is_age_18_above(back_data.get('dob', None)):
                        result['error'] = 'under_age'
                        logging.info("Passport holder is under age")
                        return result

                if back_data.get('expiry_date'):
                    from idvpackage.ocr_utils import is_expired_id
                    if is_expired_id(back_data.get('expiry_date', None)):
                        result['error'] = 'expired_id'
                        logging.info(f"ID is expired with expiry date: {back_data.get('expiry_date','')}")
                        return result


                try:
                    expiry_date_obj = datetime.strptime(back_data.get("expiry_date", ""), "%d/%m/%Y")
                except Exception as e:
                    logging.info(f"Error in parsing expiry date for IRQ ID: {e}")
                    expiry_date_obj = None
                try:
                    expiry_date_mrz_obj = datetime.strptime(back_data.get("expiry_date_mrz", ""), "%d/%m/%Y")
                except Exception as e:
                    logging.info(f"Error in parsing expiry date mrz for IRQ ID: {e}")
                    expiry_date_mrz_obj = None
                try:
                    issue_date_obj = datetime.strptime(back_data.get("issue_date", ""), "%d/%m/%Y")
                except Exception as e:
                    logging.info(f"Error in parsing issue date for IRQ ID: {e}")
                    issue_date_obj = None
                    
                if expiry_date_obj and issue_date_obj:
                    try:
                        difference_in_days_mrz_obj = (expiry_date_obj - issue_date_obj).days
                        back_data["valid_id_duration_mrz"] = difference_in_days_mrz_obj in [3651, 3652, 3653]

                    except Exception as e:
                        result['error'] = 'expiry_issue_date_difference_error'
                        logging.info(f"Error in calculating difference between expiry and issue date for IRQ ID: {e}")
                        return result
                        
                dob_back_str = back_data.get("dob", "")
                dob_back_mrz_str = back_data.get("dob_mrz", "")
                dob_back = normalize_date_generic(dob_back_str)
                dob_back_mrz = normalize_date_generic(dob_back_mrz_str)
            
                if dob_back == dob_back_mrz:
                    logging.info(f"Normalized DOB from back: {dob_back}, from MRZ: {dob_back_mrz}")
                    back_data['dob_back_and_mrz_match']= True
                else:
                    logging.info(f"Mismatch in DOB from back: {dob_back}, from MRZ: {dob_back_mrz}")
                    back_data['dob_back_and_mrz_match']= False

                back_data['exp_date_back_and_mrz_match']= False
                back_data['gender_front_and_back_match']= False 
                back_data['id_number_front_back_match'] = False
                back_data['card_number_front_back_match'] = False
                
                card_number_mrz_str = back_data.get('card_number_mrz', '')
                card_number_str= step_data.get('card_number', '')
                if card_number_mrz_str and card_number_str and card_number_mrz_str == card_number_str:
                    back_data['card_number_front_back_match'] = True
                
                mrz1= back_data.get('mrz1', '')
                mrz1 = mrz1.strip()
                back_data['id_number_mrz'] = mrz1[15:27]
                id_number_mrz_str = back_data.get('id_number_mrz', '')
                logging.info(f"ID Number from front: {step_data.get('id_number', '')} ID Number from MRZ: {id_number_mrz_str}")
                
                id_number_str= step_data.get('id_number', '')
                if id_number_mrz_str and id_number_str and id_number_mrz_str == id_number_str:
                    back_data['id_number_front_back_match'] = True
              
                exp_back_str = back_data.get("expiry_date", "")
                exp_back_mrz_str = back_data.get("expiry_date_mrz", "")
                exp_back = normalize_date_generic(exp_back_str)
                exp_back_mrz = normalize_date_generic(exp_back_mrz_str)
                logging.info(f"Normalized Expiry Date from back: {exp_back}, from MRZ: {exp_back_mrz}")

                if exp_back == exp_back_mrz:
                    logging.info(f"Normalized Expiry Date from back: {exp_back}, from MRZ: {exp_back_mrz}")
                    back_data['exp_date_back_and_mrz_match']= True
                
        
                if back_data.get('gender_mrz','')=='M':
                    back_data['gender_mrz'] = 'Male'
                elif back_data.get('gender_mrz','')=='F':
                    back_data['gender_mrz'] = 'Female' 
                    
                gender_mrz = back_data.get("gender_mrz", "")    
                gender_front = step_data.get('gender','') if step_data else ''
                
                if gender_front:
                    if gender_front == gender_mrz:
                        back_data['gender_front_and_back_match']= True  
                else:
                    back_data['gender'] = gender_mrz

                back_data['mrz'] = [back_data.get('mrz1', '') + back_data.get('mrz2', '') + back_data.get('mrz3', '')]

                if len(back_data['mrz']) == 0 or not back_data['mrz'][0].strip():
                    result['error']= "missing_mrz"
                    result['error_details'] = "Missing or empty MRZ fields"
                    return result

                nationality_to_check = "IRQ"
                logging.info(f"Nationality to check for back id: {nationality_to_check}")
                valid_nationality_result = self.check_nationality_in_iso_list(nationality_to_check)
                logging.info(f"valid_nationality_result for passport: {valid_nationality_result}")
                back_data['valid_nationality'] = valid_nationality_result
                
                result.update(back_data)

                non_optional_keys =['issuing_authority',
                                    'issuing_authority_en',
                                    'issue_date',
                                    'expiry_date',
                                    'place_of_birth',
                                    'place_of_birth_en',
                                    'dob',
                                    'mrz1',
                                    'mrz2',
                                    'mrz3',
                                    'family_number',
                                    'doc_type',
                                    'family_number_en',
                                    'nationality',
                                    'issuing_country',
                                    'card_number',
                                    'card_number_back',
                                    'id_number',
                                    'mrz',
                                    'valid_expiry_issue',
                                    'age_check',
                                    'dob_match_mrz_dob',
                                    'is_doc_expired',
                                    'gender_back']
               
                empty_string_keys = [
                    key for key, value in result.items() if key in non_optional_keys and (value == "" or value == [] or value == "[]")
                ]
                logging.info(f"Empty string keys in back_data: {empty_string_keys}")
                
                if empty_string_keys:
                    result['error'] = 'missing_key_fields'
                    logging.info(f"Empty string fields found in back_data: {empty_string_keys}")
                    return result

                back_data_update = {                 
                    'valid_nationality': valid_nationality_result,
                    'back_extracted_data': '',
                    'translated_back_id_text': '',
                    'back_coloured': True,
                    'occupation': '',
                    'employer': '',
                    'doc_on_pp': doc_on_pp_result,
                    'screenshot_result': 'screenshot_result',
                    'photo_on_screen_result': 'photo_on_screen_result',
                    'back_blurred': 'front_blurred',
                    'back_glare': 'front_glare',
                    'back_tampered_result': 'clear'
                }
                logging.info(f"Back data update before final update: ")
                result.update(back_data_update)
                logging.info(f"Final back_data completed succesfully")
                
                return result
            
            except Exception as e:
                result['error'] = 'bad_image'
                result['error_details'] = str(e)
                logging.info(f"Exception details: {e}")
                return result
 
        if country == "QAT":
            from idvpackage.qatar_id_extraction import get_response_from_openai_qat, is_physical_card
            result = {"error": "", "doc_type": "national_identity_card"}
            try:

                is_physical_card_result = is_physical_card(back_id, self.openai_key)

                if isinstance(is_physical_card_result, bool):
                    if not is_physical_card_result:
                        result["error"] = "photo_on_screen"
                        logging.info("Document appears to be a photo on screen based on OpenAI analysis.")
                        return result

                else:
                    return is_physical_card_result # Returns error and error_details dictionary


                processed_back_id = self.image_conversion(back_id)
                compressed_image = BytesIO()
                processed_back_id.save(
                    compressed_image, format="JPEG", quality=80, optimize=True
                )
                compressed_image_data = compressed_image.getvalue()
                
                st = time.time()
                back_data = get_response_from_openai_qat(compressed_image_data, "back", country, self.openai_key)
                logging.info(f"----------------Time taken for OpenAI and  final extraction back: {time.time() - st} seconds\n")
                logging.info(f"back_extraction_result: {json.dumps(back_data, ensure_ascii=False, indent=2)}")
                
                if not back_data.get('back_header_verified', False):
                    result["error"] = "not_back_id"
                    return result

                result.update(back_data)
                back_data_update = {
                    "back_extracted_data": "",
                    "back_coloured": True,
                    "doc_on_pp": "clear",
                    "screenshot_result": "clear",
                    "photo_on_screen_result": "clear",
                    "back_blurred": "clear",
                    "back_glare": "clear",
                }

                result.update(back_data_update)
                
            except Exception as e:
                result["error"] = "bad_image"
                result["error_details"] = e

            return result

        if country == "LBN":
            from idvpackage.blur_detection import is_image_blur
            from idvpackage.lebanon_id_extraction import lebanon_id_extraction_from_text
            from idvpackage.ocr_utils import (
                detect_photo_on_screen,
                detect_screenshot,
                document_on_printed_paper,
            )

            result = {"error": "", "doc_type": "national_identity_card"}
            try:
                st = time.time()
                processed_back_id = self.image_conversion(back_id)
                logging.info(f"----------------Time taken for image conversion back: {time.time() - st} seconds\n")
                st = time.time()
                compressed_image = BytesIO()
                processed_back_id.save(
                    compressed_image, format="JPEG", quality=100, optimize=True
                )
                compressed_image_data = compressed_image.getvalue()
                back_id_text = self.get_ocr_results(compressed_image_data, country="LBN")
                back_id_text_desc = back_id_text[0].description

                logging.info(f"Extracted LBN back OCR text: {back_id_text_desc}")
                logging.info(f"----------------Time taken for vision back: {time.time() - st} seconds\n")

                # Check for blur using the new comprehensive method
                image = np.array(processed_back_id)
                if is_image_blur(
                    image,
                    laplace_threshold=30,
                    canny_threshold=1500,
                    fft_threshold=120,
                    bright_reflection_min_area=1.0,
                ):
                    logging.info(f"Blur/Brightness issue detected in front image, marking as covered photo")
                    result["error"] = "blur_photo"
                    return result

                st = time.time()
                back_data = lebanon_id_extraction_from_text(back_id_text_desc, compressed_image_data, "back", self.openai_key)

                logging.info(f"back_extraction_result: {json.dumps(back_data, ensure_ascii=False, indent=2)}")

                if not back_data.get('header_verified', False):
                    result["error"] = "not_back_id"
                    return result

                if back_data.get("issue_date", None):
                    issue_date_str = back_data.get("issue_date", "")
                    from idvpackage.lebanon_id_extraction import is_valid_past_date

                    if not is_valid_past_date(issue_date_str):
                        result["error"] = "invalid_issue_date"
                        result["error_details"] = (
                            f"issue date received:{issue_date_str} "
                        )
                        return result

                logging.info(
                    f"----------------Time taken for OpenAI and  final extraction back: {time.time() - st} seconds\n"
                )

                result.update(back_data)
                image = np.array(processed_back_id)

                st = time.time()
                doc_on_pp_result = "clear"
                screenshot_result = detect_screenshot(self.client, back_id)
                photo_on_screen_result = "clear"
                back_blurred, back_glare = self.get_blurred_and_glared_for_doc(image)
                logging.info(
                    f"----------------Time taken for fraud detection attributes back: {time.time() - st} seconds\n"
                )

                result_update = {
                    "back_extracted_data": "",
                    "back_coloured": True,
                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "back_blurred": back_blurred,
                    "back_glare": back_glare,
                }

                result.update(result_update)
                non_optional_keys = ["gender", "issue_date", "card_number"]
                empty_string_keys = [
                    key
                    for key, value in result.items()
                    if key in non_optional_keys and value == ""
                ]

                if empty_string_keys:
                    result["error"] = "missing_key_fields"
                    logging.info(f"Empty non-optional keys: {empty_string_keys}")

            except Exception as e:
                result["error"] = "bad_image"
                result["error_details"] = e
                logging.info(f"Exception details: {e}")

            return result

        if country == "SDN":
            from idvpackage.blur_detection import is_image_blur
            from idvpackage.ocr_utils import (
                detect_photo_on_screen,
                detect_screenshot,
                document_on_printed_paper,
            )

            result = {"error": "", "doc_type": "national_identity_card"}
            logging.info(f"Starting Sudan ID back side processing with step_data:{step_data}")
            try:
                st = time.time()
                processed_back_id ,compressed_image_data = self.image_conversion_and_compression(back_id)
                logging.info(
                    f"----------------Time taken for image conversion back: {time.time() - st} seconds\n"
                )
                st = time.time()
                compressed_image = BytesIO()
                processed_back_id.save(
                    compressed_image, format="JPEG", quality=90, optimize=True
                )
                compressed_image_data = compressed_image.getvalue()
                image = np.array(processed_back_id)
             
                from idvpackage.sudan_passport_extraction import get_response_from_openai_sdn
                st = time.time()                
                back_data = get_response_from_openai_sdn(compressed_image_data, "back", self.openai_key)
                logging.info(f"----------------Time taken for vision back: {time.time() - st} seconds\n")
                logging.info(f"back_extraction_result: {json.dumps(back_data, ensure_ascii=False, indent=2)}")

                if not back_data.get('idsdn_verified', False):
                    result["error"] = "not_back_id"
                    return result
                logging.info(f"----------------Time taken for OpenAI and  final extraction back: {time.time() - st} seconds\n")
                
                if back_data.get("expiry_date"):
                    try:
                        expiry_date = back_data["expiry_date"]
                        expiry_date = datetime.strptime(expiry_date, "%d/%m/%Y")
                        current_date = datetime.now()

                        if expiry_date < current_date:
                            result["error"] = "expired_id"
                            return result
                    except:
                        pass

                result.update(back_data)
                result['issuing_country'] = 'SDN'
                from idvpackage.ocr_utils import normalize_date_generic

                dob_front_str = step_data.get("dob", "") if step_data else ""
                dob_back_str = result.get("dob_back", "")
                dob_back_mrz_str = result.get("date_of_birth_mrz", "")
               
                dob_front = normalize_date_generic(dob_front_str)
                dob_back = normalize_date_generic(dob_back_str)
                dob_back_mrz = normalize_date_generic(dob_back_mrz_str)
               
                try:
                    expiry_date_obj = datetime.strptime(result.get("expiry_date", ""), "%d/%m/%Y")
                except Exception as e:
                    logging.info(f"Error in parsing expiry date for SDN ID: {e}")
                    expiry_date_obj = None
                try:
                    expiry_date_mrz_obj = datetime.strptime(result.get("expiry_date_mrz", ""), "%d/%m/%Y")
                except Exception as e:
                    logging.info(f"Error in parsing expiry date mrz for SDN ID: {e}")
                    expiry_date_mrz_obj = None
                try:
                    issue_date_obj = datetime.strptime(result.get("issue_date", ""), "%d/%m/%Y")
                except Exception as e:
                    logging.info(f"Error in parsing issue date for SDN ID: {e}")
                    issue_date_obj = None


                result['valid_id_duration'] = False
                result['valid_id_duration_mrz'] = False
                result['is_expiry_date_same_mrz'] = False
                result['is_dob_front_back_match'] = False
                result['is_dob_front_back_mrz_match'] = False
                result['is_gender_mrz_match'] = False
                result['is_name_match_mrz'] = False

                if result.get('expiry_date') and result.get('expiry_date_mrz'):
                    try:
                        #check if both dates are same
                        logging.info(f"expiry_date_obj: {expiry_date_obj}, expiry_date_mrz_obj: {expiry_date_mrz_obj}")
                        if expiry_date_obj == expiry_date_mrz_obj:
                            result["is_expiry_date_same_mrz"] = True

                    except:             
                        logging.info("Error in comparing expiry dates for SDN ID")
                        pass
               
                if result.get('issue_date', '') and result.get("expiry_date_mrz",''):
                    try:
                        logging.info(f"difference_in_days issue_date_mrz_obj: {issue_date_obj}, expiry_date_mrz_obj: {expiry_date_mrz_obj} differece is : {(expiry_date_mrz_obj - issue_date_obj).days}")
                        difference_in_days_mrz_obj = (expiry_date_mrz_obj - issue_date_obj).days
                        result["valid_id_duration_mrz"] = difference_in_days_mrz_obj in [1825, 1826, 1827]
                    except:
                        logging.info("Error in calculating date difference between issue and expiry dates for SDN ID")
                        pass
            
                if result.get("issue_date",'') and result.get("expiry_date",''):
                    try:
                        logging.info(f"difference_in_days issue_date_obj: {issue_date_obj}, expiry_date_obj: {expiry_date_obj} differece is : {(expiry_date_obj - issue_date_obj).days}")
                        difference_in_days_obj = (expiry_date_obj - issue_date_obj).days
                        result["valid_id_duration"] = difference_in_days_obj in [1825, 1826, 1827]
                    except:
                        logging.info("Error in calculating date difference between issue and expiry dates from MRZ for SDN ID")
                        pass
                
                logging.info(f"dob_front_str: {dob_front_str}, dob_back_str: {dob_back_str}, dob_back_mrz_str: {dob_back_mrz_str}")
                if dob_front_str and dob_back_str:
                    try: 
                        logging.info(f"dob_front: {dob_front}, dob_back: {dob_back}")
                        if dob_front == dob_back:
                            result["is_dob_front_back_match"] = True
                    except:
                        logging.info("Error in comparing DOB between front and back for SDN ID")
                        pass
                
                if dob_front_str and dob_back_mrz_str:
                    try:
                        logging.info(f"dob_front: {dob_front}, dob_back_mrz: {dob_back_mrz}")
                        if dob_front == dob_back_mrz:
                            result["is_dob_front_back_mrz_match"] = True
                    except:
                        logging.info("Error in comparing DOB between front and back MRZ for SDN ID")
                        pass
                
                if result.get('gender') and result.get('gender_mrz'):
                    try:
                        logging.info(f"gender: {result['gender']}, gender_mrz: {result['gender_mrz']}")
                        if result['gender'] == result['gender_mrz']:
                            result["is_gender_mrz_match"] = True
                    except:
                        logging.info("Error in comparing gender between front and back MRZ for SDN ID")
                        pass

                if not (result['is_dob_front_back_mrz_match'] or result['is_dob_front_back_match']):
                    result['error'] = "front_back_mismatch"
                    return result

                from idvpackage.ocr_utils import get_name_match_mrz
                result['nationality'] = 'SDN'
                result['is_name_match_mrz'], result['name_mrz'] = get_name_match_mrz(result, "nationality_identity_card")
                logging.info(f"name from back: {result.get('name','')}, name from mrz: {result.get('name_mrz','')}")
                result['issuance_date'] = result.get('issue_date', '')
                if result.get("issuance_date",""):
                    try:
                        dt_obj = datetime.strptime(result["issuance_date"], "%d/%m/%Y")
                        result["issuance_date"] = dt_obj.strftime("%Y/%m/%d")
                    except:
                        pass

                image = np.array(processed_back_id)

                st = time.time()
                doc_on_pp_result = "clear"
                screenshot_result = detect_screenshot(self.client, back_id)
                photo_on_screen_result = "clear"
                back_blurred, back_glare = self.get_blurred_and_glared_for_doc(image)
                logging.info(
                    f"----------------Time taken for fraud detection attributes back: {time.time() - st} seconds\n"
                )

                back_data_update = {
                    "back_extracted_data": "",
                    "translated_back_id_text": "",
                    "back_coloured": True,
                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "back_blurred": back_blurred,
                    "back_glare": back_glare,
                }

                result.update(back_data_update)
                mrz1 = result.get('mrz1', '')
                mrz2 = result.get('mrz2', '')
                mrz3 = result.get('mrz3', '')
                mrz_str = f"{mrz1}{mrz2}{mrz3}"

                result['mrz'] = [mrz_str]   
                
                non_optional_keys = ["gender", "expiry_date"]
                empty_string_keys = [
                    key
                    for key, value in result.items()
                    if key in non_optional_keys and value == ""
                ]
                if empty_string_keys:
                    result["error"] = "missing_key_fields"

            except Exception as e:
                result["error"] = "bad_image"
                logging.info(f"-------------->> Something went wrong error trace:: {e}")
                result["error_details"] = e

            return result

    def extract_passport_info(self, passport, country, nationality, step_data=None):

        step_data = step_data if step_data is not None else {}

        if (nationality and nationality == "IRQ") or (
            not nationality and country == "IRQ"):
            logging.info("-------------Working on IRQ Passport \n")

            from idvpackage.iraq_id_extraction_withopenai import (
            get_response_from_openai_irq,
        )

            result = {'error': '', "error_details": '', 'doc_type': 'passport'}
            if nationality == '':
                nationality=None

            try:
                st = time.time()
                processed_passport, compressed_image_data = self.image_conversion_and_compression(passport)
                logging.info(f'----------------Time taken for image conversion: {time.time() - st} seconds\n')
                logging.info(f"starting the extraction using openai for IRQ passport")
                
                st = time.time()
                passport_data = get_response_from_openai_irq(compressed_image_data, openai_key=self.openai_key,side="page1")
                logging.info(f'----------------Time taken for OpenAI and  final extraction passport: {time.time() - st} seconds\n')
                logging.info(f"passport_data: {json.dumps(passport_data, ensure_ascii=False, indent=2)}")
                
                if not passport_data.get('header_verified', False):
                    passport_data["error"] = "not_passport"
                    return passport_data
                 
                if passport_data.get('full_name', '') and passport_data.get('last_name', ''):
                    if passport_data['last_name'] not in passport_data['full_name']:  
                        passport_data['full_name'] = passport_data.get('full_name', '') +' '+ passport_data.get('last_name', '')
                
                if passport_data.get('dob', None):
                    from idvpackage.ocr_utils import is_age_18_above
                    if not is_age_18_above(passport_data.get('dob', None)):
                        passport_data['error'] = 'under_age'
                        logging.info("Passport holder is under age")
                        return passport_data

                if passport_data.get('expiry_date'):
                    from idvpackage.ocr_utils import is_expired_id
                    if is_expired_id(passport_data.get('expiry_date', None)):
                        passport_data['error'] = 'expired_id'
                        logging.info(f"ID is expired with expiry date: {passport_data.get('expiry_date','')}")
                        return passport_data
                
                if passport_data.get('mrz2', ''):
                    mrz2 = passport_data.get('mrz2')
                    logging.info(f"Original mrz2: {mrz2}")
                    mrz2 = mrz2.replace('<', '')
                    logging.info(f"Cleaned mrz2: {mrz2}")
                    if len(mrz2) <28:
                        passport_data['error'] = 'missing_mrz'
                        logging.info("MRZ2 length is less than expected after cleaning")
                        return passport_data

                passport_data['gender'] = ''
                if passport_data.get('gender_letter', None):
                    if passport_data.get('gender_letter', '') in ['M', 'm']:
                        passport_data['gender'] = 'Male'
                    elif passport_data.get('gender_letter', '') in ['F', 'f']:
                        passport_data['gender'] = 'Female'
                
                if passport_data.get('mrz1') and passport_data.get('mrz2'):
                     passport_data['mrz'] = passport_data['mrz1'] + passport_data['mrz2']

                if len(passport_data['mrz']) == 0 or not passport_data['mrz'][0].strip():
                    return {
                        "error": "missing_mrz",
                        "error_details": "Missing or empty MRZ fields"
                    } 

                passport_data['issuing_country'] = 'IRQ'   
                nationality_to_check = passport_data.get('nationality')
                valid_nationality_result = self.check_nationality_in_iso_list(nationality_to_check)
                logging.info(f"valid_nationality_result for passport: {valid_nationality_result}")
                passport_data['valid_nationality'] = valid_nationality_result

                logging.info(f"checking all passport_data fields for empty non-optional keys{passport_data.keys()}")
                empty_string_keys = [ key for key, value in passport_data.items() if value == "" or value == [] or value == "[]"]
                if empty_string_keys:
                    passport_data['error'] = 'missing_key_fields'
                    logging.warning(f"Empty string fields found in passport_data: {empty_string_keys}")

                st = time.time()
                from idvpackage.common import load_and_process_image_deepface
                front_face_locations, front_face_encodings = load_and_process_image_deepface(passport)
                logging.info(f'----------------Time taken for face extraction: {time.time() - st} seconds\n')


                if front_face_encodings is None or len(front_face_encodings) == 0:
                    passport_data['error'] = 'face_not_detected'
                    logging.info("No face detected in passport image")
                    return passport_data

                front_face_locations_str = json.dumps([tuple(face_loc) for face_loc in front_face_locations])
                front_face_encodings_str = json.dumps([face_enc.tolist() for face_enc in front_face_encodings])
                
                result.update(passport_data)

                if step_data:
                    try:
                        logging.info(f"Matching face from Passport with National ID")
                        national_id_front_face_locations = json.loads(step_data.get("front_face_locations"))
                        national_id_front_face_encodings = json.loads(step_data.get("front_face_encodings"))
                        st = time.time()

                        largest_face_index1 = national_id_front_face_locations.index(
                            max(national_id_front_face_locations, key=lambda loc: (loc[2] - loc[0]) * (loc[3] - loc[1])))
                        largest_face_index2 = front_face_locations.index(
                            max(front_face_locations, key=lambda loc: (loc[2] - loc[0]) * (loc[3] - loc[1])))

                        face_encoding1 = national_id_front_face_encodings[largest_face_index1]
                        face_encoding2 = front_face_encodings[largest_face_index2]

                        similarity = self.calculate_similarity(face_encoding1, face_encoding2)

                        logging.info(
                            f'----------------Time taken for face extraction for matching passport with front id: {time.time() - st} seconds\n')
                        result["similarity_score"] = similarity
                        logging.info(f"Front ID and Passport similarity score: {similarity}")
                        if similarity < 0.5:
                            result["error"] = 'face_mismatch'
                            return {"error": "face_mismatch",
                                    "error_details": "Front ID and Passport Face dont match."}
                        
                    except Exception as e:
                        logging.info(f"Error in face matching between passport and national id: {e}")
                        result["error"] = 'covered_photo'
                        result["error_details"] = e
                        return result
                        
                data_temp = {
                        'passport_data': "",
                        'front_coloured': True,
                        'back_coloured': True,
                        'front_logo_result': 'clear',
                        'front_doc_on_pp': "clear",
                        'front_screenshot_result': 'clear',
                        'front_photo_on_screen_result': 'clear',
                        'doc_on_pp': "clear",
                        'screenshot_result': 'clear',
                        'photo_on_screen_result': 'clear',
                        'front_blurred': 'front_blurred',
                        'front_glare': 'front_glare',
                        'back_blurred': 'front_blurred',
                        'back_glare': 'front_glare',
                        'front_face_locations': front_face_locations_str,
                        'front_face_encodings': front_face_encodings_str,
                        'issuing_country': 'IRQ',
                        'nationality_received': nationality_to_check
                    }
                
                result.update(data_temp)

                from idvpackage.ocr_utils import validation_checks_passport
                validation_results = validation_checks_passport(passport_data, 'id_number', 'IRQ')
                logging.info(f"validation_results: {json.dumps(validation_results, ensure_ascii=False, indent=2)}")
                result.update(validation_results)

                from idvpackage.ocr_utils import get_name_match_mrz
                result['is_name_match_mrz'], result['name_mrz'] = get_name_match_mrz(result, "passport")

                return result
            
            except Exception as e:
                result['error'] = 'bad_image'
                result['error_details'] = str(e)
                logging.info(f"Exception details: {e}")
                return result

        if (nationality and nationality == "LBN") or (
            not nationality and country == "LBN"
        ):
            logging.info("-------------Working on LBN Passport \n")
            from idvpackage.blur_detection import is_image_blur
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.lebanon_id_extraction import get_response_from_openai_lbn
            from idvpackage.ocr_utils import  detect_screenshot

            result = {"error": "", "doc_type": "passport"}

            try:
                st = time.time()
                processed_passport, compressed_image_data = self.image_conversion_and_compression(passport)
                logging.info(f"----------------Time taken for image conversion passport: {time.time() - st} seconds\n")

                st = time.time()
                image = np.array(processed_passport)
                if country == "LBN" and is_image_blur(
                    image,
                    laplace_threshold=30,
                    canny_threshold=1500,
                    fft_threshold=120,
                    bright_reflection_min_area=1.0,
                ):
                    logging.info("Blur/Brightness issue detected in front image, marking as covered photo")
                    result["error"] = "blur_photo"
                    return result

                st = time.time()
                passport_data = get_response_from_openai_lbn(compressed_image_data,"first", self.openai_key)
                logging.info(
                    f"----------------Time taken for OpenAI and  final extraction passport: {time.time() - st} seconds\n"
                )
                logging.info(f"passport_data: {json.dumps(passport_data, ensure_ascii=False, indent=2)}")

                if not passport_data.get('header_verified', False):
                    result["error"] = "not_passport"
                    return result
                dob = passport_data.get('dob', '')
                if  dob:
                    from idvpackage.ocr_utils import is_age_18_above
                    is_legal_age = is_age_18_above(dob)
                    logging.info(f"is_legal_age: {is_legal_age}")
                    if not is_legal_age:
                        passport_data['error'] = 'under_age'
                        return passport_data
                else:
                    passport_data['error'] = 'missing_key_fields'
                    logging.error(f"DOB date not found in the extracted data.")
                    return passport_data

                from idvpackage.ocr_utils import is_expired_id

                try:
                    if is_expired_id(passport_data.get('expiry_date', None)):
                        passport_data['error'] = 'expired_id'
                        logging.info(f"ID is expired with expiry date: {passport_data.get('expiry_date','')}")
                        return passport_data

                except Exception as e:
                    logging.info(f"Error in expiry date check: {e}")

                passport_data['mrz'] = passport_data.get('mrz1', '')  + passport_data.get('mrz2', '')
                passport_data['full_name'] = passport_data.get('first_name', '') + ' ' + passport_data.get('last_name', '')
                passport_data['issuing_country'] = 'LBN'

                full_name = (passport_data.get("mother_name") or "").strip().split()
                passport_data["mother_first_name"] = full_name[0] if full_name else ""
                passport_data["mother_last_name"] = " ".join(full_name[1:]) if len(full_name) > 1 else ""

                full_name_en = (passport_data.get("mother_name_en") or "").strip().split()
                passport_data["mother_first_name_en"] = full_name_en[0] if full_name_en else ""
                passport_data["mother_last_name_en"] = " ".join(full_name_en[1:]) if len(full_name_en) > 1 else ""

                result.update(passport_data)
                from idvpackage.ocr_utils import validation_checks_passport
                validation_results = validation_checks_passport(result, 'id_number', 'LBN')
                logging.info(f"validation_results: {json.dumps(validation_results, ensure_ascii=False, indent=2)}")
                result.update(validation_results)

                from idvpackage.ocr_utils import get_name_match_mrz
                result['is_name_match_mrz'], result['name_mrz'] = get_name_match_mrz(result, "passport")

                image = np.array(processed_passport)
                st = time.time()
                doc_on_pp_result = "clear"
                screenshot_result = detect_screenshot(self.client, passport)
                photo_on_screen_result = "clear"
                blurred, glare = self.get_blurred_and_glared_for_doc(image)
                logging.info(f"Nationality: {passport_data.get('nationality')}")
                valid_nationality_result = self.check_nationality_in_iso_list(
                    passport_data.get("nationality")
                )
                logging.info(f"----------------Time taken for fraud detection attributes passport: {time.time() - st} seconds\n")

                st = time.time()
                front_face_locations, front_face_encodings = (load_and_process_image_deepface(passport))
                logging.info(
                    f"----------------Time taken for face extraction passport: {time.time() - st} seconds\n"
                )
                
                if front_face_encodings is None or len(front_face_encodings) == 0:
                    result["error"] = "face_not_detected"
                    logging.info("No face detected in passport image")
                    return result

                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )

                result_update = {
                    "passport_data": "",
                    "front_coloured": True,
                    "back_coloured": True,
                    "front_logo_result": "clear",
                    "front_doc_on_pp": doc_on_pp_result,
                    "front_screenshot_result": screenshot_result,
                    "front_photo_on_screen_result": photo_on_screen_result,
                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "front_blurred": blurred,
                    "front_glare": glare,
                    "back_blurred": blurred,
                    "back_glare": glare,
                    'nationality_received': nationality,
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                    "valid_nationality": valid_nationality_result,
                }

                result.update(result_update)
                non_optional_keys = [
                    "front_face_locations",
                    "id_number",
                    "dob",
                    "first_name",
                    "last_name",
                    "expiry_date",
                ]
                empty_string_keys = [
                    key
                    for key, value in result.items()
                    if key in non_optional_keys and (value == "" or value == [] or value == "[]")
                        
                ]

                if empty_string_keys:
                    result["error"] = "missing_key_fields"
                    logging.info(f"Empty keys found: {empty_string_keys}")
                   

            except Exception as e:
                result["error"] = "bad_image"
                result["error_details"] = e
                logging.info(f"Exception details: {e}")

            return result

        if (nationality and nationality == "SDN") or (
            not nationality and country == "SDN"
        ):
            logging.info("-------------Working on SDN Passport \n")
            from idvpackage.blur_detection import is_image_blur
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.ocr_utils import  detect_screenshot
            from idvpackage.sudan_passport_extraction import get_response_from_openai_sdn
            
            result = {"error": "", "doc_type": "passport"}
            try:
                st = time.time()
                processed_passport, compressed_image_data = self.image_conversion_and_compression(passport)
                logging.info(
                    f"----------------Time taken for image conversion passport: {time.time() - st} seconds\n"
                )

                st = time.time()
                image = np.array(processed_passport)
                if country == "SDN":
                    if is_image_blur(
                        image,
                        laplace_threshold=20,
                        canny_threshold=1500,
                        fft_threshold=100,
                        bright_reflection_threshold=100,
                        bright_reflection_min_area=1.0,
                    ):
                        logging.info(f"Passport Document is blurry, marking as covered photo")
                        result["error"] = "blur_photo"
                        return result

                st = time.time()
                passport_data = get_response_from_openai_sdn(compressed_image_data, "passport", self.openai_key)

                logging.info(f"Passport details extracted: {json.dumps(passport_data, ensure_ascii=False, indent=2)}")
                logging.info(f"----------------Time taken for OpenAI and  final extraction passport: {time.time() - st} seconds\n")

                if not passport_data.get('header_verified', False):
                    result["error"] = "not_passport"
                    return result
            
                passport_data['mrz'] = passport_data.get('mrz1','') + passport_data.get('mrz2','')
                passport_data['issuing_country'] = 'SDN'
                passport_data['nationality_received'] = 'SDN'
                passport_data['nationality'] = 'SDN'

                passport_data['full_name'] = passport_data.get('first_name','')+ passport_data.get('last_name','')   

                from idvpackage.ocr_utils import is_expired_id
                if is_expired_id(passport_data.get('expiry_date', None)):
                    result['error'] = 'expired_id'
                    logging.info(f"ID is expired with expiry date: {passport_data.get('expiry_date','')}")
                    return result
                
                from idvpackage.ocr_utils import is_age_18_above
                if not is_age_18_above(passport_data.get('dob', None)):
                    result['error'] = 'under_age'
                    logging.info("Passport holder is under age")
                    return result

                passport_data['passport_number_mrz'] = passport_data.get('passport_number','')

                if passport_data.get("name_en", ""):
                    passport_data['full_name_generic'] = passport_data.get("name_en","")
                else:
                    passport_data['full_name_generic'] = passport_data.get("first_name","") + " " + passport_data.get("middle_name","") + " " + passport_data.get("last_name","")
                
                result.update(passport_data)

                from idvpackage.ocr_utils import validation_checks_passport
                validation_results = validation_checks_passport(result, 'passport_number', 'SDN')
                logging.info(f"validation_results: {json.dumps(validation_results, ensure_ascii=False, indent=2)}")

                result.update(validation_results)

                from idvpackage.ocr_utils import get_name_match_mrz
                result['is_name_match_mrz'], result['name_mrz'] = get_name_match_mrz(result, "passport")

                if result.get("issue_date"):
                    result["issuance_date"] = passport_data["issue_date"]

                image = np.array(processed_passport)

                st = time.time()
                doc_on_pp_result = "clear"
                screenshot_result = detect_screenshot(self.client, passport)
                photo_on_screen_result = "clear"
                blurred, glare = self.get_blurred_and_glared_for_doc(image)
                valid_nationality_result = self.check_nationality_in_iso_list(passport_data.get("nationality"))
                logging.info(f"----------------Time taken for fraud detection attributes passport: {time.time() - st} seconds\n")

                st = time.time()
                front_face_locations, front_face_encodings = (
                    load_and_process_image_deepface(passport, country="SDN")
                )
                logging.info(
                    f"----------------Time taken for face extraction passport: {time.time() - st} seconds\n"
                )
                
                if front_face_encodings is None or len(front_face_encodings) == 0:
                    result["error"] = "face_not_detected"
                    logging.info("No face detected in passport image")
                    return result

                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )

                result_update = {
                    "passport_data": "",
                    "front_coloured": True,
                    "back_coloured": True,
                    "front_logo_result": "clear",
                    "front_doc_on_pp": doc_on_pp_result,
                    "front_screenshot_result": screenshot_result,
                    "front_photo_on_screen_result": photo_on_screen_result,
                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "front_blurred": blurred,
                    "front_glare": glare,
                    "back_blurred": blurred,
                    "back_glare": glare,
                    'nationality_received': nationality,
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                    "valid_nationality": valid_nationality_result,
                    "nationality_received": nationality,
                }

                result.update(result_update)
                non_optional_keys = [
                    "passport_number",
                    "dob",
                    "expiry_date",
                    "gender",
                ]
                empty_string_keys = [
                    key
                    for key, value in result.items()
                    if key in non_optional_keys and value == ""
                ]

                if empty_string_keys:
                    result["error"] = "missing_key_fields"
                    logging.info(f"Empty keys found: {empty_string_keys}")

            except Exception as e:
                result["error"] = "bad_image"
                logging.info(f"-------------->> Something went wrong error trace:: {e}")
                result["error_details"] = e

            return result

        if (nationality and nationality == "SYR") or (
            not nationality and country == "SYR"
        ):
            logging.info("-------------Working on SYR Passport \n")
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.ocr_utils import detect_screenshot

            from idvpackage.syr_passport_extraction import get_response_from_openai_syr
            passport_data = {"error": "", "doc_type": "passport"}

            try:
                st = time.time()
                processed_passport = self.image_conversion(passport)
                st = time.time()
                passport_details = get_response_from_openai_syr(processed_passport, "page1", country, self.openai_key)
                logging.info(
                    f"----------------Time taken for OpenAI and  final extraction passport: {time.time() - st} seconds\n"
                )
                logging.info(f"passport_details: {json.dumps(passport_details, ensure_ascii=False, indent=2)}")

                if not passport_details.get('header_verified', False):
                    passport_data["error"] = "not_passport"
                    return passport_data
                
                if passport_details.get('dob', None):
                    from idvpackage.ocr_utils import is_age_18_above
                    if not is_age_18_above(passport_details.get('dob', None)):
                        passport_data['error'] = 'under_age'
                        logging.info("Passport holder is under age")
                        return passport_data
                       
                passport_details['full_name'] = passport_details.get('first_name','') + ' ' + passport_details.get('last_name','')
                passport_details['nationality'] = "SYR"
                passport_details['mrz'] = passport_details.get('mrz1','') + passport_details.get('mrz2','')
                
                #check is passport_number is all digits and len is 9
                if  passport_details.get('passport_number', '').isdigit() and  len(passport_details.get('passport_number', '')) == 9:
                    passport_details['id_number'] = passport_details.get('passport_number','')        
                elif passport_details.get('passport_number_mrz', '').isdigit() and len(passport_details.get('passport_number_mrz', '')) == 9:
                    passport_details['id_number'] = passport_details.get('passport_number_mrz','')
                else:
                    passport_details['id_number'] = ''

                mrz2 = passport_details.get('mrz2','')
                mrz2 = mrz2.strip()
                logging.info(f"mrz2: {mrz2}")
                mrz2 = mrz2[-16:]
                logging.info(f"mrz2: last 16 chars: {mrz2}")
                mrz2 = mrz2.split("<<")[0].replace('<','')
                passport_details['national_number_mrz_regex'] = mrz2
                
                if passport_details.get('gender_mrz','').upper() =='M':
                    passport_details['gender_mrz'] = 'MALE'
                elif passport_details.get('gender_mrz','').upper() =='F':
                    passport_details['gender_mrz'] = 'FEMALE'
                    
                if passport_details.get('gender','').upper() =='M':
                    passport_details['gender'] = 'MALE'
                elif passport_details.get('gender','').upper() =='F':
                    passport_details['gender'] = 'FEMALE'

                from idvpackage.ocr_utils import get_name_match_mrz
                passport_details['is_name_match_mrz'], passport_details['name_mrz'] = get_name_match_mrz(passport_details, "passport")
            
                logging.info(f"----------------Passport details front: {json.dumps(passport_details, indent=2, ensure_ascii=False)}\n")
                logging.info(f"----------------Time taken for OpenAI and  final extraction passport: {time.time() - st} seconds\n")

                passport_data.update(passport_details)

                image = np.array(processed_passport)

                st = time.time()
              
                doc_on_pp_result = "clear"
                screenshot_result = detect_screenshot(self.client, passport)
                photo_on_screen_result = "clear"
                blurred, glare = self.get_blurred_and_glared_for_doc(image)
                valid_nationality_result = self.check_nationality_in_iso_list(
                    passport_details.get("nationality")
                )
                logging.info(f"----------------Time taken for fraud detection attributes passport: {time.time() - st} seconds\n")
                st = time.time()
                front_face_locations, front_face_encodings = (load_and_process_image_deepface(passport))
                logging.info(f"----------------Time taken for face extraction passport: {time.time() - st} seconds\n")


                if front_face_encodings is None or len(front_face_encodings) == 0:
                    passport_data["error"] = "face_not_detected"
                    logging.info("No face detected in passport image")
                    return passport_data
                
                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )

                passport_data_update = {
                    "passport_data": "",
                    "front_coloured": True,
                    "back_coloured": True,
                    "front_logo_result": "clear",
                    "front_doc_on_pp": doc_on_pp_result,
                    "front_screenshot_result": screenshot_result,
                    "front_photo_on_screen_result": photo_on_screen_result,
                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "front_blurred": blurred,
                    "front_glare": glare,
                    "back_blurred": blurred,
                    "back_glare": glare,
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                    "valid_nationality": valid_nationality_result,
                    "nationality_received": nationality,
                    "issuing_country": nationality,
                }

                passport_data.update(passport_data_update)

                non_optional_keys = ["passport_number", "dob", "gender"]
                empty_string_keys = [
                    key
                    for key, value in passport_data.items()
                    if key in non_optional_keys and value == ""
                ]
                if empty_string_keys:
                    passport_data["error"] = "missing_key_fields"

            except Exception as e:
                passport_data["error"] = "bad_image"
                passport_data["error_details"] = e
                logging.error(f"Error processing SYR passport: {e}")

            return passport_data

        if (nationality and nationality == "JOR") or (
            not nationality and country == "JOR"
        ):
            logging.info("-------------Working on JOR Passport \n")
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.jor_passport_extraction import get_response_from_openai_jor
            from idvpackage.ocr_utils import  detect_screenshot
            
            passport_data = {"error": "", "doc_type": "passport"}
            try:
                st = time.time()
                logging.info("Performing image conversion for passport")
                processed_passport = self.image_conversion(passport)
                logging.info(f"----------------Time taken for image conversion passport: {time.time() - st} seconds\n")

                logging.info("Performing OCR for passport using openai.......")
                st = time.time()
                passport_details = get_response_from_openai_jor(processed_passport, "first", nationality, self.openai_key)

                logging.info(f"----------------Passport details: {json.dumps(passport_details, indent=4, ensure_ascii=False)}\n")
                logging.info(f"----------------Time taken for openai final extraction passport: {time.time() - st} seconds\n")

                if not passport_details.get("header_verified", False):
                    passport_data["error"] = "not_passport"
                    return passport_data

                from idvpackage.ocr_utils import is_expired_id
                if is_expired_id(passport_details.get('expiry_date', None)):
                    passport_data['error'] = 'expired_id'
                    logging.info(f"ID is expired with expiry date: {passport_details.get('expiry_date','')}")
                    return passport_data

                if passport_details.get('dob', None):
                    from idvpackage.ocr_utils import is_age_18_above
                    if not is_age_18_above(passport_details.get('dob', None)):
                        passport_data['error'] = 'under_age'
                        logging.info("Passport holder is under age")
                        return passport_data
                
                  # append mrz1 and mrz2 from passport_details and make it as list
                passport_details['full_name'] = passport_details.get('first_name','') +  ' ' + passport_details.get('last_name','')  
                passport_details['mrz'] = [passport_details.get('mrz1','') + ' ' + passport_details.get('mrz2','')]
                passport_details['issuing_place'] = passport_details.get('place_of_issue','')
                passport_details['issue_date'] = passport_details.get('issuing_date','')
                        
                passport_data.update(passport_details)
               
                from idvpackage.ocr_utils import validation_checks_passport
                validation_results = validation_checks_passport(passport_data, 'passport_number', 'JOR')
                logging.info(f"validation_results: {json.dumps(validation_results, ensure_ascii=False, indent=2)}")
                passport_data.update(validation_results)
                logging.info(f"Passport data after validation checks: {json.dumps(passport_data, ensure_ascii=False, indent=2)}")
                
                from idvpackage.ocr_utils import get_name_match_mrz
                passport_data['is_name_match_mrz'], passport_data['name_mrz'] = get_name_match_mrz(passport_data, "passport")

                image = np.array(processed_passport)

                st = time.time()
                doc_on_pp_result = "clear"
                screenshot_result = detect_screenshot(self.client, passport)
                photo_on_screen_result = "clear"
                blurred, glare = self.get_blurred_and_glared_for_doc(image)
                valid_nationality_result = self.check_nationality_in_iso_list(
                    passport_details.get("nationality")
                )
                logging.info(f"----------------Time taken for fraud detection attributes passport: {time.time() - st} seconds\n")

                st = time.time()
                front_face_locations, front_face_encodings = (
                    load_and_process_image_deepface(passport)
                )
                logging.info(f"----------------Time taken for face extraction passport: {time.time() - st} seconds\n")

                if front_face_encodings is None or len(front_face_encodings) == 0:
                    passport_data["error"] = "face_not_detected"
                    logging.info("No face detected in passport image")
                    return passport_data
                
                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )

                passport_data_update = {
                    "passport_data": "",
                    "front_coloured": True,
                    "back_coloured": True,
                    "front_logo_result": "clear",
                    "front_doc_on_pp": doc_on_pp_result,
                    "front_screenshot_result": screenshot_result,
                    "front_photo_on_screen_result": photo_on_screen_result,
                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "front_blurred": blurred,
                    "front_glare": glare,
                    "back_blurred": blurred,
                    "back_glare": glare,
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                    "valid_nationality": valid_nationality_result,
                    "nationality_received": nationality,
                    "issuing_country": nationality,
                }

                passport_data.update(passport_data_update)

                non_optional_keys = ["passport_number", "dob", "expiry_date", "gender"]
                empty_string_keys = [
                    key
                    for key, value in passport_data.items()
                    if key in non_optional_keys and value == ""
                ]

                if empty_string_keys:
                    passport_data["error"] = "missing_key_fields"

            except Exception as e:
                passport_data["error"] = "bad_image"
                logging.error(f"Error processing JOR passport: {e}")
                passport_data["error_details"] = e

            return passport_data

        if (nationality and nationality == "PSE") or (
            not nationality and country == "PSE"
        ):
            logging.info("-------------Working on PSE Passport \n")
            from idvpackage.common import load_and_process_image_deepface
            from idvpackage.ocr_utils import detect_screenshot
            from idvpackage.pse_passport_extraction import get_response_from_openai_pse
            passport_data = {"error": "", "doc_type": "passport"}

            try:
                st = time.time()
                processed_passport = self.image_conversion(passport)
                st = time.time()
                try:
                    passport_details = get_response_from_openai_pse(
                        processed_passport,"first",nationality,self.openai_key
                    )
                    logging.info(f"passport_details {json.dumps(passport_details, indent=4, ensure_ascii=False)}")
                except Exception as e:
                    logging.error(f"Error in PSE passport extraction: {e}")
                logging.info(
                    f"----------------Time taken for OpenAI and  final extraction passport: {time.time() - st} seconds\n"
                )

                if not passport_details.get("header_verified", False):
                    passport_data["error"] = "not_passport"
                    return passport_data

                if passport_details.get('dob', None):
                    from idvpackage.ocr_utils import is_age_18_above
                    if not is_age_18_above(passport_details.get('dob', None)):
                        passport_data['error'] = 'under_age'
                        logging.info("Passport holder is under age")
                        return passport_data
                    
                from idvpackage.ocr_utils import is_expired_id
                if is_expired_id(passport_details.get('expiry_date', None)):
                    passport_data['error'] = 'expired_id'
                    logging.info(f"ID is expired with expiry date: {passport_details.get('expiry_date','')}")
                    return passport_data
                
                passport_details['nationality'] = 'PSE'
                passport_details['full_name_openai'] = passport_details.get('full_name','')
                passport_details['full_name'] = passport_details.get('first_name','') + ' ' + passport_details.get('last_name','')
                passport_details['mrz'] = passport_details.get('mrz1','') + passport_details.get('mrz2','')
                passport_details['issue_date'] = passport_details.get('issuing_date','')
                
                
                passport_data.update(passport_details)
                image = np.array(processed_passport)

                st = time.time()
                doc_on_pp_result = "clear"
                screenshot_result = detect_screenshot(self.client, passport)
                photo_on_screen_result = "clear"
                blurred, glare = self.get_blurred_and_glared_for_doc(image)
                valid_nationality_result = self.check_nationality_in_iso_list(
                    passport_details.get("nationality")
                )
                logging.info(
                    f"----------------Time taken for fraud detection attributes passport: {time.time() - st} seconds\n"
                )
                st = time.time()
                front_face_locations, front_face_encodings = (
                    load_and_process_image_deepface(passport)
                )
                logging.info(
                    f"----------------Time taken for face extraction passport: {time.time() - st} seconds\n"
                )
                
                if front_face_encodings is None or len(front_face_encodings) == 0:
                    passport_data["error"] = "face_not_detected"
                    logging.info("No face detected in passport image")
                    return passport_data
                
                front_face_locations_str = json.dumps(
                    [tuple(face_loc) for face_loc in front_face_locations]
                )
                front_face_encodings_str = json.dumps(
                    [face_enc.tolist() for face_enc in front_face_encodings]
                )

                passport_data_update = {
                    "passport_data": "",
                    "front_coloured": True,
                    "back_coloured": True,
                    "front_logo_result": "clear",
                    "front_doc_on_pp": doc_on_pp_result,
                    "front_screenshot_result": screenshot_result,
                    "front_photo_on_screen_result": photo_on_screen_result,
                    "doc_on_pp": doc_on_pp_result,
                    "screenshot_result": screenshot_result,
                    "photo_on_screen_result": photo_on_screen_result,
                    "front_blurred": blurred,
                    "front_glare": glare,
                    "back_blurred": blurred,
                    "back_glare": glare,
                    "front_face_locations": front_face_locations_str,
                    "front_face_encodings": front_face_encodings_str,
                    "valid_nationality": valid_nationality_result,
                    "nationality_received": nationality,
                    "issuing_country": nationality,
                }

                passport_data.update(passport_data_update)

                from idvpackage.ocr_utils import validation_checks_passport
                validation_results = validation_checks_passport(passport_details, 'id_number', 'PSE')
                logging.info(f"validation_results: {json.dumps(validation_results, ensure_ascii=False, indent=2)}")
                passport_data.update(validation_results)

                from idvpackage.ocr_utils import get_name_match_mrz
                passport_data['is_name_match_mrz'], passport_data['name_mrz'] = get_name_match_mrz(passport_data, "passport")
                
                
                non_optional_keys = ["passport_number", "dob", "expiry_date", "gender"]
                empty_string_keys = [
                    key
                    for key, value in passport_data.items()
                    if key in non_optional_keys and value == ""
                ]
                if empty_string_keys:
                    passport_data["error"] = "missing_key_fields"

            except Exception as e:
                passport_data["error"] = "bad_image"
                passport_data["error_details"] = e

            return passport_data

    def extract_passport_info_back(self, passport, country, nationality, step_data=None):
        if (nationality and nationality == "SYR") or (
            not nationality and country == "SYR"
        ):
            from idvpackage.syr_passport_extraction import get_response_from_openai_syr

            passport_data = {"error": "", "doc_type": "passport"}

            try:
                st = time.time()
                processed_passport = self.image_conversion(passport)
                logging.info(f"----------------Time taken for image conversion passport: {time.time() - st} seconds\n")
                
                st = time.time()
                passport_details = get_response_from_openai_syr(processed_passport, "page2", country, self.openai_key)
                logging.info(f"----------------Passport details back: {json.dumps(passport_details, indent=2, ensure_ascii=False)}\n")
                logging.info(f"----------------Time taken for OpenAI and  final extraction passport: {time.time() - st} seconds\n")

                passport_details['issuing_date'] = passport_details.get('issue_date','')
                passport_data.update(passport_details)
                
                from idvpackage.ocr_utils import is_expired_id
                if is_expired_id(passport_details.get('expiry_date', None)):
                    passport_data['error'] = 'expired_id'
                    logging.info(f"ID is expired with expiry date: {passport_details.get('expiry_date','')}")
                    return passport_data
                                
                temp_data = {}
                if step_data:
                    temp_data.update(step_data)
                temp_data.update(passport_details)
                
                logging.info(f"temp_data for validation: {json.dumps(temp_data, ensure_ascii=False, indent=2)}")
                from idvpackage.ocr_utils import validation_checks_passport
                validation_results = validation_checks_passport(temp_data, 'passport_number', 'SYR')
                logging.info(f"validation_results: {json.dumps(validation_results, ensure_ascii=False, indent=2)}")
                passport_data.update(validation_results)
                
                non_optional_keys = ["issuing_date", "expiry_date"]
                empty_string_keys = [
                    key
                    for key, value in passport_data.items()
                    if key in non_optional_keys and value == ""
                ]

                if empty_string_keys:
                    passport_data["error"] = "missing_key_fields"

            except Exception as e:
                passport_data["error"] = "bad_image"
                passport_data["error_details"] = e

        return passport_data

    def extract_ocr_info(self, data, video, country, report_names, back_img=None):

        try:
            if data.get("uae_pass_data", ""):
                uae_pass_data = data.get("uae_pass_data", {})
                if uae_pass_data:
                    dob = uae_pass_data.get("DateOfBirth", "")
                    if dob:
                        data["dob"] = dob

                    expiry_date = uae_pass_data.get("expiryDate", "")
                    if expiry_date:
                        data["expiry_date"] = expiry_date

                    gender = uae_pass_data.get("genderCode", "")
                    if gender:
                        data["gender"] = gender

                    nationality = uae_pass_data.get("nationalityCode", "")
                    if nationality:
                        data["nationality_received"] = nationality

            st = time.time()
            from idvpackage.ocr_utils import (
                form_final_data_document_report,
                form_final_facial_similarity_report,
            )

            face_match_threshold = 0.59
            document_report = {}
            facial_report = {}

            if country == "IRQ":
                face_match_threshold = 0.5

            if country == "LBN":
                face_match_threshold = 0.50

            if country == "SDN":
                face_match_threshold = 0.40

            tampering_result = "clear"
            data["tampering_result"] = tampering_result

            if (
                data.get("front_tampered_result") == "Tampered"
                or data.get("back_tampered_result") == "Tampered"
            ):
                tampering_result = "consider"
                data["tampering_result"] = tampering_result

            if country == "IRQ" and data.get("doc_type") == "national_identity_card":
                if not data.get("gender") and data.get("gender_back"):
                    data["gender"] = data.get("gender_back")

            colour_picture = "consider"
            if data.get("front_coloured") and data.get("back_coloured"):
                colour_picture = "clear"

            blurred = "clear"
            if (
                data.get("front_blurred") == "consider"
                or data.get("back_blurred") == "consider"
            ):
                blurred = "consider"

            glare = "clear"
            if (
                data.get("front_glare") == "consider"
                or data.get("back_glare") == "consider"
            ):
                glare = "consider"

            missing_fields = "clear"
            if data.get("front_missing_fields") or data.get("back_missing_fields"):
                missing_fields = "consider"

            if video and data.get("front_face_locations", ""):
                face_loc = json.loads(data.get("front_face_locations"))
                front_face_locations = tuple(face_loc)
                front_face_encodings = np.array(
                    json.loads(data.get("front_face_encodings"))
                )

                data["front_face_locations"] = front_face_locations
                data["front_face_encodings"] = front_face_encodings

                selfie_str = data.get("selfie")
                if isinstance(selfie_str, str):
                    selfie = np.array(json.loads(selfie_str))
                else:
                    selfie = selfie_str

                try:
                    similarity = self.extract_face_and_compute_similarity(
                        selfie, front_face_locations, front_face_encodings
                    )
                except Exception as e:
                    logging.info("issue in extracting face and computing similarity")
                    selfie = None
                    similarity = 0

            else:
                selfie = None
                similarity = 0

            if country == "SAU" or data.get("doc_type") == "passport":
                back_id_text = ""
            else:
                back_id_text = data.get("back_extracted_data")

            if data.get("doc_type") == "national_identity_card":
                front_id_text = data.get("front_extracted_data")
            else:
                front_id_text = ""

            try:
                logging.info(f"nationality check data: {data.get('nationality_received', '')}\n")
                nationality = data.get("nationality_received", "")
            except:
                pass

            if "document" in report_names:
                if nationality and not data.get("uae_pass_data", ""):
                    logging.info(
                        f"\nNationality present, picking  {nationality} for generating Document Report"
                    )
                    document_report = form_final_data_document_report(
                        data,
                        front_id_text,
                        back_id_text,
                        nationality,
                        colour_picture,
                        selfie,
                        similarity,
                        blurred,
                        glare,
                        missing_fields,
                        face_match_threshold,
                        back_img,
                    )
                else:
                    logging.info(
                        f"\nNationality not present, picking country: {country} for generating Document Report"
                    )
                    document_report = form_final_data_document_report(
                        data,
                        front_id_text,
                        back_id_text,
                        country,
                        colour_picture,
                        selfie,
                        similarity,
                        blurred,
                        glare,
                        missing_fields,
                        face_match_threshold,
                        back_img,
                    )

                if document_report:
                    if country == "IRQ" and nationality in ["LBN", "PSE"]:
                        document_report["properties"].pop("id_number", None)

                    if country == "IRQ" and nationality in ["JOR", "SYR"]:
                        document_report["properties"].pop("passport_number", None)

                    if country == "IRQ" and nationality in ["SDN"]:
                        document_report["properties"].pop("passport_number_mrz", None)

            if 'facial_similarity_video' in report_names:
                if video:
                    logging.info("--------------Checking for liveness-----------\n")
                    liveness_result = self.check_for_liveness(video)
                    logging.info(f"--------------Liveness Result from portal video: {liveness_result}\n")
                    if country == "IRQ":
                        liveness_result = "clear"
                else:
                    liveness_result = None

                if nationality:
                    logging.info(f"Nationality present, picking nationality: {nationality} for generating Video Report")
                    facial_report = form_final_facial_similarity_report(
                        data,
                        selfie,
                        similarity,
                        liveness_result,
                        face_match_threshold,
                        nationality,
                    )
                else:
                    logging.info(f"Nationality not present, picking country: {country} for generating Video Report")
                    facial_report = form_final_facial_similarity_report(
                        data,
                        selfie,
                        similarity,
                        liveness_result,
                        face_match_threshold,
                        country,
                    )

            logging.info(f"--------------Time taken for Extract Ocr Function in IDV package: {time.time() - st} seconds\n")
            return document_report, facial_report

        except Exception as e:
            logging.info(f"--------------Error occurred in extract_ocr_info: {e}\n")
            raise Exception("Error occurred in extract_ocr_info")

    def generate_facial_report_portal(self, data, latest_portal_video):
        from idvpackage.common import load_and_process_image_deepface_topup
        from idvpackage.ocr_utils import form_final_facial_similarity_report

        try:
            if latest_portal_video:
                logging.info("--------------Checking for liveness-----------\n")
                latest_vid_liveness_result = self.check_for_liveness(latest_portal_video)
                logging.info(
                    f"--------------Liveness Result from portal video: {latest_vid_liveness_result}\n"
                )
            initial_selfie_str = data.get("initial_selfie", "")
            latest_selfie_str = data.get("latest_selfie", "")

            if isinstance(initial_selfie_str, str):
                initial_selfie = np.array(json.loads(initial_selfie_str))
            else:
                initial_selfie = initial_selfie_str

            if isinstance(latest_selfie_str, str):
                latest_selfie = np.array(json.loads(latest_selfie_str))
            else:
                latest_selfie = latest_selfie_str

            onboarding_face_encodings =  load_and_process_image_deepface_topup(initial_selfie)
            top_up_face_encodings = load_and_process_image_deepface_topup(latest_selfie)

            if not onboarding_face_encodings:
                logging.info("No face detected in Onboarding Video")
                similarity_score = 0
            elif not top_up_face_encodings:
                logging.info("No face detected in Top-up Video")
                similarity_score = 0
            else:
                similarity_score = self.calculate_similarity(
                    onboarding_face_encodings[0], top_up_face_encodings[0]
                )
                similarity_score = min(1, similarity_score)

                logging.info(f"--------------Face Similarity Computed: {similarity_score}\n")

            facial_report = form_final_facial_similarity_report(
                data,
                latest_selfie,
                similarity_score,
                latest_vid_liveness_result,
                0.69,
                "IRQ",
            )

            logging.info(f"Facial Report: {facial_report}")
            return facial_report

        except Exception as e:
            logging.info(f"--------------Error occurred in generate_facial_report_portal: {e}\n")
            raise Exception("Error occurred in generate_facial_report for portal")