# from minio import Minio
import boto3


def getClient(config):
    """
    A module for interacting with AWS S3 using the boto3 library.
    This module provides functionality to connect to and perform operations on AWS S3 buckets.
    It uses the boto3 library, which is the Amazon Web Services (AWS) SDK for Python.
    """
    
    secure = "https" if config["registry"]["secure"] else "http"
    
    s3_client = boto3.client('s3', 
        endpoint_url=f"{secure}://{config['registry']['host']}",
        aws_access_key_id=config["registry"]["access_key"],
        aws_secret_access_key=config["registry"]["secret_key"],
        aws_session_token=None,
        config=boto3.session.Config(signature_version='s3v4'),
        verify=False
    )

    return s3_client
