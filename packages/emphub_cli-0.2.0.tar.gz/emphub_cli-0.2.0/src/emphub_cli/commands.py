import click
import os
from tabulate import tabulate
from .operations import pullPackage, pushPackage, getConfig
from .func import sizeof_fmt
from .s3helpers import getClient


CONFIG_PATH = os.getenv("CONFIG_PATH", os.path.expanduser("~/.emp/config.yaml"))


@click.command()
@click.argument("package")
@click.option("--device", "-d", help="Device to program.")
def run():
    click.echo("Running the package")


@click.command()
@click.argument("package")
def pull(package):
    if ":" in package:
        package, tag = package.split(":")
    else:
        tag = "latest"
    click.echo(f"Pulling {package}:{tag}...")
    obj, delta = pullPackage(package, tag, getConfig(CONFIG_PATH))
    click.echo(f"Downloaded package ({sizeof_fmt(obj['ContentLength'])}) in {delta.total_seconds()}s")


@click.command()
@click.argument("package")
@click.option("--path", "-p", type=click.Path(exists=True))
def push(package, path=None):
    if ":" in package:
        package, tag = package.split(":")
    else:
        tag = "latest"
    config = getConfig(CONFIG_PATH)
    if not path:
        path = f"{os.path.expanduser(config['local-storage']['path'])}/{package}/{tag}/package.tgz"
    click.echo(f"Pushing {package}:{tag} to registry...")
    size, delta = pushPackage(package, tag, path, config)
    click.echo(f"Uploaded package ({sizeof_fmt(size)}) in {delta.total_seconds()}s")


@click.command()
@click.argument("package")
def tags(package: str):
    config = getConfig(CONFIG_PATH)
    client = getClient(config)
    bucket = config["registry"]["bucket"]
    objects = client.list_objects_v2(Bucket=bucket, Prefix=f"{package}/")["Contents"]
    if len(objects) > 0:
        tags_table = []
        click.echo(f"Tags for {package}:")
        for obj in objects:
            tags_table.append([
                obj["Key"].split("/")[1],
                sizeof_fmt(obj["Size"]),
                obj["LastModified"].strftime("%Y-%m-%d %H:%M:%S")
            ])
        click.echo(
            tabulate(tags_table, headers=["Tag", "Size", "Last Modified"]))


@click.command()
def packages():
    config = getConfig(CONFIG_PATH)
    client = getClient(config)
    bucket = config["registry"]["bucket"]
    objects = client.list_objects_v2(Bucket=bucket)["Contents"]
    top_level_packages = []
    for obj in objects:
        top_level = obj["Key"].split("/")[0]
        if top_level not in top_level_packages:
            top_level_packages.append(top_level)
    if len(top_level_packages) > 0:
        click.echo("Packages available on emphub:")
        for package in top_level_packages:
            click.echo(f"  - {package}")
