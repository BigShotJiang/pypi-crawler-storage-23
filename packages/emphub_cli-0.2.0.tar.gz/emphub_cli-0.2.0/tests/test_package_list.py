from emphub_cli.commands import packages


def test_list_packages():
    try:
        packages()
    except SystemExit:
        pass    


if __name__ == "__main__":
    test_list_packages()
