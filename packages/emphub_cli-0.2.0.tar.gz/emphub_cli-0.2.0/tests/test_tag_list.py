from emphub_cli.commands import tags


def test_list_tags():
    try:
        tags("10gb-ethernet")
    except SystemExit:
        pass    


if __name__ == "__main__":
    test_list_tags()
