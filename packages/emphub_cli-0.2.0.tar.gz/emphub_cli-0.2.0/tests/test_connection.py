from emphub_cli.s3helpers import getClient
from emphub_cli.operations import getConfig


def test_s3_connection():
    """Test the connection to the S3 server after reading the config file at the default location."""
    # Read the config file from the default location
    config = getConfig("./.emp/config.yaml")

    # Initialize MinioHelper with the config
    s3_client = getClient(config)

    # Test the connection by listing buckets
    response = s3_client.list_buckets()
    print("S3 connection successful! Buckets:")
    for bucket in response['Buckets']:
        print(f"- {bucket['Name']}")
