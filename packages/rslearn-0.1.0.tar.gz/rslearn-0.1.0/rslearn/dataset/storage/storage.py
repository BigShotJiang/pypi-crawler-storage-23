"""Abstract classes for window metadata storage."""

import abc
from typing import TYPE_CHECKING

from upath import UPath

if TYPE_CHECKING:
    from rslearn.dataset.window import Window, WindowLayerData


class WindowStorage(abc.ABC):
    """An abstract class for the storage backend for window metadata.

    This is instantiated by a WindowStorageFactory for a specific rslearn dataset.

    Window metadata includes the location and time range of windows (metadata.json),
    the window layer datas (items.json), and which item groups have been completed
    (materialized). It excludes the actual materialized data. All operations involving
    window metadata go through the WindowStorage, including enumerating windows, creating
    new windows, updating window layer datas during `rslearn dataset prepare`, and
    marking item groups completed during `rslearn dataset materialize`.
    """

    @abc.abstractmethod
    def get_window_root(self, group: str, name: str) -> UPath:
        """Get the path where the window should be stored."""
        raise NotImplementedError

    @abc.abstractmethod
    def get_windows(
        self,
        groups: list[str] | None = None,
        names: list[str] | None = None,
    ) -> list["Window"]:
        """Load the windows in the dataset.

        Args:
            groups: an optional list of groups to filter loading
            names: an optional list of window names to filter loading
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_or_update_window(self, window: "Window") -> None:
        """Create or update the window.

        An existing window is only updated if there is one with the same name and group.

        If there is a window with the same name but a different group, the behavior is
        undefined.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_layer_datas(self, group: str, name: str) -> dict[str, "WindowLayerData"]:
        """Get the window layer datas for the specified window.

        Args:
            group: the window group.
            name: the window name.

        Returns:
            a dict mapping from the layer name to the layer data for that layer, if one
                was previously saved.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def save_layer_datas(
        self, group: str, name: str, layer_datas: dict[str, "WindowLayerData"]
    ) -> None:
        """Set the window layer datas for the specified window."""
        raise NotImplementedError

    @abc.abstractmethod
    def list_completed_layers(self, group: str, name: str) -> list[tuple[str, int]]:
        """List the completed (materialized) item groups for this window.

        Each item group is identified by a (layer_name, group_idx) pair.

        Args:
            group: the window group.
            name: the window name.

        Returns:
            a list of (layer_name, group_idx) tuples identifying completed item groups.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def is_layer_completed(
        self, group: str, name: str, layer_name: str, group_idx: int = 0
    ) -> bool:
        """Check whether the specified item group is completed in the given window.

        Completed means the data for this item group has been written (materialized).

        Args:
            group: the window group.
            name: the window name.
            layer_name: the layer name.
            group_idx: the item group index within the layer (default 0).

        Returns:
            whether the item group is completed.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def mark_layer_completed(
        self, group: str, name: str, layer_name: str, group_idx: int = 0
    ) -> None:
        """Mark the specified item group completed for the given window.

        This must be done after the contents of the item group have been written. If a
        layer has multiple item groups, the caller should wait until the contents of all
        groups have been written before marking them completed; this is because, when
        materializing a window, we skip materialization if the first item group
        (group_idx=0) is marked completed.

        Args:
            group: the window group.
            name: the window name.
            layer_name: the layer name.
            group_idx: the item group index within the layer (default 0).
        """
        raise NotImplementedError

    def close(self) -> None:
        """Release any resources held by this storage backend."""
        pass


class WindowStorageFactory(abc.ABC):
    """An abstract class for a configurable storage backend for window metadata.

    The dataset config includes a StorageConfig that configures a WindowStorageFactory,
    which in turn creates a WindowStorage given a dataset path.
    """

    @abc.abstractmethod
    def get_storage(self, ds_path: UPath) -> WindowStorage:
        """Get a WindowStorage for the given dataset path."""
        raise NotImplementedError
