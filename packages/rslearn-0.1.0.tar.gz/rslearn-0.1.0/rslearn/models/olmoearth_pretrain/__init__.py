"""OlmoEarth model architecture."""
