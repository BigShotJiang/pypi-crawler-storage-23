"""
Optics
"""

NAME = "Shadow4 \u23F5 Optical Elements"

DESCRIPTION = "Optics."

BACKGROUND = "#b9d47a"

ICON = "icons/optical_elements.png"

PRIORITY = 4.1
