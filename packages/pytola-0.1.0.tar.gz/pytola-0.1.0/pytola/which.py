"""Find executable path for commands - Minimal Rust wrapper."""

from __future__ import annotations

import argparse
import logging
import platform

# Import Rust extension - fail fast if not available
try:
    from ._pytola import find_executable
except ImportError as e:
    msg = "Rust extension '_pytola' not found. Please build the extension with 'maturin b'"  # noqa: E501
    raise ImportError(msg) from e

is_windows = platform.system() == "Windows"


def main() -> None:
    """Main entry point for the which command."""
    parser = argparse.ArgumentParser(description="Find executable path for commands.")
    parser.add_argument("commands", type=str, nargs="+", help="Commands to query")
    parser.add_argument(
        "-f",
        "--fuzzy",
        action="store_true",
        help="Enable fuzzy matching",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Only print paths, no status symbols",
    )

    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    logger = logging.getLogger(__name__)

    found_count = 0
    for command in args.commands:
        name, path = find_executable(command, fuzzy=args.fuzzy)
        if path:
            found_count += 1
            if args.quiet:
                logger.info(path)
            else:
                logger.info(f"✓ {name} -> {path}")
        elif not args.quiet:
            logger.info(f"✗ {name} -> not found")

    if not args.quiet and len(args.commands) > 1:
        logger.info(f"\nFound {found_count}/{len(args.commands)} commands")


if __name__ == "__main__":
    main()
