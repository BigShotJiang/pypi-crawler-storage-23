"""Main module."""

try:
    # 尝试导入 Rust 扩展模块
    from . import _pytola

    HAS_RUST_EXTENSION = True
except ImportError:
    HAS_RUST_EXTENSION = False
    _pytola = None


def fibonacci(n: int) -> int:
    """Calculate fibonacci number.

    Args:
        n: The position in fibonacci sequence

    Returns:
        The nth fibonacci number

    Examples:
        >>> fibonacci(10)
        55
        >>> fibonacci(0)
        0
    """
    if HAS_RUST_EXTENSION and _pytola:
        return _pytola.fib(n)
    # Python 实现作为后备
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


def factorial(n: int) -> int:
    """Calculate factorial.

    Args:
        n: The number to calculate factorial for

    Returns:
        The factorial of n

    Examples:
        >>> factorial(5)
        120
        >>> factorial(0)
        1
    """
    if HAS_RUST_EXTENSION and _pytola:
        # Rust extension 中没有 factorial, 使用 Python 实现
        pass

    # Python 实现
    if n <= 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


def is_prime(n: int) -> bool:
    """Check if a number is prime.

    Args:
        n: The number to check

    Returns:
        True if the number is prime, False otherwise

    Examples:
        >>> is_prime(17)
        True
        >>> is_prime(4)
        False
    """
    # Python 实现
    if n <= 1:
        return False
    if n <= 3:  # noqa: PLR2004
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False

    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True


def sum_as_arr(arr: list) -> int:
    """Sum array elements.

    Args:
        arr: List of integers

    Returns:
        Sum of all elements

    Examples:
        >>> sum_as_arr([1, 2, 3, 4, 5])
        15
    """
    if HAS_RUST_EXTENSION and _pytola:
        return _pytola.sum_as_arr(arr)
    return sum(arr)


# 兼容性函数
def has_rust_extension() -> bool:
    return HAS_RUST_EXTENSION


# 保持向后兼容性的别名
fib = fibonacci
fact = factorial
prime_check = is_prime
