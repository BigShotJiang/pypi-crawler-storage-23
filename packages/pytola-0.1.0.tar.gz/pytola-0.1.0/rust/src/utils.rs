//! Utility functions and constants for Pytola
//!
//! This module contains shared utilities and configuration constants
//! used across different parts of the Pytola library.

use pyo3::prelude::*;

/// Get library version information
#[pyfunction]
pub fn get_version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// Check if running on Windows
#[pyfunction]
pub fn is_windows() -> bool {
    cfg!(windows)
}

/// Get platform-specific executable extension
#[pyfunction]
pub fn get_executable_extension() -> &'static str {
    if cfg!(windows) {
        ".exe"
    } else {
        ""
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_platform_detection() {
        let windows = is_windows();
        if cfg!(windows) {
            assert!(windows);
        } else {
            assert!(!windows);
        }
    }

    #[test]
    fn test_executable_extension() {
        let ext = get_executable_extension();
        if cfg!(windows) {
            assert_eq!(ext, ".exe");
        } else {
            assert_eq!(ext, "");
        }
    }
}
