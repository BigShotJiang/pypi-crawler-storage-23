//! Mathematical computation functions for Pytola
//!
//! This module contains high-performance mathematical functions
//! implemented in Rust for better performance compared to Python.

use pyo3::prelude::*;

/// Calculate fibonacci number using recursive approach
///
/// # Arguments
/// * `n` - The position in fibonacci sequence (u32)
///
/// # Returns
/// The nth fibonacci number
///
/// # Examples
/// ```
/// let result = fib(10);
/// assert_eq!(result, 55);
/// ```
#[pyfunction]
pub fn fib(n: u32) -> u32 {
    match n {
        0 => 0,
        1 => 1,
        _ => fib(n - 1) + fib(n - 2),
    }
}

/// Sum array elements
///
/// # Arguments
/// * `arr` - Vector of integers to sum
///
/// # Returns
/// Sum of all elements in the array
///
/// # Examples
/// ```
/// let result = sum_as_arr(vec![1, 2, 3, 4, 5]);
/// assert_eq!(result, 15);
/// ```
#[pyfunction]
pub fn sum_as_arr(arr: Vec<i32>) -> i32 {
    arr.iter().sum()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fibonacci() {
        assert_eq!(fib(0), 0);
        assert_eq!(fib(1), 1);
        assert_eq!(fib(10), 55);
        assert_eq!(fib(15), 610);
    }

    #[test]
    fn test_sum_array() {
        assert_eq!(sum_as_arr(vec![1, 2, 3, 4, 5]), 15);
        assert_eq!(sum_as_arr(vec![]), 0);
        assert_eq!(sum_as_arr(vec![-1, 1]), 0);
        assert_eq!(sum_as_arr(vec![100]), 100);
    }
}
