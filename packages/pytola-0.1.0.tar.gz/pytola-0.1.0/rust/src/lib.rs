//! Pytola - High-performance utilities for Python developers
//!
//! This library provides Rust-accelerated implementations of common
//! utility functions for better performance compared to pure Python.

use pyo3::prelude::*;

// Import modules
mod math;
mod utils;
mod which;

/// Main Pytola module
#[pymodule]
fn _pytola(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Math functions
    m.add_function(wrap_pyfunction!(math::fib, m)?)?;
    m.add_function(wrap_pyfunction!(math::sum_as_arr, m)?)?;

    // Which functions
    m.add_function(wrap_pyfunction!(which::find_executable, m)?)?;
    m.add_function(wrap_pyfunction!(which::is_windows_builtin, m)?)?;
    m.add_function(wrap_pyfunction!(which::get_cmd_exe_path, m)?)?;

    // Utility functions
    m.add_function(wrap_pyfunction!(utils::get_version, m)?)?;
    m.add_function(wrap_pyfunction!(utils::is_windows, m)?)?;
    m.add_function(wrap_pyfunction!(utils::get_executable_extension, m)?)?;

    Ok(())
}

#[cfg(test)]
mod tests {
    #[test]
    fn test_compilation() {
        // Simple test to ensure the module compiles
        assert!(true);
    }
}
