//! Command finding utilities for Pytola
//!
//! This module provides cross-platform executable finding capabilities
//! with special handling for Windows built-in commands.

use pyo3::prelude::*;
use std::collections::HashSet;
use std::process::Command;
use std::sync::OnceLock;

/// Windows built-in commands set - computed once and cached
fn get_windows_builtins() -> &'static HashSet<&'static str> {
    static WINDOWS_BUILTINS: OnceLock<HashSet<&str>> = OnceLock::new();
    WINDOWS_BUILTINS.get_or_init(|| {
        [
            "assoc",
            "attrib",
            "break",
            "bcdedit",
            "cacls",
            "call",
            "cd",
            "chcp",
            "chdir",
            "chkdsk",
            "chkntfs",
            "cls",
            "cmd",
            "color",
            "comp",
            "compact",
            "convert",
            "copy",
            "date",
            "del",
            "dir",
            "diskpart",
            "doskey",
            "driverquery",
            "echo",
            "endlocal",
            "erase",
            "exit",
            "fc",
            "find",
            "findstr",
            "for",
            "format",
            "fsutil",
            "ftype",
            "goto",
            "gpresult",
            "help",
            "icacls",
            "if",
            "label",
            "md",
            "mkdir",
            "mklink",
            "mode",
            "more",
            "move",
            "openfiles",
            "path",
            "pause",
            "popd",
            "print",
            "prompt",
            "pushd",
            "rd",
            "recover",
            "rem",
            "ren",
            "rename",
            "replace",
            "rmdir",
            "robocopy",
            "set",
            "setlocal",
            "sc",
            "schtasks",
            "shift",
            "shutdown",
            "sort",
            "start",
            "subst",
            "systeminfo",
            "tasklist",
            "taskkill",
            "time",
            "title",
            "tree",
            "type",
            "ver",
            "verify",
            "vol",
            "xcopy",
            "wmic",
        ]
        .into_iter()
        .collect()
    })
}

/// Check if a command is a Windows built-in command
///
/// # Arguments
/// * `command` - The command name to check
///
/// # Returns
/// True if the command is a Windows built-in, false otherwise
#[pyfunction]
pub fn is_windows_builtin(command: &str) -> bool {
    cfg!(windows) && get_windows_builtins().contains(&command.to_lowercase().as_str())
}

/// Get Windows cmd.exe path for built-in commands
///
/// # Returns
/// Static string representing the cmd.exe path for built-ins
#[pyfunction]
pub fn get_cmd_exe_path() -> &'static str {
    "C:\\Windows\\System32\\cmd.exe (built-in)"
}

/// Find executable path for commands cross-platform
///
/// # Arguments
/// * `name` - Name of the command to find
/// * `fuzzy` - Whether to use fuzzy matching
///
/// # Returns
/// Tuple containing (command_name, Option<path>)
#[pyfunction]
pub fn find_executable(name: &str, fuzzy: bool) -> PyResult<(String, Option<String>)> {
    let ext = if cfg!(windows) { ".exe" } else { "" };

    // Try system command (where/which)
    let result = if cfg!(windows) {
        let match_name = if fuzzy {
            format!("*{}*{}", name, ext)
        } else {
            format!("{}{}", name, ext)
        };
        Command::new("where").arg(&match_name).output()
    } else {
        let match_name = if fuzzy {
            format!("*{}*", name)
        } else {
            name.to_string()
        };
        Command::new("which").arg(&match_name).output()
    };

    if let Ok(output) = result {
        if output.status.success() {
            let stdout = String::from_utf8_lossy(&output.stdout);
            let paths: Vec<&str> = stdout
                .trim()
                .split('\n')
                .filter(|s| !s.is_empty())
                .collect();
            if !paths.is_empty() {
                let path = if cfg!(windows) {
                    paths[0].to_string()
                } else {
                    stdout.trim().to_string()
                };
                return Ok((name.to_string(), Some(path)));
            }
        }
    }

    // For Windows, check if it's a built-in command
    if cfg!(windows) && is_windows_builtin(name) {
        return Ok((name.to_string(), Some(get_cmd_exe_path().to_string())));
    }

    // For Unix systems, check /usr/bin/
    #[cfg(not(windows))]
    {
        let path = format!("/usr/bin/{}", name);
        if std::path::Path::new(&path).exists()
            && std::fs::metadata(&path)
                .map(|m| m.permissions().readonly())
                .unwrap_or(false)
        {
            return Ok((name.to_string(), Some(path)));
        }
    }

    Ok((name.to_string(), None))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_windows_builtin_detection() {
        if cfg!(windows) {
            assert!(is_windows_builtin("dir"));
            assert!(is_windows_builtin("DIR"));
            assert!(is_windows_builtin("echo"));
            assert!(!is_windows_builtin("nonexistent"));
        }
    }

    #[test]
    fn test_cmd_exe_path() {
        let path = get_cmd_exe_path();
        assert!(path.contains("cmd.exe"));
        assert!(path.contains("built-in"));
    }
}
