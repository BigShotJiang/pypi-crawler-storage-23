=======
Pytola
=======

.. image:: https://img.shields.io/pypi/v/pytola.svg
        :target: https://pypi.python.org/pypi/pytola

.. image:: https://img.shields.io/travis/gooker_young/pytola.svg
        :target: https://travis-ci.com/gooker_young/pytola

.. image:: https://readthedocs.org/projects/pytola/badge/?version=latest
        :target: https://pytola.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status

Pytola: Essential Utilities for Python Devs - Now with Rust-powered performance!

* Free software: MIT license
* Documentation: https://pytola.readthedocs.io/zh-cn/stable/

Features
--------

* **高性能数学函数**: 使用 Rust 实现的核心算法，提供比纯 Python 更快的执行速度
* **无缝集成**: Python 接口自动回退到纯 Python 实现，无需额外配置
* **易于使用**: 简单直观的 API 设计
* **跨平台**: 支持 Windows、macOS 和 Linux

Installation
------------

从 PyPI 安装::

    pip install pytola

或者从源码安装::

    git clone https://gitee.com/gooker_young/pytola.git
    cd pytola
    pip install .

开发安装::

    git clone https://gitee.com/gooker_young/pytola.git
    cd pytola
    pip install -e .

Usage
-----

基础使用::

    from pytola import pytola

    # Fibonacci 数列计算
    result = pytola.fibonacci(10)  # 返回 55
    print(f"Fibonacci(10) = {result}")

    # 阶乘计算
    result = pytola.factorial(5)   # 返回 120
    print(f"Factorial(5) = {result}")

    # 素数检测
    is_prime = pytola.is_prime(17) # 返回 True
    print(f"Is 17 prime? {is_prime}")

    # 检查是否有 Rust 扩展
    has_rust = pytola.has_rust_extension()
    print(f"Rust extension available: {has_rust}")

API Reference
-------------

fibonacci(n: int) -> int
    计算第 n 个斐波那契数

factorial(n: int) -> int  
    计算 n 的阶乘

is_prime(n: int) -> bool
    检查数字 n 是否为素数

has_rust_extension() -> bool
    检查是否启用了 Rust 扩展

别名函数:
- fib(n) → fibonacci(n)
- fact(n) → factorial(n)  
- prime_check(n) → is_prime(n)

Performance
-----------

Pytola 使用 Rust 实现核心算法，在处理大数值时相比纯 Python 实现有显著性能提升:

+----------------+--------------+---------------+
| 函数           | Python 时间  | Rust 时间     |
+================+==============+===============+
| fibonacci(35)  | ~2.5s        | ~0.001s       |
+----------------+--------------+---------------+
| factorial(100) | ~0.1s        | ~0.0001s      |
+----------------+--------------+---------------+

构建要求
--------

**生产环境:**
- Python >= 3.8
- pip

**开发环境:**
- Python >= 3.8
- Rust 工具链 (推荐使用 rustup)
- maturin >= 1.0
- cargo

开发流程
--------

使用 Makefile 命令:

.. code-block:: bash

    # 清理构建文件
    make clean
    
    # 构建发布版本
    make build
    
    # 运行测试
    make test
    
    # 开发模式安装
    make develop
    
    # 检查代码质量
    make check

或者直接使用 maturin:

.. code-block:: bash

    # 开发模式安装
    maturin develop
    
    # 构建 wheel 包
    maturin build --release
    
    # 发布到 PyPI
    maturin publish

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage