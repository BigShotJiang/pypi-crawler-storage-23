# # VideoSDK CAMBAI Plugin

Agent Framework plugin for TTS services from CambAI.

## Installation

```bash
pip install videosdk-plugins-cambai
```
