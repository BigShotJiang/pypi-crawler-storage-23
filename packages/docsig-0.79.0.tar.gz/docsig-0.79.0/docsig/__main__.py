"""
docsig.__main__
===============

Module entry point.
"""

import sys as _sys  # pragma: no cover

from docsig import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    _sys.exit(main())  # pragma: no cover
