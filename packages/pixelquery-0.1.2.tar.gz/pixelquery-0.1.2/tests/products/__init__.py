"""Products module tests"""
