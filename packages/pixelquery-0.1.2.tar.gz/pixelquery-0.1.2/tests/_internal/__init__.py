"""
Tests for internal modules
"""
