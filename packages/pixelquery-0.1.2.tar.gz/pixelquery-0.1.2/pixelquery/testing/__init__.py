"""
PixelQuery Testing Utilities

Test fixtures and utilities for users and developers.
"""

# Will be populated as test utilities are added
__all__: list[str] = []
