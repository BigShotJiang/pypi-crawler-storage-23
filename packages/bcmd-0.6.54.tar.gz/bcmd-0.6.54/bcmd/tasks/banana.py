import asyncio
import uuid
from contextlib import asynccontextmanager
from getpass import getpass
from pathlib import Path
from typing import Any, Final

import pyperclip
import typer
from beni import bcolor, bcrypto, bfile, binput, bpath, bplaywright, btask
from beni.bfunc import crcStr, syncCall
from PIL import Image
from playwright.async_api import Page, async_playwright

app: Final = btask.newSubApp('Nano Banana Pro 工具')

TIMEOUT = 120 * 1000
ACCOUNT = 'bcrypto---4HVJLLd/fFxKGeO60SV7TigVJDzNZ9mTJAQ+A1NpqELvylsR5GustoNbHDs9BlhiOSRPsc+3EuRIWONfbSQBPKgL+Zp6D8k7t642WBoJkxRbC7Ri245XQNgTdYb/CJzLwQ=='
WORKPATH = bpath.workspace('banana')
STORAGE_FILE = WORKPATH / 'gemini-session.json'
COLOR_TEMPLATE_DIR = WORKPATH / 'dashcover-color-templates'
COMMAND_CHANGE_COLOR = '''
基于[参考图1]，仅选中画面中的汽车仪表盘遮光垫区域进行编辑。
将该遮光垫的颜色和材质纹理完全替换为[参考图2]中所展示的颜色和材质，严格遵守忽略[参考图2]的形状这个规则。
严格保留[参考图1]中原有的光照、阴影、褶皱形态，遮光垫形状和孔位，以及车内环境的所有细节，除了遮光垫的材质和颜色改变外，画面其他部分保持完全不变。
'''
COMMAND_RUN = '''
基于提供的参考图制作一张高质量汽车内饰照片。
汽车型号需严格符合参考图，不可拼凑。
车内必须保持极度干净整洁，移除所有杂物。
仪表台上的遮光垫尺寸和形状要严格保留原样，不能改动。
必须去掉内后视镜。
必须去掉方向盘套。
必须去掉方向盘上的车标。
天气晴朗，但车内为柔和散射光，无直射阳光。
车外环境替换为宁静整洁的（乡村道路旁 / 私人车库 / 花园车道）。
构图为广角，展示大部分仪表台区域，拍摄角度与参考图略有不同。
'''

pageList: asyncio.Queue[Page] = asyncio.Queue()


@app.command()
@syncCall
async def login(
):
    '登录 Google 账号'
    try:
        secretMsg = getpass('请输入密码：')
        content = bcrypto.decryptText(ACCOUNT, secretMsg)
        content = content.split('\n')
        username = content[0]
        password = content[-1]
    except:
        return btask.abort('密码错误，无法解密账号信息')
    async with bplaywright.page(
        browser={
            'headless': False,    # 显示浏览器UI，登录必须要显示浏览器
            'channel': 'chrome',  # 使用系统 Chrome 浏览器
            'timeout': TIMEOUT,
            'args': [
                '--disable-blink-features=AutomationControlled',
            ]
        }, context={
            'no_viewport': True,
        },
    ) as page:
        print('登录 Google 账号')
        await page.goto('https://gemini.google.com', timeout=TIMEOUT)
        await page.locator('[aria-label="登录"]').click(timeout=TIMEOUT)
        print('输入账号')
        await page.locator('#identifierId').fill(username, timeout=TIMEOUT)
        await page.get_by_text('下一步').click(timeout=TIMEOUT)
        await page.get_by_text('显示密码').wait_for(timeout=TIMEOUT)
        await page.wait_for_timeout(1000)
        print('输入密码')
        await page.locator('[aria-label="输入您的密码"]').fill(password, timeout=TIMEOUT)
        print('开始登录')
        await page.get_by_text('下一步').click(timeout=TIMEOUT)
        await page.get_by_text('制作图片').wait_for(timeout=TIMEOUT)
        await page.context.storage_state(path=STORAGE_FILE)
        bcolor.printGreen('OK')


@app.command()
@syncCall
async def run(
    path: Path = typer.Argument(None, help=""),
    show_browser: bool = typer.Option(False, help="是否显示浏览器UI"),
    times: int = typer.Option(3, help="处理次数"),
    async_num: int = typer.Option(3, help="异步处理数量"),
):
    '使用 Google Nano Banana Pro 生成图片'

    path = path or Path.cwd()
    fileList = [x for x in bpath.listFile(path) if x.suffix.lower() in ['.png', '.jpg', '.jpeg']]
    baseFileList = [file for file in fileList if file.name.startswith('base_')]
    fileList = [file for file in fileList if not file.name.startswith('base_')]
    if not fileList:
        return btask.abort('没有找到任何文件', path)

    # 提示词
    command = COMMAND_CHANGE_COLOR
    commandFile = path / 'command.txt'
    if commandFile.is_file():
        command = await bfile.readText(commandFile)

    async def handleFile(
        file: Path,
    ):
        uploadFileList = [file]
        uploadFileList.extend(baseFileList)
        outputFile = file.parent / 'output' / f'{file.stem}-{crcStr(uuid.uuid4().hex).upper()}.png'
        print('-' * 20)
        print('正在处理文件', file.name)
        page = await pageList.get()
        await runBanana(
            page=page,
            command=command,
            uploadFileList=uploadFileList,
            outputFile=outputFile,
        )
        await pageList.put(page)

    async with makePageList(show_browser, async_num):
        await asyncio.gather(*[handleFile(file) for file in fileList for _ in range(times)])

    bcolor.printGreen('OK')


@app.command()
@syncCall
async def set_color_template(
    path: Path = typer.Argument(None, help="颜色模板图片路径"),
):
    '设置颜色模板目录'

    path = path or Path.cwd()
    if not path.is_dir():
        return btask.abort('路径不存在或不是目录', path)
    fileList = [x for x in bpath.listFile(path) if x.suffix.lower() in ['.png', '.jpg', '.jpeg']]
    if not fileList:
        return btask.abort('没有找到任何图片文件', path)
    for file in fileList:
        print(file)
    await binput.confirm('确认要设置这些图片为颜色模板吗？')
    bpath.remove(COLOR_TEMPLATE_DIR)
    bpath.make(COLOR_TEMPLATE_DIR)
    for file in fileList:
        bpath.copy(file, COLOR_TEMPLATE_DIR / file.name)
    bcolor.printGreen('OK')


@app.command()
@syncCall
async def change_color(
    path: Path = typer.Argument(None, help=""),
    show_browser: bool = typer.Option(False, help="是否显示浏览器UI"),
    times: int = typer.Option(3, help="处理次数"),
    async_num: int = typer.Option(3, help="异步处理数量"),
    color: str = typer.Option(None, help="指定需要替换的颜色，多个颜色使用空格间隔，否则是全部"),
):
    '产品图片换色'

    path = path or Path.cwd()
    fileList = [x for x in bpath.listFile(path) if x.suffix.lower() in ['.png', '.jpg', '.jpeg']]
    if not fileList:
        return btask.abort('没有找到任何文件', path)

    # 提示词
    command = COMMAND_CHANGE_COLOR
    commandFile = path / 'command.txt'
    if commandFile.is_file():
        command = await bfile.readText(commandFile)

    # 检查模板文件
    if not COLOR_TEMPLATE_DIR.is_dir():
        return btask.abort('请先使用 set-color-template 命令设置颜色模板')
    templateFileList = bpath.listFile(COLOR_TEMPLATE_DIR)
    if color:
        colorList = [x.strip() for x in color.split(' ') if x.strip()]
        templateFileList = [file for file in templateFileList if file.stem in colorList]
    if not templateFileList:
        return btask.abort('没有找到任何颜色模板文件', COLOR_TEMPLATE_DIR, color)
    print(f'本次替换颜色 {", ".join([x.stem for x in templateFileList])}')
    templateFileSizeList = [Image.open(x).size for x in templateFileList]

    # 检查待处理文件是否有尺寸小于模板文件的尺寸
    for file in fileList:
        fileSize = Image.open(file).size
        for templateFile, templateSize in zip(templateFileList, templateFileSizeList):
            if fileSize[0] < templateSize[0] or fileSize[1] < templateSize[1]:
                return btask.abort(f'文件 {file} 的尺寸 {fileSize} 小于颜色模板文件 {templateFile} 的尺寸 {templateSize}，无法处理')

    async def handleFile(
        file: Path,
    ):
        fileSize = Image.open(file).size
        # 将模板文件尺寸扩大
        with bpath.useTempPath(True) as tempPath:
            for templateFile, templateSize in zip(templateFileList, templateFileSizeList):
                template_img = Image.open(templateFile)
                left = (fileSize[0] - templateSize[0]) // 2
                top = (fileSize[1] - templateSize[1]) // 2
                padded_img = Image.new('RGB', fileSize, 'white')
                padded_img.paste(template_img, (left, top))
                padded_img.save(tempPath / templateFile.name)

            # 开始换色各个颜色
            for templateFile in bpath.listFile(tempPath):
                uploadFileList = [
                    file,
                    templateFile,
                ]
                outputFile = file.parent / 'output' / f'{file.stem}-{templateFile.stem}-{crcStr(uuid.uuid4().hex).upper()}.png'
                print('-' * 20)
                print('正在处理文件', file.name, '=>', templateFile.stem)
                page = await pageList.get()
                await runBanana(
                    page=page,
                    command=command,
                    uploadFileList=uploadFileList,
                    outputFile=outputFile,
                )
                await pageList.put(page)

    async with makePageList(show_browser, async_num):
        await asyncio.gather(*[handleFile(file) for file in fileList for _ in range(times)])

    bcolor.printGreen('OK')


@app.command()
@syncCall
async def default_command(
):
    '获取默认提示词'

    msg = '\n\n\n'.join([
        COMMAND_CHANGE_COLOR.strip(),
        COMMAND_RUN.strip(),
    ])
    print(msg)
    pyperclip.copy(msg)
    print('\n\n已复制到剪贴板')
    bcolor.printGreen('OK')


async def runBanana(
    page: Page,
    command: str,
    uploadFileList: list[Path],
    outputFile: Path,
    retry: int = 3,
):
    while retry > 0:
        try:
            print('打开网页')
            await page.goto('https://gemini.google.com', timeout=TIMEOUT)

            if await page.get_by_text('登录').count():
                btask.abort('请先登录 Google 账号')

            print('输入提示词，选择模型')
            await page.fill('div.ql-editor[contenteditable="true"]', command)
            await page.get_by_text('制作图片').click()
            await page.locator('[aria-label="打开模式选择器"]').click()
            await page.locator('button[data-test-id="bard-mode-option-pro"]').click()

            if uploadFileList:
                print('开始上传参考图')
                await page.locator('[aria-label="打开文件上传菜单"]').click()
                async with page.expect_file_chooser() as fc_info:
                    await page.get_by_text('上传文件').click()
                file_chooser = await fc_info.value
                await file_chooser.set_files(uploadFileList)
                await page.wait_for_timeout(1000)

            print('发送请求')
            await page.locator('[aria-label="发送"]').click(timeout=TIMEOUT)

            print('正在生成图片')
            await page.wait_for_selector('[aria-label="下载完整尺寸的图片"]', timeout=TIMEOUT)
            await page.wait_for_timeout(3000)

            print('开始下载图片')
            async with page.expect_download(timeout=TIMEOUT) as download_info:
                await page.locator('[aria-label="下载完整尺寸的图片"]').click(timeout=TIMEOUT)
            download = await download_info.value
            await download.save_as(outputFile)
            print(outputFile)
            return
        except Exception as e:
            bcolor.printRed('操作失败', str(e))
            retry -= 1


@asynccontextmanager
async def makePageList(
    isShowBrowser: bool = False,
    asyncNum: int = 3,
):
    browser = {
        'headless': not isShowBrowser,  # 显示浏览器UI
        'channel': 'chrome',            # 使用系统 Chrome 浏览器
        'timeout': TIMEOUT,
        'args': [
            '--disable-blink-features=AutomationControlled',
        ]
    }
    context = {
        'no_viewport': True,
        'storage_state': STORAGE_FILE,
    }
    page: dict[str, Any] = {}
    num = asyncNum
    async with async_playwright() as p:
        async with await p.chromium.launch(**browser) as b:
            async with await b.new_context(**context) as c:
                for _ in range(num):
                    await pageList.put(await c.new_page(**page))
                yield
                while pageList.qsize():
                    x = await pageList.get()
                    await x.close()
