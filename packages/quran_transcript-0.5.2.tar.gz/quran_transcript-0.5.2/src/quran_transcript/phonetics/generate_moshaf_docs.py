from .moshaf_attributes import MoshafAttributes


def main():
    print(MoshafAttributes.generate_docs())


if __name__ == "__main__":
    main()
