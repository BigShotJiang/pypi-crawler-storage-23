"""Version information for sage-memory-benchmark."""
__version__ = "0.1.0.0"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
