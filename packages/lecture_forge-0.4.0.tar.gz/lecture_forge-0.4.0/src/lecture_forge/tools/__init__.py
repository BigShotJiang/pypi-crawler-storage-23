"""
Tools for LectureForge agents.
"""

# Import tools here as they are implemented
# from lecture_forge.tools.pdf_parser import PDFParserTool
# from lecture_forge.tools.web_scraper import WebScraperTool
# ...
