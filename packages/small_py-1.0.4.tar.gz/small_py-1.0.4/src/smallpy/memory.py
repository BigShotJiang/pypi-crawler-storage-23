import json
from typing import Dict,Optional,Any,List,Sequence
import os

def _validate_new_entry(
        new_entry: Dict[str, Any],
        existing_entries: Sequence[Dict[str, Any]],
        comparison_field: str,
        memory_key: str
    ) -> None:
        """
        Validate a new entry against existing stored entries.

        Validation rules:
        - The new entry must have the same dictionary structure as existing entries
        - The new entry must contain an `"id"` key
        - The specified comparison field must exist in both existing entries
        and the new entry

        Parameters
        ----------
        new_entry : dict
            The entry being validated.
        existing_entries : sequence of dict
            Existing entries stored under the same memory key.
        comparison_field : str
            Field used for comparison in memory checks.
        memory_key : str
            Name of the memory section (used for error messages).

        Returns
        -------
        None

        Raises
        ------
        ValueError
            If the entry structure does not match existing entries
        KeyError
            If:
            - `"id"` is missing
            - `comparison_field` is missing in either entry
        """
        if existing_entries:
            if existing_entries[0].keys() != new_entry.keys():
                raise KeyError(f'Dict structure of new entry does not match existing structure in {memory_key}')
            if comparison_field not in existing_entries[0]:
                raise KeyError(f'Comparison field "{comparison_field}" not found in existing entries')
        if comparison_field not in new_entry:
            raise KeyError(f'Comparison field "{comparison_field}" not found in new entry')
        if 'id' not in new_entry:
            raise KeyError(f'Key "id" must be in new entries')

def add_to_memory(
    memory_key:str, 
    new_entry:Dict[str,Any] | List[Dict[str,Any]],
    memory_path:Optional[str]=None
) -> None:
    """
    Add or update a structured entry in a persistent JSON memory file.

    Entries are stored under a named `memory_key` and must:
    - Contain an `"id"` field
    - Share the same dictionary structure as existing entries
      under the same `memory_key`

    If an entry with the same `"id"` already exists, it is replaced.

    Parameters
    ----------
    memory_key : str
        Top-level key under which entries are stored.
    new_entry : Dict[str,Any] | List[Dict[str,Any]]
        Dictionary representing the entry to store. Must include an `"id"` key.
        If a list of dicts is passed, all entries will be added at once via append
    memory_path : str, optional
        Path to the JSON memory file. Defaults to `memory/memory.json`.

    Returns
    -------
    None
    """
        
    if not memory_path:
        memory_path = r'memory\memory.json'
        
    if not os.path.isfile(memory_path):
        data = {}
    else:
        with open(memory_path,'r') as file:
            try:
                data = json.load(file)
            except json.decoder.JSONDecodeError:
                data = {}
    
    if memory_key not in data.keys():
        data[memory_key] = []
    
    new_entries = [new_entry] if isinstance(new_entry,dict) else new_entry
    for entry in new_entries:
        _validate_new_entry(entry,data[memory_key],memory_key)
    
    new_ids = {entry['id'] for entry in new_entries}
    data[memory_key] = [entry for entry in data[memory_key] if entry['id'] not in new_ids]
    data[memory_key].extend(new_entries)

    os.makedirs(os.path.dirname(memory_path), exist_ok=True)
    with open(memory_path, 'w') as file:
        json.dump(data, file, indent=2)

def is_in_memory(
    memory_key: str,
    new_entry: Dict[str, Any],
    comparison_field: str,
    memory_path: Optional[str] = None
) -> bool:
    """
    Check whether a matching entry exists in the persistent JSON memory.

    A match is defined as an entry with:
    - The same `"id"` value
    - The same value for the specified `comparison_field`

    All entries under the same `memory_key` must share the same dictionary
    structure.

    Parameters
    ----------
    memory_key : str
        Top-level key under which entries are stored.
    new_entry : dict
        Entry to compare against stored data. Must include `"id"` and
        `comparison_field`.
    comparison_field : str
        Field used to compare the new entry against existing entries.
    memory_path : str, optional
        Path to the JSON memory file. Defaults to `memory/memory.json`.

    Returns
    -------
    bool
        True if a matching entry exists, False otherwise.
    """
    
    if not memory_path:
        memory_path = r'memory\memory.json'

    if not os.path.isfile(memory_path):
        return False
    
    with open(memory_path,'r') as file:
        try:
            data = json.load(file)
        except json.decoder.JSONDecodeError:
            return False
        
    if memory_key not in data.keys():
        return False
    
    _validate_new_entry(new_entry,data[memory_key],comparison_field,memory_key)
    for entry in data[memory_key]:
        if entry['id'] == new_entry['id'] and entry[comparison_field] == new_entry[comparison_field]:
            return True
    
    return False