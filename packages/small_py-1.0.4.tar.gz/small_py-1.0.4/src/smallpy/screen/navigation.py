import pyautogui as pag
import time
from pathlib import Path
from ..utils import clear_terminal
from collections import defaultdict
import re
from abc import ABC

class ImageLocator:
    '''
    Wait for an image (or list of images) to appear or disappear on the screen.

    This class provides blocking or timeout-based image searching using PyAutoGUI
    and keeps a history of located positions.

    Attributes
    ----------
    search_paths : list[Path]
        List of image paths to search for on screen.
    location_history : list[tuple[int,int]]
        Stores all coordinates of successfully located images.
    last_location : tuple[int,int] | None
        Cached coordinates of the most recently located image, or None if no image has been found.
    _dec_indents : int
        Number of spaces to prepend to printed status messages.

    Parameters
    ----------
    search_paths : Path | list[Path]
        Single image Path or list of Paths to search for.
    dec_indents : int, optional
        Number of spaces for status printing indentation, default is 1.

    Raises
    ------
    TypeError
        If any element in search_paths is not a Path.
    ValueError
        If search_paths is empty.

    Methods
    -------
    locate(timeout=5, interval=0.1, confidence=0.95, allow_failure=False)
        Waits for any of the images to appear on screen, returns coordinates.
    wait_for_disappear(timeout=5, interval=0.1, confidence=0.95, allow_failure=False)
        Waits for all images to disappear from the screen.
    print_status(invert=False)
        Prints a status message for waiting or failure.
    '''
    def __init__(
            self,
            search_paths:Path|list[Path],
            dec_indents: int = 1
    ):
        if not isinstance(search_paths,list):
            search_paths = [search_paths]
        if not (
            all(isinstance(p,Path) for p in search_paths)
        ):
            types = {p:type(p) for p in search_paths if not isinstance(p,Path)}
            raise TypeError(f'Non-Path detected in search_paths: {types}')
        if not search_paths:
            raise ValueError('Arg search_paths cannot be empty')
        self.search_paths = search_paths

        self._dec_indents = dec_indents
        
        self.location_history = []
    
    @property
    def last_location(self) -> tuple[int,int] | None:
        return self.location_history[-1] if self.location_history else None
    
    def print_status(self,invert:bool=False) -> None:
        if invert:
            print(f'{' '*self._dec_indents}>> Waiting for {[img.name for img in self.search_paths]} to close')
        else:
            print(f'{' '*self._dec_indents}>> Unable to locate {[img.name for img in self.search_paths]}')

    def locate(
            self,
            timeout:int=5,
            interval: float = 0.1,
            confidence: float = 0.95,
            allow_failure: bool = False,
    ) -> tuple[int,int] | None:
        location = None
        start_time = time.time()
        printed = False
        while location is None:
            elapsed = time.time() - start_time
            if (elapsed > timeout) and allow_failure:
                return None
            elif (elapsed > timeout) and not allow_failure:
                if not printed:
                    self.print_status()
                    printed = True
            
            for img in self.search_paths:
                img = str(img)
                try:
                    location = pag.locateCenterOnScreen(image=img,grayscale=True,confidence=confidence)
                    if location:
                        break
                except pag.ImageNotFoundException:
                    pass
            
            time.sleep(interval)
        
        if printed:
            clear_terminal()

        self.location_history.append(location)
        return location
    
    def wait_for_disappear(
            self,
            timeout:int=5,
            interval: float = 0.1,
            confidence: float = 0.95,
            allow_failure: bool = False) -> None | tuple[int,int]:
        location = self.locate(timeout=0.5,allow_failure=True) # get a baseline check
        start_time = time.time()
        printed = False
        while location is not None:
            elapsed = time.time() - start_time
            if (elapsed > timeout) and allow_failure:
                return location
            elif (elapsed > timeout) and not allow_failure:
                if not printed:
                    self.print_status(invert=True)
                    printed = True
            
            locations = []
            for img in self.search_paths:
                img = str(img)
                try:
                    location = pag.locateCenterOnScreen(image=img,grayscale=True,confidence=confidence)
                    locations.append(location)
                except pag.ImageNotFoundException:
                    pass
            
            if not locations:
                location = None
                break
            
            time.sleep(interval)

        if printed:
            clear_terminal()
        
        return location # will only reach here if no locations found

class BaseScreen(ABC):
    '''
    Abstract base class representing a screen in a GUI automation framework.

    Handles image grouping, locating, and clicking operations. Concrete screen
    classes should inherit from this and define screen-specific workflows
    and elements.

    Attributes
    ----------
    images : dict[str, list[Path]]
        Dictionary mapping base image names to a list of Path objects. Keys are stripped
        of numeric suffixes to allow grouping of variants.
    _image_dict : dict[str, Path]
        Original dictionary of stem-to-path mappings provided at construction.

    Parameters
    ----------
    imagepath_dict : dict[str, Path]
        Mapping of image stems (without file extensions) to Path objects.

    Methods
    -------
    _group_images(image_dict)
        Groups image paths by base name, stripping numeric suffixes.
    _get_path(image_name)
        Retrieves list of Path objects for a given image name.
    click_image(image_name, offset=(0,0), n_clicks=1, interval=0)
        Locates an image and clicks on it with optional offset, multiple clicks, and interval.
    click_location(coords, offset=(0,0), n_clicks=1, interval=0)
        Clicks at the specified coordinates with optional offset, multiple clicks, and interval.
    click_series(image_names)
        Clicks a series of images in order.
    wait_until_loaded(image_name)
        Blocks until the given image appears on screen using ImageLocator.
    '''
    # use @abstractmethod for methods that must be overwritten by inheriting classes
    def __init__(self,imagepath_dict:dict[str,Path]):
        for stem,path in imagepath_dict.items():
            if '.' in stem:
                raise ValueError(f'Dict keys should only contain file stem, not name: {stem}')
        self._image_dict = dict(imagepath_dict)
        self.images = self._group_images(self._image_dict)
    
    def _group_images(self,image_dict:dict[str,Path]) -> dict[str,list[Path]]:
        grouped = defaultdict(list)
        for stem,path in image_dict.items():
            base_name = re.sub(r'\d+$','',stem)
            grouped[base_name].append(path)
        return dict(grouped)
    
    def _get_path(self,image_name:str) -> list[Path]:
        if (image_name not in self.images):
            raise KeyError(f'Unable to locate image(s) named "{image_name}" in self.images')
        return self.images[image_name]
    
    def click_image(
            self,
            image_name:str,
            offset:tuple[int,int]=(0,0),
            n_clicks:int=1,
            interval:float=0
    ) -> None:
        lctr = ImageLocator(self._get_path(image_name))
        location = lctr.locate()
        x,y = location
        x_offset,y_offset = offset
        pag.click(x+x_offset,y+y_offset,duration=0.1,clicks=n_clicks,interval=interval)
    
    def click_location(
            self,
            coords:tuple[int,int],
            offset:tuple[int,int]=(0,0),
            n_clicks:int=1,
            interval:float=0
    ) -> None:
        x,y = coords
        x_offset,y_offset = offset
        pag.click(x+x_offset,y+y_offset,duration=0.1,clicks=n_clicks,interval=interval)
    
    def click_series(self,image_names:list[str]) -> None:
        for img in image_names:
            self.click_image(img)
    
    def wait_until_loaded(self,image_name:str) -> None:
        paths = self._get_path(image_name)
        lctr = ImageLocator(paths)
        lctr.locate()
