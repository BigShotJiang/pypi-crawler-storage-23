---
type: agent
model: $system.demo
skills: []
servers:
  - mcp_sessions_client_notes
---

Client-side state notebook demo (`state` round-trip).

Try:

- "Add a client note with text alpha."
- "Add a second client note with text beta."
- "List client notes."
- "Check client_notes_status."
- "Clear client notes."
