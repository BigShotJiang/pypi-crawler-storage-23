# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["IssueType"]

IssueType: TypeAlias = Literal["BUG", "HUMAN_ANNOTATION", "SUGGESTED_TASK", "USER_SIGNAL"]
