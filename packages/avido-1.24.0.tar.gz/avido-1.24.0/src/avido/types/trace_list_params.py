# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["TraceListParams"]


class TraceListParams(TypedDict, total=False):
    has_error: Required[Annotated[bool, PropertyInfo(alias="hasError")]]
    """Filter traces with or without errors."""

    max_cost: Required[Annotated[float, PropertyInfo(alias="maxCost")]]
    """Filter traces with total cost less than or equal to this value."""

    max_duration: Required[Annotated[int, PropertyInfo(alias="maxDuration")]]
    """Filter traces with total duration (ms) less than or equal to this value."""

    max_score: Required[Annotated[float, PropertyInfo(alias="maxScore")]]
    """Filter traces with eval score less than or equal to this value."""

    min_cost: Required[Annotated[float, PropertyInfo(alias="minCost")]]
    """Filter traces with total cost greater than or equal to this value."""

    min_duration: Required[Annotated[int, PropertyInfo(alias="minDuration")]]
    """Filter traces with total duration (ms) greater than or equal to this value."""

    min_score: Required[Annotated[float, PropertyInfo(alias="minScore")]]
    """Filter traces with eval score greater than or equal to this value."""

    end_date: Annotated[Union[str, datetime], PropertyInfo(alias="endDate", format="iso8601")]
    """Filter traces created before this date (inclusive)."""

    limit: int
    """Number of items to include in the result set."""

    metadata_key: Annotated[str, PropertyInfo(alias="metadataKey")]
    """Metadata key to filter on. Must be used together with metadataValue."""

    metadata_value: Annotated[str, PropertyInfo(alias="metadataValue")]
    """Metadata value to filter on. Must be used together with metadataKey."""

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Field to order by in the result set."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    reference_id: Annotated[str, PropertyInfo(alias="referenceId")]
    """Filter traces by reference ID"""

    search: str
    """
    Full-text search across trace step content fields (input, output, toolInput,
    toolOutput, content, query, result).
    """

    skip: int
    """Number of items to skip before starting to collect the result set."""

    start_date: Annotated[Union[str, datetime], PropertyInfo(alias="startDate", format="iso8601")]
    """Filter traces created after this date (inclusive)."""

    test_id: Annotated[str, PropertyInfo(alias="testId")]
    """Filter traces by test ID"""
