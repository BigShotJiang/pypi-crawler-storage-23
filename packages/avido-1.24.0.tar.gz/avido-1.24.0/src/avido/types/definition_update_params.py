# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._utils import PropertyInfo

__all__ = [
    "DefinitionUpdateParams",
    "GlobalConfig",
    "GlobalConfigCriterion",
    "GlobalConfigGroundTruth",
    "GlobalConfigOutputMatchStringConfig",
    "GlobalConfigOutputMatchStringConfigExtract",
    "GlobalConfigOutputMatchListConfig",
    "GlobalConfigOutputMatchListConfigExtract",
]


class DefinitionUpdateParams(TypedDict, total=False):
    global_config: Annotated[GlobalConfig, PropertyInfo(alias="globalConfig")]

    name: str

    style_guide_id: Annotated[str, PropertyInfo(alias="styleGuideId")]


class GlobalConfigCriterion(TypedDict, total=False):
    criterion: Required[str]
    """The criterion describes what our evaluation LLM must look for in the response.

    Remember that the answer to the criterion must be as a pass/fail.
    """


class GlobalConfigGroundTruth(TypedDict, total=False):
    ground_truth: Required[Annotated[str, PropertyInfo(alias="groundTruth")]]
    """
    The ground truth is the most correct answer to the task that we measure the
    response against
    """


class GlobalConfigOutputMatchStringConfigExtract(TypedDict, total=False):
    flags: Required[str]

    group: Required[Union[int, Iterable[int]]]

    pattern: Required[str]


class GlobalConfigOutputMatchStringConfig(TypedDict, total=False):
    type: Required[Literal["string"]]

    extract: GlobalConfigOutputMatchStringConfigExtract


class GlobalConfigOutputMatchListConfigExtract(TypedDict, total=False):
    flags: Required[str]

    group: Required[Union[int, Iterable[int]]]

    pattern: Required[str]


class GlobalConfigOutputMatchListConfig(TypedDict, total=False):
    match_mode: Required[Annotated[Literal["exact_unordered", "contains"], PropertyInfo(alias="matchMode")]]

    type: Required[Literal["list"]]

    extract: GlobalConfigOutputMatchListConfigExtract

    pass_threshold: Annotated[float, PropertyInfo(alias="passThreshold")]

    score_metric: Annotated[Literal["f1", "precision", "recall"], PropertyInfo(alias="scoreMetric")]


GlobalConfig: TypeAlias = Union[
    GlobalConfigCriterion,
    GlobalConfigGroundTruth,
    GlobalConfigOutputMatchStringConfig,
    GlobalConfigOutputMatchListConfig,
]
