# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .document import Document
from .documents.document_version import DocumentVersion

__all__ = ["DocumentActivateResponse"]


class DocumentActivateResponse(BaseModel):
    """Response after activating a document version"""

    document: Document

    new_active_version: DocumentVersion = FieldInfo(alias="newActiveVersion")
    """A specific version of a document with its content and metadata"""
