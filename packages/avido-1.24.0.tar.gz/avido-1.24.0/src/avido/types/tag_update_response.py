# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .tag import Tag
from .._models import BaseModel

__all__ = ["TagUpdateResponse"]


class TagUpdateResponse(BaseModel):
    """Successful response containing the tag data"""

    data: Tag
    """A tag that can be applied to documents for organization"""
