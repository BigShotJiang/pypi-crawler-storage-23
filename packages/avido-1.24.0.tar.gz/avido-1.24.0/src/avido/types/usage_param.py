# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UsageParam"]


class UsageParam(TypedDict, total=False):
    completion_tokens: Required[Annotated[int, PropertyInfo(alias="completionTokens")]]
    """Number of completion tokens used by the LLM."""

    prompt_tokens: Required[Annotated[int, PropertyInfo(alias="promptTokens")]]
    """Number of prompt tokens used by the LLM."""
