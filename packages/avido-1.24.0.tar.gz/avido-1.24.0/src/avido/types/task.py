# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from . import eval_definition as _eval_definition
from .._models import BaseModel

__all__ = ["Task", "EvalDefinition", "EvalDefinitionConfig", "TaskSchedule"]


class EvalDefinitionConfig(BaseModel):
    expected: Union[str, List[str]]


class EvalDefinition(BaseModel):
    eval_definition: _eval_definition.EvalDefinition = FieldInfo(alias="evalDefinition")

    config: Optional[EvalDefinitionConfig] = None


class TaskSchedule(BaseModel):
    """Task schedule schema"""

    criticality: Literal["LOW", "MEDIUM", "HIGH"]

    cron: str

    task_id: str = FieldInfo(alias="taskId")

    last_run_at: Optional[datetime] = FieldInfo(alias="lastRunAt", default=None)

    next_run_at: Optional[datetime] = FieldInfo(alias="nextRunAt", default=None)


class Task(BaseModel):
    """
    A task that represents a specific job-to-be-done by the LLM in the user application.
    """

    id: str
    """The unique identifier of the task"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the task was created"""

    description: str
    """The task description"""

    eval_definitions: List[EvalDefinition] = FieldInfo(alias="evalDefinitions")

    input_examples: List[str] = FieldInfo(alias="inputExamples")
    """Example inputs for the task"""

    metadata: Dict[str, object]
    """Optional metadata associated with the task.

    Returns null when no metadata is stored.
    """

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the task was last modified"""

    monitoring_pass_rate: Optional[float] = FieldInfo(alias="monitoringPassRate", default=None)
    """The 30 day pass rate for monitoring runs only, measured in percentage.

    Null when no monitoring runs exist.
    """

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """
    The 30 day pass rate for the task measured in percentage (excludes monitoring
    runs). Null when no tests have been run.
    """

    status: Literal["DEDUCED", "DRAFT", "ACTIVE"]
    """The status of the task.

    DEDUCED tasks are created from unmatched traces, DRAFT tasks are user-facing
    drafts, and ACTIVE tasks are production tasks.
    """

    title: str
    """The title of the task"""

    type: Literal["STATIC", "NORMAL"]
    """The type of task.

    Normal tasks have a dynamic user prompt, while adversarial tasks have a fixed
    user prompt.
    """

    last_test: Optional[datetime] = FieldInfo(alias="lastTest", default=None)
    """The date and time this task was last tested"""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """The ID of the parent task (for DEDUCED tasks linked to a DRAFT)"""

    simulated_prompt_schema: Optional[Dict[str, object]] = FieldInfo(alias="simulatedPromptSchema", default=None)
    """
    JSON schema that defines the structure for user prompts that should be generated
    for tests
    """

    task_schedule: Optional[TaskSchedule] = FieldInfo(alias="taskSchedule", default=None)
    """Task schedule schema"""

    topic_id: Optional[str] = FieldInfo(alias="topicId", default=None)
    """The ID of the topic this task belongs to"""

    trace_id: Optional[str] = FieldInfo(alias="traceId", default=None)
    """The ID of the trace this task was deduced from (only for DEDUCED tasks)"""
