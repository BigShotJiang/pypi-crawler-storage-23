# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["TestResult"]


class TestResult(BaseModel):
    __test__ = False
    average_score: float = FieldInfo(alias="averageScore")

    failed: int

    passed: int

    pass_rate: float = FieldInfo(alias="passRate")

    total: int
