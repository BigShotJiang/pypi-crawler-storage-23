# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import trace_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPagination, AsyncOffsetPagination
from ..types.trace import Trace
from .._base_client import AsyncPaginator, make_request_options
from ..types.trace_retrieve_response import TraceRetrieveResponse
from ..types.trace_retrieve_by_test_response import TraceRetrieveByTestResponse

__all__ = ["TracesResource", "AsyncTracesResource"]


class TracesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> TracesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return TracesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TracesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return TracesResourceWithStreamingResponse(self)

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TraceRetrieveResponse:
        """
        Retrieves detailed information about a specific trace.

        Args:
          id: The unique identifier of the trace

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {**self._client._api_key, "x-application-id": omit, **(extra_headers or {})}
        return self._get(
            f"/v0/traces/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TraceRetrieveResponse,
        )

    def list(
        self,
        *,
        has_error: bool,
        max_cost: float,
        max_duration: int,
        max_score: float,
        min_cost: float,
        min_duration: int,
        min_score: float,
        end_date: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        metadata_key: str | Omit = omit,
        metadata_value: str | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        reference_id: str | Omit = omit,
        search: str | Omit = omit,
        skip: int | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        test_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[Trace]:
        """
        Retrieve traces with associated steps, filtered by application ID and optional
        date parameters.

        Args:
          has_error: Filter traces with or without errors.

          max_cost: Filter traces with total cost less than or equal to this value.

          max_duration: Filter traces with total duration (ms) less than or equal to this value.

          max_score: Filter traces with eval score less than or equal to this value.

          min_cost: Filter traces with total cost greater than or equal to this value.

          min_duration: Filter traces with total duration (ms) greater than or equal to this value.

          min_score: Filter traces with eval score greater than or equal to this value.

          end_date: Filter traces created before this date (inclusive).

          limit: Number of items to include in the result set.

          metadata_key: Metadata key to filter on. Must be used together with metadataValue.

          metadata_value: Metadata value to filter on. Must be used together with metadataKey.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          reference_id: Filter traces by reference ID

          search: Full-text search across trace step content fields (input, output, toolInput,
              toolOutput, content, query, result).

          skip: Number of items to skip before starting to collect the result set.

          start_date: Filter traces created after this date (inclusive).

          test_id: Filter traces by test ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**self._client._api_key, "x-application-id": omit, **(extra_headers or {})}
        return self._get_api_list(
            "/v0/traces",
            page=SyncOffsetPagination[Trace],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "has_error": has_error,
                        "max_cost": max_cost,
                        "max_duration": max_duration,
                        "max_score": max_score,
                        "min_cost": min_cost,
                        "min_duration": min_duration,
                        "min_score": min_score,
                        "end_date": end_date,
                        "limit": limit,
                        "metadata_key": metadata_key,
                        "metadata_value": metadata_value,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "reference_id": reference_id,
                        "search": search,
                        "skip": skip,
                        "start_date": start_date,
                        "test_id": test_id,
                    },
                    trace_list_params.TraceListParams,
                ),
            ),
            model=Trace,
        )

    def retrieve_by_test(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TraceRetrieveByTestResponse:
        """
        Retrieves detailed information about a specific trace.

        Args:
          id: The unique identifier of the trace

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {**self._client._api_key, "x-application-id": omit, **(extra_headers or {})}
        return self._get(
            f"/v0/traces/by-test/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TraceRetrieveByTestResponse,
        )


class AsyncTracesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncTracesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncTracesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTracesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncTracesResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TraceRetrieveResponse:
        """
        Retrieves detailed information about a specific trace.

        Args:
          id: The unique identifier of the trace

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {**self._client._api_key, "x-application-id": omit, **(extra_headers or {})}
        return await self._get(
            f"/v0/traces/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TraceRetrieveResponse,
        )

    def list(
        self,
        *,
        has_error: bool,
        max_cost: float,
        max_duration: int,
        max_score: float,
        min_cost: float,
        min_duration: int,
        min_score: float,
        end_date: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        metadata_key: str | Omit = omit,
        metadata_value: str | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        reference_id: str | Omit = omit,
        search: str | Omit = omit,
        skip: int | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        test_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Trace, AsyncOffsetPagination[Trace]]:
        """
        Retrieve traces with associated steps, filtered by application ID and optional
        date parameters.

        Args:
          has_error: Filter traces with or without errors.

          max_cost: Filter traces with total cost less than or equal to this value.

          max_duration: Filter traces with total duration (ms) less than or equal to this value.

          max_score: Filter traces with eval score less than or equal to this value.

          min_cost: Filter traces with total cost greater than or equal to this value.

          min_duration: Filter traces with total duration (ms) greater than or equal to this value.

          min_score: Filter traces with eval score greater than or equal to this value.

          end_date: Filter traces created before this date (inclusive).

          limit: Number of items to include in the result set.

          metadata_key: Metadata key to filter on. Must be used together with metadataValue.

          metadata_value: Metadata value to filter on. Must be used together with metadataKey.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          reference_id: Filter traces by reference ID

          search: Full-text search across trace step content fields (input, output, toolInput,
              toolOutput, content, query, result).

          skip: Number of items to skip before starting to collect the result set.

          start_date: Filter traces created after this date (inclusive).

          test_id: Filter traces by test ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**self._client._api_key, "x-application-id": omit, **(extra_headers or {})}
        return self._get_api_list(
            "/v0/traces",
            page=AsyncOffsetPagination[Trace],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "has_error": has_error,
                        "max_cost": max_cost,
                        "max_duration": max_duration,
                        "max_score": max_score,
                        "min_cost": min_cost,
                        "min_duration": min_duration,
                        "min_score": min_score,
                        "end_date": end_date,
                        "limit": limit,
                        "metadata_key": metadata_key,
                        "metadata_value": metadata_value,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "reference_id": reference_id,
                        "search": search,
                        "skip": skip,
                        "start_date": start_date,
                        "test_id": test_id,
                    },
                    trace_list_params.TraceListParams,
                ),
            ),
            model=Trace,
        )

    async def retrieve_by_test(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TraceRetrieveByTestResponse:
        """
        Retrieves detailed information about a specific trace.

        Args:
          id: The unique identifier of the trace

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {**self._client._api_key, "x-application-id": omit, **(extra_headers or {})}
        return await self._get(
            f"/v0/traces/by-test/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TraceRetrieveByTestResponse,
        )


class TracesResourceWithRawResponse:
    def __init__(self, traces: TracesResource) -> None:
        self._traces = traces

        self.retrieve = to_raw_response_wrapper(
            traces.retrieve,
        )
        self.list = to_raw_response_wrapper(
            traces.list,
        )
        self.retrieve_by_test = to_raw_response_wrapper(
            traces.retrieve_by_test,
        )


class AsyncTracesResourceWithRawResponse:
    def __init__(self, traces: AsyncTracesResource) -> None:
        self._traces = traces

        self.retrieve = async_to_raw_response_wrapper(
            traces.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            traces.list,
        )
        self.retrieve_by_test = async_to_raw_response_wrapper(
            traces.retrieve_by_test,
        )


class TracesResourceWithStreamingResponse:
    def __init__(self, traces: TracesResource) -> None:
        self._traces = traces

        self.retrieve = to_streamed_response_wrapper(
            traces.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            traces.list,
        )
        self.retrieve_by_test = to_streamed_response_wrapper(
            traces.retrieve_by_test,
        )


class AsyncTracesResourceWithStreamingResponse:
    def __init__(self, traces: AsyncTracesResource) -> None:
        self._traces = traces

        self.retrieve = async_to_streamed_response_wrapper(
            traces.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            traces.list,
        )
        self.retrieve_by_test = async_to_streamed_response_wrapper(
            traces.retrieve_by_test,
        )
