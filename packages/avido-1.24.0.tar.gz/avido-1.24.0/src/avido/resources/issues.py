# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import IssueType, IssueSource, IssuePriority, issue_create_params
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.issue_type import IssueType
from ..types.issue_source import IssueSource
from ..types.issue_priority import IssuePriority

__all__ = ["IssuesResource", "AsyncIssuesResource"]


class IssuesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> IssuesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return IssuesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> IssuesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return IssuesResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        source: IssueSource,
        title: str,
        annotation_id: str | Omit = omit,
        description: Optional[str] | Omit = omit,
        eval_definition_id: str | Omit = omit,
        parent_id: str | Omit = omit,
        priority: IssuePriority | Omit = omit,
        task_id: str | Omit = omit,
        test_id: str | Omit = omit,
        topic_id: str | Omit = omit,
        trace_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Creates a new issue for tracking problems or improvements.

        Args:
          source: Where the issue originated from

          title: Title of the issue

          annotation_id: Associated annotation ID if related to an annotation

          description: Detailed description of the issue

          eval_definition_id: Associated evaluation definition ID if issue came from an evaluation

          parent_id: Parent issue ID for creating sub-issues

          priority: Priority level of the issue

          task_id: Associated task ID if issue came from a task

          test_id: Associated test ID if issue came from a test

          topic_id: Associated topic ID if issue came from a topic

          trace_id: Associated trace ID for monitoring/debugging

          type: Type/category of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers.update({**self._client._api_key, "x-application-id": omit})
        return self._post(
            "/v0/issues",
            body=maybe_transform(
                {
                    "source": source,
                    "title": title,
                    "annotation_id": annotation_id,
                    "description": description,
                    "eval_definition_id": eval_definition_id,
                    "parent_id": parent_id,
                    "priority": priority,
                    "task_id": task_id,
                    "test_id": test_id,
                    "topic_id": topic_id,
                    "trace_id": trace_id,
                    "type": type,
                },
                issue_create_params.IssueCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncIssuesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncIssuesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncIssuesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncIssuesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncIssuesResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        source: IssueSource,
        title: str,
        annotation_id: str | Omit = omit,
        description: Optional[str] | Omit = omit,
        eval_definition_id: str | Omit = omit,
        parent_id: str | Omit = omit,
        priority: IssuePriority | Omit = omit,
        task_id: str | Omit = omit,
        test_id: str | Omit = omit,
        topic_id: str | Omit = omit,
        trace_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Creates a new issue for tracking problems or improvements.

        Args:
          source: Where the issue originated from

          title: Title of the issue

          annotation_id: Associated annotation ID if related to an annotation

          description: Detailed description of the issue

          eval_definition_id: Associated evaluation definition ID if issue came from an evaluation

          parent_id: Parent issue ID for creating sub-issues

          priority: Priority level of the issue

          task_id: Associated task ID if issue came from a task

          test_id: Associated test ID if issue came from a test

          topic_id: Associated topic ID if issue came from a topic

          trace_id: Associated trace ID for monitoring/debugging

          type: Type/category of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        extra_headers.update({**self._client._api_key, "x-application-id": omit})
        return await self._post(
            "/v0/issues",
            body=await async_maybe_transform(
                {
                    "source": source,
                    "title": title,
                    "annotation_id": annotation_id,
                    "description": description,
                    "eval_definition_id": eval_definition_id,
                    "parent_id": parent_id,
                    "priority": priority,
                    "task_id": task_id,
                    "test_id": test_id,
                    "topic_id": topic_id,
                    "trace_id": trace_id,
                    "type": type,
                },
                issue_create_params.IssueCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class IssuesResourceWithRawResponse:
    def __init__(self, issues: IssuesResource) -> None:
        self._issues = issues

        self.create = to_raw_response_wrapper(
            issues.create,
        )


class AsyncIssuesResourceWithRawResponse:
    def __init__(self, issues: AsyncIssuesResource) -> None:
        self._issues = issues

        self.create = async_to_raw_response_wrapper(
            issues.create,
        )


class IssuesResourceWithStreamingResponse:
    def __init__(self, issues: IssuesResource) -> None:
        self._issues = issues

        self.create = to_streamed_response_wrapper(
            issues.create,
        )


class AsyncIssuesResourceWithStreamingResponse:
    def __init__(self, issues: AsyncIssuesResource) -> None:
        self._issues = issues

        self.create = async_to_streamed_response_wrapper(
            issues.create,
        )
