# ValidateWebhook

Types:

```python
from avido.types import ValidateWebhookValidateResponse
```

Methods:

- <code title="post /v0/validate-webhook">client.validate_webhook.<a href="./src/avido/resources/validate_webhook.py">validate</a>(\*\*<a href="src/avido/types/validate_webhook_validate_params.py">params</a>) -> <a href="./src/avido/types/validate_webhook_validate_response.py">ValidateWebhookValidateResponse</a></code>

# Applications

Types:

```python
from avido.types import Application, ApplicationRetrieveResponse
```

Methods:

- <code title="get /v0/applications/{id}">client.applications.<a href="./src/avido/resources/applications.py">retrieve</a>(id) -> <a href="./src/avido/types/application_retrieve_response.py">ApplicationRetrieveResponse</a></code>
- <code title="get /v0/applications">client.applications.<a href="./src/avido/resources/applications.py">list</a>(\*\*<a href="src/avido/types/application_list_params.py">params</a>) -> <a href="./src/avido/types/application.py">SyncOffsetPagination[Application]</a></code>

# Traces

Types:

```python
from avido.types import OtlpAttribute, Trace, TraceRetrieveResponse, TraceRetrieveByTestResponse
```

Methods:

- <code title="get /v0/traces/{id}">client.traces.<a href="./src/avido/resources/traces.py">retrieve</a>(id) -> <a href="./src/avido/types/trace_retrieve_response.py">TraceRetrieveResponse</a></code>
- <code title="get /v0/traces">client.traces.<a href="./src/avido/resources/traces.py">list</a>(\*\*<a href="src/avido/types/trace_list_params.py">params</a>) -> <a href="./src/avido/types/trace.py">SyncOffsetPagination[Trace]</a></code>
- <code title="get /v0/traces/by-test/{id}">client.traces.<a href="./src/avido/resources/traces.py">retrieve_by_test</a>(id) -> <a href="./src/avido/types/trace_retrieve_by_test_response.py">TraceRetrieveByTestResponse</a></code>

# Ingest

Types:

```python
from avido.types import Usage, IngestCreateResponse
```

Methods:

- <code title="post /v0/ingest">client.ingest.<a href="./src/avido/resources/ingest.py">create</a>(\*\*<a href="src/avido/types/ingest_create_params.py">params</a>) -> <a href="./src/avido/types/ingest_create_response.py">IngestCreateResponse</a></code>

# Tasks

Types:

```python
from avido.types import (
    CoreTag,
    Task,
    TaskCreateResponse,
    TaskRetrieveResponse,
    TaskUpdateResponse,
    TaskListResponse,
)
```

Methods:

- <code title="post /v0/tasks">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">create</a>(\*\*<a href="src/avido/types/task_create_params.py">params</a>) -> <a href="./src/avido/types/task_create_response.py">TaskCreateResponse</a></code>
- <code title="get /v0/tasks/{id}">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">retrieve</a>(id) -> <a href="./src/avido/types/task_retrieve_response.py">TaskRetrieveResponse</a></code>
- <code title="put /v0/tasks/{id}">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">update</a>(id, \*\*<a href="src/avido/types/task_update_params.py">params</a>) -> <a href="./src/avido/types/task_update_response.py">TaskUpdateResponse</a></code>
- <code title="get /v0/tasks">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">list</a>(\*\*<a href="src/avido/types/task_list_params.py">params</a>) -> <a href="./src/avido/types/task_list_response.py">SyncOffsetPagination[TaskListResponse]</a></code>
- <code title="post /v0/tasks/trigger">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">trigger</a>(\*\*<a href="src/avido/types/task_trigger_params.py">params</a>) -> None</code>

## Tags

Types:

```python
from avido.types.tasks import TagUpdateResponse, TagListResponse
```

Methods:

- <code title="put /v0/tasks/{id}/tags">client.tasks.tags.<a href="./src/avido/resources/tasks/tags.py">update</a>(id, \*\*<a href="src/avido/types/tasks/tag_update_params.py">params</a>) -> <a href="./src/avido/types/tasks/tag_update_response.py">TagUpdateResponse</a></code>
- <code title="get /v0/tasks/{id}/tags">client.tasks.tags.<a href="./src/avido/resources/tasks/tags.py">list</a>(id) -> <a href="./src/avido/types/tasks/tag_list_response.py">TagListResponse</a></code>

# Definitions

Types:

```python
from avido.types import EvalDefinition, EvalType, DefinitionCreateResponse, DefinitionUpdateResponse
```

Methods:

- <code title="post /v0/definitions">client.definitions.<a href="./src/avido/resources/definitions.py">create</a>(\*\*<a href="src/avido/types/definition_create_params.py">params</a>) -> <a href="./src/avido/types/definition_create_response.py">DefinitionCreateResponse</a></code>
- <code title="put /v0/definitions/{id}">client.definitions.<a href="./src/avido/resources/definitions.py">update</a>(id, \*\*<a href="src/avido/types/definition_update_params.py">params</a>) -> <a href="./src/avido/types/definition_update_response.py">DefinitionUpdateResponse</a></code>
- <code title="get /v0/definitions">client.definitions.<a href="./src/avido/resources/definitions.py">list</a>(\*\*<a href="src/avido/types/definition_list_params.py">params</a>) -> <a href="./src/avido/types/eval_definition.py">SyncOffsetPagination[EvalDefinition]</a></code>
- <code title="post /v0/definitions/link">client.definitions.<a href="./src/avido/resources/definitions.py">link</a>(\*\*<a href="src/avido/types/definition_link_params.py">params</a>) -> None</code>
- <code title="post /v0/definitions/unlink">client.definitions.<a href="./src/avido/resources/definitions.py">unlink</a>(\*\*<a href="src/avido/types/definition_unlink_params.py">params</a>) -> None</code>

# Tests

Types:

```python
from avido.types import RunType, TestResult, TestRetrieveResponse, TestListResponse
```

Methods:

- <code title="get /v0/tests/{id}">client.tests.<a href="./src/avido/resources/tests.py">retrieve</a>(id) -> <a href="./src/avido/types/test_retrieve_response.py">TestRetrieveResponse</a></code>
- <code title="get /v0/tests">client.tests.<a href="./src/avido/resources/tests.py">list</a>(\*\*<a href="src/avido/types/test_list_params.py">params</a>) -> <a href="./src/avido/types/test_list_response.py">SyncOffsetPagination[TestListResponse]</a></code>

# Topics

Types:

```python
from avido.types import Topic, TopicCreateResponse, TopicRetrieveResponse
```

Methods:

- <code title="post /v0/topics">client.topics.<a href="./src/avido/resources/topics.py">create</a>(\*\*<a href="src/avido/types/topic_create_params.py">params</a>) -> <a href="./src/avido/types/topic_create_response.py">TopicCreateResponse</a></code>
- <code title="get /v0/topics/{id}">client.topics.<a href="./src/avido/resources/topics.py">retrieve</a>(id) -> <a href="./src/avido/types/topic_retrieve_response.py">TopicRetrieveResponse</a></code>
- <code title="get /v0/topics">client.topics.<a href="./src/avido/resources/topics.py">list</a>(\*\*<a href="src/avido/types/topic_list_params.py">params</a>) -> <a href="./src/avido/types/topic.py">SyncOffsetPagination[Topic]</a></code>

# Issues

Types:

```python
from avido.types import IssuePriority, IssueSource, IssueStatus, IssueType
```

Methods:

- <code title="post /v0/issues">client.issues.<a href="./src/avido/resources/issues.py">create</a>(\*\*<a href="src/avido/types/issue_create_params.py">params</a>) -> None</code>

# StyleGuides

Types:

```python
from avido.types import (
    StyleGuide,
    StyleGuideSection,
    StyleGuideCreateResponse,
    StyleGuideRetrieveResponse,
    StyleGuideUpdateResponse,
)
```

Methods:

- <code title="post /v0/style-guides">client.style_guides.<a href="./src/avido/resources/style_guides.py">create</a>(\*\*<a href="src/avido/types/style_guide_create_params.py">params</a>) -> <a href="./src/avido/types/style_guide_create_response.py">StyleGuideCreateResponse</a></code>
- <code title="get /v0/style-guides/{id}">client.style_guides.<a href="./src/avido/resources/style_guides.py">retrieve</a>(id) -> <a href="./src/avido/types/style_guide_retrieve_response.py">StyleGuideRetrieveResponse</a></code>
- <code title="put /v0/style-guides/{id}">client.style_guides.<a href="./src/avido/resources/style_guides.py">update</a>(id, \*\*<a href="src/avido/types/style_guide_update_params.py">params</a>) -> <a href="./src/avido/types/style_guide_update_response.py">StyleGuideUpdateResponse</a></code>
- <code title="get /v0/style-guides">client.style_guides.<a href="./src/avido/resources/style_guides.py">list</a>(\*\*<a href="src/avido/types/style_guide_list_params.py">params</a>) -> <a href="./src/avido/types/style_guide.py">SyncOffsetPagination[StyleGuide]</a></code>

# Documents

Types:

```python
from avido.types import (
    Document,
    DocumentCreateResponse,
    DocumentRetrieveResponse,
    DocumentListResponse,
    DocumentActivateResponse,
)
```

Methods:

- <code title="post /v0/documents">client.documents.<a href="./src/avido/resources/documents/documents.py">create</a>(\*\*<a href="src/avido/types/document_create_params.py">params</a>) -> <a href="./src/avido/types/document_create_response.py">DocumentCreateResponse</a></code>
- <code title="get /v0/documents/{id}">client.documents.<a href="./src/avido/resources/documents/documents.py">retrieve</a>(id) -> <a href="./src/avido/types/document_retrieve_response.py">DocumentRetrieveResponse</a></code>
- <code title="get /v0/documents">client.documents.<a href="./src/avido/resources/documents/documents.py">list</a>(\*\*<a href="src/avido/types/document_list_params.py">params</a>) -> <a href="./src/avido/types/document_list_response.py">SyncOffsetPagination[DocumentListResponse]</a></code>
- <code title="put /v0/documents/{id}/versions/{versionNumber}/activate">client.documents.<a href="./src/avido/resources/documents/documents.py">activate</a>(version_number, \*, id) -> <a href="./src/avido/types/document_activate_response.py">DocumentActivateResponse</a></code>

## Versions

Types:

```python
from avido.types.documents import (
    DocumentVersion,
    VersionCreateResponse,
    VersionRetrieveResponse,
    VersionUpdateResponse,
    VersionListResponse,
)
```

Methods:

- <code title="post /v0/documents/{id}/versions">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">create</a>(id) -> <a href="./src/avido/types/documents/version_create_response.py">VersionCreateResponse</a></code>
- <code title="get /v0/documents/{id}/versions/{versionNumber}">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">retrieve</a>(version_number, \*, id) -> <a href="./src/avido/types/documents/version_retrieve_response.py">VersionRetrieveResponse</a></code>
- <code title="put /v0/documents/{id}/versions/{versionNumber}">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">update</a>(version_number, \*, id, \*\*<a href="src/avido/types/documents/version_update_params.py">params</a>) -> <a href="./src/avido/types/documents/version_update_response.py">VersionUpdateResponse</a></code>
- <code title="get /v0/documents/{id}/versions">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">list</a>(id) -> <a href="./src/avido/types/documents/version_list_response.py">VersionListResponse</a></code>

## Tags

Types:

```python
from avido.types.documents import TagUpdateResponse, TagListResponse
```

Methods:

- <code title="put /v0/documents/{id}/tags">client.documents.tags.<a href="./src/avido/resources/documents/tags.py">update</a>(id, \*\*<a href="src/avido/types/documents/tag_update_params.py">params</a>) -> <a href="./src/avido/types/documents/tag_update_response.py">TagUpdateResponse</a></code>
- <code title="get /v0/documents/{id}/tags">client.documents.tags.<a href="./src/avido/resources/documents/tags.py">list</a>(id) -> <a href="./src/avido/types/documents/tag_list_response.py">TagListResponse</a></code>

# Tags

Types:

```python
from avido.types import Tag, TagCreateResponse, TagRetrieveResponse, TagUpdateResponse
```

Methods:

- <code title="post /v0/tags">client.tags.<a href="./src/avido/resources/tags.py">create</a>(\*\*<a href="src/avido/types/tag_create_params.py">params</a>) -> <a href="./src/avido/types/tag_create_response.py">TagCreateResponse</a></code>
- <code title="get /v0/tags/{id}">client.tags.<a href="./src/avido/resources/tags.py">retrieve</a>(id) -> <a href="./src/avido/types/tag_retrieve_response.py">TagRetrieveResponse</a></code>
- <code title="put /v0/tags/{id}">client.tags.<a href="./src/avido/resources/tags.py">update</a>(id, \*\*<a href="src/avido/types/tag_update_params.py">params</a>) -> <a href="./src/avido/types/tag_update_response.py">TagUpdateResponse</a></code>
- <code title="get /v0/tags">client.tags.<a href="./src/avido/resources/tags.py">list</a>(\*\*<a href="src/avido/types/tag_list_params.py">params</a>) -> <a href="./src/avido/types/tag.py">SyncOffsetPagination[Tag]</a></code>
