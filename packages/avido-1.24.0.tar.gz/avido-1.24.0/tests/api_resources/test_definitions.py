# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from avido.types import (
    EvalDefinition,
    DefinitionCreateResponse,
    DefinitionUpdateResponse,
)
from tests.utils import assert_matches_type
from avido.pagination import SyncOffsetPagination, AsyncOffsetPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestDefinitions:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Avido) -> None:
        definition = client.definitions.create(
            name="Naturalness Check",
            type="NATURALNESS",
        )
        assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Avido) -> None:
        definition = client.definitions.create(
            name="Naturalness Check",
            type="NATURALNESS",
            global_config={"criterion": "x"},
            style_guide_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Avido) -> None:
        response = client.definitions.with_raw_response.create(
            name="Naturalness Check",
            type="NATURALNESS",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = response.parse()
        assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Avido) -> None:
        with client.definitions.with_streaming_response.create(
            name="Naturalness Check",
            type="NATURALNESS",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = response.parse()
            assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Avido) -> None:
        definition = client.definitions.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Avido) -> None:
        definition = client.definitions.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            global_config={"criterion": "x"},
            name="Updated Naturalness Check",
            style_guide_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Avido) -> None:
        response = client.definitions.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = response.parse()
        assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Avido) -> None:
        with client.definitions.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = response.parse()
            assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.definitions.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        definition = client.definitions.list()
        assert_matches_type(SyncOffsetPagination[EvalDefinition], definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Avido) -> None:
        definition = client.definitions.list(
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            status="COMPLETED",
            task_id="456e4567-e89b-12d3-a456-426614174000",
            trace_id="789e4567-e89b-12d3-a456-426614174000",
            type="NATURALNESS",
        )
        assert_matches_type(SyncOffsetPagination[EvalDefinition], definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.definitions.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = response.parse()
        assert_matches_type(SyncOffsetPagination[EvalDefinition], definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.definitions.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = response.parse()
            assert_matches_type(SyncOffsetPagination[EvalDefinition], definition, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_link(self, client: Avido) -> None:
        definition = client.definitions.link(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_link(self, client: Avido) -> None:
        response = client.definitions.with_raw_response.link(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = response.parse()
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_link(self, client: Avido) -> None:
        with client.definitions.with_streaming_response.link(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = response.parse()
            assert definition is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_unlink(self, client: Avido) -> None:
        definition = client.definitions.unlink(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_unlink(self, client: Avido) -> None:
        response = client.definitions.with_raw_response.unlink(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = response.parse()
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_unlink(self, client: Avido) -> None:
        with client.definitions.with_streaming_response.unlink(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = response.parse()
            assert definition is None

        assert cast(Any, response.is_closed) is True


class TestAsyncDefinitions:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.create(
            name="Naturalness Check",
            type="NATURALNESS",
        )
        assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.create(
            name="Naturalness Check",
            type="NATURALNESS",
            global_config={"criterion": "x"},
            style_guide_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncAvido) -> None:
        response = await async_client.definitions.with_raw_response.create(
            name="Naturalness Check",
            type="NATURALNESS",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = await response.parse()
        assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncAvido) -> None:
        async with async_client.definitions.with_streaming_response.create(
            name="Naturalness Check",
            type="NATURALNESS",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = await response.parse()
            assert_matches_type(DefinitionCreateResponse, definition, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            global_config={"criterion": "x"},
            name="Updated Naturalness Check",
            style_guide_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncAvido) -> None:
        response = await async_client.definitions.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = await response.parse()
        assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncAvido) -> None:
        async with async_client.definitions.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = await response.parse()
            assert_matches_type(DefinitionUpdateResponse, definition, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.definitions.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.list()
        assert_matches_type(AsyncOffsetPagination[EvalDefinition], definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.list(
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            status="COMPLETED",
            task_id="456e4567-e89b-12d3-a456-426614174000",
            trace_id="789e4567-e89b-12d3-a456-426614174000",
            type="NATURALNESS",
        )
        assert_matches_type(AsyncOffsetPagination[EvalDefinition], definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.definitions.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = await response.parse()
        assert_matches_type(AsyncOffsetPagination[EvalDefinition], definition, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.definitions.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = await response.parse()
            assert_matches_type(AsyncOffsetPagination[EvalDefinition], definition, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_link(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.link(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_link(self, async_client: AsyncAvido) -> None:
        response = await async_client.definitions.with_raw_response.link(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = await response.parse()
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_link(self, async_client: AsyncAvido) -> None:
        async with async_client.definitions.with_streaming_response.link(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = await response.parse()
            assert definition is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_unlink(self, async_client: AsyncAvido) -> None:
        definition = await async_client.definitions.unlink(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_unlink(self, async_client: AsyncAvido) -> None:
        response = await async_client.definitions.with_raw_response.unlink(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        definition = await response.parse()
        assert definition is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_unlink(self, async_client: AsyncAvido) -> None:
        async with async_client.definitions.with_streaming_response.unlink(
            eval_ids=["123e4567-e89b-12d3-a456-426614174000"],
            task_ids=["456e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            definition = await response.parse()
            assert definition is None

        assert cast(Any, response.is_closed) is True
