# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestIssues:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Avido) -> None:
        issue = client.issues.create(
            source="TEST",
            title="Response quality degradation",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Avido) -> None:
        issue = client.issues.create(
            source="TEST",
            title="Response quality degradation",
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            description="The chatbot is providing incomplete responses to user queries",
            eval_definition_id="789e4567-e89b-12d3-a456-426614174000",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            priority="HIGH",
            task_id="789e4567-e89b-12d3-a456-426614174000",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            topic_id="789e4567-e89b-12d3-a456-426614174000",
            trace_id="trace_abc123",
            type="BUG",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Avido) -> None:
        response = client.issues.with_raw_response.create(
            source="TEST",
            title="Response quality degradation",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Avido) -> None:
        with client.issues.with_streaming_response.create(
            source="TEST",
            title="Response quality degradation",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert issue is None

        assert cast(Any, response.is_closed) is True


class TestAsyncIssues:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.create(
            source="TEST",
            title="Response quality degradation",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.create(
            source="TEST",
            title="Response quality degradation",
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            description="The chatbot is providing incomplete responses to user queries",
            eval_definition_id="789e4567-e89b-12d3-a456-426614174000",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            priority="HIGH",
            task_id="789e4567-e89b-12d3-a456-426614174000",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            topic_id="789e4567-e89b-12d3-a456-426614174000",
            trace_id="trace_abc123",
            type="BUG",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.create(
            source="TEST",
            title="Response quality degradation",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.create(
            source="TEST",
            title="Response quality degradation",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert issue is None

        assert cast(Any, response.is_closed) is True
