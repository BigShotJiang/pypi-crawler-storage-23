import re
import glob
import enum
import click
import tomlkit
import yaml
import hashlib

from dataclasses import dataclass
from e80.lib.context import E80ContextObject
from typing import Optional, Generator
from pydantic import BaseModel
from pathlib import Path


DEFAULT_YAML_CONFIG_FILENAME = "8080.yaml"
DEFAULT_TOML_CONFIG_FILENAME = "8080.toml"


class ConfigFormat(enum.Enum):
    TOML = enum.auto()
    YAML = enum.auto()


class CloudProjectConfig(BaseModel):
    project: str
    project_slug: Optional[str] = None
    organization_slug: str
    entrypoint: str
    env_vars: Optional[dict[str, str]] = None
    gpu_count: Optional[int] = None
    cpu_mhz: Optional[int] = None
    memory_size_mb: Optional[int] = None
    include_files: Optional[list[str]] = None
    exclude_files: Optional[list[str]] = None

    def require_project(self):
        if self.project_slug is None:
            raise Exception(
                "Project was not created! Please create the project on the platform first."
            )


class ArtifactMetadata(BaseModel):
    python_version: str
    artifact_id: str | None
    dependencies_checksum: str
    project_files_mtime: float


@dataclass
class LocalUVSource:
    pkg: str
    path: str


class ProjectFiles:
    _config_path: Path

    def __init__(self, ctx_obj: E80ContextObject):
        """
        Class that helps you interact with project files.

        Expects you to be in a project directory or subdirectory. Throws an exception if a project file
        cannot be found.
        """
        self._config_path = _find_config_path(ctx_obj)

    def get_root(self) -> Path:
        return self._config_path.parent

    def get_cache_root(self) -> Path:
        return self.get_root() / ".8080_cache"

    def get_artifact_path(self) -> Path:
        return self.get_cache_root() / "artifact.zip"

    def read_project_config(self) -> CloudProjectConfig:
        with self._config_path.open(mode="r") as f:
            if self._config_path.suffix == ".yaml":
                config_dict = yaml.safe_load(f)
            else:
                config_dict = tomlkit.load(f)
            parsed = CloudProjectConfig.model_validate(config_dict)

            return parsed

    def write_project_config(self, config: CloudProjectConfig) -> None:
        model_dict = config.model_dump(exclude_none=True, exclude_unset=True)
        with self._config_path.open(mode="w") as f:
            if self._config_path.suffix == ".yaml":
                model_str = yaml.dump(model_dict)
            else:
                model_str = tomlkit.dumps(model_dict)
            f.write(model_str)

    def all_project_code_paths(self) -> Generator[Path]:
        project_config = self.read_project_config()

        include_regex = []
        if project_config.include_files:
            include_regex = [
                re.compile(glob.translate(i, recursive=True, include_hidden=True))
                for i in project_config.include_files
            ]
        exclude_regex = []
        if project_config.include_files:
            exclude_regex = [
                re.compile(glob.translate(i, recursive=True, include_hidden=True))
                for i in project_config.include_files
            ]

        for root, _, files in Path(self.get_root()).walk():
            for file in files:
                excluded = False
                for ex in exclude_regex:
                    if ex.match(file):
                        excluded = True
                if excluded:
                    continue

                is_hidden = False
                for p in root.parts:
                    if p.startswith("."):
                        is_hidden = True
                if file.startswith("."):
                    is_hidden = True

                if file.endswith(".py") and not is_hidden:
                    yield root / file
                    continue

                for inc in include_regex:
                    if inc.match(file):
                        yield root / file
                        break

    def read_project_code_mtime(self) -> float:
        latest_mtime = 0.0
        for file in self.all_project_code_paths():
            new_mtime = float(file.stat().st_mtime)
            if latest_mtime < new_mtime:
                latest_mtime = new_mtime
        return latest_mtime

    def delete_artifact_metadata(self) -> None:
        metadata_file = self.get_cache_root() / "metadata.json"
        if metadata_file.exists():
            metadata_file.unlink()

    def read_artifact_metadata(self) -> ArtifactMetadata | None:
        metadata_file = self.get_cache_root() / "metadata.json"
        if not metadata_file.exists():
            return None

        with open(metadata_file, "r") as f:
            metadata_json = f.read()

        return ArtifactMetadata.model_validate_json(metadata_json)

    def write_artifact_metadata(self, new_metadata: ArtifactMetadata) -> None:
        metadata_json = new_metadata.model_dump_json()

        metadata_file = self.get_cache_root() / "metadata.json"
        with open(metadata_file, "w") as f:
            f.write(metadata_json)

    def read_pyproject_checksum(self) -> str:
        with open(self.get_root() / "pyproject.toml", "rb") as f:
            pyproject_bytes = f.read()
        return hashlib.sha256(pyproject_bytes).hexdigest()

    def read_pyproject_local_sources(self) -> list[LocalUVSource]:
        """
        Basically a hack to allow us to package a local SDK into the artifact.
        Should not be used otherwise, and doesn't support every case.
        """
        with open(self.get_root() / "pyproject.toml", "r") as f:
            data = tomlkit.load(f)

            uv_sources = data.get("tool", {}).get("uv", {}).get("sources", {})

            sources = [
                LocalUVSource(pkg, data["path"])
                for pkg, data in uv_sources.items()
                if isinstance(data, dict) and data.get("path") is not None
            ]

            return sources


def boostrap_project_config(
    ctx_obj: E80ContextObject, config: CloudProjectConfig, format: ConfigFormat | None
) -> None:
    if ctx_obj.config_path is not None:
        path = ctx_obj.config_path
    elif format == ConfigFormat.YAML:
        path = Path(DEFAULT_YAML_CONFIG_FILENAME)
    else:
        path = Path(DEFAULT_TOML_CONFIG_FILENAME)

    with path.open(mode="w") as f:
        model_dict = config.model_dump(exclude_none=True, exclude_unset=True)
        if path.suffix == ".yaml":
            model_str = yaml.dump(model_dict)
        else:
            model_str = tomlkit.dumps(model_dict)
        f.write(model_str)


def _find_config_path(ctx_obj: E80ContextObject) -> Path:
    if ctx_obj.config_path is not None:
        if not ctx_obj.config_path.exists():
            raise click.ClickException(
                f"Config file '{ctx_obj.config_path}' was not found. Please make sure it exists, or run 8080 init to create one."
            )
        return ctx_obj.config_path
    else:
        start = Path.cwd()
        for directory in (start, *start.parents):
            toml_candidate = directory / DEFAULT_TOML_CONFIG_FILENAME
            if toml_candidate.exists():
                if directory != start:
                    click.echo(f"Found configuration file at: {toml_candidate}")
                return toml_candidate.resolve()

            yaml_candidate = directory / DEFAULT_YAML_CONFIG_FILENAME
            if yaml_candidate.exists():
                if directory != start:
                    click.echo(f"Found configuration file at: {yaml_candidate}")
                return yaml_candidate.resolve()

        raise click.ClickException(
            "Config not found. Run `8080 init` or provide --config to point to your 8080.yaml."
        )
