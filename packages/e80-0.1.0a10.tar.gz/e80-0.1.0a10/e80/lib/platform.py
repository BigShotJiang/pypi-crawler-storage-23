import json
import io
from math import ceil
from e80.lib.context import E80ContextObject
import httpx
from pydantic import BaseModel
from typing import BinaryIO, Any, Callable
from e80.lib.project import CloudProjectConfig

ProgressCallback = Callable[[int], None]


class PlatformClient:
    def __init__(self, ctx_obj: E80ContextObject, api_key: str):
        self.api_key = api_key
        self.base_url = ctx_obj.platform_host
        self.session = httpx.Client(
            headers={
                "Authorization": f"Bearer {self.api_key}",
            }
        )

    def list_organization_memberships(self) -> "ListOrganizationMembershipsResponse":
        resp = self.session.get(f"{self.base_url}/api/org")
        resp.raise_for_status()
        return ListOrganizationMembershipsResponse.model_validate(resp.json())

    def create_project(self, config: CloudProjectConfig) -> "CreateProjectResponse":
        resp = self.session.put(
            f"{self.base_url}/api/project/{config.organization_slug}",
            json={"project_name": config.project},
        )
        resp.raise_for_status()

        return CreateProjectResponse.model_validate(resp.json())

    def start_upload_artifact_part(
        self,
        config: CloudProjectConfig,
        artifact_metadata: "UploadArtifactMetadata",
    ) -> "StartUploadPartArtifactResponse":
        config.require_project()

        resp = self.session.post(
            f"{self.base_url}/api/endpoint/{config.organization_slug}/{config.project_slug}/artifact/multipart",
            json={
                "config": config.model_dump(),
                "artifact_metadata": artifact_metadata.model_dump(),
            },
        )
        resp.raise_for_status()

        return StartUploadPartArtifactResponse.model_validate(resp.json())

    def upload_artifact_part(
        self,
        config: CloudProjectConfig,
        artifact_id: str,
        part_num: int,
        part: bytes,
        callback: ProgressCallback,
    ):
        config.require_project()

        resp = self.session.post(
            f"{self.base_url}/api/endpoint/{config.organization_slug}/{config.project_slug}/artifact/multipart/{artifact_id}/{part_num}",
            files={
                "artifact_part": ProgressBytesIO(
                    delegate=io.BytesIO(part), callback=callback
                )
            },
            timeout=httpx.Timeout(10.0, read=30.0),
        )
        resp.raise_for_status()

    def finish_upload_artifact_part(self, config: CloudProjectConfig, artifact_id: str):
        config.require_project()

        resp = self.session.post(
            f"{self.base_url}/api/endpoint/{config.organization_slug}/{config.project_slug}/artifact/multipart/{artifact_id}"
        )
        resp.raise_for_status()

    def upload_artifact(
        self,
        config: CloudProjectConfig,
        artifact_metadata: "UploadArtifactMetadata",
        artifact: BinaryIO,
        callback: ProgressCallback,
    ) -> "UploadArtifactResponse":
        config.require_project()

        files: dict[str, BinaryIO | str] = {
            "metadata": json.dumps(
                {
                    "config": config.model_dump(),
                    "artifact_metadata": artifact_metadata.model_dump(),
                }
            ),
            "artifact.zip": ProgressBytesIO(delegate=artifact, callback=callback),
        }
        resp = self.session.post(
            f"{self.base_url}/api/endpoint/{config.organization_slug}/{config.project_slug}/artifact",
            files=files,
        )
        resp.raise_for_status()

        return UploadArtifactResponse.model_validate(resp.json())

    def deploy_artifact(
        self, config: CloudProjectConfig, artifact_id: str
    ) -> "DeployArtifactResponse":
        config.require_project()

        resp = self.session.post(
            f"{self.base_url}/api/endpoint/{config.organization_slug}/{config.project_slug}/deploy",
            json={"artifact_id": artifact_id},
        )
        resp.raise_for_status()

        return DeployArtifactResponse.model_validate(resp.json())

    def list_secrets_for_local(
        self, config: CloudProjectConfig
    ) -> "ListSecretsResponse":
        config.require_project()

        resp = self.session.get(
            f"{self.base_url}/api/secrets/{config.project_slug}?local=1"
        )
        resp.raise_for_status()
        return ListSecretsResponse.model_validate(resp.json())

    def create_sandbox(self, config: CloudProjectConfig) -> "CreateSandboxResponse":
        config.require_project()

        resp = self.session.post(
            f"{self.base_url}/api/sandbox/{config.organization_slug}/{config.project_slug}/deploy"
        )
        resp.raise_for_status()
        return CreateSandboxResponse.model_validate(resp.json())

    def list_sandboxes(self, config: CloudProjectConfig) -> "ListSandboxesResponse":
        config.require_project()

        resp = self.session.get(
            f"{self.base_url}/api/sandbox/{config.organization_slug}/{config.project_slug}/list"
        )
        resp.raise_for_status()
        return ListSandboxesResponse.model_validate(resp.json())

    def stop_sandbox(self, config: CloudProjectConfig, sandbox_id: str) -> None:
        config.require_project()
        resp = self.session.post(f"{self.base_url}/api/sandbox/{config.organization_slug}/{config.project_slug}/{sandbox_id}/stop")
        resp.raise_for_status()


class ProgressBytesIO(io.BytesIO):
    _increments = 1024

    def __init__(self, callback: ProgressCallback, delegate: BinaryIO):
        self._delegate = delegate
        self._callback = callback

    def tell(self):
        return self._delegate.tell()

    def seek(self, *args, **kwargs):
        return self._delegate.seek(*args, **kwargs)

    def fileno(self):
        return self._delegate.fileno()

    def read(self, size=-1):
        return self.read1(size)

    def read1(self, size=-1):
        if size == -1:
            return self._read_rest()
        else:
            return self._read_bytes(size)

    def _read_rest(self) -> bytes:
        bytes_to_return = bytearray()
        while True:
            read = self._delegate.read(self._increments)
            if not read:
                break
            bytes_to_return.extend(read)
            self._callback(len(read))
        return bytes(bytes_to_return)

    def _read_bytes(self, limit: int) -> bytes:
        bytes_to_return = bytearray()
        for _ in range(0, ceil(limit / self._increments)):
            bytes_read = self._delegate.read(self._increments)
            if not bytes_read:
                break
            bytes_to_return.extend(bytes_read)
            self._callback(len(bytes_read))
        return bytes(bytes_to_return)


class CreateProjectResponse(BaseModel):
    project_id: str
    project_slug: str


class OrganizationMembership(BaseModel):
    organization_id: str
    organization_name: str
    organization_slug: str
    membership: int


class UploadArtifactResponse(BaseModel):
    artifact_id: str


class StartUploadPartArtifactResponse(BaseModel):
    artifact_id: str


class DeployArtifactResponse(BaseModel):
    deployment_id: str


class UploadArtifactMetadata(BaseModel):
    python_version: str


class ListOrganizationMembershipsResponse(BaseModel):
    memberships: list[OrganizationMembership]


class Secret(BaseModel):
    name: str
    type: str
    value: Any


class ListSecretsResponse(BaseModel):
    secrets: list[Secret]


class CreateSandboxResponse(BaseModel):
    id: str


class SandboxInfo(BaseModel, extra="allow"):
    """Sandbox information from the list API."""

    id: str
    created: str
    terminated: str | None


class ListSandboxesResponse(BaseModel):
    sandboxes: list[SandboxInfo]
