from e80.lib.context import E80ContextObject
import yaml

from pydantic import BaseModel, Field
from pathlib import Path


class AuthInfo(BaseModel):
    auth_token: str


class UserConfig(BaseModel):
    auth_info: dict[str, AuthInfo] = Field(default_factory=dict)
    project_api_keys: dict[str, str] = Field(default_factory=dict)
    api_url: str = "https://app.8080.io"


def get_auth_info(ctx_obj: E80ContextObject) -> AuthInfo | None:
    user_config = read_user_config()
    if user_config is None:
        return None

    auth = user_config.auth_info.get(ctx_obj.platform_host)
    if auth is None:
        return None

    return auth


def read_user_config() -> UserConfig | None:
    config = Path.home() / ".8080" / "user.yaml"

    if not config.exists():
        return None

    with config.open() as f:
        yaml_dict = yaml.safe_load(f)
        if not yaml_dict:
            return None
        parsed = UserConfig.model_validate(yaml_dict)
        return parsed


def write_user_config(config: UserConfig):
    config_dir = Path.home() / ".8080"

    if not config_dir.exists():
        config_dir.mkdir(parents=True, exist_ok=True)

    file = config_dir / "user.yaml"

    with file.open(mode="w") as f:
        model_dict = config.model_dump()
        model_str = yaml.dump(model_dict)
        f.write(model_str)


def get_project_api_key(project_slug: str) -> str | None:
    """Get the stored API key for a project."""
    user_config = read_user_config()
    if user_config is None:
        return None
    return user_config.project_api_keys.get(project_slug)


def set_project_api_key(project_slug: str, api_key: str) -> None:
    """Store an API key for a project."""
    user_config = read_user_config()
    if user_config is None:
        user_config = UserConfig()
    user_config.project_api_keys[project_slug] = api_key
    write_user_config(user_config)
