"""Basket (Hyper) resource for the NemlAI SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from nemlai.client import NemlAI


class BasketResource:
    """Manage the smart basket via the Hyper endpoints."""

    _VALID_SIZES = {"small", "medium", "large", "xl", "full"}

    def __init__(self, client: "NemlAI") -> None:
        self._client = client

    def status(self) -> str:
        """GET ``/cli/api/hyper/status`` -- basket unlock status."""
        return self._client._get("/cli/api/hyper/status")

    def generate(
        self,
        size: str = "medium",
        date: Optional[str] = None,
        items: Optional[str] = None,
    ) -> str:
        """POST ``/cli/api/hyper/generate`` -- generate a smart basket."""
        if size not in self._VALID_SIZES:
            raise ValueError(f"Invalid size: {size!r}. Must be one of: {', '.join(sorted(self._VALID_SIZES))}")
        payload: dict = {"size": size}
        if date is not None:
            payload["date"] = date
        if items is not None:
            payload["items"] = items
        return self._client._post("/cli/api/hyper/generate", json=payload)

    def items(self) -> str:
        """GET ``/cli/api/hyper/items`` -- list items in the current basket."""
        return self._client._get("/cli/api/hyper/items")

    def add(self, query: str) -> str:
        """POST ``/cli/api/hyper/add`` -- add an item to the basket."""
        if not query or not query.strip():
            raise ValueError("Search query must be non-empty")
        return self._client._post("/cli/api/hyper/add", json={"query": query})

    def remove(self, item: str) -> str:
        """POST ``/cli/api/hyper/remove`` -- remove an item from the basket."""
        if not item or not item.strip():
            raise ValueError("Item identifier must be non-empty")
        return self._client._post("/cli/api/hyper/remove", json={"item": item})

    def adjust(self, item: str, quantity: str) -> str:
        """POST ``/cli/api/hyper/adjust`` -- adjust item quantity."""
        if not item or not item.strip():
            raise ValueError("Item identifier must be non-empty")
        # Validate quantity is a valid integer string
        try:
            q = int(quantity)
        except (ValueError, TypeError):
            raise ValueError(f"Quantity must be a valid integer, got: {quantity!r}")
        if q < 0:
            raise ValueError("Quantity must be non-negative")
        return self._client._post(
            "/cli/api/hyper/adjust", json={"item": item, "quantity": quantity}
        )

    def send(self) -> str:
        """POST ``/cli/api/hyper/send`` -- send basket to Nemlig."""
        return self._client._post("/cli/api/hyper/send")

    def search(self, query: str) -> str:
        """POST ``/cli/api/hyper/search`` -- search for products."""
        if not query or not query.strip():
            raise ValueError("Search query must be non-empty")
        return self._client._post("/cli/api/hyper/search", json={"query": query})

    def dish(self, query: str) -> str:
        """POST ``/cli/api/hyper/dish`` -- search for a dish via Dify AI."""
        if not query or not query.strip():
            raise ValueError("Dish query must be non-empty")
        return self._client._post("/cli/api/hyper/dish", json={"query": query})
