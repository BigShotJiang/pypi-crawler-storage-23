"""NemlAI Python SDK — a thin client for the NemlAI CLI API."""

from nemlai.client import NemlAI, NemlAIError, parse_response

__version__ = "0.4.1"

__all__ = ["NemlAI", "NemlAIError", "parse_response", "__version__"]
