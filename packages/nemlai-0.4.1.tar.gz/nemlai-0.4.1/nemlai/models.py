"""Data models used by the SDK."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BasketItem:
    """A single item in the basket."""

    id: str
    name: str
    price: float
    quantity: int = 1
    is_eco: bool = False
    on_sale: bool = False
    index: int = 0

    def __post_init__(self) -> None:
        if not self.id:
            raise ValueError("BasketItem id must be non-empty")
        if self.price < 0:
            raise ValueError("BasketItem price must be non-negative")
        if self.quantity < 1:
            raise ValueError("BasketItem quantity must be at least 1")
