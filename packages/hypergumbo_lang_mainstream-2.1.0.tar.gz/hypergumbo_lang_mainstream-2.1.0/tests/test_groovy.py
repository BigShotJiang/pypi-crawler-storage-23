"""Tests for Groovy analyzer."""
from pathlib import Path

import pytest

from hypergumbo_core.analyze.base import find_child_by_type
from hypergumbo_lang_mainstream import groovy as groovy_module
from unittest.mock import patch

class TestGroovyHelpers:
    """Tests for Groovy analyzer helper functions."""

    def test_find_child_by_type_returns_none(self) -> None:
        """Returns None when no matching child type is found."""
        from unittest.mock import MagicMock

        # Create a mock node with no children matching the type
        mock_node = MagicMock()
        mock_child = MagicMock()
        mock_child.type = "different_type"
        mock_node.children = [mock_child]

        result = find_child_by_type(mock_node, "identifier")
        assert result is None

class TestFindGroovyFiles:
    """Tests for Groovy file discovery."""

    def test_finds_groovy_files(self, tmp_path: Path) -> None:
        """Finds .groovy files."""
        from hypergumbo_lang_mainstream.groovy import find_groovy_files

        (tmp_path / "Main.groovy").write_text("class Main {}")
        (tmp_path / "build.gradle").write_text("apply plugin: 'java'")
        (tmp_path / "other.txt").write_text("not groovy")

        files = list(find_groovy_files(tmp_path))

        assert len(files) == 2
        assert any(f.suffix == ".groovy" for f in files)
        assert any(f.name == "build.gradle" for f in files)

class TestGroovyTreeSitterAvailability:
    """Tests for tree-sitter-groovy availability checking."""

    def test_is_groovy_tree_sitter_available_true(self) -> None:
        """Returns True when tree-sitter-groovy is available."""
        from hypergumbo_lang_mainstream.groovy import is_groovy_tree_sitter_available

        # Grammar is actually installed in the dev environment
        assert is_groovy_tree_sitter_available() is True

    def test_is_groovy_tree_sitter_available_false(self) -> None:
        """Returns False when grammar is not available."""
        from hypergumbo_lang_mainstream.groovy import is_groovy_tree_sitter_available

        with patch.object(groovy_module._analyzer, "_check_grammar_available", return_value=False):
            assert is_groovy_tree_sitter_available() is False

class TestAnalyzeGroovyFallback:
    """Tests for fallback behavior when tree-sitter-groovy unavailable."""

    def test_returns_skipped_when_unavailable(self, tmp_path: Path) -> None:
        """Returns skipped result when tree-sitter-groovy unavailable."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "test.groovy").write_text("def test() {}")

        with patch.object(groovy_module._analyzer, "_check_grammar_available", return_value=False):
            with pytest.warns(UserWarning, match="groovy analysis skipped"):
                result = analyze_groovy(tmp_path)

        assert result.skipped is True
        assert "not available" in result.skip_reason
        assert result.run is not None

class TestGroovyClassExtraction:
    """Tests for extracting Groovy classes."""

    def test_extracts_class(self, tmp_path: Path) -> None:
        """Extracts class declarations."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Main.groovy"
        groovy_file.write_text("""
class User {
    String name

    void greet() {
        println("Hello, $name!")
    }
}

class Config {
    static String version = "1.0"
}
""")

        result = analyze_groovy(tmp_path)

        assert result.run is not None
        assert result.run.files_analyzed == 1
        classes = [s for s in result.symbols if s.kind == "class"]
        class_names = [s.name for s in classes]
        assert "User" in class_names
        assert "Config" in class_names

class TestGroovyMethodExtraction:
    """Tests for extracting Groovy methods."""

    def test_extracts_methods(self, tmp_path: Path) -> None:
        """Extracts method declarations from classes."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Utils.groovy"
        groovy_file.write_text("""
class Utils {
    void doSomething() {
        println "doing something"
    }

    int calculate(int a, int b) {
        return a + b
    }
}
""")

        result = analyze_groovy(tmp_path)

        methods = [s for s in result.symbols if s.kind == "method"]
        method_names = [s.name for s in methods]
        assert "Utils.doSomething" in method_names
        assert "Utils.calculate" in method_names

class TestGroovyFunctionExtraction:
    """Tests for extracting Groovy top-level functions."""

    def test_extracts_functions(self, tmp_path: Path) -> None:
        """Extracts top-level function definitions."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "scripts.groovy"
        groovy_file.write_text("""
def greet(name) {
    println "Hello, $name!"
}

def calculate(a, b) {
    return a + b
}
""")

        result = analyze_groovy(tmp_path)

        functions = [s for s in result.symbols if s.kind == "function"]
        func_names = [s.name for s in functions]
        assert "greet" in func_names
        assert "calculate" in func_names

class TestGroovyImportEdges:
    """Tests for extracting import statements."""

    def test_extracts_imports(self, tmp_path: Path) -> None:
        """Extracts import statements as edges."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Main.groovy"
        groovy_file.write_text("""
import groovy.json.JsonSlurper
import java.util.List

class Main {
    void parse() {
        def slurper = new JsonSlurper()
    }
}
""")

        result = analyze_groovy(tmp_path)

        import_edges = [e for e in result.edges if e.edge_type == "imports"]
        assert len(import_edges) == 2

        imported = [e.dst for e in import_edges]
        assert any("groovy.json.JsonSlurper" in dst for dst in imported)
        assert any("java.util.List" in dst for dst in imported)

class TestGroovyCallEdges:
    """Tests for extracting function call edges."""

    def test_extracts_call_edges(self, tmp_path: Path) -> None:
        """Extracts call edges between functions."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Main.groovy"
        groovy_file.write_text("""
class Helper {
    void doWork() {
        println "working"
    }
}

class Main {
    void run() {
        helper()
    }

    void helper() {
        println "helping"
    }
}
""")

        result = analyze_groovy(tmp_path)

        call_edges = [e for e in result.edges if e.edge_type == "calls"]
        # Should find run() calling helper()
        assert len(call_edges) >= 1

        # Verify at least one call edge exists
        src_names = [e.src for e in call_edges]
        dst_names = [e.dst for e in call_edges]
        assert any("run" in src or "Main.run" in src for src in src_names)

    def test_extracts_cross_file_call_edges(self, tmp_path: Path) -> None:
        """Extracts call edges between functions in different files."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        helper_file = tmp_path / "Helper.groovy"
        helper_file.write_text("""
class Helper {
    void doWork() {
        println "working"
    }
}
""")

        main_file = tmp_path / "Main.groovy"
        main_file.write_text("""
class Main {
    void run() {
        doWork()
    }
}
""")

        result = analyze_groovy(tmp_path)

        call_edges = [e for e in result.edges if e.edge_type == "calls"]
        # Should find run() calling doWork() (cross-file via global symbols)
        assert len(call_edges) >= 1

        # Cross-file call: suffix match (0.85) * base (0.80) = 0.68
        cross_file_edges = [e for e in call_edges if 0.50 <= e.confidence <= 0.85]
        assert len(cross_file_edges) >= 1

class TestGradleBuildFile:
    """Tests for analyzing Gradle build files."""

    def test_analyzes_gradle_file(self, tmp_path: Path) -> None:
        """Analyzes .gradle files."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        gradle_file = tmp_path / "build.gradle"
        gradle_file.write_text("""
plugins {
    id 'java'
    id 'application'
}

repositories {
    mavenCentral()
}

dependencies {
    implementation 'org.codehaus.groovy:groovy-all:3.0.9'
}

def customTask() {
    println "Custom task"
}
""")

        result = analyze_groovy(tmp_path)

        assert result.run is not None
        assert result.run.files_analyzed == 1

class TestGroovyInterfaceExtraction:
    """Tests for extracting Groovy interfaces."""

    def test_extracts_interface(self, tmp_path: Path) -> None:
        """Extracts interface declarations."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Api.groovy"
        groovy_file.write_text("""
interface Greeter {
    void greet(String name)
    String getMessage()
}

interface Calculator {
    int add(int a, int b)
}
""")

        result = analyze_groovy(tmp_path)

        interfaces = [s for s in result.symbols if s.kind == "interface"]
        interface_names = [s.name for s in interfaces]
        assert "Greeter" in interface_names
        assert "Calculator" in interface_names

class TestGroovyTraitExtraction:
    """Tests for extracting Groovy traits.

    Note: The tree-sitter-groovy grammar (v0.1.2) does not fully support
    trait declarations - it parses 'trait X' as a function call. This test
    documents the current behavior and will pass once the grammar is updated.
    """

    def test_trait_parsing_limitation(self, tmp_path: Path) -> None:
        """Documents trait parsing limitation in tree-sitter-groovy grammar."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Traits.groovy"
        groovy_file.write_text("""
trait Flyable {
    void fly() {
        println "Flying"
    }
}
""")

        result = analyze_groovy(tmp_path)

        # tree-sitter-groovy v0.1.2 parses 'trait X' as a function call
        # not a trait declaration. This test documents this limitation.
        # When the grammar is updated, this test should be updated.
        traits = [s for s in result.symbols if s.kind == "trait"]
        # Currently 0 traits due to grammar limitation
        assert len(traits) == 0

class TestGroovyEnumExtraction:
    """Tests for extracting Groovy enums."""

    def test_extracts_enum(self, tmp_path: Path) -> None:
        """Extracts enum declarations."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Enums.groovy"
        groovy_file.write_text("""
enum Color {
    RED, GREEN, BLUE
}

enum Status {
    PENDING, ACTIVE, COMPLETED
}
""")

        result = analyze_groovy(tmp_path)

        enums = [s for s in result.symbols if s.kind == "enum"]
        enum_names = [s.name for s in enums]
        assert "Color" in enum_names
        assert "Status" in enum_names

class TestGroovySymbolProperties:
    """Tests for symbol property correctness."""

    def test_symbol_has_correct_span(self, tmp_path: Path) -> None:
        """Symbols have correct line number spans."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Test.groovy"
        groovy_file.write_text("""class Test {
    void method() {
        println "test"
    }
}
""")

        result = analyze_groovy(tmp_path)

        test_class = next((s for s in result.symbols if s.name == "Test"), None)
        assert test_class is not None
        assert test_class.span.start_line == 1
        assert test_class.language == "groovy"
        assert test_class.origin == "groovy-v1"

    def test_method_prefixed_with_class(self, tmp_path: Path) -> None:
        """Methods are prefixed with class name."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Example.groovy"
        groovy_file.write_text("""
class Example {
    void run() {}
}
""")

        result = analyze_groovy(tmp_path)

        methods = [s for s in result.symbols if s.kind == "method"]
        assert any(s.name == "Example.run" for s in methods)

class TestGroovyEdgeProperties:
    """Tests for edge property correctness."""

    def test_edge_has_confidence(self, tmp_path: Path) -> None:
        """Edges have confidence values."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Test.groovy"
        groovy_file.write_text("""
import java.util.List

class Test {}
""")

        result = analyze_groovy(tmp_path)

        import_edges = [e for e in result.edges if e.edge_type == "imports"]
        for edge in import_edges:
            assert edge.confidence > 0
            assert edge.confidence <= 1.0

class TestGroovyEmptyFile:
    """Tests for handling empty or minimal files."""

    def test_handles_empty_file(self, tmp_path: Path) -> None:
        """Handles empty Groovy files gracefully."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Empty.groovy"
        groovy_file.write_text("")

        result = analyze_groovy(tmp_path)

        # Should not crash, may have 0 or minimal symbols
        assert result.run is not None

    def test_handles_comment_only_file(self, tmp_path: Path) -> None:
        """Handles files with only comments."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "Comments.groovy"
        groovy_file.write_text("""
// This is a comment
/* Multi-line
   comment */
""")

        result = analyze_groovy(tmp_path)

        assert result.run is not None

class TestGroovyEmptyRepo:
    """Tests for empty repository handling."""

    def test_empty_repo(self, tmp_path: Path) -> None:
        """Empty repo returns result with run metadata and zero files."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        result = analyze_groovy(tmp_path)

        assert result.run is not None
        assert result.run.files_analyzed == 0

    def test_handles_unreadable_file(self, tmp_path: Path) -> None:
        """Handles files that can't be read."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        # Create a valid groovy file and an unreadable one
        valid_file = tmp_path / "Valid.groovy"
        valid_file.write_text("class Valid {}")

        unreadable = tmp_path / "Unreadable.groovy"
        unreadable.write_text("class Unreadable {}")

        result = analyze_groovy(tmp_path)

        # Should still process the valid file
        assert result.run is not None

class TestGroovySignatureExtraction:
    """Tests for Groovy method signature extraction.

    Note: Groovy's tree-sitter grammar uses dynamic parameter types,
    so we only capture parameter names in most cases.
    """

    def test_params_extraction(self, tmp_path: Path) -> None:
        """Extracts signature with parameter names."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Calculator.groovy").write_text("""
class Calculator {
    int add(int x, int y) {
        return x + y
    }
}
""")
        result = analyze_groovy(tmp_path)
        methods = [s for s in result.symbols if s.kind == "method" and "add" in s.name]
        assert len(methods) == 1
        # Groovy's grammar has limited type info, but captures params
        assert methods[0].signature is not None
        assert "x" in methods[0].signature
        assert "y" in methods[0].signature

    def test_void_return_type_omitted(self, tmp_path: Path) -> None:
        """Void return type is omitted from signature."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Logger.groovy").write_text("""
class Logger {
    void log(String message) {
        println message
    }
}
""")
        result = analyze_groovy(tmp_path)
        methods = [s for s in result.symbols if s.kind == "method" and "log" in s.name]
        assert len(methods) == 1
        # Should have message param, no return type (void is omitted)
        assert "message" in methods[0].signature
        assert "void" not in methods[0].signature

    def test_no_params_function(self, tmp_path: Path) -> None:
        """Extracts signature for method with no parameters."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Counter.groovy").write_text("""
class Counter {
    int getCount() {
        return 0
    }
}
""")
        result = analyze_groovy(tmp_path)
        methods = [s for s in result.symbols if s.kind == "method" and "getCount" in s.name]
        assert len(methods) == 1
        # Empty params
        assert methods[0].signature == "()"

class TestGroovyImportAliases:
    """Tests for import alias extraction and qualified call resolution."""

    def test_extracts_import_alias(self, tmp_path: Path) -> None:
        """Extracts import alias from 'import as' statement."""
        from hypergumbo_lang_mainstream.groovy import _extract_import_aliases
        import tree_sitter
        import tree_sitter_groovy

        lang = tree_sitter.Language(tree_sitter_groovy.language())
        parser = tree_sitter.Parser(lang)

        groovy_file = tmp_path / "Main.groovy"
        groovy_file.write_text("""
import java.util.List as JList
import groovy.json.JsonSlurper as JS

class Main {
    void process() {
        JList items = []
        def parser = new JS()
    }
}
""")

        source = groovy_file.read_bytes()
        tree = parser.parse(source)

        aliases = _extract_import_aliases(tree, source)

        # Both aliases should be extracted
        assert "JList" in aliases
        assert aliases["JList"] == "java.util.List"
        assert "JS" in aliases
        assert aliases["JS"] == "groovy.json.JsonSlurper"

    def test_qualified_call_uses_alias(self, tmp_path: Path) -> None:
        """Qualified call resolution uses import alias for path hint."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        # Note: Coll.sort is an external JDK call, so no edge is created
        # (we don't have the JDK in our symbol table).
        # This test verifies the code path works without crashing.
        (tmp_path / "main.groovy").write_text("""
import java.util.Collections as Coll

class Main {
    void process() {
        Coll.sort([])
    }
}
""")

        result = analyze_groovy(tmp_path)

        # Should have call edge (we can't verify path_hint directly but can verify it doesn't crash)
        assert not result.skipped
        symbols = [s for s in result.symbols if s.kind in ("method", "class")]
        assert any(s.name == "Main" for s in symbols)

        # External calls (JDK) don't create edges since we don't have those symbols
        # But import edge should exist
        import_edges = [e for e in result.edges if e.edge_type == "imports"]
        assert any("Collections" in e.dst for e in import_edges)

    def test_import_alias_helps_cross_file_resolution(self, tmp_path: Path) -> None:
        """Import alias helps disambiguate calls to local symbols."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        # Create a Utils class in its own file
        (tmp_path / "utils/Utils.groovy").mkdir(parents=True, exist_ok=True)
        # Workaround: just write in tmp_path
        (tmp_path / "Utils.groovy").write_text("""
class Utils {
    static void helper() {
        println "helping"
    }
}
""")

        # Main class that calls Utils.helper
        (tmp_path / "Main.groovy").write_text("""
class Main {
    void run() {
        Utils.helper()
    }
}
""")

        result = analyze_groovy(tmp_path)

        assert not result.skipped

        # Should have call edge from Main.run to Utils.helper
        call_edges = [e for e in result.edges if e.edge_type == "calls"]
        run_calls = [e for e in call_edges if "run" in e.src]
        assert len(run_calls) >= 1
        assert any("helper" in e.dst for e in run_calls)

class TestGroovyInheritanceEdges:
    """Tests for Groovy base_classes metadata extraction.

    The inheritance linker creates edges from base_classes metadata.
    These tests verify that the Groovy analyzer extracts base_classes correctly.
    """

    def test_class_extends_class_has_base_classes(self, tmp_path: Path) -> None:
        """Class extending another class has base_classes metadata."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Models.groovy").write_text("""
class BaseModel {
    void save() {}
}

class User extends BaseModel {
    void greet() {}
}
""")
        result = analyze_groovy(tmp_path)

        user_class = next(
            (s for s in result.symbols if s.name == "User" and s.kind == "class"),
            None,
        )
        assert user_class is not None
        assert user_class.meta is not None
        assert "base_classes" in user_class.meta
        assert "BaseModel" in user_class.meta["base_classes"]

    def test_class_implements_interface_has_base_classes(self, tmp_path: Path) -> None:
        """Class implementing interface has base_classes metadata."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Models.groovy").write_text("""
interface Serializable {
    String serialize()
}

class User implements Serializable {
    String serialize() { return "" }
}
""")
        result = analyze_groovy(tmp_path)

        user_class = next(
            (s for s in result.symbols if s.name == "User" and s.kind == "class"),
            None,
        )
        assert user_class is not None
        assert user_class.meta is not None
        assert "base_classes" in user_class.meta
        assert "Serializable" in user_class.meta["base_classes"]

    def test_class_extends_and_implements_has_both(self, tmp_path: Path) -> None:
        """Class extending and implementing has both in base_classes."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Models.groovy").write_text("""
class BaseModel {}
interface Serializable {}
interface Comparable {}

class User extends BaseModel implements Serializable, Comparable {
    void save() {}
}
""")
        result = analyze_groovy(tmp_path)

        user_class = next(
            (s for s in result.symbols if s.name == "User" and s.kind == "class"),
            None,
        )
        assert user_class is not None
        assert user_class.meta is not None
        assert "base_classes" in user_class.meta
        assert "BaseModel" in user_class.meta["base_classes"]
        assert "Serializable" in user_class.meta["base_classes"]
        assert "Comparable" in user_class.meta["base_classes"]

    def test_generic_base_class_strips_type_params(self, tmp_path: Path) -> None:
        """Generic base class has type params stripped in base_classes."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Repository.groovy").write_text("""
class Repository<T> {
    T find() { return null }
}

class UserRepository extends Repository<User> {
    User findByName(String name) { return null }
}

class User {}
""")
        result = analyze_groovy(tmp_path)

        user_repo = next(
            (s for s in result.symbols if s.name == "UserRepository" and s.kind == "class"),
            None,
        )
        assert user_repo is not None
        assert user_repo.meta is not None
        assert "base_classes" in user_repo.meta
        # Should be "Repository", not "Repository<User>"
        assert "Repository" in user_repo.meta["base_classes"]

    def test_generic_interface_strips_type_params(self, tmp_path: Path) -> None:
        """Generic interface has type params stripped in base_classes."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Comparable.groovy").write_text("""
interface Comparable<T> {
    int compareTo(T other)
}

class User implements Comparable<User> {
    int compareTo(User other) { return 0 }
}
""")
        result = analyze_groovy(tmp_path)

        user_class = next(
            (s for s in result.symbols if s.name == "User" and s.kind == "class"),
            None,
        )
        assert user_class is not None
        assert user_class.meta is not None
        assert "base_classes" in user_class.meta
        # Should be "Comparable", not "Comparable<User>"
        assert "Comparable" in user_class.meta["base_classes"]

    def test_class_without_extends_has_no_base_classes(self, tmp_path: Path) -> None:
        """Class without extends clause has no base_classes metadata."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Simple.groovy").write_text("""
class SimpleClass {
    void method() {}
}
""")
        result = analyze_groovy(tmp_path)

        simple_class = next(
            (s for s in result.symbols if s.name == "SimpleClass" and s.kind == "class"),
            None,
        )
        assert simple_class is not None
        # No meta or no base_classes is fine
        if simple_class.meta:
            assert simple_class.meta.get("base_classes", []) == []

    def test_linker_creates_extends_edge(self, tmp_path: Path) -> None:
        """Inheritance linker creates extends edge from base_classes."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy
        from hypergumbo_core.linkers.inheritance import link_inheritance
        from hypergumbo_core.linkers.registry import LinkerContext

        (tmp_path / "Models.groovy").write_text("""
class BaseModel {
    void save() {}
}

class User extends BaseModel {
    void greet() {}
}
""")
        result = analyze_groovy(tmp_path)

        ctx = LinkerContext(
            repo_root=tmp_path,
            symbols=result.symbols,
            edges=result.edges,
        )
        linker_result = link_inheritance(ctx)

        # Should create an extends edge
        extends_edges = [e for e in linker_result.edges if e.edge_type == "extends"]
        assert len(extends_edges) == 1
        assert "User" in extends_edges[0].src
        assert "BaseModel" in extends_edges[0].dst


class TestGroovyAmbiguousMethodGuard:
    """Tests for AMB-METHOD invariant in Groovy.

    When a method name has 3+ definitions across different classes and
    the receiver type cannot be inferred, the analyzer must NOT produce
    a resolved call edge (which would be a false positive).

    Invariant: Method calls with 3+ ambiguous receiver types must not
    produce resolved call edges.
    """

    def test_ambiguous_method_three_plus_classes_no_resolved_edge(
        self, tmp_path: Path,
    ) -> None:
        """close() with 3 classes defining close() → no resolved edge."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "multi.groovy"
        groovy_file.write_text("""
class ServiceA {
    def close() { }
}

class ServiceB {
    def close() { }
}

class ServiceC {
    def close() { }
}

def cleanup() {
    close()
}
""")

        result = analyze_groovy(tmp_path)

        call_edges = [e for e in result.edges if e.edge_type == "calls"]
        cleanup_calls = [e for e in call_edges if "cleanup" in e.src]

        # Should NOT have a resolved edge to any specific class's close()
        for edge in cleanup_calls:
            assert "ServiceA" not in edge.dst, (
                f"Ambiguous method should not resolve to ServiceA, got {edge.dst}"
            )
            assert "ServiceB" not in edge.dst, (
                f"Ambiguous method should not resolve to ServiceB, got {edge.dst}"
            )
            assert "ServiceC" not in edge.dst, (
                f"Ambiguous method should not resolve to ServiceC, got {edge.dst}"
            )

    def test_two_classes_same_method_still_resolves(
        self, tmp_path: Path,
    ) -> None:
        """run() with 2 classes → still resolves (below threshold)."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        groovy_file = tmp_path / "two.groovy"
        groovy_file.write_text("""
class ServiceA {
    def run() { }
}

class ServiceB {
    def run() { }
}

def execute() {
    run()
}
""")

        result = analyze_groovy(tmp_path)

        call_edges = [e for e in result.edges if e.edge_type == "calls"]
        execute_calls = [e for e in call_edges if "execute" in e.src]

        # 2 candidates is below the threshold — should still resolve
        run_calls = [e for e in execute_calls if "run" in e.dst.lower()]
        assert len(run_calls) >= 1, "2 candidates should still resolve"


class TestGroovyVisibilityModifiers:
    """Tests for visibility modifier extraction into Symbol.modifiers."""

    def test_method_visibility_modifiers(self, tmp_path: Path) -> None:
        """Methods with visibility modifiers get them extracted."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Vis.groovy").write_text("""
class Vis {
    public void pubMethod() {}
    private void privMethod() {}
    protected void protMethod() {}
    static void staticMethod() {}
    void defaultMethod() {}
}
""")
        result = analyze_groovy(tmp_path)

        pub = next(s for s in result.symbols if s.name == "Vis.pubMethod")
        assert "public" in pub.modifiers

        priv = next(s for s in result.symbols if s.name == "Vis.privMethod")
        assert "private" in priv.modifiers

        prot = next(s for s in result.symbols if s.name == "Vis.protMethod")
        assert "protected" in prot.modifiers

        static = next(s for s in result.symbols if s.name == "Vis.staticMethod")
        assert "static" in static.modifiers

        default = next(s for s in result.symbols if s.name == "Vis.defaultMethod")
        assert "public" not in default.modifiers
        assert "private" not in default.modifiers

    def test_class_modifiers(self, tmp_path: Path) -> None:
        """Classes with modifiers get them extracted."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Classes.groovy").write_text("""
public class PubClass {}
abstract class AbsClass {}
""")
        result = analyze_groovy(tmp_path)

        pub = next(s for s in result.symbols if s.name == "PubClass")
        assert "public" in pub.modifiers

        abs_cls = next(s for s in result.symbols if s.name == "AbsClass")
        assert "abstract" in abs_cls.modifiers


class TestNormalizeGroovySignature:
    """Tests for Groovy signature normalization (ADR-0014 §3)."""

    def test_basic_method(self) -> None:
        from hypergumbo_lang_mainstream.groovy import normalize_groovy_signature
        assert normalize_groovy_signature("(String name, int age): String") == "(String,int)String"

    def test_none(self) -> None:
        from hypergumbo_lang_mainstream.groovy import normalize_groovy_signature
        assert normalize_groovy_signature(None) is None


class TestGroovyDocstrings:
    """Tests for Groovydoc comment extraction via populate_docstrings_from_tree."""

    def test_groovydoc_block_comment_on_class(self, tmp_path: Path) -> None:
        """Extracts Groovydoc block comment preceding a class."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Foo.groovy").write_text(
            "/** Represents a foo entity. */\n"
            "class Foo {\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        cls = next((s for s in result.symbols if s.name == "Foo"), None)
        assert cls is not None
        assert cls.docstring == "Represents a foo entity."

    def test_groovydoc_block_comment_on_method(self, tmp_path: Path) -> None:
        """Extracts Groovydoc block comment preceding a method."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Foo.groovy").write_text(
            "class Foo {\n"
            "  /** Computes the sum. */\n"
            "  def add(int x, int y) { x + y }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        method = next((s for s in result.symbols if "add" in s.name), None)
        assert method is not None
        assert method.docstring == "Computes the sum."

    def test_line_comment_on_function(self, tmp_path: Path) -> None:
        """Extracts line comment preceding a function."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Foo.groovy").write_text(
            "class Foo {\n"
            "  // Greets the user.\n"
            "  def greet() { 'hello' }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        func = next((s for s in result.symbols if "greet" in s.name), None)
        assert func is not None
        assert func.docstring == "Greets the user."

    def test_no_comment_no_docstring(self, tmp_path: Path) -> None:
        """Symbol without preceding comment has no docstring."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Bar.groovy").write_text(
            "class Bar {\n"
            "  def run() { }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        method = next((s for s in result.symbols if "run" in s.name), None)
        assert method is not None
        assert method.docstring is None


class TestGroovyAnnotations:
    """Tests for Groovy annotation extraction (INV-kobad)."""

    def test_class_annotation(self, tmp_path: Path) -> None:
        """Class with @Service annotation should have meta.decorators."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            "@Service\n"
            "class UserService {\n"
            "    def getUsers() { [] }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        cls = next((s for s in result.symbols if s.name == "UserService"), None)
        assert cls is not None
        assert cls.meta is not None
        assert "decorators" in cls.meta
        decorators = cls.meta["decorators"]
        assert len(decorators) == 1
        assert decorators[0]["name"] == "Service"

    def test_method_annotation(self, tmp_path: Path) -> None:
        """Method with @Deprecated annotation should have meta.decorators."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            "class App {\n"
            "    @Deprecated\n"
            "    def oldMethod() { }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        method = next((s for s in result.symbols if "oldMethod" in s.name), None)
        assert method is not None
        assert method.meta is not None
        decorators = method.meta["decorators"]
        assert len(decorators) == 1
        assert decorators[0]["name"] == "Deprecated"

    def test_annotation_with_string_args(self, tmp_path: Path) -> None:
        """Annotation with string argument should capture args."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            "class App {\n"
            '    @RequestMapping("/api")\n'
            "    def handle() { }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        method = next((s for s in result.symbols if "handle" in s.name), None)
        assert method is not None
        assert method.meta is not None
        decorators = method.meta["decorators"]
        assert len(decorators) == 1
        assert decorators[0]["name"] == "RequestMapping"
        assert "/api" in decorators[0]["args"]

    def test_annotation_with_named_args(self, tmp_path: Path) -> None:
        """Annotation with named arguments should capture kwargs."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            '@Table(name = "users")\n'
            "class User {\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        cls = next((s for s in result.symbols if s.name == "User"), None)
        assert cls is not None
        decorators = cls.meta["decorators"]
        assert len(decorators) == 1
        assert decorators[0]["name"] == "Table"
        assert decorators[0]["kwargs"]["name"] == "users"

    def test_annotation_with_non_string_named_arg(self, tmp_path: Path) -> None:
        """Annotation with non-string named arg (e.g. integer) should capture raw text."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            '@Timeout(value = 30)\n'
            "class Worker {\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        cls = next((s for s in result.symbols if s.name == "Worker"), None)
        assert cls is not None
        decorators = cls.meta["decorators"]
        assert len(decorators) == 1
        assert decorators[0]["name"] == "Timeout"
        assert decorators[0]["kwargs"]["value"] == "30"

    def test_no_annotation_no_decorators(self, tmp_path: Path) -> None:
        """Class without annotations should not have decorators in meta."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            "class Plain {\n"
            "    def run() { }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        cls = next((s for s in result.symbols if s.name == "Plain"), None)
        assert cls is not None
        assert cls.meta is None or "decorators" not in (cls.meta or {})

    def test_class_with_annotation_and_base_class(self, tmp_path: Path) -> None:
        """Class with both annotation and extends should have both in meta."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            "@Service\n"
            "class AdminService extends BaseService {\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        cls = next((s for s in result.symbols if s.name == "AdminService"), None)
        assert cls is not None
        assert cls.meta is not None
        assert "decorators" in cls.meta
        assert "base_classes" in cls.meta


class TestGroovyParamTypeInference:
    """Tests for Groovy parameter type inference (INV-kobad item 4).

    When a method declares typed parameters (e.g. ``void process(Client client)``),
    calls like ``client.send()`` should resolve to ``Client.send`` even when
    multiple classes define ``send``.
    """

    def test_param_type_disambiguates_method_call(self, tmp_path: Path) -> None:
        """Type info from parameter resolves ambiguous method name."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            "class Client {\n"
            "    def send() { }\n"
            "}\n"
            "\n"
            "class Server {\n"
            "    def send() { }\n"
            "}\n"
            "\n"
            "class Service {\n"
            "    def process(Client client) {\n"
            "        client.send()\n"
            "    }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        call_edges = [
            e for e in result.edges
            if e.edge_type == "calls" and "process" in e.src and "send" in e.dst
        ]
        assert len(call_edges) == 1
        # Should resolve to Client.send, not Server.send
        assert "Client" in call_edges[0].dst

    def test_param_type_resolves_cross_file(self, tmp_path: Path) -> None:
        """Type info resolves method call across files via resolver."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "Client.groovy").write_text(
            "class Client {\n"
            "    def send() { }\n"
            "}\n"
        )
        (tmp_path / "Service.groovy").write_text(
            "class Service {\n"
            "    def process(Client client) {\n"
            "        client.send()\n"
            "    }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        call_edges = [
            e for e in result.edges
            if e.edge_type == "calls" and "process" in e.src and "send" in e.dst
        ]
        assert len(call_edges) == 1
        assert "Client" in call_edges[0].dst

    def test_constructor_type_disambiguates_method_call(self, tmp_path: Path) -> None:
        """Type info from constructor assignment resolves ambiguous method name."""
        from hypergumbo_lang_mainstream.groovy import analyze_groovy

        (tmp_path / "App.groovy").write_text(
            "class UserRepository {\n"
            "    def findAll() { }\n"
            "}\n"
            "\n"
            "class OrderRepository {\n"
            "    def findAll() { }\n"
            "}\n"
            "\n"
            "class Main {\n"
            "    def run() {\n"
            "        def repo = new UserRepository()\n"
            "        repo.findAll()\n"
            "    }\n"
            "}\n"
        )
        result = analyze_groovy(tmp_path)
        call_edges = [
            e for e in result.edges
            if e.edge_type == "calls" and "run" in e.src and "findAll" in e.dst
        ]
        assert len(call_edges) == 1
        # Should resolve to UserRepository.findAll, not OrderRepository.findAll
        assert "UserRepository" in call_edges[0].dst
