"""PowerShell analysis pass using tree-sitter.

This analyzer uses tree-sitter to parse PowerShell files and extract:
- Function definitions
- Filter definitions
- Workflow definitions (PowerShell 5.1)
- Parameter declarations with types
- Command/function calls
- Module imports (Import-Module, using module)

If tree-sitter with PowerShell support is not installed, the analyzer
gracefully degrades and returns an empty result.

How It Works
------------
1. Check if tree-sitter with PowerShell grammar is available
2. If not available, return skipped result (not an error)
3. Parse all PowerShell files and extract symbols
4. Detect Import-Module and using statements for import edges
5. Detect command invocations for call edges

Why This Design
---------------
- Optional dependency keeps base install lightweight
- Uses tree-sitter-language-pack for PowerShell grammar
- PowerShell is essential for Windows/Azure automation
- Enables analysis of DevOps and infrastructure scripts

PowerShell-Specific Considerations
----------------------------------
- Functions use verb-noun naming (Get-User, Set-Config)
- Parameters can have types, defaults, and attributes
- Filters are special functions for pipeline processing
- Workflows (deprecated) may appear in legacy code
- Import-Module and using module for dependencies
"""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, Iterator, Optional

from hypergumbo_core.analyze.base import (
    AnalysisResult,
    FileAnalysis,
    TreeSitterAnalyzer,
    find_child_by_type,
    iter_tree,
    make_file_id,
    make_symbol_id,
    node_text,
)
from hypergumbo_core.discovery import find_files
from hypergumbo_core.ir import AnalysisRun, Edge, Span, Symbol, make_pass_id
from hypergumbo_core.symbol_resolution import NameResolver
from hypergumbo_core.analyze.registry import register_analyzer

if TYPE_CHECKING:
    import tree_sitter

PASS_ID = make_pass_id("powershell")


def find_powershell_files(repo_root: Path) -> Iterator[Path]:
    """Yield all PowerShell files in the repository."""
    yield from find_files(repo_root, ["*.ps1", "*.psm1", "*.psd1"])


def _make_edge_id() -> str:
    """Generate a unique edge ID."""
    return f"edge:powershell:{uuid.uuid4().hex[:12]}"


def _extract_function_signature(func_node: "tree_sitter.Node", source: bytes) -> str:
    """Extract function signature showing parameters and types.

    PowerShell function syntax:
        function Verb-Noun {
            param(
                [Type]$ParamName,
                [Type]$ParamName = Default
            )
        }

    Returns signature like "([string]$UserId, [int]$Age)".
    """
    # Find the script_block inside the function
    script_block = find_child_by_type(func_node, "script_block")
    if not script_block:
        return "()"

    # Find param_block inside script_block
    param_block = find_child_by_type(script_block, "param_block")
    if not param_block:
        return "()"

    # Find parameter_list inside param_block
    param_list = find_child_by_type(param_block, "parameter_list")
    if not param_list:
        return "()"  # pragma: no cover - defensive

    # Extract parameters
    params: list[str] = []
    for child in param_list.children:
        if child.type == "script_parameter":
            param_str = _extract_parameter(child, source)
            if param_str:
                params.append(param_str)

    return f"({', '.join(params)})"


def _extract_parameter(param_node: "tree_sitter.Node", source: bytes) -> Optional[str]:
    """Extract a single parameter with its type annotation."""
    type_str: Optional[str] = None
    var_name: Optional[str] = None

    for child in param_node.children:
        if child.type == "attribute_list":
            # Look for type_literal in attribute
            for attr in child.children:
                if attr.type == "attribute":
                    type_lit = find_child_by_type(attr, "type_literal")
                    if type_lit:
                        type_str = node_text(type_lit, source).strip()
        elif child.type == "variable":
            var_name = node_text(child, source).strip()

    if var_name:
        if type_str:
            return f"{type_str}{var_name}"
        return var_name
    return None  # pragma: no cover - defensive


def _make_powershell_symbol(
    file_path: str,
    run_id: str,
    node: "tree_sitter.Node",
    name: str,
    kind: str,
    signature: Optional[str] = None,
) -> Symbol:
    """Create a Symbol from a tree-sitter node."""
    start_line = node.start_point[0] + 1
    end_line = node.end_point[0] + 1
    start_col = node.start_point[1]
    end_col = node.end_point[1]

    span = Span(
        start_line=start_line,
        end_line=end_line,
        start_col=start_col,
        end_col=end_col,
    )
    sym_id = make_symbol_id("powershell", file_path, start_line, end_line, name, kind)
    return Symbol(
        id=sym_id,
        name=name,
        canonical_name=name,
        kind=kind,
        language="powershell",
        path=file_path,
        span=span,
        origin=PASS_ID,
        origin_run_id=run_id,
        signature=signature,
    )


def _find_enclosing_function_powershell(
    node: "tree_sitter.Node",
    source: bytes,
    local_symbols: dict[str, Symbol],
) -> Optional[Symbol]:
    """Find the enclosing function Symbol by walking up parents."""
    current = node.parent
    while current is not None:
        if current.type == "function_statement":
            name_node = find_child_by_type(current, "function_name")
            if name_node:
                name = node_text(name_node, source).strip()
                sym = local_symbols.get(name)
                if sym:
                    return sym
        current = current.parent
    return None  # pragma: no cover - defensive


def _process_import_module(
    node: "tree_sitter.Node",
    source: bytes,
    file_path: str,
    edges: list[Edge],
) -> None:
    """Process Import-Module command to extract module name."""
    elements_node = find_child_by_type(node, "command_elements")
    if elements_node:
        for child in elements_node.children:
            if child.type == "generic_token":
                module_text = node_text(child, source).strip()
                if module_text and not module_text.startswith("-"):
                    edges.append(Edge(
                        id=_make_edge_id(),
                        src=make_file_id("powershell", file_path),
                        dst=f"powershell:?:?:{module_text}:module",
                        edge_type="imports",
                        line=node.start_point[0] + 1,
                    ))
                    return


def _process_using_command(
    node: "tree_sitter.Node",
    source: bytes,
    file_path: str,
    edges: list[Edge],
) -> None:
    """Process 'using' command to extract module imports."""
    elements_node = find_child_by_type(node, "command_elements")
    if elements_node:
        tokens = [
            node_text(child, source).strip()
            for child in elements_node.children
            if child.type == "generic_token"
        ]
        if len(tokens) >= 2 and tokens[0].lower() == "module":
            module_name = tokens[1]
            edges.append(Edge(
                id=_make_edge_id(),
                src=make_file_id("powershell", file_path),
                dst=f"powershell:?:?:{module_name}:module",
                edge_type="imports",
                line=node.start_point[0] + 1,
            ))


def _extract_powershell_symbols(
    tree: "tree_sitter.Tree",
    source: bytes,
    file_path: str,
    run_id: str,
    symbols: list[Symbol],
    symbol_registry: dict[str, Symbol],
) -> None:
    """Extract symbols from a parsed PowerShell file (pass 1)."""
    for node in iter_tree(tree.root_node):
        if node.type == "function_statement":
            # Process a function, filter, or workflow definition
            kind = "function"
            for child in node.children:
                if child.type == "filter":
                    kind = "filter"
                    break
                elif child.type == "workflow":
                    kind = "workflow"
                    break
                elif child.type == "function":
                    kind = "function"
                    break

            name_node = find_child_by_type(node, "function_name")
            if name_node:
                func_name = node_text(name_node, source).strip()
                sig = _extract_function_signature(node, source)
                sym = _make_powershell_symbol(
                    file_path, run_id, node, func_name, kind, signature=sig
                )
                symbols.append(sym)
                # Register functions for call resolution
                if kind in ("function", "filter", "workflow"):
                    symbol_registry[func_name] = sym


def _extract_powershell_edges(
    tree: "tree_sitter.Tree",
    source: bytes,
    file_path: str,
    edges: list[Edge],
    local_symbols: dict[str, Symbol],
    resolver: NameResolver,
) -> None:
    """Extract edges from a parsed PowerShell file (pass 2)."""
    for node in iter_tree(tree.root_node):
        if node.type == "command":
            command_name_node = find_child_by_type(node, "command_name")
            if command_name_node:
                command_name = node_text(command_name_node, source).strip()

                if command_name.lower() == "import-module":
                    _process_import_module(node, source, file_path, edges)
                elif command_name.lower() == "using":
                    _process_using_command(node, source, file_path, edges)
                else:
                    # Check if inside a function
                    caller = _find_enclosing_function_powershell(node, source, local_symbols)
                    if caller:
                        # Use resolver for callee resolution
                        lookup_result = resolver.lookup(command_name)
                        if lookup_result.found and lookup_result.symbol:
                            dst_id = lookup_result.symbol.id
                            confidence = 0.85 * lookup_result.confidence
                        else:
                            # External cmdlet or function
                            dst_id = f"powershell:external:{command_name}:function"
                            confidence = 0.70

                        edges.append(Edge(
                            id=_make_edge_id(),
                            src=caller.id,
                            dst=dst_id,
                            edge_type="calls",
                            line=node.start_point[0] + 1,
                            confidence=confidence,
                            origin=PASS_ID,
                        ))


class PowerShellAnalyzer(TreeSitterAnalyzer):
    """Tree-sitter-based PowerShell analyzer.

    Uses tree-sitter-language-pack for the PowerShell grammar.
    Two-pass analysis: Pass 1 extracts function/filter/workflow symbols,
    Pass 2 resolves command calls and module imports into edges.
    """

    lang = "powershell"
    file_patterns: ClassVar[list[str]] = ["*.ps1", "*.psm1", "*.psd1"]
    language_pack_name = "powershell"

    def extract_symbols_from_file(
        self,
        tree: "tree_sitter.Tree",
        source: bytes,
        file_path: Path,
        rel_path: str,
        run: AnalysisRun,
    ) -> FileAnalysis:
        """Extract function, filter, and workflow symbols from a PowerShell file."""
        analysis = FileAnalysis()
        symbol_registry: dict[str, Symbol] = {}

        _extract_powershell_symbols(
            tree, source, rel_path, run.execution_id,
            analysis.symbols, symbol_registry,
        )

        # Populate symbol_by_name for edge resolution (functions/filters/workflows)
        analysis.symbol_by_name = {
            s.name: s for s in analysis.symbols
            if s.kind in ("function", "filter", "workflow")
        }

        return analysis

    def extract_edges_from_file(
        self,
        tree: "tree_sitter.Tree",
        source: bytes,
        file_path: Path,
        rel_path: str,
        local_symbols: dict[str, Symbol],
        global_symbols: dict,
        run: AnalysisRun,
        import_aliases: dict[str, str],
        resolver: NameResolver,
    ) -> list[Edge]:
        """Extract import and call edges from a PowerShell file."""
        edges: list[Edge] = []
        _extract_powershell_edges(
            tree, source, rel_path, edges, local_symbols, resolver,
        )
        return edges


_analyzer = PowerShellAnalyzer()


def is_powershell_tree_sitter_available() -> bool:
    """Check if tree-sitter with PowerShell grammar is available."""
    return _analyzer._check_grammar_available()


@register_analyzer("powershell")
def analyze_powershell(repo_root: Path) -> AnalysisResult:
    """Analyze all PowerShell files in the repository.

    Uses two-pass analysis:
    - Pass 1: Extract all symbols from all files
    - Pass 2: Extract edges (imports + calls) using NameResolver

    Args:
        repo_root: Path to the repository root.

    Returns:
        AnalysisResult with symbols and edges found.
    """
    return _analyzer.analyze(repo_root)
