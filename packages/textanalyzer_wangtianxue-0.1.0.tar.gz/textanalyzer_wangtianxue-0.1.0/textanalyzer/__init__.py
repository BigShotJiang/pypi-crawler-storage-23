"""
textanalyzer - 简单的文本情感分析库
"""
__version__ = "0.1.0"

# 从 sentiment_analyzer 模块导入函数
from .sentiment_analyzer import analyze_sentiment

# 明确声明对外导出的API
__all__ = ["analyze_sentiment", "__version__"]