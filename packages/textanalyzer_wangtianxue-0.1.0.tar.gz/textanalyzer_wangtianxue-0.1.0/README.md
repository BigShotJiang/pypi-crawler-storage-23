\# textanalyzer



A simple text analyzer with sentiment analysis using VADER.

