# SPDX-FileCopyrightText: 2026-present Contributors <contributors@example.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.0"
