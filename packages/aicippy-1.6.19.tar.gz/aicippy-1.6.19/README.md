# AiCippy

**Enterprise-grade multi-agent CLI system powered by AWS Bedrock.**

[![PyPI version](https://img.shields.io/pypi/v/aicippy)](https://pypi.org/project/aicippy/)
[![Python](https://img.shields.io/pypi/pyversions/aicippy)](https://pypi.org/project/aicippy/)
[![License](https://img.shields.io/pypi/l/aicippy)](https://pypi.org/project/aicippy/)

**Copyright (c) 2024-2026 AiVibe Software Services Pvt Ltd. All rights reserved.**

ISO 27001:2022 Certified | NVIDIA Inception Partner | AWS Activate | Microsoft for Startups

---

## Overview

AiCippy is a production-grade, multi-agent command-line system that orchestrates up to 10 parallel AI agents to complete complex software engineering tasks. Built on AWS Bedrock Agents with a rich terminal UI, real-time WebSocket communication, and enterprise-grade security.

### Key Features

- **Multi-Agent Orchestration** - Spawn up to 10 parallel agents for complex tasks
- **Real-Time Streaming** - Live token streaming with <100ms first-token latency
- **Rich Terminal UI** - Color themes, responsive layout, live progress indicators
- **MCP Tool Connectors** - AWS, GCloud, GitHub, Firebase, Figma, and more
- **Knowledge Base** - Automated feed ingestion and semantic search
- **Secure Auth** - AWS Cognito with OTP, keychain-backed token storage
- **Multi-Tenant** - Full tenant isolation for enterprise deployments
- **Billing & Plans** - Credit management, plan validation, admin privileges

## Requirements

- Python 3.11 or higher
- macOS, Linux, or Windows
- AWS account (for Bedrock access)

## Installation

```bash
pip install aicippy
```

## Quick Start

```bash
# Authenticate (Email + Password or OTP)
aicippy login

# Initialize in a project directory
aicippy init

# Launch interactive session
aicippy

# Single query mode
aicippy chat "Explain this codebase architecture"

# Multi-agent parallel execution
aicippy run "Deploy infrastructure to AWS" --agents 5
```

## CLI Commands

| Command | Description |
|---------|-------------|
| `aicippy` | Start interactive session with full UI |
| `aicippy login` | Authenticate via Cognito (password or OTP) |
| `aicippy logout` | Clear stored credentials |
| `aicippy init` | Initialize project context and workspace |
| `aicippy chat <msg>` | Single query with streaming response |
| `aicippy run <task>` | Execute task with parallel agents |
| `aicippy config` | Show or edit configuration |
| `aicippy status` | Session and agent status |
| `aicippy usage` | Token usage statistics |
| `aicippy upgrade` | Self-update to latest PyPI version |
| `aicippy doctor` | Diagnose and fix configuration issues |
| `aicippy session` | View or manage sessions |
| `aicippy help` | Detailed help and usage information |

## Interactive Session Commands

Inside the interactive session (`aicippy`), use slash commands:

| Command | Description |
|---------|-------------|
| `/help` | Show all available commands |
| `/model <name>` | Switch model (opus / sonnet / llama) |
| `/mode <name>` | Change mode (agent / edit / research / code) |
| `/agents spawn <n>` | Spawn parallel agents (1-10) |
| `/agents list` | List active agents with health status |
| `/agents stop` | Stop all running agents |
| `/tools list` | List available MCP tool connectors |
| `/kb sync` | Sync workspace to Knowledge Base |
| `/kb status` | Knowledge Base status |
| `/usage` | Token and credit usage |
| `/plan` | View current billing plan |
| `/status` | Session status overview |
| `/history` | Conversation history |
| `/memory list` | List persistent memory entries |
| `/export` | Export conversation |
| `/upload` | Upload files to context |
| `/feedback <msg>` | Send feedback |
| `/theme` | Change color theme |
| `/clear` | Clear conversation |
| `/quit` | Exit session |

## Supported Models

| Model | ID | Description |
|-------|----|-------------|
| Claude Opus 4.5 | `opus` | Most capable - complex reasoning and coding |
| Claude Sonnet 4.5 | `sonnet` | Balanced performance and speed |
| Llama 4 Maverick | `llama` | Open source alternative via Bedrock |

## Color Themes

AiCippy includes 5 built-in color themes, selectable at session start or via `/theme`:

- **Neon Night** (default) - Vibrant purple and electric blue
- **Ocean Blue** - Cool ocean waves and deep sea tones
- **Forest Green** - Natural greens and earthy hues
- **Sunset** - Warm oranges and golden light
- **Minimal** - Clean monochrome with subtle accents

Themes are fully responsive: full layout (>80 cols), compact (>60 cols), and minimal (<60 cols).

## MCP Tool Connectors

| Connector | Description |
|-----------|-------------|
| AWS CLI | EC2, S3, Lambda, IAM, CloudFormation |
| Google Cloud | Compute, Storage, Functions |
| GitHub | Repos, PRs, Issues, Actions |
| Firebase | Firestore, Auth, Hosting |
| Figma | Design tokens, components |
| Google Drive | File management |
| Gmail | Email operations |
| Razorpay | Payment processing |
| PayPal | Payment processing |
| Stripe | Payment processing |
| Shell | Sandboxed command execution |

## Architecture

```
                     ┌─────────────────┐
                     │   AiCippy CLI   │
                     │  (Rich Terminal) │
                     └────────┬────────┘
                              │
                     ┌────────▼────────┐
                     │ Agent Orchestrator│
                     │ (Up to 10 agents)│
                     └────────┬─────────┘
                              │
         ┌────────────────────┼────────────────────┐
         │         │          │          │         │
    ┌────▼────┐ ┌──▼───┐ ┌───▼───┐ ┌────▼────┐ ┌──▼────┐
    │Agent-1  │ │Agent-2│ │Agent-3│ │Agent-4  │ │Agent-N│
    └────┬────┘ └──┬───┘ └───┬───┘ └────┬────┘ └──┬────┘
         │         │         │          │         │
    ┌────▼─────────▼─────────▼──────────▼─────────▼────┐
    │             AWS Bedrock Runtime                   │
    │     (Claude Opus / Sonnet / Llama Maverick)       │
    └──────────────────────────────────────────────────┘
```

## Configuration

Environment variables (or `.env` file):

```bash
AICIPPY_AWS_REGION=us-east-1
AICIPPY_DEFAULT_MODEL=opus
AICIPPY_MAX_PARALLEL_AGENTS=10
AICIPPY_LOG_LEVEL=INFO
```

Configuration file: `~/.aicippy/config.toml`

## Security

- **Authentication**: AWS Cognito with password + OTP (email verification code)
- **Token Storage**: OS keychain (macOS Keychain, Windows Credential Manager, Linux SecretService)
- **Transport**: All communications over TLS 1.3
- **Tenant Isolation**: Multi-tenant data separation with validated namespaces
- **Path Traversal Protection**: All file paths validated against traversal attacks
- **Secrets**: Never logged, printed, or stored in plaintext
- **IAM**: Least privilege roles for all AWS operations

## Terminal Compatibility

- **UTF-8**: Full Unicode symbols with automatic ASCII fallback
- **NO_COLOR**: Respects the [no-color.org](https://no-color.org/) standard
- **Responsive**: Adapts layout to terminal width (full / compact / minimal)
- **Accessibility**: Works in screen readers and with TERM=dumb

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run linter
ruff check src/

# Format code
ruff format src/

# Type checking
mypy src/aicippy/
```

## Source Code

This is a proprietary project. Source code access requires authorization.

To request read access, visit the [GitHub repository](https://github.com/ajaitech/aicippy-cli) and contact the maintainers.

## License

Proprietary - AiVibe Software Services Pvt Ltd

## Support

- Website: [aicippy.com](https://aicippy.com)
- Documentation: [docs.aicippy.com](https://docs.aicippy.com)
- Issues: [GitHub Issues](https://github.com/ajaitech/aicippy-cli/issues) (authorized users)
- Email: support@aivibe.in

---

Built with precision by [AiVibe Software Services Pvt Ltd](https://aivibe.in), Chennai, India.
