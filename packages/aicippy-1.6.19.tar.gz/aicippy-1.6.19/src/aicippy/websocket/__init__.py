"""
WebSocket module for AiCippy.

Provides real-time communication with the AiCippy backend
via API Gateway WebSocket.
"""

from __future__ import annotations

from aicippy.websocket.client import WebSocketClient
from aicippy.websocket.models import (
    AgentUpdate,
    DiffMessage,
    FileOperationType,
    FileTransferMessage,
    FileTransferProgress,
    MessageType,
    ProgressMessage,
    ToolOutput,
    WebSocketMessage,
)
from aicippy.websocket.realtime import (
    AgentState,
    ConnectionState,
    ConnectionStatus,
    RealtimeManager,
    StreamBuffer,
    StreamState,
)

__all__ = [
    "AgentState",
    "AgentUpdate",
    "ConnectionState",
    "ConnectionStatus",
    "DiffMessage",
    "FileOperationType",
    "FileTransferMessage",
    "FileTransferProgress",
    "MessageType",
    "ProgressMessage",
    # Realtime Manager
    "RealtimeManager",
    "StreamBuffer",
    "StreamState",
    "ToolOutput",
    # Client
    "WebSocketClient",
    # Models
    "WebSocketMessage",
]
