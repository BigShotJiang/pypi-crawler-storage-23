from typing import Optional

from sai_mcp.feishu_client import FeishuCloudClient


# ==================== 搜索用户 ====================
async def search_user(client: FeishuCloudClient, query: str):
    request_url = "/search/v1/user"
    params = {
        "query": query
    }
    data = await client.make_request(
        "GET",
        request_url,
        params=params
    )

    return data.get("users", [])
