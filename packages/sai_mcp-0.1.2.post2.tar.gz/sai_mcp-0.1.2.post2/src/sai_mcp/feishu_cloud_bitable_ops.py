from sai_mcp.feishu_client import FeishuCloudClient
from typing import Optional, Dict, Any, List


# ==================== 创建多维表格 ====================
async def create_bitable(
        client: FeishuCloudClient,
        name: Optional[str] = None,
        folder_token: Optional[str] = None,
        time_zone: Optional[str] = None
) -> Dict[str, Any]:
    """
    在指定文件夹中创建一个多维表格，包含一个空白的数据表。

    Args:
        client: 飞书云客户端
        name: 多维表格 App 名称，最长为 255 个字符
        folder_token: 多维表格 App 归属文件夹，默认为空表示根目录
        time_zone: 文档时区，详情参考文档时区介绍

    Returns:
        包含多维表格信息的字典，包括 app_token、default_table_id、url 等字段

    Raises:
        FeishuAPIError: 创建多维表格失败时抛出

    注意事项:
        - 接口频率限制为 20 次/分钟
        - 要基于模板创建多维表格，可先获取模板多维表格 app_token 作为文件 token，再调用复制文件接口
    """
    request_url = "/bitable/v1/apps"
    payload = {}

    if name:
        payload["name"] = name
    if folder_token:
        payload["folder_token"] = folder_token
    if time_zone:
        payload["time_zone"] = time_zone

    data = await client.make_request("POST", request_url, json=payload)

    app_info = data.get("app", {})
    return {
        "app_token": app_info.get("app_token"),
        "name": app_info.get("name"),
        "folder_token": app_info.get("folder_token"),
        "url": app_info.get("url"),
        "default_table_id": app_info.get("default_table_id"),
        "time_zone": app_info.get("time_zone")
    }

# ==================== 新增数据表 ====================
async def create_table(
        client: FeishuCloudClient,
        app_token: str,
        name: str,
        default_view_name: Optional[str] = None,
        fields: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]:
    """
    在多维表格中新增一个数据表。

    Args:
        client: 飞书云客户端
        app_token: 多维表格 App 的唯一标识
        name: 数据表名称。该字段必填，长度范围 1-100 字符
        default_view_name: 默认表格视图的名称（可选）。如果有 fields，则必须传入此参数
        fields: 数据表的初始字段（可选）。每个字段包含 field_name、type、ui_type、property 等

    Returns:
        包含数据表信息的字典，包括 table_id、default_view_id、field_id_list 等字段

    Raises:
        FeishuAPIError: 新增数据表失败时抛出

    注意事项:
        - 接口频率限制为 10 次/秒
        - 数据表与仪表盘的总数量上限为 100
        - 数据表的第一个字段为索引字段，索引字段仅支持：多行文本、数字、日期、电话号码、超链接、公式、地理位置
    """
    request_url = f"/bitable/v1/apps/{app_token}/tables"

    table_payload = {"name": name}

    if default_view_name:
        table_payload["default_view_name"] = default_view_name

    if fields:
        table_payload["fields"] = fields

    payload = {"table": table_payload}

    data = await client.make_request("POST", request_url, json=payload)

    # result = data.get("table", {})
    return {
        "table_id": data.get("table_id"),
        "default_view_id": data.get("default_view_id"),
        "field_id_list": data.get("field_id_list", [])
    }

# ==================== 列出数据表 ====================
async def list_tables(
        client: FeishuCloudClient,
        app_token: str,
        page_token: Optional[str] = None,
        page_size: Optional[int] = None
) -> Dict[str, Any]:
    """
    列出多维表格中的所有数据表，包括其 ID、版本号和名称。

    Args:
        client: 飞书云客户端
        app_token: 多维表格 App 的唯一标识
        page_token: 分页标记（可选），第一次请求不填表示从头开始
        page_size: 分页大小（可选），默认 20，最大 100

    Returns:
        包含数据表列表的字典，包括 items（数据表列表）、has_more、page_token、total 等字段

    Raises:
        FeishuAPIError: 列出数据表失败时抛出

    注意事项:
        - 接口频率限制为 20 次/秒
        - 支持分页查询，当 has_more 为 true 时可使用返回的 page_token 继续查询
    """
    request_url = f"/bitable/v1/apps/{app_token}/tables"
    params = {}

    if page_token:
        params["page_token"] = page_token
    if page_size:
        params["page_size"] = page_size

    data = await client.make_request("GET", request_url, params=params)

    items = data.get("items", [])
    tables = []
    for table in items:
        tables.append({
            "table_id": table.get("table_id"),
            "revision": table.get("revision"),
            "name": table.get("name")
        })

    return {
        "items": tables,
        "has_more": data.get("has_more", False),
        "page_token": data.get("page_token"),
        "total": data.get("total", 0)
    }

# ==================== 列出字段 ====================
async def list_fields(
        client: FeishuCloudClient,
        app_token: str,
        table_id: str,
        view_id: Optional[str] = None,
        text_field_as_array: Optional[bool] = None,
        page_token: Optional[str] = None,
        page_size: Optional[int] = None
) -> Dict[str, Any]:
    """
    获取多维表格数据表中的所有字段。

    Args:
        client: 飞书云客户端
        app_token: 多维表格 App 的唯一标识
        table_id: 多维表格数据表的唯一标识
        view_id: 多维表格中视图的唯一标识（可选）
        text_field_as_array: 控制字段描述数据的返回格式（可选），true 表示 description 将以数组形式返回
        page_token: 分页标记（可选），第一次请求不填表示从头开始
        page_size: 分页大小（可选），默认 20，最大 100

    Returns:
        包含字段列表的字典，包括 items（字段列表）、has_more、page_token、total 等字段

    Raises:
        FeishuAPIError: 列出字段失败时抛出

    注意事项:
        - 接口频率限制为 20 次/秒
        - 支持分页查询，当 has_more 为 true 时可使用返回的 page_token 继续查询
    """
    request_url = f"/bitable/v1/apps/{app_token}/tables/{table_id}/fields"
    params = {}

    if view_id:
        params["view_id"] = view_id
    if text_field_as_array is not None:
        params["text_field_as_array"] = text_field_as_array
    if page_token:
        params["page_token"] = page_token
    if page_size:
        params["page_size"] = page_size

    data = await client.make_request("GET", request_url, params=params)

    items = data.get("items", [])
    fields = []
    for field in items:
        fields.append({
            "field_id": field.get("field_id"),
            "field_name": field.get("field_name"),
            "type": field.get("type"),
            "ui_type": field.get("ui_type"),
            "is_primary": field.get("is_primary", False),
            "is_hidden": field.get("is_hidden", False),
            "property": field.get("property")
        })

    return {
        "items": fields,
        "has_more": data.get("has_more", False),
        "page_token": data.get("page_token"),
        "total": data.get("total", 0)
    }

# ==================== 新增多条记录 ====================
async def add_records(
        client: FeishuCloudClient,
        app_token: str,
        table_id: str,
        records: List[Dict[str, Any]],
        user_id_type: Optional[str] = None,
        client_token: Optional[str] = None,
        ignore_consistency_check: Optional[bool] = None
) -> Dict[str, Any]:
    """
    在多维表格数据表中新增多条记录，单次调用最多新增 1000 条记录。

    Args:
        client: 飞书云客户端
        app_token: 多维表格 App 的唯一标识
        table_id: 多维表格数据表的唯一标识
        records: 要新增的记录列表，每条记录包含 fields 字段
        user_id_type: 用户ID类型（可选），可选值：open_id, union_id, user_id，默认 open_id
        client_token: 幂等操作标识（可选），格式为标准的 uuidv4
        ignore_consistency_check: 是否忽略一致性读写检查（可选），默认 False

    Returns:
        包含新增记录列表的字典，包括 records（记录列表，每条包含 record_id 和 fields）

    Raises:
        FeishuAPIError: 新增记录失败时抛出

    注意事项:
        - 接口频率限制为 50 次/秒
        - 单次添加记录数量限制为 1000 条
        - 从其它数据源同步的数据表，不支持对记录进行增加、删除、和修改操作
        - 字段值格式参考 create_record 函数
    """
    request_url = f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_create"
    params = {}
    payload = {"records": records}

    if user_id_type:
        params["user_id_type"] = user_id_type
    if client_token:
        params["client_token"] = client_token
    if ignore_consistency_check is not None:
        params["ignore_consistency_check"] = ignore_consistency_check

    data = await client.make_request("POST", request_url, params=params, json=payload)

    records_list = data.get("records", [])
    result_records = []
    for record in records_list:
        result_records.append({
            "record_id": record.get("record_id"),
            "fields": record.get("fields", {})
        })

    return {
        "records": result_records
    }

# ==================== 查询记录 ====================
async def query_records(
        client: FeishuCloudClient,
        app_token: str,
        table_id: str,
        view_id: Optional[str] = None,
        field_names: Optional[List[str]] = None,
        sort: Optional[List[Dict[str, Any]]] = None,
        filter_info: Optional[Dict[str, Any]] = None,
        automatic_fields: Optional[bool] = None,
        user_id_type: Optional[str] = None,
        page_token: Optional[str] = None,
        page_size: Optional[int] = None
) -> Dict[str, Any]:
    """
    查询数据表中的现有记录，单次最多查询 500 行记录，支持分页获取。

    Args:
        client: 飞书云客户端
        app_token: 多维表格 App 的唯一标识
        table_id: 多维表格数据表的唯一标识
        view_id: 多维表格中视图的唯一标识（可选）
        field_names: 字段名称列表，用于指定返回记录中包含的字段（可选）
        sort: 排序条件列表（可选），如 [{"field_name": "字段名", "desc": True}]
        filter_info: 筛选条件（可选），如 {"conjunction": "and", "conditions": [...]}
        automatic_fields: 是否返回自动计算的字段（可选），默认 False
        user_id_type: 用户ID类型（可选），可选值：open_id, union_id, user_id，默认 open_id
        page_token: 分页标记（可选），第一次请求不填表示从头开始
        page_size: 分页大小（可选），默认 20，最大 500

    Returns:
        包含记录列表的字典，包括 items（记录列表）、has_more、page_token、total 等字段

    Raises:
        FeishuAPIError: 查询记录失败时抛出

    注意事项:
        - 接口频率限制为 20 次/秒
        - 单次最多查询 500 行记录
        - 支持分页查询，当 has_more 为 true 时可使用返回的 page_token 继续查询
        - 若多维表格开启了高级权限，需确保调用身份拥有多维表格的可管理权限
    """
    request_url = f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/search"
    params = {}
    payload = {}

    if user_id_type:
        params["user_id_type"] = user_id_type
    if page_token:
        params["page_token"] = page_token
    if page_size:
        params["page_size"] = page_size

    if view_id:
        payload["view_id"] = view_id
    if field_names:
        payload["field_names"] = field_names
    if sort:
        payload["sort"] = sort
    if filter_info:
        payload["filter"] = filter_info
    if automatic_fields is not None:
        payload["automatic_fields"] = automatic_fields

    data = await client.make_request("POST", request_url, params=params, json=payload)

    items = data.get("items", [])
    records = []
    for record in items:
        records.append({
            "record_id": record.get("record_id"),
            "fields": record.get("fields", {}),
            "created_time": record.get("created_time"),
            "created_by": record.get("created_by"),
            "last_modified_time": record.get("last_modified_time"),
            "last_modified_by": record.get("last_modified_by"),
            "shared_url": record.get("shared_url"),
            "record_url": record.get("record_url")
        })

    return {
        "items": records,
        "has_more": data.get("has_more", False),
        "page_token": data.get("page_token"),
        "total": data.get("total", 0)
    }

# ==================== 批量获取记录 ====================
async def batch_get_records(
        client: FeishuCloudClient,
        app_token: str,
        table_id: str,
        record_ids: List[str],
        user_id_type: Optional[str] = None,
        with_shared_url: Optional[bool] = None,
        automatic_fields: Optional[bool] = None
) -> Dict[str, Any]:
    """
    通过多个记录 ID 查询记录信息，该接口最多支持查询 100 条记录。

    Args:
        client: 飞书云客户端
        app_token: 多维表格 App 的唯一标识
        table_id: 多维表格数据表的唯一标识
        record_ids: 记录 ID 列表（必填），最多 100 个
        user_id_type: 用户ID类型（可选），可选值：open_id, union_id, user_id，默认 open_id
        with_shared_url: 是否返回记录的分享链接（可选），默认 False
        automatic_fields: 是否返回自动计算的字段（可选），默认 False

    Returns:
        包含记录信息的字典，包括 records（记录列表）、forbidden_record_ids、absent_record_ids 等字段

    Raises:
        FeishuAPIError: 批量获取记录失败时抛出

    注意事项:
        - 接口频率限制为 20 次/秒
        - 最多支持查询 100 条记录
        - 若多维表格开启了高级权限，需确保调用身份拥有多维表格的可管理权限
    """
    request_url = f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_get"
    payload = {"record_ids": record_ids}

    if user_id_type:
        payload["user_id_type"] = user_id_type
    if with_shared_url is not None:
        payload["with_shared_url"] = with_shared_url
    if automatic_fields is not None:
        payload["automatic_fields"] = automatic_fields

    data = client.make_request("POST", request_url, json=payload)

    records_list = data.get("records", [])
    records = []
    for record in records_list:
        records.append({
            "record_id": record.get("record_id"),
            "fields": record.get("fields", {}),
            "created_time": record.get("created_time"),
            "created_by": record.get("created_by"),
            "last_modified_time": record.get("last_modified_time"),
            "last_modified_by": record.get("last_modified_by"),
            "shared_url": record.get("shared_url")
        })

    return {
        "records": records,
        "forbidden_record_ids": data.get("forbidden_record_ids", []),
        "absent_record_ids": data.get("absent_record_ids", [])
    }