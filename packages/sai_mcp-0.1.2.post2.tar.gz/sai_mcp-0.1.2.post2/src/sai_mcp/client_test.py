import asyncio
from fastmcp import Client


async def test_stdio_client():
    async with Client("main.py") as client:
        # print("===== 调用 tools 列表查询 =====")
        # tools = await client.list_tools()
        # print(tools)

        # result = await client.call_tool("create_table",
        #                                 {
        #                                     "app_token": "JpiOb0YEIan0hksH7NecEIexnAf",
        #                                     "default_view_name": "默认视图",
        #                                     "fields": [
        #                                         {
        #                                             "field_name": "序号",
        #                                             "type": 2
        #                                         },
        #                                         {
        #                                             "field_name": "品牌",
        #                                             "type": 1
        #                                         },
        #                                         {
        #                                             "field_name": "车型",
        #                                             "type": 1
        #                                         },
        #                                         {
        #                                             "field_name": "级别",
        #                                             "type": 1
        #                                         },
        #                                         {
        #                                             "field_name": "12月销量_万辆",
        #                                             "type": 2
        #                                         },
        #                                         {
        #                                             "field_name": "环比",
        #                                             "type": 1
        #                                         },
        #                                         {
        #                                             "field_name": "1-12月销量_万辆",
        #                                             "type": 2
        #                                         }
        #                                     ],
        #                                     "name": "销量数据"
        #                                 })
        # print(result)
        result = await client.call_tool("query_records",
                                        {
                                            "app_token": "JpiOb0YEIan0hksH7NecEIexnAf",
                                            "field_names": [
                                                "品牌",
                                                "12月销量_万辆",
                                                "1-12月销量_万辆"
                                            ],
                                            "page_size": 100,
                                            "sort": [
                                                {
                                                    "desc": True,
                                                    "field_name": "1-12月销量_万辆"
                                                }
                                            ],
                                            "table_id": "tblAYHBAjV5NDqVD"
                                        })
        print(result)


async def main():
    await test_stdio_client()


if __name__ == "__main__":
    asyncio.run(main())
