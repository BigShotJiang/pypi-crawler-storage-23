import json
import time
import logging
from typing import Optional, Dict, Any
import requests
from playwright.async_api import async_playwright
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
# from playwright.sync_api import sync_playwright
import re

logger = logging.getLogger(__name__)

class FeishuAPIError(Exception):
    """飞书 API 错误"""
    pass

class FeishuCloudClient:
    """飞书云文档操作客户端"""

    def __init__(self):
        """
        初始化飞书客户端
        """
        self.app_id = 'cli_a9fc631c7cf85bcd'
        self.app_secret = 'JhnWMnenFoGe4dmf4FpyYf2UmGoYQfFH'
        self.base_url = "https://open.feishu.cn/open-apis"

        self._tenant_access_token: Optional[str] = None
        self._token_expire_time: Optional[float] = None

        self._auth_code: Optional[str] = None
        self._auth_code_expire_time: Optional[float] = None

        self._user_access_token: Optional[str] = None
        self._user_expire_time: Optional[float] = None
        self._user_refresh_token: Optional[str] = None
        self._user_refresh_expire_time: Optional[float] = None

        self._load_user_token()

        # 配置带重试的会话
        self.session = self._create_session()

        logger.info("飞书客户端初始化成功")

    def _create_session(self) -> requests.Session:
        """创建带重试策略的 HTTP 会话"""
        session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST", "PUT", "DELETE", "OPTIONS", "TRACE"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    async def _get_auth_code(self) -> str:
        """
        获取 auth_code

        Returns:
            auth_code
        """
        # 检查 token 是否有效
        if self._auth_code and self._auth_code_expire_time:
            if time.time() < self._auth_code_expire_time - 300:  # 提前5分钟刷新
                return self._auth_code

        url = f"https://accounts.feishu.cn/open-apis/authen/v1/authorize?client_id={self.app_id}&response_type=code&redirect_uri=https%3a%2f%2fopen.feishu.cn%2fapi-explorer%2floading&scope=offline_access%20drive:drive%20drive:file:upload%20docx:document%20docs:document:export%20bitable:app"
        async with async_playwright() as p:
            try:
                browser = await p.chromium.launch(headless=False, channel="chrome")
                page = await browser.new_page()

                await page.goto(url)
                await page.wait_for_url(re.compile(r"https://open.feishu.cn/api-explorer/loading.*"), timeout=120000)
                print(page.url)
                self._auth_code = page.url.split("code=")[1]
                await browser.close()
            except Exception as e:
                logger.error(f"获取 auth_code 错误: {e}")
        return self._auth_code

    def _record_user_token(self):
        with open('../../token.json', 'w', encoding='utf-8') as f:
            content = {
                "access_token": self._user_access_token,
                "expires_time": self._user_expire_time,
                "refresh_token": self._user_refresh_token,
                "refresh_expire_time": self._user_refresh_expire_time,
            }
            json.dump(content, f, ensure_ascii=False, indent=4)

    def _load_user_token(self) -> bool:
        try:
            with open('../../token.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                self._user_access_token = data["access_token"]
                self._user_expire_time = data["expires_time"]
                self._user_refresh_token = data["refresh_token"]
                self._user_refresh_expire_time = data["refresh_expire_time"]
                return True
        except Exception as e:
            logger.error(f"读取token失败: {e}")
            return False

    async def get_user_access_token(self) -> str:
        """
        获取 user_access_token

        Returns:
            tenant_access_token
        """
        # 检查 token 是否有效
        if self._user_access_token and self._user_expire_time:
            if time.time() < self._user_expire_time - 300:  # 提前5分钟刷新
                return self._user_access_token
            elif self._user_refresh_token and self._user_refresh_expire_time:
                if time.time() < self._user_refresh_expire_time - 300:
                    refresh_url = f"{self.base_url}/authen/v2/oauth/token"
                    refresh_payload = {
                        "grant_type": "refresh_token",
                        "client_id": self.app_id,
                        "client_secret": self.app_secret,
                        "refresh_token": self._user_refresh_token
                    }
                    try:
                        response = self.session.post(refresh_url,
                                                     headers={"Content-Type": "application/json; charset=utf-8"},
                                                     json=refresh_payload)
                        response.raise_for_status()
                        data = response.json()
                        self._user_access_token = data.get("access_token")
                        self._user_refresh_token = data.get("refresh_token")
                        self._user_refresh_expire_time = time.time() + int(data.get("refresh_token_expires_in"))
                        logger.info("成功刷新token")
                        self._record_user_token()
                        return self._user_access_token
                    except Exception as e:
                        logger.error(f"刷新token失败: {e}")
                        raise FeishuAPIError(f"刷新token失败: {e}")

        print("user token 不存在，重新申请")
        # 检查 code 是否有效
        self._auth_code = await self._get_auth_code()
        url = f"{self.base_url}/authen/v2/oauth/token"
        payload = {
            "grant_type": "authorization_code",
            "client_id": self.app_id,
            "client_secret": self.app_secret,
            "code": self._auth_code,
            "redirect_uri": "https://open.feishu.cn/api-explorer/loading"
        }
        try:
            response = self.session.post(url, headers={"Content-Type": "application/json; charset=utf-8"}, json=payload)
            response.raise_for_status()
            data = response.json()

            if data.get("code") != 0:
                raise FeishuAPIError(f"获取 token 失败: {data.get('msg')}")

            print(data)
            self._user_access_token = data.get("access_token")
            self._user_expire_time = time.time() + int(data.get("expires_in"))
            self._user_refresh_token = data.get("refresh_token")
            self._user_refresh_expire_time = time.time() + int(data.get("refresh_token_expires_in"))

            logger.info("成功获取 user_access_token")
            self._record_user_token()
            return self._user_access_token

        except requests.RequestException as e:
            logger.error(f"获取 token 网络错误: {e}")
            raise FeishuAPIError(f"获取 token 失败: {e}")

    def _get_tenant_access_token(self) -> str:
        """
        获取 tenant_access_token

        Returns:
            tenant_access_token
        """
        # 检查 token 是否有效
        if self._tenant_access_token and self._token_expire_time:
            if time.time() < self._token_expire_time - 300:  # 提前5分钟刷新
                return self._tenant_access_token

        url = f"{self.base_url}/auth/v3/tenant_access_token/internal"
        payload = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }

        try:
            response = self.session.post(url, json=payload)
            response.raise_for_status()
            data = response.json()

            if data.get("code") != 0:
                raise FeishuAPIError(f"获取 token 失败: {data.get('msg')}")

            self._tenant_access_token = data.get("tenant_access_token")
            # token 有效期通常为 2 小时
            self._token_expire_time = time.time() + 7200

            logger.info("成功获取 tenant_access_token")
            return self._tenant_access_token

        except requests.RequestException as e:
            logger.error(f"获取 token 网络错误: {e}")
            raise FeishuAPIError(f"获取 token 失败: {e}")

    async def make_request(
            self,
            method: str,
            endpoint: str,
            **kwargs
    ) -> Dict[str, Any]:
        """
        发送 API 请求

        Args:
            method: HTTP 方法
            endpoint: API 端点
            **kwargs: 其他请求参数

        Returns:
            API 响应数据
        """
        token = await self.get_user_access_token()
        url = f"{self.base_url}{endpoint}"
        headers = kwargs.pop('headers', {})
        headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        })

        try:
            response = self.session.request(
                method,
                url,
                headers=headers,
                **kwargs
            )
            response.raise_for_status()
            data = response.json()

            if data.get("code") != 0:
                raise FeishuAPIError(f"API 请求失败: {data.get('msg')}")

            return data.get("data", {})

        except requests.RequestException as e:
            logger.error(f"API 请求网络错误: {e}")
            raise FeishuAPIError(f"API 请求失败: {e}")