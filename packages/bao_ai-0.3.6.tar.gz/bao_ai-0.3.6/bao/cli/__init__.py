"""CLI module for Bao."""
