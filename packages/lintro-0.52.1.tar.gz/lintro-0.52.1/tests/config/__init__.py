"""Tests for the Lintro config module."""
