"""Pytest configuration for logging unit tests.

Tests in this directory focus on console logging functionality, loguru integration,
and message formatting for user display.
"""

# Add any logging-specific fixtures here in the future
