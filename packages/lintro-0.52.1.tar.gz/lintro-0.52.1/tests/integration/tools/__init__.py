"""Integration tests for tool definitions."""
