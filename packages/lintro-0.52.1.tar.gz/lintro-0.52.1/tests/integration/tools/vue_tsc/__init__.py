"""Integration tests for vue-tsc tool."""
