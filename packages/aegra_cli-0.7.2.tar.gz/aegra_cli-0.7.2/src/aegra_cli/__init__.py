"""Aegra CLI - Manage your self-hosted agent deployments."""

from importlib.metadata import version

__version__ = version("aegra-cli")
