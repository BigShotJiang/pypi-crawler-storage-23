"""Unified LLM invocation layer with structured output support.

This module provides the LLMInvoker class that provides a consistent interface
for invoking LLMs across different providers (Anthropic, OpenAI, Google, Ollama).

Features:
    - Provider abstraction (single interface, multiple backends)
    - Extended thinking support via ThinkingModeAdapter
    - Structured output parsing
    - Automatic retries with exponential backoff
    - Token tracking for context management

Runtime boundary note:
    `LLMInvoker` uses direct provider SDK/API integrations. For orchestration
    subprocess flows, semantic provider `ollama` is executed through Codex
    local-provider mode (`codex --oss --local-provider ollama`) in the typed
    pipeline/subprocess runner path, not through this invoker.

Example:
    >>> from obra.llm import LLMInvoker, ThinkingLevel
    >>> invoker = LLMInvoker()
    >>> result = invoker.invoke(
    ...     prompt="Analyze this code",
    ...     provider="anthropic",
    ...     reasoning_level=ThinkingLevel.HIGH,
    ... )
    >>> print(result.content)
    >>> print(f"Tokens used: {result.tokens_used}")

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md
    - obra/llm/thinking_mode.py
    - obra/llm/providers/
"""

import logging
import time
import uuid
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

from obra.config.llm import resolve_reasoning_selection
from obra.constants import DEFAULT_RETRY_BACKOFF_S, LLM_INVOKER_MAX_RETRIES
from obra.ollama_runtime import normalize_ollama_runtime_issue
from obra.llm.thinking_mode import (
    THINKING_LEVEL_TOKENS,
    ThinkingLevel,
    ThinkingMode,
    ThinkingModeAdapter,
)

if TYPE_CHECKING:
    from obra.llm.input_budget import BudgetCheckResult
    from obra.llm.providers.base import LLMProvider

logger = logging.getLogger(__name__)


@dataclass
class InvocationResult:
    """Result from LLM invocation.

    Attributes:
        content: Generated content
        tokens_used: Total tokens used
        thinking_tokens: Tokens used for thinking (if applicable)
        provider: Provider that generated the response
        model: Model used
        duration_seconds: Time taken for invocation
        success: Whether invocation succeeded
        error_message: Error message if failed
        raw_response: Raw provider response for debugging
    """

    content: str = ""
    tokens_used: int = 0
    thinking_tokens: int = 0
    provider: str = ""
    model: str = ""
    duration_seconds: float = 0.0
    success: bool = True
    error_message: str = ""
    raw_response: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "content": self.content,
            "tokens_used": self.tokens_used,
            "thinking_tokens": self.thinking_tokens,
            "provider": self.provider,
            "model": self.model,
            "duration_seconds": self.duration_seconds,
            "success": self.success,
            "error_message": self.error_message,
        }


class LLMInvoker:
    """Unified LLM invocation with provider abstraction.

    Provides a consistent interface for invoking LLMs across different
    providers while handling thinking mode, retries, and structured output.

    Example:
        >>> invoker = LLMInvoker()
        >>> result = invoker.invoke(
        ...     prompt="Analyze this code",
        ...     provider="anthropic",
        ...     reasoning_level=ThinkingLevel.HIGH,
        ... )

    Thread-safety:
        Thread-safe through ThinkingModeAdapter's per-session configuration.

    Attributes:
        thinking_adapter: ThinkingModeAdapter for extended thinking
        providers: Dictionary of registered providers
        default_provider: Default provider name
    """

    def __init__(
        self,
        thinking_adapter: ThinkingModeAdapter | None = None,
        default_provider: str = "anthropic",
        max_retries: int = LLM_INVOKER_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_BACKOFF_S,
        config: dict[str, Any] | None = None,
        log_event: "Callable[..., None] | None" = None,
    ) -> None:
        """Initialize LLMInvoker.

        Args:
            thinking_adapter: Optional ThinkingModeAdapter
            default_provider: Default provider name
            max_retries: Maximum retry attempts
            retry_delay: Initial retry delay (exponential backoff)
            config: Optional config dict for provider initialization
            log_event: Optional callback for emitting observability events.
                Matches the LLMSubprocessConfig.log_event signature for
                event emission parity across invocation paths.
        """
        self._thinking_adapter = thinking_adapter or ThinkingModeAdapter()
        self._default_provider = default_provider
        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._providers: dict[str, LLMProvider] = {}
        self._config = config
        self._log_event = log_event

        logger.debug(
            f"LLMInvoker initialized: default_provider={default_provider}, "
            f"max_retries={max_retries}"
        )

    @property
    def available_providers(self) -> list[str]:
        """Return list of known providers (without triggering lazy load).

        This provides consistent provider discovery regardless of
        whether providers have been instantiated yet.

        Returns:
            List of provider names that can be used with this invoker.
        """
        return ["anthropic", "google", "openai", "ollama"]

    def register_provider(self, name: str, provider: "LLMProvider") -> None:
        """Register an LLM provider.

        Args:
            name: Provider name (e.g., "anthropic", "openai")
            provider: Provider instance
        """
        self._providers[name] = provider
        logger.info(f"Registered LLM provider: {name}")

    def invoke(
        self,
        prompt: str,
        provider: str | None = None,
        model: str | None = None,
        reasoning_level: str | None = None,
        response_format: str = "text",
        system_prompt: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs,
    ) -> InvocationResult:
        """Invoke LLM with unified interface.

        Args:
            prompt: Input prompt
            provider: Provider name (uses default if not specified)
            model: Model to use (provider default if not specified)
            reasoning_level: Reasoning level (off, minimal, standard, high, maximum)
            response_format: Expected response format ("text" or "json")
            system_prompt: Optional system prompt
            temperature: Temperature (0.0-2.0)
            max_tokens: Maximum tokens to generate
            **kwargs: Additional provider-specific parameters

        Returns:
            InvocationResult with content and metadata
        """
        start_time = time.time()
        provider_name = provider or self._default_provider
        model_name: str | None = model

        # Generate session ID for thinking mode
        session_id = f"invoke-{uuid.uuid4().hex[:8]}"

        try:
            # Get provider
            llm_provider = self._get_provider(provider_name)
            if llm_provider is None:
                return InvocationResult(
                    success=False,
                    error_message=f"Provider not registered: {provider_name}",
                    provider=provider_name,
                    duration_seconds=time.time() - start_time,
                )

            # Get model (provider default if not specified)
            model_name = model or llm_provider.default_model

            # Input budget preflight check (FEAT-LLM-CONTEXT-BUDGET-001)
            budget_result = self._run_budget_preflight(
                provider_name, model_name, prompt + (system_prompt or "")
            )
            if budget_result is not None and budget_result.action == "fail":
                from obra.llm.input_budget import format_budget_error_message

                return InvocationResult(
                    success=False,
                    error_message=format_budget_error_message(budget_result),
                    provider=provider_name,
                    model=model_name,
                    duration_seconds=time.time() - start_time,
                )

            # Configure thinking mode if specified
            thinking_params = {}
            effective_reasoning = reasoning_level
            forced_level = None
            strict_mode = False
            try:
                from obra.config.loaders import load_layered_config

                config_data, _, _ = load_layered_config(include_defaults=True)
                reasoning_config = config_data.get("llm", {}).get("reasoning", {})
                if isinstance(reasoning_config, dict):
                    forced_level = reasoning_config.get("force_level")
                    strict_mode = bool(reasoning_config.get("strict_mode", False))
            except Exception:
                forced_level = None
                strict_mode = False

            if reasoning_level:
                selection = resolve_reasoning_selection(
                    provider=provider_name,
                    model=model_name,
                    stage_level=reasoning_level,
                    user_forced_level=forced_level,
                    tier_min_level=None,
                    tier_max_level=None,
                    cli_override=None,
                    strict_mode=strict_mode,
                )
                effective_reasoning = selection.normalized_level
                if selection.clamped:
                    logger.warning(
                        "Reasoning level clamped for %s:%s (requested=%s resolved=%s reason=%s)",
                        provider_name,
                        model_name,
                        reasoning_level,
                        selection.normalized_level,
                        selection.clamp_reason,
                    )
                thinking_params = self._configure_thinking(
                    session_id=session_id,
                    model=model_name,
                    reasoning_level=effective_reasoning,
                    provider=provider_name,
                )

            # Build request parameters
            request_params = {
                "prompt": prompt,
                "model": model_name,
                "response_format": response_format,
                **thinking_params,
            }

            if system_prompt:
                request_params["system_prompt"] = system_prompt
            if temperature is not None:
                request_params["temperature"] = temperature
            if max_tokens is not None:
                request_params["max_tokens"] = max_tokens

            request_params.update(kwargs)

            # Invoke with retries
            response = self._invoke_with_retry(llm_provider, request_params)

            duration = time.time() - start_time
            return InvocationResult(
                content=response.get("content", ""),
                tokens_used=response.get("tokens_used", 0),
                thinking_tokens=response.get("thinking_tokens", 0),
                provider=provider_name,
                model=model_name,
                duration_seconds=duration,
                success=True,
                raw_response=response,
            )

        except Exception as e:
            duration = time.time() - start_time
            logger.exception("LLM invocation failed")
            if provider_name == "ollama":
                issue = normalize_ollama_runtime_issue(
                    str(e),
                    source="direct_api",
                    model=model_name,
                )
                self._emit_ollama_runtime_failure(issue, model_name)
                return InvocationResult(
                    success=False,
                    error_message=issue.actionable_message,
                    provider=provider_name,
                    model=model_name or "",
                    duration_seconds=duration,
                )
            return InvocationResult(
                success=False,
                error_message=str(e),
                provider=provider_name,
                duration_seconds=duration,
            )

        finally:
            # Clean up thinking session
            self._thinking_adapter.cleanup_session(session_id)

    def invoke_stream(
        self,
        prompt: str,
        provider: str | None = None,
        model: str | None = None,
        reasoning_level: str | None = None,
        **kwargs,
    ) -> Iterator[str]:
        """Invoke LLM with streaming output.

        Args:
            prompt: Input prompt
            provider: Provider name
            model: Model to use
            reasoning_level: Reasoning level
            **kwargs: Additional parameters

        Yields:
            Text chunks as they're generated
        """
        provider_name = provider or self._default_provider
        session_id = f"stream-{uuid.uuid4().hex[:8]}"
        model_name: str | None = model

        try:
            llm_provider = self._get_provider(provider_name)
            if llm_provider is None:
                if provider_name == "ollama":
                    issue = normalize_ollama_runtime_issue(
                        f"Provider not registered: {provider_name}",
                        source="direct_api",
                        model=model_name,
                    )
                    self._emit_ollama_runtime_failure(issue, model_name)
                    yield f"[Error: {issue.actionable_message}]"
                    return
                yield f"[Error: Provider not registered: {provider_name}]"
                return

            model_name = model or llm_provider.default_model

            # Input budget preflight check (FEAT-LLM-CONTEXT-BUDGET-001)
            # system_prompt is not in the explicit signature - extract from kwargs
            stream_system_prompt = kwargs.get("system_prompt", "")
            budget_result = self._run_budget_preflight(
                provider_name, model_name, prompt + (stream_system_prompt or "")
            )
            if budget_result is not None and budget_result.action == "fail":
                from obra.llm.input_budget import format_budget_error_message

                yield f"[Error: {format_budget_error_message(budget_result)}]"
                return

            # Configure thinking mode
            thinking_params = {}
            if reasoning_level:
                thinking_params = self._configure_thinking(
                    session_id=session_id,
                    model=model_name,
                    reasoning_level=reasoning_level,
                    provider=provider_name,
                )

            request_params = {
                "prompt": prompt,
                "model": model_name,
                **thinking_params,
                **kwargs,
            }

            try:
                yield from llm_provider.generate_stream(**request_params)
            except Exception as e:
                if provider_name == "ollama":
                    issue = normalize_ollama_runtime_issue(
                        str(e),
                        source="direct_api",
                        model=model_name,
                    )
                    self._emit_ollama_runtime_failure(issue, model_name)
                    yield f"[Error: {issue.actionable_message}]"
                    return
                raise

        finally:
            self._thinking_adapter.cleanup_session(session_id)

    def _emit_ollama_runtime_failure(self, issue: Any, model: str | None) -> None:
        """Emit standardized Ollama runtime failure telemetry when callback exists."""
        if not self._log_event:
            return
        self._log_event(
            "ollama_runtime_failure",
            provider="ollama",
            source=getattr(issue, "source", "direct_api"),
            error_class=getattr(getattr(issue, "error_class", None), "value", "unknown"),
            model=model or "default",
            summary=getattr(issue, "summary", "Ollama runtime failure"),
            detail=getattr(issue, "detail", ""),
        )

    def estimate_tokens(self, text: str, provider: str | None = None) -> int:
        """Estimate token count for text.

        Args:
            text: Text to count tokens for
            provider: Provider for provider-specific counting

        Returns:
            Estimated token count
        """
        provider_name = provider or self._default_provider
        llm_provider = self._get_provider(provider_name)

        if llm_provider is not None:
            return llm_provider.estimate_tokens(text)

        # Fallback: rough estimate (4 chars per token)
        return len(text) // 4

    def is_available(self, provider: str | None = None) -> bool:
        """Check if provider is available.

        Args:
            provider: Provider name to check

        Returns:
            True if provider is available
        """
        provider_name = provider or self._default_provider
        llm_provider = self._get_provider(provider_name)

        if llm_provider is None:
            return False

        return llm_provider.is_available()

    def _get_provider(self, name: str) -> Optional["LLMProvider"]:
        """Get provider by name.

        Args:
            name: Provider name

        Returns:
            Provider instance or None
        """
        if name not in self._providers:
            # Try lazy loading
            provider = self._lazy_load_provider(name)
            if provider:
                self._providers[name] = provider

        return self._providers.get(name)

    def _lazy_load_provider(self, name: str) -> Optional["LLMProvider"]:
        """Lazy load and initialize a provider.

        Creates the provider instance and calls initialize() to configure
        the API client. Without initialize(), providers like AnthropicProvider
        have self._client = None and fail on generate().

        Args:
            name: Provider name

        Returns:
            Initialized provider instance or None

        Note:
            ISSUE-SIM-002: Initialize must be called or providers fail with
            "Anthropic client not initialized" errors.

            Provider boundary:
                - This method initializes direct API providers.
                - `name == "ollama"` here means direct Ollama HTTP API usage.
                - Orchestration runtime execution for semantic provider
                  `ollama` is handled by codex-backed subprocess specs.
        """
        try:
            provider: LLMProvider | None = None

            if name == "anthropic":
                from obra.llm.providers.anthropic import AnthropicProvider

                provider = AnthropicProvider()
            elif name == "openai":
                from obra.llm.providers.openai import OpenAIProvider

                provider = OpenAIProvider()
            elif name == "google":
                from obra.llm.providers.google import GoogleProvider

                provider = GoogleProvider()
            elif name == "ollama":
                from obra.llm.providers.ollama import OllamaProvider

                provider = OllamaProvider()
            else:
                logger.warning(f"Unknown provider: {name}")
                return None

            # Initialize the provider (reads API key from environment)
            # This is critical - without initialize(), the API client is None
            if name == "ollama":
                from obra.llm.ollama_endpoint import resolve_ollama_endpoint

                endpoint = resolve_ollama_endpoint(self._config)
                provider.initialize(endpoint=endpoint)
            else:
                provider.initialize()
            return provider

        except ImportError as e:
            logger.warning(f"Failed to import provider {name}: {e}")
            return None

    def _run_budget_preflight(
        self,
        provider: str,
        model: str,
        prompt_text: str,
    ) -> "BudgetCheckResult | None":
        """Run input budget preflight check if enabled.

        Args:
            provider: Provider name
            model: Model name
            prompt_text: Combined prompt text for estimation

        Returns:
            BudgetCheckResult if check ran, None if disabled or unavailable
        """
        try:
            from obra.config.loaders import (
                get_input_budget_enabled,
                get_input_budget_on_exceed,
                get_input_budget_warning_threshold,
            )
            from obra.llm.input_budget import BudgetCheckResult, check_input_budget

            if not get_input_budget_enabled():
                return None

            return check_input_budget(
                provider=provider,
                model=model,
                prompt_text=prompt_text,
                warning_threshold=get_input_budget_warning_threshold(),
                on_exceed=get_input_budget_on_exceed(),
                log_event=self._log_event,
            )
        except Exception:
            logger.debug("Budget preflight check failed, continuing without check", exc_info=True)
            return None

    def _configure_thinking(
        self,
        session_id: str,
        model: str,
        reasoning_level: str,
        provider: str,
    ) -> dict[str, Any]:
        """Configure thinking mode for session.

        Args:
            session_id: Session ID
            model: Model name
            reasoning_level: Reasoning level string
            provider: Provider name

        Returns:
            Provider-specific thinking parameters
        """
        # Convert level string to ThinkingLevel enum
        level_map = {
            "off": ThinkingLevel.OFF,
            "low": ThinkingLevel.MINIMAL,
            "minimal": ThinkingLevel.MINIMAL,
            "medium": ThinkingLevel.STANDARD,
            "standard": ThinkingLevel.STANDARD,
            "high": ThinkingLevel.HIGH,
            "maximum": ThinkingLevel.MAXIMUM,
        }
        level = level_map.get(reasoning_level.lower(), ThinkingLevel.STANDARD)

        # Get token budget for level
        budget_tokens = THINKING_LEVEL_TOKENS.get(level, 8000)

        # Convert to ThinkingMode
        if level == ThinkingLevel.OFF:
            mode = ThinkingMode.DISABLED
        elif level in (ThinkingLevel.HIGH, ThinkingLevel.MAXIMUM):
            mode = ThinkingMode.EXTENDED
        else:
            mode = ThinkingMode.STANDARD

        # Configure adapter
        self._thinking_adapter.configure(
            session_id=session_id,
            model=model,
            mode=mode,
            thinking_budget_tokens=budget_tokens,
        )

        # Get provider-specific params
        return self._thinking_adapter.get_provider_params(
            session_id=session_id,
            provider=provider,
            interface="api",
        )

    def _invoke_with_retry(
        self,
        provider: "LLMProvider",
        request_params: dict[str, Any],
    ) -> dict[str, Any]:
        """Invoke provider with retry logic.

        Uses the centralized retry utility with exponential backoff, jitter,
        and proper error classification (auth errors, rate limits, transient errors).

        Args:
            provider: Provider instance
            request_params: Request parameters

        Returns:
            Provider response

        Raises:
            Exception: If all retries fail
        """
        from obra.llm.retry import RetryConfig, with_retry

        # Load retry config from Obra settings
        try:
            config = RetryConfig.from_obra_config()
        except Exception:
            # Fall back to instance settings if config loading fails
            config = RetryConfig(
                max_attempts=self._max_retries,
                base_delay=self._retry_delay,
            )

        def _invoke() -> dict[str, Any]:
            response = provider.generate(**request_params)
            # Check for error in response dict (provider pattern)
            if isinstance(response, dict) and response.get("error"):
                raise RuntimeError(response["error"])
            return response

        result = with_retry(
            _invoke,
            config=config,
            operation_name=f"{provider.__class__.__name__}_generate",
        )

        if result.success:
            return result.value

        # Re-raise the last error
        if result.last_error:
            raise result.last_error

        msg = "All retry attempts failed"
        raise RuntimeError(msg)


__all__ = [
    "InvocationResult",
    "LLMInvoker",
]
