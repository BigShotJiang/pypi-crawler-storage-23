"""Prompt helpers that suspend the active spinner for clean input UX."""

from __future__ import annotations

import sys
from typing import Callable

from rich.console import Console

from obra.display.spinner import suspend_active_spinner


def prompt_input(
    prompt: str = "",
    *,
    default: str | None = None,
    console: Console | None = None,
    markup: bool = False,
    input_func: Callable[[str], str] | None = None,
) -> str:
    """Read interactive input while suspending any active spinner.

    Args:
        prompt: Prompt string to display.
        default: Default value if user enters empty input (only for std input).
        console: Optional Rich Console for input.
        markup: Whether console input should interpret markup.
        input_func: Optional input function override (for tests).

    Returns:
        User input (or default if provided and empty).
    """
    with suspend_active_spinner():
        if console is not None:
            return console.input(prompt, markup=markup)
        reader = input_func or input
        value = reader(prompt)
        if default is not None and value == "":
            return default
        return value


def prompt_input_with_timeout(
    prompt: str = "",
    *,
    timeout: int,
    default: str | None = None,
) -> str | None:
    """Read interactive input with a timeout, platform-aware.

    Uses ``select.select()`` on Unix (clean, no extra threads) and a
    daemon thread on Windows (where ``select`` only supports sockets).

    The active spinner is suspended for the duration of the read.

    Args:
        prompt: Prompt string to display (written to stdout).
        timeout: Seconds to wait for input.  If <= 0, falls back to
            :func:`prompt_input` (blocking, no timeout).
        default: Value returned when the user submits empty input and
            ``timeout <= 0`` (passed through to :func:`prompt_input`).

    Returns:
        The stripped user input, or ``None`` on timeout / EOF.
    """
    if timeout <= 0:
        return prompt_input(prompt, default=default)

    with suspend_active_spinner():
        if prompt:
            sys.stdout.write(prompt)
            sys.stdout.flush()

        if sys.platform == "win32":
            return _read_stdin_threading(timeout)
        return _read_stdin_select(timeout)


def _read_stdin_select(timeout: int) -> str | None:
    """Unix: use select() to wait for stdin with a timeout."""
    import select

    ready, _, _ = select.select([sys.stdin], [], [], timeout)
    if ready:
        line = sys.stdin.readline()
        if not line:
            return None  # EOF
        return line.strip()
    return None  # Timeout


def _read_stdin_threading(timeout: int) -> str | None:
    """Windows: use a daemon thread to read stdin with a timeout.

    ``select.select()`` only supports sockets on Windows, so we read in
    a background thread and join with a timeout.
    """
    import threading

    result: list[str | None] = [None]

    def _reader() -> None:
        try:
            line = sys.stdin.readline()
            result[0] = line.strip() if line else None
        except Exception:
            result[0] = None

    thread = threading.Thread(target=_reader, daemon=True)
    thread.start()
    thread.join(timeout=timeout)
    if thread.is_alive():
        return None  # Timeout
    return result[0]
