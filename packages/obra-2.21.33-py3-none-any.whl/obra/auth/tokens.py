"""Token management for Obra authentication.

Provides functions for token refresh, validation, and auth state management.
"""

import logging
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from typing import Any

import requests  # type: ignore[import-untyped]

from obra.config import (
    DEFAULT_NETWORK_TIMEOUT,
    FIREBASE_API_KEY,
    load_auth_state,
    save_auth_state,
)
from obra.exceptions import AuthenticationError
from obra.messages import get_message

from .types import AuthResult

logger = logging.getLogger(__name__)

# Firebase Auth REST API endpoints
FIREBASE_TOKEN_ENDPOINT = "https://securetoken.googleapis.com/v1/token"
FIREBASE_USERINFO_ENDPOINT = "https://identitytoolkit.googleapis.com/v1/accounts:lookup"

# Refresh if less than 5 minutes until expiration
TOKEN_REFRESH_THRESHOLD = timedelta(minutes=5)

# Default API base URL
DEFAULT_API_BASE_URL = "https://us-central1-obra-205b0.cloudfunctions.net"


def get_user_info(id_token: str) -> dict:
    """Get user info from Firebase ID token.

    Args:
        id_token: Firebase ID token

    Returns:
        User info dict with localId, email, displayName, etc.

    Raises:
        AuthenticationError: If token is invalid
    """
    url = f"{FIREBASE_USERINFO_ENDPOINT}?key={FIREBASE_API_KEY}"

    try:
        response = requests.post(
            url,
            json={"idToken": id_token},
            timeout=DEFAULT_NETWORK_TIMEOUT,
        )

        if response.status_code != HTTPStatus.OK:
            error_data: Any = response.json()
            error_msg = "Unknown error"
            if isinstance(error_data, dict):
                error_detail = error_data.get("error")
                if isinstance(error_detail, dict):
                    message = error_detail.get("message")
                    if isinstance(message, str):
                        error_msg = message
            msg = f"Failed to get user info: {error_msg}"
            raise AuthenticationError(msg)

        data: Any = response.json()
        if not isinstance(data, dict):
            msg = "Invalid response format from authentication service"
            raise AuthenticationError(msg)

        users = data.get("users", [])

        if not users:
            msg = "No user found for token"
            raise AuthenticationError(msg)
        if not isinstance(users, list):
            msg = "Invalid response format from authentication service"
            raise AuthenticationError(msg)

        user = users[0]
        if not isinstance(user, dict):
            msg = "Invalid user record in authentication response"
            raise AuthenticationError(msg)

        return user

    except requests.RequestException as e:
        msg = f"Network error getting user info: {e}"
        raise AuthenticationError(msg) from e


def refresh_id_token(refresh_token: str) -> tuple[str, str]:
    """Refresh Firebase ID token using refresh token.

    Args:
        refresh_token: Firebase refresh token

    Returns:
        Tuple of (new_id_token, new_refresh_token)

    Raises:
        AuthenticationError: If refresh fails
    """
    url = f"{FIREBASE_TOKEN_ENDPOINT}?key={FIREBASE_API_KEY}"

    try:
        response = requests.post(
            url,
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
            },
            timeout=DEFAULT_NETWORK_TIMEOUT,
        )

        if response.status_code != HTTPStatus.OK:
            error_data: Any = response.json()
            error_msg = "Unknown error"
            if isinstance(error_data, dict):
                error_detail = error_data.get("error")
                if isinstance(error_detail, dict):
                    message = error_detail.get("message")
                    if isinstance(message, str):
                        error_msg = message
            msg = f"Failed to refresh token: {error_msg}"
            raise AuthenticationError(msg)

        data: Any = response.json()
        if not isinstance(data, dict):
            msg = "Invalid response format when refreshing token"
            raise AuthenticationError(msg)

        id_token_value = data.get("id_token")
        refresh_token_value = data.get("refresh_token")
        if not isinstance(id_token_value, str) or not isinstance(refresh_token_value, str):
            msg = "Missing token fields in refresh response"
            raise AuthenticationError(msg)

        return id_token_value, refresh_token_value

    except requests.RequestException as e:
        msg = f"Network error refreshing token: {e}"
        raise AuthenticationError(msg) from e


def save_auth(auth_result: AuthResult) -> None:
    """Save authentication result to auth state file.

    Args:
        auth_result: Authentication result to save
    """
    state: dict[str, Any] = load_auth_state()

    state["firebase_uid"] = auth_result.firebase_uid
    state["user_email"] = auth_result.email
    state["auth_token"] = auth_result.id_token
    state["refresh_token"] = auth_result.refresh_token
    state["auth_provider"] = auth_result.auth_provider
    state["auth_timestamp"] = datetime.now(UTC).isoformat()

    # Firebase ID tokens expire in 1 hour - save expiration for auto-refresh
    token_expires_at = auth_result.expires_at or (datetime.now(UTC) + timedelta(hours=1))
    if token_expires_at.tzinfo is None:
        token_expires_at = token_expires_at.replace(tzinfo=UTC)
    state["token_expires_at"] = token_expires_at.isoformat()

    if auth_result.display_name:
        state["display_name"] = auth_result.display_name

    # Set user_id for compatibility with existing code
    state["user_id"] = auth_result.email

    save_auth_state(state)
    logger.info(f"Saved auth for user: {auth_result.email}")


def clear_auth() -> None:
    """Clear stored authentication from auth state file."""
    from obra.config.loaders import AUTH_STATE_PATH

    if AUTH_STATE_PATH.exists():
        AUTH_STATE_PATH.unlink()
    logger.info("Cleared stored authentication")


def get_current_auth() -> AuthResult | None:
    """Get current authentication from auth state file.

    Returns:
        AuthResult if authenticated, None otherwise
    """
    state: dict[str, Any] = load_auth_state()

    firebase_uid = state.get("firebase_uid")
    if not isinstance(firebase_uid, str) or not firebase_uid:
        return None

    email = state.get("user_email")
    auth_token = state.get("auth_token")
    refresh_token = state.get("refresh_token")
    auth_provider = state.get("auth_provider")
    display_name = state.get("display_name")

    return AuthResult(
        firebase_uid=firebase_uid,
        email=email if isinstance(email, str) else "",
        id_token=auth_token if isinstance(auth_token, str) else "",
        refresh_token=refresh_token if isinstance(refresh_token, str) else "",
        auth_provider=auth_provider if isinstance(auth_provider, str) else "unknown",
        display_name=display_name if isinstance(display_name, str) else None,
    )


def ensure_valid_token() -> str:
    """Ensure we have a valid ID token, refreshing if necessary.

    Returns:
        Valid Firebase ID token

    Raises:
        AuthenticationError: If not authenticated or refresh fails
    """
    auth = get_current_auth()

    if not auth:
        msg = f"Not authenticated. {get_message('recovery.auth.login')}"
        raise AuthenticationError(msg)

    current_token = auth.id_token
    if not isinstance(current_token, str) or not current_token:
        msg = f"No auth token found. {get_message('recovery.auth.login')}"
        raise AuthenticationError(msg)

    refresh_token_value = auth.refresh_token if isinstance(auth.refresh_token, str) else ""

    state: dict[str, Any] = load_auth_state()
    expires_at_raw = state.get("token_expires_at")
    expires_at: datetime | None = None

    if isinstance(expires_at_raw, str) and expires_at_raw:
        try:
            expires_at = datetime.fromisoformat(expires_at_raw.replace("Z", "+00:00"))
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=UTC)
        except ValueError:
            expires_at = None

    if expires_at:
        time_until_expiry = expires_at - datetime.now(UTC)
        if time_until_expiry > TOKEN_REFRESH_THRESHOLD:
            return current_token
    else:
        return current_token

    if not refresh_token_value:
        return current_token

    try:
        new_id_token, new_refresh_token = refresh_id_token(refresh_token_value)
    except AuthenticationError as e:
        logger.warning("Token refresh failed: %s", e)
        return current_token

    state["auth_token"] = new_id_token
    state["refresh_token"] = new_refresh_token
    state["token_expires_at"] = (datetime.now(UTC) + timedelta(hours=1)).isoformat()
    save_auth_state(state)

    return new_id_token


def verify_beta_access(id_token: str, api_base_url: str | None = None) -> dict:
    """Verify user has beta access by checking allowlist.

    Calls the /verify_beta_access endpoint to check if the authenticated
    user's email is on the beta allowlist.

    Args:
        id_token: Firebase ID token
        api_base_url: Optional API base URL (default: production)

    Returns:
        Dict with user info if access granted

    Raises:
        AuthenticationError: If not on allowlist or token invalid
    """
    base_url = api_base_url or DEFAULT_API_BASE_URL
    url = f"{base_url}/verify_beta_access"

    try:
        response = requests.post(
            url,
            headers={"Authorization": f"Bearer {id_token}"},
            timeout=DEFAULT_NETWORK_TIMEOUT,
        )

        if response.status_code == HTTPStatus.OK:
            response_data: Any = response.json()
            if not isinstance(response_data, dict):
                msg = "Invalid response format while verifying access"
                raise AuthenticationError(msg)
            return response_data

        if response.status_code == HTTPStatus.FORBIDDEN:
            error_data: Any = response.json()
            error_code = "access_denied"
            if isinstance(error_data, dict):
                code_value = error_data.get("code", error_code)
                if isinstance(code_value, str):
                    error_code = code_value
                data_dict: dict[str, Any] = error_data
            else:
                data_dict = {}

            if error_code == "not_on_allowlist":
                msg = (
                    "Your email is not on the beta allowlist.\n"
                    "Contact the Obra team to request access."
                )
                raise AuthenticationError(msg)
            if error_code == "access_revoked":
                msg = (
                    "Your beta access has been revoked.\n"
                    "Contact the Obra team for more information."
                )
                raise AuthenticationError(msg)
            message_value = data_dict.get("message", error_code)
            if not isinstance(message_value, str):
                message_value = error_code
            msg = f"Access denied: {message_value}"
            raise AuthenticationError(msg)

        if response.status_code == HTTPStatus.UNAUTHORIZED:
            msg = (
                f"Authentication token is invalid or expired.\n{get_message('recovery.auth.login')}"
            )
            raise AuthenticationError(msg)

        msg = f"Failed to verify access: HTTP {response.status_code}"
        raise AuthenticationError(msg)

    except requests.RequestException as e:
        msg = f"Network error: {e}"
        raise AuthenticationError(msg) from e


__all__ = [
    "DEFAULT_API_BASE_URL",
    # Constants
    "FIREBASE_TOKEN_ENDPOINT",
    "FIREBASE_USERINFO_ENDPOINT",
    "TOKEN_REFRESH_THRESHOLD",
    "clear_auth",
    "ensure_valid_token",
    "get_current_auth",
    # Functions
    "get_user_info",
    "refresh_id_token",
    "save_auth",
    "verify_beta_access",
]
