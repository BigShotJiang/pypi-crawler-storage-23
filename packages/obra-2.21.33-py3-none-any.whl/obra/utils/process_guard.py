"""Process guard utilities for preventing runaway processes.

Provides PID file management, max runtime watchdog, and CPU monitoring
to prevent stuck processes from consuming resources indefinitely.
"""

import atexit
import logging
import os
import signal
import threading
import time
from pathlib import Path
from typing import Callable

logger = logging.getLogger(__name__)

# Default locations
OBRA_RUN_DIR = Path.home() / ".obra" / "run"


class ProcessGuard:
    """Guard against runaway processes with PID tracking and watchdogs.

    Features:
    - PID file to prevent duplicate instances
    - Max runtime watchdog (terminates after limit)
    - CPU usage monitoring (detects runaway loops)

    Usage:
        guard = ProcessGuard("config", max_runtime_hours=1)
        if not guard.acquire():
            print("Already running")
            sys.exit(1)
        # ... run your process ...
        guard.release()  # Called automatically via atexit
    """

    def __init__(
        self,
        name: str,
        max_runtime_hours: float = 4.0,
        cpu_threshold_percent: float = 90.0,
        cpu_violation_minutes: int = 5,
        run_dir: Path | None = None,
    ) -> None:
        """Initialize process guard.

        Args:
            name: Process name (used for PID file)
            max_runtime_hours: Maximum runtime before auto-termination
            cpu_threshold_percent: CPU % threshold for runaway detection
            cpu_violation_minutes: Minutes at high CPU before termination
            run_dir: Directory for PID files (default: ~/.obra/run/)
        """
        self.name = name
        self.max_runtime_hours = max_runtime_hours
        self.cpu_threshold_percent = cpu_threshold_percent
        self.cpu_violation_minutes = cpu_violation_minutes
        self.run_dir = run_dir or OBRA_RUN_DIR

        self._pid_file = self.run_dir / f"{name}.pid"
        self._watchdog_thread: threading.Thread | None = None
        self._cpu_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._acquired = False

    @property
    def pid_file(self) -> Path:
        """Path to the PID file."""
        return self._pid_file

    def acquire(self, force: bool = False) -> bool:
        """Acquire the process lock.

        Args:
            force: Kill existing process if running

        Returns:
            True if lock acquired, False if another instance is running
        """
        self.run_dir.mkdir(parents=True, exist_ok=True)

        # Check for existing process
        if self._pid_file.exists():
            try:
                old_pid = int(self._pid_file.read_text().strip())
                if self._process_alive(old_pid):
                    if force:
                        logger.warning(f"Killing existing {self.name} process (PID {old_pid})")
                        os.kill(old_pid, signal.SIGTERM)
                        time.sleep(0.5)
                        if self._process_alive(old_pid):
                            os.kill(old_pid, signal.SIGKILL)
                            time.sleep(0.2)
                    else:
                        logger.warning(f"{self.name} already running (PID {old_pid})")
                        return False
            except (ValueError, ProcessLookupError, PermissionError):
                # Stale PID file or permission issue - safe to overwrite
                pass

        # Write our PID
        self._pid_file.write_text(str(os.getpid()))
        self._acquired = True

        # Register cleanup
        atexit.register(self.release)

        # Start watchdogs
        self._start_watchdogs()

        logger.debug(f"Process guard acquired for {self.name} (PID {os.getpid()})")
        return True

    def release(self) -> None:
        """Release the process lock and stop watchdogs."""
        if not self._acquired:
            return

        self._stop_event.set()

        # Wait for threads to stop
        if self._watchdog_thread and self._watchdog_thread.is_alive():
            self._watchdog_thread.join(timeout=1.0)
        if self._cpu_thread and self._cpu_thread.is_alive():
            self._cpu_thread.join(timeout=1.0)

        # Remove PID file
        try:
            if self._pid_file.exists():
                self._pid_file.unlink()
        except OSError:
            pass

        self._acquired = False
        logger.debug(f"Process guard released for {self.name}")

    def _start_watchdogs(self) -> None:
        """Start the watchdog threads."""
        # Max runtime watchdog
        self._watchdog_thread = threading.Thread(
            target=self._runtime_watchdog,
            daemon=True,
            name=f"{self.name}-runtime-watchdog",
        )
        self._watchdog_thread.start()

        # CPU watchdog (only if psutil available)
        try:
            import psutil  # noqa: F401

            self._cpu_thread = threading.Thread(
                target=self._cpu_watchdog,
                daemon=True,
                name=f"{self.name}-cpu-watchdog",
            )
            self._cpu_thread.start()
        except ImportError:
            logger.debug("psutil not available, CPU watchdog disabled")

    def _runtime_watchdog(self) -> None:
        """Watchdog that terminates after max runtime."""
        max_seconds = self.max_runtime_hours * 3600
        check_interval = 60  # Check every minute

        elapsed = 0.0
        while not self._stop_event.is_set() and elapsed < max_seconds:
            self._stop_event.wait(timeout=check_interval)
            elapsed += check_interval

        if not self._stop_event.is_set():
            logger.error(
                f"{self.name} exceeded max runtime of {self.max_runtime_hours}h, terminating"
            )
            # P0-2: Emit terminal event before os._exit (atexit won't fire)
            try:
                from obra.hybrid.orchestrator import emit_force_quit_terminal_event
                emit_force_quit_terminal_event()
            except Exception:
                pass
            # Clean exit
            self.release()
            os._exit(1)

    def _cpu_watchdog(self) -> None:
        """Watchdog that detects runaway CPU usage."""
        try:
            import psutil
        except ImportError:
            return

        process = psutil.Process()
        high_cpu_count = 0
        check_interval = 60  # Check every minute

        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=check_interval)
            if self._stop_event.is_set():
                break

            try:
                cpu_percent = process.cpu_percent(interval=1)
                if cpu_percent > self.cpu_threshold_percent:
                    high_cpu_count += 1
                    logger.warning(
                        f"{self.name} CPU at {cpu_percent:.1f}% "
                        f"({high_cpu_count}/{self.cpu_violation_minutes} violations)"
                    )
                    if high_cpu_count >= self.cpu_violation_minutes:
                        logger.error(
                            f"{self.name} CPU runaway detected "
                            f"({cpu_percent:.1f}% for {high_cpu_count} min), terminating"
                        )
                        # P0-2: Emit terminal event before os._exit
                        try:
                            from obra.hybrid.orchestrator import emit_force_quit_terminal_event
                            emit_force_quit_terminal_event()
                        except Exception:
                            pass
                        self.release()
                        os._exit(1)
                else:
                    high_cpu_count = 0
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                break

    @staticmethod
    def _process_alive(pid: int) -> bool:
        """Check if a process with given PID is alive."""
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False


def find_stale_processes(run_dir: Path | None = None) -> list[tuple[str, int, bool]]:
    """Find all tracked processes and their status.

    Args:
        run_dir: Directory containing PID files

    Returns:
        List of (name, pid, is_alive) tuples
    """
    run_dir = run_dir or OBRA_RUN_DIR
    results: list[tuple[str, int, bool]] = []

    if not run_dir.exists():
        return results

    for pid_file in run_dir.glob("*.pid"):
        name = pid_file.stem
        try:
            pid = int(pid_file.read_text().strip())
            alive = ProcessGuard._process_alive(pid)
            results.append((name, pid, alive))
        except (ValueError, OSError):
            # Invalid PID file
            results.append((name, -1, False))

    return results


def cleanup_stale_processes(
    run_dir: Path | None = None,
    kill: bool = False,
    on_cleanup: Callable[[str, int], None] | None = None,
) -> list[tuple[str, int]]:
    """Clean up stale PID files and optionally kill running processes.

    Args:
        run_dir: Directory containing PID files
        kill: If True, kill running processes; if False, only remove stale PID files
        on_cleanup: Callback for each cleaned up process (name, pid)

    Returns:
        List of (name, pid) tuples that were cleaned up
    """
    run_dir = run_dir or OBRA_RUN_DIR
    cleaned: list[tuple[str, int]] = []

    for name, pid, alive in find_stale_processes(run_dir):
        pid_file = run_dir / f"{name}.pid"

        if alive:
            if kill:
                try:
                    os.kill(pid, signal.SIGTERM)
                    time.sleep(0.5)
                    if ProcessGuard._process_alive(pid):
                        os.kill(pid, signal.SIGKILL)
                    cleaned.append((name, pid))
                    if on_cleanup:
                        on_cleanup(name, pid)
                except (ProcessLookupError, PermissionError):
                    pass
        else:
            # Stale PID file - remove it
            try:
                pid_file.unlink()
                cleaned.append((name, pid))
                if on_cleanup:
                    on_cleanup(name, pid)
            except OSError:
                pass

    return cleaned
