"""Session management REST endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel

from obra.gateway.session_manager import SessionLimitError, SessionNotFoundError

router = APIRouter(prefix="/v1/sessions", tags=["sessions"])


# ---------------------------------------------------------------------------
# Request / Response Models
# ---------------------------------------------------------------------------


class CreateSessionRequest(BaseModel):
    """Request body for creating a new session."""

    objective: str
    project_id: str
    working_dir: str


class SessionResponse(BaseModel):
    """Single session detail."""

    session_id: str
    status: str
    objective: str
    created_at: datetime
    project_id: str
    completion_notice: dict[str, Any] | None = None
    error: str | None = None


class SessionListResponse(BaseModel):
    """List of sessions."""

    sessions: list[SessionResponse]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_session(
    body: CreateSessionRequest, request: Request
) -> dict[str, str]:
    """Create a new orchestration session."""
    sm = request.app.state.session_manager
    try:
        session_id = sm.create_session(
            objective=body.objective,
            project_id=body.project_id,
            working_dir=body.working_dir,
        )
    except SessionLimitError as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=str(exc),
        ) from exc
    return {"session_id": session_id, "status": "created"}


@router.get("/")
async def list_sessions(request: Request) -> SessionListResponse:
    """List all sessions."""
    sm = request.app.state.session_manager
    records = sm.list_sessions()
    return SessionListResponse(
        sessions=[
            SessionResponse(
                session_id=r.session_id,
                status=r.status,
                objective=r.objective,
                created_at=r.created_at,
                project_id=r.project_id,
            )
            for r in records
        ]
    )


@router.get("/{session_id}")
async def get_session(session_id: str, request: Request) -> SessionResponse:
    """Get session details by ID."""
    sm = request.app.state.session_manager
    try:
        r = sm.get_session(session_id)
    except SessionNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    completion = None
    if r.completion_notice is not None:
        from dataclasses import asdict

        completion = asdict(r.completion_notice)

    return SessionResponse(
        session_id=r.session_id,
        status=r.status,
        objective=r.objective,
        created_at=r.created_at,
        project_id=r.project_id,
        completion_notice=completion,
        error=r.error,
    )


@router.post("/{session_id}/cancel")
async def cancel_session(session_id: str, request: Request) -> dict[str, str]:
    """Request cancellation of a running session."""
    sm = request.app.state.session_manager
    try:
        sm.cancel_session(session_id)
    except SessionNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    return {"session_id": session_id, "status": "cancelling"}
