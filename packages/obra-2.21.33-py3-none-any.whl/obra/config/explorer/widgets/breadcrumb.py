"""Breadcrumb navigation widget for config explorer.

Shows current location with back/home buttons to return to main menu.
"""

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Button, Static


class Breadcrumb(Static):
    """Breadcrumb navigation showing current location with back/home buttons.

    Displays: [< Back] [Home] > Current Location

    Emits HomeClicked message when back or home button is clicked.
    """

    DEFAULT_CSS = """
    Breadcrumb {
        width: 100%;
        height: auto;
        padding: 0 1;
        background: $surface;
        border-bottom: solid $primary-darken-2;
    }

    Breadcrumb > Horizontal {
        width: auto;
        height: auto;
        align: left middle;
    }

    Breadcrumb #back-btn {
        min-width: 8;
        width: auto;
        margin-right: 1;
        background: $primary-darken-2;
        border: none;
    }

    Breadcrumb #back-btn:hover {
        background: $primary;
    }

    Breadcrumb #home-btn {
        min-width: 5;
        width: auto;
        margin-right: 0;
        background: transparent;
        border: none;
    }

    Breadcrumb #home-btn:hover {
        background: $primary-darken-1;
    }

    Breadcrumb .separator {
        color: $text-muted;
        margin: 0 1;
    }

    Breadcrumb .location {
        text-style: bold;
    }
    """

    location: reactive[str] = reactive("Home")

    class HomeClicked(Message):
        """Message emitted when back or home button is clicked."""

    def compose(self) -> ComposeResult:
        """Create the breadcrumb content."""
        with Horizontal():
            yield Button("\u2190 Back", id="back-btn")  # Left arrow + Back
            yield Button("\u2302", id="home-btn")  # House symbol
            yield Static("\u203a", classes="separator")  # Single right-pointing angle
            yield Static(self.location, id="location-label", classes="location")

    def set_location(self, location: str) -> None:
        """Update the current location display.

        Args:
            location: Human-readable name of the current view
        """
        self.location = location
        try:
            label = self.query_one("#location-label", Static)
            label.update(location)
        except Exception:
            pass  # Widget may not be mounted yet

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle back/home button click."""
        if event.button.id in ("home-btn", "back-btn"):
            self.post_message(self.HomeClicked())
