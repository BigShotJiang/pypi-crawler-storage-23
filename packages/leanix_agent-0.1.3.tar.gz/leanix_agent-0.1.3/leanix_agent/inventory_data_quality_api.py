"""
inventory_data_quality API Client.
"""

import requests
from typing import Dict, Optional, Any
from urllib.parse import urljoin
import urllib3


class Api:
    def __init__(
        self, base_url: str, token: Optional[str] = None, verify: bool = False
    ):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self._session = requests.Session()
        self._session.verify = verify

        if not verify:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def _authenticate(self):
        auth_url = f"{self.base_url}/services/mtm/v1/oauth2/token"
        response = self._session.post(
            auth_url,
            auth=("apitoken", self.token),
            data={"grant_type": "client_credentials"},
            verify=self._session.verify,
        )
        if response.status_code == 200:
            token_data = response.json()
            access_token = token_data.get("access_token")
            self._session.headers.update(
                {
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/json",
                }
            )

    def request(
        self, method: str, endpoint: str, params: Dict = None, data: Dict = None
    ) -> Any:
        if "Authorization" not in self._session.headers:
            self._authenticate()

        url = urljoin(self.base_url, endpoint)

        response = self._session.request(
            method=method, url=url, params=params, json=data
        )
        if response.status_code >= 400:
            try:
                error_text = response.text
            except Exception:
                error_text = "Unknown error"
            raise Exception(f"API error: {response.status_code} - {error_text}")

        if response.status_code == 204:
            return {"status": "success"}

        try:
            return response.json()
        except Exception:
            return {"status": "success", "text": response.text}

    def refreshembeddings(self, **kwargs) -> Any:
        """Refresh embeddings"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST",
            endpoint="/recommendations/refresh",
            params=params_dict,
            data=None,
        )

    def getrecommendationsapptobc(self, data: Dict = None, **kwargs) -> Any:
        """Get App to BC recommendations"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST",
            endpoint="/recommendations/appToBc",
            params=params_dict,
            data=data,
        )

    def getrecommendationsagenttobc(self, data: Dict = None, **kwargs) -> Any:
        """Get Agent to BC recommendations"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST",
            endpoint="/recommendations/agentToBc",
            params=params_dict,
            data=data,
        )

    def submitfeedback(self, data: Dict = None, **kwargs) -> Any:
        """Submit feedback"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST",
            endpoint="/feedback/recommendations",
            params=params_dict,
            data=data,
        )

    def submitfeedback_1(self, data: Dict = None, **kwargs) -> Any:
        """Submit feedback"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST", endpoint="/feedback", params=params_dict, data=data
        )

    def submitdqicardfeedback(self, data: Dict = None, **kwargs) -> Any:
        """Submit DQI Card feedback"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST", endpoint="/feedback/dqiCards", params=params_dict, data=data
        )

    def getdatamodel(self, **kwargs) -> Any:
        """Call GET /api/v1/datamodel"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET", endpoint="/api/v1/datamodel", params=params_dict, data=None
        )

    def getrelationnames(self, **kwargs) -> Any:
        """Call GET /api/v1/datamodel/relation-names"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint="/api/v1/datamodel/relation-names",
            params=params_dict,
            data=None,
        )

    def getfactsheettypes(self, **kwargs) -> Any:
        """Call GET /api/v1/datamodel/factsheet-types"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint="/api/v1/datamodel/factsheet-types",
            params=params_dict,
            data=None,
        )
