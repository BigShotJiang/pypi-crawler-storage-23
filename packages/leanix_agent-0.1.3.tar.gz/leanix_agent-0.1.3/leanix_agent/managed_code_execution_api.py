"""
managed_code_execution API Client.
"""

import requests
from typing import Dict, Optional, Any
from urllib.parse import urljoin
import urllib3


class Api:
    def __init__(
        self, base_url: str, token: Optional[str] = None, verify: bool = False
    ):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self._session = requests.Session()
        self._session.verify = verify

        if not verify:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def _authenticate(self):
        auth_url = f"{self.base_url}/services/mtm/v1/oauth2/token"
        response = self._session.post(
            auth_url,
            auth=("apitoken", self.token),
            data={"grant_type": "client_credentials"},
            verify=self._session.verify,
        )
        if response.status_code == 200:
            token_data = response.json()
            access_token = token_data.get("access_token")
            self._session.headers.update(
                {
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/json",
                }
            )

    def request(
        self, method: str, endpoint: str, params: Dict = None, data: Dict = None
    ) -> Any:
        if "Authorization" not in self._session.headers:
            self._authenticate()

        url = urljoin(self.base_url, endpoint)

        response = self._session.request(
            method=method, url=url, params=params, json=data
        )
        if response.status_code >= 400:
            try:
                error_text = response.text
            except Exception:
                error_text = "Unknown error"
            raise Exception(f"API error: {response.status_code} - {error_text}")

        if response.status_code == 204:
            return {"status": "success"}

        try:
            return response.json()
        except Exception:
            return {"status": "success", "text": response.text}

    def getsecretbyid(self, secretId: str, **kwargs) -> Any:
        """Get a Secret by ID"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET", endpoint=f"/secrets/{secretId}", params=params_dict, data=None
        )

    def updatesecret(self, secretId: str, data: Dict = None, **kwargs) -> Any:
        """Update a Secret"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="PUT", endpoint=f"/secrets/{secretId}", params=params_dict, data=data
        )

    def deletesecret(self, secretId: str, **kwargs) -> Any:
        """Delete a Secret"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="DELETE",
            endpoint=f"/secrets/{secretId}",
            params=params_dict,
            data=None,
        )

    def getexecutionconfiguration(self, id_: str, **kwargs) -> Any:
        """Show details of specified ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint=f"/executionConfigurations/{id_}",
            params=params_dict,
            data=None,
        )

    def updateexecutionconfiguration(
        self, id_: str, data: Dict = None, **kwargs
    ) -> Any:
        """Update an existing ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="PUT",
            endpoint=f"/executionConfigurations/{id_}",
            params=params_dict,
            data=data,
        )

    def deleteexecutionconfiguration(self, id_: str, **kwargs) -> Any:
        """Delete an existing ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="DELETE",
            endpoint=f"/executionConfigurations/{id_}",
            params=params_dict,
            data=None,
        )

    def updateexecutionconfigurationcapability(
        self, id_: str, data: Dict = None, **kwargs
    ) -> Any:
        """Update capability of an ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="PUT",
            endpoint=f"/executionConfigurations/{id_}/capability",
            params=params_dict,
            data=data,
        )

    def getallsecrets(self, **kwargs) -> Any:
        """Get all Secrets"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET", endpoint="/secrets", params=params_dict, data=None
        )

    def createsecret(self, data: Dict = None, **kwargs) -> Any:
        """Create a new Secret"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST", endpoint="/secrets", params=params_dict, data=data
        )

    def getexecutionconfigurations(self, **kwargs) -> Any:
        """List all available ExecutionConfigurations"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint="/executionConfigurations",
            params=params_dict,
            data=None,
        )

    def createexecutionconfiguration(self, data: Dict = None, **kwargs) -> Any:
        """Create a new ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="POST",
            endpoint="/executionConfigurations",
            params=params_dict,
            data=data,
        )

    def getexecutionconfigurationsbysecretid(self, secretId: str, **kwargs) -> Any:
        """Get ExecutionConfigurations that reference a Secret"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint=f"/secrets/{secretId}/executionConfigurations",
            params=params_dict,
            data=None,
        )

    def getexecutionlogs(self, id_: str, **kwargs) -> Any:
        """List all available ExecutionLogs for one ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint=f"/executionConfigurations/{id_}/executionLogs",
            params=params_dict,
            data=None,
        )

    def getexecutionlog(self, id_: str, executionLogId: str, **kwargs) -> Any:
        """Get a specific ExecutionLog for ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint=f"/executionConfigurations/{id_}/executionLogs/{executionLogId}",
            params=params_dict,
            data=None,
        )

    def getexecutionconfigurationhistory(self, id_: str, **kwargs) -> Any:
        """List all versions of a given ExecutionConfiguration"""
        params_dict = kwargs.copy()
        # Merge path args to params if needed, or rely on URL path
        return self.request(
            method="GET",
            endpoint=f"/executionConfigurations/{id_}/code",
            params=params_dict,
            data=None,
        )
