* [Home](https://help.sap.com/docs/)
  * [SAP LeanIX](https://help.sap.com/docs/leanix)
  * …
  * [Discovery and Integrations](https://help.sap.com/docs/leanix/ea/discovery-and-integrations)
  * AI Agent Discovery
