# -*- coding: utf-8 -*-
from .main import main
from .sphinx import setup

__version__ = "0.3.4"

__all__ = [
    "setup",
    "main",
]
