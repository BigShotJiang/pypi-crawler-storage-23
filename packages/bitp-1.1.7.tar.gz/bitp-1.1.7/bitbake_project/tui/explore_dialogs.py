#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Dialog integration for the explore command.

Provides state management and dialog handling that integrates with
the fzf-based explore menu, allowing inline prompts without exiting fzf.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from .dialogs import (
    Dialog,
    DialogResult,
    DialogType,
    FzfDialogRenderer,
    dialog,
)


@dataclass
class ExploreMenuState:
    """State management for explore menu with dialog support.

    Tracks the active dialog and provides methods to integrate
    dialogs into the fzf menu flow.
    """
    active_dialog: Optional[Dialog] = None
    dialog_context: Dict[str, Any] = field(default_factory=dict)
    status_message: str = ""
    _renderer: FzfDialogRenderer = field(default_factory=FzfDialogRenderer)

    def show_dialog(
        self,
        dlg: Dialog,
        context: Dict[str, Any] = None,
    ) -> None:
        """Activate a dialog.

        Args:
            dlg: The dialog to show
            context: Optional context data (e.g., selected repo)
        """
        self.active_dialog = dlg
        self.dialog_context = context or {}

    def clear_dialog(self) -> None:
        """Clear active dialog."""
        self.active_dialog = None
        self.dialog_context = {}

    def has_dialog(self) -> bool:
        """Check if dialog is active."""
        return self.active_dialog is not None

    def get_dialog_menu_lines(self) -> List[Tuple[str, str]]:
        """Get dialog items as (value, display) tuples for menu."""
        if not self.active_dialog:
            return []
        return self._renderer.render_to_menu_items(self.active_dialog)

    def get_prompt_text(self) -> Optional[str]:
        """Get prompt text when dialog is active."""
        if not self.active_dialog:
            return None
        return self._renderer.get_prompt_text(self.active_dialog)

    def get_default_cursor_line(self) -> Optional[int]:
        """Get 1-indexed line number of the selected/default option.

        For CONFIRM dialogs, defaults to the Yes button.
        For SELECT dialogs, finds the first option marked selected.
        """
        if not self.active_dialog:
            return None
        lines = self.get_dialog_menu_lines()
        # For CONFIRM dialogs, position cursor on the Yes button
        if self.active_dialog.dialog_type == DialogType.CONFIRM:
            for i, (value, _display) in enumerate(lines):
                if value == self._renderer.CONFIRM_VALUE:
                    return i + 1  # 1-indexed
            return None
        # For SELECT dialogs, find first selected option
        if not self.active_dialog.options:
            return None
        for i, (value, _display) in enumerate(lines):
            if not value.startswith(self._renderer.OPTION_PREFIX):
                continue
            idx_str = value[len(self._renderer.OPTION_PREFIX):-2]
            try:
                idx = int(idx_str)
                if idx < len(self.active_dialog.options) and self.active_dialog.options[idx].selected:
                    return i + 1  # 1-indexed
            except ValueError:
                pass
        return None

    def is_dialog_selection(self, value: str) -> bool:
        """Check if selected value is from dialog."""
        return self._renderer.is_dialog_item(value)

    def handle_dialog_selection(
        self,
        selected_value: str,
        query: str,
    ) -> DialogResult:
        """Process a dialog selection.

        Returns DialogResult with confirmation status and value.
        """
        if not self.active_dialog:
            return DialogResult(confirmed=False)

        return self._renderer.parse_result(
            self.active_dialog,
            selected_value,
            query,
        )

    def set_status(self, message: str) -> None:
        """Set a status message to show in next menu iteration."""
        self.status_message = message

    def consume_status(self) -> str:
        """Get and clear status message."""
        msg = self.status_message
        self.status_message = ""
        return msg


# --- Pre-built dialogs for common explore actions ---

def branch_all_dialog(
    on_confirm: Callable[[str], None] = None,
    default_branch: str = "",
) -> Dialog:
    """Create dialog for switching all repos to a branch."""
    return (
        dialog()
        .text_prompt("Switch all repos to branch")
        .message("Enter branch name (existing or new)")
        .placeholder("Branch name")
        .default(default_branch)
        .on_confirm(on_confirm)
        .build()
    )


def create_branch_dialog(
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create dialog for creating a new branch."""
    return (
        dialog()
        .text_prompt("Create new branch")
        .message("Enter name for the new branch")
        .placeholder("Branch name")
        .on_confirm(on_confirm)
        .build()
    )


def confirm_update_dialog(
    repo_name: str,
    action: str = "rebase",
    on_confirm: Callable[[bool], None] = None,
) -> Dialog:
    """Create confirmation dialog for updating a repo."""
    return (
        dialog()
        .confirm(f"{action.title()} {repo_name}?")
        .message(f"This will {action} from origin")
        .on_confirm(on_confirm)
        .build()
    )


def select_branch_dialog(
    branches: List[str],
    title: str = "Select branch",
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create dialog for selecting from available branches."""
    builder = dialog().select_one(title)
    for branch in branches[:10]:  # Limit to 10 options in dialog
        builder.option(branch, branch)
    if len(branches) > 10:
        builder.message(f"Showing first 10 of {len(branches)} branches")
    return builder.on_confirm(on_confirm).build()


def add_repo_dialog(
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create dialog for adding a repo by URL or path."""
    return (
        dialog()
        .text_prompt("Add repository")
        .message("Enter git URL or local path")
        .placeholder("URL or path")
        .on_confirm(on_confirm)
        .build()
    )


def confirm_delete_dialog(
    item_name: str,
    item_type: str = "branch",
    on_confirm: Callable[[bool], None] = None,
) -> Dialog:
    """Create confirmation dialog for deleting something."""
    return (
        dialog()
        .confirm(f"Delete {item_type}?")
        .message(f"This will delete: {item_name}")
        .on_confirm(on_confirm)
        .build()
    )


def confirm_action_dialog(
    title: str,
    message: str = "",
    on_confirm: Callable[[bool], None] = None,
) -> Dialog:
    """Create a generic confirmation dialog."""
    builder = dialog().confirm(title)
    if message:
        builder.message(message)
    return builder.on_confirm(on_confirm).build()


def text_input_dialog(
    title: str,
    message: str = "",
    default: str = "",
    placeholder: str = "",
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create a generic text input dialog."""
    builder = dialog().text_prompt(title)
    if message:
        builder.message(message)
    if default:
        builder.default(default)
    if placeholder:
        builder.placeholder(placeholder)
    return builder.on_confirm(on_confirm).build()


def custom_command_dialog(
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create dialog for entering a custom git command."""
    return (
        dialog()
        .text_prompt("Custom command")
        .message("Enter git command to run")
        .placeholder("git ...")
        .on_confirm(on_confirm)
        .build()
    )


def rename_dialog(
    current_name: str,
    item_type: str = "item",
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create dialog for renaming something."""
    return (
        dialog()
        .text_prompt(f"Rename {item_type}")
        .message(f"Current: {current_name}")
        .default(current_name)
        .placeholder("New name")
        .on_confirm(on_confirm)
        .build()
    )


def select_action_dialog(
    title: str,
    options: List[Tuple[str, str, str]],  # [(value, label, description), ...]
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create dialog for selecting from a list of actions."""
    builder = dialog().select_one(title)
    for value, label, desc in options:
        builder.option(value, label, desc)
    return builder.on_confirm(on_confirm).build()


def update_repo_dialog(
    repo_name: str,
    branch: str,
    default_action: str,
    index: int,
    total: int,
    upstream_count: int = 0,
    on_confirm: Callable[[str], None] = None,
) -> Dialog:
    """Create dialog for choosing how to update a single repo.

    Used by the update-all flow to show per-repo prompts inline.

    Args:
        repo_name: Display name of the repo
        branch: Current branch name
        default_action: The configured default (rebase/merge/skip)
        index: 1-based index in the update sequence
        total: Total repos being updated
        upstream_count: Number of upstream commits to pull
        on_confirm: Callback receiving the selected action string
    """
    default_label = {
        "rebase": "pull --rebase",
        "merge": "pull (merge)",
        "skip": "skip",
    }.get(default_action, default_action)

    count_hint = f"  ({upstream_count} to pull)" if upstream_count else ""

    builder = (
        dialog()
        .select_one(f"Update ({index}/{total}): {repo_name}")
        .message(f"branch: {branch}  default: {default_label}{count_hint}")
    )
    builder.option("use_default", f"Use default: {default_label}",
                   selected=(default_action not in ("rebase", "merge", "skip")))
    builder.option("rebase", "Pull --rebase", selected=(default_action == "rebase"))
    builder.option("merge", "Pull (merge)", selected=(default_action == "merge"))
    builder.option("skip", "Skip this repo", selected=(default_action == "skip"))
    builder.option("stop", "Stop updating (skip remaining)")
    return builder.on_confirm(on_confirm).build()


# --- Helper to integrate dialog lines into menu ---

def build_menu_with_dialog(
    dialog_state: ExploreMenuState,
    regular_menu_lines: List[Tuple[str, str]],
) -> str:
    """Build complete menu input including dialog if active.

    Args:
        dialog_state: Current dialog state
        regular_menu_lines: Regular menu items as (value, display) tuples

    Returns:
        Tab-separated menu input string for fzf
    """
    all_lines = []

    # Add dialog items at top if active
    if dialog_state.has_dialog():
        dialog_lines = dialog_state.get_dialog_menu_lines()
        all_lines.extend(dialog_lines)

    # Add regular menu items
    all_lines.extend(regular_menu_lines)

    # Format as tab-separated lines
    return "\n".join(f"{value}\t{display}" for value, display in all_lines)


def get_dialog_header_override(
    dialog_state: ExploreMenuState,
    normal_header: str,
) -> str:
    """Get header text, modified if dialog is active."""
    if dialog_state.has_dialog():
        return f"Complete dialog above | Esc=cancel\n{dialog_state.active_dialog.title}"
    return normal_header


def get_dialog_expect_keys(
    dialog_state: ExploreMenuState,
    normal_expect_keys: List[str],
) -> List[str]:
    """Get expect keys - empty list while dialog is active."""
    if dialog_state.has_dialog():
        return []  # Disable hotkeys during dialog
    return normal_expect_keys
