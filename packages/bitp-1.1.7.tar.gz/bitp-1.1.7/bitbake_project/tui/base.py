#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Base classes for TUI abstraction layer.

Defines the interface that all backends must implement.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple, Union


class Action(Enum):
    """Standard menu actions."""
    SELECT = auto()      # Item selected (Enter)
    CANCEL = auto()      # User cancelled (Esc)
    QUIT = auto()        # Quit entirely
    BACK = auto()        # Go back
    CUSTOM = auto()      # Custom action (check result.action_key)


@dataclass
class MenuItem:
    """A single item in a menu.

    Attributes:
        value: The actual value returned when selected
        display: Text shown in the menu (defaults to str(value))
        preview_data: Data passed to preview command/function
        metadata: Additional data attached to the item
        selectable: Whether item can be selected (False for headers/separators)
        group: Optional group name for hierarchical display
        indent: Indentation level (for hierarchical display)
    """
    value: Any
    display: Optional[str] = None
    preview_data: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    selectable: bool = True
    group: Optional[str] = None
    indent: int = 0

    def __post_init__(self):
        if self.display is None:
            self.display = str(self.value)
        if self.preview_data is None:
            self.preview_data = str(self.value)


@dataclass
class KeyBinding:
    """A key binding for a menu action.

    Attributes:
        key: The key (e.g., "ctrl-e", "alt-d", "f1")
        action: Action name for handler
        description: Human-readable description for help
        show_in_header: Whether to show in header help text
    """
    key: str
    action: str
    description: str
    show_in_header: bool = True


@dataclass
class MenuConfig:
    """Configuration for a menu.

    Attributes:
        header: Header text shown above the menu
        prompt: Prompt text shown at input line
        preview_cmd: Shell command for preview (use {} for item value)
        preview_fn: Python function for preview (receives MenuItem)
        preview_size: Preview pane size (e.g., "50%", "right:60%")
        multi_select: Allow multiple selection
        height: Menu height (e.g., "100%", "~50%", "20")
        bindings: Custom key bindings
        show_help: Show key binding help in header
        initial_query: Initial filter query
        no_sort: Disable sorting (preserve item order)
    """
    header: Optional[str] = None
    prompt: str = "> "
    preview_cmd: Optional[str] = None
    preview_fn: Optional[Callable[[MenuItem], str]] = None
    preview_size: str = "50%"
    multi_select: bool = False
    height: str = "100%"
    bindings: List[KeyBinding] = field(default_factory=list)
    show_help: bool = True
    initial_query: str = ""
    no_sort: bool = False


@dataclass
class MenuResult:
    """Result from a menu interaction.

    Attributes:
        action: The action taken (SELECT, CANCEL, QUIT, CUSTOM)
        selected: Selected item(s) - single MenuItem or list if multi_select
        action_key: The key pressed for CUSTOM actions
        query: The query string when menu closed
    """
    action: Action
    selected: Optional[Union[MenuItem, List[MenuItem]]] = None
    action_key: Optional[str] = None
    query: str = ""

    @property
    def value(self) -> Any:
        """Get the value of the selected item (convenience)."""
        if self.selected is None:
            return None
        if isinstance(self.selected, list):
            return [item.value for item in self.selected]
        return self.selected.value

    @property
    def cancelled(self) -> bool:
        """Check if user cancelled."""
        return self.action in (Action.CANCEL, Action.QUIT)


@dataclass
class PromptResult:
    """Result from a text prompt.

    Attributes:
        value: The entered text (None if cancelled)
        confirmed: Whether user confirmed (vs cancelled)
    """
    value: Optional[str]
    confirmed: bool

    @property
    def cancelled(self) -> bool:
        return not self.confirmed


class MenuBackend(ABC):
    """Abstract base class for TUI backends.

    All backends must implement these methods to provide a consistent
    interface for menus, prompts, and confirmations.
    """

    @abstractmethod
    def select_one(
        self,
        items: List[MenuItem],
        config: Optional[MenuConfig] = None,
    ) -> MenuResult:
        """Show a menu and get a single selection.

        Args:
            items: List of menu items
            config: Menu configuration

        Returns:
            MenuResult with selected item or cancellation
        """
        pass

    @abstractmethod
    def select_many(
        self,
        items: List[MenuItem],
        config: Optional[MenuConfig] = None,
    ) -> MenuResult:
        """Show a menu and get multiple selections.

        Args:
            items: List of menu items
            config: Menu configuration (multi_select forced True)

        Returns:
            MenuResult with list of selected items
        """
        pass

    @abstractmethod
    def prompt(
        self,
        message: str,
        default: str = "",
        placeholder: str = "",
    ) -> PromptResult:
        """Show a text input prompt.

        Args:
            message: Prompt message
            default: Default value
            placeholder: Placeholder text

        Returns:
            PromptResult with entered text
        """
        pass

    @abstractmethod
    def confirm(
        self,
        message: str,
        default: bool = False,
    ) -> bool:
        """Show a yes/no confirmation.

        Args:
            message: Confirmation message
            default: Default choice

        Returns:
            True if confirmed, False otherwise
        """
        pass

    @abstractmethod
    def notify(
        self,
        message: str,
        title: Optional[str] = None,
        wait: bool = False,
    ) -> None:
        """Show a notification/message.

        Args:
            message: Message text
            title: Optional title
            wait: If True, wait for user acknowledgment
        """
        pass

    def available(self) -> bool:
        """Check if this backend is available."""
        return True

    def name(self) -> str:
        """Get backend name."""
        return self.__class__.__name__
