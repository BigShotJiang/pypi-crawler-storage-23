#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Projects command - manage multiple bit working directories."""

import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
from typing import Dict, List, Optional, Tuple

from ..core import (
    Colors, get_fzf_color_args, get_fzf_preview_resize_bindings, fzf_available,
    terminal_color, TERMINAL_COLOR_ELEMENTS, ANSI_COLORS,
    get_terminal_color, set_terminal_color, _get_global_colors_file,
    get_color_mode, current_branch, load_defaults,
)
from ..fzf_bindings import get_exit_bindings, get_preview_scroll_bindings, get_action_binding, get_position_binding
from ..tui import ExploreMenuState, update_repo_dialog, confirm_action_dialog, text_input_dialog
from .update import run_single_repo_update
from .common import repo_display_name, log_message, consume_header_message, fzf_message_viewer, build_inline_dialog_lines
from .ssh_remote import (
    parse_remote_uri,
    format_remote_uri,
    is_remote_project,
    ssh_check_connection,
    ssh_path_exists,
    ssh_path_is_empty,
    ssh_run,
    ssh_get_dashboard_summary,
    ssh_get_git_repos,
    ssh_current_branch,
    ssh_run_single_repo_update,
    remote_run_action,
    remote_shell,
    fetch_remote_projects,
)


def _input_with_path_complete(prompt: str) -> str:
    """Like input() but with filesystem tab completion."""
    import readline

    def _path_completer(text, state):
        expanded = os.path.expanduser(text)
        if os.path.isdir(expanded) and not expanded.endswith(os.sep):
            expanded += os.sep
        import glob as _glob
        matches = _glob.glob(expanded + "*")
        # Append / to directories
        matches = [m + os.sep if os.path.isdir(m) else m for m in matches]
        return matches[state] if state < len(matches) else None

    old_completer = readline.get_completer()
    old_delims = readline.get_completer_delims()
    try:
        readline.set_completer(_path_completer)
        readline.set_completer_delims(" \t\n")
        readline.parse_and_bind("tab: complete")
        return input(prompt)
    finally:
        readline.set_completer(old_completer)
        readline.set_completer_delims(old_delims)


def _get_projects_file() -> str:
    """Get path to global projects config file."""
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "projects.json")


def load_projects() -> Dict[str, dict]:
    """
    Load projects from config file.

    Returns dict mapping path -> {name, description, last_used}.
    Excludes internal keys like __current_project__, __directory_browser__, etc.
    """
    projects_file = _get_projects_file()
    if not os.path.isfile(projects_file):
        return {}
    try:
        with open(projects_file, "r") as f:
            data = json.load(f)
            # Filter out internal keys (start with __)
            return {k: v for k, v in data.items() if not k.startswith("__")}
    except (json.JSONDecodeError, OSError):
        return {}


def get_current_project() -> Optional[str]:
    """Get the currently active project path, or None if not set."""
    config_file = _get_projects_file()
    if not os.path.isfile(config_file):
        return None
    try:
        with open(config_file, "r") as f:
            data = json.load(f)
            path = data.get("__current_project__")
            if not path:
                return None
            # Remote projects: check registration instead of filesystem
            projects = {k: v for k, v in data.items() if not k.startswith("__")}
            info = projects.get(path, {})
            if is_remote_project(info):
                return path
            # Local: verify it still exists
            if os.path.isdir(path):
                return path
            return None
    except (json.JSONDecodeError, OSError):
        return None


def find_project_for_directory(directory: Optional[str] = None) -> Optional[str]:
    """Return the registered project path that contains `directory`.

    If `directory` is inside (or equal to) a registered project, return that
    project's path.  When multiple projects match (nested), the deepest
    (longest path) wins.  Returns None if no project matches.
    """
    cwd = os.path.abspath(directory or os.getcwd())
    projects = load_projects()
    best_match: Optional[str] = None
    best_len = 0
    for proj_path in projects:
        proj = os.path.abspath(proj_path)
        # cwd must be the project dir itself or a subdirectory
        if cwd == proj or cwd.startswith(proj + os.sep):
            if len(proj) > best_len:
                best_match = proj
                best_len = len(proj)
    return best_match


def resolve_project_by_name(name: str) -> Optional[str]:
    """Resolve a project short name to its path.

    Matches case-insensitively against registered project names.
    Also accepts a direct path if it matches a registered project.
    Returns the project path or None.
    """
    projects = load_projects()

    # Direct path match
    if name in projects:
        return name

    # Name match (case-insensitive)
    for proj_path, info in projects.items():
        if info.get("name", "").lower() == name.lower():
            return proj_path

    return None


def set_current_project(path: Optional[str]) -> None:
    """Set the currently active project path (or None to clear)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    if path:
        # Remote URIs keep their format; local paths get normalized
        if parse_remote_uri(path):
            data["__current_project__"] = path
        else:
            data["__current_project__"] = os.path.abspath(path)
    elif "__current_project__" in data:
        del data["__current_project__"]

    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def save_projects(projects: Dict[str, dict]) -> None:
    """Save projects to config file, preserving internal __ keys."""
    projects_file = _get_projects_file()
    # Read existing data to preserve internal keys (__preview_layout__, etc.)
    existing: dict = {}
    if os.path.isfile(projects_file):
        try:
            with open(projects_file, "r") as f:
                existing = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    # Keep internal keys, replace project entries
    merged = {k: v for k, v in existing.items() if k.startswith("__")}
    merged.update(projects)
    try:
        with open(projects_file, "w") as f:
            json.dump(merged, f, indent=2)
    except OSError as e:
        print(f"Warning: Could not save projects: {e}", file=sys.stderr)


def add_project(path: str, name: Optional[str] = None, description: str = "") -> bool:
    """
    Add a project to the list.

    Args:
        path: Absolute path to the project directory
        name: Display name (defaults to directory basename)
        description: Optional description

    Returns:
        True if added, False if already exists or invalid
    """
    path = os.path.abspath(path)
    if not os.path.isdir(path):
        print(f"Error: Not a directory: {path}", file=sys.stderr)
        return False

    projects = load_projects()
    if path in projects:
        print(f"Project already registered: {path}")
        return False

    if not name:
        name = os.path.basename(path)

    projects[path] = {
        "name": name,
        "description": description,
        "last_used": None,
    }
    save_projects(projects)
    print(f"Added project: {name} ({path})")

    # Write .ignore so ripgrep/fd/etc skip build directories
    from .common import write_ignore_file
    if write_ignore_file(path):
        print(f"Wrote {os.path.join(path, '.ignore')} (excludes build*/ from searches)")

    return True


def remove_project(path: str) -> bool:
    """Remove a project from the list."""
    projects = load_projects()
    # Try as-is first (covers remote URIs), then try abspath for local
    if path not in projects:
        path = os.path.abspath(path)
    if path not in projects:
        print(f"Project not found: {path}", file=sys.stderr)
        return False

    name = projects[path].get("name", path)
    del projects[path]
    save_projects(projects)
    print(f"Removed project: {name}")
    return True


def _project_key_valid(key: str, projects: dict) -> bool:
    """Check if a project key is valid (exists on disk for local, registered for remote)."""
    if key not in projects:
        return False
    info = projects[key]
    if is_remote_project(info):
        return True  # Remote projects validated at add time
    return os.path.isdir(key)


def add_remote_project(uri: str, name: Optional[str] = None,
                       description: str = "",
                       skip_path_check: bool = False) -> bool:
    """Add a remote SSH project after validating connectivity.

    Args:
        uri: Remote URI in ``user@host:/path`` format
        name: Display name (defaults to basename of remote path)
        description: Optional description
        skip_path_check: Skip SSH path validation (caller already verified/created)

    Returns:
        True if added, False on error
    """
    parsed = parse_remote_uri(uri)
    if not parsed:
        log_message(f"{Colors.red('✗')} Invalid remote URI: {uri} (expected user@host:/path)")
        return False

    user, host, remote_path = parsed
    key = format_remote_uri(user, host, remote_path)

    projects = load_projects()
    if key in projects:
        log_message(f"{Colors.yellow('!')} Already registered: {key}")
        return False

    if not skip_path_check:
        # Validate SSH connectivity
        log_message(f"Checking SSH connection to {host}...")
        if not ssh_check_connection(user, host):
            log_message(f"{Colors.red('✗')} Cannot connect to {user}@{host} via SSH")
            return False

        # Validate remote path
        if not ssh_path_exists(user, host, remote_path):
            log_message(f"{Colors.red('✗')} Remote path does not exist: {remote_path}")
            return False

    if not name:
        name = os.path.basename(remote_path.rstrip("/"))

    projects[key] = {
        "name": name,
        "description": description,
        "last_used": None,
        "host": host,
        "user": user,
        "remote_path": remote_path,
    }
    save_projects(projects)
    log_message(f"{Colors.green('✓')} Added remote: {name} ({key})")
    return True


def sync_from_remote(host_spec: str) -> int:
    """Pull local projects from a remote bit instance. Additive only.

    Args:
        host_spec: "user@host" or just "host" (user defaults to current)

    Returns number of projects added.
    """
    if "@" in host_spec:
        user, host = host_spec.split("@", 1)
    else:
        user = os.environ.get("USER", "")
        host = host_spec

    remote_list = fetch_remote_projects(user, host)
    if not remote_list:
        return 0

    projects = load_projects()
    added = 0
    for rp in remote_list:
        uri = format_remote_uri(user, host, rp["path"])
        if uri in projects:
            continue  # already registered — additive only
        projects[uri] = {
            "name": rp["name"],
            "description": rp.get("description", ""),
            "last_used": None,
            "host": host,
            "user": user,
            "remote_path": rp["path"],
        }
        added += 1

    if added:
        save_projects(projects)

    return added


def _detect_project_info(path: str) -> dict:
    """Detect info about a potential project directory."""
    info = {
        "has_bblayers": False,
        "has_defaults": False,
        "layer_count": 0,
        "branch": None,
    }

    # Check for bblayers.conf in build/conf or any conf directory
    for root, dirs, files in os.walk(path):
        depth = root[len(path):].count(os.sep)
        if depth > 3:
            dirs[:] = []
            continue
        if "bblayers.conf" in files:
            info["has_bblayers"] = True
            break

    # Check for defaults file
    if os.path.isfile(os.path.join(path, ".bit.defaults")):
        info["has_defaults"] = True

    # Count layers
    for root, dirs, files in os.walk(path):
        depth = root[len(path):].count(os.sep)
        if depth > 4:
            dirs[:] = []
            continue
        if "layer.conf" in files and "conf" in root:
            info["layer_count"] += 1

    # Get git branch if in a git repo
    try:
        result = subprocess.run(
            ["git", "-C", path, "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            info["branch"] = result.stdout.strip()
    except Exception:
        pass

    return info


_project_info_cache: Dict[str, Tuple[float, dict]] = {}
_CACHE_TTL = 30.0


def _detect_project_info_fast(path: str) -> dict:
    """Detect project info with caching and fast checks.

    Uses a 30s TTL cache. Checks only standard bblayers.conf locations
    (conf/ and build/conf/) instead of walking the tree. Falls back to
    full _detect_project_info() for layer count on first load.
    """
    now = time.monotonic()
    if path in _project_info_cache:
        ts, cached = _project_info_cache[path]
        if now - ts < _CACHE_TTL:
            return cached

    info = {
        "has_bblayers": False,
        "has_defaults": False,
        "layer_count": 0,
        "branch": None,
        "is_dirty": False,
        "ahead": 0,
        "behind": 0,
    }

    if not os.path.isdir(path):
        _project_info_cache[path] = (now, info)
        return info

    # Fast check: bblayers.conf in standard locations only
    for subdir in ("conf", "build/conf"):
        if os.path.isfile(os.path.join(path, subdir, "bblayers.conf")):
            info["has_bblayers"] = True
            break

    # Check for defaults file
    if os.path.isfile(os.path.join(path, ".bit.defaults")):
        info["has_defaults"] = True

    # Find primary git repo — project root first, then common Yocto subdirs
    git_dir = None
    if os.path.isdir(os.path.join(path, ".git")):
        git_dir = path
    else:
        for subdir in ("poky", "oe-core", "openembedded-core"):
            candidate = os.path.join(path, subdir)
            if os.path.isdir(os.path.join(candidate, ".git")):
                git_dir = candidate
                break
        # Fallback: first git repo in immediate subdirectories
        if not git_dir:
            try:
                for entry in os.scandir(path):
                    if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                        if os.path.isdir(os.path.join(entry.path, ".git")):
                            git_dir = entry.path
                            break
            except OSError:
                pass

    # Git checks on primary repo
    if git_dir:
        try:
            result = subprocess.run(
                ["git", "-C", git_dir, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0:
                info["branch"] = result.stdout.strip()
        except Exception:
            pass

        if info["branch"]:
            try:
                r = subprocess.run(
                    ["git", "-C", git_dir, "status", "--porcelain", "-uno", "--no-renames"],
                    capture_output=True, text=True, timeout=3,
                )
                if r.returncode == 0 and r.stdout.strip():
                    info["is_dirty"] = True
            except Exception:
                pass
            try:
                r = subprocess.run(
                    ["git", "-C", git_dir, "rev-list", "--left-right", "--count", "HEAD...@{u}"],
                    capture_output=True, text=True, timeout=3,
                )
                if r.returncode == 0:
                    parts = r.stdout.strip().split()
                    if len(parts) == 2:
                        info["ahead"] = int(parts[0])
                        info["behind"] = int(parts[1])
            except Exception:
                pass

    # Layer count: reuse from previous cache if available, else full walk
    if path in _project_info_cache:
        _, old = _project_info_cache[path]
        if old.get("layer_count", 0) > 0:
            info["layer_count"] = old["layer_count"]
        else:
            full = _detect_project_info(path)
            info["layer_count"] = full.get("layer_count", 0)
    else:
        full = _detect_project_info(path)
        info["layer_count"] = full.get("layer_count", 0)

    _project_info_cache[path] = (now, info)
    return info


_dashboard_summary_cache: Dict[str, Tuple[float, dict]] = {}


def _get_project_git_repos(path: str) -> List[str]:
    """Find all git repos in a project directory, up to 2 levels deep."""
    git_repos: list = []
    if not os.path.isdir(path):
        return git_repos
    if os.path.isdir(os.path.join(path, ".git")):
        git_repos.append(path)
    try:
        for entry in os.scandir(path):
            if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                if os.path.isdir(os.path.join(entry.path, ".git")):
                    git_repos.append(entry.path)
                else:
                    try:
                        for sub in os.scandir(entry.path):
                            if sub.is_dir(follow_symlinks=False) and not sub.name.startswith("."):
                                if os.path.isdir(os.path.join(sub.path, ".git")):
                                    git_repos.append(sub.path)
                    except OSError:
                        pass
    except OSError:
        pass
    return git_repos


_REMOTE_CACHE_TTL = 120.0  # 2 minutes for remote projects


def _get_dashboard_summary(path: str, project_info: Optional[dict] = None) -> dict:
    """Get repo-level summary for a project directory.

    Scans for git repos up to 2 levels deep and gathers aggregate stats:
    repo_count, dirty_count, ahead (local commits), behind (upstream), branch.
    Uses 30s TTL cache (120s for remote projects).

    If *project_info* indicates a remote project, delegates to
    ``ssh_get_dashboard_summary()``.
    """
    now = time.monotonic()
    ttl = _REMOTE_CACHE_TTL if (project_info and is_remote_project(project_info)) else _CACHE_TTL
    if path in _dashboard_summary_cache:
        ts, cached = _dashboard_summary_cache[path]
        if now - ts < ttl:
            return cached

    empty_summary: dict = {
        "repo_count": 0,
        "dirty_count": 0,
        "ahead": 0,
        "behind": 0,
        "branch": "",
        "needs_setup": False,
    }

    # Remote project — single SSH call
    if project_info and is_remote_project(project_info):
        user = project_info.get("user", "")
        host = project_info["host"]
        remote_path = project_info.get("remote_path", "")
        summary = ssh_get_dashboard_summary(user, host, remote_path)
        _dashboard_summary_cache[path] = (now, summary)
        return summary

    if not os.path.isdir(path):
        _dashboard_summary_cache[path] = (now, empty_summary)
        return empty_summary

    summary = dict(empty_summary)
    git_repos = _get_project_git_repos(path)
    summary["repo_count"] = len(git_repos)

    # Gather per-repo stats
    branches: dict = {}  # branch_name -> count

    for repo in git_repos:
        # Branch
        try:
            r = subprocess.run(
                ["git", "-C", repo, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0:
                b = r.stdout.strip()
                if b:
                    branches[b] = branches.get(b, 0) + 1
        except Exception:
            pass

        # Dirty check
        try:
            r = subprocess.run(
                ["git", "-C", repo, "status", "--porcelain", "-uno", "--no-renames"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0 and r.stdout.strip():
                summary["dirty_count"] += 1
        except Exception:
            pass

        # Ahead/behind upstream
        try:
            r = subprocess.run(
                ["git", "-C", repo, "rev-list", "--left-right", "--count", "HEAD...@{u}"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0:
                parts = r.stdout.strip().split()
                if len(parts) == 2:
                    summary["ahead"] += int(parts[0])
                    summary["behind"] += int(parts[1])
        except Exception:
            pass

    # Most common branch across repos
    if branches:
        summary["branch"] = max(branches, key=branches.get)

    # Check if project needs setup (config cloned but not applied)
    defaults_path = os.path.join(path, ".bit.defaults")
    if os.path.isfile(defaults_path):
        try:
            with open(defaults_path) as f:
                proj_defaults = json.load(f)
            conf_meta = proj_defaults.get("__conf_json__", {})
            if conf_meta and not conf_meta.get("applied", True):
                summary["needs_setup"] = True
        except (json.JSONDecodeError, OSError):
            pass

    _dashboard_summary_cache[path] = (now, summary)
    return summary


def _remove_project_interactive() -> bool:
    """Show picker to select a project to stop tracking."""
    if not fzf_available():
        return False

    projects = load_projects()
    if not projects:
        print("No projects to remove.")
        return False

    menu_lines = []
    for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
        name = info.get("name", os.path.basename(path))
        if is_remote_project(info):
            indicator = terminal_color("project_remote", "⇄ ")
        elif os.path.isdir(path):
            indicator = "  "
        else:
            indicator = Colors.red("! ")
        menu_lines.append(f"{path}\t{indicator}{name:<20} {Colors.dim(path)}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~40%",
        "--layout", "reverse",
        "--header", "Select project to stop tracking (Enter=remove, ←/q=cancel)",
        "--prompt", "Remove: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return False

    if result.returncode != 0 or not result.stdout.strip():
        return False

    selected = result.stdout.strip().split("\t")[0]
    if selected in projects:
        return remove_project(selected)

    return False


def fzf_project_picker(include_browse: bool = True, show_exit_hint: bool = False) -> Optional[str]:
    """
    Show fzf menu to select a project.

    Args:
        include_browse: Include option to browse for new project
        show_exit_hint: Show hint about Enter exiting to command menu

    Returns:
        Selected project path, or special commands like:
        - "SELECT:<path>" - Space was pressed, set as active but stay in picker
        - "EXIT:<path>" - Enter was pressed, exit and optionally chain to command menu
        - Other special values for menu options
        - None if cancelled
    """
    if not fzf_available():
        return None

    projects = load_projects()
    current_project = get_current_project()

    if not projects and not include_browse:
        print("No projects registered. Use 'bit projects add' to add one.")
        return None

    # Build menu
    menu_lines = []

    # Compute max path length for column alignment
    max_path_len = max((len(p) for p in projects), default=20)
    path_col = max_path_len + 3  # 3 spaces after longest path

    # Column header and separator (first lines = top of screen with reverse-list)
    header_line = f"HEADER\t  {'Name':<20} {'Path':<{path_col}} Info"
    sep_len = 2 + 20 + 1 + path_col + 4
    separator = f"SEPARATOR_HEADER\t{'─' * sep_len}"
    menu_lines.append(header_line)
    menu_lines.append(separator)

    for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
        name = info.get("name", os.path.basename(path))
        desc = info.get("description", "")

        # Check if path still exists and if it's current
        is_current = (path == current_project)
        is_remote = is_remote_project(info)
        exists = is_remote or os.path.isdir(path)
        if exists:
            if is_remote:
                status = terminal_color("project_remote", "⇄") if not is_current else terminal_color("project_active", "●")
            elif is_current:
                status = terminal_color("project_active", "●")
            else:
                status = terminal_color("project_name", "○")
        else:
            status = terminal_color("project_missing", "!")

        # Detect current state (skip for remote — no local filesystem)
        proj_info = _detect_project_info(path) if (not is_remote and os.path.isdir(path)) else {}
        layers = proj_info.get("layer_count", 0)
        branch = proj_info.get("branch", "")

        extra = []
        if is_current:
            extra.append("ACTIVE")
        if layers:
            extra.append(f"{layers} layers")
        if branch:
            extra.append(branch)
        extra_str = f"({', '.join(extra)})" if extra else ""

        # Pad path to align info column (Colors.dim adds ANSI codes, so pad the raw path first)
        padded_path = f"{path:<{path_col}}"
        display = f"{status} {name:<20} {Colors.dim(padded_path)}{terminal_color('project_active', extra_str)}"
        if desc:
            display += f" - {desc}"

        menu_lines.append(f"{path}\t{display}")

    # Add browse/add/remove options
    if include_browse:
        menu_lines.append("---\t" + "─" * 50)
        menu_lines.append("ADD_CWD\t+ Add current directory")
        menu_lines.append("ADD_PATH\t+ Enter path manually...")
        menu_lines.append("BROWSE\t+ Browse for directory...")
        if projects:
            menu_lines.append("REMOVE\t- Remove project tracking...")
        if current_project:
            menu_lines.append("CLEAR\t✖ Clear active project")
        # Settings
        browser = get_directory_browser()
        browser_desc = {"auto": "auto (broot>ranger>nnn>fzf)", "nnn": "nnn", "fzf": "fzf", "broot": "broot", "ranger": "ranger"}.get(browser, browser)
        menu_lines.append(f"SETTINGS\t⚙ Settings: browser={browser_desc}")

    menu_input = "\n".join(menu_lines)

    # Build header based on context
    if show_exit_hint:
        header = (f"{terminal_color('project_active', 'Projects')} | Space=activate | Enter=done (→menu) | q=quit"
                  f"\n+=browse | -=remove | c=clear | s=settings | S=shell | i=setup")
    else:
        header = (f"{terminal_color('project_active', 'Projects')} | Space=activate | Enter=done | q=quit"
                  f"\n+=browse | -=remove | c=clear | s=settings | S=shell | i=setup")

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--layout=reverse-list",
        "--height", "~50%",
        "--header", header,
        "--prompt", "Project: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
        "--expect", "space,+,-,c,s,i,S",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None

    # Parse output - with --expect, first line is key (or empty if Enter), second is selection
    # Don't strip() first as it removes the leading newline when Enter is pressed
    lines = result.stdout.split("\n")
    key = lines[0].strip() if lines else ""
    selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

    # Items that are not projects (actions, separators, header)
    action_items = ("---", "ADD_CWD", "ADD_PATH", "BROWSE", "REMOVE", "CLEAR", "SETTINGS",
                    "HEADER", "SEPARATOR_HEADER")

    # Handle key shortcuts
    if key == "+":
        return "BROWSE"
    elif key == "space" and selected and selected not in action_items:
        # Space = select/activate the project but stay in picker
        return f"SELECT:{selected}"
    elif key == "-" and selected and selected not in action_items:
        # Remove the highlighted project directly
        return f"REMOVE:{selected}"
    elif key == "c":
        return "CLEAR"
    elif key == "s":
        return "SETTINGS"
    elif key == "S" and selected and selected not in action_items:
        return f"SHELL:{selected}"
    elif key == "i" and selected and selected not in action_items:
        return f"INIT:{selected}"

    # No special key (Enter) - return the selected item
    if not selected or selected in ("---", "HEADER", "SEPARATOR_HEADER"):
        return fzf_project_picker(include_browse, show_exit_hint)

    # Enter on a project - signal to exit
    if selected not in action_items:
        return f"EXIT:{selected}"

    return selected


def _invalidate_summary_cache(path: str) -> None:
    """Remove a project's cached dashboard summary so it refreshes."""
    _dashboard_summary_cache.pop(path, None)


def _dashboard_run_setup(project_path: str) -> None:
    """Run setup apply for a project from the dashboard."""
    saved_cwd = os.getcwd()
    try:
        os.chdir(project_path)
        apply_args = argparse.Namespace(
            defaults_file=".bit.defaults",
            bblayers=None,
            config=None,
            layers_dir="layers",
        )
        from .setup import run_setup_apply
        rc = run_setup_apply(apply_args)
        if rc != 0:
            log_message(f"{Colors.yellow('!')} Setup incomplete")
        else:
            log_message(f"{Colors.green('✓')} Setup complete")
        input("\nPress Enter to continue...")
    except (EOFError, KeyboardInterrupt):
        pass
    finally:
        try:
            os.chdir(saved_cwd)
        except OSError:
            pass


def _dashboard_run_command(project_path: str, argv: list,
                           project_info: Optional[dict] = None) -> int:
    """Run a bit command in the context of a project directory.

    For remote projects, delegates to ``remote_run_action()`` with fallback
    chain. For local projects, changes to the project directory, sets it as
    active, runs the command via cli.main(), then restores the original
    directory.
    """
    if project_info and is_remote_project(project_info):
        user = project_info.get("user", "")
        host = project_info["host"]
        rpath = project_info.get("remote_path", "")
        cmd = " ".join(argv)
        return remote_run_action(user, host, rpath, cmd)

    saved_cwd = os.getcwd()
    try:
        os.chdir(project_path)
        from ..cli import main as cli_main
        return cli_main(argv)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 1
    finally:
        try:
            os.chdir(saved_cwd)
        except OSError:
            pass


def _parse_action_key(key: str) -> Tuple[str, Optional[str]]:
    """Parse ``ACTION:<path>:<cmd>`` → ``(path, cmd)``.

    Remote project paths contain ``:`` (e.g. ``user@host:/dir``), so we
    split on the *last* colon — command names never contain ``:``.
    For non-ACTION keys returns ``(key, None)``.
    """
    if not key.startswith("ACTION:"):
        return (key, None)
    rest = key[7:]  # strip "ACTION:" prefix
    last_colon = rest.rfind(":")
    if last_colon > 0:
        return (rest[:last_colon], rest[last_colon + 1:])
    return (rest, None)


# Action submenus for expanded projects
_DASHBOARD_ACTIONS = [
    ("explore", "Browse commits and repos"),
    ("update", "Update git repos"),
    ("recipes", "Search and browse recipes"),
    ("info", "Build configuration"),
    ("deps", "Layer dependencies"),
    ("fragments", "Configuration fragments"),
    ("export", "Export config to .conf.json"),
    ("config", "Repo and layer settings"),
    ("shell", "Build environment shell"),
]


def fzf_dashboard() -> int:
    """Project dashboard with status summaries and quick actions.

    Shows all configured projects with status columns (branch, layer count,
    sync/dirty status), expandable action submenus per project, and an inline
    manage dialog. Direct action keybindings also available.
    Returns to dashboard after each action completes.
    """
    if not fzf_available():
        return 1

    GROUP_COLLAPSE_THRESHOLD = 6  # auto-collapse groups with more than this many projects
    expanded_projects: set = set()
    collapsed_groups: set = set()  # group keys: "local" or "remote:<host>"
    _groups_initialized: bool = False
    last_selection: Optional[str] = get_current_project()
    show_manage: bool = False
    show_configure: bool = False
    show_export: bool = False
    export_context: dict = {}  # project_name, sources, relative_layers, fragments
    export_enabled: Dict[str, bool] = {}  # fragment -> enabled
    export_cursor: Optional[str] = None  # key to position cursor on after toggle
    export_description: str = ""
    export_desc_input: bool = False  # True = text-input mode for description
    dialog_state = ExploreMenuState()

    while True:
        projects = load_projects()
        current_project = get_current_project()

        # Build menu lines
        menu_lines = []

        if not projects:
            # No projects yet - just show manage entry
            menu_lines.append("MANAGE\t  ⚙  Manage projects...")
        else:
            # Gather repo summaries for all projects
            summaries = {}
            for path, pinfo in projects.items():
                if _project_key_valid(path, projects):
                    summaries[path] = _get_dashboard_summary(path, project_info=pinfo)
                else:
                    summaries[path] = {}

            # Compute column widths from raw (pre-ANSI) data
            names_raw = []
            branches_raw = []
            status_raw = []
            for path, info in projects.items():
                names_raw.append(info.get("name", os.path.basename(path)))
                s = summaries.get(path, {})
                branches_raw.append(s.get("branch") or "")
                # Build raw status text for width computation
                rc = s.get("repo_count", 0)
                if rc == 0:
                    status_raw.append("")
                else:
                    sp = [f"{rc:2} repos"]
                    if s.get("dirty_count", 0):
                        sp.append(f"\u270e{s['dirty_count']}")
                    if s.get("ahead", 0):
                        sp.append(f"\u2191{s['ahead']}")
                    if s.get("behind", 0):
                        sp.append(f"\u2193{s['behind']}")
                    if not s.get("dirty_count") and not s.get("ahead") and not s.get("behind"):
                        sp.append("\u2713")
                    status_raw.append(" ".join(sp))

            max_name = max((len(n) for n in names_raw), default=10)
            name_col = min(max(max_name + 2, 10), 25)

            max_branch = max((len(b) for b in branches_raw), default=8)
            branch_col = min(max(max_branch + 2, 8), 20)

            max_status = max((len(s) for s in status_raw), default=8)
            status_col = min(max(max_status + 2, 8), 30)

            total_width = name_col + branch_col + status_col + 12

            # Banner header (non-selectable, at bottom of input = top of screen with reverse-list)
            banner_text = Colors.bold(Colors.cyan("── bit dashboard ──"))
            menu_lines.append(f"HEADER\t  {banner_text}{'─' * max(total_width - 15, 10)}")

            # Column headers — prefix is 4 visual chars: expand(1) + space(1) + dot(1) + space(1)
            col_header = (
                f"    {'Name':<{name_col}} "
                f"{'Branch':<{branch_col}} "
                f"{'Status':<{status_col}} "
                f"Path"
            )
            menu_lines.append(f"SEP_COL\t{Colors.dim(col_header)}")
            menu_lines.append(f"SEP_LINE\t  {'─' * total_width}")

            # Group projects: local first, then per-host remote
            local_projects = []
            remote_by_host = {}  # host -> [(path, info), ...]
            for path, info in projects.items():
                if is_remote_project(info):
                    h = info.get("host", "unknown")
                    remote_by_host.setdefault(h, []).append((path, info))
                else:
                    local_projects.append((path, info))

            # Sort within each group
            local_projects.sort(key=lambda x: x[1].get("name", x[0]).lower())
            for h in remote_by_host:
                remote_by_host[h].sort(key=lambda x: x[1].get("name", x[0]).lower())
            sorted_hosts = sorted(remote_by_host.keys())

            # One-time auto-collapse for groups exceeding threshold
            if not _groups_initialized:
                _groups_initialized = True
                if len(local_projects) > GROUP_COLLAPSE_THRESHOLD:
                    collapsed_groups.add("local")
                for h, items in remote_by_host.items():
                    if len(items) > GROUP_COLLAPSE_THRESHOLD:
                        collapsed_groups.add(f"remote:{h}")

            def _render_project_entry(path, info):
                """Render a single project entry into menu_lines."""
                name = info.get("name", os.path.basename(path))
                is_current = (path == current_project)
                is_expanded = (path in expanded_projects)
                is_remote = is_remote_project(info)
                if is_remote:
                    exists = summaries.get(path, {}).get("exists", True)
                else:
                    exists = os.path.isdir(path)

                s = summaries.get(path, {})
                branch = s.get("branch") or ""
                rc = s.get("repo_count", 0)
                dirty = s.get("dirty_count", 0)
                ahead = s.get("ahead", 0)
                behind = s.get("behind", 0)

                # Dot indicator (current/ready/missing)
                if exists:
                    if is_current:
                        dot = terminal_color("project_active", "●")
                    else:
                        dot = terminal_color("project_name", "○")
                else:
                    dot = terminal_color("project_missing", "!")

                # Expand marker
                expand = "-" if is_expanded else "+"

                # Build status text (raw for padding, colored for display)
                if rc == 0:
                    raw_parts = []
                    col_parts = []
                else:
                    raw_parts = [f"{rc:2} repos"]
                    col_parts = [f"{rc:2} repos"]
                    if dirty:
                        raw_parts.append(f"\u270e{dirty}")
                        col_parts.append(terminal_color("dirty", f"\u270e{dirty}"))
                    if ahead:
                        raw_parts.append(f"\u2191{ahead}")
                        col_parts.append(terminal_color("project_ahead", f"\u2191{ahead}"))
                    if behind:
                        raw_parts.append(f"\u2193{behind}")
                        col_parts.append(terminal_color("project_behind", f"\u2193{behind}"))
                    if not dirty and not ahead and not behind:
                        raw_parts.append("\u2713")
                        col_parts.append(terminal_color("clean", "\u2713"))
                if s.get("needs_setup"):
                    raw_parts.append("\u26a0 setup")
                    col_parts.append(Colors.yellow("\u26a0 setup"))
                raw_st = " ".join(raw_parts)
                colored_st = " ".join(col_parts)

                # Pad raw text BEFORE applying ANSI colors
                padded_name = f"{name:<{name_col}}"
                padded_branch = f"{branch:<{branch_col}}"
                # Status: pad with spaces after colored text
                st_padding = max(status_col - len(raw_st), 0)
                padded_status = colored_st + " " * st_padding

                # Apply colors after padding
                if is_current:
                    colored_name = Colors.bold(terminal_color("project_active", padded_name))
                elif not exists:
                    colored_name = terminal_color("project_missing", padded_name)
                else:
                    colored_name = Colors.bold(terminal_color("project_name", padded_name))

                colored_branch = terminal_color("project_branch", padded_branch) if branch else padded_branch
                colored_path = Colors.dim(path)

                desc = info.get("description", "")
                desc_suffix = f"  {Colors.dim(f'[{desc}]')}" if desc else ""
                indent = "  " if _grouped[0] else ""
                display = f"{indent}{expand} {dot} {colored_name} {colored_branch} {padded_status} {colored_path}{desc_suffix}"
                menu_lines.append(f"{path}\t{display}")

                # Action sub-items if expanded
                if is_expanded:
                    actions = list(_DASHBOARD_ACTIONS)
                    if summaries.get(path, {}).get("needs_setup"):
                        actions.insert(0, ("setup", "Complete project setup (apply config)"))
                    if is_remote:
                        actions.append(("properties", "Project name and description"))
                    for idx, (cmd, action_desc) in enumerate(actions):
                        is_last = (idx == len(actions) - 1)
                        tree_char = "└─" if is_last else "├─"
                        action_line = f"{indent}  {tree_char} {Colors.cyan(f'{cmd:<14}')}{Colors.dim(action_desc)}"
                        menu_lines.append(f"ACTION:{path}:{cmd}\t{action_line}")

            _group_index = [0]  # track group count for separator logic
            _grouped = [False]  # whether group headers are being rendered

            def _render_group(group_key, label, items):
                """Render a group header and its project entries."""
                count = len(items)
                is_collapsed = group_key in collapsed_groups

                # Dotted separator line before every group except the first
                if _group_index[0] > 0:
                    menu_lines.append(f"SEP_GROUP_{group_key}\t  {Colors.dim('╌' * total_width)}")
                _group_index[0] += 1

                # Group header line (selectable — toggles collapse)
                marker = "+" if is_collapsed else "-"
                group_display = f"{marker} {label}"
                if is_collapsed:
                    group_display += f"  {Colors.dim(f'({count})')}"
                menu_lines.append(f"GROUP:{group_key}\t{group_display}")

                if is_collapsed:
                    return

                # Render each project
                for path, info in items:
                    _render_project_entry(path, info)

            # Only show group headers when there are remote projects
            has_remotes = bool(remote_by_host)

            if has_remotes:
                _grouped[0] = True

                # Render local group
                if local_projects:
                    local_label = f"{terminal_color('project_name', '⌂')} {Colors.bold('Local')}"
                    _render_group("local", local_label, local_projects)

                # Render remote groups (one per host)
                for host in sorted_hosts:
                    items = remote_by_host[host]
                    host_label = f"{terminal_color('project_remote', '⇄')} {Colors.bold('Remote')} {Colors.dim('──')} {Colors.bold(host)}"
                    _render_group(f"remote:{host}", host_label, items)
            else:
                # No remotes — render local projects without group header
                for path, info in local_projects:
                    _render_project_entry(path, info)

            # Separator and manage entry
            menu_lines.append(f"SEP_BOTTOM\t  {'─' * total_width}")
            menu_lines.append(f"MANAGE\t  {Colors.dim('⚙')}  Manage projects...")
            menu_lines.append(f"CONFIGURE\t  {Colors.dim('⚙')}  Configure...")

        # Inline manage dialog: append items (reverse-list puts end of list near prompt)
        if show_manage:
            manage_actions = [
                ("MANAGE_ADD_CWD", f"{Colors.green('+')} Add current directory"),
                ("MANAGE_ADD_PATH", f"{Colors.green('+')} Enter path manually..."),
                ("MANAGE_BROWSE", f"{Colors.green('+')} Browse for directory..."),
                ("MANAGE_ADD_REMOTE", f"{Colors.cyan('⇄')} Add remote (SSH)..."),
                ("MANAGE_SYNC_REMOTE", f"{Colors.cyan('⇄')} Sync from remote..."),
            ]
            if current_project:
                manage_actions.append(("MANAGE_CLEAR", f"{Colors.red('✖')}  Clear active project"))
            menu_lines = menu_lines + build_inline_dialog_lines(
                "Add Project", manage_actions, reverse_list=True,
            )

        # Inline configure dialog
        if show_configure:
            from .config import fzf_global_settings
            browser = get_directory_browser()
            browser_desc = {"auto": "auto-detect", "broot": "broot", "ranger": "ranger",
                            "nnn": "nnn", "fzf": "fzf built-in"}.get(browser, browser)
            git_viewer = get_git_viewer()
            viewer_desc = {"auto": "auto-detect", "tig": "tig", "lazygit": "lazygit",
                           "gitk": "gitk"}.get(git_viewer, git_viewer)
            preview_layout = get_preview_layout()
            layout_desc = {"down": "bottom", "right": "side-by-side", "up": "top"}.get(preview_layout, preview_layout)
            recipe_scan = "bitbake-layers" if get_recipe_use_bitbake_layers() else "file scan"

            conf_actions = [
                ("CONF_COLORS", "Colors and themes..."),
                ("CONF_BROWSER", f"Dir browser          {Colors.dim(browser_desc)}"),
                ("CONF_VIEWER", f"Git viewer            {Colors.dim(viewer_desc)}"),
                ("CONF_PREVIEW", f"Preview layout        {Colors.dim(layout_desc)}"),
                ("CONF_RECIPE", f"Recipe scan           {Colors.dim(recipe_scan)}"),
            ]
            menu_lines = menu_lines + build_inline_dialog_lines(
                "Configure", conf_actions, reverse_list=True,
            )

        # Inline export dialog with fragment toggles
        if show_export and export_context:
            pname = export_context["project_name"]
            n_src = len(export_context["sources"])
            n_lay = len(export_context["relative_layers"])
            frags = export_context["fragments"]
            export_actions: List[Tuple[str, str]] = []
            if frags:
                export_actions.append(("---", ""))  # separator
                for frag in frags:
                    chk = "[x]" if export_enabled.get(frag, True) else "[ ]"
                    export_actions.append((f"EXPORT_TOGGLE:{frag}", f"  {chk} {frag}"))
            desc_display = export_description if export_description else Colors.dim("(none — click to set)")
            export_actions.append(("EXPORT_DESC", f"  Description: {desc_display}"))
            export_actions.append(("---", ""))  # separator
            export_actions.append(("EXPORT_FILE", f"  > Export to file      {Colors.dim(f'{pname}.conf.json')}"))
            export_actions.append(("EXPORT_REGISTRY", f"  > Export to registry  {Colors.dim('~/.config/bit/registry/')}"))
            annotation = Colors.dim(f"{n_src} repos, {n_lay} layers, {len(frags)} fragments")
            menu_lines = menu_lines + build_inline_dialog_lines(
                "Export", export_actions, reverse_list=True, annotation=annotation,
            )

        # Inline update dialog: append dialog items (reverse-list puts end near prompt)
        has_dialog = dialog_state.has_dialog()
        if has_dialog:
            dialog_lines = dialog_state.get_dialog_menu_lines()
            for value, display in dialog_lines:
                menu_lines.append(f"{value}\t{display}")

        menu_input = "\n".join(menu_lines)

        # Header
        if has_dialog:
            header = "Enter=select | Esc=cancel"
        else:
            header_line1 = "Space=activate | Enter/→=open | \\=fold | ?/m=commands | +/-=add/remove | q=quit"
            header_line2 = "x=explore | u=update | r=recipes | i=info | d=deps | f=fragments | c=config | S=shell | M=messages"
            header = f"{header_line1}\n{header_line2}"

        # Prepend most-recent status message (shown for one fzf iteration)
        status_msg = consume_header_message()
        if status_msg:
            header = f"{status_msg}\n{header}"

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--layout=reverse-list",
            "--height", "~80%",
            "--header", header,
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        if has_dialog:
            prompt = dialog_state.get_prompt_text() or "Select: "
            fzf_args.extend(["--disabled", "--prompt", prompt])
        elif show_manage:
            fzf_args.extend(["--disabled", "--prompt", "Manage: "])
        elif show_configure:
            fzf_args.extend(["--disabled", "--prompt", "Configure: "])
        elif show_export and export_desc_input:
            fzf_args.extend([
                "--print-query", "--disabled",
                "--query", export_description,
                "--header", "Type description, Enter=confirm  (Esc=cancel)",
                "--prompt", "Desc: ",
            ])
        elif show_export:
            fzf_args.extend(["--disabled", "--prompt", "Export: "])
        else:
            fzf_args.extend(["--prompt", "Dashboard: "])

        # Bindings using get_action_binding pattern (no --expect needed)
        fzf_args.extend(["--bind", "enter:become(echo ENTER {1})"])
        fzf_args.extend(get_action_binding("right", "RIGHT {1}"))
        fzf_args.extend(get_action_binding("left", "LEFT {1}"))
        fzf_args.extend(get_action_binding("\\", "EXPAND {1}"))
        fzf_args.extend(get_action_binding("space", "ACTIVATE {1}"))
        fzf_args.extend(get_action_binding("?", "MENU {1}"))
        fzf_args.extend(get_action_binding("m", "MENU {1}"))
        fzf_args.extend(get_action_binding("+", "MANAGE"))
        fzf_args.extend(get_action_binding("-", "REMOVE {1}"))
        fzf_args.extend(get_action_binding("q", "QUIT"))
        # Direct action keybindings on highlighted project
        fzf_args.extend(get_action_binding("x", "EXPLORE {1}"))
        fzf_args.extend(get_action_binding("u", "UPDATE {1}"))
        fzf_args.extend(get_action_binding("r", "RECIPES {1}"))
        fzf_args.extend(get_action_binding("i", "INFO {1}"))
        fzf_args.extend(get_action_binding("d", "DEPS {1}"))
        fzf_args.extend(get_action_binding("f", "FRAGMENTS {1}"))
        fzf_args.extend(get_action_binding("c", "CONFIG {1}"))
        fzf_args.extend(get_action_binding("S", "SHELL {1}"))
        fzf_args.extend(get_action_binding("n", "RENAME {1}"))
        fzf_args.extend(get_action_binding("M", "MESSAGES"))
        fzf_args.extend(["--bind", "esc:abort"])

        # Override bindings when inline dialog is active (last-wins in fzf)
        if show_manage or show_configure or show_export:
            fzf_args.extend(["--bind", "right:become(echo ENTER {1})"])
        if show_export and not export_desc_input:
            fzf_args.extend(["--bind", "space:become(echo ENTER {1})"])
        if export_desc_input:
            fzf_args.extend(["--bind", "enter:accept"])

        # Cursor positioning
        if has_dialog:
            # Position on default dialog option
            default_line = dialog_state.get_default_cursor_line()
            if default_line:
                # Offset by number of non-dialog lines (dialog items are appended at end)
                non_dialog_count = len(menu_lines) - len(dialog_state.get_dialog_menu_lines())
                fzf_args.extend(get_position_binding(non_dialog_count + default_line))
        elif show_manage or show_configure or show_export:
            # Position cursor in the inline dialog
            key_list = [line.split("\t")[0] for line in menu_lines]
            target_key = export_cursor if (show_export and export_cursor) else None
            if target_key and target_key in key_list:
                pos = key_list.index(target_key) + 1
                fzf_args.extend(get_position_binding(pos))
                export_cursor = None
            else:
                first_prefix = ("MANAGE_" if show_manage else
                                "CONF_" if show_configure else "EXPORT_")
                for idx, k in enumerate(key_list):
                    if k.startswith(first_prefix):
                        fzf_args.extend(get_position_binding(idx + 1))
                        break
        elif last_selection and projects:
            key_list = [line.split("\t")[0] for line in menu_lines]
            if last_selection in key_list:
                pos = key_list.index(last_selection) + 1  # 1-indexed
                fzf_args.extend(get_position_binding(pos))

        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return 1

        if export_desc_input:
            export_desc_input = False
            if result.returncode != 0:
                continue  # Esc = cancel
            lines = result.stdout.splitlines()
            query = lines[0].strip() if lines else ""
            if query:
                export_description = query
            continue

        if result.returncode != 0 or not result.stdout.strip():
            # Esc/abort: dismiss dialog if open, else quit
            if has_dialog:
                dialog_state.clear_dialog()
                continue
            if show_manage:
                show_manage = False
                continue
            if show_configure:
                show_configure = False
                continue
            if show_export:
                show_export = False
                export_context = {}
                export_enabled = {}
                export_cursor = None
                export_description = ""
                continue
            return 0

        output = result.stdout.strip()

        # --- Parse output ---

        # Non-selectable keys
        non_selectable = {"HEADER", "MANAGE_SEP", "CONF_SEP", "---"}

        # Handle dialog selections (Enter on a __DLG_ item)
        if has_dialog and output.startswith("ENTER __DLG_"):
            selected_value = output[6:]  # Strip "ENTER " prefix
            if dialog_state.is_dialog_selection(selected_value):
                result_dlg = dialog_state.handle_dialog_selection(selected_value, "")
                old_dialog = dialog_state.active_dialog
                if result_dlg.confirmed:
                    if old_dialog and old_dialog.on_confirm:
                        old_dialog.on_confirm(result_dlg.value)
                    # Only clear if callback didn't chain a new dialog
                    if dialog_state.active_dialog is old_dialog:
                        dialog_state.clear_dialog()
                else:
                    dialog_state.clear_dialog()
            else:
                dialog_state.clear_dialog()
            continue

        # Dismiss dialog on any other action
        if has_dialog:
            dialog_state.clear_dialog()
            continue

        if output == "QUIT":
            return 0

        if output == "MESSAGES":
            fzf_message_viewer()
            continue

        # Group header toggle (Enter/Expand/Right on GROUP: items)
        _group_prefix = None
        for _gp in ("ENTER GROUP:", "EXPAND GROUP:", "RIGHT GROUP:"):
            if output.startswith(_gp):
                _group_prefix = _gp
                break
        if _group_prefix:
            group_key = output[len(_group_prefix):]
            if group_key in collapsed_groups:
                collapsed_groups.discard(group_key)
            else:
                collapsed_groups.add(group_key)
            continue

        # Manage dialog activation (+ key or Enter on manage entry)
        if output in ("MANAGE", "ENTER MANAGE", "RIGHT MANAGE"):
            show_manage = True
            show_configure = False
            continue

        # Configure dialog activation (Enter/Right on configure entry)
        if output in ("CONFIGURE", "ENTER CONFIGURE", "RIGHT CONFIGURE"):
            show_configure = True
            show_manage = False
            continue

        # Manage dialog item selections
        if output.startswith("ENTER MANAGE_") or output.startswith("RIGHT MANAGE_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected and selected not in non_selectable:
                _dashboard_handle_manage(selected, projects, dialog_state)
            show_manage = False
            continue

        # Configure dialog item selections
        if output.startswith("ENTER CONF_") or output.startswith("RIGHT CONF_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected and selected not in non_selectable:
                _dashboard_handle_configure(selected)
            continue

        # Export dialog item selections
        if output.startswith("ENTER EXPORT_") or output.startswith("RIGHT EXPORT_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected == "EXPORT_DESC":
                export_desc_input = True
            elif selected.startswith("EXPORT_TOGGLE:"):
                frag_key = selected[len("EXPORT_TOGGLE:"):]
                export_enabled[frag_key] = not export_enabled.get(frag_key, True)
                export_cursor = selected  # stay on this item
            elif selected == "EXPORT_FILE" and export_context:
                from .setup import _write_export
                pname = export_context["project_name"]
                sel_frags = [f for f in export_context["fragments"]
                             if export_enabled.get(f, True)]
                _write_export(pname, export_context["sources"],
                              export_context["relative_layers"],
                              sel_frags, f"{pname}.conf.json",
                              description=export_description)
                log_message(f"{Colors.green('Exported')} {pname}.conf.json")
                show_export = False
                export_context = {}
                export_enabled = {}
                export_cursor = None
                export_description = ""
            elif selected == "EXPORT_REGISTRY" and export_context:
                from .setup import _write_export
                pname = export_context["project_name"]
                sel_frags = [f for f in export_context["fragments"]
                             if export_enabled.get(f, True)]
                _write_export(pname, export_context["sources"],
                              export_context["relative_layers"],
                              sel_frags, f"{pname}.conf.json", to_registry=True,
                              description=export_description)
                log_message(f"{Colors.green('Exported')} to registry: {pname}.conf.json")
                show_export = False
                export_context = {}
                export_enabled = {}
                export_cursor = None
                export_description = ""
            continue

        # LEFT while in dialog mode → dismiss
        if show_manage and output.startswith("LEFT "):
            show_manage = False
            continue
        if show_configure and output.startswith("LEFT "):
            show_configure = False
            continue
        if show_export and output.startswith("LEFT "):
            show_export = False
            export_context = {}
            export_enabled = {}
            export_description = ""
            continue

        # Activate/deactivate project (toggle)
        if output.startswith("ACTIVATE "):
            selected = output[9:].strip()
            if selected.startswith("ACTION:") or selected.startswith("GROUP:") or selected in non_selectable or selected.startswith("SEP_") or selected == "MANAGE":
                continue
            if selected and _project_key_valid(selected, projects):
                if selected == current_project:
                    # Already active → deactivate
                    set_current_project(None)
                    name = projects.get(selected, {}).get("name", os.path.basename(selected))
                    log_message(f"{Colors.yellow('○')} Deactivated: {name}")
                else:
                    set_current_project(selected)
                    name = projects.get(selected, {}).get("name", os.path.basename(selected))
                    log_message(f"{Colors.green('✓')} Activated: {Colors.bold(name)}")
            last_selection = selected
            continue

        # Remove project (- key) — show confirm dialog
        if output.startswith("REMOVE "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and selected in projects:
                name = projects[selected].get("name", os.path.basename(selected))
                target_path = selected  # capture for closure

                def _on_remove_confirm(confirmed):
                    if confirmed:
                        remove_project(target_path)
                        log_message(f"{Colors.yellow('✓')} Removed: {name}")
                        nonlocal last_selection
                        if last_selection == target_path:
                            last_selection = None

                dialog_state.show_dialog(
                    confirm_action_dialog(
                        f"Remove '{name}'?",
                        message=target_path,
                        on_confirm=_on_remove_confirm,
                    )
                )
            continue

        # Rename project (n key) — show text input dialog
        if output.startswith("RENAME "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and selected in projects:
                current_name = projects[selected].get("name", os.path.basename(selected))
                target_path = selected  # capture for closure

                def _on_rename(new_name):
                    if new_name and new_name != current_name:
                        projects[target_path]["name"] = new_name
                        save_projects(projects)
                        log_message(f"{Colors.green('✓')} Renamed: {current_name} → {new_name}")

                dialog_state.show_dialog(
                    text_input_dialog(
                        "Rename project",
                        message=selected,
                        default=current_name,
                        on_confirm=_on_rename,
                    )
                )
                last_selection = selected
            continue

        # Command menu (? or m)
        if output.startswith("MENU "):
            selected = output[5:].strip()
            target = None
            if selected.startswith("ACTION:"):
                target, _ = _parse_action_key(selected)
            elif selected and not selected.startswith("SEP_") and selected not in non_selectable and selected != "MANAGE":
                target = selected
            if not target:
                target = current_project
            if target and _project_key_valid(target, projects):
                target_info = projects.get(target, {})
                last_selection = target
                if is_remote_project(target_info):
                    # Remote: fall back to shell (no local command menu)
                    user = target_info.get("user", "")
                    host = target_info["host"]
                    rpath = target_info.get("remote_path", "")
                    remote_shell(user, host, rpath)
                else:
                    saved_cwd = os.getcwd()
                    try:
                        os.chdir(target)
                        from ..cli import fzf_command_menu, main as cli_main
                        cmd = fzf_command_menu()
                        if cmd:
                            cli_main(cmd.split())
                    finally:
                        try:
                            os.chdir(saved_cwd)
                        except OSError:
                            pass
            continue

        # Expand/collapse toggle
        if output.startswith("EXPAND "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:") or selected in non_selectable or selected.startswith("SEP_") or selected == "MANAGE":
                continue
            # Group header: toggle group collapse
            if selected.startswith("GROUP:"):
                group_key = selected[6:]
                if group_key in collapsed_groups:
                    collapsed_groups.discard(group_key)
                else:
                    collapsed_groups.add(group_key)
                continue
            if selected:
                if selected in expanded_projects:
                    expanded_projects.discard(selected)
                else:
                    expanded_projects.add(selected)
                last_selection = selected
            continue

        # Update action — inline update dialog (same pattern as explore)
        if output.startswith("UPDATE "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and _project_key_valid(selected, projects):
                last_selection = selected
                sel_info = projects.get(selected, {})
                _start_update_dialogs(selected, dialog_state, project_info=sel_info)
            continue

        # Config action (c key — special handling for remote)
        if output.startswith("CONFIG "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and not selected.startswith("SEP_") and selected not in non_selectable and selected != "MANAGE":
                if _project_key_valid(selected, projects):
                    sel_info = projects.get(selected, {})
                    last_selection = selected
                    if is_remote_project(sel_info):
                        # Remote: open local project properties (name, desc are local)
                        from .config import fzf_project_properties
                        fzf_project_properties(selected, projects)
                    else:
                        _dashboard_run_command(selected, ["config"], project_info=sel_info)
            continue

        # Direct action keybindings (x, r, i, d, f)
        direct_actions = {
            "EXPLORE ": "explore",
            "RECIPES ": "recipes",
            "INFO ": "info",
            "DEPS ": "deps",
            "FRAGMENTS ": "fragments",
        }
        handled = False
        for prefix, cmd in direct_actions.items():
            if output.startswith(prefix):
                selected = output[len(prefix):].strip()
                # Resolve ACTION: entries to their parent project
                if selected.startswith("ACTION:"):
                    selected, _ = _parse_action_key(selected)
                if selected and not selected.startswith("SEP_") and selected not in non_selectable and selected != "MANAGE":
                    if _project_key_valid(selected, projects):
                        sel_info = projects.get(selected, {})
                        _dashboard_run_command(selected, [cmd], project_info=sel_info)
                        last_selection = selected
                handled = True
                break
        if handled:
            continue

        # Shell action (S key — special handling)
        if output.startswith("SHELL "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and _project_key_valid(selected, projects):
                last_selection = selected
                sel_info = projects.get(selected, {})
                if is_remote_project(sel_info):
                    user = sel_info.get("user", "")
                    host = sel_info["host"]
                    rpath = sel_info.get("remote_path", "")
                    remote_shell(user, host, rpath)
                else:
                    os.chdir(selected)
                    ns = argparse.Namespace(layers_dir="layers")
                    from .setup import run_init_shell
                    run_init_shell(ns)
            continue

        # RIGHT arrow: expand project or run action
        if output.startswith("RIGHT "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                proj_path, cmd = _parse_action_key(selected)
                if cmd:
                    last_selection = proj_path
                    proj_info = projects.get(proj_path, {})
                    if cmd == "update":
                        if _project_key_valid(proj_path, projects):
                            _start_update_dialogs(proj_path, dialog_state, project_info=proj_info)
                    elif cmd == "setup":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                remote_run_action(
                                    proj_info.get("user", ""),
                                    proj_info["host"],
                                    proj_info.get("remote_path", ""),
                                    "setup apply",
                                )
                            else:
                                _dashboard_run_setup(proj_path)
                            _invalidate_summary_cache(proj_path)
                    elif cmd == "shell":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                remote_shell(proj_info.get("user", ""), proj_info["host"], proj_info.get("remote_path", ""))
                            else:
                                os.chdir(proj_path)
                                ns = argparse.Namespace(layers_dir="layers")
                                from .setup import run_init_shell
                                run_init_shell(ns)
                    elif cmd == "export":
                        if _project_key_valid(proj_path, projects):
                            if proj_info and is_remote_project(proj_info):
                                log_message(f"{Colors.yellow('!')} Export not supported for remote projects")
                            else:
                                saved = os.getcwd()
                                try:
                                    os.chdir(proj_path)
                                    from .setup import gather_export_data
                                    edata = gather_export_data(layers_dir="layers")
                                    if edata:
                                        export_context = edata
                                        export_enabled = {f: True for f in edata["fragments"]}
                                        show_export = True
                                    else:
                                        log_message(f"{Colors.yellow('!')} No exportable config found")
                                finally:
                                    try:
                                        os.chdir(saved)
                                    except OSError:
                                        pass
                    elif cmd == "properties":
                        from .config import fzf_project_properties
                        fzf_project_properties(proj_path, projects)
                    elif _project_key_valid(proj_path, projects):
                        _dashboard_run_command(proj_path, [cmd], project_info=proj_info)
            elif selected.startswith("GROUP:"):
                # RIGHT on group header: expand the group
                group_key = selected[6:]
                collapsed_groups.discard(group_key)
            elif selected and not selected.startswith("SEP_") and selected not in non_selectable and selected != "MANAGE":
                expanded_projects.add(selected)
                last_selection = selected
            continue

        # LEFT arrow: collapse or quit
        if output.startswith("LEFT "):
            selected = output[5:].strip()
            if selected.startswith("ACTION:"):
                parent, _ = _parse_action_key(selected)
                expanded_projects.discard(parent)
                last_selection = parent
            elif selected.startswith("GROUP:"):
                # LEFT on group header: collapse the group
                group_key = selected[6:]
                collapsed_groups.add(group_key)
            elif selected in expanded_projects:
                expanded_projects.discard(selected)
                last_selection = selected
            else:
                return 0
            continue

        # ENTER: toggle expand on project, run action on sub-item
        if output.startswith("ENTER "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                proj_path, cmd = _parse_action_key(selected)
                if cmd:
                    last_selection = proj_path
                    proj_info = projects.get(proj_path, {})
                    if cmd == "update":
                        if _project_key_valid(proj_path, projects):
                            _start_update_dialogs(proj_path, dialog_state, project_info=proj_info)
                    elif cmd == "setup":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                remote_run_action(
                                    proj_info.get("user", ""),
                                    proj_info["host"],
                                    proj_info.get("remote_path", ""),
                                    "setup apply",
                                )
                            else:
                                _dashboard_run_setup(proj_path)
                            _invalidate_summary_cache(proj_path)
                    elif cmd == "shell":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                remote_shell(proj_info.get("user", ""), proj_info["host"], proj_info.get("remote_path", ""))
                            else:
                                os.chdir(proj_path)
                                ns = argparse.Namespace(layers_dir="layers")
                                from .setup import run_init_shell
                                run_init_shell(ns)
                    elif cmd == "export":
                        if _project_key_valid(proj_path, projects):
                            if proj_info and is_remote_project(proj_info):
                                log_message(f"{Colors.yellow('!')} Export not supported for remote projects")
                            else:
                                saved = os.getcwd()
                                try:
                                    os.chdir(proj_path)
                                    from .setup import gather_export_data
                                    edata = gather_export_data(layers_dir="layers")
                                    if edata:
                                        export_context = edata
                                        export_enabled = {f: True for f in edata["fragments"]}
                                        show_export = True
                                    else:
                                        log_message(f"{Colors.yellow('!')} No exportable config found")
                                finally:
                                    try:
                                        os.chdir(saved)
                                    except OSError:
                                        pass
                    elif cmd == "properties":
                        from .config import fzf_project_properties
                        fzf_project_properties(proj_path, projects)
                    elif _project_key_valid(proj_path, projects):
                        _dashboard_run_command(proj_path, [cmd], project_info=proj_info)
            elif selected == "MANAGE":
                show_manage = True
            elif selected and not selected.startswith("SEP_") and selected not in non_selectable:
                if selected not in expanded_projects:
                    expanded_projects.add(selected)
                else:
                    expanded_projects.discard(selected)
                last_selection = selected
            continue

    return 0


def _dashboard_handle_manage(action: str, projects: dict,
                             dialog_state: ExploreMenuState = None) -> None:
    """Handle a manage submenu action."""
    # Strip MANAGE_ prefix if present
    if action.startswith("MANAGE_"):
        action = action[7:]

    def _add_or_create(path):
        """Add existing project, or create new from config if empty/missing."""
        is_empty = not os.path.exists(path) or (os.path.isdir(path) and not os.listdir(path))
        if not is_empty:
            # Existing project with content — just add it
            if dialog_state:
                def _on_confirm(confirmed):
                    if confirmed:
                        add_project(path)
                        name = os.path.basename(path)
                        log_message(f"{Colors.green('✓')} Added: {name}")
                dialog_state.show_dialog(
                    confirm_action_dialog(
                        f"Add '{os.path.basename(path)}'?",
                        message=path,
                        on_confirm=_on_confirm,
                    )
                )
            else:
                add_project(path)
            return

        # Empty or non-existent — offer to set up from config
        _create_project_at(path)

    def _add_or_create_remote(uri, ds=None):
        """Add existing remote project, or create from registry config if empty/missing."""
        parsed = parse_remote_uri(uri)
        if not parsed:
            log_message(f"{Colors.red('✗')} Invalid remote URI: {uri} (expected user@host:/path)")
            return

        user, host, rpath = parsed
        display_uri = format_remote_uri(user, host, rpath)
        name = os.path.basename(rpath.rstrip("/"))

        # Check SSH connectivity first
        log_message(f"Checking SSH connection to {host}...")
        if not ssh_check_connection(user, host):
            log_message(f"{Colors.red('✗')} Cannot connect to {user}@{host} via SSH")
            return

        # Check remote path state
        path_exists = ssh_path_exists(user, host, rpath)
        is_empty = not path_exists or ssh_path_is_empty(user, host, rpath)

        if not is_empty:
            # Path exists with content — just register it
            if ds:
                def _on_confirm(confirmed):
                    if confirmed:
                        add_remote_project(display_uri, skip_path_check=True)
                ds.show_dialog(
                    confirm_action_dialog(
                        f"Add remote '{name}'?",
                        message=f"{display_uri}",
                        on_confirm=_on_confirm,
                    )
                )
            else:
                add_remote_project(display_uri, skip_path_check=True)
            return

        # Empty or missing — offer to create from registry config
        _create_remote_project_at(user, host, rpath)

    if action == "ADD_CWD":
        _add_or_create(os.getcwd())

    elif action == "ADD_PATH":
        try:
            path = _input_with_path_complete("Enter project path: ").strip()
            if path:
                # Auto-detect remote URI format
                if parse_remote_uri(path):
                    _add_or_create_remote(path, dialog_state)
                else:
                    path = os.path.expanduser(path)
                    path = os.path.abspath(path)
                    _add_or_create(path)
        except (EOFError, KeyboardInterrupt):
            print()

    elif action == "BROWSE":
        path = browse_for_directory()
        if path:
            _add_or_create(path)

    elif action == "ADD_REMOTE":
        try:
            uri = input("Enter remote URI (user@host:/path): ").strip()
            if uri:
                _add_or_create_remote(uri, dialog_state)
        except (EOFError, KeyboardInterrupt):
            print()

    elif action == "SYNC_REMOTE":
        try:
            host_spec = input("Enter remote host (user@host): ").strip()
            if host_spec:
                added = sync_from_remote(host_spec)
                if added:
                    log_message(f"{Colors.green('✓')} Synced {added} project(s) from {host_spec}")
                else:
                    log_message(f"No new projects found on {host_spec}")
        except (EOFError, KeyboardInterrupt):
            print()

    elif action == "CLEAR":
        set_current_project(None)
        print(f"{Colors.yellow('Cleared')} active project.")

    elif action == "SETTINGS":
        from .config import fzf_global_settings
        fzf_global_settings()


def _create_project_at(target_dir: str) -> None:
    """Create a new project at target_dir from a registry config.

    Called when a user adds a directory that is empty or doesn't exist yet.
    Opens the registry browser to pick a config, then clones into it.
    """
    from .confjson import find_registry_dirs, discover_registry
    from .setup import _fzf_registry_pick, _clone_from_config, BASIC_CLONE_SENTINEL

    target_dir = os.path.abspath(target_dir)
    name = os.path.basename(target_dir)

    print()
    print(f"{Colors.bold(name)}: empty or new directory")
    print(f"  {target_dir}")
    print()

    # Browse registry for a config
    registry_dirs = find_registry_dirs()
    if not registry_dirs:
        print("No registry configurations found.")
        print(f"  Copy a .conf.json to the registry first:")
        print(f"    {Colors.cyan('bit setup registry-copy <file.conf.json>')}")
        # Still create the directory and add it as a project
        os.makedirs(target_dir, exist_ok=True)
        add_project(target_dir, name)
        print(f"\n{Colors.green('Added')} empty project: {name}")
        return

    all_entries = []
    for d, label in registry_dirs:
        entries = discover_registry(d, source_label=label)
        all_entries.extend(entries)

    if not all_entries:
        print("No configurations found in registry.")
        os.makedirs(target_dir, exist_ok=True)
        add_project(target_dir, name)
        print(f"\n{Colors.green('Added')} empty project: {name}")
        return

    print("Select a configuration to clone, or Esc to add as empty project:")
    print()

    result = _fzf_registry_pick(all_entries)
    if result is None:
        # Esc — just add as empty project
        os.makedirs(target_dir, exist_ok=True)
        add_project(target_dir, name)
        print(f"{Colors.green('Added')} empty project: {name}")
        return

    conf_file_path, conf, selected_config = result

    # Create directory and clone
    saved_cwd = os.getcwd()
    os.makedirs(target_dir, exist_ok=True)
    os.chdir(target_dir)

    try:
        layers_dir = "layers"
        defaults_file = ".bit.defaults"

        if conf_file_path == BASIC_CLONE_SENTINEL:
            # Basic clone: bitbake + oe-core + meta-yocto
            import argparse as _ap
            clone_args = _ap.Namespace(
                config=None, branch="master", layers_dir=layers_dir,
                clone=True, doit=True, defaults_file=defaults_file,
                name=name, project_dir=None,
            )
            from .setup import run_bootstrap
            rc = run_bootstrap(clone_args)
        else:
            rc = _clone_from_config(conf, selected_config, layers_dir, do_clone=True,
                                    defaults_file=defaults_file)
            if rc == 0:
                # Save config metadata
                defaults = load_defaults(defaults_file)
                conf_meta = defaults.get("__conf_json__", {})
                conf_meta["file"] = conf_file_path
                defaults["__conf_json__"] = conf_meta
                from ..core import save_defaults
                save_defaults(defaults_file, defaults)

        if rc != 0:
            os.chdir(saved_cwd)
            return

        # Register as tracked project
        add_project(target_dir, name)
        set_current_project(target_dir)
        print()
        print(f"{Colors.green('Created')} project: {name}")
        print(f"  Path: {target_dir}")

        # Auto-run apply if we have a config that hasn't been applied
        defaults = load_defaults(defaults_file)
        conf_meta = defaults.get("__conf_json__", {})
        if conf_meta and not conf_meta.get("applied", True):
            print()
            print(Colors.bold("Setting up build environment..."))
            apply_args = argparse.Namespace(
                defaults_file=defaults_file,
                bblayers=None,
                config=None,
                layers_dir=layers_dir,
            )
            from .setup import run_setup_apply
            rc = run_setup_apply(apply_args)
            if rc != 0:
                print()
                print("To complete setup later:")
                print(f"  {Colors.cyan('bit setup apply')}  (from project directory)")
                print(f"  or use the {Colors.cyan('setup')} action in the dashboard")
    finally:
        os.chdir(saved_cwd)


def _fetch_remote_registry(user: str, host: str, registry_path: str,
                           source_label: str = "Built-in") -> list:
    """Fetch .conf.json files from a remote directory via SSH.

    Returns a list of registry entry tuples matching the discover_registry()
    format: (filename, virtual_path, relative_path, parsed_conf, source_label).
    """
    import json as _json
    from .confjson import parse_conf_json_data

    # List .conf.json files on remote
    qpath = shlex.quote(registry_path)
    r = ssh_run(user, host,
                f'find {qpath} -name "*.conf.json" -type f 2>/dev/null',
                timeout=15)
    if r.returncode != 0 or not r.stdout.strip():
        return []

    remote_files = [line.strip() for line in r.stdout.strip().splitlines()
                    if line.strip()]
    if not remote_files:
        return []

    entries = []
    for remote_file in remote_files:
        # Read file content via SSH
        r = ssh_run(user, host, f'cat {shlex.quote(remote_file)}', timeout=10)
        if r.returncode != 0 or not r.stdout.strip():
            continue
        try:
            data = _json.loads(r.stdout)
            parsed = parse_conf_json_data(data)
            fname = os.path.basename(remote_file)
            rel_path = os.path.relpath(remote_file, registry_path)
            # Use a virtual path (remote:path) so it's distinguishable
            virtual_path = f"{user}@{host}:{remote_file}"
            entries.append((fname, virtual_path, rel_path, parsed, source_label))
        except (_json.JSONDecodeError, KeyError, OSError):
            continue

    return entries


def _create_remote_project_at(user: str, host: str, remote_path: str) -> None:
    """Create a new project on a remote host from a registry config.

    Mirrors _create_project_at() but executes clones on the remote via SSH.
    Clones bitbake first to make its built-in registry available for the
    config picker, just like the local flow.
    """
    from .confjson import find_registry_dirs, discover_registry
    from .setup import _fzf_registry_pick, BASIC_CLONE_SENTINEL

    name = os.path.basename(remote_path.rstrip("/"))
    uri = format_remote_uri(user, host, remote_path)

    print()
    print(f"{Colors.bold(name)}: empty or new remote directory")
    print(f"  {uri}")
    print()

    # Step 1: Clone bitbake on the remote first to get its built-in registry
    layers_dir = f"{remote_path}/layers"
    bitbake_dir = f"{layers_dir}/bitbake"
    bitbake_url = "https://git.openembedded.org/bitbake"
    bitbake_registry = f"{bitbake_dir}/default-registry"

    print(Colors.bold("Cloning bitbake on remote (for built-in registry)..."))
    clone_script = (
        f'mkdir -p {shlex.quote(layers_dir)} && '
        f'if [ ! -d {shlex.quote(bitbake_dir)} ]; then '
        f'git clone -b master {shlex.quote(bitbake_url)} {shlex.quote(bitbake_dir)} || exit 1; '
        f'echo "cloned bitbake"; '
        f'else echo "skip bitbake"; fi'
    )
    r = ssh_run(user, host, clone_script, timeout=120)
    if r.returncode != 0:
        if r.stderr:
            log_message(r.stderr.strip().splitlines()[-1])
        log_message(f"{Colors.red('✗')} Failed to clone bitbake on {host}")
        return
    for line in r.stdout.strip().splitlines():
        line = line.strip()
        if line.startswith("cloned "):
            print(f"  {Colors.green('clone')} {line[7:]}")
        elif line.startswith("skip "):
            print(f"  {Colors.yellow('skip')} {line[5:]}")
    print()

    # Step 2: Gather registry entries — remote built-in + local user
    all_entries = []

    # Fetch built-in registry from the remote bitbake clone
    builtin_entries = _fetch_remote_registry(user, host, bitbake_registry,
                                             source_label="Built-in")
    all_entries.extend(builtin_entries)

    # Local user registry (configs on this machine)
    registry_dirs = find_registry_dirs()
    for d, label in registry_dirs:
        if label == "Built-in":
            continue  # Skip local built-in — we already have the remote's
        entries = discover_registry(d, source_label=label)
        all_entries.extend(entries)

    if not all_entries:
        log_message("No configurations found in registry.")
        add_remote_project(uri, name, skip_path_check=True)
        log_message(f"{Colors.green('✓')} Added remote project: {name}")
        return

    print("Select a configuration to clone on remote, or Esc to add as-is:")
    print()

    result = _fzf_registry_pick(all_entries)
    if result is None:
        # Esc — register with just the bitbake clone already done
        add_remote_project(uri, name, skip_path_check=True)
        log_message(f"{Colors.green('✓')} Added remote project: {name}")
        return

    conf_file_path, conf, selected_config = result

    if conf_file_path == BASIC_CLONE_SENTINEL:
        # Basic clone: clone remaining 2 repos (bitbake already done)
        rc = _remote_basic_clone(user, host, remote_path, branch="master",
                                 skip_bitbake=True)
    else:
        # Config clone: clone all repos (bitbake already present, will be skipped)
        rc = _remote_clone_from_config(user, host, remote_path, conf,
                                       selected_config)

    if rc != 0:
        log_message(f"{Colors.red('✗')} Clone failed on {host}")
        return

    add_remote_project(uri, name, skip_path_check=True)
    log_message(f"{Colors.green('✓')} Created remote project: {name}")

    # Config clone: write defaults + conf.json on remote, then run setup apply
    if conf_file_path != BASIC_CLONE_SENTINEL:
        ok = _write_remote_defaults(user, host, remote_path,
                                    conf_file_path, conf, selected_config)
        if ok:
            print()
            print(Colors.bold("Setting up build environment on remote..."))
            remote_run_action(user, host, remote_path, "setup apply")


def _write_remote_defaults(user: str, host: str, remote_path: str,
                           conf_file_path: str, conf, selected_config) -> bool:
    """Write .bit.defaults and .bit.conf.json on the remote after cloning.

    Reads the raw .conf.json content (from local file or remote path),
    writes it to ``<remote_path>/.bit.conf.json``, then builds a
    ``.bit.defaults`` with ``__conf_json__`` metadata and ``__extra_repos__``.

    Returns True on success.
    """
    # Read raw .conf.json content
    conf_json_content = None
    parsed = parse_remote_uri(conf_file_path)
    if parsed:
        # Remote virtual path (user@host:path) — fetch via SSH
        r_user, r_host, r_path = parsed
        r = ssh_run(r_user, r_host, f"cat {shlex.quote(r_path)}", timeout=15)
        if r.returncode == 0 and r.stdout.strip():
            conf_json_content = r.stdout
    elif os.path.isfile(conf_file_path):
        # Local file
        try:
            with open(conf_file_path, "r") as f:
                conf_json_content = f.read()
        except OSError:
            pass

    if not conf_json_content:
        log_message(f"{Colors.yellow('!')} Could not read .conf.json — skipping remote setup")
        return False

    # Write .bit.conf.json on remote
    remote_conf = f"{remote_path}/.bit.conf.json"
    from .ssh_remote import _ssh_mux_opts, _ssh_no_prompt_env
    target = f"{user}@{host}" if user else host
    try:
        r = subprocess.run(
            ["ssh", *_ssh_mux_opts(),
             "-o", "BatchMode=yes", "-o", "ConnectTimeout=5",
             "-o", "StrictHostKeyChecking=accept-new",
             target,
             f"cat > {shlex.quote(remote_conf)}"],
            input=conf_json_content.encode(),
            capture_output=True, timeout=15,
            env=_ssh_no_prompt_env(),
        )
        if r.returncode != 0:
            log_message(f"{Colors.yellow('!')} Failed to write .bit.conf.json on remote")
            return False
    except (subprocess.TimeoutExpired, OSError):
        log_message(f"{Colors.yellow('!')} Failed to write .bit.conf.json on remote")
        return False

    # Identify non-layer repos (no conf/layer.conf) on the remote
    layers_dir = f"{remote_path}/layers"
    extra_repos = []
    for src in conf.sources:
        if src.is_local:
            continue
        repo_rel = f"layers/{src.path}"
        layer_conf = f"{layers_dir}/{src.path}/conf/layer.conf"
        r = ssh_run(user, host, f"test -f {shlex.quote(layer_conf)}", timeout=10)
        if r.returncode != 0:
            extra_repos.append(repo_rel)

    # Build .bit.defaults
    defaults = {
        "__conf_json__": {
            "file": ".bit.conf.json",
            "selected": selected_config.name,
            "applied": False,
        },
    }
    if extra_repos:
        defaults["__extra_repos__"] = extra_repos

    defaults_json = json.dumps(defaults, indent=2, sort_keys=True)
    remote_defaults = f"{remote_path}/.bit.defaults"
    try:
        r = subprocess.run(
            ["ssh", *_ssh_mux_opts(),
             "-o", "BatchMode=yes", "-o", "ConnectTimeout=5",
             "-o", "StrictHostKeyChecking=accept-new",
             target,
             f"cat > {shlex.quote(remote_defaults)}"],
            input=defaults_json.encode(),
            capture_output=True, timeout=15,
            env=_ssh_no_prompt_env(),
        )
        if r.returncode != 0:
            log_message(f"{Colors.yellow('!')} Failed to write .bit.defaults on remote")
            return False
    except (subprocess.TimeoutExpired, OSError):
        log_message(f"{Colors.yellow('!')} Failed to write .bit.defaults on remote")
        return False

    return True


def _remote_basic_clone(user: str, host: str, remote_path: str,
                        branch: str = "master",
                        skip_bitbake: bool = False) -> int:
    """Clone the 3 core Yocto repos on the remote host."""
    repos = [
        ("bitbake", "https://git.openembedded.org/bitbake"),
        ("openembedded-core", "https://git.openembedded.org/openembedded-core"),
        ("meta-yocto", "https://git.yoctoproject.org/meta-yocto"),
    ]
    if skip_bitbake:
        repos = [(n, u) for n, u in repos if n != "bitbake"]
    layers_dir = f"{remote_path}/layers"
    script_parts = [f"mkdir -p {shlex.quote(layers_dir)}"]
    for name, url in repos:
        target = f"{layers_dir}/{name}"
        script_parts.append(
            f'if [ ! -d {shlex.quote(target)} ]; then '
            f'git clone -b {shlex.quote(branch)} {shlex.quote(url)} {shlex.quote(target)} || exit 1; '
            f'echo "cloned {name}"; '
            f'else echo "skip {name}"; fi'
        )
    script = " && ".join(script_parts)

    print(Colors.bold("Cloning repositories on remote..."))
    r = ssh_run(user, host, script, timeout=300)
    for line in r.stdout.strip().splitlines():
        line = line.strip()
        if line.startswith("cloned "):
            print(f"  {Colors.green('clone')} {line[7:]}")
        elif line.startswith("skip "):
            print(f"  {Colors.yellow('skip')} {line[5:]}")
    if r.returncode != 0:
        if r.stderr:
            log_message(r.stderr.strip().splitlines()[-1])
        return 1
    print(Colors.green("Clone complete!"))
    return 0


def _remote_clone_from_config(user: str, host: str, remote_path: str,
                              conf, selected_config) -> int:
    """Clone repos from a .conf.json config on the remote host."""
    sources = conf.sources
    layers_dir = f"{remote_path}/layers"

    print()
    print(Colors.bold(f"Configuration: {selected_config.name}"))
    if selected_config.description:
        print(f"  {selected_config.description}")
    print()

    # Build a single SSH script that clones all repos
    script_parts = [f"mkdir -p {shlex.quote(layers_dir)}"]
    for src in sources:
        if src.is_local:
            continue  # Skip local symlinks — they don't make sense on remote
        branch = src.branch or src.rev or "master"
        target = f"{layers_dir}/{src.path}"
        script_parts.append(
            f'if [ ! -d {shlex.quote(target)} ]; then '
            f'git clone -b {shlex.quote(branch)} {shlex.quote(src.git_url)} {shlex.quote(target)} || exit 1; '
            f'echo "cloned {src.name}"; '
            f'else echo "skip {src.name}"; fi'
        )
        # Add extra remotes
        if len(src.remotes) > 1:
            for remote_name, remote_uri in src.remotes.items():
                if remote_name == "origin":
                    continue
                script_parts.append(
                    f'git -C {shlex.quote(target)} remote add {shlex.quote(remote_name)} {shlex.quote(remote_uri)} 2>/dev/null'
                )

    script = " && ".join(script_parts)

    print(Colors.bold(f"Cloning {len(sources)} repos on remote..."))
    r = ssh_run(user, host, script, timeout=300)
    for line in r.stdout.strip().splitlines():
        line = line.strip()
        if line.startswith("cloned "):
            print(f"  {Colors.green('clone')} {line[7:]}")
        elif line.startswith("skip "):
            print(f"  {Colors.yellow('skip')} {line[5:]}")
    if r.returncode != 0:
        if r.stderr:
            log_message(r.stderr.strip().splitlines()[-1])
        return 1
    print(Colors.green("Clone complete!"))
    return 0


def _start_update_dialogs(project_path: str, dialog_state: ExploreMenuState,
                          project_info: Optional[dict] = None) -> None:
    """Start chained inline update dialogs for all repos in a project.

    Discovers git repos in the project directory and shows a per-repo
    update dialog (same pattern as explore's update_all flow).
    For remote projects, uses SSH to discover repos and run updates.
    """
    if project_info and is_remote_project(project_info):
        _start_remote_update_dialogs(project_path, dialog_state, project_info)
        return

    repos = _get_project_git_repos(project_path)
    if not repos:
        return

    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)
    update_idx = [0]  # mutable for closures

    def _show_next():
        """Show dialog for the next repo that needs updating."""
        while update_idx[0] < len(repos):
            repo = repos[update_idx[0]]
            branch = current_branch(repo)
            if not branch:
                update_idx[0] += 1
                continue
            default_action = defaults.get(repo, "rebase")
            display_name = repo_display_name(repo)

            dialog_state.show_dialog(
                update_repo_dialog(
                    repo_name=display_name,
                    branch=branch,
                    default_action=default_action,
                    index=update_idx[0] + 1,
                    total=len(repos),
                    on_confirm=_handle_selection,
                )
            )
            return
        # All repos processed

    def _handle_selection(selected):
        """Handle user's choice for one repo, then chain the next."""
        repo = repos[update_idx[0]]
        branch = current_branch(repo)
        default_action = defaults.get(repo, "rebase")
        display_name = repo_display_name(repo)

        if selected == "stop":
            return

        action = selected
        if action == "use_default":
            action = default_action

        if action == "skip":
            update_idx[0] += 1
            _show_next()
            return

        if action in ("rebase", "merge"):
            log_message(f"Updating {display_name}...")
            run_single_repo_update(repo, branch, action)
            # Invalidate cache so dashboard refreshes status
            _dashboard_summary_cache.pop(project_path, None)
            log_message(f"Updated {display_name}")

        update_idx[0] += 1
        _show_next()

    _show_next()


def _start_remote_update_dialogs(project_path: str, dialog_state: ExploreMenuState,
                                  project_info: dict) -> None:
    """Start chained update dialogs for a remote project via SSH."""
    user = project_info.get("user", "")
    host = project_info["host"]
    remote_path = project_info.get("remote_path", "")

    log_message(f"Discovering repos on {host}...")
    repos = ssh_get_git_repos(user, host, remote_path)
    if not repos:
        log_message("No git repos found on remote.")
        return

    update_idx = [0]

    def _show_next():
        while update_idx[0] < len(repos):
            repo = repos[update_idx[0]]
            branch = ssh_current_branch(user, host, repo)
            if not branch:
                update_idx[0] += 1
                continue
            display_name = os.path.basename(repo)

            dialog_state.show_dialog(
                update_repo_dialog(
                    repo_name=f"{display_name} ({host})",
                    branch=branch,
                    default_action="rebase",
                    index=update_idx[0] + 1,
                    total=len(repos),
                    on_confirm=_handle_selection,
                )
            )
            return

    def _handle_selection(selected):
        repo = repos[update_idx[0]]
        branch = ssh_current_branch(user, host, repo)
        display_name = os.path.basename(repo)

        if selected == "stop":
            return

        action = selected
        if action == "use_default":
            action = "rebase"

        if action == "skip":
            update_idx[0] += 1
            _show_next()
            return

        if action in ("rebase", "merge"):
            log_message(f"Updating {display_name} on {host}...")
            ok = ssh_run_single_repo_update(user, host, repo, branch, action)
            if ok:
                log_message(f"Updated {display_name} on {host}")
            else:
                log_message(f"Failed to update {display_name} on {host}")
            _dashboard_summary_cache.pop(project_path, None)

        update_idx[0] += 1
        _show_next()

    _show_next()


def _dashboard_handle_configure(action: str) -> None:
    """Handle a configure dialog action."""
    if action.startswith("CONF_"):
        action = action[5:]

    if action == "DASH_COLORS":
        _pick_dashboard_colors()
    elif action == "COLORS":
        from .config import fzf_global_settings
        fzf_global_settings()
    elif action == "BROWSER":
        _pick_directory_browser()
    elif action == "VIEWER":
        _pick_git_viewer()
    elif action == "PREVIEW":
        _pick_preview_layout()
    elif action == "RECIPE":
        _pick_recipe_use_bitbake_layers()


def _pick_dashboard_colors() -> None:
    """Pick colors for all terminal display elements."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding

    # Resolve which color file to write to
    color_mode = get_color_mode()
    if color_mode == "global":
        color_file = _get_global_colors_file()
    elif color_mode == "custom":
        color_file = ".bit.defaults"
    else:
        color_file = None

    while True:
        menu_lines = []
        for elem, (default_color, desc) in TERMINAL_COLOR_ELEMENTS.items():
            current = get_terminal_color(elem)
            is_default = (current == default_color)
            ansi_code = ANSI_COLORS.get(current, "\033[33m")
            sample = f"{ansi_code}\u25a0\u25a0\u25a0\033[0m"
            status = f"{current}" if not is_default else f"{current} (default)"
            menu_lines.append(f"{elem}\t{sample}  {desc:<45} {status}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--height", "~15",
                    "--header", "Display Colors (\u2190/q=back)",
                    "--prompt", "Element: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        elem = output.split("\t")[0] if "\t" in output else output
        if elem in TERMINAL_COLOR_ELEMENTS and color_file:
            _pick_single_color(elem, color_file)
        elif not color_file:
            print("Set color mode to 'global' or 'custom' first (Colors and themes → Color Mode)")


def _pick_single_color(element: str, color_file: str) -> None:
    """Pick a color for a single terminal element."""
    from ..fzf_bindings import get_exit_bindings

    default_color = TERMINAL_COLOR_ELEMENTS[element][0]
    current = get_terminal_color(element)
    desc = TERMINAL_COLOR_ELEMENTS[element][1]

    menu_lines = []
    default_marker = "\u25cf " if current == default_color else "  "
    default_ansi = ANSI_COLORS.get(default_color, "\033[33m")
    menu_lines.append(f"(default)\t{default_marker}{default_ansi}\u25a0\u25a0\u25a0\033[0m (default: {default_color})")

    for name, ansi in sorted(ANSI_COLORS.items()):
        if name == default_color:
            continue
        marker = "\u25cf " if name == current else "  "
        menu_lines.append(f"{name}\t{marker}{ansi}\u25a0\u25a0\u25a0\033[0m {name}")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--height", "~20",
                "--header", f"Pick color for: {desc} (\u2190/q=back)",
                "--prompt", "Color: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
            ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    output = result.stdout.strip()
    if output == "BACK":
        return

    selected = output.split("\t")[0] if "\t" in output else output
    if selected == "(default)":
        set_terminal_color(element, "(default)", color_file)
    elif selected in ANSI_COLORS:
        set_terminal_color(element, selected, color_file)


def run_dashboard(args) -> int:
    """Entry point for 'bit dashboard' command."""
    return fzf_dashboard()


def get_directory_browser() -> str:
    """Get configured directory browser preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__directory_browser__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_directory_browser(browser: str) -> None:
    """Set directory browser preference (auto, nnn, fzf)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__directory_browser__"] = browser
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_git_viewer() -> str:
    """Get configured git history viewer preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__git_viewer__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_git_viewer(viewer: str) -> None:
    """Set git history viewer preference."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__git_viewer__"] = viewer
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_editor() -> str:
    """Get configured editor preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__editor__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_editor(editor: str) -> None:
    """Set editor preference (auto, vim, nvim, nano, emacs, code)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__editor__"] = editor
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def resolve_editor() -> str:
    """Resolve the editor to use: bit setting > $EDITOR > $VISUAL > vi."""
    preference = get_editor()
    if preference != "auto":
        if shutil.which(preference):
            return preference
        # Configured editor not found, fall through to env vars
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vi"
    return editor


def get_graph_renderer() -> str:
    """Get configured graph renderer preference for dependency visualization."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__graph_renderer__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_graph_renderer(renderer: str) -> None:
    """Set graph renderer preference (auto, graph-easy, ascii)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__graph_renderer__"] = renderer
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_preferred_graph_renderer() -> str:
    """
    Get the preferred graph renderer that's actually available.

    Returns: 'graph-easy', 'ascii', or the configured preference.
    """
    preference = get_graph_renderer()

    if preference == "auto":
        # Prefer graph-easy if available
        if shutil.which("graph-easy"):
            return "graph-easy"
        return "ascii"
    elif preference == "graph-easy":
        if shutil.which("graph-easy"):
            return "graph-easy"
        return "ascii"  # Fall back if not available
    else:
        return preference


def get_preferred_git_viewer() -> Optional[str]:
    """
    Get the preferred git viewer that's actually available.

    Returns the command name (tig, lazygit, gitk) or None if none available.
    """
    preference = get_git_viewer()

    # Define viewer priority
    viewers = ["tig", "lazygit", "gitk"]

    if preference == "auto":
        # Return first available
        for viewer in viewers:
            if shutil.which(viewer):
                return viewer
        return None
    elif preference in viewers and shutil.which(preference):
        return preference
    else:
        # Configured viewer not available, fall back to auto
        for viewer in viewers:
            if shutil.which(viewer):
                return viewer
        return None


def _pick_git_viewer() -> None:
    """Pick git history viewer."""
    if not fzf_available():
        return

    current = get_git_viewer()

    options = [
        ("auto", "Auto-detect (tig > lazygit > gitk)"),
        ("tig", "tig - ncurses git interface"),
        ("lazygit", "lazygit - terminal UI for git"),
        ("gitk", "gitk - graphical git browser"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        available = ""
        if value in ("tig", "lazygit", "gitk") and not shutil.which(value):
            available = Colors.dim(" (not installed)")
        menu_lines.append(f"{value}\t{marker}{desc}{available}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select git history viewer (Enter=select, ←/q=back)",
        "--prompt", "Viewer: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("auto", "tig", "lazygit", "gitk"):
        set_git_viewer(selected)


def get_preview_layout() -> str:
    """Get configured preview pane layout preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__preview_layout__", "down")
        except (json.JSONDecodeError, OSError):
            pass
    return "down"


def set_preview_layout(layout: str) -> None:
    """Set preview pane layout preference."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__preview_layout__"] = layout
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_explore_load_size() -> int:
    """Get configured number of commits to load per page in explore."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return int(data.get("__explore_load_size__", 200))
        except (json.JSONDecodeError, OSError, ValueError):
            pass
    return 200


def set_explore_load_size(size: int) -> None:
    """Set number of commits to load per page in explore."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__explore_load_size__"] = size
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_preview_window_arg(size: str = "50%") -> str:
    """Get the fzf --preview-window argument based on configured layout."""
    layout = get_preview_layout()
    if layout == "right":
        return f"right:{size}:wrap"
    elif layout == "up":
        return f"up,{size},wrap"
    else:  # down (default)
        return f"down,{size},wrap"


def get_fzf_preview_args(
    preview_cmd: str,
    size: str = "50%",
    toggle_key: str = "?",
) -> list:
    """
    Get standard fzf arguments for preview pane.

    This provides a consistent preview experience across all commands, including:
    - Preview window with configured layout
    - Resize bindings (F3/F4 cross-platform, alt-left/right on Linux)
    - Color scheme
    - Toggle preview visibility
    - Preview scrolling (multiple key options for compatibility)

    Main list navigation:
    - pgup/pgdn: Page through the list (fzf default, not overridden)
    - up/down: Move one item at a time

    Preview scrolling:
    - alt-up/alt-down: Scroll preview by full pages
    - alt-u/alt-d: Scroll preview by half-pages (vim style)
    - shift-up/shift-down: Scroll preview by lines
    - alt-k/alt-j: Scroll preview by lines (vim-style alternative)

    Preview resize:
    - F3: Grow preview (cross-platform, Mac-friendly)
    - F4: Shrink preview (cross-platform, Mac-friendly)
    - alt-left: Grow preview (Linux)
    - alt-right: Shrink preview (Linux)

    Args:
        preview_cmd: The preview command to run
        size: Preview window size (default "50%")
        toggle_key: Key to toggle preview visibility (default "?")

    Returns:
        List of fzf arguments to extend your fzf_args with
    """
    preview_window = get_preview_window_arg(size)

    args = [
        "--preview", preview_cmd,
        "--preview-window", preview_window,
        "--bind", f"{toggle_key}:toggle-preview",
        # Preview scrolling - don't override pgup/pgdn so main list paging works
        "--bind", "shift-up:preview-up",
        "--bind", "shift-down:preview-down",
        "--bind", "alt-k:preview-up",
        "--bind", "alt-j:preview-down",
        "--bind", "alt-u:preview-half-page-up",
        "--bind", "alt-d:preview-half-page-down",
        "--bind", "alt-up:preview-page-up",
        "--bind", "alt-down:preview-page-down",
    ]

    # Add resize bindings and color scheme
    args.extend(get_fzf_preview_resize_bindings())
    args.extend(get_fzf_color_args())

    return args


def _pick_preview_layout() -> None:
    """Pick preview pane layout."""
    if not fzf_available():
        return

    current = get_preview_layout()

    options = [
        ("down", "Bottom - preview below commit list"),
        ("right", "Right - preview beside commit list (side-by-side)"),
        ("up", "Top - preview above commit list"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        menu_lines.append(f"{value}\t{marker}{desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select preview pane layout (Enter=select, ←/q=back)",
        "--prompt", "Layout: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("down", "right", "up"):
        set_preview_layout(selected)


def get_recipe_use_bitbake_layers() -> bool:
    """Get whether to use bitbake-layers for recipe scanning (default: True)."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                value = data.get("__recipe_use_bitbake_layers__", True)
                # Handle string values from config
                if isinstance(value, str):
                    return value.lower() not in ("false", "no", "0")
                return bool(value)
        except (json.JSONDecodeError, OSError):
            pass
    return True


def set_recipe_use_bitbake_layers(value: bool) -> None:
    """Set whether to use bitbake-layers for recipe scanning."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__recipe_use_bitbake_layers__"] = value
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _pick_recipe_use_bitbake_layers() -> None:
    """Pick whether to use bitbake-layers for recipe scanning."""
    if not fzf_available():
        return

    current = get_recipe_use_bitbake_layers()

    options = [
        (True, "bitbake-layers - Use bitbake-layers show-recipes (more accurate, slower)"),
        (False, "File scan - Scan .bb files directly (faster, no bitbake env needed)"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        key = "true" if value else "false"
        menu_lines.append(f"{key}\t{marker}{desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Recipe scan method (Enter=select, ←/q=back)",
        "--prompt", "Method: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected == "true":
        set_recipe_use_bitbake_layers(True)
    elif selected == "false":
        set_recipe_use_bitbake_layers(False)


def _pick_directory_browser() -> None:
    """Show settings menu for directory browser preferences."""
    if not fzf_available():
        return

    while True:
        current_browser = get_directory_browser()
        current_colors = get_nnn_colors()

        # Color descriptions
        color_names = {
            "0": "black", "1": "red", "2": "green", "3": "yellow",
            "4": "blue", "5": "magenta", "6": "cyan", "7": "white"
        }
        color_desc = f"dirs={color_names.get(current_colors[0:1], '?')}" if current_colors else "default"

        menu_lines = [
            f"BROWSER\tBrowser: {current_browser}",
            f"NNN_COLORS\tnnn colors: {color_desc} ({current_colors})",
        ]

        menu_input = "\n".join(menu_lines)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~20%",
            "--layout", "reverse",
            "--header", "Projects settings (Enter=edit, ←/q=back)",
            "--prompt", "Setting: ",
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        fzf_args.extend(get_exit_bindings(mode="abort"))
        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        selected = result.stdout.strip().split("\t")[0]

        if selected == "BROWSER":
            _pick_browser_option()
        elif selected == "NNN_COLORS":
            _pick_nnn_colors()


def _pick_browser_option() -> None:
    """Pick directory browser."""
    current = get_directory_browser()

    options = [
        ("auto", "Auto-detect (broot > ranger > nnn > fzf)"),
        ("broot", "broot - fuzzy search, type paths directly"),
        ("ranger", "ranger - vim-like file manager"),
        ("nnn", "nnn - fast, minimal file manager"),
        ("fzf", "fzf built-in browser"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        available = ""
        if value in ("broot", "ranger", "nnn") and not shutil.which(value):
            available = Colors.dim(" (not installed)")
        menu_lines.append(f"{value}\t{marker}{desc}{available}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select directory browser (Enter=select, ←/q=back)",
        "--prompt", "Browser: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("auto", "fzf", "nnn", "broot", "ranger"):
        set_directory_browser(selected)


def _pick_nnn_colors() -> None:
    """Pick nnn color scheme."""
    # NNN_COLORS format: up to 8 chars, each is a color 0-7
    # We'll focus on the directory color (3rd char) which is usually the issue
    current = get_nnn_colors()

    presets = [
        ("6234", "cyan dirs (default)"),
        ("2234", "green dirs"),
        ("3234", "yellow dirs"),
        ("7234", "white dirs"),
        ("5234", "magenta dirs"),
        ("1234", "red dirs"),
        ("4234", "blue dirs (nnn default)"),
    ]

    menu_lines = []
    for value, desc in presets:
        marker = "● " if value == current else "  "
        # Show color sample
        color_code = {"1": "31", "2": "32", "3": "33", "4": "34", "5": "35", "6": "36", "7": "37"}.get(value[0], "0")
        sample = f"\033[{color_code}m■■■\033[0m"
        menu_lines.append(f"{value}\t{marker}{sample} {desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~25%",
        "--layout", "reverse",
        "--header", "Select nnn directory color (Enter=select, ←/q=back)",
        "--prompt", "Color: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected:
        set_nnn_colors(selected)


def browse_for_directory() -> Optional[str]:
    """
    Browse filesystem to select a directory.

    Uses configured browser preference, or auto-detects.
    Priority: broot > ranger > nnn > fzf
    """
    browser = get_directory_browser()

    if browser == "auto":
        # Auto-detect best available
        if shutil.which("broot"):
            return _browse_with_broot()
        elif shutil.which("ranger"):
            return _browse_with_ranger()
        elif shutil.which("nnn"):
            return _browse_with_nnn()
    elif browser == "broot" and shutil.which("broot"):
        return _browse_with_broot()
    elif browser == "ranger" and shutil.which("ranger"):
        return _browse_with_ranger()
    elif browser == "nnn" and shutil.which("nnn"):
        return _browse_with_nnn()

    # Fall back to fzf
    if fzf_available():
        return _browse_with_fzf_walker()

    return None


def _browse_with_broot() -> Optional[str]:
    """Browse for directory using broot."""
    import tempfile

    start_dir = os.path.expanduser("~")

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.broot') as f:
        out_file = f.name

    try:
        print()
        print(f"{Colors.bold('broot directory browser')}")
        print(f"  Type to fuzzy search     /path : jump to absolute path")
        print(f"  Enter    : enter dir     Alt+Enter : {Colors.cyan('SELECT and quit')}")
        print(f"  Esc/q    : cancel        ?     : help")
        print()
        input("Press Enter to open broot...")

        # --only-folders: show only directories
        # --cmd: initial command (none)
        # We use :print_path verb bound to alt-enter
        result = subprocess.run(
            ["broot", "--only-folders", "--print-path", "-o", out_file, start_dir],
        )

        if os.path.isfile(out_file):
            with open(out_file, "r") as f:
                selected = f.read().strip()
            if selected:
                # broot might output a file, get its directory
                if os.path.isfile(selected):
                    return os.path.dirname(selected)
                elif os.path.isdir(selected):
                    return selected

        return None
    finally:
        try:
            os.unlink(out_file)
        except OSError:
            pass


def _browse_with_ranger() -> Optional[str]:
    """Browse for directory using ranger with fzf integration."""
    import tempfile

    start_dir = os.path.expanduser("~")

    # Create temp directory for our ranger config
    temp_dir = tempfile.mkdtemp(prefix='ranger_bbp_')
    choosedir_file = os.path.join(temp_dir, 'choosedir')
    commands_file = os.path.join(temp_dir, 'commands.py')
    rc_file = os.path.join(temp_dir, 'rc.conf')

    try:
        # Write custom commands.py with fzf_select
        commands_content = '''
import subprocess
import os.path
from ranger.api.commands import Command

class fzf_select(Command):
    """Find a file or directory using fzf and jump to it."""
    def execute(self):
        # Use fd if available, otherwise find
        if subprocess.run(["which", "fd"], capture_output=True).returncode == 0:
            command = "fd --type d --hidden --exclude .git 2>/dev/null | fzf +m"
        else:
            command = "find . -type d -not -path '*/.*' 2>/dev/null | fzf +m"
        fzf = self.fm.execute_command(command, stdout=subprocess.PIPE)
        stdout, stderr = fzf.communicate()
        if fzf.returncode == 0:
            fzf_file = os.path.abspath(stdout.decode('utf-8').strip())
            if os.path.isdir(fzf_file):
                self.fm.cd(fzf_file)
            else:
                self.fm.select_file(fzf_file)

class fzf_cd(Command):
    """fzf to any directory from root."""
    def execute(self):
        start = self.arg(1) or os.path.expanduser("~")
        if subprocess.run(["which", "fd"], capture_output=True).returncode == 0:
            command = f"fd --type d --hidden --exclude .git . {start} 2>/dev/null | fzf +m"
        else:
            command = f"find {start} -type d -not -path '*/.*' 2>/dev/null | fzf +m"
        fzf = self.fm.execute_command(command, stdout=subprocess.PIPE)
        stdout, stderr = fzf.communicate()
        if fzf.returncode == 0:
            fzf_file = os.path.abspath(stdout.decode('utf-8').strip())
            if os.path.isdir(fzf_file):
                self.fm.cd(fzf_file)
'''
        with open(commands_file, 'w') as f:
            f.write(commands_content)

        # Write rc.conf with our mappings
        # Source user's rc.conf first if it exists
        user_rc = os.path.expanduser("~/.config/ranger/rc.conf")
        rc_content = f'''
# Source user config if exists
{"source " + user_rc if os.path.isfile(user_rc) else "# no user rc.conf"}

# bit mappings
map <C-f> fzf_select
map <C-g> fzf_cd ~
map g console cd%space
'''
        with open(rc_file, 'w') as f:
            f.write(rc_content)

        print()
        print(f"{Colors.bold('ranger directory browser')} (with fzf)")
        print(f"  {Colors.bold('Ctrl+f')}    : fzf search from current dir")
        print(f"  {Colors.bold('Ctrl+g')}    : fzf search from home")
        print(f"  {Colors.bold('g')}         : type path directly (tab completes)")
        print(f"  :cd /path : jump to path")
        print(f"  q         : {Colors.cyan('SELECT current dir and quit')}")
        print()
        input("Press Enter to open ranger...")

        env = os.environ.copy()
        env['RANGER_LOAD_DEFAULT_RC'] = 'FALSE'

        result = subprocess.run(
            ["ranger",
             f"--choosedir={choosedir_file}",
             f"--cmd=source {rc_file}",
             f"--cmd=source {commands_file}",
             start_dir],
            env=env,
        )

        if os.path.isfile(choosedir_file):
            with open(choosedir_file, "r") as f:
                selected = f.read().strip()
            if selected and os.path.isdir(selected):
                return selected

        return None
    finally:
        # Cleanup temp files
        try:
            os.unlink(choosedir_file)
        except OSError:
            pass
        try:
            os.unlink(commands_file)
        except OSError:
            pass
        try:
            os.unlink(rc_file)
        except OSError:
            pass
        try:
            os.rmdir(temp_dir)
        except OSError:
            pass


def get_nnn_colors() -> str:
    """Get configured nnn color scheme."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__nnn_colors__", "6234")
        except (json.JSONDecodeError, OSError):
            pass
    # Default: cyan dirs (6), green sel (2), yellow ctx (3), blue files (4)
    return "6234"


def set_nnn_colors(colors: str) -> None:
    """Set nnn color scheme."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__nnn_colors__"] = colors
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _browse_with_nnn() -> Optional[str]:
    """Browse for directory using nnn file manager."""
    import tempfile

    start_dir = os.path.expanduser("~")

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.nnn') as f:
        picker_file = f.name

    try:
        env = os.environ.copy()
        # Set colors - default avoids hard-to-read blue for directories
        # Format: 4 chars for contexts (cursor line, selection, dir, file)
        # 1=red, 2=green, 3=yellow, 4=blue, 5=magenta, 6=cyan, 7=white
        env["NNN_COLORS"] = get_nnn_colors()

        print()
        print(f"{Colors.bold('nnn directory browser')} (type-to-nav enabled)")
        print(f"  hjkl/arrows : navigate        {Colors.bold('/')} : filter current dir")
        print(f"  Enter/l     : enter dir       {Colors.bold('~')} : jump to home")
        print(f"  Backspace/h : go up           Just type: jump to path (e.g. /opt)")
        print(f"  {Colors.bold('p')}           : {Colors.cyan('SELECT and quit')}")
        print(f"  q           : cancel          {Colors.bold('?')} : full help")
        print()
        input("Press Enter to open nnn...")

        result = subprocess.run(
            ["nnn", "-n", "-p", picker_file, start_dir],
            env=env,
        )

        # Read selected path (written when user presses 'p')
        if os.path.isfile(picker_file):
            with open(picker_file, "r") as f:
                selected = f.read().strip()
            if selected and os.path.isdir(selected):
                return selected
            elif selected and os.path.isfile(selected):
                # If a file was selected, use its directory
                return os.path.dirname(selected)

        return None
    finally:
        try:
            os.unlink(picker_file)
        except OSError:
            pass


def _browse_with_fzf_walker() -> Optional[str]:
    """Browse for directory using fzf with manual directory navigation."""
    start_dir = os.path.expanduser("~")
    current_dir = start_dir

    while True:
        # List directories in current location
        try:
            entries = sorted(os.listdir(current_dir))
        except OSError:
            entries = []

        dirs = [d for d in entries if os.path.isdir(os.path.join(current_dir, d)) and not d.startswith(".")]

        menu_lines = []
        menu_lines.append(f".\t{Colors.green('● Select this directory')}: {current_dir}")
        if current_dir != "/":
            menu_lines.append(f"..\t{Colors.cyan('↑ Go up to')}: {os.path.dirname(current_dir)}")

        for d in dirs:
            full_path = os.path.join(current_dir, d)
            # Check for indicators this might be a Yocto project
            has_layers = os.path.isdir(os.path.join(full_path, "layers"))
            has_build = os.path.isdir(os.path.join(full_path, "build"))
            has_poky = os.path.isdir(os.path.join(full_path, "poky"))
            has_bblayers = any(
                os.path.isfile(os.path.join(full_path, sub, "conf", "bblayers.conf"))
                for sub in ["", "build"]
            )

            indicator = ""
            if has_layers or has_build or has_poky or has_bblayers:
                indicator = Colors.green(" [yocto?]")

            menu_lines.append(f"{d}\t  {d}/{indicator}")

        menu_input = "\n".join(menu_lines)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~60%",
            "--layout", "reverse",
            "--header", f"Browse: {current_dir}\nEnter=enter dir, Tab=select, ←/q=cancel",
            "--prompt", "Dir: ",
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--expect", "tab",
        ]

        fzf_args.extend(get_exit_bindings(mode="abort"))
        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return None

        if result.returncode != 0 or not result.stdout.strip():
            return None

        # Split BEFORE stripping to preserve empty key line
        lines = result.stdout.split("\n")
        key = lines[0] if lines else ""
        selected = lines[1].split("\t")[0] if len(lines) > 1 else ""

        # Tab means select current highlighted item as the project
        if key == "tab" and selected and selected not in (".", ".."):
            return os.path.join(current_dir, selected)

        if selected == ".":
            return current_dir
        elif selected == "..":
            current_dir = os.path.dirname(current_dir)
        elif selected:
            new_dir = os.path.join(current_dir, selected)
            if os.path.isdir(new_dir):
                current_dir = new_dir


def run_projects(args, from_auto_prompt: bool = False) -> int:
    """
    Main entry point for projects command.

    Args:
        args: Parsed command line arguments
        from_auto_prompt: True if invoked automatically because no project context was found.
                          In this case, after selecting a project with Enter, show command menu.

    Returns:
        0 for success, 1 for error, 2 to signal "chain to command menu"
    """
    subcommand = getattr(args, "projects_command", None)

    if subcommand == "add":
        path = getattr(args, "path", None) or os.getcwd()
        name = getattr(args, "name", None)
        desc = getattr(args, "description", "") or ""
        if add_project(path, name, desc):
            return 0
        return 1

    elif subcommand == "remove":
        path = getattr(args, "path", None)
        if not path:
            # Interactive selection
            selected = fzf_project_picker(include_browse=False)
            if not selected:
                return 1
            path = selected
        if remove_project(path):
            return 0
        return 1

    elif subcommand == "shell":
        # Alias for 'init shell' - change to current project first
        current_project = get_current_project()
        if current_project and os.path.isdir(current_project):
            os.chdir(current_project)
        from .setup import run_init_shell
        return run_init_shell(args)

    elif subcommand == "sync":
        sync_direction = getattr(args, "sync_direction", None)
        if sync_direction == "from":
            added = sync_from_remote(args.host)
            if added:
                print(f"{Colors.green('✓')} Synced {added} project(s) from {args.host}")
            else:
                print(f"No new projects found on {args.host}")
            return 0
        elif sync_direction == "to":
            print("Push sync not yet implemented.")
            return 1
        else:
            # No direction given — print help
            # Re-parse to get the sync subparser for help
            print("Usage: bit projects sync {from,to} <host>")
            print("\nSync project lists between local and remote bit instances.")
            print("Additive only — never removes existing entries.")
            print("\nDirections:")
            print("  from  Pull remote's projects into local list")
            print("  to    Push local projects to remote's list (future)")
            return 0

    elif subcommand == "list":
        projects = load_projects()
        current = get_current_project()

        if not projects:
            print("No projects registered.")
            print("Use 'bit projects add' to add one.")
            return 0

        print(f"\n{Colors.bold('Registered projects:')}\n")
        for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
            name = info.get("name", os.path.basename(path))
            desc = info.get("description", "")
            is_remote = is_remote_project(info)
            if is_remote:
                user = info.get("user", "")
                host = info.get("host", "")
                remote_path = info.get("remote_path", "")
                if user and host and remote_path:
                    exists = ssh_path_exists(user, host, remote_path)
                else:
                    exists = False
            else:
                exists = os.path.isdir(path)
            is_current = (path == current)

            if is_current:
                status = terminal_color("project_active", "●")
                label = f" {terminal_color('project_active', '(ACTIVE)')}"
            elif exists:
                status = terminal_color("project_name", "○")
                label = ""
            else:
                status = terminal_color("project_missing", "!")
                label = ""

            print(f"  {status} {terminal_color('project_active' if is_current else 'project_name', name)}{label}")
            print(f"    {path}")
            if desc:
                print(f"    {Colors.dim(desc)}")
            if not exists:
                print(f"    {Colors.red('(directory not found)')}")
            print()
        return 0

    else:
        # Default: launch dashboard
        return fzf_dashboard()
