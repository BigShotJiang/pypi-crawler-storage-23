#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Shared utilities for bit commands.

This module contains all run_* functions and their supporting utilities.
"""

import json
import os
import re
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Iterable, List, Optional, Set, Tuple

from ..core import (
    Colors,
    GitRepo,
    FzfMenu,
    fzf_available,
    fzf_expandable_menu,
    get_custom_command,
    get_fzf_color_args,
    is_custom_default,
    parse_help_options,
    git_toplevel,
    current_branch,
    current_head,
    repo_is_clean,
    load_defaults,
    save_defaults,
    load_prep_state,
    save_prep_state,
    load_export_state,
    save_export_state,
    terminal_color,
    get_terminal_color,
    ANSI_COLORS,
)
from ..tui import ExploreMenuState, text_input_dialog
from ..fzf_bindings import get_action_binding, get_exit_bindings, get_preview_header_suffix, get_toggle_binding


# ---------------------------------------------------------------------------
# Session message store
# ---------------------------------------------------------------------------
# Captures status messages (e.g. "✓ Activated: poky") so they can be shown
# in the fzf header for one redraw cycle and reviewed later via M key.

_messages: List[Tuple[float, str]] = []   # (timestamp, text)
_pending_message: str = ""                # consumed once per header render


def log_message(text: str):
    """Store *text* for header display and later review."""
    global _pending_message
    _messages.append((time.time(), text))
    _pending_message = text


def consume_header_message() -> str:
    """Return pending message (once), then clear it."""
    global _pending_message
    msg = _pending_message
    _pending_message = ""
    return msg


def get_messages() -> List[Tuple[float, str]]:
    """Return all stored messages."""
    return list(_messages)


def clear_messages():
    """Clear message history."""
    global _pending_message
    _messages.clear()
    _pending_message = ""


def fzf_message_viewer():
    """Show message log in a read-only fzf browser."""
    messages = get_messages()
    if not messages:
        subprocess.run(
            ["fzf", "--ansi", "--no-sort", "--layout=reverse",
             "--height=~30%", "--border=rounded",
             "--header", "No messages yet | q=close",
             "--disabled",
             *get_exit_bindings(mode="abort")],
            input="", text=True,
        )
        return
    lines = []
    for ts, text in messages:
        t = time.strftime("%H:%M:%S", time.localtime(ts))
        clean = text.replace("\n", " ").strip()
        lines.append(f"{Colors.dim(t)}  {clean}")
    lines.reverse()  # newest first
    subprocess.run(
        ["fzf", "--ansi", "--no-sort", "--layout=reverse",
         "--height=~50%", "--border=rounded",
         "--header", "Messages (newest first) | q=close",
         "--disabled",
         *get_exit_bindings(mode="abort")],
        input="\n".join(lines), text=True,
    )

def resolve_bblayers_path(path_opt: Optional[str]) -> str:
    if path_opt:
        return path_opt
    candidates = ["conf/bblayers.conf", "build/conf/bblayers.conf"]
    for cand in candidates:
        if os.path.exists(cand):
            return cand
    sys.exit("bblayers.conf not found (tried conf/bblayers.conf and build/conf/bblayers.conf). Use --bblayers to specify.")


class BblayersParser:
    """
    Parse bblayers.conf with proper BitBake syntax support.

    Handles:
    - Line continuations (backslash)
    - Assignment operators: =, ?=, ??=, :=, ::=
    - Append/prepend: +=, .=, =+, =., :append, :prepend
    - Remove: :remove
    - Variable expansion: ${VAR}
    - Include/require statements
    - Comments (# lines)
    """

    def __init__(self, conf_path: str):
        self.conf_path = os.path.abspath(conf_path)
        self.conf_dir = os.path.dirname(self.conf_path)
        # Build dir is typically parent of conf/
        self.build_dir = os.path.dirname(self.conf_dir)

        # Variable storage
        self.variables: Dict[str, str] = {}
        self.bblayers: List[str] = []
        self.bblayers_remove: Set[str] = set()

        # Initialize common variables
        self._init_common_variables()

    def _init_common_variables(self) -> None:
        """Initialize commonly used variables that we can infer."""
        # TOPDIR is the build directory (where conf/ lives)
        self.variables['TOPDIR'] = self.build_dir

        # Try to find OEROOT/COREBASE by looking for oe-init-build-env
        # Usually it's a sibling or parent directory
        for search_dir in [
            os.path.dirname(self.build_dir),  # Parent of build
            self.build_dir,
        ]:
            if os.path.isfile(os.path.join(search_dir, 'oe-init-build-env')):
                self.variables['OEROOT'] = search_dir
                self.variables['COREBASE'] = search_dir
                break

        # BSPDIR is often the project root (parent of build dir)
        self.variables['BSPDIR'] = os.path.dirname(self.build_dir)

        # Environment variables can also be referenced
        for env_var in ['HOME', 'PWD', 'USER']:
            if env_var in os.environ:
                self.variables[env_var] = os.environ[env_var]

    def _expand_variables(self, value: str) -> str:
        """Expand ${VAR} references in a string."""
        if '${' not in value:
            return value

        # Iteratively expand variables (handles nested refs)
        max_iterations = 10
        for _ in range(max_iterations):
            original = value
            for var_name, var_value in self.variables.items():
                value = value.replace(f'${{{var_name}}}', var_value)
            if value == original:
                break

        return value

    def _join_continued_lines(self, content: str) -> List[str]:
        """Join lines that end with backslash continuation."""
        lines = content.splitlines()
        result = []
        current_line = ""

        for line in lines:
            # Strip trailing whitespace but preserve leading
            line_stripped = line.rstrip()

            if line_stripped.endswith('\\'):
                # Continuation - append without the backslash
                current_line += line_stripped[:-1]
            else:
                current_line += line_stripped
                result.append(current_line)
                current_line = ""

        # Don't forget last line if file doesn't end with newline
        if current_line:
            result.append(current_line)

        return result

    def _extract_quoted_value(self, value_part: str) -> str:
        """Extract value from quoted string (handles both " and ')."""
        value_part = value_part.strip()

        # Try double quotes first
        match = re.match(r'^"(.*)"', value_part, re.DOTALL)
        if match:
            return match.group(1)

        # Try single quotes
        match = re.match(r"^'(.*)'", value_part, re.DOTALL)
        if match:
            return match.group(1)

        # Unquoted value (take until comment or end)
        match = re.match(r'^([^#\s]+)', value_part)
        if match:
            return match.group(1)

        return value_part

    def _parse_assignment(self, line: str) -> Optional[Tuple[str, str, str]]:
        """
        Parse a variable assignment line.

        Returns: (var_name, operator, value) or None if not an assignment.
        Operator includes any suffix like :append, :remove, etc.
        """
        # Skip comments and empty lines
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            return None

        # Match variable assignment patterns
        # Handles: VAR =, VAR ?=, VAR ??=, VAR +=, VAR .=, VAR :=, VAR ::=
        # Also: VAR:append =, VAR:prepend =, VAR:remove =
        pattern = r'^([A-Za-z_][A-Za-z0-9_]*)((?::[a-z]+)?)\s*(\?\?=|\?=|:=|::=|\+=|\.=|=\+|=\.|=)\s*(.*)$'
        match = re.match(pattern, stripped)

        if not match:
            return None

        var_name = match.group(1)
        var_suffix = match.group(2)  # :append, :remove, etc.
        operator = match.group(3)
        value_part = match.group(4)

        # Extract the actual value (may be quoted)
        value = self._extract_quoted_value(value_part)

        # Combine suffix into operator for easier handling
        full_operator = var_suffix + operator if var_suffix else operator

        return (var_name, full_operator, value)

    def _apply_assignment(self, var_name: str, operator: str, value: str) -> None:
        """Apply a variable assignment based on the operator."""
        # Expand variables in the value
        expanded_value = self._expand_variables(value)

        if var_name == 'BBLAYERS':
            self._apply_bblayers_assignment(operator, expanded_value)
        else:
            # Track other variables for potential expansion
            self._apply_variable_assignment(var_name, operator, expanded_value)

    def _apply_variable_assignment(self, var_name: str, operator: str, value: str) -> None:
        """Apply assignment to a regular variable."""
        if operator in ('=', ':=', '::='):
            # Direct assignment
            self.variables[var_name] = value
        elif operator == '?=':
            # Default assignment (only if not set)
            if var_name not in self.variables:
                self.variables[var_name] = value
        elif operator == '??=':
            # Weak default (we treat same as ?= for simplicity)
            if var_name not in self.variables:
                self.variables[var_name] = value
        elif operator in ('+=', ':append='):
            # Append with space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = current + ' ' + value if current else value
        elif operator in ('.=', ):
            # Append without space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = current + value
        elif operator in ('=+', ':prepend='):
            # Prepend with space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = value + ' ' + current if current else value
        elif operator == '=.':
            # Prepend without space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = value + current

    def _apply_bblayers_assignment(self, operator: str, value: str) -> None:
        """Apply assignment specifically to BBLAYERS."""
        # Extract paths from the value
        paths = self._extract_paths_from_value(value)

        if operator == ':remove=':
            # Add to remove set
            for path in paths:
                self.bblayers_remove.add(path)
        elif operator in ('=', ':=', '::='):
            # Direct assignment - replace
            self.bblayers = paths
        elif operator == '?=':
            # Default - only if empty
            if not self.bblayers:
                self.bblayers = paths
        elif operator == '??=':
            # Weak default
            if not self.bblayers:
                self.bblayers = paths
        elif operator in ('+=', ':append='):
            # Append
            self.bblayers.extend(paths)
        elif operator in ('.=',):
            # Append (same effect for lists)
            self.bblayers.extend(paths)
        elif operator in ('=+', ':prepend='):
            # Prepend
            self.bblayers = paths + self.bblayers
        elif operator == '=.':
            # Prepend
            self.bblayers = paths + self.bblayers

    def _extract_paths_from_value(self, value: str) -> List[str]:
        """Extract layer paths from a BBLAYERS value string."""
        paths = []
        for token in value.split():
            # Skip empty tokens
            if not token:
                continue
            # Skip obvious non-paths
            if '/' not in token and not token.startswith('$'):
                continue
            # Expand any remaining variables
            expanded = self._expand_variables(token)
            # Skip if still has unexpanded variables
            if '${' in expanded:
                # Try to warn but still include partial path
                # This helps with debugging
                pass
            if expanded and '/' in expanded:
                # Normalize the path
                if os.path.isabs(expanded):
                    paths.append(os.path.normpath(expanded))
                else:
                    # Relative to build dir
                    paths.append(os.path.normpath(os.path.join(self.build_dir, expanded)))
        return paths

    def _process_include(self, line: str) -> None:
        """Process include or require statement."""
        stripped = line.strip()

        match = re.match(r'^(include|require)\s+(.+)$', stripped)
        if not match:
            return

        directive = match.group(1)
        include_path = match.group(2).strip()

        # Expand variables in include path
        include_path = self._expand_variables(include_path)

        # Still has unexpanded variables - skip
        if '${' in include_path:
            return

        # Resolve relative paths
        if not os.path.isabs(include_path):
            include_path = os.path.join(self.conf_dir, include_path)

        # For 'include', file is optional; for 'require', it must exist
        if os.path.isfile(include_path):
            self._parse_file(include_path)
        elif directive == 'require':
            # Required file missing - in real bitbake this is an error
            # We just skip it silently
            pass

    def _parse_file(self, file_path: str) -> None:
        """Parse a single conf file."""
        if not os.path.isfile(file_path):
            return

        try:
            with open(file_path, encoding='utf-8') as f:
                content = f.read()
        except (IOError, OSError):
            return

        # Join continued lines
        lines = self._join_continued_lines(content)

        for line in lines:
            stripped = line.strip()

            # Skip empty and comment lines
            if not stripped or stripped.startswith('#'):
                continue

            # Check for include/require
            if stripped.startswith('include ') or stripped.startswith('require '):
                self._process_include(line)
                continue

            # Try to parse as assignment
            assignment = self._parse_assignment(line)
            if assignment:
                var_name, operator, value = assignment
                self._apply_assignment(var_name, operator, value)

    def parse(self) -> List[str]:
        """Parse bblayers.conf and return list of layer paths."""
        if not os.path.exists(self.conf_path):
            return []

        self._parse_file(self.conf_path)

        # Apply removes
        final_layers = []
        seen = set()
        for layer in self.bblayers:
            # Normalize for comparison
            normalized = os.path.realpath(layer) if os.path.exists(layer) else layer
            if normalized in self.bblayers_remove:
                continue
            if normalized in seen:
                continue
            seen.add(normalized)
            final_layers.append(layer)

        return final_layers


def extract_layer_paths(conf_path: str) -> List[str]:
    """
    Extract layer paths from bblayers.conf.

    Uses BblayersParser for robust parsing with support for:
    - Variable expansion (${TOPDIR}, etc.)
    - Append/prepend operators (+=, :append, etc.)
    - Remove operator (:remove)
    - Include/require statements
    """
    if not os.path.exists(conf_path):
        sys.exit(f"bblayers.conf not found: {conf_path}")

    parser = BblayersParser(conf_path)
    return parser.parse()


def dedupe_preserve_order(items: Iterable[str]) -> List[str]:
    seen: Set[str] = set()
    out: List[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        out.append(item)
    return out


def discover_layers(
    base_dir: str = ".",
    max_depth: int = 3,
    exclude_layers: Optional[Set[str]] = None,
    peer_dirs: Optional[Set[str]] = None,
) -> List[Tuple[str, str]]:
    """
    Discover layers by finding conf/layer.conf files.

    Args:
        base_dir: Directory to start searching from
        max_depth: Maximum directory depth to search (default 3)
        exclude_layers: Set of layer paths to skip (e.g., already in bblayers.conf)
        peer_dirs: Additional directories to search (e.g., parent dirs of known repos)

    Returns:
        List of (layer_path, repo_path) tuples
    """
    exclude_layers = exclude_layers or set()
    peer_dirs = peer_dirs or set()
    results = []
    seen_layers: Set[str] = set()

    # Directories to skip (won't contain layers)
    skip_dirs = {
        '.git', 'build', 'builds', 'tmp', 'tmp-glibc', 'tmp-musl',
        'downloads', 'sstate-cache', 'cache', 'node_modules',
        '__pycache__', '.tox', '.venv', 'venv',
    }

    def search_from(start_dir: str) -> None:
        """Search for layers starting from a directory."""
        base = os.path.abspath(start_dir)
        if not os.path.isdir(base):
            return

        for root, dirs, _files in os.walk(base):
            # Calculate depth from base
            rel_path = root[len(base):]
            if rel_path:
                depth = rel_path.count(os.sep)
            else:
                depth = 0

            if depth >= max_depth:
                dirs[:] = []  # Don't descend further
            else:
                # Prune directories that won't contain layers
                dirs[:] = [d for d in dirs if d not in skip_dirs]

            # Check for layer.conf (standard BitBake layer structure)
            layer_conf = os.path.join(root, "conf", "layer.conf")
            if os.path.isfile(layer_conf):
                # Use realpath to resolve symlinks and match bblayers.conf paths
                layer_path = os.path.realpath(root)
                if layer_path in exclude_layers or layer_path in seen_layers:
                    continue
                repo_path = git_toplevel(layer_path)
                if repo_path:
                    results.append((layer_path, repo_path))
                    seen_layers.add(layer_path)

    # Search from base directory
    search_from(base_dir)

    # Also search from peer directories
    for peer_dir in peer_dirs:
        search_from(peer_dir)

    return results


def discover_git_repos(
    base_dir: str = ".",
    max_depth: int = 3,
    exclude_repos: Optional[Set[str]] = None,
    peer_dirs: Optional[Set[str]] = None,
) -> List[str]:
    """
    Discover git repositories that are NOT layers (no conf/layer.conf).

    Args:
        base_dir: Directory to start searching from
        max_depth: Maximum directory depth to search (default 3)
        exclude_repos: Set of repo paths to skip (e.g., already known repos)
        peer_dirs: Additional directories to check for repos (e.g., parents of known repos)

    Returns:
        List of repo paths (git toplevels)
    """
    exclude_repos = exclude_repos or set()
    peer_dirs = peer_dirs or set()
    results: Set[str] = set()

    # Directories to skip
    skip_dirs = {
        '.git', 'build', 'builds', 'tmp', 'tmp-glibc', 'tmp-musl',
        'downloads', 'sstate-cache', 'cache', 'node_modules',
        '__pycache__', '.tox', '.venv', 'venv',
    }

    def is_non_layer_repo(path: str) -> Optional[str]:
        """Check if path is a git repo without conf/layer.conf. Returns repo path or None."""
        git_dir = os.path.join(path, ".git")
        if os.path.exists(git_dir):
            repo_path = git_toplevel(path)
            if repo_path and repo_path not in exclude_repos:
                # Check it's NOT a layer
                layer_conf = os.path.join(repo_path, "conf", "layer.conf")
                if not os.path.isfile(layer_conf):
                    return repo_path
        return None

    # First, check peer directories (one level deep)
    for peer_dir in peer_dirs:
        if not os.path.isdir(peer_dir):
            continue
        # Check the peer dir itself
        repo = is_non_layer_repo(peer_dir)
        if repo:
            results.add(repo)
        # Check immediate children
        try:
            for entry in os.listdir(peer_dir):
                if entry in skip_dirs:
                    continue
                child = os.path.join(peer_dir, entry)
                if os.path.isdir(child):
                    repo = is_non_layer_repo(child)
                    if repo:
                        results.add(repo)
        except PermissionError:
            pass

    # Then do the normal walk from base_dir
    base = os.path.abspath(base_dir)
    for root, dirs, _files in os.walk(base):
        # Calculate depth from base
        rel_path = root[len(base):]
        if rel_path:
            depth = rel_path.count(os.sep)
        else:
            depth = 0

        if depth >= max_depth:
            dirs[:] = []  # Don't descend further
        else:
            # Prune directories that won't contain repos
            dirs[:] = [d for d in dirs if d not in skip_dirs]

        # Check if this is a git repo
        repo = is_non_layer_repo(root)
        if repo:
            results.add(repo)
            # Don't descend into git repos
            dirs[:] = []
        elif os.path.exists(os.path.join(root, ".git")):
            # It's a git repo but excluded or is a layer - still don't descend
            dirs[:] = []

    return list(results)


def build_layer_collection_map(layer_paths: List[str]) -> Dict[str, str]:
    """
    Build a map from layer collection names to layer paths.

    Parses BBFILE_COLLECTIONS from each layer's conf/layer.conf.

    Args:
        layer_paths: List of layer directory paths

    Returns:
        Dict mapping collection name to layer path
    """
    collection_map: Dict[str, str] = {}

    for layer_path in layer_paths:
        layer_conf = os.path.join(layer_path, "conf", "layer.conf")
        if not os.path.isfile(layer_conf):
            continue

        try:
            with open(layer_conf, 'r') as f:
                content = f.read()
            # Parse BBFILE_COLLECTIONS += "name" or BBFILE_COLLECTIONS = "name"
            for match in re.finditer(r'BBFILE_COLLECTIONS\s*\+?=\s*"([^"]+)"', content):
                collection_name = match.group(1).strip()
                if collection_name:
                    collection_map[collection_name] = layer_path
        except (IOError, OSError):
            pass

    return collection_map


def add_layer_to_bblayers(
    layer_path: str,
    bblayers_conf: str,
    collection_map: Dict[str, str],
    init_script: Optional[str] = None,
) -> Tuple[bool, str, List[str]]:
    """
    Add a layer to bblayers.conf using bitbake-layers, resolving dependencies.

    Args:
        layer_path: Path to the layer to add
        bblayers_conf: Path to bblayers.conf
        collection_map: Map from collection names to layer paths
        init_script: Optional path to oe-init-build-env script

    Returns:
        Tuple of (success, message, layers_added)
    """
    # Ensure absolute path for bblayers.conf to correctly compute build_dir
    bblayers_conf = os.path.abspath(bblayers_conf)
    build_dir = os.path.dirname(os.path.dirname(bblayers_conf))  # conf/ -> build/

    if not build_dir or not os.path.isdir(build_dir):
        return False, f"Invalid build directory: {build_dir}", []

    layers_added: List[str] = []
    layers_to_add: List[str] = [os.path.abspath(layer_path)]
    max_iterations = 20  # Prevent infinite loops

    # Check if bitbake-layers is already available in PATH
    bitbake_layers_cmd = shutil.which("bitbake-layers")
    use_direct = bitbake_layers_cmd is not None

    # If not in PATH, find init script
    if not use_direct and not init_script:
        # Look for oe-init-build-env in parent directories
        search_dir = os.path.dirname(build_dir)
        for _ in range(3):
            candidate = os.path.join(search_dir, "oe-init-build-env")
            if os.path.isfile(candidate):
                init_script = candidate
                break
            # Also check in layers subdirectory
            for subdir in ["layers", "poky", "openembedded-core"]:
                candidate = os.path.join(search_dir, subdir, "oe-init-build-env")
                if os.path.isfile(candidate):
                    init_script = candidate
                    break
                # Check deeper
                candidate = os.path.join(search_dir, subdir, "openembedded-core", "oe-init-build-env")
                if os.path.isfile(candidate):
                    init_script = candidate
                    break
            if init_script:
                break
            search_dir = os.path.dirname(search_dir)

    if not use_direct and not init_script:
        return False, "Could not find oe-init-build-env script or bitbake-layers in PATH", []

    iteration = 0
    attempted: Set[str] = set()  # Track layers we've attempted to avoid infinite loops

    while layers_to_add and iteration < max_iterations:
        iteration += 1
        current_layer = layers_to_add.pop(0)

        if current_layer in layers_added:
            continue

        # Track how many times we've tried this layer
        attempt_key = current_layer
        if attempt_key in attempted:
            # We've already tried this layer once, something is wrong
            continue
        attempted.add(attempt_key)

        try:
            # Use direct bitbake-layers if available, otherwise source init script
            if use_direct:
                result = subprocess.run(
                    ["bitbake-layers", "add-layer", current_layer],
                    capture_output=True,
                    text=True,
                    cwd=build_dir,
                )
            else:
                cmd = f'source "{init_script}" "{build_dir}" > /dev/null 2>&1 && bitbake-layers add-layer "{current_layer}" 2>&1'
                result = subprocess.run(
                    cmd,
                    shell=True,
                    executable='/bin/bash',
                    capture_output=True,
                    text=True,
                    cwd=build_dir,
                )

            output = result.stdout + result.stderr

            if result.returncode == 0:
                layers_added.append(current_layer)
            elif "already in" in output.lower() or "already enabled" in output.lower():
                # Layer is already in bblayers.conf - treat as success
                layers_added.append(current_layer)
            else:
                # Parse dependency errors
                # Format: ERROR: Layer 'X' depends on layer 'Y', but this layer is not enabled
                dep_pattern = r"ERROR: Layer '[^']+' depends on layer '([^']+)', but this layer is not enabled"
                missing_deps = re.findall(dep_pattern, output)

                if missing_deps:
                    # Check if the "missing" dependency is actually the layer we're adding
                    # This happens when bitbake-layers complains about pre-existing issues
                    # e.g., "networking-layer depends on meta-python" when adding meta-python
                    current_layer_name = None
                    layer_conf = os.path.join(current_layer, "conf", "layer.conf")
                    if os.path.isfile(layer_conf):
                        try:
                            with open(layer_conf, 'r') as f:
                                content = f.read()
                            match = re.search(r'BBFILE_COLLECTIONS\s*\+?=\s*"([^"]+)"', content)
                            if match:
                                current_layer_name = match.group(1).strip()
                        except (IOError, OSError):
                            pass

                    # Filter out deps that are the current layer itself
                    real_missing_deps = [d for d in missing_deps if d != current_layer_name]

                    if not real_missing_deps:
                        # The only "missing" dep is the layer we're adding - this is a pre-existing
                        # dependency issue in bblayers.conf. bitbake-layers can't add the layer
                        # because it validates all existing layers first.
                        # Suggest manual fix.
                        layer_name = os.path.basename(current_layer)
                        return False, f"Pre-existing dependency issue prevents add. Add {layer_name} manually or fix bblayers.conf", layers_added

                    # Remove from attempted so we can retry after adding deps
                    attempted.discard(current_layer)
                    # Add current layer back to try after dependencies
                    layers_to_add.append(current_layer)

                    # Find and add missing dependencies
                    added_any_dep = False
                    for dep_name in real_missing_deps:
                        if dep_name in collection_map:
                            dep_path = collection_map[dep_name]
                            if dep_path not in layers_added and dep_path not in layers_to_add:
                                # Insert at beginning so deps are added first
                                layers_to_add.insert(0, dep_path)
                                added_any_dep = True
                        else:
                            return False, f"Missing dependency '{dep_name}' not found in available layers", layers_added

                    # If we didn't add any new deps, we're stuck
                    if not added_any_dep:
                        deps_status = [f"{d}" for d in real_missing_deps]
                        return False, f"Dependencies already queued but still failing: {', '.join(deps_status)}", layers_added
                else:
                    # Unknown error
                    error_msg = result.stderr.strip() or result.stdout.strip()
                    if not error_msg:
                        error_msg = "bitbake-layers not available (is bitbake installed/cloned?)"
                    return False, f"Failed to add layer: {error_msg}", layers_added

        except Exception as e:
            return False, f"Error running bitbake-layers: {e}", layers_added

    if iteration >= max_iterations:
        return False, "Too many dependency iterations - possible circular dependency", layers_added

    # Build summary of what was added
    if layers_added:
        added_names = [os.path.basename(l) for l in layers_added]
        return True, f"Added: {', '.join(added_names)}", layers_added
    return True, "No layers added", layers_added


def remove_layer_from_bblayers(
    layer_path: str,
    bblayers_conf: str,
) -> Tuple[bool, str]:
    """
    Remove a layer from bblayers.conf using bitbake-layers.

    Args:
        layer_path: Path to the layer to remove
        bblayers_conf: Path to bblayers.conf

    Returns:
        Tuple of (success, message)
    """
    # Ensure absolute path for bblayers.conf to correctly compute build_dir
    bblayers_conf = os.path.abspath(bblayers_conf)
    build_dir = os.path.dirname(os.path.dirname(bblayers_conf))

    if not build_dir or not os.path.isdir(build_dir):
        return False, f"Invalid build directory: {build_dir}"

    layer_path = os.path.abspath(layer_path)
    layer_name = os.path.basename(layer_path)

    # Check if bitbake-layers is already available in PATH
    bitbake_layers_cmd = shutil.which("bitbake-layers")

    try:
        if bitbake_layers_cmd:
            result = subprocess.run(
                ["bitbake-layers", "remove-layer", layer_path],
                capture_output=True,
                text=True,
                cwd=build_dir,
            )
        else:
            # Try to find and source oe-init-build-env
            init_script = None
            search_dir = os.path.dirname(build_dir)
            for _ in range(3):
                for candidate_path in [
                    os.path.join(search_dir, "oe-init-build-env"),
                    os.path.join(search_dir, "layers", "oe-init-build-env"),
                    os.path.join(search_dir, "poky", "oe-init-build-env"),
                ]:
                    if os.path.isfile(candidate_path):
                        init_script = candidate_path
                        break
                if init_script:
                    break
                search_dir = os.path.dirname(search_dir)

            if not init_script:
                return False, "Could not find oe-init-build-env script or bitbake-layers in PATH"

            cmd = f'source "{init_script}" "{build_dir}" > /dev/null 2>&1 && bitbake-layers remove-layer "{layer_path}" 2>&1'
            result = subprocess.run(
                cmd,
                shell=True,
                executable='/bin/bash',
                capture_output=True,
                text=True,
                cwd=build_dir,
            )

        if result.returncode == 0:
            return True, f"Removed: {layer_name}"
        else:
            error_msg = result.stderr.strip() or result.stdout.strip()
            return False, f"Failed to remove layer: {error_msg}"

    except Exception as e:
        return False, f"Error running bitbake-layers: {e}"


def run_cmd(repo: str, args, dry_run: bool, *, shell: bool = False) -> None:
    if dry_run:
        cmd = args if shell else " ".join(shlex.quote(str(a)) for a in args)
        print(f"[dry-run] (cd {shlex.quote(repo)} && {cmd})")
        return
    subprocess.run(args, check=True, cwd=repo, shell=shell)


def get_upstream_count_ls_remote(repo: str, branch: str, timeout: int = 5) -> Optional[int]:
    """Get upstream commit count using ls-remote (no local modification).

    Returns:
        None: no remote tracking, timeout, or error
        -1: remote has changes but can't count (not fetched)
        0+: exact count of commits to pull
    """
    try:
        # Get remote SHA via ls-remote (with timeout to avoid hanging)
        out = subprocess.check_output(
            ["git", "-C", repo, "ls-remote", "origin", branch],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        )
        if not out.strip():
            return None
        remote_sha = out.split()[0]

        # Check if we have this commit locally
        exists = subprocess.run(
            ["git", "-C", repo, "cat-file", "-e", remote_sha],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if not exists:
            # Remote has commits we don't have locally - can't count without fetch
            return -1  # Signal "unknown but has changes"

        # Count commits between HEAD and remote
        out = subprocess.check_output(
            ["git", "-C", repo, "rev-list", "--count", f"HEAD..{remote_sha}"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return int(out.strip())
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError):
        return None


def fzf_prompt_action(repo: str, branch: str, default_action: str, upstream_info: Optional[str] = None, saved_default: Optional[str] = None) -> Optional[Tuple[str, str, Optional[str]]]:
    """Use fzf to prompt for update action."""
    display_name = repo_display_name(repo)
    dialog_state = ExploreMenuState()

    # Build menu options
    from .branch import get_upstream_ref
    upstream = get_upstream_ref(repo, branch) or f"origin/{branch}"
    if is_custom_default(default_action):
        cmd = get_custom_command(default_action)
        default_label = f"custom ({cmd})"
    else:
        default_label = {"rebase": "pull --rebase", "merge": "pull (merge)", "skip": "skip"}.get(default_action, default_action)
    # When up-to-date auto-skip overrides the saved default, show both
    if saved_default and saved_default != default_action and default_action == "skip":
        saved_label = f"custom ({get_custom_command(saved_default)})" if is_custom_default(saved_default) else saved_default
        default_label += f" (up-to-date, default: {saved_label})"
    base_menu_lines = [
        f"►► Use default: {default_label}",
        f"   Pull --rebase {upstream}",
        f"   Pull (merge) {upstream}",
        "   Custom command...",
        "── Set default ──",
        "   Set default: rebase",
        "   Set default: merge",
        "   Set default: skip",
        "   Set default: custom...",
        "──────────────────",
        "   Skip this repo (s)",
        "   Quit (q)",
    ]

    # Build header with repo name prominent at top
    header = f"{Colors.BOLD}{Colors.GREEN}→ {display_name}{Colors.RESET}\n"
    tracking_info = ""
    if not upstream.startswith("origin/"):
        tracking_info = f"  tracking: {upstream}"
    display_default = saved_default if saved_default else default_action
    header += f"  branch: {Colors.BOLD}{branch}{Colors.RESET}{tracking_info}  default: {display_default}"
    if upstream_info:
        upstream_color = ANSI_COLORS.get(get_terminal_color("upstream"), Colors.YELLOW)
        header += f"  {upstream_color}{upstream_info}{Colors.RESET}"

    setting_custom_default = False  # flag: dialog is for "Set default: custom"

    while True:
        has_dialog = dialog_state.has_dialog()

        # Build menu lines with dialog items prepended if active
        if has_dialog:
            dialog_items = dialog_state.get_dialog_menu_lines()
            menu_lines = [f"{item[0]}\t{item[1]}" for item in dialog_items] + base_menu_lines
            header_text = header + "\n  Type command in query, Enter=confirm | Esc=cancel"
        else:
            menu_lines = base_menu_lines
            header_text = header + "\n  Enter=select | s=skip | q=quit"

        # Build fzf command - conditional bindings based on dialog state
        fzf_cmd = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--no-info",
            "--ansi",
            "--height", "~18",
            "--header", header_text,
            "--prompt", "Command: " if has_dialog else "Action: ",
        ]

        if has_dialog:
            fzf_cmd.extend(["--disabled", "--print-query", "--bind", "esc:abort"])
        else:
            fzf_cmd.extend(
                get_action_binding("s", "SKIP") +
                get_action_binding("q", "QUIT")
            )

        fzf_cmd.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_cmd,
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return None  # fzf not available

        # Parse output based on dialog state
        if has_dialog:
            lines = result.stdout.strip().split("\n") if result.stdout else []
            query = lines[0] if lines else ""
            selected = lines[1] if len(lines) > 1 else ""
        else:
            query = ""
            selected = result.stdout.strip() if result.stdout else ""

        # Handle interrupt (Esc)
        if result.returncode != 0:
            if has_dialog:
                dialog_state.clear_dialog()
                continue
            print(f"Skipping {repo}.")
            return ("skip", branch, None)

        # Handle dialog selection — extract value from tab-delimited line
        selected_value = selected.split("\t")[0] if has_dialog else selected
        if has_dialog and dialog_state._renderer.is_dialog_item(selected_value):
            dlg_result = dialog_state.handle_dialog_selection(selected_value, query)
            if dlg_result.confirmed and dlg_result.value:
                custom_cmd = dlg_result.value.strip()
                dialog_state.clear_dialog()
                if custom_cmd:
                    if setting_custom_default:
                        setting_custom_default = False
                        print(f"Setting default for {repo} to custom: {custom_cmd}")
                        return ("custom", custom_cmd, f"custom:{custom_cmd}")
                    return ("custom", custom_cmd, None)
                print(f"No command provided, skipping {repo}.")
                setting_custom_default = False
                return ("skip", branch, None)
            dialog_state.clear_dialog()
            setting_custom_default = False
            continue

        if selected == "SKIP" or "Skip this repo" in selected:
            print(f"Skipping {repo}.")
            return ("skip", branch, None)

        if selected == "QUIT" or "Quit" in selected:
            return ("quit", branch, None)

        if "Use default" in selected:
            if is_custom_default(default_action):
                return ("custom", get_custom_command(default_action), None)
            return (default_action, branch, None)

        if "Pull --rebase" in selected:
            return ("rebase", branch, None)

        if "Pull (merge)" in selected:
            return ("merge", branch, None)

        if "Custom command" in selected:
            dialog_state.show_dialog(text_input_dialog("Enter command:"))
            continue

        if "Set default: rebase" in selected:
            print(f"Setting default for {repo} to rebase.")
            return ("rebase", branch, "rebase")

        if "Set default: merge" in selected:
            print(f"Setting default for {repo} to merge.")
            return ("merge", branch, "merge")

        if "Set default: skip" in selected:
            print(f"Setting default for {repo} to skip.")
            return ("skip", branch, "skip")

        if "Set default: custom" in selected:
            setting_custom_default = True
            dialog_state.show_dialog(text_input_dialog("Set custom default:"))
            continue

        return ("skip", branch, None)


def prompt_action(repo: str, branch: Optional[str], default_action: str, use_fzf: bool = True) -> Optional[Tuple[str, str, Optional[str]]]:
    if not branch:
        print(f"Skipping {repo} (detached HEAD or no branch).")
        return None

    # Get upstream status
    upstream_info = ""
    upstream_count = get_upstream_count_ls_remote(repo, branch)
    if upstream_count is not None:
        if upstream_count == -1:
            upstream_info = "↓ upstream has changes"
        elif upstream_count > 0:
            upstream_info = f"↓ {upstream_count} to pull"
        elif upstream_count == 0:
            upstream_info = "up-to-date"

    # If up-to-date, default to skip (but don't change saved default)
    effective_default = default_action
    if upstream_count == 0:
        effective_default = "skip"

    # Try fzf first (unless disabled)
    if use_fzf and fzf_available():
        saved = default_action if effective_default != default_action else None
        result = fzf_prompt_action(repo, branch, effective_default, upstream_info or None, saved_default=saved)
        if result is not None:
            return result

    # Fall back to text-based prompt
    print(f"\n╭─ {repo}")
    print(f"│   branch: {branch}")
    upstream_line = f"  ({upstream_info})" if upstream_info else ""
    if is_custom_default(effective_default):
        default_display = f"custom ({get_custom_command(effective_default)})"
    else:
        default_display = effective_default
    if effective_default != default_action:
        default_display = f"{effective_default} (up-to-date, default: {default_action})"
    print(f"│   Default: {default_display}{upstream_line}")
    print("│   Actions: [Enter] default | r [br] pull --rebase | m [br] pull | c <cmd> custom | d <skip|rebase|merge|custom cmd> set default | s skip | q quit")
    choice = input("╰─ choice: ").strip()

    if not choice:
        if is_custom_default(effective_default):
            return ("custom", get_custom_command(effective_default), None)
        return (effective_default, branch, None)

    if choice.lower() in {"s", "n"}:
        print(f"Skipping {repo}.")
        return ("skip", branch, None)

    if choice.lower() == "q":
        return ("quit", branch, None)

    if choice.lower().startswith("d custom "):
        custom_cmd = choice[9:].strip()
        if custom_cmd:
            new_default = f"custom:{custom_cmd}"
            print(f"Setting default for {repo} to custom: {custom_cmd}")
            return ("custom", custom_cmd, new_default)
        print("No custom command provided, keeping current default.")
        return None

    if choice.lower().startswith("d "):
        parts = choice.split(maxsplit=1)
        new_default = parts[1].strip().lower() if len(parts) > 1 else ""
        if new_default not in {"skip", "rebase", "merge"}:
            print(f"Unrecognized default '{new_default}', keeping current default.")
            return None
        print(f"Setting default for {repo} to {new_default}.")
        return (new_default, branch, new_default)

    if choice.lower().startswith("c "):
        custom_cmd = choice[2:].strip()
        if not custom_cmd:
            print(f"No custom command provided, skipping {repo}.")
            return None
        return ("custom", custom_cmd, None)

    parts = choice.split(maxsplit=1)
    action = parts[0].lower()
    target = branch
    if len(parts) > 1 and parts[1]:
        target = parts[1]

    if action == "r":
        return ("rebase", target, None)
    if action == "m":
        return ("merge", target, None)

    print(f"Unrecognized input '{choice}', skipping {repo}.")
    return None


def repo_display_name(repo: str) -> str:
    """
    Get display name for a repo. Checks git config for override first,
    then derives from origin URL, falling back to basename.

    To set a custom name: git -C <repo> config bit.display-name "OE-core"
    """
    # Check for user override in git config
    try:
        override = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "bit.display-name"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
        if override:
            return override
    except subprocess.CalledProcessError:
        pass

    # Derive from origin URL
    try:
        url = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "remote.origin.url"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except subprocess.CalledProcessError:
        url = ""

    candidate = url
    if candidate:
        candidate = candidate.rstrip("/")
        # handle scp-like git@host:org/repo.git
        if ":" in candidate and "://" not in candidate:
            candidate = candidate.split(":", 1)[1]
        candidate = candidate.split("/")[-1]
        if candidate.endswith(".git"):
            candidate = candidate[:-4]
    if not candidate:
        candidate = os.path.basename(repo.rstrip("/")) or repo
    return candidate


def build_inline_dialog_lines(
    title: str,
    items: List[Tuple[str, str]],
    *,
    reverse_list: bool = True,
    annotation: str = "",
    width: int = 40,
) -> List[str]:
    """Build box-drawing inline dialog lines for fzf menus.

    Produces a header (``┌─ title ───``) and item lines (``│  display``)
    in the correct order for the caller's fzf layout.

    Args:
        title: Clean title text (used for dash-padding calculation).
        items: ``(key, display)`` pairs.  Keys starting with ``---``
            render as separator lines (``│  ────``).
        reverse_list: True for ``--layout=reverse-list`` (header first,
            items last — APPEND to menu_lines).  False for default layout
            (items first, header last — PREPEND to menu_lines).
        annotation: Optional extra text appended to the header before the
            trailing dashes (may contain ANSI codes).
        width: Target width for the trailing dashes.

    Returns:
        List of tab-delimited ``key\\tdisplay`` strings ready for fzf.
    """
    header = f"┌─ {title} "
    if annotation:
        header += annotation + " "
    header += "─" * max(0, width - len(title))
    header_line = f"---\t{Colors.cyan(header)}"

    item_lines: List[str] = []
    for key, display in items:
        if key.startswith("---"):
            item_lines.append(
                f"---\t{Colors.cyan('│')}  {Colors.dim('───────────────────')}"
            )
        else:
            item_lines.append(f"{key}\t{Colors.cyan('│')}  {display}")

    if reverse_list:
        # Header first (visually above), items last (near prompt)
        return [header_line] + item_lines
    else:
        # Items first (near prompt in default layout), header last
        return item_lines + [header_line]


def get_project_header_prefix() -> str:
    """Return formatted '[ProjectName] ' for fzf headers, or '' if no project.

    When running inside a bit-spawned SSH session (detected via
    ``BIT_REMOTE_HOST``), prepends a ``⇄ hostname`` indicator.
    """
    from .projects import find_project_for_directory, load_projects
    parts = []

    # Remote session indicator — only when bit spawned the SSH session
    # (BIT_REMOTE_HOST is set explicitly by ssh_remote.py).
    # We intentionally don't check SSH_CONNECTION because most users
    # are SSH'd in already and that would always trigger.
    remote_host = os.environ.get("BIT_REMOTE_HOST", "")
    if remote_host:
        parts.append(terminal_color("project_remote", f"⇄ {remote_host}"))

    proj_path = find_project_for_directory()
    if proj_path:
        projects = load_projects()
        name = projects.get(proj_path, {}).get("name", os.path.basename(proj_path))
        parts.append(Colors.bold(terminal_color("project_active", f"[{name}]")))

    if not parts:
        return ""
    return " ".join(parts) + " "


def repo_origin_url(repo: str) -> Optional[str]:
    """Get the origin URL for a repo."""
    try:
        return subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "remote.origin.url"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except subprocess.CalledProcessError:
        return None


def commit_files(repo: str, commit: str) -> List[str]:
    """Get list of files changed in a commit."""
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "show", "--name-only", "--format=", commit],
            text=True,
        )
        return [f for f in output.strip().splitlines() if f]
    except subprocess.CalledProcessError:
        return []


def commit_to_layer(repo: str, commit: str, layers: List[str]) -> Optional[str]:
    """
    Determine which layer a commit belongs to.
    Returns the layer path if commit touches exactly one layer,
    None if commit touches no layers or multiple layers.
    """
    files = commit_files(repo, commit)
    if not files:
        return None

    # Get relative paths of layers within the repo
    layer_relpaths = []
    for layer in layers:
        try:
            relpath = os.path.relpath(layer, repo)
            layer_relpaths.append((layer, relpath))
        except ValueError:
            continue

    # Find which layers this commit touches
    touched_layers = set()
    for filepath in files:
        for layer, relpath in layer_relpaths:
            if filepath.startswith(relpath + "/") or filepath == relpath:
                touched_layers.add(layer)
                break

    if len(touched_layers) == 1:
        return touched_layers.pop()
    return None


def layer_display_name(layer: str) -> str:
    """Get display name for a layer (just the directory name)."""
    return os.path.basename(layer.rstrip("/"))


def group_commits_by_layer(repo: str, commits: List[str], layers: List[str]) -> Tuple[Dict[str, List[str]], List[str], List[str]]:
    """
    Group commits by which layer they touch.
    Returns (layer_commits dict, list of commits touching multiple layers, list of commits touching no layers).
    """
    layer_commits: Dict[str, List[str]] = {}
    cross_layer_commits: List[str] = []
    no_layer_commits: List[str] = []

    for commit in commits:
        layer = commit_to_layer(repo, commit, layers)
        if layer is None:
            # Check if it touches multiple layers or no layers
            files = commit_files(repo, commit)
            layer_relpaths = []
            for l in layers:
                try:
                    relpath = os.path.relpath(l, repo)
                    layer_relpaths.append((l, relpath))
                except ValueError:
                    continue

            touched = set()
            for filepath in files:
                for l, relpath in layer_relpaths:
                    if filepath.startswith(relpath + "/") or filepath == relpath:
                        touched.add(l)
                        break

            if len(touched) > 1:
                cross_layer_commits.append(commit)
            elif len(touched) == 1:
                layer = touched.pop()
                layer_commits.setdefault(layer, []).append(commit)
            else:
                no_layer_commits.append(commit)
        else:
            layer_commits.setdefault(layer, []).append(commit)

    return layer_commits, cross_layer_commits, no_layer_commits


def get_upstream_layer_counts(repo: str, branch: str, layers: List[str]) -> Dict[str, int]:
    """Get per-layer count of upstream commits efficiently.

    Uses git rev-list --count with path filtering — one call per layer.
    Only meaningful after a fetch (requires commit objects locally).
    """
    from .branch import get_upstream_ref
    remote_ref = get_upstream_ref(repo, branch)
    if not remote_ref:
        return {}

    counts: Dict[str, int] = {}
    for layer in layers:
        try:
            relpath = os.path.relpath(layer, repo)
        except ValueError:
            continue
        try:
            out = subprocess.check_output(
                ["git", "-C", repo, "rev-list", "--count", f"HEAD..{remote_ref}", "--", f"{relpath}/"],
                text=True, stderr=subprocess.DEVNULL,
            )
            count = int(out.strip())
            if count > 0:
                counts[layer] = count
        except (subprocess.CalledProcessError, ValueError):
            continue
    return counts


def create_pull_branch(repo: str, branch_name: str, base_ref: str, range_spec: str, force: bool) -> Tuple[bool, str]:
    """
    Create a branch with the selected commits for pulling.
    The branch is created from the parent of the first commit in range_spec,
    then all commits are cherry-picked onto it.
    Returns (success, message).
    """
    # Check if branch exists
    branch_exists = subprocess.run(
        ["git", "-C", repo, "rev-parse", "--verify", branch_name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0

    if branch_exists:
        if force:
            subprocess.run(["git", "-C", repo, "branch", "-D", branch_name], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            return False, f"Branch '{branch_name}' already exists (use --force to overwrite)"

    # Get the commits in the range
    try:
        if range_spec == "--root":
            # All commits from root - just create branch at HEAD
            subprocess.run(
                ["git", "-C", repo, "branch", branch_name, "HEAD"],
                check=True,
            )
        else:
            # Get list of commits in range
            commits = subprocess.check_output(
                ["git", "-C", repo, "rev-list", "--reverse", range_spec],
                text=True,
            ).strip().splitlines()

            if not commits:
                return False, "No commits in range"

            # Get parent of first commit
            first_commit = commits[0]
            try:
                first_parent = subprocess.check_output(
                    ["git", "-C", repo, "rev-parse", f"{first_commit}^"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                ).strip()
            except subprocess.CalledProcessError:
                # First commit has no parent (root commit), use base_ref as fallback
                first_parent = base_ref

            # Check if first_parent is in upstream (base_ref), or if there are
            # intermediate local commits between upstream and our selection
            is_upstream = subprocess.run(
                ["git", "-C", repo, "merge-base", "--is-ancestor", first_parent, base_ref],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode == 0

            extra_count = 0
            if is_upstream:
                # Parent is upstream, we can branch from it directly
                branch_base = first_parent
            else:
                # Parent is a local commit - find commits between upstream and first selected
                try:
                    extra_commits = subprocess.check_output(
                        ["git", "-C", repo, "rev-list", "--reverse", f"{base_ref}..{first_parent}"],
                        text=True,
                    ).strip().splitlines()
                except subprocess.CalledProcessError:
                    extra_commits = []

                if extra_commits:
                    # Include the extra local commits so the branch is pullable
                    extra_count = len(extra_commits)
                    commits = extra_commits + commits
                    branch_base = base_ref
                else:
                    branch_base = first_parent

            # Create branch at the determined base
            subprocess.run(
                ["git", "-C", repo, "branch", branch_name, branch_base],
                check=True,
            )

            # Cherry-pick commits onto the branch
            # First checkout the branch
            original_branch = subprocess.check_output(
                ["git", "-C", repo, "symbolic-ref", "--short", "HEAD"],
                text=True,
            ).strip()

            subprocess.run(["git", "-C", repo, "checkout", branch_name], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            cherry_pick_failed = False
            failed_commit = None
            for commit in commits:
                result = subprocess.run(
                    ["git", "-C", repo, "cherry-pick", commit],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                if result.returncode != 0:
                    cherry_pick_failed = True
                    failed_commit = commit[:12]
                    break

            if cherry_pick_failed:
                # Abort cherry-pick and clean up
                subprocess.run(["git", "-C", repo, "cherry-pick", "--abort"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(["git", "-C", repo, "checkout", original_branch],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(["git", "-C", repo, "branch", "-D", branch_name],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return False, f"Cherry-pick failed on {failed_commit} (conflict with {base_ref}?)"

            # Switch back to original branch
            subprocess.run(["git", "-C", repo, "checkout", original_branch], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        if range_spec != "--root" and extra_count > 0:
            return True, f"Created branch '{branch_name}' (included {extra_count} additional local commit(s) before selection)"
        return True, f"Created branch '{branch_name}'"
    except subprocess.CalledProcessError as e:
        return False, f"Failed to create branch: {e}"


def author_ident(repo: str) -> Tuple[str, str]:
    fallback = ("nobody", "nobody@localhost")
    try:
        ident = subprocess.check_output(
            ["git", "-C", repo, "var", "GIT_AUTHOR_IDENT"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
        # Format: "Name <email> timestamp timezone"
        if "<" in ident and ">" in ident:
            name = ident.split("<", 1)[0].strip()
            email = ident.split("<", 1)[1].split(">", 1)[0].strip()
            return name or fallback[0], email or fallback[1]
    except subprocess.CalledProcessError:
        pass
    return fallback


def patch_subject(patch_path: str) -> str:
    try:
        with open(patch_path, encoding="utf-8") as f:
            for line in f:
                if line.lower().startswith("subject:"):
                    subj = line.split(":", 1)[1].strip()
                    if subj.startswith("[PATCH"):
                        end = subj.find("]")
                        if end != -1:
                            subj = subj[end + 1 :].strip()
                    return subj
    except Exception:
        pass
    return os.path.basename(patch_path)


def git_version() -> str:
    try:
        out = subprocess.check_output(["git", "--version"], text=True).strip()
        # format: git version X.Y.Z
        parts = out.split()
        if len(parts) >= 3:
            return parts[2]
    except Exception:
        pass
    return "unknown"


def git_request_pull(
    repo: str,
    base_ref: str,
    push_url: str,
    local_ref: str,
    remote_branch: str,
) -> Optional[str]:
    """
    Generate a git request-pull message.
    Returns the request-pull output (without diffstat), or None on error.
    """
    try:
        # Format: git request-pull <start> <url> <local>:<remote>
        cmd = ["git", "-C", repo, "request-pull", base_ref, push_url, f"{local_ref}:{remote_branch}"]
        output = subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT)
        # Remove the diffstat portion (everything after the first file stats line)
        # The format is: URL line, then empty line, then diffstat
        lines = output.splitlines()
        result_lines = []
        for line in lines:
            # Stop before diffstat (lines with file changes like " file | N +++ ---")
            if re.match(r"^\s+\S+.*\|\s+\d+", line):
                break
            # Also stop at "N files changed" summary
            if re.match(r"^\s*\d+ files? changed", line):
                break
            result_lines.append(line)
        # Remove trailing empty lines
        while result_lines and not result_lines[-1].strip():
            result_lines.pop()
        return "\n".join(result_lines)
    except subprocess.CalledProcessError as e:
        return None


def push_branch_to_target(
    repo: str,
    push_url: str,
    local_ref: str,
    remote_branch: str,
    force: bool = False,
) -> Tuple[bool, str]:
    """
    Push a branch to the push target.
    Returns (success, message).
    """
    try:
        cmd = ["git", "-C", repo, "push", push_url, f"{local_ref}:{remote_branch}"]
        if force:
            cmd.insert(3, "--force")
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        return True, f"Pushed {local_ref} to {push_url} {remote_branch}"
    except subprocess.CalledProcessError as e:
        return False, f"Push failed: {e.stderr.strip() or e.stdout.strip() or str(e)}"


def clean_title(subject: str) -> str:
    s = subject.strip()
    # Drop leading bracketed tokens like [PATCH 1/2], [repo], etc.
    s = re.sub(r"^(?:\[[^\]]*\]\s*)+", "", s)
    return s.strip()


def rewrite_patch_subject(patch_path: str, repo_name: str) -> None:
    """
    Normalize Subject to: [NN/MM][repo] title
    """
    try:
        with open(patch_path, encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return

    new_lines = []
    changed = False
    subj_re_patch = re.compile(r"Subject:\s*(?:\[[^\]]*\]\s*)*\[PATCH\s+(\d+)/(\d+)\]\s*(.*)", re.IGNORECASE)
    subj_re_repo_num = re.compile(r"Subject:\s*\[+([^\]]+?)\]+\s*\[?(\d+)/(\d+)\]?\s*(.*)", re.IGNORECASE)
    subj_re_num_repo = re.compile(r"Subject:\s*\[?(\d+)/(\d+)\]?\s*\[+([^\]]+?)\]+\s*(.*)", re.IGNORECASE)
    for line in lines:
        if not changed and line.lower().startswith("subject:"):
            m = subj_re_patch.match(line)
            repo = repo_name
            if m:
                num, den, rest = m.groups()
            else:
                m = subj_re_repo_num.match(line)
                if m:
                    repo, num, den, rest = m.groups()
                    repo = repo.strip("[]") or repo_name
                else:
                    m = subj_re_num_repo.match(line)
                    if m:
                        num, den, repo, rest = m.groups()
                        repo = repo.strip("[]") or repo_name
                    else:
                        new_lines.append(line)
                        continue

            # strip any leading bracket tokens from rest
            while rest.startswith("[") and "]" in rest:
                rest = rest.split("]", 1)[1].strip()
            new_line = f"Subject: [{repo}][PATCH {num}/{den}] {rest}\n"
            new_lines.append(new_line)
            changed = True
            continue
        new_lines.append(line)

    if changed:
        try:
            with open(patch_path, "w", encoding="utf-8") as f:
                f.writelines(new_lines)
        except Exception:
            pass


def load_resume(resume_file: str) -> Optional[Tuple[int, List[str]]]:
    if not os.path.exists(resume_file):
        return None
    with open(resume_file, encoding="utf-8") as f:
        lines = [line.rstrip("\n") for line in f]
    if not lines:
        return None
    try:
        idx = int(lines[0])
    except ValueError:
        return None
    return idx, lines[1:]


def save_resume(resume_file: str, next_idx: int, repos: List[str]) -> None:
    with open(resume_file, "w", encoding="utf-8") as f:
        f.write(f"{next_idx}\n")
        for repo in repos:
            f.write(f"{repo}\n")


def get_extra_repos(defaults: dict) -> List[str]:
    """Get list of extra repos from defaults."""
    return defaults.get("__extra_repos__", [])


def get_hidden_repos(defaults: dict) -> List[str]:
    """Get list of hidden repos from defaults."""
    return defaults.get("__hidden_repos__", [])


def write_ignore_file(project_dir: str) -> bool:
    """Write a .ignore file to exclude build directories from search tools.

    Writes 'build*/' so ripgrep, fd, etc. skip build directories.
    Returns True if the file was written, False if it already existed.
    """
    ignore_path = os.path.join(project_dir, ".ignore")
    if os.path.exists(ignore_path):
        return False
    try:
        with open(ignore_path, "w") as f:
            f.write("build*/\n")
        return True
    except OSError:
        return False


def add_extra_repo(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Add a repo to the extra repos list and save."""
    extra = defaults.get("__extra_repos__", [])
    if repo_path not in extra:
        extra.append(repo_path)
        defaults["__extra_repos__"] = extra
        save_defaults(defaults_file, defaults)


def add_hidden_repo(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Add a repo to the hidden repos list and save."""
    hidden = defaults.get("__hidden_repos__", [])
    if repo_path not in hidden:
        hidden.append(repo_path)
        defaults["__hidden_repos__"] = hidden
        save_defaults(defaults_file, defaults)


def remove_hidden_repo(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Remove a repo from the hidden repos list and save."""
    hidden = defaults.get("__hidden_repos__", [])
    if repo_path in hidden:
        hidden.remove(repo_path)
        defaults["__hidden_repos__"] = hidden
        save_defaults(defaults_file, defaults)


def get_push_target(defaults: dict, repo_path: str) -> Optional[Dict[str, str]]:
    """Get push target config for a repo. Returns dict with push_url, branch_prefix, or None."""
    targets = defaults.get("__push_targets__", {})
    return targets.get(repo_path)


def set_push_target(
    defaults_file: str,
    defaults: dict,
    repo_path: str,
    push_url: str,
    branch_prefix: str = "",
) -> None:
    """Set push target config for a repo."""
    targets = defaults.get("__push_targets__", {})
    targets[repo_path] = {
        "push_url": push_url,
        "branch_prefix": branch_prefix,
    }
    defaults["__push_targets__"] = targets
    save_defaults(defaults_file, defaults)


def remove_push_target(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Remove push target config for a repo."""
    targets = defaults.get("__push_targets__", {})
    if repo_path in targets:
        del targets[repo_path]
        defaults["__push_targets__"] = targets
        save_defaults(defaults_file, defaults)


def resolve_bblayers_path(path_opt: Optional[str]) -> Optional[str]:
    """Find bblayers.conf path, or return None if not found and not specified."""
    if path_opt:
        return path_opt
    candidates = ["conf/bblayers.conf", "build/conf/bblayers.conf"]
    for cand in candidates:
        if os.path.exists(cand):
            return cand
    return None


@dataclass
class RepoSets:
    """Tracks different categories of repos and layers."""
    discovered: Set[str]  # Discovered repos (magenta, "(?)")
    external: Set[str]    # Non-layer git repos (cyan, "(ext)")
    hidden: Set[str]      # Hidden repos (not shown unless toggled)
    configured_layers: Set[str]  # Layers from bblayers.conf (vs discovered)


@dataclass
class LayerInfo:
    """Layer metadata from layer.conf."""
    name: str              # Collection name from BBFILE_COLLECTIONS
    path: str              # Filesystem path to the layer
    depends: List[str]     # Required dependencies from LAYERDEPENDS
    recommends: List[str]  # Optional dependencies from LAYERRECOMMENDS
    priority: int          # Layer priority from BBFILE_PRIORITY


def parse_layer_conf(layer_path: str) -> Optional[LayerInfo]:
    """
    Parse a layer's conf/layer.conf to extract dependency information.

    Returns LayerInfo with collection name, dependencies, and priority,
    or None if the layer.conf doesn't exist or can't be parsed.
    """
    conf_path = os.path.join(layer_path, "conf", "layer.conf")
    if not os.path.isfile(conf_path):
        return None

    try:
        with open(conf_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, IOError):
        return None

    # Handle line continuations
    content = content.replace("\\\n", " ")

    # Extract BBFILE_COLLECTIONS (the layer's collection name)
    # Format: BBFILE_COLLECTIONS += "layer-name"
    collection_match = re.search(
        r'BBFILE_COLLECTIONS\s*\+?=\s*"([^"]*)"', content
    )
    collection_name = ""
    if collection_match:
        collection_name = collection_match.group(1).strip()

    if not collection_name:
        # Try to derive from layer path as fallback
        collection_name = os.path.basename(layer_path)
        if collection_name.startswith("meta-"):
            collection_name = collection_name[5:]

    # Extract LAYERDEPENDS_<collection> (required dependencies)
    # Format: LAYERDEPENDS_<collection> = "dep1 dep2:version dep3 (>= 4)"
    # Version constraints can be "layer:version" or "(>= version)" after a layer name
    depends = []
    depends_pattern = re.compile(
        r'LAYERDEPENDS_' + re.escape(collection_name) + r'\s*\+?=\s*"([^"]*)"'
    )
    for match in depends_pattern.finditer(content):
        deps_str = match.group(1).strip()
        # Remove parenthetical version constraints like "(>= 12)" or "(< 5)"
        deps_str = re.sub(r'\([^)]*\)', '', deps_str)
        for dep in deps_str.split():
            # Strip version constraints (e.g., "core:4" -> "core")
            dep_name = dep.split(":")[0].strip()
            # Skip empty strings and things that look like version numbers
            if dep_name and dep_name not in depends and not dep_name.isdigit():
                depends.append(dep_name)

    # Extract LAYERRECOMMENDS_<collection> (optional dependencies)
    recommends = []
    recommends_pattern = re.compile(
        r'LAYERRECOMMENDS_' + re.escape(collection_name) + r'\s*\+?=\s*"([^"]*)"'
    )
    for match in recommends_pattern.finditer(content):
        rec_str = match.group(1).strip()
        # Remove parenthetical version constraints
        rec_str = re.sub(r'\([^)]*\)', '', rec_str)
        for rec in rec_str.split():
            rec_name = rec.split(":")[0].strip()
            if rec_name and rec_name not in recommends and not rec_name.isdigit():
                recommends.append(rec_name)

    # Extract BBFILE_PRIORITY_<collection>
    # Format: BBFILE_PRIORITY_<collection> = "6"
    priority = 0
    priority_pattern = re.compile(
        r'BBFILE_PRIORITY_' + re.escape(collection_name) + r'\s*=\s*"?(\d+)"?'
    )
    priority_match = priority_pattern.search(content)
    if priority_match:
        try:
            priority = int(priority_match.group(1))
        except ValueError:
            pass

    return LayerInfo(
        name=collection_name,
        path=layer_path,
        depends=depends,
        recommends=recommends,
        priority=priority,
    )


def resolve_base_and_layers(
    path_opt: Optional[str],
    defaults: Optional[dict] = None,
    include_external: bool = True,
    discover_all: bool = True,
) -> Tuple[List[Tuple[str, str]], RepoSets]:
    """
    Resolve layers from bblayers.conf and discover additional layers/repos.

    Args:
        path_opt: Path to bblayers.conf (or None for auto-detect)
        defaults: Defaults dict (for extra_repos and hidden_repos)
        include_external: Whether to discover non-layer git repos
        discover_all: Whether to discover layers not in bblayers.conf

    Returns:
        Tuple of (pairs, repo_sets) where:
        - pairs: List of (layer_path, repo_path) tuples
        - repo_sets: RepoSets with discovered, external, and hidden repo sets
    """
    defaults = defaults or {}
    pairs: List[Tuple[str, str]] = []
    bblayers_layer_paths: Set[str] = set()
    known_repos: Set[str] = set()
    discovered_repos: Set[str] = set()
    external_repos: Set[str] = set()

    extra_repos_list = get_extra_repos(defaults)
    hidden_repos_set = set(get_hidden_repos(defaults))

    # Try to get layers from bblayers.conf
    bblayers = resolve_bblayers_path(path_opt)
    if bblayers:
        layers = extract_layer_paths(bblayers)
        for layer in layers:
            # Normalize path with realpath to resolve symlinks and avoid duplicates
            layer = os.path.realpath(layer)
            repo = git_toplevel(layer)
            if not repo:
                print(f"Warning: {layer} is not inside a git repo; skipping.")
                continue
            pairs.append((layer, repo))
            bblayers_layer_paths.add(layer)
            known_repos.add(repo)

    # Add extra repos from config (these are tracked, not external)
    for repo_path in extra_repos_list:
        repo_path = os.path.realpath(repo_path)
        if os.path.isdir(repo_path) and repo_path not in known_repos:
            repo = git_toplevel(repo_path)
            if repo:
                # Add as a pseudo-layer (repo path is both layer and repo)
                pairs.append((repo, repo))
                known_repos.add(repo)

    # Collect parent directories of known repos to check for peer repos/layers
    # e.g., if layers are in /path/project/layers/, also check /path/project/
    # But avoid searching from overly broad directories like home or root
    home_dir = os.path.expanduser("~")
    too_broad = {"/", "/home", "/opt", "/usr", home_dir}
    peer_dirs: Set[str] = set()
    for repo in known_repos:
        parent = os.path.dirname(repo)
        if parent and parent not in too_broad:
            peer_dirs.add(parent)

    # Discover additional layers not in bblayers.conf (only if discover_all is True)
    if discover_all:
        discovered = discover_layers(exclude_layers=bblayers_layer_paths, peer_dirs=peer_dirs)
        for layer, repo in discovered:
            # Add all discovered layers to pairs
            pairs.append((layer, repo))
            # But only mark repo as discovered once
            if repo not in known_repos:
                discovered_repos.add(repo)
                known_repos.add(repo)

    # Discover external git repos (non-layers) - only if discovery is enabled
    if include_external:
        external = discover_git_repos(exclude_repos=known_repos, peer_dirs=peer_dirs)
        for repo in external:
            external_repos.add(repo)

    if not pairs and not external_repos:
        if bblayers:
            sys.exit("No git repositories found for the configured layers.")
        else:
            sys.exit("No layers found. Provide --bblayers, or use -a to discover layers in the current directory.")

    repo_sets = RepoSets(
        discovered=discovered_repos,
        external=external_repos,
        hidden=hidden_repos_set,
        configured_layers=bblayers_layer_paths,
    )
    return pairs, repo_sets


def collect_repos(
    path_opt: Optional[str],
    defaults: Optional[dict] = None,
    include_external: bool = False,
    discover_all: bool = False,
) -> Tuple[List[str], RepoSets]:
    """
    Collect unique repos from bblayers.conf and discovered layers.

    Args:
        path_opt: Path to bblayers.conf (or None for auto-detect)
        defaults: Defaults dict (for extra_repos and hidden_repos)
        include_external: Whether to discover non-layer git repos
        discover_all: Whether to discover layers not in bblayers.conf

    Returns:
        Tuple of (repos, repo_sets) where:
        - repos: Deduplicated list of repo paths
        - repo_sets: RepoSets with discovered, external, and hidden repo sets
    """
    pairs, repo_sets = resolve_base_and_layers(path_opt, defaults, include_external, discover_all=discover_all)
    repos = dedupe_preserve_order(repo for _, repo in pairs)
    return repos, repo_sets


def get_repo_commit_info(repo: str) -> Tuple[Optional[str], bool, str, int, str, str]:
    branch = current_branch(repo)
    if not branch:
        return None, False, "", 0, "", "detached head"

    remote_ref = f"origin/{branch}"
    remote_exists = (
        subprocess.run(
            ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode
        == 0
    )

    if remote_exists:
        count = int(
            subprocess.check_output(
                ["git", "-C", repo, "rev-list", "--count", f"{remote_ref}..HEAD"],
                text=True,
            ).strip()
        )
        range_spec = f"{remote_ref}..HEAD"
        desc = f"local commits vs {remote_ref}"
    else:
        count = int(subprocess.check_output(["git", "-C", repo, "rev-list", "--count", "HEAD"], text=True).strip())
        range_spec = "--root"
        desc = "commits from root (no origin/<branch>)"

    return branch, remote_exists, remote_ref, count, range_spec, desc


def show_log_for_pick(repo: str, max_entries: int = 30) -> None:
    try:
        out = subprocess.check_output(
            [
                "git",
                "-C",
                repo,
                "log",
                "--oneline",
                "--decorate",
                f"-n{max_entries}",
            ],
            text=True,
        )
    except subprocess.CalledProcessError:
        print(f"{repo}: failed to read log for pick mode.")
        return
    print(out.rstrip())


# Shared command list for menus - add new commands here
COMMANDS = [
    ("explore", "Interactively explore commits in layer repos"),
    ("update", "Update git repos referenced by layers in bblayers.conf"),
    ("status", "Show local commit summary for layer repos"),
    ("config", "View and configure repo/layer settings"),
    ("branch", "View and switch branches across repos"),
    ("export", "Export patches from layer repos"),
    ("repos", "List layer repos"),
    ("setup", "Set up build environment, clone repos, manage configs"),
    ("setup shell", "Start a shell with build environment pre-sourced"),
    ("setup clone", "Clone repos and register project"),
    ("setup configs", "Browse and manage saved configurations"),
    ("setup apply", "Apply layers and fragments from saved config"),
    ("setup save", "Save a config file to the user registry"),
    ("layer-index", "Search and browse OpenEmbedded Layer Index"),
]


def fzf_command_menu() -> Optional[str]:
    """Show fzf menu to select a subcommand. Returns command name or None if cancelled."""
    # Commands with their subcommands (alphabetical order)
    commands = [
        ("branch", "View and switch branches across repos", []),
        ("config", "View and configure repo/layer settings", []),
        ("export", "Export patches from layer repos", [
            ("export prep", "Prepare commits for export (reorder/group)"),
        ]),
        ("explore", "Interactively explore commits in layer repos", []),
        ("help", "Browse help for all commands", []),
        ("setup", "Set up build environment, clone repos, manage configs", [
            ("setup shell", "Start a shell with build environment pre-sourced"),
            ("setup clone", "Clone repos and register project"),
            ("setup configs", "Browse and manage saved configurations"),
            ("setup apply", "Apply layers and fragments from saved config"),
            ("setup save", "Save a config file to the user registry"),
        ]),
        ("repos", "List layer repos", [
            ("repos status", "Show one-liner status for each repo"),
        ]),
        ("layer-index", "Search and browse OpenEmbedded Layer Index", []),
        ("status", "Show local commit summary for layer repos", []),
        ("update", "Update git repos referenced by layers in bblayers.conf", []),
    ]

    return fzf_expandable_menu(
        commands,
        header="Enter/←/→/\\=fold | q=quit",
        prompt="bit ",
        height="~80%",
    )


def fzf_help_browser() -> Optional[str]:
    """
    Interactive help browser with preview pane.
    Returns command name to run, or None to exit.
    """
    # Get the script path for preview commands
    script_path = os.path.abspath(sys.argv[0])

    # Commands with their subcommands (alphabetical order)
    commands = [
        ("(general)", "Overview and global options", []),
        ("branch", "View and switch branches across repos", []),
        ("config", "View and configure repo/layer settings", []),
        ("export", "Export patches from layer repos", [
            ("export prep", "Prepare commits for export (reorder/group)"),
        ]),
        ("explore", "Interactively explore commits in layer repos", []),
        ("help", "Browse help for all commands", []),
        ("setup", "Set up build environment, clone repos, manage configs", [
            ("setup shell", "Start a shell with build environment pre-sourced"),
            ("setup clone", "Clone repos and register project"),
            ("setup configs", "Browse and manage saved configurations"),
            ("setup apply", "Apply layers and fragments from saved config"),
            ("setup save", "Save a config file to the user registry"),
        ]),
        ("repos", "List layer repos", [
            ("repos status", "Show one-liner status for each repo"),
        ]),
        ("layer-index", "Search and browse OpenEmbedded Layer Index", []),
        ("status", "Show local commit summary for layer repos", []),
        ("update", "Update git repos referenced by layers in bblayers.conf", []),
    ]

    # Preview command: show help for the selected command
    preview_cmd = (
        f'cmd={{1}}; '
        f'if [ "$cmd" = "(general)" ]; then '
        f'  "{script_path}" --help 2>&1; '
        f'elif [ "$cmd" = "export prep" ]; then '
        f'  "{script_path}" export prep --help 2>&1; '
        f'elif [ "$cmd" = "setup shell" ]; then '
        f'  "{script_path}" setup shell --help 2>&1; '
        f'elif [ "$cmd" = "repos status" ]; then '
        f'  "{script_path}" repos status --help 2>&1; '
        f'else '
        f'  "{script_path}" "$cmd" --help 2>&1; '
        f'fi'
    )

    # Options provider: parse --help output for command options
    def get_options(cmd: str) -> List[Tuple[str, str]]:
        if cmd == "(general)":
            return parse_help_options(script_path, "")
        return parse_help_options(script_path, cmd)

    selected = fzf_expandable_menu(
        commands,
        header=f"Enter/←/→/\\=fold | v=options | ?=preview | q=quit\n{get_preview_header_suffix()}",
        prompt="Select command: ",
        height="100%",
        preview_cmd=preview_cmd,
        preview_window="right,60%,wrap",
        options_provider=get_options,
    )

    if not selected:
        return None

    # Don't try to "run" general help
    if selected == "(general)":
        return None
    # For subcommands, return the parent command
    if selected == "export prep":
        return "export"
    if selected == "setup shell":
        return "setup"
    if selected == "repos status":
        return "repos"

    return selected


def fzf_pick_range(repo: str, branch: str, default_range: Optional[str] = None,
                   prev_range: Optional[str] = None, max_entries: int = 100,
                   prev_was_skip: bool = False) -> Optional[str]:
    """
    Use fzf to interactively select a commit range.
    Returns a git range string like 'abc123^..def456', or:
    - None if cancelled (Escape)
    - "SKIP" if user wants to skip this repo
    - "SKIP_REST" if user wants to skip all remaining repos
    - "USE_DEFAULT" to use the default range (all local commits)
    - "USE_PREVIOUS" to use the previous range

    If prev_was_skip is True, the skip option is shown first as the default.
    """
    # Only show commits not in origin (local commits)
    remote_ref = f"origin/{branch}"
    remote_exists = subprocess.run(
        ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0

    try:
        if remote_exists:
            # Show only commits not in origin
            log_output = subprocess.check_output(
                ["git", "-C", repo, "log", "--oneline", "--decorate", f"{remote_ref}..HEAD"],
                text=True,
            )
        else:
            # No remote, show recent commits
            log_output = subprocess.check_output(
                ["git", "-C", repo, "log", "--oneline", "--decorate", f"-n{max_entries}"],
                text=True,
            )
    except subprocess.CalledProcessError:
        return None

    if not log_output.strip():
        print(f"{repo}: no local commits to export.")
        return "SKIP"

    # Count local commits
    local_count = len(log_output.strip().splitlines())

    # Build menu with options at top
    menu_lines = []

    skip_line = "►► Skip this repo (s)"
    skip_all_line = "── [S] Skip all remaining repos ──"

    # If previously skipped, show skip as first option (default)
    if prev_was_skip:
        menu_lines.append(skip_line)

    # Add "use previous" option if we have a previous range from last export
    if prev_range and prev_range != default_range:
        menu_lines.append(f"►► Use previous: {prev_range}")

    # Add "include all" option
    if remote_exists:
        menu_lines.append(f"►► Include all {local_count} local commits ({remote_ref}..HEAD)")
    else:
        menu_lines.append(f"►► Include all {local_count} commits")

    # If not previously skipped, show skip after include options
    if not prev_was_skip:
        menu_lines.append(skip_line)
    menu_lines.append(skip_all_line)

    menu_input = "\n".join(menu_lines) + "\n" + log_output

    header = f"repo: {repo}  branch: {branch}\n"
    header += "Space=range | Tab=single | s=skip | S=skip all | Enter=confirm"

    # Temp file for tracking range markers (consistent with prep command)
    range_file = f"/tmp/fzf_range_{os.getpid()}"
    if os.path.exists(range_file):
        os.remove(range_file)

    # Shell script to build prompt showing range marker count
    prompt_script = (
        f'rng=; '
        f'[ -f {range_file} ] && {{ n=$(wc -l < {range_file}); [ "$n" -gt 0 ] && rng="[range:$n]"; }}; '
        f'echo "Select$rng: "'
    )

    try:
        result = subprocess.run(
            [
                "fzf",
                "--multi",
                "--no-sort",
                "--height", "~50%",  # Inline, fit content up to 50% of terminal
                "--header", header,
                "--prompt", "Select: ",
                "--color", "header:italic",
                # Space binding has complex action - preserved as custom
                "--bind", f"space:toggle+execute-silent(echo {{}} >> {range_file})+transform-prompt({prompt_script})+down",  # Space marks range
            ] + get_toggle_binding() +  # Tab for single commit toggle
            get_action_binding("s", "SKIP_THIS") +  # Shortcut for skip
            get_action_binding("S", "SKIP_REST") +  # Shortcut for skip all
            get_fzf_color_args(),
            input=menu_input,
            stdout=subprocess.PIPE,  # Capture selection output
            # Don't capture stderr - let fzf render to terminal
            text=True,
        )
    except FileNotFoundError:
        if os.path.exists(range_file):
            os.remove(range_file)
        return None

    # Clean up range file
    if os.path.exists(range_file):
        os.remove(range_file)

    if result.returncode != 0 or not result.stdout.strip():
        # Escape pressed or no selection
        return None

    selected = result.stdout.strip().splitlines()
    if not selected:
        return None

    # Check for shortcut keys and menu options
    for sel in selected:
        if sel.strip() == "SKIP_THIS":
            return "SKIP"
        if sel.strip() == "SKIP_REST":
            return "SKIP_REST"
        if "Use previous:" in sel:
            return "USE_PREVIOUS"
        if "Include all" in sel:
            return "USE_DEFAULT"
        if "Skip this repo" in sel:
            return "SKIP"
        if "Skip all remaining" in sel:
            return "SKIP_REST"

    # Extract commit hashes from selected lines
    log_lines = log_output.strip().splitlines()
    hash_to_pos = {}
    for i, line in enumerate(log_lines):
        parts = line.split(maxsplit=1)
        if parts:
            hash_to_pos[parts[0]] = i

    commits = []
    for line in selected:
        parts = line.split(maxsplit=1)
        if parts and parts[0] in hash_to_pos:
            commits.append(parts[0])

    if not commits:
        return None

    if len(commits) == 1:
        # Single commit selected
        return f"{commits[0]}^..{commits[0]}"

    # Multiple commits - sort by position (lower = newer in git log)
    commits_sorted = sorted(commits, key=lambda c: hash_to_pos.get(c, 0))
    newest = commits_sorted[0]
    oldest = commits_sorted[-1]
    return f"{oldest}^..{newest}"


def prepare_target_dir(target: str, force: bool) -> None:
    if not os.path.exists(target):
        os.makedirs(target, exist_ok=True)
        return

    if not os.path.isdir(target):
        sys.exit(f"Target path '{target}' exists and is not a directory.")

    existing = os.listdir(target)
    if existing and force:
        for entry in existing:
            entry_path = os.path.join(target, entry)
            if os.path.isdir(entry_path):
                shutil.rmtree(entry_path)
            else:
                os.remove(entry_path)
    elif existing and not force:
        # Prompt user to clear directory
        print(f"Target directory '{target}' contains {len(existing)} file(s).")
        choice = input("Remove existing files? [y/N]: ").strip().lower()
        if choice == 'y':
            for entry in existing:
                entry_path = os.path.join(target, entry)
                if os.path.isdir(entry_path):
                    shutil.rmtree(entry_path)
                else:
                    os.remove(entry_path)
            print(f"Cleared {len(existing)} file(s) from {target}")
        else:
            sys.exit("Aborted.")


def prompt_export(repo: str, layer: str, info: Tuple[Optional[str], bool, str, int, str, str], default_include: bool, display_name: str = None) -> Tuple[bool, bool]:
    branch, remote_exists, remote_ref, count, _range, desc = info
    name = display_name or repo
    if count == 0:
        print(f"{name}: no local commits to export.")
        return False, False
    if not branch:
        print(f"{name}: detached HEAD; skipping.")
        return False, False

    default_hint = "Y/n" if default_include else "y/N"
    prompt = f"Include {name} ({repo}) [{desc}, {count} commits]? ({default_hint}, S=skip rest) "
    resp = input(prompt).strip()
    if not resp:
        return default_include, False
    if resp == "S":
        return False, True
    if resp.lower().startswith("y"):
        return True, False
    if resp.lower() in {"n", "s"}:
        return False, False
    return default_include, False


# ------------------------ Commands ------------------------


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard using available clipboard tool. Returns True on success."""
    import shutil

    # Try different clipboard commands
    clipboard_cmds = [
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"],
        ["pbcopy"],  # macOS
    ]

    for cmd in clipboard_cmds:
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, input=text, text=True, check=True)
                return True
            except subprocess.CalledProcessError:
                continue
    return False



def find_repo_by_identifier(repos: List[str], identifier: str, defaults: Dict[str, str]) -> Optional[str]:
    """
    Find a repo by index, display name, path, or partial match.
    Returns the repo path or None if not found.
    """
    # Try as index
    try:
        idx = int(identifier)
        if 1 <= idx <= len(repos):
            return repos[idx - 1]
        return None
    except ValueError:
        pass

    # Try matching by display name (case-insensitive)
    for repo in repos:
        if repo_display_name(repo).lower() == identifier.lower():
            return repo

    # Try as absolute/relative path
    if os.path.isdir(identifier):
        abs_path = os.path.abspath(identifier)
        if abs_path in repos:
            return abs_path

    # Try partial path match
    for repo in repos:
        if identifier in repo or repo.endswith(identifier):
            return repo

    return None




def export_single_patch(repo: str, commit: str, target_dir: str = ".") -> Optional[str]:
    """Export a single commit as a .patch file using git format-patch. Returns full path or None on error."""
    try:
        # Use git format-patch to create file with standard naming (0001-subject.patch)
        output = subprocess.check_output(
            ["git", "-C", repo, "format-patch", "-1", commit, "-o", target_dir],
            text=True,
        ).strip()
        # git format-patch outputs the created filename
        return output
    except subprocess.CalledProcessError:
        return None


def export_commits_from_explore(repo: str, commits: List[str]) -> None:
    """Export one or more commits as patch files. Prompts for directory if multiple."""
    if not commits:
        return

    # Get current directory for display
    cwd = os.getcwd()

    if len(commits) == 1:
        # Single commit - export to current directory
        print(f"\nExporting to {cwd}...")
        filepath = export_single_patch(repo, commits[0], cwd)
        if filepath:
            print(f"  {os.path.basename(filepath)}")
        else:
            print(f"  Failed to export {commits[0][:8]}")
        input("Press Enter to continue...")
        return

    # Multiple commits - prompt for target directory
    print(f"\nExporting {len(commits)} commits...")
    try:
        default_target = os.path.expanduser("~/patches")
        target_dir = input(f"Target directory [{default_target}]: ").strip()
        if not target_dir:
            target_dir = default_target
        target_dir = os.path.expanduser(target_dir)
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        return

    # Create directory if needed
    os.makedirs(target_dir, exist_ok=True)

    print(f"Exporting to {target_dir}...")

    # Export each commit using git format-patch (standard naming)
    exported = []
    for i, commit in enumerate(commits, 1):
        try:
            # Use git format-patch with start-number for proper sequencing
            output = subprocess.check_output(
                ["git", "-C", repo, "format-patch", "-1", commit, "-o", target_dir,
                 f"--start-number={i}"],
                text=True,
            ).strip()
            exported.append(os.path.basename(output))
            print(f"  {os.path.basename(output)}")
        except subprocess.CalledProcessError as e:
            print(f"  Failed: {commit[:8]}")

    print(f"Exported {len(exported)} patch(es)")
    input("Press Enter to continue...")
