#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Config command - view and configure repo/layer settings."""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Dict, List, Optional, Set, Tuple

from ..core import (
    Colors,
    current_branch,
    current_head,
    export_settings,
    fzf_available,
    get_custom_command,
    get_fzf_preview_resize_bindings,
    git_toplevel,
    import_settings,
    is_custom_default,
    load_defaults,
    repo_is_clean,
    save_defaults,
    FZF_THEMES,
    FZF_TEXT_COLORS,
    get_current_theme_name,
    get_current_text_color_name,
    get_fzf_color_args,
    get_custom_colors,
    fzf_theme_picker,
    fzf_text_color_picker,
    fzf_custom_color_menu,
    TERMINAL_COLOR_ELEMENTS,
    ANSI_COLORS,
    get_terminal_color,
    set_terminal_color,
    terminal_color,
    COLOR_MODES,
    get_color_mode,
    set_color_mode,
    _get_global_colors_file,
)
from .projects import (
    get_directory_browser,
    set_directory_browser,
    _pick_directory_browser,
    get_git_viewer,
    set_git_viewer,
    _pick_git_viewer,
    get_preview_layout,
    set_preview_layout,
    _pick_preview_layout,
    get_recipe_use_bitbake_layers,
    set_recipe_use_bitbake_layers,
    _pick_recipe_use_bitbake_layers,
    get_nnn_colors,
    set_nnn_colors,
    get_editor,
    set_editor,
    resolve_editor,
)
from .common import (
    resolve_bblayers_path,
    resolve_base_and_layers,
    extract_layer_paths,
    collect_repos,
    repo_display_name,
    layer_display_name,
    get_push_target,
    set_push_target,
    remove_push_target,
    add_extra_repo,
    add_hidden_repo,
    remove_hidden_repo,
    get_hidden_repos,
    discover_layers,
    discover_git_repos,
    add_layer_to_bblayers,
    remove_layer_from_bblayers,
    build_layer_collection_map,
    get_upstream_count_ls_remote,
    build_inline_dialog_lines,
)
from ..tui import (
    ExploreMenuState,
    text_input_dialog,
    confirm_action_dialog,
)
from ..fzf_bindings import (
    get_exit_bindings,
    get_position_binding,
    get_preview_header_suffix,
    get_preview_scroll_bindings,
    get_accept_binding,
    get_action_binding,
)

def run_config_edit(args) -> int:
    """Edit a layer's layer.conf file in $EDITOR."""
    pairs, _repo_sets = resolve_base_and_layers(args.bblayers)
    layers = [layer for layer, repo in pairs]

    # Find the target layer by index, name, or path
    target_layer = None
    try:
        idx = int(args.layer)
        if 1 <= idx <= len(layers):
            target_layer = layers[idx - 1]
        else:
            print(f"Invalid index {idx}. Valid range: 1-{len(layers)}")
            return 1
    except ValueError:
        # Try matching by layer name (directory name)
        for layer in layers:
            if layer_display_name(layer).lower() == args.layer.lower():
                target_layer = layer
                break
        # Then try as path
        if not target_layer and os.path.isdir(args.layer):
            target_layer = os.path.abspath(args.layer)
        # Finally try partial path match
        if not target_layer:
            for layer in layers:
                if args.layer in layer or layer.endswith(args.layer):
                    target_layer = layer
                    break

    if not target_layer:
        print(f"Layer not found: {args.layer}")
        print("\nAvailable layers:")
        for idx, layer in enumerate(layers, start=1):
            print(f"  {idx}. {layer_display_name(layer)}: {layer}")
        return 1

    # Find layer.conf
    layer_conf = os.path.join(target_layer, "conf", "layer.conf")
    if not os.path.isfile(layer_conf):
        print(f"layer.conf not found: {layer_conf}")
        return 1

    editor = resolve_editor()

    print(f"Editing: {layer_conf}")
    try:
        subprocess.run([editor, layer_conf], check=True)
        return 0
    except subprocess.CalledProcessError as e:
        print(f"Editor exited with code {e.returncode}")
        return e.returncode
    except FileNotFoundError:
        print(f"Editor not found: {editor}")
        print("Configure via 'bit settings' or set $EDITOR")
        return 1



def _get_settings_registry() -> dict:
    """Return registry of configurable global settings.

    Each entry maps a key name to (getter, setter, description).
    Getters return str; setters accept str.
    """
    from .ssh_remote import get_tmux_prefix, set_tmux_prefix

    def _get_recipe_scan():
        return "bitbake-layers" if get_recipe_use_bitbake_layers() else "file-scan"

    def _set_recipe_scan(v):
        set_recipe_use_bitbake_layers(v in ("bitbake-layers", "true", "1", "yes"))

    return {
        "browser": (get_directory_browser, set_directory_browser,
                     "Directory browser (auto, broot, ranger, nnn, fzf)"),
        "git-viewer": (get_git_viewer, set_git_viewer,
                        "Git viewer (auto, tig, lazygit, gitk)"),
        "preview-layout": (get_preview_layout, set_preview_layout,
                            "Preview pane position (down, right, up)"),
        "recipe-scan": (_get_recipe_scan, _set_recipe_scan,
                         "Recipe scan method (bitbake-layers, file-scan)"),
        "tmux-prefix": (get_tmux_prefix, set_tmux_prefix,
                         "Tmux prefix key for remote sessions (e.g. C-a, C-b)"),
    }


def run_config(args) -> int:
    # Handle 'set' command: config set <key> <value>
    if args.repo == "set":
        registry = _get_settings_registry()
        key = args.extra_arg
        value = getattr(args, "value_arg", None)
        if not key:
            print("Usage: bit config set <key> <value>")
            print(f"\nAvailable keys:")
            for name, (getter, _, desc) in sorted(registry.items()):
                print(f"  {name:20s} {desc}")
                print(f"  {' ':20s} current: {getter()}")
            return 1
        if key not in registry:
            print(f"Unknown setting: {key}")
            print(f"Available: {', '.join(sorted(registry))}")
            return 1
        if not value:
            getter, _, desc = registry[key]
            print(f"{key} = {getter()}")
            print(f"  {desc}")
            return 0
        _, setter, _ = registry[key]
        setter(value)
        print(f"{key} = {value}")
        return 0

    # Handle 'get' command: config get <key>
    if args.repo == "get":
        registry = _get_settings_registry()
        key = args.extra_arg
        if not key:
            for name, (getter, _, desc) in sorted(registry.items()):
                print(f"{name:20s} {getter()}")
            return 0
        if key not in registry:
            print(f"Unknown setting: {key}")
            print(f"Available: {', '.join(sorted(registry))}")
            return 1
        getter, _, _ = registry[key]
        print(getter())
        return 0

    # Handle 'edit' command: config edit <layer>
    if args.repo == "edit":
        if not args.extra_arg:
            print("Usage: bit config edit <layer>")
            print("  layer: index, name, or path")
            return 1
        # Create a mock args object with layer attribute
        class EditArgs:
            pass
        edit_args = EditArgs()
        edit_args.bblayers = args.bblayers
        edit_args.layer = args.extra_arg
        return run_config_edit(edit_args)

    if args.repo == "export-settings":
        export_file = args.extra_arg or "bit-settings.json"
        count = export_settings(args.defaults_file, export_file)
        print(f"Exported {count} setting(s) to {export_file}")
        return 0

    if args.repo == "import-settings":
        if not args.extra_arg:
            import_file = "bit-settings.json"
        else:
            import_file = args.extra_arg
        if not os.path.exists(import_file):
            print(f"File not found: {import_file}")
            return 1
        count = import_settings(import_file, args.defaults_file)
        print(f"Imported {count} setting(s) from {import_file}")
        return 0

    defaults = load_defaults(args.defaults_file)
    repos, _repo_sets = collect_repos(args.bblayers, defaults)

    # If no repo specified, use fzf interactive interface
    if args.repo is None:
        return fzf_config_repos(repos, defaults, args.bblayers, args.defaults_file)

    # Find the target repo by index, display name, or path
    target_repo = None
    try:
        idx = int(args.repo)
        if 1 <= idx <= len(repos):
            target_repo = repos[idx - 1]
        else:
            print(f"Invalid index {idx}. Valid range: 1-{len(repos)}")
            return 1
    except ValueError:
        # Try matching by display name first
        for repo in repos:
            if repo_display_name(repo).lower() == args.repo.lower():
                target_repo = repo
                break
        # Then try as path
        if not target_repo and os.path.isdir(args.repo):
            target_repo = os.path.abspath(args.repo)
        # Finally try partial path match
        if not target_repo:
            for repo in repos:
                if args.repo in repo or repo.endswith(args.repo):
                    target_repo = repo
                    break

    if not target_repo:
        print(f"Repo not found: {args.repo}")
        return 1

    # If -e/--edit specified, open interactive submenu for this repo
    if getattr(args, 'edit', False):
        fzf_repo_config(target_repo, defaults, args.defaults_file)
        return 0

    # If no options specified, show current config for this repo
    if args.display_name is None and args.update_default is None:
        display = repo_display_name(target_repo)
        update_default = defaults.get(target_repo, "rebase")
        push_target = get_push_target(defaults, target_repo)
        print(f"Repo: {target_repo}")
        print(f"Display name: {display}")
        try:
            custom = subprocess.check_output(
                ["git", "-C", target_repo, "config", "--get", "bit.display-name"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
            if custom:
                print("  (custom override)")
            else:
                print("  (auto-detected)")
        except subprocess.CalledProcessError:
            print("  (auto-detected)")
        default_display = f"custom ({get_custom_command(update_default)})" if is_custom_default(update_default) else update_default
        print(f"Update default: {default_display}")
        if push_target:
            print(f"Push target: {push_target.get('push_url', '')}")
            if push_target.get('branch_prefix'):
                print(f"  Branch prefix: {push_target['branch_prefix']}")
        return 0

    # Handle display name changes
    if args.display_name is not None:
        if args.display_name == "":
            # Clear custom name
            try:
                subprocess.run(
                    ["git", "-C", target_repo, "config", "--unset", "bit.display-name"],
                    check=True,
                )
                print(f"Cleared custom display name for {target_repo}")
                print(f"Now using: {repo_display_name(target_repo)}")
            except subprocess.CalledProcessError:
                print(f"No custom display name was set for {target_repo}")
        else:
            subprocess.run(
                ["git", "-C", target_repo, "config", "bit.display-name", args.display_name],
                check=True,
            )
            print(f"Set display name for {target_repo}")
            print(f"  {args.display_name}")

    # Handle update default changes
    if args.update_default is not None:
        val = args.update_default
        if val not in ("rebase", "merge", "skip") and not val.startswith("custom:"):
            print(f"Error: invalid default '{val}'. Use rebase, merge, skip, or custom:<command>")
            return 1
        old_default = defaults.get(target_repo, "rebase")
        defaults[target_repo] = val
        save_defaults(args.defaults_file, defaults)
        old_display = f"custom ({get_custom_command(old_default)})" if is_custom_default(old_default) else old_default
        new_display = f"custom ({get_custom_command(val)})" if is_custom_default(val) else val
        print(f"Set update default for {target_repo}")
        print(f"  {old_display} -> {new_display}")

    return 0



def show_repo_status_detail(repo: str, branch: str) -> None:
    """Show detailed status for a repo (local and upstream commits)."""
    if not branch:
        print("  (detached HEAD)")
        return

    # Local commits
    try:
        local_log = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"origin/{branch}..HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        if local_log:
            lines = local_log.splitlines()
            print(f"  {len(lines)} local commit(s):")
            for line in lines[:10]:
                print(f"    {line}")
            if len(lines) > 10:
                print(f"    ... and {len(lines) - 10} more")
        else:
            print("  No local commits")
    except subprocess.CalledProcessError:
        print("  (could not get local commits)")

    # Upstream commits
    try:
        upstream_log = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"HEAD..origin/{branch}"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        if upstream_log:
            lines = upstream_log.splitlines()
            print(f"  {len(lines)} upstream commit(s) to pull:")
            for line in lines[:5]:
                print(f"    {Colors.YELLOW}{line}{Colors.RESET}")
            if len(lines) > 5:
                print(f"    ... and {len(lines) - 5} more")
        else:
            print("  Up-to-date with upstream")
    except subprocess.CalledProcessError:
        print("  (could not get upstream commits)")

    # Working tree status
    is_clean = repo_is_clean(repo)
    if is_clean:
        print(f"  Working tree: {Colors.green('clean')}")
    else:
        print(f"  Working tree: {Colors.red('DIRTY')}")



def parse_config_variables(conf_path: str) -> List[Tuple[str, int, str]]:
    """
    Parse BitBake config file for variable assignments.
    Handles multi-line continuations (lines ending with backslash).
    Returns: [(var_name, line_number, raw_value), ...]
    """
    if not os.path.isfile(conf_path):
        return []

    results = []
    seen_vars = set()  # Track seen variable names to deduplicate
    # Match variable assignments: VAR = "...", VAR += "...", VAR:append = "...", etc.
    var_pattern = re.compile(r'^([A-Z_][A-Z0-9_]*(?::[a-z_]+)?)\s*[\?\+\.]*=')

    try:
        with open(conf_path, "r") as f:
            lines = f.readlines()

        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                i += 1
                continue

            match = var_pattern.match(stripped)
            if match:
                var_name = match.group(1)
                start_line = i + 1  # 1-indexed

                # Extract value (everything after the = sign)
                eq_pos = stripped.find("=")
                value_parts = [stripped[eq_pos + 1:].strip()]

                # Handle line continuations (ending with \)
                while value_parts[-1].endswith("\\") and i + 1 < len(lines):
                    i += 1
                    cont_line = lines[i].strip()
                    # Remove trailing \ from previous part
                    value_parts[-1] = value_parts[-1][:-1].strip()
                    value_parts.append(cont_line)

                # Combine all parts
                full_value = " ".join(value_parts)
                # Clean up quotes and whitespace
                full_value = full_value.strip().strip('"').strip("'").strip()

                # Only add if we haven't seen this variable (deduplicate)
                if var_name not in seen_vars:
                    seen_vars.add(var_name)
                    # Truncate for display
                    display_value = full_value
                    if len(display_value) > 50:
                        display_value = display_value[:47] + "..."
                    results.append((var_name, start_line, display_value))

            i += 1
    except (IOError, OSError):
        pass

    return results



def fzf_build_config(bblayers_path: Optional[str] = None) -> None:
    """Show config menu for project conf files (local.conf, bblayers.conf)."""
    # Find conf directory
    bblayers_conf = resolve_bblayers_path(bblayers_path)
    if not bblayers_conf:
        print("\nCould not find bblayers.conf")
        input("Press Enter to continue...")
        return

    conf_dir = os.path.dirname(bblayers_conf)
    local_conf = os.path.join(conf_dir, "local.conf")

    # Track which files are expanded
    expanded_files: Set[str] = set()
    # Cache parsed variables
    var_cache: Dict[str, List[Tuple[str, int, str]]] = {}
    # Cache for bitbake-getvar results
    getvar_cache: Dict[str, str] = {}

    def get_variables(conf_path: str) -> List[Tuple[str, int, str]]:
        """Get cached variables for a config file."""
        if conf_path not in var_cache:
            var_cache[conf_path] = parse_config_variables(conf_path)
        return var_cache[conf_path]

    # Calculate max variable name length for alignment
    def get_max_var_len() -> int:
        max_len = 0
        for conf_path in [bblayers_conf, local_conf]:
            if conf_path in expanded_files:
                for var_name, _, _ in get_variables(conf_path):
                    max_len = max(max_len, len(var_name))
        return max_len

    # Create temp files for preview script and getvar cache
    getvar_cache_file = os.path.join(tempfile.gettempdir(), f"bit-getvar-{os.getpid()}.txt")
    preview_script_file = os.path.join(tempfile.gettempdir(), f"bit-preview-{os.getpid()}.sh")

    # Write preview script once (content doesn't change)
    with open(preview_script_file, "w") as f:
        f.write(f'''#!/bin/bash
item="$1"
cache_file="{getvar_cache_file}"
if [[ "$item" == VAR:* ]]; then
    var_name=$(echo "$item" | cut -d: -f2)
    file_path=$(echo "$item" | cut -d: -f3-)
    line_num="${{file_path##*:}}"
    file_path="${{file_path%:*}}"
    # Check if we have cached getvar output for this variable
    if [ -f "$cache_file" ]; then
        cached_var=$(head -1 "$cache_file" 2>/dev/null)
        if [ "$cached_var" = "$var_name" ]; then
            echo -e "\\033[1;36mbitbake-getvar $var_name\\033[0m"
            echo
            tail -n +2 "$cache_file"
            exit 0
        fi
    fi
    # Show value from file (15 lines to capture multi-line values)
    echo -e "\\033[1m$var_name\\033[0m (line $line_num)"
    echo
    [ -f "$file_path" ] && sed -n "${{line_num}},$((line_num + 14))p" "$file_path"
else
    file_path="${{item#FILE:}}"
    [ -f "$file_path" ] && head -40 "$file_path"
fi
''')
    os.chmod(preview_script_file, 0o755)
    preview_cmd = f"{preview_script_file} {{1}}"

    next_selection = None  # Track item to select after operations
    try:
        while True:
            menu_lines = []
            max_var_len = get_max_var_len()

            # bblayers.conf entry
            bblayers_vars = get_variables(bblayers_conf)
            expand_marker = "+ " if bblayers_vars and bblayers_conf not in expanded_files else "  "
            if bblayers_conf in expanded_files:
                expand_marker = "- "
            menu_lines.append(f"FILE:{bblayers_conf}\t{expand_marker}Edit bblayers.conf  conf/bblayers.conf")

            # Expanded variables for bblayers.conf
            if bblayers_conf in expanded_files:
                for i, (var_name, line_num, raw_value) in enumerate(bblayers_vars):
                    is_last = (i == len(bblayers_vars) - 1)
                    prefix = "  └─ " if is_last else "  ├─ "
                    # Show VAR = value aligned with colors
                    padded_name = f"{var_name:<{max_var_len}}"
                    display_value = raw_value if raw_value else '""'
                    if len(display_value) > 40:
                        display_value = display_value[:37] + "..."
                    colored_name = Colors.cyan(padded_name)
                    colored_value = Colors.green(display_value)
                    menu_lines.append(f"VAR:{var_name}:{bblayers_conf}:{line_num}\t{prefix}{colored_name} = {colored_value}")

            # local.conf entry
            if os.path.isfile(local_conf):
                local_vars = get_variables(local_conf)
                expand_marker = "+ " if local_vars and local_conf not in expanded_files else "  "
                if local_conf in expanded_files:
                    expand_marker = "- "
                menu_lines.append(f"FILE:{local_conf}\t{expand_marker}Edit local.conf     conf/local.conf")

                # Expanded variables for local.conf
                if local_conf in expanded_files:
                    for i, (var_name, line_num, raw_value) in enumerate(local_vars):
                        is_last = (i == len(local_vars) - 1)
                        prefix = "  └─ " if is_last else "  ├─ "
                        padded_name = f"{var_name:<{max_var_len}}"
                        display_value = raw_value if raw_value else '""'
                        if len(display_value) > 40:
                            display_value = display_value[:37] + "..."
                        colored_name = Colors.cyan(padded_name)
                        colored_value = Colors.green(display_value)
                        menu_lines.append(f"VAR:{var_name}:{local_conf}:{line_num}\t{prefix}{colored_name} = {colored_value}")
            else:
                menu_lines.append(f"FILE:{local_conf}\t  Edit local.conf     (not found)")

            header = f"Project config | Enter/→=fold/edit | \\=fold | r=bitbake-getvar | S=shell | q/←=back\n{get_preview_header_suffix()}"

            try:
                fzf_cmd = [
                    "fzf",
                    "--ansi",
                    "--no-multi",
                    "--no-sort",
                    "--layout=reverse-list",
                    "--height", "50%",
                    "--header", header,
                    "--prompt", "Select: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--preview", preview_cmd,
                    "--preview-window", "right:60%:wrap",
                    "--bind", "b:become(echo FILE:" + bblayers_conf + ")",
                    "--bind", "l:become(echo FILE:" + local_conf + ")",
                    "--bind", "\\:become(echo EXPAND {1})",
                    "--bind", "r:become(echo GETVAR {1})",
                    "--bind", "S:become(echo SHELL)",
                    "--bind", "right:become(echo RIGHT {1})",
                ] + get_exit_bindings(mode="back") + [
                    "--bind", "left:become(echo LEFT {1})",  # Override left from exit bindings
                ] + get_preview_scroll_bindings(include_half_page=False) + get_fzf_preview_resize_bindings() + get_fzf_color_args()

                # Jump to selected item's position if we have one
                if next_selection:
                    for i, line in enumerate(menu_lines):
                        if line.startswith(next_selection + "\t"):
                            fzf_cmd.extend(["--sync", "--bind", f"load:pos({i + 1})"])
                            break
                    next_selection = None

                result = subprocess.run(
                    fzf_cmd,
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                print("fzf not found")
                return

            if result.returncode != 0 or not result.stdout.strip():
                break

            output = result.stdout.strip()

            if output == "BACK":
                break
            elif output == "SHELL":
                from .setup import run_init_shell
                ns = argparse.Namespace(layers_dir="layers")
                run_init_shell(ns)
                continue
            elif output.startswith("EXPAND "):
                # Toggle expansion of a file
                item = output[7:].strip()
                if item.startswith("FILE:"):
                    file_path = item[5:]
                    if file_path in expanded_files:
                        expanded_files.discard(file_path)
                    else:
                        expanded_files.add(file_path)
                elif item.startswith("VAR:"):
                    # Expanding on a variable - expand its parent file
                    parts = item.split(":")
                    if len(parts) >= 3:
                        file_path = ":".join(parts[2:-1])  # Handle paths with colons
                        if file_path in expanded_files:
                            expanded_files.discard(file_path)
                        else:
                            expanded_files.add(file_path)
                continue
            elif output.startswith("GETVAR "):
                # Run bitbake-getvar for a variable and cache result for preview
                item = output[7:].strip()
                if item.startswith("VAR:"):
                    parts = item.split(":")
                    if len(parts) >= 2:
                        var_name = parts[1]
                        # Check if bitbake-getvar is available
                        if not shutil.which("bitbake-getvar"):
                            print(f"\nbitbake-getvar not found in PATH.")
                            print("Source oe-init-build-env first to enable this feature.")
                            input("Press Enter to continue...")
                            continue
                        print(f"\nRunning: bitbake-getvar {var_name}...")
                        # Write result to cache file for preview
                        with open(getvar_cache_file, "w") as f:
                            f.write(var_name + "\n")
                        try:
                            getvar_result = subprocess.run(
                                ["bitbake-getvar", var_name],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT,
                                text=True,
                            )
                            with open(getvar_cache_file, "a") as f:
                                f.write(getvar_result.stdout)
                            # Jump back to this item so preview shows the result
                            next_selection = item
                            if getvar_result.returncode != 0:
                                print(f"Error: {getvar_result.stdout}")
                                input("Press Enter to continue...")
                        except FileNotFoundError:
                            print(f"\nbitbake-getvar not found.")
                            input("Press Enter to continue...")
                continue
            elif output.startswith("LEFT "):
                # Left arrow: collapse if expanded, back otherwise
                item = output[5:].strip()
                if item.startswith("FILE:"):
                    file_path = item[5:]
                    if file_path in expanded_files:
                        expanded_files.discard(file_path)
                        continue
                elif item.startswith("VAR:"):
                    # On a variable - collapse its parent file
                    parts = item.split(":")
                    if len(parts) >= 3:
                        file_path = ":".join(parts[2:-1])
                        if file_path in expanded_files:
                            expanded_files.discard(file_path)
                            continue
                # Not expanded or not a file - back
                break
            elif output.startswith("RIGHT "):
                # Right arrow: expand if expandable FILE:, otherwise accept
                item = output[6:].strip()
                if item.startswith("FILE:"):
                    file_path = item[5:]
                    if file_path not in expanded_files:
                        # Not expanded yet - expand it
                        expanded_files.add(file_path)
                        continue
                    # Already expanded - fall through to edit
                    output = item  # Rewrite as FILE: for handling below
                elif item.startswith("VAR:"):
                    output = item  # Rewrite as VAR: for handling below
                else:
                    continue
                via_right = True
            else:
                via_right = False
            if output.startswith("FILE:"):
                file_path = output.split("\t")[0][5:]
                if not via_right and file_path not in expanded_files:
                    # Enter on collapsed FILE: expands it
                    expanded_files.add(file_path)
                    continue
                if not via_right and file_path in expanded_files:
                    # Enter on expanded FILE: opens editor (same as Right)
                    pass  # fall through to editor launch below
                # RIGHT on already-expanded FILE: or Enter on expanded - edit
                if os.path.isfile(file_path):
                    editor = resolve_editor()
                    subprocess.run([editor, file_path])
                    # Clear cache after editing
                    var_cache.pop(file_path, None)
                else:
                    print(f"\nFile not found: {file_path}")
                    input("Press Enter to continue...")
            elif output.startswith("VAR:"):
                # Open editor at specific line - extract first field before tab
                first_field = output.split("\t")[0]
                parts = first_field.split(":")
                if len(parts) >= 4:
                    var_name = parts[1]
                    line_num = parts[-1]
                    file_path = ":".join(parts[2:-1])
                    if os.path.isfile(file_path):
                        editor = resolve_editor()
                        # Most editors support +line syntax
                        subprocess.run([editor, f"+{line_num}", file_path])
                        # Clear cache after editing
                        var_cache.pop(file_path, None)
    finally:
        # Cleanup temp files
        for tmp_file in [getvar_cache_file, preview_script_file]:
            if os.path.exists(tmp_file):
                try:
                    os.unlink(tmp_file)
                except OSError:
                    pass



def fzf_repo_config(
    repo: str,
    defaults: Dict[str, str],
    defaults_file: str,
) -> None:
    """Show config submenu for a single repo (standalone version for explore)."""
    dialog_state = ExploreMenuState()

    # Track state for two-step push target dialog
    pending_push_url: Optional[str] = None

    def get_display_name() -> Tuple[str, bool]:
        """Get display name and whether it's custom."""
        display = repo_display_name(repo)
        is_custom = False
        try:
            with open(defaults_file, "r") as f:
                for line in f:
                    if line.startswith(f"display:{repo}="):
                        is_custom = True
                        break
        except FileNotFoundError:
            pass
        return display, is_custom

    def pick_update_default() -> None:
        """Show submenu to pick update default."""
        display, _ = get_display_name()
        current = defaults.get(repo, "rebase")
        current_for_radio = "custom" if is_custom_default(current) else current

        options = [
            ("rebase", "Rebase local commits on top of upstream"),
            ("merge", "Merge upstream into local branch"),
            ("skip", "Skip this repo during updates"),
            ("custom", "Run a custom shell command"),
        ]

        menu_lines = []
        for opt, desc in options:
            marker = "●" if opt == current_for_radio else "○"
            label = opt
            if opt == "custom" and is_custom_default(current):
                label = f"custom ({get_custom_command(current)})"
            menu_lines.append(f"{opt}\t{marker} {label:<8} {desc}")

        header = f"Update default for {display}"

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--height", "~9",
                    "--header", header,
                    "--prompt", "Select: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        # Extract option from first field
        selected = output.split("\t")[0]
        if selected in ("rebase", "merge", "skip"):
            save_default(defaults_file, repo, selected)
            defaults[repo] = selected
        elif selected == "custom":
            # Show text input to capture custom command
            prefill = get_custom_command(current) if is_custom_default(current) else ""
            try:
                cmd_result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--height", "~4",
                        "--header", f"Custom command for {display}  Esc=cancel",
                        "--prompt", "Command: ",
                        "--disabled",
                        "--print-query",
                        "--query", prefill,
                    ] + get_fzf_color_args(),
                    input="",
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return
            if cmd_result.returncode != 0:
                return
            lines = cmd_result.stdout.strip().split("\n")
            custom_cmd = lines[0].strip() if lines else ""
            if custom_cmd:
                new_val = f"custom:{custom_cmd}"
                save_default(defaults_file, repo, new_val)
                defaults[repo] = new_val

    def edit_layer_conf() -> None:
        """Edit layer.conf for this repo."""
        # Find layer.conf files in this repo
        layer_confs = []
        for root, dirs, files in os.walk(repo):
            # Don't descend into .git
            if ".git" in dirs:
                dirs.remove(".git")
            if "layer.conf" in files:
                conf_path = os.path.join(root, "conf", "layer.conf")
                if os.path.isfile(conf_path):
                    layer_confs.append(conf_path)
                else:
                    # Check if it's directly in conf/
                    parent = os.path.dirname(root)
                    if os.path.basename(root) == "conf":
                        layer_confs.append(os.path.join(root, "layer.conf"))

        if not layer_confs:
            # Try standard location
            for item in os.listdir(repo):
                conf_path = os.path.join(repo, item, "conf", "layer.conf")
                if os.path.isfile(conf_path):
                    layer_confs.append(conf_path)

        if not layer_confs:
            print(f"\nNo layer.conf found in {repo}")
            input("Press Enter to continue...")
            return

        if len(layer_confs) == 1:
            editor = resolve_editor()
            subprocess.run([editor, layer_confs[0]])
        else:
            # Multiple - let user pick
            menu = "\n".join(layer_confs)
            try:
                result = subprocess.run(
                    ["fzf", "--height", "~10", "--header", "Select layer.conf to edit"] + get_fzf_color_args(),
                    input=menu,
                    stdout=subprocess.PIPE,
                    text=True,
                )
                if result.returncode == 0 and result.stdout.strip():
                    editor = resolve_editor()
                    subprocess.run([editor, result.stdout.strip()])
            except FileNotFoundError:
                pass

    while True:
        display, is_custom = get_display_name()
        update_default = defaults.get(repo, "rebase")
        has_dialog = dialog_state.has_dialog()

        display_suffix = " (custom)" if is_custom else " (auto)"
        push_target_data = get_push_target(defaults, repo)
        push_status = push_target_data.get("push_url", "")[:40] if push_target_data else "(not configured)"
        default_display = f"custom ({get_custom_command(update_default)})" if is_custom_default(update_default) else update_default
        menu_lines = [
            f"DISPLAY\tDisplay name     {display}{display_suffix}",
            f"DEFAULT\tUpdate default   {default_display}",
            f"PUSH\tPush target      {push_status}",
            f"EDIT\tEdit layer.conf  →",
        ]

        # Build menu input
        menu_input = "\n".join(menu_lines)

        # Prepend dialog items if active
        if has_dialog:
            dialog_lines = dialog_state.get_dialog_menu_lines()
            dialog_input = "\n".join(f"{value}\t{display}" for value, display in dialog_lines)
            menu_input = dialog_input + "\n" + menu_input
            current_header = "Complete dialog above | Esc=cancel"
            current_prompt = dialog_state.get_prompt_text() or "Input: "
        else:
            current_header = f"Configure {display} ({repo})"
            current_prompt = "Select: "

        fzf_cmd = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~12",
            "--header", current_header,
            "--prompt", current_prompt,
            "--with-nth", "2..",
            "--delimiter", "\t",
        ] + get_fzf_color_args()

        if has_dialog:
            fzf_cmd.extend(["--print-query", "--bind", "esc:abort"])
        else:
            fzf_cmd.extend(get_exit_bindings(mode="back") + get_accept_binding())

        try:
            result = subprocess.run(
                fzf_cmd,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            if has_dialog:
                dialog_state.clear_dialog()
                continue
            return

        # Parse output based on dialog mode
        if has_dialog:
            lines = result.stdout.split("\n")
            query = lines[0] if lines else ""
            output = lines[1].strip() if len(lines) > 1 else ""

            # Handle dialog selection
            if dialog_state.is_dialog_selection(output.split("\t")[0] if output else ""):
                dlg_result = dialog_state.handle_dialog_selection(output.split("\t")[0], query)
                if dlg_result.confirmed and dialog_state.active_dialog.on_confirm:
                    dialog_state.active_dialog.on_confirm(dlg_result.value)
                dialog_state.clear_dialog()
                continue
        else:
            output = result.stdout.strip()

        if output == "BACK":
            return
        elif output.startswith("DISPLAY\t"):
            # Show inline dialog for display name
            current_display, _ = get_display_name()

            def on_display_confirm(new_name):
                key = f"display:{repo}"
                if new_name:
                    save_default(defaults_file, key, new_name)
                else:
                    remove_default(defaults_file, key)

            dialog_state.show_dialog(
                text_input_dialog(
                    title="Set display name",
                    message=f"Current: {current_display} | Empty to reset to auto",
                    default=current_display,
                    placeholder="Display name",
                    on_confirm=on_display_confirm,
                )
            )
        elif output.startswith("DEFAULT\t"):
            pick_update_default()
        elif output.startswith("PUSH\t"):
            # Show inline dialog for push URL (first step)
            push_target_data = get_push_target(defaults, repo)
            current_url = push_target_data.get("push_url", "") if push_target_data else ""
            current_prefix = push_target_data.get("branch_prefix", "") if push_target_data else ""

            def on_push_url_confirm(new_url):
                nonlocal pending_push_url
                if not new_url:
                    # Clear push target
                    remove_push_target(defaults_file, defaults, repo)
                else:
                    # Store URL and show prefix dialog
                    pending_push_url = new_url

                    def on_prefix_confirm(new_prefix):
                        nonlocal pending_push_url
                        if pending_push_url:
                            set_push_target(defaults_file, defaults, repo, pending_push_url, new_prefix or "")
                            pending_push_url = None

                    dialog_state.show_dialog(
                        text_input_dialog(
                            title="Branch prefix",
                            message="e.g. 'yourname/' or empty for none",
                            default=current_prefix,
                            placeholder="Prefix",
                            on_confirm=on_prefix_confirm,
                        )
                    )

            dialog_state.show_dialog(
                text_input_dialog(
                    title="Push URL",
                    message=f"Current: {current_url or '(not configured)'} | Empty to clear",
                    default=current_url,
                    placeholder="git@...",
                    on_confirm=on_push_url_confirm,
                )
            )
        elif output.startswith("EDIT\t"):
            edit_layer_conf()



def fzf_project_properties(proj_path: str, projects: dict = None) -> None:
    """Show submenu for editing project-level properties (name, description).

    Can be called from both the config view and the dashboard.
    If *projects* is not provided, loads from disk.
    """
    from .projects import load_projects, save_projects

    if projects is None:
        projects = load_projects()
    info = projects.get(proj_path, {})
    if not info:
        return

    while True:
        cur_name = info.get("name", os.path.basename(proj_path))
        cur_desc = info.get("description", "") or "(none)"

        menu_lines = [
            f"NAME\tName           {cur_name}",
            f"DESC\tDescription    {cur_desc}",
        ]

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--height", "~6",
                    "--header", f"Project properties — {proj_path}",
                    "--prompt", "Select: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        field = output.split("\t")[0]
        if field == "NAME":
            try:
                new_val = input(f"\nProject name [{cur_name}]: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if new_val and new_val != cur_name:
                info["name"] = new_val
                projects[proj_path] = info
                save_projects(projects)
                print(f"  {Colors.green('✓')} Name: {cur_name} → {new_val}")
            else:
                print("  Unchanged.")
        elif field == "DESC":
            try:
                prompt_desc = cur_desc if cur_desc != "(none)" else ""
                new_val = input(f"\nDescription [{prompt_desc}]: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if new_val:
                info["description"] = new_val
                projects[proj_path] = info
                save_projects(projects)
                print(f"  {Colors.green('✓')} Description: {new_val}")
            elif cur_desc != "(none)":
                print("  Unchanged.")


_OPT_PREFIX = "OPT:"

# Pickers that use inline dialog instead of a separate fzf instance
_INLINE_PICKERS = {"BROWSER", "GITVIEWER", "PREVIEW", "RECIPE", "NNN_COLORS", "EDITOR"}


def _build_setting_picker_lines(picker: str) -> Tuple[List[str], int]:
    """Build inline dialog lines for a setting picker.

    Returns:
        (dialog_lines, current_idx) where current_idx is the 0-based index
        of the currently-selected option within the items list.
    """
    if picker == "BROWSER":
        title = "Dir Browser"
        current = get_directory_browser()
        raw_options = [
            ("auto", "Auto-detect (broot > ranger > nnn > fzf)"),
            ("broot", "broot - fuzzy search, type paths directly"),
            ("ranger", "ranger - vim-like file manager"),
            ("nnn", "nnn - fast, minimal file manager"),
            ("fzf", "fzf built-in browser"),
        ]
        items = []
        for value, desc in raw_options:
            marker = "● " if value == current else "  "
            avail = ""
            if value in ("broot", "ranger", "nnn") and not shutil.which(value):
                avail = Colors.dim(" (not installed)")
            items.append((f"{_OPT_PREFIX}{value}", f"{marker}{desc}{avail}"))

    elif picker == "GITVIEWER":
        title = "Git Viewer"
        current = get_git_viewer()
        raw_options = [
            ("auto", "Auto-detect (tig > lazygit > gitk)"),
            ("tig", "tig - ncurses git interface"),
            ("lazygit", "lazygit - terminal UI for git"),
            ("gitk", "gitk - graphical git browser"),
        ]
        items = []
        for value, desc in raw_options:
            marker = "● " if value == current else "  "
            avail = ""
            if value in ("tig", "lazygit", "gitk") and not shutil.which(value):
                avail = Colors.dim(" (not installed)")
            items.append((f"{_OPT_PREFIX}{value}", f"{marker}{desc}{avail}"))

    elif picker == "PREVIEW":
        title = "Preview Layout"
        current = get_preview_layout()
        raw_options = [
            ("down", "Bottom - preview below commit list"),
            ("right", "Right - preview beside commit list (side-by-side)"),
            ("up", "Top - preview above commit list"),
        ]
        items = []
        for value, desc in raw_options:
            marker = "● " if value == current else "  "
            items.append((f"{_OPT_PREFIX}{value}", f"{marker}{desc}"))

    elif picker == "RECIPE":
        title = "Recipe Scan"
        current_bool = get_recipe_use_bitbake_layers()
        current = "true" if current_bool else "false"
        raw_options = [
            ("true", "bitbake-layers - Use bitbake-layers show-recipes (more accurate, slower)"),
            ("false", "File scan - Scan .bb files directly (faster, no bitbake env needed)"),
        ]
        items = []
        for value, desc in raw_options:
            marker = "● " if value == current else "  "
            items.append((f"{_OPT_PREFIX}{value}", f"{marker}{desc}"))

    elif picker == "NNN_COLORS":
        title = "NNN Colors"
        current = get_nnn_colors()
        presets = [
            ("6234", "cyan dirs (default)"),
            ("2234", "green dirs"),
            ("3234", "yellow dirs"),
            ("7234", "white dirs"),
            ("5234", "magenta dirs"),
            ("1234", "red dirs"),
            ("4234", "blue dirs (nnn default)"),
        ]
        items = []
        for value, desc in presets:
            marker = "● " if value == current else "  "
            color_code = {"1": "31", "2": "32", "3": "33", "4": "34",
                          "5": "35", "6": "36", "7": "37"}.get(value[0], "0")
            sample = f"\033[{color_code}m■■■\033[0m"
            items.append((f"{_OPT_PREFIX}{value}", f"{marker}{sample} {desc}"))

    elif picker == "EDITOR":
        title = "Editor"
        current = get_editor()
        raw_options = [
            ("auto", "Auto ($EDITOR / $VISUAL / vi)"),
            ("vim", "vim"),
            ("nvim", "neovim"),
            ("nano", "nano"),
            ("emacs", "emacs"),
            ("code", "VS Code (code --wait)"),
        ]
        items = []
        for value, desc in raw_options:
            marker = "● " if value == current else "  "
            avail = ""
            if value not in ("auto",) and not shutil.which(value):
                avail = Colors.dim(" (not installed)")
            items.append((f"{_OPT_PREFIX}{value}", f"{marker}{desc}{avail}"))
    else:
        return [], 0

    # Find current option index
    current_idx = 0
    for i, (key, _display) in enumerate(items):
        if key[len(_OPT_PREFIX):] == current:
            current_idx = i
            break

    dialog_lines = build_inline_dialog_lines(title, items, reverse_list=True)
    return dialog_lines, current_idx


def _apply_setting(picker: str, value: str) -> None:
    """Apply a setting value from the inline picker."""
    if picker == "BROWSER":
        set_directory_browser(value)
    elif picker == "GITVIEWER":
        set_git_viewer(value)
    elif picker == "PREVIEW":
        set_preview_layout(value)
    elif picker == "RECIPE":
        set_recipe_use_bitbake_layers(value == "true")
    elif picker == "NNN_COLORS":
        set_nnn_colors(value)
    elif picker == "EDITOR":
        set_editor(value)


def fzf_global_settings(defaults_file: str = ".bit.defaults") -> None:
    """Global settings menu for bit tool configuration.

    Accessible from the dashboard and from the config command.
    Covers colors/themes, directory browser, git viewer, preview layout,
    recipe scan, and b4 patch management.
    """
    from ..fzf_bindings import get_exit_bindings, get_accept_binding

    defaults = load_defaults(defaults_file)

    def _resolve_color_file():
        """Resolve the color file based on current mode."""
        mode = get_color_mode(defaults_file)
        if mode == "global":
            return _get_global_colors_file()
        elif mode == "custom":
            return defaults_file
        return None

    def _colors_submenu() -> None:
        """Show colors/theme submenu."""
        while True:
            color_mode = get_color_mode(defaults_file)
            mode_desc = COLOR_MODES.get(color_mode, color_mode)

            if color_mode == "global":
                color_file = _get_global_colors_file()
                header_source = "global (~/.config/bit/colors.json)"
            elif color_mode == "custom":
                color_file = defaults_file
                header_source = "per-project (.bit.defaults)"
            else:
                color_file = None
                header_source = "built-in defaults"

            current_theme = get_current_theme_name(defaults_file)
            theme_desc = FZF_THEMES.get(current_theme, ("", ""))[1]
            custom_colors = get_custom_colors(defaults_file)
            custom_count = len(custom_colors)
            custom_desc = f"{custom_count} override{'s' if custom_count != 1 else ''}" if custom_count else "none"

            terminal_overrides = sum(
                1 for elem in TERMINAL_COLOR_ELEMENTS
                if get_terminal_color(elem, defaults_file) != TERMINAL_COLOR_ELEMENTS[elem][0]
            )
            terminal_desc = f"{terminal_overrides} override{'s' if terminal_overrides != 1 else ''}" if terminal_overrides else "defaults"

            menu_lines = [
                f"MODE\tColor Mode       {color_mode} - {mode_desc}",
                f"THEME\tTheme            {current_theme} - {theme_desc}",
                f"CUSTOM\tIndividual       {custom_desc}",
                f"TERMINAL\tDisplay Colors   {terminal_desc}",
            ]

            header = f"Colors - {header_source} (←/q=back)"

            try:
                result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--height", "~10",
                        "--header", header,
                        "--prompt", "Option: ",
                        "--with-nth", "2..",
                        "--delimiter", "\t",
                    ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return

            if result.returncode != 0 or not result.stdout.strip():
                return

            output = result.stdout.strip()

            if output == "BACK":
                return
            elif output.startswith("MODE\t"):
                _color_mode_picker()
            elif output.startswith("THEME\t"):
                if color_file is None:
                    _color_mode_picker()
                else:
                    fzf_theme_picker(color_file)
            elif output.startswith("CUSTOM\t"):
                if color_file is None:
                    _color_mode_picker()
                else:
                    fzf_custom_color_menu(color_file)
            elif output.startswith("TERMINAL\t"):
                if color_file is None:
                    _color_mode_picker()
                else:
                    _terminal_colors_submenu(color_file)

    def _color_mode_picker() -> None:
        """Show picker for color mode (default/global/custom)."""
        current_mode = get_color_mode(defaults_file)

        menu_lines = []
        for mode, desc in COLOR_MODES.items():
            marker = "● " if mode == current_mode else "  "
            menu_lines.append(f"{mode}\t{marker}{mode:<10} {desc}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--height", "~8",
                    "--header", "Select color mode (←/q=back)",
                    "--prompt", "Mode: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        selected = output.split("\t")[0]
        if selected in COLOR_MODES:
            set_color_mode(selected, defaults_file)

    def _terminal_colors_submenu(color_file: str) -> None:
        """Show terminal output colors submenu."""
        while True:
            menu_lines = []
            for elem, (default_color, desc) in TERMINAL_COLOR_ELEMENTS.items():
                current = get_terminal_color(elem, defaults_file)
                is_default = (current == default_color)
                marker = "  " if is_default else "● "
                ansi_code = ANSI_COLORS.get(current, "\033[33m")
                sample = f"{ansi_code}■■■\033[0m"
                status = f"{current}" if not is_default else f"{current} (default)"
                menu_lines.append(f"{elem}\t{marker}{sample} {desc:<35} {status}")

            try:
                result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--ansi",
                        "--height", "~15",
                        "--header", "Display Colors (←/q=back)\nColors used in dashboard, repos view, and status output",
                        "--prompt", "Element: ",
                        "--with-nth", "2..",
                        "--delimiter", "\t",
                    ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return

            if result.returncode != 0 or not result.stdout.strip():
                return

            output = result.stdout.strip()

            if output == "BACK":
                return

            elem = output.split("\t")[0] if "\t" in output else output
            if elem in TERMINAL_COLOR_ELEMENTS:
                _terminal_color_picker(elem, color_file)

    def _terminal_color_picker(element: str, color_file: str) -> None:
        """Pick a color for a terminal output element."""
        default_color = TERMINAL_COLOR_ELEMENTS[element][0]
        current = get_terminal_color(element, defaults_file)
        desc = TERMINAL_COLOR_ELEMENTS[element][1]

        menu_lines = []
        default_marker = "● " if current == default_color else "  "
        default_ansi = ANSI_COLORS.get(default_color, "\033[33m")
        menu_lines.append(f"(default)\t{default_marker}{default_ansi}■■■\033[0m (default: {default_color})")

        for name, ansi in sorted(ANSI_COLORS.items()):
            if name == default_color:
                continue
            marker = "● " if name == current else "  "
            menu_lines.append(f"{name}\t{marker}{ansi}■■■\033[0m {name}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--height", "~20",
                    "--header", f"Pick color for: {desc} (←/q=back)",
                    "--prompt", "Color: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        selected = output.split("\t")[0] if "\t" in output else output
        if selected == "(default)":
            set_terminal_color(element, "(default)", color_file)
        elif selected in ANSI_COLORS:
            set_terminal_color(element, selected, color_file)

    active_picker: Optional[str] = None

    while True:
        color_mode = get_color_mode(defaults_file)
        current_theme = get_current_theme_name(defaults_file)
        custom_colors = get_custom_colors(defaults_file)
        custom_count = len(custom_colors)
        theme_summary = f"{color_mode}: {current_theme}"
        if custom_count:
            theme_summary += f" +{custom_count} custom"

        browser = get_directory_browser()
        browser_desc = {
            "auto": "auto-detect",
            "broot": "broot",
            "ranger": "ranger",
            "nnn": "nnn",
            "fzf": "fzf built-in"
        }.get(browser, browser)

        git_viewer = get_git_viewer()
        git_viewer_desc = {
            "auto": "auto-detect",
            "tig": "tig",
            "lazygit": "lazygit",
            "gitk": "gitk",
        }.get(git_viewer, git_viewer)

        preview_layout = get_preview_layout()
        preview_layout_desc = {
            "down": "bottom",
            "right": "side-by-side",
            "up": "top",
        }.get(preview_layout, preview_layout)

        use_bitbake_layers = get_recipe_use_bitbake_layers()
        recipe_scan_desc = "bitbake-layers" if use_bitbake_layers else "file scan"

        b4_installed = shutil.which("b4") is not None
        b4_desc = "available" if b4_installed else "not found"
        b4_list = defaults.get("b4_default_list", "")
        if b4_list:
            b4_desc += f", list: {b4_list}"

        # Display colors summary
        terminal_overrides = sum(
            1 for elem in TERMINAL_COLOR_ELEMENTS
            if get_terminal_color(elem, defaults_file) != TERMINAL_COLOR_ELEMENTS[elem][0]
        )
        display_desc = f"{terminal_overrides} override{'s' if terminal_overrides != 1 else ''}" if terminal_overrides else "defaults"

        # Tmux prefix for remote sessions
        from .ssh_remote import get_tmux_prefix
        tmux_prefix = get_tmux_prefix()

        # NNN colors summary
        nnn_colors = get_nnn_colors()
        nnn_color_names = {
            "0": "black", "1": "red", "2": "green", "3": "yellow",
            "4": "blue", "5": "magenta", "6": "cyan", "7": "white",
        }
        nnn_desc = f"{nnn_color_names.get(nnn_colors[0:1], '?')} dirs ({nnn_colors})"

        editor_pref = get_editor()
        editor_desc = {
            "auto": f"auto ({resolve_editor()})",
            "vim": "vim",
            "nvim": "neovim",
            "nano": "nano",
            "emacs": "emacs",
            "code": "VS Code",
        }.get(editor_pref, editor_pref)

        settings_lines = [
            f"HEADER\t{Colors.bold(Colors.cyan('─── bit Settings ───'))}",
            f"COLORS\tColors/Themes    {theme_summary}",
            f"DISPLAY\tDisplay Colors   {display_desc}",
            f"BROWSER\tDir Browser      {browser_desc}",
            f"NNN_COLORS\tNNN Colors       {nnn_desc}",
            f"GITVIEWER\tGit Viewer       {git_viewer_desc}",
            f"PREVIEW\tPreview Layout   {preview_layout_desc}",
            f"RECIPE\tRecipe Scan      {recipe_scan_desc}",
            f"EDITOR\tEditor           {editor_desc}",
            f"B4\tB4 Patch Mgmt    {b4_desc}",
            f"TMUX\tTmux Prefix      {tmux_prefix}",
        ]

        menu_lines = list(settings_lines)

        # Inline picker dialog
        if active_picker:
            dialog_lines, current_idx = _build_setting_picker_lines(active_picker)
            menu_lines = menu_lines + dialog_lines

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--layout=reverse-list",
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        if active_picker:
            picker_title = {
                "BROWSER": "Dir Browser",
                "GITVIEWER": "Git Viewer",
                "PREVIEW": "Preview Layout",
                "RECIPE": "Recipe Scan",
                "NNN_COLORS": "NNN Colors",
                "EDITOR": "Editor",
            }.get(active_picker, active_picker)
            fzf_args.extend([
                "--disabled",
                "--height", "~24",
                "--header", f"Select {picker_title}  (Esc=back)",
                "--prompt", "Option: ",
            ])
            # Position cursor on current option: settings + 1 header + offset
            fzf_args.extend(get_position_binding(len(settings_lines) + 2 + current_idx))
        else:
            fzf_args.extend([
                "--height", "~14",
                "--header", "Customize colors, tools, and preferences (←/q=back)",
                "--prompt", "Setting: ",
            ])

        fzf_args.extend(get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            if active_picker:
                active_picker = None
                continue
            return

        output = result.stdout.strip()
        output_key = output.split("\t")[0]

        if output_key == "BACK":
            if active_picker:
                active_picker = None
                continue
            return

        if output_key in ("HEADER", "---"):
            continue

        if active_picker:
            if output_key.startswith(_OPT_PREFIX):
                _apply_setting(active_picker, output_key[len(_OPT_PREFIX):])
            active_picker = None
            continue

        # Main menu dispatch
        if output_key in _INLINE_PICKERS:
            active_picker = output_key
        elif output_key == "DISPLAY":
            cf = _resolve_color_file()
            if cf:
                _terminal_colors_submenu(cf)
            else:
                _color_mode_picker()
        elif output_key == "COLORS":
            _colors_submenu()
        elif output_key == "B4":
            _pick_b4_settings(defaults_file, defaults)
        elif output_key == "TMUX":
            _pick_tmux_prefix()


def _pick_tmux_prefix() -> None:
    """Pick tmux prefix key for remote sessions."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding
    from .ssh_remote import get_tmux_prefix, set_tmux_prefix

    current = get_tmux_prefix()

    options = [
        ("C-a", "Ctrl-A (screen default)"),
        ("C-b", "Ctrl-B (tmux default)"),
        ("C-s", "Ctrl-S"),
        ("C-q", "Ctrl-Q"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        menu_lines.append(f"{value}\t{marker}{desc}")

    # If current isn't one of the presets, show it too
    preset_values = {v for v, _ in options}
    if current not in preset_values:
        menu_lines.insert(0, f"{current}\t● {current} (custom)")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--height", "~10",
                "--header", "Tmux prefix for remote sessions (←/q=back)\nUsed by bit when running commands inside tmux on remote hosts",
                "--prompt", "Prefix: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
                "--print-query",
            ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    # --print-query output: line 0 = query, line 1 = selected item.
    # Don't strip() before splitlines — empty query line must be preserved.
    lines = result.stdout.splitlines()
    if result.returncode != 0 or len(lines) < 2:
        # No selection (Esc/back); check for typed-only query
        query = lines[0].strip() if lines else ""
        if query and query != "BACK":
            set_tmux_prefix(query)
        return

    selected = lines[1].split("\t")[0]
    if selected and selected != "BACK":
        set_tmux_prefix(selected)


def _pick_b4_settings(defaults_file: str, defaults: dict) -> None:
    """Show b4 settings submenu for configuring mail-based patch management."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding
    from .b4 import (
        fzf_pick_mailing_list, get_b4_setting, get_b4_repo_config,
        set_b4_repo_config, remove_b4_repo_config,
        load_global_b4_config, save_global_b4_config,
    )

    while True:
        # Project-level settings
        current_list = get_b4_setting(defaults, "b4_default_list") or "(not set)"
        current_midmask = get_b4_setting(defaults, "b4_midmask") or "https://lore.kernel.org/%s"
        auto_trailers = get_b4_setting(defaults, "b4_auto_trailers") or "false"
        auto_desc = "on" if auto_trailers == "true" else "off"

        # Thread viewer setting
        thread_viewer = get_b4_setting(defaults, "b4_thread_viewer") or "terminal"
        viewer_desc = "terminal" if thread_viewer == "terminal" else "browser"

        # Source indicators (project vs global)
        list_source = "project" if defaults.get("b4_default_list") else "global"
        midmask_source = "project" if defaults.get("b4_midmask") else "global"
        trailers_source = "project" if defaults.get("b4_auto_trailers") else "global"
        viewer_source = "project" if defaults.get("b4_thread_viewer") else "global"

        # Repo associations
        b4_repos = defaults.get("__b4_repos__", {})
        repo_count = len(b4_repos)
        repo_desc = f"{repo_count} configured" if repo_count else "none"

        menu_lines = [
            f"LIST\tDefault Mailing List   {current_list}  ({list_source})",
            f"MIDMASK\tMessage-Id URL Mask   {current_midmask}  ({midmask_source})",
            f"TRAILERS\tAuto-check Trailers   {auto_desc}  ({trailers_source})",
            f"VIEWER\tThread Viewer          {viewer_desc}  ({viewer_source})",
            f"REPOS\tRepo Associations      {repo_desc}",
            f"---\t{Colors.dim('  ───────────────────')}",
            f"GLOBAL\tEdit Global Defaults   (~/.config/bit/b4.json)",
        ]

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-sort",
                    "--no-multi",
                    "--height", "~10",
                    "--header", "B4 Settings (\u2190/q=back)",
                    "--prompt", "Setting: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--ansi",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        key = output.split("\t")[0]

        if key == "LIST":
            picked = fzf_pick_mailing_list()
            if picked:
                defaults["b4_default_list"] = picked[0]
                save_defaults(defaults_file, defaults)
        elif key == "MIDMASK":
            try:
                val = input(f"Message-Id URL mask [{current_midmask}]: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if val:
                defaults["b4_midmask"] = val
                save_defaults(defaults_file, defaults)
        elif key == "TRAILERS":
            new_val = "false" if auto_trailers == "true" else "true"
            defaults["b4_auto_trailers"] = new_val
            save_defaults(defaults_file, defaults)
        elif key == "VIEWER":
            new_val = "browser" if thread_viewer == "terminal" else "terminal"
            defaults["b4_thread_viewer"] = new_val
            save_defaults(defaults_file, defaults)
        elif key == "REPOS":
            _pick_b4_repo_associations(defaults_file, defaults)
        elif key == "GLOBAL":
            _pick_b4_global_settings()


def _pick_b4_repo_associations(defaults_file: str, defaults: dict) -> None:
    """Manage per-repo mailing list associations."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding
    from .b4 import (
        fzf_pick_mailing_list, get_b4_repo_config,
        set_b4_repo_config, remove_b4_repo_config,
    )
    from .common import repo_display_name

    while True:
        b4_repos = defaults.get("__b4_repos__", {})

        menu_lines = []
        if b4_repos:
            for repo_path, cfg in sorted(b4_repos.items()):
                display = repo_display_name(repo_path)
                ml = cfg.get("mailing_list", "")
                lore = cfg.get("lore_name", "")
                desc = lore if lore else ml
                menu_lines.append(f"{repo_path}\t{display:30s}  \u21a6 {desc}")
        else:
            menu_lines.append(f"---\t  No repos configured yet")

        menu_lines.append(f"---\t{Colors.dim('  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500')}")
        menu_lines.append(f"ADD\t  Add repo association...")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-sort",
                    "--no-multi",
                    "--height", "~10",
                    "--header", "Repo \u21a6 Mailing List Associations (\u2190/q=back)\nSelect to edit/remove",
                    "--prompt", "Repo: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--ansi",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        key = output.split("\t")[0]

        if key in ("---", ""):
            continue
        elif key == "ADD":
            # Pick a repo, then a mailing list
            try:
                repo_path = input("Repository path: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if not repo_path:
                continue
            repo_path = os.path.expanduser(repo_path)
            picked = fzf_pick_mailing_list(repo=repo_path)
            if picked:
                set_b4_repo_config(defaults_file, defaults, repo_path, picked[0], picked[1])
                print(f"Configured {repo_display_name(repo_path)} \u21a6 {picked[0]}")
                input("Press Enter to continue...")
        elif key in b4_repos:
            # Edit/remove existing
            display = repo_display_name(key)
            cfg = b4_repos[key]
            ml = cfg.get("mailing_list", "")
            print(f"\n{display} \u21a6 {ml}")
            try:
                choice = input("[C]hange list / [R]emove / Enter=keep: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if choice in ("c", "change"):
                picked = fzf_pick_mailing_list(repo=key)
                if picked:
                    set_b4_repo_config(defaults_file, defaults, key, picked[0], picked[1])
                    print(f"Updated {display} \u21a6 {picked[0]}")
                    input("Press Enter to continue...")
            elif choice in ("r", "remove"):
                remove_b4_repo_config(defaults_file, defaults, key)
                print(f"Removed {display}")
                input("Press Enter to continue...")


def _pick_b4_global_settings() -> None:
    """Edit global b4 defaults (~/.config/bit/b4.json)."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding
    from .b4 import load_global_b4_config, save_global_b4_config, fzf_pick_mailing_list

    while True:
        config = load_global_b4_config()
        current_list = config.get("default_list", "(not set)")
        current_midmask = config.get("midmask", "https://lore.kernel.org/%s")
        auto_trailers = config.get("auto_trailers", False)
        auto_desc = "on" if auto_trailers else "off"

        menu_lines = [
            f"LIST\tDefault Mailing List   {current_list}",
            f"MIDMASK\tMessage-Id URL Mask   {current_midmask}",
            f"TRAILERS\tAuto-check Trailers   {auto_desc}",
        ]

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-sort",
                    "--no-multi",
                    "--height", "~8",
                    "--header", "Global B4 Defaults (~/.config/bit/b4.json)  (\u2190/q=back)",
                    "--prompt", "Setting: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        key = output.split("\t")[0]

        if key == "LIST":
            picked = fzf_pick_mailing_list()
            if picked:
                config["default_list"] = picked[0]
                save_global_b4_config(config)
        elif key == "MIDMASK":
            try:
                val = input(f"Message-Id URL mask [{current_midmask}]: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if val:
                config["midmask"] = val
                save_global_b4_config(config)
        elif key == "TRAILERS":
            config["auto_trailers"] = not auto_trailers
            save_global_b4_config(config)


def fzf_config_repos(
    repos: List[str],
    defaults: Dict[str, str],
    bblayers_path: str,
    defaults_file: str,
) -> int:
    """
    Interactive fzf-based config interface.
    Returns exit code.
    """
    if not repos:
        print("No repos found.")
        return 1

    def get_repo_info(repo: str) -> Tuple[str, bool]:
        """Get display name and whether it's custom."""
        display = repo_display_name(repo)
        is_custom = False
        try:
            custom = subprocess.check_output(
                ["git", "-C", repo, "config", "--get", "bit.display-name"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
            if custom:
                is_custom = True
        except subprocess.CalledProcessError:
            pass
        return display, is_custom

    # --- Expand/collapse and inline dialog state ---
    repos_expanded = False
    show_repo_actions = False
    selected_repo = ""
    repo_text_input = False       # True = text input active
    repo_text_action = ""          # "display", "push", "push_prefix"
    repo_text_query = ""           # pre-fill for text input
    action_cursor_key = ""         # key to position cursor on in action dialog
    pending_push_url = None

    _ACTION_PREFIX = "RACT:"

    # Pre-compute max name length (stable across iterations)
    max_name_len = max(20, max((len(repo_display_name(r)) + 1 for r in repos), default=20))

    # Pre-compute special entry lines
    bblayers_conf = resolve_bblayers_path(bblayers_path)
    sep_len = 4 + 1 + max_name_len + 1 + 10 + 1 + 20

    def build_menu_lines() -> str:
        """Build fzf menu input in top-to-bottom order (for --layout=reverse-list)."""
        data_lines = []

        # Column header + separator at top
        col_header = f"HEADER\t  {'Name':<{max_name_len + 3}} {'Default':<10} Path"
        data_lines.append(col_header)
        data_lines.append(f"SEPARATOR\t{'─' * sep_len}")

        # Repositories row (expandable, de-indented)
        marker = "-" if repos_expanded else "+"
        repos_label = f"{'Repositories':<{max_name_len + 3}}"
        data_lines.append(f"REPOS\t{marker} {terminal_color('project_active', repos_label)} {'—':<10} {len(repos):2} repositories")

        # Expanded repo lines with tree connectors (indented under Repositories)
        if repos_expanded:
            for i, repo in enumerate(repos):
                display, is_custom = get_repo_info(repo)
                if is_custom:
                    display = f"{display}*"
                update_default = defaults.get(repo, "rebase")
                default_display = f"custom ({get_custom_command(update_default)})" if is_custom_default(update_default) else update_default
                is_last = (i == len(repos) - 1)
                tree = "└─ " if is_last else "├─ "
                data_lines.append(f"{repo}\t  {tree}{display:<{max_name_len}} {default_display:<10} {repo}")

        # Separator + special entries (aligned under Repositories name)
        data_lines.append(f"SEPARATOR\t")
        if bblayers_conf:
            conf_dir = os.path.dirname(bblayers_conf)
            project_name = f"{'project':<{max_name_len + 3}}"
            data_lines.append(f"PROJECT\t  {terminal_color('project_active', project_name)} {'—':<10} {conf_dir}")

        from .projects import find_project_for_directory, load_projects
        proj_path = find_project_for_directory()
        if proj_path:
            proj_data = load_projects()
            proj_name = proj_data.get(proj_path, {}).get("name", os.path.basename(proj_path))
            props_label = f"{'properties':<{max_name_len + 3}}"
            data_lines.append(f"PROPERTIES\t  {terminal_color('project_active', props_label)} {'—':<10} {proj_name}")

        settings_name = f"{'bit':<{max_name_len + 3}}"
        data_lines.append(f"SETTINGS\t  {Colors.magenta(settings_name)} {'—':<10} configure options")

        # Inline action dialog (appended — near prompt in reverse-list)
        if show_repo_actions and selected_repo:
            display_name, is_custom = get_repo_info(selected_repo)
            update_default = defaults.get(selected_repo, "rebase")
            push_target = get_push_target(defaults, selected_repo)
            push_status = push_target.get("push_url", "")[:40] if push_target else "(not configured)"
            display_suffix = " (custom)" if is_custom else " (auto)"

            current_for_radio = "custom" if is_custom_default(update_default) else update_default

            def _radio(opt):
                return "●" if current_for_radio == opt else "○"

            custom_label = f"custom ({get_custom_command(update_default)})" if is_custom_default(update_default) else "custom..."
            items = [
                (f"{_ACTION_PREFIX}DISPLAY", f"Display name     {display_name}{display_suffix}"),
                (f"{_ACTION_PREFIX}DEFAULT_rebase", f"Update default   {_radio('rebase')} rebase"),
                (f"{_ACTION_PREFIX}DEFAULT_merge", f"                 {_radio('merge')} merge"),
                (f"{_ACTION_PREFIX}DEFAULT_skip", f"                 {_radio('skip')} skip"),
                (f"{_ACTION_PREFIX}DEFAULT_custom", f"                 {_radio('custom')} {custom_label}"),
                (f"{_ACTION_PREFIX}PUSH", f"Push target      {push_status}"),
                (f"{_ACTION_PREFIX}EDIT", f"Edit layer.conf  →"),
            ]
            dialog_lines = build_inline_dialog_lines(
                f"Configure {display_name}", items, reverse_list=True,
            )
            data_lines.extend(dialog_lines)

        return "\n".join(data_lines)

    def set_display_name(repo: str) -> None:
        """Prompt and set display name for a repo."""
        current, is_custom = get_repo_info(repo)
        try:
            if is_custom:
                new_name = input(f"\nDisplay name [{current}] (empty to clear): ").strip()
            else:
                new_name = input(f"\nDisplay name [{current}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Cancelled.")
            return

        if new_name == "" and is_custom:
            # Clear custom name
            try:
                subprocess.run(
                    ["git", "-C", repo, "config", "--unset", "bit.display-name"],
                    check=True,
                )
                print(f"  Cleared. Now using: {repo_display_name(repo)}")
            except subprocess.CalledProcessError:
                pass
        elif new_name:
            subprocess.run(
                ["git", "-C", repo, "config", "bit.display-name", new_name],
                check=True,
            )
            print(f"  Set to: {new_name}")
        else:
            print("  Unchanged.")

    def set_update_default(repo: str, new_default: str) -> None:
        """Set update default for a repo."""
        old_default = defaults.get(repo, "rebase")
        if old_default == new_default:
            display, _ = get_repo_info(repo)
            print(f"\n  {display}: already set to {new_default}")
            return
        defaults[repo] = new_default
        save_defaults(defaults_file, defaults)
        display, _ = get_repo_info(repo)
        print(f"\n  {display}: {old_default} → {new_default}")

    def edit_layer_conf(repo: str) -> None:
        """Edit layer.conf for a repo."""
        # Find layers in this repo
        pairs, _repo_sets = resolve_base_and_layers(bblayers_path)
        repo_layers = [layer for layer, r in pairs if r == repo]

        if not repo_layers:
            print(f"\n  No layers found in {repo}")
            return

        if len(repo_layers) == 1:
            layer = repo_layers[0]
        else:
            # Multiple layers - use fzf to pick
            display_name, _ = get_repo_info(repo)
            menu_lines = []
            bindings = []
            for i, lyr in enumerate(repo_layers, start=1):
                # Format: "layer_path\t#  layer_name"
                menu_lines.append(f"{lyr}\t{i}  {layer_display_name(lyr)}")
                # Add number key binding (1-9)
                if i <= 9:
                    bindings.extend(["--bind", f"{i}:become(echo {lyr})"])

            try:
                result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--height", "~10",
                        "--header", f"Select layer in {display_name} (←=back, 1-{min(len(repo_layers), 9)} or Enter)",
                        "--prompt", "Layer: ",
                        "--with-nth", "2..",
                        "--delimiter", "\t",
                    ] + get_exit_bindings(mode="back") + bindings + get_fzf_color_args(),
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                print("  fzf not found")
                return

            if result.returncode != 0 or not result.stdout.strip():
                return

            output = result.stdout.strip()
            if output == "BACK":
                return
            # Extract layer path (either raw path from number key, or first field from selection)
            if "\t" in output:
                layer = output.split("\t")[0]
            else:
                layer = output

        layer_conf = os.path.join(layer, "conf", "layer.conf")
        if not os.path.isfile(layer_conf):
            print(f"\n  layer.conf not found: {layer_conf}")
            return

        editor = resolve_editor()
        print(f"\n  Editing: {layer_conf}")
        try:
            subprocess.run([editor, layer_conf], check=True)
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            print(f"  Error: {e}")

    def show_repo_submenu(repo: str) -> None:
        """Show config submenu for a single repo."""
        submenu_dialog_state = ExploreMenuState()
        pending_push_url: Optional[str] = None

        while True:
            display, is_custom = get_repo_info(repo)
            update_default = defaults.get(repo, "rebase")
            has_dialog = submenu_dialog_state.has_dialog()

            # Build menu showing current values
            display_suffix = " (custom)" if is_custom else " (auto)"
            push_target = get_push_target(defaults, repo)
            push_status = push_target.get("push_url", "")[:40] if push_target else "(not configured)"
            default_display = f"custom ({get_custom_command(update_default)})" if is_custom_default(update_default) else update_default
            menu_lines = [
                f"DISPLAY\tDisplay name     {display}{display_suffix}",
                f"DEFAULT\tUpdate default   {default_display}",
                f"PUSH\tPush target      {push_status}",
                f"EDIT\tEdit layer.conf  →",
            ]

            menu_input = "\n".join(menu_lines)

            # Prepend dialog items if active
            if has_dialog:
                dialog_lines = submenu_dialog_state.get_dialog_menu_lines()
                dialog_input = "\n".join(f"{value}\t{disp}" for value, disp in dialog_lines)
                menu_input = dialog_input + "\n" + menu_input
                current_header = "Complete dialog above | Esc=cancel"
                current_prompt = submenu_dialog_state.get_prompt_text() or "Input: "
            else:
                current_header = f"Configure {display} ({repo})"
                current_prompt = "Select: "

            fzf_cmd = [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--height", "~12",
                "--header", current_header,
                "--prompt", current_prompt,
                "--with-nth", "2..",
                "--delimiter", "\t",
            ] + get_fzf_color_args()

            if has_dialog:
                fzf_cmd.extend(["--print-query", "--bind", "esc:abort"])
            else:
                fzf_cmd.extend(get_exit_bindings(mode="back") + get_accept_binding())

            try:
                result = subprocess.run(
                    fzf_cmd,
                    input=menu_input,
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return

            if result.returncode != 0 or not result.stdout.strip():
                if has_dialog:
                    submenu_dialog_state.clear_dialog()
                    continue
                return

            # Parse output based on dialog mode
            if has_dialog:
                lines = result.stdout.split("\n")
                query = lines[0] if lines else ""
                output = lines[1].strip() if len(lines) > 1 else ""

                if submenu_dialog_state.is_dialog_selection(output.split("\t")[0] if output else ""):
                    dlg_result = submenu_dialog_state.handle_dialog_selection(output.split("\t")[0], query)
                    if dlg_result.confirmed and submenu_dialog_state.active_dialog.on_confirm:
                        submenu_dialog_state.active_dialog.on_confirm(dlg_result.value)
                    submenu_dialog_state.clear_dialog()
                    continue
            else:
                output = result.stdout.strip()

            if output == "BACK":
                return
            elif output.startswith("DISPLAY\t"):
                # Show inline dialog for display name
                def on_display_confirm(new_name):
                    if new_name == "" and is_custom:
                        try:
                            subprocess.run(
                                ["git", "-C", repo, "config", "--unset", "bit.display-name"],
                                check=True,
                            )
                        except subprocess.CalledProcessError:
                            pass
                    elif new_name:
                        subprocess.run(
                            ["git", "-C", repo, "config", "bit.display-name", new_name],
                            check=True,
                        )

                submenu_dialog_state.show_dialog(
                    text_input_dialog(
                        title="Set display name",
                        message=f"Current: {display} | Empty to {'clear' if is_custom else 'keep'}",
                        default=display if is_custom else "",
                        placeholder="Display name",
                        on_confirm=on_display_confirm,
                    )
                )
            elif output.startswith("DEFAULT\t"):
                pick_update_default(repo)
            elif output.startswith("EDIT\t"):
                edit_layer_conf(repo)
            elif output.startswith("PUSH\t"):
                # Show inline dialog for push URL
                current_url = push_target.get("push_url", "") if push_target else ""
                current_prefix = push_target.get("branch_prefix", "") if push_target else ""

                def on_push_url_confirm(new_url):
                    nonlocal pending_push_url
                    if not new_url:
                        remove_push_target(defaults_file, defaults, repo)
                    else:
                        pending_push_url = new_url

                        def on_prefix_confirm(new_prefix):
                            nonlocal pending_push_url
                            if pending_push_url:
                                set_push_target(defaults_file, defaults, repo, pending_push_url, new_prefix or "")
                                pending_push_url = None

                        submenu_dialog_state.show_dialog(
                            text_input_dialog(
                                title="Branch prefix",
                                message="e.g. 'yourname/' or empty for none",
                                default=current_prefix,
                                placeholder="Prefix",
                                on_confirm=on_prefix_confirm,
                            )
                        )

                submenu_dialog_state.show_dialog(
                    text_input_dialog(
                        title="Push URL",
                        message=f"Current: {current_url or '(not configured)'} | Empty to clear",
                        default=current_url,
                        placeholder="git@...",
                        on_confirm=on_push_url_confirm,
                    )
                )

    def configure_push_target(repo: str) -> None:
        """Configure push target for a repo."""
        display, _ = get_repo_info(repo)
        push_target = get_push_target(defaults, repo)
        current_url = push_target.get("push_url", "") if push_target else ""
        current_prefix = push_target.get("branch_prefix", "") if push_target else ""

        print(f"\nPush target for {display}")
        print(f"Current push URL: {current_url or '(not configured)'}")
        print(f"Current branch prefix: {current_prefix or '(none)'}")
        print()

        new_url = input("Push URL (empty to clear, - to keep): ").strip()
        if new_url == "-":
            new_url = current_url
        elif not new_url:
            # Clear the push target
            remove_push_target(defaults_file, defaults, repo)
            print("Push target cleared.")
            input("Press Enter to continue...")
            return

        new_prefix = input("Branch prefix (e.g. 'yourname/', empty for none, - to keep): ").strip()
        if new_prefix == "-":
            new_prefix = current_prefix

        set_push_target(defaults_file, defaults, repo, new_url, new_prefix)
        print(f"Push target set: {new_url}")
        if new_prefix:
            print(f"Branch prefix: {new_prefix}")
        input("Press Enter to continue...")

    def show_build_config() -> None:
        """Show config submenu for project conf files."""
        fzf_build_config(bblayers_path)

    def show_project_properties() -> None:
        """Show submenu for editing project-level properties."""
        from .projects import find_project_for_directory
        proj_path = find_project_for_directory()
        if proj_path:
            fzf_project_properties(proj_path)

    def show_settings_submenu() -> None:
        """Show settings submenu for bit tool configuration."""
        fzf_global_settings(defaults_file)

    def pick_update_default(repo: str) -> None:
        """Show submenu to pick update default."""
        display, _ = get_repo_info(repo)
        current = defaults.get(repo, "rebase")
        current_for_radio = "custom" if is_custom_default(current) else current

        menu_lines = []
        for opt in ["rebase", "merge", "skip", "custom"]:
            marker = "●" if opt == current_for_radio else "○"
            label = opt
            if opt == "custom" and is_custom_default(current):
                label = f"custom ({get_custom_command(current)})"
            menu_lines.append(f"{opt}\t{marker} {label}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--height", "~7",
                    "--header", f"Update default for {display}",
                    "--prompt", "Default: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--bind", "r:become(echo rebase)",
                    "--bind", "m:become(echo merge)",
                    "--bind", "s:become(echo skip)",
                    "--bind", "c:become(echo custom)",
                ] + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        # Handle both direct key (rebase) and selection (rebase\t● rebase)
        new_default = output.split("\t")[0]
        if new_default in ("rebase", "merge", "skip"):
            set_update_default(repo, new_default)
        elif new_default == "custom":
            # Show text input to capture custom command
            prefill = get_custom_command(current) if is_custom_default(current) else ""
            try:
                cmd_result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--height", "~4",
                        "--header", f"Custom command for {display}  Esc=cancel",
                        "--prompt", "Command: ",
                        "--disabled",
                        "--print-query",
                        "--query", prefill,
                    ] + get_fzf_color_args(),
                    input="",
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return
            if cmd_result.returncode != 0:
                return
            lines = cmd_result.stdout.strip().split("\n")
            custom_cmd = lines[0].strip() if lines else ""
            if custom_cmd:
                set_update_default(repo, f"custom:{custom_cmd}")

    from .common import get_project_header_prefix
    prefix = get_project_header_prefix()
    default_header = f"{prefix}Enter/→=configure | \\=fold | d=display | r=rebase | m=merge | s=skip | e=edit | q=quit"


    while True:
        menu_input = build_menu_lines()

        # Base fzf args (reverse-list layout — natural top-to-bottom order)
        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--no-info",
            "--ansi",
            "--height", "~50%",
            "--layout=reverse-list",
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        if repo_text_input:
            # --- Text input mode ---
            if repo_text_action == "display":
                display_name, is_custom = get_repo_info(selected_repo)
                if is_custom:
                    prompt_header = f"Display name for {display_name} (empty to clear)  Esc=cancel"
                else:
                    prompt_header = f"Display name for {display_name}  Esc=cancel"
                fzf_args.extend([
                    "--print-query",
                    "--disabled",
                    "--query", repo_text_query,
                    "--header", prompt_header,
                    "--prompt", "Name: ",
                ])
            elif repo_text_action == "push":
                push_target = get_push_target(defaults, selected_repo)
                current_url = push_target.get("push_url", "") if push_target else ""
                fzf_args.extend([
                    "--print-query",
                    "--disabled",
                    "--query", repo_text_query,
                    "--header", f"Push URL (empty to clear)  Esc=cancel",
                    "--prompt", "URL: ",
                ])
            elif repo_text_action == "push_prefix":
                fzf_args.extend([
                    "--print-query",
                    "--disabled",
                    "--query", repo_text_query,
                    "--header", f"Branch prefix (e.g. 'yourname/', empty for none)  Esc=cancel",
                    "--prompt", "Prefix: ",
                ])
            elif repo_text_action == "custom_default":
                display_name, _ = get_repo_info(selected_repo)
                fzf_args.extend([
                    "--print-query",
                    "--disabled",
                    "--query", repo_text_query,
                    "--header", f"Custom command for {display_name}  Esc=cancel",
                    "--prompt", "Command: ",
                ])
        elif show_repo_actions:
            # --- Action dialog mode ---
            # Count lines before dialog: header + sep + repos row + expanded repos + sep + special entries
            n_lines = 3  # HEADER + separator + REPOS row
            if repos_expanded:
                n_lines += len(repos)
            n_lines += 1  # separator before special entries
            if bblayers_conf:
                n_lines += 1  # PROJECT
            from .projects import find_project_for_directory
            if find_project_for_directory():
                n_lines += 1  # PROPERTIES
            n_lines += 1  # SETTINGS
            first_action_pos = n_lines + 2  # +1 for dialog header, +1 for 1-indexed
            display_name, _ = get_repo_info(selected_repo)
            fzf_args.extend([
                "--header", f"Configure {display_name}  Esc=back",
                "--prompt", "Action: ",
                "--bind", "space:accept",
            ])
            # Position cursor on previously selected action, or first action
            if action_cursor_key:
                action_keys = [
                    f"{_ACTION_PREFIX}DISPLAY",
                    f"{_ACTION_PREFIX}DEFAULT_rebase",
                    f"{_ACTION_PREFIX}DEFAULT_merge",
                    f"{_ACTION_PREFIX}DEFAULT_skip",
                    f"{_ACTION_PREFIX}DEFAULT_custom",
                    f"{_ACTION_PREFIX}PUSH",
                    f"{_ACTION_PREFIX}EDIT",
                ]
                try:
                    cursor_offset = action_keys.index(action_cursor_key)
                except ValueError:
                    cursor_offset = 0
                fzf_args.extend(get_position_binding(first_action_pos + cursor_offset))
            else:
                fzf_args.extend(get_position_binding(first_action_pos))
        else:
            # --- Normal mode ---
            fzf_args.extend([
                "--header", default_header,
                "--prompt", "Config: ",
                "--bind", "q:become(echo QUIT)",
                "--bind", "d:become(echo DISPLAY {1})",
                "--bind", "r:become(echo REBASE {1})",
                "--bind", "m:become(echo MERGE {1})",
                "--bind", "s:become(echo SKIP {1})",
                "--bind", "e:become(echo EDIT {1})",
            ])
            fzf_args.extend(get_action_binding("\\", "EXPAND {1}"))
            fzf_args.extend(get_accept_binding())

        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            print("fzf not found. Use CLI: bit config <repo> --display-name/--update-default")
            return 1

        # --- Text input result ---
        if repo_text_input:
            action = repo_text_action
            repo_text_input = False
            repo_text_action = ""
            repo_text_query = ""

            if result.returncode != 0:
                # Cancelled — return to action dialog (or main menu)
                if action == "push_prefix":
                    # Cancel prefix input — still save the push URL with empty prefix
                    if pending_push_url:
                        set_push_target(defaults_file, defaults, selected_repo, pending_push_url, "")
                        pending_push_url = None
                continue

            lines = result.stdout.splitlines()
            query = lines[0].strip() if lines else ""

            if action == "display":
                display_name, is_custom = get_repo_info(selected_repo)
                if query == "" and is_custom:
                    try:
                        subprocess.run(
                            ["git", "-C", selected_repo, "config", "--unset", "bit.display-name"],
                            check=True,
                        )
                    except subprocess.CalledProcessError:
                        pass
                elif query:
                    subprocess.run(
                        ["git", "-C", selected_repo, "config", "bit.display-name", query],
                        check=True,
                    )
                # Stay in action dialog
            elif action == "push":
                if not query:
                    remove_push_target(defaults_file, defaults, selected_repo)
                else:
                    # Chain to prefix input
                    pending_push_url = query
                    push_target = get_push_target(defaults, selected_repo)
                    current_prefix = push_target.get("branch_prefix", "") if push_target else ""
                    repo_text_input = True
                    repo_text_action = "push_prefix"
                    repo_text_query = current_prefix
            elif action == "push_prefix":
                if pending_push_url:
                    set_push_target(defaults_file, defaults, selected_repo, pending_push_url, query or "")
                    pending_push_url = None
            elif action == "custom_default":
                if query:
                    set_update_default(selected_repo, f"custom:{query}")
            continue

        # --- Esc / cancel ---
        if result.returncode != 0 or not result.stdout.strip():
            if show_repo_actions:
                show_repo_actions = False
                selected_repo = ""
                action_cursor_key = ""
                continue
            break

        output = result.stdout.strip()

        # --- Action dialog result ---
        if show_repo_actions:
            output_key = output.split("\t")[0]
            if output_key.startswith(_ACTION_PREFIX):
                action = output_key[len(_ACTION_PREFIX):]

                # Handle default select picker (silent — no print, just update and redraw)
                if action.startswith("DEFAULT_"):
                    new_default = action[len("DEFAULT_"):]
                    if new_default in ("rebase", "merge", "skip"):
                        defaults[selected_repo] = new_default
                        save_defaults(defaults_file, defaults)
                        action_cursor_key = output_key
                        continue
                    elif new_default == "custom":
                        # Switch to text input for custom command
                        current = defaults.get(selected_repo, "rebase")
                        prefill = get_custom_command(current) if is_custom_default(current) else ""
                        repo_text_input = True
                        repo_text_action = "custom_default"
                        repo_text_query = prefill
                        action_cursor_key = output_key
                        continue

                show_repo_actions = False
                if action == "DISPLAY":
                    display_name, is_custom = get_repo_info(selected_repo)
                    repo_text_input = True
                    repo_text_action = "display"
                    repo_text_query = display_name if is_custom else ""
                    show_repo_actions = True  # Return to dialog after text input
                elif action == "PUSH":
                    push_target = get_push_target(defaults, selected_repo)
                    current_url = push_target.get("push_url", "") if push_target else ""
                    repo_text_input = True
                    repo_text_action = "push"
                    repo_text_query = current_url
                    show_repo_actions = True
                elif action == "EDIT":
                    edit_layer_conf(selected_repo)
                    selected_repo = ""
                continue

            # Non-action item selected — dismiss dialog, fall through to normal handling
            show_repo_actions = False
            selected_repo = ""
            action_cursor_key = ""

        # --- Normal mode result ---
        if output == "QUIT":
            break

        # Expand/collapse handler
        if output.startswith("EXPAND "):
            key = output.split(" ", 1)[1].strip()
            if key == "REPOS":
                repos_expanded = not repos_expanded
            continue

        # Keybinding handlers (d/r/m/s/e on repo lines)
        if output.startswith("DISPLAY "):
            repo_path = output[8:].strip()
            if repo_path not in ("HEADER", "SEPARATOR", "REPOS", "PROJECT", "PROPERTIES", "SETTINGS", "---"):
                display_name, is_custom = get_repo_info(repo_path)
                selected_repo = repo_path
                show_repo_actions = True
                repo_text_input = True
                repo_text_action = "display"
                repo_text_query = display_name if is_custom else ""
        elif output.startswith("REBASE "):
            repo_path = output[7:].strip()
            if repo_path not in ("HEADER", "SEPARATOR", "REPOS", "PROJECT", "PROPERTIES", "SETTINGS", "---"):
                set_update_default(repo_path, "rebase")
        elif output.startswith("MERGE "):
            repo_path = output[6:].strip()
            if repo_path not in ("HEADER", "SEPARATOR", "REPOS", "PROJECT", "PROPERTIES", "SETTINGS", "---"):
                set_update_default(repo_path, "merge")
        elif output.startswith("SKIP "):
            repo_path = output[5:].strip()
            if repo_path not in ("HEADER", "SEPARATOR", "REPOS", "PROJECT", "PROPERTIES", "SETTINGS", "---"):
                set_update_default(repo_path, "skip")
        elif output.startswith("EDIT "):
            repo_path = output[5:].strip()
            if repo_path not in ("HEADER", "SEPARATOR", "REPOS", "PROJECT", "PROPERTIES", "SETTINGS", "---"):
                edit_layer_conf(repo_path)
        elif "\t" in output:
            # Enter/→ pressed on a line
            repo_path = output.split("\t")[0]
            if repo_path == "REPOS":
                repos_expanded = not repos_expanded
            elif repo_path == "PROJECT":
                show_build_config()
            elif repo_path == "PROPERTIES":
                show_project_properties()
            elif repo_path == "SETTINGS":
                show_settings_submenu()
            elif repo_path not in ("HEADER", "SEPARATOR", "---"):
                # Enter on a repo line → show inline action dialog
                selected_repo = repo_path
                show_repo_actions = True

    return 0


