#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Export command - export patches from layer repos."""

import argparse
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

from ..core import (
    Colors,
    current_branch,
    current_head,
    fzf_available,
    load_defaults,
    load_export_state,
    load_prep_state,
    repo_is_clean,
    save_export_state,
    save_prep_state,
)
from .common import (
    resolve_bblayers_path,
    resolve_base_and_layers,
    collect_repos,
    repo_display_name,
    prepare_target_dir,
    get_repo_commit_info,
    fzf_pick_range,
    show_log_for_pick,
    prompt_export,
    group_commits_by_layer,
    commit_files,
    layer_display_name,
    create_pull_branch,
    repo_origin_url,
    author_ident,
    patch_subject,
    clean_title,
    git_version,
    git_request_pull,
    push_branch_to_target,
    get_push_target,
    copy_to_clipboard,
)
from .branch import (
    get_local_commits,
    fzf_multiselect_commits,
    fzf_select_insertion_point,
    prompt_branch_name,
)

# Lazy imports to avoid circular dependency with explore.py
def _get_explore_functions():
    from .explore import (
        text_multiselect_commits,
        text_select_insertion_point,
        reorder_commits_via_cherrypick,
    )
    return text_multiselect_commits, text_select_insertion_point, reorder_commits_via_cherrypick

def diffstat_for_range(repo: str, range_spec: str) -> str:
    try:
        if range_spec == "--root":
            empty = subprocess.check_output(
                ["git", "-C", repo, "hash-object", "-t", "tree", "/dev/null"], text=True
            ).strip()
            return subprocess.check_output(
                ["git", "-C", repo, "diff", "--stat", f"{empty}..HEAD"], text=True
            ).strip()
        return subprocess.check_output(["git", "-C", repo, "diff", "--stat", range_spec], text=True).strip()
    except subprocess.CalledProcessError:
        return ""



def run_export(args) -> int:
    # Validate incompatible options
    if getattr(args, 'from_branch', None) and args.branch:
        print("Error: Cannot use --from-branch with --branch", file=sys.stderr)
        return 1

    defaults = load_defaults(args.defaults_file)
    pairs, _repo_sets = resolve_base_and_layers(args.bblayers, defaults)
    export_state = load_export_state(args.export_state_file)

    # Load prep state if available
    PREP_STATE_FILE = ".bit.prep-state.json"
    prep_state = load_prep_state(PREP_STATE_FILE)
    used_prep_state = False

    if prep_state and not getattr(args, 'from_branch', None):
        # Show what prep found
        print("\nFound prep state from previous 'export prep' run:")
        for repo, info in prep_state.get("repos", {}).items():
            display = repo_display_name(repo)
            branch = info.get("prep_branch") or (info.get("cut_point", "?")[:8] + "...")
            print(f"  {display}: {branch}")

        # Prompt user
        print()
        try:
            choice = input("Use prep results? [Y]es / [n]o / [a]bort: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if choice in ("a", "abort"):
            return 0
        elif choice in ("n", "no"):
            prep_state = None  # Ignore prep state
        else:
            used_prep_state = True

    prepare_target_dir(args.target_dir, args.force)
    if os.listdir(args.target_dir) and not args.force:
        sys.exit(f"Target directory '{args.target_dir}' is not empty; use --force to proceed.")

    repo_layers: Dict[str, List[str]] = {}
    for layer, repo in pairs:
        repo_layers.setdefault(repo, []).append(layer)

    repo_cache: Dict[str, Tuple[Optional[str], bool, str, int, str, str]] = {}
    selections: List[Tuple[str, List[str], str, Tuple[Optional[str], bool, str, int, str, str]]] = []

    skip_rest = False

    for repo, layers in repo_layers.items():
        if skip_rest:
            break

        # When using prep state, skip repos that weren't prepped
        if used_prep_state and repo not in prep_state.get("repos", {}):
            continue

        if repo not in repo_cache:
            repo_cache[repo] = get_repo_commit_info(repo)
        info = repo_cache[repo]
        branch, remote_exists, remote_ref, count, range_spec, desc = info
        head = current_head(repo)
        display_name = repo_display_name(repo)

        # Determine export reference (--from-branch or prep_state)
        export_ref = None
        from_branch_arg = getattr(args, 'from_branch', None)
        if from_branch_arg:
            # Verify branch exists in this repo
            result = subprocess.run(
                ["git", "-C", repo, "rev-parse", "--verify", from_branch_arg],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                export_ref = from_branch_arg
            else:
                print(f"  {display_name}: branch '{from_branch_arg}' not found, using HEAD")
        elif prep_state and repo in prep_state.get("repos", {}):
            repo_prep = prep_state["repos"][repo]
            if repo_prep.get("prep_branch"):
                # Verify prep branch still exists
                result = subprocess.run(
                    ["git", "-C", repo, "rev-parse", "--verify", repo_prep["prep_branch"]],
                    capture_output=True, text=True
                )
                if result.returncode == 0:
                    export_ref = repo_prep["prep_branch"]
            elif repo_prep.get("cut_point"):
                export_ref = repo_prep["cut_point"]

        # If we have a custom export ref, recalculate range_spec and count
        if export_ref and branch:
            new_range = f"origin/{branch}..{export_ref}"
            try:
                new_count = int(subprocess.check_output(
                    ["git", "-C", repo, "rev-list", "--count", new_range],
                    text=True
                ).strip())
                range_spec = new_range
                count = new_count
                desc = f"from {export_ref}"
                info = (branch, remote_exists, remote_ref, count, range_spec, desc)
            except subprocess.CalledProcessError:
                print(f"  {display_name}: invalid range '{new_range}', using default")

        default_include = defaults.get(repo, "rebase") != "skip"
        prev = export_state.get(repo)
        prev_range = None
        default_from_state = False
        if prev and prev.get("head") == head:
            if "include" in prev:
                default_include = bool(prev["include"])
                default_from_state = True
            prev_range = prev.get("range") or None
        layer_list = ", ".join(layers)

        if args.pick:
            if not branch:
                print(f"{display_name}: detached HEAD; skipping.")
                continue

            user_range = None
            default_range = range_spec if range_spec != "--root" else None

            # Try fzf for interactive selection
            if fzf_available():
                prev_was_skip = default_from_state and not default_include
                fzf_result = fzf_pick_range(repo, branch, default_range=default_range, prev_range=prev_range, prev_was_skip=prev_was_skip)
                if fzf_result == "SKIP_REST":
                    export_state[repo] = {"head": head or "", "include": False, "range": prev_range or default_range or ""}
                    skip_rest = True
                    break
                elif fzf_result == "SKIP":
                    export_state[repo] = {"head": head or "", "include": False, "range": prev_range or default_range or ""}
                    continue
                elif fzf_result is None:
                    # Escape pressed - treat as skip
                    print(f"Skipping {display_name} (cancelled).")
                    export_state[repo] = {"head": head or "", "include": False, "range": prev_range or default_range or ""}
                    continue
                elif fzf_result == "USE_DEFAULT":
                    user_range = default_range or range_spec
                elif fzf_result == "USE_PREVIOUS":
                    user_range = prev_range
                else:
                    user_range = fzf_result
            else:
                # Fallback to manual input
                suggested_range = prev_range or default_range or range_spec
                print(f"\n{display_name} ({repo}) on {branch}")
                show_log_for_pick(repo)
                prompt = f"Range to export (git range, e.g. <start>^..<end>; empty to "
                prompt += "use default" if suggested_range else "skip"
                if default_from_state:
                    prompt += " (prev choice: "
                    prompt += "include" if default_include else "skip"
                    prompt += ")"
                prompt += f"; default {suggested_range}; S=skip rest, s=skip this): "
                user_range = input(prompt).strip()
                if not user_range:
                    if default_include and suggested_range:
                        user_range = suggested_range
                    else:
                        export_state[repo] = {"head": head or "", "include": False, "range": suggested_range or ""}
                        continue
                if user_range == "S":
                    export_state[repo] = {"head": head or "", "include": False, "range": suggested_range or ""}
                    skip_rest = True
                    break
                if user_range.lower() == "s":
                    export_state[repo] = {"head": head or "", "include": False, "range": suggested_range or ""}
                    continue

            try:
                cnt = int(subprocess.check_output(["git", "-C", repo, "rev-list", "--count", user_range], text=True).strip())
            except subprocess.CalledProcessError:
                print(f"{display_name}: invalid range '{user_range}', skipping.")
                continue
            if cnt == 0:
                print(f"{display_name}: range '{user_range}' has no commits, skipping.")
                continue
            remote_ref = f"origin/{branch}"
            info = (branch, True, remote_ref, cnt, user_range, f"user range {user_range}")
            selections.append((layer_list.split(", "), repo, display_name, info))
            export_state[repo] = {"head": head or "", "include": True, "range": user_range}
            continue
        include, skip_rest = prompt_export(repo, layer_list, info, default_include, display_name)
        if include:
            selections.append((layer_list.split(", "), repo, display_name, info))
        else:
            if count > 0:
                print(f"Skipping {display_name} ({repo}).")
        export_state[repo] = {"head": head or "", "include": include, "range": range_spec or prev_range or ""}

    if not selections:
        print("No patches selected for export.")
        return 0

    prefix_tag = f"[{args.subject_prefix}]" if getattr(args, 'subject_prefix', None) else ""

    global_counter = 1
    summary_entries = []
    all_patches: List[Tuple[str, str, str]] = []  # (display_name, patch_path, repo_path)
    diffstats: List[str] = []
    pull_urls: List[Tuple[str, str, str]] = []  # (repo_name, url, branch_name)
    request_pull_msgs: Dict[str, str] = {}  # repo_path -> git request-pull output

    for layers, repo, repo_name, info in selections:
        branch, remote_exists, remote_ref, count, range_spec, desc = info

        out_dir = args.target_dir
        if args.layout == "per-repo":
            out_dir = os.path.join(args.target_dir, repo_name)
            os.makedirs(out_dir, exist_ok=True)

        # For multi-layer repos, we need to generate patches per-layer
        # For single-layer repos, use repo_name as prefix
        if len(layers) > 1:
            # Get commits in range
            if range_spec == "--root":
                commits = subprocess.check_output(
                    ["git", "-C", repo, "rev-list", "--reverse", "HEAD"],
                    text=True,
                ).strip().splitlines()
            else:
                commits = subprocess.check_output(
                    ["git", "-C", repo, "rev-list", "--reverse", range_spec],
                    text=True,
                ).strip().splitlines()

            # Group commits by layer
            layer_commits, cross_layer, no_layer = group_commits_by_layer(repo, commits, layers)

            if cross_layer:
                # Get short hash and subject for error message
                for c in cross_layer:
                    short = c[:12]
                    subj = subprocess.check_output(
                        ["git", "-C", repo, "log", "-1", "--format=%s", c],
                        text=True,
                    ).strip()[:60]
                    touched_layers = []
                    files = commit_files(repo, c)
                    for layer in layers:
                        relpath = os.path.relpath(layer, repo)
                        for f in files:
                            if f.startswith(relpath + "/") or f == relpath:
                                touched_layers.append(layer_display_name(layer))
                                break
                    print(f"Error: commit {short} touches multiple layers ({', '.join(touched_layers)}): {subj}")
                return 1

            if no_layer:
                # Commits touching files outside known layers
                for c in no_layer:
                    short = c[:12]
                    subj = subprocess.check_output(
                        ["git", "-C", repo, "log", "-1", "--format=%s", c],
                        text=True,
                    ).strip()[:60]
                    print(f"Error: commit {short} touches no known layer: {subj}")
                return 1

            # Generate patches per-layer
            print(f"{repo_name}:")
            repo_patch_count = 0
            for layer in layers:
                if layer not in layer_commits:
                    continue
                layer_name = layer_display_name(layer)
                layer_commit_list = layer_commits[layer]

                # Track existing patches
                existing_patches = set(os.listdir(out_dir)) if os.path.exists(out_dir) else set()

                # Generate patches for this layer's commits
                for commit in layer_commit_list:
                    cmd = ["git", "-C", repo, "format-patch", "-1", "--start-number", str(global_counter),
                           "--output-directory", out_dir, "--subject-prefix", layer_name, commit]
                    try:
                        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)
                    except subprocess.CalledProcessError as exc:
                        print(f"Failed to export patch for {commit[:12]}: {exc}")
                        return exc.returncode or 1
                    global_counter += 1

                # Collect newly generated patches
                layer_patch_count = 0
                for fname in sorted(os.listdir(out_dir)):
                    if fname.endswith(".patch") and fname not in existing_patches:
                        patch_path = os.path.join(out_dir, fname)
                        all_patches.append((layer_name, patch_path, repo))
                        layer_patch_count += 1
                        repo_patch_count += 1

                print(f"  {layer_name}: {layer_patch_count} patch(es)")

            print(f"  -> {out_dir}")

            # Diffstat for whole repo
            diffstat = diffstat_for_range(repo, range_spec)
            if diffstat:
                diffstats.append(f"{repo_name}:\n{diffstat}")

            # Generate cover letter for per-repo layout (since we're not using --cover-letter)
            if args.layout == "per-repo":
                cover_path = os.path.join(out_dir, "0000-cover-letter.patch")
                author_name, author_email = author_ident(repo)
                date_str = datetime.now().astimezone().strftime("%a, %d %b %Y %H:%M:%S %z")
                version_str = f"v{args.series_version} " if args.series_version else ""

                # Get commit subjects for shortlog
                all_commits = []
                for layer in layers:
                    if layer in layer_commits:
                        all_commits.extend(layer_commits[layer])

                with open(cover_path, "w", encoding="utf-8") as f:
                    f.write("From 0000000000000000000000000000000000000000 Mon Sep 17 00:00:00 2001\n")
                    f.write(f"From: {author_name} <{author_email}>\n")
                    f.write(f"Date: {date_str}\n")
                    f.write(f"Subject: [{repo_name}]{prefix_tag}[PATCH {version_str}0/{repo_patch_count}] *** SUBJECT HERE ***\n")
                    f.write("\n")
                    f.write("*** BLURB HERE ***\n")
                    f.write("\n")
                    # Shortlog by layer
                    for layer in layers:
                        if layer in layer_commits:
                            layer_name = layer_display_name(layer)
                            f.write(f"{layer_name} ({len(layer_commits[layer])}):\n")
                            for commit in layer_commits[layer]:
                                subj = subprocess.check_output(
                                    ["git", "-C", repo, "log", "-1", "--format=%s", commit],
                                    text=True,
                                ).strip()
                                f.write(f"  {subj}\n")
                            f.write("\n")
                    if diffstat:
                        for line in diffstat.splitlines():
                            f.write(f" {line}\n")
                        f.write("\n")
                    f.write("-- \n")
                    f.write(f"{git_version()}\n")

        else:
            # Single layer - use repo display name
            cmd = ["git", "-C", repo, "format-patch", "--start-number", str(global_counter), "--output-directory", out_dir, "--subject-prefix", repo_name]
            if args.layout == "per-repo":
                cmd.append("--cover-letter")

            if range_spec == "--root":
                cmd.append("--root")
            else:
                cmd.append(range_spec)

            # Track existing patches before format-patch to only collect new ones
            existing_patches = set(os.listdir(out_dir)) if os.path.exists(out_dir) else set()

            try:
                subprocess.run(cmd, check=True)
            except subprocess.CalledProcessError as exc:
                print(f"Failed to export patches for {repo}: {exc}")
                return exc.returncode or 1

            # collect only newly generated patches for this repo
            patch_count = 0
            for fname in sorted(os.listdir(out_dir)):
                if fname.endswith(".patch") and fname not in existing_patches:
                    patch_path = os.path.join(out_dir, fname)
                    all_patches.append((repo_name, patch_path, repo))
                    patch_count += 1

            print(f"{repo_name}:")
            print(f"  {patch_count} patch(es) -> {out_dir}")

            diffstat = diffstat_for_range(repo, range_spec)
            if diffstat:
                diffstats.append(f"{repo_name}:\n{diffstat}")

            global_counter += count

        # Create pull branch if requested (per-repo, not per-layer)
        if args.branch:
            if not repo_is_clean(repo):
                print(f"  skipping branch creation (repo is dirty)")
            else:
                base_ref = remote_ref if remote_exists else "HEAD"
                success, msg = create_pull_branch(repo, args.branch, base_ref, range_spec, args.force)
                if success:
                    print(f"  {msg}")
                    origin_url = repo_origin_url(repo)
                    if origin_url:
                        pull_urls.append((repo_name, origin_url, args.branch))
                else:
                    print(f"  {msg}")

        summary_entries.append((repo_name, layers, branch or "(detached)", desc, count, out_dir, repo))

    # Rewrite subjects with per-display-name numbering
    patches_by_name: Dict[str, List[str]] = {}
    for display_name, patch_path, _repo_path in all_patches:
        patches_by_name.setdefault(display_name, []).append(patch_path)

    for display_name, plist in patches_by_name.items():
        total = len(plist)
        for idx, patch_path in enumerate(plist, start=1):
            title = clean_title(patch_subject(patch_path))
            try:
                with open(patch_path, encoding="utf-8") as f:
                    lines = f.readlines()
            except Exception:
                continue
            new_lines = []
            changed = False
            version_str = f"v{args.series_version} " if args.series_version else ""
            for line in lines:
                if not changed and line.lower().startswith("subject:"):
                    new_lines.append(f"Subject: [{display_name}]{prefix_tag}[PATCH {version_str}{idx:02d}/{total:02d}] {title}\n")
                    changed = True
                    continue
                new_lines.append(line)
            if changed:
                try:
                    with open(patch_path, "w", encoding="utf-8") as f:
                        f.writelines(new_lines)
                except Exception:
                    pass

    # Push step - check for configured push targets and offer to push
    repos_with_push_targets = []
    for layers, repo, repo_name, info in selections:
        push_target = get_push_target(defaults, repo)
        if push_target and push_target.get("push_url"):
            branch = info[0]  # branch from info tuple
            if branch:
                repos_with_push_targets.append((repo, repo_name, branch, push_target))

    if repos_with_push_targets:
        print("\nPush targets configured for:")
        for repo, repo_name, branch, target in repos_with_push_targets:
            # Determine default remote branch - prefer prep branch name
            prefix = target.get("branch_prefix", "")
            if prep_state and repo in prep_state.get("repos", {}):
                repo_prep = prep_state["repos"][repo]
                if repo_prep.get("prep_branch"):
                    default_remote = f"{prefix}{repo_prep['prep_branch']}" if prefix else repo_prep["prep_branch"]
                else:
                    default_remote = f"{prefix}{branch}" if prefix else branch
            else:
                default_remote = f"{prefix}{branch}" if prefix else branch
            print(f"  {repo_name}: {target['push_url']} -> {default_remote}")

        try:
            push_choice = input("\nPush branches? [y]es / [N]o: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            push_choice = ""

        if push_choice in ("y", "yes"):
            print()
            for repo, repo_name, branch, target in repos_with_push_targets:
                push_url = target["push_url"]
                prefix = target.get("branch_prefix", "")

                # Determine what to push - use prep branch or current branch
                local_ref = branch
                if prep_state and repo in prep_state.get("repos", {}):
                    repo_prep = prep_state["repos"][repo]
                    if repo_prep.get("prep_branch"):
                        local_ref = repo_prep["prep_branch"]

                # Default remote branch name - use prep branch if available
                default_remote = f"{prefix}{local_ref}" if prefix else local_ref

                # Prompt for remote branch name
                try:
                    prompt = f"{repo_name}: push {local_ref} to [{default_remote}]: "
                    user_input = input(prompt).strip()
                except (EOFError, KeyboardInterrupt):
                    print("\nSkipping remaining pushes.")
                    break

                if user_input.lower() == "s":
                    print(f"  Skipped {repo_name}")
                    continue
                elif user_input.lower() == "f":
                    # Force push with default name
                    remote_branch = default_remote
                    force_push = True
                elif user_input.startswith("f "):
                    # Force push with custom name
                    remote_branch = user_input[2:].strip() or default_remote
                    force_push = True
                elif user_input:
                    remote_branch = user_input
                    force_push = False
                else:
                    remote_branch = default_remote
                    force_push = False

                # Push the branch
                success, msg = push_branch_to_target(repo, push_url, local_ref, remote_branch, force=force_push)
                if success:
                    force_str = " (forced)" if force_push else ""
                    print(f"  {repo_name}: pushed to {remote_branch}{force_str}")
                    # Generate request-pull message
                    # Find the base ref (remote tracking branch)
                    base_ref = f"origin/{branch}"
                    rp_msg = git_request_pull(repo, base_ref, push_url, local_ref, remote_branch)
                    if rp_msg:
                        request_pull_msgs[repo] = rp_msg
                else:
                    print(f"  {repo_name}: {msg}")

    if args.layout == "flat":
        cover_path = os.path.join(args.target_dir, "0000-cover-letter.patch")
        author_name, author_email = author_ident(selections[0][1] if selections else ".")
        date_str = datetime.now().astimezone().strftime("%a, %d %b %Y %H:%M:%S %z")
        version_str = f"v{args.series_version} " if args.series_version else ""
        with open(cover_path, "w", encoding="utf-8") as f:
            f.write("From 0000000000000000000000000000000000000000 Mon Sep 17 00:00:00 2001\n")
            f.write(f"From: {author_name} <{author_email}>\n")
            f.write(f"Date: {date_str}\n")
            f.write(f"Subject: {prefix_tag}[PATCH {version_str}0/{len(all_patches)}] *** SUBJECT HERE ***\n")
            f.write("\n")
            f.write("*** BLURB HERE ***\n")
            f.write("\n")
            # Shortlog by repo/layer
            for repo_name, layers, branch, desc, count, _out_dir, repo_path in summary_entries:
                f.write(f"{repo_name} ({count}):\n")
                for display_name, patch_path, patch_repo_path in all_patches:
                    if patch_repo_path == repo_path:
                        subj = patch_subject(patch_path)
                        # Clean up the subject
                        clean = clean_title(subj)
                        f.write(f"  {clean}\n")
                f.write("\n")
            if pull_urls:
                f.write("Pull requests:\n")
                for repo_name, url, branch_name in pull_urls:
                    f.write(f"  {repo_name}: git pull {url} {branch_name}\n")
                f.write("\n")
            if request_pull_msgs:
                for repo_name, layers, branch, desc, count, _out_dir, repo_path in summary_entries:
                    if repo_path in request_pull_msgs:
                        f.write(f"{repo_name}:\n")
                        for line in request_pull_msgs[repo_path].splitlines():
                            f.write(f"  {line}\n")
                        f.write("\n")
            if diffstats:
                for stat in diffstats:
                    lines = stat.splitlines()
                    for i, line in enumerate(lines):
                        clean = line.lstrip()
                        f.write(f" {clean}\n")
                    f.write("\n")
            f.write("-- \n")
            f.write(f"{git_version()}\n")
        print(f"Wrote cover letter: {cover_path}")
    else:
        # For per-repo layout, update cover letters with request-pull info if available
        for repo_name, _layer, _branch, _desc, _count, out_dir, repo_path in summary_entries:
            cover = os.path.join(out_dir, "0000-cover-letter.patch")
            if os.path.exists(cover):
                if repo_path in request_pull_msgs:
                    # Insert request-pull info before diffstat in cover letter
                    try:
                        with open(cover, "r", encoding="utf-8") as f:
                            content = f.read()
                        # Find where to insert (before diffstat or at end of body)
                        rp_text = "\nThe following changes since commit "
                        if "*** BLURB HERE ***" in content:
                            # Insert after BLURB HERE marker
                            rp_info = request_pull_msgs[repo_path]
                            content = content.replace(
                                "*** BLURB HERE ***",
                                f"*** BLURB HERE ***\n\n{rp_info}"
                            )
                            with open(cover, "w", encoding="utf-8") as f:
                                f.write(content)
                    except Exception:
                        pass
                print(f"Summary for {repo_name}: {cover}")

    print(f"Export complete. Patches written under {args.target_dir}")
    save_export_state(args.export_state_file, export_state)

    # Post-export b4 send
    if getattr(args, 'send', False):
        from .b4 import b4_available, b4_send
        if not b4_available():
            print(f"\n{Colors.yellow('b4 is not installed.')} Install with: pip install b4")
        else:
            send_to = getattr(args, 'send_to', None)
            if not send_to:
                send_defaults = load_defaults(getattr(args, 'defaults_file', '.bit.defaults'))
                send_to = send_defaults.get("b4_default_list")
            b4_send(args.target_dir, send_to=send_to)

    # Prompt to delete prep state if we used it
    if used_prep_state and os.path.exists(PREP_STATE_FILE):
        try:
            choice = input("\nDelete prep state file? [Y]es / [n]o: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            choice = ""
        if choice not in ("n", "no"):
            os.remove(PREP_STATE_FILE)
            print("Prep state deleted.")

    return 0



def export_single_patch(repo: str, commit: str, target_dir: str = ".") -> Optional[str]:
    """Export a single commit as a .patch file using git format-patch. Returns full path or None on error."""
    try:
        # Use git format-patch to create file with standard naming (0001-subject.patch)
        output = subprocess.check_output(
            ["git", "-C", repo, "format-patch", "-1", commit, "-o", target_dir],
            text=True,
        ).strip()
        # git format-patch outputs the created filename
        return output
    except subprocess.CalledProcessError:
        return None


def export_commits_from_explore(repo: str, commits: List[str]) -> None:
    """Export one or more commits as patch files. Prompts for directory if multiple."""
    if not commits:
        return

    # Get current directory for display
    cwd = os.getcwd()

    if len(commits) == 1:
        # Single commit - export to current directory
        print(f"\nExporting to {cwd}...")
        filepath = export_single_patch(repo, commits[0], cwd)
        if filepath:
            print(f"  {os.path.basename(filepath)}")
        else:
            print(f"  Failed to export {commits[0][:8]}")
        input("Press Enter to continue...")
        return

    # Multiple commits - prompt for target directory
    print(f"\nExporting {len(commits)} commits...")
    try:
        default_target = os.path.expanduser("~/patches")
        target_dir = input(f"Target directory [{default_target}]: ").strip()
        if not target_dir:
            target_dir = default_target
        target_dir = os.path.expanduser(target_dir)
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        return

    # Create directory if needed
    os.makedirs(target_dir, exist_ok=True)

    print(f"Exporting to {target_dir}...")

    # Export each commit using git format-patch (standard naming)
    exported = []
    for i, commit in enumerate(commits, 1):
        try:
            # Use git format-patch with start-number for proper sequencing
            output = subprocess.check_output(
                ["git", "-C", repo, "format-patch", "-1", commit, "-o", target_dir,
                 f"--start-number={i}"],
                text=True,
            ).strip()
            exported.append(os.path.basename(output))
            print(f"  {os.path.basename(output)}")
        except subprocess.CalledProcessError as e:
            print(f"  Failed: {commit[:8]}")

    print(f"Exported {len(exported)} patch(es)")

    # Offer b4 send if available
    if exported:
        from .b4 import b4_available, b4_send
        if b4_available():
            try:
                send_choice = input("Send via b4? [y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                send_choice = ""
            if send_choice in ("y", "yes"):
                send_defaults = load_defaults(".bit.defaults")
                send_to = send_defaults.get("b4_default_list")
                b4_send(target_dir, send_to=send_to)

    input("Press Enter to continue...")



def run_prepare_export(args) -> int:
    """Main entry point for prepare-export subcommand."""
    # Lazy import to avoid circular dependency
    text_multiselect_commits, text_select_insertion_point, reorder_commits_via_cherrypick = _get_explore_functions()

    bblayers_path = resolve_bblayers_path(args.bblayers)
    defaults = load_defaults(args.defaults_file)
    repos, _repo_sets = collect_repos(bblayers_path, defaults)

    if not repos:
        print("No repos found.")
        return 1

    processed_repos = []
    skip_rest = False

    for repo in repos:
        if skip_rest:
            break

        display_name = repo_display_name(repo)

        # Check if repo should be skipped by default
        if defaults.get(repo, "rebase") == "skip":
            print(f"→ {display_name}: default=skip")
            continue

        # Check for dirty repo
        if not repo_is_clean(repo):
            print(f"→ {Colors.yellow(display_name)}: uncommitted changes, skipping")
            continue

        # Get branch info
        branch = current_branch(repo)
        if not branch:
            print(f"→ {display_name}: detached HEAD, skipping")
            continue

        # Get local commits
        commits, base_ref = get_local_commits(repo, branch)
        if not base_ref:
            print(f"→ {display_name}: no origin/{branch}, skipping")
            continue

        if not commits:
            print(f"→ {display_name}: no local commits")
            continue

        # Prompt for selection
        # Skip branch prompt in fzf if --branch is already specified
        skip_branch_prompt = bool(args.branch)
        if args.plain or not fzf_available():
            result = text_multiselect_commits(repo, branch, commits)
            branch_mode = None  # Text mode doesn't have 'b' key
            want_backup = False  # Text mode doesn't have '!' key
        else:
            result = fzf_multiselect_commits(repo, branch, commits, base_ref=base_ref, skip_branch_prompt=skip_branch_prompt)

        if result is None:
            print(f"→ {display_name}: cancelled")
            continue

        selected, action, branch_mode, want_backup = result

        if action == "skip_rest":
            print(f"→ {display_name}: skipping remaining repos")
            skip_rest = True
            break
        if action == "skip" or not selected:
            print(f"→ {display_name}: skipped")
            continue

        # Compute remaining commits (not selected) - keep as (hash, subject) tuples
        selected_set = set(selected)
        selected_tuples = [(h, s) for h, s in commits if h in selected_set]
        remaining_tuples = [(h, s) for h, s in commits if h not in selected_set]
        remaining = [h for h, _ in remaining_tuples]

        # Prompt for insertion point if there are remaining commits
        insertion_point = base_ref
        if remaining_tuples:
            if args.plain or not fzf_available():
                insertion_point = text_select_insertion_point(repo, branch, base_ref, remaining_tuples)
            else:
                insertion_point, branch_mode = fzf_select_insertion_point(
                    repo, branch, base_ref, remaining_tuples, selected_tuples, branch_mode
                )

            if insertion_point is None:
                print(f"→ {display_name}: cancelled")
                continue

        # Determine the actual commit order based on insertion point
        if insertion_point == base_ref:
            # Default: base_ref -> selected -> remaining
            final_order = selected + remaining
        else:
            # Custom insertion point: commits before insertion -> selected -> commits after
            insertion_idx = None
            for i, h in enumerate(remaining):
                if h == insertion_point:
                    insertion_idx = i
                    break
            if insertion_idx is not None:
                before = remaining[:insertion_idx + 1]  # Include the insertion point commit
                after = remaining[insertion_idx + 1:]
                final_order = before + selected + after
            else:
                # Fallback if not found
                final_order = selected + remaining

        # Check if reorder is actually needed
        actual_order = [h for h, _ in commits]
        if final_order == actual_order:
            print(f"→ {Colors.green(display_name)}: commits already in correct order")
            # Get cut point for branch creation (last selected commit)
            cut_point = selected[-1] if selected else None
            processed_repos.append((repo, cut_point, branch_mode))
            continue

        # Perform reorder
        backup_branch = None
        if args.backup or want_backup:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            backup_branch = f"{branch}-backup-{timestamp}"

        success, msg, cut_point = reorder_commits_via_cherrypick(
            repo=repo,
            branch=branch,
            base_ref=base_ref,
            selected_commits=selected,
            remaining_commits=remaining,
            commits_info=commits,
            insertion_point=insertion_point,
            backup_branch=backup_branch,
            dry_run=args.dry_run,
        )

        if success:
            print(f"→ {Colors.green(display_name)}: {msg}")
            processed_repos.append((repo, cut_point, branch_mode))
        else:
            print(f"→ {Colors.red(display_name)}: {msg}")

    # Summary
    print()
    if not processed_repos:
        if args.dry_run:
            print("Dry run complete. No changes made.")
        else:
            print("No repos were prepared.")
        return 0

    print(f"Prepared {len(processed_repos)} repo(s) for export.")

    # Branch creation logic
    branch_name = args.branch  # From CLI
    # Check if any repo requested branch creation (b or B key)
    any_branch_mode = any(mode for _, _, mode in processed_repos)
    # Use replace mode if any repo pressed 'B'
    force_replace = any(mode == "replace" for _, _, mode in processed_repos)

    if args.dry_run:
        if branch_name:
            print(f"Would create branch '{branch_name}' at cut points")
        elif any_branch_mode:
            mode_str = "replace existing" if force_replace else "skip existing"
            print(f"Would prompt for branch name ({mode_str})")
        print("\nDry run complete. No changes made.")
        return 0

    if not branch_name and any_branch_mode:
        # User pressed 'b' or 'B' in fzf - prompt for branch name
        branch_name = prompt_branch_name()
    elif not branch_name:
        # Fallback prompt if no --branch specified
        branch_name = prompt_branch_name()

    # Create branches if a name was provided
    if branch_name:
        print()
        for repo, cut_point, _ in processed_repos:
            if not cut_point:
                continue  # Skip if no cut point (shouldn't happen in non-dry-run)

            display_name = repo_display_name(repo)

            # Check if branch already exists
            branch_exists = subprocess.run(
                ["git", "-C", repo, "rev-parse", "--verify", branch_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode == 0

            if branch_exists:
                if force_replace:
                    # Delete existing branch
                    subprocess.run(
                        ["git", "-C", repo, "branch", "-D", branch_name],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                else:
                    # Prompt user to overwrite
                    choice = input(f"→ {display_name}: branch '{branch_name}' already exists. Overwrite? [y/N]: ").strip().lower()
                    if choice == 'y':
                        subprocess.run(
                            ["git", "-C", repo, "branch", "-D", branch_name],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                        )
                    else:
                        print(f"→ {Colors.yellow(display_name)}: skipping")
                        continue

            # Create branch at cut point
            result = subprocess.run(
                ["git", "-C", repo, "branch", branch_name, cut_point],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if result.returncode == 0:
                action = "replaced" if branch_exists else "created"
                print(f"→ {Colors.green(display_name)}: {action} branch '{branch_name}' at {cut_point[:12]}")
            else:
                print(f"→ {Colors.red(display_name)}: failed to create branch '{branch_name}'")

    # Save prep state for use by export command
    PREP_STATE_FILE = ".bit.prep-state.json"
    prep_state_data = {}
    for repo, cut_point, _ in processed_repos:
        if cut_point:
            # Get working branch
            working_branch = subprocess.run(
                ["git", "-C", repo, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True
            ).stdout.strip()
            prep_state_data[repo] = {
                "working_branch": working_branch,
                "prep_branch": branch_name if branch_name else None,
                "cut_point": cut_point,
            }
    if prep_state_data:
        save_prep_state(PREP_STATE_FILE, prep_state_data)
        print(f"\nPrep state saved to {PREP_STATE_FILE}")

    # Prompt for export
    print()
    try:
        response = input("Proceed to export? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return 0

    if response not in ('', 'y', 'yes'):
        return 0

    # Prompt for target directory
    print()
    try:
        default_target = os.path.expanduser("~/patches")
        target_dir = input(f"Target directory [{default_target}]: ").strip()
        if not target_dir:
            target_dir = default_target
        target_dir = os.path.expanduser(target_dir)
    except (EOFError, KeyboardInterrupt):
        print()
        return 0

    # Prompt for layout
    try:
        layout_choice = input("Layout - [f]lat (all patches in one dir) or [p]er-repo (subdirs)? [F/p]: ").strip().lower()
        layout = "per-repo" if layout_choice == 'p' else "flat"
    except (EOFError, KeyboardInterrupt):
        print()
        return 0

    # Prompt for series version
    try:
        version_input = input("Series version (e.g., 2 for v2, Enter to skip): ").strip()
        series_version = int(version_input) if version_input else None
    except (EOFError, KeyboardInterrupt):
        print()
        return 0
    except ValueError:
        series_version = None

    # Prompt for subject prefix
    try:
        prefix_input = input("Subject prefix tag (e.g., kirkstone, Enter to skip): ").strip()
        subject_prefix = prefix_input if prefix_input else None
    except (EOFError, KeyboardInterrupt):
        print()
        return 0

    # Build export args
    export_args = argparse.Namespace(
        bblayers=args.bblayers,
        defaults_file=args.defaults_file,
        target_dir=target_dir,
        layout=layout,
        force=False,
        pick=False,  # Not needed - prep state provides the range
        series_version=series_version,
        subject_prefix=subject_prefix,
        branch=None,  # Branch already created by prep
        from_branch=None,  # Will use prep state
        export_state_file=".bit.export-state.json",
    )

    print()
    return run_export(export_args)

