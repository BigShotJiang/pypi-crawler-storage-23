#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for custom command in the update flow."""

import argparse
import subprocess
from unittest.mock import MagicMock, patch, call

import pytest

from bitbake_project.core import is_custom_default, get_custom_command
from bitbake_project.commands.common import (
    prompt_action,
    fzf_prompt_action,
    run_cmd,
)
from bitbake_project.commands.update import run_update


class TestRunCmdCustom:
    """Tests for run_cmd with shell=True (custom commands)."""

    def test_custom_cmd_dry_run(self, capsys):
        """Dry-run prints command without executing."""
        run_cmd("/path/to/repo", "git pull --rebase origin/master", dry_run=True, shell=True)
        out = capsys.readouterr().out
        assert "[dry-run]" in out
        assert "git pull --rebase origin/master" in out
        assert "/path/to/repo" in out

    @patch("bitbake_project.commands.common.subprocess.run")
    def test_custom_cmd_runs_with_shell(self, mock_run):
        """Custom command is executed with shell=True and correct cwd."""
        run_cmd("/path/to/repo", "git pull --rebase origin/master", dry_run=False, shell=True)
        mock_run.assert_called_once_with(
            "git pull --rebase origin/master",
            check=True,
            cwd="/path/to/repo",
            shell=True,
        )


class TestPromptActionCustom:
    """Tests for text-based prompt_action custom command path."""

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="c git fetch --all")
    def test_custom_command_returns_tuple(self, mock_input, mock_upstream, mock_fzf):
        """'c <cmd>' input returns ('custom', cmd, None)."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result == ("custom", "git fetch --all", None)

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="c ")
    def test_custom_command_empty_returns_none(self, mock_input, mock_upstream, mock_fzf):
        """'c ' with no actual command returns None."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result is None

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="c git log --oneline -5")
    def test_custom_command_preserves_full_string(self, mock_input, mock_upstream, mock_fzf):
        """Full command string after 'c ' is preserved."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result[0] == "custom"
        assert result[1] == "git log --oneline -5"


class TestFzfPromptActionCustom:
    """Tests for fzf-based custom command dialog (the --disabled fix)."""

    @patch("bitbake_project.commands.common.get_fzf_color_args", return_value=[])
    @patch("bitbake_project.commands.common.get_action_binding", return_value=[])
    @patch("bitbake_project.commands.common.get_terminal_color", return_value="yellow")
    @patch("bitbake_project.commands.common.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.common.subprocess.run")
    def test_custom_command_dialog_uses_disabled(
        self, mock_run, mock_display, mock_color, mock_binding, mock_fzf_colors
    ):
        """When 'Custom command...' is selected, the next fzf invocation uses --disabled."""
        # First call: user selects "Custom command..."
        first_result = MagicMock()
        first_result.returncode = 0
        first_result.stdout = "   Custom command..."

        # Second call: dialog mode with --disabled, user types a command
        # fzf outputs: line 0 = query (--print-query), line 1 = selected item
        # Dialog items are tab-delimited: __DLG_CONFIRM__\t<display>
        second_result = MagicMock()
        second_result.returncode = 0
        second_result.stdout = "git pull --rebase origin/master\n__DLG_CONFIRM__\t│  [ ✓ Confirm ]"

        mock_run.side_effect = [first_result, second_result]

        with patch("bitbake_project.commands.branch.get_upstream_ref", return_value="origin/main"):
            result = fzf_prompt_action("/repo", "main", "rebase")

        # Verify the second fzf call included --disabled
        assert mock_run.call_count == 2
        second_call_args = mock_run.call_args_list[1]
        fzf_cmd = second_call_args[0][0]
        assert "--disabled" in fzf_cmd
        assert "--print-query" in fzf_cmd

        # Should return the custom command
        assert result == ("custom", "git pull --rebase origin/master", None)

    @patch("bitbake_project.commands.common.get_fzf_color_args", return_value=[])
    @patch("bitbake_project.commands.common.get_action_binding", return_value=[])
    @patch("bitbake_project.commands.common.get_terminal_color", return_value="yellow")
    @patch("bitbake_project.commands.common.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.common.subprocess.run")
    def test_custom_command_dialog_esc_cancels(
        self, mock_run, mock_display, mock_color, mock_binding, mock_fzf_colors
    ):
        """Esc in custom command dialog returns to menu, not skip."""
        # First call: user selects "Custom command..."
        first_result = MagicMock()
        first_result.returncode = 0
        first_result.stdout = "   Custom command..."

        # Second call: user presses Esc (returncode != 0)
        second_result = MagicMock()
        second_result.returncode = 130
        second_result.stdout = ""

        # Third call: user selects Skip
        third_result = MagicMock()
        third_result.returncode = 0
        third_result.stdout = "   Skip this repo (s)"

        mock_run.side_effect = [first_result, second_result, third_result]

        with patch("bitbake_project.commands.branch.get_upstream_ref", return_value="origin/main"):
            result = fzf_prompt_action("/repo", "main", "rebase")

        # Should have gone back to menu and then skipped
        assert mock_run.call_count == 3
        assert result == ("skip", "main", None)

    @patch("bitbake_project.commands.common.get_fzf_color_args", return_value=[])
    @patch("bitbake_project.commands.common.get_action_binding", return_value=[])
    @patch("bitbake_project.commands.common.get_terminal_color", return_value="yellow")
    @patch("bitbake_project.commands.common.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.common.subprocess.run")
    def test_first_fzf_call_does_not_use_disabled(
        self, mock_run, mock_display, mock_color, mock_binding, mock_fzf_colors
    ):
        """The initial action menu should NOT use --disabled (needs fuzzy matching)."""
        result_obj = MagicMock()
        result_obj.returncode = 0
        result_obj.stdout = "   Skip this repo (s)"
        mock_run.return_value = result_obj

        with patch("bitbake_project.commands.branch.get_upstream_ref", return_value="origin/main"):
            fzf_prompt_action("/repo", "main", "rebase")

        first_call_args = mock_run.call_args_list[0]
        fzf_cmd = first_call_args[0][0]
        assert "--disabled" not in fzf_cmd


class TestRunUpdateCustomCommand:
    """Tests for custom command through the full run_update flow."""

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.prompt_action")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults", return_value={})
    def test_custom_command_dispatched_with_shell(
        self, mock_defaults, mock_collect, mock_branch, mock_prompt, mock_run_cmd
    ):
        """Custom command from prompt_action is passed to run_cmd with shell=True."""
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))
        mock_prompt.return_value = ("custom", "git pull --rebase origin/master", None)

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=False,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_called_once_with(
            "/repo/meta-oe", "git pull --rebase origin/master", False, shell=True
        )

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.prompt_action")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults", return_value={})
    def test_custom_command_target_is_the_command_string(
        self, mock_defaults, mock_collect, mock_branch, mock_prompt, mock_run_cmd
    ):
        """The 'target' field in the custom tuple is the command string, not a branch."""
        mock_collect.return_value = (["/repo/poky"], MagicMock(external=[]))
        mock_prompt.return_value = ("custom", "git fetch --all && git rebase", None)

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=False,
            all=False,
            repo=None,
        )

        run_update(args)

        # The second arg to run_cmd is the custom command string
        cmd_arg = mock_run_cmd.call_args[0][1]
        assert cmd_arg == "git fetch --all && git rebase"


class TestCustomDefaultHelpers:
    """Tests for is_custom_default() and get_custom_command() helpers."""

    def test_is_custom_default_true(self):
        assert is_custom_default("custom:git pull --rebase") is True

    def test_is_custom_default_false_rebase(self):
        assert is_custom_default("rebase") is False

    def test_is_custom_default_false_merge(self):
        assert is_custom_default("merge") is False

    def test_is_custom_default_false_skip(self):
        assert is_custom_default("skip") is False

    def test_is_custom_default_false_empty(self):
        assert is_custom_default("") is False

    def test_is_custom_default_false_custom_no_colon(self):
        assert is_custom_default("custom") is False

    def test_get_custom_command_basic(self):
        assert get_custom_command("custom:git pull --rebase") == "git pull --rebase"

    def test_get_custom_command_with_spaces(self):
        assert get_custom_command("custom:git fetch --all && git rebase") == "git fetch --all && git rebase"

    def test_get_custom_command_empty_after_prefix(self):
        assert get_custom_command("custom:") == ""


class TestRunUpdateCustomDefault:
    """Tests for run_update with --yes and custom: defaults."""

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_custom_default(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd
    ):
        """--yes with a custom: default executes the custom command."""
        mock_defaults.return_value = {"/repo/meta-oe": "custom:git pull --rebase origin/master"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_called_once_with(
            "/repo/meta-oe", "git pull --rebase origin/master", False, shell=True
        )

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_custom_default_prints_info(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd, capsys
    ):
        """--yes with custom: default prints descriptive info."""
        mock_defaults.return_value = {"/repo/poky": "custom:make update"}
        mock_collect.return_value = (["/repo/poky"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        out = capsys.readouterr().out
        assert "custom" in out
        assert "make update" in out

    @patch("bitbake_project.commands.update.get_pull_args", return_value=(["git", "pull", "--rebase", "origin", "main"], "git pull --rebase origin/main"))
    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_standard_default_still_works(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd, mock_pull_args
    ):
        """--yes with standard rebase default still works normally."""
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        # Should call run_cmd without shell=True (standard pull)
        mock_run_cmd.assert_called_once()
        call_kwargs = mock_run_cmd.call_args
        assert call_kwargs[0][1] == ["git", "pull", "--rebase", "origin", "main"]


class TestPromptActionCustomDefault:
    """Tests for text-based prompt_action with d custom <cmd>."""

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom git pull --rebase origin/master")
    def test_d_custom_sets_default(self, mock_input, mock_upstream, mock_fzf):
        """'d custom <cmd>' returns custom tuple with new_default."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result == ("custom", "git pull --rebase origin/master", "custom:git pull --rebase origin/master")

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom ")
    def test_d_custom_empty_returns_none(self, mock_input, mock_upstream, mock_fzf):
        """'d custom ' with no command returns None."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result is None

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="")
    def test_enter_with_custom_default_runs_custom(self, mock_input, mock_upstream, mock_fzf):
        """Pressing Enter with a custom: default returns the custom command."""
        result = prompt_action("/repo", "main", "custom:git fetch --all", use_fzf=False)
        assert result == ("custom", "git fetch --all", None)


class TestConfigUpdateDefaultValidation:
    """Tests for CLI --update-default validation."""

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_custom_update_default_accepted(
        self, mock_defaults, mock_collect, mock_display, mock_save
    ):
        """--update-default 'custom:git pull' is accepted and saved."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="custom:git pull --rebase",
            edit=False,
        )

        result = run_config(args)
        assert result == 0
        # Verify the custom value was saved
        assert mock_defaults.return_value["/repo/meta-oe"] == "custom:git pull --rebase"

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_invalid_update_default_rejected(
        self, mock_defaults, mock_collect, mock_display, mock_save
    ):
        """--update-default 'invalid' returns error."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="invalid",
            edit=False,
        )

        result = run_config(args)
        assert result == 1
