#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for explore command pure functions."""

import pytest

from bitbake_project.commands.explore import (
    _build_file_tree,
    _build_tree_menu_lines,
    _format_refs,
    _parse_commit_browser_output,
)


# ────────────────────────────────────────────────────────────────────
# _format_refs
# ────────────────────────────────────────────────────────────────────

class TestFormatRefs:
    """Tests for tig-style ref decoration formatting."""

    def test_empty_refs(self):
        assert _format_refs([]) == ""

    def test_local_branch(self):
        assert _format_refs([("main", "local")]) == "[main]"

    def test_remote_ref(self):
        assert _format_refs([("origin/main", "remote")]) == "{origin/main}"

    def test_tag(self):
        assert _format_refs([("v1.0", "tag")]) == "<v1.0>"

    def test_mixed_refs(self):
        refs = [("main", "local"), ("origin/main", "remote"), ("v1.0", "tag")]
        assert _format_refs(refs) == "[main] {origin/main} <v1.0>"

    def test_multiple_same_type(self):
        refs = [("main", "local"), ("develop", "local")]
        assert _format_refs(refs) == "[main] [develop]"

    def test_unknown_type_ignored(self):
        refs = [("main", "local"), ("something", "unknown")]
        assert _format_refs(refs) == "[main]"


# ────────────────────────────────────────────────────────────────────
# _build_file_tree
# ────────────────────────────────────────────────────────────────────

class TestBuildFileTree:
    """Tests for building tree structure from flat file paths."""

    def test_single_file_at_root(self):
        tree = _build_file_tree(["README.md"])
        assert tree[""] == [("README.md", False)]

    def test_single_file_in_dir(self):
        tree = _build_file_tree(["src/main.py"])
        # Root has one dir
        assert tree[""] == [("src", True)]
        # src/ has one file
        assert tree["src"] == [("main.py", False)]

    def test_dirs_sorted_before_files(self):
        tree = _build_file_tree([
            "README.md",
            "src/main.py",
        ])
        root = tree[""]
        names = [name for name, _ in root]
        types = [is_dir for _, is_dir in root]
        # src/ (dir) should come before README.md (file)
        assert names == ["src", "README.md"]
        assert types == [True, False]

    def test_alphabetical_within_type(self):
        tree = _build_file_tree([
            "zebra.txt",
            "alpha.txt",
            "lib/foo.py",
            "docs/bar.md",
        ])
        root = tree[""]
        names = [name for name, _ in root]
        # Dirs first (alphabetical), then files (alphabetical)
        assert names == ["docs", "lib", "alpha.txt", "zebra.txt"]

    def test_nested_directories(self):
        tree = _build_file_tree(["a/b/c/file.txt"])
        assert tree[""] == [("a", True)]
        assert tree["a"] == [("b", True)]
        assert tree["a/b"] == [("c", True)]
        assert tree["a/b/c"] == [("file.txt", False)]

    def test_multiple_files_same_dir(self):
        tree = _build_file_tree([
            "src/alpha.py",
            "src/beta.py",
        ])
        children = tree["src"]
        names = [name for name, _ in children]
        assert names == ["alpha.py", "beta.py"]

    def test_sibling_dirs_and_files(self):
        tree = _build_file_tree([
            "meta-oe/recipes/rocksdb/files/patch.diff",
            "meta-oe/recipes/rocksdb/rocksdb_1.0.bb",
        ])
        rocksdb = tree["meta-oe/recipes/rocksdb"]
        names = [name for name, _ in rocksdb]
        types = [is_dir for _, is_dir in rocksdb]
        # files/ dir before rocksdb_1.0.bb file
        assert names == ["files", "rocksdb_1.0.bb"]
        assert types == [True, False]

    def test_empty_file_list(self):
        tree = _build_file_tree([])
        assert tree == {}

    def test_case_insensitive_sort(self):
        tree = _build_file_tree(["Makefile", "README.md", "configure"])
        root = tree[""]
        names = [name for name, _ in root]
        assert names == ["configure", "Makefile", "README.md"]


# ────────────────────────────────────────────────────────────────────
# _build_tree_menu_lines
# ────────────────────────────────────────────────────────────────────

class TestBuildTreeMenuLines:
    """Tests for rendering tree structure as fzf menu lines."""

    def _ids(self, output: str):
        """Extract identifier column from tab-separated output."""
        return [line.split("\t")[0] for line in output.splitlines()]

    def test_single_file(self):
        tree = _build_file_tree(["README.md"])
        output = _build_tree_menu_lines(tree, set())
        ids = self._ids(output)
        assert ids == ["FILE:README.md"]

    def test_collapsed_dir(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs=set())
        ids = self._ids(output)
        # Dir collapsed — only the dir entry, no children
        assert ids == ["DIR:src"]

    def test_expanded_dir(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs={"src"})
        ids = self._ids(output)
        assert ids == ["DIR:src", "FILE:src/main.py"]

    def test_nested_expansion(self):
        tree = _build_file_tree(["a/b/file.txt"])
        # Only expand a, not a/b
        output = _build_tree_menu_lines(tree, expanded_dirs={"a"})
        ids = self._ids(output)
        assert ids == ["DIR:a", "DIR:a/b"]

        # Expand both levels
        output = _build_tree_menu_lines(tree, expanded_dirs={"a", "a/b"})
        ids = self._ids(output)
        assert ids == ["DIR:a", "DIR:a/b", "FILE:a/b/file.txt"]

    def test_expanded_file_no_commits(self):
        tree = _build_file_tree(["f.txt"])
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"},
        )
        ids = self._ids(output)
        # File expanded but no commits loaded — shows "(no commits)"
        assert ids == ["FILE:f.txt", "COMMIT:none:f.txt"]

    def test_expanded_file_with_commits(self):
        tree = _build_file_tree(["f.txt"])
        commits = {"f.txt": [("abc123", "first commit"), ("def456", "second")]}
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"}, file_commits=commits,
        )
        ids = self._ids(output)
        assert ids == [
            "FILE:f.txt",
            "COMMIT:abc123:f.txt",
            "COMMIT:def456:f.txt",
        ]

    def test_file_commits_has_more(self):
        tree = _build_file_tree(["f.txt"])
        commits = {"f.txt": [("abc123", "commit msg")]}
        output = _build_tree_menu_lines(
            tree, set(),
            expanded_files={"f.txt"},
            file_commits=commits,
            file_has_more={"f.txt": True},
        )
        ids = self._ids(output)
        assert ids == ["FILE:f.txt", "COMMIT:abc123:f.txt", "MORE:f.txt"]

    def test_file_commits_no_more(self):
        tree = _build_file_tree(["f.txt"])
        commits = {"f.txt": [("abc123", "commit msg")]}
        output = _build_tree_menu_lines(
            tree, set(),
            expanded_files={"f.txt"},
            file_commits=commits,
            file_has_more={"f.txt": False},
        )
        ids = self._ids(output)
        # No MORE entry when has_more is False
        assert "MORE:f.txt" not in ids

    def test_highlight_files_colors_name(self):
        tree = _build_file_tree(["f.txt"])
        output_plain = _build_tree_menu_lines(tree, set())
        output_highlight = _build_tree_menu_lines(
            tree, set(), highlight_files={"f.txt"},
        )
        # Highlighted version should contain ANSI yellow escape
        assert "\033[33m" in output_highlight
        assert "\033[33m" not in output_plain

    def test_highlight_only_specified_files(self):
        tree = _build_file_tree(["a.txt", "b.txt"])
        output = _build_tree_menu_lines(
            tree, set(), highlight_files={"a.txt"},
        )
        lines = output.splitlines()
        a_line = [l for l in lines if l.startswith("FILE:a.txt")][0]
        b_line = [l for l in lines if l.startswith("FILE:b.txt")][0]
        assert "\033[33m" in a_line
        assert "\033[33m" not in b_line

    def test_collapsed_marker(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs=set())
        # Collapsed dir uses right-pointing triangle
        assert "\u25b6" in output

    def test_expanded_marker(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs={"src"})
        # Expanded dir uses down-pointing triangle
        assert "\u25be" in output

    def test_empty_tree(self):
        output = _build_tree_menu_lines({}, set())
        assert output == ""

    def test_dir_trailing_slash(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, set())
        # Display text should show dir name with trailing slash
        display = output.split("\t")[1]
        assert "src/" in display

    def test_commit_hash_truncated_to_10(self):
        tree = _build_file_tree(["f.txt"])
        full_hash = "abcdef1234567890"
        commits = {"f.txt": [(full_hash, "msg")]}
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"}, file_commits=commits,
        )
        # ID preserves full hash
        assert f"COMMIT:{full_hash}:f.txt" in output
        # Display truncates to 10 chars
        lines = output.splitlines()
        commit_line = [l for l in lines if l.startswith("COMMIT:")][0]
        display = commit_line.split("\t")[1]
        assert "abcdef1234" in display
        # Full hash should NOT appear in display text
        assert full_hash not in display

    def test_subject_truncated_to_60(self):
        tree = _build_file_tree(["f.txt"])
        long_subject = "A" * 80
        commits = {"f.txt": [("abc123", long_subject)]}
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"}, file_commits=commits,
        )
        lines = output.splitlines()
        commit_line = [l for l in lines if l.startswith("COMMIT:")][0]
        display = commit_line.split("\t")[1]
        assert "A" * 60 in display
        assert "A" * 61 not in display


# ────────────────────────────────────────────────────────────────────
# _parse_commit_browser_output
# ────────────────────────────────────────────────────────────────────

class TestParseCommitBrowserOutput:
    """Tests for parsing fzf output from the commit browser."""

    def test_back(self):
        assert _parse_commit_browser_output("BACK", [], [], []) == ("back", [])

    def test_quit(self):
        assert _parse_commit_browser_output("QUIT", [], [], []) == ("quit", [])

    def test_unknown_output_returns_back(self):
        assert _parse_commit_browser_output("UNKNOWN_ACTION", [], [], []) == ("back", [])

    def test_empty_output_returns_back(self):
        assert _parse_commit_browser_output("", [], [], []) == ("back", [])

    # -- COPY --

    def test_copy_commit(self):
        assert _parse_commit_browser_output("COPY abc123", [], [], []) == ("copy", ["abc123"])

    def test_copy_separator_ignored(self):
        assert _parse_commit_browser_output("COPY ---", [], [], []) == ("copy", [])

    def test_copy_dirty_ignored(self):
        assert _parse_commit_browser_output("COPY DIRTY", [], [], []) == ("copy", [])

    def test_copy_empty_hash(self):
        assert _parse_commit_browser_output("COPY ", [], [], []) == ("copy", [])

    # -- TIG --

    def test_tig_commit(self):
        assert _parse_commit_browser_output("TIG abc123", [], [], []) == ("tig", ["abc123"])

    def test_tig_separator_ignored(self):
        assert _parse_commit_browser_output("TIG ---", [], [], []) == ("tig", [])

    def test_tig_empty(self):
        assert _parse_commit_browser_output("TIG ", [], [], []) == ("tig", [])

    # -- TREE_MODE --

    def test_tree_mode_with_commit(self):
        action, hashes = _parse_commit_browser_output("TREE_MODE abc123", [], [], [])
        assert action == "tree_mode"
        assert hashes == ["abc123"]

    def test_tree_mode_no_commit(self):
        assert _parse_commit_browser_output("TREE_MODE", [], [], []) == ("tree_mode", [])

    def test_tree_mode_separator_skipped(self):
        assert _parse_commit_browser_output("TREE_MODE ---", [], [], []) == ("tree_mode", [])

    def test_tree_mode_dirty_skipped(self):
        assert _parse_commit_browser_output("TREE_MODE DIRTY", [], [], []) == ("tree_mode", [])

    def test_tree_mode_load_more_skipped(self):
        assert _parse_commit_browser_output("TREE_MODE LOAD_MORE", [], [], []) == ("tree_mode", [])

    # -- LOAD_MORE --

    def test_load_more(self):
        assert _parse_commit_browser_output("LOAD_MORE", [], [], []) == ("load_more", [])

    def test_load_more_with_tab_suffix(self):
        # fzf outputs entire line including tab-separated display text
        assert _parse_commit_browser_output("LOAD_MORE\t   (load more...)", [], [], []) == ("load_more", [])

    # -- Simple actions --

    def test_rebase_interactive(self):
        assert _parse_commit_browser_output("REBASE_INTERACTIVE", [], [], []) == ("rebase_interactive", [])

    def test_layer_view(self):
        assert _parse_commit_browser_output("LAYER_VIEW", [], [], []) == ("layer_view", [])

    # -- EXPORT --

    def test_export_single_hash(self):
        all_hashes = ["aaa111bbb222ccc333"]
        action, hashes = _parse_commit_browser_output("EXPORT aaa111bbb2", all_hashes, [], [])
        assert action == "export"
        assert hashes == ["aaa111bbb222ccc333"]

    def test_export_multiple_hashes(self):
        all_hashes = ["aaa111", "bbb222", "ccc333"]
        action, hashes = _parse_commit_browser_output("EXPORT aaa111 ccc333", all_hashes, [], [])
        assert action == "export"
        assert "aaa111" in hashes
        assert "ccc333" in hashes

    def test_export_filters_separators(self):
        action, hashes = _parse_commit_browser_output("EXPORT --- abc1234 DIRTY", [], [], [])
        assert action == "export"
        # --- and DIRTY should be filtered out; abc1234 kept as-is (len >= 7)
        assert hashes == ["abc1234"]

    def test_export_range_markers(self):
        all_hashes = ["aaa", "bbb", "ccc", "ddd", "eee"]
        # Range markers select from bbb to ddd
        action, hashes = _parse_commit_browser_output(
            "EXPORT aaa", all_hashes, [], ["bbb", "ddd"],
        )
        assert action == "export"
        # Should include range bbb..ddd plus individually selected aaa
        assert "aaa" in hashes
        assert "bbb" in hashes
        assert "ccc" in hashes
        assert "ddd" in hashes

    def test_export_upstream_hash_resolution(self):
        all_upstream = ["upstream_abc123def456"]
        action, hashes = _parse_commit_browser_output(
            "EXPORT upstream_abc12", [], all_upstream, [],
        )
        assert action == "export"
        assert hashes == ["upstream_abc123def456"]

    def test_export_unknown_long_hash_kept(self):
        # Hash not in any list but >= 7 chars — kept as-is
        action, hashes = _parse_commit_browser_output("EXPORT abcdef1", [], [], [])
        assert action == "export"
        assert hashes == ["abcdef1"]

    def test_export_short_hash_dropped(self):
        # Hash < 7 chars and not in any list — dropped
        action, hashes = _parse_commit_browser_output("EXPORT abc", [], [], [])
        assert action == "export"
        assert hashes == []
