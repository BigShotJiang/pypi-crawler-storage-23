#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for fzf_bindings module."""

import pytest

from bitbake_project.fzf_bindings import (
    get_exit_bindings,
    get_accept_binding,
    get_preview_toggle_binding,
    get_preview_scroll_bindings,
    get_preview_line_scroll_bindings,
    get_preview_all_bindings,
    get_toggle_binding,
    get_toggle_all_binding,
    get_multi_select_bindings,
    get_refresh_binding,
    get_action_binding,
    get_action_bindings,
    get_position_binding,
    get_sync_position_binding,
    get_standard_menu_bindings,
    get_browser_bindings,
    get_picker_bindings,
    format_keybinding_help,
    get_standard_header_suffix,
    get_preview_header_suffix,
    KEY_QUIT,
    KEY_ESCAPE,
    KEY_BACK,
)


class TestExitBindings:
    """Tests for exit/navigation bindings."""

    def test_abort_mode(self):
        """Abort mode uses :abort action."""
        bindings = get_exit_bindings(mode="abort")
        assert "--bind" in bindings
        assert "esc:abort" in bindings
        assert "q:abort" in bindings
        assert "left:abort" in bindings

    def test_back_mode(self):
        """Back mode uses become(echo BACK)."""
        bindings = get_exit_bindings(mode="back")
        assert "esc:become(echo BACK)" in bindings
        assert "q:become(echo BACK)" in bindings
        assert "left:become(echo BACK)" in bindings

    def test_back_mode_custom_value(self):
        """Back mode with custom value."""
        bindings = get_exit_bindings(mode="back", back_value="EXIT")
        assert "esc:become(echo EXIT)" in bindings

    def test_quit_mode(self):
        """Quit mode uses become(echo QUIT)."""
        bindings = get_exit_bindings(mode="quit")
        assert "q:become(echo QUIT)" in bindings
        assert "left:become(echo BACK)" in bindings  # Left still goes back

    def test_invalid_mode_raises(self):
        """Invalid mode raises ValueError."""
        with pytest.raises(ValueError):
            get_exit_bindings(mode="invalid")


class TestAcceptBinding:
    """Tests for accept keybinding."""

    def test_default_accept(self):
        """Default accept uses :accept action."""
        bindings = get_accept_binding()
        assert bindings == ["--bind", "right:accept"]

    def test_custom_action(self):
        """Custom action string."""
        bindings = get_accept_binding(action="become(echo SELECT)")
        assert bindings == ["--bind", "right:become(echo SELECT)"]


class TestPreviewBindings:
    """Tests for preview-related bindings."""

    def test_preview_toggle(self):
        """Preview toggle uses ?."""
        bindings = get_preview_toggle_binding()
        assert bindings == ["--bind", "?:toggle-preview"]

    def test_preview_scroll_with_half_page(self):
        """Preview scroll includes half-page by default."""
        bindings = get_preview_scroll_bindings()
        # pgup/pgdn are left unbound (scroll main list)
        assert "pgup:preview-page-up" not in bindings
        assert "pgdn:preview-page-down" not in bindings
        assert "alt-up:preview-page-up" in bindings
        assert "alt-down:preview-page-down" in bindings
        assert "alt-u:preview-half-page-up" in bindings
        assert "alt-d:preview-half-page-down" in bindings

    def test_preview_scroll_without_half_page(self):
        """Preview scroll without half-page."""
        bindings = get_preview_scroll_bindings(include_half_page=False)
        assert "pgup:preview-page-up" not in bindings
        assert "alt-up:preview-page-up" in bindings
        assert "ctrl-u:preview-half-page-up" not in bindings

    def test_preview_line_scroll(self):
        """Line scroll uses shift-up/down and alt-k/j."""
        bindings = get_preview_line_scroll_bindings()
        assert "shift-up:preview-up" in bindings
        assert "shift-down:preview-down" in bindings
        assert "alt-k:preview-up" in bindings
        assert "alt-j:preview-down" in bindings

    def test_preview_all_includes_toggle(self):
        """Preview all includes toggle by default."""
        bindings = get_preview_all_bindings()
        assert "?:toggle-preview" in bindings
        assert "alt-up:preview-page-up" in bindings

    def test_preview_all_without_toggle(self):
        """Preview all without toggle."""
        bindings = get_preview_all_bindings(include_toggle=False)
        assert "?:toggle-preview" not in bindings
        assert "alt-up:preview-page-up" in bindings


class TestSelectionBindings:
    """Tests for selection/toggle bindings."""

    def test_toggle_binding(self):
        """Toggle uses tab."""
        bindings = get_toggle_binding()
        assert bindings == ["--bind", "tab:toggle"]

    def test_toggle_all_binding(self):
        """Toggle all uses ctrl-a."""
        bindings = get_toggle_all_binding()
        assert bindings == ["--bind", "ctrl-a:toggle-all"]

    def test_multi_select_bindings(self):
        """Multi-select includes both toggle bindings."""
        bindings = get_multi_select_bindings()
        assert "tab:toggle" in bindings
        assert "ctrl-a:toggle-all" in bindings


class TestActionBindings:
    """Tests for action bindings."""

    def test_refresh_binding(self):
        """Refresh uses r key."""
        bindings = get_refresh_binding()
        assert bindings == ["--bind", "r:become(echo REFRESH)"]

    def test_refresh_custom_value(self):
        """Refresh with custom value."""
        bindings = get_refresh_binding(action_value="RELOAD")
        assert bindings == ["--bind", "r:become(echo RELOAD)"]

    def test_action_binding(self):
        """Single action binding."""
        bindings = get_action_binding("d", "DELETE")
        assert bindings == ["--bind", "d:become(echo DELETE)"]

    def test_action_bindings_multiple(self):
        """Multiple action bindings from dict."""
        bindings = get_action_bindings({"d": "DELETE", "e": "EDIT"})
        assert "d:become(echo DELETE)" in bindings
        assert "e:become(echo EDIT)" in bindings


class TestPositionBindings:
    """Tests for cursor positioning bindings."""

    def test_position_binding(self):
        """Position at specific line."""
        bindings = get_position_binding(5)
        assert bindings == ["--bind", "load:pos(5)"]

    def test_sync_position_binding(self):
        """Sync position includes --sync."""
        bindings = get_sync_position_binding(10)
        assert "--sync" in bindings
        assert "load:pos(10)" in bindings


class TestCompositeBindings:
    """Tests for composite binding sets."""

    def test_standard_menu_bindings(self):
        """Standard menu includes exit and accept."""
        bindings = get_standard_menu_bindings()
        # Should have exit bindings
        assert any("esc:" in b for b in bindings)
        # Should have accept
        assert any("right:" in b for b in bindings)
        # Should have preview scroll (alt-up, not pgup which scrolls main list)
        assert any("alt-up:" in b for b in bindings)

    def test_standard_menu_no_preview(self):
        """Standard menu without preview."""
        bindings = get_standard_menu_bindings(include_preview=False)
        assert not any("alt-up:" in b for b in bindings)

    def test_browser_bindings(self):
        """Browser includes refresh and preview toggle."""
        bindings = get_browser_bindings()
        assert any("r:become(echo REFRESH)" in b for b in bindings)
        assert any("?:toggle-preview" in b for b in bindings)

    def test_picker_bindings(self):
        """Picker is minimal - just exit and accept."""
        bindings = get_picker_bindings()
        # Should have exit
        assert any("esc:" in b for b in bindings)
        # Should have accept
        assert any("right:" in b for b in bindings)
        # Should NOT have preview
        assert not any("alt-up:" in b for b in bindings)


class TestHeaderHelpers:
    """Tests for header text helpers."""

    def test_format_keybinding_help(self):
        """Format keybinding help text."""
        result = format_keybinding_help(
            ("Enter", "select"),
            ("q", "quit"),
        )
        assert result == "Enter=select | q=quit"

    def test_format_keybinding_help_single(self):
        """Format single keybinding."""
        result = format_keybinding_help(("Enter", "confirm"))
        assert result == "Enter=confirm"

    def test_standard_header_suffix(self):
        """Standard header suffix format."""
        result = get_standard_header_suffix()
        assert "q" in result or "back" in result
        assert "page" in result.lower() or "half-page" in result.lower()

    def test_preview_header_suffix(self):
        """Preview header suffix format."""
        result = get_preview_header_suffix()
        assert "?" in result or "toggle" in result.lower()


class TestKeyConstants:
    """Tests for key constants."""

    def test_key_constants_defined(self):
        """Key constants are strings."""
        assert isinstance(KEY_QUIT, str)
        assert isinstance(KEY_ESCAPE, str)
        assert isinstance(KEY_BACK, str)

    def test_key_constants_not_empty(self):
        """Key constants are not empty."""
        assert KEY_QUIT
        assert KEY_ESCAPE
        assert KEY_BACK
