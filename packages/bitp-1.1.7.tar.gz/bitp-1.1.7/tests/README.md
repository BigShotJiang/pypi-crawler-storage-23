# Tests

This directory contains the test suite for the `bit` tool.

## Running Tests

```bash
# Activate virtual environment first
source .venv/bin/activate

# Run all tests
pytest tests/ -v

# Run only unit tests
pytest tests/unit/ -v

# Run only integration tests
pytest tests/integration/ -v

# Run with coverage report
pytest tests/ --cov=bitbake_project --cov-report=term-missing

# Run tests matching a pattern
pytest tests/ -k "test_colors" -v

# Run a specific test file
pytest tests/unit/test_info.py -v
```

## Test Structure

```
tests/
├── conftest.py           # Shared fixtures
├── unit/                 # Unit tests (fast, no external deps)
│   ├── test_colors.py
│   ├── test_helpers.py
│   ├── test_state.py
│   ├── test_gitrepo.py
│   ├── test_fzf_menu.py
│   ├── test_fzf_bindings.py
│   ├── test_explore.py
│   ├── test_bblayers_parser.py
│   ├── test_cli_parser.py
│   ├── test_info.py
│   └── test_update.py
├── integration/          # Integration tests
│   ├── test_cli_dispatch.py
│   └── test_projects_command.py
└── data/                 # Test data files
    └── bblayers/         # Sample bblayers.conf files
```

## Known Issues

### pytest-mock fixture errors

Some tests in `test_fzf_menu.py` use the `mocker` fixture from pytest-mock.
If you see errors like:

```
E       fixture 'mocker' not found
```

Install pytest-mock:

```bash
pip install pytest-mock
```

Or run tests excluding that file:

```bash
pytest tests/ -v --ignore=tests/unit/test_fzf_menu.py
```

## Writing Tests

### Fixtures

Common fixtures are defined in `conftest.py`:

- `tmp_path` - Temporary directory (pytest built-in)
- `temp_git_repo` - Temporary git repository
- `temp_git_repo_with_remote` - Git repo with origin remote
- `temp_git_repo_with_contrib_remote` - Git repo with origin + contrib remote (branch tracking contrib)
- `temp_bblayers` - Temporary bblayers.conf file
- `temp_defaults` - Temporary .bit.defaults file

### Test Naming

- Test files: `test_<module>.py`
- Test classes: `Test<FeatureName>`
- Test methods: `test_<behavior_description>`

Example:
```python
class TestParseLocalConfVariables:
    def test_parse_simple_assignments(self, tmp_path):
        ...
    def test_missing_file_returns_empty(self, tmp_path):
        ...
```
