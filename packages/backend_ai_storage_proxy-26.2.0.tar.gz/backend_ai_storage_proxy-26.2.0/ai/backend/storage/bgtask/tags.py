from typing import Final, Literal

ROOT_PRIVILEGED_TAG: Final[Literal["privileged"]] = "privileged"
