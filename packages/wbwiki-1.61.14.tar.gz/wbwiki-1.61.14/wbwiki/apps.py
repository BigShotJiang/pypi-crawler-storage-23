from django.apps import AppConfig


class WbwikiConfig(AppConfig):
    name = "wbwiki"
