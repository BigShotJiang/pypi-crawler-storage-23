def test_initial():
    assert True
