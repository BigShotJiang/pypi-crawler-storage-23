"""Core modules for FileMapper."""
