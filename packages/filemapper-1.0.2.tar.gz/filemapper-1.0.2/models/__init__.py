"""Data models for FileMapper."""
