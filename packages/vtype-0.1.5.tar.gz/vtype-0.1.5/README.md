# vtype

**Offline voice input for any focused window.** Press `Ctrl+Alt+V` (Windows/Linux) or `Control+Option+V` (Mac), speak, and your words are typed instantly — no cloud, no API key, no subscription.

Works in Claude Code terminal, VS Code, any text editor, browser, chat app — whatever window is focused.

---

## Install

```bash
pip install vtype
```

> **First run** downloads a speech model (~140 MB). Subsequent runs are instant.

## Usage

```bash
vtype
```

- Press `Ctrl+Alt+V` (Windows/Linux) or `Control+Option+V` (Mac) — starts listening
- Speak naturally
- Silence for ~1 second → transcribes and types into the focused window
- Press the hotkey again to cancel
- `Ctrl+C` to quit

## Requirements

- Python 3.9+
- A microphone

## How it works

- Speech detection runs locally using RMS-based VAD (no network calls)
- Transcription runs on CPU — no GPU required
- Text is typed via OS-level keyboard simulation — works in any window including terminals and browser tabs

## Privacy

Everything runs on your machine. Audio never leaves your device.

## License

MIT
