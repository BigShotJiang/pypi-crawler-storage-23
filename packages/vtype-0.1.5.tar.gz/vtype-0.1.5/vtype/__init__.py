"""vtype — offline voice input for any focused window."""

__version__ = "0.1.5"
