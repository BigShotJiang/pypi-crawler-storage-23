=========
indiapins
=========


.. image:: https://img.shields.io/pypi/v/indiapins?label=PyPI&logo=PyPI&logoColor=white&color=blue
        :target: https://pypi.python.org/pypi/indiapins

.. image:: https://img.shields.io/pypi/pyversions/indiapins?label=Python&logo=Python&logoColor=white
    :target: https://www.python.org/downloads
    :alt: Python versions

.. image:: https://github.com/pawangeek/indiapins/actions/workflows/ci.yml/badge.svg
        :target: https://github.com/pawangeek/indiapins/actions/workflows/ci.yml
        :alt: CI

.. image:: https://static.pepy.tech/badge/indiapins
     :target: https://pepy.tech/project/indiapins
     :alt: Downloads


**Indiapins is a Python package for getting the places tagged to particular Indian pincode**

**Data is last updated February 21, 2026, with 165,627 area pin codes**

* Free software: MIT license
* Documentation: https://pawangeek.github.io/indiapins/
* Github Repo: https://github.com/pawangeek/indiapins
* PyPI: https://pypi.org/project/indiapins/


Installation
------------

Install the plugin using 'pip':

.. code-block:: shell

   $ pip install indiapins

Alternatively, install from source by cloning this repo:

.. code-block:: shell

   $ pip install .


Features
--------
* Get all the mappings of given pins
* The Python sqlite3 module is not required, so easily to use in Clouds (no additional dependencies)
* Works with 3.10, 3.11, 3.12, 3.13, 3.14 and PyPy
* Cross-platform: Windows, Mac, and Linux are officially supported.
* Simple usage and very fast results


Examples
--------

1. Exact Match
##############

To find the names of all places, districts, circles and related information by given Indian Pincode

**Important: The Pincode should be of 6 digits, in string format**

.. code-block:: python

    indiapins.matching('110011')

    [{'Name': 'Nirman Bhawan', 'BranchType': 'PO', 'DeliveryStatus': 'Delivery', 
      'Circle': 'Delhi Circle', 'District': 'NEW DELHI', 'Division': 'New Delhi Central Division', 
      'Region': 'Delhi Region', 'State': 'DELHI', 'Pincode': 110011,
      'Latitude': 28.6108611, 'Longitude': 77.2148611},
     {'Name': 'Udyog Bhawan', 'BranchType': 'PO', 'DeliveryStatus': 'Non Delivery', 
      'Circle': 'Delhi Circle', 'District': 'NEW DELHI', 'Division': 'New Delhi Central Division',
      'Region': 'Delhi Region', 'State': 'DELHI', 'Pincode': 110011,
      'Latitude': 28.6111111, 'Longitude': 77.2127500}]


2. Valid Pincode
################

To check if the given Pincode is valid or not

.. code-block:: python

    indiapins.isvalid('110011')

    True

3. District by Pincode
######################

It extracts the district of given Indian pincode

.. code-block:: python

    indiapins.districtmatch('302005')

    'Jaipur'

4. Coordinates of Pincode
#########################

It extracts all the coordinates of given Indian pincode

.. code-block:: python

    indiapins.coordinates('110011')

    {'Udyog Bhawan': {'latitude': '28.6111111', 'longitude': '77.2127500'},
    'Nirman Bhawan': {'latitude': '28.6108611', 'longitude': '77.2148611'}}
