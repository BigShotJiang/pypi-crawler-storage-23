=======
History
=======
1.0.6 (2026-02-21)
------------------

* Updated all dependencies to latest versions
* Dropped Python 3.9 support, added Python 3.14 support

1.0.5 (2026-02-15)
------------------

* Fixed KeyError bug caused by inconsistent key casing in data
* Updated pincode database with 8,436 new records (165,627 total)
* Enhanced coordinates and district matching functions

1.0.4 (2025-01-26)
------------------

* Added new pins

1.0.2 (2024-08-10)
------------------

* Added latest libs

1.0.1 (2023-09-12)
------------------

* Fix pins import error

0.1.7 (2023-09-11)
------------------

* Update Pincode data to latest (Sept 2023)
* Added coordinates info with pins
* Fetch longitude and latitude of any pin
* Update security vulnerabilities

0.1.0 (2021-07-27)
------------------

* Match location with the pins
* Mark pin is valid or not
* Extract cities on basis of pins
