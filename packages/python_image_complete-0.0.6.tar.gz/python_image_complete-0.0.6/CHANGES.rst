Changelog
=========

0.0.6 (2026-03-02)
------------------

- switched to underscores in project name
- approved astro-jingtao's PR that enhances the image type detection and validation logic (https://github.com/waikato-datamining/python-image-complete/pull/3)


0.0.5 (2023-04-17)
------------------

- added support for *lenient mode* via `strict` and `check_size` parameters


0.0.4 (2023-03-30)
------------------

- added support for determining completeness of bytes or BytesIO objects rather than just file names
- added `is_XYZ` methods that determine whether a file/bytes/BytesIO represents file type `XYZ`


0.0.3 (2023-03-28)
------------------

- added support for: WebP


0.0.2 (2020-01-13)
------------------

- added support for: BMP


0.0.1 (2019-04-17)
------------------

- initial release
- support for: GIF, JPG, PNG
