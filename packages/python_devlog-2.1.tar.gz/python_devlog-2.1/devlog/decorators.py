import asyncio
import logging
import sys
import traceback
from types import FunctionType
from typing import Any, Optional, Tuple, Type, Union

from .base import WrapCallback, LoggingDecorator


class LogOnStart(LoggingDecorator):
    r"""A logging decorator that logs the start of the function.

    This decorator will log the start of the function using the logger and the handler
    provided in the constructor.

    Attributes:
        log_level: The log level to use for logging.
        message: The message format for the log.
        logger: The logger to use for logging.
            If not set, the logger will be created using the module name of the function.
        handler: The handler to use for logging.
        callable_format_variable: The name of the variable to use for the callable.
        args_kwargs: If True, the message will accept {args} {kwargs} format.
        trace_stack: Whether to include the stack trace in the log.
        trace_stack_message:The message format for the stack trace log.
    """

    def __init__(self, log_level: int = logging.INFO,
                 message: Optional[str] = None,
                 **kwargs: Any):
        super().__init__(log_level, message, **kwargs)
        if message is None:
            self.message = "Start func {{{cal_var}.__name__}} " \
                           "with args {{args}}, kwargs {{kwargs}}".format(cal_var=self.callable_format_variable)

    def _devlog_executor(self, fn: FunctionType, *args: Any, **kwargs: Any) -> Any:
        __tracebackhide__ = True
        self._do_logging(fn, *args, **kwargs)
        if self._has_sensitive(args, kwargs):
            args, kwargs = self._unwrap_args(args, kwargs)
        return super()._devlog_executor(fn, *args, **kwargs)

    async def _async_devlog_executor(self, fn: FunctionType, *args: Any, **kwargs: Any) -> Any:
        __tracebackhide__ = True
        self._do_logging(fn, *args, **kwargs)
        if self._has_sensitive(args, kwargs):
            args, kwargs = self._unwrap_args(args, kwargs)
        return await super()._async_devlog_executor(fn, *args, **kwargs)

    def _do_logging(self, fn: FunctionType, *args: Any, **kwargs: Any) -> None:
        logger = self.get_logger(fn)
        extra = {self.callable_format_variable: fn}
        msg = self.build_msg(fn, fn_args=args, fn_kwargs=kwargs, **extra)

        self.log(logger, self.log_level, msg)
        if self.trace_stack:
            sensitive_names, sensitive_objects = self._collect_sensitive_info(fn, args, kwargs)
            tainted = self._find_tainted_vars(
                traceback.walk_stack(None), sensitive_objects
            ) if sensitive_objects else {}
            stack = traceback.StackSummary(
                LoggingDecorator.get_stack_summary(self.include_decorator, capture_locals=self.capture_locals)
            )
            self._sanitize_frame_locals(stack, sensitive_names, tainted)
            self.log(logger, logging.DEBUG, "".join(stack.format()).strip())


class LogOnEnd(LoggingDecorator):
    r"""A logging decorator that logs the end of the function.

    This decorator will log the end of the function using the logger and the handler
    provided in the constructor.

    Attributes:
        log_level: The log level to use for logging.
        message: The message format for the log.
        logger: The logger to use for logging.
            If not set, the logger will be created using the module name of the function.
        handler: The handler to use for logging.
        callable_format_variable: The name of the variable to use for the callable.
        args_kwargs: If True, the message will accept {args} {kwargs} format.
        trace_stack: Whether to include the stack trace in the log.
        trace_stack_message:The message format for the stack trace log.
        result_format_variable: The variable to use for the result.
    """

    def __init__(self, log_level: int = logging.INFO,
                 message: Optional[str] = None, result_format_variable: str = "result",
                 **kwargs: Any):
        super().__init__(log_level, message, **kwargs)
        if message is None:
            self.message = "Successfully run func {{{cal_var}.__name__}} " \
                           "with args {{args}}, kwargs {{kwargs}}".format(cal_var=self.callable_format_variable)
        self.result_format_variable = result_format_variable

    def _devlog_executor(self, fn: FunctionType, *args: Any, **kwargs: Any) -> Any:
        __tracebackhide__ = True
        original_args, original_kwargs = args, kwargs
        if self._has_sensitive(args, kwargs):
            args, kwargs = self._unwrap_args(args, kwargs)
        result = super()._devlog_executor(fn, *args, **kwargs)
        self._do_logging(fn, result, *original_args, **original_kwargs)
        return result

    async def _async_devlog_executor(self, fn: FunctionType, *args: Any, **kwargs: Any) -> Any:
        __tracebackhide__ = True
        original_args, original_kwargs = args, kwargs
        if self._has_sensitive(args, kwargs):
            args, kwargs = self._unwrap_args(args, kwargs)
        result = await super()._async_devlog_executor(fn, *args, **kwargs)
        self._do_logging(fn, result, *original_args, **original_kwargs)
        return result

    def _do_logging(self, fn: FunctionType, result: Any, *args: Any, **kwargs: Any) -> None:
        logger = self.get_logger(fn)

        extra = {self.result_format_variable: result, self.callable_format_variable: fn}
        msg = self.build_msg(fn, fn_args=args, fn_kwargs=kwargs, **extra)

        self.log(logger, self.log_level, msg)
        if self.trace_stack:
            sensitive_names, sensitive_objects = self._collect_sensitive_info(fn, args, kwargs)
            tainted = self._find_tainted_vars(
                traceback.walk_stack(None), sensitive_objects
            ) if sensitive_objects else {}
            stack = traceback.StackSummary(
                LoggingDecorator.get_stack_summary(self.include_decorator, capture_locals=self.capture_locals)
            )
            self._sanitize_frame_locals(stack, sensitive_names, tainted)
            self.log(logger, logging.DEBUG, "".join(stack.format()).strip())


class LogOnError(LoggingDecorator):
    r"""A logging decorator that logs the error of the function.

    This decorator will log the error of the function using the logger and the handler
    provided in the constructor.

    Attributes:
        log_level: The log level to use for logging.
        message: The message format for the log.
        logger: The logger to use for logging.
            If not set, the logger will be created using the module name of the function.
        handler: The handler to use for logging.
        args_kwargs: If True, the message will accept {args} {kwargs} format.
        trace_stack: Whether to include the stack trace in the log.
        trace_stack_message:The message format for the stack trace log.
        on_exception: The exception that will catch. Empty mean everything.
        reraise: Whether to reraise the exception or supress it.
        exception_format_variable: The variable to use for the error.
    """

    def __init__(self, log_level: int = logging.ERROR,
                 message: Optional[str] = None,
                 on_exceptions: Optional[Union[Type[BaseException], Tuple[Type[BaseException], ...]]] = None,
                 reraise: bool = True, exception_format_variable: str = "error", **kwargs: Any):
        super().__init__(log_level, message, **kwargs)
        if message is None:
            self.message = "Error in func {{{cal_var}.__name__}} " \
                           "with args {{args}}, kwargs {{kwargs}}\n{{{except_var}}}.".format(
                cal_var=self.callable_format_variable,
                except_var=exception_format_variable
            )
        self.on_exceptions: Union[Type[BaseException], Tuple[Type[BaseException], ...]] = on_exceptions if \
            on_exceptions is not None else BaseException
        self.reraise = reraise
        self.exception_format_variable = exception_format_variable
        self.capture_locals = self.trace_stack or self.capture_locals

    def _devlog_executor(self, fn: FunctionType, *args: Any, **kwargs: Any) -> Any:
        __tracebackhide__ = True
        original_args, original_kwargs = args, kwargs
        if self._has_sensitive(args, kwargs):
            args, kwargs = self._unwrap_args(args, kwargs)
        try:
            return super()._devlog_executor(fn, *args, **kwargs)
        except BaseException as e:
            self._on_error(fn, e, *original_args, **original_kwargs)

    async def _async_devlog_executor(self, fn: FunctionType, *args: Any, **kwargs: Any) -> Any:
        __tracebackhide__ = True
        original_args, original_kwargs = args, kwargs
        if self._has_sensitive(args, kwargs):
            args, kwargs = self._unwrap_args(args, kwargs)
        try:
            return await super()._async_devlog_executor(fn, *args, **kwargs)
        except BaseException as e:
            self._on_error(fn, e, *original_args, **original_kwargs)

    def _do_logging(self, fn: FunctionType, *args: Any, **kwargs: Any) -> None:
        logger = self.get_logger(fn)
        exc_info = sys.exc_info()
        full_traceback = traceback.TracebackException(*exc_info, capture_locals=self.capture_locals)
        custom_traceback = list(LoggingDecorator.get_stack_summary(
            self.include_decorator, capture_locals=self.capture_locals)
        )

        # exclude all the stack trace that are in this module
        for frame in full_traceback.stack:
            if not LoggingDecorator._is_internal_file(frame.filename) or self.include_decorator:
                custom_traceback.append(frame)

        full_traceback.stack = traceback.StackSummary(custom_traceback)

        sensitive_names, sensitive_objects = self._collect_sensitive_info(fn, args, kwargs)
        tainted = {}
        if sensitive_objects:
            tainted.update(self._find_tainted_vars(traceback.walk_stack(None), sensitive_objects))
            if exc_info[2]:
                tainted.update(self._find_tainted_vars(traceback.walk_tb(exc_info[2]), sensitive_objects))
        self._sanitize_frame_locals(full_traceback.stack, sensitive_names, tainted)

        extra = {self.callable_format_variable: fn,
                 self.exception_format_variable: "".join(list(full_traceback.format(chain=True))).strip()}

        msg = self.build_msg(fn, fn_args=args, fn_kwargs=kwargs, **extra)

        self.log(logger, self.log_level, msg)

    def _on_error(self, fn: FunctionType, exception: BaseException, *args: Any, **kwargs: Any) -> None:
        __tracebackhide__ = True
        if issubclass(exception.__class__, self.on_exceptions) and not hasattr(exception, "_devlog_logged"):
            self._do_logging(fn, *args, **kwargs)
            exception._devlog_logged = True
        if self.reraise:
            raise


# Register this file as internal
LoggingDecorator._internal_files.add(__file__)
