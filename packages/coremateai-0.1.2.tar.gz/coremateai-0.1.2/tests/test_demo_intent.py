from pathlib import Path

import pytest

from coremate.demo_intent import (
    default_intent_dataset,
    predict_demo_intent,
    train_demo_intent_model,
)


@pytest.mark.skipif(
    __import__("importlib").util.find_spec("torch") is None, reason="torch not installed"
)
def test_train_and_predict_demo_model(tmp_path: Path):
    model_path = tmp_path / "demo_intent.pt"
    train_result = train_demo_intent_model(
        model_path,
        epochs=40,
        batch_size=4,
        hidden_dim=32,
        seed=123,
    )
    assert model_path.exists()
    assert train_result.vocab_size > 0
    assert train_result.train_accuracy >= 0.5

    prediction = predict_demo_intent(model_path, "hello can you help me")
    labels = {label for _, label in default_intent_dataset()}
    assert prediction.label in labels
    assert 0.0 <= prediction.confidence <= 1.0
    assert set(prediction.scores.keys()) == labels
