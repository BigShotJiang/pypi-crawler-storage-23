from pathlib import Path

import pytest

from coremate.scaffold import create_ai_project


def test_create_ai_project_generates_files(tmp_path: Path):
    result = create_ai_project("coremateai-demo", base_dir=tmp_path)
    project_dir = Path(result.project_dir)

    assert project_dir.exists()
    assert result.package_name == "coremateai_demo"
    assert (project_dir / "README.md").exists()
    assert (project_dir / "pyproject.toml").exists()
    assert (project_dir / "train.py").exists()
    assert (project_dir / "predict.py").exists()
    assert (project_dir / "config.json").exists()
    assert (project_dir / "src" / result.package_name / "__init__.py").exists()
    assert (project_dir / "artifacts" / ".gitkeep").exists()


def test_create_ai_project_rejects_invalid_name(tmp_path: Path):
    with pytest.raises(ValueError):
        create_ai_project("???", base_dir=tmp_path)


def test_create_ai_project_blocks_non_empty_folder_without_force(tmp_path: Path):
    target = tmp_path / "my-ai"
    target.mkdir()
    (target / "custom.txt").write_text("keep", encoding="utf-8")

    with pytest.raises(FileExistsError):
        create_ai_project("my-ai", base_dir=tmp_path)
