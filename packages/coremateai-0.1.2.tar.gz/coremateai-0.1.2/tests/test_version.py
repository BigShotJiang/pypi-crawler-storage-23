import tomllib
from pathlib import Path

import coremate


def test_version_is_pinned_to_012():
    assert coremate.__version__ == "0.1.2"

    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    assert data["project"]["version"] == "0.1.2"
