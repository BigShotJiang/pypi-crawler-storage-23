"""Small trainable intent-classification demo built on PyTorch."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Sequence

from .ai import build_training_plan, set_global_seed

_TOKEN_PATTERN = re.compile(r"[^\W_]+", flags=re.UNICODE)


@dataclass(frozen=True)
class DemoTrainResult:
    output_path: str
    epochs: int
    batch_size: int
    learning_rate: float
    weight_decay: float
    vocab_size: int
    label_count: int
    final_loss: float
    train_accuracy: float
    device: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class DemoPredictResult:
    text: str
    label: str
    confidence: float
    scores: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _load_torch() -> Any:
    try:
        import torch  # type: ignore
        import torch.nn as nn  # type: ignore

        return torch, nn
    except Exception as error:
        raise RuntimeError(
            "PyTorch is required for demo intent model. Install with: pip install torch"
        ) from error


def default_intent_dataset() -> list[tuple[str, str]]:
    """Return a small built-in intent dataset."""
    return [
        ("hello", "greet"),
        ("hi there", "greet"),
        ("good morning", "greet"),
        ("hey bot", "greet"),
        ("what can you do", "help"),
        ("i need help", "help"),
        ("show commands", "help"),
        ("how does this work", "help"),
        ("train model", "train"),
        ("start training", "train"),
        ("run optimization", "train"),
        ("launch fine tuning", "train"),
        ("stop now", "bye"),
        ("bye", "bye"),
        ("good night", "bye"),
        ("exit app", "bye"),
        ("check gpu status", "gpu"),
        ("show cuda info", "gpu"),
        ("is cuda enabled", "gpu"),
        ("report vram", "gpu"),
    ]


def _tokenize(text: str) -> list[str]:
    return [token.lower() for token in _TOKEN_PATTERN.findall(text)]


def _build_vocab(dataset: Sequence[tuple[str, str]], min_freq: int = 1) -> dict[str, int]:
    frequencies: dict[str, int] = {}
    for text, _ in dataset:
        for token in _tokenize(text):
            frequencies[token] = frequencies.get(token, 0) + 1
    tokens = sorted(token for token, freq in frequencies.items() if freq >= min_freq)
    return {token: index for index, token in enumerate(tokens)}


def _vectorize_text(text: str, vocab: dict[str, int], torch: Any) -> Any:
    vector = torch.zeros(len(vocab), dtype=torch.float32)
    for token in _tokenize(text):
        index = vocab.get(token)
        if index is not None:
            vector[index] += 1.0
    return vector


def _vectorize_dataset(
    dataset: Sequence[tuple[str, str]],
    vocab: dict[str, int],
    label_to_index: dict[str, int],
    torch: Any,
) -> tuple[Any, Any]:
    features = torch.stack([_vectorize_text(text, vocab, torch) for text, _ in dataset])
    targets = torch.tensor([label_to_index[label] for _, label in dataset], dtype=torch.long)
    return features, targets


def _select_device(torch: Any) -> Any:
    if torch.cuda.is_available():
        return torch.device("cuda")
    mps = getattr(getattr(torch, "backends", None), "mps", None)
    if mps is not None and hasattr(mps, "is_available") and mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def train_demo_intent_model(
    output_path: str | Path,
    *,
    dataset: Sequence[tuple[str, str]] | None = None,
    epochs: int = 120,
    batch_size: int = 8,
    hidden_dim: int = 64,
    seed: int = 42,
    deterministic: bool = False,
    weight_decay: float = 0.01,
) -> DemoTrainResult:
    """Train a small intent classifier and save it to disk."""
    torch, nn = _load_torch()
    set_global_seed(seed, deterministic=bool(deterministic))

    train_data = list(dataset) if dataset is not None else default_intent_dataset()
    if len(train_data) < 4:
        raise ValueError("dataset must contain at least 4 examples")

    labels = sorted({label for _, label in train_data})
    label_to_index = {label: index for index, label in enumerate(labels)}
    vocab = _build_vocab(train_data)
    if not vocab:
        raise ValueError("dataset produced empty vocabulary")

    plan = build_training_plan(
        task="nlp",
        model_scale="tiny",
        target_global_batch_size=max(1, int(batch_size)),
        aggressive=True,
    )
    learning_rate = max(float(plan.learning_rate), 0.002)

    features, targets = _vectorize_dataset(train_data, vocab, label_to_index, torch)
    device = _select_device(torch)
    features = features.to(device)
    targets = targets.to(device)

    input_dim = features.shape[1]
    classes = len(labels)
    hidden = max(8, int(hidden_dim))

    model = nn.Sequential(
        nn.Linear(input_dim, hidden),
        nn.ReLU(),
        nn.Linear(hidden, classes),
    ).to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(), lr=learning_rate, weight_decay=float(weight_decay)
    )
    loss_fn = nn.CrossEntropyLoss()

    num_samples = features.shape[0]
    effective_batch = max(1, min(int(batch_size), num_samples))
    final_loss = 0.0

    for _ in range(max(1, int(epochs))):
        permutation = torch.randperm(num_samples, device=device)
        epoch_loss = 0.0
        steps = 0
        for start in range(0, num_samples, effective_batch):
            batch_indices = permutation[start : start + effective_batch]
            batch_x = features[batch_indices]
            batch_y = targets[batch_indices]

            optimizer.zero_grad(set_to_none=True)
            logits = model(batch_x)
            loss = loss_fn(logits, batch_y)
            loss.backward()
            optimizer.step()

            epoch_loss += float(loss.item())
            steps += 1
        final_loss = epoch_loss / max(steps, 1)

    with torch.no_grad():
        logits = model(features)
        predictions = logits.argmax(dim=1)
        accuracy = float((predictions == targets).float().mean().item())

    output = Path(output_path).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "state_dict": model.state_dict(),
            "vocab": vocab,
            "labels": labels,
            "hidden_dim": hidden,
            "input_dim": int(input_dim),
            "seed": int(seed),
        },
        str(output),
    )

    return DemoTrainResult(
        output_path=str(output),
        epochs=max(1, int(epochs)),
        batch_size=effective_batch,
        learning_rate=learning_rate,
        weight_decay=float(weight_decay),
        vocab_size=len(vocab),
        label_count=len(labels),
        final_loss=round(final_loss, 6),
        train_accuracy=round(accuracy, 6),
        device=str(device),
    )


def _load_demo_model(model_path: str | Path) -> tuple[Any, Any, dict[str, int], list[str], Any]:
    torch, nn = _load_torch()
    checkpoint = torch.load(str(Path(model_path).expanduser().resolve()), map_location="cpu")
    vocab = dict(checkpoint["vocab"])
    labels = list(checkpoint["labels"])
    hidden_dim = int(checkpoint["hidden_dim"])
    input_dim = int(checkpoint["input_dim"])

    model = nn.Sequential(
        nn.Linear(input_dim, hidden_dim),
        nn.ReLU(),
        nn.Linear(hidden_dim, len(labels)),
    )
    model.load_state_dict(checkpoint["state_dict"])
    model.eval()
    return torch, model, vocab, labels, _select_device(torch)


def predict_demo_intent(model_path: str | Path, text: str) -> DemoPredictResult:
    """Predict intent for a single text using saved demo model."""
    torch, model, vocab, labels, device = _load_demo_model(model_path)
    model = model.to(device)

    feature = _vectorize_text(text, vocab, torch).unsqueeze(0).to(device)
    with torch.no_grad():
        logits = model(feature)
        probs = torch.softmax(logits, dim=1).squeeze(0).cpu()

    best_index = int(probs.argmax().item())
    scores = {
        label: round(float(probs[index].item()), 6) for index, label in enumerate(labels)
    }
    return DemoPredictResult(
        text=text,
        label=labels[best_index],
        confidence=round(float(probs[best_index].item()), 6),
        scores=scores,
    )
