"""coremate - practical Python utilities for AI and CUDA workflows."""

__version__ = "0.1.2"

from .ai import (
    TrainingPlan,
    TrainingPreset,
    apply_cuda_env_defaults,
    build_training_plan,
    detect_ai_stack,
    optimize_torch_cuda,
    recommend_training_preset,
    recommend_torch_training_kwargs,
    select_accelerator,
    set_global_seed,
    tune_torch_runtime,
)
from .demo_intent import (
    DemoPredictResult,
    DemoTrainResult,
    default_intent_dataset,
    predict_demo_intent,
    train_demo_intent_model,
)
from .scaffold import AICreateResult, create_ai_project

__all__ = [
    "AICreateResult",
    "DemoPredictResult",
    "DemoTrainResult",
    "TrainingPlan",
    "TrainingPreset",
    "__version__",
    "apply_cuda_env_defaults",
    "build_training_plan",
    "default_intent_dataset",
    "detect_ai_stack",
    "create_ai_project",
    "optimize_torch_cuda",
    "predict_demo_intent",
    "recommend_training_preset",
    "recommend_torch_training_kwargs",
    "select_accelerator",
    "set_global_seed",
    "train_demo_intent_model",
    "tune_torch_runtime",
]
