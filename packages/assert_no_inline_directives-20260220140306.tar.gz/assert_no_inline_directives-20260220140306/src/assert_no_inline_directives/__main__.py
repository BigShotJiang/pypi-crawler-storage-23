"""Entry point for running as python -m assert_no_inline_directives."""

from assert_no_inline_directives.cli import main

main()
