"""End-to-end test configuration."""
