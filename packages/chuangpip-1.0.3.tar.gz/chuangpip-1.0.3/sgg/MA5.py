def 你好():
    return "你好"


if __name__ == '__main__':
    result=你好()
    print(result)
