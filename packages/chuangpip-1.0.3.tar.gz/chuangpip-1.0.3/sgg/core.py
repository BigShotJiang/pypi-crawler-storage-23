def add_one(number):
    return number + 1


def helloworld():
    return "hello sgg!"


def hellxiaochaung(name):
    return f"hello xiaochuang {name}!"
