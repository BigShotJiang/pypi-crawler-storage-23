from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Literal,
    NotRequired,
    TypeAlias,
    TypedDict,
    cast,
)

from .credits import CreditsClient
from .fetch import ApiTransport, SSESubscription
from .subscriptions import SubscriptionsClient

if TYPE_CHECKING:
    from .subscribe_user import KotharApiUserEvent


UserKind: TypeAlias = Literal["academic"] | None
UserSubscription: TypeAlias = Literal["pro"] | None


class WithUser(TypedDict):
    userId: str
    fullName: NotRequired[str]
    email: NotRequired[str]


class UserProfile(WithUser):
    userKind: NotRequired[UserKind]
    subscription: NotRequired[UserSubscription]


class UserByIdClient:
    def __init__(self, transport: ApiTransport, user_id: str) -> None:
        self._transport = transport
        self._user_id = user_id
        self.credits = CreditsClient(transport, user_id)
        self.subscriptions = SubscriptionsClient(transport, user_id)

    def get_profile(self) -> UserProfile:
        return cast(
            UserProfile,
            self._transport.get_json(
                "v1/users/:userId", path_params={"userId": self._user_id}
            ),
        )

    def get_customer_portal(self, *, return_url: str | None = None) -> str:
        payload = cast(
            dict[str, str],
            self._transport.post_json(
                "v1/users/:userId/$customerPortal",
                path_params={"userId": self._user_id},
                json_data={"returnUrl": return_url} if return_url else {},
            ),
        )
        return payload["url"]

    def subscribe(
        self, callback: Callable[[KotharApiUserEvent], None]
    ) -> Callable[[], None]:
        subscription = SSESubscription(
            self._transport,
            "v1/users/:userId/events",
            {"userId": self._user_id},
            cast(Callable[[Any], None], callback),
        )
        return subscription.close


class UsersClient:
    def __init__(self, transport: ApiTransport) -> None:
        self._transport = transport
        self.me = UserByIdClient(transport, "me")

    def id(self, user_id: str) -> UserByIdClient:
        return UserByIdClient(self._transport, user_id)
