from __future__ import annotations

from typing import NotRequired, TypedDict, cast

from .fetch import ApiTransport


class RuntimesPage(TypedDict):
    items: list[str]
    next: NotRequired[str]


class RuntimesClient:
    def __init__(self, transport: ApiTransport) -> None:
        self._transport = transport

    def list(
        self, *, next: str | None = None, prefix: str | None = None
    ) -> RuntimesPage:
        return cast(
            RuntimesPage,
            self._transport.get_json(
                "v1/runtimes",
                search_params={"next": next, "prefix": prefix},
            ),
        )
