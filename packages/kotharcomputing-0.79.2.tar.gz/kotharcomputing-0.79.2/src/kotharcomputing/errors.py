from __future__ import annotations

from typing import Any, TypedDict


class ProblemDetails(TypedDict, total=False):
    type: str
    title: str
    status: int
    detail: str
    instance: str


KOTHAR_ERROR_TYPE_BASE_URL = "https://kotharcomputing.com"


class KotharApiError(Exception):
    def __init__(
        self,
        problem_details: ProblemDetails,
        trace_id: str | None = None,
        cause: Exception | None = None,
    ):
        super().__init__(problem_details.get("title") or "Unknown error")
        self.problem_details = problem_details
        self.trace_id = trace_id
        self.__cause__ = cause

    @property
    def type(self) -> str | None:
        value = self.problem_details.get("type")
        return value if isinstance(value, str) else None

    @property
    def title(self) -> str | None:
        value = self.problem_details.get("title")
        return value if isinstance(value, str) else None

    @property
    def status(self) -> int | None:
        value = self.problem_details.get("status")
        return int(value) if isinstance(value, int) else None

    @property
    def detail(self) -> str | None:
        value = self.problem_details.get("detail")
        return value if isinstance(value, str) else None

    @property
    def instance(self) -> str | None:
        value = self.problem_details.get("instance")
        return value if isinstance(value, str) else None

    @property
    def extra(self) -> dict[str, Any]:
        return {
            key: value
            for key, value in self.problem_details.items()
            if key not in {"type", "title", "status", "detail", "instance"}
        }
