from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .agents import AgentsClient
from .fetch import AccessTokenProvider, ApiTransport, QueryParamValue, RawResponse
from .runtimes import RuntimesClient
from .service_prices import ServicePricesClient
from .users import UsersClient
from .workspaces import WorkspacesClient

DEFAULT_BASE_URL = "https://api.kotharcomputing.com"


@dataclass(slots=True)
class KotharClientOptions:
    base_url: str = DEFAULT_BASE_URL
    access_token: AccessTokenProvider | None = None
    timeout: float = 30.0


class KotharClient:
    def __init__(
        self,
        options: KotharClientOptions | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        access_token: AccessTokenProvider | None = None,
        timeout: float = 30.0,
    ) -> None:
        if options is None:
            options = KotharClientOptions(
                base_url=base_url,
                access_token=access_token,
                timeout=timeout,
            )

        self._transport = ApiTransport(
            base_url=options.base_url,
            access_token=options.access_token,
            timeout=options.timeout,
        )

        self.agents = AgentsClient(self._transport)
        self.runtimes = RuntimesClient(self._transport)
        self.service_prices = ServicePricesClient(self._transport)
        self.users = UsersClient(self._transport)
        self.workspaces = WorkspacesClient(self._transport)

        # TS-compat aliases.
        self.servicePrices = self.service_prices
        self.apiVersion = self.api_version
        self._raw = self.raw

    def api_version(self) -> dict[str, str]:
        return self._transport.get_json("version")

    def raw(
        self,
        method: str,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        body: bytes | str | None = None,
        json_data: Any | None = None,
    ) -> RawResponse:
        return self._transport.raw(
            method,
            templated_url,
            path_params=path_params,
            search_params=search_params,
            headers=headers,
            body=body,
            json_data=json_data,
        )
