from __future__ import annotations

from typing import Literal, NotRequired, TypeAlias, TypedDict, cast

from .agents import WithAgent
from .common import JSONValue
from .errors import KotharApiError
from .executions import ExecutionScriptArgs, SystemMetrics
from .fetch import ApiTransport
from .users import WithUser


JobStatus: TypeAlias = Literal[
    "canceled", "created", "failed", "running", "scheduled", "success", "staled"
]


class Job(WithUser, WithAgent):
    id: str
    workspaceId: str
    path: str
    status: JobStatus
    createdAt: str
    isTerminated: bool
    name: NotRequired[str]
    notes: NotRequired[str]
    timeout: NotRequired[str]
    maxThreads: NotRequired[int]
    maxMemoryMb: NotRequired[int]
    executionArgs: NotRequired[ExecutionScriptArgs]
    runningAt: NotRequired[str]
    finishedAt: NotRequired[str]
    duration: NotRequired[str]
    lastPing: NotRequired[str]
    consumedCredits: NotRequired[float]
    data: NotRequired[JSONValue]


class CreateJobArgs(TypedDict):
    agentId: str
    path: str
    runtimeId: NotRequired[str]
    name: NotRequired[str]
    notes: NotRequired[str]
    dependencies: NotRequired[list[str]]
    timeout: NotRequired[str]
    maxThreads: NotRequired[int]
    maxMemoryMb: NotRequired[int]
    executionArgs: NotRequired[ExecutionScriptArgs]


class UpdateJobArgs(TypedDict):
    name: NotRequired[str | None]
    notes: NotRequired[str | None]


class JobsPage(TypedDict):
    items: list[Job]
    next: NotRequired[str]


class JobByIdClient:
    def __init__(self, transport: ApiTransport, workspace_id: str, job_id: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._job_id = job_id

    def get(
        self,
        *,
        with_agents: bool | None = None,
        with_usernames: bool | None = None,
        with_consumed_credits: bool | None = None,
    ) -> Job:
        return cast(
            Job,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/jobs/:jobId",
                path_params={"workspaceId": self._workspace_id, "jobId": self._job_id},
                search_params={
                    "withAgents": with_agents,
                    "withUsernames": with_usernames,
                    "withConsumedCredits": with_consumed_credits,
                },
            ),
        )

    def update(self, args: UpdateJobArgs) -> Job:
        return cast(
            Job,
            self._transport.patch_json(
                "v1/workspaces/:workspaceId/jobs/:jobId",
                path_params={"workspaceId": self._workspace_id, "jobId": self._job_id},
                json_data=args,
            ),
        )

    def cancel(self) -> Job:
        return cast(
            Job,
            self._transport.post_json(
                "v1/workspaces/:workspaceId/jobs/:jobId/$cancel",
                path_params={"workspaceId": self._workspace_id, "jobId": self._job_id},
            ),
        )

    def delete(self) -> None:
        self._transport.raw(
            "delete",
            "v1/workspaces/:workspaceId/jobs/:jobId",
            path_params={"workspaceId": self._workspace_id, "jobId": self._job_id},
        )

    def output(self) -> str:
        return self._transport.raw(
            "get",
            "v1/workspaces/:workspaceId/jobs/:jobId/output",
            path_params={"workspaceId": self._workspace_id, "jobId": self._job_id},
        ).text()

    def metrics(self) -> SystemMetrics | None:
        try:
            return cast(
                SystemMetrics,
                self._transport.get_json(
                    "v1/workspaces/:workspaceId/jobs/:jobId/metrics",
                    path_params={
                        "workspaceId": self._workspace_id,
                        "jobId": self._job_id,
                    },
                ),
            )
        except KotharApiError as error:
            if (error.status or 0) in (403, 404):
                return None
            raise

    def output_download_url(self) -> str:
        payload = cast(
            dict[str, str],
            self._transport.get_json(
                "v1/workspaces/:workspaceId/jobs/$outputDownloadUrl",
                path_params={"workspaceId": self._workspace_id},
                search_params={"jobId": self._job_id},
            ),
        )
        return payload["url"]


class JobsClient:
    def __init__(self, transport: ApiTransport, workspace_id: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id

    def list(
        self,
        *,
        next: str | None = None,
        with_agents: bool | None = None,
        with_usernames: bool | None = None,
        with_consumed_credits: bool | None = None,
    ) -> JobsPage:
        return cast(
            JobsPage,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/jobs",
                path_params={"workspaceId": self._workspace_id},
                search_params={
                    "next": next,
                    "withAgents": with_agents,
                    "withUsernames": with_usernames,
                    "withConsumedCredits": with_consumed_credits,
                },
            ),
        )

    def create(self, args: CreateJobArgs) -> Job:
        return cast(
            Job,
            self._transport.post_json(
                "v1/workspaces/:workspaceId/jobs",
                path_params={"workspaceId": self._workspace_id},
                json_data=args,
            ),
        )

    def id(self, job_id: str) -> JobByIdClient:
        return JobByIdClient(self._transport, self._workspace_id, job_id)
