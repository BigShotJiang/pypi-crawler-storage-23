from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, NotRequired, TypedDict, cast

from .errors import KOTHAR_ERROR_TYPE_BASE_URL, KotharApiError
from .fetch import ApiTransport, extract_filename


class FileListItem(TypedDict):
    path: str
    workspaceId: NotRequired[str]
    etag: NotRequired[str]
    size: NotRequired[int]
    lastModified: NotRequired[str]
    isFolder: NotRequired[bool]


class FileHistoryEntry(TypedDict):
    versionId: str
    date: str
    action: Literal["upload", "delete"]
    isLatest: bool
    size: NotRequired[int]
    etag: NotRequired[str]


class FileSearchResultItem(TypedDict):
    path: str
    line: int
    excerpt: str


class FilesPage(TypedDict):
    items: list[FileListItem]
    next: NotRequired[str]


class FileSearchResult(TypedDict):
    items: list[FileSearchResultItem]


class FileHistoryResult(TypedDict):
    items: list[FileHistoryEntry]


@dataclass(slots=True)
class FileContent:
    data: bytes
    file_name: str
    etag: str | None = None
    mime_type: str | None = None

    def text(self, encoding: str = "utf-8") -> str:
        return self.data.decode(encoding)


class FileByPathClient:
    def __init__(self, transport: ApiTransport, workspace_id: str, path: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._path = path

    def get(self, *, etag: str | None = None) -> FileContent | None:
        response = self._transport.raw(
            "get",
            "v1/workspaces/:workspaceId/files/:filePath",
            path_params={"workspaceId": self._workspace_id, "filePath": self._path},
            headers={"if-none-match": etag} if etag else None,
        )

        if response.status == 304:
            return None

        content_disposition = response.headers.get("content-disposition", "")
        file_name = extract_filename(content_disposition) or self._path.split("/")[-1]
        return FileContent(
            data=response.body,
            file_name=file_name,
            etag=response.headers.get("etag"),
            mime_type=response.headers.get("content-type"),
        )

    def create(
        self, *, as_folder: bool | None = None, content: bytes | str | None = None
    ) -> dict[str, str | None]:
        response = self._transport.raw(
            "post",
            "v1/workspaces/:workspaceId/files/:filePath",
            path_params={"workspaceId": self._workspace_id, "filePath": self._path},
            search_params={"asFolder": as_folder},
            body=content,
        )
        return {"etag": response.headers.get("etag")}

    def update(
        self, *, content: bytes | str, etag: str | None = None
    ) -> dict[str, str]:
        response = self._transport.raw(
            "put",
            "v1/workspaces/:workspaceId/files/:filePath",
            path_params={"workspaceId": self._workspace_id, "filePath": self._path},
            headers={"if-match": etag} if etag else None,
            body=content,
        )
        response_etag = response.headers.get("etag")
        if not response_etag:
            raise KotharApiError(
                {
                    "type": f"{KOTHAR_ERROR_TYPE_BASE_URL}/unexpected-response",
                    "title": "Missing ETag in update response",
                    "status": response.status,
                },
            )
        return {"etag": response_etag}

    def download_url(self) -> str:
        payload = cast(
            dict[str, str],
            self._transport.get_json(
                "v1/workspaces/:workspaceId/files/$downloadUrl",
                path_params={"workspaceId": self._workspace_id},
                search_params={"path": self._path},
            ),
        )
        return payload["url"]

    def move(self, target_path: str) -> None:
        self._transport.raw(
            "post",
            "v1/workspaces/:workspaceId/files/$move",
            path_params={"workspaceId": self._workspace_id},
            json_data={"sourcePath": self._path, "targetPath": target_path},
        )

    def delete(self) -> None:
        self._transport.raw(
            "delete",
            "v1/workspaces/:workspaceId/files/:filePath",
            path_params={"workspaceId": self._workspace_id, "filePath": self._path},
        )

    def history(self) -> FileHistoryResult:
        return cast(
            FileHistoryResult,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/files/$history",
                path_params={"workspaceId": self._workspace_id},
                search_params={"path": self._path},
            ),
        )


class FilesClient:
    def __init__(self, transport: ApiTransport, workspace_id: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id

    def list(
        self,
        *,
        next: str | None = None,
        path: str | None = None,
        limit: int | None = None,
    ) -> FilesPage:
        return cast(
            FilesPage,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/files",
                path_params={"workspaceId": self._workspace_id},
                search_params={"next": next, "path": path, "limit": limit},
            ),
        )

    def search(self, *, search: str) -> FileSearchResult:
        return cast(
            FileSearchResult,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/files/$search",
                path_params={"workspaceId": self._workspace_id},
                search_params={"q": search},
            ),
        )

    def path(self, path: str) -> FileByPathClient:
        return FileByPathClient(self._transport, self._workspace_id, path)
