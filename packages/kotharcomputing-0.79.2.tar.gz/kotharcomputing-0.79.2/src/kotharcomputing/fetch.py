from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
import json
import threading
from typing import Any, Callable, Iterable, Mapping, TypeAlias, cast
from urllib import error as urllib_error
from urllib import parse as urllib_parse
from urllib import request as urllib_request

from .errors import KOTHAR_ERROR_TYPE_BASE_URL, KotharApiError, ProblemDetails

AccessTokenProvider: TypeAlias = str | Callable[[], str | None]
QueryValue: TypeAlias = str | int | float | bool | date | datetime | None
QueryParamValue: TypeAlias = QueryValue | list[QueryValue]


@dataclass(slots=True)
class RawResponse:
    status: int
    headers: dict[str, str]
    body: bytes

    def text(self, encoding: str = "utf-8", errors: str = "strict") -> str:
        return self.body.decode(encoding, errors=errors)

    def json(self) -> Any:
        if not self.body:
            return {}
        return json.loads(self.body.decode("utf-8"))


class SSESubscription:
    def __init__(
        self,
        transport: "ApiTransport",
        templated_url: str,
        path_params: Mapping[str, str] | None,
        callback: Callable[[Any], None],
    ) -> None:
        self._transport = transport
        self._templated_url = templated_url
        self._path_params = path_params
        self._callback = callback
        self._closed = threading.Event()
        self._response_lock = threading.Lock()
        self._current_response: Any | None = None
        self._thread = threading.Thread(
            target=self._run, name="kothar-sse-subscription", daemon=True
        )
        self._thread.start()

    def close(self) -> None:
        self._closed.set()
        self._close_current_response()

    def _set_current_response(self, response: Any | None) -> None:
        with self._response_lock:
            self._current_response = response

    def _close_current_response(self) -> None:
        with self._response_lock:
            response = self._current_response
            self._current_response = None
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    def _run(self) -> None:
        try:
            while not self._closed.is_set():
                try:
                    with self._transport.open_sse_stream(
                        "get",
                        self._templated_url,
                        path_params=self._path_params,
                    ) as response:
                        self._set_current_response(response)
                        for payload in self._transport.iter_sse_payloads(response):
                            if self._closed.is_set():
                                return
                            try:
                                self._callback(payload)
                            except Exception:
                                pass
                except Exception:
                    if self._closed.is_set():
                        return
                finally:
                    self._set_current_response(None)

                if self._closed.wait(1.0):
                    return
        finally:
            self._close_current_response()


class ApiTransport:
    def __init__(
        self,
        base_url: str,
        access_token: AccessTokenProvider | None,
        timeout: float,
    ) -> None:
        self.base_url = base_url if base_url.endswith("/") else f"{base_url}/"
        self._access_token = access_token
        self._timeout = timeout
        self._opener = urllib_request.build_opener()

    def get_access_token(self) -> str | None:
        if isinstance(self._access_token, str):
            return _normalize_access_token(self._access_token)
        if callable(self._access_token):
            return _normalize_access_token(self._access_token())
        return None

    def get_json(
        self,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
    ) -> Any:
        return self.raw(
            "get",
            templated_url,
            path_params=path_params,
            search_params=search_params,
            headers=headers,
        ).json()

    def post_json(
        self,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        json_data: Any | None = None,
    ) -> Any:
        return self.raw(
            "post",
            templated_url,
            path_params=path_params,
            search_params=search_params,
            headers=headers,
            json_data=json_data,
        ).json()

    def put_json(
        self,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        json_data: Any | None = None,
    ) -> Any:
        return self.raw(
            "put",
            templated_url,
            path_params=path_params,
            search_params=search_params,
            headers=headers,
            json_data=json_data,
        ).json()

    def patch_json(
        self,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        json_data: Any | None = None,
    ) -> Any:
        return self.raw(
            "patch",
            templated_url,
            path_params=path_params,
            search_params=search_params,
            headers=headers,
            json_data=json_data,
        ).json()

    def delete_json(
        self,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        json_data: Any | None = None,
    ) -> Any:
        return self.raw(
            "delete",
            templated_url,
            path_params=path_params,
            search_params=search_params,
            headers=headers,
            json_data=json_data,
        ).json()

    def raw(
        self,
        method: str,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        body: bytes | str | None = None,
        json_data: Any | None = None,
        absolute_url: bool = False,
    ) -> RawResponse:
        if body is not None and json_data is not None:
            raise ValueError("Only one of body or json_data can be provided")

        request_headers: dict[str, str] = {
            key: value for key, value in (headers or {}).items() if value is not None
        }

        access_token = self.get_access_token()
        if access_token:
            request_headers["Authorization"] = f"Bearer {access_token}"

        data: bytes | None
        if json_data is not None:
            request_headers["Content-Type"] = "application/json"
            data = json.dumps(
                json_data, separators=(",", ":"), default=_json_default
            ).encode("utf-8")
        elif isinstance(body, str):
            data = body.encode("utf-8")
        else:
            data = body

        url = self.build_url(
            templated_url,
            path_params=path_params,
            search_params=search_params,
            absolute_url=absolute_url,
        )

        request = urllib_request.Request(
            url, data=data, method=method.upper(), headers=request_headers
        )
        try:
            with self._opener.open(request, timeout=self._timeout) as response:
                payload = response.read()
                return RawResponse(
                    status=response.getcode(),
                    headers={k.lower(): v for k, v in response.headers.items()},
                    body=payload,
                )
        except urllib_error.HTTPError as exc:
            payload = exc.read()
            raw_response = RawResponse(
                status=exc.code,
                headers={k.lower(): v for k, v in exc.headers.items()},
                body=payload,
            )
            if raw_response.status == 304:
                return raw_response
            raise self._to_api_error(raw_response, cause=exc) from exc
        except urllib_error.URLError as exc:
            raise KotharApiError(
                {
                    "type": f"{KOTHAR_ERROR_TYPE_BASE_URL}/unknown",
                    "title": str(exc.reason),
                    "status": 0,
                },
                cause=exc,
            ) from exc

    def sse(
        self,
        method: str,
        templated_url: str,
        callback: Callable[[Any], None],
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        body: bytes | str | None = None,
        json_data: Any | None = None,
        absolute_url: bool = False,
    ) -> None:
        with self.open_sse_stream(
            method,
            templated_url,
            path_params=path_params,
            search_params=search_params,
            headers=headers,
            body=body,
            json_data=json_data,
            absolute_url=absolute_url,
        ) as response:
            for payload in self.iter_sse_payloads(response):
                callback(payload)

    def open_sse_stream(
        self,
        method: str,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        headers: Mapping[str, str | None] | None = None,
        body: bytes | str | None = None,
        json_data: Any | None = None,
        absolute_url: bool = False,
    ) -> Any:
        if body is not None and json_data is not None:
            raise ValueError("Only one of body or json_data can be provided")

        request_headers: dict[str, str] = {
            "Accept": "text/event-stream",
            **{
                key: value
                for key, value in (headers or {}).items()
                if value is not None
            },
        }

        access_token = self.get_access_token()
        if access_token:
            request_headers["Authorization"] = f"Bearer {access_token}"

        data: bytes | None
        if json_data is not None:
            request_headers["Content-Type"] = "application/json"
            data = json.dumps(
                json_data, separators=(",", ":"), default=_json_default
            ).encode("utf-8")
        elif isinstance(body, str):
            data = body.encode("utf-8")
        else:
            data = body

        url = self.build_url(
            templated_url,
            path_params=path_params,
            search_params=search_params,
            absolute_url=absolute_url,
        )

        request = urllib_request.Request(
            url, data=data, method=method.upper(), headers=request_headers
        )
        try:
            response = self._opener.open(request, timeout=self._timeout)
        except urllib_error.HTTPError as exc:
            payload = exc.read()
            raise self._to_api_error(
                RawResponse(
                    status=exc.code,
                    headers={k.lower(): v for k, v in exc.headers.items()},
                    body=payload,
                ),
                cause=exc,
            ) from exc
        except urllib_error.URLError as exc:
            raise KotharApiError(
                {
                    "type": f"{KOTHAR_ERROR_TYPE_BASE_URL}/unknown",
                    "title": str(exc.reason),
                    "status": 0,
                },
                cause=exc,
            ) from exc

        content_type = response.headers.get("content-type", "")
        if "text/event-stream" not in content_type:
            raw = response.read()
            response.close()
            raise KotharApiError(
                {
                    "type": f"{KOTHAR_ERROR_TYPE_BASE_URL}/unexpected-response",
                    "title": "Expected text/event-stream response",
                    "status": response.getcode(),
                    "detail": raw.decode("utf-8", errors="replace") if raw else "",
                },
                trace_id=response.headers.get("x-trace-id"),
            )
        return response

    def iter_sse_payloads(self, response: Any) -> Iterable[Any]:
        data_lines: list[str] = []

        while True:
            raw_line = response.readline()
            if not raw_line:
                break

            line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")
            if line == "":
                if data_lines:
                    payload = "\n".join(data_lines)
                    data_lines.clear()
                    try:
                        yield json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                continue

            if line.startswith(":"):
                continue

            field, separator, value = line.partition(":")
            if not separator:
                continue
            if value.startswith(" "):
                value = value[1:]

            if field == "data":
                data_lines.append(value)

        if data_lines:
            payload = "\n".join(data_lines)
            try:
                yield json.loads(payload)
            except json.JSONDecodeError:
                return

    def build_url(
        self,
        templated_url: str,
        *,
        path_params: Mapping[str, str | int | bool] | None = None,
        search_params: Mapping[str, QueryParamValue] | None = None,
        absolute_url: bool = False,
    ) -> str:
        templated = templated_url
        if path_params:
            for key, value in path_params.items():
                templated = templated.replace(
                    f":{key}", urllib_parse.quote(_to_string(value), safe="")
                )

        if (
            absolute_url
            or templated.startswith("http://")
            or templated.startswith("https://")
        ):
            if not templated.startswith(self.base_url):
                raise ValueError(
                    f"The URL {templated} does not start with the base URL {self.base_url}"
                )
            parsed = urllib_parse.urlsplit(templated)
            query_items = urllib_parse.parse_qsl(parsed.query, keep_blank_values=True)
            query_items.extend(_query_items(search_params))
            final_query = urllib_parse.urlencode(query_items, doseq=True)
            return urllib_parse.urlunsplit(
                (
                    parsed.scheme,
                    parsed.netloc,
                    parsed.path,
                    final_query,
                    parsed.fragment,
                )
            )

        path = templated[1:] if templated.startswith("/") else templated
        url = urllib_parse.urljoin(self.base_url, path)
        query_items = _query_items(search_params)
        if not query_items:
            return url
        separator = "&" if urllib_parse.urlsplit(url).query else "?"
        return f"{url}{separator}{urllib_parse.urlencode(query_items, doseq=True)}"

    def _to_api_error(
        self, response: RawResponse, cause: Exception | None = None
    ) -> KotharApiError:
        content_type = response.headers.get("content-type", "")
        trace_id = response.headers.get("x-trace-id")

        if "application/problem+json" in content_type:
            try:
                payload = cast(ProblemDetails, response.json())
                return KotharApiError(payload, trace_id=trace_id, cause=cause)
            except Exception:
                pass

        title = response.text(errors="replace") if response.body else "Unknown error"
        return KotharApiError(
            {
                "type": f"{KOTHAR_ERROR_TYPE_BASE_URL}/unknown",
                "title": title,
                "status": response.status,
            },
            trace_id=trace_id,
            cause=cause,
        )


def to_optional_iso(value: date | datetime | str | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return value.isoformat()


def extract_filename(content_disposition: str) -> str | None:
    if not content_disposition:
        return None

    _, _, filename_part = content_disposition.partition("filename=")
    if not filename_part:
        return None

    filename = filename_part.strip()
    if filename.startswith('"') and filename.endswith('"') and len(filename) >= 2:
        filename = filename[1:-1]
    return filename or None


def _to_string(value: str | int | bool) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _json_default(value: Any) -> Any:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def _query_items(
    search_params: Mapping[str, QueryParamValue] | None,
) -> list[tuple[str, str]]:
    if not search_params:
        return []

    items: list[tuple[str, str]] = []
    for key, value in search_params.items():
        if value is None:
            continue
        if isinstance(value, list):
            for item in value:
                if item is None:
                    continue
                items.append((key, _query_value_to_string(item)))
        else:
            items.append((key, _query_value_to_string(value)))
    return items


def _query_value_to_string(value: QueryValue) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value)


def _normalize_access_token(token: Any) -> str | None:
    if not isinstance(token, str):
        return None

    normalized = token.strip()
    if normalized.lower().startswith("bearer "):
        normalized = normalized[7:].strip()
    return normalized or None
