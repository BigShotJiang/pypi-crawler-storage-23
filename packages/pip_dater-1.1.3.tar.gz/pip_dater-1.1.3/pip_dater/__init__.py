from pip_dater.main import main

__version__ = "1.1.3"
__all__ = ['main', '__version__']
