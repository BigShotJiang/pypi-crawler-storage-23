"""
Helper functions.
"""
import subprocess


def runtime_output(args, indent='  ', verbose=False):
    """Display in realtime the output of the subprocess.
    Return the error code and the whole output (stdout+stderr).
    """
    cursor = '-\\|/'
    output = ''
    with subprocess.Popen(args, shell=False, text=True, bufsize=1,                     
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT
                          ) as process:
        for line in process.stdout:
            output += line
            if verbose:
                print(indent, line, end='')
            else:
                print(indent, cursor[0], '\r', end='')
                cursor = cursor[1:] + cursor[0]
        if not verbose: print(indent, ' ', '\r', end='')  # cleanup
        process.communicate()
        process.wait()  # DEBUG: is this really required?
        returncode = process.returncode
    return returncode, output


##########################
if __name__ == "__main__":
    # test runtime_output
    err1, out1 = runtime_output("pip install --help", verbose=True)
    err2, out2 = runtime_output("pip install --help", verbose=False)
    print(err1, len(out1))
    print(err2, len(out2))
