# pip-dater
This is just another utility for the maintenance of the python packages.
In particular it can be useful to create a repository of packages to be copied and installed on offline machines.

The functions are:
  * CHECK the consistency of the environment
  * UPGRADE as many packages as possible without breaking any dependency
  * DOWNLOAD all the required packages to clone the environment

Check and upgrade are based on pip --dry-run, which is very safe but very slow.
A local database of rejected upgrades is used to speed-up the process on next runs.


## Installation

```
   pip install pip-dater
```
