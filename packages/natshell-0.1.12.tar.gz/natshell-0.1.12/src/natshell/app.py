"""NatShell TUI application — the main user interface."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.events import MouseUp
from textual.widgets import Button, Footer, Input, Static

from natshell.agent.loop import AgentEvent, AgentLoop, EventType
from natshell.agent.plan import Plan, PlanStep, parse_plan_file
from natshell.config import (
    NatShellConfig,
    save_engine_preference,
    save_model_config,
    save_ollama_default,
)
from natshell.inference.engine import ToolCall
from natshell.inference.ollama import (
    get_model_context_length,
    list_models,
    normalize_base_url,
    ping_server,
)
from natshell.safety.classifier import Risk
from natshell.tools.execute_shell import (
    execute_shell,
    needs_sudo_password,
    set_sudo_password,
)
from natshell.ui import clipboard
from natshell.ui.commands import MODELS_DIR, ModelSwitchProvider
from natshell.ui.widgets import (
    AssistantMessage,
    BlockedMessage,
    CommandBlock,
    ConfirmScreen,
    HelpMessage,
    HistoryInput,
    LogoBanner,
    PlanningMessage,
    PlanOverviewMessage,
    PlanStepDivider,
    PlanSummaryMessage,
    RunStatsMessage,
    SudoPasswordScreen,
    SystemMessage,
    ThinkingIndicator,
    UserMessage,
    _escape,
)


def _tool_display_text(tool_call: ToolCall) -> str:
    """Human-readable command text for the EXECUTING display block."""
    match tool_call.name:
        case "execute_shell":
            return tool_call.arguments.get("command", str(tool_call.arguments))
        case "edit_file":
            return f"edit_file \u2192 {tool_call.arguments.get('path', '?')}"
        case "run_code":
            lang = tool_call.arguments.get("language", "?")
            return f"run_code \u2192 {lang}"
        case "write_file":
            return f"write_file \u2192 {tool_call.arguments.get('path', '?')}"
        case _:
            return f"{tool_call.name}({tool_call.arguments})"


logger = logging.getLogger(__name__)


def _shallow_tree(directory: Path, max_depth: int = 2) -> str:
    """Build a compact directory tree string (2 levels deep, no hidden files)."""
    lines: list[str] = [f"{directory}/"]

    def _walk(path: Path, prefix: str, depth: int) -> None:
        if depth > max_depth:
            return
        try:
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except OSError:
            return
        entries = [e for e in entries if not e.name.startswith(".")]
        for i, entry in enumerate(entries):
            connector = "\u2514\u2500 " if i == len(entries) - 1 else "\u251c\u2500 "
            extension = "   " if i == len(entries) - 1 else "\u2502  "
            if entry.is_dir():
                lines.append(f"{prefix}{connector}{entry.name}/")
                _walk(entry, prefix + extension, depth + 1)
            else:
                lines.append(f"{prefix}{connector}{entry.name}")

    _walk(directory, "  ", 1)
    return "\n".join(lines)


def _build_step_prompt(
    step: PlanStep, plan: Plan, completed_summaries: list[str], max_steps: int = 25
) -> str:
    """Build a focused prompt for a single plan step.

    Includes the step body, one-line summaries of completed steps,
    project directory tree, preamble context, budget guidance,
    and a directive to not read plan files.
    """
    parts = [f"Execute this task (step {step.number} of {len(plan.steps)}):"]

    # Include project directory structure so the model doesn't waste steps discovering it
    if plan.source_dir and plan.source_dir.is_dir():
        tree = _shallow_tree(plan.source_dir)
        parts.append(f"\nProject layout:\n{tree}")

    # Include preamble context (tech stack, conventions, key interfaces)
    if plan.preamble:
        parts.append(f"\nProject context:\n{plan.preamble}")

    if completed_summaries:
        parts.append("\nPreviously completed:")
        for summary in completed_summaries:
            parts.append(f"  {summary}")

    parts.append(f"\n## {step.title}\n")
    parts.append(step.body)
    parts.append(
        f"\nYou have {max_steps} tool calls for this step. Prioritize core implementation over "
        "validation. Do not re-read files you just wrote. Do not start long-running servers "
        "unless the step specifically requires it. If you must start a server for testing, "
        "kill it before finishing."
    )
    parts.append(
        "\nExecute this step now. All instructions are above \u2014 do not read any plan files."
    )

    return "\n".join(parts)


def _build_plan_prompt(description: str, directory_tree: str) -> str:
    """Build a prompt that instructs the model to generate a PLAN.md file."""
    parts = [
        "Generate a multi-step plan file called PLAN.md in the current directory.",
        "",
        "User's request:",
        description,
        "",
        "Current directory:",
        directory_tree,
        "",
        "Plan format — the file MUST use this exact markdown structure:",
        "",
        "  # Plan Title",
        "  ",
        "  Preamble with shared context: tech stack, file structure, naming",
        "  conventions, key interfaces. This context carries across all steps.",
        "  ",
        "  ## Step 1: Title describing what this step does",
        "  ",
        "  Detailed instructions. Include exact file paths, function names,",
        "  data structures. A small LLM executes each step independently.",
        "  ",
        "  ## Step 2: Next step title",
        "  ...",
        "",
        "Rules:",
        "- First line: # heading (plan title)",
        "- Preamble BEFORE the first ## heading with shared context",
        "- Each step: ## heading (not ###)",
        "- Each step: 1-3 files, achievable in under 15 tool calls",
        "- Include exact names: functions, variables, file paths, types",
        "- Order by dependency — foundations first",
        "- 3-10 steps depending on complexity",
        "",
        "Execution quality:",
        "- Each step is executed by a small LLM with NO memory of previous steps",
        "  (only one-line summaries). Include ALL context needed in each step.",
        "- When a file depends on config from another file (e.g., import style",
        "  matching package.json \"type\"), state the dependency explicitly.",
        "- Test steps must specify: framework setup, state isolation between tests,",
        "  and the exact validation command.",
        "- Do not include \"start the server and verify in browser\" as validation.",
        "  Use test commands or scripts that start/stop automatically.",
        "",
        "Quality expectations:",
        "- READ the actual source files before writing about them. Use read_file",
        "  on key modules — do not summarize from file names alone.",
        "- Look for architecture docs (README, CONTRIBUTING, design docs, etc.)",
        "  in the project root and read them to understand documented conventions",
        "  and design decisions before proposing changes.",
        "- Be specific: reference exact file paths, function names, line ranges,",
        "  and concrete problems or patterns found.",
        "- Suggestions must be actionable and evidence-based, not generic advice",
        '  like "add more robust validation" or "improve error handling".',
        "- If reviewing code, cite the specific code that needs improvement and",
        "  explain why, not just which module it's in.",
        "",
        "First examine the directory with list_directory. Read key source files",
        "and any project documentation (README, design docs, etc.) to understand",
        "the codebase before writing PLAN.md.",
    ]
    return "\n".join(parts)


SLASH_COMMANDS = [
    ("/help", "Show available commands"),
    ("/clear", "Clear chat and model context"),
    ("/compact", "Compact context, keeping key facts"),
    ("/cmd", "Execute a shell command directly"),
    ("/exeplan", "Preview or execute a multi-step plan"),
    ("/plan", "Generate a multi-step plan from a description"),
    ("/model", "Show current engine/model info"),
    ("/model list", "List models on the remote server"),
    ("/model use", "Switch to a remote model"),
    ("/model switch", "Switch to a different local model"),
    ("/model local", "Switch back to local model"),
    ("/model default", "Set default remote model"),
    ("/history", "Show conversation context size"),
]


class NatShellApp(App):
    """The NatShell TUI application."""

    TITLE = "NatShell"
    SUB_TITLE = "Natural Language Shell"
    CSS_PATH = Path("ui/styles.tcss")
    COMMANDS = App.COMMANDS | {ModelSwitchProvider}

    ALLOW_SELECT = True

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True),
        Binding("ctrl+e", "copy_chat", "Copy Chat"),
        Binding("ctrl+l", "clear_chat", "Clear Chat"),
        Binding("ctrl+y", "copy_selection", "Copy", show=False),
    ]

    def __init__(
        self,
        agent: AgentLoop,
        config: NatShellConfig | None = None,
        skip_permissions: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.agent = agent
        self._config = config or NatShellConfig()
        self._busy = False
        self._skip_permissions = skip_permissions

    def compose(self) -> ComposeResult:
        yield LogoBanner()
        yield ScrollableContainer(
            Static(
                "[dim]Welcome to NatShell. Type a request to get started."
                " Use /help for commands.[/]\n"
            ),
            id="conversation",
        )
        with Vertical(id="input-area"):
            yield Static(id="slash-suggestions")
            with Horizontal(id="input-row"):
                yield HistoryInput(
                    placeholder="Ask me anything about your system...",
                    id="user-input",
                )
                yield Button("\U0001f4cb", id="paste-btn", variant="default")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#user-input", Input).focus()
        if self._skip_permissions:
            conversation = self.query_one("#conversation", ScrollableContainer)
            conversation.mount(
                Static(
                    "[bold yellow]WARNING: --danger-fast is active. "
                    "All confirmations will be skipped.[/]\n"
                )
            )

    @on(Input.Changed, "#user-input")
    def on_input_changed(self, event: Input.Changed) -> None:
        """Show/hide slash command suggestions as the user types."""
        text = event.value
        suggestions = self.query_one("#slash-suggestions", Static)

        if text.startswith("/") and " " not in text:
            matches = [(cmd, desc) for cmd, desc in SLASH_COMMANDS if cmd.startswith(text.lower())]
            if matches:
                lines = [f"  [bold cyan]{cmd}[/]  [dim]{desc}[/]" for cmd, desc in matches]
                suggestions.update("\n".join(lines))
                suggestions.display = True
                return

        suggestions.display = False

    @on(Input.Submitted, "#user-input")
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        input_widget = self.query_one("#user-input", HistoryInput)
        user_text = input_widget.get_submit_text().strip()
        self.query_one("#slash-suggestions", Static).display = False
        if not user_text or self._busy:
            return

        input_widget.add_to_history(user_text)
        input_widget.value = ""
        input_widget.clear_paste()

        # Intercept slash commands before the agent
        if user_text.startswith("/"):
            await self._handle_slash_command(user_text)
            return

        self._busy = True

        # Add user message to conversation
        conversation = self.query_one("#conversation", ScrollableContainer)
        conversation.mount(UserMessage(user_text))

        # Run the agent loop
        self.run_agent(user_text)

    def _render_agent_event(
        self,
        event: AgentEvent,
        conversation: ScrollableContainer,
        thinking_ref: list[ThinkingIndicator | None],
    ) -> None:
        """Render a single agent event into the conversation. Shared by run_agent and run_plan.

        thinking_ref is a single-element list holding the current ThinkingIndicator
        (or None), used as a mutable reference so callers can track it.
        """
        thinking = thinking_ref[0]

        # Remove thinking indicator when we get a real event
        if thinking and event.type in (
            EventType.PLANNING,
            EventType.TOOL_RESULT,
            EventType.RESPONSE,
            EventType.BLOCKED,
            EventType.ERROR,
        ):
            thinking.remove()
            thinking_ref[0] = None
            self.query_one(LogoBanner).stop_animation()

        match event.type:
            case EventType.THINKING:
                if not thinking_ref[0]:
                    indicator = ThinkingIndicator()
                    conversation.mount(indicator)
                    thinking_ref[0] = indicator
                    self.query_one(LogoBanner).start_animation()

            case EventType.PLANNING:
                conversation.mount(PlanningMessage(event.data))

            case EventType.EXECUTING:
                cmd = _tool_display_text(event.tool_call)
                block = CommandBlock(cmd)
                block.id = f"cmd-{event.tool_call.id}"
                conversation.mount(block)

            case EventType.TOOL_RESULT:
                block_id = f"cmd-{event.tool_call.id}"
                try:
                    block = self.query_one(f"#{block_id}", CommandBlock)
                    block.set_result(
                        event.tool_result.output or event.tool_result.error,
                        event.tool_result.exit_code,
                    )
                except Exception:
                    conversation.mount(
                        CommandBlock(
                            str(event.tool_call.arguments),
                            event.tool_result.output or event.tool_result.error,
                            event.tool_result.exit_code,
                        )
                    )

            case EventType.BLOCKED:
                cmd = event.tool_call.arguments.get("command", str(event.tool_call.arguments))
                conversation.mount(BlockedMessage(cmd))

            case EventType.RESPONSE:
                conversation.mount(AssistantMessage(event.data, metrics=event.metrics))

            case EventType.RUN_STATS:
                if event.metrics:
                    conversation.mount(RunStatsMessage(event.metrics))

            case EventType.ERROR:
                conversation.mount(Static(f"[bold red]Error:[/] {_escape(event.data)}"))

        conversation.scroll_end()

    @work(exclusive=True, thread=False)
    async def run_agent(self, user_text: str) -> None:
        """Run the agent loop in a background worker."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        thinking_ref: list[ThinkingIndicator | None] = [None]

        async def confirm_callback(tool_call: ToolCall) -> bool:
            return await self.push_screen_wait(ConfirmScreen(tool_call))

        async def password_callback(tool_call: ToolCall) -> str | None:
            command = tool_call.arguments.get("command", "")
            return await self.push_screen_wait(SudoPasswordScreen(command))

        confirm_cb = None if self._skip_permissions else confirm_callback

        try:
            async for event in self.agent.handle_user_message(
                user_text,
                confirm_callback=confirm_cb,
                password_callback=password_callback,
            ):
                self._render_agent_event(event, conversation, thinking_ref)

        except Exception as e:
            conversation.mount(Static(f"[bold red]Agent error:[/] {_escape(str(e))}"))

        finally:
            if thinking_ref[0]:
                thinking_ref[0].remove()
            self._busy = False
            self.query_one(LogoBanner).stop_animation()
            self.query_one("#user-input", Input).focus()

    async def _handle_slash_command(self, text: str) -> None:
        """Parse and dispatch slash commands."""
        parts = text.split(maxsplit=1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""
        conversation = self.query_one("#conversation", ScrollableContainer)

        match command:
            case "/help":
                self._show_help(conversation)
            case "/clear":
                self.action_clear_chat()
            case "/compact":
                self._compact_chat(conversation)
            case "/cmd":
                if not args:
                    conversation.mount(SystemMessage("Usage: /cmd <command>"))
                else:
                    self.run_cmd(args)
            case "/exeplan":
                self._handle_exeplan_command(args, conversation)
            case "/plan":
                if not args:
                    conversation.mount(
                        SystemMessage(
                            "Usage: /plan <description>\n"
                            "Example: /plan build a REST API with Express and SQLite"
                        )
                    )
                else:
                    self._handle_plan_command(args, conversation)
            case "/model":
                await self._handle_model_command(args, conversation)
            case "/history":
                self._show_history_info(conversation)
            case _:
                conversation.mount(
                    SystemMessage(f"Unknown command: {command}. Type /help for available commands.")
                )

        conversation.scroll_end()

    @work(exclusive=True, thread=False)
    async def run_cmd(self, command: str) -> None:
        """Execute a shell command directly, bypassing the AI. Runs in a worker
        so that push_screen_wait (for confirmation/sudo password) works."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        conversation.mount(UserMessage(f"/cmd {command}"))

        # Safety classification
        risk = self.agent.safety.classify_command(command)

        if risk == Risk.BLOCKED:
            conversation.mount(BlockedMessage(command))
            return

        if risk == Risk.CONFIRM and not self._skip_permissions:
            synthetic_call = ToolCall(
                id="slash-cmd", name="execute_shell", arguments={"command": command}
            )
            confirmed = await self.push_screen_wait(ConfirmScreen(synthetic_call))
            if not confirmed:
                conversation.mount(SystemMessage("Command cancelled."))
                return

        self._busy = True
        try:
            result = await execute_shell(command)

            # If sudo needs a password, prompt and retry
            if needs_sudo_password(result):
                password = await self.push_screen_wait(SudoPasswordScreen(command))
                if password:
                    set_sudo_password(password)
                    result = await execute_shell(command)

            output = result.output or result.error
            conversation.mount(CommandBlock(command, output, result.exit_code))

            # Inject into agent context so the model knows what the user ran
            self.agent.messages.append(
                {
                    "role": "user",
                    "content": (
                        f"[The user directly ran a shell command: `{command}`]\n"
                        f"Exit code: {result.exit_code}\n"
                        f"Output:\n{output}"
                    ),
                }
            )
        finally:
            self._busy = False
            self.query_one("#user-input", Input).focus()
            conversation.scroll_end()

    # ─── /plan ────────────────────────────────────────────────────────────

    def _handle_plan_command(self, description: str, conversation: ScrollableContainer) -> None:
        """Generate a PLAN.md file from a natural language description."""
        conversation.mount(UserMessage(f"/plan {description}"))
        conversation.mount(
            SystemMessage(
                "Generating plan\u2026 the model will examine your project and create PLAN.md."
            )
        )
        self.run_plan_generation(description)

    @work(exclusive=True, thread=False)
    async def run_plan_generation(self, description: str) -> None:
        """Run the agent loop with a plan generation prompt."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        thinking_ref: list[ThinkingIndicator | None] = [None]
        self._busy = True

        async def confirm_callback(tool_call: ToolCall) -> bool:
            return await self.push_screen_wait(ConfirmScreen(tool_call))

        async def password_callback(tool_call: ToolCall) -> str | None:
            command = tool_call.arguments.get("command", "")
            return await self.push_screen_wait(SudoPasswordScreen(command))

        confirm_cb = None if self._skip_permissions else confirm_callback

        # Fresh context — plan generation is self-contained
        self.agent.clear_history()
        tree = _shallow_tree(Path.cwd())
        prompt = _build_plan_prompt(description, tree)

        try:
            async for event in self.agent.handle_user_message(
                prompt,
                confirm_callback=confirm_cb,
                password_callback=password_callback,
            ):
                self._render_agent_event(event, conversation, thinking_ref)

        except Exception as e:
            conversation.mount(Static(f"[bold red]Plan generation error:[/] {_escape(str(e))}"))

        finally:
            if thinking_ref[0]:
                thinking_ref[0].remove()
            self._busy = False
            self.query_one(LogoBanner).stop_animation()
            self.query_one("#user-input", Input).focus()

        # Preview the generated plan if it was written
        plan_path = Path.cwd() / "PLAN.md"
        if plan_path.exists():
            try:
                plan = parse_plan_file(str(plan_path))
                conversation.mount(PlanOverviewMessage(plan.title, [s.title for s in plan.steps]))
            except (ValueError, FileNotFoundError):
                conversation.mount(
                    SystemMessage(
                        f"Plan written to {plan_path}\n"
                        "[dim]Note: could not parse step structure. "
                        "Check that ## headings are used for steps.[/]"
                    )
                )

        conversation.scroll_end()

    # ─── /exeplan ──────────────────────────────────────────────────────────

    def _handle_exeplan_command(self, args: str, conversation: ScrollableContainer) -> None:
        """Dispatch /exeplan subcommands."""
        parts = args.strip().split(maxsplit=1)

        if not parts:
            conversation.mount(
                SystemMessage(
                    "Usage: /exeplan <file>       \u2014 preview plan steps\n"
                    "       /exeplan run <file>   \u2014 execute all steps\n"
                    "       /exeplan show <file>  \u2014 same as bare /exeplan"
                )
            )
            return

        subcmd = parts[0].lower()

        if subcmd == "run":
            file_path = parts[1].strip() if len(parts) > 1 else ""
            if not file_path:
                conversation.mount(SystemMessage("Usage: /exeplan run <file>"))
                return
            try:
                plan = parse_plan_file(file_path)
            except FileNotFoundError as e:
                conversation.mount(SystemMessage(f"[red]{e}[/]"))
                return
            except ValueError as e:
                conversation.mount(SystemMessage(f"[red]Parse error: {e}[/]"))
                return
            self.run_plan(plan)

        elif subcmd == "show":
            file_path = parts[1].strip() if len(parts) > 1 else ""
            if not file_path:
                conversation.mount(SystemMessage("Usage: /exeplan show <file>"))
                return
            self._show_plan_preview(file_path, conversation)

        else:
            # Bare /exeplan <file> — treat as show
            file_path = args.strip()
            self._show_plan_preview(file_path, conversation)

    def _show_plan_preview(self, file_path: str, conversation: ScrollableContainer) -> None:
        """Parse and display a plan preview (dry-run)."""
        try:
            plan = parse_plan_file(file_path)
        except FileNotFoundError as e:
            conversation.mount(SystemMessage(f"[red]{e}[/]"))
            return
        except ValueError as e:
            conversation.mount(SystemMessage(f"[red]Parse error: {e}[/]"))
            return

        conversation.mount(PlanOverviewMessage(plan.title, [s.title for s in plan.steps]))

    @work(exclusive=True, thread=False)
    async def run_plan(self, plan: Plan) -> None:
        """Execute a multi-step plan, one step at a time."""
        import time

        conversation = self.query_one("#conversation", ScrollableContainer)
        self._busy = True
        plan_t0 = time.monotonic()

        # Show plan overview header
        conversation.mount(
            SystemMessage(
                f"[bold]Executing plan:[/] {_escape(plan.title)} ({len(plan.steps)} steps)"
            )
        )
        conversation.scroll_end()

        async def confirm_callback(tool_call: ToolCall) -> bool:
            return await self.push_screen_wait(ConfirmScreen(tool_call))

        async def password_callback(tool_call: ToolCall) -> str | None:
            command = tool_call.arguments.get("command", "")
            return await self.push_screen_wait(SudoPasswordScreen(command))

        confirm_cb = None if self._skip_permissions else confirm_callback

        completed_summaries: list[str] = []
        completed_count = 0
        failed_count = 0
        skipped_count = 0

        try:
            for step in plan.steps:
                # Mount step divider
                divider = PlanStepDivider(step.number, len(plan.steps), step.title)
                divider.id = f"plan-step-{step.number}"
                conversation.mount(divider)
                conversation.scroll_end()

                # Clear agent history (keep system prompt) for a fresh context
                self.agent.clear_history()

                # Use higher step limit for plan execution
                plan_max = self.agent.config.plan_max_steps
                original_max = self.agent.config.max_steps
                self.agent.config.max_steps = plan_max
                # Re-derive effective max_steps with the plan floor
                effective_max = getattr(self.agent, "_max_steps", plan_max)
                effective_max = max(effective_max, plan_max)

                # Build focused prompt for this step
                prompt = _build_step_prompt(
                    step, plan, completed_summaries, max_steps=effective_max
                )

                # Run the agent loop for this step
                thinking_ref: list[ThinkingIndicator | None] = [None]
                hit_max_steps = False

                try:
                    async for event in self.agent.handle_user_message(
                        prompt,
                        confirm_callback=confirm_cb,
                        password_callback=password_callback,
                    ):
                        self._render_agent_event(event, conversation, thinking_ref)

                        # Detect max-steps warning
                        if (
                            event.type == EventType.RESPONSE
                            and event.data
                            and "maximum number of steps" in event.data
                        ):
                            hit_max_steps = True

                except Exception as e:
                    conversation.mount(Static(f"[bold red]Step error:[/] {_escape(str(e))}"))
                    divider.mark_failed(str(e))
                    failed_count += 1
                    completed_summaries.append(f"{step.number}. {step.title} \u2717")
                    continue

                finally:
                    self.agent.config.max_steps = original_max
                    if thinking_ref[0]:
                        thinking_ref[0].remove()
                    self.query_one(LogoBanner).stop_animation()

                # Update divider status
                if hit_max_steps:
                    divider.mark_partial()
                    failed_count += 1
                    completed_summaries.append(f"{step.number}. {step.title} \u26a0 (partial)")
                else:
                    divider.mark_done()
                    completed_count += 1
                    completed_summaries.append(f"{step.number}. {step.title} \u2713")

                conversation.scroll_end()

        except Exception as e:
            conversation.mount(Static(f"[bold red]Plan aborted:[/] {_escape(str(e))}"))
        finally:
            # Calculate remaining skipped steps
            executed = completed_count + failed_count
            skipped_count = len(plan.steps) - executed

            wall_ms = int((time.monotonic() - plan_t0) * 1000)
            conversation.mount(
                PlanSummaryMessage(completed_count, failed_count, skipped_count, wall_ms)
            )
            self._busy = False
            self.query_one(LogoBanner).stop_animation()
            self.query_one("#user-input", Input).focus()
            conversation.scroll_end()

    def _show_help(self, conversation: ScrollableContainer) -> None:
        """Show available slash commands."""
        help_text = (
            "[bold]Available Commands[/]\n\n"
            "  [bold cyan]/help[/]                  Show this help message\n"
            "  [bold cyan]/clear[/]                 Clear chat and model context\n"
            "  [bold cyan]/compact[/]               Compact context, keeping key facts\n"
            "  [bold cyan]/cmd <command>[/]         Execute a shell command directly\n"
            "  [bold cyan]/exeplan <file>[/]        Preview a multi-step plan\n"
            "  [bold cyan]/exeplan run <file>[/]    Execute all plan steps\n"
            "  [bold cyan]/plan <description>[/]    Generate a multi-step plan\n"
            "  [bold cyan]/model[/]                 Show current engine/model info\n"
            "  [bold cyan]/model list[/]            List models on remote server\n"
            "  [bold cyan]/model use <name>[/]      Switch to a remote model\n"
            "  [bold cyan]/model switch[/]          Switch local model (or Ctrl+P)\n"
            "  [bold cyan]/model local[/]           Switch back to local model\n"
            "  [bold cyan]/model default <name>[/]  Save default remote model\n"
            "  [bold cyan]/history[/]               Show conversation context size\n\n"
            "[bold]Copy & Paste[/]\n\n"
            "  Click [bold cyan]\U0001f4cb[/] on any message to copy it.\n"
            "  Click [bold cyan]\U0001f4cb Copy Chat[/] or press"
            " [bold cyan]Ctrl+E[/] to copy entire chat.\n"
            "  [bold cyan]Shift+drag[/] to select text, then use terminal copy.\n"
            "  [bold cyan]Right-click[/] or [bold cyan]Ctrl+Y[/] to copy Textual selection.\n"
            "  [bold cyan]Ctrl+Shift+V[/] or terminal paste to paste.\n"
            f"  Clipboard: [bold cyan]{clipboard.backend_name()}[/]\n\n"
            "[dim]Tip: Use /cmd when you know the exact command to run.[/]"
        )
        conversation.mount(HelpMessage(help_text))

    async def _handle_model_command(self, args: str, conversation: ScrollableContainer) -> None:
        """Dispatch /model subcommands."""
        if not args:
            self._show_model_info(conversation)
            return

        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower()
        subargs = parts[1] if len(parts) > 1 else ""

        match subcmd:
            case "list":
                await self._model_list(conversation)
            case "use":
                if not subargs:
                    conversation.mount(SystemMessage("Usage: /model use <model-name>"))
                else:
                    await self._model_use(subargs.strip(), conversation)
            case "switch":
                await self._model_switch_command(subargs.strip(), conversation)
            case "local":
                await self._model_switch_local(conversation)
            case "default":
                if not subargs:
                    conversation.mount(SystemMessage("Usage: /model default <model-name>"))
                else:
                    self._model_set_default(subargs.strip(), conversation)
            case _:
                conversation.mount(
                    SystemMessage(
                        "Unknown subcommand. Usage:\n"
                        "  /model          — show current info\n"
                        "  /model list     — list remote models\n"
                        "  /model use <n>  — switch to remote model\n"
                        "  /model switch   — switch local model\n"
                        "  /model local    — switch to local model\n"
                        "  /model default <n> — set default model"
                    )
                )

    def _get_remote_base_url(self) -> str | None:
        """Find the remote base URL from config or current engine."""
        if self._config.ollama.url:
            return normalize_base_url(self._config.ollama.url)
        if self._config.remote.url:
            return normalize_base_url(self._config.remote.url)
        info = self.agent.engine.engine_info()
        if info.base_url:
            return normalize_base_url(info.base_url)
        return None

    def _show_model_info(self, conversation: ScrollableContainer) -> None:
        """Show current model/engine information."""
        info = self.agent.engine.engine_info()
        parts = ["[bold]Model Info[/]"]
        parts.append(f"  Engine: {info.engine_type}")
        if info.model_name:
            parts.append(f"  Model: {info.model_name}")
        if info.base_url:
            parts.append(f"  URL: {info.base_url}")
        if info.n_ctx:
            parts.append(f"  Context: {info.n_ctx} tokens")
        if info.n_gpu_layers:
            parts.append(f"  GPU layers: {info.n_gpu_layers}")
        if info.engine_type == "local":
            try:
                from llama_cpp import llama_supports_gpu_offload

                gpu_ok = llama_supports_gpu_offload()
            except ImportError:
                gpu_ok = False
            status = "[green]active[/]" if gpu_ok else "[red]unavailable (CPU-only build)[/]"
            parts.append(f"  GPU backend: {status}")

            # Show detected GPU hardware
            from natshell.gpu import detect_gpus

            gpus = detect_gpus()
            if gpus:
                if info.main_gpu is not None and info.main_gpu >= 0:
                    # Find the selected GPU by device index
                    selected = next((g for g in gpus if g.device_index == info.main_gpu), gpus[0])
                else:
                    selected = gpus[0]
                vram = f", {selected.vram_mb} MB VRAM" if selected.vram_mb else ""
                parts.append(f"  GPU: {selected.name}{vram}")
                if len(gpus) > 1:
                    parts.append(f"  Device index: {selected.device_index} (of {len(gpus)} GPUs)")

        remote_url = self._get_remote_base_url()
        if remote_url:
            parts.append("\n[dim]Tip: /model list — see available remote models[/]")
        conversation.mount(SystemMessage("\n".join(parts)))

    async def _model_list(self, conversation: ScrollableContainer) -> None:
        """Ping server and list available models."""
        base_url = self._get_remote_base_url()
        if not base_url:
            conversation.mount(
                SystemMessage(
                    "No remote server configured.\n"
                    "Set [ollama] url in ~/.config/natshell/config.toml\n"
                    "or use --remote <url> at startup."
                )
            )
            return

        conversation.mount(SystemMessage(f"Checking {base_url}..."))

        reachable = await ping_server(base_url)
        if not reachable:
            conversation.mount(SystemMessage(f"[red]Cannot reach server at {base_url}[/]"))
            return

        models = await list_models(base_url)
        if not models:
            conversation.mount(SystemMessage("Server is running but returned no models."))
            return

        current_info = self.agent.engine.engine_info()
        lines = ["[bold]Available Models[/]"]
        for m in models:
            marker = " [green]◀ active[/]" if m.name == current_info.model_name else ""
            detail = ""
            if m.size_gb:
                detail += f" ({m.size_gb} GB)"
            if m.parameter_size:
                detail += f" [{m.parameter_size}]"
            lines.append(f"  {m.name}{detail}{marker}")
        lines.append("\n[dim]Use /model use <name> to switch[/]")
        conversation.mount(SystemMessage("\n".join(lines)))

    async def _model_use(self, model_name: str, conversation: ScrollableContainer) -> None:
        """Switch to a remote model."""
        base_url = self._get_remote_base_url()
        if not base_url:
            conversation.mount(
                SystemMessage("No remote server configured. Set [ollama] url in config.")
            )
            return

        reachable = await ping_server(base_url)
        if not reachable:
            conversation.mount(SystemMessage(f"[red]Cannot reach server at {base_url}[/]"))
            return

        from natshell.inference.remote import RemoteEngine

        # Ensure URL has /v1 for the OpenAI-compatible endpoint
        api_url = base_url if base_url.endswith("/v1") else f"{base_url}/v1"
        if self._config.remote.n_ctx > 0:
            n_ctx = self._config.remote.n_ctx
        else:
            n_ctx = await get_model_context_length(base_url, model_name)
        new_engine = RemoteEngine(base_url=api_url, model=model_name, n_ctx=n_ctx)
        await self.agent.swap_engine(new_engine)
        save_engine_preference("remote")
        save_ollama_default(model_name, url=base_url)
        conversation.mount(
            SystemMessage(
                f"Switched to [bold]{model_name}[/] on {base_url}\n"
                "[dim]Conversation history cleared.[/]"
            )
        )

    async def _model_switch_local(self, conversation: ScrollableContainer) -> None:
        """Switch back to the local model."""
        info = self.agent.engine.engine_info()
        if info.engine_type == "local":
            conversation.mount(SystemMessage("Already using the local model."))
            return

        mc = self._config.model
        model_path = mc.path
        if model_path == "auto":
            model_dir = Path.home() / ".local" / "share" / "natshell" / "models"
            model_path = str(model_dir / mc.hf_file)

        if not Path(model_path).exists():
            conversation.mount(
                SystemMessage(
                    f"[red]Local model not found at {model_path}[/]\n"
                    "Run natshell --download to fetch it."
                )
            )
            return

        conversation.mount(SystemMessage("Loading local model..."))

        from natshell.inference.local import LocalEngine

        try:
            engine = await asyncio.to_thread(
                LocalEngine,
                model_path=model_path,
                n_ctx=mc.n_ctx,
                n_threads=mc.n_threads,
                n_gpu_layers=mc.n_gpu_layers,
                main_gpu=mc.main_gpu,
            )
            await self.agent.swap_engine(engine)
            save_engine_preference("local")
            conversation.mount(
                SystemMessage(
                    f"Switched to local model: [bold]{Path(model_path).name}[/]\n"
                    "[dim]Conversation history cleared.[/]"
                )
            )
        except Exception as e:
            conversation.mount(SystemMessage(f"[red]Failed to load local model: {e}[/]"))

    async def _model_switch_command(self, args: str, conversation: ScrollableContainer) -> None:
        """Handle /model switch [filename]."""
        if not MODELS_DIR.is_dir():
            conversation.mount(
                SystemMessage(
                    f"No models directory found at {MODELS_DIR}\n"
                    "Run natshell --download to fetch a model."
                )
            )
            return

        available = sorted(MODELS_DIR.glob("*.gguf"))
        if not available:
            conversation.mount(
                SystemMessage("No .gguf models found. Run natshell --download to fetch one.")
            )
            return

        if not args:
            # List available models
            current = self.agent.engine.engine_info().model_name
            lines = ["[bold]Local Models[/]"]
            for gguf in available:
                marker = " [green]◀ active[/]" if gguf.name == current else ""
                lines.append(f"  {gguf.name}{marker}")
            lines.append("\n[dim]Use /model switch <filename> to switch[/]")
            conversation.mount(SystemMessage("\n".join(lines)))
            return

        # Find matching model file
        target = None
        for gguf in available:
            if gguf.name == args or gguf.stem == args:
                target = gguf
                break

        if not target:
            conversation.mount(
                SystemMessage(
                    f"Model not found: {args}\nUse /model switch to list available models."
                )
            )
            return

        await self.switch_local_model(str(target))

    async def switch_local_model(self, model_path: str) -> None:
        """Switch to a different local .gguf model (used by command palette and /model switch)."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        name = Path(model_path).name
        conversation.mount(SystemMessage(f"Loading {name}..."))
        conversation.scroll_end()

        from natshell.inference.local import LocalEngine

        mc = self._config.model
        try:
            engine = await asyncio.to_thread(
                LocalEngine,
                model_path=model_path,
                n_ctx=mc.n_ctx,
                n_threads=mc.n_threads,
                n_gpu_layers=mc.n_gpu_layers,
                main_gpu=mc.main_gpu,
            )
            await self.agent.swap_engine(engine)

            # Derive hf_repo/hf_file and persist to config
            # hf_file is the filename; hf_repo we keep as current config value
            hf_file = name
            hf_repo = mc.hf_repo
            save_model_config(hf_repo, hf_file)
            save_engine_preference("local")
            mc.hf_file = hf_file

            conversation.mount(
                SystemMessage(f"Switched to [bold]{name}[/]\n[dim]Conversation history cleared.[/]")
            )
        except Exception as e:
            conversation.mount(SystemMessage(f"[red]Failed to load {name}: {e}[/]"))

        conversation.scroll_end()

    def _model_set_default(self, model_name: str, conversation: ScrollableContainer) -> None:
        """Persist the default model and remote URL to user config."""
        remote_url = self._get_remote_base_url()
        config_path = save_ollama_default(model_name, url=remote_url)
        parts = [f"Default model set to [bold]{model_name}[/]"]
        if remote_url:
            parts.append(f"Server: {remote_url}")
        parts.append(f"Saved to {config_path}")
        conversation.mount(SystemMessage("\n".join(parts)))

    def _show_history_info(self, conversation: ScrollableContainer) -> None:
        """Show conversation context size and context window usage."""
        msg_count = len(self.agent.messages)
        char_count = sum(len(str(m.get("content", ""))) for m in self.agent.messages)

        parts = [f"Conversation: {msg_count} messages, ~{char_count} chars"]

        cm = self.agent._context_manager
        if cm:
            used = cm.estimate_tokens(self.agent.messages)
            budget = cm.context_budget
            pct = min(100, int(used / budget * 100)) if budget > 0 else 0
            bar_len = 20
            filled = int(bar_len * pct / 100)
            bar = "\u2588" * filled + "\u2591" * (bar_len - filled)

            if pct >= 90:
                color = "red"
            elif pct >= 70:
                color = "yellow"
            else:
                color = "green"

            parts.append(f"  Context: [{color}]{bar}[/] {pct}% ({used}/{budget} tokens)")

            if cm.trimmed_count > 0:
                parts.append(f"  Trimmed: {cm.trimmed_count} messages compressed")

        conversation.mount(SystemMessage("\n".join(parts)))

    def on_mouse_up(self, event: MouseUp) -> None:
        """Copy selected text to clipboard on right-click."""
        if event.button == 3:
            selected = self.screen.get_selected_text()
            if selected:
                if clipboard.copy(selected, self):
                    self.notify("Copied to clipboard", timeout=2)
                else:
                    self.notify(
                        "Copy failed — no clipboard tool found", severity="error", timeout=3
                    )

    def action_copy_selection(self) -> None:
        """Copy selected text to clipboard (Ctrl+Y)."""
        selected = self.screen.get_selected_text()
        if selected:
            if clipboard.copy(selected, self):
                self.notify("Copied to clipboard", timeout=2)
            else:
                self.notify("Copy failed — no clipboard tool found", severity="error", timeout=3)

    def action_copy_chat(self) -> None:
        """Copy the entire chat conversation to clipboard."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        parts = []
        for child in conversation.children:
            if hasattr(child, "copyable_text"):
                parts.append(child.copyable_text)
        if parts:
            text = "\n\n".join(parts)
            if clipboard.copy(text, self):
                self.notify("Chat copied!", timeout=2)
            else:
                self.notify("Copy failed — no clipboard tool found", severity="error", timeout=3)
        else:
            self.notify("Nothing to copy", timeout=2)

    @on(Button.Pressed, "#copy-chat-btn")
    def on_copy_chat_btn(self) -> None:
        self.action_copy_chat()

    @on(Button.Pressed, "#paste-btn")
    def on_paste_btn(self) -> None:
        content = clipboard.read()
        if content is None:
            self.notify(
                "Cannot read clipboard — no paste tool available", severity="error", timeout=3
            )
            return
        if not content.strip():
            self.notify("Clipboard is empty", timeout=2)
            return
        input_widget = self.query_one("#user-input", HistoryInput)
        input_widget.insert_from_clipboard(content)
        input_widget.focus()

    def action_clear_chat(self) -> None:
        """Clear the conversation and agent history."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        conversation.remove_children()
        conversation.mount(Static("[dim]Chat cleared. Type a new request.[/]\n"))
        self.agent.clear_history()
        self.query_one("#user-input", HistoryInput).clear_history()

    def _compact_chat(self, conversation: ScrollableContainer) -> None:
        """Compact conversation context, keeping key facts."""
        stats = self.agent.compact_history()
        if not stats["compacted"]:
            conversation.mount(SystemMessage("Nothing to compact — conversation is too short."))
            return

        conversation.remove_children()
        summary_lines = [
            "[bold]Context compacted[/]\n",
            f"  Messages: {stats['before_msgs']} \u2192 {stats['after_msgs']}",
            f"  Tokens:   ~{stats['before_tokens']} \u2192 ~{stats['after_tokens']}",
        ]
        if stats["summary"]:
            summary_lines.append(f"\n[dim]Preserved facts:[/]\n{_escape(stats['summary'])}")
        conversation.mount(SystemMessage("\n".join(summary_lines)))
