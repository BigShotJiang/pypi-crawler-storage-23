# Verification configs for functional extraction
