"""CLI Agent Adapter for Evaluation.
Runs CLI agents (Claude Code, Codex, Cursor) as subprocess and parses their output
into Trajectory format compatible with the existing evaluation framework.
Usage:
    # Direct evaluation
    trajectory = await run_cli_agent("claude-code", instruction, working_dir)
    sample = Sample(id="test", input=data, trajectory=trajectory)
    score = score_fn(sample)
    # With existing evaluate() infrastructure
    results = await evaluate_cli_agents(
        agents=["claude-code", "codex"],
        dataset=problems,
        working_dir=kernels_dir,
        score_fn=my_score_fn,
    )
"""
from __future__ import annotations

import json
import logging
import shlex
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

import trio

from .dtypes import (
    Message,
    Sample,
    Score,
    TextContent,
    ToolCallContent,
    Trajectory,
)
from .eval_utils import write_sample_started

logger = logging.getLogger(__name__)
# ── Types ─────────────────────────────────────────────────────────────────────
AgentName = Literal["claude-code", "codex", "cursor", "wafer"]


@dataclass(frozen=True)
class CLIAgentConfig:
    """Configuration for CLI agent execution.
    Frozen dataclass: immutable, serializable, explicit.
    """
    agent: AgentName
    model: str | None = None
    timeout_sec: float = 600.0
    allowed_tools: list[str] | None = None
    extra_args: list[str] = field(default_factory=list)
    use_modal: bool = False

    @classmethod
    def from_toml(cls, path: Path, *, timeout_sec: float = 600.0) -> "CLIAgentConfig":
        """Build CLIAgentConfig from a TOML config file.
        For wafer agent: passes --config path so the file provides all settings.
        For other agents: extracts model and tools to pass as flags.
        """
        from wafer.cli.agent_config import load_agent_config

        path = path.resolve()
        assert path.exists(), f"Config file not found: {path}"
        file_config = load_agent_config(path)

        _VALID_AGENTS: tuple[AgentName, ...] = ("wafer", "claude-code", "codex", "cursor")
        agent_name: AgentName
        if file_config.agent is None:
            agent_name = "wafer"
        elif file_config.agent in _VALID_AGENTS:
            agent_name = file_config.agent  # type: ignore[assignment]
        else:
            raise ValueError(f"Invalid agent in config: {file_config.agent}. Must be one of {_VALID_AGENTS}")

        if agent_name == "wafer":
            return cls(
                agent="wafer",
                model=None,
                timeout_sec=timeout_sec,
                allowed_tools=None,
                extra_args=["--config", str(path)],
                use_modal=False,
            )
        return cls(
            agent=agent_name,
            model=file_config.model,
            timeout_sec=timeout_sec,
            allowed_tools=file_config.tools,
            extra_args=[],
            use_modal=False,
        )

    @classmethod
    def for_template(
        cls,
        template_name: str,
        *,
        timeout_sec: float = 600.0,
        config_template_args: dict[str, str] | None = None,
    ) -> "CLIAgentConfig":
        """Build CLIAgentConfig for wafer agent with a bundled template.
        Uses -t template_name so the sandbox resolves from its installed package.
        config_template_args become --args KEY=VALUE for template variable substitution.
        Raises ValueError if template not found.
        """
        from wafer.cli.agent_config import get_bundled_template_path

        path = get_bundled_template_path(template_name)
        if path is None:
            from wafer.cli.agent_config import list_bundled_templates
            available = list_bundled_templates()
            raise ValueError(
                f"Template not found: {template_name}. "
                f"Available: {', '.join(available) if available else '(none)'}"
            )
        extra_args: list[str] = ["-t", template_name]
        if config_template_args:
            for k, v in config_template_args.items():
                extra_args.extend(["--args", f"{k}={v}"])
        return cls(
            agent="wafer",
            model=None,
            timeout_sec=timeout_sec,
            allowed_tools=None,
            extra_args=extra_args,
            use_modal=False,
        )


@dataclass(frozen=True)
class CLIAgentResult:
    """Result of running a CLI agent.
    Frozen dataclass: all fields explicit, immutable after creation.
    """
    trajectory: Trajectory
    raw_output: str
    duration_sec: float
    exit_code: int
    error: str | None = None


@dataclass(frozen=True)
class CLIEvalConfig:
    """Configuration for CLI-agent-based evaluation runs.

    Configures the RUNNER (orchestration, output, concurrency).
    Agent behavior is configured via CLIAgentConfig + agent config TOML files.
    """
    agents: list[CLIAgentConfig]
    build_instruction: Callable[[dict[str, Any]], str]
    score_fn: Callable[[Sample], Score]

    prepare_working_dir: Callable[[dict[str, Any], Path], None] | None = None

    max_concurrent: int = 4
    max_samples: int | None = None
    timeout_override: float | None = None

    eval_name: str = "evaluation"
    output_dir: Path | None = None
    report_batch_size: int = 1

    resume_dir: Path | None = None

    show_progress: bool = True
    verbose: bool = True

    upload_to_supabase: bool = False

    max_sample_retries: int = 3

    metadata: dict[str, Any] | None = None

    on_sample_complete: Callable[[Sample], None] | None = None


# ── Parsing Functions (Pure) ──────────────────────────────────────────────────
def parse_claude_code_stream_json(output: str) -> list[Message]:
    """Parse Claude Code / JsonFrontend --output-format stream-json into list[Message].
    Claude Code emits NDJSON with event types:
    - {"type": "system", "subtype": "init", ...}
    - {"type": "assistant", "message": {"content": [...]}}
    - {"type": "user", "message": {"content": [{"type": "tool_result", ...}]}}
    - {"type": "result", "subtype": "success", ...}
    JsonFrontend also emits granular tool_result events:
    - {"type": "tool_result", "tool_call_id": ..., "content": ..., "is_error": ...}
    Pure function: no side effects, explicit input/output.
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type")
        if event_type == "assistant":
            content_blocks = _parse_claude_content_blocks(event)
            if content_blocks:
                messages.append(Message(role="assistant", content=content_blocks))
        elif event_type == "user":
            tool_messages = _parse_claude_tool_results(event)
            messages.extend(tool_messages)
        elif event_type == "tool_result":
            content = event.get("content", "")
            if isinstance(content, list):
                content = json.dumps(content)
            messages.append(
                Message(
                    role="tool",
                    content=str(content),
                    tool_call_id=event.get("tool_call_id", ""),
                )
            )
    return messages


def _parse_claude_content_blocks(event: dict[str, Any]) -> list[TextContent | ToolCallContent]:
    """Parse content blocks from Claude Code assistant message.
    Pure function: extracts TextContent and ToolCallContent from event.
    """
    assert "message" in event
    assert "content" in event["message"]
    content_blocks: list[TextContent | ToolCallContent] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        block_type = block.get("type")
        if block_type == "text":
            content_blocks.append(TextContent(text=block.get("text", "")))
        elif block_type == "tool_use":
            content_blocks.append(
                ToolCallContent(
                    id=block.get("id", ""),
                    name=block.get("name", ""),
                    arguments=block.get("input", {}),
                )
            )
    return content_blocks


def _parse_claude_tool_results(event: dict[str, Any]) -> list[Message]:
    """Parse tool results from Claude Code user message.
    Pure function: extracts tool result messages.
    """
    assert "message" in event
    assert "content" in event["message"]
    messages: list[Message] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        if block.get("type") == "tool_result":
            messages.append(
                Message(
                    role="tool",
                    content=block.get("content", ""),
                    tool_call_id=block.get("tool_use_id", ""),
                )
            )
    return messages


def parse_codex_json(output: str) -> list[Message]:
    """Parse Codex ``exec --json`` output into list[Message].
    Codex emits NDJSON with an item-based event stream::
        {"type": "item.started", "item": {"id": "...", "type": "command_execution", "command": "ls", "aggregated_output": "", ...}}
        {"type": "item.completed", "item": {"id": "...", "type": "command_execution", "command": "ls", "aggregated_output": "file1\\n...", "exit_code": 0}}
        {"type": "item.completed", "item": {"id": "...", "type": "agent_message", "text": "Here is..."}}
        {"type": "turn.completed", "usage": {"input_tokens": N, ...}}
    We convert completed items into Messages:
    - ``agent_message`` → assistant text message
    - ``command_execution`` → assistant tool_use + tool result pair
    - ``file_change`` → assistant tool_use + tool result pair
    Pure function: no side effects, explicit input/output.
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type")
        if event_type != "item.completed":
            continue
        item = event.get("item", {})
        item_type = item.get("type")
        item_id = item.get("id", "")
        if item_type == "agent_message":
            text = item.get("text", "")
            if text:
                messages.append(Message(role="assistant", content=text))
        elif item_type == "command_execution":
            command = item.get("command", "")
            output_text = item.get("aggregated_output") or item.get("output", "")
            # Emit as tool_use + tool_result pair
            messages.append(
                Message(
                    role="assistant",
                    content=[
                        ToolCallContent(
                            id=item_id,
                            name="bash",
                            arguments={"command": command},
                        )
                    ],
                )
            )
            messages.append(
                Message(
                    role="tool",
                    content=output_text,
                    tool_call_id=item_id,
                )
            )
        elif item_type == "file_change":
            # Codex file_change items have: item.changes = [{"path": "...", "kind": "add|update|delete"}, ...]
            changes = item.get("changes", [])
            for change in changes:
                path = change.get("path", "")
                kind = change.get("kind", "update")
                tool_name = "write" if kind in ("add", "update") else "edit"
                messages.append(
                    Message(
                        role="assistant",
                        content=[
                            ToolCallContent(
                                id=item_id,
                                name=tool_name,
                                arguments={"path": path, "kind": kind},
                            )
                        ],
                    )
                )
                messages.append(
                    Message(
                        role="tool",
                        content=f"{'Wrote' if kind != 'delete' else 'Deleted'} {path}",
                        tool_call_id=item_id,
                    )
                )
    return messages


def parse_wafer_stream_json(output: str) -> list[Message]:
    """Parse wafer agent --output-format stream-json into list[Message].

    Wafer's StreamingChunkFrontend emits NDJSON:
    - {"type": "text_delta", "delta": "..."}
    - {"type": "tool_call_start", "tool_name": "..."}
    - {"type": "tool_call_end", "tool_name": "...", "args": {...}}
    - {"type": "tool_result", "is_error": bool}
    - {"type": "session_end"}

    Groups consecutive text_deltas into assistant messages, and
    tool_call_end + tool_result into tool use / tool result pairs.
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    text_parts: list[str] = []
    tool_counter = 0

    def _flush_text() -> None:
        if text_parts:
            messages.append(Message(role="assistant", content="".join(text_parts)))
            text_parts.clear()

    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type", "")

        if event_type == "text_delta":
            text_parts.append(event.get("delta", ""))
        elif event_type == "tool_call_end":
            _flush_text()
            tool_id = f"wafer_tool_{tool_counter}"
            tool_counter += 1
            messages.append(Message(
                role="assistant",
                content=[ToolCallContent(
                    id=tool_id,
                    name=event.get("tool_name", ""),
                    arguments=event.get("args", {}),
                )],
            ))
        elif event_type == "tool_result":
            tool_content = event.get("content", "(tool result)")
            messages.append(Message(
                role="tool",
                content=tool_content if tool_content else "(tool result)",
                tool_call_id=f"wafer_tool_{tool_counter - 1}" if tool_counter > 0 else "",
            ))
        elif event_type == "session_end":
            break

    _flush_text()
    return messages


def parse_cursor_stream_json(output: str) -> list[Message]:
    """Parse Cursor CLI --output-format stream-json into list[Message].
    Cursor emits NDJSON similar to Claude Code:
    - {"type": "assistant", "message": {"content": [...]}}
    - {"type": "tool_call", "subtype": "started|completed", ...}
    Pure function: no side effects, explicit input/output.
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type")
        if event_type == "assistant":
            content_blocks = _parse_claude_content_blocks(event)
            if content_blocks:
                messages.append(Message(role="assistant", content=content_blocks))
        elif event_type == "tool_call":
            subtype = event.get("subtype")
            if subtype == "completed":
                # Tool execution finished
                tool_id = event.get("id", "")
                output_content = event.get("output", "")
                messages.append(
                    Message(
                        role="tool",
                        content=output_content,
                        tool_call_id=tool_id,
                    )
                )
    return messages


def parse_raw_text_fallback(output: str) -> list[Message]:
    """Fallback parser: treat entire output as single assistant message.
    Used when agent doesn't support structured output.
    Pure function: simple transformation.
    """
    assert isinstance(output, str)
    if not output.strip():
        return []
    return [Message(role="assistant", content=output.strip())]


# ── Command Building (Pure) ───────────────────────────────────────────────────
def build_cli_command(config: CLIAgentConfig, instruction: str) -> list[str]:
    """Build CLI command for the specified agent.
    Pure function: config + instruction -> command list.
    """
    assert config is not None
    assert instruction is not None
    assert len(instruction) > 0
    if config.agent == "claude-code":
        return _build_claude_code_command(config, instruction)
    elif config.agent == "codex":
        return _build_codex_command(config, instruction)
    elif config.agent == "cursor":
        return _build_cursor_command(config, instruction)
    elif config.agent == "wafer":
        return _build_wafer_command(config, instruction)
    else:
        raise ValueError(f"Unknown agent: {config.agent}")


def _build_claude_code_command(config: CLIAgentConfig, instruction: str) -> list[str]:
    """Build Claude Code CLI command.
    claude -p "instruction" --output-format stream-json --verbose [--allowedTools ...]
    """
    cmd = [
        "claude",
        "-p",
        instruction,
        "--output-format",
        "stream-json",
        "--verbose",  # Required for stream-json with --print
    ]
    if config.allowed_tools:
        cmd.extend(["--allowedTools", ",".join(config.allowed_tools)])
    if config.model:
        cmd.extend(["--model", config.model])
    cmd.extend(config.extra_args)
    return cmd


def _build_codex_command(config: CLIAgentConfig, instruction: str) -> list[str]:
    """Build Codex CLI command.
    codex exec --json --full-auto --skip-git-repo-check -m <model> "instruction"
    """
    cmd = [
        "codex",
        "exec",
        "--json",
        "--full-auto",
        "--skip-git-repo-check",
    ]
    if config.model:
        cmd.extend(["-m", config.model])
    cmd.extend(config.extra_args)
    cmd.append(instruction)
    return cmd


def _build_cursor_command(config: CLIAgentConfig, instruction: str) -> list[str]:
    """Build Cursor CLI command.
    cursor -p "instruction" --output-format stream-json
    """
    cmd = [
        "cursor",
        "-p",
        instruction,
        "--output-format",
        "stream-json",
    ]
    if config.model:
        cmd.extend(["--model", config.model])
    cmd.extend(config.extra_args)
    return cmd


def _build_wafer_command(config: CLIAgentConfig, instruction: str) -> list[str]:
    """Build wafer-cli agent command.
    wafer agent "instruction" --output-format stream-json [extra_args]
    Agent config (model, tools, single_turn) comes from -c or -t in extra_args.
    """
    cmd = [
        "wafer",
        "agent",
        instruction,
        "--output-format",
        "stream-json",
    ]
    cmd.extend(config.extra_args)
    return cmd


# ── Agent Execution ───────────────────────────────────────────────────────────
_USE_COLOR = sys.stdout.isatty()
_RESET = "\033[0m"
_DIM = "\033[2m"
_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_BLUE = "\033[34m"
_MAGENTA = "\033[35m"
_CYAN = "\033[36m"


def _color(code: str, text: str) -> str:
    return f"{code}{text}{_RESET}" if _USE_COLOR and code else text


def _prefixed_write(
    text: str,
    output_prefix: str | None,
    at_line_start: list[bool],
    stdout_lock: threading.Lock | None = None,
    prefix_color: str = "",
) -> None:
    """Write text to stdout, prefixing each line with [output_prefix] when set."""
    if not text:
        return

    def _do_write() -> None:
        if output_prefix and at_line_start[0]:
            prefix = f"[{output_prefix}] "
            sys.stdout.write(_color(prefix_color or _CYAN, prefix))
            at_line_start[0] = False
        sys.stdout.write(text)
        sys.stdout.flush()
        at_line_start[0] = text.endswith("\n")

    if stdout_lock is not None:
        with stdout_lock:
            _do_write()
    else:
        _do_write()


async def run_cli_agent(
    config: CLIAgentConfig,
    instruction: str,
    working_dir: Path,
    on_stream_line: Callable[[dict[str, Any]], None] | None = None,
    output_prefix: str | None = None,
    stdout_lock: threading.Lock | None = None,
    use_modal: bool = False,
) -> CLIAgentResult:
    """Run CLI agent and return structured result.
    Args:
        config: Agent configuration (agent name, model, timeout)
        instruction: Task instruction for the agent
        working_dir: Directory where agent will execute
        on_stream_line: Optional callback for each parsed JSON line from agent stdout
        output_prefix: When set, prefix each line of stdout (for concurrent runs)
        use_modal: When True, run inside a Modal Sandbox instead of local subprocess
    Returns:
        CLIAgentResult with trajectory, raw output, timing, exit code
    """
    assert config is not None
    assert instruction is not None
    assert len(instruction) > 0

    if use_modal:
        from .modal_runner import run_cli_agent_modal
        return await run_cli_agent_modal(
            config=config,
            instruction=instruction,
            working_dir=working_dir,
            on_stream_line=on_stream_line,
        )

    assert working_dir.exists()  # noqa: ASYNC240 - sync assertion before async work
    assert working_dir.is_dir()  # noqa: ASYNC240 - sync assertion before async work
    cmd = build_cli_command(config, instruction)
    if output_prefix:
        flat = instruction.replace("\n", " ").strip()
        logger.info(f"[{output_prefix}] {flat}")
    else:
        logger.info(f"Running {config.agent}: {shlex.join(cmd[:5])}...")
    start_time = time.perf_counter()
    raw_output_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    stdout_line_buf = ""
    at_line_start: list[bool] = [True]
    text_buffer: list[str] = []
    pending_tool_call: list[str] = []  # ["  > grep("] when tool_call_start seen

    def _flush_text_buffer() -> None:
        if text_buffer:
            text = "".join(text_buffer)
            if text and not text.endswith("\n"):
                text += "\n"
            _prefixed_write(
                _color(_BLUE, text),
                output_prefix,
                at_line_start,
                stdout_lock,
            )
            text_buffer.clear()

    def _out(text: str, color: str = "") -> None:
        out = _color(color, text) if color else text
        _prefixed_write(out, output_prefix, at_line_start, stdout_lock)

    def _out_assistant_or_user(obj: dict[str, Any], role: str) -> None:
        """Pretty-print assistant or user message content."""
        msg = obj.get("message") or {}
        content = msg.get("content", []) if isinstance(msg, dict) else []
        for block in content[:5]:
            if not isinstance(block, dict):
                continue
            bt = block.get("type", "")
            if bt == "text":
                text = block.get("text", "")
                if text:
                    full = text if text.endswith("\n") else text + "\n"
                    _out(f"  [{role}] {full}", _BLUE)
            elif bt == "tool_use":
                name = block.get("name", "?")
                inp = block.get("input", {}) or {}
                path = inp.get("path", "")
                args_preview = f"path={path}" if path else ""
                _out(f"  > {name}({args_preview})\n", _YELLOW)
            elif bt == "tool_result":
                c = block.get("content", "")
                full = c if c.endswith("\n") else c + "\n"
                _out(f"  => {full}", _GREEN)

    def _flush_line(line: str) -> None:
        """Pretty-print a single NDJSON line from the agent stream."""
        stripped = line.strip()
        if not stripped:
            return
        try:
            obj = json.loads(stripped)
        except json.JSONDecodeError:
            _flush_text_buffer()
            out = line if line.endswith("\n") else line + "\n"
            _out(out, _DIM)
            return
        if on_stream_line is not None:
            try:
                on_stream_line(obj)
            except Exception:
                logger.debug("on_stream_line callback failed", exc_info=True)
        t = obj.get("type", "")
        if t == "text_delta":
            text_buffer.append(obj.get("delta", ""))
        elif t == "status":
            _flush_text_buffer()
            _out(f"\n  [{obj.get('message', '')}]\n", _DIM)
        elif t == "tool_call_start":
            _flush_text_buffer()
            pending_tool_call.append(f"\n  > {obj.get('tool_name', '')}(")
        elif t == "tool_call_end":
            args = obj.get("args", {})
            args_str = ", ".join(f"{k}={v!r}" for k, v in args.items()) if isinstance(args, dict) else str(args)
            if pending_tool_call:
                _out(pending_tool_call.pop() + f"{args_str})\n", _YELLOW)
            else:
                _out(f"{args_str})\n", _YELLOW)
        elif t == "tool_result":
            _flush_text_buffer()
            content = obj.get("content", "")
            is_err = obj.get("is_error", False)
            pfx = "  ERR " if is_err else "  => "
            color = _RED if is_err else _GREEN
            full = content if content.endswith("\n") else content + "\n"
            _out(f"{pfx}{full}", color)
        elif t == "initializing":
            _out("  initializing...\n", _DIM)
        elif t == "tool_exec_start":
            pass
        elif t == "tool_call_delta":
            pass  # suppress per-token streaming deltas (extremely verbose)
        elif t == "result":
            _flush_text_buffer()
            subtype = obj.get("subtype", "done")
            _out(f"  Agent completed ({subtype})\n", _MAGENTA)
        elif t == "assistant":
            _flush_text_buffer()
            _out_assistant_or_user(obj, "assistant")
        elif t == "user":
            _flush_text_buffer()
            _out_assistant_or_user(obj, "user")
        elif t == "system":
            _flush_text_buffer()
            subtype = obj.get("subtype", "")
            if subtype == "init":
                pass
            else:
                _out(f"  [system: {subtype or 'event'}]\n", _DIM)
        elif t in ("content_block_start", "content_block_stop",
                    "content_block_delta", "message_start", "message_delta",
                    "message_stop", "input_json_delta", "ping"):
            pass  # suppress Anthropic streaming protocol noise
        else:
            _flush_text_buffer()
            _out(f"  {stripped}\n", _DIM)

    try:
        process = await trio.lowlevel.open_process(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(working_dir),
        )
        assert process.stdout is not None
        assert process.stderr is not None

        async def read_stdout() -> None:
            nonlocal stdout_line_buf
            try:
                async for chunk in process.stdout:
                    raw_output_chunks.append(chunk)
                    text = chunk.decode("utf-8", errors="replace")
                    stdout_line_buf += text
                    while "\n" in stdout_line_buf:
                        line, stdout_line_buf = stdout_line_buf.split("\n", 1)
                        _flush_line(line)
            except trio.Cancelled:
                raise
            except Exception:
                pass

        async def read_stderr() -> None:
            try:
                async for chunk in process.stderr:
                    stderr_chunks.append(chunk)
                    sys.stderr.buffer.write(chunk)
                    sys.stderr.flush()
            except trio.Cancelled:
                raise
            except Exception:
                pass

        with trio.move_on_after(config.timeout_sec) as cancel_scope:
            async with trio.open_nursery() as nursery:
                nursery.start_soon(read_stdout)
                nursery.start_soon(read_stderr)
        if stdout_line_buf.strip():
            _flush_line(stdout_line_buf)
            stdout_line_buf = ""
        sys.stdout.write("\n")
        sys.stdout.flush()
        if cancel_scope.cancelled_caught:
                process.terminate()
                with trio.move_on_after(5):
                    await process.wait()
                if process.returncode is None:
                    process.kill()
                    await process.wait()
                duration_sec = time.perf_counter() - start_time
                raw_output = b"".join(raw_output_chunks).decode("utf-8", errors="replace")
                return CLIAgentResult(
                    trajectory=Trajectory(messages=[]),
                    raw_output=raw_output,
                    duration_sec=duration_sec,
                    exit_code=-1,
                    error=f"Timeout after {config.timeout_sec}s",
                )

        await process.wait()
        duration_sec = time.perf_counter() - start_time
        raw_output = b"".join(raw_output_chunks).decode("utf-8", errors="replace")
        stderr = b"".join(stderr_chunks).decode("utf-8", errors="replace")
        messages = _parse_agent_output(config.agent, raw_output)
        error = None
        if process.returncode != 0:
            error = f"Exit code {process.returncode}: {stderr[:500]}"
        return CLIAgentResult(
            trajectory=Trajectory(messages=messages),
            raw_output=raw_output,
            duration_sec=duration_sec,
            exit_code=process.returncode or 0,
            error=error,
        )
    except FileNotFoundError:
        duration_sec = time.perf_counter() - start_time
        return CLIAgentResult(
            trajectory=Trajectory(messages=[]),
            raw_output="",
            duration_sec=duration_sec,
            exit_code=-1,
            error=f"Agent not found: {config.agent}. Is it installed?",
        )
    except Exception as e:
        duration_sec = time.perf_counter() - start_time
        raw_output = b"".join(raw_output_chunks).decode("utf-8", errors="replace")
        messages = _parse_agent_output(config.agent, raw_output)
        return CLIAgentResult(
            trajectory=Trajectory(messages=messages),
            raw_output=raw_output,
            duration_sec=duration_sec,
            exit_code=-1,
            error=f"Execution failed: {type(e).__name__}: {e}",
        )


def _parse_agent_output(agent: AgentName, output: str) -> list[Message]:
    """Route to appropriate parser based on agent.
    Pure function: dispatches to agent-specific parser.

    Wafer with --output-format stream-json emits Claude Code-compatible NDJSON
    (via JsonFrontend), so we try that parser first. The chunk-format parser
    (parse_wafer_stream_json) handles the direct-endpoint streaming case.
    """
    assert agent in ("claude-code", "codex", "cursor", "wafer")
    if agent == "claude-code":
        messages = parse_claude_code_stream_json(output)
    elif agent == "codex":
        messages = parse_codex_json(output)
    elif agent == "cursor":
        messages = parse_cursor_stream_json(output)
    elif agent == "wafer":
        messages = parse_claude_code_stream_json(output)
        if not messages:
            messages = parse_wafer_stream_json(output)
    else:
        messages = parse_raw_text_fallback(output)

    if not messages and output.strip():
        messages = parse_raw_text_fallback(output)
    return messages


# ── Evaluation Integration ────────────────────────────────────────────────────
async def evaluate_cli_agent_sample(
    config: CLIAgentConfig,
    sample_data: dict[str, Any],
    sample_id: str,
    working_dir: Path,
    build_instruction: Callable[[dict[str, Any]], str],
    score_fn: Callable[[Sample], Score],
    on_stream_line: Callable[[dict[str, Any]], None] | None = None,
    output_prefix: str | None = None,
    stdout_lock: threading.Lock | None = None,
    eval_logger: logging.Logger | None = None,
) -> Sample:
    """Evaluate a single sample with a CLI agent.
    Drop-in replacement for evaluate_sample() but uses CLI agent instead of LLM API.
    Args:
        config: CLI agent configuration
        sample_data: Raw sample data (problem definition)
        sample_id: Unique identifier for this sample
        working_dir: Directory where agent executes
        build_instruction: Function that builds instruction from sample_data
        score_fn: Scoring function (Sample -> Score)
        on_stream_line: Optional callback for each parsed JSON line from agent
        output_prefix: When set, prefix each line of agent stdout (for concurrent runs)
    Returns:
        Sample with trajectory, score, and metadata
    """
    assert config is not None
    assert sample_data is not None
    assert sample_id is not None
    assert working_dir.exists()  # noqa: ASYNC240 - sync assertion before async work
    instruction = build_instruction(sample_data)
    assert instruction is not None
    assert len(instruction) > 0
    result = await run_cli_agent(
        config, instruction, working_dir,
        on_stream_line=on_stream_line,
        output_prefix=output_prefix,
        stdout_lock=stdout_lock,
        use_modal=config.use_modal,
    )
    turns_used = len(result.trajectory.messages) if result.trajectory else 0
    sample = Sample(
        id=sample_id,
        input=sample_data,
        trajectory=result.trajectory,
        ground_truth=sample_data.get("expected_answer") or sample_data.get("ground_truth"),
        metadata={
            "agent": config.agent,
            "model": config.model,
            "duration_sec": result.duration_sec,
            "exit_code": result.exit_code,
            "error": result.error,
            "status": "success" if result.error is None else "failed",
            "turns_used": turns_used,
        },
    )
    import inspect
    if output_prefix is not None and stdout_lock is not None:
        _prefixed_write(
            _color(_MAGENTA, "  [Judge running...]\n"),
            output_prefix,
            [True],
            stdout_lock,
        )
    # Write judge_start directly so UI sees it immediately (logger queue can lag)
    output_dir = working_dir.parent.parent
    events_path = output_dir / "events.jsonl"

    def _write_judge_event(obj: dict) -> None:
        if events_path.exists():
            with open(events_path, "a") as f:
                f.write(json.dumps(obj, default=str) + "\n")
                f.flush()

    if events_path.exists():
        _write_judge_event({
            "message": "judge_start",
            "type": "judge_start",
            "id": sample_id,
            "sample_id": sample_id,
        })

    judge_at_line_start: list[bool] = [True]

    def _on_judge_chunk(chunk: str) -> None:
        _write_judge_event({
            "type": "judge_result_delta",
            "id": sample_id,
            "sample_id": sample_id,
            "delta": chunk,
        })
        if output_prefix is not None and stdout_lock is not None:
            _prefixed_write(
                _color(_MAGENTA, chunk),
                output_prefix,
                judge_at_line_start,
                stdout_lock,
            )

    try:
        score_result = score_fn(sample, on_chunk=_on_judge_chunk)
    except TypeError:
        score_result = score_fn(sample)
    if inspect.iscoroutine(score_result):
        score = await score_result
    else:
        score = score_result
    sample.score = score
    sample.reward = score.reward if score else 0.0
    if sample.reward > 0 and sample.metadata.get("status") == "failed":
        sample.metadata["status"] = "completed"
    if eval_logger is not None and sample.metadata.get("judge_output"):
        eval_logger.info(
            "judge_result",
            extra={
                "type": "judge_result",
                "id": sample_id,
                "sample_id": sample_id,
                "judge_output": sample.metadata["judge_output"],
                "reward": sample.reward,
            },
        )
    judge_out = sample.metadata.get("judge_output", "")
    if output_prefix is not None and stdout_lock is not None and judge_out:
        full = judge_out if judge_out.endswith("\n") else judge_out + "\n"
        _prefixed_write(
            _color(_MAGENTA, f"  Judge: {full}"),
            output_prefix,
            [True],
            stdout_lock,
        )
    return sample


async def evaluate_cli_agents(
    dataset: list[dict[str, Any]],
    config: CLIEvalConfig,
    working_dir: Path | None = None,
) -> EvalReport:
    """Production-grade CLI agent evaluation runner.

    Replaces evaluate() for all CLI-agent-based evals. Features:
    - Resume support (skip completed samples)
    - Per-sample file streaming (live observability)
    - Partial report writing (interrupt recovery)
    - Retry failed samples with exponential backoff
    - Progress display
    - Summary metrics
    - Supabase upload
    """
    from .eval_utils import (
        EvalReport,
        compute_summary_metrics,
        load_completed_sample_ids,
        load_streamed_samples,
        stream_sample_to_file,
        write_partial_report,
    )

    assert config.agents is not None
    assert len(config.agents) > 0
    assert dataset is not None
    assert len(dataset) > 0

    output_dir = config.output_dir or (
        Path(f"results/{config.eval_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    if working_dir is None:
        working_dir = output_dir / "workdirs"
    working_dir.mkdir(parents=True, exist_ok=True)

    # Resume: load completed sample IDs
    completed_ids: set[str] = set()
    resumed_samples: list[Sample] = []
    if config.resume_dir:
        completed_ids = load_completed_sample_ids(config.resume_dir)
        resumed_samples = load_streamed_samples(config.resume_dir)
        logger.info(f"Resuming: {len(completed_ids)} completed samples found")

    # Build work list
    samples_to_eval: list[tuple[str, CLIAgentConfig, dict[str, Any]]] = []
    effective_dataset = dataset[: config.max_samples] if config.max_samples else dataset
    for agent_config in config.agents:
        for idx, sample_data in enumerate(effective_dataset):
            sample_id = f"{agent_config.agent}_{idx:04d}"
            if sample_id in completed_ids:
                continue
            samples_to_eval.append((sample_id, agent_config, sample_data))

    if not samples_to_eval:
        logger.info("All samples already completed")
        return EvalReport(
            eval_name=config.eval_name,
            total_samples=len(effective_dataset) * len(config.agents),
            summary_metrics=compute_summary_metrics(resumed_samples),
            sample_results=resumed_samples,
            metadata=config.metadata,
        )

    from ._logging.logging_config import setup_eval_logging

    eval_logging_ctx = setup_eval_logging(output_dir)
    eval_logger = logging.getLogger("wafer.eval.events")
    total_to_run = len(samples_to_eval) + len(resumed_samples)
    eval_logger.info(
        "eval_start",
        extra={
            "type": "eval_start",
            "id": "",
            "eval_name": config.eval_name,
            "total": total_to_run,
        },
    )

    resumed = len(completed_ids)
    if resumed:
        logger.info(f"Evaluating {len(samples_to_eval)} samples ({resumed} already done)")
    else:
        logger.info(f"Evaluating {len(samples_to_eval)} samples")

    all_results: list[Sample] = list(resumed_samples)
    last_report_count = len(all_results)
    interrupted = False
    limiter = trio.CapacityLimiter(config.max_concurrent)
    stdout_lock = threading.Lock() if config.max_concurrent > 1 else None

    try:

        async def _run_one(
            sample_id: str,
            agent_config: CLIAgentConfig,
            sample_data: dict[str, Any],
        ) -> Sample:
            nonlocal last_report_count
            eval_logger.info(
                "sample_start",
                extra={"type": "sample_start", "id": sample_id, "sample_id": sample_id},
            )
            write_sample_started(sample_id, sample_data, output_dir)
            async with limiter:
                sample_dir = working_dir / sample_id
                sample_dir.mkdir(parents=True, exist_ok=True)
                if config.prepare_working_dir:
                    config.prepare_working_dir(sample_data, sample_dir)
                effective_config = agent_config
                if config.timeout_override:
                    effective_config = CLIAgentConfig(
                        agent=agent_config.agent,
                        model=agent_config.model,
                        allowed_tools=agent_config.allowed_tools,
                        timeout_sec=config.timeout_override,
                        extra_args=agent_config.extra_args,
                    )
                def _on_agent_line(obj: dict[str, Any], _sid: str = sample_id) -> None:
                    event_type = obj.get("type", "unknown")
                    extra: dict[str, Any] = {"type": event_type, "id": _sid, "sample_id": _sid}
                    for k, v in obj.items():
                        if k == "message":
                            extra["msg_payload"] = v
                        else:
                            extra[k] = v
                    eval_logger.info(event_type, extra=extra)

                prefix = sample_id if config.max_concurrent > 1 else None
                sample = await evaluate_cli_agent_sample(
                    config=effective_config,
                    sample_data=sample_data,
                    sample_id=sample_id,
                    working_dir=sample_dir,
                    build_instruction=config.build_instruction,
                    score_fn=config.score_fn,
                    on_stream_line=_on_agent_line,
                    output_prefix=prefix,
                    stdout_lock=stdout_lock,
                    eval_logger=eval_logger,
                )
                stream_sample_to_file(sample, output_dir)
                all_results.append(sample)
                reward = sample.reward if hasattr(sample, "reward") else 0.0
                eval_logger.info(
                    "sample_end",
                    extra={
                        "type": "sample_end",
                        "id": sample_id,
                        "sample_id": sample_id,
                        "score": reward,
                        "reward": reward,
                    },
                )
                if config.on_sample_complete:
                    config.on_sample_complete(sample)
                if len(all_results) - last_report_count >= config.report_batch_size:
                    write_partial_report(
                        output_dir, all_results, config.eval_name,
                        metadata=config.metadata,
                    )
                    last_report_count = len(all_results)
                return sample

        # Run batch with interrupt handling
        try:
            async with trio.open_nursery() as nursery:
                for sample_id, agent_config, sample_data in samples_to_eval:
                    async def task(
                        sid: str = sample_id,
                        acfg: CLIAgentConfig = agent_config,
                        sdata: dict[str, Any] = sample_data,
                    ) -> None:
                        await _run_one(sid, acfg, sdata)
                    nursery.start_soon(task)
        except KeyboardInterrupt:
            interrupted = True
            logger.warning("Evaluation interrupted by user")
        except BaseExceptionGroup as eg:
            if eg.subgroup(KeyboardInterrupt) is not None:
                interrupted = True
                logger.warning("Evaluation interrupted by user (from nursery)")
            else:
                raise

        # Retry failed samples
        if not interrupted and config.max_sample_retries > 0:
            for retry_attempt in range(config.max_sample_retries):
                provider_errors = [
                    (s.id, s.input)
                    for s in all_results
                    if s.metadata.get("status") == "provider_error"
                ]
                if not provider_errors:
                    break
                wait_seconds = min(30 * (2 ** retry_attempt), 120)
                logger.info(
                    f"Retry {retry_attempt + 1}/{config.max_sample_retries}: "
                    f"{len(provider_errors)} provider errors, waiting {wait_seconds}s"
                )
                await trio.sleep(wait_seconds)
                for err_id, err_input in provider_errors:
                    matching = [
                        (sid, acfg, sdata)
                        for sid, acfg, sdata in samples_to_eval
                        if sid == err_id
                    ]
                    if matching:
                        _, acfg, sdata = matching[0]
                        all_results = [r for r in all_results if r.id != err_id]
                        await _run_one(err_id, acfg, sdata)

        # Write final report
        summary_metrics = compute_summary_metrics(all_results)
        report = EvalReport(
            eval_name=config.eval_name,
            total_samples=len(effective_dataset) * len(config.agents),
            summary_metrics=summary_metrics,
            sample_results=all_results,
            metadata=config.metadata,
        )

        if output_dir:
            await report.save(output_dir)
            if interrupted:
                write_partial_report(
                    output_dir, all_results, config.eval_name,
                    interrupted=True, metadata=config.metadata,
                )

        eval_logger.info(
            "eval_end",
            extra={
                "type": "eval_end",
                "id": "",
                "eval_name": config.eval_name,
                "total": len(all_results),
                "mean_reward": summary_metrics.get("mean_reward", 0.0),
                "interrupted": interrupted,
            },
        )
    finally:
        eval_logging_ctx.teardown()

    # Upload
    if config.upload_to_supabase and output_dir:
        try:
            from .upload import upload_results_to_supabase
            upload_results_to_supabase(output_dir)
        except Exception as e:
            logger.warning(f"Failed to upload to Supabase: {e}")

    logger.info(f"Complete: {len(all_results)} samples, mean_reward={summary_metrics.get('mean_reward', 0.0):.3f}")
    return report


# ── Convenience Functions ─────────────────────────────────────────────────────
def trajectory_to_text(trajectory: Trajectory) -> str:
    """Convert trajectory to human-readable text.
    Useful for logging and debugging.
    Pure function: trajectory -> string.
    """
    assert trajectory is not None
    lines = []
    for msg in trajectory.messages:
        role = msg.role.upper()
        if isinstance(msg.content, str):
            lines.append(f"[{role}]\n{msg.content}\n")
        elif isinstance(msg.content, list):
            parts = []
            for block in msg.content:
                if isinstance(block, TextContent):
                    parts.append(block.text)
                elif isinstance(block, ToolCallContent):
                    parts.append(f"[TOOL: {block.name}({json.dumps(block.arguments)})]")
            lines.append(f"[{role}]\n{''.join(parts)}\n")
        else:
            lines.append(f"[{role}]\n{msg.content}\n")
    return "\n".join(lines)
