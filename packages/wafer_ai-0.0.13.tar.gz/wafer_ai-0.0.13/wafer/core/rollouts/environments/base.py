# Environment class moved to dtypes.py to avoid circular imports
# This file is kept for backward compatibility but is now empty
# Import Environment from dtypes instead:
# from ..dtypes import Environment
