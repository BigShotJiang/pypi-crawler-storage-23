"""Reconciliation: compare TargetSpecs to live Targets.

Pure function — no API calls, no side effects. Takes specs and targets as
inputs, returns a ReconcileResult describing what's bound, what's orphaned,
and what's unprovisioned.
"""

from __future__ import annotations

from wafer.core.targets.types import ReconcileResult, Target, TargetSpec


def reconcile(
    specs: list[TargetSpec],
    targets: list[Target],
    binding_hints: dict[str, str] | None = None,
) -> ReconcileResult:
    """Compare specs to live targets and classify each.

    Matching rules (in priority order):
    1. Target.spec_name matches Spec.name exactly (set by naming convention
       or explicit binding).
    2. binding_hints maps resource_id → spec_name (from local cache).
    3. No match → target is unbound (orphan).

    Args:
        specs: All known TargetSpecs (loaded from TOML files).
        targets: All live Targets (fetched from provider APIs).
        binding_hints: Optional resource_id → spec_name cache for targets
            whose spec_name can't be inferred from naming convention.

    Returns:
        ReconcileResult with bound, unbound, and unprovisioned lists.
    """
    hints = binding_hints or {}
    spec_by_name = {s.name: s for s in specs}

    bound: list[tuple[TargetSpec, Target]] = []
    unbound: list[Target] = []

    for target in targets:
        resolved_spec_name = target.spec_name or hints.get(target.resource_id)
        if resolved_spec_name and resolved_spec_name in spec_by_name:
            spec = spec_by_name[resolved_spec_name]
            bound.append((spec, target))
        else:
            unbound.append(target)

    return ReconcileResult(
        bound=bound,
        unbound=unbound,
        unprovisioned=[],
    )
