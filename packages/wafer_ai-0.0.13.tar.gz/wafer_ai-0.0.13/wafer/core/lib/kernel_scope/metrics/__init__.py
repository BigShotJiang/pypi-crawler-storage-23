"""Metric computation for kernel scope analysis."""

from wafer.core.lib.kernel_scope.metrics.occupancy import (
    OccupancyResult,
    compute_occupancy,
)

__all__ = [
    "compute_occupancy",
    "OccupancyResult",
]
