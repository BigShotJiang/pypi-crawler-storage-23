"""Wafer environments for agent execution."""

from wafer.core.environments.coding import CodingEnvironment
from wafer.core.environments.gpumode import GPUModeSimpleEnvironment
from wafer.core.environments.remote_target import RemoteTargetEnvironment

__all__ = ["CodingEnvironment", "GPUModeSimpleEnvironment", "RemoteTargetEnvironment"]
