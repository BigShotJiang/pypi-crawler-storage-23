<!-- AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
     Regenerate with: just generate-skill
     Source template: SKILL.md.template -->

# Command Reference

### `wafer tool eval`
Test kernel correctness and performance

Usage:
  wafer tool eval --task <name>       Run evaluation for a specific task
  wafer tool eval --list-tasks        List all available evaluation tasks

Available tasks: kernelbench, gpumode, aiter, vllm, flashinfer-bench, hipblaslt

GPU access is composed via target run:
  wafer target run --name <target> -- wafer tool eval --task <name>

### `wafer tool`
Run profiling, evaluation, and analysis tools.

Subcommands:
  wafer tool roofline  Analyze kernel performance against roofline model.
  wafer tool capture  Capture an execution snapshot for reproducibility and comparison.
  wafer tool capture-list  List captured executions.
  wafer tool eval  Test kernel correctness and performance
  wafer tool baseline  Discover what kernel PyTorch dispatches to for a given operation.
  wafer tool ncu  Nsight Compute profiling and analysis
  wafer tool nsys  Nsight Systems profile analysis
  wafer tool perfetto  Perfetto trace analysis and SQL queries
  wafer tool tracelens  TraceLens performance reports
  wafer tool nvidia-distributed-traces  Analyze NCCL collective operations in distributed training traces
  wafer tool isa  ISA analysis for AMD GPU kernels (.co, .s, .ll, .ttgir files)
  wafer tool compare  Compare GPU traces across platforms (AMD vs NVIDIA)
  wafer tool amd-distributed-traces  Analyze RCCL collective operations in distributed training traces
  wafer tool rocprof-sdk  ROCprofiler-SDK profiling tool commands
  wafer tool rocprof-systems  ROCprofiler-Systems profiling tool commands
  wafer tool rocprof-compute  ROCprofiler-Compute profiling tool commands
  wafer tool autotuner  Hyperparameter sweep for performance engineering

### `wafer target`
Create, manage, and run code on GPU targets.

Subcommands:
  wafer target list  List all targets (workspaces + hosts).
  wafer target show  Show details for a target (workspace or host).
  wafer target remove  Remove a target (workspace or host).
  wafer target default  Set the default target.
  wafer target ssh  SSH into a target (workspace or host).
  wafer target sync  Sync local files to a target.
  wafer target pull  Pull files from a target to local machine.
  wafer target probe  Probe a target to discover available compilation backends.
  wafer target run  Run a command on a GPU target.
  wafer target pool  Manage target pools for fleet-level evaluation.
  wafer target init  Initialize a new GPU target.

### `wafer agent`
AI assistant for GPU kernel development.
Helps with CUDA/Triton kernel optimization, GPU documentation queries,
and performance analysis. Launches interactive TUI by default.

Examples:
    wafer agent                                    # interactive TUI
    wafer agent "What is TMEM in CuTeDSL?"        # TUI with initial prompt
    wafer agent -t ask-docs "query"                 # use a template
    wafer agent --resume last "follow up"          # resume session

Options:
  --interactive/-i  Launch full interactive TUI mode (default when no prompt given)
  --simple  Use simple stdout mode instead of TUI (for scripts/pipes)
  --resume/-r TEXT  Resume session by ID (or 'last' for most recent)
  --from-turn INTEGER  Branch from specific turn (default: resume from end)
  --list-sessions  List recent sessions and exit
  --get-session TEXT  Get session by ID and print messages (use with --json)
  --allow-spawn  Allow wafer tool to spawn sub-wevin agents (blocked by default)
  --max-tool-fails INTEGER  Exit after N consecutive tool failures
  --json/-j  Output in JSON format (stream-json style)
  --list-templates  List available templates with descriptions and args, then exit
  --template/-t TEXT  Run with template (use --list-templates to see all available)
  --args TEXT  Template variable (KEY=VALUE, can be repeated)
  --env TEXT  Environment name (coding, remote-target, modal-sandbox). Uses --args for config.
  --workspace TEXT  Workspace ID (requires --env workspace)

### `wafer settings skill`
Manage AI coding assistant skills (Claude Code, Codex)

Subcommands:
  wafer settings skill install  Install the wafer-guide skill for AI coding assistants.
  wafer settings skill uninstall  Uninstall the wafer-guide skill.
  wafer settings skill status  Show installation status of the wafer-guide skill.
