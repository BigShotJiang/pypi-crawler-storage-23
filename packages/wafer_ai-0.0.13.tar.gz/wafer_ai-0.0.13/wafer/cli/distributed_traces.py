"""CLI commands for distributed traces analysis.
Provides subcommands for analyzing NCCL/RCCL collective operations
in distributed training traces.
Commands:
    analyze  - Full analysis with all metrics
    collect  - Run command with profiling enabled
    compare  - Differential analysis between trace sets
    metrics  - List available metrics and thresholds
"""
from pathlib import Path

import typer

nvidia_distributed_traces_app = typer.Typer(
    help="Analyze NCCL collective operations in distributed training traces"
)
amd_distributed_traces_app = typer.Typer(
    help="Analyze RCCL collective operations in distributed training traces"
)


def _run_analyze(
    files: list[Path],
    output: Path | None,
    format_type: str,
    interconnect: str,
    timeout: int,
    json_output: bool,
    verbose: bool,
) -> None:
    """Common analyze implementation for both NVIDIA and AMD."""
    from wafer.core.lib.distributed_traces import (
        AnalyzerConfig,
        DistributedTracesAnalyzer,
    )
    from wafer.core.lib.distributed_traces.analysis.bandwidth import InterconnectType

    interconnect_map = {
        "nvlink3": InterconnectType.NVLINK_3,
        "nvlink4": InterconnectType.NVLINK_4,
        "nvlink5": InterconnectType.NVLINK_5,
        "pcie4": InterconnectType.PCIE_4,
        "pcie5": InterconnectType.PCIE_5,
        "xgmi": InterconnectType.XGMI,
        "ib-hdr": InterconnectType.IB_HDR,
        "ib-ndr": InterconnectType.IB_NDR,
        "auto": InterconnectType.UNKNOWN,
    }
    config = AnalyzerConfig(
        interconnect=interconnect_map.get(interconnect, InterconnectType.UNKNOWN),
        timeout_sec=float(timeout),
    )
    analyzer = DistributedTracesAnalyzer(config)
    file_paths = [str(f) for f in files]
    if verbose:
        typer.echo(f"Loading {len(file_paths)} trace files...")
    session, error = analyzer.load_traces(file_paths)
    if error:
        typer.echo(f"Error loading traces: {error}", err=True)
        raise typer.Exit(1)
    if session is None:
        typer.echo("Error: No traces loaded", err=True)
        raise typer.Exit(1)
    # Analyze
    if verbose:
        typer.echo("Analyzing traces...")
    result = analyzer.analyze(session)
    # Output
    if json_output or format_type == "json":
        output_str = analyzer.export_json(result, session)
        if output:
            Path(output).write_text(output_str)
            typer.echo(f"Results written to {output}")
        else:
            typer.echo(output_str)
    elif format_type == "csv":
        output_str = analyzer.export_csv(session)
        if output:
            Path(output).write_text(output_str)
            typer.echo(f"Results written to {output}")
        else:
            typer.echo(output_str)
    else:
        # Text output
        _print_analysis_summary(result, session, verbose)
        if output:
            output_str = analyzer.export_json(result, session)
            Path(output).write_text(output_str)
            typer.echo(f"\nDetailed results written to {output}")


def _print_analysis_summary(result: "AnalysisResult", session: "TraceSession", verbose: bool) -> None:  # noqa: F821
    """Print analysis summary to console."""
    summary = result.summary
    typer.echo("\n" + "=" * 60)
    typer.echo("DISTRIBUTED TRACES ANALYSIS")
    typer.echo("=" * 60)
    typer.echo(f"\nSession: {summary.get('session_name', 'unnamed')}")
    typer.echo(f"Format: {summary.get('trace_format', 'unknown')}")
    typer.echo(f"Ranks: {summary.get('num_ranks', 0)}")
    typer.echo(f"Total Collectives: {summary.get('total_collectives', 0)}")
    typer.echo(f"Duration: {summary.get('duration_ms', 0):.2f} ms")
    typer.echo("\n--- Bandwidth ---")
    typer.echo(f"Achieved: {summary.get('achieved_bandwidth_gbps', 0):.2f} GB/s")
    typer.echo(f"Efficiency: {summary.get('bandwidth_efficiency_percent', 0):.1f}%")
    typer.echo("\n--- Communication/Compute Overlap ---")
    typer.echo(f"Overlap Ratio: {summary.get('overlap_percent', 0):.1f}%")
    typer.echo("\n--- Straggler Detection ---")
    flagged = summary.get('flagged_straggler_ranks', [])
    if flagged:
        typer.echo(f"Flagged Ranks: {flagged}")
        typer.echo(f"Total Impact: {summary.get('total_straggler_impact_ms', 0):.2f} ms")
    else:
        typer.echo("No stragglers detected")
    typer.echo("\n--- Hang Risk ---")
    risk_dist = summary.get('hang_risk_distribution', {})
    critical = risk_dist.get('critical', 0)
    warning = risk_dist.get('warning', 0)
    if critical > 0:
        typer.echo(f"CRITICAL: {critical} collectives at >50% of timeout")
    if warning > 0:
        typer.echo(f"WARNING: {warning} collectives at 10-50% of timeout")
    if critical == 0 and warning == 0:
        typer.echo("All collectives within normal thresholds")
    if verbose:
        typer.echo("\n--- Collectives by Type ---")
        for ctype, count in summary.get('collectives_by_type', {}).items():
            typer.echo(f"  {ctype}: {count}")
    typer.echo("")


# NVIDIA Commands
@nvidia_distributed_traces_app.command("analyze")
def nvidia_analyze(
    files: list[Path] = typer.Argument(
        ...,
        help="Trace files to analyze (PyTorch JSON, NCCL Inspector JSONL, NSYS SQLite)",
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
    format_type: str = typer.Option(
        "text", "--format", "-f", help="Output format: text, json, csv"
    ),
    interconnect: str = typer.Option(
        "auto",
        "--interconnect",
        "-i",
        help="Interconnect type: nvlink3, nvlink4, nvlink5, pcie4, pcie5, ib-hdr, ib-ndr, auto",
    ),
    timeout: int = typer.Option(
        600, "--timeout", "-t", help="NCCL timeout threshold in seconds"
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Output as JSON (shorthand for --format json)"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
) -> None:
    """Analyze NCCL collective operations in distributed training traces.
    Supports PyTorch Profiler JSON, NCCL Inspector JSONL, and Nsight Systems SQLite.
    Examples:
        wafer tool nvidia-distributed-traces analyze trace_rank*.json
        wafer tool nvidia-distributed-traces analyze ./traces/ --format json
        wafer tool nvidia-distributed-traces analyze trace.nsys-rep --interconnect nvlink4
    """
    # Expand directories to files
    expanded_files = _expand_file_paths(files)
    if not expanded_files:
        typer.echo("Error: No trace files found", err=True)
        raise typer.Exit(1)
    _run_analyze(expanded_files, output, format_type, interconnect, timeout, json_output, verbose)


@nvidia_distributed_traces_app.command("collect")
def nvidia_collect(
    command: list[str] = typer.Argument(..., help="Command to run with tracing"),
    output_dir: Path = typer.Option(
        Path("./traces"), "--output", "-o", help="Output directory for traces"
    ),
    method: str = typer.Option(
        "inspector",
        "--method",
        "-m",
        help="Collection method: inspector (NCCL Inspector) or nsys (Nsight Systems)",
    ),
    analyze: bool = typer.Option(
        True, "--analyze/--no-analyze", help="Run analysis after collection"
    ),
) -> None:
    """Run a command with NCCL trace collection enabled.
    Sets up environment variables for NCCL Inspector or wraps with Nsight Systems.
    Examples:
        wafer tool nvidia-distributed-traces collect python train.py --world-size 4
        wafer tool nvidia-distributed-traces collect --method nsys torchrun --nproc_per_node 8 train.py
    """
    from wafer.core.lib.distributed_traces.collection import NVIDIACollector
    collector = NVIDIACollector()
    collector.nccl_config.output_dir = str(output_dir)
    collector.nsys_config.output_path = str(output_dir / "nsys_trace")
    typer.echo(f"Collecting traces to {output_dir}")
    if method == "inspector":
        result = collector.collect_with_inspector(command)
    elif method == "nsys":
        result = collector.collect_with_nsys(command)
    else:
        typer.echo(f"Unknown method: {method}. Use 'inspector' or 'nsys'.", err=True)
        raise typer.Exit(1)
    if not result.success:
        typer.echo(f"Collection failed: {result.error}", err=True)
        if result.stderr:
            typer.echo(result.stderr, err=True)
        raise typer.Exit(1)
    typer.echo("Collection complete. Output files:")
    for f in result.output_files:
        typer.echo(f"  {f}")
    if analyze and result.output_files:
        typer.echo("\nRunning analysis...")
        _run_analyze(
            [Path(f) for f in result.output_files],
            output_dir / "analysis.json",
            "text",
            "auto",
            600,
            False,
            True,
        )


@nvidia_distributed_traces_app.command("compare")
def nvidia_compare(
    baseline: Path = typer.Argument(..., help="Baseline trace file or directory"),
    comparison: Path = typer.Argument(..., help="Comparison trace file or directory"),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Compare two trace sets for performance regression detection.
    Examples:
        wafer tool nvidia-distributed-traces compare baseline/ comparison/
        wafer tool nvidia-distributed-traces compare before.json after.json --json
    """
    from wafer.core.lib.distributed_traces import DistributedTracesAnalyzer
    analyzer = DistributedTracesAnalyzer()
    baseline_files = _expand_file_paths([baseline])
    comparison_files = _expand_file_paths([comparison])
    baseline_session, err1 = analyzer.load_traces(baseline_files, "baseline")
    if err1:
        typer.echo(f"Error loading baseline: {err1}", err=True)
        raise typer.Exit(1)
    comparison_session, err2 = analyzer.load_traces(comparison_files, "comparison")
    if err2:
        typer.echo(f"Error loading comparison: {err2}", err=True)
        raise typer.Exit(1)
    # Compare
    result = analyzer.compare_sessions(baseline_session, comparison_session)
    if json_output:
        output_data = {
            "baseline": result.baseline_summary,
            "comparison": result.comparison_summary,
            "bandwidth_delta_percent": result.bandwidth_delta,
            "overlap_delta_percent": result.overlap_delta,
            "straggler_delta_percent": result.straggler_delta,
            "regressions": result.regressions,
            "improvements": result.improvements,
            "recommendations": result.recommendations,
        }
        from .output import json_response
        output_str = json_response(data=output_data)
        if output:
            Path(output).write_text(output_str)
        else:
            typer.echo(output_str)
    else:
        typer.echo("\n" + "=" * 60)
        typer.echo("TRACE COMPARISON")
        typer.echo("=" * 60)
        typer.echo(f"\nBandwidth: {result.bandwidth_delta:+.1f}%")
        typer.echo(f"Overlap: {result.overlap_delta:+.1f}%")
        typer.echo(f"Straggler Impact: {result.straggler_delta:+.1f}%")
        if result.regressions:
            typer.echo("\n--- Regressions ---")
            for r in result.regressions:
                typer.echo(f"  - {r}")
        if result.improvements:
            typer.echo("\n--- Improvements ---")
            for i in result.improvements:
                typer.echo(f"  + {i}")
        if result.recommendations:
            typer.echo("\n--- Recommendations ---")
            for rec in result.recommendations:
                typer.echo(f"  {rec}")


@nvidia_distributed_traces_app.command("metrics")
def nvidia_metrics() -> None:
    """List available metrics and their thresholds.
    Shows all metrics computed by the distributed traces analyzer and their
    default thresholds for flagging issues.
    """
    _print_metrics_info()


# AMD Commands (mirror NVIDIA commands)
@amd_distributed_traces_app.command("analyze")
def amd_analyze(
    files: list[Path] = typer.Argument(
        ...,
        help="Trace files to analyze (PyTorch JSON, rocprofv3 CSV/JSON, ROCm Systems)",
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
    format_type: str = typer.Option(
        "text", "--format", "-f", help="Output format: text, json, csv"
    ),
    interconnect: str = typer.Option(
        "auto",
        "--interconnect",
        "-i",
        help="Interconnect type: xgmi, pcie4, pcie5, ib-hdr, ib-ndr, auto",
    ),
    timeout: int = typer.Option(
        600, "--timeout", "-t", help="RCCL timeout threshold in seconds"
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Output as JSON (shorthand for --format json)"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
) -> None:
    """Analyze RCCL collective operations in distributed training traces.
    Supports PyTorch Profiler JSON, rocprofv3 CSV/JSON, and ROCm Systems Profiler.
    Examples:
        wafer tool amd-distributed-traces analyze trace_rank*.json
        wafer tool amd-distributed-traces analyze ./traces/ --format json
        wafer tool amd-distributed-traces analyze results.csv --interconnect xgmi
    """
    expanded_files = _expand_file_paths(files)
    if not expanded_files:
        typer.echo("Error: No trace files found", err=True)
        raise typer.Exit(1)
    _run_analyze(expanded_files, output, format_type, interconnect, timeout, json_output, verbose)


@amd_distributed_traces_app.command("collect")
def amd_collect(
    command: list[str] = typer.Argument(..., help="Command to run with tracing"),
    output_dir: Path = typer.Option(
        Path("./traces"), "--output", "-o", help="Output directory for traces"
    ),
    method: str = typer.Option(
        "rocprofv3",
        "--method",
        "-m",
        help="Collection method: rocprofv3 or omnitrace",
    ),
    analyze: bool = typer.Option(
        True, "--analyze/--no-analyze", help="Run analysis after collection"
    ),
) -> None:
    """Run a command with RCCL trace collection enabled.
    Wraps command with rocprofv3 or ROCm Systems Profiler for trace collection.
    Examples:
        wafer tool amd-distributed-traces collect python train.py --world-size 4
        wafer tool amd-distributed-traces collect --method omnitrace torchrun --nproc_per_node 8 train.py
    """
    from wafer.core.lib.distributed_traces.collection import AMDCollector
    collector = AMDCollector()
    collector.rocprofv3_config.output_dir = str(output_dir)
    collector.rocsys_config.output_dir = str(output_dir)
    typer.echo(f"Collecting traces to {output_dir}")
    if method == "rocprofv3":
        result = collector.collect_with_rocprofv3(command)
    elif method == "omnitrace":
        result = collector.collect_with_omnitrace(command)
    else:
        typer.echo(f"Unknown method: {method}. Use 'rocprofv3' or 'omnitrace'.", err=True)
        raise typer.Exit(1)
    if not result.success:
        typer.echo(f"Collection failed: {result.error}", err=True)
        if result.stderr:
            typer.echo(result.stderr, err=True)
        raise typer.Exit(1)
    typer.echo("Collection complete. Output files:")
    for f in result.output_files:
        typer.echo(f"  {f}")
    if analyze and result.output_files:
        typer.echo("\nRunning analysis...")
        _run_analyze(
            [Path(f) for f in result.output_files],
            output_dir / "analysis.json",
            "text",
            "auto",
            600,
            False,
            True,
        )


@amd_distributed_traces_app.command("compare")
def amd_compare(
    baseline: Path = typer.Argument(..., help="Baseline trace file or directory"),
    comparison: Path = typer.Argument(..., help="Comparison trace file or directory"),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Compare two trace sets for performance regression detection.
    Examples:
        wafer tool amd-distributed-traces compare baseline/ comparison/
        wafer tool amd-distributed-traces compare before.json after.json --json
    """
    # Reuse NVIDIA compare logic
    nvidia_compare(baseline, comparison, output, json_output)


@amd_distributed_traces_app.command("metrics")
def amd_metrics() -> None:
    """List available metrics and their thresholds."""
    _print_metrics_info()


def _expand_file_paths(paths: list[Path]) -> list[Path]:
    """Expand directories to trace files."""
    expanded = []
    trace_extensions = {".json", ".jsonl", ".csv", ".nsys-rep", ".sqlite", ".rocpd", ".db", ".gz"}
    for path in paths:
        if path.is_dir():
            for ext in trace_extensions:
                expanded.extend(path.glob(f"*{ext}"))
        elif path.exists():
            expanded.append(path)
        elif "*" in str(path):
            import glob
            expanded.extend(Path(p) for p in glob.glob(str(path)))
    return sorted(set(expanded))


def _print_metrics_info() -> None:
    """Print metrics documentation."""
    typer.echo("""
DISTRIBUTED TRACES METRICS
==========================
BANDWIDTH METRICS
-----------------
  Achieved Bandwidth (GB/s)
    Actual bytes/second for each collective
    Calculation: message_size / duration
  Theoretical Bandwidth (GB/s)
    Expected max based on interconnect:
    - NVLink 3.0 (A100): 600 GB/s
    - NVLink 4.0 (H100): 900 GB/s
    - NVLink 5.0 (B200): 1800 GB/s
    - PCIe 4.0 x16: 32 GB/s
    - PCIe 5.0 x16: 64 GB/s
    - xGMI (MI300): 400 GB/s
    - InfiniBand HDR: 25 GB/s
    - InfiniBand NDR: 50 GB/s
  Bandwidth Efficiency (%)
    Achieved / Theoretical * 100
    Threshold: <50% flagged as low
OVERLAP METRICS
---------------
  Overlap Ratio (0-1)
    overlapped_time / communication_time
    Higher is better (more hidden latency)
  Recommendations:
    - <30%: Consider gradient bucketing, smaller first bucket
    - >70%: Excellent overlap
STRAGGLER METRICS
-----------------
  Per-Rank Score
    Cumulative wait time imposed on other ranks
    Formula: (rank_duration - median) * (num_ranks - 1)
  Flagged Threshold
    Ranks exceeding 2 standard deviations above mean
HANG RISK METRICS
-----------------
  Risk Score (% of timeout)
    Collective duration as percentage of timeout threshold
  Risk Levels:
    - Normal: <1% of timeout
    - Elevated: 1-10% of timeout
    - Warning: 10-50% of timeout
    - Critical: >50% of timeout
  Default Timeout: 600 seconds (TORCH_NCCL_HEARTBEAT_TIMEOUT_SEC)
""")
