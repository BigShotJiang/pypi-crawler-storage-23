"""CLI wrapper for trace comparison commands.
This module provides the CLI interface for the `wafer compare` commands.
All core logic is in wafer.core.lib.trace_compare.
Uses the fused analyzer for optimal performance - loads traces once and computes
all analysis results (operation stats, graph matching, fusion analysis) in a single pass.
"""
import os
from pathlib import Path

import typer


def _color(color: str | None) -> str | None:
    """Return color if NO_COLOR is not set, otherwise None."""
    if os.environ.get("NO_COLOR"):
        return None
    return color


from wafer.core.lib.trace_compare import (
    format_fusion_json,
    format_fusion_text,
    format_graph_comparison_detailed,
    format_graph_comparison_json,
    format_json,
    format_text,
)
from wafer.core.lib.trace_compare.fused_analyzer import analyze_and_match_fused


def filter_graph_results_by_phase(graph_results: dict, phase_filter: str | None) -> dict:
    """Filter graph matching results to only include kernels from the specified phase.
    Args:
        graph_results: Results from match_traces()
        phase_filter: Phase to filter by ('prefill', 'decode', 'mixed', or None for all)
    Returns:
        Filtered graph_results with only kernels matching the phase
    """
    if not phase_filter or not graph_results:
        return graph_results
    # Deep copy to avoid modifying original
    filtered = {
        'amd_platform': graph_results.get('amd_platform'),
        'nv_platform': graph_results.get('nv_platform'),
        'amd_graphs': graph_results.get('amd_graphs', []),
        'nv_graphs': graph_results.get('nv_graphs', []),
        'graph_pairs': [],
        'all_matches': [],
        'summary': graph_results.get('summary', {})
    }
    for pair in graph_results.get('graph_pairs', []):
        matches = pair.get('matches', [])
        filtered_matches = []
        for match in matches:
            kernel = match.get('amd_kernel') or match.get('nv_kernel')
            if kernel and kernel.get('phase') == phase_filter:
                filtered_matches.append(match)
        # Only include graph pair if it has matches after filtering
        if filtered_matches:
            filtered_pair = pair.copy()
            filtered_pair['matches'] = filtered_matches
            filtered['graph_pairs'].append(filtered_pair)
    return filtered


def compare_traces(
    trace1: Path,
    trace2: Path,
    output: Path | None = None,
    output_format: str = "text",
    phase: str = "all",
    show_all: bool = False,
    show_stack_traces: bool = False,
    grouped: bool = False,
    max_graphs: int = 10,
    show_fusion: bool = False,
    min_group_size: int = 300,
) -> None:
    """Compare two GPU traces and generate performance report.
    Uses fused analyzer for optimal performance - single trace load computes all results.
    Args:
        trace1: Path to first trace file (AMD or NVIDIA)
        trace2: Path to second trace file (AMD or NVIDIA)
        output: Optional output file path (default: stdout)
        output_format: Output format ('text' or 'json')
        phase: Filter by phase ('all', 'prefill', or 'decode')
        show_all: Show all items without truncation (applies to operations, kernels)
        show_stack_traces: Show Python stack traces for operations
        grouped: Group kernels by operation type in kernel-level details (default: position order)
        max_graphs: Maximum number of CUDA graph patterns to show (default: 10)
        show_fusion: Also show fusion analysis (kernel fusion differences)
        min_group_size: Minimum correlation group size for fusion analysis (default: 300)
    """
    # Validate files exist
    if not trace1.exists():
        typer.secho(f"❌ File not found: {trace1}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    if not trace2.exists():
        typer.secho(f"❌ File not found: {trace2}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    # Run fused analyzer - single pass computes all results (operation stats, graph matching, fusion)
    # Only show progress messages for non-JSON formats (JSON needs clean stdout)
    if output_format != 'json':
        typer.echo("📊 Loading and analyzing traces (fused single-pass)...")
    try:
        # Fused analyzer returns all three results in one call (loads traces once)
        results, graph_results, fusion_results = analyze_and_match_fused(
            trace1,
            trace2,
            min_graph_size=min_group_size,
        )
    except ValueError as e:
        typer.secho(f"❌ {e}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.secho(f"❌ Error analyzing traces: {e}", fg=_color(typer.colors.RED), err=True)
        import traceback
        traceback.print_exc()
        raise typer.Exit(1) from None
    # Show loading confirmation
    if output_format != 'json':
        meta = results["metadata"]

        if meta['trace1_platform'] == 'AMD':
            amd_gpu, nvidia_gpu = meta['trace1_gpu'], meta['trace2_gpu']
        else:
            amd_gpu, nvidia_gpu = meta['trace2_gpu'], meta['trace1_gpu']
        typer.echo(f"✅ Loaded: AMD ({amd_gpu}) vs NVIDIA ({nvidia_gpu})")
        if show_fusion:
            fusion_meta = fusion_results["metadata"]
            typer.echo(
                f"   Found {fusion_meta['trace1_correlation_groups']} AMD groups and "
                f"{fusion_meta['trace2_correlation_groups']} NV groups with ≥{min_group_size} kernels"
            )
            typer.echo(f"   Matched {fusion_meta['matched_groups']} correlation groups for fusion analysis")
    typer.echo()

    if phase and phase != "all":
        graph_results = filter_graph_results_by_phase(graph_results, phase)
    # Generate output based on format
    if output_format == "text":
        output_str = format_text(
            results,
            show_all=show_all,
            show_stack_traces=show_stack_traces,
            grouped=grouped,
            graph_results=graph_results,
            max_graphs=max_graphs
        )
        # Append fusion analysis if requested
        if show_fusion:
            output_str += "\n\n" + "=" * 80 + "\n"
            output_str += "FUSION ANALYSIS\n"
            output_str += "=" * 80 + "\n\n"
            output_str += format_fusion_text(fusion_results)
    elif output_format == "json":
        output_str = format_json(results, graph_results=graph_results)
        if show_fusion:
            import json
            combined = json.loads(output_str)
            combined["fusion"] = json.loads(format_fusion_json(fusion_results))
            output_str = json.dumps(combined, indent=2)
    else:
        typer.secho(f"❌ Unknown format: {output_format}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    # Write output
    if output:
        output.write_text(output_str)
        typer.secho(f"✅ Report saved to {output}", fg=_color(typer.colors.GREEN))
    else:
        typer.echo(output_str)


def compare_fusion(
    trace1: Path,
    trace2: Path,
    output: Path | None = None,
    format_type: str = "text",
    min_group_size: int = 50,
    use_graph_matching: bool = True,
) -> None:
    """Analyze kernel fusion differences between AMD and NVIDIA traces.
    Uses fused analyzer for optimal performance - single trace load computes all results.
    Args:
        trace1: Path to first trace file (AMD or NVIDIA)
        trace2: Path to second trace file (AMD or NVIDIA)
        output: Optional output file path (default: stdout)
        format_type: Output format ('text', 'csv', or 'json')
        min_group_size: Minimum correlation group size to analyze
        use_graph_matching: Use graph-based matching (default True, always used in fused analyzer)
    """
    # Validate files exist
    if not trace1.exists():
        typer.secho(f"❌ File not found: {trace1}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    if not trace2.exists():
        typer.secho(f"❌ File not found: {trace2}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    # Run fused analyzer - single pass computes all results
    # Only show progress messages for non-JSON formats (JSON needs clean stdout)
    if format_type != 'json':
        typer.echo("📊 Loading and analyzing traces (fused single-pass)...")
    try:
        # Fused analyzer returns all three results - we only need fusion results here
        _, _, results = analyze_and_match_fused(
            trace1,
            trace2,
            min_graph_size=min_group_size,
        )
    except Exception as e:
        typer.secho(
            f"❌ Error analyzing traces: {e}", fg=_color(typer.colors.RED), err=True
        )
        import traceback
        traceback.print_exc()
        raise typer.Exit(1) from None
    # Show loading confirmation
    if format_type != 'json':
        meta = results["metadata"]
        # Note: fusion analyzer always uses trace1=AMD, trace2=NVIDIA
        typer.echo(f"✅ Loaded: {meta['trace1_gpu']} vs {meta['trace2_gpu']}")
        typer.echo(
            f"Found {meta['trace1_correlation_groups']} trace1 groups and "
            f"{meta['trace2_correlation_groups']} trace2 groups with ≥{min_group_size} kernels"
        )
        typer.echo(f"✅ Matched {meta['matched_groups']} correlation groups")
        typer.echo()
    # Generate output
    if format_type == "text":
        output_str = format_fusion_text(results)
    elif format_type == "json":
        output_str = format_fusion_json(results)
    else:
        typer.secho(f"❌ Unknown format: {format_type}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    # Write output
    if output:
        output.write_text(output_str)
        typer.secho(f"✅ Report saved to {output}", fg=_color(typer.colors.GREEN))
    else:
        typer.echo(output_str)


def compare_graphs(
    trace1: Path,
    trace2: Path,
    output: Path | None = None,
    format_type: str = "text",
    min_graph_size: int = 300,
    show_all: bool = False,
    grouped: bool = False,
) -> None:
    """Compare CUDA graph execution patterns between AMD and NVIDIA traces.
    Uses fused analyzer for optimal performance - single trace load computes all results.
    Default view shows kernels in position order. Use --grouped to group by operation type.
    Args:
        trace1: Path to first trace file (AMD or NVIDIA)
        trace2: Path to second trace file (AMD or NVIDIA)
        output: Optional output file path (default: stdout)
        format_type: Output format ('text' or 'json')
        min_graph_size: Minimum graph size to analyze (default: 300 for transformer layers)
        show_all: Show all kernel pairs without truncation
        grouped: Group kernels by operation type instead of position order
    """
    # Validate files exist
    if not trace1.exists():
        typer.secho(f"❌ File not found: {trace1}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    if not trace2.exists():
        typer.secho(f"❌ File not found: {trace2}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    # Run fused analyzer - single pass computes all results
    if format_type != 'json':
        typer.echo("📊 Loading and analyzing traces (fused single-pass)...")
    try:
        # Fused analyzer returns all three results - we only need graph matching here
        _, results, _ = analyze_and_match_fused(
            trace1,
            trace2,
            min_graph_size=min_graph_size,
        )
    except Exception as e:
        typer.secho(
            f"❌ Error analyzing traces: {e}", fg=_color(typer.colors.RED), err=True
        )
        import traceback
        traceback.print_exc()
        raise typer.Exit(1)
    # Show loading confirmation
    if format_type != 'json':
        summary = results['summary']
        typer.echo(f"✅ Matched {summary['num_graph_pairs']:,} CUDA graph pairs")
        typer.echo(f"   Match rate: {summary['match_rate']:.1f}% "
                   f"({summary['matched']:,} matched, "
                   f"{summary['amd_only']:,} AMD-only, "
                   f"{summary['nv_only']:,} NV-only)")
        typer.echo()
    # Generate output
    if format_type == "text":
        output_str = format_graph_comparison_detailed(results, show_all=show_all, group_by_op=grouped)
    elif format_type == "json":
        output_str = format_graph_comparison_json(results)
    else:
        typer.secho(f"❌ Unknown format: {format_type}", fg=_color(typer.colors.RED), err=True)
        raise typer.Exit(1)
    # Write output
    if output:
        output.write_text(output_str)
        typer.secho(f"✅ Report saved to {output}", fg=_color(typer.colors.GREEN))
    else:
        typer.echo(output_str)
