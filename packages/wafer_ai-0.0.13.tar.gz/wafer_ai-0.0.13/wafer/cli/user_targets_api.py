"""API client for user targets and wafer keys."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from .api_client import get_api_url
from .auth import get_auth_headers


def _get_client() -> tuple[str, dict[str, str]]:
    api_url = get_api_url()
    headers = get_auth_headers()
    if not api_url or not api_url.startswith("http"):
        raise RuntimeError("API URL must be configured. Run: wafer settings login")
    if not headers:
        raise RuntimeError("Not authenticated. Run: wafer settings login")
    return api_url, headers


def list_targets(scope: str | None = None) -> list[dict[str, Any]]:
    """List user targets from API."""
    api_url, headers = _get_client()
    params = {}
    if scope:
        params["scope"] = scope
    resp = httpx.get(
        f"{api_url}/v1/user-targets",
        headers=headers,
        params=params or None,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def get_target_by_name(name: str) -> dict[str, Any] | None:
    """Get target by name. Returns None if not found."""
    targets = list_targets()
    for t in targets:
        if t.get("name") == name:
            return t
    return None


def get_target_by_id(target_id: str) -> dict[str, Any]:
    """Get target by ID."""
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/user-targets/{target_id}",
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def create_target(
    name: str,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int = 22,
    scope: str = "local",
    ssh_key_path: str | None = None,
    gpu_type: str | None = None,
    gpu_ids: list[int] | None = None,
) -> dict[str, Any]:
    """Create target. Returns CreateTargetResponse with target and optional key info."""
    api_url, headers = _get_client()
    body: dict[str, Any] = {
        "name": name,
        "ssh_host": ssh_host,
        "ssh_port": ssh_port,
        "ssh_user": ssh_user,
        "scope": scope,
    }
    if scope == "local":
        if not ssh_key_path:
            raise ValueError("ssh_key_path required for local scope")
        body["ssh_key_path"] = ssh_key_path
    else:
        body["ssh_key_path"] = None
    if gpu_type:
        body["gpu_type"] = gpu_type
    if gpu_ids is not None:
        body["gpu_ids"] = gpu_ids

    resp = httpx.post(
        f"{api_url}/v1/user-targets",
        headers=headers,
        json=body,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def enable_cloud(name: str) -> dict[str, Any]:
    """Upgrade target to cloud scope. Returns target + key info."""
    target = get_target_by_name(name)
    if not target:
        raise ValueError(f"Target '{name}' not found")
    api_url, headers = _get_client()
    resp = httpx.post(
        f"{api_url}/v1/user-targets/{target['id']}/enable-cloud",
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def delete_target(name: str) -> None:
    """Delete target by name."""
    target = get_target_by_name(name)
    if not target:
        raise ValueError(f"Target '{name}' not found")
    api_url, headers = _get_client()
    resp = httpx.delete(
        f"{api_url}/v1/user-targets/{target['id']}",
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()


def verify_target(name: str, from_cloud: bool = False) -> dict[str, Any]:
    """Verify target connectivity."""
    target = get_target_by_name(name)
    if not target:
        raise ValueError(f"Target '{name}' not found")
    api_url, headers = _get_client()
    params = {"from-cloud": str(from_cloud).lower()}
    resp = httpx.post(
        f"{api_url}/v1/user-targets/{target['id']}/verify",
        headers=headers,
        params=params,
        timeout=120 if from_cloud else 30,
    )
    resp.raise_for_status()
    return resp.json()


def list_wafer_keys() -> list[dict[str, Any]]:
    """List Wafer-managed SSH keys."""
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/wafer-keys",
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def generate_wafer_key(name: str) -> dict[str, Any]:
    """Generate a Wafer SSH keypair. Returns key with private_key (one-time)."""
    api_url, headers = _get_client()
    resp = httpx.post(
        f"{api_url}/v1/wafer-keys/generate",
        headers=headers,
        json={"name": name},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def delete_wafer_key(key_id: str) -> None:
    """Delete a Wafer key by ID."""
    api_url, headers = _get_client()
    resp = httpx.delete(
        f"{api_url}/v1/wafer-keys/{key_id}",
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()


_COMPUTE_CAPS: dict[str, str] = {
    "B200": "10.0", "H100": "9.0", "A100": "8.0", "A10": "8.6",
    "V100": "7.0", "MI300X": "9.4", "MI250X": "9.0", "MI100": "8.0",
    "MI350X": "9.4",
    "RTX 5090": "10.0", "RTX 4090": "8.9", "RTX 3090": "8.6",
    "AMD Instinct MI300X": "9.4", "AMD Instinct MI250X": "9.0",
    "AMD Instinct MI100": "8.0", "AMD Instinct MI350X": "9.4",
}


def user_target_to_baremetal_target(t: dict[str, Any]) -> "BaremetalTarget":
    """Convert user target API response to BaremetalTarget for SSH operations."""
    from wafer.core.utils.kernel_utils.targets.config import BaremetalTarget

    name = t["name"]
    scope = t.get("scope", "local")
    if scope == "local":
        key_path = t.get("ssh_key_path")
        if not key_path:
            raise ValueError(f"Target '{name}' (local scope) has no ssh_key_path")
    else:
        key_path = str(Path.home() / ".wafer" / "keys" / name)
    ssh_target = f"{t['ssh_user']}@{t['ssh_host']}:{t['ssh_port']}"
    gpu_ids = t.get("gpu_ids") or [0]
    if isinstance(gpu_ids, list) and len(gpu_ids) == 0:
        gpu_ids = [0]
    gpu_type = t.get("gpu_type") or "B200"
    gpu_upper = gpu_type.upper()
    if "TRAINIUM" in gpu_upper or "TRN1" in gpu_upper or "TRN2" in gpu_upper or "TRN3" in gpu_upper:
        compute_capability = "0.0"
        vendor = "trainium"
    elif "TPU" in gpu_upper:
        compute_capability = "0.0"
        vendor = "tpu"
    else:
        compute_capability = _COMPUTE_CAPS.get(gpu_type, "8.0")
        vendor = (
            "amd"
            if (gpu_upper.startswith("MI") or "INSTINCT" in gpu_upper)
            else "nvidia"
        )
    ncu_available = vendor == "nvidia"
    return BaremetalTarget(
        name=name,
        ssh_target=ssh_target,
        ssh_key=key_path,
        gpu_ids=gpu_ids,
        gpu_type=gpu_type,
        compute_capability=compute_capability,
        vendor=vendor,
        ncu_available=ncu_available,
    )
