# wafer-ai

Unified Wafer package containing:

- `wafer.cli` – CLI commands and templates
- `wafer.core` – SDK, tools, environments, and rollouts
- `wafer.lsp` – language server implementation

Install locally from the monorepo:

```bash
uv pip install -e packages/wafer-ai
```
