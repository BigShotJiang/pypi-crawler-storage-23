"""Version information for Copilot Dashboard."""

__version__ = "0.4.1"
__repository__ = "https://github.com/JeffSteinbok/ghcpCliDashboard"
