# PyTracerLab
PyTracerLab is an open-source Python package and graphical user interface (GUI) for the analysis of groundwater residence time distributions using lumped parameter models.

::::{grid} 2
:::{grid-item-card}  User Guide
:link: userguide/usage
:link-type: doc

User guide on installation, usage, and the basic concepts of PyTracerLab.
:::
:::{grid-item-card}  Examples
:link: examples/example_01
:link-type: doc

Examples of PyTracerLab in action.
:::
::::

::::{grid} 2
:::{grid-item-card}  Code Reference
:link: api/modules
:link-type: doc

PyTracerLab code reference.
:::
:::{grid-item-card}  Development
:link: development/devguide
:link-type: doc

PyTracerLab development guide.
:::
::::

This webpage provides the package documentation, user guides, and examples. The package is hosted on [GitHub](https://github.com/iGW-TU-Dresden/PyTracerLab), where you can also find the executable that contains the GUI. The package can also be found on [PyPI](https://pypi.org/project/PyTracerLab/). To install the Python package, simply

`pip install PyTracerLab`

To use the GUI, the Python package does not need to be installed. You can simply download and use the latest version from [GitHub](https://github.com/iGW-TU-Dresden/PyTracerLab/releases) (look for the PyTracerLab-vX.X.X.exe in any release).

```{toctree}
:maxdepth: 4
:caption: Guides
:hidden:

userguide/index
examples/index
development/index
```

```{toctree}
:maxdepth: 4
:caption: Code Reference
:hidden:

api/modules
```
