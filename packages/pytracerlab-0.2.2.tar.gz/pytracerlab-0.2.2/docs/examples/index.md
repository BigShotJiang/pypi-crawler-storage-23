# Examples

```{toctree}
:maxdepth: 2
:caption: Examples
:hidden:

example_01
example_02
example_03
example_04
example_05
example_06
```
