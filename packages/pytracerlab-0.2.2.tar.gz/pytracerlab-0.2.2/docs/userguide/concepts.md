# Concepts

PyTracerLab uses the convolution integral as a central concept.
