PyTracerLab package
===================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   PyTracerLab.gui
   PyTracerLab.model

Module contents
---------------

.. automodule:: PyTracerLab
   :members:
   :show-inheritance:
   :undoc-members:
