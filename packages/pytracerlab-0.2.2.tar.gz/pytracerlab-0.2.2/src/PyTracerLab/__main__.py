"""Console entry point for launching the PyTracerLab GUI."""

# from PyTracerLab.app import main
from PyTracerLab.gui.app import main

if __name__ == "__main__":
    main()
