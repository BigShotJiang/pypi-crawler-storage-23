"""Base classes for model units."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict

import numpy as np
from scipy import integrate


class Unit(ABC):
    """Abstract base class for a model unit.

    Concrete units represent hydrological transport schemata and must expose
    and accept their **local** parameter values via a mapping. Units are
    intentionally unaware of optimization bounds; those live in the Model's
    parameter registry.

    Notes
    -----
    - Implementations must keep local parameter names *stable* over time so that
      the Model's registry stays consistent.
    - Names should be short (e.g., ``"mtt"``, ``"eta"``).
    """

    @abstractmethod
    def param_values(self) -> Dict[str, float]:
        """Return current local parameter values.

        Returns
        -------
        Dict[str, float]
            Mapping from local parameter name to value.
        """
        raise NotImplementedError

    @abstractmethod
    def set_param_values(self, values: Dict[str, float]) -> None:
        """Set one or more local parameter values.

        Parameters
        ----------
        values : Dict[str, float]
            Mapping from local parameter name to new value. Keys not present
            are ignored.
        """
        raise NotImplementedError

    def get_block(
        self, h: np.ndarray, tau: np.ndarray, dt: float, lambda_: float, prod: bool = False
    ) -> np.ndarray:
        """Get 1-dt block response."""
        # area = float(h.sum() * dt)
        area = integrate.trapezoid(h, dx=dt)
        if not np.isfinite(area) or area <= 0:
            raise ValueError(f"Impulse response has non-positive/invalid area: {area}")
        h /= area

        # decay / production
        if prod:
            h *= 1 - np.exp(-lambda_ * tau)
        else:
            h *= np.exp(-lambda_ * tau)

        step = np.cumsum(h) * dt
        step = integrate.cumulative_trapezoid(h, dx=dt, initial=0)
        block = np.append(step[0], np.subtract(step[1:], step[:-1]))

        return block

    def normalize_response(self, h: np.ndarray, dt: float) -> np.ndarray:
        """Normalize impulse response to unit area for conservation of mass."""
        area = float(h.sum() * dt)
        if not np.isfinite(area) or area <= 0:
            raise ValueError(f"Impulse response has non-positive/invalid area: {area}")
        h /= area

        return h

    @abstractmethod
    def get_impulse_response(self, tau: np.ndarray, dt: float, lambda_: float) -> np.ndarray:
        """Evaluate the unit's impulse response on a time grid.

        Parameters
        ----------
        tau : ndarray
            Non-negative time axis (same spacing as simulation time grid).
        dt : float
            Time step size of the discretization.
        lambda_ : float
            Decay constant (1 / time units of ``tau``).

        Returns
        -------
        ndarray
            Impulse response sampled at ``tau``.
        """
        raise NotImplementedError


@dataclass
class EPMUnit(Unit):
    """Exponential Piston-Flow Model (EPM) unit.

    Parameters
    ----------
    mtt : float
        Mean travel time.
    eta : float
        Ratio of total volume to the exponential reservoir (>= 1). ``eta=1``
        reduces to a pure exponential model; ``eta>1`` adds a piston component.
    PREFIX : str
        Prefix for local parameter names. Helper for GUI.
    PARAMS : List[Dict[str, Any]]
        List of (default) parameter definitions. Helper for GUI.

    Note: The parameter key for the mean travel time (``mtt``) is used in the
    GUI explicitly. The GUI assumes the parameter is given in years and
    internally converts it.
    """

    mtt: float
    eta: float
    PREFIX = "epm"
    # The parameter keys are used explicitly in the GUI! Changing them will lead
    # to the GUI not displaying parameter units properly.
    PARAMS = [
        {"key": "mtt", "label": "Mean Transit Time", "default": 10.0, "bounds": (0.0, 10000.0)},
        {"key": "eta", "label": "Eta", "default": 1.1, "bounds": (1.0, 2.0)},
    ]

    def param_values(self) -> Dict[str, float]:
        """Get parameter values.

        Returns
        -------
        Dict[str, float]
            Mapping from local parameter name to value.
        """
        return {"mtt": float(self.mtt), "eta": float(self.eta)}

    def set_param_values(self, values: Dict[str, float]) -> None:
        """Set one or more local parameter values.

        Parameters
        ----------
        values : Dict[str, float]
            Mapping from local parameter name to new value. Keys not present
            are ignored.
        """
        if "mtt" in values:
            self.mtt = float(values["mtt"])
        if "eta" in values:
            self.eta = float(values["eta"])

    def get_impulse_response(
        self, tau: np.ndarray, dt: float, lambda_: float, prod: bool = False
    ) -> np.ndarray:
        """EPM impulse response with decay.

        The continuous-time EPM response (without decay) is
        ``h(τ) = (η/mtt) * exp(-η τ / mtt + η - 1)`` for
        ``τ >= mtt*(1 - 1/η)`` and ``0`` otherwise. We also apply
        an exponential decay term ``exp(-λ τ)``.

        Parameters
        ----------
        tau : ndarray
            Non-negative time axis (same spacing as simulation time grid).
        dt : float
            Time step size of the discretization.
        lambda_ : float
            Decay constant (1 / time units of ``tau``).
        prod : bool, optional
            If True, calculate production response (used to simulate 3He
            production from 3H decay).

        Returns
        -------
        ndarray
            Impulse response evaluated at ``tau``.
        """
        # check for edge cases
        if self.eta <= 1.0 or self.mtt <= 0.0:
            return np.zeros_like(tau)

        # Note: a non-zero response at h[0] corresponds to a response at the
        # same time step as the forcing. This is usually not what we want, so
        # we need to make sure the first time bin is 0.

        # We don't need to shift the age grid here because we (almost surely)
        # avoid having non-zero response at h[0] anyways for the EPM.

        # base EPM shape
        h_prelim = (self.eta / self.mtt) * np.exp(-self.eta * tau / self.mtt + self.eta - 1.0)
        cutoff = self.mtt * (1.0 - 1.0 / self.eta)
        h = np.where(tau <= cutoff, 0.0, h_prelim)

        # get response for constant-input block of length dt
        h = self.get_block(h, tau, dt, lambda_, prod)

        return h


@dataclass
class ExEPMUnit(Unit):
    """Explicit xponential Piston-Flow Model (EPM) unit.
    This model is essentially the same as the EPMUnit, but the EPM ratio
    (total volume / exponential volume or total area / area receiving
    recharge) is defined via two parameters instead of one aggregated
    parameter. Those two parameters are directly related and can never be
    estimated simultaneously.

    Parameters
    ----------
    mtt : float
        Mean travel time.
    exp_part: float
        Area receiving recharge or exponential volume of the system.
    piston_part: float
        Area not receiving recharge or piston-flow volume of the system.
    PREFIX : str
        Prefix for local parameter names. Helper for GUI.
    PARAMS : List[Dict[str, Any]]
        List of (default) parameter definitions. Helper for GUI.

    Note: The parameter key for the mean travel time (``mtt``) is used in the
    GUI explicitly. The GUI assumes the parameter is given in years and
    internally converts it.
    """

    mtt: float
    exp_part: float
    piston_part: float
    PREFIX = "epm"
    # The parameter keys are used explicitly in the GUI! Changing them will lead
    # to the GUI not displaying parameter units properly.
    PARAMS = [
        {"key": "mtt", "label": "Mean Transit Time", "default": 10.0, "bounds": (0.0, 10000.0)},
        {"key": "exp_part", "label": "Exponential Part", "default": 0.5, "bounds": (0.0, 100.0)},
        {"key": "piston_part", "label": "Piston Part", "default": 1.0, "bounds": (0.0, 100.0)},
    ]

    def param_values(self) -> Dict[str, float]:
        """Get parameter values.

        Returns
        -------
        Dict[str, float]
            Mapping from local parameter name to value.
        """
        return {
            "mtt": float(self.mtt),
            "exp_part": float(self.exp_part),
            "piston_part": float(self.piston_part),
        }

    def set_param_values(self, values: Dict[str, float]) -> None:
        """Set one or more local parameter values.

        Parameters
        ----------
        values : Dict[str, float]
            Mapping from local parameter name to new value. Keys not present
            are ignored.
        """
        if "mtt" in values:
            self.mtt = float(values["mtt"])
        if "exp_part" in values:
            self.exp_part = float(values["exp_part"])
        if "piston_part" in values:
            self.piston_part = float(values["piston_part"])

    def get_impulse_response(
        self, tau: np.ndarray, dt: float, lambda_: float, prod: bool = False
    ) -> np.ndarray:
        """ExEPM impulse response with decay.

        The continuous-time EPM response (without decay) is
        ``h(τ) = (η/mtt) * exp(-η τ / mtt + η - 1)`` for
        ``τ >= mtt*(1 - 1/η)`` and ``0`` otherwise. We also apply
        an exponential decay term ``exp(-λ τ)``.

        Parameters
        ----------
        tau : ndarray
            Non-negative time axis (same spacing as simulation time grid).
        dt : float
            Time step size of the discretization.
        lambda_ : float
            Decay constant (1 / time units of ``tau``).
        prod : bool, optional
            If True, calculate production response (used to simulate 3He
            production from 3H decay).

        Returns
        -------
        ndarray
            Impulse response evaluated at ``tau``.
        """
        # calculate eta
        eta = (self.piston_part / self.exp_part) + 1

        # check for edge cases
        if eta <= 1.0 or self.mtt <= 0.0:
            return np.zeros_like(tau)

        # Note: a non-zero response at h[0] corresponds to a response at the
        # same time step as the forcing. This is usually not what we want, so
        # we need to make sure the first time bin is 0.

        # We don't need to shift the age grid here because we (almost surely)
        # avoid having non-zero response at h[0] anyways for the EPM.

        # base EPM shape
        h_prelim = (eta / self.mtt) * np.exp(-eta * tau / self.mtt + eta - 1.0)
        cutoff = self.mtt * (1.0 - 1.0 / eta)
        h = np.where(tau < cutoff, 0.0, h_prelim)

        # get response for constant-input block of length dt
        h = self.get_block(h, tau, dt, lambda_, prod)

        return h


@dataclass
class DMUnit(Unit):
    """Dispersion Model (DM) unit.

    Parameters
    ----------
    mtt : float
        Mean travel time.
    DP : float
        Dispersion parameter. Represents the inverse of the Peclet number.
        Also represents the ratio of the dispersion coefficient to the
        velocity and outlet / sampling position
    PREFIX : str
        Prefix for local parameter names. Helper for GUI.
    PARAMS : List[Dict[str, Any]]
        List of (default) parameter definitions. Helper for GUI.

    Note: The parameter key for the mean travel time (``mtt``) is used in the
    GUI explicitly. The GUI assumes the parameter is given in years and
    internally converts it.
    """

    mtt: float
    DP: float
    PREFIX = "dm"
    # The parameter keys are used explicitly in the GUI! Changing them will lead
    # to the GUI not displaying parameter units properly.
    PARAMS = [
        {"key": "mtt", "label": "Mean Transit Time", "default": 10.0, "bounds": (1.0, 10000.0)},
        {"key": "DP", "label": "Dispersion Param.", "default": 1.0, "bounds": (0.0001, 10.0)},
    ]

    def param_values(self) -> Dict[str, float]:
        """Get parameter values.

        Returns
        -------
        Dict[str, float]
            Mapping from local parameter name to value.
        """
        return {"mtt": float(self.mtt), "DP": float(self.DP)}

    def set_param_values(self, values: Dict[str, float]) -> None:
        """Set one or more local parameter values.

        Parameters
        ----------
        values : Dict[str, float]
            Mapping from local parameter name to new value. Keys not present
            are ignored.
        """
        if "mtt" in values:
            self.mtt = float(values["mtt"])
        if "DP" in values:
            self.DP = float(values["DP"])

    def get_impulse_response(
        self, tau: np.ndarray, dt: float, lambda_: float, prod: bool = False
    ) -> np.ndarray:
        """DM impulse response with decay.

        The continuous-time DM response (without decay) is
        ``h(τ) = (1/mtt) * 1 / (sqrt(K)) * exp((1 - τ / mtt)^2 / K)`` with
        ``K = 4 pi DP (τ / mtt)``. We also apply an exponential decay
        term ``exp(-λ τ)``.

        Parameters
        ----------
        tau : ndarray
            Non-negative time axis (same spacing as simulation time grid).
        dt : float
            Time step size of the discretization.
        lambda_ : float
            Decay constant (1 / time units of ``tau``).
        prod : bool, optional
            If True, calculate production response (used to simulate 3He
            production from 3H decay).

        Returns
        -------
        ndarray
            Impulse response evaluated at ``tau``.
        """
        # Check for edge cases
        if self.DP <= 0.0 or self.mtt <= 0.0:
            return np.zeros_like(tau)

        # Note: a non-zero response at h[0] corresponds to a response at the
        # same time step as the forcing. This is usually not what we want, so
        # we need to make sure the first time bin is 0.

        # The transfer function breaks down as τ tends towards 0
        # We therefore prepare a result array for h and fill it up, starting
        # with the non-zero values
        h = np.zeros_like(tau)

        # Pre-compute terms
        buffer = 1
        a = tau[buffer:] * np.sqrt(4 * np.pi * self.DP * tau[buffer:] / self.mtt)
        b = -((1 - tau[buffer:] / self.mtt) ** 2.0 / (4 * self.DP * tau[buffer:] / self.mtt))

        h[buffer:] = 1 / a * np.exp(b)

        # get response for constant-input block of length dt
        h = self.get_block(h, tau, dt, lambda_, prod)

        return h


@dataclass
class EMUnit(Unit):
    """Exponential Model (EM) unit.

    Parameters
    ----------
    mtt : float
        Mean travel time.
    PREFIX : str
        Prefix for local parameter names. Helper for GUI.
    PARAMS : List[Dict[str, Any]]
        List of (default) parameter definitions. Helper for GUI.

    Note: The parameter key for the mean travel time (``mtt``) is used in the
    GUI explicitly. The GUI assumes the parameter is given in years and
    internally converts it.
    """

    mtt: float
    PREFIX = "em"
    # The parameter keys are used explicitly in the GUI! Changing them will lead
    # to the GUI not displaying parameter units properly.
    PARAMS = [
        {"key": "mtt", "label": "Mean Transit Time", "default": 10.0, "bounds": (0.0, 10000.0)},
    ]

    def param_values(self) -> Dict[str, float]:
        """Get parameter values.

        Returns
        -------
        Dict[str, float]
            Mapping from local parameter name to value.
        """
        return {"mtt": float(self.mtt)}

    def set_param_values(self, values: Dict[str, float]) -> None:
        """Set one or more local parameter values.

        Parameters
        ----------
        values : Dict[str, float]
            Mapping from local parameter name to new value. Keys not present
            are ignored.
        """
        if "mtt" in values:
            self.mtt = float(values["mtt"])

    def get_impulse_response(
        self, tau: np.ndarray, dt: float, lambda_: float, prod: bool = False
    ) -> np.ndarray:
        """EM impulse response with decay.

        The continuous-time EPM response (without decay) is
        ``h(τ) = (1/mtt) * exp(-τ / mtt)``. We also apply an exponential
        decay term ``exp(-λ τ)``.

        Parameters
        ----------
        tau : ndarray
            Non-negative time axis (same spacing as simulation time grid).
        dt : float
            Time step size of the discretization.
        lambda_ : float
            Decay constant (1 / time units of ``tau``).
        prod : bool, optional
            If True, calculate production response (used to simulate 3He
            production from 3H decay).

        Returns
        -------
        ndarray
            Impulse response evaluated at ``tau``.
        """
        # check for edge cases
        if self.mtt <= 0.0:
            return np.zeros_like(tau)

        # Note: a non-zero response at h[0] corresponds to a response at the
        # same time step as the forcing. This is usually not what we want, so
        # we need to make sure the first time bin is 0.

        # Base EM shape
        h = np.zeros_like(tau)
        h = (1 / self.mtt) * np.exp(-tau / self.mtt)

        # get response for constant-input block of length dt
        h = self.get_block(h, tau, dt, lambda_, prod)

        return h


@dataclass
class PMUnit(Unit):
    """Piston-Flow Model (discrete delta at the mean travel time) with decay.

    Parameters
    ----------
    mtt : float
        Mean travel time where all mass is transported as a plug flow.
    PREFIX : str
        Prefix for local parameter names. Helper for GUI.
    PARAMS : List[Dict[str, Any]]
        List of (default) parameter definitions. Helper for GUI.

    Note: The parameter key for the mean travel time (``mtt``) is used in the
    GUI explicitly. The GUI assumes the parameter is given in years and
    internally converts it.
    """

    mtt: float
    PREFIX = "pm"
    # The parameter keys are used explicitly in the GUI! Changing them will lead
    # to the GUI not displaying parameter units properly.
    PARAMS = [
        {"key": "mtt", "label": "Mean Transit Time", "default": 10.0, "bounds": (0.0, 10000.0)},
    ]

    def param_values(self) -> Dict[str, float]:
        """Get parameter values.

        Returns
        -------
        Dict[str, float]
            Mapping from local parameter name to value.
        """
        return {"mtt": float(self.mtt)}

    def set_param_values(self, values: Dict[str, float]) -> None:
        """Set local parameter value.

        Parameters
        ----------
        values : Dict[str, float]
            Mapping from local parameter name to new value. Keys not present
            are ignored.
        """
        if "mtt" in values:
            self.mtt = float(values["mtt"])

    def get_impulse_response(
        self, tau: np.ndarray, dt: float, lambda_: float, prod: bool = False
    ) -> np.ndarray:
        """Discrete delta response on the grid with exponential decay.

        The delta is represented by setting the bin at ``round(mtt/dt)`` to
        ``1/dt`` to preserve unit mass in the discrete sum.

        Parameters
        ----------
        tau : ndarray
            Non-negative time axis (same spacing as simulation time grid).
        dt : float
            Time step size of the discretization.
        lambda_ : float
            Decay constant (1 / time units of ``tau``).
        prod : bool, optional
            If True, calculate production response (used to simulate 3He
            production from 3H decay).

        Returns
        -------
        ndarray
            Impulse response evaluated at ``tau``.
        """
        # Check for edge cases
        if self.mtt <= 0.0:
            return np.zeros_like(tau)

        # Note: a non-zero response at h[0] corresponds to a response at the
        # same time step as the forcing. This is usually not what we want, so
        # we need to make sure the first time bin is 0.

        # We don't need to shift the age grid here because we (almost surely)
        # avoid having non-zero response at h[0] anyways for the PM.

        h = np.zeros_like(tau)
        idx = max(1, int(round(self.mtt / dt)))

        # Mass is already preserved: before radioactive decay, we set a
        # single time bin to 1/dt. Multiplying by dt and dividing by the
        # sum just gives us 1/dt again.
        if 0 <= idx < len(tau):
            h[idx] = 1.0 / dt
            # radioactive/first-order decay/production
            if prod:
                h[idx] *= 1 - np.exp(-lambda_ * self.mtt)
            else:
                h[idx] *= np.exp(-lambda_ * self.mtt)
        return h
