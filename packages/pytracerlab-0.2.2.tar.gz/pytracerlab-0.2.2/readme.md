[![image](https://img.shields.io/pypi/v/PyTracerLab.svg)](https://pypi.python.org/pypi/PyTracerLab)
[![image](https://img.shields.io/pypi/l/PyTracerLab.svg)](https://mit-license.org/)
[![image](https://img.shields.io/pypi/pyversions/PyTracerLab)](https://pypi.python.org/pypi/PyTracerLab)


[![CI](https://github.com/iGW-TU-Dresden/PyTracerLab/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/iGW-TU-Dresden/PyTracerLab/actions/workflows/ci.yml)
[![Docs](https://github.com/iGW-TU-Dresden/PyTracerLab/actions/workflows/docs.yml/badge.svg?branch=main)](https://github.com/iGW-TU-Dresden/PyTracerLab/actions/workflows/docs.yml)
[![Release](https://github.com/iGW-TU-Dresden/PyTracerLab/actions/workflows/release.yml/badge.svg)](https://github.com/iGW-TU-Dresden/PyTracerLab/actions/workflows/release.yml)

<img src="https://github.com/iGW-TU-Dresden/PyTracerLab/blob/main/logo.png" width="400">

# PyTracerLab

Lumped parameter groundwater age simulations with a simple user interface - in Python.

PyTracerLab is an open-source framework for the analysis of groundwater residence time distributions with lumped parameter models. PyTracerLab is not only usable as a Python package but is also released as standalone application with a graphical user interface (GUI). The GUI closes the gap in accessibility between complex Python-based workflows and practical applications outside Python.

## Installing PyTracerLab

The package can be found on [PyPI](https://pypi.org/project/PyTracerLab/). To install the Python package, simply use

`pip install PyTracerLab`

To use the GUI, the Python package does not need to be installed. You can simply download and use the latest version from [the releases on GitHub](https://github.com/iGW-TU-Dresden/PyTracerLab/releases) (look for the PyTracerLab-vX.X.X.exe in any release).
