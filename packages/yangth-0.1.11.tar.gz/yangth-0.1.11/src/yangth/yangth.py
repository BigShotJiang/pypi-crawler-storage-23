from sqlalchemy import create_engine, text
import pandas as pd
import time
import threading
from functools import wraps
from openai import OpenAI
from typing import Optional
import tushare as ts
import logging
import warnings
logging.getLogger("httpx").setLevel(logging.WARNING)
warnings.filterwarnings("ignore")

def rate_limit(period_attr_name='_period'):
    """优化的限流装饰器，支持动态获取period"""
    def decorator(func):
        last_called = 0.0
        lock = threading.Lock()
        
        @wraps(func)
        def wrapper(self, *args, **kwargs):  # 添加self参数
            nonlocal last_called
            # 动态从实例获取period值
            period = getattr(self, period_attr_name)
            
            with lock:
                elapsed = time.time() - last_called
                if elapsed < period:
                    wait_time = period - elapsed
                    raise RuntimeError(f"操作过于频繁，请等待 {wait_time:.1f} 秒后再试")
                last_called = time.time()
            return func(self, *args, **kwargs)  # 传递self参数
        return wrapper
    return decorator

class yangth:
    MAX_NEWS_LIMIT = 1000
    MAX_SUMMARY_LIMIT = 10
    def __init__(self, token: str = '17612152074'):
        self.token = str(token)
        self._engine = create_engine(
            f'mysql+pymysql://yangthpypi:2B6682876669d3b46635ed65dfe7ef89@'
            f'rm-uf6frg8f8628ip3fieo.mysql.rds.aliyuncs.com:3306/stk?charset=utf8')
        self._api_key = self._load_api_key()
        self._period = self._load_period()
        self._ts_key=self._load_ts_key()
        self.mod_dict={'doubao2.0mini':'doubao-seed-2-0-mini-260215'
                       ,'doubao2.0lite':'doubao-seed-2-0-lite-260215'
                       ,'doubao1.8':'doubao-seed-1-8-251228'}
    
    def _load_api_key(self) -> str:
        try:
            query = text(f"SELECT token FROM yth_usr_log_inf WHERE mob_phe='{self.token}' and sts_flg=1 AND date(now())<=exp_dte AND typ='doubao'")
            df = pd.read_sql(query, con=self._engine)
            return df['token'].iloc[0] if not df.empty else ''
        except Exception:
            raise ValueError("获取服务器数据失败")
            
    def _load_period(self) -> str:
        try:
            query = text(f"SELECT min(vip_flg) as vip_flg FROM yth_usr_log_inf WHERE mob_phe='{self.token}' and sts_flg=1 AND date(now())<=exp_dte AND typ='doubao'")
            df = pd.read_sql(query, con=self._engine)
            if df.empty or pd.isna(df['vip_flg'].iloc[0]):
                return 30
            else:
                return df['vip_flg'].iloc[0]
        except Exception:
            raise ValueError("获取服务器数据失败")
            
    def _load_ts_key(self) -> str:
        try:
            query = text(f"SELECT min(token) as token FROM yth_usr_log_inf WHERE mob_phe='{self.token}' and typ='tushare' and sts_flg=1 AND date(now())<=exp_dte AND typ='doubao'")
            df = pd.read_sql(query, con=self._engine)
            return df['token'].iloc[0] if not df.empty else ''
        except Exception:
            raise ValueError("获取服务器数据失败")
    
    def _validate_limit(self, limit: int, max_limit: int) -> None:
        """验证limit参数"""
        if not isinstance(limit, int) or limit <= 0:
            raise ValueError(f"limit必须是正整数，当前值: {limit}")
        if limit > max_limit:
            raise ValueError(f"limit不能超过{max_limit}")
    
    @rate_limit('_period')
    def get_lst_news(self, limit: int = 1) -> pd.DataFrame:
        """获取最新新闻列表"""
        self._validate_limit(limit, self.MAX_NEWS_LIMIT)
        query = text(f"SELECT * FROM major_news ORDER BY crt_time DESC LIMIT {limit}")
        return pd.read_sql(query, self._engine, params={'limit': limit})
    
    @rate_limit('_period')
    def get_lst_news_summary(self, limit: int = 1, prompt: str = '', mod_typ: str = 'doubao2.0mini') -> str:
        if mod_typ not in self.mod_dict.keys():
            raise ValueError("暂不支持其他大模型或者输入参数有误")
        self._validate_limit(limit, self.MAX_SUMMARY_LIMIT)
        
        # 获取新闻数据
        news_df = self.get_lst_news(limit)
        if news_df.empty:
            return "暂无新闻数据"
        
        # 构建提示词
        content_text = ';'.join(news_df['content'].tolist())
        full_prompt = f"【{content_text}】对于以上新闻{prompt}"
        
        # 调用大模型
        if len(str(self._api_key))==0:
            raise ValueError("输入token不正确，请输入11位有效的token")
        client = OpenAI(base_url="https://ark.cn-beijing.volces.com/api/v3",api_key=self._api_key)
        try:
            response = client.responses.create(
                model=self.mod_dict.get(mod_typ),
                input=[{"role": "user", "content": [{"type": "input_text", "text": full_prompt}]}],
                tools=[{"type": "web_search", "max_keyword": 5}]
            )
            return response.output_text
        except Exception as e:
            if 'Error code: 401' in str(e):
                raise ValueError("豆包大模型资源不足")
            raise ValueError(f"大模型调用失败: {e}")
      
    @rate_limit('_period')
    def wrap_final_response(self, prompt: str = '', mod_typ: str = 'doubao2.0mini') -> str:
        if mod_typ not in self.mod_dict.keys():
            raise ValueError("暂不支持其他大模型或者输入参数有误")
        if len(prompt)==0:
            raise ValueError("输入为空")
        # 调用大模型
        if len(str(self._api_key))==0:
            raise ValueError("输入token不正确，请输入11位有效的token")
        client = OpenAI(base_url="https://ark.cn-beijing.volces.com/api/v3",api_key=self._api_key)
        try:
            response = client.responses.create(
                model=self.mod_dict.get(mod_typ),
                input=[{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
                tools=[{"type": "web_search", "max_keyword": 5}]
            )
            return response.output_text
        except Exception as e:
            if 'Error code: 401' in str(e):
                raise ValueError("豆包大模型资源不足")
            raise ValueError(f"大模型调用失败: {e}")
            
    @rate_limit('_period')
    def get_stk_ts_code(self, prompt: str = '', mod_typ: str = 'doubao2.0mini') -> str:
        if mod_typ not in self.mod_dict.keys():
            raise ValueError("暂不支持其他大模型或者输入参数有误")
        if len(prompt)==0:
            raise ValueError("输入为空")
        full_prompt='【'+prompt+'】以上内容涉及哪些股票，输出这些股票代码'
        # 调用大模型
        if len(str(self._api_key))==0:
            raise ValueError("输入token不正确，请输入11位有效的token")
        client = OpenAI(base_url="https://ark.cn-beijing.volces.com/api/v3",api_key=self._api_key)
        try:
            response = client.responses.create(
                model=self.mod_dict.get(mod_typ),
                input=[{"role": "user", "content": [{"type": "input_text", "text": full_prompt}]}],
                tools=[{"type": "web_search", "max_keyword": 5}]
            )
            contents= response.output_text
            pro = ts.pro_api(self._ts_key)
            df = pro.daily()
            ts_code_list=[]
            for ts_code in df['ts_code'].tolist():
                if ts_code[:6] in contents:
                    ts_code_list.append(ts_code)
            return ts_code_list
        except Exception as e:
            if 'Error code: 401' in str(e):
                raise ValueError("豆包大模型资源不足")
            raise ValueError(f"大模型调用失败: {e}")