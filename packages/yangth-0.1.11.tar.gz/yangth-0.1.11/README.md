yangth 数据库工具包
项目简介

yangth 是一个基于 Python 的数据库操作工具包，专门用于从 MySQL 数据库中快速获取新闻数据。
该工具封装了 SQLAlchemy 和 pandas 的数据库操作，提供了简洁的 API 接口，适合需要快速查询结构化新闻数据的场景。

功能特性

自动连接管理：内置数据库引擎初始化，支持长连接复用
安全查询：参数化查询防止 SQL 注入，自动验证输入参数
数据框返回：直接返回 pandas DataFrame 对象，便于后续数据分析
错误处理：完整的参数类型和值检查机制
安装要求
系统环境
Python 3.9 或更高版本
必需的依赖包见下文

依赖库

sqlalchemy >= 1.4.39
pandas >= 1.4.4
pymysql >= 1.1.2
openai >=1.0
tushare>=1.4.24
安装方法
通过 pip 安装
bash
pip install yangth
手动安装
克隆项目代码：
bash
git clone https://github.com/your-repo/yangth.git

使用方法
初始化连接
python
from yangth import yangth

# 使用令牌初始化（默认置空）
yth = yangth(token='your_custom_token')
获取新闻数据
python
# 获取最新1条新闻
df = yth.get_lst_news(limit=1)
print(df)

# 获取最新10条新闻
df = yth.get_lst_news(limit=10)
print(df.head())
返回数据格式

方法返回包含以下字段的 DataFrame：
id：新闻唯一标识
title：新闻标题
content：新闻内容
crt_time：新闻创建时间
# 获取最新1条新闻，进行大模型分析
yth.get_lst_news_summary(1,'这个条新闻对金融市场有什么影响')
# 获取大模型调用内容
yth.wrap_final_response('最近热点新闻有哪些？')
# 获取输入内容涉及哪些股票的代码
yth.get_stk_ts_code('输入文本'+'，以上涉及哪些股票代码')
return ts_code_list
注意事项
安全警告：当前代码中包含明文数据库凭证，建议使用环境变量或配置文件存储敏感信息
连接限制：频繁调用可能触发数据库连接限制，建议合理设置查询频率
网络要求：需要保证能够访问阿里云 RDS 服务端地址
故障排除
常见错误
TypeError：参数类型错误时抛出，请检查 limit 参数是否为整数
ValueError：参数值错误时抛出，请确保 limit 为正整数
连接错误：检查网络连接和数据库服务状态

获取帮助

如遇问题，请提供以下信息：
Python 版本号
错误完整堆栈跟踪
调用参数值
贡献指南
欢迎提交 Issue 和 Pull Request 来改进项目功能。贡献前请确保：
通过所有现有测试
更新相关文档
遵循 PEP 8 代码规范
许可证
本项目采用 MIT 许可证，详见 LICENSE 文件
更新日志
v0.1.7（2026-02-12）：实现基本新闻查询功能
联系方式：wx17612152074
项目维护者：田晖扬
问题反馈：GitHub Issues

注意：本文档最后更新于 2026年02月12日，如发现内容过期请联系维护者更新