### Simian Free License Agreement

**License Agreement for "Simian Free"**

This License Agreement ("Agreement") is made between the user ("You" or "Licensee") and MonkeyProof Solutions B.V. ("Licensor") for the use of the "Simian Free" software ("Software"). By downloading, installing, or using the Software, You agree to be bound by the terms of this Agreement.

**1. Definitions**

   - **Software**: Refers to the "Simian Free" software, including the Simian GUI, Simian Local, and Simian Builder software packages for Python, MATLAB, and Julia.
   - **Licensor**: Refers to MonkeyProof Solutions B.V., the provider of the Software.
   - **Licensee**: Refers to the individual or entity who has downloaded, installed, or used the Software.
   - **Simian GUI**: Refers to the graphical user interface component of the Software.
   - **Simian Local**: Refers to the local execution environment component of the Software.
   - **Simian Builder**: Refers to the application building component of the Software.
   - **Simian Portal**: Refers to the commercial Simian offering required for the deployment or hosting of Simian applications.
   - **Simian Wrapper**: Refers to a separate commercial Simian offering that facilitates reproducible research and operation, and is not included in the Software.
   - **End-user Machine**: Refers to a computing device (physical or virtual) that operates independently and is not accessed or utilized remotely through web services, remote desktop, or similar means by other users or machines. It may be part of a computer network but is primarily used by an individual user for local computing tasks.
   - **Server**: Refers to any physical or virtual machine or device that provides services, functionality, or resources to other machines or devices over a network.
   - **Development**: Refers to the process of creating, testing, and modifying applications using the Software.
   - **Use/Usage**: Refers to Development and running of applications built with the Software.
   - **Hosting/Host** Refers to storing of software applications on a Server, allowing access to and running of such software solution or application by other users, machines, or services through the network or internet.
   - **Third-party libraries**: Refers to external software components or libraries utilized by the Software.
   - **Software Documentation**: Refers to all documentation, in any form, in any way related to the Software.
   - **Simian Website**: Refers to https://simiansuite.com/

**2. Grant of License**

Licensor grants You a non-exclusive, non-transferable, limited license to Use the Software on your End-user Machine(s) under the following conditions:
   - Simian GUI and Simian Builder may only be Used in combination with Simian Local.
   - The Software is intended for Use solely on a personal or individual End-user Machine.

**3. License Fee**

The Software provided under this Agreement is licensed to You at no charge. The Licensor grants You a royalty-free, non-exclusive, non-transferable license to use the Software in accordance with the terms and conditions of this Agreement. There are no license fees, subscription fees, or any other charges associated with the use of the Software.

The Licensee acknowledges and agrees that while the Software is provided free of charge, this does not imply any warranty, support, or maintenance services unless otherwise specified in this Agreement or an additional support agreement. Any such services, if provided, may be subject to separate terms and conditions and may incur additional charges.

**4. Restrictions**

You agree to the following restrictions:
   - You may not Host software applications that incorporate the Software in part or as a whole, other than by using Simian Portal. 
   - You may not distribute, sublicense, rent, lease, or sell the Software.
   - You may not reverse engineer, decompile, or disassemble the Software, except to the extent expressly permitted by applicable law.
   - You may not alter, remove or obscure any copyright, trade secret, patent, trademark, logo, proprietary and/or other notices or license files included with or in the Software. 
   - You may not use the Software in any manner that violates any applicable laws or regulations.

**5. Third-Party Libraries**

The Software may include Third-party Software that are subject to separate license agreements. Your use of the Software is subject to the terms and conditions of all applicable third-party licenses. You are solely responsible for complying with the terms of such third-party licenses. Attempting to isolate or separate third-party software from the Software may constitute a violation of third-party licenses and is not permitted.

**6. User Responsibilities**

You are responsible for maintaining the security of your systems, including but not limited to the end-user machines and any applications built with the Software. Additionally, you must ensure compliance with all applicable laws and regulations while using the Software.

**7. Documentation**

Any documentation provided with the Software is for personal use only and may not be self-hosted or redistributed. Access to official documentation must be through the channels provided by Licensor.

**8. Ownership**

The Software is licensed, not sold. Licensor retains all rights, title, and interest in and to the Software and Software Documentation, including all intellectual property rights. No rights are granted to You other than as expressly set forth in this Agreement.

**9. Licensee's Intellectual Property Rights (IPR)**

Licensee retains ownership of the Intellectual Property Rights (IPR) to any work created by Licensee that builds upon or extends the functionality of the Software ("Licensee's Work"). Licensee is not obliged to share Licensee's Work with Licensor. However, unless explicitly agreed otherwise in writing between Licensor and Licensee, if Licensee's Work is shared with Licensor or made publicly available in any way, Licensee grants Licensor a non-exclusive, perpetual, irrevocable, royalty-free license to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display Licensee's Work for any purpose related to the Software. Licensor's rights to independently develop new functionality or features for the Software are not restricted by Licensee's Work.

**10. Termination**

This Agreement is effective until terminated. Your rights under this Agreement will terminate automatically without notice if You fail to comply with any term(s) of this Agreement. Upon termination, You must cease all use of the Software and destroy all copies of the Software in your possession or control.

**11. Export Control**

This License may be subject to export control laws and other import and export laws and regulations. In the exercise of Licensee's rights under this License, Licensee shall not violate any such laws and/or regulations.  Licensee warrants and represents that Licensee is not located in a country subject to an embargo and that Licensee is not included on any list of prohibited or restricted parties.  Any breach of the obligations of Licensee under this article shall be considered a material breach under Article 10. Termination. 

**12. Disclaimer of Warranties**

The Software is provided "as-is" without any warranties of any kind, express or implied. Licensor disclaims all warranties, including but not limited to the implied warranties of merchantability, fitness for a particular purpose, and non-infringement.

**13. Limitation of Liability**

To the maximum extent permitted by law, Licensor shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any damages whatsoever arising out of or related to your use or inability to use the Software.

**14. Support**

Users of "Simian Free" are not eligible for direct support from Licensor. However, You are invited to submit issues and questions through the channels documented on Simian Website.

**15. Amendments**

Licensor reserves the right to make amendments to this Agreement for future versions of the Software. Any amendments will be effective immediately upon posting the updated Agreement on the Licensor's website or through other communication channels.

**16. Severability**

If any provision of this Agreement is found to be invalid or unenforceable, the remaining provisions will remain in full force and effect. Licensor has the right to replace the defective clause or clauses with a clause or clauses that are lawful and enforceable and that capture the intent of the clause or clauses deemed unlawful or unenforceable as closely as possible. 

**17. Jurisdiction**

This Agreement shall be governed by and construed in accordance with the laws of the Netherlands. Any disputes arising out of or in connection with this Agreement shall be submitted to the exclusive jurisdiction of the Court of Breda in the Netherlands. It is acknowledged that Dutch law is interpreted in accordance with the spirit of the law, with consideration given to equitable principles, rather than strictly adhering to the letter of the law as often seen in Anglo-Saxon legal systems.

**18. Entire Agreement**

This Agreement constitutes the entire agreement between You and Licensor regarding the use of the Software and supersedes all prior or contemporaneous understandings regarding such subject matter.

By clicking "Accept" or by downloading, installing, or using the Software, You acknowledge that You have read and understood this Agreement and agree to be bound by its terms.

**MonkeyProof Solutions B.V.**  
Entity Type: Besloten Vennootschap (BV)  
Jurisdiction of Incorporation: The Netherlands  
Chamber of Commerce (KvK) Number: 24434348  
Principal Place of Business: Groot Ypelaardreef 71, 4834 HC, Breda, The Netherlands  
Email: info@monkeyproofsolutions.nl  
Website: https://monkeyproofsolutions.nl/


---

If you have any questions or need further assistance, please contact info@simiansuite.com.
