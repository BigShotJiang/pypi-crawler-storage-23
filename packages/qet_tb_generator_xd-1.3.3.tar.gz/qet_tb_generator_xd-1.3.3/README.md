# QET Terminal Block Generator

[![PyPI version](https://img.shields.io/pypi/v/qet_tb_generator_xd.svg)](https://pypi.org/project/qet_tb_generator_xd/)
[![License: GPL v2](https://img.shields.io/badge/License-GPL%20v2-blue.svg)](LICENSE.txt)

A powerful plugin for **QElectroTech** that automatically generates terminal blocks and connectors for your electrical diagrams.

Refactored with a modern **CustomTkinter** UI for a premium look and feel.

---

## ✨ Features

- **Automatic Generation**: Creates terminal blocks directly into your QET project.
- **Visual Management**: Modern UI to sort, edit, and organize terminals.
- **Bridge Support**: Automatically detects and draws bridges between terminals.
- **Multi-level Support**: Handles multi-level (Etage) terminals (1 to 4 levels).
- **Auto-Fill Colors**: Quick assignment of wire colors (24V, 0V, etc.).
- **Cross-Platform**: Works on Windows, Linux, and macOS.

---

## 🚀 Installation

### Via Pip (Recommended)

The easiest way to install and keep the plugin updated is via [PyPI](https://pypi.org/project/qet-tb-generator-xd/):

```bash
pip install qet_tb_generator_xd
```

### From Source

1. Clone the repository.
2. Install dependencies:
   ```bash
   pip install customtkinter Pillow
   ```
3. Run the application:
   ```bash
   python -m qet_tb_generator_xd
   ```

---

## 📖 How to Use

1. **In QElectroTech**: 
   - Ensure your terminals have a tag like `X1:1` (Block:Terminal).
   `X1:1.1` `X1:1.2` `X1:1.3` for stage terminal
   - Save your project.
2. **Launch the Plugin**:
   - Run the command `qet-tb-generator` in your terminal.
   - Select your `.qet` project file.
3. **In the Plugin**:
   - Organize your terminals (drag & drop or sort buttons).
   - Configure bridges and levels.
   - Click **"Create Terminal Blocks"**.
4. **Back in QET**:
   - Reopen your project.
   - The new terminal blocks will appear in your project's **Collections** tree.

---

## 🛠️ Development & Build

This project uses the modern `pyproject.toml` standard.

### Build the package
To generate distribution files (`.tar.gz` and `.whl`):
```bash
python -m build
```

### Upload to PyPI
```bash
twine upload dist/*
```

---

## 📂 Project Structure

- `src/qet_tb_generator/`: Main package source code.
  - `assets/`: UI images and icons.
  - `main.py`: Modern CustomTkinter interface.
  - `qetproject.py`: QET XML manipulation logic.
  - `terminalblock.py`: Drawing and geometry logic.
- `pyproject.toml`: Modern build configuration.
- `LICENSE.txt`: GNU General Public License v2.0.

---

## 📄 License

This project is licensed under the **GNU General Public License v2.0**. See the [LICENSE.txt](LICENSE.txt) file for details.

Created by **Raul Roda** (raulroda8@gmail.com)  
Refactored by **Xavier Denecheau** (javdenech@gmail.com)
