"""STT backend factory."""

from audio_transcript_mcp.backends.deepgram import DeepgramBackend
from audio_transcript_mcp.backends.whisper import WhisperBackend


def create_backend(backend_type, label, sample_rate, channels, is_float32, buf, config):
    """Create a backend instance based on type string."""
    if backend_type == "local":
        return WhisperBackend(label, sample_rate, channels, is_float32, buf, config)
    else:
        return DeepgramBackend(label, sample_rate, channels, is_float32, buf, config)
