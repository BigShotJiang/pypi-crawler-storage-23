"""Audio format conversion utilities."""

import numpy as np


def float32_to_int16(data: bytes) -> bytes:
    """Convert float32 PCM bytes to int16 PCM bytes."""
    arr = np.frombuffer(data, dtype=np.float32)
    return np.clip(arr * 32767, -32768, 32767).astype(np.int16).tobytes()


def stereo_to_mono_f32(data: bytes, channels: int = 2) -> bytes:
    """Downmix multi-channel float32 to mono by averaging channels."""
    arr = np.frombuffer(data, dtype=np.float32).reshape(-1, channels)
    return arr.mean(axis=1).astype(np.float32).tobytes()
