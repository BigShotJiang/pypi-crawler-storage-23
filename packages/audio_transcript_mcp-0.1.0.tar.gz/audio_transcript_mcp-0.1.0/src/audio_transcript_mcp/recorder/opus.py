"""Stereo Opus streaming recorder using PyOgg."""

import pathlib
import threading

import numpy as np


class StereoOpusRecorder:
    """Collects mono int16@48kHz from two sources into one stereo opus file.

    Left channel = "me" (microphone), Right channel = "others" (system audio).
    Both worker threads call write() concurrently; internal lock keeps it safe.
    """

    FRAME_SAMPLES = 960  # 20ms at 48kHz

    def __init__(self, path: pathlib.Path):
        from pyogg import OggOpusWriter, OpusBufferedEncoder

        enc = OpusBufferedEncoder()
        enc.set_application("audio")
        enc.set_sampling_frequency(48000)
        enc.set_channels(2)
        enc.set_frame_size(20)  # ms

        self._writer = OggOpusWriter(str(path), enc)
        self._bufs = {"me": bytearray(), "others": bytearray()}
        self._lock = threading.Lock()
        self._frame_bytes = self.FRAME_SAMPLES * 2  # int16 = 2 bytes/sample
        self.path = path

    def write(self, label: str, mono_i16: bytes):
        """Append mono int16 PCM to the given channel and flush full frames."""
        with self._lock:
            self._bufs[label].extend(mono_i16)
            # If one channel is >5s ahead, pad the other with silence
            for lbl in self._bufs:
                if lbl != label and len(self._bufs[lbl]) + 48000 * 2 * 5 < len(self._bufs[label]):
                    pad = len(self._bufs[label]) - len(self._bufs[lbl])
                    self._bufs[lbl].extend(b'\x00' * pad)
            self._flush()

    def _flush(self):
        fb = self._frame_bytes
        while len(self._bufs["me"]) >= fb and len(self._bufs["others"]) >= fb:
            left = np.frombuffer(bytes(self._bufs["me"][:fb]), dtype=np.int16)
            right = np.frombuffer(bytes(self._bufs["others"][:fb]), dtype=np.int16)
            del self._bufs["me"][:fb]
            del self._bufs["others"][:fb]
            stereo = np.column_stack([left, right]).astype(np.int16)
            self._writer.write(memoryview(bytearray(stereo.tobytes())))

    def close(self):
        """Flush remaining audio (pad shorter channel) and close the file."""
        with self._lock:
            max_len = max(len(b) for b in self._bufs.values())
            if max_len > 0:
                pad_to = ((max_len + self._frame_bytes - 1) // self._frame_bytes) * self._frame_bytes
                for lbl in self._bufs:
                    if len(self._bufs[lbl]) < pad_to:
                        self._bufs[lbl].extend(b'\x00' * (pad_to - len(self._bufs[lbl])))
                self._flush()
            self._writer.close()
