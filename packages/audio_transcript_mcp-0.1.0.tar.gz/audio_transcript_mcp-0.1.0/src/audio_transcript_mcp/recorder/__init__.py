"""Audio recorder module."""

from audio_transcript_mcp.recorder.opus import StereoOpusRecorder

__all__ = ["StereoOpusRecorder"]
