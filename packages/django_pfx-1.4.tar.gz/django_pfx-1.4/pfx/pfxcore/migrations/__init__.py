from django.db.migrations import *

from .operations import *
