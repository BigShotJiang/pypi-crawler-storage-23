"""
TLM Learner -- Passive learning from git history.

Watches git, analyzes every commit against specs, and injects lessons
into future interviews. No user effort required.

Adapted from MVP's learner.py to work without the Project class,
using direct file path operations and V2's config module.
"""

import json
import subprocess
import datetime
from pathlib import Path

from tlm.knowledge_db import KnowledgeDB
from tlm.config import load_project_config


# --- Git Reader ---

class GitReader:
    """Reads git commit history."""

    def __init__(self, project_root: str = "."):
        self.root = Path(project_root).resolve()

    def _run_git(self, args: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git"] + args,
            capture_output=True, text=True,
            cwd=str(self.root), timeout=timeout,
        )

    def _get_commit_diff(self, commit_hash: str) -> str:
        result = self._run_git(["rev-list", "--parents", "-n", "1", commit_hash])
        parts = result.stdout.strip().split()
        if len(parts) == 1:
            result = self._run_git(["diff", "--root", commit_hash], timeout=60)
        else:
            result = self._run_git(["diff", f"{commit_hash}^..{commit_hash}"], timeout=60)
        return result.stdout

    def _parse_commit_log(self, log_output: str) -> list[dict]:
        commits = []
        for line in log_output.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split("|||")
            if len(parts) != 4:
                continue
            commit = {
                "hash": parts[0].strip(),
                "message": parts[1].strip(),
                "author": parts[2].strip(),
                "date": parts[3].strip(),
            }
            commit["diff"] = self._get_commit_diff(commit["hash"])
            commits.append(commit)
        return commits

    def get_last_commit(self) -> dict | None:
        result = self._run_git(["log", "-1", "--format=%H|||%s|||%an|||%aI"])
        if result.returncode != 0 or not result.stdout.strip():
            return None
        commits = self._parse_commit_log(result.stdout)
        return commits[0] if commits else None

    def get_commits_since(self, since_iso: str) -> list[dict]:
        result = self._run_git([
            "log", f"--since={since_iso}",
            "--format=%H|||%s|||%an|||%aI", "--reverse",
        ])
        if result.returncode != 0 or not result.stdout.strip():
            return []
        return self._parse_commit_log(result.stdout)

    def get_all_commits(self) -> list[dict]:
        result = self._run_git([
            "log", "--format=%H|||%s|||%an|||%aI", "--reverse",
        ])
        if result.returncode != 0 or not result.stdout.strip():
            return []
        return self._parse_commit_log(result.stdout)

    def get_commit_count_since(self, since_iso: str) -> int:
        result = self._run_git(["rev-list", "--count", f"--since={since_iso}", "HEAD"])
        if result.returncode != 0:
            return 0
        try:
            return int(result.stdout.strip())
        except ValueError:
            return 0


# --- Commit Analyzer ---

class CommitAnalyzer:
    """Analyzes commits one by one via TLM server API."""

    def __init__(self, api_client, project_id: str):
        self.api_client = api_client
        self.project_id = project_id

    def analyze_commit(self, commit: dict) -> dict:
        result = self.api_client.analyze_commit(self.project_id, commit)
        return result["analysis"]

    def analyze_batch(self, commits: list[dict], progress_callback=None) -> list[dict]:
        results = []
        for i, commit in enumerate(commits):
            try:
                result = self.analyze_commit(commit)
            except Exception:
                try:
                    result = self.analyze_commit(commit)
                except Exception:
                    result = {
                        "hash": commit.get("hash", ""),
                        "category": "unknown",
                        "planned": False,
                        "matching_spec": None,
                        "summary": commit.get("message", "")[:80],
                        "unplanned_reason": "Analysis failed (timeout or server error)",
                        "lessons": [],
                    }
            results.append(result)
            if progress_callback:
                progress_callback(i + 1, len(commits), commit["hash"][:7], result.get("summary", ""))
        return results


# --- Learning Synthesizer ---

class LearningSynthesizer:
    """Synthesizes patterns from analyzed commits via TLM server API."""

    def __init__(self, api_client, project_id: str):
        self.api_client = api_client
        self.project_id = project_id

    def synthesize(self, analyzed_commits: list[dict]) -> dict:
        result = self.api_client.synthesize(self.project_id, analyzed_commits)
        return result["synthesis"]


# --- Knowledge Updater ---

class KnowledgeUpdater:
    """Updates knowledge base files with lessons from synthesis."""

    def __init__(self, project_root: str):
        self.root = Path(project_root)
        self.tlm_dir = self.root / ".tlm"
        self._db = None

    @property
    def db(self) -> KnowledgeDB:
        if self._db is None:
            self._db = KnowledgeDB(str(self.tlm_dir))
            self._db.init_db()
        return self._db

    def update_from_synthesis(self, synthesis: dict):
        """Write synthesis results to knowledge base and config."""
        period = synthesis.get("period", "unknown")
        total = synthesis.get("total_commits", 0)
        accuracy = synthesis.get("spec_accuracy_percent", 0)

        lines = []
        lines.append(f"### Lessons from commits ({period})")
        lines.append(f"_{total} commits analyzed, {accuracy}% spec accuracy_\n")

        bug_patterns = synthesis.get("bug_patterns", [])
        if bug_patterns:
            lines.append("**Bug patterns:**")
            for bp in bug_patterns:
                lines.append(f"- {bp.get('pattern', '?')} ({bp.get('frequency', '?')}x, {bp.get('severity', '?')}): {bp.get('lesson', '')}")

        unplanned = synthesis.get("unplanned_features", [])
        if unplanned:
            lines.append("\n**Unplanned features:**")
            for uf in unplanned:
                lines.append(f"- {uf.get('what', '?')}: {uf.get('lesson', '')}")

        evolutions = synthesis.get("architecture_evolutions", [])
        if evolutions:
            lines.append("\n**Architecture evolutions:**")
            for ae in evolutions:
                lines.append(f"- {ae.get('what', '?')}: {ae.get('lesson', '')}")

        improvements = synthesis.get("interview_improvements", [])
        if improvements:
            lines.append("\n**Interview improvements:**")
            for imp in improvements:
                lines.append(f"- {imp}")

        # Append to knowledge.md
        knowledge_file = self.tlm_dir / "knowledge.md"
        existing = ""
        if knowledge_file.exists():
            existing = knowledge_file.read_text()
        knowledge_file.write_text(existing + "\n\n" + "\n".join(lines))

        # Update config.json
        config = load_project_config(str(self.root))
        if "spec_accuracy_history" not in config:
            config["spec_accuracy_history"] = []
        config["spec_accuracy_history"].append({
            "date": str(datetime.date.today()),
            "accuracy": synthesis.get("spec_accuracy_percent", 0),
            "commits": synthesis.get("total_commits", 0),
        })
        config["total_commits_analyzed"] = (
            config.get("total_commits_analyzed", 0)
            + synthesis.get("total_commits", 0)
        )
        config["last_learning_at"] = datetime.datetime.now().isoformat()
        config_file = self.tlm_dir / "config.json"
        config_file.write_text(json.dumps(config, indent=2))

        # Save raw synthesis
        lessons_dir = self.tlm_dir / "lessons"
        lessons_dir.mkdir(exist_ok=True)
        synthesis_path = lessons_dir / f"{datetime.date.today()}-synthesis.json"
        synthesis_path.write_text(json.dumps(synthesis, indent=2))

        # Write to knowledge.db
        self._write_to_db(synthesis)

    def _write_to_db(self, synthesis: dict):
        period = synthesis.get("period", "unknown")
        week = period.split(" to ")[0] if " to " in period else period
        self.db.add_metric(
            week_number=week,
            spec_accuracy=synthesis.get("spec_accuracy_percent", 0),
            total_commits=synthesis.get("total_commits", 0),
            planned_commits=synthesis.get("planned_commits", 0),
            unplanned_commits=synthesis.get("unplanned_commits", 0),
        )
        for bp in synthesis.get("bug_patterns", []):
            lesson = bp.get("lesson", "")
            if lesson:
                self.db.add_rule(lesson, source="learned_from_bug",
                                 tags=["bug_pattern", bp.get("severity", "medium")])
            for q in bp.get("interview_questions", []):
                self.db.add_rule(q, source="learned_from_bug", tags=["interview"])
        for uf in synthesis.get("unplanned_features", []):
            for q in uf.get("interview_questions", []):
                self.db.add_rule(q, source="learned_from_unplanned", tags=["interview"])
        for imp in synthesis.get("interview_improvements", []):
            self.db.add_rule(imp, source="learned_from_synthesis", tags=["interview"])


# --- Learner (Orchestrator) ---

class Learner:
    """Main orchestrator for the learning system."""

    def __init__(self, project_root: str, api_client, project_id: str):
        self.root = Path(project_root)
        self.tlm_dir = self.root / ".tlm"
        self.git = GitReader(project_root)
        self.analyzer = CommitAnalyzer(api_client=api_client, project_id=project_id)
        self.synthesizer = LearningSynthesizer(api_client=api_client, project_id=project_id)
        self.updater = KnowledgeUpdater(project_root)

    def learn_last_commit(self) -> dict:
        commit = self.git.get_last_commit()
        if not commit:
            return {"error": "No commits found"}

        result = self.analyzer.analyze_commit(commit)

        commits_dir = self.tlm_dir / "commits"
        commits_dir.mkdir(exist_ok=True)
        commit_file = commits_dir / f"{commit['hash']}.json"
        commit_file.write_text(json.dumps(result, indent=2))

        self.updater.db.add_commit(
            hash=commit["hash"],
            category=result.get("category"),
            patterns_extracted=result.get("lessons", []),
        )

        return result

    def learn_since_last_session(self, progress_callback=None) -> dict:
        config = load_project_config(str(self.root))
        last_session = config.get("last_session_at")

        if not last_session:
            return {"total_commits": 0, "message": "No previous session to learn from."}

        pre_analyzed = self._load_unprocessed_commits()
        if pre_analyzed:
            synthesis = self.synthesizer.synthesize(pre_analyzed)
            self.updater.update_from_synthesis(synthesis)
            self._mark_commits_processed()
            return synthesis

        commits = self.git.get_commits_since(last_session)
        if not commits:
            return {"total_commits": 0, "message": "No new commits since last session."}

        analyzed = self.analyzer.analyze_batch(commits, progress_callback)
        synthesis = self.synthesizer.synthesize(analyzed)
        self.updater.update_from_synthesis(synthesis)
        return synthesis

    def learn_full_history(self, progress_callback=None) -> dict:
        commits = self.git.get_all_commits()
        if not commits:
            return {"total_commits": 0, "message": "No git history found."}

        analyzed = self.analyzer.analyze_batch(commits, progress_callback)
        synthesis = self.synthesizer.synthesize(analyzed)
        self.updater.update_from_synthesis(synthesis)
        return synthesis

    def _load_unprocessed_commits(self) -> list[dict]:
        commits_dir = self.tlm_dir / "commits"
        if not commits_dir.exists():
            return []
        results = []
        for f in sorted(commits_dir.glob("*.json")):
            if f.name.endswith("-processed.json"):
                continue
            try:
                results.append(json.loads(f.read_text()))
            except (json.JSONDecodeError, OSError):
                pass
        return results

    def _mark_commits_processed(self):
        commits_dir = self.tlm_dir / "commits"
        if not commits_dir.exists():
            return
        for f in commits_dir.glob("*.json"):
            if not f.name.endswith("-processed.json"):
                new_name = f.stem + "-processed.json"
                f.rename(f.parent / new_name)
