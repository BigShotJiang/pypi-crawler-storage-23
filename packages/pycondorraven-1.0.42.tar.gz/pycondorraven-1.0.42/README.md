# PyCondor

Investment analytics, asset liability management, machine learning and more.

## Local installation:
run `pip install .` on directory with setup.py, or pip install .whl file.
