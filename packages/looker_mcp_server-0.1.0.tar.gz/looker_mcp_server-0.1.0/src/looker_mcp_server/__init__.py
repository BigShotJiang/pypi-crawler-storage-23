"""Looker MCP Server — Full-featured MCP server for the Looker API."""

__version__ = "0.1.0"
