"""
Functions in support of CLI database creation.

"""

#def dbinit(db,prefix):
#    """
#    Command-line arguments are created and parsed, fed to functions.
#
#    """
#    options = get_options(db,prefix)
#    session = get_session(options)
#    files = get_files(options)
#
#    tables = get_or_create_tables(options, session, create=True)
#
#    lastids = ['arid', 'chanid', 'evid', 'orid', 'wfid']
#    last = get_lastids(session, tables['lastid'], lastids, create=True)   
   
