"""
Functions in support of database conversion.

"""