"""
Functions in support of dropping database tables.

"""
