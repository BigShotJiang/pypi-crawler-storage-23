"""
Subpackage in support of the Pisces command line.

"""