"""
Support for conversion of waveform and metadata formats into database tables.

"""