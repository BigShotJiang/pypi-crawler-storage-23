"""
Concrete canonical tables for quick analysis and testing.

"""