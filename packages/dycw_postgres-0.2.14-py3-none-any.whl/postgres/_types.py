from __future__ import annotations

type RepoNumOrName = str | int


__all__ = ["RepoNumOrName"]
