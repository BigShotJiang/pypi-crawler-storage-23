"""Allow running sentrial as a module: python -m sentrial"""
from .cli import main

if __name__ == "__main__":
    main()
