"""Type definitions for Sentrial SDK"""

from enum import Enum


class EventType(str, Enum):
    """Event types"""

    TOOL_CALL = "tool_call"
    LLM_DECISION = "llm_decision"
    ERROR = "error"
