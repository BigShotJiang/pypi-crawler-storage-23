def hello_myfoo():
    """Returns a simple greeting from the SDK."""
    return "Hello from the My Foo SDK!"

# This ensures that 'hello_myfoo' is easily accessible
__all__ = ["hello_myfoo"]