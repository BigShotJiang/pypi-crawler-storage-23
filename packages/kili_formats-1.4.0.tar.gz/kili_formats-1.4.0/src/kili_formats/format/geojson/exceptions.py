"""GeoJson-related exceptions."""


class ConversionError(Exception):
    """Exception thrown when the an annotation cannot be converted to GeoJson."""
