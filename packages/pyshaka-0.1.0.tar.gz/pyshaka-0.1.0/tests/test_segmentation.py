"""Tests for segmentation / ChunkingConfig (Issue #6)."""

from __future__ import annotations

import pytest

from pyshaka.config import ChunkingConfig, Mp4OutputConfig


class TestChunkingConfig:
    def test_defaults(self):
        config = ChunkingConfig()
        assert config.segment_duration == 4.0
        assert config.subsegment_duration == 0.0
        assert config.segment_sap_aligned is True
        assert config.subsegment_sap_aligned is True
        assert config.start_segment_number == 1
        assert config.low_latency_dash_mode is False

    def test_custom_values(self):
        config = ChunkingConfig(
            segment_duration=6.0,
            subsegment_duration=2.0,
            segment_sap_aligned=False,
            start_segment_number=0,
        )
        assert config.segment_duration == 6.0
        assert config.subsegment_duration == 2.0
        assert config.segment_sap_aligned is False
        assert config.start_segment_number == 0

    def test_low_latency_mode(self):
        config = ChunkingConfig(
            segment_duration=2.0,
            low_latency_dash_mode=True,
        )
        assert config.low_latency_dash_mode is True

    def test_validate_positive_duration(self):
        config = ChunkingConfig(segment_duration=4.0, subsegment_duration=2.0)
        config.validate()  # should not raise

    def test_validate_negative_duration(self):
        config = ChunkingConfig(segment_duration=-1.0)
        with pytest.raises(ValueError, match="segment_duration.*positive"):
            config.validate()

    def test_validate_zero_duration(self):
        config = ChunkingConfig(segment_duration=0.0)
        with pytest.raises(ValueError, match="segment_duration.*positive"):
            config.validate()

    def test_validate_negative_subsegment(self):
        config = ChunkingConfig(subsegment_duration=-1.0)
        with pytest.raises(ValueError, match="subsegment_duration.*non-negative"):
            config.validate()

    def test_validate_subsegment_exceeds_segment(self):
        config = ChunkingConfig(segment_duration=4.0, subsegment_duration=8.0)
        with pytest.raises(ValueError, match="subsegment_duration.*exceed"):
            config.validate()

    def test_validate_subsegment_equals_segment(self):
        config = ChunkingConfig(segment_duration=4.0, subsegment_duration=4.0)
        config.validate()  # should not raise

    def test_validate_negative_start_segment(self):
        config = ChunkingConfig(start_segment_number=-1)
        with pytest.raises(ValueError, match="start_segment_number"):
            config.validate()

    def test_validate_zero_start_segment(self):
        config = ChunkingConfig(start_segment_number=0)
        config.validate()  # should not raise

    def test_frozen(self):
        config = ChunkingConfig()
        with pytest.raises(AttributeError):
            config.segment_duration = 10.0  # type: ignore[misc]

    def test_common_durations(self):
        """Test commonly used segment durations."""
        for duration in [2.0, 4.0, 6.0, 10.0]:
            config = ChunkingConfig(segment_duration=duration)
            config.validate()


class TestMp4OutputConfig:
    def test_defaults(self):
        config = Mp4OutputConfig()
        assert config.include_pssh_in_stream is True
        assert config.generate_sidx_in_media_segments is True
        assert config.low_latency_dash_mode is False

    def test_no_pssh(self):
        config = Mp4OutputConfig(include_pssh_in_stream=False)
        assert config.include_pssh_in_stream is False

    def test_no_sidx(self):
        config = Mp4OutputConfig(generate_sidx_in_media_segments=False)
        assert config.generate_sidx_in_media_segments is False

    def test_low_latency(self):
        config = Mp4OutputConfig(low_latency_dash_mode=True)
        assert config.low_latency_dash_mode is True

    def test_frozen(self):
        config = Mp4OutputConfig()
        with pytest.raises(AttributeError):
            config.include_pssh_in_stream = False  # type: ignore[misc]
