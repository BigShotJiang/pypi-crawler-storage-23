"""Tests for configuration dataclasses and validation."""

from __future__ import annotations

import pytest

from pyshaka.config import (
    AdCueConfig,
    ChunkingConfig,
    CuePoint,
    DashConfig,
    DecryptionConfig,
    EncryptionConfig,
    HlsConfig,
    HlsPlaylistType,
    KeyInfo,
    KeyProvider,
    Mp4OutputConfig,
    PackagingConfig,
    ProtectionScheme,
    ProtectionSystem,
    StreamConfig,
    TextStreamConfig,
    UtcTimingConfig,
)


class TestProtectionScheme:
    def test_values(self):
        assert ProtectionScheme.CENC.value == "cenc"
        assert ProtectionScheme.CBCS.value == "cbcs"
        assert ProtectionScheme.CENS.value == "cens"
        assert ProtectionScheme.CBC1.value == "cbc1"

    def test_from_string(self):
        assert ProtectionScheme("cbcs") == ProtectionScheme.CBCS
        assert ProtectionScheme("cenc") == ProtectionScheme.CENC


class TestKeyProvider:
    def test_values(self):
        assert KeyProvider.RAW.value == "raw"
        assert KeyProvider.WIDEVINE.value == "widevine"
        assert KeyProvider.PLAYREADY.value == "playready"
        assert KeyProvider.CPIX.value == "cpix"


class TestProtectionSystem:
    def test_individual_values(self):
        assert ProtectionSystem.COMMON == 0x01
        assert ProtectionSystem.WIDEVINE == 0x02
        assert ProtectionSystem.PLAYREADY == 0x04
        assert ProtectionSystem.FAIRPLAY == 0x08
        assert ProtectionSystem.MARLIN == 0x10

    def test_bitwise_or(self):
        combined = ProtectionSystem.WIDEVINE | ProtectionSystem.PLAYREADY
        assert combined & ProtectionSystem.WIDEVINE
        assert combined & ProtectionSystem.PLAYREADY
        assert not (combined & ProtectionSystem.FAIRPLAY)

    def test_multi_system(self):
        all_drm = ProtectionSystem.WIDEVINE | ProtectionSystem.PLAYREADY | ProtectionSystem.FAIRPLAY
        assert all_drm & ProtectionSystem.WIDEVINE
        assert all_drm & ProtectionSystem.PLAYREADY
        assert all_drm & ProtectionSystem.FAIRPLAY


class TestHlsPlaylistType:
    def test_values(self):
        assert HlsPlaylistType.VOD.value == "vod"
        assert HlsPlaylistType.EVENT.value == "event"
        assert HlsPlaylistType.LIVE.value == "live"


class TestKeyInfo:
    def test_defaults(self):
        ki = KeyInfo()
        assert ki.key_id == ""
        assert ki.key == ""
        assert ki.iv is None

    def test_with_values(self):
        ki = KeyInfo(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            iv="aaaabbbbccccddddeeeeffffgggghhhh",
        )
        assert ki.key_id == "00112233445566778899aabbccddeeff"


class TestEncryptionConfig:
    def test_default_values(self):
        config = EncryptionConfig()
        assert config.protection_scheme == ProtectionScheme.CBCS
        assert config.key_provider == KeyProvider.RAW
        assert config.key_id is None
        assert config.key is None
        assert config.iv is None
        assert config.clear_lead == 0.0
        assert config.protection_systems == ProtectionSystem.COMMON
        assert config.crypt_byte_block == 0
        assert config.skip_byte_block == 0

    def test_frozen(self):
        config = EncryptionConfig()
        with pytest.raises(AttributeError):
            config.key_id = "test"  # type: ignore[misc]

    def test_validate_raw_key_valid(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        config.validate()  # should not raise

    def test_validate_raw_key_missing_key(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
        )
        with pytest.raises(ValueError, match="key_id.*key"):
            config.validate()

    def test_validate_raw_key_missing_key_id(self):
        config = EncryptionConfig(
            key="ffeeddccbbaa99887766554433221100",
        )
        with pytest.raises(ValueError, match="key_id.*key"):
            config.validate()

    def test_validate_raw_key_wrong_length(self):
        config = EncryptionConfig(
            key_id="0011223344",
            key="ffeeddccbbaa99887766554433221100",
        )
        with pytest.raises(ValueError, match="32-character"):
            config.validate()

    def test_validate_raw_iv_wrong_length(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            iv="short",
        )
        with pytest.raises(ValueError, match="iv.*32-character"):
            config.validate()

    def test_validate_multi_key(self):
        config = EncryptionConfig(
            key_map={
                "SD": KeyInfo(
                    "00112233445566778899aabbccddeeff",
                    "ffeeddccbbaa99887766554433221100",
                ),
                "HD": KeyInfo(
                    "aabbccddeeff00112233445566778899",
                    "99887766554433221100aabbccddeeff",
                ),
            },
        )
        config.validate()

    def test_validate_multi_key_invalid(self):
        config = EncryptionConfig(
            key_map={
                "SD": KeyInfo("short", "ffeeddccbbaa99887766554433221100"),
            },
        )
        with pytest.raises(ValueError, match="key_map"):
            config.validate()

    def test_validate_widevine_valid(self):
        config = EncryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            widevine_key_server_url="https://example.com/keys",
            signer="test-signer",
            signing_key="00112233445566778899aabbccddeeff",
        )
        config.validate()  # should not raise

    def test_validate_widevine_missing_url(self):
        config = EncryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            signer="test-signer",
            signing_key="key",
        )
        with pytest.raises(ValueError, match="widevine_key_server_url"):
            config.validate()

    def test_validate_widevine_missing_signer(self):
        config = EncryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            widevine_key_server_url="https://example.com/keys",
        )
        with pytest.raises(ValueError, match="signer"):
            config.validate()

    def test_validate_cpix_valid(self):
        config = EncryptionConfig(
            key_provider=KeyProvider.CPIX,
            cpix_server_url="https://cpix.example.com/v2/keys",
        )
        config.validate()  # should not raise

    def test_validate_cpix_missing_url(self):
        config = EncryptionConfig(
            key_provider=KeyProvider.CPIX,
        )
        with pytest.raises(ValueError, match="cpix_server_url"):
            config.validate()

    def test_protection_systems_flag(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            protection_systems=ProtectionSystem.WIDEVINE | ProtectionSystem.PLAYREADY,
        )
        config.validate()
        assert config.protection_systems & ProtectionSystem.WIDEVINE

    def test_pattern_encryption(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            crypt_byte_block=1,
            skip_byte_block=9,
        )
        config.validate()
        assert config.crypt_byte_block == 1
        assert config.skip_byte_block == 9


class TestDecryptionConfig:
    def test_defaults(self):
        config = DecryptionConfig()
        assert config.key_provider == KeyProvider.RAW
        assert config.key_id is None
        assert config.key is None

    def test_validate_raw_valid(self):
        config = DecryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        config.validate()

    def test_validate_raw_missing(self):
        config = DecryptionConfig()
        with pytest.raises(ValueError, match="key_id.*key"):
            config.validate()

    def test_validate_widevine(self):
        config = DecryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            widevine_key_server_url="https://example.com",
        )
        config.validate()

    def test_validate_widevine_missing_url(self):
        config = DecryptionConfig(key_provider=KeyProvider.WIDEVINE)
        with pytest.raises(ValueError, match="widevine_key_server_url"):
            config.validate()


class TestStreamConfig:
    def test_default(self):
        config = StreamConfig()
        assert config.stream_type == "video"
        assert config.language is None

    def test_audio_with_language(self):
        config = StreamConfig(stream_type="audio", language="en")
        assert config.stream_type == "audio"
        assert config.language == "en"

    def test_invalid_stream_type(self):
        with pytest.raises(ValueError, match="stream_type"):
            StreamConfig(stream_type="subtitle")

    def test_all_valid_types(self):
        for t in ("video", "audio", "text"):
            config = StreamConfig(stream_type=t)
            assert config.stream_type == t

    def test_extended_fields(self):
        config = StreamConfig(
            stream_type="video",
            trick_play_factor=2,
            bandwidth=5000000,
            skip_encryption=True,
            drm_label="HD",
        )
        assert config.trick_play_factor == 2
        assert config.bandwidth == 5000000
        assert config.skip_encryption is True
        assert config.drm_label == "HD"

    def test_hls_fields(self):
        config = StreamConfig(
            stream_type="audio",
            language="en",
            hls_name="English",
            hls_group_id="audio",
            hls_playlist_name="audio_en.m3u8",
        )
        assert config.hls_name == "English"
        assert config.hls_group_id == "audio"

    def test_dash_fields(self):
        config = StreamConfig(
            stream_type="audio",
            language="en",
            dash_roles="main",
            dash_label="English",
        )
        assert config.dash_roles == "main"
        assert config.dash_label == "English"


class TestTextStreamConfig:
    def test_defaults(self):
        config = TextStreamConfig()
        assert config.stream_type == "text"
        assert config.language == "en"
        assert config.output_format == "vtt+mp4"

    def test_ttml(self):
        config = TextStreamConfig(language="pt-BR", output_format="ttml+mp4")
        assert config.stream_type == "text"
        assert config.language == "pt-BR"
        assert config.output_format == "ttml+mp4"

    def test_with_hls(self):
        config = TextStreamConfig(
            language="en",
            hls_playlist_name="subs_en.m3u8",
            hls_characteristics="public.accessibility.transcribes-spoken-dialog",
        )
        assert config.hls_playlist_name == "subs_en.m3u8"


class TestChunkingConfig:
    def test_defaults(self):
        config = ChunkingConfig()
        assert config.segment_duration == 4.0
        assert config.subsegment_duration == 0.0
        assert config.segment_sap_aligned is True
        assert config.start_segment_number == 1
        assert config.low_latency_dash_mode is False

    def test_validate_valid(self):
        config = ChunkingConfig(segment_duration=6.0, subsegment_duration=2.0)
        config.validate()

    def test_validate_negative_duration(self):
        config = ChunkingConfig(segment_duration=-1.0)
        with pytest.raises(ValueError, match="segment_duration.*positive"):
            config.validate()

    def test_validate_subsegment_exceeds(self):
        config = ChunkingConfig(segment_duration=4.0, subsegment_duration=8.0)
        with pytest.raises(ValueError, match="subsegment_duration.*exceed"):
            config.validate()

    def test_validate_negative_start_segment(self):
        config = ChunkingConfig(start_segment_number=-1)
        with pytest.raises(ValueError, match="start_segment_number"):
            config.validate()


class TestMp4OutputConfig:
    def test_defaults(self):
        config = Mp4OutputConfig()
        assert config.include_pssh_in_stream is True
        assert config.generate_sidx_in_media_segments is True
        assert config.low_latency_dash_mode is False


class TestDashConfig:
    def test_defaults(self):
        config = DashConfig()
        assert config.mpd_output == ""
        assert config.min_buffer_time == 2.0
        assert config.generate_dash_if_iop_compliant_mpd is True

    def test_validate_valid(self):
        config = DashConfig(
            mpd_output="output.mpd",
            min_buffer_time=5.0,
            time_shift_buffer_depth=60.0,
        )
        config.validate()

    def test_validate_negative_buffer(self):
        config = DashConfig(min_buffer_time=-1.0)
        with pytest.raises(ValueError, match="min_buffer_time"):
            config.validate()

    def test_validate_negative_time_shift(self):
        config = DashConfig(time_shift_buffer_depth=-1.0)
        with pytest.raises(ValueError, match="time_shift_buffer_depth"):
            config.validate()

    def test_utc_timings(self):
        config = DashConfig(
            utc_timings=[
                UtcTimingConfig(
                    scheme_id_uri="urn:mpeg:dash:utc:http-xsdate:2014",
                    value="https://time.akamai.com/?iso",
                )
            ]
        )
        assert len(config.utc_timings) == 1

    def test_base_urls(self):
        config = DashConfig(base_urls=["https://cdn1.example.com/", "https://cdn2.example.com/"])
        assert len(config.base_urls) == 2


class TestHlsConfig:
    def test_defaults(self):
        config = HlsConfig()
        assert config.master_playlist_output == ""
        assert config.playlist_type == HlsPlaylistType.VOD
        assert config.is_independent_segments is True

    def test_validate_valid(self):
        config = HlsConfig(master_playlist_output="master.m3u8")
        config.validate()

    def test_validate_negative_seq(self):
        config = HlsConfig(media_sequence_number=-1)
        with pytest.raises(ValueError, match="media_sequence_number"):
            config.validate()

    def test_live_type(self):
        config = HlsConfig(playlist_type=HlsPlaylistType.LIVE)
        assert config.playlist_type == HlsPlaylistType.LIVE

    def test_event_with_program_date(self):
        config = HlsConfig(
            playlist_type=HlsPlaylistType.EVENT,
            add_program_date_time=True,
        )
        assert config.add_program_date_time is True


class TestAdCueConfig:
    def test_empty(self):
        config = AdCueConfig()
        config.validate()
        assert config.cue_points == []

    def test_valid_cues(self):
        config = AdCueConfig(
            cue_points=[
                CuePoint(start_time=10.0, duration=30.0),
                CuePoint(start_time=60.0, duration=15.0),
            ]
        )
        config.validate()

    def test_negative_start(self):
        config = AdCueConfig(cue_points=[CuePoint(start_time=-1.0)])
        with pytest.raises(ValueError, match="start_time.*non-negative"):
            config.validate()

    def test_unsorted_cues(self):
        config = AdCueConfig(
            cue_points=[
                CuePoint(start_time=60.0),
                CuePoint(start_time=10.0),
            ]
        )
        with pytest.raises(ValueError, match="sorted"):
            config.validate()


class TestPackagingConfig:
    def test_defaults(self):
        config = PackagingConfig()
        assert config.single_threaded is True
        assert len(config.streams) == 1
        assert config.streams[0].stream_type == "video"
        assert config.encryption is None
        assert config.decryption is None
        assert config.chunking.segment_duration == 4.0

    def test_with_encryption(self):
        config = PackagingConfig(
            encryption=EncryptionConfig(
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
        )
        assert config.encryption is not None
        assert config.encryption.protection_scheme == ProtectionScheme.CBCS

    def test_with_dash_and_hls(self):
        config = PackagingConfig(
            dash=DashConfig(mpd_output="output.mpd"),
            hls=HlsConfig(master_playlist_output="master.m3u8"),
        )
        assert config.dash is not None
        assert config.hls is not None

    def test_multiple_streams(self):
        config = PackagingConfig(
            streams=[
                StreamConfig(stream_type="video"),
                StreamConfig(stream_type="audio", language="en"),
                TextStreamConfig(language="en"),
            ]
        )
        assert len(config.streams) == 3
