"""Tests for the high-level Packager API.

These tests use mocks since the native C++ extension may not be available
in CI or development environments without Shaka Packager built.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pyshaka.config import (
    DecryptionConfig,
    EncryptionConfig,
    ProtectionScheme,
)
from pyshaka.errors import BuildError, EncryptionError
from pyshaka.packager import Packager, PackagerResult


class TestPackagerResult:
    def test_defaults(self):
        result = PackagerResult()
        assert result.data == b""
        assert result.init_data is None
        assert result.duration_ms == 0.0
        assert result.pssh_boxes == {}
        assert result.outputs == {}
        assert result.manifests == {}
        assert result.success is True
        assert result.errors == []

    def test_with_data(self):
        result = PackagerResult(
            data=b"\x00\x01\x02",
            init_data=b"\x03\x04",
            duration_ms=1.5,
            pssh_boxes={"edef8ba9": b"\x00\x00\x00\x34"},
            outputs={"video": b"\x05\x06"},
            manifests={"output.mpd": "<MPD/>"},
            success=True,
        )
        assert len(result.data) == 3
        assert len(result.init_data) == 2
        assert result.duration_ms == 1.5
        assert "edef8ba9" in result.pssh_boxes
        assert "video" in result.outputs
        assert "output.mpd" in result.manifests

    def test_failure_result(self):
        result = PackagerResult(
            success=False,
            errors=["init failed", "codec not supported"],
        )
        assert result.success is False
        assert len(result.errors) == 2


class TestPackagerNativeCheck:
    def test_raises_build_error_when_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError, match="native extension"):
                packager.encrypt_segment(
                    input_data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )

    def test_get_library_version_no_native(self):
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError, match="native extension"):
                Packager.get_library_version()


class TestPackagerWithMockNative:
    """Test the Packager with a mocked native extension."""

    @pytest.fixture
    def mock_cpp(self):
        """Create a mock _pyshaka_cpp module."""
        mock = MagicMock()

        # Mock Status
        mock_status = MagicMock()
        mock_status.ok.return_value = True
        mock_status.error_code = 0
        mock_status.error_message = ""

        # Mock PackagerCore
        mock_core = MagicMock()
        mock_core.initialize.return_value = mock_status
        mock_core.run.return_value = mock_status
        mock.PackagerCore.return_value = mock_core

        # Mock all param types
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.EncryptionParams.return_value = MagicMock()
        mock.DecryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()

        return mock

    def test_encrypt_segment_basic(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(
                input_data=b"\x00" * 1000,
                stream_type="video",
                protection_scheme=ProtectionScheme.CBCS,
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )

        assert isinstance(result, PackagerResult)
        assert result.duration_ms >= 0
        assert mock_cpp.PackagerCore.called

    def test_encrypt_segment_with_config(self, mock_cpp):
        config = EncryptionConfig(
            protection_scheme=ProtectionScheme.CENC,
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(
                input_data=b"\x00" * 500,
                encryption=config,
            )

        assert isinstance(result, PackagerResult)

    def test_encrypt_segment_init_failure(self, mock_cpp):
        fail_status = MagicMock()
        fail_status.ok.return_value = False
        fail_status.error_code = 42
        fail_status.__str__ = lambda self: "Error(42): init failed"

        mock_cpp.PackagerCore.return_value.initialize.return_value = fail_status

        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(EncryptionError, match="initialization failed"):
                packager.encrypt_segment(
                    input_data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )

    def test_encrypt_segment_run_failure(self, mock_cpp):
        ok_status = MagicMock()
        ok_status.ok.return_value = True

        fail_status = MagicMock()
        fail_status.ok.return_value = False
        fail_status.error_code = 7
        fail_status.__str__ = lambda self: "Error(7): encryption failed"

        core = mock_cpp.PackagerCore.return_value
        core.initialize.return_value = ok_status
        core.run.return_value = fail_status

        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(EncryptionError, match="Encryption failed"):
                packager.encrypt_segment(
                    input_data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )

    def test_encrypt_segment_validation_error(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(ValueError, match="key_id.*key"):
                packager.encrypt_segment(
                    input_data=b"\x00" * 100,
                )

    def test_encrypt_segment_audio(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(
                input_data=b"\x00" * 200,
                stream_type="audio",
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )

        assert isinstance(result, PackagerResult)

    def test_encrypt_init_segment(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_init_segment(
                init_data=b"\x00" * 300,
                stream_type="video",
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )

        assert isinstance(result, PackagerResult)


class TestDecryptSegment:
    """Test the decrypt_segment method."""

    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.DecryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_decrypt_basic(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.decrypt_segment(
                input_data=b"\x00" * 500,
                stream_type="video",
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
        assert isinstance(result, PackagerResult)
        assert result.duration_ms >= 0

    def test_decrypt_with_config(self, mock_cpp):
        config = DecryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.decrypt_segment(
                input_data=b"\x00" * 500,
                decryption=config,
            )
        assert isinstance(result, PackagerResult)

    def test_decrypt_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.decrypt_segment(
                    input_data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )

    def test_decrypt_validation_error(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(ValueError, match="key_id.*key"):
                packager.decrypt_segment(input_data=b"\x00" * 100)


class TestPackageSubtitles:
    """Test the package_subtitles method."""

    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_package_webvtt(self, mock_cpp):
        vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nHello"
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.package_subtitles(
                input_data=vtt,
                input_format="webvtt",
                output_format="vtt+mp4",
                language="en",
            )
        assert isinstance(result, PackagerResult)

    def test_package_bytes_input(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.package_subtitles(
                input_data=b"WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nHello",
            )
        assert isinstance(result, PackagerResult)

    def test_package_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.package_subtitles(input_data="WEBVTT\n\ntest")


class TestExtractCaptions:
    """Test the extract_captions method."""

    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_extract_basic(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.extract_captions(
                input_data=b"\x00" * 1000,
                cc_index=0,
                output_format="webvtt",
            )
        assert isinstance(result, PackagerResult)

    def test_extract_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.extract_captions(input_data=b"\x00" * 100)


class TestMakeTrickPlayStream:
    """Test the make_trick_play_stream method."""

    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_trick_play_basic(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.make_trick_play_stream(
                input_data=b"\x00" * 2000,
                trick_play_factor=2,
            )
        assert isinstance(result, PackagerResult)

    def test_trick_play_with_iframe_playlist(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.make_trick_play_stream(
                input_data=b"\x00" * 2000,
                trick_play_factor=4,
                hls_iframe_playlist_name="iframe.m3u8",
            )
        assert isinstance(result, PackagerResult)

    def test_trick_play_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.make_trick_play_stream(input_data=b"\x00" * 100)


class TestGetLibraryVersion:
    def test_with_mock(self):
        mock_cpp = MagicMock()
        mock_cpp.PackagerCore.get_library_version.return_value = "3.2.0-pyshaka"
        with patch("pyshaka.packager._cpp", mock_cpp):
            version = Packager.get_library_version()
        assert version == "3.2.0-pyshaka"


class TestPackagerConfigOverrides:
    """Test that direct parameters override EncryptionConfig fields."""

    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.EncryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_key_override(self, mock_cpp):
        base_config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(
                input_data=b"\x00" * 100,
                encryption=base_config,
                key="aabbccddeeff00112233445566778899",
            )

        assert isinstance(result, PackagerResult)

    def test_scheme_override(self, mock_cpp):
        base_config = EncryptionConfig(
            protection_scheme=ProtectionScheme.CBCS,
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(
                input_data=b"\x00" * 100,
                encryption=base_config,
                protection_scheme="cenc",
            )

        assert isinstance(result, PackagerResult)
