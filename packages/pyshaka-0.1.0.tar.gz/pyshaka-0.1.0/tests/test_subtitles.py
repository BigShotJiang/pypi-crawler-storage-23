"""Tests for subtitle/text bindings (Issue #10)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pyshaka.config import StreamConfig, TextStreamConfig
from pyshaka.errors import BuildError
from pyshaka.packager import Packager, PackagerResult


class TestTextStreamConfig:
    def test_defaults(self):
        config = TextStreamConfig()
        assert config.stream_type == "text"
        assert config.language == "en"
        assert config.output_format == "vtt+mp4"
        assert config.cc_index == -1
        assert config.forced_subtitle is False

    def test_custom_language(self):
        config = TextStreamConfig(language="pt-BR")
        assert config.language == "pt-BR"

    def test_ttml_format(self):
        config = TextStreamConfig(output_format="ttml+mp4")
        assert config.output_format == "ttml+mp4"

    def test_forced_subtitle(self):
        config = TextStreamConfig(forced_subtitle=True)
        assert config.forced_subtitle is True

    def test_cc_index(self):
        config = TextStreamConfig(cc_index=1)
        assert config.cc_index == 1

    def test_hls_fields(self):
        config = TextStreamConfig(
            language="en",
            hls_playlist_name="subs_en.m3u8",
            hls_characteristics="public.accessibility.transcribes-spoken-dialog",
        )
        assert config.hls_playlist_name == "subs_en.m3u8"
        assert "transcribes" in config.hls_characteristics

    def test_dash_fields(self):
        config = TextStreamConfig(
            language="en",
            dash_roles="subtitle",
            dash_accessibilities="urn:tva:metadata:cs:AudioPurposeCS:2007:2",
        )
        assert config.dash_roles == "subtitle"
        assert "AudioPurpose" in config.dash_accessibilities

    def test_hls_only(self):
        config = TextStreamConfig(hls_only=True)
        assert config.hls_only is True

    def test_dash_only(self):
        config = TextStreamConfig(dash_only=True)
        assert config.dash_only is True

    def test_dash_label(self):
        config = TextStreamConfig(dash_label="English Subtitles")
        assert config.dash_label == "English Subtitles"


class TestStreamConfigTextType:
    def test_text_stream_via_streamconfig(self):
        config = StreamConfig(stream_type="text", language="en")
        assert config.stream_type == "text"

    def test_text_with_output_format(self):
        config = StreamConfig(stream_type="text", language="en", output_format="vtt+mp4")
        assert config.output_format == "vtt+mp4"


class TestPackageSubtitlesWithMock:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_package_webvtt_string(self, mock_cpp):
        vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nHello world"
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.package_subtitles(input_data=vtt)
        assert isinstance(result, PackagerResult)

    def test_package_webvtt_bytes(self, mock_cpp):
        vtt = b"WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nHello"
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.package_subtitles(input_data=vtt)
        assert isinstance(result, PackagerResult)

    def test_package_ttml(self, mock_cpp):
        ttml = '<?xml version="1.0"?><tt xmlns="http://www.w3.org/ns/ttml"><body></body></tt>'
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.package_subtitles(
                input_data=ttml,
                input_format="ttml",
                output_format="ttml+mp4",
            )
        assert isinstance(result, PackagerResult)

    def test_package_custom_language(self, mock_cpp):
        vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nOlá"
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.package_subtitles(
                input_data=vtt,
                language="pt-BR",
            )
        assert isinstance(result, PackagerResult)

    def test_package_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.package_subtitles(input_data="WEBVTT\n\n")


class TestExtractCaptionsWithMock:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_extract_default(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.extract_captions(input_data=b"\x00" * 1000)
        assert isinstance(result, PackagerResult)

    def test_extract_cc_index(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.extract_captions(
                input_data=b"\x00" * 1000,
                cc_index=1,
            )
        assert isinstance(result, PackagerResult)

    def test_extract_ttml_output(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.extract_captions(
                input_data=b"\x00" * 1000,
                output_format="ttml",
            )
        assert isinstance(result, PackagerResult)

    def test_extract_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.extract_captions(input_data=b"\x00" * 100)
