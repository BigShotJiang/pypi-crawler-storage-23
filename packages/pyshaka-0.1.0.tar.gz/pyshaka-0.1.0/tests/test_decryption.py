"""Tests for decryption bindings (Issue #9)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pyshaka.config import DecryptionConfig, KeyInfo, KeyProvider
from pyshaka.errors import BuildError, EncryptionError
from pyshaka.packager import Packager, PackagerResult


class TestDecryptionConfig:
    def test_defaults(self):
        config = DecryptionConfig()
        assert config.key_provider == KeyProvider.RAW
        assert config.key_id is None
        assert config.key is None
        assert config.key_map == {}

    def test_raw_key(self):
        config = DecryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        config.validate()

    def test_raw_missing_key(self):
        config = DecryptionConfig(key_id="00112233445566778899aabbccddeeff")
        with pytest.raises(ValueError, match="key_id.*key"):
            config.validate()

    def test_raw_missing_key_id(self):
        config = DecryptionConfig(key="ffeeddccbbaa99887766554433221100")
        with pytest.raises(ValueError, match="key_id.*key"):
            config.validate()

    def test_multi_key_decrypt(self):
        config = DecryptionConfig(
            key_map={
                "SD": KeyInfo(
                    "00112233445566778899aabbccddeeff",
                    "ffeeddccbbaa99887766554433221100",
                ),
                "HD": KeyInfo(
                    "aabbccddeeff00112233445566778899",
                    "99887766554433221100aabbccddeeff",
                ),
            }
        )
        config.validate()

    def test_multi_key_invalid(self):
        config = DecryptionConfig(
            key_map={
                "SD": KeyInfo("", "ffeeddccbbaa99887766554433221100"),
            }
        )
        with pytest.raises(ValueError, match="key_map"):
            config.validate()

    def test_widevine_decrypt(self):
        config = DecryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            widevine_key_server_url="https://license.example.com",
            content_id="test_content",
            signer="widevine_test",
            signing_key="00112233445566778899aabbccddeeff",
        )
        config.validate()

    def test_widevine_missing_url(self):
        config = DecryptionConfig(key_provider=KeyProvider.WIDEVINE)
        with pytest.raises(ValueError, match="widevine_key_server_url"):
            config.validate()

    def test_frozen(self):
        config = DecryptionConfig()
        with pytest.raises(AttributeError):
            config.key_id = "test"  # type: ignore[misc]


class TestDecryptSegmentWithMock:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.DecryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_decrypt_video(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.decrypt_segment(
                input_data=b"\x00" * 500,
                stream_type="video",
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
        assert isinstance(result, PackagerResult)
        assert result.duration_ms >= 0

    def test_decrypt_audio(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.decrypt_segment(
                input_data=b"\x00" * 300,
                stream_type="audio",
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
        assert isinstance(result, PackagerResult)

    def test_decrypt_with_config(self, mock_cpp):
        config = DecryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.decrypt_segment(
                input_data=b"\x00" * 500,
                decryption=config,
            )
        assert isinstance(result, PackagerResult)

    def test_decrypt_widevine(self, mock_cpp):
        config = DecryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            widevine_key_server_url="https://license.example.com",
            content_id="test",
            signer="test-signer",
            signing_key="00112233445566778899aabbccddeeff",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.decrypt_segment(
                input_data=b"\x00" * 500,
                decryption=config,
            )
        assert isinstance(result, PackagerResult)

    def test_decrypt_init_failure(self, mock_cpp):
        fail = MagicMock()
        fail.ok.return_value = False
        fail.error_code = 42
        mock_cpp.PackagerCore.return_value.initialize.return_value = fail

        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(EncryptionError, match="Decryption initialization failed"):
                packager.decrypt_segment(
                    input_data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )

    def test_decrypt_run_failure(self, mock_cpp):
        ok = MagicMock()
        ok.ok.return_value = True
        fail = MagicMock()
        fail.ok.return_value = False
        fail.error_code = 7

        core = mock_cpp.PackagerCore.return_value
        core.initialize.return_value = ok
        core.run.return_value = fail

        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(EncryptionError, match="Decryption failed"):
                packager.decrypt_segment(
                    input_data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )

    def test_decrypt_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.decrypt_segment(
                    input_data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )
