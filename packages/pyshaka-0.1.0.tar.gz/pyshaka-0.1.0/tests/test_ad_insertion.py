"""Tests for ad insertion / cue point bindings (Issue #12)."""

from __future__ import annotations

import pytest

from pyshaka.config import AdCueConfig, CuePoint


class TestCuePoint:
    def test_defaults(self):
        cp = CuePoint()
        assert cp.start_time == 0.0
        assert cp.duration == 0.0

    def test_with_values(self):
        cp = CuePoint(start_time=30.0, duration=15.0)
        assert cp.start_time == 30.0
        assert cp.duration == 15.0

    def test_zero_duration(self):
        """Zero duration means unknown/indefinite."""
        cp = CuePoint(start_time=10.0, duration=0.0)
        assert cp.duration == 0.0

    def test_frozen(self):
        cp = CuePoint()
        with pytest.raises(AttributeError):
            cp.start_time = 10.0  # type: ignore[misc]


class TestAdCueConfig:
    def test_empty(self):
        config = AdCueConfig()
        config.validate()
        assert config.cue_points == []

    def test_single_cue(self):
        config = AdCueConfig(cue_points=[CuePoint(start_time=30.0, duration=15.0)])
        config.validate()
        assert len(config.cue_points) == 1

    def test_multiple_sorted_cues(self):
        config = AdCueConfig(
            cue_points=[
                CuePoint(start_time=10.0, duration=30.0),
                CuePoint(start_time=60.0, duration=15.0),
                CuePoint(start_time=120.0, duration=30.0),
            ]
        )
        config.validate()
        assert len(config.cue_points) == 3

    def test_equal_start_times_allowed(self):
        """Two cues at the same time should not raise if sorted."""
        config = AdCueConfig(
            cue_points=[
                CuePoint(start_time=10.0, duration=0.0),
                CuePoint(start_time=10.0, duration=15.0),
            ]
        )
        config.validate()

    def test_unsorted_cues_error(self):
        config = AdCueConfig(
            cue_points=[
                CuePoint(start_time=60.0, duration=15.0),
                CuePoint(start_time=10.0, duration=30.0),
            ]
        )
        with pytest.raises(ValueError, match="sorted"):
            config.validate()

    def test_negative_start_time(self):
        config = AdCueConfig(cue_points=[CuePoint(start_time=-1.0)])
        with pytest.raises(ValueError, match="start_time.*non-negative"):
            config.validate()

    def test_negative_duration(self):
        config = AdCueConfig(cue_points=[CuePoint(start_time=10.0, duration=-5.0)])
        with pytest.raises(ValueError, match="duration.*non-negative"):
            config.validate()

    def test_frozen(self):
        config = AdCueConfig()
        with pytest.raises(AttributeError):
            config.cue_points = []  # type: ignore[misc]

    def test_typical_ad_breaks(self):
        """Typical 30-minute show with 3 mid-roll ad breaks."""
        config = AdCueConfig(
            cue_points=[
                CuePoint(start_time=480.0, duration=120.0),  # 8 min
                CuePoint(start_time=960.0, duration=120.0),  # 16 min
                CuePoint(start_time=1440.0, duration=120.0),  # 24 min
            ]
        )
        config.validate()

    def test_pre_roll(self):
        """Pre-roll ad at start."""
        config = AdCueConfig(cue_points=[CuePoint(start_time=0.0, duration=30.0)])
        config.validate()

    def test_many_cues(self):
        """Stress test with many cue points."""
        cues = [CuePoint(start_time=float(i * 10), duration=5.0) for i in range(100)]
        config = AdCueConfig(cue_points=cues)
        config.validate()
        assert len(config.cue_points) == 100
