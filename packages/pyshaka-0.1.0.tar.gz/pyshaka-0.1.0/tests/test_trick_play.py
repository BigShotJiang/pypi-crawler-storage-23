"""Tests for trick play bindings (Issue #11)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pyshaka.config import StreamConfig
from pyshaka.errors import BuildError
from pyshaka.packager import Packager, PackagerResult


class TestTrickPlayConfig:
    """Test trick play configuration via StreamConfig."""

    def test_trick_play_factor_default(self):
        config = StreamConfig()
        assert config.trick_play_factor == 0

    def test_trick_play_factor_set(self):
        config = StreamConfig(trick_play_factor=2)
        assert config.trick_play_factor == 2

    def test_trick_play_4x(self):
        config = StreamConfig(trick_play_factor=4)
        assert config.trick_play_factor == 4

    def test_trick_play_with_iframe_playlist(self):
        config = StreamConfig(
            trick_play_factor=2,
            hls_iframe_playlist_name="iframe.m3u8",
        )
        assert config.trick_play_factor == 2
        assert config.hls_iframe_playlist_name == "iframe.m3u8"

    def test_trick_play_with_bandwidth(self):
        config = StreamConfig(
            trick_play_factor=2,
            bandwidth=500000,
        )
        assert config.bandwidth == 500000


class TestMakeTrickPlayStreamWithMock:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_basic_trick_play(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.make_trick_play_stream(
                input_data=b"\x00" * 2000,
                trick_play_factor=2,
            )
        assert isinstance(result, PackagerResult)

    def test_trick_play_4x(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.make_trick_play_stream(
                input_data=b"\x00" * 2000,
                trick_play_factor=4,
            )
        assert isinstance(result, PackagerResult)

    def test_trick_play_with_iframe_playlist(self, mock_cpp):
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.make_trick_play_stream(
                input_data=b"\x00" * 2000,
                trick_play_factor=2,
                hls_iframe_playlist_name="iframe.m3u8",
            )
        assert isinstance(result, PackagerResult)

    def test_trick_play_no_native(self):
        packager = Packager()
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                packager.make_trick_play_stream(input_data=b"\x00" * 100)

    def test_trick_play_init_failure(self, mock_cpp):
        fail = MagicMock()
        fail.ok.return_value = False
        fail.error_code = 42
        mock_cpp.PackagerCore.return_value.initialize.return_value = fail

        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(Exception, match="Trick play.*failed"):
                packager.make_trick_play_stream(
                    input_data=b"\x00" * 100,
                    trick_play_factor=2,
                )

    def test_trick_play_run_failure(self, mock_cpp):
        ok = MagicMock()
        ok.ok.return_value = True
        fail = MagicMock()
        fail.ok.return_value = False
        fail.error_code = 7

        core = mock_cpp.PackagerCore.return_value
        core.initialize.return_value = ok
        core.run.return_value = fail

        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            with pytest.raises(Exception, match="Trick play.*failed"):
                packager.make_trick_play_stream(
                    input_data=b"\x00" * 100,
                    trick_play_factor=2,
                )
