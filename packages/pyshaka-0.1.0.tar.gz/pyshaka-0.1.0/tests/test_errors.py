"""Tests for error classes."""

from __future__ import annotations

import pytest

from pyshaka.errors import (
    BuildError,
    EncryptionError,
    PackagerNotInitializedError,
    PyshakaError,
)


class TestErrorHierarchy:
    def test_base_error(self):
        err = PyshakaError("test")
        assert isinstance(err, Exception)
        assert str(err) == "test"

    def test_encryption_error_is_pyshaka_error(self):
        err = EncryptionError("failed", error_code=42)
        assert isinstance(err, PyshakaError)
        assert err.error_code == 42

    def test_not_initialized_is_pyshaka_error(self):
        err = PackagerNotInitializedError("not ready")
        assert isinstance(err, PyshakaError)

    def test_build_error(self):
        err = BuildError()
        assert isinstance(err, PyshakaError)
        assert "native extension" in str(err)
        assert "pyshaka" in str(err)

    def test_catch_all_with_base(self):
        """All pyshaka exceptions should be catchable with PyshakaError."""
        errors = [
            PyshakaError("base"),
            EncryptionError("enc"),
            PackagerNotInitializedError("init"),
            BuildError(),
        ]
        for err in errors:
            with pytest.raises(PyshakaError):
                raise err
