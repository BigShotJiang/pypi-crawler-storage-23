"""Tests for full encryption bindings (Issue #5).

Tests cover:
- Multi-key encryption configs
- Protection system bitmasks
- Pattern encryption (crypt_byte_block / skip_byte_block)
- Key rotation (crypto_period_duration)
- Stream label functions
- PlayReady extra header
- All DRM provider validations
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pyshaka.config import (
    EncryptionConfig,
    KeyInfo,
    KeyProvider,
    ProtectionScheme,
    ProtectionSystem,
)
from pyshaka.packager import Packager, PackagerResult


class TestMultiKeyEncryption:
    """Multi-key (per-track) encryption."""

    def test_multi_key_config(self):
        config = EncryptionConfig(
            key_map={
                "SD": KeyInfo(
                    "00112233445566778899aabbccddeeff",
                    "ffeeddccbbaa99887766554433221100",
                ),
                "HD": KeyInfo(
                    "aabbccddeeff00112233445566778899",
                    "99887766554433221100aabbccddeeff",
                ),
            }
        )
        config.validate()
        assert len(config.key_map) == 2
        assert config.key_map["SD"].key_id == "00112233445566778899aabbccddeeff"

    def test_multi_key_missing_key(self):
        config = EncryptionConfig(
            key_map={
                "SD": KeyInfo("00112233445566778899aabbccddeeff", ""),
            }
        )
        with pytest.raises(ValueError, match="key_map"):
            config.validate()

    def test_multi_key_short_key_id(self):
        config = EncryptionConfig(
            key_map={
                "SD": KeyInfo("0011", "ffeeddccbbaa99887766554433221100"),
            }
        )
        with pytest.raises(ValueError, match="32-char"):
            config.validate()

    def test_multi_key_with_iv(self):
        config = EncryptionConfig(
            key_map={
                "AUDIO": KeyInfo(
                    "00112233445566778899aabbccddeeff",
                    "ffeeddccbbaa99887766554433221100",
                    "aabbccddeeff00112233445566778899",
                ),
            }
        )
        config.validate()
        assert config.key_map["AUDIO"].iv == "aabbccddeeff00112233445566778899"

    def test_multi_key_invalid_iv_length(self):
        config = EncryptionConfig(
            key_map={
                "AUDIO": KeyInfo(
                    "00112233445566778899aabbccddeeff",
                    "ffeeddccbbaa99887766554433221100",
                    "short",
                ),
            }
        )
        with pytest.raises(ValueError, match="iv.*32-char"):
            config.validate()


class TestProtectionSystems:
    """Protection system bitmask combinations."""

    def test_single_system(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            protection_systems=ProtectionSystem.WIDEVINE,
        )
        config.validate()
        assert config.protection_systems == ProtectionSystem.WIDEVINE

    def test_combined_systems(self):
        combined = (
            ProtectionSystem.WIDEVINE | ProtectionSystem.PLAYREADY | ProtectionSystem.FAIRPLAY
        )
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            protection_systems=combined,
        )
        config.validate()
        assert config.protection_systems & ProtectionSystem.WIDEVINE
        assert config.protection_systems & ProtectionSystem.PLAYREADY
        assert config.protection_systems & ProtectionSystem.FAIRPLAY
        assert not (config.protection_systems & ProtectionSystem.MARLIN)

    def test_all_systems(self):
        all_sys = (
            ProtectionSystem.COMMON
            | ProtectionSystem.WIDEVINE
            | ProtectionSystem.PLAYREADY
            | ProtectionSystem.FAIRPLAY
            | ProtectionSystem.MARLIN
        )
        assert all_sys.value == 0x1F


class TestPatternEncryption:
    """CBCS pattern encryption mode (1:9 pattern)."""

    def test_pattern_config(self):
        config = EncryptionConfig(
            protection_scheme=ProtectionScheme.CBCS,
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            crypt_byte_block=1,
            skip_byte_block=9,
        )
        config.validate()
        assert config.crypt_byte_block == 1
        assert config.skip_byte_block == 9

    def test_full_sample_encryption(self):
        config = EncryptionConfig(
            protection_scheme=ProtectionScheme.CENC,
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            crypt_byte_block=0,
            skip_byte_block=0,
        )
        config.validate()


class TestKeyRotation:
    """Crypto period duration for key rotation."""

    def test_key_rotation_config(self):
        config = EncryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            widevine_key_server_url="https://license.example.com/cenc/getcontentkey",
            signer="widevine_test",
            signing_key="00112233445566778899aabbccddeeff",
            crypto_period_duration=10.0,
        )
        config.validate()
        assert config.crypto_period_duration == 10.0

    def test_zero_period_means_no_rotation(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            crypto_period_duration=0.0,
        )
        config.validate()
        assert config.crypto_period_duration == 0.0


class TestStreamLabelFunc:
    """Custom stream label function for multi-key."""

    def test_custom_label_func(self):
        def my_label_func(stream_type: str) -> str:
            return "HD" if stream_type == "video" else "AUDIO"

        config = EncryptionConfig(
            key_map={
                "HD": KeyInfo(
                    "00112233445566778899aabbccddeeff",
                    "ffeeddccbbaa99887766554433221100",
                ),
                "AUDIO": KeyInfo(
                    "aabbccddeeff00112233445566778899",
                    "99887766554433221100aabbccddeeff",
                ),
            },
            stream_label_func=my_label_func,
        )
        config.validate()
        assert config.stream_label_func("video") == "HD"
        assert config.stream_label_func("audio") == "AUDIO"


class TestPlayReadyEncryption:
    """PlayReady-specific encryption config."""

    def test_playready_with_key(self):
        config = EncryptionConfig(
            key_provider=KeyProvider.PLAYREADY,
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            playready_extra_header_data="<custom_xml>extra</custom_xml>",
        )
        config.validate()
        assert config.playready_extra_header_data == "<custom_xml>extra</custom_xml>"

    def test_playready_requires_key_or_url(self):
        config = EncryptionConfig(key_provider=KeyProvider.PLAYREADY)
        with pytest.raises(ValueError, match="PlayReady"):
            config.validate()


class TestVP9SubsampleEncryption:
    """VP9 subsample encryption flag."""

    def test_vp9_flag(self):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            vp9_subsample_encryption=True,
        )
        config.validate()
        assert config.vp9_subsample_encryption is True


class TestEncryptionWithMock:
    """Test encryption operations with mocked native extension."""

    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.EncryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_encrypt_with_protection_systems(self, mock_cpp):
        config = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            protection_systems=ProtectionSystem.WIDEVINE | ProtectionSystem.PLAYREADY,
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(input_data=b"\x00" * 100, encryption=config)
        assert isinstance(result, PackagerResult)

    def test_encrypt_with_pattern(self, mock_cpp):
        config = EncryptionConfig(
            protection_scheme=ProtectionScheme.CBCS,
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
            crypt_byte_block=1,
            skip_byte_block=9,
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(input_data=b"\x00" * 100, encryption=config)
        assert isinstance(result, PackagerResult)

    def test_encrypt_widevine_provider(self, mock_cpp):
        config = EncryptionConfig(
            key_provider=KeyProvider.WIDEVINE,
            widevine_key_server_url="https://example.com/keys",
            signer="test-signer",
            signing_key="00112233445566778899aabbccddeeff",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(input_data=b"\x00" * 100, encryption=config)
        assert isinstance(result, PackagerResult)

    def test_encrypt_cpix_provider(self, mock_cpp):
        config = EncryptionConfig(
            key_provider=KeyProvider.CPIX,
            cpix_server_url="https://cpix.example.com/v2",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(input_data=b"\x00" * 100, encryption=config)
        assert isinstance(result, PackagerResult)

    def test_encrypt_with_stream_label(self, mock_cpp):
        config = EncryptionConfig(
            key_map={
                "HD": KeyInfo(
                    "00112233445566778899aabbccddeeff",
                    "ffeeddccbbaa99887766554433221100",
                ),
            },
            stream_label_func=lambda s: "HD",
        )
        packager = Packager()
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = packager.encrypt_segment(input_data=b"\x00" * 100, encryption=config)
        assert isinstance(result, PackagerResult)

    def test_encrypt_all_schemes(self, mock_cpp):
        for scheme in ProtectionScheme:
            config = EncryptionConfig(
                protection_scheme=scheme,
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
            packager = Packager()
            with patch("pyshaka.packager._cpp", mock_cpp):
                result = packager.encrypt_segment(input_data=b"\x00" * 100, encryption=config)
            assert isinstance(result, PackagerResult)
