"""Tests for DASH manifest bindings (Issue #7)."""

from __future__ import annotations

import pytest

from pyshaka.config import DashConfig, UtcTimingConfig


class TestUtcTimingConfig:
    def test_defaults(self):
        config = UtcTimingConfig()
        assert config.scheme_id_uri == ""
        assert config.value == ""

    def test_http_xsdate(self):
        config = UtcTimingConfig(
            scheme_id_uri="urn:mpeg:dash:utc:http-xsdate:2014",
            value="https://time.akamai.com/?iso",
        )
        assert "http-xsdate" in config.scheme_id_uri
        assert "akamai" in config.value

    def test_direct_utc(self):
        config = UtcTimingConfig(
            scheme_id_uri="urn:mpeg:dash:utc:direct:2014",
            value="2024-01-01T00:00:00Z",
        )
        assert "direct" in config.scheme_id_uri


class TestDashConfig:
    def test_defaults(self):
        config = DashConfig()
        assert config.mpd_output == ""
        assert config.base_urls == []
        assert config.min_buffer_time == 2.0
        assert config.minimum_update_period == 0.0
        assert config.suggested_presentation_delay == 0.0
        assert config.time_shift_buffer_depth == 0.0
        assert config.preserved_segments_outside_live_window == 0
        assert config.utc_timings == []
        assert config.default_language == ""
        assert config.default_text_language == ""
        assert config.generate_static_live_mpd is False
        assert config.generate_dash_if_iop_compliant_mpd is True
        assert config.allow_approximate_segment_timeline is False
        assert config.allow_codec_switching is False
        assert config.include_mspr_pro is True
        assert config.use_segment_list is False
        assert config.low_latency_dash_mode is False
        assert config.target_latency_seconds == 0.0

    def test_vod_config(self):
        config = DashConfig(
            mpd_output="output.mpd",
            min_buffer_time=2.0,
            default_language="en",
        )
        config.validate()
        assert config.mpd_output == "output.mpd"

    def test_live_config(self):
        config = DashConfig(
            mpd_output="live.mpd",
            minimum_update_period=2.0,
            suggested_presentation_delay=6.0,
            time_shift_buffer_depth=60.0,
        )
        config.validate()
        assert config.minimum_update_period == 2.0
        assert config.time_shift_buffer_depth == 60.0

    def test_low_latency_config(self):
        config = DashConfig(
            mpd_output="ll.mpd",
            low_latency_dash_mode=True,
            target_latency_seconds=3.0,
            minimum_update_period=1.0,
        )
        config.validate()
        assert config.low_latency_dash_mode is True
        assert config.target_latency_seconds == 3.0

    def test_multi_base_url(self):
        config = DashConfig(
            base_urls=[
                "https://cdn1.example.com/",
                "https://cdn2.example.com/",
                "https://cdn3.example.com/",
            ]
        )
        assert len(config.base_urls) == 3

    def test_utc_timing_list(self):
        config = DashConfig(
            utc_timings=[
                UtcTimingConfig(
                    "urn:mpeg:dash:utc:http-xsdate:2014", "https://time.akamai.com/?iso"
                ),
                UtcTimingConfig("urn:mpeg:dash:utc:direct:2014", "2024-01-01T00:00:00Z"),
            ]
        )
        assert len(config.utc_timings) == 2

    def test_validate_negative_buffer(self):
        config = DashConfig(min_buffer_time=-1.0)
        with pytest.raises(ValueError, match="min_buffer_time.*non-negative"):
            config.validate()

    def test_validate_negative_time_shift(self):
        config = DashConfig(time_shift_buffer_depth=-1.0)
        with pytest.raises(ValueError, match="time_shift_buffer_depth.*non-negative"):
            config.validate()

    def test_frozen(self):
        config = DashConfig()
        with pytest.raises(AttributeError):
            config.mpd_output = "test.mpd"  # type: ignore[misc]

    def test_codec_switching(self):
        config = DashConfig(allow_codec_switching=True)
        assert config.allow_codec_switching is True

    def test_segment_list_mode(self):
        config = DashConfig(use_segment_list=True)
        assert config.use_segment_list is True

    def test_iop_compliance_disabled(self):
        config = DashConfig(generate_dash_if_iop_compliant_mpd=False)
        assert config.generate_dash_if_iop_compliant_mpd is False

    def test_static_live_mpd(self):
        config = DashConfig(generate_static_live_mpd=True)
        assert config.generate_static_live_mpd is True

    def test_preserved_segments(self):
        config = DashConfig(preserved_segments_outside_live_window=5)
        assert config.preserved_segments_outside_live_window == 5

    def test_playready_mspr_pro(self):
        config = DashConfig(include_mspr_pro=False)
        assert config.include_mspr_pro is False

    def test_default_text_language(self):
        config = DashConfig(default_language="en", default_text_language="es")
        assert config.default_text_language == "es"

    def test_approximate_segment_timeline(self):
        config = DashConfig(allow_approximate_segment_timeline=True)
        assert config.allow_approximate_segment_timeline is True
