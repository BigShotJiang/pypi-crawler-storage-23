"""Shared pytest configuration and fixtures for pyshaka tests."""

from __future__ import annotations

from pathlib import Path

import pytest

# ── Test data directory ──────────────────────────────────────────────
TEST_DATA_DIR = Path(__file__).parent / "data"


# ── Custom markers ───────────────────────────────────────────────────
def pytest_configure(config: pytest.Config) -> None:
    """Register custom markers."""
    config.addinivalue_line("markers", "native: requires compiled _pyshaka_cpp extension")
    config.addinivalue_line("markers", "slow: long-running tests (>5s)")
    config.addinivalue_line("markers", "integration: requires Shaka Packager or network")


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Auto-skip native-marked tests when _pyshaka_cpp is not importable."""
    try:
        import pyshaka._pyshaka_cpp  # noqa: F401

        has_native = True
    except ImportError:
        has_native = False

    skip_native = pytest.mark.skip(reason="_pyshaka_cpp extension not available")
    for item in items:
        if "native" in item.keywords and not has_native:
            item.add_marker(skip_native)


# ── Media fixtures ───────────────────────────────────────────────────
@pytest.fixture
def sample_webvtt() -> str:
    """Simple WebVTT subtitle file with 3 cues."""
    return (TEST_DATA_DIR / "sample.vtt").read_text()


@pytest.fixture
def sample_ttml() -> str:
    """TTML subtitle file with 3 cues."""
    return (TEST_DATA_DIR / "sample.ttml").read_text()


@pytest.fixture
def sample_video_mp4() -> bytes:
    """Fake 2-second H.264 Baseline / AAC fMP4 (video+audio muxed).

    Returns a synthetic fMP4 with ftyp + moov + moof + mdat boxes.
    NOT a real playable file — used for API testing.
    """
    from tests.helpers import make_fake_fmp4

    return make_fake_fmp4(
        include_ftyp=True,
        include_moov=True,
        include_moof=True,
        include_mdat=True,
    )


@pytest.fixture
def sample_video_only_mp4() -> bytes:
    """Fake video-only fMP4 (no audio)."""
    from tests.helpers import make_fake_fmp4

    return make_fake_fmp4(
        include_ftyp=True,
        include_moov=True,
        include_moof=True,
        include_mdat=True,
    )


@pytest.fixture
def sample_audio_only_mp4() -> bytes:
    """Fake audio-only fMP4."""
    from tests.helpers import make_fake_fmp4

    return make_fake_fmp4(
        include_ftyp=True,
        include_moov=True,
        include_moof=True,
        include_mdat=True,
    )


@pytest.fixture
def sample_init_segment() -> bytes:
    """Fake fMP4 init segment (ftyp + moov)."""
    from tests.helpers import make_fake_fmp4

    return make_fake_fmp4(include_ftyp=True, include_moov=True)


@pytest.fixture
def sample_media_segment() -> bytes:
    """Fake fMP4 media segment (moof + mdat)."""
    from tests.helpers import make_fake_box

    return make_fake_box(b"moof", b"\x00" * 8) + make_fake_box(b"mdat", b"\x00" * 64)


@pytest.fixture
def encryption_key() -> str:
    """128-bit hex encryption key for testing."""
    return "00112233445566778899aabbccddeeff"


@pytest.fixture
def encryption_key_id() -> str:
    """128-bit hex key ID for testing."""
    return "ffeeddccbbaa99887766554433221100"


@pytest.fixture
def tmp_output_dir(tmp_path: Path) -> Path:
    """Temporary directory for output files."""
    out = tmp_path / "output"
    out.mkdir()
    return out
