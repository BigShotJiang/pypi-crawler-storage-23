"""Tests for high-level convenience functions (Issue #14)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pyshaka.config import (
    DecryptionConfig,
    EncryptionConfig,
    PackagingConfig,
    ProtectionScheme,
    StreamConfig,
)
from pyshaka.errors import BuildError
from pyshaka.highlevel import decrypt, encrypt, package, package_bytes
from pyshaka.packager import PackagerResult


class TestEncryptFunction:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.EncryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_basic_encrypt(self, mock_cpp):
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = encrypt(
                data=b"\x00" * 100,
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
        assert isinstance(result, bytes)

    def test_encrypt_with_scheme(self, mock_cpp):
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = encrypt(
                data=b"\x00" * 100,
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
                protection_scheme=ProtectionScheme.CENC,
            )
        assert isinstance(result, bytes)

    def test_encrypt_no_native(self):
        with patch("pyshaka.packager._cpp", None):
            with pytest.raises(BuildError):
                encrypt(
                    data=b"\x00" * 100,
                    key_id="00112233445566778899aabbccddeeff",
                    key="ffeeddccbbaa99887766554433221100",
                )


class TestDecryptFunction:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.DecryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_basic_decrypt(self, mock_cpp):
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = decrypt(
                data=b"\x00" * 100,
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
        assert isinstance(result, bytes)

    def test_decrypt_audio(self, mock_cpp):
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = decrypt(
                data=b"\x00" * 100,
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
                stream_type="audio",
            )
        assert isinstance(result, bytes)


class TestPackageBytesFunction:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.EncryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_with_encryption(self, mock_cpp):
        enc = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = package_bytes(
                data=b"\x00" * 100,
                encryption=enc,
            )
        assert isinstance(result, PackagerResult)

    def test_with_config(self, mock_cpp):
        config = PackagingConfig(
            encryption=EncryptionConfig(
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            )
        )
        with patch("pyshaka.packager._cpp", mock_cpp):
            result = package_bytes(data=b"\x00" * 100, config=config)
        assert isinstance(result, PackagerResult)


class TestPackageFunction:
    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.EncryptionParams.return_value = MagicMock()
        mock.DecryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_empty_package(self):
        results = package()
        assert results == {}

    def test_with_inputs_and_encryption(self, mock_cpp):
        enc = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        with patch("pyshaka.packager._cpp", mock_cpp):
            results = package(
                encryption=enc,
                input_files={"video.mp4": b"\x00" * 500},
            )
        assert "video.mp4" in results
        assert isinstance(results["video.mp4"], PackagerResult)

    def test_with_decryption(self, mock_cpp):
        dec = DecryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        with patch("pyshaka.packager._cpp", mock_cpp):
            results = package(
                decryption=dec,
                input_files={"video_enc.mp4": b"\x00" * 500},
            )
        assert "video_enc.mp4" in results

    def test_no_encryption_passthrough(self):
        results = package(
            input_files={"video.mp4": b"\x00" * 100},
        )
        assert "video.mp4" in results
        assert results["video.mp4"].data == b"\x00" * 100

    def test_multi_input(self, mock_cpp):
        enc = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )
        with patch("pyshaka.packager._cpp", mock_cpp):
            results = package(
                encryption=enc,
                input_files={
                    "video.mp4": b"\x00" * 500,
                    "audio.mp4": b"\x01" * 300,
                },
                streams=[
                    StreamConfig(stream_type="video"),
                    StreamConfig(stream_type="audio", language="en"),
                ],
            )
        assert len(results) == 2
        assert "video.mp4" in results
        assert "audio.mp4" in results
