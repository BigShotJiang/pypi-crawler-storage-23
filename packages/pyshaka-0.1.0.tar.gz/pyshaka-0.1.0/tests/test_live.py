"""Tests for live packaging support (Issue #13)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pyshaka.config import (
    ChunkingConfig,
    DashConfig,
    EncryptionConfig,
    HlsConfig,
    HlsPlaylistType,
    PackagingConfig,
    StreamConfig,
)
from pyshaka.packager import Packager, PackagerResult


class TestLivePackagingConfig:
    """Test configurations typical for live packaging."""

    def test_live_dash_config(self):
        config = DashConfig(
            mpd_output="live.mpd",
            minimum_update_period=2.0,
            suggested_presentation_delay=6.0,
            time_shift_buffer_depth=60.0,
            preserved_segments_outside_live_window=3,
            generate_static_live_mpd=True,
        )
        config.validate()
        assert config.minimum_update_period == 2.0
        assert config.generate_static_live_mpd is True

    def test_live_hls_config(self):
        config = HlsConfig(
            master_playlist_output="live.m3u8",
            playlist_type=HlsPlaylistType.LIVE,
            time_shift_buffer_depth=60.0,
            add_program_date_time=True,
        )
        config.validate()
        assert config.playlist_type == HlsPlaylistType.LIVE

    def test_event_hls_config(self):
        config = HlsConfig(
            master_playlist_output="event.m3u8",
            playlist_type=HlsPlaylistType.EVENT,
            add_program_date_time=True,
        )
        config.validate()
        assert config.playlist_type == HlsPlaylistType.EVENT

    def test_low_latency_chunking(self):
        config = ChunkingConfig(
            segment_duration=2.0,
            low_latency_dash_mode=True,
        )
        config.validate()
        assert config.low_latency_dash_mode is True
        assert config.segment_duration == 2.0

    def test_full_live_config(self):
        """Test a complete live packaging configuration."""
        config = PackagingConfig(
            chunking=ChunkingConfig(
                segment_duration=4.0,
                segment_sap_aligned=True,
            ),
            dash=DashConfig(
                mpd_output="live.mpd",
                minimum_update_period=4.0,
                suggested_presentation_delay=8.0,
                time_shift_buffer_depth=120.0,
            ),
            hls=HlsConfig(
                master_playlist_output="live.m3u8",
                playlist_type=HlsPlaylistType.LIVE,
                time_shift_buffer_depth=120.0,
                add_program_date_time=True,
            ),
            streams=[
                StreamConfig(stream_type="video"),
                StreamConfig(stream_type="audio", language="en"),
            ],
        )
        assert config.dash is not None
        assert config.hls is not None
        assert len(config.streams) == 2

    def test_live_with_encryption(self):
        """Test live config with encryption (typical for DRM-protected live)."""
        config = PackagingConfig(
            encryption=EncryptionConfig(
                key_id="00112233445566778899aabbccddeeff",
                key="ffeeddccbbaa99887766554433221100",
            ),
            chunking=ChunkingConfig(segment_duration=4.0),
            dash=DashConfig(
                mpd_output="live_drm.mpd",
                minimum_update_period=4.0,
                time_shift_buffer_depth=60.0,
            ),
        )
        assert config.encryption is not None
        assert config.dash is not None

    def test_low_latency_full_config(self):
        """Test LL-DASH configuration."""
        config = PackagingConfig(
            chunking=ChunkingConfig(
                segment_duration=2.0,
                low_latency_dash_mode=True,
            ),
            dash=DashConfig(
                mpd_output="ll.mpd",
                low_latency_dash_mode=True,
                target_latency_seconds=3.0,
                minimum_update_period=1.0,
            ),
        )
        assert config.chunking.low_latency_dash_mode is True
        assert config.dash.low_latency_dash_mode is True


class TestLivePackagerSimulation:
    """Simulate live packaging workflow with mocked native."""

    @pytest.fixture
    def mock_cpp(self):
        mock = MagicMock()
        ok = MagicMock()
        ok.ok.return_value = True
        mock.PackagerCore.return_value.initialize.return_value = ok
        mock.PackagerCore.return_value.run.return_value = ok
        mock.BufferCallbackParams.return_value = MagicMock()
        mock.StreamDescriptor.return_value = MagicMock()
        mock.EncryptionParams.return_value = MagicMock()
        mock.PackagingParams.return_value = MagicMock()
        return mock

    def test_sequential_segment_encryption(self, mock_cpp):
        """Simulate encrypting multiple live segments sequentially."""
        packager = Packager()
        enc = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )

        results = []
        with patch("pyshaka.packager._cpp", mock_cpp):
            for i in range(5):
                segment = b"\x00" * (1000 + i * 100)
                result = packager.encrypt_segment(
                    input_data=segment,
                    encryption=enc,
                )
                results.append(result)

        assert len(results) == 5
        assert all(isinstance(r, PackagerResult) for r in results)

    def test_multi_track_live(self, mock_cpp):
        """Simulate encrypting video + audio tracks in parallel-like fashion."""
        packager = Packager()
        enc = EncryptionConfig(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        )

        with patch("pyshaka.packager._cpp", mock_cpp):
            video_result = packager.encrypt_segment(
                input_data=b"\x00" * 5000,
                stream_type="video",
                encryption=enc,
            )
            audio_result = packager.encrypt_segment(
                input_data=b"\x00" * 1000,
                stream_type="audio",
                encryption=enc,
            )

        assert isinstance(video_result, PackagerResult)
        assert isinstance(audio_result, PackagerResult)
