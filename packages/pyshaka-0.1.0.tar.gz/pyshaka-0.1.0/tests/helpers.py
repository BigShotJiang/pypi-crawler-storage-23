"""Shared test helpers for pyshaka tests."""

from __future__ import annotations

import struct


def is_valid_fmp4(data: bytes) -> bool:
    """Quick check: data starts with an fMP4-compatible box (ftyp, styp, or moof).

    Parameters
    ----------
    data : bytes
        Raw binary data to check.

    Returns
    -------
    bool
        True if the first box type is ftyp, styp, or moof.
    """
    if len(data) < 8:
        return False
    box_type = data[4:8]
    return box_type in (b"ftyp", b"styp", b"moof")


def find_box(data: bytes, box_type: bytes) -> bytes | None:
    """Find the first MP4 box of the given type and return its payload.

    Parses the top-level MP4 box structure (size + fourcc) and returns
    the body of the first matching box, or None if not found.

    Parameters
    ----------
    data : bytes
        Raw MP4/fMP4 binary data.
    box_type : bytes
        4-byte box type to search for (e.g., b"pssh", b"ftyp").

    Returns
    -------
    bytes or None
        The box payload (excluding size and type fields), or None.
    """
    offset = 0
    while offset + 8 <= len(data):
        size = struct.unpack(">I", data[offset : offset + 4])[0]
        btype = data[offset + 4 : offset + 8]
        if size < 8:
            break
        if btype == box_type:
            return data[offset + 8 : offset + size]
        offset += size
    return None


def has_pssh_box(data: bytes) -> bool:
    """Check if data contains a PSSH box (DRM system identifier).

    Parameters
    ----------
    data : bytes
        Raw MP4/fMP4 binary data.

    Returns
    -------
    bool
        True if a PSSH box is found.
    """
    return find_box(data, b"pssh") is not None


def make_fake_box(box_type: bytes, payload: bytes = b"") -> bytes:
    """Create a fake MP4 box with the given type and payload.

    Parameters
    ----------
    box_type : bytes
        4-byte box type (e.g., b"ftyp").
    payload : bytes
        Box content.

    Returns
    -------
    bytes
        Complete MP4 box (size + type + payload).
    """
    size = 8 + len(payload)
    return struct.pack(">I", size) + box_type + payload


def make_fake_fmp4(
    *,
    include_ftyp: bool = True,
    include_moov: bool = True,
    include_moof: bool = False,
    include_mdat: bool = False,
    include_pssh: bool = False,
) -> bytes:
    """Build a minimal fake fMP4 byte sequence for testing.

    Parameters
    ----------
    include_ftyp : bool
        Include an ftyp box.
    include_moov : bool
        Include a moov box.
    include_moof : bool
        Include a moof box.
    include_mdat : bool
        Include an mdat box.
    include_pssh : bool
        Include a PSSH box inside moov.

    Returns
    -------
    bytes
        Fake fMP4 data.
    """
    data = b""
    if include_ftyp:
        data += make_fake_box(b"ftyp", b"isom\x00\x00\x02\x00isomiso6mp41")
    if include_pssh:
        pssh_payload = (
            b"\x01\x00\x00\x00"  # version + flags
            b"\xed\xef\x8b\xa9\x79\xd6\x4a\xce"  # Widevine system ID
            b"\xa3\xc8\x27\xdc\xd5\x1d\x21\xed"
            b"\x00\x00\x00\x01"  # key ID count
            b"\x00\x11\x22\x33\x44\x55\x66\x77"  # key ID
            b"\x88\x99\xaa\xbb\xcc\xdd\xee\xff"
            b"\x00\x00\x00\x00"  # data size
        )
        pssh_box = make_fake_box(b"pssh", pssh_payload)
        moov_payload = pssh_box if include_moov else b""
    else:
        moov_payload = b"\x00" * 16  # minimal moov content
    if include_moov:
        data += make_fake_box(b"moov", moov_payload)
    if include_moof:
        data += make_fake_box(b"moof", b"\x00" * 8)
    if include_mdat:
        data += make_fake_box(b"mdat", b"\x00" * 64)
    return data


def assert_manifest_valid_mpd(content: str) -> None:
    """Assert that the content looks like a valid DASH MPD.

    Performs basic structural validation — checks for XML declaration,
    MPD root element, and closing tag.

    Parameters
    ----------
    content : str
        MPD manifest content.

    Raises
    ------
    AssertionError
        If the content doesn't match expected MPD structure.
    """
    assert content.strip().startswith("<?xml"), "MPD must start with XML declaration"
    assert "<MPD" in content, "MPD must contain <MPD element"
    assert "</MPD>" in content, "MPD must contain closing </MPD> tag"


def assert_manifest_valid_m3u8(content: str) -> None:
    """Assert that the content looks like a valid HLS m3u8 playlist.

    Parameters
    ----------
    content : str
        HLS manifest content.

    Raises
    ------
    AssertionError
        If the content doesn't match expected m3u8 structure.
    """
    assert content.strip().startswith("#EXTM3U"), "m3u8 must start with #EXTM3U"
