"""Tests for HLS manifest bindings (Issue #8)."""

from __future__ import annotations

import pytest

from pyshaka.config import HlsConfig, HlsPlaylistType


class TestHlsPlaylistType:
    def test_values(self):
        assert HlsPlaylistType.VOD.value == "vod"
        assert HlsPlaylistType.EVENT.value == "event"
        assert HlsPlaylistType.LIVE.value == "live"

    def test_from_string(self):
        assert HlsPlaylistType("vod") == HlsPlaylistType.VOD
        assert HlsPlaylistType("event") == HlsPlaylistType.EVENT
        assert HlsPlaylistType("live") == HlsPlaylistType.LIVE


class TestHlsConfig:
    def test_defaults(self):
        config = HlsConfig()
        assert config.master_playlist_output == ""
        assert config.base_url == ""
        assert config.playlist_type == HlsPlaylistType.VOD
        assert config.key_uri == ""
        assert config.time_shift_buffer_depth == 0.0
        assert config.preserved_segments_outside_live_window == 0
        assert config.default_language == ""
        assert config.default_text_language == ""
        assert config.is_independent_segments is True
        assert config.media_sequence_number == 0
        assert config.start_time_offset == 0.0
        assert config.create_session_keys is False
        assert config.add_program_date_time is False

    def test_vod_config(self):
        config = HlsConfig(
            master_playlist_output="master.m3u8",
            playlist_type=HlsPlaylistType.VOD,
            default_language="en",
        )
        config.validate()
        assert config.master_playlist_output == "master.m3u8"

    def test_live_config(self):
        config = HlsConfig(
            master_playlist_output="live.m3u8",
            playlist_type=HlsPlaylistType.LIVE,
            time_shift_buffer_depth=60.0,
            add_program_date_time=True,
        )
        config.validate()
        assert config.playlist_type == HlsPlaylistType.LIVE
        assert config.time_shift_buffer_depth == 60.0

    def test_event_config(self):
        config = HlsConfig(
            master_playlist_output="event.m3u8",
            playlist_type=HlsPlaylistType.EVENT,
        )
        config.validate()

    def test_with_key_uri(self):
        config = HlsConfig(
            master_playlist_output="encrypted.m3u8",
            key_uri="https://example.com/keys/content_key",
        )
        assert config.key_uri == "https://example.com/keys/content_key"

    def test_base_url(self):
        config = HlsConfig(base_url="https://cdn.example.com/hls/")
        assert config.base_url == "https://cdn.example.com/hls/"

    def test_session_keys(self):
        config = HlsConfig(
            master_playlist_output="master.m3u8",
            create_session_keys=True,
        )
        assert config.create_session_keys is True

    def test_independent_segments_disabled(self):
        config = HlsConfig(is_independent_segments=False)
        assert config.is_independent_segments is False

    def test_validate_negative_seq(self):
        config = HlsConfig(media_sequence_number=-1)
        with pytest.raises(ValueError, match="media_sequence_number.*non-negative"):
            config.validate()

    def test_validate_zero_seq(self):
        config = HlsConfig(media_sequence_number=0)
        config.validate()  # should not raise

    def test_validate_positive_seq(self):
        config = HlsConfig(media_sequence_number=100)
        config.validate()  # should not raise

    def test_start_time_offset(self):
        config = HlsConfig(start_time_offset=10.5)
        assert config.start_time_offset == 10.5

    def test_preserved_segments(self):
        config = HlsConfig(preserved_segments_outside_live_window=3)
        assert config.preserved_segments_outside_live_window == 3

    def test_program_date_time(self):
        config = HlsConfig(add_program_date_time=True)
        assert config.add_program_date_time is True

    def test_frozen(self):
        config = HlsConfig()
        with pytest.raises(AttributeError):
            config.master_playlist_output = "fail.m3u8"  # type: ignore[misc]

    def test_text_languages(self):
        config = HlsConfig(
            default_language="en",
            default_text_language="es",
        )
        assert config.default_language == "en"
        assert config.default_text_language == "es"
