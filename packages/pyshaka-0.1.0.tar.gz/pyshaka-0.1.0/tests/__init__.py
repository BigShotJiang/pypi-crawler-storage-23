"""Tests for pyshaka — Python bindings for Shaka Packager."""
