"""Tests for test infrastructure: helpers, fixtures, and markers."""

from __future__ import annotations

import struct
from pathlib import Path

import pytest

from tests.helpers import (
    assert_manifest_valid_m3u8,
    assert_manifest_valid_mpd,
    find_box,
    has_pssh_box,
    is_valid_fmp4,
    make_fake_box,
    make_fake_fmp4,
)


class TestIsValidFmp4:
    def test_positive_ftyp(self):
        data = make_fake_box(b"ftyp", b"isom")
        assert is_valid_fmp4(data) is True

    def test_positive_styp(self):
        data = make_fake_box(b"styp", b"msdh")
        assert is_valid_fmp4(data) is True

    def test_positive_moof(self):
        data = make_fake_box(b"moof", b"\x00" * 4)
        assert is_valid_fmp4(data) is True

    def test_negative_random(self):
        assert is_valid_fmp4(b"\x00\x01\x02\x03\x04\x05\x06\x07") is False

    def test_negative_short(self):
        assert is_valid_fmp4(b"\x00\x01") is False

    def test_negative_empty(self):
        assert is_valid_fmp4(b"") is False


class TestFindBox:
    def test_finds_existing_box(self):
        payload = b"hello"
        box = make_fake_box(b"test", payload)
        result = find_box(box, b"test")
        assert result == payload

    def test_returns_none_for_missing(self):
        box = make_fake_box(b"ftyp", b"isom")
        assert find_box(box, b"moov") is None

    def test_finds_in_multi_box(self):
        data = make_fake_box(b"ftyp", b"isom") + make_fake_box(b"moov", b"content")
        result = find_box(data, b"moov")
        assert result == b"content"

    def test_empty_data(self):
        assert find_box(b"", b"ftyp") is None


class TestHasPsshBox:
    def test_positive(self):
        make_fake_fmp4(include_pssh=True)
        # The PSSH is inside moov, so we need to look inside moov's payload
        # However has_pssh_box only looks at top-level boxes
        # Let's create a top-level PSSH for this test
        pssh_data = make_fake_box(b"pssh", b"\x00" * 16)
        assert has_pssh_box(pssh_data) is True

    def test_negative(self):
        data = make_fake_fmp4(include_pssh=False)
        assert has_pssh_box(data) is False


class TestMakeFakeBox:
    def test_box_structure(self):
        box = make_fake_box(b"test", b"data")
        size = struct.unpack(">I", box[:4])[0]
        assert size == 12  # 8 header + 4 payload
        assert box[4:8] == b"test"
        assert box[8:] == b"data"

    def test_empty_payload(self):
        box = make_fake_box(b"test")
        size = struct.unpack(">I", box[:4])[0]
        assert size == 8


class TestMakeFakeFmp4:
    def test_default(self):
        data = make_fake_fmp4()
        assert is_valid_fmp4(data)
        assert find_box(data, b"ftyp") is not None
        assert find_box(data, b"moov") is not None

    def test_with_moof_mdat(self):
        data = make_fake_fmp4(include_moof=True, include_mdat=True)
        assert find_box(data, b"moof") is not None
        assert find_box(data, b"mdat") is not None


class TestAssertManifestValidMpd:
    def test_valid(self):
        mpd = '<?xml version="1.0"?>\n<MPD xmlns="urn:mpeg:dash:schema:mpd:2011"></MPD>'
        assert_manifest_valid_mpd(mpd)  # should not raise

    def test_missing_xml_decl(self):
        with pytest.raises(AssertionError, match="XML declaration"):
            assert_manifest_valid_mpd("<MPD></MPD>")

    def test_missing_mpd_element(self):
        with pytest.raises(AssertionError, match="<MPD"):
            assert_manifest_valid_mpd('<?xml version="1.0"?>\n<Root></Root>')

    def test_missing_closing_tag(self):
        with pytest.raises(AssertionError, match="</MPD>"):
            assert_manifest_valid_mpd('<?xml version="1.0"?>\n<MPD>')


class TestAssertManifestValidM3u8:
    def test_valid(self):
        m3u8 = "#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:4.0,\nseg1.ts"
        assert_manifest_valid_m3u8(m3u8)  # should not raise

    def test_invalid(self):
        with pytest.raises(AssertionError, match="#EXTM3U"):
            assert_manifest_valid_m3u8("not a playlist")


class TestFixtures:
    def test_sample_webvtt(self, sample_webvtt: str):
        assert sample_webvtt.startswith("WEBVTT")
        assert "First cue" in sample_webvtt

    def test_sample_ttml(self, sample_ttml: str):
        assert sample_ttml.startswith("<?xml")
        assert "First cue" in sample_ttml

    def test_sample_video_mp4(self, sample_video_mp4: bytes):
        assert len(sample_video_mp4) > 0
        assert is_valid_fmp4(sample_video_mp4)

    def test_sample_audio_only(self, sample_audio_only_mp4: bytes):
        assert len(sample_audio_only_mp4) > 0

    def test_sample_init_segment(self, sample_init_segment: bytes):
        assert len(sample_init_segment) > 0
        assert find_box(sample_init_segment, b"ftyp") is not None

    def test_sample_media_segment(self, sample_media_segment: bytes):
        assert len(sample_media_segment) > 0

    def test_encryption_key(self, encryption_key: str):
        assert len(encryption_key) == 32

    def test_encryption_key_id(self, encryption_key_id: str):
        assert len(encryption_key_id) == 32

    def test_tmp_output_dir(self, tmp_output_dir: Path):
        assert tmp_output_dir.is_dir()


class TestNativeMarkerSkip:
    """Verify the native marker auto-skip mechanism."""

    @pytest.mark.native
    def test_would_skip_without_native(self):
        """This test should be skipped if _pyshaka_cpp is not importable."""
        try:
            import pyshaka._pyshaka_cpp  # noqa: F401
        except ImportError:
            pytest.fail("Should have been auto-skipped by conftest")
