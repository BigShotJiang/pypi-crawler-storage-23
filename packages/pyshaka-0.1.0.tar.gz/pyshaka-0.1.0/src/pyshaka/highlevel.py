"""High-level convenience functions for common packaging workflows.

These are thin wrappers around :class:`Packager` for the most common
use cases: encrypt, decrypt, package subtitles, and create trick play streams.

Example
-------
>>> from pyshaka import Package
>>> results = Package(
...     inputs=["video.mp4"],
...     stream_descriptors=["in=video.mp4,stream=video,output=video_enc.mp4"],
...     encryption=EncryptionConfig(
...         key_id="00112233445566778899aabbccddeeff",
...         key="ffeeddccbbaa99887766554433221100",
...     ),
... )
"""

from __future__ import annotations

from pyshaka.config import (
    DecryptionConfig,
    EncryptionConfig,
    PackagingConfig,
    ProtectionScheme,
    StreamConfig,
)
from pyshaka.packager import Packager, PackagerResult


def encrypt(
    data: bytes,
    *,
    key_id: str,
    key: str,
    iv: str | None = None,
    stream_type: str = "video",
    protection_scheme: ProtectionScheme = ProtectionScheme.CBCS,
) -> bytes:
    """Encrypt a single segment with raw keys. Returns encrypted bytes.

    This is the simplest one-call encryption API.

    Parameters
    ----------
    data : bytes
        Raw fMP4 segment.
    key_id : str
        32-char hex key ID.
    key : str
        32-char hex content key.
    iv : str, optional
        32-char hex IV.
    stream_type : str
        "video", "audio", or "text".
    protection_scheme : ProtectionScheme
        CBCS (default) or CENC.

    Returns
    -------
    bytes
        Encrypted segment data.
    """
    packager = Packager()
    result = packager.encrypt_segment(
        input_data=data,
        stream_type=stream_type,
        protection_scheme=protection_scheme,
        key_id=key_id,
        key=key,
        iv=iv,
    )
    return result.data


def decrypt(
    data: bytes,
    *,
    key_id: str,
    key: str,
    stream_type: str = "video",
) -> bytes:
    """Decrypt a single segment with raw keys. Returns decrypted bytes.

    Parameters
    ----------
    data : bytes
        Encrypted fMP4 segment.
    key_id : str
        32-char hex key ID.
    key : str
        32-char hex content key.
    stream_type : str
        "video", "audio", or "text".

    Returns
    -------
    bytes
        Decrypted segment data.
    """
    packager = Packager()
    result = packager.decrypt_segment(
        input_data=data,
        stream_type=stream_type,
        key_id=key_id,
        key=key,
    )
    return result.data


def package_bytes(
    data: bytes,
    *,
    config: PackagingConfig | None = None,
    stream_type: str = "video",
    encryption: EncryptionConfig | None = None,
) -> PackagerResult:
    """Package a single media buffer using the given config.

    Higher-level than :meth:`Packager.encrypt_segment` — accepts a
    ``PackagingConfig`` with all options grouped together.

    Parameters
    ----------
    data : bytes
        Raw media data.
    config : PackagingConfig, optional
        Full configuration. If None, uses defaults.
    stream_type : str
        Stream type to process.
    encryption : EncryptionConfig, optional
        Encryption config (shorthand; overrides config.encryption).

    Returns
    -------
    PackagerResult
    """
    packager = Packager()

    enc = encryption
    if enc is None and config is not None:
        enc = config.encryption

    return packager.encrypt_segment(
        input_data=data,
        stream_type=stream_type,
        encryption=enc,
    )


def package(
    *,
    streams: list[StreamConfig] | None = None,
    config: PackagingConfig | None = None,
    encryption: EncryptionConfig | None = None,
    decryption: DecryptionConfig | None = None,
    input_files: dict[str, bytes] | None = None,
) -> dict[str, PackagerResult]:
    """Multi-stream packaging with named inputs/outputs.

    This is the most flexible high-level API, supporting multiple
    streams, mixed encryption/decryption, and named output collection.

    Parameters
    ----------
    streams : list[StreamConfig], optional
        Stream descriptors to process.
    config : PackagingConfig, optional
        Full configuration.
    encryption : EncryptionConfig, optional
        Encryption config (overrides config.encryption).
    decryption : DecryptionConfig, optional
        Decryption config (overrides config.decryption).
    input_files : dict[str, bytes], optional
        Named input buffers.

    Returns
    -------
    dict[str, PackagerResult]
        Results keyed by stream type / output name.
    """
    if config is None:
        config = PackagingConfig()

    if streams is None:
        streams = config.streams

    enc = encryption or config.encryption
    dec = decryption or config.decryption

    packager = Packager(single_threaded=config.single_threaded)
    results: dict[str, PackagerResult] = {}

    if input_files:
        for name, data in input_files.items():
            stream_type = "video"  # infer from name
            for s in streams:
                if s.stream_type in name or name in (s.hls_playlist_name or ""):
                    stream_type = s.stream_type
                    break

            if enc:
                result = packager.encrypt_segment(
                    input_data=data,
                    stream_type=stream_type,
                    encryption=enc,
                )
            elif dec:
                result = packager.decrypt_segment(
                    input_data=data,
                    stream_type=stream_type,
                    decryption=dec,
                )
            else:
                result = PackagerResult(data=data)

            results[name] = result

    return results
