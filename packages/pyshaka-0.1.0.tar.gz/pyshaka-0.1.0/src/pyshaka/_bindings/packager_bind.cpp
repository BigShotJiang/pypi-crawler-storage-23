// pyshaka — Packager class bindings
// SPDX-License-Identifier: BSD-3-Clause
//
// Adapter layer between Python-friendly types and real Shaka Packager C++ API.
// Python sets fields on simple wrapper structs; PackagerCore converts them
// to real shaka:: types before calling Initialize/Run.

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

// Real Shaka Packager public headers.
#include <packager/packager.h>
#include <packager/status.h>
#include <packager/buffer_callback_params.h>
#include <packager/crypto_params.h>
#include <packager/chunking_params.h>
#include <packager/mp4_output_params.h>
#include <packager/mpd_params.h>
#include <packager/hls_params.h>
#include <packager/ad_cue_generator_params.h>

namespace py = pybind11;

// ═══════════════════════════════════════════════════════════════════════
// Utility helpers
// ═══════════════════════════════════════════════════════════════════════

namespace {

std::vector<uint8_t> hex_to_bytes(const std::string& hex) {
    std::vector<uint8_t> bytes;
    bytes.reserve(hex.size() / 2);
    for (size_t i = 0; i + 1 < hex.size(); i += 2) {
        unsigned int byte = 0;
        std::sscanf(hex.c_str() + i, "%02x", &byte);
        bytes.push_back(static_cast<uint8_t>(byte));
    }
    return bytes;
}

uint32_t scheme_to_fourcc(const std::string& s) {
    if (s == "cbcs") return shaka::EncryptionParams::kProtectionSchemeCbcs;
    if (s == "cens") return shaka::EncryptionParams::kProtectionSchemeCens;
    if (s == "cbc1") return shaka::EncryptionParams::kProtectionSchemeCbc1;
    return shaka::EncryptionParams::kProtectionSchemeCenc;  // default
}

shaka::KeyProvider str_to_key_provider(const std::string& p) {
    if (p == "raw")       return shaka::KeyProvider::kRawKey;
    if (p == "widevine")  return shaka::KeyProvider::kWidevine;
    if (p == "playready") return shaka::KeyProvider::kPlayReady;
    return shaka::KeyProvider::kNone;
}

}  // anonymous namespace

// ═══════════════════════════════════════════════════════════════════════
// Python-facing wrapper types
//
// These have the SAME field names and types as the old placeholder structs
// so that the Python layer (packager.py) works unchanged.  They are
// converted to real shaka:: types inside PackagerCore.
// ═══════════════════════════════════════════════════════════════════════

namespace pyshaka {

// ── StatusResult ────────────────────────────────────────────────────
struct StatusResult {
    int error_code = 0;
    std::string error_message;
    bool ok() const { return error_code == 0; }
    std::string ToString() const {
        if (ok()) return "OK";
        return "Error(" + std::to_string(error_code) + "): " + error_message;
    }
};

// ── Buffer I/O ──────────────────────────────────────────────────────
struct BufferCallbackParams {
    // Python-side callbacks: read(name, position, size) -> bytes
    //                        write(name, bytes) -> None
    std::function<py::bytes(const std::string&, int64_t, uint64_t)> read_func;
    std::function<void(const std::string&, py::bytes)> write_func;
};

// ── Mp4OutputParams ─────────────────────────────────────────────────
struct Mp4OutputParams {
    bool include_pssh_in_stream = true;
    bool generate_sidx_in_media_segments = true;
    bool low_latency_dash_mode = false;
};

// ── ChunkingParams ──────────────────────────────────────────────────
struct ChunkingParams {
    double segment_duration_in_seconds = 4.0;
    double subsegment_duration_in_seconds = 0.0;
    bool segment_sap_aligned = true;
    bool subsegment_sap_aligned = true;
    int start_segment_number = 1;
    bool low_latency_dash_mode = false;
};

// ── UtcTiming ───────────────────────────────────────────────────────
struct UtcTiming {
    std::string scheme_id_uri;
    std::string value;
};

// ── MpdParams ───────────────────────────────────────────────────────
struct MpdParams {
    std::string mpd_output;
    std::vector<std::string> base_urls;
    double min_buffer_time = 2.0;
    double minimum_update_period = 0.0;
    double suggested_presentation_delay = 0.0;
    double time_shift_buffer_depth = 0.0;
    uint32_t preserved_segments_outside_live_window = 0;
    std::vector<UtcTiming> utc_timings;
    std::string default_language;
    std::string default_text_language;
    bool generate_static_live_mpd = false;
    bool generate_dash_if_iop_compliant_mpd = true;
    bool allow_approximate_segment_timeline = false;
    bool allow_codec_switching = false;
    bool include_mspr_pro = true;
    bool use_segment_list = false;
    bool low_latency_dash_mode = false;
    double target_latency_seconds = 0.0;
};

// ── HlsPlaylistType ────────────────────────────────────────────────
enum class HlsPlaylistType { VOD = 0, EVENT = 1, LIVE = 2 };

// ── HlsParams ───────────────────────────────────────────────────────
struct HlsParams {
    std::string master_playlist_output;
    std::string base_url;
    HlsPlaylistType playlist_type = HlsPlaylistType::VOD;
    std::string key_uri;
    double time_shift_buffer_depth = 0.0;
    uint32_t preserved_segments_outside_live_window = 0;
    std::string default_language;
    std::string default_text_language;
    bool is_independent_segments = true;
    int media_sequence_number = 0;
    double start_time_offset = 0.0;
    bool create_session_keys = false;
    bool add_program_date_time = false;
};

// ── TestParams ──────────────────────────────────────────────────────
struct TestParams {
    bool dump_stream_info = false;
    bool inject_fake_clock = false;
    std::string injected_library_version;
};

// ── Cuepoint ────────────────────────────────────────────────────────
struct Cuepoint {
    double start_time_in_seconds = 0.0;
    double duration_in_seconds = 0.0;
};

struct AdCueGeneratorParams {
    std::vector<Cuepoint> cue_points;
};

// ── DecryptionParams (Python-friendly) ──────────────────────────────
struct DecryptionParams {
    std::string key_provider;
    std::string key_id;
    std::string key;
    std::string widevine_key_server_url;
    std::string content_id;
    std::string signer;
    std::string signing_key;
    std::string signing_iv;
};

// ── EncryptionParams (Python-friendly) ──────────────────────────────
struct EncryptionParams {
    std::string key_provider;
    std::string key_id;
    std::string key;
    std::string iv;
    std::string protection_scheme;
    double clear_lead = 0.0;
    uint32_t protection_systems = 0;
    uint8_t crypt_byte_block = 0;
    uint8_t skip_byte_block = 0;
    bool vp9_subsample_encryption = false;
    double crypto_period_duration_in_seconds = 0.0;
    std::function<std::string(const std::string&)> stream_label_func;
    std::string playready_extra_header_data;
    std::string widevine_key_server_url;
    std::string content_id;
    std::string signer;
    std::string signing_key;
    std::string signing_iv;
    bool enable_cpix = false;
    std::string cpix_server_url;
};

// ── StreamDescriptor (Python-friendly — 25 fields) ──────────────────
struct StreamDescriptor {
    std::string input;
    std::string stream_selector;
    std::string output;
    std::string segment_template;
    std::string language;
    std::string output_format;
    std::string input_format;
    std::string init_segment;
    std::string hls_name;
    std::string hls_group_id;
    std::string hls_playlist_name;
    std::string hls_iframe_playlist_name;
    std::string hls_characteristics;
    bool hls_only = false;
    std::string dash_roles;
    std::string dash_accessibilities;
    bool dash_only = false;
    std::string dash_label;
    int trick_play_factor = 0;
    uint32_t bandwidth = 0;
    bool forced_subtitle = false;
    int cc_index = -1;
    bool skip_encryption = false;
    std::string drm_label;
    int index = 0;
};

// ── PackagingParams (Python-friendly) ───────────────────────────────
struct PackagingParams {
    ChunkingParams chunking_params;
    Mp4OutputParams mp4_output_params;
    MpdParams mpd_params;
    HlsParams hls_params;
    EncryptionParams encryption_params;
    DecryptionParams decryption_params;
    AdCueGeneratorParams ad_cue_generator_params;
    BufferCallbackParams buffer_callback_params;
    int transport_stream_timestamp_offset_ms = 0;
    bool output_media_info = false;
    bool single_threaded = true;
    std::string temp_dir;
    double default_text_zero_bias_ms = 0.0;
    TestParams test_params;
};

// ═══════════════════════════════════════════════════════════════════════
// Conversion: Python wrapper types  →  real shaka:: types
// ═══════════════════════════════════════════════════════════════════════

shaka::EncryptionParams to_shaka_enc(const EncryptionParams& py) {
    shaka::EncryptionParams s;
    s.key_provider = str_to_key_provider(py.key_provider);
    s.protection_scheme = scheme_to_fourcc(py.protection_scheme);
    s.clear_lead_in_seconds = py.clear_lead;
    s.protection_systems = static_cast<shaka::ProtectionSystem>(py.protection_systems);
    s.crypt_byte_block = py.crypt_byte_block;
    s.skip_byte_block = py.skip_byte_block;
    s.vp9_subsample_encryption = py.vp9_subsample_encryption;
    s.crypto_period_duration_in_seconds = py.crypto_period_duration_in_seconds;
    s.playready_extra_header_data = py.playready_extra_header_data;

    // Raw key params
    if (s.key_provider == shaka::KeyProvider::kRawKey) {
        shaka::RawKeyParams::KeyInfo ki;
        if (!py.key_id.empty()) ki.key_id = hex_to_bytes(py.key_id);
        if (!py.key.empty())    ki.key    = hex_to_bytes(py.key);
        if (!py.iv.empty())     ki.iv     = hex_to_bytes(py.iv);
        s.raw_key.key_map[""] = ki;  // default stream label
        if (!py.iv.empty()) s.raw_key.iv = hex_to_bytes(py.iv);
    }

    // Widevine
    if (s.key_provider == shaka::KeyProvider::kWidevine) {
        s.widevine.key_server_url = py.widevine_key_server_url;
        if (!py.content_id.empty())
            s.widevine.content_id.assign(py.content_id.begin(), py.content_id.end());
        if (!py.signer.empty()) {
            s.widevine.signer.signer_name = py.signer;
            s.widevine.signer.signing_key_type =
                shaka::WidevineSigner::SigningKeyType::kAes;
            if (!py.signing_key.empty())
                s.widevine.signer.aes.key = hex_to_bytes(py.signing_key);
            if (!py.signing_iv.empty())
                s.widevine.signer.aes.iv  = hex_to_bytes(py.signing_iv);
        }
    }

    // PlayReady
    if (s.key_provider == shaka::KeyProvider::kPlayReady) {
        s.playready.key_server_url = py.widevine_key_server_url;  // reused field
    }

    // Stream label function adapter
    if (py.stream_label_func) {
        auto func = py.stream_label_func;  // capture by value
        s.stream_label_func =
            [func](const shaka::EncryptionParams::EncryptedStreamAttributes& a)
                -> std::string {
            std::string type;
            switch (a.stream_type) {
                case shaka::EncryptionParams::EncryptedStreamAttributes::kVideo:
                    type = "video"; break;
                case shaka::EncryptionParams::EncryptedStreamAttributes::kAudio:
                    type = "audio"; break;
                default: type = "unknown"; break;
            }
            return func(type);
        };
    }
    return s;
}

shaka::DecryptionParams to_shaka_dec(const DecryptionParams& py) {
    shaka::DecryptionParams s;
    s.key_provider = str_to_key_provider(py.key_provider);

    if (s.key_provider == shaka::KeyProvider::kRawKey) {
        shaka::RawKeyParams::KeyInfo ki;
        if (!py.key_id.empty()) ki.key_id = hex_to_bytes(py.key_id);
        if (!py.key.empty())    ki.key    = hex_to_bytes(py.key);
        s.raw_key.key_map[""] = ki;
    }
    if (s.key_provider == shaka::KeyProvider::kWidevine) {
        s.widevine.key_server_url = py.widevine_key_server_url;
        if (!py.signer.empty()) {
            s.widevine.signer.signer_name = py.signer;
            s.widevine.signer.signing_key_type =
                shaka::WidevineSigner::SigningKeyType::kAes;
            if (!py.signing_key.empty())
                s.widevine.signer.aes.key = hex_to_bytes(py.signing_key);
            if (!py.signing_iv.empty())
                s.widevine.signer.aes.iv  = hex_to_bytes(py.signing_iv);
        }
    }
    return s;
}

shaka::StreamDescriptor to_shaka_stream(const StreamDescriptor& py) {
    shaka::StreamDescriptor s;
    s.input            = py.input;
    s.stream_selector  = py.stream_selector;
    s.output           = py.output;
    s.segment_template = py.segment_template;
    s.language         = py.language;
    s.output_format    = py.output_format;
    s.input_format     = py.input_format;
    s.hls_name         = py.hls_name;
    s.hls_group_id     = py.hls_group_id;
    s.hls_playlist_name        = py.hls_playlist_name;
    s.hls_iframe_playlist_name = py.hls_iframe_playlist_name;
    if (!py.hls_characteristics.empty())
        s.hls_characteristics = {py.hls_characteristics};
    s.hls_only = py.hls_only;
    if (!py.dash_roles.empty())
        s.dash_roles = {py.dash_roles};
    if (!py.dash_accessibilities.empty())
        s.dash_accessiblities = {py.dash_accessibilities};  // Shaka typo
    s.dash_only        = py.dash_only;
    s.dash_label       = py.dash_label;
    s.trick_play_factor = static_cast<uint32_t>(std::max(0, py.trick_play_factor));
    s.bandwidth        = py.bandwidth;
    s.forced_subtitle  = py.forced_subtitle;
    s.cc_index         = py.cc_index;
    s.skip_encryption  = py.skip_encryption;
    s.drm_label        = py.drm_label;
    if (py.index >= 0)
        s.index = static_cast<uint32_t>(py.index);
    return s;
}

// ═══════════════════════════════════════════════════════════════════════
// PackagerCore — thin wrapper around real shaka::Packager
// ═══════════════════════════════════════════════════════════════════════

class PackagerCore {
public:
    PackagerCore() = default;

    StatusResult initialize(
        const PackagingParams& py_params,
        const std::vector<StreamDescriptor>& py_streams)
    {
        // ── 1. Convert params ───────────────────────────────────────
        shaka::PackagingParams sp;

        // Chunking
        sp.chunking_params.segment_duration_in_seconds =
            py_params.chunking_params.segment_duration_in_seconds;
        sp.chunking_params.subsegment_duration_in_seconds =
            py_params.chunking_params.subsegment_duration_in_seconds;
        sp.chunking_params.segment_sap_aligned =
            py_params.chunking_params.segment_sap_aligned;
        sp.chunking_params.subsegment_sap_aligned =
            py_params.chunking_params.subsegment_sap_aligned;
        sp.chunking_params.start_segment_number =
            py_params.chunking_params.start_segment_number;
        sp.chunking_params.low_latency_dash_mode =
            py_params.chunking_params.low_latency_dash_mode;

        // MP4 output
        sp.mp4_output_params.include_pssh_in_stream =
            py_params.mp4_output_params.include_pssh_in_stream;
        sp.mp4_output_params.generate_sidx_in_media_segments =
            py_params.mp4_output_params.generate_sidx_in_media_segments;
        sp.mp4_output_params.low_latency_dash_mode =
            py_params.mp4_output_params.low_latency_dash_mode;

        // MPD
        sp.mpd_params.mpd_output = py_params.mpd_params.mpd_output;
        sp.mpd_params.base_urls  = py_params.mpd_params.base_urls;
        sp.mpd_params.min_buffer_time = py_params.mpd_params.min_buffer_time;
        sp.mpd_params.minimum_update_period =
            py_params.mpd_params.minimum_update_period;
        sp.mpd_params.suggested_presentation_delay =
            py_params.mpd_params.suggested_presentation_delay;
        sp.mpd_params.time_shift_buffer_depth =
            py_params.mpd_params.time_shift_buffer_depth;
        sp.mpd_params.preserved_segments_outside_live_window =
            py_params.mpd_params.preserved_segments_outside_live_window;
        for (const auto& ut : py_params.mpd_params.utc_timings)
            sp.mpd_params.utc_timings.push_back({ut.scheme_id_uri, ut.value});
        sp.mpd_params.default_language =
            py_params.mpd_params.default_language;
        sp.mpd_params.default_text_language =
            py_params.mpd_params.default_text_language;
        sp.mpd_params.generate_static_live_mpd =
            py_params.mpd_params.generate_static_live_mpd;
        sp.mpd_params.generate_dash_if_iop_compliant_mpd =
            py_params.mpd_params.generate_dash_if_iop_compliant_mpd;
        sp.mpd_params.allow_approximate_segment_timeline =
            py_params.mpd_params.allow_approximate_segment_timeline;
        sp.mpd_params.allow_codec_switching =
            py_params.mpd_params.allow_codec_switching;
        sp.mpd_params.include_mspr_pro =
            py_params.mpd_params.include_mspr_pro;
        sp.mpd_params.use_segment_list =
            py_params.mpd_params.use_segment_list;
        sp.mpd_params.low_latency_dash_mode =
            py_params.mpd_params.low_latency_dash_mode;
        sp.mpd_params.target_latency_seconds =
            py_params.mpd_params.target_latency_seconds;

        // HLS
        sp.hls_params.master_playlist_output =
            py_params.hls_params.master_playlist_output;
        sp.hls_params.base_url = py_params.hls_params.base_url;
        switch (py_params.hls_params.playlist_type) {
            case HlsPlaylistType::EVENT:
                sp.hls_params.playlist_type = shaka::HlsPlaylistType::kEvent;
                break;
            case HlsPlaylistType::LIVE:
                sp.hls_params.playlist_type = shaka::HlsPlaylistType::kLive;
                break;
            default:
                sp.hls_params.playlist_type = shaka::HlsPlaylistType::kVod;
                break;
        }
        sp.hls_params.key_uri = py_params.hls_params.key_uri;
        sp.hls_params.time_shift_buffer_depth =
            py_params.hls_params.time_shift_buffer_depth;
        sp.hls_params.preserved_segments_outside_live_window =
            py_params.hls_params.preserved_segments_outside_live_window;
        sp.hls_params.default_language =
            py_params.hls_params.default_language;
        sp.hls_params.default_text_language =
            py_params.hls_params.default_text_language;
        sp.hls_params.is_independent_segments =
            py_params.hls_params.is_independent_segments;
        sp.hls_params.media_sequence_number =
            static_cast<uint32_t>(py_params.hls_params.media_sequence_number);
        if (py_params.hls_params.start_time_offset != 0.0)
            sp.hls_params.start_time_offset = py_params.hls_params.start_time_offset;

        // Encryption / Decryption
        sp.encryption_params = to_shaka_enc(py_params.encryption_params);
        sp.decryption_params = to_shaka_dec(py_params.decryption_params);

        // Ad cues
        for (const auto& cp : py_params.ad_cue_generator_params.cue_points)
            sp.ad_cue_generator_params.cue_points.push_back(
                {cp.start_time_in_seconds, cp.duration_in_seconds});

        // ── 2. Buffer callback adapters ─────────────────────────────
        // Shaka uses void* I/O;  Python uses bytes.  We bridge them here.
        auto read_pos = std::make_shared<
            std::unordered_map<std::string, int64_t>>();

        const auto& pycb = py_params.buffer_callback_params;
        if (pycb.read_func) {
            auto py_read = pycb.read_func;  // capture by value
            sp.buffer_callback_params.read_func =
                [py_read, read_pos](const std::string& name,
                                    void* buffer, uint64_t size) -> int64_t {
                    py::gil_scoped_acquire acquire;
                    int64_t pos = (*read_pos)[name];
                    py::bytes result = py_read(name, pos, size);
                    std::string data(result);
                    size_t actual = std::min<size_t>(data.size(), size);
                    std::memcpy(buffer, data.data(), actual);
                    (*read_pos)[name] += static_cast<int64_t>(actual);
                    return static_cast<int64_t>(actual);
                };
        }
        if (pycb.write_func) {
            auto py_write = pycb.write_func;
            sp.buffer_callback_params.write_func =
                [py_write](const std::string& name,
                           const void* buffer, uint64_t size) -> int64_t {
                    py::gil_scoped_acquire acquire;
                    py::bytes data(static_cast<const char*>(buffer), size);
                    py_write(name, data);
                    return static_cast<int64_t>(size);
                };
        }

        // Misc
        sp.transport_stream_timestamp_offset_ms =
            py_params.transport_stream_timestamp_offset_ms;
        sp.output_media_info = py_params.output_media_info;
        sp.single_threaded   = py_params.single_threaded;
        sp.temp_dir          = py_params.temp_dir;
        sp.default_text_zero_bias_ms =
            static_cast<int32_t>(py_params.default_text_zero_bias_ms);
        sp.test_params.dump_stream_info =
            py_params.test_params.dump_stream_info;
        sp.test_params.inject_fake_clock =
            py_params.test_params.inject_fake_clock;
        sp.test_params.injected_library_version =
            py_params.test_params.injected_library_version;

        // Store converted params (keeps callback lambdas alive)
        shaka_params_ = std::move(sp);

        // ── 3. Convert stream descriptors ───────────────────────────
        std::vector<shaka::StreamDescriptor> streams;
        streams.reserve(py_streams.size());
        for (const auto& s : py_streams)
            streams.push_back(to_shaka_stream(s));

        // ── 4. Initialize real Shaka Packager ───────────────────────
        packager_ = std::make_unique<shaka::Packager>();
        auto status = packager_->Initialize(shaka_params_, streams);

        StatusResult r;
        r.error_code    = static_cast<int>(status.error_code());
        r.error_message = status.error_message();
        return r;
    }

    StatusResult run() {
        if (!packager_) {
            StatusResult r;
            r.error_code = 1;
            r.error_message = "Packager not initialized. Call initialize() first.";
            return r;
        }
        auto status = packager_->Run();
        StatusResult r;
        r.error_code    = static_cast<int>(status.error_code());
        r.error_message = status.error_message();
        return r;
    }

    void cancel() {
        if (packager_) packager_->Cancel();
    }

    static std::string get_library_version() {
        return shaka::Packager::GetLibraryVersion();
    }

private:
    std::unique_ptr<shaka::Packager> packager_;
    shaka::PackagingParams shaka_params_;  // must outlive Run()
};

}  // namespace pyshaka

// ═══════════════════════════════════════════════════════════════════════
// pybind11 bindings
// ═══════════════════════════════════════════════════════════════════════

void init_packager(py::module_& m) {

    // ── StatusResult ────────────────────────────────────────────────
    py::class_<pyshaka::StatusResult>(m, "Status",
        "Result of a Shaka Packager operation.")
        .def_readonly("error_code", &pyshaka::StatusResult::error_code)
        .def_readonly("error_message", &pyshaka::StatusResult::error_message)
        .def("ok", &pyshaka::StatusResult::ok)
        .def("__repr__", &pyshaka::StatusResult::ToString)
        .def("__bool__", &pyshaka::StatusResult::ok);

    // ── BufferCallbackParams ────────────────────────────────────────
    py::class_<pyshaka::BufferCallbackParams>(m, "BufferCallbackParams",
        "Callbacks for in-memory I/O.")
        .def(py::init<>())
        .def_readwrite("read_func", &pyshaka::BufferCallbackParams::read_func)
        .def_readwrite("write_func", &pyshaka::BufferCallbackParams::write_func);

    // ── Mp4OutputParams ─────────────────────────────────────────────
    py::class_<pyshaka::Mp4OutputParams>(m, "Mp4OutputParams",
        "MP4 output formatting options.")
        .def(py::init<>())
        .def_readwrite("include_pssh_in_stream", &pyshaka::Mp4OutputParams::include_pssh_in_stream)
        .def_readwrite("generate_sidx_in_media_segments", &pyshaka::Mp4OutputParams::generate_sidx_in_media_segments)
        .def_readwrite("low_latency_dash_mode", &pyshaka::Mp4OutputParams::low_latency_dash_mode);

    // ── ChunkingParams ──────────────────────────────────────────────
    py::class_<pyshaka::ChunkingParams>(m, "ChunkingParams",
        "Segmentation/chunking parameters.")
        .def(py::init<>())
        .def_readwrite("segment_duration_in_seconds", &pyshaka::ChunkingParams::segment_duration_in_seconds)
        .def_readwrite("subsegment_duration_in_seconds", &pyshaka::ChunkingParams::subsegment_duration_in_seconds)
        .def_readwrite("segment_sap_aligned", &pyshaka::ChunkingParams::segment_sap_aligned)
        .def_readwrite("subsegment_sap_aligned", &pyshaka::ChunkingParams::subsegment_sap_aligned)
        .def_readwrite("start_segment_number", &pyshaka::ChunkingParams::start_segment_number)
        .def_readwrite("low_latency_dash_mode", &pyshaka::ChunkingParams::low_latency_dash_mode);

    // ── UtcTiming ───────────────────────────────────────────────────
    py::class_<pyshaka::UtcTiming>(m, "UtcTiming",
        "UTC timing element for DASH manifests.")
        .def(py::init<>())
        .def_readwrite("scheme_id_uri", &pyshaka::UtcTiming::scheme_id_uri)
        .def_readwrite("value", &pyshaka::UtcTiming::value);

    // ── MpdParams ───────────────────────────────────────────────────
    py::class_<pyshaka::MpdParams>(m, "MpdParams",
        "DASH MPD manifest generation parameters.")
        .def(py::init<>())
        .def_readwrite("mpd_output", &pyshaka::MpdParams::mpd_output)
        .def_readwrite("base_urls", &pyshaka::MpdParams::base_urls)
        .def_readwrite("min_buffer_time", &pyshaka::MpdParams::min_buffer_time)
        .def_readwrite("minimum_update_period", &pyshaka::MpdParams::minimum_update_period)
        .def_readwrite("suggested_presentation_delay", &pyshaka::MpdParams::suggested_presentation_delay)
        .def_readwrite("time_shift_buffer_depth", &pyshaka::MpdParams::time_shift_buffer_depth)
        .def_readwrite("preserved_segments_outside_live_window", &pyshaka::MpdParams::preserved_segments_outside_live_window)
        .def_readwrite("utc_timings", &pyshaka::MpdParams::utc_timings)
        .def_readwrite("default_language", &pyshaka::MpdParams::default_language)
        .def_readwrite("default_text_language", &pyshaka::MpdParams::default_text_language)
        .def_readwrite("generate_static_live_mpd", &pyshaka::MpdParams::generate_static_live_mpd)
        .def_readwrite("generate_dash_if_iop_compliant_mpd", &pyshaka::MpdParams::generate_dash_if_iop_compliant_mpd)
        .def_readwrite("allow_approximate_segment_timeline", &pyshaka::MpdParams::allow_approximate_segment_timeline)
        .def_readwrite("allow_codec_switching", &pyshaka::MpdParams::allow_codec_switching)
        .def_readwrite("include_mspr_pro", &pyshaka::MpdParams::include_mspr_pro)
        .def_readwrite("use_segment_list", &pyshaka::MpdParams::use_segment_list)
        .def_readwrite("low_latency_dash_mode", &pyshaka::MpdParams::low_latency_dash_mode)
        .def_readwrite("target_latency_seconds", &pyshaka::MpdParams::target_latency_seconds);

    // ── HlsPlaylistType ─────────────────────────────────────────────
    py::enum_<pyshaka::HlsPlaylistType>(m, "HlsPlaylistType",
        "HLS playlist type.")
        .value("VOD",   pyshaka::HlsPlaylistType::VOD)
        .value("EVENT", pyshaka::HlsPlaylistType::EVENT)
        .value("LIVE",  pyshaka::HlsPlaylistType::LIVE)
        .export_values();

    // ── HlsParams ───────────────────────────────────────────────────
    py::class_<pyshaka::HlsParams>(m, "HlsParams",
        "HLS manifest generation parameters.")
        .def(py::init<>())
        .def_readwrite("master_playlist_output", &pyshaka::HlsParams::master_playlist_output)
        .def_readwrite("base_url", &pyshaka::HlsParams::base_url)
        .def_readwrite("playlist_type", &pyshaka::HlsParams::playlist_type)
        .def_readwrite("key_uri", &pyshaka::HlsParams::key_uri)
        .def_readwrite("time_shift_buffer_depth", &pyshaka::HlsParams::time_shift_buffer_depth)
        .def_readwrite("preserved_segments_outside_live_window", &pyshaka::HlsParams::preserved_segments_outside_live_window)
        .def_readwrite("default_language", &pyshaka::HlsParams::default_language)
        .def_readwrite("default_text_language", &pyshaka::HlsParams::default_text_language)
        .def_readwrite("is_independent_segments", &pyshaka::HlsParams::is_independent_segments)
        .def_readwrite("media_sequence_number", &pyshaka::HlsParams::media_sequence_number)
        .def_readwrite("start_time_offset", &pyshaka::HlsParams::start_time_offset)
        .def_readwrite("create_session_keys", &pyshaka::HlsParams::create_session_keys)
        .def_readwrite("add_program_date_time", &pyshaka::HlsParams::add_program_date_time);

    // ── TestParams ──────────────────────────────────────────────────
    py::class_<pyshaka::TestParams>(m, "TestParams",
        "Testing/debugging parameters.")
        .def(py::init<>())
        .def_readwrite("dump_stream_info", &pyshaka::TestParams::dump_stream_info)
        .def_readwrite("inject_fake_clock", &pyshaka::TestParams::inject_fake_clock)
        .def_readwrite("injected_library_version", &pyshaka::TestParams::injected_library_version);

    // ── Cuepoint ────────────────────────────────────────────────────
    py::class_<pyshaka::Cuepoint>(m, "Cuepoint",
        "Ad insertion cue point.")
        .def(py::init<>())
        .def_readwrite("start_time_in_seconds", &pyshaka::Cuepoint::start_time_in_seconds)
        .def_readwrite("duration_in_seconds", &pyshaka::Cuepoint::duration_in_seconds);

    // ── AdCueGeneratorParams ────────────────────────────────────────
    py::class_<pyshaka::AdCueGeneratorParams>(m, "AdCueGeneratorParams",
        "Ad cue point generation parameters.")
        .def(py::init<>())
        .def_readwrite("cue_points", &pyshaka::AdCueGeneratorParams::cue_points);

    // ── DecryptionParams ────────────────────────────────────────────
    py::class_<pyshaka::DecryptionParams>(m, "DecryptionParams",
        "Decryption parameters.")
        .def(py::init<>())
        .def_readwrite("key_provider", &pyshaka::DecryptionParams::key_provider)
        .def_readwrite("key_id", &pyshaka::DecryptionParams::key_id)
        .def_readwrite("key", &pyshaka::DecryptionParams::key)
        .def_readwrite("widevine_key_server_url", &pyshaka::DecryptionParams::widevine_key_server_url)
        .def_readwrite("content_id", &pyshaka::DecryptionParams::content_id)
        .def_readwrite("signer", &pyshaka::DecryptionParams::signer)
        .def_readwrite("signing_key", &pyshaka::DecryptionParams::signing_key)
        .def_readwrite("signing_iv", &pyshaka::DecryptionParams::signing_iv);

    // ── EncryptionParams ────────────────────────────────────────────
    py::class_<pyshaka::EncryptionParams>(m, "EncryptionParams",
        "Full encryption parameters including DRM provider config.")
        .def(py::init<>())
        .def_readwrite("key_provider", &pyshaka::EncryptionParams::key_provider)
        .def_readwrite("key_id", &pyshaka::EncryptionParams::key_id)
        .def_readwrite("key", &pyshaka::EncryptionParams::key)
        .def_readwrite("iv", &pyshaka::EncryptionParams::iv)
        .def_readwrite("protection_scheme", &pyshaka::EncryptionParams::protection_scheme)
        .def_readwrite("clear_lead", &pyshaka::EncryptionParams::clear_lead)
        .def_readwrite("protection_systems", &pyshaka::EncryptionParams::protection_systems)
        .def_readwrite("crypt_byte_block", &pyshaka::EncryptionParams::crypt_byte_block)
        .def_readwrite("skip_byte_block", &pyshaka::EncryptionParams::skip_byte_block)
        .def_readwrite("vp9_subsample_encryption", &pyshaka::EncryptionParams::vp9_subsample_encryption)
        .def_readwrite("crypto_period_duration_in_seconds", &pyshaka::EncryptionParams::crypto_period_duration_in_seconds)
        .def_readwrite("stream_label_func", &pyshaka::EncryptionParams::stream_label_func)
        .def_readwrite("playready_extra_header_data", &pyshaka::EncryptionParams::playready_extra_header_data)
        .def_readwrite("widevine_key_server_url", &pyshaka::EncryptionParams::widevine_key_server_url)
        .def_readwrite("content_id", &pyshaka::EncryptionParams::content_id)
        .def_readwrite("signer", &pyshaka::EncryptionParams::signer)
        .def_readwrite("signing_key", &pyshaka::EncryptionParams::signing_key)
        .def_readwrite("signing_iv", &pyshaka::EncryptionParams::signing_iv)
        .def_readwrite("enable_cpix", &pyshaka::EncryptionParams::enable_cpix)
        .def_readwrite("cpix_server_url", &pyshaka::EncryptionParams::cpix_server_url);

    // ── StreamDescriptor (25 fields) ────────────────────────────────
    py::class_<pyshaka::StreamDescriptor>(m, "StreamDescriptor",
        "Describes a single input/output stream for packaging.")
        .def(py::init<>())
        .def_readwrite("input", &pyshaka::StreamDescriptor::input)
        .def_readwrite("stream_selector", &pyshaka::StreamDescriptor::stream_selector)
        .def_readwrite("output", &pyshaka::StreamDescriptor::output)
        .def_readwrite("segment_template", &pyshaka::StreamDescriptor::segment_template)
        .def_readwrite("language", &pyshaka::StreamDescriptor::language)
        .def_readwrite("output_format", &pyshaka::StreamDescriptor::output_format)
        .def_readwrite("input_format", &pyshaka::StreamDescriptor::input_format)
        .def_readwrite("init_segment", &pyshaka::StreamDescriptor::init_segment)
        .def_readwrite("hls_name", &pyshaka::StreamDescriptor::hls_name)
        .def_readwrite("hls_group_id", &pyshaka::StreamDescriptor::hls_group_id)
        .def_readwrite("hls_playlist_name", &pyshaka::StreamDescriptor::hls_playlist_name)
        .def_readwrite("hls_iframe_playlist_name", &pyshaka::StreamDescriptor::hls_iframe_playlist_name)
        .def_readwrite("hls_characteristics", &pyshaka::StreamDescriptor::hls_characteristics)
        .def_readwrite("hls_only", &pyshaka::StreamDescriptor::hls_only)
        .def_readwrite("dash_roles", &pyshaka::StreamDescriptor::dash_roles)
        .def_readwrite("dash_accessibilities", &pyshaka::StreamDescriptor::dash_accessibilities)
        .def_readwrite("dash_only", &pyshaka::StreamDescriptor::dash_only)
        .def_readwrite("dash_label", &pyshaka::StreamDescriptor::dash_label)
        .def_readwrite("trick_play_factor", &pyshaka::StreamDescriptor::trick_play_factor)
        .def_readwrite("bandwidth", &pyshaka::StreamDescriptor::bandwidth)
        .def_readwrite("forced_subtitle", &pyshaka::StreamDescriptor::forced_subtitle)
        .def_readwrite("cc_index", &pyshaka::StreamDescriptor::cc_index)
        .def_readwrite("skip_encryption", &pyshaka::StreamDescriptor::skip_encryption)
        .def_readwrite("drm_label", &pyshaka::StreamDescriptor::drm_label)
        .def_readwrite("index", &pyshaka::StreamDescriptor::index);

    // ── PackagingParams ─────────────────────────────────────────────
    py::class_<pyshaka::PackagingParams>(m, "PackagingParams",
        "Top-level packaging configuration.")
        .def(py::init<>())
        .def_readwrite("chunking_params", &pyshaka::PackagingParams::chunking_params)
        .def_readwrite("mp4_output_params", &pyshaka::PackagingParams::mp4_output_params)
        .def_readwrite("mpd_params", &pyshaka::PackagingParams::mpd_params)
        .def_readwrite("hls_params", &pyshaka::PackagingParams::hls_params)
        .def_readwrite("encryption_params", &pyshaka::PackagingParams::encryption_params)
        .def_readwrite("decryption_params", &pyshaka::PackagingParams::decryption_params)
        .def_readwrite("ad_cue_generator_params", &pyshaka::PackagingParams::ad_cue_generator_params)
        .def_readwrite("buffer_callback_params", &pyshaka::PackagingParams::buffer_callback_params)
        .def_readwrite("transport_stream_timestamp_offset_ms", &pyshaka::PackagingParams::transport_stream_timestamp_offset_ms)
        .def_readwrite("output_media_info", &pyshaka::PackagingParams::output_media_info)
        .def_readwrite("single_threaded", &pyshaka::PackagingParams::single_threaded)
        .def_readwrite("temp_dir", &pyshaka::PackagingParams::temp_dir)
        .def_readwrite("default_text_zero_bias_ms", &pyshaka::PackagingParams::default_text_zero_bias_ms)
        .def_readwrite("test_params", &pyshaka::PackagingParams::test_params);

    // ── PackagerCore ────────────────────────────────────────────────
    py::class_<pyshaka::PackagerCore>(m, "PackagerCore",
        "Wrapper around shaka::Packager with Python-friendly types.")
        .def(py::init<>())
        .def("initialize", &pyshaka::PackagerCore::initialize,
            py::arg("params"), py::arg("streams"),
            "Initialize with PackagingParams and stream descriptors.")
        .def("run", &pyshaka::PackagerCore::run,
            py::call_guard<py::gil_scoped_release>(),
            "Run the packaging pipeline. Releases the GIL.")
        .def("cancel", &pyshaka::PackagerCore::cancel,
            "Cancel a running operation (thread-safe).")
        .def_static("get_library_version",
            &pyshaka::PackagerCore::get_library_version,
            "Return the Shaka Packager library version string.");
}
