// pyshaka — Encryption parameter bindings
// SPDX-License-Identifier: BSD-3-Clause
//
// Binds ProtectionScheme as a Python enum.  The full EncryptionParams
// binding lives in packager_bind.cpp alongside the other wrapper types.

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// C++ enum for pybind11 (maps to int values used by Python config layer).
// The adapter in packager_bind.cpp converts to real Shaka FourCC uint32_t codes.
enum ProtectionScheme : int {
    CENC = 0,
    CBCS = 1,
    CENS = 2,
    CBC1 = 3,
};

void init_encryption(py::module_& m) {

    // ── ProtectionScheme enum ───────────────────────────────────────
    py::enum_<ProtectionScheme>(m, "ProtectionScheme",
        "CENC/CBCS protection scheme identifiers.")
        .value("CENC", ProtectionScheme::CENC, "AES-CTR full-sample encryption (Widevine, PlayReady)")
        .value("CBCS", ProtectionScheme::CBCS, "AES-CBC pattern encryption (FairPlay, Widevine)")
        .value("CENS", ProtectionScheme::CENS, "AES-CTR subsample encryption")
        .value("CBC1", ProtectionScheme::CBC1, "AES-CBC full-sample encryption")
        .export_values();
}
