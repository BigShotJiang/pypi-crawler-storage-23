// pyshaka — Python bindings for Shaka Packager
// SPDX-License-Identifier: BSD-3-Clause
//
// Main pybind11 module definition. Each sub-module registers its own
// classes and enums via the init_*() functions declared below.

#include <pybind11/pybind11.h>

namespace py = pybind11;

// Forward declarations — implemented in sibling .cpp files
void init_packager(py::module_& m);
void init_stream_descriptor(py::module_& m);
void init_encryption(py::module_& m);

PYBIND11_MODULE(_pyshaka_cpp, m) {
    m.doc() = R"doc(
        pyshaka — Python bindings for Google's Shaka Packager.

        Provides in-memory CMAF/DASH/HLS encryption and packaging
        without subprocess overhead or temporary files.
    )doc";

    // Register types in dependency order
    init_encryption(m);
    init_stream_descriptor(m);
    init_packager(m);
}
