// pyshaka — StreamDescriptor bindings
// SPDX-License-Identifier: BSD-3-Clause
//
// StreamDescriptor is bound inline in packager_bind.cpp alongside
// the other Python-friendly wrapper types.  This file is reserved
// for future refactoring if the binding grows large enough to warrant
// splitting.

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

void init_stream_descriptor(py::module_& m) {
    // StreamDescriptor binding is in packager_bind.cpp.
    // This function intentionally left empty.
    (void)m;
}
