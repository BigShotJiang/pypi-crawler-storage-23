"""Configuration dataclasses for pyshaka."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Callable

# ── Enums ────────────────────────────────────────────────────────────


class ProtectionScheme(str, enum.Enum):
    """CENC/CBCS protection scheme identifiers.

    See ISO 23001-7 for full specification.
    """

    CENC = "cenc"
    """AES-CTR full-sample encryption. Used by Widevine and PlayReady."""

    CBCS = "cbcs"
    """AES-CBC pattern encryption. Required for FairPlay, supported by Widevine."""

    CENS = "cens"
    """AES-CTR subsample encryption."""

    CBC1 = "cbc1"
    """AES-CBC full-sample encryption."""


class KeyProvider(str, enum.Enum):
    """DRM key provider type."""

    RAW = "raw"
    """Direct key/key_id hex values."""

    WIDEVINE = "widevine"
    """Widevine key server."""

    PLAYREADY = "playready"
    """PlayReady key server."""

    CPIX = "cpix"
    """CPIX 2.x key exchange protocol (e.g., DRMtoday, PallyCon)."""


class ProtectionSystem(enum.IntFlag):
    """DRM protection system bitmask flags.

    Can be combined with ``|`` to enable multiple DRM systems::

        systems = ProtectionSystem.WIDEVINE | ProtectionSystem.PLAYREADY
    """

    COMMON = 0x01
    WIDEVINE = 0x02
    PLAYREADY = 0x04
    FAIRPLAY = 0x08
    MARLIN = 0x10


class HlsPlaylistType(str, enum.Enum):
    """HLS playlist type."""

    VOD = "vod"
    EVENT = "event"
    LIVE = "live"


# ── Encryption ───────────────────────────────────────────────────────


@dataclass(frozen=True)
class KeyInfo:
    """A single content key for multi-key encryption.

    Parameters
    ----------
    key_id : str
        32-char hex key ID.
    key : str
        32-char hex content key.
    iv : str, optional
        32-char hex IV. Auto-generated if omitted.
    """

    key_id: str = ""
    key: str = ""
    iv: str | None = None


@dataclass(frozen=True)
class EncryptionConfig:
    """Encryption parameters for a packaging operation.

    For raw key mode, provide ``key_id``, ``key``, and optionally ``iv``.
    For DRM server mode, set ``key_provider`` and the corresponding server fields.
    """

    protection_scheme: ProtectionScheme = ProtectionScheme.CBCS
    key_provider: KeyProvider = KeyProvider.RAW
    key_id: str | None = None
    key: str | None = None
    iv: str | None = None
    clear_lead: float = 0.0

    # Protection systems
    protection_systems: ProtectionSystem = ProtectionSystem.COMMON

    # Pattern encryption
    crypt_byte_block: int = 0
    skip_byte_block: int = 0
    vp9_subsample_encryption: bool = False

    # Key rotation
    crypto_period_duration: float = 0.0

    # Multi-key
    key_map: dict[str, KeyInfo] = field(default_factory=dict)

    # Stream label function
    stream_label_func: Callable[[str], str] | None = None

    # Widevine server fields
    widevine_key_server_url: str | None = None
    content_id: str | None = None
    signer: str | None = None
    signing_key: str | None = None
    signing_iv: str | None = None

    # PlayReady fields
    playready_extra_header_data: str | None = None

    # CPIX fields
    cpix_server_url: str | None = None

    def validate(self) -> None:
        """Validate configuration consistency.

        Raises
        ------
        ValueError
            If required fields for the selected key_provider are missing.
        """
        if self.key_provider == KeyProvider.RAW:
            if self.key_map:
                # Multi-key mode — validate each key
                for label, ki in self.key_map.items():
                    if not ki.key_id or not ki.key:
                        raise ValueError(f"key_map['{label}'] requires both 'key_id' and 'key'.")
                    if len(ki.key_id) != 32 or len(ki.key) != 32:
                        raise ValueError(f"key_map['{label}']: key_id and key must be 32-char hex.")
                    if ki.iv and len(ki.iv) != 32:
                        raise ValueError(f"key_map['{label}']: iv must be a 32-char hex string.")
            else:
                # Single-key mode
                if not self.key_id or not self.key:
                    raise ValueError(
                        "Raw key mode requires both 'key_id' and 'key' (32-char hex each)."
                    )
                if len(self.key_id) != 32 or len(self.key) != 32:
                    raise ValueError("key_id and key must be 32-character hex strings.")
                if self.iv and len(self.iv) != 32:
                    raise ValueError("iv must be a 32-character hex string.")

        elif self.key_provider == KeyProvider.WIDEVINE:
            if not self.widevine_key_server_url:
                raise ValueError("Widevine mode requires 'widevine_key_server_url'.")
            if not self.signer or not self.signing_key:
                raise ValueError("Widevine mode requires 'signer' and 'signing_key'.")

        elif self.key_provider == KeyProvider.PLAYREADY:
            if not self.widevine_key_server_url and not self.key_id:
                raise ValueError(
                    "PlayReady mode requires either a key server URL or raw key_id/key."
                )

        elif self.key_provider == KeyProvider.CPIX:
            if not self.cpix_server_url:
                raise ValueError("CPIX mode requires 'cpix_server_url'.")


# ── Decryption ───────────────────────────────────────────────────────


@dataclass(frozen=True)
class DecryptionConfig:
    """Decryption parameters.

    Parameters
    ----------
    key_provider : KeyProvider
        Key provider type (RAW or WIDEVINE).
    key_id : str, optional
        32-char hex key ID (raw mode).
    key : str, optional
        32-char hex content key (raw mode).
    key_map : dict, optional
        Multi-key mapping label → KeyInfo (raw mode).
    widevine_key_server_url : str, optional
        Widevine key server for decryption.
    """

    key_provider: KeyProvider = KeyProvider.RAW
    key_id: str | None = None
    key: str | None = None
    key_map: dict[str, KeyInfo] = field(default_factory=dict)

    # Widevine
    widevine_key_server_url: str | None = None
    content_id: str | None = None
    signer: str | None = None
    signing_key: str | None = None
    signing_iv: str | None = None

    def validate(self) -> None:
        """Validate decryption config."""
        if self.key_provider == KeyProvider.RAW:
            if self.key_map:
                for label, ki in self.key_map.items():
                    if not ki.key_id or not ki.key:
                        raise ValueError(f"key_map['{label}'] requires both 'key_id' and 'key'.")
            elif not self.key_id or not self.key:
                raise ValueError("Raw decryption requires 'key_id' and 'key'.")
        elif self.key_provider == KeyProvider.WIDEVINE:
            if not self.widevine_key_server_url:
                raise ValueError("Widevine decryption requires 'widevine_key_server_url'.")


# ── Segmentation ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class ChunkingConfig:
    """Segmentation/chunking parameters.

    Parameters
    ----------
    segment_duration : float
        Segment duration in seconds.
    subsegment_duration : float
        Subsegment duration (0 = no subsegments).
    segment_sap_aligned : bool
        Align segments at SAP (Stream Access Points).
    subsegment_sap_aligned : bool
        Align subsegments at SAP.
    start_segment_number : int
        First segment number.
    low_latency_dash_mode : bool
        Enable LL-DASH chunking.
    """

    segment_duration: float = 4.0
    subsegment_duration: float = 0.0
    segment_sap_aligned: bool = True
    subsegment_sap_aligned: bool = True
    start_segment_number: int = 1
    low_latency_dash_mode: bool = False

    def validate(self) -> None:
        """Validate chunking config."""
        if self.segment_duration <= 0:
            raise ValueError("segment_duration must be positive.")
        if self.subsegment_duration < 0:
            raise ValueError("subsegment_duration must be non-negative.")
        if self.subsegment_duration > self.segment_duration:
            raise ValueError("subsegment_duration cannot exceed segment_duration.")
        if self.start_segment_number < 0:
            raise ValueError("start_segment_number must be non-negative.")


# ── Mp4 Output ───────────────────────────────────────────────────────


@dataclass(frozen=True)
class Mp4OutputConfig:
    """MP4 output formatting options."""

    include_pssh_in_stream: bool = True
    generate_sidx_in_media_segments: bool = True
    low_latency_dash_mode: bool = False


# ── DASH ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class UtcTimingConfig:
    """UTC timing element for DASH manifests."""

    scheme_id_uri: str = ""
    value: str = ""


@dataclass(frozen=True)
class DashConfig:
    """DASH MPD manifest generation parameters."""

    mpd_output: str = ""
    base_urls: list[str] = field(default_factory=list)
    min_buffer_time: float = 2.0
    minimum_update_period: float = 0.0
    suggested_presentation_delay: float = 0.0
    time_shift_buffer_depth: float = 0.0
    preserved_segments_outside_live_window: int = 0
    utc_timings: list[UtcTimingConfig] = field(default_factory=list)
    default_language: str = ""
    default_text_language: str = ""
    generate_static_live_mpd: bool = False
    generate_dash_if_iop_compliant_mpd: bool = True
    allow_approximate_segment_timeline: bool = False
    allow_codec_switching: bool = False
    include_mspr_pro: bool = True
    use_segment_list: bool = False
    low_latency_dash_mode: bool = False
    target_latency_seconds: float = 0.0

    def validate(self) -> None:
        """Validate DASH config."""
        if self.min_buffer_time < 0:
            raise ValueError("min_buffer_time must be non-negative.")
        if self.time_shift_buffer_depth < 0:
            raise ValueError("time_shift_buffer_depth must be non-negative.")


# ── HLS ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class HlsConfig:
    """HLS manifest generation parameters."""

    master_playlist_output: str = ""
    base_url: str = ""
    playlist_type: HlsPlaylistType = HlsPlaylistType.VOD
    key_uri: str = ""
    time_shift_buffer_depth: float = 0.0
    preserved_segments_outside_live_window: int = 0
    default_language: str = ""
    default_text_language: str = ""
    is_independent_segments: bool = True
    media_sequence_number: int = 0
    start_time_offset: float = 0.0
    create_session_keys: bool = False
    add_program_date_time: bool = False

    def validate(self) -> None:
        """Validate HLS config."""
        if self.media_sequence_number < 0:
            raise ValueError("media_sequence_number must be non-negative.")


# ── Ad Insertion ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class CuePoint:
    """Ad insertion cue point.

    Parameters
    ----------
    start_time : float
        Start time in seconds.
    duration : float
        Duration in seconds (0 = unknown).
    """

    start_time: float = 0.0
    duration: float = 0.0


@dataclass(frozen=True)
class AdCueConfig:
    """Ad cue point generation parameters."""

    cue_points: list[CuePoint] = field(default_factory=list)

    def validate(self) -> None:
        """Validate ad cue config."""
        for i, cp in enumerate(self.cue_points):
            if cp.start_time < 0:
                raise ValueError(f"cue_points[{i}].start_time must be non-negative.")
            if cp.duration < 0:
                raise ValueError(f"cue_points[{i}].duration must be non-negative.")
        # Check sorted order
        for i in range(1, len(self.cue_points)):
            if self.cue_points[i].start_time < self.cue_points[i - 1].start_time:
                raise ValueError("cue_points must be sorted by start_time.")


# ── Streams ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class StreamConfig:
    """Describes a single stream to process.

    Parameters
    ----------
    stream_type : str
        One of "video", "audio", "text".
    language : str, optional
        BCP-47 language tag (e.g., "en", "pt-BR"). Required for audio/text.
    """

    stream_type: str = "video"
    language: str | None = None

    # Extended fields
    output_format: str | None = None
    cc_index: int = -1
    forced_subtitle: bool = False
    trick_play_factor: int = 0
    bandwidth: int = 0
    skip_encryption: bool = False
    drm_label: str | None = None

    # HLS fields
    hls_name: str | None = None
    hls_group_id: str | None = None
    hls_playlist_name: str | None = None
    hls_iframe_playlist_name: str | None = None
    hls_characteristics: str | None = None
    hls_only: bool = False

    # DASH fields
    dash_roles: str | None = None
    dash_accessibilities: str | None = None
    dash_only: bool = False
    dash_label: str | None = None

    def __post_init__(self) -> None:
        valid = {"video", "audio", "text"}
        if self.stream_type not in valid:
            raise ValueError(f"stream_type must be one of {valid}, got '{self.stream_type}'")


class TextStreamConfig(StreamConfig):
    """StreamConfig specialized for text/subtitle tracks.

    Example
    -------
    >>> config = TextStreamConfig(language="en", output_format="vtt+mp4")
    """

    def __init__(
        self,
        *,
        language: str = "en",
        output_format: str = "vtt+mp4",
        cc_index: int = -1,
        forced_subtitle: bool = False,
        hls_playlist_name: str | None = None,
        hls_characteristics: str | None = None,
        hls_only: bool = False,
        dash_roles: str | None = None,
        dash_accessibilities: str | None = None,
        dash_only: bool = False,
        dash_label: str | None = None,
    ) -> None:
        super().__init__(
            stream_type="text",
            language=language,
            output_format=output_format,
            cc_index=cc_index,
            forced_subtitle=forced_subtitle,
            hls_playlist_name=hls_playlist_name,
            hls_characteristics=hls_characteristics,
            hls_only=hls_only,
            dash_roles=dash_roles,
            dash_accessibilities=dash_accessibilities,
            dash_only=dash_only,
            dash_label=dash_label,
        )


# ── Top-Level Config ─────────────────────────────────────────────────


@dataclass
class PackagingConfig:
    """Top-level configuration combining streams and encryption.

    This is an alternative to passing parameters directly to
    :meth:`Packager.encrypt_segment`. Useful when processing multiple
    segments with the same settings.
    """

    encryption: EncryptionConfig | None = None
    decryption: DecryptionConfig | None = None
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    mp4_output: Mp4OutputConfig = field(default_factory=Mp4OutputConfig)
    dash: DashConfig | None = None
    hls: HlsConfig | None = None
    ad_cues: AdCueConfig | None = None
    streams: list[StreamConfig] = field(default_factory=lambda: [StreamConfig("video")])
    single_threaded: bool = True
    output_media_info: bool = False
    temp_dir: str = ""
