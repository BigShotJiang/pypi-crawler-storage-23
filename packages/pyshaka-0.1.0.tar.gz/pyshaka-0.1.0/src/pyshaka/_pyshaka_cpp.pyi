"""Type stubs for the native _pyshaka_cpp extension.

These provide IDE auto-completion and type checking even
when the native module isn't compiled.
"""

from __future__ import annotations

from typing import Callable

class Status:
    error_code: int
    error_message: str
    def ok(self) -> bool: ...
    def __bool__(self) -> bool: ...
    def __repr__(self) -> str: ...

class BufferCallbackParams:
    read_func: Callable[[str, int, int], bytes]
    write_func: Callable[[str, bytes], None]
    def __init__(self) -> None: ...

class Mp4OutputParams:
    include_pssh_in_stream: bool
    generate_sidx_in_media_segments: bool
    low_latency_dash_mode: bool
    def __init__(self) -> None: ...

class ChunkingParams:
    segment_duration_in_seconds: float
    subsegment_duration_in_seconds: float
    segment_sap_aligned: bool
    subsegment_sap_aligned: bool
    start_segment_number: int
    low_latency_dash_mode: bool
    def __init__(self) -> None: ...

class UtcTiming:
    scheme_id_uri: str
    value: str
    def __init__(self) -> None: ...

class MpdParams:
    mpd_output: str
    base_urls: list[str]
    min_buffer_time: float
    minimum_update_period: float
    suggested_presentation_delay: float
    time_shift_buffer_depth: float
    preserved_segments_outside_live_window: int
    utc_timings: list[UtcTiming]
    default_language: str
    default_text_language: str
    generate_static_live_mpd: bool
    generate_dash_if_iop_compliant_mpd: bool
    allow_approximate_segment_timeline: bool
    allow_codec_switching: bool
    include_mspr_pro: bool
    use_segment_list: bool
    low_latency_dash_mode: bool
    target_latency_seconds: float
    def __init__(self) -> None: ...

class HlsPlaylistType:
    VOD: int
    EVENT: int
    LIVE: int

class HlsParams:
    master_playlist_output: str
    base_url: str
    playlist_type: HlsPlaylistType
    key_uri: str
    time_shift_buffer_depth: float
    preserved_segments_outside_live_window: int
    default_language: str
    default_text_language: str
    is_independent_segments: bool
    media_sequence_number: int
    start_time_offset: float
    create_session_keys: bool
    add_program_date_time: bool
    def __init__(self) -> None: ...

class TestParams:
    dump_stream_info: bool
    inject_fake_clock: bool
    injected_library_version: str
    def __init__(self) -> None: ...

class Cuepoint:
    start_time_in_seconds: float
    duration_in_seconds: float
    def __init__(self) -> None: ...

class AdCueGeneratorParams:
    cue_points: list[Cuepoint]
    def __init__(self) -> None: ...

class DecryptionParams:
    key_provider: str
    key_id: str
    key: str
    widevine_key_server_url: str
    content_id: str
    signer: str
    signing_key: str
    signing_iv: str
    def __init__(self) -> None: ...

class EncryptionParams:
    key_provider: str
    key_id: str
    key: str
    iv: str
    protection_scheme: str
    clear_lead: float
    protection_systems: int
    crypt_byte_block: int
    skip_byte_block: int
    vp9_subsample_encryption: bool
    crypto_period_duration_in_seconds: float
    stream_label_func: Callable[[str], str] | None
    playready_extra_header_data: str
    widevine_key_server_url: str
    content_id: str
    signer: str
    signing_key: str
    signing_iv: str
    enable_cpix: bool
    cpix_server_url: str
    def __init__(self) -> None: ...

class StreamDescriptor:
    # Basic I/O
    input: str
    stream_selector: str
    output: str
    segment_template: str
    language: str
    # Output format
    output_format: str
    input_format: str
    init_segment: str
    # HLS fields
    hls_name: str
    hls_group_id: str
    hls_playlist_name: str
    hls_iframe_playlist_name: str
    hls_characteristics: str
    hls_only: bool
    # DASH fields
    dash_roles: str
    dash_accessibilities: str
    dash_only: bool
    dash_label: str
    # Trick play
    trick_play_factor: int
    # Stream properties
    bandwidth: int
    forced_subtitle: bool
    cc_index: int
    skip_encryption: bool
    drm_label: str
    index: int
    def __init__(self) -> None: ...

class PackagingParams:
    chunking_params: ChunkingParams
    mp4_output_params: Mp4OutputParams
    mpd_params: MpdParams
    hls_params: HlsParams
    encryption_params: EncryptionParams
    decryption_params: DecryptionParams
    ad_cue_generator_params: AdCueGeneratorParams
    buffer_callback_params: BufferCallbackParams
    transport_stream_timestamp_offset_ms: int
    output_media_info: bool
    single_threaded: bool
    temp_dir: str
    default_text_zero_bias_ms: float
    test_params: TestParams
    def __init__(self) -> None: ...

class PackagerCore:
    def __init__(self) -> None: ...
    def initialize(
        self,
        params: PackagingParams,
        streams: list[StreamDescriptor],
    ) -> Status: ...
    def initialize_with_callbacks(
        self,
        callback_params: BufferCallbackParams,
        streams: list[StreamDescriptor],
    ) -> Status: ...
    def run(self) -> Status: ...
    def cancel(self) -> None: ...
    @staticmethod
    def get_library_version() -> str: ...

class ProtectionScheme:
    CENC: int
    CBCS: int
    CENS: int
    CBC1: int
