"""pyshaka error hierarchy."""

from __future__ import annotations


class PyshakaError(Exception):
    """Base exception for all pyshaka errors."""


class PackagerNotInitializedError(PyshakaError):
    """Raised when operating on an uninitialized Packager."""


class EncryptionError(PyshakaError):
    """Raised when encryption fails."""

    def __init__(self, message: str, error_code: int = 0):
        self.error_code = error_code
        super().__init__(message)


class BuildError(PyshakaError):
    """Raised when the native extension is not available."""

    def __init__(self) -> None:
        super().__init__(
            "pyshaka native extension (_pyshaka_cpp) not found. "
            "Install from a pre-built wheel or build from source. "
            "See: https://github.com/horamarques/pyshaka#building-from-source"
        )
