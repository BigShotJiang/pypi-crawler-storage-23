"""High-level Packager API — the primary interface for pyshaka users."""

from __future__ import annotations

import io
import logging
from dataclasses import dataclass, field

from pyshaka.config import (
    DecryptionConfig,
    EncryptionConfig,
    KeyProvider,
    ProtectionScheme,
)
from pyshaka.errors import BuildError, EncryptionError

logger = logging.getLogger("pyshaka")

# Try to import the native extension.
try:
    from pyshaka import _pyshaka_cpp as _cpp
except ImportError:
    _cpp = None  # type: ignore[assignment]


@dataclass
class PackagerResult:
    """Result of a packaging/encryption operation.

    Attributes
    ----------
    data : bytes
        The encrypted/packaged segment data.
    init_data : bytes or None
        The initialization segment (ftyp+moov) if generated, else None.
    duration_ms : float
        Processing time in milliseconds.
    pssh_boxes : dict[str, bytes]
        PSSH boxes keyed by system ID.
    outputs : dict[str, bytes]
        Named output buffers (for multi-stream packaging).
    manifests : dict[str, str]
        Manifest outputs (MPD/m3u8 content).
    """

    data: bytes = b""
    init_data: bytes | None = None
    duration_ms: float = 0.0
    pssh_boxes: dict[str, bytes] = field(default_factory=dict)
    outputs: dict[str, bytes] = field(default_factory=dict)
    manifests: dict[str, str] = field(default_factory=dict)
    success: bool = True
    errors: list[str] = field(default_factory=list)


class Packager:
    """High-level Python interface to Shaka Packager.

    Wraps the C++ ``shaka::Packager`` class with Pythonic buffer I/O,
    automatic resource management, and type-safe configuration.
    """

    def __init__(self, *, single_threaded: bool = True) -> None:
        self._single_threaded = single_threaded
        self._core: object | None = None

    def _ensure_native(self) -> None:
        """Verify the native extension is available."""
        if _cpp is None:
            raise BuildError()

    @staticmethod
    def get_library_version() -> str:
        """Return the Shaka Packager library version string.

        Returns
        -------
        str
            Version string (e.g., "3.2.0-pyshaka").

        Raises
        ------
        BuildError
            If native extension is not available.
        """
        if _cpp is None:
            raise BuildError()
        return _cpp.PackagerCore.get_library_version()

    def encrypt_segment(
        self,
        input_data: bytes,
        *,
        stream_type: str = "video",
        encryption: EncryptionConfig | None = None,
        protection_scheme: str | ProtectionScheme | None = None,
        key_id: str | None = None,
        key: str | None = None,
        iv: str | None = None,
        clear_lead: float = 0.0,
        separate_init: bool = False,
    ) -> PackagerResult:
        """Encrypt a single CMAF segment in memory.

        Parameters
        ----------
        input_data : bytes
            Raw fMP4 segment data.
        stream_type : str
            One of "video", "audio", "text".
        encryption : EncryptionConfig, optional
            Full encryption configuration.
        protection_scheme, key_id, key, iv, clear_lead
            Shorthand params (override encryption fields).
        separate_init : bool
            If True, return init segment separately in ``result.init_data``.

        Returns
        -------
        PackagerResult
        """
        self._ensure_native()

        # Build or merge encryption config
        if encryption is None:
            scheme = (
                ProtectionScheme(protection_scheme) if protection_scheme else ProtectionScheme.CBCS
            )
            encryption = EncryptionConfig(
                protection_scheme=scheme,
                key_id=key_id,
                key=key,
                iv=iv,
                clear_lead=clear_lead,
            )
        else:
            if protection_scheme or key_id or key or iv:
                encryption = EncryptionConfig(
                    protection_scheme=(
                        ProtectionScheme(protection_scheme)
                        if protection_scheme
                        else encryption.protection_scheme
                    ),
                    key_provider=encryption.key_provider,
                    key_id=key_id or encryption.key_id,
                    key=key or encryption.key,
                    iv=iv or encryption.iv,
                    clear_lead=clear_lead if clear_lead else encryption.clear_lead,
                    protection_systems=encryption.protection_systems,
                    crypt_byte_block=encryption.crypt_byte_block,
                    skip_byte_block=encryption.skip_byte_block,
                    vp9_subsample_encryption=encryption.vp9_subsample_encryption,
                    crypto_period_duration=encryption.crypto_period_duration,
                    key_map=encryption.key_map,
                    stream_label_func=encryption.stream_label_func,
                    widevine_key_server_url=encryption.widevine_key_server_url,
                    content_id=encryption.content_id,
                    signer=encryption.signer,
                    signing_key=encryption.signing_key,
                    signing_iv=encryption.signing_iv,
                    playready_extra_header_data=encryption.playready_extra_header_data,
                    cpix_server_url=encryption.cpix_server_url,
                )

        encryption.validate()

        import time

        t0 = time.monotonic()

        # ── Set up in-memory buffer I/O ──────────────────────────────
        output_buffers: dict[str, io.BytesIO] = {}

        def read_callback(name: str, position: int, size: int) -> bytes:
            return input_data[position : position + size]

        def write_callback(name: str, data: bytes) -> None:
            if name not in output_buffers:
                output_buffers[name] = io.BytesIO()
            output_buffers[name].write(data)

        # ── Configure Shaka Packager ─────────────────────────────────
        buffer_params = _cpp.BufferCallbackParams()
        buffer_params.read_func = read_callback
        buffer_params.write_func = write_callback

        stream_desc = _cpp.StreamDescriptor()
        stream_desc.input = "buffer://input"
        stream_desc.stream_selector = stream_type
        stream_desc.output = "buffer://output"
        stream_desc.segment_template = ""

        enc_params = _cpp.EncryptionParams()
        enc_params.key_provider = encryption.key_provider.value
        enc_params.protection_scheme = encryption.protection_scheme.value
        if encryption.key_id:
            enc_params.key_id = encryption.key_id
        if encryption.key:
            enc_params.key = encryption.key
        if encryption.iv:
            enc_params.iv = encryption.iv
        enc_params.clear_lead = encryption.clear_lead
        enc_params.protection_systems = encryption.protection_systems.value
        enc_params.crypt_byte_block = encryption.crypt_byte_block
        enc_params.skip_byte_block = encryption.skip_byte_block
        enc_params.vp9_subsample_encryption = encryption.vp9_subsample_encryption
        enc_params.crypto_period_duration_in_seconds = encryption.crypto_period_duration

        if encryption.stream_label_func:
            enc_params.stream_label_func = encryption.stream_label_func

        # Server-side key providers
        if encryption.key_provider == KeyProvider.WIDEVINE:
            enc_params.widevine_key_server_url = encryption.widevine_key_server_url or ""
            enc_params.content_id = encryption.content_id or ""
            enc_params.signer = encryption.signer or ""
            enc_params.signing_key = encryption.signing_key or ""
            enc_params.signing_iv = encryption.signing_iv or ""
        elif encryption.key_provider == KeyProvider.CPIX:
            enc_params.enable_cpix = True
            enc_params.cpix_server_url = encryption.cpix_server_url or ""
        elif encryption.key_provider == KeyProvider.PLAYREADY:
            enc_params.playready_extra_header_data = encryption.playready_extra_header_data or ""

        # ── Build PackagingParams ────────────────────────────────────
        params = _cpp.PackagingParams()
        params.buffer_callback_params = buffer_params
        params.encryption_params = enc_params
        params.single_threaded = self._single_threaded

        # ── Run ──────────────────────────────────────────────────────
        core = _cpp.PackagerCore()
        status = core.initialize(params, [stream_desc])
        if not status.ok():
            raise EncryptionError(f"Packager initialization failed: {status}", status.error_code)

        status = core.run()
        if not status.ok():
            raise EncryptionError(f"Encryption failed: {status}", status.error_code)

        elapsed_ms = (time.monotonic() - t0) * 1000

        # ── Collect results ──────────────────────────────────────────
        main_output = b""
        init_output = None

        for name, buf in output_buffers.items():
            data = buf.getvalue()
            if separate_init and "init" in name:
                init_output = data
            else:
                main_output = data

        if not separate_init and not main_output:
            main_output = b"".join(buf.getvalue() for buf in output_buffers.values())

        logger.debug(
            "Encrypted %s segment: %d → %d bytes in %.1fms",
            stream_type,
            len(input_data),
            len(main_output),
            elapsed_ms,
        )

        return PackagerResult(
            data=main_output,
            init_data=init_output,
            duration_ms=elapsed_ms,
        )

    def encrypt_init_segment(
        self,
        init_data: bytes,
        *,
        stream_type: str = "video",
        encryption: EncryptionConfig | None = None,
        **kwargs,
    ) -> PackagerResult:
        """Encrypt just an initialization segment (ftyp+moov)."""
        return self.encrypt_segment(
            input_data=init_data,
            stream_type=stream_type,
            encryption=encryption,
            separate_init=False,
            **kwargs,
        )

    def decrypt_segment(
        self,
        input_data: bytes,
        *,
        stream_type: str = "video",
        decryption: DecryptionConfig | None = None,
        key_id: str | None = None,
        key: str | None = None,
    ) -> PackagerResult:
        """Decrypt a single CMAF segment in memory.

        Parameters
        ----------
        input_data : bytes
            Encrypted fMP4 segment data.
        stream_type : str
            One of "video", "audio", "text".
        decryption : DecryptionConfig, optional
            Full decryption configuration.
        key_id, key : str, optional
            Shorthand for raw key decryption.

        Returns
        -------
        PackagerResult
        """
        self._ensure_native()

        if decryption is None:
            decryption = DecryptionConfig(key_id=key_id, key=key)
        decryption.validate()

        import time

        t0 = time.monotonic()

        output_buffers: dict[str, io.BytesIO] = {}

        def read_callback(name: str, position: int, size: int) -> bytes:
            return input_data[position : position + size]

        def write_callback(name: str, data: bytes) -> None:
            if name not in output_buffers:
                output_buffers[name] = io.BytesIO()
            output_buffers[name].write(data)

        buffer_params = _cpp.BufferCallbackParams()
        buffer_params.read_func = read_callback
        buffer_params.write_func = write_callback

        stream_desc = _cpp.StreamDescriptor()
        stream_desc.input = "buffer://input"
        stream_desc.stream_selector = stream_type
        stream_desc.output = "buffer://output"

        dec_params = _cpp.DecryptionParams()
        dec_params.key_provider = decryption.key_provider.value
        if decryption.key_id:
            dec_params.key_id = decryption.key_id
        if decryption.key:
            dec_params.key = decryption.key

        if decryption.key_provider == KeyProvider.WIDEVINE:
            dec_params.widevine_key_server_url = decryption.widevine_key_server_url or ""
            dec_params.content_id = decryption.content_id or ""
            dec_params.signer = decryption.signer or ""
            dec_params.signing_key = decryption.signing_key or ""
            dec_params.signing_iv = decryption.signing_iv or ""

        params = _cpp.PackagingParams()
        params.buffer_callback_params = buffer_params
        params.decryption_params = dec_params
        params.single_threaded = self._single_threaded

        core = _cpp.PackagerCore()
        status = core.initialize(params, [stream_desc])
        if not status.ok():
            raise EncryptionError(f"Decryption initialization failed: {status}", status.error_code)

        status = core.run()
        if not status.ok():
            raise EncryptionError(f"Decryption failed: {status}", status.error_code)

        elapsed_ms = (time.monotonic() - t0) * 1000

        main_output = b""
        for buf in output_buffers.values():
            main_output = buf.getvalue()

        return PackagerResult(data=main_output, duration_ms=elapsed_ms)

    def package_subtitles(
        self,
        input_data: bytes | str,
        *,
        input_format: str = "webvtt",
        output_format: str = "vtt+mp4",
        language: str = "en",
    ) -> PackagerResult:
        """Package subtitle/text content into fMP4.

        Parameters
        ----------
        input_data : bytes or str
            Subtitle content (WebVTT or TTML).
        input_format : str
            Input format: "webvtt" or "ttml".
        output_format : str
            Output format: "vtt+mp4", "ttml+mp4", etc.
        language : str
            BCP-47 language tag.

        Returns
        -------
        PackagerResult
        """
        self._ensure_native()

        if isinstance(input_data, str):
            input_bytes = input_data.encode("utf-8")
        else:
            input_bytes = input_data

        import time

        t0 = time.monotonic()

        output_buffers: dict[str, io.BytesIO] = {}

        def read_callback(name: str, position: int, size: int) -> bytes:
            return input_bytes[position : position + size]

        def write_callback(name: str, data: bytes) -> None:
            if name not in output_buffers:
                output_buffers[name] = io.BytesIO()
            output_buffers[name].write(data)

        buffer_params = _cpp.BufferCallbackParams()
        buffer_params.read_func = read_callback
        buffer_params.write_func = write_callback

        stream_desc = _cpp.StreamDescriptor()
        stream_desc.input = "buffer://input"
        stream_desc.stream_selector = "text"
        stream_desc.output = "buffer://output"
        stream_desc.language = language
        stream_desc.input_format = input_format
        stream_desc.output_format = output_format

        params = _cpp.PackagingParams()
        params.buffer_callback_params = buffer_params
        params.single_threaded = self._single_threaded

        core = _cpp.PackagerCore()
        status = core.initialize(params, [stream_desc])
        if not status.ok():
            raise EncryptionError(f"Subtitle packaging failed: {status}", status.error_code)

        status = core.run()
        if not status.ok():
            raise EncryptionError(f"Subtitle packaging failed: {status}", status.error_code)

        elapsed_ms = (time.monotonic() - t0) * 1000
        main_output = b"".join(buf.getvalue() for buf in output_buffers.values())

        return PackagerResult(data=main_output, duration_ms=elapsed_ms)

    def extract_captions(
        self,
        input_data: bytes,
        *,
        cc_index: int = 0,
        output_format: str = "webvtt",
        language: str = "en",
    ) -> PackagerResult:
        """Extract embedded captions (CEA-608/708) from video.

        Parameters
        ----------
        input_data : bytes
            Video data with embedded captions.
        cc_index : int
            Caption channel index (0-3 for CEA-608).
        output_format : str
            Output format: "webvtt" or "ttml".
        language : str
            BCP-47 language tag.

        Returns
        -------
        PackagerResult
        """
        self._ensure_native()

        import time

        t0 = time.monotonic()

        output_buffers: dict[str, io.BytesIO] = {}

        def read_callback(name: str, position: int, size: int) -> bytes:
            return input_data[position : position + size]

        def write_callback(name: str, data: bytes) -> None:
            if name not in output_buffers:
                output_buffers[name] = io.BytesIO()
            output_buffers[name].write(data)

        buffer_params = _cpp.BufferCallbackParams()
        buffer_params.read_func = read_callback
        buffer_params.write_func = write_callback

        stream_desc = _cpp.StreamDescriptor()
        stream_desc.input = "buffer://input"
        stream_desc.stream_selector = "text"
        stream_desc.output = "buffer://output"
        stream_desc.language = language
        stream_desc.cc_index = cc_index
        stream_desc.output_format = output_format

        params = _cpp.PackagingParams()
        params.buffer_callback_params = buffer_params
        params.single_threaded = self._single_threaded

        core = _cpp.PackagerCore()
        status = core.initialize(params, [stream_desc])
        if not status.ok():
            raise EncryptionError(f"Caption extraction failed: {status}", status.error_code)

        status = core.run()
        if not status.ok():
            raise EncryptionError(f"Caption extraction failed: {status}", status.error_code)

        elapsed_ms = (time.monotonic() - t0) * 1000
        main_output = b"".join(buf.getvalue() for buf in output_buffers.values())

        return PackagerResult(data=main_output, duration_ms=elapsed_ms)

    def make_trick_play_stream(
        self,
        input_data: bytes,
        *,
        trick_play_factor: int = 2,
        hls_iframe_playlist_name: str = "",
    ) -> PackagerResult:
        """Create a trick play (I-frame only) stream.

        Parameters
        ----------
        input_data : bytes
            Video data.
        trick_play_factor : int
            Trick play factor (2 = every 2nd keyframe).
        hls_iframe_playlist_name : str
            Output HLS I-frame playlist name.

        Returns
        -------
        PackagerResult
        """
        self._ensure_native()

        import time

        t0 = time.monotonic()

        output_buffers: dict[str, io.BytesIO] = {}

        def read_callback(name: str, position: int, size: int) -> bytes:
            return input_data[position : position + size]

        def write_callback(name: str, data: bytes) -> None:
            if name not in output_buffers:
                output_buffers[name] = io.BytesIO()
            output_buffers[name].write(data)

        buffer_params = _cpp.BufferCallbackParams()
        buffer_params.read_func = read_callback
        buffer_params.write_func = write_callback

        stream_desc = _cpp.StreamDescriptor()
        stream_desc.input = "buffer://input"
        stream_desc.stream_selector = "video"
        stream_desc.output = "buffer://output"
        stream_desc.trick_play_factor = trick_play_factor
        if hls_iframe_playlist_name:
            stream_desc.hls_iframe_playlist_name = hls_iframe_playlist_name

        params = _cpp.PackagingParams()
        params.buffer_callback_params = buffer_params
        params.single_threaded = self._single_threaded

        core = _cpp.PackagerCore()
        status = core.initialize(params, [stream_desc])
        if not status.ok():
            raise EncryptionError(f"Trick play generation failed: {status}", status.error_code)

        status = core.run()
        if not status.ok():
            raise EncryptionError(f"Trick play generation failed: {status}", status.error_code)

        elapsed_ms = (time.monotonic() - t0) * 1000
        main_output = b"".join(buf.getvalue() for buf in output_buffers.values())

        return PackagerResult(data=main_output, duration_ms=elapsed_ms)
