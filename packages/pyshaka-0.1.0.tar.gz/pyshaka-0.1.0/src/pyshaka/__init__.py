"""
pyshaka — Python bindings for Google's Shaka Packager.

Provides in-memory CMAF/DASH/HLS encryption and packaging
without subprocess overhead or temporary files.

Example
-------
>>> from pyshaka import Packager, EncryptionConfig
>>>
>>> packager = Packager()
>>> result = packager.encrypt_segment(
...     input_data=segment_bytes,
...     stream_type="video",
...     protection_scheme="cbcs",
...     key_id="00112233445566778899aabbccddeeff",
...     key="ffeeddccbbaa99887766554433221100",
... )
>>> encrypted_bytes = result.data
"""

from __future__ import annotations

__version__ = "0.1.0"
__all__ = [
    # Core
    "Packager",
    "PackagerResult",
    # High-level
    "encrypt",
    "decrypt",
    "package",
    "package_bytes",
    # Enums
    "ProtectionScheme",
    "KeyProvider",
    "ProtectionSystem",
    "HlsPlaylistType",
    # Encryption / Decryption
    "EncryptionConfig",
    "DecryptionConfig",
    "KeyInfo",
    # Segmentation / Output
    "ChunkingConfig",
    "Mp4OutputConfig",
    # Manifests
    "DashConfig",
    "HlsConfig",
    "UtcTimingConfig",
    # Streams
    "StreamConfig",
    "TextStreamConfig",
    # Ad Insertion
    "CuePoint",
    "AdCueConfig",
    # Top-level
    "PackagingConfig",
    # Errors
    "PyshakaError",
    "PackagerNotInitializedError",
    "EncryptionError",
    "BuildError",
]

from pyshaka.config import (
    AdCueConfig,
    ChunkingConfig,
    CuePoint,
    DashConfig,
    DecryptionConfig,
    EncryptionConfig,
    HlsConfig,
    HlsPlaylistType,
    KeyInfo,
    KeyProvider,
    Mp4OutputConfig,
    PackagingConfig,
    ProtectionScheme,
    ProtectionSystem,
    StreamConfig,
    TextStreamConfig,
    UtcTimingConfig,
)
from pyshaka.errors import BuildError, EncryptionError, PackagerNotInitializedError, PyshakaError
from pyshaka.highlevel import decrypt, encrypt, package, package_bytes
from pyshaka.packager import Packager, PackagerResult
