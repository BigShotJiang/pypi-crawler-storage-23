# Contributing to pyshaka

Thank you for your interest in contributing to pyshaka!

## Development Setup

```bash
# Clone the repo
git clone --recursive https://github.com/horamarques/pyshaka.git
cd pyshaka

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate

# Install dev dependencies
pip install -e ".[dev]"
```

## Running Tests

```bash
# Run all pure-Python tests (no native extension needed)
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=pyshaka --cov-report=html
```

## Building the Native Extension

To test with the actual C++ bindings, you need to build Shaka Packager first:

```bash
# Build Shaka Packager (takes ~10-20 min)
bash scripts/build_shaka_linux.sh   # Linux
bash scripts/build_shaka_macos.sh   # macOS

# Build the extension
pip install -e .
```

## Code Style

We use [ruff](https://github.com/astral-sh/ruff) for linting and formatting:

```bash
ruff check src/ tests/
ruff format src/ tests/
```

## Pull Request Process

1. Fork the repo and create your branch from `main`
2. Add tests for any new functionality
3. Ensure all tests pass: `pytest tests/ -v`
4. Ensure code passes lint: `ruff check src/ tests/`
5. Update documentation if you changed the public API
6. Open a PR with a clear description

## Reporting Issues

- Use GitHub Issues for bug reports and feature requests
- Include your Python version, OS, and Shaka Packager version
- For build issues, include the full build log

## Architecture Overview

```
src/pyshaka/
├── __init__.py          # Public API exports
├── config.py            # EncryptionConfig, StreamConfig, etc.
├── errors.py            # Exception hierarchy
├── packager.py          # High-level Packager class
├── _pyshaka_cpp.pyi     # Type stubs for native extension
└── _bindings/           # C++ pybind11 source
    ├── module.cpp        # Module definition
    ├── packager_bind.cpp # Packager + BufferCallbackParams
    ├── stream_descriptor_bind.cpp
    └── encryption_bind.cpp
```

## License

By contributing, you agree that your contributions will be licensed
under the BSD-3-Clause license.
