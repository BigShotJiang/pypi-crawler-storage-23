# Changelog

All notable changes to pyshaka will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project scaffolding
- Python wrapper API: `Packager`, `EncryptionConfig`, `StreamConfig`, `PackagerResult`
- Protection schemes: CENC, CBCS, CENS, CBC1
- Key providers: RAW, WIDEVINE, PLAYREADY, CPIX
- pybind11 C++ binding skeleton for `shaka::Packager`
- In-memory I/O via `BufferCallbackParams` (no temp files)
- CMake build system with scikit-build-core
- CI/CD with GitHub Actions + cibuildwheel
- Comprehensive test suite with mock native extension
- Type stubs (PEP 561) for IDE auto-completion
- Build scripts for Linux and macOS
