#!/usr/bin/env bash
# Generate minimal reference test media for pyshaka tests.
# Requires: FFmpeg
#
# Usage: bash scripts/generate_test_data.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${SCRIPT_DIR}/../tests/data"
mkdir -p "$DATA_DIR"

echo "==> Generating test media in $DATA_DIR"

# 2-second muxed video+audio fMP4
ffmpeg -y -f lavfi -i testsrc2=duration=2:size=320x240:rate=24 \
  -f lavfi -i sine=frequency=440:duration=2:sample_rate=48000 \
  -c:v libx264 -profile:v baseline -level 3.0 -pix_fmt yuv420p \
  -c:a aac -b:a 64k \
  -movflags +frag_keyframe+empty_moov+default_base_moof \
  "$DATA_DIR/sample.mp4"

# Video only
ffmpeg -y -f lavfi -i testsrc2=duration=2:size=320x240:rate=24 \
  -c:v libx264 -profile:v baseline -level 3.0 -pix_fmt yuv420p \
  -an -movflags +frag_keyframe+empty_moov+default_base_moof \
  "$DATA_DIR/sample_video.mp4"

# Audio only
ffmpeg -y -f lavfi -i sine=frequency=440:duration=2:sample_rate=48000 \
  -c:a aac -b:a 64k \
  -movflags +frag_keyframe+empty_moov+default_base_moof \
  "$DATA_DIR/sample_audio.mp4"

echo "==> Done. Files in $DATA_DIR:"
ls -la "$DATA_DIR"
