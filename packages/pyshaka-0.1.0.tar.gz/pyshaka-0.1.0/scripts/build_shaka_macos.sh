#!/usr/bin/env bash
# Build Shaka Packager as a shared library on macOS.
# Called by cibuildwheel's before-all hook.
#
# Produces:
#   /tmp/shaka-packager/install/lib/libpackager.dylib
#   /tmp/shaka-packager/install/include/packager/*.h
#   /tmp/shaka-packager/install/lib/pkgconfig/packager.pc
set -euo pipefail

SHAKA_VERSION="${SHAKA_VERSION:-v3.2.0}"
INSTALL_DIR="/tmp/shaka-packager"

echo "==> Building Shaka Packager ${SHAKA_VERSION} for macOS"

# Install build dependencies
brew install cmake ninja pkg-config

# Skip rebuild if already installed (e.g. from CI cache)
if [ -f "${INSTALL_DIR}/install/lib/libpackager.dylib" ]; then
    echo "==> libpackager.dylib already installed, skipping build"
    exit 0
fi

# Clone Shaka Packager (with submodules for third_party deps)
if [ ! -d "${INSTALL_DIR}/.git" ]; then
    MAX_RETRIES=5
    for i in $(seq 1 $MAX_RETRIES); do
        echo "==> Clone attempt $i/$MAX_RETRIES"
        if git clone --depth 1 --branch "${SHAKA_VERSION}" --recurse-submodules --shallow-submodules \
            https://github.com/shaka-project/shaka-packager.git "${INSTALL_DIR}"; then
            break
        fi
        echo "==> Clone failed (attempt $i/$MAX_RETRIES), retrying in $((i * 30))s..."
        rm -rf "${INSTALL_DIR}"
        sleep $((i * 30))
        if [ "$i" -eq "$MAX_RETRIES" ]; then
            echo "==> All clone attempts failed"
            exit 1
        fi
    done
fi

cd "${INSTALL_DIR}"

# Build as shared library
# Require macOS 11.0+ (Big Sur) — needed for arm64 and for protobuf/abseil APIs
cmake -B build \
    -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_POSITION_INDEPENDENT_CODE=ON \
    -DBUILD_SHARED_LIBS=ON \
    -DCMAKE_INSTALL_PREFIX="${INSTALL_DIR}/install" \
    -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0 \
    -DSKIP_INTEGRATION_TESTS=ON

cmake --build build --parallel "$(sysctl -n hw.ncpu)"

# Install headers, library, and pkgconfig
cmake --install build

echo "==> Shaka Packager installed to ${INSTALL_DIR}/install"
echo "==> Libraries:"
find "${INSTALL_DIR}/install" -name 'libpackager*' -type f 2>/dev/null || true
echo "==> Headers:"
ls "${INSTALL_DIR}/install/include/packager/" 2>/dev/null | head -10 || true
