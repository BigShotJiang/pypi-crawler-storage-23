#!/usr/bin/env bash
# Build Shaka Packager as a shared library on Linux.
# Called by cibuildwheel's before-all hook.
#
# Produces:
#   /tmp/shaka-packager/install/lib/libpackager.so
#   /tmp/shaka-packager/install/include/packager/*.h
#   /tmp/shaka-packager/install/lib/pkgconfig/packager.pc
set -euo pipefail

SHAKA_VERSION="${SHAKA_VERSION:-v3.2.0}"
INSTALL_DIR="/tmp/shaka-packager"

echo "==> Building Shaka Packager ${SHAKA_VERSION} for Linux"

# Install build dependencies
if command -v apt-get &>/dev/null; then
    apt-get update -qq
    apt-get install -y -qq git cmake ninja-build g++ pkg-config \
        libcurl4-openssl-dev libglib2.0-dev zlib1g-dev
elif command -v yum &>/dev/null; then
    yum install -y git cmake3 ninja-build gcc-c++ pkgconfig \
        libcurl-devel glib2-devel zlib-devel
fi

# Skip rebuild if already installed (e.g. from CI cache)
if [ -f "${INSTALL_DIR}/install/lib/libpackager.so" ]; then
    echo "==> libpackager.so already installed, skipping build"
    exit 0
fi

# Clone Shaka Packager (with submodules for third_party deps)
if [ ! -d "${INSTALL_DIR}/.git" ]; then
    MAX_RETRIES=5
    for i in $(seq 1 $MAX_RETRIES); do
        echo "==> Clone attempt $i/$MAX_RETRIES"
        if git clone --depth 1 --branch "${SHAKA_VERSION}" --recurse-submodules --shallow-submodules \
            https://github.com/shaka-project/shaka-packager.git "${INSTALL_DIR}"; then
            break
        fi
        echo "==> Clone failed (attempt $i/$MAX_RETRIES), retrying in $((i * 30))s..."
        rm -rf "${INSTALL_DIR}"
        sleep $((i * 30))
        if [ "$i" -eq "$MAX_RETRIES" ]; then
            echo "==> All clone attempts failed"
            exit 1
        fi
    done
fi

cd "${INSTALL_DIR}"

# Build as shared library
cmake -B build \
    -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_POSITION_INDEPENDENT_CODE=ON \
    -DBUILD_SHARED_LIBS=ON \
    -DCMAKE_INSTALL_PREFIX="${INSTALL_DIR}/install" \
    -DCMAKE_INSTALL_LIBDIR=lib \
    -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
    -DSKIP_INTEGRATION_TESTS=ON

cmake --build build --parallel "$(nproc)"

# Install headers, library, and pkgconfig
cmake --install build

echo "==> Shaka Packager installed to ${INSTALL_DIR}/install"
echo "==> Libraries:"
find "${INSTALL_DIR}/install" -name 'libpackager*' -type f 2>/dev/null || true
echo "==> Headers:"
ls "${INSTALL_DIR}/install/include/packager/" 2>/dev/null | head -10 || true
