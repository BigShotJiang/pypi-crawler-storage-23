# pyshaka

**Python bindings for [Google's Shaka Packager](https://github.com/shaka-project/shaka-packager)** — CMAF/DASH/HLS encryption, decryption & packaging via pybind11.

[![CI](https://github.com/horamarques/pyshaka/actions/workflows/ci.yml/badge.svg)](https://github.com/horamarques/pyshaka/actions/workflows/ci.yml)
[![PyPI](https://img.shields.io/pypi/v/pyshaka)](https://pypi.org/project/pyshaka/)
[![Python](https://img.shields.io/pypi/pyversions/pyshaka)](https://pypi.org/project/pyshaka/)
[![License](https://img.shields.io/github/license/horamarques/pyshaka)](LICENSE)

---

## Features

- **In-memory I/O** — No temp files. Feed bytes in, get packaged bytes out.
- **~10x faster** than subprocess — eliminates spawn + file I/O overhead (~1-3 ms vs ~15-25 ms per segment).
- **Encryption & Decryption** — CENC, CBCS, CENS, CBC1. Multi-key, pattern encryption, key rotation.
- **Multi-DRM** — Widevine, FairPlay, PlayReady, Marlin, and CPIX key exchange.
- **DASH manifest generation** — MPD output with 18 configurable parameters, LL-DASH support.
- **HLS manifest generation** — Master + media playlists, VOD/EVENT/LIVE, I-frame playlists, session keys.
- **Subtitles** — WebVTT/TTML → fMP4 packaging, CEA-608/708 caption extraction.
- **Trick play** — I-frame only streams with configurable trick play factor.
- **Ad insertion** — SCTE-35 cue point generation with sorted, validated cue lists.
- **Live packaging** — Time-shift buffer, preserved segments, `EXT-X-PROGRAM-DATE-TIME`.
- **Segmentation control** — Segment/subsegment duration, SAP alignment, LL-DASH chunked mode.
- **Type-safe API** — Frozen dataclass configs with built-in validation, IDE auto-completion.
- **GIL-safe** — Releases the GIL during C++ execution.
- **High-level API** — One-call `encrypt()`, `decrypt()`, `package()`, `package_bytes()` functions.

---

## Installation

```bash
pip install pyshaka
```

Pre-built wheels for:
- **Linux**: x86_64 (manylinux)
- **macOS**: x86_64, arm64 (Apple Silicon)
- **Python**: 3.9 – 3.13

---

## Quick Start

### Encrypt a segment

```python
from pyshaka import Packager, ProtectionScheme

packager = Packager()
result = packager.encrypt_segment(
    input_data=segment_bytes,
    stream_type="video",
    protection_scheme=ProtectionScheme.CBCS,
    key_id="00112233445566778899aabbccddeeff",
    key="ffeeddccbbaa99887766554433221100",
)

encrypted = result.data
print(f"Encrypted in {result.duration_ms:.1f}ms")
```

### Decrypt a segment

```python
from pyshaka import Packager

packager = Packager()
result = packager.decrypt_segment(
    input_data=encrypted_bytes,
    stream_type="video",
    key_id="00112233445566778899aabbccddeeff",
    key="ffeeddccbbaa99887766554433221100",
)
original = result.data
```

### One-call high-level API

```python
from pyshaka import encrypt, decrypt

# Encrypt
ciphertext = encrypt(
    raw_segment,
    key_id="00112233445566778899aabbccddeeff",
    key="ffeeddccbbaa99887766554433221100",
)

# Decrypt
plaintext = decrypt(
    ciphertext,
    key_id="00112233445566778899aabbccddeeff",
    key="ffeeddccbbaa99887766554433221100",
)
```

---

## Encryption

### Raw keys with full config

```python
from pyshaka import Packager, EncryptionConfig, ProtectionScheme, KeyProvider

config = EncryptionConfig(
    protection_scheme=ProtectionScheme.CBCS,
    key_provider=KeyProvider.RAW,
    key_id="00112233445566778899aabbccddeeff",
    key="ffeeddccbbaa99887766554433221100",
    clear_lead=0.0,
)

packager = Packager()
result = packager.encrypt_segment(input_data=segment_bytes, encryption=config)
```

### Multi-key encryption

Assign different keys to video, audio, and text tracks:

```python
from pyshaka import EncryptionConfig, KeyInfo, ProtectionScheme

config = EncryptionConfig(
    protection_scheme=ProtectionScheme.CENC,
    key_map={
        "video": KeyInfo(
            key_id="00112233445566778899aabbccddeeff",
            key="ffeeddccbbaa99887766554433221100",
        ),
        "audio": KeyInfo(
            key_id="aabbccddeeff00112233445566778899",
            key="112233445566778899aabbccddeeff00",
        ),
    },
)
```

### Pattern encryption (CBCS)

Control the encrypt/skip byte block ratio:

```python
config = EncryptionConfig(
    protection_scheme=ProtectionScheme.CBCS,
    key_id="...",
    key="...",
    crypt_byte_block=1,   # encrypt 1 block
    skip_byte_block=9,    # skip 9 blocks (1:9 pattern)
)
```

### Key rotation

Rotate keys at a fixed interval:

```python
config = EncryptionConfig(
    key_id="...",
    key="...",
    crypto_period_duration=30.0,  # new key every 30 seconds
)
```

### Multi-DRM protection systems

Enable multiple DRM systems in a single encryption pass:

```python
from pyshaka import EncryptionConfig, ProtectionSystem

config = EncryptionConfig(
    key_id="...",
    key="...",
    protection_systems=ProtectionSystem.WIDEVINE | ProtectionSystem.PLAYREADY | ProtectionSystem.FAIRPLAY,
)
```

### Widevine key server

```python
config = EncryptionConfig(
    protection_scheme=ProtectionScheme.CENC,
    key_provider=KeyProvider.WIDEVINE,
    widevine_key_server_url="https://license.widevine.com/cenc/getkeys",
    content_id="my-content-id",
    signer="my-signer",
    signing_key="...",
)
```

### CPIX key exchange

```python
config = EncryptionConfig(
    key_provider=KeyProvider.CPIX,
    cpix_server_url="https://cpix.example.com/v2/keys",
)
```

---

## Decryption

### Raw key decryption

```python
from pyshaka import Packager, DecryptionConfig

config = DecryptionConfig(
    key_id="00112233445566778899aabbccddeeff",
    key="ffeeddccbbaa99887766554433221100",
)

packager = Packager()
result = packager.decrypt_segment(input_data=encrypted_bytes, decryption=config)
```

### Multi-key decryption

```python
from pyshaka import DecryptionConfig, KeyInfo

config = DecryptionConfig(
    key_map={
        "video": KeyInfo(key_id="...", key="..."),
        "audio": KeyInfo(key_id="...", key="..."),
    },
)
```

### Widevine server decryption

```python
config = DecryptionConfig(
    key_provider=KeyProvider.WIDEVINE,
    widevine_key_server_url="https://license.widevine.com/cenc/getkeys",
    signer="my-signer",
    signing_key="...",
)
```

---

## DASH Manifests

Generate DASH MPD manifests with full control over timing and presentation:

```python
from pyshaka import DashConfig, UtcTimingConfig

dash = DashConfig(
    mpd_output="output.mpd",
    base_urls=["https://cdn.example.com/"],
    min_buffer_time=2.0,
    minimum_update_period=5.0,
    suggested_presentation_delay=10.0,
    time_shift_buffer_depth=300.0,
    default_language="en",
    generate_dash_if_iop_compliant_mpd=True,
    allow_codec_switching=True,
    utc_timings=[
        UtcTimingConfig(
            scheme_id_uri="urn:mpeg:dash:utc:http-xsdate:2014",
            value="https://time.example.com/now",
        ),
    ],
)
```

### Low-latency DASH

```python
dash = DashConfig(
    mpd_output="ll-dash.mpd",
    low_latency_dash_mode=True,
    target_latency_seconds=3.0,
    minimum_update_period=1.0,
    suggested_presentation_delay=3.0,
)
```

---

## HLS Manifests

Generate HLS master + media playlists:

```python
from pyshaka import HlsConfig, HlsPlaylistType

hls = HlsConfig(
    master_playlist_output="master.m3u8",
    base_url="https://cdn.example.com/",
    playlist_type=HlsPlaylistType.VOD,
    default_language="en",
    is_independent_segments=True,
)
```

### Live HLS with DVR window

```python
hls = HlsConfig(
    master_playlist_output="live.m3u8",
    playlist_type=HlsPlaylistType.LIVE,
    time_shift_buffer_depth=900.0,        # 15-minute DVR window
    preserved_segments_outside_live_window=3,
    add_program_date_time=True,
)
```

### Encrypted HLS with session keys

```python
hls = HlsConfig(
    master_playlist_output="master.m3u8",
    key_uri="skd://content-id",            # FairPlay key URI
    create_session_keys=True,
)
```

---

## Subtitles

### Package WebVTT/TTML into fMP4

```python
packager = Packager()
result = packager.package_subtitles(
    input_data="WEBVTT\n\n00:00:01.000 --> 00:00:04.000\nHello, world!",
    input_format="webvtt",
    output_format="vtt+mp4",
    language="en",
)
subtitle_fmp4 = result.data
```

### Extract CEA-608/708 captions

```python
result = packager.extract_captions(
    input_data=video_bytes,
    cc_index=0,              # CEA-608 channel (0-3)
    output_format="webvtt",
    language="en",
)
captions_vtt = result.data.decode("utf-8")
```

### Text stream configuration

```python
from pyshaka import TextStreamConfig

text = TextStreamConfig(
    language="es",
    output_format="ttml+mp4",
    forced_subtitle=True,
    hls_playlist_name="subs_es.m3u8",
    dash_roles="subtitle",
)
```

---

## Trick Play

Generate I-frame only streams for fast-forward/rewind:

```python
packager = Packager()
result = packager.make_trick_play_stream(
    input_data=video_bytes,
    trick_play_factor=2,                     # every 2nd keyframe
    hls_iframe_playlist_name="iframe.m3u8",
)
trick_play_data = result.data
```

Or configure via `StreamConfig`:

```python
from pyshaka import StreamConfig

stream = StreamConfig(
    stream_type="video",
    trick_play_factor=4,
    hls_iframe_playlist_name="iframe_4x.m3u8",
)
```

---

## Ad Insertion

Define SCTE-35 cue points for ad break signaling:

```python
from pyshaka import AdCueConfig, CuePoint

ad_cues = AdCueConfig(
    cue_points=[
        CuePoint(start_time=30.0, duration=15.0),   # 15s ad at 30s
        CuePoint(start_time=120.0, duration=30.0),   # 30s ad at 2min
        CuePoint(start_time=300.0, duration=0.0),    # unknown duration at 5min
    ],
)
```

Cue points are validated for sorted order and non-negative values.

---

## Segmentation

Control segment boundaries and chunking behavior:

```python
from pyshaka import ChunkingConfig

chunking = ChunkingConfig(
    segment_duration=4.0,         # 4-second segments
    subsegment_duration=1.0,      # 1-second subsegments
    segment_sap_aligned=True,     # align at Stream Access Points
    subsegment_sap_aligned=True,
    start_segment_number=1,
    low_latency_dash_mode=False,
)
```

---

## Multi-Stream Packaging

Use `PackagingConfig` to combine all options and process multiple streams:

```python
from pyshaka import (
    PackagingConfig, EncryptionConfig, ChunkingConfig,
    DashConfig, HlsConfig, StreamConfig, TextStreamConfig,
    AdCueConfig, CuePoint, package,
)

config = PackagingConfig(
    encryption=EncryptionConfig(
        key_id="00112233445566778899aabbccddeeff",
        key="ffeeddccbbaa99887766554433221100",
    ),
    chunking=ChunkingConfig(segment_duration=4.0),
    dash=DashConfig(mpd_output="manifest.mpd"),
    hls=HlsConfig(master_playlist_output="master.m3u8"),
    ad_cues=AdCueConfig(cue_points=[CuePoint(start_time=60.0, duration=15.0)]),
    streams=[
        StreamConfig(stream_type="video", hls_playlist_name="video.m3u8"),
        StreamConfig(stream_type="audio", language="en", hls_playlist_name="audio_en.m3u8"),
        TextStreamConfig(language="en", hls_playlist_name="subs_en.m3u8"),
    ],
)

results = package(
    config=config,
    input_files={"video": video_bytes, "audio": audio_bytes},
)
```

### `package_bytes` — single-buffer shorthand

```python
from pyshaka import package_bytes, EncryptionConfig

result = package_bytes(
    data=segment_bytes,
    stream_type="video",
    encryption=EncryptionConfig(key_id="...", key="..."),
)
```

---

## API Reference

### `Packager`

The core entry point. Create once, reuse for multiple segments.

| Method | Description |
|---|---|
| `encrypt_segment(input_data, *, stream_type, encryption, ...)` | Encrypt a CMAF segment in memory |
| `encrypt_init_segment(init_data, *, stream_type, encryption, ...)` | Encrypt an init segment (ftyp+moov) |
| `decrypt_segment(input_data, *, stream_type, decryption, ...)` | Decrypt a CMAF segment in memory |
| `package_subtitles(input_data, *, input_format, output_format, language)` | Package WebVTT/TTML → fMP4 |
| `extract_captions(input_data, *, cc_index, output_format, language)` | Extract CEA-608/708 captions |
| `make_trick_play_stream(input_data, *, trick_play_factor, ...)` | Generate I-frame only stream |
| `get_library_version()` | Return Shaka Packager version string |

### High-Level Functions

| Function | Description |
|---|---|
| `encrypt(data, *, key_id, key, ...)` | One-call segment encryption → `bytes` |
| `decrypt(data, *, key_id, key, ...)` | One-call segment decryption → `bytes` |
| `package(*, streams, config, ...)` | Multi-stream packaging → `dict[str, PackagerResult]` |
| `package_bytes(data, *, config, ...)` | Single-buffer packaging → `PackagerResult` |

### `PackagerResult`

| Field | Type | Description |
|---|---|---|
| `data` | `bytes` | Packaged/encrypted segment data |
| `init_data` | `bytes \| None` | Init segment (ftyp+moov) if `separate_init=True` |
| `duration_ms` | `float` | Processing time in milliseconds |
| `pssh_boxes` | `dict[str, bytes]` | PSSH boxes keyed by system ID |
| `outputs` | `dict[str, bytes]` | Named output buffers (multi-stream) |
| `manifests` | `dict[str, str]` | Manifest outputs (MPD/m3u8 content) |
| `success` | `bool` | Whether the operation succeeded |
| `errors` | `list[str]` | Error messages if any |

### Enums

#### `ProtectionScheme`

| Value | Description |
|---|---|
| `CENC` | AES-CTR full-sample encryption (Widevine, PlayReady) |
| `CBCS` | AES-CBC pattern encryption (FairPlay, Widevine) |
| `CENS` | AES-CTR subsample encryption |
| `CBC1` | AES-CBC full-sample encryption |

#### `KeyProvider`

| Value | Description |
|---|---|
| `RAW` | Direct hex key/key_id values |
| `WIDEVINE` | Widevine key server |
| `PLAYREADY` | PlayReady key server |
| `CPIX` | CPIX 2.x key exchange (DRMtoday, PallyCon, etc.) |

#### `ProtectionSystem`

Combinable with `|` for multi-DRM:

| Flag | Value |
|---|---|
| `COMMON` | `0x01` |
| `WIDEVINE` | `0x02` |
| `PLAYREADY` | `0x04` |
| `FAIRPLAY` | `0x08` |
| `MARLIN` | `0x10` |

#### `HlsPlaylistType`

| Value | Description |
|---|---|
| `VOD` | Video on demand |
| `EVENT` | Event (append-only) |
| `LIVE` | Live (sliding window) |

### Configuration Classes

| Class | Fields | Description |
|---|---|---|
| `EncryptionConfig` | 18 fields | Encryption: scheme, keys, DRM provider, pattern, rotation |
| `DecryptionConfig` | 9 fields | Decryption: keys, DRM provider |
| `KeyInfo` | 3 fields | Single key entry for multi-key maps |
| `ChunkingConfig` | 6 fields | Segmentation: duration, SAP alignment, LL-DASH |
| `Mp4OutputConfig` | 3 fields | MP4 output: PSSH in stream, SIDX generation |
| `DashConfig` | 18 fields | DASH MPD: timing, buffer, UTC, codec switching |
| `HlsConfig` | 13 fields | HLS: playlist type, key URI, session keys |
| `UtcTimingConfig` | 2 fields | UTC timing element for DASH |
| `StreamConfig` | 19 fields | Stream descriptor: type, language, DRM label, HLS/DASH fields |
| `TextStreamConfig` | (extends StreamConfig) | Text/subtitle specialized config |
| `CuePoint` | 2 fields | Ad cue: start time, duration |
| `AdCueConfig` | 1 field | Ad cue list with validation |
| `PackagingConfig` | 11 fields | Top-level: combines all configs |

All config classes are **frozen dataclasses** with a `validate()` method that checks field consistency.

### Exceptions

| Exception | Description |
|---|---|
| `PyshakaError` | Base exception for all pyshaka errors |
| `EncryptionError` | Encryption or decryption operation failed |
| `PackagerNotInitializedError` | Native extension not loaded |
| `BuildError` | Native C++ extension not compiled |

---

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    Python API Layer                        │
│                                                           │
│  High-level: encrypt() / decrypt() / package()            │
│  Core:       Packager.encrypt_segment()                   │
│              Packager.decrypt_segment()                    │
│              Packager.package_subtitles()                  │
│              Packager.make_trick_play_stream()             │
│  Config:     EncryptionConfig, DashConfig, HlsConfig ...  │
├──────────────────────────────────────────────────────────┤
│              pybind11 C++ Bindings (~900 LoC)             │
│                                                           │
│  _pyshaka_cpp.PackagerCore                                │
│  BufferCallbackParams (in-memory read/write callbacks)    │
│  EncryptionParams, DecryptionParams, StreamDescriptor     │
│  MpdParams, HlsParams, ChunkingParams, AdCueParams       │
├──────────────────────────────────────────────────────────┤
│           Shaka Packager C++ (libpackager.so)             │
│                                                           │
│  shaka::Packager → Initialize() → Run()                   │
│  CENC/CBCS encryption, PSSH box generation                │
│  NAL unit parsing, subsample encryption                   │
│  DASH MPD / HLS m3u8 manifest generation                  │
│  WebVTT/TTML muxing, CEA-608/708 extraction               │
└──────────────────────────────────────────────────────────┘
```

### How it works

1. Python passes media bytes via `BufferCallbackParams` (read/write callbacks) — **zero temp files**
2. Configuration dataclasses are translated to C++ `PackagingParams` + `StreamDescriptor` structs
3. Shaka Packager processes fMP4 in memory — encryption, muxing, manifest generation
4. Encrypted/packaged bytes are collected via the write callback
5. Results returned as `PackagerResult` with data, manifests, PSSH boxes, and timing info

---

## Building from Source

### Prerequisites

- Python 3.9+
- CMake 3.15+
- Ninja
- C++17 compiler (GCC 9+, Clang 10+, MSVC 19.20+)
- pybind11

### Build steps

```bash
# Clone with submodules
git clone --recursive https://github.com/horamarques/pyshaka.git
cd pyshaka

# Build Shaka Packager native library
bash scripts/build_shaka_linux.sh   # or build_shaka_macos.sh

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest
```

### Building wheels

```bash
pip install cibuildwheel
cibuildwheel --output-dir wheelhouse
```

---

## Comparison with Alternatives

| Approach | Latency/seg | Temp files | Multi-DRM | DASH/HLS | Subtitles | License |
|---|---|---|---|---|---|---|
| **pyshaka** | 1-3 ms | No | Yes | Yes | Yes | BSD-3 |
| `subprocess` shaka-packager | 15-25 ms | Yes | Yes | Yes | Yes | Apache-2.0 |
| Pure Python (pymp4) | 2-5 ms | No | Partial* | No | No | MIT |
| Bento4 mp4encrypt | 1-3 ms | No | Yes | Yes | No | GPL ⚠️ |

\* Pure Python cannot safely do CBCS subsample encryption without NAL unit parsing.

---

## License

BSD-3-Clause — same as Shaka Packager.

## Contributing

Contributions welcome! Please open an issue first for major changes.

```bash
git clone --recursive https://github.com/horamarques/pyshaka.git
cd pyshaka
pip install -e ".[dev]"
ruff check src/ tests/
pytest
```

## Credits

- [Shaka Packager](https://github.com/shaka-project/shaka-packager) by Google
- [pybind11](https://github.com/pybind/pybind11) for seamless C++/Python interop
