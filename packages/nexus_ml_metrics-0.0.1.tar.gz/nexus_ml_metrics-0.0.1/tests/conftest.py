"""Test configuration and shared fixtures for nexus-ml."""

import pytest

from nexus_ml.core.types import (
    ArchitectureType,
    EnergyDomain,
    EnergyMeasurement,
    LayerProfile,
    ModelProfile,
    NexusMetrics,
    OperationCount,
    OperationType,
    Precision,
    TransistorOperations,
)


@pytest.fixture
def sample_mac_operation() -> OperationCount:
    """A sample MAC operation count."""
    return OperationCount(
        op_type=OperationType.MAC,
        precision=Precision.FP32,
        count=1_000_000,
        source="theoretical",
    )


@pytest.fixture
def sample_memory_operation() -> OperationCount:
    """A sample memory read operation count."""
    return OperationCount(
        op_type=OperationType.MEMORY_READ,
        precision=Precision.FP32,
        count=500_000,
        source="ncu_measured",
    )


@pytest.fixture
def sample_transistor_ops(sample_mac_operation: OperationCount) -> TransistorOperations:
    """A sample TransistorOperations for MAC at FP32."""
    return TransistorOperations(
        operation=sample_mac_operation,
        beta_coefficient=5000.0,
        total_tos=5_000_000_000,
        energy_domain=EnergyDomain.COMPUTE,
    )


@pytest.fixture
def sample_layer_profile(
    sample_mac_operation: OperationCount,
    sample_memory_operation: OperationCount,
) -> LayerProfile:
    """A sample layer profile with compute and memory operations."""
    compute_tos = TransistorOperations(
        operation=sample_mac_operation,
        beta_coefficient=5000.0,
        total_tos=5_000_000_000,
        energy_domain=EnergyDomain.COMPUTE,
    )
    memory_tos = TransistorOperations(
        operation=sample_memory_operation,
        beta_coefficient=192.0,
        total_tos=96_000_000,
        energy_domain=EnergyDomain.MEMORY,
    )
    return LayerProfile(
        name="conv2d_1",
        layer_type="Conv2d",
        operations=(sample_mac_operation, sample_memory_operation),
        transistor_ops=(compute_tos, memory_tos),
        parameters=9408,
        input_shape=(3, 224, 224),
        output_shape=(64, 112, 112),
    )


@pytest.fixture
def sample_model_profile(sample_layer_profile: LayerProfile) -> ModelProfile:
    """A sample model profile with one layer."""
    return ModelProfile(
        model_name="test_model",
        architecture_type=ArchitectureType.CNN,
        layers=(sample_layer_profile,),
        total_parameters=9408,
        default_precision=Precision.FP32,
        framework="test",
    )


@pytest.fixture
def sample_energy_measurement() -> EnergyMeasurement:
    """A sample energy measurement."""
    return EnergyMeasurement(
        energy_joules=130.3,
        power_watts_avg=108.0,
        power_watts_peak=145.0,
        duration_seconds=1.21,
        power_watts_idle=15.0,
        num_runs=5,
        coefficient_of_variation=0.03,
        hardware_backend="nvidia_gpu",
    )


@pytest.fixture
def sample_overhead_transistor_ops() -> TransistorOperations:
    """A sample TransistorOperations for overhead domain."""
    overhead_op = OperationCount(
        op_type=OperationType.MAC,  # Could be any op type
        precision=Precision.FP32,
        count=10_000,
        source="estimated",
    )
    return TransistorOperations(
        operation=overhead_op,
        beta_coefficient=100.0,
        total_tos=1_000_000,
        energy_domain=EnergyDomain.OVERHEAD,
    )


@pytest.fixture
def sample_nexus_metrics() -> NexusMetrics:
    """Sample NEXUS metrics (based on ResNet-50 values from FLAIRS paper)."""
    return NexusMetrics(
        saft=1.03e9,
        lsrt=0.852,
        ecu=1.711,
        mcer=2.33,
        ddev=0.174,
        cpto=7.43e-8,
    )
