"""Unit tests for nexus_ml.core.types.

Tests all dataclasses, enums, validation logic, and computed properties
in the core type definitions. These types are the foundation of the
entire NEXUS framework — correctness here is critical.
"""

import pytest
from dataclasses import FrozenInstanceError

from nexus_ml.core.types import (
    ArchitectureType,
    BaselineMetrics,
    ComparisonResult,
    EnergyDomain,
    EnergyMeasurement,
    LayerProfile,
    ModelProfile,
    NexusMetrics,
    OperationCount,
    OperationType,
    Precision,
    TransistorOperations,
)


# =============================================================================
# Precision Enum
# =============================================================================


class TestPrecision:
    """Tests for the Precision enum.

    Critical: BF16, FP16, INT8, FP8, INT32, FP32 must all be DISTINCT
    enum members, not aliases. Python enums treat same-valued members
    as aliases, so we use an encoding scheme (bit_width × 10 + format_index)
    to ensure uniqueness while preserving correct bit widths via .bits property.
    """

    def test_all_members_exist(self):
        """Every expected precision format is a member of the enum."""
        expected = {"FP32", "FP16", "BF16", "FP8", "INT8", "FP4", "INT4", "INT32"}
        actual = set(Precision.__members__.keys())
        assert expected == actual

    def test_bits_property_fp32(self):
        assert Precision.FP32.bits == 32

    def test_bits_property_fp16(self):
        assert Precision.FP16.bits == 16

    def test_bits_property_bf16(self):
        assert Precision.BF16.bits == 16

    def test_bits_property_fp8(self):
        assert Precision.FP8.bits == 8

    def test_bits_property_int8(self):
        assert Precision.INT8.bits == 8

    def test_bits_property_fp4(self):
        assert Precision.FP4.bits == 4

    def test_bits_property_int4(self):
        assert Precision.INT4.bits == 4

    def test_bits_property_int32(self):
        assert Precision.INT32.bits == 32

    # -- Distinctness tests: these are the critical scientific correctness tests --
    # BF16 and FP16 have different exponent/mantissa splits (8/7 vs 5/10),
    # resulting in different transistor costs for multiply/add operations.
    # INT8 vs FP8 is integer vs floating-point arithmetic at the same bit width.
    # INT32 vs FP32 is the same distinction at 32 bits.

    def test_bf16_is_not_fp16(self):
        """BF16 and FP16 must be distinct — different circuit implementations."""
        assert Precision.BF16 is not Precision.FP16
        assert Precision.BF16 != Precision.FP16

    def test_int8_is_not_fp8(self):
        """INT8 and FP8 must be distinct — integer vs floating-point arithmetic."""
        assert Precision.INT8 is not Precision.FP8
        assert Precision.INT8 != Precision.FP8

    def test_int32_is_not_fp32(self):
        """INT32 and FP32 must be distinct — integer vs floating-point arithmetic."""
        assert Precision.INT32 is not Precision.FP32
        assert Precision.INT32 != Precision.FP32

    def test_int4_is_not_fp4(self):
        """INT4 and FP4 must be distinct — integer vs floating-point arithmetic."""
        assert Precision.INT4 is not Precision.FP4
        assert Precision.INT4 != Precision.FP4

    def test_bf16_same_bit_width_as_fp16(self):
        """BF16 and FP16 share bit width but differ in format."""
        assert Precision.BF16.bits == Precision.FP16.bits == 16

    def test_int8_same_bit_width_as_fp8(self):
        """INT8 and FP8 share bit width but differ in format."""
        assert Precision.INT8.bits == Precision.FP8.bits == 8

    def test_int32_same_bit_width_as_fp32(self):
        """INT32 and FP32 share bit width but differ in format."""
        assert Precision.INT32.bits == Precision.FP32.bits == 32

    def test_int4_same_bit_width_as_fp4(self):
        """INT4 and FP4 share bit width but differ in format."""
        assert Precision.INT4.bits == Precision.FP4.bits == 4

    def test_all_eight_are_unique_enum_members(self):
        """All 8 precision formats iterate as distinct members."""
        members = list(Precision)
        assert len(members) == 8

    def test_bf16_name_preserved(self):
        """BF16 retains its own name (not aliased to FP16)."""
        assert Precision.BF16.name == "BF16"

    def test_int8_name_preserved(self):
        """INT8 retains its own name (not aliased to FP8)."""
        assert Precision.INT8.name == "INT8"

    def test_int32_name_preserved(self):
        """INT32 retains its own name (not aliased to FP32)."""
        assert Precision.INT32.name == "INT32"

    def test_int4_name_preserved(self):
        """INT4 retains its own name (not aliased to FP4)."""
        assert Precision.INT4.name == "INT4"

    def test_fp4_name_preserved(self):
        """FP4 retains its own name."""
        assert Precision.FP4.name == "FP4"

    def test_usable_as_distinct_dict_keys(self):
        """Each precision can key a separate β-coefficient entry."""
        table = {p: f"beta_{p.name}" for p in Precision}
        assert len(table) == 8
        assert table[Precision.BF16] != table[Precision.FP16]
        assert table[Precision.INT8] != table[Precision.FP8]
        assert table[Precision.INT32] != table[Precision.FP32]
        assert table[Precision.INT4] != table[Precision.FP4]


# =============================================================================
# OperationType Enum
# =============================================================================


class TestOperationType:
    """Tests for the OperationType enum."""

    def test_arithmetic_operations_exist(self):
        """Core arithmetic ops from Horowitz energy model are present."""
        assert OperationType.MAC
        assert OperationType.MULTIPLY
        assert OperationType.ADD
        assert OperationType.DIVIDE

    def test_activation_functions_exist(self):
        """Activation functions with varying transistor costs are present."""
        activations = {
            OperationType.RELU,
            OperationType.SIGMOID,
            OperationType.TANH,
            OperationType.GELU,
            OperationType.SWIGLU,
            OperationType.SOFTMAX,
        }
        assert len(activations) == 6

    def test_memory_operations_exist(self):
        """Memory operations (dominant energy cost) are present."""
        assert OperationType.MEMORY_READ
        assert OperationType.MEMORY_WRITE
        assert OperationType.CACHE_ACCESS

    def test_tree_operations_exist(self):
        """GBDT-specific operations are present (validated in FLAIRS paper)."""
        assert OperationType.COMPARISON
        assert OperationType.LEAF_ACCUMULATE

    def test_attention_operations_exist(self):
        """Transformer attention ops are present (for future extension)."""
        assert OperationType.ATTENTION_SCORE
        assert OperationType.ATTENTION_SOFTMAX

    def test_all_members_are_distinct(self):
        """All operation types are unique enum members."""
        members = list(OperationType)
        names = [m.name for m in members]
        assert len(names) == len(set(names))


# =============================================================================
# ArchitectureType Enum
# =============================================================================


class TestArchitectureType:
    """Tests for the ArchitectureType enum."""

    def test_validated_architectures_exist(self):
        """Architectures validated in FLAIRS paper are present."""
        assert ArchitectureType.CNN
        assert ArchitectureType.RNN
        assert ArchitectureType.LSTM
        assert ArchitectureType.GRU
        assert ArchitectureType.GBDT

    def test_transformer_exists_for_future_extension(self):
        """Transformer architecture type exists for planned extension."""
        assert ArchitectureType.TRANSFORMER

    def test_utility_types_exist(self):
        """General-purpose architecture types are present."""
        assert ArchitectureType.LINEAR
        assert ArchitectureType.ENSEMBLE
        assert ArchitectureType.CUSTOM


# =============================================================================
# EnergyDomain Enum
# =============================================================================


class TestEnergyDomain:
    """Tests for the EnergyDomain enum."""

    def test_all_three_domains_exist(self):
        """Compute, Memory, and Overhead domains are all present."""
        domains = list(EnergyDomain)
        assert len(domains) == 3
        assert EnergyDomain.COMPUTE in domains
        assert EnergyDomain.MEMORY in domains
        assert EnergyDomain.OVERHEAD in domains


# =============================================================================
# OperationCount
# =============================================================================


class TestOperationCount:
    """Tests for the OperationCount frozen dataclass."""

    def test_construction(self, sample_mac_operation):
        """Basic construction with all fields."""
        assert sample_mac_operation.op_type == OperationType.MAC
        assert sample_mac_operation.precision == Precision.FP32
        assert sample_mac_operation.count == 1_000_000
        assert sample_mac_operation.source == "theoretical"

    def test_default_source_is_theoretical(self):
        """Default source is 'theoretical' when not specified."""
        op = OperationCount(
            op_type=OperationType.ADD,
            precision=Precision.FP16,
            count=100,
        )
        assert op.source == "theoretical"

    def test_ncu_measured_source(self):
        """Source can be 'ncu_measured' for hardware-profiled counts."""
        op = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.FP32,
            count=500_000,
            source="ncu_measured",
        )
        assert op.source == "ncu_measured"

    def test_zero_count_is_valid(self):
        """Zero count is allowed (layer may have no ops of a given type)."""
        op = OperationCount(
            op_type=OperationType.RELU,
            precision=Precision.FP32,
            count=0,
        )
        assert op.count == 0

    def test_negative_count_raises_valueerror(self):
        """Negative operation counts are physically meaningless."""
        with pytest.raises(ValueError, match="cannot be negative"):
            OperationCount(
                op_type=OperationType.MAC,
                precision=Precision.FP32,
                count=-1,
            )

    def test_frozen_immutability(self):
        """OperationCount is frozen — cannot be mutated after construction."""
        op = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.FP32,
            count=100,
        )
        with pytest.raises(FrozenInstanceError):
            op.count = 200  # type: ignore[misc]

    def test_different_precisions_at_same_bit_width(self):
        """BF16 and FP16 operations are distinguishable."""
        op_fp16 = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.FP16,
            count=1000,
        )
        op_bf16 = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.BF16,
            count=1000,
        )
        assert op_fp16.precision != op_bf16.precision
        assert op_fp16.precision.bits == op_bf16.precision.bits


# =============================================================================
# TransistorOperations
# =============================================================================


class TestTransistorOperations:
    """Tests for the TransistorOperations frozen dataclass."""

    def test_construction(self, sample_transistor_ops, sample_mac_operation):
        """Basic construction with all fields."""
        assert sample_transistor_ops.operation is sample_mac_operation
        assert sample_transistor_ops.beta_coefficient == 5000.0
        assert sample_transistor_ops.total_tos == 5_000_000_000
        assert sample_transistor_ops.energy_domain == EnergyDomain.COMPUTE

    def test_negative_beta_raises_valueerror(self):
        """Negative β-coefficient is physically meaningless."""
        op = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.FP32,
            count=100,
        )
        with pytest.raises(ValueError, match="cannot be negative"):
            TransistorOperations(
                operation=op,
                beta_coefficient=-1.0,
                total_tos=100,
                energy_domain=EnergyDomain.COMPUTE,
            )

    def test_zero_beta_is_valid(self):
        """Zero β is allowed (e.g., an operation with negligible TO cost)."""
        op = OperationCount(
            op_type=OperationType.RELU,
            precision=Precision.FP32,
            count=1000,
        )
        to = TransistorOperations(
            operation=op,
            beta_coefficient=0.0,
            total_tos=0,
            energy_domain=EnergyDomain.COMPUTE,
        )
        assert to.beta_coefficient == 0.0

    def test_total_tos_is_stored_not_computed(self):
        """total_tos is an explicit field, not automatically derived from count × β.

        This is by design: the actual TO count may come from hardware measurement
        (NCU profiling) rather than theoretical computation. The operations_to_transistor_ops()
        function in core/operations.py performs the count × β multiplication; the dataclass
        stores the result (or a measured alternative) without enforcing the relationship.
        """
        op = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.FP32,
            count=1000,
        )
        # Deliberately set total_tos != count × beta to show it's stored, not derived
        to = TransistorOperations(
            operation=op,
            beta_coefficient=5.0,
            total_tos=9999,  # Not 1000 × 5.0 = 5000
            energy_domain=EnergyDomain.COMPUTE,
        )
        assert to.total_tos == 9999
        assert to.total_tos != to.operation.count * to.beta_coefficient

    def test_frozen_immutability(self):
        """TransistorOperations is frozen."""
        op = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.FP32,
            count=100,
        )
        to = TransistorOperations(
            operation=op,
            beta_coefficient=5.0,
            total_tos=500,
            energy_domain=EnergyDomain.COMPUTE,
        )
        with pytest.raises(FrozenInstanceError):
            to.total_tos = 999  # type: ignore[misc]

    def test_memory_domain(self, sample_memory_operation):
        """TransistorOperations can represent memory-domain work."""
        to = TransistorOperations(
            operation=sample_memory_operation,
            beta_coefficient=192.0,
            total_tos=96_000_000,
            energy_domain=EnergyDomain.MEMORY,
        )
        assert to.energy_domain == EnergyDomain.MEMORY

    def test_overhead_domain(self, sample_overhead_transistor_ops):
        """TransistorOperations can represent overhead-domain work."""
        assert sample_overhead_transistor_ops.energy_domain == EnergyDomain.OVERHEAD


# =============================================================================
# LayerProfile
# =============================================================================


class TestLayerProfile:
    """Tests for the LayerProfile frozen dataclass."""

    def test_construction(self, sample_layer_profile):
        """Basic construction with all fields."""
        assert sample_layer_profile.name == "conv2d_1"
        assert sample_layer_profile.layer_type == "Conv2d"
        assert sample_layer_profile.parameters == 9408
        assert sample_layer_profile.input_shape == (3, 224, 224)
        assert sample_layer_profile.output_shape == (64, 112, 112)

    def test_total_tos(self, sample_layer_profile):
        """total_tos sums across all energy domains."""
        # From conftest: compute=5_000_000_000 + memory=96_000_000
        expected = 5_000_000_000 + 96_000_000
        assert sample_layer_profile.total_tos == expected

    def test_compute_tos(self, sample_layer_profile):
        """compute_tos returns only COMPUTE domain TOs."""
        assert sample_layer_profile.compute_tos == 5_000_000_000

    def test_memory_tos(self, sample_layer_profile):
        """memory_tos returns only MEMORY domain TOs."""
        assert sample_layer_profile.memory_tos == 96_000_000

    def test_empty_operations(self):
        """Layer with no operations has zero TOs across all domains."""
        layer = LayerProfile(
            name="empty_layer",
            layer_type="Identity",
        )
        assert layer.total_tos == 0
        assert layer.compute_tos == 0
        assert layer.memory_tos == 0
        assert layer.operations == ()
        assert layer.transistor_ops == ()

    def test_layer_with_all_three_domains(self, sample_overhead_transistor_ops):
        """Layer can have compute, memory, and overhead TOs."""
        mac_op = OperationCount(
            op_type=OperationType.MAC,
            precision=Precision.FP32,
            count=1000,
        )
        mem_op = OperationCount(
            op_type=OperationType.MEMORY_READ,
            precision=Precision.FP32,
            count=500,
        )
        compute_to = TransistorOperations(
            operation=mac_op,
            beta_coefficient=5000.0,
            total_tos=5_000_000,
            energy_domain=EnergyDomain.COMPUTE,
        )
        memory_to = TransistorOperations(
            operation=mem_op,
            beta_coefficient=192.0,
            total_tos=96_000,
            energy_domain=EnergyDomain.MEMORY,
        )
        layer = LayerProfile(
            name="layer_all_domains",
            layer_type="Custom",
            transistor_ops=(compute_to, memory_to, sample_overhead_transistor_ops),
        )
        assert layer.compute_tos == 5_000_000
        assert layer.memory_tos == 96_000
        assert layer.total_tos == 5_000_000 + 96_000 + 1_000_000

    def test_default_optional_fields(self):
        """Optional fields have correct defaults."""
        layer = LayerProfile(name="test", layer_type="Linear")
        assert layer.parameters == 0
        assert layer.input_shape is None
        assert layer.output_shape is None
        assert layer.metadata == {}

    def test_frozen_immutability(self, sample_layer_profile):
        """LayerProfile is frozen."""
        with pytest.raises(FrozenInstanceError):
            sample_layer_profile.name = "modified"  # type: ignore[misc]


# =============================================================================
# ModelProfile
# =============================================================================


class TestModelProfile:
    """Tests for the ModelProfile frozen dataclass."""

    def test_construction(self, sample_model_profile):
        """Basic construction with all fields."""
        assert sample_model_profile.model_name == "test_model"
        assert sample_model_profile.architecture_type == ArchitectureType.CNN
        assert sample_model_profile.total_parameters == 9408
        assert sample_model_profile.default_precision == Precision.FP32
        assert sample_model_profile.framework == "test"

    def test_num_layers(self, sample_model_profile):
        """num_layers returns correct layer count."""
        assert sample_model_profile.num_layers == 1

    def test_total_tos_aggregation(self, sample_model_profile):
        """total_tos sums across all layers."""
        expected = 5_000_000_000 + 96_000_000  # single layer from fixture
        assert sample_model_profile.total_tos == expected

    def test_total_compute_tos(self, sample_model_profile):
        """total_compute_tos sums compute domain across all layers."""
        assert sample_model_profile.total_compute_tos == 5_000_000_000

    def test_total_memory_tos(self, sample_model_profile):
        """total_memory_tos sums memory domain across all layers."""
        assert sample_model_profile.total_memory_tos == 96_000_000

    def test_multi_layer_aggregation(self, sample_layer_profile):
        """Properties aggregate correctly across multiple layers."""
        layer2 = LayerProfile(
            name="conv2d_2",
            layer_type="Conv2d",
            transistor_ops=(
                TransistorOperations(
                    operation=OperationCount(
                        op_type=OperationType.MAC,
                        precision=Precision.FP32,
                        count=2_000_000,
                    ),
                    beta_coefficient=5000.0,
                    total_tos=10_000_000_000,
                    energy_domain=EnergyDomain.COMPUTE,
                ),
            ),
            parameters=36864,
        )
        model = ModelProfile(
            model_name="two_layer_model",
            architecture_type=ArchitectureType.CNN,
            layers=(sample_layer_profile, layer2),
            total_parameters=9408 + 36864,
        )
        assert model.num_layers == 2
        # Layer1: 5B compute + 96M memory; Layer2: 10B compute
        assert model.total_compute_tos == 5_000_000_000 + 10_000_000_000
        assert model.total_memory_tos == 96_000_000
        assert model.total_tos == 15_000_000_000 + 96_000_000

    def test_empty_model(self):
        """Model with no layers has zero TOs."""
        model = ModelProfile(
            model_name="empty",
            architecture_type=ArchitectureType.CUSTOM,
            layers=(),
            total_parameters=0,
        )
        assert model.num_layers == 0
        assert model.total_tos == 0
        assert model.total_compute_tos == 0
        assert model.total_memory_tos == 0

    def test_default_precision_is_fp32(self):
        """Default precision defaults to FP32."""
        model = ModelProfile(
            model_name="test",
            architecture_type=ArchitectureType.CNN,
            layers=(),
            total_parameters=0,
        )
        assert model.default_precision == Precision.FP32

    def test_default_framework_is_unknown(self):
        """Framework defaults to 'unknown'."""
        model = ModelProfile(
            model_name="test",
            architecture_type=ArchitectureType.CNN,
            layers=(),
            total_parameters=0,
        )
        assert model.framework == "unknown"

    def test_frozen_immutability(self, sample_model_profile):
        """ModelProfile is frozen."""
        with pytest.raises(FrozenInstanceError):
            sample_model_profile.model_name = "modified"  # type: ignore[misc]


# =============================================================================
# EnergyMeasurement
# =============================================================================


class TestEnergyMeasurement:
    """Tests for the EnergyMeasurement frozen dataclass."""

    def test_construction(self, sample_energy_measurement):
        """Basic construction with all fields."""
        assert sample_energy_measurement.energy_joules == 130.3
        assert sample_energy_measurement.power_watts_avg == 108.0
        assert sample_energy_measurement.power_watts_peak == 145.0
        assert sample_energy_measurement.duration_seconds == 1.21
        assert sample_energy_measurement.power_watts_idle == 15.0
        assert sample_energy_measurement.num_runs == 5
        assert sample_energy_measurement.coefficient_of_variation == 0.03
        assert sample_energy_measurement.hardware_backend == "nvidia_gpu"

    def test_negative_energy_raises_valueerror(self):
        """Negative energy is physically impossible."""
        with pytest.raises(ValueError, match="Energy cannot be negative"):
            EnergyMeasurement(
                energy_joules=-1.0,
                power_watts_avg=100.0,
                power_watts_peak=150.0,
                duration_seconds=1.0,
            )

    def test_zero_energy_is_valid(self):
        """Zero energy is valid (e.g., idle measurement with baseline subtracted)."""
        m = EnergyMeasurement(
            energy_joules=0.0,
            power_watts_avg=0.0,
            power_watts_peak=0.0,
            duration_seconds=1.0,
        )
        assert m.energy_joules == 0.0

    def test_zero_duration_raises_valueerror(self):
        """Zero duration is invalid — measurement must have nonzero time."""
        with pytest.raises(ValueError, match="Duration must be positive"):
            EnergyMeasurement(
                energy_joules=1.0,
                power_watts_avg=100.0,
                power_watts_peak=150.0,
                duration_seconds=0.0,
            )

    def test_negative_duration_raises_valueerror(self):
        """Negative duration is physically impossible."""
        with pytest.raises(ValueError, match="Duration must be positive"):
            EnergyMeasurement(
                energy_joules=1.0,
                power_watts_avg=100.0,
                power_watts_peak=150.0,
                duration_seconds=-0.5,
            )

    def test_default_optional_fields(self):
        """Optional fields have correct defaults."""
        m = EnergyMeasurement(
            energy_joules=1.0,
            power_watts_avg=10.0,
            power_watts_peak=15.0,
            duration_seconds=0.1,
        )
        assert m.power_watts_idle == 0.0
        assert m.num_runs == 1
        assert m.coefficient_of_variation == 0.0
        assert m.hardware_backend == "unknown"
        assert m.metadata == {}

    def test_frozen_immutability(self, sample_energy_measurement):
        """EnergyMeasurement is frozen."""
        with pytest.raises(FrozenInstanceError):
            sample_energy_measurement.energy_joules = 999.0  # type: ignore[misc]


# =============================================================================
# NexusMetrics
# =============================================================================


class TestNexusMetrics:
    """Tests for the NexusMetrics frozen dataclass."""

    def test_construction(self, sample_nexus_metrics):
        """Basic construction with FLAIRS paper values."""
        assert sample_nexus_metrics.saft == 1.03e9
        assert sample_nexus_metrics.lsrt == 0.852
        assert sample_nexus_metrics.ecu == 1.711
        assert sample_nexus_metrics.mcer == 2.33
        assert sample_nexus_metrics.ddev == 0.174
        assert sample_nexus_metrics.cpto == 7.43e-8

    def test_negative_mcer_raises_valueerror(self):
        """MCER is a ratio of non-negative energies — cannot be negative."""
        with pytest.raises(ValueError, match="MCER cannot be negative"):
            NexusMetrics(
                saft=1.0,
                lsrt=0.5,
                ecu=1.0,
                mcer=-0.1,
                ddev=0.1,
                cpto=1.0,
            )

    def test_negative_ddev_raises_valueerror(self):
        """DDEV is a coefficient of variation — cannot be negative."""
        with pytest.raises(ValueError, match="DDEV cannot be negative"):
            NexusMetrics(
                saft=1.0,
                lsrt=0.5,
                ecu=1.0,
                mcer=1.0,
                ddev=-0.1,
                cpto=1.0,
            )

    def test_zero_mcer_is_valid(self):
        """Zero MCER means no memory energy (purely compute-bound)."""
        m = NexusMetrics(
            saft=1.0, lsrt=0.5, ecu=1.0, mcer=0.0, ddev=0.1, cpto=1.0,
        )
        assert m.mcer == 0.0

    def test_zero_ddev_is_valid(self):
        """Zero DDEV means perfectly uniform energy across inputs."""
        m = NexusMetrics(
            saft=1.0, lsrt=0.5, ecu=1.0, mcer=1.0, ddev=0.0, cpto=1.0,
        )
        assert m.ddev == 0.0

    def test_is_memory_bound_true(self, sample_nexus_metrics):
        """MCER > 1 means memory-bound (key finding from FLAIRS paper)."""
        # sample_nexus_metrics has mcer=2.33 (ResNet-50 from FLAIRS)
        assert sample_nexus_metrics.is_memory_bound is True

    def test_is_memory_bound_false(self):
        """MCER < 1 means compute-bound."""
        m = NexusMetrics(
            saft=1.0, lsrt=0.5, ecu=1.0, mcer=0.5, ddev=0.1, cpto=1.0,
        )
        assert m.is_memory_bound is False

    def test_is_memory_bound_boundary(self):
        """MCER == 1 is exactly balanced — not memory-bound by definition."""
        m = NexusMetrics(
            saft=1.0, lsrt=0.5, ecu=1.0, mcer=1.0, ddev=0.1, cpto=1.0,
        )
        assert m.is_memory_bound is False

    def test_frozen_immutability(self, sample_nexus_metrics):
        """NexusMetrics is frozen."""
        with pytest.raises(FrozenInstanceError):
            sample_nexus_metrics.mcer = 0.0  # type: ignore[misc]


# =============================================================================
# BaselineMetrics
# =============================================================================


class TestBaselineMetrics:
    """Tests for the BaselineMetrics frozen dataclass."""

    def test_all_defaults_are_zero(self):
        """All fields default to zero — baseline metrics are optional."""
        b = BaselineMetrics()
        assert b.flops == 0
        assert b.macs == 0
        assert b.parameters == 0
        assert b.model_size_bytes == 0
        assert b.throughput_samples_per_sec == 0.0
        assert b.latency_seconds == 0.0

    def test_construction_with_values(self):
        """Construction with explicit values."""
        b = BaselineMetrics(
            flops=4_100_000_000,
            macs=2_050_000_000,
            parameters=25_600_000,
            model_size_bytes=102_400_000,
            throughput_samples_per_sec=1200.0,
            latency_seconds=0.0008,
        )
        assert b.flops == 4_100_000_000
        assert b.macs == 2_050_000_000

    def test_frozen_immutability(self):
        """BaselineMetrics is frozen."""
        b = BaselineMetrics()
        with pytest.raises(FrozenInstanceError):
            b.flops = 100  # type: ignore[misc]


# =============================================================================
# ComparisonResult
# =============================================================================


class TestComparisonResult:
    """Tests for the ComparisonResult frozen dataclass.

    This type is a core deliverable of NEXUS — demonstrating that
    NEXUS-guided analysis provides better energy prediction than FLOPs.
    """

    def test_construction(self, sample_nexus_metrics):
        """Basic construction with all fields."""
        baseline = BaselineMetrics(flops=4_100_000_000)
        cr = ComparisonResult(
            model_name="resnet50",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=baseline,
            nexus_predicted_energy_j=125.0,
            flops_predicted_energy_j=180.0,
            measured_energy_j=130.3,
        )
        assert cr.model_name == "resnet50"
        assert cr.nexus_metrics is sample_nexus_metrics

    def test_nexus_error_pct(self, sample_nexus_metrics):
        """NEXUS error percentage is correctly computed."""
        cr = ComparisonResult(
            model_name="test",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=BaselineMetrics(),
            nexus_predicted_energy_j=125.0,
            measured_energy_j=130.0,
        )
        # |125 - 130| / 130 * 100 = 3.846...%
        assert cr.nexus_error_pct is not None
        assert abs(cr.nexus_error_pct - 3.846153846) < 1e-6

    def test_flops_error_pct(self, sample_nexus_metrics):
        """FLOPs error percentage is correctly computed."""
        cr = ComparisonResult(
            model_name="test",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=BaselineMetrics(),
            flops_predicted_energy_j=180.0,
            measured_energy_j=130.0,
        )
        # |180 - 130| / 130 * 100 = 38.461...%
        assert cr.flops_error_pct is not None
        assert abs(cr.flops_error_pct - 38.461538461) < 1e-6

    def test_error_pct_none_when_prediction_missing(self, sample_nexus_metrics):
        """Error is None when prediction is not available."""
        cr = ComparisonResult(
            model_name="test",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=BaselineMetrics(),
            measured_energy_j=130.0,
        )
        assert cr.nexus_error_pct is None
        assert cr.flops_error_pct is None

    def test_error_pct_none_when_measured_missing(self, sample_nexus_metrics):
        """Error is None when measured energy is not available."""
        cr = ComparisonResult(
            model_name="test",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=BaselineMetrics(),
            nexus_predicted_energy_j=125.0,
            flops_predicted_energy_j=180.0,
        )
        assert cr.nexus_error_pct is None
        assert cr.flops_error_pct is None

    def test_error_pct_none_when_measured_is_zero(self, sample_nexus_metrics):
        """Error is None when measured energy is zero (avoid division by zero)."""
        cr = ComparisonResult(
            model_name="test",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=BaselineMetrics(),
            nexus_predicted_energy_j=125.0,
            flops_predicted_energy_j=180.0,
            measured_energy_j=0.0,
        )
        assert cr.nexus_error_pct is None
        assert cr.flops_error_pct is None

    def test_defaults_are_none(self, sample_nexus_metrics):
        """Prediction and measured fields default to None."""
        cr = ComparisonResult(
            model_name="test",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=BaselineMetrics(),
        )
        assert cr.nexus_predicted_energy_j is None
        assert cr.flops_predicted_energy_j is None
        assert cr.measured_energy_j is None

    def test_frozen_immutability(self, sample_nexus_metrics):
        """ComparisonResult is frozen."""
        cr = ComparisonResult(
            model_name="test",
            nexus_metrics=sample_nexus_metrics,
            baseline_metrics=BaselineMetrics(),
        )
        with pytest.raises(FrozenInstanceError):
            cr.model_name = "modified"  # type: ignore[misc]
