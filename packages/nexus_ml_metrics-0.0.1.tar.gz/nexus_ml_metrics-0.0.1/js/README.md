# NEXUS-ML JavaScript/TypeScript Port

This directory is reserved for a future JS/TS implementation of the NEXUS framework,
targeting browser and edge inference optimization.

## Planned Scope

- Core metric computation (SAF-T, MCER, ECU, etc.) in TypeScript
- Integration with ONNX Runtime Web, TensorFlow.js, WebNN
- Browser-based energy estimation for edge deployment decisions
- Lightweight — no heavy ML framework dependencies

## Status

🚧 **Not yet started** — Python package is the priority. This port will begin once
the Python API is stable (post v0.2.0).

## Design Principle

The JS/TS port should share the same core algorithms and β-coefficient data as the
Python package, with framework-specific adapters for the JS/TS ML ecosystem.
