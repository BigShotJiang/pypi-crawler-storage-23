"""Core type definitions for NEXUS-ML.

This module defines the fundamental data structures used throughout the framework.
All types are immutable dataclasses to enforce data integrity.

Design principles:
    - Immutable by default (frozen dataclasses)
    - Framework-agnostic — no PyTorch/TF/XGBoost types here
    - Self-documenting with units in field names where applicable
    - Validated at construction time where possible
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


# =============================================================================
# Enumerations
# =============================================================================


class Precision(Enum):
    """Numerical precision of computations.

    Each precision format maps to distinct β-coefficients derived from
    Horowitz (ISSCC 2014) semiconductor data. Formats at the same bit
    width (e.g., FP16 vs BF16) have different transistor costs due to
    different exponent/mantissa splits and circuit implementations.

    Values use the encoding: bit_width × 10 + format_index, where:
        - format_index 0 = IEEE floating point
        - format_index 1 = alternative format (bfloat / integer)

    This ensures each member is a distinct enum value (Python treats
    same-valued enum members as aliases, which would incorrectly merge
    BF16 with FP16, INT8 with FP8, and INT32 with FP32).

    Use the `bits` property to get the actual bit width.
    """

    FP32 = 320   # 32-bit IEEE 754 single precision
    FP16 = 160   # 16-bit IEEE 754 half precision (5-bit exp, 10-bit mantissa)
    BF16 = 161   # 16-bit bfloat16 (8-bit exp, 7-bit mantissa)
    FP8 = 80     # 8-bit float (E4M3 or E5M2)
    INT8 = 81    # 8-bit integer
    FP4 = 40     # 4-bit float (e.g., FP4 E2M1)
    INT4 = 41    # 4-bit integer
    INT32 = 321  # 32-bit integer

    @property
    def bits(self) -> int:
        """Return the bit width of this precision."""
        return self.value // 10


class OperationType(Enum):
    """Types of operations that consume energy at the transistor level.

    Each maps to a specific transistor operation (TO) count derived
    from circuit complexity analysis.
    """

    # Arithmetic operations
    MAC = auto()        # Fused multiply-accumulate
    MULTIPLY = auto()   # Standalone multiply
    ADD = auto()        # Standalone add/accumulate
    DIVIDE = auto()     # Division

    # Activation functions (vary dramatically in energy cost)
    RELU = auto()       # Compare + mux — very cheap
    SIGMOID = auto()    # Exponential + division — expensive
    TANH = auto()       # Similar to sigmoid
    GELU = auto()       # Gaussian error linear unit
    SWIGLU = auto()     # SwiGLU — very expensive
    SOFTMAX = auto()    # Exp + sum + division per element

    # Memory operations (typically dominate energy)
    MEMORY_READ = auto()
    MEMORY_WRITE = auto()
    CACHE_ACCESS = auto()

    # Tree-specific operations (for GBDTs)
    COMPARISON = auto()
    LEAF_ACCUMULATE = auto()

    # Attention-specific operations
    ATTENTION_SCORE = auto()
    ATTENTION_SOFTMAX = auto()


class ArchitectureType(Enum):
    """High-level ML architecture categories.

    These determine which operation decomposition rules apply.
    """

    CNN = auto()
    RNN = auto()
    LSTM = auto()
    GRU = auto()
    TRANSFORMER = auto()
    GBDT = auto()       # Gradient Boosted Decision Trees
    LINEAR = auto()     # Simple linear/logistic models
    ENSEMBLE = auto()   # Random forests, bagging, etc.
    CUSTOM = auto()


class EnergyDomain(Enum):
    """Classification of energy consumption domains."""

    COMPUTE = auto()    # Arithmetic/logic operations
    MEMORY = auto()     # DRAM/HBM/cache access
    OVERHEAD = auto()   # Clock distribution, power gating, I/O


# =============================================================================
# Operation-level data structures
# =============================================================================


@dataclass(frozen=True)
class OperationCount:
    """Count of a specific operation type at a given precision.

    This is the atomic unit of NEXUS analysis — everything builds up
    from counts of typed, precision-tagged operations.

    Attributes:
        op_type: The type of operation.
        precision: The numerical precision used.
        count: Number of times this operation is performed.
        source: Where this count came from (e.g., 'theoretical', 'ncu_measured').
    """

    op_type: OperationType
    precision: Precision
    count: int
    source: str = "theoretical"

    def __post_init__(self) -> None:
        """Validate that count is non-negative."""
        if self.count < 0:
            raise ValueError(f"Operation count cannot be negative: {self.count}")


@dataclass(frozen=True)
class TransistorOperations:
    """Transistor operation (TO) count for a single operation.

    Combines an operation count with its β-coefficient to produce
    the actual transistor-level work measure.

    Attributes:
        operation: The source operation count.
        beta_coefficient: TOs per operation from Horowitz-derived data.
        total_tos: Total transistor operations (count × β).
        energy_domain: Whether this is compute, memory, or overhead.
    """

    operation: OperationCount
    beta_coefficient: float
    total_tos: int
    energy_domain: EnergyDomain

    def __post_init__(self) -> None:
        """Validate consistency."""
        if self.beta_coefficient < 0:
            raise ValueError(
                f"β-coefficient cannot be negative: {self.beta_coefficient}"
            )


# =============================================================================
# Layer-level data structures
# =============================================================================


@dataclass(frozen=True)
class LayerProfile:
    """Energy profile of a single layer/module in a model.

    Attributes:
        name: Layer identifier (e.g., 'conv2d_3', 'attention.self.query').
        layer_type: String description of the layer type.
        operations: All operation counts for this layer.
        transistor_ops: Computed TO breakdown (populated after analysis).
        parameters: Number of trainable parameters in this layer.
        input_shape: Shape of input tensor(s).
        output_shape: Shape of output tensor(s).
        metadata: Additional framework-specific information.
    """

    name: str
    layer_type: str
    operations: tuple[OperationCount, ...] = ()
    transistor_ops: tuple[TransistorOperations, ...] = ()
    parameters: int = 0
    input_shape: tuple[int, ...] | None = None
    output_shape: tuple[int, ...] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def total_tos(self) -> int:
        """Total transistor operations across all operation types."""
        return sum(to.total_tos for to in self.transistor_ops)

    @property
    def compute_tos(self) -> int:
        """Transistor operations in the compute domain."""
        return sum(
            to.total_tos
            for to in self.transistor_ops
            if to.energy_domain == EnergyDomain.COMPUTE
        )

    @property
    def memory_tos(self) -> int:
        """Transistor operations in the memory domain."""
        return sum(
            to.total_tos
            for to in self.transistor_ops
            if to.energy_domain == EnergyDomain.MEMORY
        )


# =============================================================================
# Model-level data structures
# =============================================================================


@dataclass(frozen=True)
class ModelProfile:
    """Complete NEXUS profile of an ML model.

    This is the primary output of the Analyze stage and the input
    to all subsequent stages (Measure, Diagnose, Recommend, Optimize).

    Attributes:
        model_name: Human-readable model identifier.
        architecture_type: High-level architecture category.
        layers: Per-layer profiles.
        total_parameters: Total trainable parameters.
        default_precision: The precision the model runs at by default.
        framework: Which ML framework (e.g., 'pytorch', 'xgboost').
        metadata: Additional information (batch size, sequence length, etc.).
    """

    model_name: str
    architecture_type: ArchitectureType
    layers: tuple[LayerProfile, ...]
    total_parameters: int
    default_precision: Precision = Precision.FP32
    framework: str = "unknown"
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def total_tos(self) -> int:
        """Total transistor operations across all layers."""
        return sum(layer.total_tos for layer in self.layers)

    @property
    def total_compute_tos(self) -> int:
        """Total compute-domain transistor operations."""
        return sum(layer.compute_tos for layer in self.layers)

    @property
    def total_memory_tos(self) -> int:
        """Total memory-domain transistor operations."""
        return sum(layer.memory_tos for layer in self.layers)

    @property
    def num_layers(self) -> int:
        """Number of profiled layers."""
        return len(self.layers)


# =============================================================================
# Measurement data structures
# =============================================================================


@dataclass(frozen=True)
class EnergyMeasurement:
    """A single energy measurement from hardware.

    Attributes:
        energy_joules: Total energy consumed in joules.
        power_watts_avg: Average power draw in watts.
        power_watts_peak: Peak power draw in watts.
        duration_seconds: Wall-clock duration in seconds.
        power_watts_idle: Idle power baseline in watts.
        num_runs: Number of measurement runs averaged.
        coefficient_of_variation: CV across runs (lower = more stable).
        hardware_backend: Which hardware backend produced this measurement.
        metadata: Additional measurement context.
    """

    energy_joules: float
    power_watts_avg: float
    power_watts_peak: float
    duration_seconds: float
    power_watts_idle: float = 0.0
    num_runs: int = 1
    coefficient_of_variation: float = 0.0
    hardware_backend: str = "unknown"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate measurement values."""
        if self.energy_joules < 0:
            raise ValueError(
                f"Energy cannot be negative: {self.energy_joules}"
            )
        if self.duration_seconds <= 0:
            raise ValueError(
                f"Duration must be positive: {self.duration_seconds}"
            )


# =============================================================================
# Metrics data structures
# =============================================================================


@dataclass(frozen=True)
class NexusMetrics:
    """The six NEXUS metrics computed for a model.

    All metrics are derived from transistor operation analysis and/or
    hardware measurements. See metrics module for computation details.

    Attributes:
        saft: Switching Activity Factor per Token — transistor transitions per output.
        lsrt: Logic State Residence Time — fraction of time in stable states.
        ecu: Energy per Capability Unit — joules per unit of task performance.
        mcer: Memory-Compute Energy Ratio — >1 means memory-bound.
        ddev: Data-Dependent Energy Variation — coefficient of variation across inputs.
        cpto: Capability per Transistor Operation — task performance per TO.
    """

    saft: float
    lsrt: float
    ecu: float
    mcer: float
    ddev: float
    cpto: float

    def __post_init__(self) -> None:
        """Validate metric values."""
        if self.mcer < 0:
            raise ValueError(f"MCER cannot be negative: {self.mcer}")
        if self.ddev < 0:
            raise ValueError(f"DDEV cannot be negative: {self.ddev}")

    @property
    def is_memory_bound(self) -> bool:
        """Whether the model is memory-bound (MCER > 1)."""
        return self.mcer > 1.0


@dataclass(frozen=True)
class BaselineMetrics:
    """Traditional metrics computed as a baseline for comparison.

    These are the conventional measures that NEXUS aims to improve upon.

    Attributes:
        flops: Floating-point operations count.
        macs: Multiply-accumulate operations count.
        parameters: Total trainable parameters.
        model_size_bytes: Size of model weights in bytes.
        throughput_samples_per_sec: Inference throughput.
        latency_seconds: Per-sample inference latency.
    """

    flops: int = 0
    macs: int = 0
    parameters: int = 0
    model_size_bytes: int = 0
    throughput_samples_per_sec: float = 0.0
    latency_seconds: float = 0.0


@dataclass(frozen=True)
class ComparisonResult:
    """Side-by-side comparison of NEXUS vs baseline analysis.

    This is a core deliverable: demonstrating that NEXUS-guided
    analysis provides better energy prediction than FLOPs alone.

    Attributes:
        model_name: Identifier for the model being compared.
        nexus_metrics: NEXUS metric values.
        baseline_metrics: Traditional metric values.
        nexus_predicted_energy_j: NEXUS energy prediction in joules.
        flops_predicted_energy_j: FLOP-based energy prediction in joules.
        measured_energy_j: Actual measured energy (ground truth) in joules.
    """

    model_name: str
    nexus_metrics: NexusMetrics
    baseline_metrics: BaselineMetrics
    nexus_predicted_energy_j: float | None = None
    flops_predicted_energy_j: float | None = None
    measured_energy_j: float | None = None

    @property
    def nexus_error_pct(self) -> float | None:
        """Percentage error of NEXUS prediction vs measured."""
        if self.nexus_predicted_energy_j is None or self.measured_energy_j is None:
            return None
        if self.measured_energy_j == 0:
            return None
        return abs(
            self.nexus_predicted_energy_j - self.measured_energy_j
        ) / self.measured_energy_j * 100

    @property
    def flops_error_pct(self) -> float | None:
        """Percentage error of FLOP-based prediction vs measured."""
        if self.flops_predicted_energy_j is None or self.measured_energy_j is None:
            return None
        if self.measured_energy_j == 0:
            return None
        return abs(
            self.flops_predicted_energy_j - self.measured_energy_j
        ) / self.measured_energy_j * 100
