"""Transistor operation counting for ML model components.

This module maps high-level ML operations (convolutions, matrix multiplies,
attention, tree traversals) to transistor operation counts using the
β-coefficients from the coefficients module.

The mapping is architecture-aware: a Conv2D layer's operation count
depends on kernel size, channels, spatial dimensions, and precision.
"""

from __future__ import annotations

from nexus_ml.core.coefficients import BetaCoefficientTable
from nexus_ml.core.types import (
    EnergyDomain,
    LayerProfile,
    OperationCount,
    OperationType,
    Precision,
    TransistorOperations,
)


def count_mac_operations(
    *,
    input_elements: int,
    output_elements: int,
    weight_elements: int,
    precision: Precision = Precision.FP32,
) -> OperationCount:
    """Count multiply-accumulate operations for a linear/conv layer.

    Args:
        input_elements: Total input activation elements.
        output_elements: Total output activation elements.
        weight_elements: Total weight parameters.
        precision: Numerical precision.

    Returns:
        OperationCount for MAC operations.
    """
    # Standard MAC count: each output element requires one MAC per weight
    # connected to it. For dense layers: out_features × in_features MACs.
    # For conv layers: out_channels × kernel_h × kernel_w × in_channels × out_h × out_w
    #
    # NOTE: The caller provides the total MAC count; this function
    # just wraps it in the proper type. The actual counting logic
    # lives in the framework-specific backends.
    raise NotImplementedError("TODO: Implement after β-coefficient resolution")


def operations_to_transistor_ops(
    operation: OperationCount,
    coefficient_table: BetaCoefficientTable,
) -> TransistorOperations:
    """Convert an operation count to transistor operations using β-coefficients.

    This is the core NEXUS transformation: from framework-level operation
    counts to physics-grounded transistor operation counts.

    Args:
        operation: The operation count to convert.
        coefficient_table: The β-coefficient lookup table.

    Returns:
        TransistorOperations with the computed TO count.
    """
    beta = coefficient_table.get(operation.op_type, operation.precision)

    total_tos = int(operation.count * beta.value)

    # Classify the energy domain
    if operation.op_type in (OperationType.MEMORY_READ, OperationType.MEMORY_WRITE,
                              OperationType.CACHE_ACCESS):
        domain = EnergyDomain.MEMORY
    elif operation.op_type in (OperationType.MAC, OperationType.MULTIPLY,
                                OperationType.ADD, OperationType.RELU,
                                OperationType.SIGMOID, OperationType.TANH,
                                OperationType.GELU, OperationType.SWIGLU,
                                OperationType.SOFTMAX, OperationType.DIVIDE,
                                OperationType.COMPARISON, OperationType.LEAF_ACCUMULATE,
                                OperationType.ATTENTION_SCORE,
                                OperationType.ATTENTION_SOFTMAX):
        domain = EnergyDomain.COMPUTE
    else:
        domain = EnergyDomain.OVERHEAD

    return TransistorOperations(
        operation=operation,
        beta_coefficient=beta.value,
        total_tos=total_tos,
        energy_domain=domain,
    )
