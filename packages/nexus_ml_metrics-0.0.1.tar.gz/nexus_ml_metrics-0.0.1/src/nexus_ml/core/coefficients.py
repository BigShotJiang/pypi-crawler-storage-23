"""β-coefficient definitions derived from semiconductor physics.

This module contains the transistor operation (TO) counts per operation type,
derived from Horowitz (ISSCC 2014) energy data and circuit complexity analysis.

IMPORTANT: The exact numerical values here are subject to validation.
See FRAMEWORK_REVIEW.md for known issues with Horowitz source data
ambiguity that must be resolved before these values are finalized.

References:
    Horowitz, M. (2014). "Computing's Energy Problem (and what we can
    do about it)." ISSCC 2014. DOI: 10.1109/ISSCC.2014.6757323

    Li et al. (2024). Transistor operation counting for CNN energy analysis.

TODO: Resolve Horowitz FP32 multiply value (3.7 vs 4.0 pJ) — see FRAMEWORK_REVIEW.md
TODO: Resolve FP16 multiply value (1.0 vs 1.1 pJ)
TODO: Validate FMA additivity assumption with independent data
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nexus_ml.core.types import OperationType, Precision


@dataclass(frozen=True)
class BetaCoefficient:
    """A single β-coefficient: transistor operations per operation instance.

    Attributes:
        op_type: The operation this coefficient applies to.
        precision: The numerical precision.
        value: Transistor operations per operation instance.
        source: Provenance of this value (e.g., 'horowitz_2014', 'derived').
        confidence: Confidence level ('verified', 'derived', 'estimated').
        notes: Any caveats or assumptions.
    """

    op_type: OperationType
    precision: Precision
    value: float
    source: str = "unknown"
    confidence: str = "estimated"
    notes: str = ""


class BetaCoefficientTable:
    """Registry of all β-coefficients used by NEXUS.

    This is the single source of truth for transistor operation counts.
    All values must be traceable to either:
    - Direct Horowitz (2014) measurements
    - Circuit complexity derivations from Horowitz data
    - Experimentally validated measurements

    No fabricated or assumed values are permitted.
    """

    def __init__(self) -> None:
        """Initialize with default coefficient table."""
        self._coefficients: dict[tuple[OperationType, Precision], BetaCoefficient] = {}
        self._load_defaults()

    def _load_defaults(self) -> None:
        """Load the default β-coefficient table.

        NOTE: These values are PLACEHOLDERS pending resolution of
        Horowitz source data ambiguity. See FRAMEWORK_REVIEW.md.
        """
        # TODO: Replace with verified values after resolving Horowitz data
        # For now, using Li et al. (2024) / Horowitz slide values as starting point
        #
        # The values below are from the existing TOML model (toml_modelv3.py)
        # and need independent verification before publication.
        pass

    def get(
        self,
        op_type: OperationType,
        precision: Precision,
    ) -> BetaCoefficient:
        """Look up the β-coefficient for a given operation and precision.

        Args:
            op_type: The operation type.
            precision: The numerical precision.

        Returns:
            The BetaCoefficient for this operation/precision combination.

        Raises:
            KeyError: If no coefficient is defined for this combination.
        """
        key = (op_type, precision)
        if key not in self._coefficients:
            raise KeyError(
                f"No β-coefficient defined for {op_type.name} at {precision.name}. "
                f"Available: {self.list_available()}"
            )
        return self._coefficients[key]

    def set(self, coefficient: BetaCoefficient) -> None:
        """Set or override a β-coefficient.

        This allows users to provide their own measured coefficients
        for custom hardware or to update values as new data becomes available.

        Args:
            coefficient: The β-coefficient to register.
        """
        key = (coefficient.op_type, coefficient.precision)
        self._coefficients[key] = coefficient

    def list_available(self) -> list[tuple[str, str]]:
        """Return all defined (op_type, precision) combinations."""
        return [(op.name, prec.name) for op, prec in self._coefficients]

    def to_dict(self) -> dict[str, Any]:
        """Export all coefficients as a serializable dictionary."""
        result = {}
        for (op_type, precision), coef in self._coefficients.items():
            key = f"{op_type.name}_{precision.name}"
            result[key] = {
                "value": coef.value,
                "source": coef.source,
                "confidence": coef.confidence,
                "notes": coef.notes,
            }
        return result
