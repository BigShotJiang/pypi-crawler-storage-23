"""Backend auto-detection and registration.

Backends register themselves here. The registry auto-detects which
backends are available based on installed packages (e.g., if torch
is installed, the PyTorch backend is available).
"""

from __future__ import annotations

from typing import Any

from nexus_ml.backends.base import ModelBackend

# Registry of available backends, populated at import time
_BACKENDS: dict[str, type[ModelBackend]] = {}


def register_backend(name: str, backend_cls: type[ModelBackend]) -> None:
    """Register a model backend.

    Args:
        name: Unique identifier for the backend (e.g., 'pytorch').
        backend_cls: The backend class (must subclass ModelBackend).

    Raises:
        TypeError: If backend_cls is not a subclass of ModelBackend.
        ValueError: If a backend with this name is already registered.
    """
    if not (isinstance(backend_cls, type) and issubclass(backend_cls, ModelBackend)):
        raise TypeError(
            f"Backend must be a subclass of ModelBackend, got {backend_cls}"
        )
    if name in _BACKENDS:
        raise ValueError(f"Backend '{name}' is already registered")
    _BACKENDS[name] = backend_cls


def get_backend(name: str) -> ModelBackend:
    """Get an instantiated backend by name.

    Args:
        name: The backend identifier (e.g., 'pytorch').

    Returns:
        An instantiated ModelBackend.

    Raises:
        KeyError: If no backend with this name is registered.
    """
    if name not in _BACKENDS:
        available = list(_BACKENDS.keys())
        raise KeyError(
            f"Backend '{name}' not found. Available backends: {available}"
        )
    return _BACKENDS[name]()


def detect_backend(model: Any) -> ModelBackend:
    """Auto-detect the appropriate backend for a model.

    Iterates through registered backends and returns the first
    one that reports compatibility with the model.

    Args:
        model: The ML model to find a backend for.

    Returns:
        An instantiated ModelBackend compatible with the model.

    Raises:
        RuntimeError: If no compatible backend is found.
    """
    for name, backend_cls in _BACKENDS.items():
        backend = backend_cls()
        if backend.is_compatible(model):
            return backend

    raise RuntimeError(
        f"No compatible backend found for model of type {type(model).__name__}. "
        f"Available backends: {list(_BACKENDS.keys())}. "
        f"Install the appropriate extra (e.g., pip install nexus-ml[pytorch])."
    )


def list_backends() -> list[str]:
    """Return names of all registered backends."""
    return list(_BACKENDS.keys())


def _auto_discover_backends() -> None:
    """Attempt to import and register all known backends.

    This is called at module import time. Each backend module
    handles its own ImportError if its framework is not installed.
    """
    # PyTorch backend
    try:
        from nexus_ml.backends.pytorch import PyTorchBackend
        register_backend("pytorch", PyTorchBackend)
    except ImportError:
        pass

    # XGBoost backend
    try:
        from nexus_ml.backends.xgboost_backend import XGBoostBackend
        register_backend("xgboost", XGBoostBackend)
    except ImportError:
        pass

    # scikit-learn backend
    try:
        from nexus_ml.backends.sklearn_backend import SklearnBackend
        register_backend("sklearn", SklearnBackend)
    except ImportError:
        pass


# Auto-discover on import
_auto_discover_backends()
