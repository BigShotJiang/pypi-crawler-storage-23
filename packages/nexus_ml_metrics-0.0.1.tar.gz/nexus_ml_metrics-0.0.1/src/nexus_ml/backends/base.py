"""Abstract base class for ML framework backends.

Any ML framework (PyTorch, TensorFlow, XGBoost, scikit-learn, etc.)
is integrated by implementing this interface. The core NEXUS pipeline
is completely framework-agnostic — it only works with the types
defined in core.types.

To add support for a new framework:
    1. Subclass ModelBackend
    2. Implement all abstract methods
    3. Register via the backends.registry module
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from nexus_ml.core.types import (
    ArchitectureType,
    BaselineMetrics,
    LayerProfile,
    ModelProfile,
    Precision,
)


class ModelBackend(ABC):
    """Abstract interface for ML framework adapters.

    A backend translates framework-specific model representations
    into NEXUS's framework-agnostic types (ModelProfile, LayerProfile, etc.).

    It also provides the reverse direction: applying optimizations
    back to the framework-specific model.
    """

    @property
    @abstractmethod
    def framework_name(self) -> str:
        """Return the name of the ML framework (e.g., 'pytorch', 'xgboost')."""
        ...

    @abstractmethod
    def extract_profile(
        self,
        model: Any,
        *,
        input_shape: tuple[int, ...] | None = None,
        sample_input: Any | None = None,
        precision: Precision = Precision.FP32,
    ) -> ModelProfile:
        """Extract a NEXUS ModelProfile from a framework-specific model.

        This is the primary analysis entry point. The backend must:
        1. Walk the model's layer/module structure
        2. For each layer, compute operation counts (MACs, memory accesses, etc.)
        3. Package everything into LayerProfile and ModelProfile objects

        Args:
            model: The ML model in its native framework representation.
            input_shape: Shape of a single input sample (without batch dimension).
            sample_input: An actual input tensor for tracing (alternative to input_shape).
            precision: The numerical precision the model will run at.

        Returns:
            A complete ModelProfile with per-layer operation counts.

        Raises:
            TypeError: If the model is not compatible with this backend.
            ValueError: If neither input_shape nor sample_input is provided
                and the backend cannot infer shapes.
        """
        ...

    @abstractmethod
    def detect_architecture_type(self, model: Any) -> ArchitectureType:
        """Detect the high-level architecture type of a model.

        Args:
            model: The ML model in its native framework representation.

        Returns:
            The detected ArchitectureType.
        """
        ...

    @abstractmethod
    def compute_baseline_metrics(
        self,
        model: Any,
        *,
        input_shape: tuple[int, ...] | None = None,
        sample_input: Any | None = None,
    ) -> BaselineMetrics:
        """Compute traditional baseline metrics (FLOPs, MACs, parameters).

        This wraps established libraries (fvcore, ptflops, etc.) for the
        specific framework to provide the conventional metrics that NEXUS
        is compared against.

        Args:
            model: The ML model in its native framework representation.
            input_shape: Shape of a single input sample.
            sample_input: An actual input tensor for tracing.

        Returns:
            BaselineMetrics with FLOPs, MACs, parameter count, etc.
        """
        ...

    @abstractmethod
    def get_layer_names(self, model: Any) -> list[str]:
        """Return ordered list of layer/module names in the model.

        Args:
            model: The ML model in its native framework representation.

        Returns:
            List of layer identifiers in execution order.
        """
        ...

    @abstractmethod
    def apply_quantization(
        self,
        model: Any,
        *,
        target_precision: Precision,
        layer_names: list[str] | None = None,
    ) -> Any:
        """Apply quantization to the model (or specific layers).

        Args:
            model: The ML model to quantize.
            target_precision: The target precision (e.g., FP16, INT8).
            layer_names: If provided, only quantize these layers.
                If None, quantize the entire model.

        Returns:
            The quantized model in the framework's native representation.
        """
        ...

    @abstractmethod
    def apply_pruning(
        self,
        model: Any,
        *,
        sparsity: float,
        layer_names: list[str] | None = None,
    ) -> Any:
        """Apply weight pruning to the model (or specific layers).

        Args:
            model: The ML model to prune.
            sparsity: Target sparsity ratio (0.0 = no pruning, 1.0 = all zeros).
            layer_names: If provided, only prune these layers.

        Returns:
            The pruned model in the framework's native representation.
        """
        ...

    def is_compatible(self, model: Any) -> bool:
        """Check if this backend can handle the given model.

        Override this to implement framework-specific type checking.
        The default implementation always returns False.

        Args:
            model: The ML model to check.

        Returns:
            True if this backend can process the model.
        """
        return False
