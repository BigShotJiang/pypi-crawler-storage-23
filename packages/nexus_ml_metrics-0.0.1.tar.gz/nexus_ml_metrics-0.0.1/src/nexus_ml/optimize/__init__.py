"""Optimization application stage."""
