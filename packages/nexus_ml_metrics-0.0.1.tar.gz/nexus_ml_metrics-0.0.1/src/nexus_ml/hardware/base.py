"""Abstract base class for hardware measurement backends.

Hardware backends handle the physical energy measurement layer.
Each backend wraps platform-specific tools (NCU for NVIDIA,
LibreHardwareMonitor for CPU, etc.) behind a common interface.

To add support for new hardware:
    1. Subclass HardwareBackend
    2. Implement all abstract methods
    3. Register via the hardware.registry module
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from nexus_ml.core.types import EnergyMeasurement


class HardwareBackend(ABC):
    """Abstract interface for hardware energy measurement adapters.

    A hardware backend collects actual energy measurements from
    physical hardware, providing the ground truth that validates
    NEXUS's transistor-operation-based predictions.
    """

    @property
    @abstractmethod
    def hardware_name(self) -> str:
        """Return the name of the hardware platform (e.g., 'nvidia_gpu', 'cpu')."""
        ...

    @abstractmethod
    def is_available(self) -> bool:
        """Check if this hardware backend is usable on the current system.

        This should verify that:
        - The required hardware is present
        - Required drivers/tools are installed
        - The backend has necessary permissions

        Returns:
            True if the backend can perform measurements.
        """
        ...

    @abstractmethod
    def measure_inference(
        self,
        run_fn: Any,
        *,
        num_runs: int = 5,
        warmup_runs: int = 3,
    ) -> EnergyMeasurement:
        """Measure energy consumption of an inference workload.

        The backend should:
        1. Perform warmup runs (discarded)
        2. Measure idle baseline power
        3. Run the workload num_runs times
        4. Compute average energy with idle baseline subtracted
        5. Report statistical metrics (CV, peak power, etc.)

        Args:
            run_fn: A callable that performs one inference pass.
                Must be callable with no arguments.
            num_runs: Number of measurement runs to average.
            warmup_runs: Number of warmup runs before measurement.

        Returns:
            An EnergyMeasurement with the collected data.
        """
        ...

    @abstractmethod
    def measure_idle_power(self, duration_seconds: float = 5.0) -> float:
        """Measure the idle power draw of the hardware.

        This baseline is subtracted from workload measurements to
        isolate the energy consumed by the computation itself.

        Args:
            duration_seconds: How long to measure idle power.

        Returns:
            Average idle power in watts.
        """
        ...

    @abstractmethod
    def get_hardware_info(self) -> dict[str, Any]:
        """Return hardware identification and capability information.

        Returns:
            Dictionary with keys like 'device_name', 'memory_gb',
            'tdp_watts', 'compute_capability', etc.
        """
        ...
