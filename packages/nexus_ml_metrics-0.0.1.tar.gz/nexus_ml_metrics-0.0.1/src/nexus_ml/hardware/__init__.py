"""Hardware measurement backend adapters."""
