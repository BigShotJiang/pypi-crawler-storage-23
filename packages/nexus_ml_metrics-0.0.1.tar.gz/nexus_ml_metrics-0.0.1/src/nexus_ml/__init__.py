"""NEXUS-ML: Physics-grounded energy efficiency framework for ML systems."""

__version__ = "0.0.1"
