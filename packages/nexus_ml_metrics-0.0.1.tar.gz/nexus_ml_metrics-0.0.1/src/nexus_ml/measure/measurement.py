"""Measurement orchestration — coordinates hardware backends for energy data."""
