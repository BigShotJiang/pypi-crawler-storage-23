"""Hardware energy measurement stage."""
