"""Side-by-side comparison of NEXUS vs traditional baseline metrics."""
