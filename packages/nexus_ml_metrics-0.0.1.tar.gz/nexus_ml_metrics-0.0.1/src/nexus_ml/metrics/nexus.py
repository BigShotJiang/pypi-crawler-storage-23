"""NEXUS metric computation: SAF-T, LSRT, ECU, MCER, DDEV, CpTO.

Each metric is computed from transistor operation counts, measured energy,
and model capability data — never from FLOPs or other proxy metrics.
"""

import numpy as np

from nexus_ml.core.types import (
    EnergyMeasurement,
    ModelProfile,
    NexusMetrics,
)


def compute_saft(total_switching_ops: int, num_outputs: int) -> float:
    """Compute SAF-T: Switching Activity Factor per Token.

    Args:
        total_switching_ops: Total transistor switching operations.
        num_outputs: Number of output tokens/samples produced.

    Returns:
        SAF-T value. Lower indicates more efficient per output.

    Raises:
        ValueError: If num_outputs is zero.
    """
    if num_outputs == 0:
        raise ValueError("num_outputs must be > 0")
    return total_switching_ops / num_outputs


def compute_lsrt(time_stable_s: float, time_total_s: float) -> float:
    """Compute LSRT: Logic State Residence Time.

    Args:
        time_stable_s: Time transistors spend in stable (non-switching) states.
        time_total_s: Total computation time.

    Returns:
        LSRT value in [0, 1]. Higher means more static power dominance.

    Raises:
        ValueError: If time_total_s is zero.
    """
    if time_total_s == 0:
        raise ValueError("time_total_s must be > 0")
    return time_stable_s / time_total_s


def compute_ecu(energy_j: float, capability_score: float) -> float:
    """Compute ECU: Energy per Capability Unit.

    Args:
        energy_j: Total energy consumed in joules.
        capability_score: Model capability (e.g., accuracy percentage).

    Returns:
        ECU in joules per capability unit. Lower is better.

    Raises:
        ValueError: If capability_score is zero.
    """
    if capability_score == 0:
        raise ValueError("capability_score must be > 0")
    return energy_j / capability_score


def compute_mcer(memory_energy_j: float, compute_energy_j: float) -> float:
    """Compute MCER: Memory-Compute Energy Ratio.

    Args:
        memory_energy_j: Energy consumed by memory operations.
        compute_energy_j: Energy consumed by compute operations.

    Returns:
        MCER value. >1 means memory-bound, <1 means compute-bound.

    Raises:
        ValueError: If compute_energy_j is zero.
    """
    if compute_energy_j == 0:
        raise ValueError("compute_energy_j must be > 0")
    return memory_energy_j / compute_energy_j


def compute_ddev(energy_measurements: list[float]) -> float:
    """Compute DDEV: Data-Dependent Energy Variation.

    Args:
        energy_measurements: Energy measurements across different input data.
            Each measurement should use the same model on different inputs.

    Returns:
        DDEV as coefficient of variation (std/mean). Higher means more
        data-dependent.

    Raises:
        ValueError: If fewer than 2 measurements provided.
    """
    if len(energy_measurements) < 2:
        raise ValueError("At least 2 measurements required for DDEV")
    arr = np.array(energy_measurements, dtype=np.float64)
    mean = np.mean(arr)
    if mean == 0:
        return 0.0
    return float(np.std(arr, ddof=1) / mean)


def compute_cpto(capability_score: float, total_switching_ops: int) -> float:
    """Compute CpTO: Capability per Transistor Operation.

    Args:
        capability_score: Model capability (e.g., accuracy percentage).
        total_switching_ops: Total transistor switching operations.

    Returns:
        CpTO value. Higher means more capability per energy spent.

    Raises:
        ValueError: If total_switching_ops is zero.
    """
    if total_switching_ops == 0:
        raise ValueError("total_switching_ops must be > 0")
    return capability_score / total_switching_ops
