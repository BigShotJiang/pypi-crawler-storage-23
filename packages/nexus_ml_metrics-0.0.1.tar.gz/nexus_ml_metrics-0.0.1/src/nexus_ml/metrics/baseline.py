"""Baseline metric computation wrapping established libraries (fvcore, ptflops)."""
