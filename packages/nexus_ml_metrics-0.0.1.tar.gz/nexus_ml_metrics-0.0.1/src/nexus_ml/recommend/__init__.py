"""Optimization recommendation stage."""
