"""Energy bottleneck diagnosis stage."""
