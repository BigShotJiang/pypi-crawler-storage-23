"""Per-layer transistor operation and energy breakdown."""
