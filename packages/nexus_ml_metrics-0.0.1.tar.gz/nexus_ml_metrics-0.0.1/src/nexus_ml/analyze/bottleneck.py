"""Identify dominant energy consumers at the layer and operation level."""
