"""Main analysis orchestrator — coordinates profiling and decomposition."""
