#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2026 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class BioconductorIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "bioconductor"

    @property
    def original_file_name(self) -> "str":
        return "bioconductor.svg"

    @property
    def title(self) -> "str":
        return "Bioconductor"

    @property
    def primary_color(self) -> "str":
        return "#1A81C2"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Bioconductor</title>
     <path d="M15.103 0a.649.649 0 1 0 .001 1.298.649.649 0 0 0
 0-1.298m7.473.031a.69.69 0 1 0 .001 1.38.69.69 0 0 0
 0-1.38M7.757.727a.663.663 0 1 0 .001 1.325.663.663 0 0 0
 0-1.325m5.87.053a.495.495 0 1 0 0 .99.495.495 0 0 0
 0-.99m3.256.07a.663.663 0 1 0 0 1.325.662.662 0 0 0
 0-1.324m-7.275.596a.755.755 0 0 0-.756.758.755.755 0 1 0 1.51 0
 .755.755 0 0 0-.754-.758m-3.373.395a.59.59 0 0 0-.596.588c0
 .325.267.59.596.59.33 0 .597-.265.596-.59a.59.59 0 0
 0-.596-.588m6.397.1a.347.347 0 1 0-.002.693.347.347 0 0 0
 .002-.694m8.941.034a.455.455 0 1 0 0 .91.455.455 0 0 0
 0-.91m-3.065.108a.808.808 0 1 0-.002 1.615.808.808 0 0 0
 .002-1.615m-7.183.607a.935.935 0 1 0 0 1.87.935.935 0 0 0
 0-1.87m-5.978.541a.39.39 0 1 0 0 .78.39.39 0 0 0
 0-.78m15.203.217a.865.865 0 1 0 .003 1.73.865.865 0 0
 0-.003-1.73m-7.52.857a.736.736 0 1 0 .004 1.472.736.736 0 0
 0-.003-1.472m-3.63.12a.579.579 0 1 0 .002 1.158.579.579 0 0
 0-.002-1.158M22 4.762a.499.499 0 1 0 .002.998.499.499 0 0
 0-.002-.998m-17.05.094c-.01 4.734.082 13.81-.009
 14.286-.39-.202-1.113-.406-2.135-.012-1.13.435-2.007 1.386-2.216
 2.404a4 4 0 0 0-.004 1.24c.13.688.554 1.116 1.193 1.204a3.8 3.8 0 0 0
 1.182-.059c1.006-.262 1.94-1.01
 2.38-1.91.291-.597.266.227.264-8.703L5.604
 5.37c-.22-.167-.435-.342-.652-.514m2.477.137a.792.792 0 1 0 .001
 1.583.792.792 0 0 0 0-1.583m11.858.06a.295.295 0 1 0 .001.59.295.295
 0 0 0 0-.59m-4.245.516a.639.639 0 1 0 0 1.277.639.639 0 0 0
 0-1.277m8.068.078a.347.347 0 1 0 0 .694.347.347 0 0 0
 0-.694m-4.82.08a.387.387 0 1 0 0 .774.387.387 0 0 0
 0-.774m-1.294.58a.488.488 0 1 0 0 .975.488.488 0 0 0 0-.976" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return '''https://github.com/Bioconductor/BiocStickers/
blob/2e3af2dd45ce43e18110c91b687ebcb996cffae9/Bioconductor/Bioconducto'''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
