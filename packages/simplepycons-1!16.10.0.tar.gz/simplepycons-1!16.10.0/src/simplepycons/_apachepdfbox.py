#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2026 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class ApachePdfboxIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "apachepdfbox"

    @property
    def original_file_name(self) -> "str":
        return "apachepdfbox.svg"

    @property
    def title(self) -> "str":
        return "Apache PDFBox"

    @property
    def primary_color(self) -> "str":
        return "#34A5DA"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Apache PDFBox</title>
     <path d="M22.3345 1.8808c.0165.7973.1099 1.5857.2759
 2.3557.1628.7548.3977 1.5025.8023
 2.1732.1488.246.3186.4783.5077.6948a.475.475 0 0 1 .0404.4526 877 877
 0 0 0-6.8253 1.99 841 841 0 0 0-6.8254 2.0531.26.26 0 0 1
 .0328-.1744.268.268 0 0 1 .2127-.1315l11.4106-4.3878a14.7 14.7 0 0
 1-.3442-2.5002 14.67 14.67 0 0 1 .0849-2.4784.3296.3296 0 0 1
 .3673-.2623.316.316 0 0 1 .2585.217zM20.872.8805q-.015
 0-.0304.0032L5.5643
 1.9407c-.4358.0307-.8229.2841-1.0334.667-.2918.5312-.1966 1.1877.2464
 1.5853.1198.1076.2614.1887.377.301a.96.96 0 0 1 .2152.313 3.998 3.998
 0 0 1 .7178 4.1209 3.83 3.83 0 0 1-.891 1.3335l-3.0991-.6766
 1.9623-4.871a.2404.2404 0 0 0-.1177-.3569.232.232 0 0
 0-.2955.1303L1.313 9.4045l-.4955-.1816a.298.298 0 0
 0-.242.0767.294.294 0 0 0-.0909.1716L0 17.444a.3594.3594 0 0 0
 .5464-.0168 26.97 26.97 0 0 0 .9775-6.8762l5.7242.6422a.65.65 0 0 0
 .322.0567.66.66 0 0 0 .322-.1147 407 407 0 0 1 5.2662-2.3868 416 416
 0 0 1 5.2619-2.2981.28.28 0 0 1 .2035.1147.282.282 0 0 1 .0398.2539
 4.34 4.34 0 0 0-.8405
 1.0448c.005.0143.009.0286.0147.0425.0134.0357.0294.0706.0525.1012a.284.284
 0 0 0 .4186.0353 4.018 4.018 0 0 1 2.7288-1.335.4.4 0 0 0
 .1862-.3126.39.39 0 0 0-.0656-.2444 1.134 1.134 0 0
 1-.8515-.3062l.8217-3.284a.676.676 0 0 0-.5233-.244 133.2 133.2 0 0
 1-13.428.5112c-.1592.0242-.2866-.13-.2328-.2816a.189.189 0 0 1
 .1765-.1259L20.6455 1.325a1.23 1.23 0 0 0
 .2412-.1337c.0614-.0435.1256-.0994.1239-.1824-.001-.0735-.0624-.1298-.1326-.1307zm-.9923
 2.3544a.198.198 0 0 1 .1339.1692l-.5447 1.4865a1.966 1.966 0 0
 1-.8479.6157L7.66 7.9713l-.883-3.3971 13.1002-1.3399Zm3.9342
 9.2118L8.7384 23.1217.1731 19.8916a11.66 11.66 0 0 0 2.8722-1.147
 11.88 11.88 0 0 0 5.3922-6.4555.488.488 0 0 1 .5573-.2298.483.483 0 0
 1 .351.4307l-.15 7.9055 14.0794-8.1534a.424.424 0 0 1
 .3169-.0032.422.422 0 0 1 .2235.2044zm-.0549-4.115.005
 3.2916a.288.288 0 0 1-.2604.1997.291.291 0 0
 1-.2897-.1997l.0542-3.3429a.2434.2434 0 0 1 .2452-.2118.249.249 0 0 1
 .2452.2627z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
