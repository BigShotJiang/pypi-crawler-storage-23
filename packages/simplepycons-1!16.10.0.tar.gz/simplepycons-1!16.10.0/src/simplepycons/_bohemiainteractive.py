#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2026 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class BohemiaInteractiveIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "bohemiainteractive"

    @property
    def original_file_name(self) -> "str":
        return "bohemiainteractive.svg"

    @property
    def title(self) -> "str":
        return "Bohemia Interactive"

    @property
    def primary_color(self) -> "str":
        return "#6BA539"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Bohemia Interactive</title>
     <path d="m18.225
 12.831.036-.109c.684-2.231.411-4.3-.774-5.817a5.666 5.666 0 0
 0-3.513-2.068L15.88 0h-1.457s-.696 2.261-1.53 4.728a8.157 8.157 0 0
 0-.859 0 12.166 12.166 0 0 0-6.736 2.685 11.314 11.314 0 0 0-3.49
 4.076h1.21A10.382 10.382 0 0 1 5.841 8.12a11.314 11.314 0 0 1
 6.234-2.497h.514c-.096.284-.2.562-.296.84-.38 1.07-1.288 3.58-2.304
 6.374H6.64l-1.511 2.128a22.664 22.664 0 0 1 4.408-.87c-.798
 2.195-1.62 4.456-2.274 6.264-2.038.115-3.858-.483-4.989-1.771a4.233
 4.233 0 0 1-1.021-1.96l-.49-.46a5.243 5.243 0 0 0 1.064 2.952 6.156
 6.156 0 0 0 4.983 2.17h.09L5.938 24l.604-.466.901-2.268a12.281 12.281
 0 0 0 6.555-2.66 12.529 12.529 0 0 0
 3.955-5.08H22.766l.472-.67zm-4.583-7.13a4.898 4.898 0 0 1 3.144
 1.748c.998 1.288 1.21 3.066.605
 5.013-.037.12-.079.248-.121.369h-6.458zm-.182 12.204a11.489 11.489 0
 0 1-5.624 2.418l2.504-6.307c1.711-.193 3.9-.362 6.651-.44a11.87 11.87
 0 0 1-3.53 4.329z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
