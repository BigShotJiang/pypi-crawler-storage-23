#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2026 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class ApacheRocketmqIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "apacherocketmq"

    @property
    def original_file_name(self) -> "str":
        return "apacherocketmq.svg"

    @property
    def title(self) -> "str":
        return "Apache RocketMQ"

    @property
    def primary_color(self) -> "str":
        return "#D77310"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Apache RocketMQ</title>
     <path d="M11.438
 23.467c-.517-.638-1.106-1.89-1.217-2.587l-.082-.511h1.835c1.435 0
 1.835.036 1.835.165 0 .352-.412 1.553-.709 2.066-.333.577-1.021
 1.41-1.155
 1.4-.043-.004-.272-.244-.507-.533zm-4.532-4.193c-1.251-3.005-1.231-6.784.056-10.63.786-2.35
 2.652-5.689 4.413-7.9L11.967 0l.422.493c.763.893 2.612 3.731 3.28
 5.036 1.32 2.578 2.055 4.993 2.264 7.438.197 2.302-.176 4.837-.962
 6.533l-.338.731-.727-.433-.727-.433H11.95c-2.466
 0-3.287.039-3.476.166-.136.091-.453.29-.705.441l-.458.276-.405-.974zm9.338-1.79c.779-2.623.532-6.253-.635-9.344-.683-1.81-2.085-4.319-3.211-5.747-.357-.452-.387-.466-.609-.265-.441.398-1.854
 2.622-2.544 4.002-1.927 3.856-2.484 7.995-1.521
 11.308l.196.672h8.138l.186-.626zM3.311
 19.835c.037-.155.108-.565.157-.909.079-.549.189-.729.885-1.443l.795-.815.002.507c.003.641.302
 1.799.631
 2.445l.254.498H4.64c-1.384-.001-1.396-.003-1.329-.283zm14.944-.376c.271-.613.529-1.616.606-2.352.031-.299.066-.282.762.379s.738.735.908
 1.631c.098.516.179.952.179.97 0
 .017-.618.031-1.373.031h-1.373l.291-.659zm-6.477-4.504a2.173 2.173 0
 0 1-2.17-2.17c0-1.196.973-2.17 2.17-2.17s2.17.973 2.17 2.17-.973
 2.17-2.17 2.17zm0-3.865c-.935 0-1.696.761-1.696 1.695s.761 1.696
 1.696 1.696c.935 0 1.696-.761
 1.696-1.696s-.761-1.695-1.696-1.695zM9.455 9.457a.657.657 0 1 1 0
 1.314.657.657 0 0 1 0-1.314zm-.357 4.665a.8.8 0 1 1 0 1.6.8.8 0 0 1
 0-1.6zm5.212-5.18a1.069 1.069 0 1 1 0 2.138 1.069 1.069 0 0 1
 0-2.138zm0 5.75a1.418 1.418 0 1 1 0 2.836 1.418 1.418 0 0 1
 0-2.836zM9.447
 10.68l.491-.491.729.729-.491.491-.729-.729zm4.066-.336l.539.539-.729.729-.539-.539.729-.729zm-3.572
 3.362l.491.491-.729.729-.491-.491.729-.729zm2.721
 1.064l.61-.59.779.754-.61.59-.779-.754zm-1.717-2.167a.277.277 0 1 1 0
 .554.277.277 0 0 1 0-.554zm.794 0a.277.277 0 1 1 0 .554.277.277 0 0 1
 0-.554zm.794 0a.277.277 0 1 1 0 .554.277.277 0 0 1 0-.554z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
