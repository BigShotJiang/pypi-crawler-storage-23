#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2026 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class BrandfetchIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "brandfetch"

    @property
    def original_file_name(self) -> "str":
        return "brandfetch.svg"

    @property
    def title(self) -> "str":
        return "Brandfetch"

    @property
    def primary_color(self) -> "str":
        return "#0084FF"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Brandfetch</title>
     <path d="M23.226 5.842c0 1.491-.53 2.78-1.589 3.869-1.059
 1.07-2.603 1.842-4.633 2.315 1.094.299 1.924.79 2.489
 1.474.565.667.847 1.439.847 2.316 0 1.386-.441 2.588-1.324 3.605-.865
 1.018-2.136 1.807-3.812 2.368-1.677.544-3.698.816-6.063.816-.883
 0-1.589-.026-2.118-.079-.018.491-.23.86-.636
 1.106-.406.245-.927.368-1.562.368s-1.077-.14-1.324-.421c-.23-.28-.326-.693-.291-1.237.159-2.456.468-5.026.927-7.71a75.521
 75.521 0 0 1 1.747-7.816c.124-.439.37-.746.741-.921.371-.176.856-.263
 1.457-.263 1.076 0 1.615.298 1.615.894 0 .246-.053.527-.16.842-.458
 1.369-.917 3.228-1.376 5.58a65.729 65.729 0 0 0-.98 6.684c.848.07
 1.536.105 2.066.105 2.47 0 4.28-.351 5.427-1.053 1.165-.72
 1.747-1.631 1.747-2.737
 0-.772-.335-1.42-1.006-1.947-.653-.526-1.756-.816-3.31-.868-.352-.018-.6-.106-.74-.264-.142-.157-.212-.412-.212-.763
 0-.509.106-.92.317-1.237.212-.315.6-.482 1.165-.5 1.254-.035
 2.383-.219 3.39-.552 1.023-.334 1.826-.798
 2.409-1.395.582-.614.873-1.325.873-2.132
 0-1.017-.503-1.815-1.509-2.394C16.792 3.298 15.248 3 13.165 3c-1.889
 0-3.716.246-5.48.737-1.766.474-3.266 1.079-4.501
 1.816-.565.333-1.042.5-1.43.5-.318
 0-.565-.106-.742-.316-.158-.228-.238-.509-.238-.842
 0-.439.088-.816.265-1.132.194-.316.644-.675 1.35-1.079 1.483-.842
 3.221-1.5 5.216-1.973A26.377 26.377 0 0 1 13.721 0c3.195 0 5.577.535
 7.148 1.605 1.571 1.07 2.357 2.483 2.357 4.237z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
