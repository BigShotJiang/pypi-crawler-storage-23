#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2026 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class AcodeIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "acode"

    @property
    def original_file_name(self) -> "str":
        return "acode.svg"

    @property
    def title(self) -> "str":
        return "Acode"

    @property
    def primary_color(self) -> "str":
        return "#3499FE"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Acode</title>
     <path d="M11.846 3.139c-.38 0-.73.405-.73.956q0 .127.027.262c.765
 3.946 2.288 11.91 3 15.682.1.535.492.799.751.799h1.713c.31 0
 .743-.397.743-.756a.4.4 0 0
 0-.006-.072c-.118-.682-.243-1.404-.371-2.153a1.2 1.2 0 0 1-.64-.275
 1.37 1.37 0 0
 1-.435-.562c-.195-.483-.214-1.152.274-1.637q.138-.137.32-.322c-.686-4.002-1.413-8.274-1.889-11.079-.072-.427-.45-.843-.773-.843zm-1.666.023c-.323
 0-.701.416-.774.844-.476 2.808-1.204 7.085-1.89
 11.09l.312.314c.488.485.469 1.152.274
 1.635v.002c-.093.229-.242.41-.434.562a1.2 1.2 0 0 1-.633.274l-.369
 2.148a.4.4 0 0 0-.006.072c0 .36.432.758.742.758h1.713c.26 0
 .651-.264.752-.799.441-2.338 1.194-6.29
 1.885-9.894-.418-2.182-.812-4.232-1.1-5.715-.092-.476.006-.947.24-1.29zm6.894
 4.145c-.3-.001-.609.277-.71.529-.131.322-.131.803.161 1.094.794.788
 3.078 3.177 3.295 3.404-.217.228-2.5 2.614-3.295
 3.402-.175.175-.245.418-.245.654 0
 .158.031.313.083.442.102.252.41.53.711.53.529-.003 1.644 0 2.172 0
 .195 0 .37-.103.545-.28.953-.964 2.767-2.836
 3.781-3.912.068-.071.139-.135.194-.193a.87.87 0 0 0
 .234-.602c0-.044-.004-.098-.008-.143a.84.84 0 0
 0-.226-.54c-.055-.059-.126-.123-.194-.194a292 292 0 0
 0-3.781-3.912c-.175-.177-.35-.28-.545-.28-.528 0-1.643.003-2.172
 0m-12.32.027c-.195 0-.37.102-.545.28-.953.964-2.767 2.835-3.781
 3.911-.068.072-.139.134-.194.192a.85.85 0 0 0-.226.543 2 2 0 0
 0-.008.142c0 .168.046.403.234.602.055.058.126.122.194.193a292 292 0 0
 0 3.781 3.912c.175.177.35.28.545.28.528 0 1.643-.002 2.172 0 .3 0
 .609-.28.71-.532.131-.322.131-.803-.161-1.093-.794-.789-3.078-3.176-3.295-3.403.217-.227
 2.501-2.615 3.295-3.404.175-.174.245-.417.245-.653
 0-.157-.031-.312-.083-.44-.102-.252-.41-.531-.711-.53-.53.002-1.644
 0-2.172 0z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return '''https://github.com/Acode-Foundation/acode.app'''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
