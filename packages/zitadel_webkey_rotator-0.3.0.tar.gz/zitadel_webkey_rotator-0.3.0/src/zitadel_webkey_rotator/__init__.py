import dataclasses
import datetime
import pathlib
import tempfile
import typing as t

import cyclopts
import pydantic
import slcfg
from zitadel_client import (
    WebKeyServiceActivateWebKeyRequest,
    WebKeyServiceCreateWebKeyRequest,
    WebKeyServiceDeleteWebKeyRequest,
    WebKeyServiceECDSA,
    WebKeyServiceECDSACurve,
    WebKeyServiceRSA,
    WebKeyServiceRSABits,
    WebKeyServiceRSAHasher,
    WebKeyServiceState,
)
from zitadel_client.zitadel import Zitadel


class AccessTokenAuth(pydantic.BaseModel):
    access_token: str


class CredentialsAuth(pydantic.BaseModel):
    username: str
    password: str


class PrivateKeyAuth(pydantic.BaseModel):
    key_id: str
    private_key_pem: str
    user_id: str


type Auth = AccessTokenAuth | CredentialsAuth | PrivateKeyAuth

type RsaBits = t.Literal[2048, 3072, 4096]
type RsaHasher = t.Literal['SHA256', 'SHA384', 'SHA512']


class Rsa(pydantic.BaseModel):
    kind: t.Literal['rsa']
    bits: RsaBits
    hasher: RsaHasher


type EcdsaCurve = t.Literal['P256', 'P384', 'P512']


class Ecdsa(pydantic.BaseModel):
    kind: t.Literal['ecdsa']
    curve: EcdsaCurve


class Ed25519(pydantic.BaseModel):
    kind: t.Literal['ed25519']


type Algorithm = Rsa | Ecdsa | Ed25519


class Config(pydantic.BaseModel):
    host: str
    auth: Auth
    rotation_period: datetime.timedelta
    keep_inactive_for: datetime.timedelta
    algorithm: Algorithm


class _KeyFile(pydantic.BaseModel):
    type: t.Literal['serviceaccount'] = 'serviceaccount'
    key_id: str = pydantic.Field(alias='keyId')
    key: str
    user_id: str = pydantic.Field(alias='userId')


def get_config(  # noqa: PLR0913
    *,
    host: str | None = None,
    access_token: str | None = None,
    username: str | None = None,
    password: str | None = None,
    key_file_path: pathlib.Path | None = None,
    rotation_period: datetime.timedelta | None = None,
    keep_inactive_for: datetime.timedelta | None = None,
    algorithm_kind: t.Literal['rsa', 'ecdsa', 'ed25519'] | None = None,
    algorithm_bits: RsaBits | None = None,
    algorithm_hasher: RsaHasher | None = None,
    algorithm_curve: EcdsaCurve | None = None,
) -> Config:
    key_file = (
        _KeyFile.model_validate_json(key_file_path.read_text(), by_alias=True)
        if key_file_path
        else None
    )
    return slcfg.read_config(
        Config,
        [
            slcfg.toml_file_layer(pathlib.Path('.env.toml'), optional=True),
            slcfg.env_base64_toml_layer('ZWR_CONFIG', optional=True),
            slcfg.env_layer('ZWR_', '__'),
            slcfg.value_layer({'host': host} if host else {}),
            slcfg.value_layer({'auth': {'access_token': access_token}} if access_token else {}),
            slcfg.value_layer({'auth': {'username': username}} if username else {}),
            slcfg.value_layer({'auth': {'password': password}} if password else {}),
            slcfg.value_layer(
                {
                    'auth': {
                        'key_id': key_file.key_id,
                        'private_key_pem': key_file.key,
                        'user_id': key_file.user_id,
                    }
                }
                if key_file
                else {}
            ),
            slcfg.value_layer({'rotation_period': rotation_period} if rotation_period else {}),
            slcfg.value_layer(
                {'keep_inactive_for': keep_inactive_for} if keep_inactive_for else {}
            ),
            slcfg.value_layer({'algorithm': {'kind': algorithm_kind}} if algorithm_kind else {}),
            slcfg.value_layer({'algorithm': {'bits': algorithm_bits}} if algorithm_bits else {}),
            slcfg.value_layer(
                {'algorithm': {'hasher': algorithm_hasher}} if algorithm_hasher else {}
            ),
            slcfg.value_layer({'algorithm': {'curve': algorithm_curve}} if algorithm_curve else {}),
        ],
    )


def create_client(config: Config) -> Zitadel:
    match config.auth:
        case AccessTokenAuth():
            return Zitadel.with_access_token(
                host=config.host, access_token=config.auth.access_token
            )
        case CredentialsAuth():
            return Zitadel.with_client_credentials(
                host=config.host, client_id=config.auth.username, client_secret=config.auth.password
            )
        case PrivateKeyAuth():
            with tempfile.TemporaryDirectory() as tmp_dir_:
                tmp_dir = pathlib.Path(tmp_dir_)
                tmp_key_file = tmp_dir / 'key-file.json'
                tmp_key_file.write_text(
                    _KeyFile(
                        keyId=config.auth.key_id,
                        key=config.auth.private_key_pem,
                        userId=config.auth.user_id,
                    ).model_dump_json(by_alias=True)
                )
                return Zitadel.with_private_key(host=config.host, key_file=str(tmp_key_file))


@dataclasses.dataclass
class WebKey:
    id: str
    state_age: datetime.timedelta


@dataclasses.dataclass
class WebKeys:
    initial: t.Sequence[WebKey]
    active: WebKey
    inactive: t.Sequence[WebKey]


def get_web_keys(client: Zitadel) -> WebKeys:
    initial: list[WebKey] = []
    active: WebKey | None = None
    inactive: list[WebKey] = []

    now = datetime.datetime.now().astimezone()

    for webkey in client.webkeys.list_web_keys().web_keys or []:
        if webkey.id is None or webkey.change_date is None:
            continue

        state_age = now - webkey.change_date

        match webkey.state:
            case WebKeyServiceState.STATE_INITIAL:
                initial.append(WebKey(webkey.id, state_age))

            case WebKeyServiceState.STATE_ACTIVE:
                if active is not None:
                    msg = f'Found multiple active keys: {active.id} and {webkey.id}'
                    raise RuntimeError(msg)
                active = WebKey(webkey.id, state_age)

            case WebKeyServiceState.STATE_INACTIVE:
                inactive.append(WebKey(webkey.id, state_age))

            case _:
                pass

    if active is None:
        msg = 'Found no active key'
        raise RuntimeError(msg)

    return WebKeys(initial=initial, active=active, inactive=inactive)


def activate_next_key(webkeys: WebKeys, client: Zitadel, config: Config) -> bool:
    if webkeys.active.state_age < config.rotation_period:
        return False

    candidate = max(webkeys.initial, key=lambda k: k.state_age, default=None)
    if candidate is None:
        return False

    if candidate.state_age < config.rotation_period:
        return False

    client.webkeys.activate_web_key(WebKeyServiceActivateWebKeyRequest(id=candidate.id))
    return True


def create_new_key(  # noqa: C901, PLR0912
    webkeys: WebKeys, client: Zitadel, config: Config, *, activated_key: bool
) -> None:
    if len(webkeys.initial) - activated_key > 0:
        return

    match config.algorithm:
        case Rsa():
            match config.algorithm.bits:
                case 2048:
                    bits = WebKeyServiceRSABits.RSA_BITS_2048
                case 3072:
                    bits = WebKeyServiceRSABits.RSA_BITS_3072
                case 4096:
                    bits = WebKeyServiceRSABits.RSA_BITS_4096

            match config.algorithm.hasher:
                case 'SHA256':
                    hasher = WebKeyServiceRSAHasher.RSA_HASHER_SHA256
                case 'SHA384':
                    hasher = WebKeyServiceRSAHasher.RSA_HASHER_SHA384
                case 'SHA512':
                    hasher = WebKeyServiceRSAHasher.RSA_HASHER_SHA512

            request = WebKeyServiceCreateWebKeyRequest(
                rsa=WebKeyServiceRSA(bits=bits, hasher=hasher)
            )
        case Ecdsa():
            match config.algorithm.curve:
                case 'P256':
                    curve = WebKeyServiceECDSACurve.ECDSA_CURVE_P256
                case 'P384':
                    curve = WebKeyServiceECDSACurve.ECDSA_CURVE_P384
                case 'P512':
                    curve = WebKeyServiceECDSACurve.ECDSA_CURVE_P512
            request = WebKeyServiceCreateWebKeyRequest(ecdsa=WebKeyServiceECDSA(curve=curve))
        case Ed25519():
            request = WebKeyServiceCreateWebKeyRequest(ed25519={})

    client.webkeys.create_web_key(request)


def delete_keys(webkeys: WebKeys, client: Zitadel, config: Config) -> None:
    for webkey in webkeys.inactive:
        if webkey.state_age < config.keep_inactive_for:
            continue

        client.webkeys.delete_web_key(WebKeyServiceDeleteWebKeyRequest(id=webkey.id))


def rotate(config: Config) -> None:
    client = create_client(config)
    webkeys = get_web_keys(client)
    activated_key = activate_next_key(webkeys, client, config)
    create_new_key(webkeys, client, config, activated_key=activated_key)
    delete_keys(webkeys, client, config)


APP = cyclopts.App()


@APP.default
def main(  # noqa: PLR0913
    *,
    host: str | None = None,
    username: str | None = None,
    password: str | None = None,
    access_token: str | None = None,
    key_file: pathlib.Path | None = None,
    rotation_period: datetime.timedelta | None = None,
    keep_inactive_for: datetime.timedelta | None = None,
    algorithm_kind: t.Literal['rsa', 'ecdsa', 'ed25519'] | None = None,
    algorithm_bits: RsaBits | None = None,
    algorithm_hasher: RsaHasher | None = None,
    algorithm_curve: EcdsaCurve | None = None,
) -> None:
    rotate(
        get_config(
            host=host,
            access_token=access_token,
            username=username,
            password=password,
            key_file_path=key_file,
            rotation_period=rotation_period,
            keep_inactive_for=keep_inactive_for,
            algorithm_kind=algorithm_kind,
            algorithm_bits=algorithm_bits,
            algorithm_hasher=algorithm_hasher,
            algorithm_curve=algorithm_curve,
        )
    )
