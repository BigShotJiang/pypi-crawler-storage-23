"""pgagent CLI entrypoint — all `pg` commands defined here."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich import print as rprint

app = typer.Typer(
    name="pg",
    help="pgagent — ProteoGenomics CLI research assistant",
    rich_markup_mode="rich",
    no_args_is_help=False,
)
console = Console()

# Sub-app groups
report_app = typer.Typer(help="Report commands", no_args_is_help=True)
cache_app = typer.Typer(help="Cache commands", no_args_is_help=True)
agents_app = typer.Typer(help="Agent commands", no_args_is_help=True)
config_app = typer.Typer(help="Config commands", no_args_is_help=True)
papers_app = typer.Typer(help="Papers commands", no_args_is_help=True)
manuscript_app = typer.Typer(help="Manuscript commands", no_args_is_help=True)

app.add_typer(report_app, name="report")
app.add_typer(cache_app, name="cache")
app.add_typer(agents_app, name="agents")
app.add_typer(config_app, name="config")
app.add_typer(papers_app, name="papers")
app.add_typer(manuscript_app, name="manuscript")


# ── Helpers ──────────────────────────────────────────────────────────────────

def _get_project_root() -> Optional[Path]:
    from pgagent.workspace import find_project_root
    return find_project_root()


def _require_project_root() -> Path:
    root = _get_project_root()
    if root is None:
        console.print("[red]✗ Not inside a pgagent project. Run `pg init <name>` first.[/red]")
        raise typer.Exit(1)
    return root


def _run_pipeline(project_root: Path, question: str, run_id: Optional[str] = None) -> None:
    """Execute full pipeline with progress display."""
    from pgagent.run_manager import RunManager
    from pgagent.state import PGState
    from pgagent.graph import run_pipeline

    rm = RunManager(project_root=project_root, run_id=run_id)
    rm.log_event("start", {"question": question})

    initial = PGState(
        project_root=str(project_root),
        run_id=rm.run_id,
        question=question,
    )

    nodes = [
        "lead_plan_node", "literature_node", "data_node", "stats_node",
        "hypothesis_node", "writing_node", "verifier_node", "finalize_node",
    ]
    node_labels = {
        "lead_plan_node": "Planning",
        "literature_node": "Literature review",
        "data_node": "Loading data",
        "stats_node": "Statistical analysis",
        "hypothesis_node": "Generating hypotheses",
        "writing_node": "Drafting manuscript",
        "verifier_node": "Verifying evidence",
        "finalize_node": "Finalizing report",
    }

    console.print(Panel(
        f"[cyan]Run ID:[/cyan] {rm.run_id}\n"
        f"[cyan]Question:[/cyan] {question}\n"
        f"[cyan]Project:[/cyan] {project_root}",
        title="[bold green]pgagent — Starting Pipeline[/bold green]",
        border_style="green",
    ))

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Initializing...", total=len(nodes))
        for node_name in nodes:
            progress.update(task, description=f"[yellow]{node_labels.get(node_name, node_name)}[/yellow]")
            progress.advance(task)

        try:
            final_state = run_pipeline(initial)
        except Exception as exc:
            console.print(f"[red]✗ Pipeline error: {exc}[/red]")
            raise typer.Exit(1)

    # Summary
    cov = final_state.evidence_coverage_pct
    n_fig = len(final_state.figures)
    n_cit = len(final_state.citations)
    n_hyp = len(final_state.hypotheses)

    console.print(Panel(
        f"[green]✓ Run complete[/green] — {rm.run_id}\n"
        f"  Evidence coverage: [bold]{cov:.1f}%[/bold]\n"
        f"  Figures: {n_fig}  Citations: {n_cit}  Hypotheses: {n_hyp}\n"
        f"  Report: [dim]{rm.report_path}[/dim]\n"
        f"  Artifacts: [dim]{rm.artifact_dir}/[/dim]",
        title="[bold green]Pipeline Complete[/bold green]",
        border_style="green",
    ))


# ── Root command: REPL or one-shot ───────────────────────────────────────────

@app.callback(invoke_without_command=True)
def root(ctx: typer.Context):
    """ProteoGenomics CLI — start REPL when called with no subcommand."""
    if ctx.invoked_subcommand is not None:
        return  # let the subcommand handle it
    _start_repl()


def _start_repl() -> None:
    """Interactive REPL session."""
    root_path = _get_project_root()
    project_name = root_path.name if root_path else "no project"

    console.print(Panel(
        "[bold cyan]pgagent[/bold cyan] — ProteoGenomics CLI Research Assistant\n"
        f"Project: [yellow]{project_name}[/yellow]\n"
        "Type [green]help[/green] for commands, [red]exit[/red] to quit.",
        border_style="cyan",
    ))

    while True:
        try:
            line = console.input("[bold green]pg>[/bold green] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Goodbye.[/dim]")
            break

        if not line:
            continue
        if line.lower() in ("exit", "quit", "q"):
            console.print("[dim]Goodbye.[/dim]")
            break
        if line.lower() == "help":
            console.print(
                "[cyan]Commands:[/cyan] run <query>, summarize, doctor, agents, config, exit"
            )
            continue
        if line.lower().startswith("run "):
            query = line[4:].strip().strip('"')
            if root_path:
                _run_pipeline(root_path, query)
            else:
                console.print("[red]No active project. cd into a project directory.[/red]")
            continue

        console.print(f"[dim]Unknown command: {line}. Type 'help' for options.[/dim]")


# ── pg run ───────────────────────────────────────────────────────────────────

@app.command("run")
def run_cmd(
    query: str = typer.Argument(..., help="Research question"),
    run_id: Optional[str] = typer.Option(None, "--run-id", help="Override run ID"),
):
    """Run the full research pipeline for a query."""
    root_path = _require_project_root()
    _run_pipeline(root_path, query, run_id=run_id)


# ── pg init ───────────────────────────────────────────────────────────────────

@app.command("init")
def init_cmd(
    project_name: str = typer.Argument(..., help="Project name"),
    base_dir: Optional[Path] = typer.Option(None, "--dir", help="Parent directory"),
):
    """Create a new pgagent research workspace."""
    from pgagent.workspace import init_workspace
    root = init_workspace(project_name, base_dir=base_dir)
    console.print(f"[green]✓ Workspace created:[/green] {root}")
    console.print(f"  [dim]cd {root} && pg run \"your question\"[/dim]")


# ── pg setup ──────────────────────────────────────────────────────────────────

@app.command("setup")
def setup_cmd():
    """Create ~/.pgagent/config.yaml with defaults."""
    from pgagent.config import save_config, load_config, CONFIG_PATH
    save_config(load_config())
    console.print(f"[green]✓ Config written to:[/green] {CONFIG_PATH}")


# ── pg doctor ─────────────────────────────────────────────────────────────────

@app.command("doctor")
def doctor_cmd():
    """Check environment and dependencies."""
    checks = []
    # Python version
    import sys
    py_ok = sys.version_info >= (3, 10)
    checks.append(("Python ≥ 3.10", py_ok, sys.version.split()[0]))

    for pkg in ["typer", "rich", "pydantic", "pandas", "numpy", "matplotlib", "seaborn", "jinja2", "ruamel.yaml"]:
        try:
            mod = __import__(pkg.replace("-", "_").replace(".", "_"))
            ver = getattr(mod, "__version__", "?")
            checks.append((pkg, True, ver))
        except ImportError:
            checks.append((pkg, False, "MISSING"))

    # LangGraph
    try:
        import langgraph
        checks.append(("langgraph", True, getattr(langgraph, "__version__", "?")))
    except ImportError:
        checks.append(("langgraph", False, "MISSING — pip install langgraph"))

    # Project root
    root = _get_project_root()
    checks.append(("pgagent project", root is not None, str(root) if root else "Run `pg init <name>`"))

    # Config
    from pgagent.config import CONFIG_PATH, load_config
    cfg = load_config()
    checks.append(("Config file", CONFIG_PATH.exists(), str(CONFIG_PATH)))
    checks.append(("Default provider", True, cfg.default_provider))

    table = Table(title="pgagent Doctor Report", show_header=True)
    table.add_column("Check", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Info", style="dim")
    for name, ok, info in checks:
        status = "[green]✓ OK[/green]" if ok else "[red]✗ FAIL[/red]"
        table.add_row(name, status, str(info))
    console.print(table)


# ── pg summarize latest ───────────────────────────────────────────────────────

@app.command("summarize")
def summarize_cmd(
    which: str = typer.Argument("latest", help="'latest' or run_id"),
):
    """Print run summary from report."""
    root_path = _require_project_root()
    if which == "latest":
        report = root_path / "results" / "reports" / "latest.md"
    else:
        report = root_path / "results" / "reports" / f"run_{which}.md"

    if not report.exists():
        # Try without prefix
        report = root_path / "results" / "reports" / f"{which}.md"

    if not report.exists():
        console.print(f"[red]Report not found: {report}[/red]")
        raise typer.Exit(1)

    text = report.read_text()
    lines = text.splitlines()
    # Print first 50 lines
    console.print(Panel("\n".join(lines[:60]), title=f"[cyan]{report.name}[/cyan]", border_style="cyan"))


# ── pg explain ────────────────────────────────────────────────────────────────

@app.command("explain")
def explain_cmd(
    artifact: str = typer.Argument(..., help="Path or filename of artifact to explain"),
):
    """Explain a plot or table artifact."""
    root_path = _get_project_root()

    # Look up in manifests
    manifest_dir = root_path / "results" / "manifests" if root_path else Path(".")
    explanation = None
    for mf in sorted(manifest_dir.glob("*.yaml"), reverse=True):
        from ruamel.yaml import YAML
        _y = YAML()
        data = _y.load(mf)
        if data and "figures" in data:
            for fig in data["figures"]:
                if artifact in str(fig.get("path", "")):
                    explanation = (
                        f"**Caption:** {fig.get('caption', 'N/A')}\n"
                        f"**Created by:** {fig.get('created_by', 'N/A')}\n"
                        f"**Params hash:** {fig.get('params_hash', 'N/A')}\n"
                        f"**Input hash:** {fig.get('input_hash', 'N/A')}"
                    )
                    break
        if explanation:
            break

    if not explanation:
        explanation = f"No metadata found for artifact `{artifact}`."

    console.print(Panel(explanation, title=f"[cyan]Explain: {artifact}[/cyan]"))


# ── pg resume ─────────────────────────────────────────────────────────────────

@app.command("resume")
def resume_cmd(
    run_id: str = typer.Argument(..., help="Run ID to resume"),
):
    """Resume a pipeline from its last checkpoint."""
    from pgagent.checkpoint import load_checkpoint
    from pgagent.graph import run_pipeline

    root_path = _require_project_root()
    ckpt_path = root_path / "results" / "checkpoints" / f"run_{run_id}.json"
    state = load_checkpoint(ckpt_path)
    if state is None:
        console.print(f"[red]Checkpoint not found: {ckpt_path}[/red]")
        raise typer.Exit(1)

    start_node = state.current_node
    if start_node == "done":
        console.print(f"[yellow]Run {run_id} already finished. Showing report...[/yellow]")
        summarize_cmd(run_id)
        return

    console.print(f"[green]Resuming run {run_id} from node:[/green] {start_node}")
    final = run_pipeline(state, start_node=start_node)
    cov = final.evidence_coverage_pct
    console.print(f"[green]✓ Resume complete. Evidence coverage: {cov:.1f}%[/green]")


# ── report subcommands ────────────────────────────────────────────────────────

@report_app.command("publish")
def report_publish(
    run_id: Optional[str] = typer.Argument(None, help="Run ID or 'latest'"),
):
    """Convert Markdown report to HTML."""
    from pgagent.tools.report import publish_html
    root_path = _require_project_root()

    if run_id and run_id != "latest":
        md = root_path / "results" / "reports" / f"run_{run_id}.md"
    else:
        md = root_path / "results" / "reports" / "latest.md"
        if md.is_symlink():
            md = md.resolve()

    if not md.exists():
        console.print(f"[red]Report not found: {md}[/red]")
        raise typer.Exit(1)

    html = publish_html(md)
    console.print(f"[green]✓ HTML published:[/green] {html}")


# ── cache subcommands ─────────────────────────────────────────────────────────

@cache_app.command("clear")
def cache_clear():
    """Clear all cached tool results."""
    from pgagent.tools.cache import Cache
    root_path = _require_project_root()
    cache = Cache(root_path)
    n = cache.clear()
    console.print(f"[green]✓ Cache cleared:[/green] {n} entries removed.")


@cache_app.command("status")
def cache_status():
    """Show cache size."""
    from pgagent.tools.cache import Cache
    root_path = _require_project_root()
    cache = Cache(root_path)
    console.print(f"Cache entries: {cache.size()} in {root_path / 'cache'}")


# ── agents subcommands ────────────────────────────────────────────────────────

@agents_app.command("list")
def agents_list():
    """List all available agents."""
    agents = [
        ("literature",  "LiteratureAgent",  "PubMed search, abstract fetch, citation assembly"),
        ("data",        "DataAgent",         "Table loading, QC, data discovery"),
        ("stats",       "StatsAgent",        "Differential expression, enrichment, volcano & heatmap"),
        ("hypothesis",  "HypothesisAgent",   "Ranked hypothesis generation with confidence scores"),
        ("writing",     "WritingAgent",       "9-section manuscript drafting"),
        ("verifier",    "VerifierAgent",      "Evidence-First Policy enforcement + coverage %"),
    ]
    table = Table(title="pgagent Agents", show_header=True)
    table.add_column("ID", style="cyan")
    table.add_column("Class", style="green")
    table.add_column("Description")
    for agent_id, cls, desc in agents:
        table.add_row(agent_id, cls, desc)
    console.print(table)


# ── config subcommands ────────────────────────────────────────────────────────

@config_app.command("show")
def config_show():
    """Display current configuration."""
    from pgagent.config import load_config, CONFIG_PATH
    cfg = load_config()
    table = Table(title=f"Config: {CONFIG_PATH}", show_header=True)
    table.add_column("Key", style="cyan")
    table.add_column("Value")
    for k, v in cfg.model_dump(exclude_none=True).items():
        table.add_row(k, str(v))
    console.print(table)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (dot-notation ok)"),
    value: str = typer.Argument(..., help="Value to set"),
):
    """Set a configuration value."""
    from pgagent.config import set_config_value
    set_config_value(key, value)
    console.print(f"[green]✓[/green] {key} = {value}")


# ── papers subcommands ────────────────────────────────────────────────────────

@papers_app.command("add")
def papers_add(
    pdf: Path = typer.Argument(..., help="Path to PDF file"),
):
    """Add an offline paper PDF to knowledge/papers/."""
    from pgagent.workspace import add_paper
    root_path = _require_project_root()
    if not pdf.exists():
        console.print(f"[red]File not found: {pdf}[/red]")
        raise typer.Exit(1)
    dest = add_paper(root_path, pdf)
    console.print(f"[green]✓ Paper added:[/green] {dest}")


# ── manuscript subcommands ────────────────────────────────────────────────────

@manuscript_app.command("pack")
def manuscript_pack(
    run_id: Optional[str] = typer.Argument("latest", help="Run ID"),
):
    """Package manuscript files (report + figures + bibliography)."""
    root_path = _require_project_root()

    if run_id == "latest":
        reports = sorted((root_path / "results" / "reports").glob("run_*.md"), reverse=True)
        if not reports:
            console.print("[red]No reports found.[/red]")
            raise typer.Exit(1)
        md = reports[0]
        run_id = md.stem.replace("run_", "")
    else:
        md = root_path / "results" / "reports" / f"run_{run_id}.md"

    out_dir = root_path / "results" / "manuscripts" / f"run_{run_id}"
    out_dir.mkdir(parents=True, exist_ok=True)

    import shutil
    if md.exists():
        shutil.copy2(md, out_dir / "manuscript.md")

    # Copy figures
    artifact_dir = root_path / "results" / "artifacts" / f"run_{run_id}"
    if artifact_dir.exists():
        figs_dir = out_dir / "figures"
        figs_dir.mkdir(exist_ok=True)
        for f in artifact_dir.glob("*.png"):
            shutil.copy2(f, figs_dir / f.name)

    console.print(f"[green]✓ Manuscript packed:[/green] {out_dir}")
    for f in sorted(out_dir.rglob("*")):
        if f.is_file():
            console.print(f"  [dim]{f.relative_to(out_dir)}[/dim]")


# ── Entry ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app()
