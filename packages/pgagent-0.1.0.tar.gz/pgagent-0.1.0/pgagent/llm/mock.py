"""MockClient — deterministic LLM for offline/testing use."""
from __future__ import annotations

from typing import Optional

from pgagent.llm import LLMClient

_CANNED: dict[str, str] = {
    "plan": (
        "Plan: 1. Literature review via PubMed\n"
        "2. Load proteomics table\n"
        "3. Differential expression analysis\n"
        "4. Pathway enrichment\n"
        "5. Hypothesis generation\n"
        "6. Draft manuscript sections"
    ),
    "literature": (
        "PubMed search returned 5 mock articles on proteogenomics pathway analysis. "
        "Key themes: ubiquitin-proteasome system, mTOR signaling, glycolysis dysregulation."
    ),
    "data": (
        "Loaded synthetic_proteomics.tsv: 200 proteins, 6 samples. "
        "QC: no missing values, median log2FC = 0.42."
    ),
    "stats": (
        "Differential expression: 37 proteins significantly upregulated (adj p<0.05, |logFC|>1). "
        "Top pathways: glycolysis, proteasome, ribosome biogenesis."
    ),
    "hypothesis": (
        "H1 (confidence 0.82): Upregulation of glycolytic enzymes (GAPDH, PKM2) drives metabolic "
        "reprogramming in tumor samples. [artifact-backed]\n"
        "H2 (confidence 0.71): Dysregulated proteasome subunits suggest impaired protein quality "
        "control. [citation-backed: PMID:12345678]\n"
        "H3 (confidence 0.60): mTOR pathway activation links nutrient sensing to translation "
        "upregulation observed in data. [hypothesis]"
    ),
    "writing": (
        "Draft sections generated covering: research question, data inputs, methods, key results, "
        "literature evidence, hypotheses + experiments, manuscript outline, limitations, "
        "evidence coverage."
    ),
    "verifier": (
        "Evidence-First audit complete. "
        "Coverage: 88%. "
        "2 claims flagged as unsupported hypotheses without confidence labels."
    ),
    "default": "Task completed successfully by MockClient.",
}


class MockClient(LLMClient):
    """Deterministic mock LLM — zero API calls, offline-capable."""

    def complete(
        self,
        prompt: str,
        system: Optional[str] = None,
        temperature: float = 0.2,
        max_tokens: int = 2048,
    ) -> str:
        prompt_lower = prompt.lower()
        for key, response in _CANNED.items():
            if key in prompt_lower:
                return response
        return _CANNED["default"]
