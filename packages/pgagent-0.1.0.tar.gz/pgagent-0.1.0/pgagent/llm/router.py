"""LLM router — resolve the right LLMClient per agent from config."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from pgagent.llm import LLMClient


def get_client_for_agent(agent_name: str, project_root: Optional[str] = None) -> LLMClient:
    """Return the configured LLMClient for a given agent name.

    Resolution order:
    1. Per-agent override in config.agent_models.<agent_name>
    2. Global config.default_provider
    3. Fallback: MockClient
    """
    try:
        from pgagent.config import load_config
        cfg = load_config()
        provider = cfg.default_provider
        model: Optional[str] = cfg.default_model

        if agent_name in cfg.agent_models:
            entry = cfg.agent_models[agent_name]
            provider = entry.provider
            model = entry.model
    except Exception:
        provider = "mock"
        model = None

    return _build_client(provider, model)


def _build_client(provider: str, model: Optional[str]) -> LLMClient:
    provider = (provider or "mock").lower()
    if provider == "openai":
        from pgagent.llm.openai_client import OpenAIClient
        return OpenAIClient(model=model or "gpt-4o")
    if provider == "anthropic":
        from pgagent.llm.anthropic_client import AnthropicClient
        return AnthropicClient(model=model or "claude-3-5-sonnet-20241022")
    if provider == "gemini":
        from pgagent.llm.gemini_client import GeminiClient
        return GeminiClient(model=model or "gemini-1.5-pro")
    # Default / mock
    from pgagent.llm.mock import MockClient
    return MockClient()
