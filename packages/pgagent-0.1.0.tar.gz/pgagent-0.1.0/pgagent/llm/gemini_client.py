"""Google Gemini LLM client (stub)."""
from __future__ import annotations

from typing import Optional

from pgagent.llm import LLMClient


class GeminiClient(LLMClient):
    def __init__(self, model: str = "gemini-1.5-pro", api_key: Optional[str] = None):
        try:
            import google.generativeai as genai  # noqa: F401
        except ImportError:
            raise ImportError("Install google-generativeai: pip install pgagent[gemini]")
        import os
        import google.generativeai as genai
        genai.configure(api_key=api_key or os.environ.get("GOOGLE_API_KEY"))
        self._model = genai.GenerativeModel(model)

    def complete(self, prompt: str, system: Optional[str] = None,
                 temperature: float = 0.2, max_tokens: int = 2048) -> str:
        full = f"{system}\n\n{prompt}" if system else prompt
        resp = self._model.generate_content(full)
        return resp.text
