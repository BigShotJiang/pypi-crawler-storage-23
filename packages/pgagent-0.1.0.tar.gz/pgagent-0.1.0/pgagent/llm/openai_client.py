"""OpenAI LLM client (stub — install openai package to activate)."""
from __future__ import annotations

from typing import Optional

from pgagent.llm import LLMClient


class OpenAIClient(LLMClient):
    def __init__(self, model: str = "gpt-4o", api_key: Optional[str] = None):
        try:
            import openai  # noqa: F401
        except ImportError:
            raise ImportError("Install openai: pip install pgagent[openai]")
        import os
        import openai
        self._client = openai.OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))
        self.model = model

    def complete(self, prompt: str, system: Optional[str] = None,
                 temperature: float = 0.2, max_tokens: int = 2048) -> str:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        resp = self._client.chat.completions.create(
            model=self.model, messages=messages,
            temperature=temperature, max_tokens=max_tokens,
        )
        return resp.choices[0].message.content or ""
