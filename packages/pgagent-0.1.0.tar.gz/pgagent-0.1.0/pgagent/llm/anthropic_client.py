"""Anthropic Claude LLM client (stub)."""
from __future__ import annotations

from typing import Optional

from pgagent.llm import LLMClient


class AnthropicClient(LLMClient):
    def __init__(self, model: str = "claude-3-5-sonnet-20241022", api_key: Optional[str] = None):
        try:
            import anthropic  # noqa: F401
        except ImportError:
            raise ImportError("Install anthropic: pip install pgagent[anthropic]")
        import os
        import anthropic
        self._client = anthropic.Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))
        self.model = model

    def complete(self, prompt: str, system: Optional[str] = None,
                 temperature: float = 0.2, max_tokens: int = 2048) -> str:
        import anthropic
        kwargs: dict = dict(
            model=self.model, max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        if system:
            kwargs["system"] = system
        resp = self._client.messages.create(**kwargs)
        return resp.content[0].text
