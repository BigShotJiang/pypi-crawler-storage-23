"""LLM abstraction layer — base class."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class LLMClient(ABC):
    """Uniform interface for all LLM providers."""

    @abstractmethod
    def complete(
        self,
        prompt: str,
        system: Optional[str] = None,
        temperature: float = 0.2,
        max_tokens: int = 2048,
    ) -> str:
        """Send a prompt and return the model's text response."""

    def name(self) -> str:
        return self.__class__.__name__
