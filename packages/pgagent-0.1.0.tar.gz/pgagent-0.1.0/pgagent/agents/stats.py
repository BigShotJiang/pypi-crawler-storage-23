"""Stats agent: differential expression + enrichment + plot generation."""
from __future__ import annotations

from pathlib import Path

from pgagent.agents import BaseAgent
from pgagent.state import PGState, ToolCallRecord, ArtifactMeta
from pgagent.tools.data import differential_expression_like, enrichment_stub
from pgagent.tools.plots import plot_volcano, plot_heatmap


class StatsAgent(BaseAgent):
    name = "stats"
    system_prompt = (
        "You are a computational proteomics statistician. "
        "Perform differential expression and pathway enrichment analysis, then generate publication-quality figures."
    )

    def run(self, state: PGState) -> PGState:
        root = Path(state.project_root)
        run_dir = str(root / "results" / "artifacts" / f"run_{state.run_id}")

        for data_entry in state.data_inputs:
            df_json = data_entry.get("_df_json", "")
            if not df_json:
                continue

            # ── Differential expression ──────────────────────────────────
            de_result = differential_expression_like(df_json=df_json)
            state.tool_calls.append(ToolCallRecord(
                tool_name="differential_expression_like",
                inputs={"path": data_entry.get("path")},
                outputs={k: v for k, v in de_result.outputs.items() if "_json" not in k},
                ok=de_result.ok,
            ))
            if not de_result.ok:
                state.errors.append(f"StatsAgent DE: {de_result.error}")
                continue

            state.analysis_results.update({
                "n_significant": de_result.outputs.get("n_significant"),
                "n_up": de_result.outputs.get("n_up"),
                "n_down": de_result.outputs.get("n_down"),
                "top_upregulated": de_result.outputs.get("top_upregulated"),
                "top_downregulated": de_result.outputs.get("top_downregulated"),
            })

            # ── Enrichment ───────────────────────────────────────────────
            top_up = de_result.outputs.get("top_upregulated", [])
            gene_list = [r.get("gene", "") for r in top_up if r.get("gene")]
            if gene_list:
                enr_result = enrichment_stub(gene_list=gene_list)
                state.tool_calls.append(ToolCallRecord(
                    tool_name="enrichment_stub",
                    inputs={"gene_list": gene_list},
                    outputs=enr_result.outputs,
                    ok=enr_result.ok,
                ))
                state.analysis_results["pathways"] = enr_result.outputs.get("pathways", [])

            full_df_json = de_result.outputs.get("full_df_json", df_json)

            # ── Volcano plot ─────────────────────────────────────────────
            vol_result = plot_volcano(df_json=full_df_json, run_dir=run_dir)
            state.tool_calls.append(ToolCallRecord(
                tool_name="plot_volcano", inputs={"run_dir": run_dir},
                outputs={k: v for k, v in vol_result.outputs.items() if "_json" not in k},
                ok=vol_result.ok,
            ))
            if vol_result.ok and vol_result.artifacts:
                a = vol_result.artifacts[0]
                state.figures.append(ArtifactMeta(**a))

            # ── Heatmap ──────────────────────────────────────────────────
            hm_result = plot_heatmap(df_json=full_df_json, run_dir=run_dir)
            state.tool_calls.append(ToolCallRecord(
                tool_name="plot_heatmap", inputs={"run_dir": run_dir},
                outputs={k: v for k, v in hm_result.outputs.items() if "_json" not in k},
                ok=hm_result.ok,
            ))
            if hm_result.ok and hm_result.artifacts:
                a = hm_result.artifacts[0]
                state.figures.append(ArtifactMeta(**a))

        return state
