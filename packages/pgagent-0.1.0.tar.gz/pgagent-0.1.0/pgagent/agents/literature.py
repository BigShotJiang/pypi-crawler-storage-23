"""Literature agent: PubMed search, abstract fetch, citation assembly."""
from __future__ import annotations

from pgagent.agents import BaseAgent
from pgagent.state import PGState, ToolCallRecord
from pgagent.tools.literature import pubmed_search, pubmed_fetch_abstracts, build_citation


class LiteratureAgent(BaseAgent):
    name = "literature"
    system_prompt = (
        "You are a biomedical literature specialist. "
        "Retrieve and summarize relevant publications with full citations."
    )

    def run(self, state: PGState) -> PGState:
        # 1. PubMed search
        search_result = pubmed_search(query=state.question, n=5)
        state.tool_calls.append(ToolCallRecord(
            tool_name="pubmed_search",
            inputs={"query": state.question, "n": 5},
            outputs=search_result.outputs,
            ok=search_result.ok,
        ))

        articles = search_result.outputs.get("articles", [])

        # 2. Fetch abstracts
        pmids = [str(a["pmid"]) for a in articles]
        fetch_result = pubmed_fetch_abstracts(pmids=pmids)
        state.tool_calls.append(ToolCallRecord(
            tool_name="pubmed_fetch_abstracts",
            inputs={"pmids": pmids},
            outputs=fetch_result.outputs,
            ok=fetch_result.ok,
        ))

        # 3. Build citations
        cites = []
        for article in fetch_result.outputs.get("abstracts", []):
            cite_result = build_citation(entry=article)
            if cite_result.ok:
                cites.append(cite_result.outputs["citation"])

        # 4. LLM synthesis
        prompt = (
            f"Summarize the following abstracts relevant to: '{state.question}'\n\n"
            + "\n\n".join(
                f"[{a.get('pmid')}] {a.get('title')}: {a.get('abstract', '')}"
                for a in fetch_result.outputs.get("abstracts", articles)
            )
        )
        synthesis = self.think(prompt)

        state.literature = fetch_result.outputs.get("abstracts", articles)
        state.citations = list(set(state.citations + cites))

        return state
