"""Verifier agent: Evidence-First Policy enforcement + coverage computation."""
from __future__ import annotations

from typing import List

from pgagent.agents import BaseAgent
from pgagent.state import PGState, DraftSection


class VerifierAgent(BaseAgent):
    """Enforce Evidence-First Policy:
    Every claim must be:
      A) citation-backed (PMID:...)
      B) artifact-backed (results/artifacts/...)
      C) labeled hypothesis with confidence score.
    """

    name = "verifier"
    system_prompt = (
        "You are a scientific verifier enforcing Evidence-First policy. "
        "Flag any claims that are not citation-backed, artifact-backed, or "
        "labeled as hypotheses with confidence scores."
    )

    def run(self, state: PGState) -> PGState:
        violations: List[str] = []
        supported_claims = 0
        total_claims = 0

        for section in state.draft_sections:
            claims = self._extract_claims(section)
            for claim in claims:
                total_claims += 1
                if self._is_supported(claim, section, state):
                    supported_claims += 1
                else:
                    violations.append(
                        f"[{section.heading}] Unsupported claim: '{claim[:80].strip()}...'"
                    )

        # Coverage
        coverage = (supported_claims / total_claims * 100) if total_claims > 0 else 100.0
        state.evidence_coverage_pct = round(coverage, 1)
        state.evidence_violations = violations

        # Update section 9 with actual coverage
        for sec in state.draft_sections:
            if "9." in sec.heading or "Evidence Coverage" in sec.heading:
                sec.body = (
                    f"**Evidence Coverage: {state.evidence_coverage_pct:.1f}%**\n\n"
                    f"- Total claims evaluated: {total_claims}\n"
                    f"- Supported claims: {supported_claims}\n"
                    f"- Violations flagged: {len(violations)}\n"
                )
                if violations:
                    sec.body += "\n**Violations:**\n" + "\n".join(f"  - {v}" for v in violations)
                break

        return state

    # ── Internal helpers ────────────────────────────────────────────────────

    def _extract_claims(self, section: DraftSection) -> List[str]:
        """Split body into 'claims' (bullet points or sentences)."""
        lines = [l.strip() for l in section.body.splitlines() if l.strip()]
        return [l for l in lines if len(l) > 20]  # ignore headers/short lines

    def _is_supported(self, claim: str, section: DraftSection, state: PGState) -> bool:
        """Return True if the claim is evidence-backed."""
        claim_lower = claim.lower()

        # A) citation-backed
        if "pmid:" in claim_lower:
            return True

        # B) artifact-backed
        if any(
            frag in claim_lower
            for frag in ["results/artifacts", ".png", ".csv", ".tsv", "figure", "plot", "heatmap", "volcano"]
        ):
            return True

        # C) hypothesis + confidence
        if any(kw in claim_lower for kw in ["hypothesis", "confidence=", "h1", "h2", "h3", "proposed"]):
            return True

        # D) has an evidence_ref from parent section
        if section.evidence_refs:
            return True

        # E) method/metadata sections get a pass
        if any(
            section.heading.startswith(prefix)
            for prefix in ["1.", "2.", "3.", "7.", "8."]
        ):
            return True

        return False
