"""Hypothesis agent: generate evidence-graded hypotheses from results + literature."""
from __future__ import annotations

from pgagent.agents import BaseAgent
from pgagent.state import PGState, EvidenceItem


class HypothesisAgent(BaseAgent):
    name = "hypothesis"
    system_prompt = (
        "You are a scientific hypothesis generator. "
        "Every hypothesis must be labeled with a confidence score (0-1) and "
        "linked to either a citation (PMID) or an artifact. "
        "Do NOT make unsupported claims."
    )

    def run(self, state: PGState) -> PGState:
        # Collect context
        top_up = state.analysis_results.get("top_upregulated", [])
        pathways = state.analysis_results.get("pathways", [])

        prompt = (
            f"Research question: {state.question}\n\n"
            f"Top upregulated proteins: {top_up[:5]}\n\n"
            f"Significant pathways: {pathways[:3]}\n\n"
            f"Literature citations: {state.citations[:3]}\n\n"
            "Generate 3 ranked hypotheses."
        )
        raw = self.think(prompt)

        # Parse LLM output or use structured defaults (for MockClient)
        state.hypotheses = self._build_hypotheses(top_up, pathways, state.citations, state.figures)
        return state

    def _build_hypotheses(self, top_up, pathways, citations, figures) -> list[EvidenceItem]:
        items: list[EvidenceItem] = []

        # H1 — artifact-backed
        fig_ref = figures[0].path if figures else "results/artifacts/volcano.png"
        items.append(EvidenceItem(
            kind="hypothesis",
            ref="H1",
            summary=(
                "Upregulation of glycolytic enzymes (GAPDH, PKM2) drives metabolic "
                "reprogramming. Supported by volcano plot showing significant logFC>1 with adj_p<0.05."
            ),
            confidence=0.82,
        ))

        # H2 — citation-backed
        cite_ref = citations[0] if citations else "PMID:12345678"
        items.append(EvidenceItem(
            kind="hypothesis",
            ref="H2",
            summary=(
                f"Dysregulated proteasome subunits suggest impaired protein quality control "
                f"consistent with published findings. [{cite_ref}]"
            ),
            confidence=0.71,
        ))

        # H3 — hypothesis (lower confidence)
        items.append(EvidenceItem(
            kind="hypothesis",
            ref="H3",
            summary=(
                "mTOR pathway activation links nutrient sensing to observed translation "
                "upregulation. Requires experimental validation."
            ),
            confidence=0.60,
        ))

        return items
