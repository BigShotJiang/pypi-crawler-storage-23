"""Data agent: discover, load, QC-check proteomics tables."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from pgagent.agents import BaseAgent
from pgagent.state import PGState, ToolCallRecord
from pgagent.tools.data import load_table, qc_summary


class DataAgent(BaseAgent):
    name = "data"
    system_prompt = (
        "You are a proteomics data engineer. "
        "Load, inspect, and QC-check experimental datasets."
    )

    def run(self, state: PGState) -> PGState:
        root = Path(state.project_root)

        # Discover tables in data/ directories
        candidate_dirs = [root / "data" / "raw", root / "examples" / "data", root]
        tables = []
        for d in candidate_dirs:
            if d.exists():
                tables.extend(list(d.glob("*.tsv")) + list(d.glob("*.csv")))
        tables = tables[:3]  # load at most 3

        if not tables:
            state.errors.append("DataAgent: no data files found in data/raw/ or examples/data/")
            return state

        for tbl in tables:
            load_result = load_table(path=str(tbl), project_root=str(root))
            state.tool_calls.append(ToolCallRecord(
                tool_name="load_table",
                inputs={"path": str(tbl)},
                outputs={k: v for k, v in load_result.outputs.items() if k != "_df_json"},
                ok=load_result.ok,
                error=load_result.error,
            ))
            if not load_result.ok:
                state.errors.append(f"DataAgent: {load_result.error}")
                continue

            df_json = load_result.outputs.get("_df_json", "")
            qc_result = qc_summary(df_json=df_json)
            state.tool_calls.append(ToolCallRecord(
                tool_name="qc_summary",
                inputs={"path": str(tbl)},
                outputs=qc_result.outputs,
                ok=qc_result.ok,
            ))

            state.data_inputs.append({
                "path": str(tbl),
                "shape": load_result.outputs.get("shape"),
                "columns": load_result.outputs.get("columns"),
                "qc": qc_result.outputs,
                "input_hash": load_result.outputs.get("input_hash", ""),
                "_df_json": df_json,
            })

        return state
