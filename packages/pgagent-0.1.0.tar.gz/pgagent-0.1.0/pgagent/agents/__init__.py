"""Base agent class."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from pgagent.llm import LLMClient
from pgagent.state import PGState


class BaseAgent(ABC):
    """Abstract base for all pgagent agents."""

    name: str = "base"
    system_prompt: str = "You are a scientific research assistant."

    def __init__(self, llm: Optional[LLMClient] = None):
        if llm is None:
            from pgagent.llm.mock import MockClient
            llm = MockClient()
        self.llm = llm

    def think(self, prompt: str) -> str:
        """Call the LLM with the agent's system prompt."""
        return self.llm.complete(prompt, system=self.system_prompt)

    @abstractmethod
    def run(self, state: PGState) -> PGState:
        """Execute this agent's logic and return updated state."""
