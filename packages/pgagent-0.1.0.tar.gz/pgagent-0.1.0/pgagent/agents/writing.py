"""Writing agent: draft all 9 required manuscript sections."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from pgagent.agents import BaseAgent
from pgagent.state import PGState, DraftSection


class WritingAgent(BaseAgent):
    name = "writing"
    system_prompt = (
        "You are a biomedical scientific writer. "
        "Draft all manuscript sections with clear evidence attribution. "
        "Always cite PMIDs or artifacts. Do not make unsupported claims."
    )

    def run(self, state: PGState) -> PGState:
        run_id = state.run_id
        figures = state.figures
        citations = state.citations
        hypotheses = state.hypotheses
        results = state.analysis_results
        pathways = results.get("pathways", [])
        n_sig = results.get("n_significant", "N/A")
        n_up = results.get("n_up", "N/A")
        n_down = results.get("n_down", "N/A")
        top_up = results.get("top_upregulated", [])
        top_down = results.get("top_downregulated", [])

        fig_table = "\n".join(
            f"- **{Path(f.path).name}**: {f.caption}" for f in figures
        ) or "No figures generated."

        cite_table = "\n".join(f"- {c}" for c in citations[:5]) or "No citations recorded."

        hyp_table = "\n".join(
            f"- **{h.ref}** (confidence={h.confidence:.2f}): {h.summary}"
            for h in hypotheses
        ) or "No hypotheses generated."

        pw_table = "\n".join(
            f"- {pw['pathway']} (adj_p={pw['p_adj']:.4f})" for pw in pathways[:5]
        ) or "No pathway enrichment results."

        top_up_str = "\n".join(
            f"  - {r.get('gene','?')}: logFC={r.get('logFC',0):.2f}, adj_p={r.get('adj_pval',1):.4f}"
            for r in top_up[:5]
        ) or "  None"

        data_inputs_str = "\n".join(
            f"- {d.get('path', '?')}: {d.get('shape')} ({d.get('qc', {}).get('total_missing', 0)} missing)"
            for d in state.data_inputs
        ) or "- No data inputs recorded."

        sections = [
            DraftSection(
                heading="1. Research Question",
                body=state.question or "Not specified.",
                evidence_refs=[],
            ),
            DraftSection(
                heading="2. Data Inputs",
                body=data_inputs_str,
                evidence_refs=[d.get("input_hash", "") for d in state.data_inputs],
            ),
            DraftSection(
                heading="3. Methods Executed",
                body=(
                    "**Literature**: PubMed search + abstract fetch (stub)\n"
                    "**Data QC**: Missing value analysis, descriptive statistics\n"
                    "**Differential Expression**: adj_pval < 0.05, |logFC| > 1.0\n"
                    "**Enrichment**: Pathway over-representation (stub)\n"
                    "**Visualization**: Volcano plot, expression heatmap"
                ),
                evidence_refs=[],
            ),
            DraftSection(
                heading="4. Key Results",
                body=(
                    f"Differential expression identified **{n_sig}** significant proteins "
                    f"({n_up} upregulated, {n_down} downregulated).\n\n"
                    f"**Top upregulated:**\n{top_up_str}\n\n"
                    f"**Significant pathways:**\n{pw_table}\n\n"
                    f"**Generated figures:**\n{fig_table}"
                ),
                evidence_refs=[f.path for f in figures],
            ),
            DraftSection(
                heading="5. Literature Evidence Table",
                body=cite_table,
                evidence_refs=citations[:5],
            ),
            DraftSection(
                heading="6. Hypotheses and Proposed Experiments",
                body=hyp_table + "\n\n**Proposed experiments:**\n"
                    "- Metabolic flux analysis (Seahorse) for H1\n"
                    "- Proteasome activity assay for H2\n"
                    "- mTOR inhibitor (rapamycin) rescue experiment for H3",
                evidence_refs=[h.ref for h in hypotheses],
            ),
            DraftSection(
                heading="7. Manuscript Outline",
                body=(
                    "**Abstract** → **Introduction** (background, question)\n"
                    "→ **Methods** (data acquisition, DE, enrichment)\n"
                    "→ **Results** (volcano, heatmap, pathways)\n"
                    "→ **Discussion** (hypotheses, comparison with literature)\n"
                    "→ **Conclusion** → **References**"
                ),
                evidence_refs=[],
            ),
            DraftSection(
                heading="8. Limitations and Next Steps",
                body=(
                    "**Limitations:**\n"
                    "- Stub PubMed results (not live API)\n"
                    "- Synthetic dataset (replace with real quantitative proteomics)\n"
                    "- No peptide-level validation\n\n"
                    "**Next Steps:**\n"
                    "- Validate H1 with metabolic assay\n"
                    "- Cross-reference with PhosphoSitePlus\n"
                    "- Integrate RNA-seq for proteotranscriptomic correlation"
                ),
                evidence_refs=[],
            ),
            DraftSection(
                heading="9. Evidence Coverage",
                body="[Computed by VerifierAgent — see below]",
                evidence_refs=[],
            ),
        ]

        state.draft_sections = sections
        state.limitations = [
            "Stub PubMed results",
            "Synthetic dataset",
            "No peptide-level validation",
        ]
        state.next_steps = [
            "Validate H1 with metabolic assay",
            "Cross-reference with PhosphoSitePlus",
            "Integrate RNA-seq",
        ]
        return state
