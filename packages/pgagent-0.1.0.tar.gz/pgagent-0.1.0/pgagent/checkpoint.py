"""Checkpoint: serialize / deserialize PGState to disk for resumability."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from pgagent.state import PGState


def save_checkpoint(state: PGState, checkpoint_path: Path) -> None:
    """Serialize PGState to JSON checkpoint."""
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    checkpoint_path.write_text(state.model_dump_json(indent=2))


def load_checkpoint(checkpoint_path: Path) -> Optional[PGState]:
    """Deserialize PGState from JSON checkpoint. Returns None if not found."""
    if not checkpoint_path.exists():
        return None
    raw = json.loads(checkpoint_path.read_text())
    return PGState(**raw)


def list_checkpoints(project_root: Path) -> list[Path]:
    """Return sorted list of checkpoint files (newest first)."""
    ckpt_dir = project_root / "results" / "checkpoints"
    if not ckpt_dir.exists():
        return []
    return sorted(ckpt_dir.glob("run_*.json"), reverse=True)
