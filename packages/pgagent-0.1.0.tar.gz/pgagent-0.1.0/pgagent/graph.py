"""LangGraph workflow graph for pgagent.

Nodes:
  1. lead_plan_node
  2. literature_node
  3. data_node
  4. stats_node
  5. hypothesis_node
  6. writing_node
  7. verifier_node
  8. finalize_node

Edges: linear, with conditional retry loop from verifier → writing.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional

from pgagent.checkpoint import save_checkpoint
from pgagent.state import PGState

logger = logging.getLogger(__name__)


# ── Node implementations ────────────────────────────────────────────────────
# Each node receives a PGState dict (LangGraph passes TypedDict / dict),
# mutates what it needs, and returns the updated dict.


def lead_plan_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Plan the research: select agents and create a plan."""
    st = PGState(**state)
    from pgagent.agents.literature import LiteratureAgent
    from pgagent.agents.data import DataAgent
    from pgagent.agents.stats import StatsAgent
    from pgagent.agents.hypothesis import HypothesisAgent
    from pgagent.agents.writing import WritingAgent
    from pgagent.agents.verifier import VerifierAgent

    # Default: run all agents
    st.selected_agents = ["literature", "data", "stats", "hypothesis", "writing", "verifier"]
    st.plan = (
        f"Research plan for: '{st.question}'\n"
        "1. Survey literature via PubMed\n"
        "2. Load and QC proteomics data\n"
        "3. Run differential expression + pathway enrichment\n"
        "4. Generate hypotheses ranked by evidence\n"
        "5. Draft 9-section manuscript\n"
        "6. Verify evidence coverage"
    )
    st.completed_nodes.append("lead_plan_node")
    st.current_node = "literature_node"
    _checkpoint(st)
    return st.model_dump()


def literature_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Run the LiteratureAgent."""
    st = PGState(**state)
    from pgagent.agents.literature import LiteratureAgent
    from pgagent.llm.router import get_client_for_agent
    agent = LiteratureAgent(llm=get_client_for_agent("literature", st.project_root))
    st = agent.run(st)
    st.completed_nodes.append("literature_node")
    st.current_node = "data_node"
    _checkpoint(st)
    return st.model_dump()


def data_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Run the DataAgent."""
    st = PGState(**state)
    from pgagent.agents.data import DataAgent
    from pgagent.llm.router import get_client_for_agent
    agent = DataAgent(llm=get_client_for_agent("data", st.project_root))
    st = agent.run(st)
    st.completed_nodes.append("data_node")
    st.current_node = "stats_node"
    _checkpoint(st)
    return st.model_dump()


def stats_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Run the StatsAgent."""
    st = PGState(**state)
    from pgagent.agents.stats import StatsAgent
    from pgagent.llm.router import get_client_for_agent
    agent = StatsAgent(llm=get_client_for_agent("stats", st.project_root))
    st = agent.run(st)
    st.completed_nodes.append("stats_node")
    st.current_node = "hypothesis_node"
    _checkpoint(st)
    return st.model_dump()


def hypothesis_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Run the HypothesisAgent."""
    st = PGState(**state)
    from pgagent.agents.hypothesis import HypothesisAgent
    from pgagent.llm.router import get_client_for_agent
    agent = HypothesisAgent(llm=get_client_for_agent("hypothesis", st.project_root))
    st = agent.run(st)
    st.completed_nodes.append("hypothesis_node")
    st.current_node = "writing_node"
    _checkpoint(st)
    return st.model_dump()


def writing_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Run the WritingAgent."""
    st = PGState(**state)
    from pgagent.agents.writing import WritingAgent
    from pgagent.llm.router import get_client_for_agent
    agent = WritingAgent(llm=get_client_for_agent("writing", st.project_root))
    st = agent.run(st)
    st.completed_nodes.append("writing_node")
    st.current_node = "verifier_node"
    _checkpoint(st)
    return st.model_dump()


def verifier_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Run the VerifierAgent — Evidence-First policy enforcement."""
    st = PGState(**state)
    from pgagent.agents.verifier import VerifierAgent
    from pgagent.llm.router import get_client_for_agent
    agent = VerifierAgent(llm=get_client_for_agent("verifier", st.project_root))
    st = agent.run(st)
    st.completed_nodes.append("verifier_node")
    st.current_node = "finalize_node"
    _checkpoint(st)
    return st.model_dump()


def finalize_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Write report, manifest, and link latest."""
    st = PGState(**state)
    from pgagent.run_manager import RunManager
    from pgagent.tools.report import save_markdown_report

    rm = RunManager(project_root=Path(st.project_root), run_id=st.run_id)
    save_markdown_report(st, rm.report_path)
    rm.link_latest_report()

    # Write manifest
    rm.write_manifest({
        "question": st.question,
        "plan": st.plan,
        "agents": st.selected_agents,
        "figures": [f.model_dump() for f in st.figures],
        "citations": st.citations,
        "evidence_coverage_pct": st.evidence_coverage_pct,
        "completed_nodes": st.completed_nodes,
        "errors": st.errors,
    })
    rm.log_event("finalize", {"status": "done", "run_id": st.run_id})

    st.completed_nodes.append("finalize_node")
    st.current_node = "done"
    save_checkpoint(st, rm.checkpoint_path)
    return st.model_dump()


# ── Routing helper ──────────────────────────────────────────────────────────

def _should_retry_writing(state: Dict[str, Any]) -> str:
    """After verifier: retry writing if too many violations."""
    st = PGState(**state)
    if len(st.evidence_violations) > 5 and "writing_node_retry" not in st.completed_nodes:
        return "writing_node"
    return "finalize_node"


def _checkpoint(st: PGState) -> None:
    """Save intermediate checkpoint if project_root is set."""
    if st.project_root and st.run_id:
        ckpt = Path(st.project_root) / "results" / "checkpoints" / f"run_{st.run_id}.json"
        try:
            save_checkpoint(st, ckpt)
        except Exception:
            pass


# ── Graph builder ───────────────────────────────────────────────────────────

def build_graph():
    """Build and compile the LangGraph StateGraph.

    Returns the compiled graph ready for .invoke().
    """
    try:
        from langgraph.graph import StateGraph, END
    except ImportError:
        raise ImportError(
            "langgraph is not installed. Run: pip install langgraph"
        )

    # LangGraph works with TypedDict; we pass plain dict and wrap/unwrap PGState
    from typing import TypedDict

    class _S(TypedDict, total=False):
        __annotations__ = {}  # dynamically accepts any keys

    builder = StateGraph(dict)

    builder.add_node("lead_plan_node", lead_plan_node)
    builder.add_node("literature_node", literature_node)
    builder.add_node("data_node", data_node)
    builder.add_node("stats_node", stats_node)
    builder.add_node("hypothesis_node", hypothesis_node)
    builder.add_node("writing_node", writing_node)
    builder.add_node("verifier_node", verifier_node)
    builder.add_node("finalize_node", finalize_node)

    builder.set_entry_point("lead_plan_node")
    builder.add_edge("lead_plan_node", "literature_node")
    builder.add_edge("literature_node", "data_node")
    builder.add_edge("data_node", "stats_node")
    builder.add_edge("stats_node", "hypothesis_node")
    builder.add_edge("hypothesis_node", "writing_node")
    builder.add_edge("writing_node", "verifier_node")
    builder.add_conditional_edges(
        "verifier_node",
        _should_retry_writing,
        {"writing_node": "writing_node", "finalize_node": "finalize_node"},
    )
    builder.add_edge("finalize_node", END)

    return builder.compile()


def run_pipeline(initial_state: PGState, start_node: Optional[str] = None) -> PGState:
    """Execute the full pipeline (or resume from start_node).

    Uses manual sequential node execution for maximum reliability across
    LangGraph versions. The compiled graph is available via build_graph()
    for streaming / async use cases.

    Args:
        initial_state: A fully-initialized PGState.
        start_node: If resuming, the node name to start from.

    Returns:
        Final PGState after all nodes have executed.
    """
    _node_order = [
        "lead_plan_node", "literature_node", "data_node", "stats_node",
        "hypothesis_node", "writing_node", "verifier_node", "finalize_node",
    ]
    _node_fns = {
        "lead_plan_node": lead_plan_node,
        "literature_node": literature_node,
        "data_node": data_node,
        "stats_node": stats_node,
        "hypothesis_node": hypothesis_node,
        "writing_node": writing_node,
        "verifier_node": verifier_node,
        "finalize_node": finalize_node,
    }

    idx = 0
    if start_node and start_node in _node_order:
        idx = _node_order.index(start_node)

    state_dict = initial_state.model_dump()

    for node_name in _node_order[idx:]:
        state_dict = _node_fns[node_name](state_dict)
        # Verifier retry: if violations > 5 and writing not yet retried
        if node_name == "verifier_node":
            st = PGState(**state_dict)
            if len(st.evidence_violations) > 5 and "writing_node_retry" not in st.completed_nodes:
                st.completed_nodes.append("writing_node_retry")
                state_dict = writing_node(st.model_dump())
                state_dict = verifier_node(state_dict)

    return PGState(**state_dict)

