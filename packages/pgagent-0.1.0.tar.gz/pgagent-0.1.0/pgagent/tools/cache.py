"""Cache layer: SHA-256 content-addressed disk cache inside project cache/."""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any, Optional


class Cache:
    """Simple content-addressed JSON cache stored under project_root/cache/."""

    def __init__(self, project_root: Path):
        self.cache_dir = project_root / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _key_path(self, key: str) -> Path:
        digest = hashlib.sha256(key.encode()).hexdigest()
        return self.cache_dir / f"{digest}.json"

    def get(self, key: str) -> Optional[Any]:
        """Return cached value for key, or None on cache miss."""
        p = self._key_path(key)
        if p.exists():
            try:
                return json.loads(p.read_text())
            except Exception:
                return None
        return None

    def set(self, key: str, value: Any) -> None:
        """Store value under key."""
        p = self._key_path(key)
        p.write_text(json.dumps(value, default=str))

    def has(self, key: str) -> bool:
        return self._key_path(key).exists()

    def delete(self, key: str) -> bool:
        p = self._key_path(key)
        if p.exists():
            p.unlink()
            return True
        return False

    def clear(self) -> int:
        """Remove all cached entries. Returns count of deleted files."""
        count = 0
        for f in self.cache_dir.glob("*.json"):
            f.unlink()
            count += 1
        return count

    def size(self) -> int:
        """Return number of cached entries."""
        return len(list(self.cache_dir.glob("*.json")))


def make_cache_key(*args: Any, **kwargs: Any) -> str:
    """Create a cache key from arbitrary arguments."""
    payload = json.dumps({"args": [str(a) for a in args], "kwargs": {k: str(v) for k, v in sorted(kwargs.items())}},
                         sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()
