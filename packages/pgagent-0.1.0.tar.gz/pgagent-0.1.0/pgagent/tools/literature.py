"""Literature tools: PubMed search/fetch (stubs) + citation builder."""
from __future__ import annotations

import hashlib
from typing import Any, Dict, List, Optional

from pgagent.tools import ToolResult, default_registry

# ── Stub data ───────────────────────────────────────────────────────────────

_MOCK_ARTICLES = [
    {
        "pmid": "12345678",
        "title": "Glycolytic reprogramming in tumor proteomes",
        "authors": ["Smith A", "Jones B"],
        "journal": "Mol Cell Proteomics",
        "year": 2022,
        "abstract": (
            "We report widespread upregulation of glycolytic enzymes in tumor "
            "proteomes, with GAPDH and PKM2 as key drivers of metabolic reprogramming."
        ),
    },
    {
        "pmid": "23456789",
        "title": "Proteasome dysfunction in cancer",
        "authors": ["Lee C", "Wang D"],
        "journal": "Cancer Res",
        "year": 2023,
        "abstract": (
            "Mutations in 26S proteasome subunits correlate with impaired protein "
            "quality control and accumulation of oncoproteins."
        ),
    },
    {
        "pmid": "34567890",
        "title": "mTOR signaling and translation upregulation",
        "authors": ["Patel E"],
        "journal": "Cell Rep",
        "year": 2021,
        "abstract": (
            "mTORC1-mediated phosphorylation of 4EBP1 drives cap-dependent "
            "translation in nutrient-rich tumor microenvironments."
        ),
    },
    {
        "pmid": "45678901",
        "title": "Ubiquitin landscape of the cancer proteome",
        "authors": ["Kumar F", "Zhao G"],
        "journal": "Nat Commun",
        "year": 2023,
        "abstract": (
            "Global ubiquitinomics reveals selective degradation of tumor suppressors "
            "via the CRL family of E3 ligases."
        ),
    },
    {
        "pmid": "56789012",
        "title": "Ribosome biogenesis and growth control",
        "authors": ["Chen H"],
        "journal": "EMBO J",
        "year": 2022,
        "abstract": (
            "Coordinated upregulation of ribosomal proteins and rRNA processing "
            "factors correlates with tumor proliferation rate."
        ),
    },
]


# ── Tools ───────────────────────────────────────────────────────────────────

@default_registry.register("pubmed_search")
def pubmed_search(query: str, n: int = 5) -> ToolResult:
    """Stub PubMed search — returns mock article metadata."""
    results = _MOCK_ARTICLES[:n]
    return ToolResult(
        ok=True,
        summary=f"PubMed search for '{query}' returned {len(results)} results (stub).",
        outputs={"articles": results, "query": query},
        citations=[f"PMID:{a['pmid']}" for a in results],
    )


@default_registry.register("pubmed_fetch_abstracts")
def pubmed_fetch_abstracts(pmids: List[str]) -> ToolResult:
    """Stub abstract fetcher — returns matching mock abstracts."""
    pmid_set = set(pmids)
    found = [a for a in _MOCK_ARTICLES if a["pmid"] in pmid_set]
    if not found:
        found = _MOCK_ARTICLES[:2]  # fallback
    return ToolResult(
        ok=True,
        summary=f"Fetched abstracts for {len(found)} PMIDs.",
        outputs={"abstracts": found},
        citations=[f"PMID:{a['pmid']}" for a in found],
    )


@default_registry.register("build_citation")
def build_citation(entry: Dict[str, Any]) -> ToolResult:
    """Format an article dict into a citation string."""
    authors = ", ".join(entry.get("authors", ["Unknown"]))
    year = entry.get("year", "")
    title = entry.get("title", "")
    journal = entry.get("journal", "")
    pmid = entry.get("pmid", "")
    citation = f"{authors} ({year}). {title}. {journal}. PMID:{pmid}"
    return ToolResult(
        ok=True,
        summary="Citation formatted.",
        outputs={"citation": citation},
        citations=[f"PMID:{pmid}"] if pmid else [],
    )
