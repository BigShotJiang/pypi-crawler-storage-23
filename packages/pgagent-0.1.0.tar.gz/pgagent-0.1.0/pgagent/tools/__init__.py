"""Tool Registry: ToolResult contract and tool registration decorator."""
from __future__ import annotations

import functools
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class ToolResult:
    """Uniform return contract for every registered tool."""
    ok: bool
    summary: str
    outputs: Dict[str, Any] = field(default_factory=dict)
    artifacts: List[Dict[str, str]] = field(default_factory=list)
    citations: List[str] = field(default_factory=list)
    error: Optional[str] = None


class ToolRegistry:
    """Registry that maps tool names to callables.

    Usage:
        registry = ToolRegistry()

        @registry.register("my_tool")
        def my_tool(...) -> ToolResult:
            ...

        result = registry.call("my_tool", ...)
    """

    def __init__(self) -> None:
        self._tools: Dict[str, Callable[..., ToolResult]] = {}

    def register(self, name: Optional[str] = None) -> Callable:
        """Decorator to register a callable as a tool."""
        def decorator(fn: Callable) -> Callable:
            tool_name = name or fn.__name__
            self._tools[tool_name] = fn
            return fn
        return decorator

    def call(self, name: str, **kwargs: Any) -> ToolResult:
        """Call a registered tool by name, catching exceptions."""
        if name not in self._tools:
            return ToolResult(ok=False, summary=f"Tool '{name}' not found.",
                              error=f"Unknown tool: {name}")
        try:
            return self._tools[name](**kwargs)
        except Exception as exc:
            return ToolResult(ok=False, summary=f"Tool '{name}' failed.",
                              error=str(exc))

    def list_tools(self) -> List[str]:
        """Return sorted list of registered tool names."""
        return sorted(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools


# Module-level default registry — all tools self-register here
default_registry = ToolRegistry()
