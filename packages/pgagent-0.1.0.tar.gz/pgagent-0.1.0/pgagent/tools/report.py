"""Report tools: Markdown report renderer + HTML publisher."""
from __future__ import annotations

from pathlib import Path
from datetime import datetime

from pgagent.state import PGState


def save_markdown_report(state: PGState, report_path: Path) -> None:
    """Render PGState → Markdown report using Jinja2 template."""
    try:
        from jinja2 import Environment, FileSystemLoader
        tmpl_dir = Path(__file__).parent.parent / "templates"
        env = Environment(loader=FileSystemLoader(str(tmpl_dir)), autoescape=False)
        tmpl = env.get_template("report.md.jinja")
        content = tmpl.render(state=state, now=datetime.utcnow().isoformat() + "Z")
    except Exception:
        # Fallback: plain concatenation
        content = _plain_report(state)

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(content, encoding="utf-8")


def publish_html(md_path: Path, out_path: Optional[Path] = None) -> Path:
    """Convert a Markdown report to standalone HTML."""
    if out_path is None:
        out_path = md_path.with_suffix(".html")

    md_text = md_path.read_text(encoding="utf-8") if md_path.exists() else ""

    try:
        import markdown
        html_body = markdown.markdown(md_text, extensions=["tables", "fenced_code"])
    except ImportError:
        # Ultra-simple fallback
        html_body = "<pre>" + md_text.replace("&", "&amp;").replace("<", "&lt;") + "</pre>"

    html = _wrap_html(html_body, title=md_path.stem)
    out_path.write_text(html, encoding="utf-8")
    return out_path


def _plain_report(state: PGState) -> str:
    lines = [
        f"# pgagent Research Report",
        f"",
        f"**Run ID:** {state.run_id}",
        f"**Generated:** {datetime.utcnow().isoformat()}Z",
        f"",
    ]
    for section in state.draft_sections:
        lines.append(f"## {section.heading}")
        lines.append(section.body)
        lines.append("")
    if state.evidence_coverage_pct is not None:
        lines.append(f"## Evidence Coverage: {state.evidence_coverage_pct:.1f}%")
    return "\n".join(lines)


def _wrap_html(body: str, title: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>{title}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
         max-width: 900px; margin: 40px auto; padding: 0 20px; color: #222; }}
  h1 {{ border-bottom: 2px solid #005f87; padding-bottom: 8px; color: #005f87; }}
  h2 {{ color: #2c5f87; margin-top: 32px; }}
  table {{ border-collapse: collapse; width: 100%; margin: 16px 0; }}
  th, td {{ border: 1px solid #ccc; padding: 8px 12px; text-align: left; }}
  th {{ background: #f0f4f8; font-weight: 600; }}
  code, pre {{ background: #f6f8fa; border-radius: 4px; padding: 2px 6px; }}
  pre {{ padding: 12px; overflow-x: auto; }}
</style>
</head>
<body>
{body}
</body>
</html>"""


# Allow Optional to be used above without importing at module level
from typing import Optional
