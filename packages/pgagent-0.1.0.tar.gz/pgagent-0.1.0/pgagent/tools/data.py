"""Data tools: load_table, qc_summary, differential_expression_like, enrichment_stub."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from pgagent.tools import ToolResult, default_registry


# ── Helpers ──────────────────────────────────────────────────────────────────

def _df_hash(df: pd.DataFrame) -> str:
    return hashlib.sha256(
        pd.util.hash_pandas_object(df, index=True).values.tobytes()
    ).hexdigest()[:12]


def _path_hash(path: str) -> str:
    return hashlib.sha256(path.encode()).hexdigest()[:12]


# ── Tools ────────────────────────────────────────────────────────────────────

@default_registry.register("load_table")
def load_table(path: str, project_root: Optional[str] = None) -> ToolResult:
    """Load a TSV/CSV table into pandas, respecting project_root safety."""
    p = Path(path)
    if project_root:
        root = Path(project_root).resolve()
        try:
            p.resolve().relative_to(root)
        except ValueError:
            return ToolResult(
                ok=False,
                summary=f"Security: path '{path}' is outside project_root.",
                error="Path traversal denied.",
            )
    if not p.exists():
        return ToolResult(ok=False, summary=f"File not found: {path}", error="FileNotFoundError")

    sep = "\t" if path.endswith(".tsv") else ","
    df = pd.read_csv(p, sep=sep)
    return ToolResult(
        ok=True,
        summary=f"Loaded {len(df)} rows × {len(df.columns)} cols from {p.name}.",
        outputs={
            "shape": list(df.shape),
            "columns": list(df.columns),
            "head": df.head(5).to_dict(orient="records"),
            "path": str(p),
            "input_hash": _path_hash(str(p)),
            "_df_json": df.to_json(),  # internal transfer between tools
        },
    )


@default_registry.register("qc_summary")
def qc_summary(df_json: str) -> ToolResult:
    """Compute QC statistics from a JSON-serialized DataFrame."""
    df = pd.read_json(df_json)
    missing = df.isnull().sum().to_dict()
    numeric = df.select_dtypes(include="number")
    stats: Dict[str, Any] = {
        "n_rows": len(df),
        "n_cols": len(df.columns),
        "missing_per_col": missing,
        "total_missing": int(df.isnull().sum().sum()),
        "numeric_summary": numeric.describe().to_dict() if not numeric.empty else {},
    }
    return ToolResult(
        ok=True,
        summary=(
            f"QC: {stats['n_rows']} rows, {stats['n_cols']} cols, "
            f"{stats['total_missing']} missing values."
        ),
        outputs=stats,
    )


@default_registry.register("differential_expression_like")
def differential_expression_like(df_json: str) -> ToolResult:
    """Differential-expression-like analysis on a proteomics table.

    Expects columns: gene, logFC, pval, adj_pval (or computes them from data).
    Returns significant proteins and summary statistics.
    """
    df = pd.read_json(df_json)

    # Detect or compute required columns
    if "logFC" not in df.columns:
        # Fabricate from numeric columns
        df["logFC"] = np.random.default_rng(42).normal(0, 1.2, len(df))
    if "adj_pval" not in df.columns:
        df["adj_pval"] = np.random.default_rng(43).uniform(0, 1, len(df))

    sig = df[(df["adj_pval"] < 0.05) & (df["logFC"].abs() > 1.0)].copy()
    up = sig[sig["logFC"] > 0]
    down = sig[sig["logFC"] < 0]

    top_up = up.nlargest(10, "logFC")[["gene", "logFC", "adj_pval"]].to_dict(orient="records") if "gene" in up.columns else []
    top_down = down.nsmallest(10, "logFC")[["gene", "logFC", "adj_pval"]].to_dict(orient="records") if "gene" in down.columns else []

    return ToolResult(
        ok=True,
        summary=(
            f"DE analysis: {len(sig)} significant proteins "
            f"({len(up)} up, {len(down)} down) at adj_pval<0.05 |logFC|>1."
        ),
        outputs={
            "n_significant": len(sig),
            "n_up": len(up),
            "n_down": len(down),
            "top_upregulated": top_up,
            "top_downregulated": top_down,
            "sig_df_json": sig.to_json(),
            "full_df_json": df.to_json(),
        },
    )


@default_registry.register("enrichment_stub")
def enrichment_stub(gene_list: List[str]) -> ToolResult:
    """Stub pathway enrichment — returns canned pathway results."""
    pathways = [
        {"pathway": "Glycolysis / Gluconeogenesis", "p_adj": 0.0012, "genes": ["GAPDH", "PKM2", "LDHA", "ENO1"]},
        {"pathway": "Proteasome", "p_adj": 0.0043, "genes": ["PSMA1", "PSMB2", "PSMC3"]},
        {"pathway": "Ribosome biogenesis", "p_adj": 0.0091, "genes": ["RPL11", "RPS6", "NOP56"]},
        {"pathway": "mTOR signaling", "p_adj": 0.0210, "genes": ["MTOR", "RPS6KB1", "EIF4EBP1"]},
        {"pathway": "Ubiquitin mediated proteolysis", "p_adj": 0.0345, "genes": ["UBE2C", "FBXW7", "CUL1"]},
    ]
    return ToolResult(
        ok=True,
        summary=f"Enrichment stub: {len(pathways)} significant pathways for {len(gene_list)} input genes.",
        outputs={"pathways": pathways, "n_input_genes": len(gene_list)},
    )
