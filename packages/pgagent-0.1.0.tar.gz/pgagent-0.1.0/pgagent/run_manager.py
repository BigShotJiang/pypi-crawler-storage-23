"""Run lifecycle management: run_id creation, output directory setup, manifests."""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from ruamel.yaml import YAML

_yaml = YAML()
_yaml.default_flow_style = False


def make_run_id() -> str:
    """Generate a deterministic-ish run ID: YYYYMMDD-HHMMSS-<4hex>."""
    ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    suffix = uuid.uuid4().hex[:6]
    return f"{ts}-{suffix}"


class RunManager:
    """Creates and manages output paths for a single pgagent run."""

    def __init__(self, project_root: Path, run_id: Optional[str] = None):
        self.project_root = project_root.resolve()
        self.run_id = run_id or make_run_id()
        self._setup_dirs()

    # ── Paths ──────────────────────────────────────────────────────────────

    @property
    def log_path(self) -> Path:
        return self.project_root / "results" / "logs" / f"run_{self.run_id}.jsonl"

    @property
    def report_path(self) -> Path:
        return self.project_root / "results" / "reports" / f"run_{self.run_id}.md"

    @property
    def manifest_path(self) -> Path:
        return self.project_root / "results" / "manifests" / f"run_{self.run_id}.yaml"

    @property
    def artifact_dir(self) -> Path:
        return self.project_root / "results" / "artifacts" / f"run_{self.run_id}"

    @property
    def checkpoint_path(self) -> Path:
        return self.project_root / "results" / "checkpoints" / f"run_{self.run_id}.json"

    @property
    def latest_report_path(self) -> Path:
        return self.project_root / "results" / "reports" / "latest.md"

    # ── Setup ──────────────────────────────────────────────────────────────

    def _setup_dirs(self) -> None:
        for d in [
            self.log_path.parent,
            self.report_path.parent,
            self.manifest_path.parent,
            self.artifact_dir,
            self.checkpoint_path.parent,
        ]:
            d.mkdir(parents=True, exist_ok=True)

    # ── Logging ────────────────────────────────────────────────────────────

    def log_event(self, event_type: str, payload: Dict[str, Any]) -> None:
        """Append a JSON-line to the run log."""
        record = {
            "ts": datetime.utcnow().isoformat() + "Z",
            "run_id": self.run_id,
            "event": event_type,
            **payload,
        }
        with self.log_path.open("a") as fh:
            fh.write(json.dumps(record) + "\n")

    # ── Manifest ───────────────────────────────────────────────────────────

    def write_manifest(self, data: Dict[str, Any]) -> None:
        """Write or overwrite the run manifest YAML."""
        manifest = {
            "run_id": self.run_id,
            "created": datetime.utcnow().isoformat() + "Z",
            **data,
        }
        with self.manifest_path.open("w") as fh:
            _yaml.dump(manifest, fh)

    def read_manifest(self) -> Optional[Dict[str, Any]]:
        if self.manifest_path.exists():
            return dict(_yaml.load(self.manifest_path))
        return None

    # ── Latest symlink ─────────────────────────────────────────────────────

    def link_latest_report(self) -> None:
        """Update results/reports/latest.md to point to this run's report."""
        latest = self.latest_report_path
        if latest.is_symlink() or latest.exists():
            latest.unlink()
        # Use relative symlink so the workspace remains portable
        try:
            latest.symlink_to(self.report_path.name)
        except Exception:
            # Fallback: just copy
            import shutil
            if self.report_path.exists():
                shutil.copy2(self.report_path, latest)
