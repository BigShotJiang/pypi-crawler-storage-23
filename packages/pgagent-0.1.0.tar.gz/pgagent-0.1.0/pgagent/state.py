"""PGState — the shared Pydantic state model for the LangGraph workflow."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ArtifactMeta(BaseModel):
    """Contract for every artifact produced by a tool."""
    path: str
    caption: str = ""
    created_by: str = ""
    params_hash: str = ""
    input_hash: str = ""


class ToolCallRecord(BaseModel):
    """Record of a single tool invocation."""
    tool_name: str
    inputs: Dict[str, Any] = Field(default_factory=dict)
    outputs: Dict[str, Any] = Field(default_factory=dict)
    ok: bool = True
    error: Optional[str] = None


class EvidenceItem(BaseModel):
    """A single piece of evidence (citation or artifact)."""
    kind: str  # "citation" | "artifact" | "hypothesis"
    ref: str   # PMID, artifact path, or hypothesis id
    summary: str = ""
    confidence: Optional[float] = None  # 0-1, for hypotheses


class DraftSection(BaseModel):
    """One section of the manuscript draft."""
    heading: str
    body: str
    evidence_refs: List[str] = Field(default_factory=list)


class PGState(BaseModel):
    """Shared mutable state threaded through all LangGraph nodes."""

    # ── Identity ──────────────────────────────────────────────────────────
    project_root: str = ""
    run_id: str = ""
    question: str = ""

    # ── Planning ──────────────────────────────────────────────────────────
    plan: Optional[str] = None
    selected_agents: List[str] = Field(default_factory=list)

    # ── Tool calls ────────────────────────────────────────────────────────
    tool_calls: List[ToolCallRecord] = Field(default_factory=list)

    # ── Literature ────────────────────────────────────────────────────────
    literature: List[Dict[str, Any]] = Field(default_factory=list)
    citations: List[str] = Field(default_factory=list)

    # ── Data ──────────────────────────────────────────────────────────────
    data_inputs: List[Dict[str, Any]] = Field(default_factory=list)

    # ── Analysis ──────────────────────────────────────────────────────────
    analysis_results: Dict[str, Any] = Field(default_factory=dict)
    figures: List[ArtifactMeta] = Field(default_factory=list)

    # ── Hypotheses ────────────────────────────────────────────────────────
    hypotheses: List[EvidenceItem] = Field(default_factory=list)

    # ── Writing ───────────────────────────────────────────────────────────
    draft_sections: List[DraftSection] = Field(default_factory=list)

    # ── Verification ─────────────────────────────────────────────────────
    evidence_violations: List[str] = Field(default_factory=list)
    evidence_coverage_pct: Optional[float] = None

    # ── Wrap-up ───────────────────────────────────────────────────────────
    limitations: List[str] = Field(default_factory=list)
    next_steps: List[str] = Field(default_factory=list)

    # ── Errors & meta ─────────────────────────────────────────────────────
    errors: List[str] = Field(default_factory=list)
    current_node: str = "lead_plan_node"
    completed_nodes: List[str] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}
