"""Global configuration management for pgagent.

Config lives at ~/.pgagent/config.yaml (or $PGCLI_CONFIG env var).
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field
from ruamel.yaml import YAML

_yaml = YAML()
_yaml.default_flow_style = False

CONFIG_DIR = Path(os.environ.get("PGCLI_CONFIG_DIR", Path.home() / ".pgagent"))
CONFIG_PATH = CONFIG_DIR / "config.yaml"


# ── Pydantic model ──────────────────────────────────────────────────────────

class AgentModelConfig(BaseModel):
    """Per-agent model routing entry."""
    provider: str = "mock"
    model: Optional[str] = None


class PGConfig(BaseModel):
    """Top-level pgagent configuration."""
    default_provider: str = Field(default="mock", description="LLM provider: mock|openai|anthropic|gemini")
    default_model: Optional[str] = None
    agent_models: Dict[str, AgentModelConfig] = Field(default_factory=dict)
    pubmed_email: Optional[str] = None
    cache_enabled: bool = True
    max_literature_results: int = 10
    log_level: str = "INFO"
    extra: Dict[str, Any] = Field(default_factory=dict)


# ── Load / Save ─────────────────────────────────────────────────────────────

def load_config() -> PGConfig:
    """Load config from disk; return defaults if file missing."""
    if CONFIG_PATH.exists():
        raw = _yaml.load(CONFIG_PATH)
        if raw:
            return PGConfig(**raw)
    return PGConfig()


def save_config(cfg: PGConfig) -> None:
    """Persist config to disk."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = cfg.model_dump(exclude_none=True)
    with CONFIG_PATH.open("w") as fh:
        _yaml.dump(data, fh)


def get_config_value(key: str) -> Any:
    """Retrieve a single config key (dot-notation supported)."""
    cfg = load_config()
    parts = key.split(".")
    obj: Any = cfg.model_dump()
    for part in parts:
        if isinstance(obj, dict):
            obj = obj.get(part)
        else:
            return None
    return obj


def set_config_value(key: str, value: str) -> None:
    """Set a single config key (dot-notation). Saves immediately."""
    cfg = load_config()
    data = cfg.model_dump()
    parts = key.split(".")
    d = data
    for part in parts[:-1]:
        d = d.setdefault(part, {})
    # Attempt bool/int coercion
    if value.lower() in ("true", "false"):
        d[parts[-1]] = value.lower() == "true"
    elif value.isdigit():
        d[parts[-1]] = int(value)
    else:
        d[parts[-1]] = value
    save_config(PGConfig(**data))
