"""pgagent — ProteoGenomics CLI research assistant."""

__version__ = "0.1.0"
__author__ = "Zhang Lab"
