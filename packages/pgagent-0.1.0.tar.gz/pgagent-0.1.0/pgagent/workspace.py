"""Workspace management: project init, directory layout, pgproject.yaml."""
from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

from ruamel.yaml import YAML

_yaml = YAML()
_yaml.default_flow_style = False

# Directories created under <project_root>/
WORKSPACE_DIRS = [
    "data/raw",
    "data/processed",
    "results/artifacts",
    "results/reports",
    "results/logs",
    "results/manifests",
    "results/checkpoints",
    "knowledge/papers",
    "knowledge/bib",
    "knowledge/notes",
    "cache",
]

PGPROJECT_YAML = "pgproject.yaml"


def init_workspace(project_name: str, base_dir: Optional[Path] = None) -> Path:
    """Create a new pgagent workspace directory and scaffold.

    Args:
        project_name: Name of the project (becomes directory name).
        base_dir: Parent directory. Defaults to current working directory.

    Returns:
        Absolute path to the newly created project root.
    """
    root = (base_dir or Path.cwd()) / project_name
    root.mkdir(parents=True, exist_ok=True)

    for subdir in WORKSPACE_DIRS:
        (root / subdir).mkdir(parents=True, exist_ok=True)

    _write_pgproject(root, project_name)
    _write_gitignore(root)
    return root


def _write_pgproject(root: Path, name: str) -> None:
    meta = {
        "name": name,
        "version": "0.1.0",
        "created": datetime.utcnow().isoformat() + "Z",
        "description": f"{name} proteogenomics project",
        "data": {"raw": "data/raw/", "processed": "data/processed/"},
        "results": {
            "artifacts": "results/artifacts/",
            "reports": "results/reports/",
            "logs": "results/logs/",
            "manifests": "results/manifests/",
            "checkpoints": "results/checkpoints/",
        },
    }
    with (root / PGPROJECT_YAML).open("w") as fh:
        _yaml.dump(meta, fh)


def _write_gitignore(root: Path) -> None:
    content = "\n".join([
        "cache/",
        "results/artifacts/",
        "__pycache__/",
        "*.pyc",
        ".DS_Store",
        "",
    ])
    (root / ".gitignore").write_text(content)


def load_pgproject(project_root: Path) -> dict:
    """Load pgproject.yaml from project root."""
    path = project_root / PGPROJECT_YAML
    if not path.exists():
        raise FileNotFoundError(f"Not a pgagent workspace: {project_root}")
    return _yaml.load(path)


def find_project_root(start: Optional[Path] = None) -> Optional[Path]:
    """Walk up from start (cwd) looking for pgproject.yaml."""
    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        if (candidate / PGPROJECT_YAML).exists():
            return candidate
    return None


def add_paper(project_root: Path, pdf_path: Path) -> Path:
    """Copy a PDF into knowledge/papers/."""
    dest_dir = project_root / "knowledge" / "papers"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / pdf_path.name
    shutil.copy2(pdf_path, dest)
    return dest
