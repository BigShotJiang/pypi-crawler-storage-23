"""Tests: run manifest completeness."""
from __future__ import annotations

import pytest
from pathlib import Path


REQUIRED_MANIFEST_KEYS = {"run_id", "created", "question", "agents", "completed_nodes"}


def test_manifest_written(tmp_project, base_state):
    """Manifest is created at expected path."""
    from pgagent.run_manager import RunManager
    rm = RunManager(tmp_project, run_id="test-run-001")
    rm.write_manifest({
        "question": "test question",
        "plan": "test plan",
        "agents": ["literature", "data"],
        "figures": [],
        "citations": [],
        "evidence_coverage_pct": 90.0,
        "completed_nodes": ["lead_plan_node"],
        "errors": [],
    })
    assert rm.manifest_path.exists()


def test_manifest_has_required_keys(tmp_project):
    """Manifest YAML contains all required top-level keys."""
    from pgagent.run_manager import RunManager
    rm = RunManager(tmp_project, run_id="test-manifest-001")
    rm.write_manifest({
        "question": "q",
        "plan": "p",
        "agents": ["data"],
        "figures": [],
        "citations": [],
        "evidence_coverage_pct": 75.0,
        "completed_nodes": ["lead_plan_node", "data_node"],
        "errors": [],
    })
    data = rm.read_manifest()
    assert data is not None
    for key in REQUIRED_MANIFEST_KEYS:
        assert key in data, f"Missing key: {key}"


def test_manifest_run_id_correct(tmp_project):
    """Manifest run_id matches RunManager.run_id."""
    from pgagent.run_manager import RunManager
    rm = RunManager(tmp_project, run_id="abc-123")
    rm.write_manifest({"question": "q", "agents": [], "figures": [],
                       "citations": [], "evidence_coverage_pct": None,
                       "completed_nodes": [], "errors": []})
    data = rm.read_manifest()
    assert data["run_id"] == "abc-123"


def test_manifest_jsonl_log(tmp_project):
    """JSONL log events are appended correctly."""
    import json
    from pgagent.run_manager import RunManager
    rm = RunManager(tmp_project, run_id="log-001")
    rm.log_event("start", {"question": "q"})
    rm.log_event("agent", {"name": "literature"})
    lines = rm.log_path.read_text().strip().splitlines()
    assert len(lines) == 2
    ev1 = json.loads(lines[0])
    assert ev1["event"] == "start"
    assert ev1["run_id"] == "log-001"
