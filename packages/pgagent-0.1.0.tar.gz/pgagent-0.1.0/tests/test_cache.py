"""Tests: caching correctness."""
from __future__ import annotations

import pytest
from pathlib import Path


def test_cache_miss_on_fresh(tmp_project):
    """Fresh cache returns None."""
    from pgagent.tools.cache import Cache
    cache = Cache(tmp_project)
    assert cache.get("nonexistent_key") is None
    assert not cache.has("nonexistent_key")


def test_cache_hit_after_set(tmp_project):
    """Value stored and retrieved correctly."""
    from pgagent.tools.cache import Cache
    cache = Cache(tmp_project)
    cache.set("tool:query1", {"result": "data", "count": 42})
    result = cache.get("tool:query1")
    assert result is not None
    assert result["count"] == 42


def test_cache_hit_determinism(tmp_project):
    """Same key always hits same value."""
    from pgagent.tools.cache import Cache
    cache = Cache(tmp_project)
    cache.set("k", [1, 2, 3])
    assert cache.get("k") == [1, 2, 3]
    assert cache.get("k") == [1, 2, 3]


def test_cache_make_key_stable(tmp_project):
    """make_cache_key is deterministic."""
    from pgagent.tools.cache import make_cache_key
    k1 = make_cache_key("pubmed_search", query="cancer", n=5)
    k2 = make_cache_key("pubmed_search", query="cancer", n=5)
    assert k1 == k2


def test_cache_different_keys(tmp_project):
    """Different inputs produce different keys."""
    from pgagent.tools.cache import make_cache_key
    k1 = make_cache_key("pubmed_search", query="cancer")
    k2 = make_cache_key("pubmed_search", query="diabetes")
    assert k1 != k2


def test_cache_clear(tmp_project):
    """Clear removes all entries."""
    from pgagent.tools.cache import Cache
    cache = Cache(tmp_project)
    cache.set("a", 1)
    cache.set("b", 2)
    n = cache.clear()
    assert n == 2
    assert cache.size() == 0
    assert cache.get("a") is None


def test_cache_delete(tmp_project):
    """Delete removes a single entry."""
    from pgagent.tools.cache import Cache
    cache = Cache(tmp_project)
    cache.set("x", 99)
    assert cache.has("x")
    assert cache.delete("x")
    assert not cache.has("x")
    assert not cache.delete("x")  # second delete returns False
