"""Tests: generated report headings and structure."""
from __future__ import annotations

import pytest
from pathlib import Path

REQUIRED_HEADINGS = [
    "1. Research Question",
    "2. Data Inputs",
    "3. Methods Executed",
    "4. Key Results",
    "5. Literature Evidence Table",
    "6. Hypotheses",
    "7. Manuscript Outline",
    "8. Limitations",
    "9. Evidence Coverage",
]


def _make_full_state(tmp_project):
    """Build a fully populated PGState for report testing."""
    from pgagent.state import PGState, DraftSection, ArtifactMeta, EvidenceItem

    state = PGState(
        project_root=str(tmp_project),
        run_id="report-test-001",
        question="Test research question?",
        plan="Test plan",
        citations=["Smith A (2022). Title. Journal. PMID:12345678"],
        evidence_coverage_pct=88.0,
        evidence_violations=["Section 4: unsupported claim"],
    )
    state.figures = [
        ArtifactMeta(
            path=str(tmp_project / "results/artifacts/run_report/volcano_abc.png"),
            caption="Volcano plot",
            created_by="plot_volcano",
            params_hash="abc",
            input_hash="def",
        )
    ]
    state.hypotheses = [
        EvidenceItem(kind="hypothesis", ref="H1",
                     summary="Glycolysis is upregulated [artifact-backed]", confidence=0.8)
    ]
    state.draft_sections = [
        DraftSection(heading=h, body=f"Content for '{h}'", evidence_refs=[])
        for h in REQUIRED_HEADINGS
    ]
    return state


def test_report_has_all_required_headings(tmp_project):
    """Generated Markdown report contains all 9 required section headings."""
    from pgagent.tools.report import save_markdown_report
    state = _make_full_state(tmp_project)
    report_path = tmp_project / "results" / "reports" / "run_report-test-001.md"
    save_markdown_report(state, report_path)

    assert report_path.exists()
    content = report_path.read_text()

    for heading in REQUIRED_HEADINGS:
        # Each heading should appear somewhere in the document
        assert heading in content, f"Missing heading: {heading}"


def test_report_contains_run_id(tmp_project):
    """Report includes the run ID."""
    from pgagent.tools.report import save_markdown_report
    state = _make_full_state(tmp_project)
    report_path = tmp_project / "results" / "reports" / "run_id_test.md"
    save_markdown_report(state, report_path)
    content = report_path.read_text()
    assert "report-test-001" in content


def test_report_contains_evidence_coverage(tmp_project):
    """Report includes evidence coverage percentage."""
    from pgagent.tools.report import save_markdown_report
    state = _make_full_state(tmp_project)
    report_path = tmp_project / "results" / "reports" / "run_coverage_test.md"
    save_markdown_report(state, report_path)
    content = report_path.read_text()
    assert "88" in content or "Coverage" in content


def test_report_figures_section(tmp_project):
    """Report includes figure metadata."""
    from pgagent.tools.report import save_markdown_report
    state = _make_full_state(tmp_project)
    report_path = tmp_project / "results" / "reports" / "run_figures_test.md"
    save_markdown_report(state, report_path)
    content = report_path.read_text()
    assert "Volcano plot" in content or "volcano" in content.lower()


def test_html_publish(tmp_project):
    """publish_html creates a non-empty HTML file."""
    from pgagent.tools.report import save_markdown_report, publish_html
    state = _make_full_state(tmp_project)
    report_path = tmp_project / "results" / "reports" / "run_html_test.md"
    save_markdown_report(state, report_path)
    html_path = publish_html(report_path)
    assert html_path.exists()
    content = html_path.read_text()
    assert "<html" in content.lower()
    assert len(content) > 200
