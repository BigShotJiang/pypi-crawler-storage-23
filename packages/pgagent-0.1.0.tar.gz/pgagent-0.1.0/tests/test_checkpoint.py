"""Tests: checkpoint save, load, and resume."""
from __future__ import annotations

import pytest
from pathlib import Path


def test_checkpoint_save_and_load(tmp_project, base_state):
    """Saved checkpoint can be deserialized back to exact PGState."""
    from pgagent.checkpoint import save_checkpoint, load_checkpoint

    base_state.plan = "Test plan"
    base_state.citations = ["PMID:12345678"]
    base_state.completed_nodes = ["lead_plan_node", "literature_node"]

    ckpt = tmp_project / "results" / "checkpoints" / "run_test-run-001.json"
    save_checkpoint(base_state, ckpt)

    loaded = load_checkpoint(ckpt)
    assert loaded is not None
    assert loaded.run_id == base_state.run_id
    assert loaded.plan == "Test plan"
    assert loaded.citations == ["PMID:12345678"]
    assert "lead_plan_node" in loaded.completed_nodes


def test_checkpoint_load_missing_returns_none(tmp_project):
    """Loading a non-existent checkpoint returns None."""
    from pgagent.checkpoint import load_checkpoint
    ckpt = tmp_project / "results" / "checkpoints" / "run_nonexistent.json"
    result = load_checkpoint(ckpt)
    assert result is None


def test_checkpoint_preserves_figures(tmp_project, base_state):
    """ArtifactMeta objects survive round-trip."""
    from pgagent.checkpoint import save_checkpoint, load_checkpoint
    from pgagent.state import ArtifactMeta

    base_state.figures = [
        ArtifactMeta(
            path="results/artifacts/run_001/volcano_abc.png",
            caption="Volcano plot",
            created_by="plot_volcano",
            params_hash="abc123",
            input_hash="def456",
        )
    ]
    ckpt = tmp_project / "results" / "checkpoints" / "run_fig-test.json"
    save_checkpoint(base_state, ckpt)
    loaded = load_checkpoint(ckpt)
    assert len(loaded.figures) == 1
    assert loaded.figures[0].caption == "Volcano plot"
    assert loaded.figures[0].created_by == "plot_volcano"


def test_checkpoint_list(tmp_project, base_state):
    """List checkpoints returns saved files."""
    from pgagent.checkpoint import save_checkpoint, load_checkpoint, list_checkpoints

    ckpt1 = tmp_project / "results" / "checkpoints" / "run_aaa.json"
    ckpt2 = tmp_project / "results" / "checkpoints" / "run_bbb.json"
    save_checkpoint(base_state, ckpt1)
    save_checkpoint(base_state, ckpt2)

    checkpoints = list_checkpoints(tmp_project)
    names = [c.name for c in checkpoints]
    assert "run_aaa.json" in names
    assert "run_bbb.json" in names
