# morphlabs

Python SDK for Morphlabs biosignal processing API.

## Installation

```bash
pip install morphlabs
```

## Quick Start

```python
from morphlabs.models import Scientia

# Set SCIENTIA_API_KEY environment variable or pass directly
scientia = Scientia(api_key="your-api-key")

# Clean EEG data
cleaned_data, channel_names, sfreq = scientia.clean_data("path/to/eeg_file.csv")
```

## Documentation

For full documentation, see [docs.morphlabs.tech](https://docs.morphlabs.tech)

## License

MIT
