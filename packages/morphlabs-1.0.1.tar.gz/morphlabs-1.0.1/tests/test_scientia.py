import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path
import requests

from morphlabs.models import Scientia


@pytest.fixture
def test_data_path():
    return Path(__file__).parent / "test_data"


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("SCIENTIA_API_KEY", "test_api_key")
    return "test_api_key"


@pytest.fixture
def no_api_key(monkeypatch):
    monkeypatch.delenv("SCIENTIA_API_KEY", raising=False)


# =============================================================================
# MockRunPodAPI helper
# =============================================================================

class MockRunPodAPI:
    """Stateful mock that simulates the two-phase async RunPod flow."""

    def __init__(self, job_id="test-job-123", poll_responses=None):
        self.job_id = job_id
        self.submitted_payloads = []
        self.poll_call_count = 0
        # Default: immediately COMPLETED echoing submitted data
        self._poll_responses = poll_responses
        self._submitted_data = None

    def mock_post(self, url, headers=None, json=None, **kwargs):
        self.submitted_payloads.append(json)
        self._submitted_data = json
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {
            "id": self.job_id,
            "status": "IN_QUEUE",
        }
        return mock_response

    def mock_get(self, url, headers=None, **kwargs):
        self.poll_call_count += 1
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True

        if self._poll_responses:
            # Pop the next custom response from the list
            resp = self._poll_responses.pop(0)
            mock_response.json.return_value = resp
        else:
            # Default: COMPLETED, echo the submitted data back
            data = self._submitted_data["input"]["data"] if self._submitted_data else []
            mock_response.json.return_value = {
                "status": "COMPLETED",
                "output": {
                    "reconstructed": data,
                    "meta": {"model_version": "v1"},
                },
            }
        return mock_response


# =============================================================================
# Init Tests
# =============================================================================

def test_init_defaults(no_api_key):
    scientia = Scientia()
    assert scientia.api_key is None
    assert scientia.base_url == "https://api.runpod.ai/v2/bsqrfd0tjfl0u4"


def test_init_with_api_key(no_api_key):
    scientia = Scientia(api_key="test_api_key1")
    assert scientia.api_key == "test_api_key1"
    assert scientia.base_url == "https://api.runpod.ai/v2/bsqrfd0tjfl0u4"


def test_init_from_env(api_key):
    scientia = Scientia(base_url="https://test.scientia.ai")
    assert scientia.api_key == "test_api_key"
    assert scientia.base_url == "https://test.scientia.ai"


@pytest.mark.parametrize("base_url,expected", [
    ("https://api.scientia.ai/", "https://api.scientia.ai"),
    ("https://api.scientia.ai/v1", "https://api.scientia.ai/v1"),
    ("https://api.scientia.ai/v1/", "https://api.scientia.ai/v1"),
])
def test_init_strips_trailing_slash(base_url, expected):
    scientia = Scientia(api_key="test_api_key", base_url=base_url)
    assert scientia.base_url == expected


def test_configurable_poll_params():
    scientia = Scientia(api_key="test_api_key", poll_interval=2.5, max_poll_time=600.0)
    assert scientia.poll_interval == 2.5
    assert scientia.max_poll_time == 600.0


def test_base_url_from_env(monkeypatch):
    monkeypatch.setenv("MORPHLABS_BASE_URL", "https://dev.runpod.ai/v2/dev-endpoint")
    scientia = Scientia(api_key="test_api_key")
    assert scientia.base_url == "https://dev.runpod.ai/v2/dev-endpoint"


def test_base_url_param_overrides_env(monkeypatch):
    monkeypatch.setenv("MORPHLABS_BASE_URL", "https://dev.runpod.ai/v2/dev-endpoint")
    scientia = Scientia(api_key="test_api_key", base_url="https://custom.api.ai/v1")
    assert scientia.base_url == "https://custom.api.ai/v1"


# =============================================================================
# Validation Tests
# =============================================================================

def test_missing_api_key_error(no_api_key, test_data_path):
    scientia = Scientia()
    with pytest.raises(ValueError) as e:
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key not found" in str(e.value)


def test_empty_api_key_error(monkeypatch, test_data_path):
    monkeypatch.setenv("SCIENTIA_API_KEY", "")
    with pytest.raises(ValueError) as e:
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key cannot be empty or whitespace" in str(e.value)


def test_whitespace_api_key_error(monkeypatch, test_data_path):
    monkeypatch.setenv("SCIENTIA_API_KEY", " ")
    with pytest.raises(ValueError) as e:
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key cannot be empty or whitespace" in str(e.value)


def test_invalid_base_url_error(test_data_path):
    with pytest.raises(ValueError) as e:
        scientia = Scientia(api_key="test_api_key", base_url="invalid_url")
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "Invalid base_url" in str(e.value)


def test_invalid_base_url_protocol_error(test_data_path):
    with pytest.raises(ValueError) as e:
        scientia = Scientia(api_key="test_api_key", base_url="ftp://invalid_url")
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "URL must start with http:// or https://" in str(e.value)


# =============================================================================
# Success / Data Tests
# =============================================================================

def test_clean_data_success(api_key, test_data_path):
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        data, channel_names, sfreq = scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert data is not None
        assert data.shape == (19, 2500)
        assert isinstance(channel_names, list)
        assert isinstance(sfreq, float)


def test_clean_data_removes_padding(api_key, test_data_path):
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()

        data_padded, _, _ = scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert data_padded.shape == (19, 2500)

        data_no_pad, _, _ = scientia.clean_data(test_data_path / "valid_19ch_2000samples.csv")
        assert data_no_pad.shape == (19, 2000)


def test_json_missing_reconstructed_field(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        {"status": "COMPLETED", "output": {}},
    ])
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert "Invalid response from API: Missing 'reconstructed' field in response." in str(e.value)


def test_json_decode_error_on_submit(api_key, test_data_path):
    def mock_bad_json_post(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.side_effect = requests.exceptions.JSONDecodeError("", "", 0)
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_bad_json_post):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Expected JSON but received invalid data" in str(e.value)


def test_json_decode_error_on_poll(api_key, test_data_path):
    mock_api = MockRunPodAPI()
    original_get = mock_api.mock_get

    def mock_bad_json_get(url, headers=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.side_effect = requests.exceptions.JSONDecodeError("", "", 0)
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_bad_json_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Expected JSON but received invalid data" in str(e.value)


# =============================================================================
# HTTP Error Tests
# =============================================================================

@pytest.mark.parametrize("status_code", [429, 500, 502, 503, 504])
def test_retryable_status_codes(api_key, test_data_path, status_code):
    def mock_retryable_error(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = status_code
        mock_response.ok = False
        mock_response.text = f"Error {status_code}"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_retryable_error):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert f"API request failed with status {status_code}" in str(last_exception)


@pytest.mark.parametrize("status_code,expected_msg", [
    (400, "Bad request"),
    (401, "Authentication failed"),
    (403, "Access denied"),
    (404, "API endpoint not found"),
])
def test_non_retryable_status_codes(api_key, test_data_path, status_code, expected_msg):
    def mock_non_retryable_error(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = status_code
        mock_response.ok = False
        mock_response.text = f"Error {status_code}"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_non_retryable_error):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert expected_msg in str(e.value)


def test_retry_attempts_count(api_key, test_data_path):
    call_count = 0

    def mock_always_fails(url, headers=None, json=None, **kwargs):
        nonlocal call_count
        call_count += 1
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.ok = False
        mock_response.text = "Server error"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_always_fails):
        scientia = Scientia()
        with pytest.raises(Exception):
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert call_count == 3


def test_network_timeout(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=requests.exceptions.Timeout("Connection timed out")):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert "Network error" in str(last_exception)


def test_network_connection_error(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=requests.exceptions.ConnectionError("Connection refused")):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert "Network error" in str(last_exception)


# =============================================================================
# RunPod Polling / Status Tests
# =============================================================================

def test_poll_transitions_through_statuses(api_key, test_data_path):
    """IN_QUEUE -> IN_PROGRESS -> COMPLETED should succeed."""
    mock_api = MockRunPodAPI(poll_responses=[
        {"status": "IN_QUEUE"},
        {"status": "IN_PROGRESS"},
        # Final COMPLETED will be auto-generated by mock_get default path
    ])
    # After poll_responses are exhausted, fall back to default COMPLETED
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        data, _, _ = scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert data is not None
        assert data.shape == (19, 1000)
        assert mock_api.poll_call_count == 3  # IN_QUEUE + IN_PROGRESS + COMPLETED


def test_runpod_failed_status(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        {"status": "FAILED", "error": "GPU out of memory"},
    ])
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Scientia API request failed" in str(e.value)
        assert "GPU out of memory" in str(e.value)


def test_runpod_cancelled_status(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        {"status": "CANCELLED"},
    ])
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "was cancelled" in str(e.value)


def test_poll_timeout(api_key, test_data_path):
    mock_api = MockRunPodAPI(poll_responses=[
        {"status": "IN_QUEUE"},
        {"status": "IN_QUEUE"},
        {"status": "IN_PROGRESS"},
    ])

    # Simulate time advancing past max_poll_time
    time_values = iter([0.0, 0.0, 100.0, 100.0, 400.0, 400.0])

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"), \
         patch("morphlabs.models.scientia.time.monotonic", side_effect=time_values):
        scientia = Scientia(max_poll_time=300.0)
        with pytest.raises(TimeoutError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "did not complete within" in str(e.value)


def test_submit_missing_job_id(api_key, test_data_path):
    """If /run response lacks an 'id' field, raise ValueError."""
    def mock_no_id_post(url, headers=None, json=None, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {"status": "IN_QUEUE"}  # no "id"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_no_id_post):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Missing job 'id' field" in str(e.value)


def test_url_construction(api_key, test_data_path):
    """Verify POST goes to /run and GET goes to /status/{job_id}."""
    captured_post_urls = []
    captured_get_urls = []

    mock_api = MockRunPodAPI()
    original_post = mock_api.mock_post
    original_get = mock_api.mock_get

    def capture_post(url, headers=None, json=None, **kwargs):
        captured_post_urls.append(url)
        return original_post(url, headers=headers, json=json, **kwargs)

    def capture_get(url, headers=None, **kwargs):
        captured_get_urls.append(url)
        return original_get(url, headers=headers, **kwargs)

    with patch("morphlabs.models.scientia.requests.post", side_effect=capture_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=capture_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert all(url.endswith("/run") for url in captured_post_urls)
    assert all("/status/test-job-123" in url for url in captured_get_urls)


# =============================================================================
# Payload / Header Tests
# =============================================================================

def test_api_key_in_payload(api_key, test_data_path):
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert len(mock_api.submitted_payloads) > 0
    payload = mock_api.submitted_payloads[0]
    assert "input" in payload
    assert "api_key" in payload["input"]
    assert payload["input"]["api_key"] == "test_api_key"
    assert "channel_names" in payload["input"]
    assert isinstance(payload["input"]["channel_names"], list)
    assert "data" in payload["input"]
    assert isinstance(payload["input"]["data"], list)


def test_runpod_api_key_in_header(api_key, test_data_path):
    captured_headers = None
    mock_api = MockRunPodAPI()

    def mock_capture_headers(url, headers=None, json=None, **kwargs):
        nonlocal captured_headers
        captured_headers = headers
        # Delegate to mock_api so it stores the submitted data for polling
        return mock_api.mock_post(url, headers=headers, json=json, **kwargs)

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_capture_headers), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert captured_headers is not None
    assert "Authorization" in captured_headers
    assert captured_headers["Authorization"].startswith("Bearer ")
    assert "rpa_" in captured_headers["Authorization"]


def test_channel_names_in_payload(api_key, test_data_path):
    """Verify channel_names values match expected normalized names."""
    mock_api = MockRunPodAPI()
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_api.mock_post), \
         patch("morphlabs.models.scientia.requests.get", side_effect=mock_api.mock_get), \
         patch("morphlabs.models.scientia.time.sleep"):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    payload = mock_api.submitted_payloads[0]
    channel_names = payload["input"]["channel_names"]
    expected = [
        "FP1", "FP2", "F7", "F3", "FZ", "F4", "F8",
        "T3", "C3", "CZ", "C4", "T4",
        "T5", "P3", "PZ", "P4", "T6",
        "O1", "O2",
    ]
    assert channel_names == expected
