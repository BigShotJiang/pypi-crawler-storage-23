import pytest
import numpy as np

from morphlabs.io.preprocessing import (
    highpass_filter,
    notch_filter,
    normalize,
    denormalize,
    NormalizationParams
)


class TestHighpassFilter:
    """Tests for the high-pass filter function."""

    def test_removes_dc_offset(self):
        """High-pass filter should remove DC offset (constant component)."""
        sfreq = 250.0
        n_channels = 19
        n_samples = 2500

        # Create data with large DC offset
        dc_offset = 100.0
        data = np.ones((n_channels, n_samples), dtype=np.float32) * dc_offset

        filtered = highpass_filter(data, sfreq, cutoff=1.0)

        # DC component should be near zero after filtering
        assert np.abs(np.mean(filtered)) < 1.0

    def test_preserves_high_frequencies(self):
        """High-pass filter should preserve frequencies above cutoff."""
        sfreq = 250.0
        n_channels = 19
        n_samples = 2500

        # Create 10 Hz sine wave (well above 1 Hz cutoff)
        t = np.linspace(0, n_samples / sfreq, n_samples, dtype=np.float32)
        sine_wave = np.sin(2 * np.pi * 10 * t)
        data = np.tile(sine_wave, (n_channels, 1))

        filtered = highpass_filter(data, sfreq, cutoff=1.0)

        # Power should be mostly preserved (allow some edge effects)
        original_power = np.mean(data ** 2)
        filtered_power = np.mean(filtered ** 2)
        assert filtered_power > 0.8 * original_power

    def test_attenuates_low_frequencies(self):
        """High-pass filter should attenuate frequencies below cutoff."""
        sfreq = 250.0
        n_channels = 19
        n_samples = 5000

        # Create 0.1 Hz sine wave (below 1 Hz cutoff)
        t = np.linspace(0, n_samples / sfreq, n_samples, dtype=np.float32)
        sine_wave = np.sin(2 * np.pi * 0.1 * t)
        data = np.tile(sine_wave, (n_channels, 1))

        filtered = highpass_filter(data, sfreq, cutoff=1.0)

        # Power should be significantly reduced
        original_power = np.mean(data ** 2)
        filtered_power = np.mean(filtered ** 2)
        assert filtered_power < 0.3 * original_power

    def test_output_dtype(self):
        """Output should be float32."""
        sfreq = 250.0
        data = np.random.randn(19, 1000).astype(np.float32)
        filtered = highpass_filter(data, sfreq)
        assert filtered.dtype == np.float32

    def test_output_shape(self):
        """Output shape should match input shape."""
        sfreq = 250.0
        data = np.random.randn(19, 1000).astype(np.float32)
        filtered = highpass_filter(data, sfreq)
        assert filtered.shape == data.shape


class TestNotchFilter:
    """Tests for the notch filter function."""

    def test_attenuates_60hz(self):
        """Notch filter should attenuate 60 Hz power line frequency."""
        sfreq = 250.0
        n_channels = 19
        n_samples = 2500

        # Create 60 Hz sine wave
        t = np.linspace(0, n_samples / sfreq, n_samples, dtype=np.float32)
        sine_wave = np.sin(2 * np.pi * 60 * t)
        data = np.tile(sine_wave, (n_channels, 1))

        filtered = notch_filter(data, sfreq, freq=60.0)

        # Power should be significantly reduced at 60 Hz
        original_power = np.mean(data ** 2)
        filtered_power = np.mean(filtered ** 2)
        assert filtered_power < 0.1 * original_power

    def test_attenuates_50hz(self):
        """Notch filter should attenuate 50 Hz when configured for EU."""
        sfreq = 250.0
        n_channels = 19
        n_samples = 2500

        # Create 50 Hz sine wave
        t = np.linspace(0, n_samples / sfreq, n_samples, dtype=np.float32)
        sine_wave = np.sin(2 * np.pi * 50 * t)
        data = np.tile(sine_wave, (n_channels, 1))

        filtered = notch_filter(data, sfreq, freq=50.0)

        # Power should be significantly reduced at 50 Hz
        original_power = np.mean(data ** 2)
        filtered_power = np.mean(filtered ** 2)
        assert filtered_power < 0.1 * original_power

    def test_preserves_other_frequencies(self):
        """Notch filter should preserve frequencies away from notch."""
        sfreq = 250.0
        n_channels = 19
        n_samples = 2500

        # Create 30 Hz sine wave (away from 60 Hz notch)
        t = np.linspace(0, n_samples / sfreq, n_samples, dtype=np.float32)
        sine_wave = np.sin(2 * np.pi * 30 * t)
        data = np.tile(sine_wave, (n_channels, 1))

        filtered = notch_filter(data, sfreq, freq=60.0)

        # Power should be mostly preserved
        original_power = np.mean(data ** 2)
        filtered_power = np.mean(filtered ** 2)
        assert filtered_power > 0.9 * original_power

    def test_output_dtype(self):
        """Output should be float32."""
        sfreq = 250.0
        data = np.random.randn(19, 1000).astype(np.float32)
        filtered = notch_filter(data, sfreq)
        assert filtered.dtype == np.float32

    def test_output_shape(self):
        """Output shape should match input shape."""
        sfreq = 250.0
        data = np.random.randn(19, 1000).astype(np.float32)
        filtered = notch_filter(data, sfreq)
        assert filtered.shape == data.shape


class TestNormalize:
    """Tests for the normalize function."""

    def test_produces_zero_mean(self):
        """Normalized data should have approximately zero mean per channel."""
        data = np.random.randn(19, 1000).astype(np.float32) * 10 + 5
        normalized, _ = normalize(data)

        channel_means = np.mean(normalized, axis=1)
        assert np.allclose(channel_means, 0, atol=1e-5)

    def test_produces_unit_std(self):
        """Normalized data should have approximately unit standard deviation per channel."""
        data = np.random.randn(19, 1000).astype(np.float32) * 10 + 5
        normalized, _ = normalize(data)

        channel_stds = np.std(normalized, axis=1)
        assert np.allclose(channel_stds, 1, atol=1e-5)

    def test_returns_normalization_params(self):
        """Normalize should return parameters needed for denormalization."""
        data = np.random.randn(19, 1000).astype(np.float32) * 10 + 5
        _, params = normalize(data)

        assert isinstance(params, NormalizationParams)
        assert params.mean.shape == (19,)
        assert params.std.shape == (19,)

    def test_handles_zero_std(self):
        """Normalize should handle constant channels (zero std) without division by zero."""
        data = np.ones((19, 1000), dtype=np.float32) * 5
        normalized, params = normalize(data)

        # Should not contain NaN or Inf
        assert not np.any(np.isnan(normalized))
        assert not np.any(np.isinf(normalized))

    def test_output_dtype(self):
        """Output should be float32."""
        data = np.random.randn(19, 1000).astype(np.float32)
        normalized, _ = normalize(data)
        assert normalized.dtype == np.float32

    def test_output_shape(self):
        """Output shape should match input shape."""
        data = np.random.randn(19, 1000).astype(np.float32)
        normalized, _ = normalize(data)
        assert normalized.shape == data.shape


class TestDenormalize:
    """Tests for the denormalize function."""

    def test_recovers_original_data(self):
        """Denormalize should recover the original data."""
        original = np.random.randn(19, 1000).astype(np.float32) * 10 + 5
        normalized, params = normalize(original)
        recovered = denormalize(normalized, params)

        assert np.allclose(recovered, original, atol=1e-5)

    def test_handles_different_scales(self):
        """Denormalize should work with different channel scales."""
        # Create data with different scales per channel
        original = np.zeros((19, 1000), dtype=np.float32)
        for i in range(19):
            original[i] = np.random.randn(1000) * (i + 1) * 10 + (i - 10) * 5

        normalized, params = normalize(original)
        recovered = denormalize(normalized, params)

        assert np.allclose(recovered, original, atol=1e-4)

    def test_output_dtype(self):
        """Output should be float32."""
        data = np.random.randn(19, 1000).astype(np.float32)
        normalized, params = normalize(data)
        recovered = denormalize(normalized, params)
        assert recovered.dtype == np.float32

    def test_output_shape(self):
        """Output shape should match input shape."""
        data = np.random.randn(19, 1000).astype(np.float32)
        normalized, params = normalize(data)
        recovered = denormalize(normalized, params)
        assert recovered.shape == data.shape

    def test_roundtrip_preserves_statistics(self):
        """After normalize->denormalize, statistics should match original."""
        original = np.random.randn(19, 1000).astype(np.float32) * 10 + 5
        normalized, params = normalize(original)
        recovered = denormalize(normalized, params)

        original_means = np.mean(original, axis=1)
        recovered_means = np.mean(recovered, axis=1)
        assert np.allclose(original_means, recovered_means, atol=1e-5)

        original_stds = np.std(original, axis=1)
        recovered_stds = np.std(recovered, axis=1)
        assert np.allclose(original_stds, recovered_stds, atol=1e-5)


class TestNormalizationParams:
    """Tests for the NormalizationParams dataclass."""

    def test_stores_mean_and_std(self):
        """NormalizationParams should store mean and std arrays."""
        mean = np.array([1.0, 2.0, 3.0])
        std = np.array([0.5, 1.0, 1.5])
        params = NormalizationParams(mean=mean, std=std)

        assert np.array_equal(params.mean, mean)
        assert np.array_equal(params.std, std)
