"""Test cosmology distance module

"""
######## Imports ########
#### Standard Library ####
import time
import warnings
#### Third Party ####
import numpy as np
from astropy import units as u
from astropy import constants as const
from astropy.cosmology import Planck15
#### Local ####
from basil_core.astro.coordinates.distance import DistanceInterpolator
from basil_core.astro.coordinates.distance import JaxPlanck15Interpolator

######## Functions ########
######## Tests ########
def test_distance_interpolator(ngrid=2000):
    """Test the distance interpolation object"""
    # Construct interpolator
    interp = DistanceInterpolator(Planck15,ngrid=ngrid)
    # Print things
    print(f"hubble_time: {interp.hubble_time}")
    print(f"age of universe: {interp.age}")
    print(f"H0: {interp.H0}")
    print(f"dH: {interp.dH}")
    print("Training grid; this may take some time")
    tic = time.perf_counter()
    interp.train()
    toc = time.perf_counter()
    print(f"Training interpolator (with ngrid={ngrid}) took {toc-tic} seconds!")
    # Get grids
    true_redshift = interp.redshift_grid
    true_lookback = interp.lookback_grid
    true_comoving = interp.comoving_grid
    true_luminosity = interp.luminosity_grid
    # Get interpolated values
    interp_lookback = interp.lookback_time(true_redshift)
    interp_comoving = interp.comoving_distance(true_redshift)
    interp_luminosity = interp.luminosity_distance(true_redshift)
    # Estimate error
    dt = np.abs(interp_lookback - true_lookback)
    dl = np.abs(interp_comoving - true_comoving)
    dlum  = np.abs(interp_luminosity - true_luminosity)
    fract = (dt/true_lookback).to("1.").value
    fracl = (dl/true_comoving).to("1.").value
    fraclum = (dlum/true_luminosity).to("1.").value
    print(f"Lookback error on grid (for ngrid={interp.ngrid}): {np.max(dt)}; frac: {np.max(fract)}")
    print(f"Comoving error on grid (for ngrid={interp.ngrid}): {np.max(dl)}; frac: {np.max(fracl)}")
    print(f"Luminosity error on grid (for ngrid={interp.ngrid}): {np.max(dlum)}; frac: {np.max(fraclum)}")

    # Check if its monatonic
    sort_lookback = np.sort(true_lookback)
    sort_comoving = np.sort(true_comoving)
    sort_luminosity = np.sort(true_luminosity)
    if not np.all(sort_lookback == true_lookback):
        print("lookback monatonic failed!")
        print(f"lookback: {true_lookback}")
        print(f"sorted: {sort_lookback}")
        raise RuntimeError("Cosmology has failed us all")
    if not np.all(sort_comoving == true_comoving):
        print("comoving monatonic failed!")
        print(f"comoving: {true_comoving}")
        print(f"sorted: {sort_comoving}")
        raise RuntimeError("Cosmology has failed us all")
    if not np.all(sort_luminosity == true_luminosity):
        print("luminosity monatonic failed!")
        print(f"luminosity: {true_luminosity}")
        print(f"sorted: {sort_luminosity}")
        raise RuntimeError("Cosmology has failed us all")

    # Check inverse
    interp_redshift = interp.inv_lookback_time(true_lookback)
    dz = np.abs(interp_redshift - true_redshift.value)
    fracz = dz/true_redshift.value
    print(f"Inverse lookback error on grid (for ngrid={interp.ngrid}): {np.max(dz)}; frac: {np.max(fracz)}")
    interp_redshift = interp.inv_comoving_distance(true_comoving)
    dz = np.abs(interp_redshift - true_redshift.value)
    fracz = dz/true_redshift.value
    print(f"Inverse comoving error on grid (for ngrid={interp.ngrid}): {np.max(dz)}; frac: {np.max(fracz)}")
    interp_redshift = interp.inv_luminosity_distance(true_luminosity)
    dz = np.abs(interp_redshift - true_redshift.value)
    fracz = dz/true_redshift.value
    print(f"Inverse luminosity error on grid (for ngrid={interp.ngrid}): {np.max(dz)}; frac: {np.max(fracz)}")

    # Draw random samples
    zsample = (np.random.uniform(size=ngrid) * (interp.zmax - interp.zmin)) + interp.zmin
    # Get interpolated values off the grid
    interp_lookback = interp.lookback_time(zsample)
    interp_comoving = interp.comoving_distance(zsample)
    interp_luminosity = interp.luminosity_distance(zsample)
    # Look it up
    true_lookback = Planck15.lookback_time(zsample)
    true_comoving = Planck15.comoving_distance(zsample)
    true_luminosity = Planck15.luminosity_distance(zsample)
    # Estimate error
    dt = np.abs(interp_lookback - true_lookback)
    dl = np.abs(interp_comoving - true_comoving)
    dlum = np.abs(interp_luminosity - true_luminosity)
    fract = (dt/true_lookback).to("1.").value
    fracl = (dl/true_comoving).to("1.").value
    fraclum = (dlum/true_luminosity).to("1.").value
    print(f"Lookback error off grid (for nsample={interp.ngrid}): {np.max(dt)}; frac: {np.max(fract)}")
    print(f"Comoving error off grid (for nsample={interp.ngrid}): {np.max(dl)}; frac: {np.max(fracl)}")
    print(f"Luminosity error off grid (for nsample={interp.ngrid}): {np.max(dlum)}; frac: {np.max(fraclum)}")

    # Check inverse
    interp_redshift = interp.inv_lookback_time(true_lookback)
    dz = np.abs(interp_redshift - zsample)
    fracz = dz/zsample
    print(f"Inverse lookback error off grid (for ngrid={interp.ngrid}): {np.max(dz)}; frac: {np.max(fracz)}")
    interp_redshift = interp.inv_comoving_distance(true_comoving)
    dz = np.abs(interp_redshift - zsample)
    fracz = dz/zsample
    print(f"Inverse comoving error off grid (for ngrid={interp.ngrid}): {np.max(dz)}; frac: {np.max(fracz)}")
    interp_redshift = interp.inv_luminosity_distance(true_luminosity)
    dz = np.abs(interp_redshift - zsample)
    fracz = dz/zsample
    print(f"Inverse luminosity error off grid (for ngrid={interp.ngrid}): {np.max(dz)}; frac: {np.max(fracz)}")



######## Main ########
def main():
    test_distance_interpolator()
    return

######## Execution ########
if __name__ == "__main__":
    main()
