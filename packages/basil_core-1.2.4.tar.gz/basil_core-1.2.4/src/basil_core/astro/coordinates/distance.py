"""Objects for estimating and interpolating from the lookback time and 
    comoving distance for a given cosmology model.

Provide GPU parallelized calculations for common cosmological quantities

"""
######## Imports ########
#### Standard Library ####
import time
from functools import cache
#### Third Party ####
from astropy import units as u
from astropy import constants as const
from astropy.cosmology import z_at_value
from astropy.cosmology import units as cu
from scipy.interpolate import CubicSpline

######## Setup ########
ANDROMEDA_DISTANCE_LY = 2.537 * u.Myr
MINIMUM_LOOKBACK = ANDROMEDA_DISTANCE_LY
MINIMUM_REDSHIFT = 1e-4
MAXIMUM_REDSHIFT = 20.

######## Objects ########

class DistanceInterpolator(object):
    """An interpolator for comoving and light travel distance

    """
    def __init__(
            self,
            cosmo,
            numpy=None,
            zmin=MINIMUM_REDSHIFT,
            zmax=MAXIMUM_REDSHIFT,
            ngrid=int(2e4),
        ):
        """Construct a distance interpolator object

        Parameters
        ----------
        cosmo : astropy.cosmology module
            The module (i.e. Planck15) which defines cosmological methods
        numpy : numpy module
            The Numpy module you would like to use
        """
        self.cosmo = cosmo
        if numpy is None:
            import numpy as np
            self.np = np
        else:
            self.np = numpy
        self._ngrid = ngrid
        self._lookback_interp = None
        self._comoving_interp = None
        self._luminosity_interp = None
        self._inv_lookback_interp = None
        self._inv_comoving_interp = None
        self._inv_luminosity_interp = None
        self.zmin = zmin
        self.zmax = zmax
    
    @property
    def hubble_time(self):
        return self.cosmo.hubble_time.to("Gyr")

    @property
    def age(self):
        return self.cosmo.age(0)

    @property
    def H0(self):
        return self.cosmo.H(0)

    @property
    def dH(self):
        return (const.c / self.H0).si

    @property
    @cache
    def redshift_grid(self):
        # Get age of universe at zmin and zmax
        age_limits = self.cosmo.age(self.np.asarray([self.zmin,self.zmax]))
        # Get lookback limits
        lookback_limits = self.age - age_limits
        # Get lookback_grid
        self._lookback_grid = self.np.linspace(lookback_limits[0], lookback_limits[1], self.ngrid).to("Myr")
        # Get redshift_grid
        return z_at_value(self.cosmo.lookback_time, self.lookback_grid)

    @property
    def lookback_grid(self):
        return self._lookback_grid

    @property
    @cache
    def comoving_grid(self):
        return self.cosmo.comoving_distance(self.redshift_grid).to("kpc")

    @property
    @cache
    def luminosity_grid(self):
        return self.cosmo.luminosity_distance(self.redshift_grid).to("kpc")

    @property
    def ngrid(self):
        return self._ngrid
    
    def train(self):
        """Train the cosmology distance interpolator model"""
        self._lookback_interp = CubicSpline(self.redshift_grid.value, self.lookback_grid.value)
        self._comoving_interp = CubicSpline(self.redshift_grid.value, self.comoving_grid.value)
        self._luminosity_interp = CubicSpline(self.redshift_grid.value, self.luminosity_grid.value)
        self._inv_lookback_interp = CubicSpline(self.lookback_grid.value, self.redshift_grid.value)
        self._inv_comoving_interp = CubicSpline(self.comoving_grid.value, self.redshift_grid.value)
        self._inv_luminosity_interp = CubicSpline(self.luminosity_grid.value, self.redshift_grid.value)

    def comoving_distance(self,z):
        """Return the comoving distance interpolated on some points

        Parameters
        ----------
        z : array_like
            redshift values

        Returns
        -------
        distance : array_like
            comoving_distance
        """
        # Train interpolators
        if self._comoving_interp is None:
            self.train()
        # Initialize output
        out = self.np.zeros(self.np.size(z),dtype=float) * self.comoving_grid.unit
        # Check limits
        in_range = (z >= self.zmin) & (z <= self.zmax)
        # Interpolate
        out[in_range] = self._comoving_interp(z[in_range]) * self.comoving_grid.unit
        # Lower bound can zero out
        out[z < self.zmin] = self.comoving_grid[0]
        # Upper bound can max out
        out[z > self.zmax] = self.comoving_grid[-1]
        return out

    def inv_comoving_distance(self,dc):
        """Return the redshift for a given comoving distance

        Parameters
        ----------
        dc : array_like
            comoving distance

        Returns
        -------
        z : array_like
            Redshift
        """
        # Train interpolators
        if self._inv_comoving_interp is None:
            self.train()
        # Initialize output
        out = self.np.zeros(self.np.size(dc),dtype=float) * cu.redshift
        # Check limits
        in_range = (dc >= self.comoving_grid[0]) & (dc <= self.comoving_grid[-1])
        # Interpolate
        out[in_range] = self._inv_comoving_interp(dc[in_range].to(self.comoving_grid.unit))
        # Handle lower bound
        out[dc < self.comoving_grid[0]] = self.redshift_grid[0]
        # Handle upper bound
        out[dc >= self.comoving_grid[-1]] = self.redshift_grid[-1]
        return out
        
    def luminosity_distance(self,z):
        """Return the luminosity distance interpolated on some points

        Parameters
        ----------
        z : array_like
            redshift values

        Returns
        -------
        distance : array_like
            luminosity_distance
        """
        # Train interpolators
        if self._luminosity_interp is None:
            self.train()
        # Initialize output
        out = self.np.zeros(self.np.size(z),dtype=float) * self.luminosity_grid.unit
        # Check limits
        in_range = (z >= self.zmin) & (z <= self.zmax)
        # Interpolate
        out[in_range] = self._luminosity_interp(z[in_range]) * self.luminosity_grid.unit
        # Lower bound can zero out
        out[z < self.zmin] = self.luminosity_grid[0]
        # Upper bound can max out
        out[z > self.zmax] = self.luminosity_grid[-1]
        return out

    def inv_luminosity_distance(self,dc):
        """Return the redshift for a given luminosity distance

        Parameters
        ----------
        dc : array_like
            luminosity distance

        Returns
        -------
        z : array_like
            Redshift
        """
        # Train interpolators
        if self._inv_luminosity_interp is None:
            self.train()
        # Initialize output
        out = self.np.zeros(self.np.size(dc),dtype=float) * cu.redshift
        # Check limits
        in_range = (dc >= self.luminosity_grid[0]) & (dc <= self.luminosity_grid[-1])
        # Interpolate
        out[in_range] = self._inv_luminosity_interp(dc[in_range].to(self.luminosity_grid.unit))
        # Handle lower bound
        out[dc < self.luminosity_grid[0]] = self.redshift_grid[0]
        # Handle upper bound
        out[dc >= self.luminosity_grid[-1]] = self.redshift_grid[-1]
        return out

    def lookback_time(self,z):
        """Return the lookback time interpolated on some points

        Parameters
        ----------
        z : array_like
            redshift values

        Returns
        -------
        lookback_time : array_like
            light travel time to given redshift
        """
        # Train interpolators
        if self._lookback_interp is None:
            self.train()
        # Initialize output
        out = self.np.zeros(self.np.size(z),dtype=float) * self.lookback_grid.unit
        # Check limits
        in_range = (z >= self.zmin) & (z <= self.zmax)
        # Interpolate
        out[in_range] = self._lookback_interp(z[in_range]) * self.lookback_grid.unit
        # Lower bound can zero out
        out[z < self.zmin] = self.lookback_grid[0]
        # Upper bound can max out
        out[z > self.zmax] = self.lookback_grid[-1]
        return out

    def inv_lookback_time(self,dc):
        """Return the redshift for a given lookback_time

        Parameters
        ----------
        tl : array_like
            lookback_time

        Returns
        -------
        z : array_like
            Redshift
        """
        # Train interpolators
        if self._inv_lookback_interp is None:
            self.train()
        # Initialize output
        out = self.np.zeros(self.np.size(dc),dtype=float) * cu.redshift
        # Check limits
        in_range = (dc >= self.lookback_grid[0]) & (dc <= self.lookback_grid[-1])
        # Interpolate
        out[in_range] = self._inv_lookback_interp(dc[in_range].to(self.lookback_grid.unit))
        # Handle lower bound
        out[dc < self.lookback_grid[0]] = self.redshift_grid[0]
        # Handle upper bound
        out[dc >= self.lookback_grid[-1]] = self.redshift_grid[-1]
        return out

#### Jax version ####
class JaxPlanck15Interpolator(DistanceInterpolator):
    """Use jaxcosmo and Planck15, and train manually"""
    def __init__(**kwargs):
        """Construct Jax Planck15 Interpolator"""
        # Imports and setup
        import jax
        import jax.numpy as np
        from astropy.cosmology import Planck15 as acosmo
        import jax_cosmo as jc
        jcosmo = jc.Planck15()
        # Construct super
        super().__init__(acosmo,numpy=np,**kwargs)
        # Define jcosmo
        self.jcosmo = jcosmo
        self.jc = jc
        raise NotImplementedError("Not tested in its current form.")

    @property
    @cache
    def redshift_grid(self):
        return 10**self.np.linspace(self.np.log10(self.zmin),self.np.log10(self.zmax),self.ngrid)

    def lookback_time_integrand(self,z):
        """The integrand for the lookback time equation

        Parameters
        ----------
        z : array_like
            Redshift array

        Returns
        -------
        Q : jax array
            Array of the lookback time integrand quantity
        """
        return 1./(self.np.sqrt(self.jc.background.Esqr(self.jcosmo,1./(z+1.)))*(1+z))

    def comoving_distance_integrand(self,z):
        """The integrand for the comoving distance equation

        Parameters
        ----------
        z : array_like
            Redshift array

        Returns
        -------
        Q : jax array
            Array of comoving distance integrand quantity
        """
        return 1./self.np.sqrt(self.jc.background.Esqr(self.jcosmo,1./(z+1.)))

    def lookback_time_trapezoid(self,z):
        """The lookback time, according to trapezoid rule
    
        Parameters
        ----------
        z : array_like
            Redshift array
    
        Returns
        -------
        zcenters : array
            redshift bin centers
        dz : array
            redshift bin widths
        cum : array
            cumulative lookback time 
        """
        f_of_z = self.lookback_time_integrand(z)
        dz = z[1:] - z[:-1]
        zcenters = 0.5*(z[:-1] + z[1:])
        trp = dz * (f_of_z[1:] + f_of_z[:-1]) * 0.5
        cum = self.np.cumsum(trp)
        return zcenters, dz, cum

    def comoving_distance_trapezoid(self,z):
        """The comoving distance, according to trapezoid rule
    
        Parameters
        ----------
        z : array_like
            Redshift array
    
        Returns
        -------
        zcenters : array
            redshift bin centers
        dz : array
            redshift bin widths
        cum : array
            cumulative integral of distance
        """
        f_of_z = self.comoving_distance_integrand(z)
        dz = z[1:] - z[:-1]
        zcenters = 0.5*(z[:-1] + z[1:])
        trp = dz * (f_of_z[1:] + f_of_z[:-1]) * 0.5
        cum = self.np.cumsum(trp)
        return zcenters, dz, cum

    @property
    @cache
    def lookback_grid(self):
        # Identify lookback time integral
        zcenters, dz, trp = self.lookback_time_trapezoid(self.redshift_grid)
        # Return values
        return self.age * trp

    @property
    @cache
    def comoving_grid(self):
        # Identify comoving distance trapezoid values
        zcenters, dz, trp = comoving_distance_trapezoid(self.redshift_grid)
        # return values
        return self.dH * trp

    def train(self):
        """Train the cosmology distance interpolator model"""
        def f_lookback(z):
            return self.np.interp(z,self.redshift_grid,self.lookback_grid)
        self._lookback_interp = f_lookback
        def f_comoving(z):
            return self.np.interp(z,self.redshift_grid,self.comoving_grid)
        self._comoving_interp = f_comoving

    def comoving_distance(self,z):
        """Return the comoving distance interpolated on some points

        Parameters
        ----------
        z : array_like
            redshift values

        Returns
        -------
        distance : array_like
            comoving_distance
        """
        # Train interpolators
        if self._comoving_interp is None:
            self.train()
        return self._comoving_interp(z) * self.comoving_grid.unit

    def lookback_time(self,z):
        """Return the lookback time interpolated on some points

        Parameters
        ----------
        z : array_like
            redshift values

        Returns
        -------
        lookback_time : array_like
            light travel time to given redshift
        """
        # Train interpolators
        if self._lookback_interp is None:
            self.train()
        return self._lookback_interp(z) * self.lookback_grid.unit
