from basil_core.astro.relations.AGND.AGND import Ueda_AGND
from basil_core.astro.relations.AGND.AGND import Lyon2024_AGND
