from basil_core.astro.relations.IMF.IMF import Salpeter_IMF
