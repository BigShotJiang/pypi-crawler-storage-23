from __future__ import annotations

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

from mcp_server_propel.tools.review_tools import (
    check_review_status,
    get_review,
    submit_comment_feedback,
    submit_review,
)


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[dict]:
    base_url = os.environ.get("PROPEL_API_URL", "https://api.propelcode.ai")
    yield {"base_url": base_url}


mcp = FastMCP("propel", lifespan=app_lifespan, stateless_http=True)

mcp.tool()(submit_review)
mcp.tool()(get_review)
mcp.tool()(check_review_status)
mcp.tool()(submit_comment_feedback)


@mcp.custom_route("/health", methods=["GET"])
async def health(_: Request) -> JSONResponse:
    return JSONResponse({"status": "ok"})


# ASGI app for HTTP transport (used by uvicorn for hosted deployments)
app = mcp.streamable_http_app()


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
