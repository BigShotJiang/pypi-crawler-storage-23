from .app import create_base_app

__all__ = ["create_base_app"]
