# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Maurice Garcia

from __future__ import annotations

CLEAR_MESSAGE = ""
PRECHECK_FAILURE_MESSAGE = "precheck failed"
MISSING_IP_MESSAGE = "modem ip address missing"
NO_MESSAGE_RESPONSE = "capture returned no message response"
MISSING_TRANSACTION_MESSAGE = "missing transaction_id or filename"

__all__ = [
    "CLEAR_MESSAGE",
    "MISSING_IP_MESSAGE",
    "MISSING_TRANSACTION_MESSAGE",
    "NO_MESSAGE_RESPONSE",
    "PRECHECK_FAILURE_MESSAGE",
]

