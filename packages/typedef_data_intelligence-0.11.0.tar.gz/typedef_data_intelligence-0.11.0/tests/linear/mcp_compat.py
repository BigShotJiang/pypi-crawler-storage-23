"""Compatibility helpers for Linear MCP integration tests."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

ARG_ALIASES: dict[str, tuple[str, ...]] = {
    "id": ("id", "issueId", "identifier"),
    "team": ("team", "teamId"),
    "assignee": ("assignee", "assigneeId"),
    "description": ("description", "body"),
    "state": ("state", "stateName", "status"),
    "labelIds": ("labelIds", "labels"),
}


def resolve_available_tool(available: set[str], *candidates: str) -> str | None:
    """Return the first candidate present in ``available``."""
    for candidate in candidates:
        if candidate in available:
            return candidate
    return None


def filter_args_for_schema(
    args: dict[str, Any], properties: set[str] | None
) -> dict[str, Any]:
    """Map known aliases to keys accepted by a tool schema."""
    if not properties:
        return args

    filtered: dict[str, Any] = {}
    for key, value in args.items():
        if key in properties:
            filtered[key] = value
            continue

        aliases = ARG_ALIASES.get(key)
        if not aliases:
            continue

        mapped_key = next((alias for alias in aliases if alias in properties), None)
        if mapped_key:
            filtered[mapped_key] = value

    return filtered


def extract_tool_properties(tool: Any) -> set[str] | None:
    """Extract JSON schema property names from a FastMCP tool descriptor."""
    schema = getattr(tool, "inputSchema", None) or getattr(tool, "input_schema", None)
    if not isinstance(schema, dict):
        return None

    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return None

    return set(properties)


def tool_name_set(tools: Iterable[Any]) -> set[str]:
    """Return a set of tool names from ``list_tools()`` output."""
    return {tool.name for tool in tools if getattr(tool, "name", None)}


def extract_issue_from_payload(payload: Any) -> dict[str, Any] | None:
    """Return an issue object from varying tool response shapes."""
    if isinstance(payload, dict):
        if isinstance(payload.get("issue"), dict):
            return payload["issue"]
        if isinstance(payload.get("data"), dict) and "id" in payload["data"]:
            return payload["data"]
        if "id" in payload and "title" in payload:
            return payload

    if isinstance(payload, list):
        for item in payload:
            if isinstance(item, dict) and "id" in item:
                return item

    return None
