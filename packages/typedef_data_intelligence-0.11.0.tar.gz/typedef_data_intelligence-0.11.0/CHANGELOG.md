# Changelog

## [0.11.0](https://github.com/typedef-ai/data-intelligence/compare/v0.10.0...v0.11.0) (2026-03-03)


### Features

* **tui:** add `/status` command ([#282](https://github.com/typedef-ai/data-intelligence/issues/282)) ([f5c47ad](https://github.com/typedef-ai/data-intelligence/commit/f5c47ad93486b2f479eaa9abb77f6006c2fc0207))
* **tui:** add slash command autocomplete menu in chat input ([#277](https://github.com/typedef-ai/data-intelligence/issues/277)) ([1f2029c](https://github.com/typedef-ai/data-intelligence/commit/1f2029c42c67ae7b770c7a0403680d2b73392f1f))

## [0.10.0](https://github.com/typedef-ai/data-intelligence/compare/v0.9.0...v0.10.0) (2026-03-02)


### Features

* **agent:** 5-specialist architecture with progressive skill disclosure ([#251](https://github.com/typedef-ai/data-intelligence/issues/251)) ([a12a73e](https://github.com/typedef-ai/data-intelligence/commit/a12a73ecdec51cd00eabd3423274432363636b7a))
* **agent:** Graph-first agent prompts, grain validation, and benchmark tooling ([#266](https://github.com/typedef-ai/data-intelligence/issues/266)) ([fb17aef](https://github.com/typedef-ai/data-intelligence/commit/fb17aefff3312c8f61b1d53a68d073c610e96f28))
* **agent:** robustness improvements + replace custom todo toolset with pydantic-ai-todo ([#257](https://github.com/typedef-ai/data-intelligence/issues/257)) ([017eeba](https://github.com/typedef-ai/data-intelligence/commit/017eebac5452e1301e766ef989f9b9c6a0e08517))
* **benchmark:** agentic judge, rubric templates, results pipeline, and reporter dashboards ([#233](https://github.com/typedef-ai/data-intelligence/issues/233)) ([21de8f3](https://github.com/typedef-ai/data-intelligence/commit/21de8f377de736ce5a31f69fedd0fb1b4c822be4))
* bm workspaces for isolated task generation+validation ([#181](https://github.com/typedef-ai/data-intelligence/issues/181)) ([411e377](https://github.com/typedef-ai/data-intelligence/commit/411e3774ca3d6d388176707833fe468b8f7eec30))
* **data:** add DuckDB backend support with init wizard selector (TD-2187) ([#273](https://github.com/typedef-ai/data-intelligence/issues/273)) ([d741680](https://github.com/typedef-ai/data-intelligence/commit/d741680e6e516d75e64cee0c122a65fa01b8cc41))
* **tui:** minor performance improvements ([#268](https://github.com/typedef-ai/data-intelligence/issues/268)) ([1358244](https://github.com/typedef-ai/data-intelligence/commit/1358244090ffca736db9254a6c7e21e1b287f219))


### Bug Fixes

* **tui:** align wizard palette with app theme ([#275](https://github.com/typedef-ai/data-intelligence/issues/275)) ([fcc6b94](https://github.com/typedef-ai/data-intelligence/commit/fcc6b948cc3cf7d337e830d12f9700edfae6848b))
* **tui:** cleaner approach to clearing the chat box ([#259](https://github.com/typedef-ai/data-intelligence/issues/259)) ([160144d](https://github.com/typedef-ai/data-intelligence/commit/160144d67f0c9704bf7947dc653662645b3bc9d9))

## [0.9.0](https://github.com/typedef-ai/data-intelligence/compare/v0.8.0...v0.9.0) (2026-02-26)


### Features

* **tui:** improve chat focus + busy feedback ([#252](https://github.com/typedef-ai/data-intelligence/issues/252)) ([712a5f1](https://github.com/typedef-ai/data-intelligence/commit/712a5f1e2fd4139ad9c85ec831362b3aa832f105))

## [0.8.0](https://github.com/typedef-ai/data-intelligence/compare/v0.7.0...v0.8.0) (2026-02-25)


### Features

* **agent:** add ProjectOverview graph node and expose as tool (TD-2149) ([#247](https://github.com/typedef-ai/data-intelligence/issues/247)) ([bd4509d](https://github.com/typedef-ai/data-intelligence/commit/bd4509d7390be2b40a96e314c168eded1c3ae672))
* capture additional Salesforce field properties on SfField ([#248](https://github.com/typedef-ai/data-intelligence/issues/248)) ([8659b4b](https://github.com/typedef-ai/data-intelligence/commit/8659b4b2df39a7485b580011e17812fb6fb053b0))
* scope-level column lineage with structural edge tracking (TD-2087, TD-2088) ([#207](https://github.com/typedef-ai/data-intelligence/issues/207)) ([eb02897](https://github.com/typedef-ai/data-intelligence/commit/eb028973121076b9caf5b4b3b15c2f48adf4b4e8))
* **tui:** move artifacts to modal and add compact activity modal ([#250](https://github.com/typedef-ai/data-intelligence/issues/250)) ([e403fa3](https://github.com/typedef-ai/data-intelligence/commit/e403fa3eee083f944e16f30bde4e837b0148ec99))
* **tui:** unify help and shortcuts UX for keyboard-first guidance ([#240](https://github.com/typedef-ai/data-intelligence/issues/240)) ([5c00bf8](https://github.com/typedef-ai/data-intelligence/commit/5c00bf87ef2c81992c3d4c2d3478c7f27707d4fa))
* **tui:** unify shortcuts help and center command palette modal ([#243](https://github.com/typedef-ai/data-intelligence/issues/243)) ([a293811](https://github.com/typedef-ai/data-intelligence/commit/a29381122359c2b2c90816550fdbde940f0bfd8a))


### Bug Fixes

* lineage mcp works with claude code pipeline ([#163](https://github.com/typedef-ai/data-intelligence/issues/163)) ([f5cfdbf](https://github.com/typedef-ai/data-intelligence/commit/f5cfdbf0a64c86eac5a09f72d8631c8966eac899))
* **tui:** prevent collapsible title mount errors in chat tool blocks ([#246](https://github.com/typedef-ai/data-intelligence/issues/246)) ([792bbc4](https://github.com/typedef-ai/data-intelligence/commit/792bbc49778fe9dd2e12df02969289b3a6527298))
* **tui:** refine wizard nav layout and focus visibility ([#237](https://github.com/typedef-ai/data-intelligence/issues/237)) ([fbefbba](https://github.com/typedef-ai/data-intelligence/commit/fbefbba19fc8767e19b0f3ea39dc93e7f0915e04))


### Performance Improvements

* **agent:** Optimize SHOW TERSE semantic commands to avoid account-wide scan (TD-2169) ([#239](https://github.com/typedef-ai/data-intelligence/issues/239)) ([9f95847](https://github.com/typedef-ai/data-intelligence/commit/9f95847810dfedec0213db6ca11c9da10b3cfc18))

## [0.7.0](https://github.com/typedef-ai/data-intelligence/compare/v0.6.0...v0.7.0) (2026-02-20)


### Features

* add generic report schema with cross-platform IR and Salesforce integration ([#168](https://github.com/typedef-ai/data-intelligence/issues/168)) ([a80ec62](https://github.com/typedef-ai/data-intelligence/commit/a80ec62d34797873daaa0230a111fb90d22f2ac6))
* claude code SDK proc agent supported by bedrock ([#219](https://github.com/typedef-ai/data-intelligence/issues/219)) ([b1141fb](https://github.com/typedef-ai/data-intelligence/commit/b1141fba09247b93892f5c6d7a36c3af9bb2a51a))
* create PhysicalTable nodes for dbt sources ([#173](https://github.com/typedef-ai/data-intelligence/issues/173)) ([e2f2973](https://github.com/typedef-ai/data-intelligence/commit/e2f2973284d9c643717ee15198d99e842bce1dae))
* falkor copy and write exclusion ([#218](https://github.com/typedef-ai/data-intelligence/issues/218)) ([007c1ca](https://github.com/typedef-ai/data-intelligence/commit/007c1ca20f486ee4ea7e46b8cbca154d50b55b0f))
* lineage batch updates to falkordb during bulk_load and fingerprint optimization ([#190](https://github.com/typedef-ai/data-intelligence/issues/190)) ([fb04130](https://github.com/typedef-ai/data-intelligence/commit/fb041301c7201969d2c703b470f3164da256c495))
* **tui:** add progressive startup and dependency readiness checks ([#230](https://github.com/typedef-ai/data-intelligence/issues/230)) ([8eef3a5](https://github.com/typedef-ai/data-intelligence/commit/8eef3a573686192846077a8cac3dfd1e705addd2))
* **tui:** copy on highlight ([#226](https://github.com/typedef-ai/data-intelligence/issues/226)) ([e1e5002](https://github.com/typedef-ai/data-intelligence/commit/e1e50029c3b449804ed00aea690c1d96472efc06))
* **tui:** polish startup loading and adaptive status bar hints ([#231](https://github.com/typedef-ai/data-intelligence/issues/231)) ([5379b13](https://github.com/typedef-ai/data-intelligence/commit/5379b131dcb51000be349fc8f35d05c92cbc040e))
* **tui:** unify chat into one screen ([#225](https://github.com/typedef-ai/data-intelligence/issues/225)) ([32c0806](https://github.com/typedef-ai/data-intelligence/commit/32c0806983015cfd0f846fd2aa3f65d1c1744935))


### Bug Fixes

* auto-create DbtColumn nodes from SQL for undocumented models ([#188](https://github.com/typedef-ai/data-intelligence/issues/188)) ([2057129](https://github.com/typedef-ai/data-intelligence/commit/20571299c980a5e1014d88db47446b950698a735))
* linear mcp test should always use DEV team and should clean up issues ([#203](https://github.com/typedef-ai/data-intelligence/issues/203)) ([189a676](https://github.com/typedef-ai/data-intelligence/commit/189a676f0fb769129222fbef4d976846a452498e))
* resolve column lineage for CASE WHEN inside aggregations (TD-2084) ([#195](https://github.com/typedef-ai/data-intelligence/issues/195)) ([4204414](https://github.com/typedef-ai/data-intelligence/commit/4204414470cd6859d79c579bcb9513f655c1d082))
* **tui:** preserve wizard step state when navigating back ([#221](https://github.com/typedef-ai/data-intelligence/issues/221)) ([fd08314](https://github.com/typedef-ai/data-intelligence/commit/fd083143e3ae8134ce191ead04177c5052216582))

## [0.6.0](https://github.com/typedef-ai/data-intelligence/compare/v0.5.0...v0.6.0) (2026-02-12)

### Features

- add uv workspace dependency-groups for unified installs ([#161](https://github.com/typedef-ai/data-intelligence/issues/161)) ([c227af5](https://github.com/typedef-ai/data-intelligence/commit/c227af5324a4043cce57e68d772a2baefc9fdd79))
- **ci:** add tests github actions workflow ([#184](https://github.com/typedef-ai/data-intelligence/issues/184)) ([abd25df](https://github.com/typedef-ai/data-intelligence/commit/abd25dff27bbbd6b9a0bc962865f49cfdde0e59d))
- claude_code skills ([#171](https://github.com/typedef-ai/data-intelligence/issues/171)) ([dfd8513](https://github.com/typedef-ai/data-intelligence/commit/dfd85132507c3512e9450811b366eff36296faea))
- Deep Agent Prototype ([#91](https://github.com/typedef-ai/data-intelligence/issues/91)) ([1f2e229](https://github.com/typedef-ai/data-intelligence/commit/1f2e229272bd8ca2d42b2d2a9f6664b9e0d2f412))
- Enhanced Join Clustering to create Inferred Subject Areas ([#108](https://github.com/typedef-ai/data-intelligence/issues/108)) ([2fb6e68](https://github.com/typedef-ai/data-intelligence/commit/2fb6e68d954bd181d1b9e76b160f924d2abd7a71))
- Salesforce upstream source integration (metadata ingestion + OAuth authentication) ([#136](https://github.com/typedef-ai/data-intelligence/issues/136)) ([b66fd9f](https://github.com/typedef-ai/data-intelligence/commit/b66fd9fcc334a6b65ac2dc04ded0e2f7dc29712f))

### Bug Fixes

- pass sqlglot schema to cache fingerprint computation ([#166](https://github.com/typedef-ai/data-intelligence/issues/166)) ([40ed4ce](https://github.com/typedef-ai/data-intelligence/commit/40ed4cef351b256ee96e2b435054a224702db301))
- pass the proper environment variables when creating the eval workspace, pass --profiles-dir when it is required in the dbt tooling ([#152](https://github.com/typedef-ai/data-intelligence/issues/152)) ([cc67346](https://github.com/typedef-ai/data-intelligence/commit/cc67346ea11b6000bb0cbcacba172aad4655b1ca))
- reserve integration mark for external-service tests and skip by ([c7af0d8](https://github.com/typedef-ai/data-intelligence/commit/c7af0d8e477a5e6d2c31a5b76101723d27971d5a))
- reserve integration mark for external-service tests and skip by default ([#167](https://github.com/typedef-ai/data-intelligence/issues/167)) ([c7af0d8](https://github.com/typedef-ai/data-intelligence/commit/c7af0d8e477a5e6d2c31a5b76101723d27971d5a))
- update stale tests for current Linear MCP and Bedrock APIs ([c7af0d8](https://github.com/typedef-ai/data-intelligence/commit/c7af0d8e477a5e6d2c31a5b76101723d27971d5a))

### Performance Improvements

- benchmark persist base task db ([#162](https://github.com/typedef-ai/data-intelligence/issues/162)) ([2804dc2](https://github.com/typedef-ai/data-intelligence/commit/2804dc2c251d51cb47b22e3fcc845ebda1b8f461))

## [0.5.0](https://github.com/typedef-ai/data-intelligence/compare/v0.4.1...v0.5.0) (2026-01-31)

### Features

- Add dbt test and unit test support to lineage graph ([#132](https://github.com/typedef-ai/data-intelligence/issues/132)) ([6f5513b](https://github.com/typedef-ai/data-intelligence/commit/6f5513bc713bfcae07f0b40ec11210c6583bf5ae))
- create implicit DEPENDS_ON edges, fix PhysicalRelation fqns ([#143](https://github.com/typedef-ai/data-intelligence/issues/143)) ([e47ad23](https://github.com/typedef-ai/data-intelligence/commit/e47ad230e34f04618bb57a6d96b6a27ddafffb1a))
- new demo reset devtool for tui workspace ([#134](https://github.com/typedef-ai/data-intelligence/issues/134)) ([c7fd10d](https://github.com/typedef-ai/data-intelligence/commit/c7fd10dcecce541970708f15cf548c355e376a4a))
- Physically Agnostic Incremental Loading ([#121](https://github.com/typedef-ai/data-intelligence/issues/121)) ([39d16bb](https://github.com/typedef-ai/data-intelligence/commit/39d16bbf034796dc406c9b0035eae00deca36421))
- proper versioning in cli ([#146](https://github.com/typedef-ai/data-intelligence/issues/146)) ([5e7722b](https://github.com/typedef-ai/data-intelligence/commit/5e7722b5f85595d6446b21bc162cc2a409842c7c))

### Bug Fixes

- A few tweaks to benchmark and bedrock agents ([#141](https://github.com/typedef-ai/data-intelligence/issues/141)) ([6e38a03](https://github.com/typedef-ai/data-intelligence/commit/6e38a035b3e8614ab770fd576a5186fcb86f75ca))

## [0.4.1](https://github.com/typedef-ai/data-intelligence/compare/v0.4.0...v0.4.1) (2026-01-27)

### Bug Fixes

- support separate git configurations per project ([#133](https://github.com/typedef-ai/data-intelligence/issues/133)) ([44ac010](https://github.com/typedef-ai/data-intelligence/commit/44ac010c0a7df587f37b44155eae551d92791c26))

## [0.4.0](https://github.com/typedef-ai/data-intelligence/compare/v0.3.1...v0.4.0) (2026-01-27)

### Features

- add placeholder text for the agent screens ([0138828](https://github.com/typedef-ai/data-intelligence/commit/0138828873fb753811735d063b4f5e69fc90071c))
- add placeholder text for the agent screens ([#117](https://github.com/typedef-ai/data-intelligence/issues/117)) ([0138828](https://github.com/typedef-ai/data-intelligence/commit/0138828873fb753811735d063b4f5e69fc90071c))
- Benchmarks perform full and incremental graph builds ([#106](https://github.com/typedef-ai/data-intelligence/issues/106)) ([faa0c24](https://github.com/typedef-ai/data-intelligence/commit/faa0c24483c31bf2e90b463da64095e870337d2c))

### Bug Fixes

- handle new Linear API response format ([#127](https://github.com/typedef-ai/data-intelligence/issues/127)) ([37deb11](https://github.com/typedef-ai/data-intelligence/commit/37deb11059413434648d0d28e9060a0d9134c283))

## [0.3.1](https://github.com/typedef-ai/data-intelligence/compare/v0.3.0...v0.3.1) (2026-01-23)

### Bug Fixes

- local build regression from pypi README requirement ([#109](https://github.com/typedef-ai/data-intelligence/issues/109)) ([bb84348](https://github.com/typedef-ai/data-intelligence/commit/bb843486a3ae78bcdd499463474dcb839e3b1760))

## [0.3.0](https://github.com/typedef-ai/data-intelligence/compare/v0.2.0...v0.3.0) (2026-01-16)

### Features

- Deterministic-LLM Hybrid Analysis of dbt SQL ([#67](https://github.com/typedef-ai/data-intelligence/issues/67)) ([99e0dd6](https://github.com/typedef-ai/data-intelligence/commit/99e0dd6bf2398250385ccdb94405cb227c014e6b))

### Bug Fixes

- ensure that a uv venv exists in the project so we can run dbt cli. also moves profiles out of the project to limit project changes that need to be .gitignored ([#102](https://github.com/typedef-ai/data-intelligence/issues/102)) ([90da937](https://github.com/typedef-ai/data-intelligence/commit/90da937cc266a7394ef93219749fd96b76ccbdb9))
- regression in k8s builds caused by pypi doc req ([#104](https://github.com/typedef-ai/data-intelligence/issues/104)) ([d9b0719](https://github.com/typedef-ai/data-intelligence/commit/d9b0719b3072f4cb61a626cc63dd0ffe7ee723ae))

## [0.2.0](https://github.com/typedef-ai/data-intelligence/compare/v0.1.0...v0.2.0) (2026-01-13)

### Features

- Add Data Engineer tools/prompts to Pydantic CLI Agent, improved stability of logfire ([#32](https://github.com/typedef-ai/data-intelligence/issues/32)) ([08efbb1](https://github.com/typedef-ai/data-intelligence/commit/08efbb1fead1fd7727f641d42c85ec4086e8ca85))
- add rich progress tracking to ingest pipeline ([#47](https://github.com/typedef-ai/data-intelligence/issues/47)) ([91adc20](https://github.com/typedef-ai/data-intelligence/commit/91adc200a4d8f1e71756a31cf7024913545e973f))
- Add smart autoscroll control in TUI and enforce feature branch workflow for DE copilot ([#81](https://github.com/typedef-ai/data-intelligence/issues/81)) ([42e787d](https://github.com/typedef-ai/data-intelligence/commit/42e787db12d90585d9fc85559f4ebf464f76f385))
- Add support for bedrock models ([#58](https://github.com/typedef-ai/data-intelligence/issues/58)) ([7711bcc](https://github.com/typedef-ai/data-intelligence/commit/7711bcc37b33c13e940d275c171c07f63cdf6a62))
- add the daemon ticket based experience to the tui ([#70](https://github.com/typedef-ai/data-intelligence/issues/70)) ([fc87df8](https://github.com/typedef-ai/data-intelligence/commit/fc87df83100ad4f86189c6fc36d4dcb7f212169c))
- add TUI setup wizard with Textual (prototype) ([#49](https://github.com/typedef-ai/data-intelligence/issues/49)) ([6147e8c](https://github.com/typedef-ai/data-intelligence/commit/6147e8c5d5340144719d2e690f4b49a60065eb68))
- adding a webui for data analyst ([#2](https://github.com/typedef-ai/data-intelligence/issues/2)) ([9096a18](https://github.com/typedef-ai/data-intelligence/commit/9096a186c56087c101ec46c1a82ccebd90103593))
- dev docker compose ([#4](https://github.com/typedef-ai/data-intelligence/issues/4)) ([97e1d73](https://github.com/typedef-ai/data-intelligence/commit/97e1d73aa6de637eebe5f245e41ad71ad597ba97))
- falkordb full text search, snowflake db visibility filtering ([#46](https://github.com/typedef-ai/data-intelligence/issues/46)) ([5110928](https://github.com/typedef-ai/data-intelligence/commit/5110928ae576303fbe25456ae718e93d136213f5))
- full clustering implementation ([#10](https://github.com/typedef-ai/data-intelligence/issues/10)) ([71bebad](https://github.com/typedef-ai/data-intelligence/commit/71bebad07d0060dc0a07224472bffd0c0db4db88))
- Improve demo workflow with benchmark branch preservation and session management cleanup ([#64](https://github.com/typedef-ai/data-intelligence/issues/64)) ([df015f8](https://github.com/typedef-ai/data-intelligence/commit/df015f8613d532a14b7eada0b7c7c05c7719edf9))
- Mattermost clones working plus tasks for scenarios ([#43](https://github.com/typedef-ai/data-intelligence/issues/43)) ([fd77b49](https://github.com/typedef-ai/data-intelligence/commit/fd77b49b4ebd5f2905f9c227c0479a20f5c09d98))
- prototype benchmark for data-intelligence ([#26](https://github.com/typedef-ai/data-intelligence/issues/26)) ([de2871a](https://github.com/typedef-ai/data-intelligence/commit/de2871afdd78d586fbcd3da86d82d9bf1522d616))
- separate logical and physical concepts ([#20](https://github.com/typedef-ai/data-intelligence/issues/20)) ([3a9bd05](https://github.com/typedef-ai/data-intelligence/commit/3a9bd05cd6b07328d5098893574a1ab7477a17ef))

### Bug Fixes

- **backend/docker:** misc path/entrypoint fixes to get it running ([#22](https://github.com/typedef-ai/data-intelligence/issues/22)) ([aa47c3f](https://github.com/typedef-ai/data-intelligence/commit/aa47c3fba30895bde9f107d3f9bea4014fb2a8b1))
- daemon only grabs labeled tickets ([#18](https://github.com/typedef-ai/data-intelligence/issues/18)) ([748f6c3](https://github.com/typedef-ai/data-intelligence/commit/748f6c332cb5fac490f4c6645a2bdab7d4749e07))
- if the dbt project gets cloned with git, enable git in the config ([#73](https://github.com/typedef-ai/data-intelligence/issues/73)) ([6e99162](https://github.com/typedef-ai/data-intelligence/commit/6e9916232ab569c4385cbf54d6651c1312517c92))
- limit the daemon to only process tickets assigned to data-engineer-agent ([#74](https://github.com/typedef-ai/data-intelligence/issues/74)) ([ac94267](https://github.com/typedef-ai/data-intelligence/commit/ac94267c4965b040977cdf3933f39ace67cd06e1))
- minor fixes to get medallion + frontend to work ([#59](https://github.com/typedef-ai/data-intelligence/issues/59)) ([1444285](https://github.com/typedef-ai/data-intelligence/commit/1444285ba030a4a2f242a4494e102f106d81d868))
- readme ([#1](https://github.com/typedef-ai/data-intelligence/issues/1)) ([172767a](https://github.com/typedef-ai/data-intelligence/commit/172767a78d33c963e5a09685b34f5016bd7a9714))
