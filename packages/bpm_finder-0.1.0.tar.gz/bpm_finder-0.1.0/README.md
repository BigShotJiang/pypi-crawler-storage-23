# BPM Finder

BPM Finder is a lightweight Python package for tap tempo, BPM conversion, and practical tempo workflow helpers. For browser-based audio BPM detection, visit https://bpm-finder.net/

## What It Does

This package gives you a compact set of utilities for common tempo-related tasks in scripts, internal tools, and automation workflows:

- Estimate BPM from tap timestamps or intervals
- Convert BPM to note length in milliseconds
- Normalize half-time and double-time values into a practical range
- Classify tempo into simple buckets for UI or workflow logic

The package is dependency-free and designed for straightforward command-line and library usage.

## Installation

```bash
pip install bpm-finder
```

## CLI Usage

### Estimate BPM from tap intervals

```bash
bpm-finder tap --intervals 500,500,498,502
```

### Convert BPM to milliseconds

Use `--division 4` for quarter notes, `8` for eighth notes, and `1` for whole notes.

```bash
bpm-finder bpm-to-ms --bpm 128 --division 4
```

### Convert milliseconds back to BPM

```bash
bpm-finder ms-to-bpm --ms 468.75 --division 4
```

### Normalize BPM into a practical range

```bash
bpm-finder normalize --bpm 64
```

### Get a simple tempo bucket

```bash
bpm-finder bucket --bpm 174
```

## Library Usage

```python
from bpm_finder import (
    bpm_to_ms,
    estimate_bpm_from_taps,
    is_bpm_in_range,
    ms_to_bpm,
    normalize_bpm,
    tempo_bucket,
)

tap_bpm = estimate_bpm_from_taps([0, 500, 1000, 1500, 2000])
quarter_note_ms = bpm_to_ms(128, note_division=4)
detected_bpm = ms_to_bpm(468.75, note_division=4)
normalized = normalize_bpm(64)
bucket = tempo_bucket(174)
in_range = is_bpm_in_range(128, 90, 180)
```

### Public API

- `bpm_to_ms(bpm: float, note_division: int = 1) -> float`
- `ms_to_bpm(milliseconds: float, note_division: int = 1) -> float`
- `normalize_bpm(bpm: float, min_bpm: float = 70, max_bpm: float = 180) -> float`
- `estimate_bpm_from_taps(timestamps: list[float], strategy: str = "median") -> float`
- `tempo_bucket(bpm: float) -> str`
- `is_bpm_in_range(bpm: float, low: float, high: float) -> bool`

## Use Cases

- Build tap tempo shortcuts into DJ prep scripts
- Convert BPM to delay times in music production utilities
- Normalize BPM data from mixed sources before sorting playlists
- Add quick tempo helpers to internal music or workout tools
- Attach tempo buckets to rows in analytics or recommendation workflows

## Why BPM Finder Online

This package is ideal for Python scripts, automation, and developer workflows. If you need browser-based audio BPM detection with a user-friendly interface, use BPM Finder Online at https://bpm-finder.net/

## License

MIT

