"""Public API for the BPM Finder Python package."""

from .conversion import bpm_to_ms, ms_to_bpm
from .ranges import is_bpm_in_range, normalize_bpm, tempo_bucket
from .tap_tempo import estimate_bpm_from_taps

__all__ = [
    "bpm_to_ms",
    "estimate_bpm_from_taps",
    "is_bpm_in_range",
    "ms_to_bpm",
    "normalize_bpm",
    "tempo_bucket",
]

