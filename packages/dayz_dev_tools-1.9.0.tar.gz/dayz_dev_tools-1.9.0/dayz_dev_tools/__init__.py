from importlib import metadata


version = metadata.version('dayz-dev-tools')
