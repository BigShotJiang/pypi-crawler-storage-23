"""
Command Handler — Dispatches all slash commands (/help, /status, /config, etc.).
Extracted from the monolithic AgentManager for clean separation of concerns.
"""
import os
import re
import json
from .utils.style import SlokiStyle


class CommandHandler:
    """Handles all interactive slash commands in the Sloki CLI."""

    def __init__(self, config_manager, llm_client, rule_engine, memory_manager, brain_dir):
        self.config = config_manager
        self.llm_client = llm_client
        self.rule_engine = rule_engine
        self.memory_manager = memory_manager
        self.brain_dir = brain_dir
        self.master_agent = None  # Linked via AgentManager

        # Agent persona registry
        self.agent_registry = {}
        self.active_agent_name = "assistant"
        self._load_agents()

        # Diff tracking
        self.last_diff = ""
        self.diff_path = os.path.join(self.brain_dir, "last_diff.patch")
        if os.path.exists(self.diff_path):
            try:
                with open(self.diff_path, 'r', encoding='utf-8') as f:
                    self.last_diff = f.read()
            except Exception:
                self.last_diff = ""

    # ──────────────────────────────────────────────
    #  AGENT PERSONA MANAGEMENT
    # ──────────────────────────────────────────────

    def _load_agents(self):
        registry_path = os.path.join(self.brain_dir, "agents_registry.json")
        if os.path.exists(registry_path):
            try:
                with open(registry_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.agent_registry = data.get("agents", {})
                    self.active_agent_name = data.get("active_agent", "assistant")
            except Exception:
                self.agent_registry = {}

    def _save_agents(self):
        registry_path = os.path.join(self.brain_dir, "agents_registry.json")
        try:
            with open(registry_path, 'w', encoding='utf-8') as f:
                json.dump({
                    "agents": self.agent_registry,
                    "active_agent": self.active_agent_name
                }, f, indent=4)
        except Exception:
            pass

    def register_master_agent(self, master_agent):
        """Link the MasterAgent to allow listing of specialized domains."""
        self.master_agent = master_agent

    # ──────────────────────────────────────────────
    #  COMMAND DISPATCH
    # ──────────────────────────────────────────────

    def try_handle(self, user_input, auto_mode=False):
        """
        Attempt to handle user_input as a slash command.
        Returns (handled: bool, success: bool, result: str).
        If handled is False, the input should be passed to the pipeline.
        """
        parts = user_input.split()
        if not parts:
            return True, False, "Empty command"

        cmd = parts[0].lower()

        handlers = {
            "/status":  lambda: self._show_status(),
            "/help":    lambda: self._show_help(),
            "/config":  lambda: self._run_config_wizard(auto_mode),
            "/diff":    lambda: self._show_last_diff(),
            "/memory":  lambda: self._show_memory(),
            "/wipe":    lambda: self._clear_session(),
            "/reset":   lambda: self._full_reset(),
            "/agent":   lambda: self._handle_agent_command(parts),
            "/guide":   lambda: self._show_guide(),
        }

        if cmd in ["/exit", "exit", "quit"]:
            return True, True, "EXIT_SIGNAL"

        if cmd in ["/cls", "/clear"]:
            os.system('cls' if os.name == 'nt' else 'clear')
            SlokiStyle.banner()
            return True, True, "Screen cleared"

        if cmd in handlers:
            result = handlers[cmd]()
            return True, True, result or "Done"

        if cmd in ["/rules"]:
            return True, True, self._handle_rules(parts)

        if cmd in ['/model', '/switch', '/provider']:
            return True, True, self._handle_model_switch()

        if cmd in ['/analyze', '/analyse']:
            return True, True, self._run_analysis()

        # Not a slash command → delegate to pipeline
        return False, False, ""

    # ──────────────────────────────────────────────
    #  STATUS & HELP
    # ──────────────────────────────────────────────

    def _show_status(self):
        prov = self.llm_client.preferred_provider.upper()
        model = (self.llm_client.lmstudio_model if prov == "LMSTUDIO"
                 else self.llm_client.preferred_model or "Standard")

        SlokiStyle.grid({
            "Project Root": self.config.project_root,
            "Editable Files": f"{len(self.config.editable_files)} configured",
            "Protected Files": f"{len(self.config.protected_files)} for context",
            "LLM Provider": prov,
            "Active Model": model,
            "Brain Dir": os.path.basename(self.brain_dir)
        }, title="SESSION STATUS")
        return "Status displayed"

    def _show_help(self):
        SlokiStyle.header("SLOKI AGENT HELP")

        SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[ CORE COMMANDS ]{SlokiStyle.RESET}")
        commands = {
            "/status":  "Display current session configuration",
            "/config":  "Interactively modify project discovery settings",
            "/model":   "Switch LLM provider or change LM Studio models",
            "/load":    "Select an .md file for new requirements",
            "/rules":   "Manage guardrails (e.g. /rules list|add|delete)",
            "/diff":    "Recall and review the last generated code changes",
            "/global":  "Apply a prompt across ALL editable files",
            "/wipe":    "Reset SESSION (wipe artifacts/logs, keep brain)",
            "/cls":     "Clear terminal screen (also /clear)",
            "/reset":   "FULL RESET (wipe everything including brain/style)",
            "/memory":  "View persistent session style and history",
            "/analyze": "Explicitly re-scan the project structure",
            "/agent":   "Manage AI agent personas (list|create|switch|delete)",
            "/guide":   "Show the comprehensive setup guide for LM Studio and APIs",
            "/exit":    "Terminate the current session",
        }
        for cmd, desc in commands.items():
            SlokiStyle.label(cmd, desc)

        print()
        SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[ ACTION COMMANDS ]{SlokiStyle.RESET}")
        SlokiStyle.label("Natural Language", "Simply type what you want (e.g., 'add a video task')")
        SlokiStyle.label("Feedback", "If Sloki fails, provide feedback to re-plan or re-code")
        print(f"\n{SlokiStyle.CYAN}{'━' * 60}{SlokiStyle.RESET}")
        return "Help displayed"

    def _show_guide(self):
        """Displays a comprehensive setup guide for the Sloki Agent."""
        SlokiStyle.header("SLOKI AGENT SETUP GUIDE")
        
        guide_text = f"""
{SlokiStyle.BOLD}{SlokiStyle.BLUE}1. LLM PROVIDERS & API KEYS{SlokiStyle.RESET}
Sloki supports multiple AI providers. You can configure them via {SlokiStyle.CYAN}/config{SlokiStyle.RESET} 
or by manually editing the {SlokiStyle.CYAN}~/.sloki/.env{SlokiStyle.RESET} file.

  • {SlokiStyle.GOLD}Gemini:{SlokiStyle.RESET} Get an API key from Google AI Studio. 
    Variable: GEMINI_API_KEY
  • {SlokiStyle.GOLD}Anthropic:{SlokiStyle.RESET} Get an API key from the Anthropic Console. 
    Variable: ANTHROPIC_API_KEY
  • {SlokiStyle.GOLD}OpenAI:{SlokiStyle.RESET} Get an API key from the OpenAI Platform. 
    Variable: OPENAI_API_KEY

{SlokiStyle.BOLD}{SlokiStyle.BLUE}2. LM STUDIO SETUP (LOCAL AI){SlokiStyle.RESET}
To run Sloki entirely locally (100% privacy, no API costs):

  {SlokiStyle.BOLD}Step A:{SlokiStyle.RESET} Download and install LM Studio from https://lmstudio.ai/
  {SlokiStyle.BOLD}Step B:{SlokiStyle.RESET} Download a "Coder" model (e.g., Qwen-2.5-Coder-7b-Instruct GGUF).
  {SlokiStyle.BOLD}Step C:{SlokiStyle.RESET} Go to the Local Server tab icon in LM Studio.
  {SlokiStyle.BOLD}Step D:{SlokiStyle.RESET} Enable "CORS" and make sure the server runs on port 1234.
  {SlokiStyle.BOLD}Step E:{SlokiStyle.RESET} Click "Start Server".
  
  In Sloki, run {SlokiStyle.CYAN}/config{SlokiStyle.RESET} and select 'lmstudio' as your provider.

{SlokiStyle.BOLD}{SlokiStyle.BLUE}3. AUTONOMOUS MODE{SlokiStyle.RESET}
If you want Sloki to edit files without asking for "y/n" confirmation:
  • Run {SlokiStyle.CYAN}/config{SlokiStyle.RESET} and follow the prompts to enable Autonomous Mode.
  • Or start the agent with: {SlokiStyle.CYAN}python main.py --auto{SlokiStyle.RESET}
  {SlokiStyle.RED}*Warning: Sloki can delete or break files in this mode!{SlokiStyle.RESET}

{SlokiStyle.BOLD}{SlokiStyle.BLUE}4. MANAGING MULTI-AGENTS{SlokiStyle.RESET}
Sloki uses specialized "Mini-Agents" for different tasks:
  • {SlokiStyle.CYAN}/agent list{SlokiStyle.RESET}   → View all available task specialists.
  • {SlokiStyle.CYAN}/agent create{SlokiStyle.RESET} → Create a new specialist (e.g., database_expert).
  • {SlokiStyle.CYAN}/agent switch{SlokiStyle.RESET} → Force Sloki into a specific domain.

{SlokiStyle.BOLD}{SlokiStyle.BLUE}5. WORKFLOW & RULES{SlokiStyle.RESET}
  • {SlokiStyle.CYAN}/rules{SlokiStyle.RESET} → View and manage security guardrails.
  • Guardrails block dangerous actions like deleting protected files.
  • Use {SlokiStyle.CYAN}/load{SlokiStyle.RESET} to import large Markdown requirement documents.
"""
        print(guide_text)
        print(f"{SlokiStyle.CYAN}{'━' * 60}{SlokiStyle.RESET}")
        return "Setup guide displayed"

    # ──────────────────────────────────────────────
    #  DIFF
    # ──────────────────────────────────────────────

    def _show_last_diff(self):
        if not self.last_diff:
            SlokiStyle.safe_print(
                f"{SlokiStyle.GOLD}[System] No recent code changes to display.{SlokiStyle.RESET}"
            )
            return "No diff"

        SlokiStyle.header("LAST GENERATED CODE CHANGES")
        for line in self.last_diff.splitlines():
            if line.startswith('+'):
                print(f"{SlokiStyle.GREEN}{line}{SlokiStyle.RESET}")
            elif line.startswith('-'):
                print(f"{SlokiStyle.RED}{line}{SlokiStyle.RESET}")
            else:
                print(line)
        return "Diff displayed"

    # ──────────────────────────────────────────────
    #  MEMORY
    # ──────────────────────────────────────────────

    def _show_memory(self):
        SlokiStyle.header("PERSISTENT SESSION DASHBOARD")
        mem = self.memory_manager.get_memory_data()

        SlokiStyle.grid({
            "Interactions": len(mem["chat_history"]),
            "Operations": len(mem.get("project_operations", [])),
            "Preferences": len(mem["preferences"]),
            "Last Seen": mem["last_interaction"].split('T')[0] if mem["last_interaction"] else "N/A"
        }, title="SESSION OVERVIEW")

        # 1. Project Operations (Timeline)
        ops = mem.get("project_operations", [])
        if ops:
            print(f"\n{SlokiStyle.GOLD}[ PROJECT OPERATIONS LOG ]{SlokiStyle.RESET}")
            for op in reversed(ops[-8:]):  # Show last 8
                SlokiStyle.safe_print(f" {SlokiStyle.CYAN}•{SlokiStyle.RESET} {op}")

        # 2. Preferences
        if mem["preferences"]:
            print(f"\n{SlokiStyle.GOLD}[ ACTIVE PREFERENCES ]{SlokiStyle.RESET}")
            for k, v in mem["preferences"].items():
                SlokiStyle.label(k.replace('_', ' ').title(), str(v), color=SlokiStyle.CYAN)

        # 3. Chat History
        history = self.memory_manager.get_filtered_history(limit=5)
        if history:
            print(f"\n{SlokiStyle.GOLD}[ SIGNIFICANT INTERACTIONS ]{SlokiStyle.RESET}")
            for chat in history:
                role = "User" if chat["role"] == "user" else "Sloki"
                color = SlokiStyle.BLUE if chat["role"] == "user" else SlokiStyle.GREEN
                content = chat["content"].strip()
                preview = content.split('\n')[0]
                if len(content) > 100:
                    preview = preview[:97] + "..."
                print(f" {SlokiStyle.BOLD}{color}{role.ljust(6)}{SlokiStyle.RESET} | {preview}")

        # 4. Supplemental Style Context (Only if exists)
        if mem["style_notes"]:
            print(f"\n{SlokiStyle.DIM}[ STYLE & CONTEXT SUPPLEMENTS ]{SlokiStyle.RESET}")
            for note in mem["style_notes"]:
                SlokiStyle.safe_print(f" {SlokiStyle.DIM}• {note}{SlokiStyle.RESET}")

        print(f"\n{SlokiStyle.CYAN}{'━' * 60}{SlokiStyle.RESET}")
        return "Memory displayed"

    # ──────────────────────────────────────────────
    #  SESSION MANAGEMENT
    # ──────────────────────────────────────────────

    def _clear_session(self):
        SlokiStyle.header("CLEARING CURRENT SESSION")
        for f in ["task.md", "implementation_plan.md", "walkthrough.md"]:
            path = os.path.join(self.brain_dir, f)
            if os.path.exists(path):
                os.remove(path)

        self.config.clear()
        self.last_diff = ""
        self.memory_manager.clear_history()
        SlokiStyle.safe_print(
            f"{SlokiStyle.GREEN}[System] Session cleared (history & artifacts). "
            f"Preferences preserved.{SlokiStyle.RESET}"
        )
        return "Session cleared"

    def _full_reset(self):
        SlokiStyle.header("NUCLEAR RESET: WIPING ALL BRAIN DATA")
        SlokiStyle.safe_print(
            f"{SlokiStyle.RED}WARNING: This will delete ALL session history, "
            f"style preferences, and project configs.{SlokiStyle.RESET}"
        )
        print(f"{SlokiStyle.BOLD}Are you absolutely sure? (y/n):{SlokiStyle.RESET} ", end="")
        if input().strip().lower() != 'y':
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] Reset cancelled.{SlokiStyle.RESET}")
            return "Reset cancelled"

        for f in ["task.md", "implementation_plan.md", "walkthrough.md", "project_config.md"]:
            path = os.path.join(self.brain_dir, f)
            if os.path.exists(path):
                os.remove(path)

        self.memory_manager.wipe_all()
        self.config.clear()
        self.last_diff = ""
        SlokiStyle.safe_print(
            f"\n{SlokiStyle.GREEN}[System] Full brain reset complete. Sloki is now fresh.{SlokiStyle.RESET}"
        )
        return "Full reset complete"

    # ──────────────────────────────────────────────
    #  RULES
    # ──────────────────────────────────────────────

    def _handle_rules(self, parts):
        subcmd = parts[1] if len(parts) > 1 else "usage"

        if subcmd == "list":
            SlokiStyle.header("ACTIVE GUARDRAILS (rules.json)")
            try:
                with open(self.rule_engine.rules_path, 'r', encoding='utf-8') as f:
                    rules = json.load(f)
                for category, data in rules.items():
                    SlokiStyle.safe_print(f"\n{SlokiStyle.GOLD}[ {category.upper()} ]{SlokiStyle.RESET}")
                    if isinstance(data, list):
                        for rule in data:
                            SlokiStyle.safe_print(f" • {rule}")
                    elif isinstance(data, dict):
                        for k, v in data.items():
                            SlokiStyle.safe_print(f" • {SlokiStyle.CYAN}{k}{SlokiStyle.RESET}: {v}")
            except Exception as e:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}Error reading rules: {e}{SlokiStyle.RESET}")
            return "Rules displayed"

        if subcmd == "add" and len(parts) >= 4:
            cat, val = parts[2], " ".join(parts[3:])
            success, msg = self.rule_engine.add_rule(cat, val)
            if success:
                self.rule_engine.save_rules()
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
            else:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] {msg}{SlokiStyle.RESET}")
            return msg

        if subcmd == "delete" and len(parts) >= 4:
            cat, val = parts[2], " ".join(parts[3:])
            success, msg = self.rule_engine.delete_rule(cat, val)
            if success:
                self.rule_engine.save_rules()
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
            else:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] {msg}{SlokiStyle.RESET}")
            return msg

        if subcmd == "sync" and len(parts) >= 3:
            md_path = " ".join(parts[2:])
            success, msg = self.rule_engine.sync_from_markdown(md_path)
            if success:
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
            else:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] {msg}{SlokiStyle.RESET}")
            return msg

        SlokiStyle.header("RULES SYSTEM USAGE")
        SlokiStyle.safe_print(f"{SlokiStyle.BOLD}Commands:{SlokiStyle.RESET}")
        SlokiStyle.safe_print("  /rules list             Show all active guardrails")
        SlokiStyle.safe_print("  /rules add <cat> <val>  Add a rule to a category (e.g. protected_files)")
        SlokiStyle.safe_print("  /rules delete <cat> <val> Remove a rule from a category")
        SlokiStyle.safe_print("  /rules sync <file.md>   Update rules from a Markdown file")
        
        SlokiStyle.safe_print(f"\n{SlokiStyle.BOLD}Example:{SlokiStyle.RESET}")
        SlokiStyle.safe_print("  /rules add protected_files include/config.h")
        SlokiStyle.safe_print("  /rules sync my_guardrails.md")
        return "Rules usage help displayed"

    # ──────────────────────────────────────────────
    #  MODEL / PROVIDER SWITCHING
    # ──────────────────────────────────────────────

    def _handle_model_switch(self):
        SlokiStyle.header("LLM PROVIDER SWITCHER")
        providers = ["gemini", "openai", "anthropic", "lmstudio"]
        for i, p in enumerate(providers):
            print(f"[{SlokiStyle.CYAN}{i}{SlokiStyle.RESET}] {p}")

        print(f"\n{SlokiStyle.BOLD}Select New Provider:{SlokiStyle.RESET} ", end="")
        try:
            p_idx = input().strip()
            if not p_idx.isdigit() or int(p_idx) >= len(providers):
                SlokiStyle.safe_print(f"{SlokiStyle.RED}Invalid index.{SlokiStyle.RESET}")
                return "Model switch cancelled"

            new_provider = providers[int(p_idx)]
            self.llm_client.preferred_provider = new_provider
            new_model = "N/A"
            self.llm_client.preferred_model = None

            if new_provider == "lmstudio":
                SlokiStyle.safe_print(f"\n{SlokiStyle.BLUE}Select LM Studio Model:{SlokiStyle.RESET}")
                available = self.llm_client.list_lmstudio_models()
                models = available + ["custom"]
                for j, m in enumerate(models):
                    print(f"[{SlokiStyle.CYAN}{j}{SlokiStyle.RESET}] {m}")
                print(f"{SlokiStyle.BOLD}Index:{SlokiStyle.RESET} ", end="")
                try:
                    m_idx = input().strip()
                except (KeyboardInterrupt, EOFError):
                    return "Operation cancelled"

                if m_idx.isdigit() and int(m_idx) < len(models):
                    if models[int(m_idx)] == "custom":
                        print(f"{SlokiStyle.BOLD}Enter Model Name:{SlokiStyle.RESET} ", end="")
                        try:
                            new_model = input().strip()
                        except (KeyboardInterrupt, EOFError):
                            return "Operation cancelled"
                    else:
                        new_model = models[int(m_idx)]
                    self.llm_client.lmstudio_model = new_model
                    self.llm_client.preferred_model = new_model

            # Persist to config file
            config_path = os.path.join(self.brain_dir, "project_config.md")
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                content = re.sub(r'\*\*Preferred Provider\*\*:\s*.*',
                                 f'**Preferred Provider**: {new_provider}', content)
                content = re.sub(r'\*\*Preferred Model\*\*:\s*.*',
                                 f'**Preferred Model**: {new_model}', content)
                with open(config_path, 'w', encoding='utf-8') as f:
                    f.write(content)

            SlokiStyle.safe_print(
                f"{SlokiStyle.GREEN}[System] Switched to {new_provider.upper()}{SlokiStyle.RESET}"
            )
            return f"Switched to {new_provider}"

        except Exception as e:
            SlokiStyle.safe_print(f"{SlokiStyle.RED}Switch failed: {e}{SlokiStyle.RESET}")
            return "Model switch failed"

    # ──────────────────────────────────────────────
    #  CONFIG WIZARD
    # ──────────────────────────────────────────────

    def _run_config_wizard(self, auto_mode=False):
        SlokiStyle.header("SLOKI CONFIGURATION WIZARD")

        SlokiStyle.safe_print(f"{SlokiStyle.BOLD}Current Root:{SlokiStyle.RESET} {self.config.project_root}")
        if not auto_mode:
            print(f"{SlokiStyle.CYAN}Change Root? (Leave empty to keep):{SlokiStyle.RESET} ", end="")
            new_root = input().strip()
            if new_root and os.path.exists(new_root):
                self.config.project_root = new_root

        SlokiStyle.header("PHASE: AI ROLE DISCOVERY")
        SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Analyzing project structure...")
        editable_rel, protected_rel, files = self.config.analyze_project(self.config.project_root)

        SlokiStyle.grid({
            "Editable Suggestion": ", ".join(editable_rel) or "None",
            "Protected Suggestion": f"{len(protected_rel)} files"
        }, title="AI SUGGESTIONS")

        if auto_mode:
            self.config.apply_roles(editable_rel, protected_rel)
            SlokiStyle.safe_print(
                f"{SlokiStyle.GREEN}[System] Auto-accepted AI suggestions.{SlokiStyle.RESET}"
            )
            return "Config updated"

        print(f"\n{SlokiStyle.BOLD}Accept? ([y] Accept, [m] Manual, [n] Cancel):{SlokiStyle.RESET} ", end="")
        choice = input().strip().lower()

        if choice == 'y':
            self.config.apply_roles(editable_rel, protected_rel)
            SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] Configuration updated.{SlokiStyle.RESET}")
        elif choice == 'n':
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] Configuration unchanged.{SlokiStyle.RESET}")
        else:
            self._manual_override(editable_rel)

        print(f"\n{SlokiStyle.BOLD}Enable Autonomous Mode (Bypass y/n prompts)? (y/n):{SlokiStyle.RESET} ", end="")
        auto_choice = input().strip().lower()
        if auto_choice == 'y':
            SlokiStyle.safe_print(
                f"\n{SlokiStyle.RED}{SlokiStyle.BOLD}[WARNING] You are enabling Autonomous Mode.\n"
                f"The agent will automatically apply code edits and physical file changes without asking for confirmation.\n"
                f"The agent and its creators are NOT responsible for any destructive mistakes or broken code.\n"
                f"Are you ABSOLUTELY sure? (type 'yes' to confirm):{SlokiStyle.RESET} "
            )
            confirm = input().strip().lower()
            if confirm == 'yes':
                self.config.auto_mode = True
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] Autonomous Mode ENABLED.{SlokiStyle.RESET}")
            else:
                self.config.auto_mode = False
                SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] Autonomous Mode DISABLED.{SlokiStyle.RESET}")
        else:
            self.config.auto_mode = False
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] Autonomous Mode DISABLED.{SlokiStyle.RESET}")

        SlokiStyle.header("PHASE: API CONFIGURATION")
        print(f"{SlokiStyle.BOLD}Configure API Keys? ([y] Yes, [n] Skip):{SlokiStyle.RESET} ", end="")
        api_choice = input().strip().lower()
        if api_choice == 'y':
            keys_to_config = ["GEMINI_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY"]
            updates = {}
            for key in keys_to_config:
                current_val = os.environ.get(key, "")
                masked = f"{current_val[:6]}...{current_val[-4:]}" if len(current_val) > 10 else "Not Set"
                print(f"\n{SlokiStyle.CYAN}{key}{SlokiStyle.RESET} (Current: {masked})")
                print(f"Enter new key (Leave empty to keep current): ", end="")
                new_key = input().strip()
                if new_key:
                    updates[key] = new_key
            
            if updates:
                self._update_env_file(updates)
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] API Keys updated successfully.{SlokiStyle.RESET}")
            else:
                SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] No API Keys were changed.{SlokiStyle.RESET}")
        else:
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] API Configuration skipped.{SlokiStyle.RESET}")
            
        self.config.save_config()

        return "Configuration updated"

    def _update_env_file(self, updates):
        """Safely update or append keys in the .env file without destroying other vars."""
        env_path = os.path.join(os.path.expanduser("~"), ".sloki", ".env")
        os.makedirs(os.path.dirname(env_path), exist_ok=True)
        
        lines = []
        if os.path.exists(env_path):
            with open(env_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

        new_lines = []
        updated_keys = set()

        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                new_lines.append(line)
                continue

            parts = stripped.split('=', 1)
            if len(parts) == 2:
                key, _ = parts
                key = key.strip()
                if key in updates:
                    new_lines.append(f"{key}={updates[key]}\n")
                    updated_keys.add(key)
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)

        # Append new keys that weren't in the file
        for key, val in updates.items():
            if key not in updated_keys:
                # Ensure trailing newline if file didn't have one
                if new_lines and not new_lines[-1].endswith('\n'):
                    new_lines[-1] += '\n'
                new_lines.append(f"{key}={val}\n")

        with open(env_path, 'w', encoding='utf-8') as f:
            f.writelines(new_lines)
            
        # Also update current process environment
        for key, val in updates.items():
            os.environ[key] = val

    def _manual_override(self, editable_rel):
        SlokiStyle.header("MANUAL ROLE OVERRIDE")
        extensions = ('.c', '.h', '.cpp', '.hpp', '.py', '.js', '.ts', '.rs', '.go', '.java', '.cs', '.sh', '.md')
        all_files = []
        for root, _, filenames in os.walk(self.config.project_root):
            for f in filenames:
                if f.endswith(extensions):
                    all_files.append(os.path.relpath(os.path.join(root, f), self.config.project_root))

        print(f"{SlokiStyle.DIM}Toggle file status: [E] Editable, [P] Protected{SlokiStyle.RESET}")
        new_editable, new_protected = [], []

        for f in all_files:
            current_status = "E" if f in editable_rel else "P"
            print(f"[{SlokiStyle.CYAN}{current_status}{SlokiStyle.RESET}] {f} -> Change? (e/p/skip): ", end="")
            m_choice = input().strip().lower()
            final = m_choice if m_choice in ['e', 'p'] else current_status.lower()
            target = os.path.join(self.config.project_root, f)
            (new_editable if final == 'e' else new_protected).append(target)

        self.config.editable_files = new_editable
        self.config.protected_files = new_protected
        if self.config.editable_files:
            from sloki_agent.code_editor.block_parser import BlockParser
            self.config.block_parser = BlockParser(self.config.editable_files[0])
        self.config.save_config()
        SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] Project configuration updated manually.{SlokiStyle.RESET}")

    # ──────────────────────────────────────────────
    #  ANALYSIS
    # ──────────────────────────────────────────────

    def _run_analysis(self):
        SlokiStyle.header("PROJECT DEEP ANALYSIS")
        SlokiStyle.safe_print(
            f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Re-scanning: {self.config.project_root}..."
        )
        editable_rel, protected_rel, files = self.config.analyze_project(self.config.project_root)
        self.config.apply_roles(editable_rel, protected_rel)

        SlokiStyle.grid({
            "Scan Result": "Success",
            "Code Files Found": len(files),
            "Auto-Detected Editable": ", ".join(editable_rel),
            "Protected Files": len(protected_rel)
        }, title="ANALYSIS SUMMARY")

        # AI Rule Synthesis
        SlokiStyle.header("PHASE: SMART RULE SYNTHESIS")
        SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Drafting guardrails...")

        prompt_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "prompts", "rules_synthesis.txt"
        )
        try:
            with open(prompt_path, 'r', encoding='utf-8') as f:
                rules_prompt = f.read().format(files_json=json.dumps(files, indent=2))

            ai_rules_json, _ = self.llm_client.generate(rules_prompt)
            from .config_manager import _extract_json_block
            json_data = _extract_json_block(ai_rules_json)
            if json_data:
                with open(self.rule_engine.rules_path, 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=2)
                self.rule_engine.__init__(self.rule_engine.rules_path)
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GREEN}[System] Guardrails synthesized and applied.{SlokiStyle.RESET}"
                )
            else:
                SlokiStyle.safe_print(
                    f"{SlokiStyle.RED}[Error] AI failed to generate valid guardrails.{SlokiStyle.RESET}"
                )
        except Exception as e:
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Rule synthesis failed: {e}{SlokiStyle.RESET}")

        return "Analysis complete"

    # ──────────────────────────────────────────────
    #  AGENT PERSONAS
    # ──────────────────────────────────────────────
    # ──────────────────────────────────────────────────
    #  AGENT PERSONAS (now Mini-Agents)
    # ──────────────────────────────────────────────────

    def _handle_agent_command(self, parts):
        subcmd = parts[1] if len(parts) > 1 else "list"

        if subcmd == "list":
            SlokiStyle.header("AGENT MANAGEMENT")
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[ MASTER AGENT ]{SlokiStyle.RESET}")
            SlokiStyle.label("assistant",
                             f"Master Orchestrator (Unique Pilot) {'(ACTIVE)' if self.active_agent_name == 'assistant' else ''}")
            SlokiStyle.label("global",
                             f"Global Mode (Project-wide context) {'(ACTIVE)' if self.active_agent_name == 'global' else ''}")
            
            SlokiStyle.safe_print(f"\n{SlokiStyle.CYAN}[ MINI-AGENTS (Task Specialists) ]{SlokiStyle.RESET}")
            
            # Show Mini-Agents from MasterAgent first
            known_names = set(["assistant", "global"])
            if self.master_agent and self.master_agent.mini_agents:
                for name, agent in self.master_agent.mini_agents.items():
                    known_names.add(name)
                    active_tag = (f" {SlokiStyle.GREEN}(ACTIVE){SlokiStyle.RESET}"
                                  if self.active_agent_name == name else "")
                    desc = agent.config.description
                    if name == "task_scheduler":
                        desc = "Specialist for all task-related code and logic."
                    SlokiStyle.label(name, f"{desc}{active_tag}")

            # Show custom personas if any (only if not already listed as Mini-Agent)
            if self.agent_registry:
                for name, purpose in self.agent_registry.items():
                    if name not in known_names:
                        active_tag = (f" {SlokiStyle.GREEN}(ACTIVE){SlokiStyle.RESET}"
                                      if self.active_agent_name == name else "")
                        SlokiStyle.label(name, f"{purpose}{active_tag}")

            SlokiStyle.safe_print("\nUsage:")
            SlokiStyle.safe_print("  /agent switch <name>             Switch active agent")
            SlokiStyle.safe_print("  /agent create <name> [purpose]   Create a Task Specialist")
            SlokiStyle.safe_print("  /agent delete <name>             Delete a Mini-Agent")
            return "Agents listed"

        if subcmd == "create" and len(parts) >= 3:
            name = parts[2].lower()
            
            # 1. Duplicate Detection
            is_mini = self.master_agent and name in self.master_agent.mini_agents
            if name in ["assistant", "global", "master", "orchestrator"]:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Master Agent cannot be re-created.{SlokiStyle.RESET}")
                return "Reserved name"
            if is_mini or name in self.agent_registry:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Agent name '{name}' is already taken.{SlokiStyle.RESET}")
                return "Duplicate name"

            desc = " ".join(parts[3:]) if len(parts) > 3 else ""
            if not desc:
                SlokiStyle.safe_print(f"{SlokiStyle.CYAN}Enter specialist's task or path to .md specification:{SlokiStyle.RESET} ", end="")
                desc = input().strip()
            
            if not desc:
                return "Operation cancelled."

            # CASE 1: Markdown Specification
            if desc.lower().endswith(".md"):
                if not os.path.exists(desc):
                    SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Requirement file '{desc}' not found.{SlokiStyle.RESET}")
                    return "File not found"
                
                md_path = desc
                SlokiStyle.safe_print(f"{SlokiStyle.BLUE}[System] Synthesizing instructions from {os.path.basename(md_path)}...{SlokiStyle.RESET}")
                
                # For MD, we always ensure the specialist is created first
                success, msg = self.master_agent.create_specialist(name, "Spec-Based Specialist")
                if not success:
                    SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] {msg}{SlokiStyle.RESET}")
                    return msg
                
                success, msg = self.master_agent.configure_from_md(name, md_path)
                if success:
                    SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
                else:
                    SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] {msg}{SlokiStyle.RESET}")
                return msg
            
            # CASE 2: Plain Text Specialist
            if len(desc) > 10:
                SlokiStyle.safe_print(f"{SlokiStyle.BLUE}[System] Synthesizing instructions for '{name}'...{SlokiStyle.RESET}")

            success, msg = self.master_agent.create_specialist(name, desc)
            if success:
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
            else:
                # Persona Fallback (Style-only agents)
                persona_prompt = self._create_agent_persona(name, desc)
                if persona_prompt:
                    self.agent_registry[name] = desc
                    self._save_agents()
                    SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] Mini-Agent (Style) '{name}' created.{SlokiStyle.RESET}")
                    return f"Agent {name} created"
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] {msg}{SlokiStyle.RESET}")
            return msg

        if subcmd == "switch" and len(parts) >= 3:
            name = parts[2].lower()
            is_mini = self.master_agent and name in self.master_agent.mini_agents
            if name in ["assistant", "global"] or name in self.agent_registry or is_mini:
                self.active_agent_name = name
                self._save_agents()
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GREEN}[System] Switched to agent: {name}{SlokiStyle.RESET}"
                )
                return f"Switched to {name}"
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Agent '{name}' not found.{SlokiStyle.RESET}")
            return "Agent not found"

        if subcmd == "delete" and len(parts) >= 3:
            name = parts[2].lower()
            if name in ["assistant", "global"]:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Master Agent cannot be deleted.{SlokiStyle.RESET}")
                return "Delete blocked"

            deleted = False
            msg = ""
            
            if self.master_agent and name in self.master_agent.mini_agents:
                deleted, msg = self.master_agent.delete_specialist(name)
            
            if name in self.agent_registry:
                self.agent_registry.pop(name)
                self._save_agents()
                deleted = True
                msg = f"Agent '{name}' removed."

            if deleted:
                if self.active_agent_name == name:
                    self.active_agent_name = "assistant"
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
                return msg
            
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Agent '{name}' not found.{SlokiStyle.RESET}")
            return "Agent not found"

        return "Invalid agent command"

    def _create_agent_persona(self, name, purpose):
        SlokiStyle.safe_print(
            f"{SlokiStyle.BLUE}[System] Synthesizing instructions for '{name}'...{SlokiStyle.RESET}"
        )
        synthesis_prompt = f"""
### TASK: SYSTEM PROMPT SYNTHESIS
You are the Sloki Master Architect. Write a high-fidelity System Instruction for a new AI Agent named '{name}'.

### AGENT PURPOSE:
{purpose}

### REQUIREMENTS:
1. Write in the second person ("You are...").
2. Define the core philosophy, tone, and specific constraints.
3. Keep it professional, concise, and focused on coding/engineering.
4. Output ONLY the raw instructions. No preamble.

### OUTPUT:
"""
        response, _ = self.llm_client.generate(synthesis_prompt)
        if response:
            prompt_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts", "agents")
            os.makedirs(prompt_dir, exist_ok=True)
            with open(os.path.join(prompt_dir, f"{name}.txt"), 'w', encoding='utf-8') as f:
                f.write(response.strip())
            return response.strip()
        return None
