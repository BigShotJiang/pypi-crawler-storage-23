"""
Pipeline — The core agentic execution engine.
Handles: Intent → RuleGuard → Planning → Editing → Validation → Walkthrough.
Supports both interactive (human-in-the-loop) and autonomous (headless) modes.
"""
import os
import re
import json
import difflib
import subprocess
import shutil
from .utils.style import SlokiStyle
from .utils.logger import get_logger
from .config_manager import _extract_json_block
from .workflow_executor import WorkflowExecutor
from sloki_agent.code_editor.block_parser import BlockParser
from sloki_agent.retrieval.context_engine import ContextEngine
from sloki_agent.agents.intent_agent import IntentAgent
from sloki_agent.agents.rule_guard_agent import RuleGuardAgent
from sloki_agent.agents.edit_agent import EditAgent
from sloki_agent.agents.planning_agent import PlanningAgent
from sloki_agent.agents.walkthrough_agent import WalkthroughAgent
from sloki_agent.agents.assistant_agent import AssistantAgent
from sloki_agent.agents.persona_agent import PersonaAgent
from sloki_agent.validators.code_validator import CompilationValidator


class Pipeline:
    """
    The core execution pipeline for Sloki.
    Orchestrates: Intent → RuleGuard → Planning → Editing → Validation → Walkthrough.
    """

    def __init__(self, llm_client, rule_engine, config_manager, memory_manager,
                 command_handler, brain_dir, auto_mode=False):
        self.llm_client = llm_client
        self.rule_engine = rule_engine
        self.config = config_manager
        self.memory_manager = memory_manager
        self.cmd_handler = command_handler
        self.brain_dir = brain_dir
        self.auto_mode = auto_mode

        # Logger
        self.log = get_logger(log_dir=os.path.join(brain_dir, 'logs'))

        # Context Engine
        self.context_engine = ContextEngine(
            project_root=config_manager.project_root,
            editable_files=config_manager.editable_files,
            protected_files=config_manager.protected_files
        )

        # Workflow Executor
        workflows_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), '.agents', 'workflows'
        )
        self.workflow_executor = WorkflowExecutor(workflows_dir)

        # Agents
        self.intent_agent = IntentAgent(llm_client)
        self.rule_guard = RuleGuardAgent(rule_engine)
        self.edit_agent = EditAgent(llm_client)
        self.planning_agent = PlanningAgent(llm_client)
        self.walkthrough_agent = WalkthroughAgent(llm_client)
        self.assistant_agent = AssistantAgent(llm_client)

        # State
        self.current_plan = ""
        self.tasks = []

    @property
    def is_auto(self):
        """Dynamic check for autonomous mode (CLI flag or config)."""
        return self.auto_mode or getattr(self.config, 'auto_mode', False)

    # ──────────────────────────────────────────────
    #  ARTIFACTS
    # ──────────────────────────────────────────────

    def _save_artifact(self, filename, content):
        path = os.path.join(self.brain_dir, filename)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return path

    # ──────────────────────────────────────────────
    #  MAIN ENTRY POINT
    # ──────────────────────────────────────────────

    def execute(self, user_input, is_global=False):
        """
        Run the full agentic pipeline for a user request.
        Supports an autonomous retry loop for robustness.
        """
        max_retries = 3
        current_attempt = 0
        feedback = ""
        last_error = ""

        while current_attempt < max_retries:
            success, result = self._execute_once(user_input, is_global, feedback)
            if success:
                return True, result
            
            # Autonomous Retry Logic
            current_attempt += 1
            last_error = result
            
            if current_attempt < max_retries:
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GOLD}[Reflection]{SlokiStyle.RESET} "
                    f"Attempt {current_attempt} failed: {result}. Retrying autonomously..."
                )
                feedback = (
                    f"Your previous attempt failed with error: '{result}'.\n"
                    f"Please reflect on what went wrong and try a different approach. "
                    f"If you missed a filename or reached a dead end, CORRECT it now."
                )
                # Small sleep to avoid rate limits or just to show progress
                import time
                time.sleep(1)
            else:
                return False, f"Autonomous execution failed after {max_retries} attempts. Last error: {last_error}"

    def _execute_once(self, user_input, is_global=False, autonomous_feedback=""):
        """Single pass of the pipeline."""
        core_input = user_input
        parts = user_input.split()
        cmd = parts[0].lower() if parts else ""

        # ── Handle /global flag ──
        if cmd == "/global":
            is_global = True
            core_input = " ".join(parts[1:]).strip()
            if not core_input:
                if self.is_auto:
                    return False, "Global prompt missing in auto mode"
                print(f"{SlokiStyle.BOLD}Enter the global prompt:{SlokiStyle.RESET} ", end="")
                core_input = input().strip()
                if not core_input:
                    return False, "Prompt missing"

        # ── Handle /load (file-based input) ──
        if cmd in ['/select', '/file', '/load']:
            loaded = self._load_requirements(parts)
            if loaded is None:
                return False, "No requirements loaded"
            core_input = loaded

        # ── Handle direct .md path input ──
        elif user_input.lower().endswith(".md") and os.path.exists(user_input):
            with open(user_input, 'r', encoding='utf-8') as f:
                core_input = f.read()
            SlokiStyle.safe_print(
                f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Loaded requirements from: {user_input}"
            )

        # ── Log to memory ──
        self.memory_manager.add_chat("user", core_input)
        memory_context = self.memory_manager.get_context_summary()

        # ── Enrich context with project-aware retrieval ──
        project_context = self.context_engine.get_relevant_context(core_input)
        if project_context:
            memory_context = f"{memory_context}\n\n{project_context}"
        
        if autonomous_feedback:
            # Inject reflection feedback into the core prompt
            core_input = f"{core_input}\n\n### AUTONOMOUS FEEDBACK (FROM PREVIOUS FAILURE):\n{autonomous_feedback}"

        # ══════════════════════════════════════════
        #  PHASE 1: INTENT ANALYSIS
        # ══════════════════════════════════════════
        current_block = self._build_code_context()
        intent = self.intent_agent.parse(
            f"{memory_context}\n\nCURRENT REQUEST:\n{core_input}",
            current_code=current_block
        )
        action = intent.get('action')
        params = intent.get('params', {})

        # ── Agent mode injection ──
        active_agent = self.cmd_handler.active_agent_name
        is_specialist = active_agent != "assistant"
        
        if is_specialist:
            if action == "chat":
                coding_keywords = [
                    "create", "add", "modify", "update", "delete", "remove",
                    "refactor", "setup", "new file", "change", "write",
                    "implement", "build"
                ]
                if any(k in core_input.lower() for k in coding_keywords):
                    # Force coding action if keywords present
                    if "delete" in core_input.lower() or "remove" in core_input.lower():
                        action = "delete_file"
                    else:
                        action = "edit_code"
                    intent['action'] = action

        if active_agent == "global":
            is_global = True

        # Normalize legacy action names (preserve original for RuleGuard)
        if action in ['add_task', 'remove_task', 'update_task', 'create_file']:
            intent['original_action'] = action
            action = 'edit_code'
            intent['action'] = 'edit_code'

        # ── Memory signals ──
        pref = params.get('preference')
        if pref and isinstance(pref, dict):
            for k, v in pref.items():
                self.memory_manager.set_preference(k, v)
        
        # New: Log AI-detected project operations
        ops = params.get('project_operations')
        if ops and isinstance(ops, list):
            for op in ops:
                self.memory_manager.add_operation(op)

        note = params.get('style_note')
        if note:
            self.memory_manager.add_style_note(note)

        # ══════════════════════════════════════════
        #  BRANCH: CHAT
        # ══════════════════════════════════════════
        if action == "chat":
            return self._handle_chat(core_input, memory_context, intent)

        # ══════════════════════════════════════════
        #  BRANCH: EDIT RULES
        # ══════════════════════════════════════════
        if action == "edit_rules":
            return self._handle_edit_rules(params)

        # ══════════════════════════════════════════
        #  BRANCH: DELETE FILE
        # ══════════════════════════════════════════
        if action == "delete_file":
            return self._handle_delete_file(params, core_input, intent)

        # ══════════════════════════════════════════
        #  BRANCH: RENAME FILE
        # ══════════════════════════════════════════
        if action == "rename_file":
            return self._handle_rename_file(params, core_input, intent)

        # ══════════════════════════════════════════
        #  BRANCH: BUILD / TEST / SEARCH / ANALYZE
        # ══════════════════════════════════════════
        if action == "build_project":
            return self._handle_build_project(intent)
        if action == "run_tests":
            return self._handle_run_tests(intent)
        if action == "search_code":
            return self._handle_search_code(params)
        if action == "git_action":
            return self._handle_git_action(params, core_input)
        if action == "analyze_codebase":
            return self._handle_analyze_codebase(intent)

        # ══════════════════════════════════════════
        #  PHASE 2: RULE GUARD GATE  🛡️
        # ══════════════════════════════════════════
        if action in ['edit_code', 'create_file', 'delete_file', 'rename_file', 'git_action', 'build_project', 'run_tests', 'search_code', 'analyze_codebase']:
            # Check target file protection
            target_file = params.get('details', {}).get('filename', '')
            if target_file and self.rule_engine.is_file_protected(target_file):
                self.log.rule_check(f'file:{target_file}', False, 'Protected file')
                SlokiStyle.safe_print(
                    f"{SlokiStyle.RED}[BLOCKED] File '{target_file}' is protected "
                    f"by rules.json{SlokiStyle.RESET}"
                )
                return False, f"Protected file: {target_file}"

            # Validate action and params against rules
            valid, msg = self.rule_guard.validate(intent)
            self.log.rule_check(action, valid, msg)
            if not valid:
                SlokiStyle.safe_print(
                    f"{SlokiStyle.RED}[BLOCKED] {msg}{SlokiStyle.RESET}"
                )
                return False, msg

            # ── Match to a workflow if available ──
            wf_name, workflow = self.workflow_executor.match_workflow(core_input)
            if workflow:
                self.log.pipeline_phase(f'Workflow: {wf_name}', 'matched')
                workflow_context = self.workflow_executor.build_prompt_context(wf_name)
                memory_context = f"{memory_context}\n\n{workflow_context}"
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GOLD}[Workflow]{SlokiStyle.RESET} Using: {wf_name}"
                )

        # ══════════════════════════════════════════
        #  PHASE 3: PLANNING (with iterative review)
        # ══════════════════════════════════════════
        planning_feedback = ""
        while True:
            SlokiStyle.header("PHASE: PLANNING")
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Analyzing requirements...")

            planning_context = (
                f"<session_context>\n{memory_context}\n</session_context>\n\n"
                f"### MANDATORY REQUIREMENTS:\n{core_input}"
            )
            if planning_feedback:
                planning_context += f"\n\n### USER FEEDBACK ON PREVIOUS PLAN:\n{planning_feedback}"

            raw_plan = self.planning_agent.create_plan(planning_context)
            self.current_plan, self.tasks = self._parse_plan(raw_plan)

            self._save_artifact("implementation_plan.md", f"# Implementation Plan\n\n{self.current_plan}")
            self._save_artifact("task.md", "# Tasks\n\n" + "\n".join(self.tasks))

            SlokiStyle.header("PROPOSED PLAN")
            SlokiStyle.safe_print(self.current_plan)
            SlokiStyle.header("TASK LIST")
            for t in self.tasks:
                print(t)

            # Auto-approve in headless mode
            if self.is_auto:
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GREEN}[Auto] Plan auto-approved.{SlokiStyle.RESET}"
                )
                break

            print(f"\n{SlokiStyle.CYAN}{SlokiStyle.BOLD}Approve this plan? "
                  f"(y/n or provide feedback):{SlokiStyle.RESET} ", end="")
            feedback = input().strip()
            if feedback.lower() == 'y':
                break
            elif feedback.lower() == 'n':
                return False, "Plan rejected"
            else:
                planning_feedback = feedback
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GOLD}[System] Re-planning based on feedback...{SlokiStyle.RESET}"
                )

        # ══════════════════════════════════════════
        #  PHASE 4: CODE GENERATION (with iterative review)
        # ══════════════════════════════════════════
        return self._run_code_generation(intent, core_input, memory_context, is_global)

    # ──────────────────────────────────────────────
    #  CODE CONTEXT BUILDER
    # ──────────────────────────────────────────────

    def _build_code_context(self):
        """Build code context from editable files and their blocks."""
        rep_file = self.config.editable_files[0] if self.config.editable_files else ""
        current_block = ""

        if rep_file:
            parser = BlockParser(rep_file)
            all_blocks = parser.list_blocks()
            block_contexts = []
            for bname in all_blocks:
                bdata = parser.extract_block(bname)
                if bdata:
                    block_contexts.append(f"[BLOCK: {bname}]\n{bdata}")
                    if not current_block:
                        current_block = bdata
            current_block = "\n\n".join(block_contexts) if block_contexts else current_block

            if not current_block and os.path.exists(rep_file):
                with open(rep_file, 'r', encoding='utf-8') as f:
                    current_block = f.read()

        return current_block

    # ──────────────────────────────────────────────
    #  PLAN PARSER
    # ──────────────────────────────────────────────

    def _parse_plan(self, raw_plan):
        """Parse [PLAN] and [TASKS] sections from LLM output."""
        plan_match = re.search(r'\[PLAN\](.*?)(?=\[TASKS\]|$)', raw_plan, re.DOTALL | re.IGNORECASE)
        task_match = re.search(r'\[TASKS\](.*)', raw_plan, re.DOTALL | re.IGNORECASE)

        plan_text = plan_match.group(1).strip() if plan_match else raw_plan.split('[TASKS]')[0].strip()
        task_block = task_match.group(1).strip() if task_match else ""

        if not task_block:
            potential = re.findall(r'^[-*]\s*\[\s*[ xX]*\]\s*.*$', raw_plan, re.MULTILINE)
            if potential:
                task_block = "\n".join(potential)

        potential_tasks = [line.strip() for line in task_block.split('\n') if line.strip()]
        tasks = [t for t in potential_tasks if '- [' in t or '* [' in t]
        if not tasks and potential_tasks:
            tasks = [f"- [ ] {t}" if not t.startswith('-') else t for t in potential_tasks]
        if not tasks:
            tasks = ["- [ ] Execute requested code modifications"]

        return plan_text, tasks

    # ──────────────────────────────────────────────
    #  CHAT HANDLER
    # ──────────────────────────────────────────────

    def _handle_chat(self, core_input, memory_context, intent):
        active_agent = self.cmd_handler.active_agent_name
        SlokiStyle.safe_print(
            f"{SlokiStyle.BLUE}[AI {active_agent.capitalize()}]{SlokiStyle.RESET} ",
            end="", flush=True
        )

        if active_agent in self.cmd_handler.agent_registry:
            persona = PersonaAgent(self.llm_client, active_agent)
            response = persona.chat(core_input, context=memory_context)
        else:
            response = self.assistant_agent.chat(core_input, context=memory_context)

        self.memory_manager.add_chat("assistant", response)
        self._save_artifact("implementation_plan.md", "# Implementation Plan\n\nN/A - General Conversation")
        self._save_artifact("task.md", "# Tasks\n\n- [x] Completed conversation")
        self._save_artifact("walkthrough.md", "# Final Walkthrough\n\nConversational response provided.")
        return True, "Chat delivered"

    # ──────────────────────────────────────────────
    #  RULE EDIT HANDLER
    # ──────────────────────────────────────────────

    def _handle_edit_rules(self, params):
        details = params.get('details', {})
        category = details.get('category') or params.get('category')
        value = details.get('value') or params.get('value')
        operation = details.get('operation') or params.get('operation') or 'add'

        if category and value:
            if operation == 'delete':
                success, msg = self.rule_engine.delete_rule(category, value)
            else:
                success, msg = self.rule_engine.add_rule(category, value)

            if success:
                self.rule_engine.save_rules()
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
            else:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[System] {msg}{SlokiStyle.RESET}")

            self._save_artifact("implementation_plan.md", f"# Rule Update Plan\n\n{msg}")
            self._save_artifact("task.md", f"# Tasks\n\n- [x] {msg}")
            self._save_artifact("walkthrough.md", f"# Final Walkthrough\n\n{msg}")
            return True, msg

        return False, "Incomplete rule parameters from AI"

    # ──────────────────────────────────────────────
    #  DELETE FILE HANDLER
    # ──────────────────────────────────────────────

    def _handle_delete_file(self, params, core_input, intent):
        """Handle physical file deletion with confirmation."""
        filename = params.get('details', {}).get('filename')
        if not filename:
            # Try to extract from core_input if LLM missed it
            match = re.search(r'delete\s+([\w\./\\]+)', core_input, re.I)
            if match:
                filename = match.group(1)
        
        if not filename:
            return False, "Could not determine file to delete"

        target_path = os.path.join(self.config.project_root or os.getcwd(), filename)
        
        # 🛡️ Rule Guard
        if self.rule_engine.is_file_protected(filename):
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[BLOCKED] File '{filename}' is protected.{SlokiStyle.RESET}")
            return False, f"Protected file: {filename}"

        SlokiStyle.header(f"ACTION: DELETE FILE")
        SlokiStyle.safe_print(f"{SlokiStyle.RED}{SlokiStyle.BOLD}Target:{SlokiStyle.RESET} {target_path}")
        
        if not os.path.exists(target_path):
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] File does not exist.{SlokiStyle.RESET}")
            return False, f"File not found: {target_path}"

        if not self.is_auto:
            print(f"\n{SlokiStyle.BOLD}{SlokiStyle.RED}Are you sure you want to PERMANENTLY DELETE this file? (y/n):{SlokiStyle.RESET} ", end="")
            choice = input().strip().lower()
            if choice != 'y':
                return False, "Deletion cancelled by user"

        try:
            os.remove(target_path)
            msg = f"Successfully deleted {filename}"
            SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
            
            # Walkthrough
            report = self.walkthrough_agent.generate_report(intent, f"DELETED: {filename}")
            self._save_artifact("walkthrough.md", f"# Final Walkthrough\n\n{report}")
            SlokiStyle.header("FINAL WALKTHROUGH")
            SlokiStyle.safe_print(report)
            
            return True, msg
        except Exception as e:
            return False, f"Error deleting file: {e}"

    # ──────────────────────────────────────────────
    #  RENAME FILE HANDLER
    # ──────────────────────────────────────────────

    def _handle_rename_file(self, params, core_input, intent):
        """Handle physical file renaming/moving on disk."""
        details = params.get('details', {})
        old_name = details.get('old_name')
        new_name = details.get('new_name')

        if not old_name or not new_name:
            # Try to extract from core_input if LLM missed it
            match = re.search(r'rename\s+([\w\./\\]+)\s+to\s+([\w\./\\]+)', core_input, re.I)
            if match:
                old_name, new_name = match.groups()
            else:
                return False, "Could not determine filenames for rename (need old_name and new_name)"

        # Resolve paths
        project_root = self.config.project_root or os.getcwd()
        old_path = os.path.join(project_root, old_name)
        new_path = os.path.join(project_root, new_name)

        # 🛡️ Rule Guard (Check both names)
        if self.rule_engine.is_file_protected(old_name):
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[BLOCKED] Source file '{old_name}' is protected.{SlokiStyle.RESET}")
            return False, f"Rule violation: '{old_name}' is protected"
        
        if self.rule_engine.is_file_protected(new_name):
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[BLOCKED] Target file '{new_name}' is protected.{SlokiStyle.RESET}")
            return False, f"Rule violation: '{new_name}' is protected"

        SlokiStyle.header(f"ACTION: RENAME FILE")
        SlokiStyle.safe_print(f"{SlokiStyle.BLUE}From:{SlokiStyle.RESET} {old_path}")
        SlokiStyle.safe_print(f"{SlokiStyle.GREEN}To:  {SlokiStyle.RESET} {new_path}")

        if not os.path.exists(old_path):
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[System] Source file does not exist.{SlokiStyle.RESET}")
            return False, f"File not found: {old_path}"

        if not self.is_auto:
            print(f"\n{SlokiStyle.BOLD}Rename this file? (y/n):{SlokiStyle.RESET} ", end="")
            choice = input().strip().lower()
            if choice != 'y':
                return False, "Rename cancelled by user"

        try:
            # Ensure target directory exists
            os.makedirs(os.path.dirname(new_path), exist_ok=True)
            os.rename(old_path, new_path)
            
            msg = f"Successfully renamed {old_name} to {new_name}"
            SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
            
            # Walkthrough
            report_text = f"RENAMED: {old_name} → {new_name}"
            report = self.walkthrough_agent.generate_report(intent, report_text)
            self._save_artifact("walkthrough.md", f"# Final Walkthrough\n\n{report}")
            SlokiStyle.header("FINAL WALKTHROUGH")
            SlokiStyle.safe_print(report)
            
            return True, msg
        except Exception as e:
            return False, f"Error renaming file: {e}"

    # ──────────────────────────────────────────────
    #  GIT ACTION HANDLER
    # ──────────────────────────────────────────────

    def _handle_git_action(self, params, core_input):
        """Execute a subset of safe git commands."""
        details = params.get('details', {})
        command = details.get('git_command')
        args = details.get('git_args', [])

        # Whitelist of allowed git commands
        allowed_commands = [
            "init", "add", "commit", "branch", "checkout", 
            "remote", "status", "diff", "log", "show", 
            "push", "pull", "fetch", "merge", "rebase", "reset"
        ]

        if not command:
            # Try to extract from core_input (e.g. "git status")
            match = re.search(r'git\s+(\w+)', core_input, re.I)
            if match:
                command = match.group(1).lower()
                # Extract args after the command
                remaining = core_input[match.end():].strip()
                if remaining:
                    args = remaining.split()
            else:
                return False, "Could not determine git command"

        if command not in allowed_commands:
            return False, f"Git command '{command}' is not in the allowed whitelist."

        # 🛡️ Security Guard: Check if any argument is a protected file (for 'add', 'reset', etc.)
        if command in ["add", "reset", "checkout", "diff", "show"]:
            for arg in args:
                if self.rule_engine.is_file_protected(arg):
                    SlokiStyle.safe_print(f"{SlokiStyle.RED}[BLOCKED] Git action involves protected file: {arg}{SlokiStyle.RESET}")
                    return False, f"Rule violation: '{arg}' is protected"

        SlokiStyle.header(f"ACTION: GIT {command.upper()}")
        full_cmd = ["git", command] + args
        SlokiStyle.safe_print(f"{SlokiStyle.BLUE}Command:{SlokiStyle.RESET} {' '.join(full_cmd)}")

        project_root = self.config.project_root or os.getcwd()

        try:
            # Ensure it's a git repo unless we are doing 'init'
            if command != "init" and not os.path.exists(os.path.join(project_root, ".git")):
                return False, "Not a git repository (missing .git folder). Run 'git init' first."

            result = subprocess.run(full_cmd, cwd=project_root, capture_output=True, text=True)
            
            if result.returncode == 0:
                msg = f"Successfully executed: {' '.join(full_cmd)}"
                SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] {msg}{SlokiStyle.RESET}")
                if result.stdout:
                    print(f"\n{SlokiStyle.GOLD}Output:{SlokiStyle.RESET}\n{result.stdout}")
                return True, msg
            else:
                error_msg = result.stderr or result.stdout
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] {error_msg}{SlokiStyle.RESET}")
                return False, f"Git command failed: {error_msg}"

        except Exception as e:
            return False, f"Error during git action: {e}"

    # ──────────────────────────────────────────────
    #  BUILD / TEST / SEARCH / ANALYZE HANDLERS
    # ──────────────────────────────────────────────

    def _handle_build_project(self, intent):
        """Trigger project build process."""
        SlokiStyle.header("ACTION: BUILD PROJECT")
        validator = CompilationValidator(self.config.project_root)
        valid, msg = validator.validate()
        
        # Report
        report_text = f"BUILD RESULT: {'SUCCESS' if valid else 'FAILED'}\n\n{msg}"
        report = self.walkthrough_agent.generate_report(intent, report_text)
        self._save_artifact("walkthrough.md", f"# Build Report\n\n{report}")
        SlokiStyle.header("BUILD WALKTHROUGH")
        SlokiStyle.safe_print(report)
        
        return valid, msg

    def _handle_run_tests(self, intent):
        """Find and execute project tests."""
        SlokiStyle.header("ACTION: RUN TESTS")
        project_root = self.config.project_root or os.getcwd()
        
        # Look for common test entry points
        test_scripts = [
            os.path.join(project_root, "tests", "run_tests.py"),
            os.path.join(project_root, "run_tests.py"),
            os.path.join(project_root, "tests", "test_all.py")
        ]
        
        script_to_run = next((s for s in test_scripts if os.path.exists(s)), None)
        
        if not script_to_run:
            # Try running python -m pytest if available or similar
            return False, "No test script found in common locations (tests/run_tests.py, etc.)"

        try:
            result = subprocess.run([sys.executable, script_to_run], capture_output=True, text=True, cwd=project_root)
            output = result.stdout + result.stderr
            success = result.returncode == 0
            
            report_text = f"TEST RESULT: {'PASS' if success else 'FAIL'}\n\n{output}"
            report = self.walkthrough_agent.generate_report(intent, report_text)
            self._save_artifact("walkthrough.md", f"# Test Report\n\n{report}")
            SlokiStyle.header("TEST WALKTHROUGH")
            SlokiStyle.safe_print(report)
            
            return success, f"Tests executed. Result: {'Pass' if success else 'Fail'}"
        except Exception as e:
            return False, f"Error running tests: {e}"

    def _handle_search_code(self, params):
        """Search for a pattern in the codebase."""
        query = params.get('details', {}).get('query')
        if not query:
            return False, "No search query provided"
            
        SlokiStyle.header(f"ACTION: SEARCH CODE ('{query}')")
        project_root = self.config.project_root or os.getcwd()
        
        try:
            # Simple grep-like search across typical source files
            results = []
            extensions = ('.c', '.h', '.py', '.md', '.json')
            for root, _, files in os.walk(project_root):
                if '.git' in root or '.agents' in root or '__pycache__' in root:
                    continue
                for file in files:
                    if file.endswith(extensions):
                        path = os.path.join(root, file)
                        try:
                            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                                for line_no, line in enumerate(f, 1):
                                    if query.lower() in line.lower():
                                        rel_path = os.path.relpath(path, project_root)
                                        results.append(f"{rel_path}:{line_no}: {line.strip()}")
                                        if len(results) > 50: break # Cap results
                        except: pass
                if len(results) > 50: break

            if not results:
                msg = f"No matches found for '{query}'"
                SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] {msg}{SlokiStyle.RESET}")
                return True, msg
            
            results_text = "\n".join(results)
            SlokiStyle.safe_print(f"{SlokiStyle.GREEN}[System] Matches found:{SlokiStyle.RESET}\n{results_text}")
            return True, f"Found {len(results)} matches for '{query}'"
        except Exception as e:
            return False, f"Search error: {e}"

    def _handle_analyze_codebase(self, intent):
        """Provide a high-level summary of the codebase."""
        SlokiStyle.header("ACTION: ANALYZE CODEBASE")
        project_root = self.config.project_root or os.getcwd()
        
        # Aggregate structural info
        files_info = []
        for root, _, files in os.walk(project_root):
            if '.git' in root or '.agents' in root: continue
            for f in files:
                if f.endswith(('.c', '.h', '.py')):
                    files_info.append(os.path.relpath(os.path.join(root, f), project_root))
        
        analysis_prompt = (
            f"You are a Senior Architect. Analyze the following project structure and summarize the purpose "
            f"of key components and the overall architecture.\n\nProject Root: {project_root}\nFiles:\n" + 
            "\n".join(files_info[:50]) # Cap for context
        )
        
        response, thought = self.llm_client.generate(analysis_prompt)
        
        self._save_artifact("analysis_report.md", f"# Codebase Analysis\n\n{response}")
        SlokiStyle.header("ANALYSIS REPORT")
        SlokiStyle.safe_print(response)
        
        return True, "Analysis complete. See analysis_report.md for details."

    # ──────────────────────────────────────────────
    #  CODE GENERATION ENGINE
    # ──────────────────────────────────────────────

    def _run_code_generation(self, intent, core_input, memory_context, is_global):
        """Run code generation with retries, diff review, and validation."""
        params = intent.get('params', {})
        generation_feedback = ""

        while True:
            SlokiStyle.header("PHASE: CODE GENERATION")

            # Determine targets
            targets = []
            if is_global:
                targets = self.config.editable_files.copy()
            elif self.config.editable_files:
                targets = [self.config.editable_files[0]]

            # Filter out wildcard scope markers
            targets = [t for t in targets if t != "**/*"]

            new_file_name = params.get('details', {}).get('filename')
            if new_file_name and not any(os.path.basename(t) == os.path.basename(new_file_name) for t in targets):
                new_path = os.path.join(self.config.project_root or os.getcwd(), new_file_name)
                targets.append(new_path)

            if not targets:
                # Try aggressive extraction
                alt_file = self._extract_filename_from_input(core_input)
                if alt_file:
                    new_path = os.path.join(self.config.project_root or os.getcwd(), alt_file)
                    targets = [new_path]
                    SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Robustly picked target from prompt: {alt_file}")
                
            if not targets:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}[System] Could not determine target file. Please specify a file name.{SlokiStyle.RESET}")
                return False, "No target file specified"

            # Store originals for rollback
            originals = {}

            # Retry loop
            retries = 0
            while retries < 2:
                all_diffs = []
                new_contents = {}

                for target_path in targets:
                    # 🛡️ RULE GUARD: Skip protected files
                    if self.config.project_root:
                        rel = os.path.relpath(target_path, self.config.project_root)
                    else:
                        rel = os.path.basename(target_path)
                    if self.rule_engine.is_file_protected(rel):
                        SlokiStyle.safe_print(
                            f"{SlokiStyle.RED}[BLOCKED] Skipping protected: "
                            f"{os.path.basename(target_path)}{SlokiStyle.RESET}"
                        )
                        continue

                    SlokiStyle.safe_print(
                        f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} "
                        f"Processing {os.path.basename(target_path)}..."
                    )

                    # Read original
                    original = ""
                    if os.path.exists(target_path):
                        if os.path.isdir(target_path):
                            SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Target '{target_path}' is a directory, not a file. Please specify a full file path.{SlokiStyle.RESET}")
                            return False, f"Target is a directory: {target_path}"
                        try:
                            with open(target_path, 'r', encoding='utf-8') as f:
                                original = f.read()
                        except PermissionError:
                            SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Permission Denied reading {target_path}. Is it locked?{SlokiStyle.RESET}")
                            return False, f"Permission Denied: {target_path}"
                    originals[target_path] = original

                    # Process blocks or full file
                    parser = BlockParser(target_path)
                    file_blocks = parser.list_blocks()

                    if file_blocks:
                        updated = original
                        for block_name in file_blocks:
                            current_block = parser.extract_block(block_name)
                            if not current_block:
                                continue

                            edit_intent = intent.copy()
                            edit_intent['target_file'] = os.path.basename(target_path)
                            if generation_feedback:
                                edit_intent['feedback'] = generation_feedback
                            if retries > 0:
                                edit_intent['feedback'] = (
                                    edit_intent.get('feedback', '') +
                                    "\n[CRITICAL] You returned NO CHANGES last time. "
                                    "You MUST rewrite the block correctly."
                                )

                            edit_context = f"<session_context>\n{memory_context}\n</session_context>"
                            updated_block = self.edit_agent.generate_edit(
                                edit_intent, current_block, context=edit_context, is_full_file=False
                            )
                            updated_block = re.sub(
                                r'// === EDITABLE_(START|END):.*? ===', '', updated_block
                            ).strip()

                            # Preservation guard
                            orig_lines = len([l for l in current_block.split('\n') if l.strip()])
                            new_lines = len([l for l in updated_block.split('\n') if l.strip()])
                            edit_type = params.get('edit_type', '')

                            if edit_type != 'delete' and new_lines < orig_lines * 0.5:
                                SlokiStyle.safe_print(
                                    f"{SlokiStyle.RED}[System]{SlokiStyle.RESET} "
                                    f"Code shrank {orig_lines} → {new_lines} lines. Retrying..."
                                )
                                generation_feedback = (
                                    f"CRITICAL: Shrank from {orig_lines} to {new_lines} lines. "
                                    f"COPY ALL existing code first, then make ONLY the change."
                                )
                                retries += 1
                                break

                            pattern = (
                                rf"(// === EDITABLE_START: {block_name} ===)"
                                rf".*?"
                                rf"(// === EDITABLE_END: {block_name} ===)"
                            )
                            replacement = (
                                f"// === EDITABLE_START: {block_name} ===\n"
                                f"{updated_block}\n"
                                f"// === EDITABLE_END: {block_name} ==="
                            )
                            updated = re.sub(pattern, replacement, updated, flags=re.DOTALL)
                    else:
                        # Full file editing
                        edit_intent = intent.copy()
                        edit_intent['target_file'] = os.path.basename(target_path)
                        if generation_feedback:
                            edit_intent['feedback'] = generation_feedback

                        updated = self.edit_agent.generate_edit(
                            edit_intent, original,
                            context=memory_context, is_full_file=True
                        )

                        orig_l = len([l for l in original.split('\n') if l.strip()])
                        new_l = len([l for l in updated.split('\n') if l.strip()])
                        if params.get('edit_type', '') != 'delete' and new_l < orig_l * 0.7:
                            SlokiStyle.safe_print(
                                f"{SlokiStyle.RED}[System]{SlokiStyle.RESET} "
                                f"Full file shrank {orig_l} → {new_l}. Retrying..."
                            )
                            generation_feedback = (
                                f"CRITICAL: You deleted too much. Original had {orig_l} lines."
                            )
                            retries += 1
                            continue

                    # Generate diff
                    diff = list(difflib.unified_diff(
                        original.splitlines(keepends=True),
                        updated.splitlines(keepends=True),
                        fromfile=f"a/{os.path.relpath(target_path, self.config.project_root)}",
                        tofile=f"b/{os.path.relpath(target_path, self.config.project_root)}"
                    ))

                    if diff:
                        all_diffs.extend(diff)
                        new_contents[target_path] = updated

                if all_diffs:
                    break
                retries += 1
                if retries < 2:
                    SlokiStyle.safe_print(
                        f"{SlokiStyle.GOLD}[System] No diff generated. Retrying...{SlokiStyle.RESET}"
                    )

            if not all_diffs:
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GOLD}[System] No changes detected after retries.{SlokiStyle.RESET}"
                )
                return True, "No changes"

            # Display diff
            SlokiStyle.header("PROPOSED CROSS-FILE CHANGES")
            diff_text = "".join(all_diffs)
            for line in all_diffs:
                if line.startswith('+'):
                    print(f"{SlokiStyle.GREEN}{line.strip()}{SlokiStyle.RESET}")
                elif line.startswith('-'):
                    print(f"{SlokiStyle.RED}{line.strip()}{SlokiStyle.RESET}")
                else:
                    print(line.strip())

            self.cmd_handler.last_diff = diff_text
            with open(self.cmd_handler.diff_path, 'w', encoding='utf-8') as f:
                f.write(diff_text)

            # Auto-approve in headless mode
            if self.is_auto:
                choice = 'y'
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GREEN}[Auto] Changes auto-approved.{SlokiStyle.RESET}"
                )
            else:
                SlokiStyle.safe_print(
                    f"\n{SlokiStyle.BOLD}{SlokiStyle.RED}Apply changes to "
                    f"{len(new_contents)} file(s)? (y/n/r for review):{SlokiStyle.RESET} ",
                    end=""
                )
                choice = input().strip().lower()

            if choice == 'y':
                # Apply changes
                for path, content in new_contents.items():
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(content)
                SlokiStyle.safe_print(
                    f"{SlokiStyle.GREEN}[System] Changes applied to "
                    f"{len(new_contents)} files.{SlokiStyle.RESET}"
                )

                # ══════════════════════════════════
                #  PHASE 5: POST-EDIT VALIDATION 🔍
                # ══════════════════════════════════
                validator = CompilationValidator(self.config.project_root)
                valid, vmsg = validator.validate()
                if valid:
                    SlokiStyle.safe_print(
                        f"{SlokiStyle.GREEN}[VERIFIED] {vmsg}{SlokiStyle.RESET}"
                    )
                else:
                    SlokiStyle.safe_print(
                        f"{SlokiStyle.RED}[VALIDATION FAILED] {vmsg}{SlokiStyle.RESET}"
                    )
                    # In auto mode, revert changes
                    if self.is_auto:
                        SlokiStyle.safe_print(
                            f"{SlokiStyle.RED}[Auto] Reverting changes...{SlokiStyle.RESET}"
                        )
                        for path, orig in originals.items():
                            if path in new_contents:
                                with open(path, 'w', encoding='utf-8') as f:
                                    f.write(orig)
                        return False, f"Validation failed and reverted: {vmsg}"

                # ══════════════════════════════════
                #  PHASE 6: WALKTHROUGH REPORT
                # ══════════════════════════════════
                report = self.walkthrough_agent.generate_report(intent, diff_text)
                self._save_artifact("walkthrough.md", f"# Final Walkthrough\n\n{report}")
                SlokiStyle.header("FINAL WALKTHROUGH")
                SlokiStyle.safe_print(report)

                updated_tasks = [
                    t.replace("[ ]", "[x]") if "[x]" not in t else t
                    for t in self.tasks
                ]
                self._save_artifact("task.md", "# Tasks\n\n" + "\n".join(updated_tasks))

                return True, "Modifications applied"

            elif choice == 'r':
                if self.is_auto:
                    return False, "Review not available in auto mode"
                print(f"{SlokiStyle.GOLD}[System] Enter feedback:{SlokiStyle.RESET} ", end="")
                generation_feedback = input().strip()
                continue
            else:
                return False, "Modifications cancelled"

        return True, "Pipeline complete"

    # ──────────────────────────────────────────────
    #  REQUIREMENTS LOADER
    # ──────────────────────────────────────────────

    def _load_requirements(self, parts):
        """Handle /load command — load requirements from .md file. Returns content or None."""
        target_path = " ".join(parts[1:]).strip().strip('"')

        if target_path:
            if os.path.exists(target_path):
                try:
                    with open(target_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    SlokiStyle.safe_print(
                        f"{SlokiStyle.GREEN}[System] Loaded: {target_path}{SlokiStyle.RESET}"
                    )
                    return content
                except Exception as e:
                    SlokiStyle.safe_print(f"{SlokiStyle.RED}Read error: {e}{SlokiStyle.RESET}")
                    return None
            else:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}Path not found: {target_path}{SlokiStyle.RESET}")
                return None

        if self.is_auto:
            return None

        # Scan for .md files
        SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Scanning for .md files...")
        md_files = []
        for root, _, filenames in os.walk(self.config.project_root):
            for f in filenames:
                if f.endswith('.md') and 'brain' not in root and 'docs' not in root:
                    md_files.append(os.path.relpath(os.path.join(root, f), self.config.project_root))

        if not md_files:
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System] No markdown files found.{SlokiStyle.RESET}")
            print(f"{SlokiStyle.CYAN}Enter path to .md file:{SlokiStyle.RESET} ", end="")
            custom = input().strip().strip('"')
            if custom and os.path.exists(custom):
                with open(custom, 'r', encoding='utf-8') as f:
                    return f.read()
            return None

        SlokiStyle.header("SELECT REQUIREMENTS FILE")
        for i, f in enumerate(md_files):
            print(f"[{SlokiStyle.CYAN}{i}{SlokiStyle.RESET}] {f}")

        print(f"\n{SlokiStyle.BOLD}Enter index or path:{SlokiStyle.RESET} ", end="")
        try:
            choice_str = input().strip().strip('"')
            if not choice_str:
                return None
            if choice_str.isdigit() and int(choice_str) < len(md_files):
                selected = os.path.join(self.config.project_root, md_files[int(choice_str)])
            elif os.path.exists(choice_str):
                selected = choice_str
            else:
                SlokiStyle.safe_print(f"{SlokiStyle.RED}Invalid selection.{SlokiStyle.RESET}")
                return None

            with open(selected, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            SlokiStyle.safe_print(f"{SlokiStyle.RED}Selection failed: {e}{SlokiStyle.RESET}")
            return None

    def _extract_filename_from_input(self, text):
        """Regex-based fallback for filename discovery in natural language."""
        if not text: return None
        # Look for patterns like "named X.c", "file X.py", or paths like "C:\..." or "src/..."
        
        # 1. Look for absolute Windows paths (e.g. C:\Users\...)
        abs_win = re.search(r'([A-Za-z]:\\[\w\\\.\s-]+)', text)
        if abs_win: return abs_win.group(1).strip()
        
        # 2. Look for "named XXX" or "file XXX" or "at XXX"
        named_match = re.search(r'(?:named|file|at)\s+([\w\./\\]+\.\w+)', text, re.I)
        if named_match: return named_match.group(1).strip()
        
        # 3. Look for anything that looks like a relative path with extension
        rel_match = re.search(r'([\w\./\\]+\.\w+)', text)
        if rel_match: return rel_match.group(1).strip()
        
        return None
