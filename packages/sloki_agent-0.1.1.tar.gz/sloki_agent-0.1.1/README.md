# 🚀 Sloki Agent — Agentic Code Editor

A professional, multi-agent AI system for rule-driven, surgical code editing with autonomous execution support.

## ✨ Features

- **Multi-Agent Pipeline**: Intent → RuleGuard → Planning → Editing → Validation → Walkthrough
- **Surgical Precision**: Only modifies code within `// === EDITABLE ===` blocks
- **Rule Enforcement**: RuleGuard agent blocks modifications to protected files
- **Autonomous Mode**: `--auto` flag for headless, zero-interaction execution from `.md` files
- **Human-in-the-Loop**: Interactive mode with plan approval and code review
- **Comprehensive Setup UI**: Built-in `/config` and `/guide` wizards for seamless API key and local LLM configuration
- **Post-Edit Validation**: Automatic compilation check after code changes
- **Multi-Provider LLM**: Supports LMStudio (local), Gemini, OpenAI, Anthropic
- **Workflow System**: Structured `.md` workflows for repeatable task execution
- **Skills System**: Domain-specific skill definitions with strict boundaries

## 📁 Repository Structure

```text
sloki_agent/
├── agents/              # Specialized AI agents
│   ├── intent_agent.py      # Routes user requests
│   ├── rule_guard_agent.py  # Enforces safety rules
│   ├── planning_agent.py    # Generates implementation plans
│   ├── edit_agent.py        # Generates code modifications
│   ├── walkthrough_agent.py # Final verification reports
│   ├── assistant_agent.py   # Chat/conversation handler
│   └── persona_agent.py     # Custom agent personas
├── core/                # System backbone
│   ├── agent_manager.py     # Thin coordinator (delegates to modules below)
│   ├── config_manager.py    # Project config, file discovery, roles
│   ├── command_handler.py   # All slash command handling
│   ├── pipeline.py          # Core 6-phase execution engine
│   ├── llm_client.py        # Multi-provider LLM client
│   ├── clients/             # Provider-specific implementations
│   └── utils/               # Style, memory manager
├── .agents/             # Agent infrastructure
│   ├── workflows/           # Step-by-step workflow definitions
│   └── skills/              # Domain-specific skill boundaries
├── code_editor/         # Surgical block parser
├── rules/               # Rule engine and configuration
├── validators/          # Post-edit compilation validator
├── prompts/             # LLM prompt templates
├── brain/               # Session persistence
├── docs/                # Documentation
└── src/sloki_agent/cli.py # Entry point (interactive + autonomous)
```

## 🚀 Getting Started

### Interactive Mode

```bash
sloki-agent
```

### Autonomous Mode (No Human Intervention)

```bash
sloki-agent --auto --input requirements.md
sloki-agent --auto --input requirements.md --provider gemini
```

### Provider Selection

```bash
sloki-agent --provider lmstudio   # Local (default)
sloki-agent --provider gemini     # Google Gemini
sloki-agent --provider openai     # OpenAI GPT
sloki-agent --provider anthropic  # Anthropic Claude
```

## 📚 Documentation

- [Architecture Overview](docs/architecture.md)
- [Usage Guide](docs/usage_guide.md)
- [Rule Engine](docs/rules_engine.md)
- [Agent Details](docs/agent_details.md)
- [RAG Strategy](docs/rag_integration.md)
- [Development Guide](docs/development.md)

## 🔧 Configuration

1. Set API keys in `~/.sloki/.env` (copy from `.env.example`) or configure them via the CLI.
2. Run `sloki-agent` for the first-time setup wizard (handles API Keys, Auto Mode, and Project Discovery).
3. Type `/guide` in the CLI for instructions on setting up LM Studio locally.
4. Or use `--auto` mode with a pre-configured `~/.sloki/brain/project_config.md`.
