import pandas as pd
from dataclasses import dataclass
from typing import Optional, List


REQUIRED_COLUMNS = {"type", "strike", "expiry", "price"}
OPTION_TYPES = {"C", "P"}


# ---------- Helpers ----------

def _normalize_option_types(series: pd.Series) -> pd.Series:
    """
    Normalize option type labels to C/P.
    Accepts: call, put, c, p, CE, PE, Call, Put, etc.
    """
    mapping = {
        "call": "C",
        "put": "P",
        "c": "C",
        "p": "P",
        "ce": "C",
        "pe": "P",
    }

    return (
        series.astype(str)
        .str.strip()
        .str.lower()
        .map(mapping)
    )


@dataclass
class OptionChain:
    data: pd.DataFrame
    underlying: Optional[float] = None
    timestamp: Optional[pd.Timestamp] = None

    # ---------- Constructors ----------

    @classmethod
    def from_dataframe(cls, df: pd.DataFrame, underlying=None, timestamp=None):
        df = df.copy()

        df["type"] = _normalize_option_types(df["type"])
        df["expiry"] = pd.to_datetime(df["expiry"])

        cls._validate_schema(df)
        return cls(df, underlying, timestamp)

    @classmethod
    def from_csv(cls, path: str, **kwargs):
        df = pd.read_csv(path)
        return cls.from_dataframe(df, **kwargs)

    @classmethod
    def from_dict(cls, data: dict, **kwargs):
        df = pd.DataFrame(data)
        return cls.from_dataframe(df, **kwargs)

    @classmethod
    def from_nse(cls, json_data: dict):
        from qfinindia.data.nse import parse_nse_chain
        df, underlying, timestamp = parse_nse_chain(json_data)
        return cls.from_dataframe(df, underlying, timestamp)

    # ---------- Validation ----------

    @staticmethod
    def _validate_schema(df: pd.DataFrame):
        missing = REQUIRED_COLUMNS - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        if df["type"].isna().any():
            raise ValueError("Invalid option type values found")

        if not set(df["type"].unique()).issubset(OPTION_TYPES):
            raise ValueError("Option type must normalize to C or P")

    # ---------- Expiry helpers ----------

    def expiries(self) -> List[pd.Timestamp]:
        """
        Return sorted unique expiries in the chain.
        """
        return sorted(self.data["expiry"].unique())

    def default_expiry(self) -> pd.Timestamp:
        """
        Return first expiry in chain.
        """
        exps = self.expiries()
        if len(exps) == 0:
            raise ValueError("No expiries in chain")
        return exps[0]

    # ---------- Filters ----------

    def expiry(self, expiry):
        expiry = pd.to_datetime(expiry)
        return OptionChain(
            self.data[self.data.expiry == expiry],
            self.underlying,
            self.timestamp
        )

    def calls(self, expiry=None):
        df = self.data[self.data.type == "C"]
        if expiry is not None:
            expiry = pd.to_datetime(expiry)
            df = df[df.expiry == expiry]
        return OptionChain(df, self.underlying, self.timestamp)

    def puts(self, expiry=None):
        df = self.data[self.data.type == "P"]
        if expiry is not None:
            expiry = pd.to_datetime(expiry)
            df = df[df.expiry == expiry]
        return OptionChain(df, self.underlying, self.timestamp)

    # ---------- Accessors ----------

    def strikes(self, sort=True):
        k = self.data["strike"].values
        return sorted(k) if sort else k

    def prices(self):
        return self.data["price"].values

    def iv(self):
        if "iv" not in self.data.columns:
            raise ValueError("IV column missing")
        return self.data["iv"].values

    def to_dataframe(self):
        return self.data.copy()
