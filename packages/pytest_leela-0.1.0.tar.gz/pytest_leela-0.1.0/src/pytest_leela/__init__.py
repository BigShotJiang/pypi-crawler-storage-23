"""pytest-leela: Type-aware mutation testing for Python."""

__version__ = "0.1.0"
