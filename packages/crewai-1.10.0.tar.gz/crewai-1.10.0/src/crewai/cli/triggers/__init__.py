"""Triggers command module for CrewAI CLI."""

from crewai.cli.triggers.main import TriggersCommand


__all__ = ["TriggersCommand"]
