"""A2A utility modules for client operations."""
