"""Provider interfaces for extensible crewAI components."""
