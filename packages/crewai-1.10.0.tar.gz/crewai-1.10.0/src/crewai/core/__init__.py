"""Core crewAI components and interfaces."""
