# tracewell-opentelemetry

This is a **placeholder** package to prevent typosquatting.

Official Tracewell Python package: **tracewell**  
- Docs: https://tracewell.edizalic.com  
- GitHub: https://github.com/trace-well