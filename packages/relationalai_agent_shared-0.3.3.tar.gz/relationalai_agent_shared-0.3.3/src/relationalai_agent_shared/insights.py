"""Insight types for agent-skills.

Types for generating business insights and analytical questions from semantic models.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class InsightIdea(BaseModel):
    """Business insight question generated from model analysis.

    Represents a potentially valuable question that can be answered
    using the available model data.
    """

    subjects: list[str] = Field(
        description="Entity IDs this question relates to, in descending order of relevance"
    )
    question: str = Field(
        description="Natural language question that drives business value"
    )
