"""Canonical table types for agent-skills.

Types for generating canonical views/tables from semantic model concepts.
"""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field

# TODO: This implements its own mini tasks - should update to use new, shared task system instead.
# Type aliases for clarity and reuse
DataType = Literal["string", "integer", "float", "boolean", "date", "timestamp", "uuid"]
Aggregation = Literal[
    "sum", "avg", "min", "max", "count", "count_distinct", "any", "approx_distinct"
]
TimeGrain = Literal[
    "second", "minute", "hour", "day", "week", "month", "quarter", "year"
]
JoinType = Literal["inner", "left", "right", "full"]
ScopeType = Literal["global", "metric", "field"]
FocusHint = Literal["raw", "aggregated"]


class ViewType(str, Enum):
    """Types of canonical views that can be generated."""

    CANONICAL = "canonical"
    SUBSET = "subset"
    GROUP_BY = "group_by"
    TIME = "time"
    RANKING = "ranking"


class SourceRef(BaseModel):
    """Reference to a source table."""

    name: str = Field(description="Human label for the source")
    schema_: str | None = Field(
        None,
        alias="schema",
        description="Optional schema/database",
    )
    table: str = Field(description="Physical table or view name")
    alias: str | None = Field(None, description="Default alias used in SQL")


class FilterSpec(BaseModel):
    """Filter specification for canonical views."""

    predicate: str = Field(description="SQL predicate string")
    applies_to: ScopeType = Field("global", description="Scope of the filter")
    target: str | None = Field(None, description="Metric or field name when scoped")


class FieldSpec(BaseModel):
    """Field specification for canonical views."""

    name: str = Field(description="Output column name")
    expr: str = Field(description="SQL expression or source column")
    data_type: DataType = Field(description="Logical data type")
    label: str | None = Field(None, description="Readable label")
    description: str | None = Field(None, description="What the column represents")
    is_dimension: bool = Field(True, description="True if groupable")
    time_grain: TimeGrain | None = Field(None, description="Applied grain if temporal")
    format_hint: str | None = Field(
        None, description="Display hint like currency/percent"
    )


class MetricSpec(BaseModel):
    """Metric specification for canonical views."""

    name: str = Field(description="Metric name")
    label: str | None = Field(None, description="Readable label")
    description: str | None = Field(None, description="What the metric represents")
    agg: Aggregation = Field(description="Aggregation function")
    expr: str = Field(description="SQL expression to aggregate")
    filter: FilterSpec | None = Field(None, description="Optional metric-level filter")
    window: str | None = Field(None, description="Optional window clause")


class RelationshipSpec(BaseModel):
    """Relationship specification for joins in canonical views."""

    left: str = Field(description="Left-side alias (e.g., orders)")
    right: str = Field(description="Right-side alias (e.g., customers)")
    join_type: JoinType = Field("inner", description="Join type")
    on: str = Field(description="SQL ON predicate")


class CanonicalIdea(BaseModel):
    """LLM-generated idea for a canonical view.

    Result of the field picker phase - describes what columns and metrics
    should be included in the canonical view.
    """

    short_name: str = Field(
        description="Concise handle (snake or kebab case acceptable)"
    )
    long_name: str = Field(description="Readable name for users")
    description: str = Field(description="What the rows represent")
    source: SourceRef = Field(description="Primary table/view for FROM")
    fields: list[FieldSpec] = Field(
        default_factory=list,
        description="Output dimensions and non-aggregated columns",
    )
    metrics: list[MetricSpec] = Field(
        default_factory=list, description="Aggregation kernels"
    )
    relationships: list[RelationshipSpec] = Field(
        default_factory=list, description="Required joins"
    )
    filters: list[FilterSpec] = Field(
        default_factory=list, description="Global default filters"
    )


class DisplayNameMapping(BaseModel):
    """Mapping from SQL column name to display name.

    Display names should be:
    - Concise (1-3 words)
    - Title Case
    - Replace underscores with spaces
    - Ordered by business value
    - Non-human-readable identifiers (GUIDs, auto-increment IDs) placed last
    - Human-readable identifiers (slugs, codes) may appear earlier if useful
    """

    source: str = Field(description="Raw column name from SQL")
    display: str = Field(description="User-friendly display name")


class CanonicalTableSQL(BaseModel):
    """LLM-generated SQL for a canonical view.

    Result of the SQL generator phase - executable SQL with metadata.
    SQL should include explicit ORDER BY and LIMIT for preview.
    """

    sql: str = Field(description="The complete SQL query with ORDER BY and LIMIT")
    columns: list[str] = Field(
        default_factory=list, description="Column names projected by the query"
    )
    display_names: list[DisplayNameMapping] = Field(
        default_factory=list,
        description="Display name mappings ordered by business value",
    )


class CanonicalTableDescriptor(BaseModel):
    """Final canonical table descriptor with validated SQL.

    This is the complete result of the canonical table generation pipeline.
    """

    id: str = Field(description="Stable identifier (concept_id-short_name)")
    concept_id: str = Field(description="ID of the concept this table describes")
    long_name: str = Field(description="Human friendly full name")
    description: str = Field(description="Brief explanation of what the rows represent")
    canonical_idea: CanonicalIdea | None = Field(
        default=None, description="Canonical idea originating this table"
    )
    sql: str = Field(description="Executable SELECT statement")
    columns: list[str] = Field(
        default_factory=list, description="Column names projected by the SQL"
    )
    display_names: list[DisplayNameMapping] = Field(
        default_factory=list, description="Display name mappings"
    )
