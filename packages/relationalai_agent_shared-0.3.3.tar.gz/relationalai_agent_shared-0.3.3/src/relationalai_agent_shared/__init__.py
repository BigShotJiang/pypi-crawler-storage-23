"""Shared types and contracts for the agent API.

This package contains result types and other shared contracts used across:
- agent-skills (implementation)
- model-server (orchestration)
- agent-client-sdk (public API)

This module implements shared result types and contracts for the agent-api.
"""

from .events import (
    ErrorEvent,
    ExecuteCodeEvent,
    PlanEvent,
    ResultEvent,
    StatusEvent,
    StreamEvent,
    StreamEventType,
    TaskEndEvent,
    TaskStartEvent,
)
from .ecs import (
    AgentContextItem,
    Interpretation,
    ModelFragment,
    QueryPlan,
)
from .request import AskRequest, CapabilityConfig, Quotas
from .results import (
    CodeGenerationResult,
    DataResult,
    InsufficientResult,
    InterpretationResult,
    ProseResult,
    ProseSegment,
    QueryPlanResult,
    Result,
)
from .canonical import (
    CanonicalIdea,
    CanonicalTableDescriptor,
    CanonicalTableSQL,
    DisplayNameMapping,
    FieldSpec,
    FilterSpec,
    MetricSpec,
    RelationshipSpec,
    SourceRef,
    ViewType,
)
from .insights import InsightIdea

__version__ = "0.1.0"

__all__ = [
    # Request types
    "AskRequest",
    "CapabilityConfig",
    "Quotas",
    # Event types
    "StreamEvent",
    "StreamEventType",
    "PlanEvent",
    "TaskStartEvent",
    "TaskEndEvent",
    "ResultEvent",
    "ErrorEvent",
    "StatusEvent",
    "ExecuteCodeEvent",
    # Result types
    "CodeGenerationResult",
    "DataResult",
    "InsufficientResult",
    "Interpretation",
    "InterpretationResult",
    "ProseResult",
    "ProseSegment",
    "QueryPlan",
    "QueryPlanResult",
    "Result",
    # ECS types
    "AgentContextItem",
    "ModelFragment",
    # Canonical table types
    "CanonicalIdea",
    "CanonicalTableDescriptor",
    "CanonicalTableSQL",
    "DisplayNameMapping",
    "FieldSpec",
    "FilterSpec",
    "MetricSpec",
    "RelationshipSpec",
    "SourceRef",
    "ViewType",
    # Insight types
    "InsightIdea",
]
