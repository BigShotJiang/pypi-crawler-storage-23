"""Built-in relation singletons.

All relation class definitions and singleton instances in one place.
Components access relation data through the singleton instances.

Example:
    from relationalai_agent_shared.ecs import builtins

    # Access relation data via RowProxy
    name = builtins.name[eid].value
    builtins.description[eid].value = "A customer"
"""

import logging
import traceback
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic.alias_generators import to_camel
from .base import BaseRelation, BuiltinRelation
from .task_body import TaskItem
from .proxy import per_model
from .query import (
    AggregateQueryStep,
    ComputeQueryStep,
    FilterQueryStep,
    GetQueryStep,
    JoinQueryStep,
    VisualizationSpec,
)

# Import canonical types from agent-shared
from relationalai_agent_shared.canonical import (
    CanonicalIdea,
    SourceRef,
    FieldSpec,
    MetricSpec,
    FilterSpec,
    RelationshipSpec,
    DisplayNameMapping,
    ViewType,
    DataType,
    Aggregation,
    TimeGrain,
    JoinType,
    ScopeType,
)

# ============================================================================
# Data Types (stored in relations)
# ============================================================================
# TODO: Should we get rid of these entirely? Consider if these should be
# entities with eids, or if simple structs are appropriate for ECS.


class TaskStatus(str, Enum):
    """Task execution status and data freshness (unified field).

    State machine flow:
    UNSTARTED → QUEUED → RUNNING → FRESH → STALE → (back to QUEUED)
                            ↓
                         FAILED
    """

    UNSTARTED = "unstarted"  # Never executed
    QUEUED = "queued"  # Scheduled to run
    RUNNING = "running"  # Currently executing
    FRESH = "fresh"  # Completed successfully, data is current
    STALE = "stale"  # Completed successfully, but data is out of tolerance
    FAILED = "failed"  # Last execution failed


class Column(BaseModel):
    """A column in a source table with full Snowflake metadata."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    name: str = Field(description="Column name")
    type: str = Field(description="SQL Data type")
    ordinal_position: int | None = Field(
        default=None, description="Column position in table"
    )
    is_nullable: bool | None = Field(
        default=None, description="Whether column can contain NULL values"
    )
    column_default: str | None = Field(default=None, description="Default value")
    numeric_precision: int | None = Field(
        default=None, description="Numeric precision for numeric types"
    )
    numeric_scale: int | None = Field(
        default=None, description="Numeric scale for numeric types"
    )
    numeric_precision_radix: int | None = Field(
        default=None, description="Radix of numeric precision"
    )
    character_maximum_length: int | None = Field(
        default=None, description="Max length for character types"
    )
    datetime_precision: int | None = Field(
        default=None, description="Precision for datetime types"
    )
    comment: str | None = Field(
        default=None, description="Column-level documentation from schema"
    )
    is_identity: bool | None = Field(
        default=None, description="Whether column is an identity/auto-increment column"
    )


class ConceptKey(BaseModel):
    """Maps a concept to a source table via key columns."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    source_eid: UUID = Field(description="EID of the Source entity")
    columns: list[str] = Field(description="Column names used to identify/join")


class Reading(BaseModel):
    """Linguistic template for describing a relationship from a concept's perspective."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    owner: str = Field(description="Concept eid (owner of this reading)")
    parts: list[str | int] = Field(
        description="Template parts: alternating static text and field indices"
    )


_relation_field_logger = logging.getLogger(__name__ + ".RelationField")


def _caller_location(
    skip_filenames: tuple[str, ...] = ("pydantic", "builtins.py"),
) -> str:
    """Return a ' at file:line' string for the first external caller, or '' if not found."""
    stack = traceback.extract_stack(limit=12)
    caller = next(
        (
            f
            for f in reversed(stack)
            if not any(s in f.filename for s in skip_filenames)
        ),
        None,
    )
    return f" at {caller.filename}:{caller.lineno}" if caller else ""


class RelationField(BaseModel):
    """A field in a relation (relationship).

    After normalization, ``type`` must always be a UUID string — either a concept
    eid or a builtin scalar type eid (``00000001-`` prefix).  A validator warns
    on non-UUID values so we catch normalization gaps early.
    """

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    name: str = Field(description="Field name")
    type: str = Field(
        description="Field type — must be a UUID (concept eid or builtin type eid)"
    )

    @model_validator(mode="after")
    def _normalize_non_uuid_type(self) -> "RelationField":
        from .builtin_types import SCALAR_TYPE_UNKNOWN

        try:
            UUID(self.type)
        except ValueError:
            # Auto-fix bare strings to Unknown sentinel so the model is
            # structurally valid. This covers old persisted data and any
            # other path that hasn't been normalized yet.
            _relation_field_logger.warning(
                "RelationField(%s).type is not a UUID: %r → Unknown%s",
                self.name,
                self.type,
                _caller_location(),
            )
            self.type = str(SCALAR_TYPE_UNKNOWN)
        return self


class Capability(BaseModel):
    """A capability required to use a relation."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    name: str = Field(description="Capability name")


class Annotation(BaseModel):
    """Annotation providing compiler hints about how to treat entities."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    name: str = Field(description="Annotation name")
    value: str | None = Field(default=None, description="Optional annotation value")


# ----------------------------------------------------------------------------
# SourceAnalysis data types
# ----------------------------------------------------------------------------


class ColumnAnalysisData(BaseModel):
    """Analysis metadata for a single column."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    humanized_name: str = Field(description="Humanized column name")
    importance: float = Field(ge=0.0, le=1.0, description="Business importance score")
    pkey_probability: float = Field(
        ge=0.0, le=1.0, description="Probability this is a primary key"
    )
    fkey_probability: float = Field(
        ge=0.0, le=1.0, description="Probability this is a foreign key"
    )


class ForeignKeyRef(BaseModel):
    """Reference to a foreign key target."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    target_source_eid: UUID = Field(description="EID of the target source entity")
    target_column: str = Field(description="Column name in the target source")


class UnifyRef(BaseModel):
    """Reference to a soft-join target."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    target_source_eid: UUID = Field(description="EID of the target source entity")
    target_column: str = Field(description="Column name in the target source")


# ----------------------------------------------------------------------------
# Search/Task data types
# ----------------------------------------------------------------------------


class SearchPresentationData(BaseModel):
    """UI presentation hints for search results."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    label: str | None = Field(default=None, description="Display label for the search")
    question_summary: str | None = Field(
        default=None, description="Summary of the question"
    )
    answer_summary_hint: str | None = Field(
        default=None, description="Hint for answer summary"
    )
    answer_summary: str | None = Field(default=None, description="Final answer summary")


class InterpretationSpan(BaseModel):
    """Character offsets into original query text."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    start: int = Field(description="Beginning character offset")
    end: int = Field(description="Ending character offset")
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence in this span")


class InterpretationEntity(BaseModel):
    """Entity reference in an interpretation."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    type: str = Field(description="Entity type: concept, relationship, or source")
    id: str = Field(description="Entity ID (UUID or FQN)")
    fields: list[str] | None = Field(
        default=None, description="Specific fields referenced"
    )
    columns: list[str] | None = Field(
        default=None, description="Specific columns referenced"
    )


class InterpretationInstance(BaseModel):
    """Variable instance in an interpretation."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    name: str = Field(description="Unique variable name")
    entity: InterpretationEntity = Field(
        description="What entity this is an instance of"
    )
    reference_type: str = Field(description="explicit, implicit, or helpful")
    spans: list[InterpretationSpan] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence in this instance")


class InterpretationData(BaseModel):
    """NLP interpretation of a search query."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    description: str = Field(description="Concise description of the interpretation")
    label: str | None = Field(
        default=None, description="Short 2-4 word navigation label"
    )
    instances: dict[str, InterpretationInstance] = Field(
        description="Variable instances"
    )
    paths: list[list[str]] = Field(description="Instance arrangement paths")
    confidence: float = Field(ge=0.0, le=1.0, description="Overall confidence")


# Step type aliases — same classes as ecs.query, re-exported under legacy names
# so existing code (e.g. migration.py) that imports GetStep, JoinStep, etc.
# from builtins continues to work without changes.
GetStep = GetQueryStep
JoinStep = JoinQueryStep
FilterStep = FilterQueryStep
ComputeStep = ComputeQueryStep
AggregateStep = AggregateQueryStep

# Discriminated union of all step types
QueryPlanStep = (
    GetQueryStep
    | JoinQueryStep
    | FilterQueryStep
    | ComputeQueryStep
    | AggregateQueryStep
)


class QueryPlanData(BaseModel):
    """Logical query plan with steps."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    steps: list[QueryPlanStep] = Field(description="Query execution steps")
    project: list[str] = Field(description="Variables to project in result")
    subjects: list[UUID] = Field(description="Core entities for this query")
    related: list[UUID] = Field(description="Tangentially relevant entities")
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence in plan")
    visualization: "VisualizationSpec | None" = Field(
        default=None,
        description="VisualizationSpec, persisted from QueryPlan for page-reload scenarios",
    )


class SQLQueryData(BaseModel):
    """Generated SQL query."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    type: str = Field(default="sql", description="Query type: sql or rejected")
    sql: str | None = Field(default=None, description="SQL text if successful")
    reason: str | None = Field(default=None, description="Rejection reason if rejected")
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence in SQL")


# ============================================================================
# Relation Class Definitions
# ============================================================================


@per_model
class Name(BuiltinRelation):
    """Stores entity names."""

    value: list[str] = Field(default_factory=list)


@per_model
class Description(BuiltinRelation):
    """Stores entity descriptions."""

    value: list[str] = Field(default_factory=list)


@per_model
class ParentTypes(BuiltinRelation):
    """Stores parent types (super types) for concepts."""

    parent_eids: list[list[UUID]] = Field(default_factory=list)


@per_model
class Annotations(BuiltinRelation):
    """Stores annotations for entities."""

    value: list[list[Annotation]] = Field(default_factory=list)


@per_model
class Capabilities(BuiltinRelation):
    """Stores required capabilities for relationships."""

    value: list[list[Capability]] = Field(default_factory=list)


@per_model
class Fields(BuiltinRelation):
    """Stores field definitions for relationships."""

    value: list[list[RelationField]] = Field(default_factory=list)


@per_model
class Overloads(BuiltinRelation):
    """Stores which relationships this relationship overloads."""

    value: list[list[UUID]] = Field(default_factory=list)


@per_model
class FQN(BuiltinRelation):
    """Stores fully qualified names for source tables."""

    value: list[str] = Field(default_factory=list)


@per_model
class Database(BuiltinRelation):
    """Stores database names for source tables."""

    value: list[str] = Field(default_factory=list)


@per_model
class Schema(BuiltinRelation):
    """Stores schema names for source tables."""

    value: list[str] = Field(default_factory=list)


@per_model
class TableName(BuiltinRelation):
    """Stores table names for source tables."""

    value: list[str] = Field(default_factory=list)


@per_model
class Columns(BuiltinRelation):
    """Stores column definitions for source tables."""

    value: list[list[Column]] = Field(default_factory=list)


# ----------------------------------------------------------------------------
# SourceAnalysis relations
# NOTE: Reuses existing builtins.name and builtins.description for name/description
# ----------------------------------------------------------------------------


@per_model
class ColumnAnalyses(BuiltinRelation):
    """Column-level analysis metadata."""

    value: list[dict[str, ColumnAnalysisData]] = Field(default_factory=list)


@per_model
class InferredPrimaryKeys(BuiltinRelation):
    """Primary keys inferred by LLM analysis"""

    value: list[list[str]] = Field(default_factory=list)


@per_model
class InferredForeignKeys(BuiltinRelation):
    """Foreign keys inferred by LLM analysis"""

    value: list[dict[str, ForeignKeyRef]] = Field(default_factory=list)


@per_model
class InferredUnifyRelationships(BuiltinRelation):
    """Soft-join (unify) relationships inferred by LLM analysis"""

    value: list[dict[str, list[UnifyRef]]] = Field(default_factory=list)


# ----------------------------------------------------------------------------
# Task relations
# ----------------------------------------------------------------------------


@per_model
class TaskConsumes(BuiltinRelation):
    """Input entity IDs consumed by this task."""

    value: list[list[UUID]] = Field(default_factory=list)


@per_model
class TaskProduces(BuiltinRelation):
    """Output entity IDs produced by this task."""

    value: list[list[UUID]] = Field(default_factory=list)


@per_model
class TaskLayer(BuiltinRelation):
    """Processing layer: logical or physical."""

    value: list[str] = Field(default_factory=list)  # "logical" or "physical"


@per_model
class TaskCreatedBy(BuiltinRelation):
    """Who/what created this task."""

    value: list[str] = Field(default_factory=list)


@per_model
class TaskCreatedAt(BuiltinRelation):
    """When the task was created."""

    value: list[str] = Field(default_factory=list)  # ISO datetime string


@per_model
class TaskModifiedAt(BuiltinRelation):
    """When the task was last modified."""

    value: list[str] = Field(default_factory=list)  # ISO datetime string


@per_model
class TaskImplementation(BuiltinRelation):
    """Python class name for task implementation (discriminator for subclasses)."""

    value: list[str] = Field(default_factory=list)  # e.g. "Task", "TestDataTask"


@per_model
class SQLTaskQuery(BuiltinRelation):
    """The SQL query string for SQLTask execution."""

    value: list[str] = Field(default_factory=list)


@per_model
class SQLTaskTargetRelation(BuiltinRelation):
    """The target relation ID for SQLTask results."""

    value: list[UUID | None] = Field(default_factory=list)


@per_model
class DSLTaskCode(BuiltinRelation):
    """The PyRel DSL code for DSLTask execution."""

    value: list[str] = Field(default_factory=list)


@per_model
class TaskBody(BuiltinRelation):
    """Metamodel task body (TaskItem tree). Persistence adapter handles serialization."""

    value: list[TaskItem] = Field(default_factory=list)


# NOTE: No equivalent DSLTaskTargetRelation because the SQLTaskTargetRelation is already deprecated, and both are served via the generic TaskProduces


@per_model
class DynamicRelationAvailableCardinality(BuiltinRelation):
    """Number of rows actually fetched and stored in DynamicRelation."""

    value: list[int] = Field(default_factory=list)


@per_model
class DynamicRelationTotalCardinality(BuiltinRelation):
    """Total row count from COUNT(*) OVER() - full dataset size."""

    value: list[int] = Field(default_factory=list)


@per_model
class DynamicRelationVisualization(BuiltinRelation):
    """Visualization spec for DynamicRelation query results."""

    value: list[VisualizationSpec] = Field(default_factory=list)


@per_model
class TaskStatusRelation(BuiltinRelation):
    """Execution status for tasks (pending/running/completed/failed)."""

    status: list[str] = Field(default_factory=list)  # TaskStatus enum values


@per_model
class TaskLastUpdatedRelation(BuiltinRelation):
    """Last update timestamp for tasks (when status changed)."""

    timestamp: list[str] = Field(default_factory=list)  # ISO datetime string


@per_model
class TaskFailureMessage(BuiltinRelation):
    """Error message when task execution fails."""

    value: list[str] = Field(default_factory=list)


# ----------------------------------------------------------------------------
# Search relations
# ----------------------------------------------------------------------------


@per_model
class SearchQuery(BuiltinRelation):
    """The user's search query text."""

    value: list[str] = Field(default_factory=list)


@per_model
class SearchStep(BuiltinRelation):
    """Current execution step/status."""

    value: list[str] = Field(default_factory=list)


@per_model
class SearchSubjects(BuiltinRelation):
    """Related entity subjects."""

    value: list[list[UUID]] = Field(default_factory=list)


@per_model
class SearchInterpretations(BuiltinRelation):
    """NLP interpretations of the query."""

    value: list[list[InterpretationData]] = Field(default_factory=list)


@per_model
class SearchQueryPlan(BuiltinRelation):
    """Query plan from search execution."""

    value: list[QueryPlanData] = Field(default_factory=list)


@per_model
class SearchSqlQuery(BuiltinRelation):
    """Generated SQL query."""

    value: list[SQLQueryData] = Field(default_factory=list)


@per_model
class SearchTimings(BuiltinRelation):
    """Performance timings for each step (milliseconds)."""

    value: list[dict[str, int]] = Field(default_factory=list)


@per_model
class SearchFailureMessage(BuiltinRelation):
    """Error message if search failed."""

    value: list[str] = Field(default_factory=list)


@per_model
class SearchStepHistory(BuiltinRelation):
    """Historical record of execution steps."""

    value: list[list[str]] = Field(default_factory=list)


@per_model
class SearchPresentation(BuiltinRelation):
    """UI rendering hints."""

    value: list[SearchPresentationData] = Field(default_factory=list)


# ----------------------------------------------------------------------------
# CanonicalTable relations
# ----------------------------------------------------------------------------


@per_model
class CanonicalTableConcept(BuiltinRelation):
    """Concept EID that this canonical table describes."""

    value: list[UUID] = Field(default_factory=list)


@per_model
class CanonicalTableViewType(BuiltinRelation):
    """View type: canonical, subset, group_by, time, or ranking."""

    value: list[str] = Field(default_factory=list)


@per_model
class CanonicalTableLongName(BuiltinRelation):
    """Human-friendly full name for the canonical table."""

    value: list[str] = Field(default_factory=list)


@per_model
class CanonicalTableSql(BuiltinRelation):
    """Executable SQL SELECT statement for the canonical table."""

    value: list[str] = Field(default_factory=list)


@per_model
class CanonicalTableColumns(BuiltinRelation):
    """Column names projected by the SQL query."""

    value: list[list[str]] = Field(default_factory=list)


@per_model
class CanonicalTableDisplayNames(BuiltinRelation):
    """Display name mappings for columns."""

    value: list[list[DisplayNameMapping]] = Field(default_factory=list)


@per_model
class CanonicalTableIdea(BuiltinRelation):
    """Canonical idea (field picker result) for traceability."""

    value: list[CanonicalIdea] = Field(default_factory=list)


@per_model
class CanonicalTableRationale(BuiltinRelation):
    """Why this view is useful to analysts."""

    value: list[str] = Field(default_factory=list)


@per_model
class CanonicalTableCreatedAt(BuiltinRelation):
    """Creation timestamp (ISO format)."""

    value: list[str] = Field(default_factory=list)


@per_model
class CanonicalTableDataRelation(BuiltinRelation):
    """Reference to the data relation ID for canonical table results.

    Points to a RelationData instance that holds the actual query results.
    This indirection allows SQLTask to populate a separate data relation.
    """

    value: list[UUID] = Field(default_factory=list)


@per_model
class RelationshipDataRelation(BuiltinRelation):
    """Reference to the data relation ID for relationship query results.

    Points to a RelationData instance that holds the SQL query results for
    identity/link/property relationships. SQLTask executes SELECT DISTINCT
    on source tables to populate these relations.
    """

    value: list[UUID] = Field(default_factory=list)


@per_model
class SourceDataRelation(BuiltinRelation):
    """Reference to the data relation ID for source preview results.

    Points to a RelationData instance that holds source table preview data
    (SELECT * LIMIT 100). SQLTask executes preview queries to populate these.
    """

    value: list[UUID] = Field(default_factory=list)


# ----------------------------------------------------------------------------
# Generic data storage for query results
# ----------------------------------------------------------------------------


# DynamicColumns has been removed - replaced by DynamicRelation extending BaseRelation
# Each DynamicRelation instance now has its own UUID-based ID and file on disk
# instead of all being stored in a centralized DynamicColumns relation


# ----------------------------------------------------------------------------
# Concept-specific relations
# ----------------------------------------------------------------------------


@per_model
class ConceptKeys(BuiltinRelation):
    """Authoritative source mappings for concepts (identity keys)."""

    value: list[list[ConceptKey]] = Field(default_factory=list)


## TODO: ConceptJoins may be removable - currently barely used. Test during model porting to verify if it's needed or if migration would be lossy.
@per_model
class ConceptJoins(BuiltinRelation):
    """Non-authoritative source mappings for concepts (joinable but not identity)."""

    value: list[list[ConceptKey]] = Field(default_factory=list)


# ----------------------------------------------------------------------------
# Relationship-specific relations
# ----------------------------------------------------------------------------

## NOTE: RelationshipType is derived, not stored. See Relationship.type property.


@per_model
class Identifies(BuiltinRelation):
    """Stores which concept a relationship identifies (for identity relationships)."""

    value: list[UUID] = Field(default_factory=list)


@per_model
class CardinalityGroups(BuiltinRelation):
    """Stores cardinality group labels for relationship fields."""

    value: list[list[str]] = Field(default_factory=list)


@per_model
class RelationshipSource(BuiltinRelation):
    """Stores source table eid for relationships."""

    value: list[UUID] = Field(default_factory=list)


@per_model
class Readings(BuiltinRelation):
    """Stores reading templates for relationships."""

    value: list[list[Reading]] = Field(default_factory=list)


## TODO: Analysis metadata (confidence, importance, rationale) removed pending proper Analysis component redesign.


# ============================================================================
# Singleton Instances
# ============================================================================

# ============================================================================
# Identity Relations (type markers)
# ============================================================================


@per_model
class ConceptType(BuiltinRelation):
    """Marks an entity as a Concept."""

    pass  # No additional columns - presence indicates type


@per_model
class RelationshipType(BuiltinRelation):
    """Marks an entity as a Relationship."""

    pass


@per_model
class SourceType(BuiltinRelation):
    """Marks an entity as a Source."""

    pass


@per_model
class SourceAnalysisType(BuiltinRelation):
    """Marks an entity as a SourceAnalysis."""

    pass


@per_model
class SearchType(BuiltinRelation):
    """Marks an entity as a Search."""

    pass


@per_model
class TaskType(BuiltinRelation):
    """Marks an entity as a Task."""

    pass


@per_model
class CanonicalTableType(BuiltinRelation):
    """Marks an entity as a CanonicalTable."""

    pass


@per_model
class DynamicRelationType(BuiltinRelation):
    """Entity type marker for DynamicRelation instances.

    NOTE: Will fix this inversion in a future PR. For now, to be compatible
    with existing patterns, this must extend BaseRelation.
    """

    pass


# ============================================================================
# Singleton Instances
# ============================================================================
# NOTE: With @per_model decorator, the decorated classes (Name, Description, etc.)
# are actually RelationProxy subclasses of the decorated class. The decorator creates
# a singleton at import time and transparently manages dispatching to the underlying
# BaseRelation instance for the given model.

# Identity relations
concept_type = ConceptType()
relationship_type = RelationshipType()
source_type = SourceType()
source_analysis_type = SourceAnalysisType()
search_type = SearchType()
task_type = TaskType()
canonical_table_type = CanonicalTableType()
dynamic_relation_type = DynamicRelationType()

# Shared relations (used by multiple components)
name = Name()
description = Description()
annotations = Annotations()

# Concept relations
parent_types = ParentTypes()
concept_keys = ConceptKeys()
concept_joins = ConceptJoins()

# Relationship relations
fields = Fields()
capabilities = Capabilities()
overloads = Overloads()
identifies = Identifies()
cardinality_groups = CardinalityGroups()
relationship_source = RelationshipSource()
readings = Readings()

# Source relations
fqn = FQN()
database = Database()
schema = Schema()
table_name = TableName()
columns = Columns()

# SourceAnalysis relations
column_analyses = ColumnAnalyses()
inferred_primary_keys = InferredPrimaryKeys()
inferred_foreign_keys = InferredForeignKeys()
inferred_unify_relationships = InferredUnifyRelationships()

# Task relations
task_consumes = TaskConsumes()
task_produces = TaskProduces()
task_layer = TaskLayer()
task_created_by = TaskCreatedBy()
task_created_at = TaskCreatedAt()
task_modified_at = TaskModifiedAt()
task_implementation = TaskImplementation()
sql_task_query = SQLTaskQuery()
sql_task_target_relation = SQLTaskTargetRelation()
dsl_task_code = DSLTaskCode()
task_body = TaskBody()
dynamic_relation_available_cardinality = DynamicRelationAvailableCardinality()
dynamic_relation_total_cardinality = DynamicRelationTotalCardinality()
dynamic_relation_visualization = DynamicRelationVisualization()
task_status = TaskStatusRelation()
task_last_updated = TaskLastUpdatedRelation()
task_failure_message = TaskFailureMessage()

# Search relations
search_query = SearchQuery()
search_step = SearchStep()
search_subjects = SearchSubjects()
search_interpretations = SearchInterpretations()
search_query_plan = SearchQueryPlan()
search_sql_query = SearchSqlQuery()
search_timings = SearchTimings()
search_failure_message = SearchFailureMessage()
search_step_history = SearchStepHistory()
search_presentation = SearchPresentation()

# CanonicalTable relations
canonical_table_concept = CanonicalTableConcept()
canonical_table_view_type = CanonicalTableViewType()
canonical_table_long_name = CanonicalTableLongName()
canonical_table_sql = CanonicalTableSql()
canonical_table_columns = CanonicalTableColumns()
canonical_table_display_names = CanonicalTableDisplayNames()
canonical_table_idea = CanonicalTableIdea()
canonical_table_rationale = CanonicalTableRationale()
canonical_table_created_at = CanonicalTableCreatedAt()
canonical_table_data_relation = CanonicalTableDataRelation()
relationship_data_relation = RelationshipDataRelation()
source_data_relation = SourceDataRelation()

# Generic data storage (DynamicColumns) has been removed
# Use DynamicRelation instances directly instead


from .builtin_types import (  # noqa: E402
    BUILTIN_SCALAR_TYPES,
    SCALAR_TYPE_BOOL,
    SCALAR_TYPE_DATE,
    SCALAR_TYPE_DATETIME,
    SCALAR_TYPE_FLOAT,
    SCALAR_TYPE_INT,
    SCALAR_TYPE_STRING,
    SCALAR_TYPE_UNKNOWN,
    builtin_eid_to_pyrel_name,
    is_primitive_type_eid,
    decimal_type_eid,
    get_decimal_params,
    is_decimal_type_eid,
    sql_type_to_type_eid,
)


def clear_all_builtins() -> None:
    """Clear all builtin relation data for the active model.

    Resets all relation arrays to empty state. Used for test cleanup
    to ensure fresh state between test runs.

    Requires active model context. Clears the active model's relation instances.
    """
    import sys

    current_module = sys.modules[__name__]
    for name in dir(current_module):
        obj = getattr(current_module, name)
        # @per_model decorated relations are BaseRelation instances (proxy singletons)
        if isinstance(obj, BaseRelation):
            obj.clear()


__all__ = [
    # Functions
    "clear_all_builtins",
    "builtin_eid_to_pyrel_name",
    "sql_type_to_type_eid",
    "decimal_type_eid",
    "is_decimal_type_eid",
    "get_decimal_params",
    # Scalar type UUIDs
    "SCALAR_TYPE_STRING",
    "SCALAR_TYPE_INT",
    "SCALAR_TYPE_FLOAT",
    "SCALAR_TYPE_BOOL",
    "SCALAR_TYPE_DATE",
    "SCALAR_TYPE_DATETIME",
    "SCALAR_TYPE_UNKNOWN",
    "BUILTIN_SCALAR_TYPES",
    "is_primitive_type_eid",
    # Data types
    "Column",
    "ConceptKey",
    "Reading",
    "RelationField",
    "Capability",
    "Annotation",
    # Canonical types (imported from agent-shared)
    "CanonicalIdea",
    "SourceRef",
    "FieldSpec",
    "MetricSpec",
    "FilterSpec",
    "RelationshipSpec",
    "DisplayNameMapping",
    "ViewType",
    "DataType",
    "Aggregation",
    "TimeGrain",
    "JoinType",
    "ScopeType",
    # Search/Task data types
    "SearchPresentationData",
    "InterpretationSpan",
    "InterpretationEntity",
    "InterpretationInstance",
    "InterpretationData",
    "GetStep",
    "JoinStep",
    "FilterStep",
    "ComputeStep",
    "AggregateStep",
    "QueryPlanStep",
    "QueryPlanData",
    "SQLQueryData",
    # Identity relations
    "concept_type",
    "relationship_type",
    "source_type",
    "source_analysis_type",
    "search_type",
    "task_type",
    "canonical_table_type",
    "dynamic_relation_type",
    # Shared relations
    "name",
    "description",
    "annotations",
    # Concept relations
    "parent_types",
    "concept_keys",
    "concept_joins",
    # Relationship relations
    "fields",
    "capabilities",
    "overloads",
    "identifies",
    "cardinality_groups",
    "relationship_source",
    "readings",
    # Source relations
    "fqn",
    "database",
    "schema",
    "table_name",
    "columns",
    # SourceAnalysis relations
    "column_analyses",
    "inferred_primary_keys",
    "inferred_foreign_keys",
    "inferred_unify_relationships",
    # Task relations
    "TaskStatus",
    "task_consumes",
    "task_produces",
    "task_layer",
    "task_created_by",
    "task_created_at",
    "task_modified_at",
    "task_implementation",
    "sql_task_query",
    "sql_task_target_relation",
    "dsl_task_code",
    "task_body",
    "dynamic_relation_available_cardinality",
    "dynamic_relation_total_cardinality",
    "dynamic_relation_visualization",
    "task_status",
    "task_last_updated",
    "task_failure_message",
    # Search relations
    "search_query",
    "search_step",
    "search_subjects",
    "search_interpretations",
    "search_query_plan",
    "search_sql_query",
    "search_timings",
    "search_failure_message",
    "search_step_history",
    "search_presentation",
    # CanonicalTable relations
    "canonical_table_concept",
    "canonical_table_view_type",
    "canonical_table_long_name",
    "canonical_table_sql",
    "canonical_table_columns",
    "canonical_table_display_names",
    "canonical_table_idea",
    "canonical_table_rationale",
    "canonical_table_created_at",
    "canonical_table_data_relation",
    "relationship_data_relation",
    "source_data_relation",
    # Generic data storage (DynamicColumns removed - use DynamicRelation instead)
    # Misc source data
    "ColumnAnalysisData",
    "ForeignKeyRef",
    "UnifyRef",
]
