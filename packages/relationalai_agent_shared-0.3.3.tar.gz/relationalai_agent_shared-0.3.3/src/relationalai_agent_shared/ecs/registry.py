"""Relation registry for lookup by ID.

Auto-populated by @per_model decorator during module import.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .base import BaseRelation

# ============================================================================
# INTERNAL: Relation Registry
# ============================================================================
# WARNING: This is an internal implementation detail used by get_relation_by_id().
# Do NOT access this directly. It is not part of the public API and may change
# without notice. Use get_relation_by_id() instead.

_RELATION_REGISTRY: dict[str, Any] = {}


def get_relation_by_id(relation_id: str) -> BaseRelation:
    """Get a handle to the relation for a given relation ID.

    Relations automatically handle dispatch per-model.

    Args:
        relation_id: The relation ID (e.g., "sys::Name")

    Returns:
        The RelationProxy singleton for that ID

    Raises:
        ValueError: If the relation ID is unknown
    """
    if relation_id not in _RELATION_REGISTRY:
        raise ValueError(f"Unknown relation id: {relation_id}")

    return _RELATION_REGISTRY[relation_id]


def get_all_relations() -> list[BaseRelation]:
    """Get all registered relation instances.

    Returns:
        List of all RelationProxy instances in the registry
    """
    return list(_RELATION_REGISTRY.values())
