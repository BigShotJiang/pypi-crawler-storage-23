"""Structured task body — a Pydantic tree of TaskItem nodes mirroring the RAI metamodel.

The emitter (Phase 2) translates these trees directly into pyrel define() calls.
See docs/backend/pyrel/native-tasks.md for the full spec and design rationale.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal, Sequence as Seq
from uuid import UUID

from pydantic import BaseModel, Discriminator, Field, TypeAdapter

from .builtin_types import TypeId  # noqa: F401 — re-exported for task body consumers

# RelationId is always a UUID — Relationship eid or builtin relation eid (=, <, count, etc.,
# all registered in builtins.py). Used in Lookup, Update, Construct, and Aggregate nodes.
RelationId = UUID


# ------------------------------------------------------------------
# Values (arguments to Lookup, Update, Construct, Aggregate, Output)
# ------------------------------------------------------------------


class Var(BaseModel):
    """A typed variable. Variables are produced by Lookup nodes scanning relations; the type
    comes from the relation's schema (the relation may hold concept instances, scalars, or anything
    else). Same name in the same task tree = same variable."""

    kind: Literal["var"] = "var"
    name: str
    type_eid: TypeId


class VarDefault(BaseModel):
    """A variable with a fallback value if the enclosing task fails (used in hoisted)."""

    kind: Literal["var_default"] = "var_default"
    var: Var
    value: "Value"


class Lit(BaseModel):
    """A literal constant value."""

    kind: Literal["lit"] = "lit"
    type_eid: TypeId
    value: Any  # must be JSON-serializable


Value = Annotated[Var | VarDefault | Lit, Field(discriminator="kind")]

VarOrDefault = Annotated[Var | VarDefault, Field(discriminator="kind")]


# ------------------------------------------------------------------
# Leaf task nodes
# ------------------------------------------------------------------


class Lookup(BaseModel):
    """Read/filter: scan relation, binding unbound Vars and checking bound Vars as constraints."""

    kind: Literal["lookup"] = "lookup"
    relation_eid: RelationId
    args: Seq[Value]


class Update(BaseModel):
    """Write to a relation.

    In practice, effect is always "derive" — the only value the LQP compiler currently
    accepts (lqp/validators.py asserts this). "derive" means a *supported/maintained*
    derivation: the fact exists while the supporting rule conditions hold, and is
    automatically retracted if those conditions no longer hold. This is standard
    datalog semantics.

    "insert" and "delete" exist as IR enum values for non-maintained writes but are
    not yet implemented in the execution stack. They are included here for completeness
    and future alignment with the metamodel, but all Tasks produced by model-building
    should use "derive".

    The distinction between "this is a persistent installed rule" vs "this is a query"
    is NOT encoded in the effect field — it is made at the LQP transaction level by
    the presence or absence of Output nodes (which generate LQP reads in addition to
    the normal LQP Define write).
    """

    kind: Literal["update"] = "update"
    relation_eid: RelationId
    args: Seq[Value]
    effect: Literal["derive", "insert", "delete"] = "derive"


class Output(BaseModel):
    """Mark query result output — maps variable/value expressions to output column names."""

    kind: Literal["output"] = "output"
    aliases: list[tuple[str, Value]]  # [(column_name, value), ...]
    keys: list[Var] | None = None  # optional key variables (for keyed output)


class Construct(BaseModel):
    """Create a new entity id by hashing (type + binding_relation_name + value, ...) and bind to var.

    The hash is deterministic: same inputs always produce the same id. This is how concept
    instantiation works — the entity id is derived from the natural key columns.
    """

    kind: Literal["construct"] = "construct"
    var: Var  # the variable that receives the new id
    bindings: Seq[
        tuple[RelationId, Value]
    ]  # [(relation_eid, value), ...] — the natural key


class Aggregate(BaseModel):
    """Perform an aggregation.

    aggregation: eid of the builtin aggregation relation (count, sum, avg, min, max — registered in builtins.py)
    projection:  variables to aggregate over
    group:       variables to group by (these are hoisted out to the parent scope)
    args:        additional arguments (e.g. the values to sum)
    """

    kind: Literal["aggregate"] = "aggregate"
    aggregation: (
        RelationId  # builtin aggregation relation eid (count, sum, avg, min, max)
    )
    projection: list[Var]
    group: list[Var]
    args: Seq[Value]


class Data(BaseModel):
    """Inline data table — a set of rows bound to typed variables."""

    kind: Literal["data"] = "data"
    rows: list[list[Any]]  # each row is a list of JSON-serializable values
    vars: list[Var]  # typed variables, one per column


# ------------------------------------------------------------------
# Composition task nodes
# ------------------------------------------------------------------


class Logical(BaseModel):
    """Concurrent AND to fix-point. All sub-tasks run together; succeeds if all succeed.

    Most common for conjunctive rules: lookups, constraints, updates in any order.

    hoisted: variables computed in sub-tasks that are visible in the parent scope.
             Required for aggregation results and any variable needed above this node.
    """

    kind: Literal["logical"] = "logical"
    body: list["TaskItem"]
    hoisted: list[VarOrDefault] = []


class Sequence(BaseModel):
    """Sequential AND. Each task executes after the prior; later tasks see prior results.

    Use when one computation depends on a prior result (e.g., aggregate then filter on result).
    """

    kind: Literal["sequence"] = "sequence"
    tasks: list["TaskItem"]
    hoisted: list[VarOrDefault] = []


class Union(BaseModel):
    """Concurrent OR. Succeeds if at least one sub-task succeeds."""

    kind: Literal["union"] = "union"
    tasks: list["TaskItem"]
    hoisted: list[VarOrDefault] = []


class Match(BaseModel):
    """Sequential OR. Tries tasks in order, stops at first success."""

    kind: Literal["match"] = "match"
    tasks: list["TaskItem"]
    hoisted: list[VarOrDefault] = []


# ------------------------------------------------------------------
# Quantifier task nodes
# ------------------------------------------------------------------


class Not(BaseModel):
    """Logical negation. Succeeds if the sub-task fails."""

    kind: Literal["not"] = "not"
    task: "TaskItem"


class Exists(BaseModel):
    """Existential quantification over vars in the sub-task."""

    kind: Literal["exists"] = "exists"
    vars: list[Var]
    task: "TaskItem"


class ForAll(BaseModel):
    """Universal quantification over vars in the sub-task."""

    kind: Literal["for_all"] = "for_all"
    vars: list[Var]
    task: "TaskItem"


# ------------------------------------------------------------------
# Discriminated union — any node in a task tree
# ------------------------------------------------------------------

TaskItem = Annotated[
    Lookup
    | Update
    | Output
    | Construct
    | Aggregate
    | Data
    | Logical
    | Sequence
    | Union
    | Match
    | Not
    | Exists
    | ForAll,
    Discriminator("kind"),
]

# Resolve forward references in all classes that contain TaskItem or Value fields.
VarDefault.model_rebuild()
Logical.model_rebuild()
Sequence.model_rebuild()
Union.model_rebuild()
Match.model_rebuild()
Not.model_rebuild()
Exists.model_rebuild()
ForAll.model_rebuild()

# Module-level singleton — used directly by callers for (de)serialization.
# The discriminator annotation encodes all routing logic; no wrapper needed.
TaskItemAdapter: TypeAdapter[TaskItem] = TypeAdapter(TaskItem)
