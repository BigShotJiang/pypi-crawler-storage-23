"""ModelFragment - A collection of ECS model entities.

Provides structured access to concepts, relationships, and sources
with convenient filtering and description methods.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from ..canonical import CanonicalTableDescriptor
from ..insights import InsightIdea
from .components import Concept, Relationship, Source


class ModelFragment(BaseModel):
    """Represents a collection of ECS model entities.

    Provides structured access to concepts, relationships, and sources
    organized by name/FQN with convenient filtering and description methods.

    This replaces raw `list[AgentContextItem]` usage throughout the codebase,
    providing a more structured and type-safe way to work with model entities.

    TODO: Turn model fragments into ctx managers in order to dynamically scope entities visible by builtins
    """

    concepts: dict[str, Concept]
    relationships: dict[str, Relationship]
    sources: dict[str, Source]
    canonical_tables: dict[str, CanonicalTableDescriptor] = Field(default_factory=dict)
    insights: list[InsightIdea] = Field(default_factory=list)

    @classmethod
    def from_items(cls, items: list[Concept | Relationship | Source]) -> ModelFragment:
        """Organize a list of ECS items into a structured fragment.

        Args:
            items: Mixed list of Concept, Relationship, and Source objects

        Returns:
            ModelFragment with entities organized by type and keyed by name/FQN

        Note:
            - Concepts and Relationships are keyed by lowercase name for case-insensitive lookup
            - Sources are keyed by FQN (fully qualified name)
        """
        concepts: dict[str, Concept] = {}
        relationships: dict[str, Relationship] = {}
        sources: dict[str, Source] = {}

        for item in items:
            if isinstance(item, Concept):
                # Case-insensitive key
                concepts[item.name.lower()] = item
            elif isinstance(item, Relationship):
                # Case-insensitive key
                relationships[item.name.lower()] = item
            elif isinstance(item, Source):
                # FQN as key (typically uppercase)
                sources[item.fqn] = item

        return cls(
            concepts=concepts,
            relationships=relationships,
            sources=sources,
        )

    def merge(self, other: ModelFragment) -> ModelFragment:
        """Merge another fragment into this one, with other taking precedence.

        Args:
            other: Fragment to merge, whose values override this fragment's

        Returns:
            New ModelFragment with merged contents
        """
        merged_concepts = {**self.concepts, **other.concepts}
        merged_relationships = {**self.relationships, **other.relationships}
        merged_sources = {**self.sources, **other.sources}

        return ModelFragment(
            concepts=merged_concepts,
            relationships=merged_relationships,
            sources=merged_sources,
        )

    def summary(self) -> str:
        """Format all entities using their summary() method.

        Returns:
            String with all entities formatted as:
            - Concepts: "eid:UUID:Name - description"
            - Relationships: "eid:UUID:Name - fields"
            - Sources: "eid:UUID:FQN - columns"
        """
        lines: list[str] = []

        if self.concepts:
            lines.append("Concepts:")
            for concept in self.concepts.values():
                lines.append(f"  {concept.summary()}")

        if self.relationships:
            lines.append("Relationships:")
            for rel in self.relationships.values():
                lines.append(f"  {rel.summary()}")

        if self.sources:
            lines.append("Sources:")
            for source in self.sources.values():
                lines.append(f"  {source.summary()}")

        return "\n".join(lines)

    def detail(
        self,
        concept_ids: list[str] = [],
        relationship_ids: list[str] = [],
        source_ids: list[str] = [],
    ) -> str:
        """Format specified entities using their detail() method.

        Args:
            concept_ids: List of concept names to include (empty = all)
            relationship_ids: List of relationship names to include (empty = all)
            source_ids: List of source FQNs to include (empty = all)

        Returns:
            String with requested entities formatted with full details

        Note:
            If no IDs are provided for a type, all entities of that type are included.
        """
        lines: list[str] = []

        # Helper for case-insensitive lookup
        def get_case_insensitive(d: dict[str, Concept | Relationship], key: str):
            return d.get(key.lower())

        # Determine which concepts to include
        concepts_to_show = (
            {
                cid.lower(): get_case_insensitive(self.concepts, cid)
                for cid in concept_ids
            }
            if concept_ids
            else self.concepts
        )
        # Filter out None values
        concepts_to_show = {k: v for k, v in concepts_to_show.items() if v is not None}

        # Determine which relationships to include
        rels_to_show = (
            {
                rid.lower(): get_case_insensitive(self.relationships, rid)
                for rid in relationship_ids
            }
            if relationship_ids
            else self.relationships
        )
        # Filter out None values
        rels_to_show = {k: v for k, v in rels_to_show.items() if v is not None}

        # Determine which sources to include
        sources_to_show = (
            {fqn: self.sources.get(fqn) for fqn in source_ids}
            if source_ids
            else self.sources
        )
        # Filter out None values
        sources_to_show = {k: v for k, v in sources_to_show.items() if v is not None}

        if concepts_to_show:
            lines.append("Concepts:")
            for concept in concepts_to_show.values():
                lines.append(f"  {concept.detail()}")

        if rels_to_show:
            lines.append("Relationships:")
            for rel in rels_to_show.values():
                lines.append(f"  {rel.detail()}")

        if sources_to_show:
            lines.append("Sources:")
            for source in sources_to_show.values():
                lines.append(f"  {source.detail()}")

        return "\n".join(lines)
