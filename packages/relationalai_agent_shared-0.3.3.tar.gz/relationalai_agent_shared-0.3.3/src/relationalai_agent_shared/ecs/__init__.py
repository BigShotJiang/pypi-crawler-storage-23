"""ECS (Entity-Component-System) runtime for agent data management.

An Entity-Component-System for managing semantic model entities during
agent workflows. Data is stored in columnar format (arrays) that map
directly to Snowflake table structure.

Key concepts:
- **Relations**: Store entity data as parallel arrays (columnar storage)
- **Components**: Provide typed interfaces to query/mutate relation data
- **builtins**: Singleton relation instances holding all entity data

Example:
    >>> from relationalai_agent_shared.ecs import Concept, builtins
    >>>
    >>> # Create a concept (generates UUID, populates relations)
    >>> concept = Concept.create(name="Customer", description="A buyer")
    >>>
    >>> # Access via component properties
    >>> print(concept.name)  # "Customer"
    >>>
    >>> # Or query relation data directly
    >>> name = builtins.name_relation.get(concept.eid)
    >>>
    >>> # Serialize for API/Snowflake
    >>> print(concept.model_dump())
"""

from .base import BaseRelation, BaseComponent
from .components import (
    Concept,
    Relationship,
    Source,
    SourceAnalysis,
    Search,
    Task,
    AgentContextItem,
)
from .fragment import ModelFragment
from . import builtins
from .builtins import Column, RelationField, Capability, Annotation
from .types import Verbosity
from .model import Model, Transaction, get_active_model, get_active_transaction
from .proxy import per_model
from .registry import get_all_relations, get_relation_by_id
from .query import (
    ConceptEntity,
    RelationshipEntity,
    SourceEntity,
    Entity,
    Instance,
    Interpretation,
    InterpretationList,
    GetQueryStep,
    JoinQueryStep,
    FilterQueryStep,
    ComputeQueryStep,
    AggregateQueryStep,
    QueryPlanStep,
    QueryPlan,
    SQLQuery,
    Normalized,
    VisualizationSpec,
)

__all__ = [
    "BaseRelation",
    "BaseComponent",
    "Concept",
    "Relationship",
    "Source",
    "SourceAnalysis",
    "Search",
    "Task",
    "AgentContextItem",
    "ModelFragment",
    "Verbosity",
    "AgentContextItem",
    "builtins",
    "clear_all_builtins",
    # Model context management
    "Model",
    "Transaction",
    "get_active_model",
    "get_active_transaction",
    "per_model",
    # Registry
    "get_all_relations",
    "get_relation_by_id",
    # Data types
    "Column",
    "RelationField",
    "Capability",
    "Annotation",
    # Query models
    "ConceptEntity",
    "RelationshipEntity",
    "SourceEntity",
    "Entity",
    "Instance",
    "Interpretation",
    "InterpretationList",
    "GetQueryStep",
    "JoinQueryStep",
    "FilterQueryStep",
    "ComputeQueryStep",
    "AggregateQueryStep",
    "QueryPlanStep",
    "QueryPlan",
    "SQLQuery",
    "Normalized",
    "VisualizationSpec",
]
