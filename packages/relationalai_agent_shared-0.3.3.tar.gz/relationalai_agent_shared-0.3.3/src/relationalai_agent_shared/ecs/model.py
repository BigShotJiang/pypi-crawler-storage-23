"""Model context management for per-model relation isolation.

Provides:
- Model: Context manager for model-scoped relation instances
- Transaction: ACID transaction context for relation writes
- Context variable management for active model/transaction tracking
"""

from __future__ import annotations

import re
from contextvars import ContextVar
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any
from uuid import UUID

from pydantic import BaseModel, Field, PrivateAttr
from . import builtins

if TYPE_CHECKING:
    from .base import BaseRelation

_active_model: ContextVar[Model | None] = ContextVar("active_model", default=None)
_active_transaction: ContextVar[Transaction | None] = ContextVar(
    "active_transaction", default=None
)

# Global transaction commit hooks
# Each hook is called with (model, changesets) after commit
_transaction_commit_hooks: list = []

# Model metadata persistence base path (set by ModelManager)
_metadata_base_path: Path | None = None


def register_transaction_commit_hook(hook) -> None:
    """Register a hook to be called after transaction commits.

    Hook signature: async def hook(model: Model, changesets: dict[str, list[Change]])

    Args:
        hook: Async function to call after transaction commits with all changesets
    """
    _transaction_commit_hooks.append(hook)


def set_metadata_base_path(base_path: Path) -> None:
    """Set the base path for model metadata persistence.

    This should be called by ModelManager during initialization.

    Args:
        base_path: Directory containing model subdirectories
    """
    global _metadata_base_path
    _metadata_base_path = Path(base_path)


class Model(BaseModel):
    """A model with automatic context management.

    Example:
        m1 = Model(id="m1", name="Customer Model")
        with m1:
            async with Transaction(m1):
                builtins.name[eid].value = "Alice"
    """

    # TODO: We should eventually come back and populate Model via BaseRelations as an entity of its own, so we have a single source of truth and system for managing persistence, but that introduces a bootstrapping problem that I'd rather not try to solve up front.

    id: str
    name: str | None = None
    description: str | None = None
    created_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    mtime: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Store relation instances per model (private, excluded from serialization)
    # Keyed by relation.id (str) instead of relation class type
    _relations: dict[str, BaseRelation] = PrivateAttr(default_factory=dict)

    # Stack of context tokens for nested contexts
    _token_stack: list[Any] = PrivateAttr(default_factory=list)

    def __hash__(self):
        """Hash based on immutable model ID."""
        return hash(self.id)

    @property
    def rai_model_name(self) -> str:
        """Unique, valid RAI model identifier derived from this model's name and id."""
        parts = [self.name or "model", self.id]
        return "-".join(
            re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", p.lower())).strip("-")
            for p in parts
        )

    def __enter__(self):
        """Activate this model's context.

        Supports nested/reentrant usage - each enter creates a new token
        that gets pushed onto a stack.
        """
        # Always create a new token and push to stack
        # TODO: Confirm this can't get corrupted by changing the order of entries vs exits. Should this be an external thread local?
        token = _active_model.set(self)
        self._token_stack.append(token)
        return self

    def __exit__(self, *args):
        """Deactivate this model's context.

        Pops and resets the most recent token from the stack.
        Handles the case where token was created in a different asyncio context.
        """
        # Pop the most recent token and reset it
        if self._token_stack:
            token = self._token_stack.pop()
            try:
                _active_model.reset(token)
            except ValueError:
                # Token was created in a different asyncio context (e.g., from concurrent tasks)
                # This is expected when using asyncio.gather() or similar concurrent patterns
                pass

    @property
    def concept_count(self) -> int:
        """Compute count of concepts from loaded relations."""
        try:
            # Use model context to access relation proxy, which resolves to the per-model instance
            with self:
                return len(builtins.concept_type.eids)
        except (ImportError, AttributeError):
            pass
        return 0

    @property
    def relationship_count(self) -> int:
        """Compute count of relationships from loaded relations."""
        try:
            # Use model context to access relation proxy, which resolves to the per-model instance
            with self:
                return len(builtins.relationship_type.eids)
        except (ImportError, AttributeError):
            pass
        return 0

    @property
    def source_count(self) -> int:
        """Compute count of sources from loaded relations."""
        try:
            # Use model context to access relation proxy, which resolves to the per-model instance
            with self:
                return len(builtins.source_type.eids)
        except (ImportError, AttributeError):
            pass
        return 0

    async def _save_metadata(self) -> None:
        """Save model metadata to disk.

        Raises:
            RuntimeError: If metadata base path has not been set
        """
        if _metadata_base_path is None:
            raise RuntimeError(
                "Metadata base path not set. Call set_metadata_base_path() first."
            )

        model_dir = _metadata_base_path / self.id
        model_dir.mkdir(parents=True, exist_ok=True)

        metadata_file = model_dir / "__model__.json"
        with open(metadata_file, "w") as f:
            f.write(self.model_dump_json(indent=2))

    async def rename(self, new_name: str) -> None:
        """Rename this model."""
        self.name = new_name
        self.mtime = datetime.now(timezone.utc).isoformat()
        await self._save_metadata()

    async def update_description(self, new_description: str) -> None:
        """Update this model's description."""
        self.description = new_description
        self.mtime = datetime.now(timezone.utc).isoformat()
        await self._save_metadata()

    async def rename_entity(self, entity_id: UUID, name: str) -> None:
        """Rename an entity.

        Args:
            entity_id: The entity to rename
            name: New name for the entity

        Raises:
            ValueError: If entity does not exist
        """

        with self:
            if entity_id not in builtins.name.eids:
                raise ValueError(f"Entity {entity_id} does not exist")

            async with Transaction(self):
                builtins.name[entity_id].value = name

        # Update mtime
        self.mtime = datetime.now(timezone.utc).isoformat()

    async def update_entity_description(
        self, entity_id: UUID, description: str
    ) -> None:
        """Update an entity's description.

        Args:
            entity_id: The entity to update
            description: New description for the entity

        Raises:
            ValueError: If entity does not exist
        """

        with self:
            if entity_id not in builtins.description.eids:
                raise ValueError(f"Entity {entity_id} does not exist")

            async with Transaction(self):
                builtins.description[entity_id].value = description

        # Update mtime
        self.mtime = datetime.now(timezone.utc).isoformat()

    def _register_relation(self, relation: BaseRelation) -> None:
        """Register a relation and create its channel (if applicable).

        Called when:
        - Loading relations from disk (in load_model())
        - Creating new relations at runtime (in DynamicRelation.create())

        This ensures channels are ALWAYS created immediately when relations
        are registered, regardless of code path.

        Args:
            relation: The relation instance to register
        """
        # Add to model's relation registry
        self._relations[relation.id] = relation

        # Create channel for non-builtin relations
        if not relation.id.startswith("sys::"):
            # Import here to avoid circular dependency
            try:
                from agent_core.sync import register_relation_channel
                from agent_core.sync.relation_channel import RelationChannel

                channel = RelationChannel(self.id, relation.id)
                register_relation_channel(self.id, relation.id, channel)
            except ImportError:
                # agent_core not available (e.g., in tests) - skip channel registration
                pass

    async def _register_task(self, task) -> None:
        """Register task (no-op now that FreshnessTracker is removed).

        Task → relation mappings are now computed on-demand by checking
        task.produces_ids instead of maintaining a registry.

        Args:
            task: The Task component (unused)
        """
        # No-op: Task registration no longer needed
        pass


class Transaction:
    """Transaction context for relation writes.

    Nested transactions: Only the outermost transaction commits.
    Inner transactions are no-ops (share the outer transaction's state).

    The model parameter is optional - if not provided, uses the active model
    from the current context (set by 'with model:' block).

    Example:
        # With explicit model
        async with Transaction(model):
            builtins.name[eid].value = "Alice"
            builtins.description[eid].value = "Customer"
            # Both writes committed atomically on exit

        # Using active model from context
        with model:
            async with Transaction():
                builtins.name[eid].value = "Bob"
    """

    def __init__(self, model: Model | None = None):
        if model is None:
            model = get_active_model()
            if model is None:
                raise RuntimeError(
                    "No active model in context. Use 'with model:' or pass model explicitly."
                )
        self.model = model
        self.depth = 0  # Track nesting depth
        # Keyed by relation.id (str) instead of relation class type
        self.changesets: dict[str, list[Change]] = {}

    def record_change(self, relation_id: str, change: Change):
        """Record a change to be applied on commit.

        WARNING: Changes are grouped by relation_id and may replay in a different
        order than recorded if they span multiple relations. Order is preserved within
        a single relation (LWW semantics), but cross-relation ordering is not guaranteed.

        Args:
            relation_id: The relation ID (str) to record the change for
            change: The change to record
        """
        if relation_id not in self.changesets:
            self.changesets[relation_id] = []
        self.changesets[relation_id].append(change)

    async def __aenter__(self):
        """Start transaction or enter nested transaction.

        Async transactions support persistence adapters.
        """
        existing = _active_transaction.get()
        if existing is not None:
            # Nested transaction - increment depth and reuse outer transaction
            existing.depth += 1
            return existing

        # New outermost transaction
        self._token = _active_transaction.set(self)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit transaction - only commit if outermost and no exception."""
        # Check if this is a nested transaction by looking at active transaction
        active = _active_transaction.get()
        if active is not self:
            # This is a nested transaction object, decrement depth on the active one
            if active is not None:
                active.depth -= 1
            return

        if self.depth > 0:
            # Inner transaction exiting - just decrement depth
            self.depth -= 1
            return

        # Outermost transaction exiting
        try:
            if exc_type is None:
                # No exception - apply changes and persist
                for relation_id, changes in self.changesets.items():
                    instance = self.model._relations.get(relation_id)
                    if instance is None:
                        # FIXME: throw in this case, then ensure we're eagerly creating relations of the appropriate type and adding them
                        # Look up template instance from global registry to get the class
                        from .registry import _RELATION_REGISTRY

                        template_instance = _RELATION_REGISTRY.get(relation_id)
                        if template_instance is None:
                            raise ValueError(f"Unknown relation ID: {relation_id}")

                        # Create a new instance of the same class for this model
                        relation_class = type(template_instance)
                        instance = relation_class()
                        instance.model_id = self.model.id
                        # ID is computed from class via BuiltinRelation.id property
                        self.model._relations[relation_id] = instance

                    # Apply all changes
                    for change in changes:
                        change.apply(instance)

                    # Persist if adapter is configured
                    adapter = instance.__class__.persistence_adapter
                    if adapter is not None:
                        await adapter.save_relation(instance)

                # Call registered commit hooks with all changesets
                for hook in _transaction_commit_hooks:
                    await hook(self.model, self.changesets)
            # If exception occurred, changes are discarded
        finally:
            if hasattr(self, "_token"):
                _active_transaction.reset(self._token)


class Change(BaseModel):
    """Represents a change to be applied to a relation."""

    field_name: str
    eid: UUID | None  # None for bulk operations
    value: Any
    is_insert: bool = False  # Set to True during apply() if this creates a new entity
    old_row_count: int | None = None  # For bulk replacement: number of rows to delete

    @staticmethod
    def replace_all(columns: dict[str, list], old_row_count: int):
        """Bulk operation: replace entire relation with these columns.

        Args:
            columns: New column data to insert
            old_row_count: Number of existing rows to delete first
        """
        return Change(
            field_name="__replace_all__",
            eid=None,
            value=columns,
            old_row_count=old_row_count,
        )

    def apply(self, relation: BaseRelation):
        """Apply this change to the relation."""
        # Skip bulk operations - they're handled during publishing
        if self.field_name == "__replace_all__":
            return

        # Bulk operations should have eid=None, others must have eid
        assert self.eid is not None, "Non-bulk operations must have an eid"

        eids = relation.eids

        # Handle eid-only inserts (field_name="eids" for marker relations)
        if self.field_name == "eids":
            if self.eid not in eids:
                self.is_insert = True
                eids.append(self.eid)
                relation._invalidate_index()
            return

        # Get the column (abstracted to handle both typed fields and generic columns)
        column = relation.get_column(self.field_name)
        # If column doesn't exist, create it
        if not column:
            column = []
            relation.set_column(self.field_name, column)

        # Use cached index for O(1) lookup instead of O(n) linear search
        idx = relation._get_index(self.eid)
        if idx is not None:
            # Existing entity - update value
            # Ensure column is long enough (sparse)
            while len(column) <= idx:
                if len(column) > 0 and isinstance(column[0], list):
                    column.append([])
                else:
                    column.append(None)
            column[idx] = self.value
        else:
            # New entity - append
            self.is_insert = True
            eids.append(self.eid)
            column.append(self.value)
            # Invalidate index cache
            relation._invalidate_index()


def get_active_transaction() -> Transaction | None:
    """Get the currently active transaction."""
    return _active_transaction.get()


def get_active_model() -> Model | None:
    """Get the currently active model."""
    return _active_model.get()


def record_entity_type_marker(
    marker_relation_instance: BaseRelation, eid: UUID
) -> None:
    """Record that an entity of a specific type was created.

    This notifies the transaction system that a new entity with the given eid
    should be added to a marker relation (e.g., RelationshipType, DynamicRelationType,
    ConceptType). Marker relations track which entities are of which type.

    The marker relation is typically a singleton instance decorated with @per_model,
    which creates a proxy. This function uses the proxy's .id property which
    automatically delegates to the per-model instance's id.

    Args:
        marker_relation_instance: The marker relation instance (e.g., builtins.relationship_type)
        eid: The entity ID to add to the marker relation

    Raises:
        RuntimeError: If called outside of a Transaction context

    Example:
        >>> from relationalai_agent_shared.ecs import builtins
        >>> from uuid import uuid4
        >>>
        >>> eid = uuid4()
        >>> record_entity_type_marker(builtins.relationship_type, eid)
    """
    transaction = get_active_transaction()
    if transaction is None:
        raise RuntimeError(
            "record_entity_type_marker() must be called within a Transaction context"
        )

    # Use the proxy instance's .id property directly
    # This automatically delegates to the per-model instance's id
    transaction.record_change(
        marker_relation_instance.id,
        Change(field_name="eids", eid=eid, value=None),
    )
