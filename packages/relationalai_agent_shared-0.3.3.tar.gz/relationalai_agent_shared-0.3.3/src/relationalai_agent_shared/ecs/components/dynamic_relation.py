"""DynamicRelation - BaseRelation for dynamic SQL query result storage.

DynamicRelation extends BaseRelation to store columnar data from SQL queries.
Each DynamicRelation instance has a unique UUID-based ID and stores data in
BaseRelation's generic _columns dict.

Used by SQLTask to store results from sources, canonical tables, search queries,
and relationships.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from pydantic import Field, computed_field

from relationalai_agent_shared.persistence.file_adapter import FileAdapter

from ..base import BaseRelation, get_persistence_path


class DynamicRelation(BaseRelation):
    """Dynamic relation for SQL query result storage.

    Stores columnar data from SQL queries using BaseRelation's generic
    dict-of-arrays storage (_columns). Each DynamicRelation instance represents
    one query result set (e.g., one canonical table, one relationship's data).

    Unlike builtin relations (sys::Name), each DynamicRelation has a unique
    UUID-based ID. Multiple DynamicRelations can exist per model, each with
    its own entity ID.

    Multi-Component Pattern:
    - Pure DynamicRelations: Sources and canonical tables (only has DynamicRelation)
    - Hybrid entities: Relationships (has BOTH Relationship component + DynamicRelation on same eid)

    Important distinction:
    - self.eids: Array of entity IDs in the data (rows of the query result)
    - self.eid: The entity ID of this DynamicRelation itself (for identification)
    """

    persistence_adapter = FileAdapter(get_persistence_path())

    # The entity ID of this DynamicRelation itself (separate from data row eids)
    eid: UUID = Field(default_factory=uuid4)

    def model_post_init(self, __context) -> None:
        """Register in global registry after initialization."""
        from ..registry import _RELATION_REGISTRY

        # Register this instance in the global registry
        if self.id not in _RELATION_REGISTRY:
            _RELATION_REGISTRY[self.id] = self

    @property
    def id(self) -> str:
        """Return UUID-based relation ID.

        For dynamic relations, each instance is unique and identified by its relation eid.
        This allows multiple DynamicRelation instances per model, each with its
        own file on disk (e.g., model_id/3fa85f64-5717-4562-b3fc-2c963f66afa6.json).
        """
        return str(self.eid)

    @computed_field
    @property
    def columns(self) -> dict[str, list[Any]]:
        """Get columnar data as dict-of-arrays.

        Computed field for Pydantic serialization - includes _columns in model_dump().
        Returns dictionary mapping column names to value arrays.
        """
        return self.get_columns_dict()

    @computed_field
    @property
    def available_cardinality(self) -> int:
        """Number of rows actually fetched and stored in this relation."""
        from .. import builtins

        return builtins.dynamic_relation_available_cardinality[self.eid].value or 0

    @available_cardinality.setter
    def available_cardinality(self, value: int) -> None:
        from .. import builtins

        builtins.dynamic_relation_available_cardinality[self.eid].value = value

    @computed_field
    @property
    def total_cardinality(self) -> int:
        """Total row count from COUNT(*) OVER() - full dataset size."""
        from .. import builtins

        return builtins.dynamic_relation_total_cardinality[self.eid].value or 0

    @total_cardinality.setter
    def total_cardinality(self, value: int) -> None:
        from .. import builtins

        builtins.dynamic_relation_total_cardinality[self.eid].value = value

    def populate_from_rows(self, data: list[dict]) -> None:
        """Populate this relation from a list of row dicts (row-oriented → column-oriented).

        Converts ``[{"a": 1, "b": 2}, {"a": 3, "b": 4}]`` into
        ``{"eids": [...], "a": [1, 3], "b": [2, 4]}`` and stores via
        ``set_columns_dict``.  If *data* is empty, clears the relation.
        """
        if not data:
            self.set_columns_dict({})
            return

        eids = [uuid4() for _ in range(len(data))]
        all_keys: set[str] = set()
        for row in data:
            all_keys.update(row.keys())

        columns: dict = {"eids": eids}
        for key in all_keys:
            columns[key] = [row.get(key) for row in data]

        self.set_columns_dict(columns)

    @classmethod
    def get(cls, eid: UUID) -> DynamicRelation | None:
        """Get an existing DynamicRelation by its entity ID.

        Args:
            eid: The entity ID of the DynamicRelation to retrieve

        Returns:
            Existing DynamicRelation instance, or None if not found

        Example:
            # Retrieve existing DynamicRelation
            data_rel = DynamicRelation.get(some_eid)
            if data_rel:
                columns = data_rel.columns
        """
        from ..model import get_active_model

        model = get_active_model()
        assert model

        relation_id = str(eid)
        instance = model._relations.get(relation_id)

        if isinstance(instance, DynamicRelation):
            return instance
        return None

    @classmethod
    def create(cls, eid: UUID | None = None) -> DynamicRelation:
        """Create a new DynamicRelation entity.

        Args:
            eid: Optional entity ID for this DynamicRelation itself. If provided,
                 uses that eid (multi-component pattern). If None, generates a new UUID.

        Returns:
            New DynamicRelation instance registered in model context

        Example:
            # Create standalone DynamicRelation (e.g., for canonical table)
            canonical_rel = DynamicRelation.create()

            # Create DynamicRelation sharing eid with Relationship (multi-component)
            relationship = Relationship(eid=some_eid)
            data_rel = DynamicRelation.create(eid=relationship.eid)
        """
        from ..model import get_active_model, record_entity_type_marker
        from .. import builtins

        if eid is None:
            eid = uuid4()

        # Create the relation instance
        instance = cls(eid=eid)
        instance.set_columns_dict({})  # Empty dict-of-arrays

        # Mark as DynamicRelation type (enables automatic channel registration)
        if eid not in builtins.dynamic_relation_type.eids:
            record_entity_type_marker(builtins.dynamic_relation_type, eid)

        # Register in active model context
        model = get_active_model()
        # FIXME: This is such a footgun
        if model is not None:
            instance.model_id = model.id
            model._register_relation(instance)

        return instance
