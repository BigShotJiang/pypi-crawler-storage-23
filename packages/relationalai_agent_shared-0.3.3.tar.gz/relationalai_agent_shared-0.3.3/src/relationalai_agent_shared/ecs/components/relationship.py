"""Relationship component - Virtual wrapper for relationship entities.

Relationships represent semantic model relationships between concepts.
Examples: has_orders, customer_email, belongs_to_organization
"""

from __future__ import annotations

from typing import Literal
from uuid import UUID, uuid4

from pydantic import computed_field

from ..base import BaseComponent
from .. import builtins
from ..builtin_types import is_primitive_type_eid
from ..builtins import RelationField, Capability, Annotation, Reading
from ..types import Verbosity


# TODO: MOD-1150 sort out the distinction and lack of connection between BaseRelation and Relationship(BaseComponent)
class Relationship(BaseComponent):
    """Represents a semantic model relationship.

    Groups name, fields, capabilities, annotations, and overloads into a
    cohesive interface. Maps to agent-shared/model.py Relation for wire
    serialization.

    Relationships define the schema of connections between concepts or
    between concepts and primitive values.
    """

    entity_type: Literal["relationship"] = "relationship"

    @classmethod
    def get_required_relations(cls) -> list[str]:
        """Relationship requires name and fields relations."""
        return ["name", "fields"]

    @classmethod
    def all(cls) -> list[Relationship]:
        """Get all relationship entities from builtins.

        Returns:
            List of all Relationship instances marked with the relationship type marker
        """
        return [
            cls(eid=eid)
            for eid in builtins.relationship_type.eids
            if cls(eid=eid).exists()
        ]

    def describe(self, verbosity: Verbosity) -> str:
        """Return a string description of this relationship.

        Args:
            verbosity: SUMMARY returns "eid:name"
                      DETAILED returns "eid:name(field1:Type1,field2:Type2,...)"
        """
        from .. import Verbosity

        if verbosity == Verbosity.SUMMARY:
            return f"{self.eid}:{self.name}"
        else:  # DETAILED
            fields_str = ",".join(f"{f.name}:{f.type}" for f in self.fields)
            return f"{self.eid}:{self.name}({fields_str})"

    def summary(self) -> str:
        """Return terse summary: 'eid:Name - field:type,field:type,...'."""
        field_strs = [f"{f.name}:{f.type}" for f in self.fields]
        return f"{self.eid}:{self.name} - {', '.join(field_strs)}"

    def detail(self) -> str:
        """Return full detail including capabilities, annotations, and overloads."""
        field_strs = [f"{f.name}:{f.type}" for f in self.fields]
        info = f"eid:{self.eid} | name:{self.name} | fields:{','.join(field_strs)}"
        if self.capabilities:
            cap_strs = [c.name for c in self.capabilities]
            info += f" | capabilities:{','.join(cap_strs)}"
        if self.annotations:
            ann_strs = [f"{a.name}={a.value}" for a in self.annotations]
            info += f" | annotations:{','.join(ann_strs)}"
        if self.overloads:
            info += f" | overloads:{len(self.overloads)}"
        return info

    @computed_field
    @property
    def name(self) -> str:
        """Get the relationship's name."""
        return builtins.name[self.eid].value or ""

    @name.setter
    def name(self, value: str) -> None:
        """Set the relationship's name."""
        builtins.name[self.eid].value = value

    @computed_field
    @property
    def description(self) -> str:
        """Get the relationship's description."""
        return builtins.description[self.eid].value or ""

    @description.setter
    def description(self, value: str) -> None:
        """Set the relationship's description."""
        builtins.description[self.eid].value = value

    @computed_field
    @property
    def fields(self) -> list[RelationField]:
        """Get the relationship's fields."""
        return builtins.fields[self.eid].value or []

    @fields.setter
    def fields(self, value: list[RelationField]) -> None:
        """Set the relationship's fields."""
        if value:
            builtins.fields[self.eid].value = value
        else:
            builtins.fields.delete(self.eid)

    @computed_field
    @property
    def capabilities(self) -> list[Capability]:
        """Get required capabilities (optional)."""
        return builtins.capabilities[self.eid].value or []

    @capabilities.setter
    def capabilities(self, value: list[Capability]) -> None:
        """Set required capabilities."""
        if value:
            builtins.capabilities[self.eid].value = value
        else:
            builtins.capabilities.delete(self.eid)

    @computed_field
    @property
    def annotations(self) -> list[Annotation]:
        """Get annotations (optional)."""
        return builtins.annotations[self.eid].value or []

    @annotations.setter
    def annotations(self, value: list[Annotation]) -> None:
        """Set annotations."""
        if value:
            builtins.annotations[self.eid].value = value
        else:
            builtins.annotations.delete(self.eid)

    @computed_field
    @property
    def overloads(self) -> list[UUID]:
        """Get overloaded relationship eids (optional)."""
        return builtins.overloads[self.eid].value or []

    @overloads.setter
    def overloads(self, value: list[UUID]) -> None:
        """Set overloaded relationship eids."""
        if value:
            builtins.overloads[self.eid].value = value
        else:
            builtins.overloads.delete(self.eid)

    @computed_field
    @property
    def type(self) -> str:
        """Get relationship type (derived from structure).

        - identity: if identifies is set
        - link: if multiple concept fields (joins multiple concepts)
        - property: otherwise (single concept + primitive fields)

        Concept fields are detected by excluding builtin scalar type UUIDs (which
        all share the ``00000001-`` prefix). See ``is_primitive_type_eid()``.
        """
        if self.identifies is not None:
            return "identity"

        concept_field_count = sum(
            1 for f in self.fields if f.type and not is_primitive_type_eid(f.type)
        )

        if concept_field_count >= 2:
            return "link"

        return "property"

    @computed_field
    @property
    def identifies(self) -> UUID | None:
        """Get concept eid that this relationship identifies (for identity relationships)."""
        return builtins.identifies[self.eid].value

    @identifies.setter
    def identifies(self, value: UUID | None) -> None:
        """Set concept eid that this relationship identifies."""
        if value:
            builtins.identifies[self.eid].value = value
        else:
            builtins.identifies.delete(self.eid)

    @computed_field
    @property
    def cardinality_groups(self) -> list[str]:
        """Get cardinality group labels (a, b, c, etc.)."""
        return builtins.cardinality_groups[self.eid].value or []

    @cardinality_groups.setter
    def cardinality_groups(self, value: list[str]) -> None:
        """Set cardinality group labels."""
        if value:
            builtins.cardinality_groups[self.eid].value = value
        else:
            builtins.cardinality_groups.delete(self.eid)

    @computed_field
    @property
    def source(self) -> UUID | None:
        """Get source table eid."""
        values = builtins.relationship_source[self.eid].value
        return values[0] if isinstance(values, list) else values

    @source.setter
    def source(self, value: UUID | None) -> None:
        """Set source table eid."""
        if value:
            builtins.relationship_source[self.eid].value = [value]
        else:
            builtins.relationship_source.delete(self.eid)

    @computed_field
    @property
    def readings(self) -> list[Reading]:
        """Get reading templates for this relationship."""
        return builtins.readings[self.eid].value or []

    @readings.setter
    def readings(self, value: list[Reading]) -> None:
        """Set reading templates."""
        if value:
            builtins.readings[self.eid].value = value
        else:
            builtins.readings.delete(self.eid)

    @property
    def relation(self):
        """Get the data storage relation for this relationship, if it exists.

        Returns DynamicRelation (BaseRelation) instance sharing this eid, or None
        if no data storage exists yet.

        Example:
            rel = Relationship(eid=some_eid)
            data_rel = rel.relation
            if data_rel:
                columns = data_rel.columns  # Access query result data
        """
        from ..model import get_active_model

        model = get_active_model()
        if model is None:
            raise RuntimeError(
                "Relationship.relation requires active model context. "
                "Use 'with model:' to activate model context."
            )

        # Look for DynamicRelation with UUID-based ID matching this eid
        relation_id = str(self.eid)
        # FIXME: need to fallback to support builtin relations at some point.
        # This will be needed when we reflect system relations (builtins) to the UI
        # for presentation to the user. Relationships point to relations they represent
        # metadata for - currently only DynamicRelations, but could be builtins in future.
        return model._relations.get(relation_id)

    def create_relation(self):
        """Create and attach a data storage relation for this relationship.

        Creates a DynamicRelation instance sharing this relationship's eid
        (multi-component pattern). This is called eagerly during Relationship.create()
        to ensure data storage exists from the start.

        Can also be called manually if a Relationship was created without using .create()
        or if the relation needs to be recreated for some reason.

        Returns:
            New DynamicRelation instance sharing this relationship's eid

        Example:
            rel = Relationship(eid=some_eid)
            data_rel = rel.create_relation()
            data_rel.set_columns_dict({"customer_id": [1, 2, 3], "name": ["Alice", "Bob", "Carol"]})
        """
        from .dynamic_relation import DynamicRelation

        # Create DynamicRelation with same eid (multi-component pattern)
        return DynamicRelation.create(eid=self.eid)

    @classmethod
    def create(
        cls,
        name: str,
        fields: list[RelationField],
        description: str = "",
        identifies: UUID | None = None,
        cardinality_groups: list[str] | None = None,
        source: UUID | None = None,
        readings: list[Reading] | None = None,
        capabilities: list[Capability] | None = None,
        annotations: list[Annotation] | None = None,
        overloads: list[UUID] | None = None,
    ) -> Relationship:
        """Create a new Relationship from minimal data (LLM output hydration).

        Args:
            name: The relationship's name
            fields: The field definitions
            description: The relationship's description
            identifies: Concept eid that this relationship identifies (for identity relationships)
            cardinality_groups: Cardinality group labels
            source: Source table eid
            readings: Optional reading templates for this relationship
            capabilities: Optional required capabilities
            annotations: Optional annotations
            overloads: Optional overloaded relationship eids

        Note:
            Type is derived automatically:
            - identity if identifies is set
            - link if multiple concept fields
            - property otherwise

        Returns:
            A new Relationship component wrapping the created entity
        """
        from ..model import record_entity_type_marker

        eid = uuid4()

        # Mark as Relationship type using transaction system
        record_entity_type_marker(builtins.relationship_type, eid)

        # Required relations
        builtins.name[eid].value = name
        builtins.fields[eid].value = fields
        builtins.description[eid].value = description

        # Relationship-specific relations
        if identifies:
            builtins.identifies[eid].value = identifies
        if cardinality_groups:
            builtins.cardinality_groups[eid].value = cardinality_groups
        if source:
            builtins.relationship_source[eid].value = source
        if readings:
            builtins.readings[eid].value = readings

        # Optional relations
        if capabilities:
            builtins.capabilities[eid].value = capabilities
        if annotations:
            builtins.annotations[eid].value = annotations
        if overloads:
            builtins.overloads[eid].value = overloads

        # Create the Relationship component
        relationship = cls(eid=eid)
        relationship.create_relation()

        return relationship
