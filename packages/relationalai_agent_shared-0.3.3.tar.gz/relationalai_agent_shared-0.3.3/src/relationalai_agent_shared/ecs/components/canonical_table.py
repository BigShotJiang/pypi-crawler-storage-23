"""CanonicalTable component - canonical views/tables for concepts.

The CanonicalTable component represents canonical views/tables generated from
semantic model concepts, providing curated data views for analysts.
"""

from __future__ import annotations

from typing import Literal
from uuid import UUID, uuid4

from pydantic import computed_field

from ..base import BaseComponent
from .. import builtins
from relationalai_agent_shared.canonical import (
    CanonicalIdea,
    DisplayNameMapping,
)
from ..types import Verbosity


class CanonicalTable(BaseComponent):
    """Represents a canonical table/view for a concept.

    Canonical tables are curated views of data that provide analysts with
    pre-built, high-value perspectives on concepts. Each table is linked to
    a concept and contains metadata about the SQL view, its columns, and
    display information.
    """

    entity_type: Literal["canonical_table"] = "canonical_table"

    @classmethod
    def get_required_relations(cls) -> list[str]:
        """CanonicalTable requires concept, view_type, long_name, and SQL."""
        return [
            "canonical_table_concept",
            "canonical_table_view_type",
            "canonical_table_long_name",
            "canonical_table_sql",
        ]

    @classmethod
    def all(cls) -> list[CanonicalTable]:
        """Get all CanonicalTable entities from builtins."""
        tables: list[CanonicalTable] = []
        for eid in builtins.canonical_table_type.eids:
            table = cls(eid=eid)
            if table.exists():
                tables.append(table)
        return tables

    def describe(self, verbosity: Verbosity) -> str:
        """Return a string description of this canonical table.

        Args:
            verbosity: SUMMARY returns "eid:long_name"
                      DETAILED returns "eid:long_name (view_type) - description"
        """

        if verbosity == Verbosity.SUMMARY:
            return f"{self.eid}:{self.long_name}"
        else:  # DETAILED
            desc = f"{self.eid}:{self.long_name} ({self.view_type})"
            if self.description:
                desc += f" - {self.description}"
            return desc

    def summary(self) -> str:
        """Return terse summary: 'eid:LongName'."""
        return f"{self.eid}:{self.long_name}"

    def detail(self) -> str:
        """Return full detail including concept reference and column count."""
        info = f"eid:{self.eid} | name:{self.long_name} | type:{self.view_type}"
        info += f" | concept:{self.concept_eid}"
        if self.columns:
            info += f" | columns:{len(self.columns)}"
        return info

    # Core canonical table properties

    @computed_field
    @property
    def concept_eid(self) -> UUID | None:
        """Get the concept EID this table belongs to."""
        return builtins.canonical_table_concept[self.eid].value

    @concept_eid.setter
    def concept_eid(self, value: UUID | None) -> None:
        """Set the concept EID."""
        builtins.canonical_table_concept[self.eid].value = value

    @computed_field
    @property
    def view_type(self) -> str:
        """Get the view type (canonical, subset, group_by, time, ranking)."""
        return builtins.canonical_table_view_type[self.eid].value or "canonical"

    @view_type.setter
    def view_type(self, value: str) -> None:
        """Set the view type."""
        builtins.canonical_table_view_type[self.eid].value = value

    @computed_field
    @property
    def long_name(self) -> str | None:
        """Get the human-friendly long name."""
        return builtins.canonical_table_long_name[self.eid].value

    @long_name.setter
    def long_name(self, value: str) -> None:
        """Set the long name."""
        builtins.canonical_table_long_name[self.eid].value = value

    @computed_field
    @property
    def description(self) -> str:
        """Get the table description."""
        return builtins.description[self.eid].value or ""

    @description.setter
    def description(self, value: str) -> None:
        """Set the description."""
        builtins.description[self.eid].value = value

    @computed_field
    @property
    def sql(self) -> str:
        """Get the SQL query for this canonical table."""
        return builtins.canonical_table_sql[self.eid].value or ""

    @sql.setter
    def sql(self, value: str) -> None:
        """Set the SQL query."""
        builtins.canonical_table_sql[self.eid].value = value

    @computed_field
    @property
    def columns(self) -> list[str]:
        """Get the column names projected by the SQL."""
        return builtins.canonical_table_columns[self.eid].value or []

    @columns.setter
    def columns(self, value: list[str]) -> None:
        """Set the column names."""
        if value:
            builtins.canonical_table_columns[self.eid].value = value
        else:
            builtins.canonical_table_columns.delete(self.eid)

    @computed_field
    @property
    def display_names(self) -> list[DisplayNameMapping]:
        """Get the display name mappings."""
        return builtins.canonical_table_display_names[self.eid].value or []

    @display_names.setter
    def display_names(self, value: list[DisplayNameMapping] | None) -> None:
        """Set the display name mappings."""
        if value:
            builtins.canonical_table_display_names[self.eid].value = value
        else:
            builtins.canonical_table_display_names.delete(self.eid)

    @computed_field
    @property
    def canonical_idea(self) -> CanonicalIdea | None:
        """Get the canonical idea (field picker result)."""
        return builtins.canonical_table_idea[self.eid].value or None

    @canonical_idea.setter
    def canonical_idea(self, value: CanonicalIdea | None) -> None:
        """Set the canonical idea."""
        if value is not None:
            builtins.canonical_table_idea[self.eid].value = value
        else:
            builtins.canonical_table_idea.delete(self.eid)

    @computed_field
    @property
    def rationale(self) -> str | None:
        """Get the rationale for why this view is useful."""
        return builtins.canonical_table_rationale[self.eid].value or None

    @rationale.setter
    def rationale(self, value: str | None) -> None:
        """Set the rationale."""
        if value:
            builtins.canonical_table_rationale[self.eid].value = value
        else:
            builtins.canonical_table_rationale.delete(self.eid)

    @computed_field
    @property
    def created_at(self) -> str | None:
        """Get the creation timestamp (ISO format)."""
        return builtins.canonical_table_created_at[self.eid].value or None

    @created_at.setter
    def created_at(self, value: str | None) -> None:
        """Set the creation timestamp."""
        if value:
            builtins.canonical_table_created_at[self.eid].value = value
        else:
            builtins.canonical_table_created_at.delete(self.eid)

    @classmethod
    def create(
        cls,
        concept_eid: UUID,
        short_name: str,
        view_type: str,
        long_name: str,
        description: str,
        sql: str,
        columns: list[str],
        display_names: list[DisplayNameMapping] | None = None,
        canonical_idea: CanonicalIdea | None = None,
        rationale: str | None = None,
        created_at: str | None = None,
    ) -> CanonicalTable:
        """Create a new CanonicalTable entity.

        Args:
            concept_eid: UUID of the concept this table describes
            short_name: Short identifier (from old format ID)
            view_type: Type of view (canonical, subset, group_by, time, ranking)
            long_name: Human-friendly full name
            description: Brief explanation of what the rows represent
            sql: Executable SELECT statement
            columns: Column names projected by the SQL
            display_names: Optional display name mappings
            canonical_idea: Optional canonical idea for traceability
            rationale: Optional explanation of why this view is useful
            created_at: Optional ISO timestamp string

        Returns:
            New CanonicalTable instance with generated UUID
        """
        # Generate deterministic UUID based on concept and short_name
        eid = uuid4()

        # Mark entity type
        builtins.canonical_table_type.eids.append(eid)

        # Create instance and set properties
        table = cls(eid=eid)
        table.concept_eid = concept_eid
        table.view_type = view_type
        table.long_name = long_name
        table.description = description
        table.sql = sql
        table.columns = columns

        if display_names:
            table.display_names = display_names

        if canonical_idea:
            table.canonical_idea = canonical_idea

        if rationale:
            table.rationale = rationale

        if created_at:
            table.created_at = created_at

        return table


__all__ = ["CanonicalTable"]
