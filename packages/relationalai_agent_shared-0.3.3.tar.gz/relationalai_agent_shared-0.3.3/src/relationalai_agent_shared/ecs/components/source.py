"""Source component - Virtual wrapper for source table entities.

Sources represent physical data tables in the warehouse.
Examples: TASTYBYTES.PUBLIC.CUSTOMERS, SALES.ORDERS
"""

from __future__ import annotations

from typing import Literal
from uuid import uuid4

from pydantic import computed_field

from ..base import BaseComponent
from .. import builtins
from ..builtins import Column
from ..types import Verbosity


class Source(BaseComponent):
    """Represents a physical source table in the data warehouse.

    Groups FQN, database, schema, table name, and columns into a cohesive
    interface. Maps to agent-shared/model.py Table for wire serialization.

    Sources are the physical tables that concepts and relationships derive from.

    TODO: Generalize schema to support multiple source types (not just Snowflake tables).
    Consider pattern: Source (base) + SnowflakeTable/AzureTable/SnowflakeJSON (specific),
    similar to how Search+Task describes search-specific tasks. Current schema is
    Snowflake-specific (fqn, database, schema, table_name).
    """

    entity_type: Literal["source"] = "source"

    @classmethod
    def get_required_relations(cls) -> list[str]:
        """Source requires fqn, database, schema, table_name, and columns."""
        return ["fqn", "database", "schema", "table_name", "columns"]

    @classmethod
    def all(cls) -> list[Source]:
        """Get all source entities from builtins.

        TODO: Is there a better way to get all the eids for the agent during QA?
        Currently iterates builtins.fqn.eids and filters for valid sources.

        Returns:
            List of all Source instances that exist in builtins
        """
        return [cls(eid=eid) for eid in builtins.fqn.eids if cls(eid=eid).exists()]

    def describe(self, verbosity: Verbosity) -> str:
        """Return a string description of this source.

        Args:
            verbosity: SUMMARY returns "fqn"
                      DETAILED returns "fqn(col1:Type1,col2:Type2,...)"
        """
        from .. import Verbosity

        if verbosity == Verbosity.SUMMARY:
            return self.fqn
        else:  # DETAILED
            columns_str = ",".join(f"{c.name}:{c.type}" for c in self.columns)
            return f"{self.fqn}({columns_str})"

    def summary(self) -> str:
        """Return terse summary: 'eid:FQN - col:type,col:type,...'."""
        col_strs = [f"{c.name}:{c.type}" for c in self.columns]
        return f"{self.eid}:{self.fqn} - {', '.join(col_strs)}"

    def detail(self) -> str:
        """Return full detail including database, schema, table name, and columns."""
        col_strs = [f"{c.name}:{c.type}" for c in self.columns]
        return (
            f"eid:{self.eid} | fqn:{self.fqn} | database:{self.database} | "
            f"schema:{self.schema} | table:{self.table_name} | columns:{','.join(col_strs)}"
        )

    @computed_field
    @property
    def fqn(self) -> str:
        """Get the fully qualified name."""
        return builtins.fqn[self.eid].value or ""

    @fqn.setter
    def fqn(self, value: str) -> None:
        """Set the fully qualified name."""
        builtins.fqn[self.eid].value = value

    @computed_field
    @property
    def database(self) -> str:
        """Get the database name."""
        return builtins.database[self.eid].value or ""

    @database.setter
    def database(self, value: str) -> None:
        """Set the database name."""
        builtins.database[self.eid].value = value

    @computed_field
    @property
    def schema(self) -> str:
        """Get the schema name."""
        return builtins.schema[self.eid].value or ""

    @schema.setter
    def schema(self, value: str) -> None:
        """Set the schema name."""
        builtins.schema[self.eid].value = value

    @computed_field
    @property
    def table_name(self) -> str:
        """Get the table name."""
        return builtins.table_name[self.eid].value or ""

    @table_name.setter
    def table_name(self, value: str) -> None:
        """Set the table name."""
        builtins.table_name[self.eid].value = value

    @computed_field
    @property
    def columns(self) -> list[Column]:
        """Get the column definitions."""
        return builtins.columns[self.eid].value or []

    @columns.setter
    def columns(self, value: list[Column]) -> None:
        """Set the column definitions."""
        if value:
            builtins.columns[self.eid].value = value
        else:
            builtins.columns.delete(self.eid)

    @classmethod
    def create(
        cls,
        fqn: str,
        database: str,
        schema: str,
        table_name: str,
        columns: list[Column],
    ) -> Source:
        """Create a new Source from table metadata.

        Args:
            fqn: Fully qualified name (DATABASE.SCHEMA.TABLE)
            database: Database name
            schema: Schema name
            table_name: Table name
            columns: Column definitions

        Returns:
            A new Source component wrapping the created entity
        """
        from ..model import record_entity_type_marker

        eid = uuid4()

        # Mark as Source type using transaction system
        record_entity_type_marker(builtins.source_type, eid)

        # Required relations
        builtins.fqn[eid].value = fqn
        builtins.database[eid].value = database
        builtins.schema[eid].value = schema
        builtins.table_name[eid].value = table_name
        builtins.columns[eid].value = columns

        return cls(eid=eid)
