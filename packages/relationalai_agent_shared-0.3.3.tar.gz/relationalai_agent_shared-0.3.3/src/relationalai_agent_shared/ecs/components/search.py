"""Search component - user queries and execution state."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal
from uuid import UUID

from pydantic import computed_field

from ..base import BaseComponent

if TYPE_CHECKING:
    pass
from .. import builtins
from ..builtins import (
    InterpretationData,
    QueryPlanData,
    SQLQueryData,
    SearchPresentationData,
)
from ..types import Verbosity


class Search(BaseComponent):
    """Represents a user search query and its execution state.

    Paired with a Task component (shared EID) that tracks provenance.
    """

    entity_type: Literal["search"] = "search"

    @classmethod
    def get_required_relations(cls) -> list[str]:
        """Searches require a query."""
        return ["search_query"]

    @classmethod
    def all(cls) -> list[Search]:
        """Get all Search entities."""
        return [
            cls(eid=eid) for eid in builtins.search_type.eids if cls(eid=eid).exists()
        ]

    def describe(self, verbosity: Verbosity) -> str:
        """Return string description."""
        from .. import Verbosity

        if verbosity == Verbosity.SUMMARY:
            return f"Search: {self.query[:50]}..."
        else:  # DETAILED
            return f"Search({self.eid}): query='{self.query}', step={self.step}, subjects={len(self.subjects)}"

    def summary(self) -> str:
        """Return terse single-line summary."""
        return f"Search: {self.query[:60]}"

    def detail(self) -> str:
        """Return full detail."""
        return (
            f"eid:{self.eid} | "
            f"query:{self.query} | "
            f"step:{self.step} | "
            f"subjects:{len(self.subjects)}"
        )

    # Core search properties

    @computed_field
    @property
    def query(self) -> str:
        """The user's search query text."""
        return builtins.search_query[self.eid].value or ""

    @query.setter
    def query(self, value: str) -> None:
        builtins.search_query[self.eid].value = value

    @computed_field
    @property
    def step(self) -> str:
        """Current execution step/status."""
        return builtins.search_step[self.eid].value or "started"

    @step.setter
    def step(self, value: str) -> None:
        builtins.search_step[self.eid].value = value

    @computed_field
    @property
    def subjects(self) -> list[UUID]:
        """Related entity subjects."""
        return builtins.search_subjects[self.eid].value or []

    @subjects.setter
    def subjects(self, value: list[UUID]) -> None:
        if value:
            builtins.search_subjects[self.eid].value = value
        else:
            builtins.search_subjects.delete(self.eid)

    # Result properties (typed Pydantic models)

    @computed_field
    @property
    def interpretations(self) -> list[InterpretationData]:
        """NLP interpretations of the query."""
        return builtins.search_interpretations[self.eid].value or []

    @interpretations.setter
    def interpretations(self, value: list[InterpretationData] | None) -> None:
        if value:
            builtins.search_interpretations[self.eid].value = value
        else:
            builtins.search_interpretations.delete(self.eid)

    @computed_field
    @property
    def query_plan(self) -> QueryPlanData | None:
        """Query plan from search execution."""
        return builtins.search_query_plan[self.eid].value or None

    @query_plan.setter
    def query_plan(self, value: QueryPlanData | None) -> None:
        if value is not None:
            builtins.search_query_plan[self.eid].value = value
        else:
            builtins.search_query_plan.delete(self.eid)

    @computed_field
    @property
    def sql_query(self) -> SQLQueryData | None:
        """Generated SQL query."""
        return builtins.search_sql_query[self.eid].value or None

    @sql_query.setter
    def sql_query(self, value: SQLQueryData | None) -> None:
        if value is not None:
            builtins.search_sql_query[self.eid].value = value
        else:
            builtins.search_sql_query.delete(self.eid)

    # Metadata properties

    @computed_field
    @property
    def timings(self) -> dict[str, int]:
        """Performance timings for each step (milliseconds)."""
        return builtins.search_timings[self.eid].value or {}

    @timings.setter
    def timings(self, value: dict[str, int]) -> None:
        if value:
            builtins.search_timings[self.eid].value = value
        else:
            builtins.search_timings.delete(self.eid)

    @computed_field
    @property
    def failure_message(self) -> str | None:
        """Error message if search failed."""
        return builtins.search_failure_message[self.eid].value or None

    @failure_message.setter
    def failure_message(self, value: str | None) -> None:
        if value:
            builtins.search_failure_message[self.eid].value = value
        else:
            builtins.search_failure_message.delete(self.eid)

    @computed_field
    @property
    def step_history(self) -> list[str]:
        """Historical record of execution steps."""
        return builtins.search_step_history[self.eid].value or []

    @step_history.setter
    def step_history(self, value: list[str]) -> None:
        if value:
            builtins.search_step_history[self.eid].value = value
        else:
            builtins.search_step_history.delete(self.eid)

    @computed_field
    @property
    def presentation(self) -> SearchPresentationData | None:
        """UI rendering hints."""
        return builtins.search_presentation[self.eid].value or None

    @presentation.setter
    def presentation(self, value: SearchPresentationData | None) -> None:
        if value is not None:
            builtins.search_presentation[self.eid].value = value
        else:
            builtins.search_presentation.delete(self.eid)

    @classmethod
    def create(cls, query: str, step: str = "started", eid: UUID | None = None):
        from ..model import record_entity_type_marker

        search = cls(eid=eid) if eid is not None else cls()
        eid = search.eid
        record_entity_type_marker(builtins.search_type, eid)
        search.query = query
        search.step = step
        print("SEARCH", eid, search.eid)
        return search


__all__ = ["Search"]
