"""Concept component - Virtual wrapper for concept entities.

The Concept component groups name, description, and parent_types relations
into a cohesive interface, representing a semantic model concept (type).
"""

from __future__ import annotations

from typing import Literal
from uuid import UUID, uuid4

from pydantic import computed_field

from ..base import BaseComponent
from .. import builtins
from ..builtins import ConceptKey
from ..types import Verbosity


class Concept(BaseComponent):
    """Represents a semantic model concept (type).

    Groups name, description, and parent types into a cohesive interface.
    Maps to agent-shared/model.py ScalarType for wire serialization.

    Concepts are the building blocks of the semantic model - they represent
    domain entities like Customer, Order, Product, etc.
    """

    entity_type: Literal["concept"] = "concept"

    @classmethod
    def get_required_relations(cls) -> list[str]:
        """Concept requires name and description relations."""
        return ["name", "description"]

    @classmethod
    def all(cls) -> list[Concept]:
        """Get all concept entities from builtins.

        Returns:
            List of all Concept instances marked with the concept type marker
        """
        return [cls(eid=eid) for eid in builtins.concept_type.eids if cls(eid=eid).exists()]

    def describe(self, verbosity: Verbosity) -> str:
        """Return a string description of this concept.

        Args:
            verbosity: SUMMARY returns "eid:name"
                      DETAILED returns "eid:name - description"
        """
        from .. import Verbosity

        if verbosity == Verbosity.SUMMARY:
            return f"{self.eid}:{self.name}"
        else:  # DETAILED
            return f"{self.eid}:{self.name} - {self.description}"

    def summary(self) -> str:
        """Return terse summary: 'eid:Name - description' or 'eid:Name'."""
        if self.description:
            return f"{self.eid}:{self.name} - {self.description}"
        return f"{self.eid}:{self.name}"

    def detail(self) -> str:
        """Return full detail including parent types if present."""
        info = f"eid:{self.eid} | name:{self.name} | description:{self.description}"
        if self.parent_eids:
            parent_names = []
            for parent_eid in self.parent_eids:
                parent = Concept(eid=parent_eid)
                if parent.exists():
                    parent_names.append(parent.name)
            if parent_names:
                info += f" | extends:{','.join(parent_names)}"
        return info

    @computed_field
    @property
    def name(self) -> str:
        """Get the concept's name."""
        return builtins.name[self.eid].value or ""

    @name.setter
    def name(self, value: str) -> None:
        """Set the concept's name."""
        builtins.name[self.eid].value = value

    @computed_field
    @property
    def description(self) -> str:
        """Get the concept's description."""
        return builtins.description[self.eid].value or ""

    @description.setter
    def description(self, value: str) -> None:
        """Set the concept's description."""
        builtins.description[self.eid].value = value

    @computed_field
    @property
    def parent_eids(self) -> list[UUID]:
        """Get the parent type entity IDs (optional field)."""
        return builtins.parent_types[self.eid].parent_eids or []

    @parent_eids.setter
    def parent_eids(self, value: list[UUID]) -> None:
        """Set the parent type entity IDs."""
        if value:
            builtins.parent_types[self.eid].parent_eids = value
        else:
            # Empty list - remove from relation
            builtins.parent_types.delete(self.eid)

    @computed_field
    @property
    def keys(self) -> list[ConceptKey]:
        """Get authoritative source mappings (identity keys)."""
        return builtins.concept_keys[self.eid].value or []

    @keys.setter
    def keys(self, value: list[ConceptKey]) -> None:
        """Set authoritative source mappings."""
        if value:
            builtins.concept_keys[self.eid].value = value
        else:
            builtins.concept_keys.delete(self.eid)

    @computed_field
    @property
    def joins(self) -> list[ConceptKey]:
        """Get non-authoritative source mappings (joinable)."""
        return builtins.concept_joins[self.eid].value or []

    @joins.setter
    def joins(self, value: list[ConceptKey]) -> None:
        """Set non-authoritative source mappings."""
        if value:
            builtins.concept_joins[self.eid].value = value
        else:
            builtins.concept_joins.delete(self.eid)

    @classmethod
    def create(
        cls,
        name: str,
        description: str = "",
        keys: list[ConceptKey] | None = None,
        joins: list[ConceptKey] | None = None,
        parent_eids: list[UUID] | None = None,
    ) -> Concept:
        """Create a new Concept from minimal data (LLM output hydration).

        This is the primary factory method - takes minimal structured data
        and creates a fully populated ECS entity.

        NOTE: We use hydrate() instead of Pydantic __init__ because Pydantic
        does NOT call property setters during __init__. Calling Concept(name="X")
        would not populate builtins.name relation. See docs/ecs-design-questions.md
        and scripts/test_pydantic_init.py for details.

        Args:
            name: The concept's name
            description: The concept's description (empty string if not provided)
            keys: Authoritative source mappings (identity keys)
            joins: Non-authoritative source mappings (joinable but not identity)
            parent_eids: Optional list of parent type entity IDs

        Returns:
            A new Concept component wrapping the created entity
        """
        from ..model import record_entity_type_marker

        # Generate new entity ID
        eid = uuid4()

        # Mark as Concept type using transaction system
        record_entity_type_marker(builtins.concept_type, eid)

        # Create the component first
        concept = cls(eid=eid)

        # Use property setters (handles dict → ConceptKey conversion)
        concept.name = name
        concept.description = description

        if keys:
            concept.keys = keys  # Setter converts dicts to ConceptKey
        if joins:
            concept.joins = joins  # Setter converts dicts to ConceptKey

        if parent_eids:
            concept.parent_eids = parent_eids

        return concept
