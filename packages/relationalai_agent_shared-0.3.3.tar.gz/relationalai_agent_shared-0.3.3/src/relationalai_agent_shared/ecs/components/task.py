"""Task component - execution provenance and lineage."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal, Self
from uuid import UUID

if TYPE_CHECKING:
    from relationalai_agent_shared.ecs.task_body import TaskItem

from pydantic import computed_field

from ..base import BaseComponent
from .. import builtins
from ..types import Verbosity

# Task implementation registry - maps implementation name to class
# Automatically populated via __init_subclass__ hook
TASK_IMPLEMENTATIONS: dict[str, type["Task"]] = {}


class Task(BaseComponent):
    """Tracks an operation: inputs → transformation → outputs.

    Examples:
    - User search: [] → search(query) → [Relationships, Results]
    - Model generation: [Sources] → generate_model() → [Concepts, Relationships]
    - Relationship discovery: [Source, Source] → find_joins() → [Relationship]
    """

    entity_type: Literal["task"] = "task"

    def __init_subclass__(cls, **kwargs):
        """Automatically register task implementations when subclass is defined.

        All Task subclasses are automatically added to TASK_IMPLEMENTATIONS
        using their class name as the key. This enables dynamic task instantiation
        based on implementation name stored in the model.
        """
        super().__init_subclass__(**kwargs)
        TASK_IMPLEMENTATIONS[cls.__name__] = cls

    def __hash__(self):
        """Hash based on entity ID for use in sets/dicts."""
        return hash(self.eid)

    def __eq__(self, other):
        """Equality based on entity ID."""
        if not isinstance(other, Task):
            return NotImplemented
        return self.eid == other.eid

    @classmethod
    def get_required_relations(cls) -> list[str]:
        """Tasks have no strictly required relations."""
        return []

    @classmethod
    def all(cls) -> list[Task]:
        """Get all Task entities with correct subclass types.

        Uses the implementation discriminator to instantiate the correct
        Task subclass (e.g., SQLTask) rather than always creating base Task instances.
        """
        tasks = []
        for eid in builtins.task_type.eids:
            # Create temporary instance to check existence and get implementation
            temp = Task(eid=eid)
            if not temp.exists():
                continue

            # Get stored implementation name and instantiate correct subclass
            impl_name = temp.implementation
            task_class = TASK_IMPLEMENTATIONS.get(impl_name, Task)
            tasks.append(task_class(eid=eid))

        return tasks

    def describe(self, verbosity: Verbosity) -> str:
        """Return string description."""
        from .. import Verbosity

        if verbosity == Verbosity.SUMMARY:
            return f"Task({self.eid}): {self.layer} layer"
        else:  # DETAILED
            return f"Task({self.eid}): consumes={len(self.consumes_ids)}, produces={len(self.produces_ids)}, layer={self.layer}, created_by={self.created_by}"

    def summary(self) -> str:
        """Return terse single-line summary."""
        return f"Task {self.created_by}@{self.layer}: {len(self.consumes_ids)}→{len(self.produces_ids)}"

    def detail(self) -> str:
        """Return full detail."""
        return (
            f"eid:{self.eid} | "
            f"consumes:{len(self.consumes_ids)} | "
            f"produces:{len(self.produces_ids)} | "
            f"layer:{self.layer} | "
            f"created_by:{self.created_by} | "
            f"created_at:{self.created_at}"
        )

    # Core task properties

    @computed_field
    @property
    def consumes_ids(self) -> list[UUID]:
        """Input entity IDs consumed by this task."""
        return builtins.task_consumes[self.eid].value or []

    @consumes_ids.setter
    def consumes_ids(self, value: list[UUID]) -> None:
        if value:
            builtins.task_consumes[self.eid].value = value
        else:
            builtins.task_consumes.delete(self.eid)

    @computed_field
    @property
    def produces_ids(self) -> list[UUID]:
        """Output entity IDs produced by this task."""
        return builtins.task_produces[self.eid].value or []

    @produces_ids.setter
    def produces_ids(self, value: list[UUID]) -> None:
        if value:
            builtins.task_produces[self.eid].value = value
        else:
            builtins.task_produces.delete(self.eid)

    @computed_field
    @property
    def layer(self) -> str:
        """Processing layer: logical or physical."""
        return builtins.task_layer[self.eid].value or "logical"

    @layer.setter
    def layer(self, value: str) -> None:
        builtins.task_layer[self.eid].value = value

    # Metadata properties

    @computed_field
    @property
    def created_by(self) -> str:
        """Who/what created this task."""
        return builtins.task_created_by[self.eid].value or "system"

    @created_by.setter
    def created_by(self, value: str) -> None:
        builtins.task_created_by[self.eid].value = value

    @computed_field
    @property
    def created_at(self) -> str:
        """When the task was created (ISO datetime)."""
        return builtins.task_created_at[self.eid].value or ""

    @created_at.setter
    def created_at(self, value: str) -> None:
        builtins.task_created_at[self.eid].value = value

    @computed_field
    @property
    def modified_at(self) -> str:
        """When the task was last modified (ISO datetime)."""
        return builtins.task_modified_at[self.eid].value or ""

    @modified_at.setter
    def modified_at(self, value: str) -> None:
        builtins.task_modified_at[self.eid].value = value

    @property
    def implementation(self) -> str:
        """Python class name for this task (discriminator)."""
        return builtins.task_implementation[self.eid].value or "Task"

    @implementation.setter
    def implementation(self, value: str) -> None:
        builtins.task_implementation[self.eid].value = value

    @property
    def body(self) -> "TaskItem | None":
        """Metamodel-structured task body for PyRel emission."""
        return builtins.task_body[self.eid].value

    @body.setter
    def body(self, value: "TaskItem | None") -> None:
        if value is not None:
            builtins.task_body[self.eid].value = value
        else:
            builtins.task_body.delete(self.eid)

    # Status and freshness properties

    @computed_field
    @property
    def status(self) -> builtins.TaskStatus | None:
        """Current execution status (pending/running/completed/failed)."""
        status_value = builtins.task_status[self.eid].status
        if status_value:
            return builtins.TaskStatus(status_value)
        return None

    @computed_field
    @property
    def last_updated(self) -> str | None:
        """ISO datetime string of last status change."""
        return builtins.task_last_updated[self.eid].timestamp or None

    @computed_field
    @property
    def failure_message(self) -> str | None:
        """Error message when task execution fails."""
        return builtins.task_failure_message[self.eid].value or None

    @failure_message.setter
    def failure_message(self, value: str | None) -> None:
        if value:
            builtins.task_failure_message[self.eid].value = value
        else:
            builtins.task_failure_message.delete(self.eid)

    @computed_field
    @property
    def needs_refresh(self) -> bool:
        """Whether task data needs refresh (is stale or unstarted)."""
        status = self.status
        if status is None:
            return True
        return status in (builtins.TaskStatus.STALE, builtins.TaskStatus.UNSTARTED)

    @computed_field
    @property
    def is_refreshing(self) -> bool:
        """Whether task is actively refreshing (queued or running)."""
        status = self.status
        if status is None:
            return False
        return status in (builtins.TaskStatus.QUEUED, builtins.TaskStatus.RUNNING)

    @status.setter
    def status(self, value: builtins.TaskStatus) -> None:
        """Update task status and timestamp (must be in transaction).

        Args:
            value: New task status

        Raises:
            RuntimeError: If called outside of a Transaction context
        """
        from ..model import get_active_transaction
        import datetime

        txn = get_active_transaction()
        if txn is None:
            raise RuntimeError("Setting status must be called within a Transaction")

        # Update status
        builtins.task_status[self.eid].status = value.value

        # Update timestamp - make ISO string
        builtins.task_last_updated[
            self.eid
        ].timestamp = datetime.datetime.now().isoformat()

    @classmethod
    def create(
        cls,
        consumes: list[UUID] | None = None,
        produces: list[UUID] | None = None,
        layer: str = "logical",
        created_by: str = "system",
        created_at: str = "",
        modified_at: str = "",
        eid: UUID | None = None,
    ) -> Self:
        """Create a new Task entity.

        Args:
            consumes: Input entity IDs
            produces: Output entity IDs
            layer: Processing layer (logical or physical)
            created_by: Creator identifier
            created_at: Creation timestamp (ISO format)
            modified_at: Modification timestamp (ISO format)
            eid: Optional explicit entity ID (for reusing existing entities like searches)

        Returns:
            New Task instance
        """
        # Import here to get EID from Search if creating with Search
        from uuid import uuid4
        from ..model import record_entity_type_marker

        if eid is None:
            eid = uuid4()

        # Mark entity type using transaction system (avoid duplicates if reusing existing eid)
        if eid not in builtins.task_type.eids:
            record_entity_type_marker(builtins.task_type, eid)

        # Create instance and set properties
        task = cls(eid=eid)

        # Set implementation discriminator (preserves subclass type)
        task.implementation = cls.__name__

        if consumes:
            task.consumes_ids = consumes
        if produces:
            task.produces_ids = produces

        task.layer = layer
        task.created_by = created_by

        if created_at:
            task.created_at = created_at
        if modified_at:
            task.modified_at = modified_at

        # Set initial status to UNSTARTED (requires Transaction context)
        task.status = builtins.TaskStatus.UNSTARTED

        return task

    async def exec(self) -> list[UUID]:
        """Execute this task and return produced entity IDs.

        Base implementation orchestrates execution workflow:
        1. Transitions status from QUEUED to RUNNING # FIXME: subclasses should manage this
        2. Validates consumed entities exist
        3. Delegates to _execute_task_logic() (overridden by subclasses)
        4. Sets status to FRESH on success, FAILED on exception

        Note: Relations may be unions of multiple tasks. Relation status is computed
        from all contributing task statuses.

        Returns:
            List of entity IDs produced by this task
        """
        # Get model context
        from ..model import get_active_model, Transaction
        from .. import get_all_relations

        model = get_active_model()

        if model is None:
            raise RuntimeError("Task.exec() requires active model context")

        # Set status to RUNNING
        async with Transaction(model):
            self.status = builtins.TaskStatus.RUNNING

        try:
            # Validate consumed entities exist
            for consumed_id in self.consumes_ids:
                # Check if entity exists in model (has entity type)
                exists = any(consumed_id in rel.eids for rel in get_all_relations())
                if not exists:
                    raise ValueError(
                        f"Consumed entity {consumed_id} not found in model"
                    )

            # Update produces_ids if task created new entities
            async with Transaction(model):
                produced = await self._execute_task_logic(self.produces_ids)
                self.produces_ids = produced
                self.failure_message = None
                # Set status to FRESH on success
                # Status and last_updated timestamp are all we need for staleness checking
                self.status = builtins.TaskStatus.FRESH

            return self.produces_ids

        except Exception as exc:
            # Set status to FAILED on exception
            # Transaction commit hook will sync status change to frontend automatically
            async with Transaction(model):
                self.status = builtins.TaskStatus.FAILED
                self.failure_message = str(exc)

            # Re-raise the exception
            raise

    async def _execute_task_logic(self, prev: list[UUID] | None = None) -> list[UUID]:
        """Override in subclasses to implement task-specific execution.

        Base implementation is a no-op stub that preserves existing produces_ids.

        Args:
            prev: Previous produces_ids list to preserve/extend

        Returns:
            List of entity IDs (preserves prev if no changes)
        """
        # Stub: subclasses override with real logic
        # Preserve existing produces_ids if no changes
        return prev or []


TASK_IMPLEMENTATIONS["Task"] = Task

__all__ = ["Task", "TASK_IMPLEMENTATIONS"]
