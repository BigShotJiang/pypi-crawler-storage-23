"""ECS Components - Virtual entity wrappers.

Components provide a convenient interface to query relations.
They define which relations an entity must have to be considered
"of this type".
"""

from typing import Annotated

from pydantic import Field
from .concept import Concept
from .relationship import Relationship
from .source import Source
from .source_analysis import SourceAnalysis
from .search import Search
from .task import Task
from .canonical_table import CanonicalTable

AgentContextItem = Annotated[
    (Concept | Relationship | Source | SourceAnalysis | Search | Task | CanonicalTable),
    Field(discriminator="entity_type"),
]


__all__ = [
    "Concept",
    "Relationship",
    "Source",
    "SourceAnalysis",
    "Search",
    "Task",
    "CanonicalTable",
    "AgentContextItem",
]
