"""SourceAnalysis component - Virtual wrapper for source analysis entities.

SourceAnalysis holds the LLM-generated analysis of a Source table,
including humanized names, purpose descriptions, column importance,
and key relationships (PKs, FKs, soft-joins).

Key distinction:
- Source = ingested data (raw table metadata from warehouse)
- SourceAnalysis = our analysis (LLM-generated insights about the source)
"""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from pydantic import computed_field

from ..base import BaseComponent
from .. import builtins
from ..builtins import ColumnAnalysisData, ForeignKeyRef, UnifyRef
from ..types import Verbosity


class SourceAnalysis(BaseComponent):
    """Represents analysis metadata for a source table.

    Groups analysis results from LLM into a cohesive interface:
    - name/description: Human-friendly table identification
    - column_analyses: Per-column analysis with key probabilities
    - inferred_primary_keys/inferred_foreign_keys/inferred_unify_relationships: LLM-inferred key analysis

    SourceAnalysis entities share the same eid as their corresponding Source
    entity, allowing them to be linked without explicit foreign keys.
    """

    entity_type: Literal["source_analysis"] = "source_analysis"

    @classmethod
    def get_required_relations(cls) -> list[str]:
        """SourceAnalysis requires name and description at minimum.

        Note: Reuses builtins.name and builtins.description (shared relations).
        """
        return ["name", "description"]

    @classmethod
    def all(cls) -> list[SourceAnalysis]:
        """Get all source analysis entities from builtins.

        Filters to entities that have column_analyses set (distinguishes
        SourceAnalysis from other entities that have name/description).

        Returns:
            List of all SourceAnalysis instances that exist in builtins
        """
        return [
            cls(eid=eid)
            for eid in builtins.column_analyses.eids
            if cls(eid=eid).exists()
        ]

    def describe(self, verbosity: Verbosity) -> str:
        """Return a string description of this source analysis.

        Args:
            verbosity: SUMMARY returns "eid:name"
                      DETAILED returns "eid:name - description"
        """
        from .. import Verbosity

        if verbosity == Verbosity.SUMMARY:
            return f"{self.eid}:{self.name}"
        else:  # DETAILED
            return f"{self.eid}:{self.name} - {self.description}"

    def summary(self) -> str:
        """Return terse summary: 'eid:Name - description'."""
        if self.description:
            return f"{self.eid}:{self.name} - {self.description}"
        return f"{self.eid}:{self.name}"

    def detail(self) -> str:
        """Return full detail including all analysis metadata."""
        parts = [
            f"eid:{self.eid}",
            f"name:{self.name}",
            f"description:{self.description}",
        ]

        if self.inferred_primary_keys:
            parts.append(
                f"inferred_primary_keys:{','.join(self.inferred_primary_keys)}"
            )

        if self.inferred_foreign_keys:
            fk_strs = [
                f"{col}->{ref.target_column}"
                for col, ref in self.inferred_foreign_keys.items()
            ]
            parts.append(f"inferred_foreign_keys:{','.join(fk_strs)}")

        return " | ".join(parts)

    # -------------------------------------------------------------------------
    # Computed field properties backed by builtins
    # -------------------------------------------------------------------------

    @computed_field
    @property
    def name(self) -> str:
        """Get the human-friendly table name."""
        return builtins.name[self.eid].value or ""

    @name.setter
    def name(self, value: str) -> None:
        """Set the human-friendly table name."""
        builtins.name[self.eid].value = value

    @computed_field
    @property
    def description(self) -> str:
        """Get the purpose description (140 chars max)."""
        return builtins.description[self.eid].value or ""

    @description.setter
    def description(self, value: str) -> None:
        """Set the purpose description."""
        builtins.description[self.eid].value = value

    ## TODO: Consider value of making columns their own entity instead of field on SourceAnalysis.
    @computed_field
    @property
    def column_analyses(self) -> dict[str, ColumnAnalysisData]:
        """Get column-level analysis metadata."""
        return builtins.column_analyses[self.eid].value or {}

    @column_analyses.setter
    def column_analyses(self, value: dict[str, ColumnAnalysisData]) -> None:
        """Set column-level analysis metadata."""
        if value:
            builtins.column_analyses[self.eid].value = value
        else:
            builtins.column_analyses.delete(self.eid)

    @computed_field
    @property
    def inferred_primary_keys(self) -> list[str]:
        """Get LLM-inferred primary key columns.

        Distinguishes from canonical Snowflake primary keys.
        """
        return builtins.inferred_primary_keys[self.eid].value or []

    @inferred_primary_keys.setter
    def inferred_primary_keys(self, value: list[str]) -> None:
        """Set LLM-inferred primary key columns."""
        if value:
            builtins.inferred_primary_keys[self.eid].value = value
        else:
            builtins.inferred_primary_keys.delete(self.eid)

    @computed_field
    @property
    def inferred_foreign_keys(self) -> dict[str, ForeignKeyRef]:
        """Get LLM-inferred foreign key relationships.

        Distinguishes from canonical Snowflake foreign keys.
        """
        return builtins.inferred_foreign_keys[self.eid].value or {}

    @inferred_foreign_keys.setter
    def inferred_foreign_keys(self, value: dict[str, ForeignKeyRef]) -> None:
        """Set LLM-inferred foreign key relationships."""
        if value:
            builtins.inferred_foreign_keys[self.eid].value = value
        else:
            builtins.inferred_foreign_keys.delete(self.eid)

    @computed_field
    @property
    def inferred_unify_relationships(self) -> dict[str, list[UnifyRef]]:
        """Get LLM-inferred soft-join relationships.

        These are semantic relationships not captured by database constraints.
        """
        return builtins.inferred_unify_relationships[self.eid].value or {}

    @inferred_unify_relationships.setter
    def inferred_unify_relationships(self, value: dict[str, list[UnifyRef]]) -> None:
        """Set LLM-inferred soft-join relationships."""
        if value:
            builtins.inferred_unify_relationships[self.eid].value = value
        else:
            builtins.inferred_unify_relationships.delete(self.eid)

    # -------------------------------------------------------------------------
    # Derived/combined properties (for future canonical + inferred merge)
    # -------------------------------------------------------------------------

    @computed_field
    @property
    def primary_keys(self) -> list[str]:
        """Get combined primary keys (canonical + inferred).

        TODO: Currently returns only inferred keys. When canonical Snowflake
        constraint metadata is added to Source, this should merge:
        - Canonical PKs from INFORMATION_SCHEMA.TABLE_CONSTRAINTS (truth when present)
        - Inferred PKs from LLM (fill gaps, require confidence threshold)

        Returns:
            Combined list of primary key column names
        """
        # TODO: Merge canonical + inferred when canonical support is added
        return self.inferred_primary_keys

    @computed_field
    @property
    def foreign_keys(self) -> dict[str, ForeignKeyRef]:
        """Get combined foreign keys (canonical + inferred).

        TODO: Currently returns only inferred keys. When canonical Snowflake
        constraint metadata is added, this should merge:
        - Canonical FKs from INFORMATION_SCHEMA.KEY_COLUMN_USAGE (truth when present)
        - Inferred FKs from LLM (fill gaps, validate against existing sources)

        Returns:
            Combined dict of foreign key relationships
        """
        # TODO: Merge canonical + inferred when canonical support is added
        return self.inferred_foreign_keys

    @computed_field
    @property
    def unify_relationships(self) -> dict[str, list[UnifyRef]]:
        """Get soft-join relationships.

        Note: These are semantic relationships not captured by database constraints,
        so there are no "canonical" unify relationships - only inferred.

        Returns:
            Dict of soft-join relationships
        """
        return self.inferred_unify_relationships

    # -------------------------------------------------------------------------
    # Factory method
    # -------------------------------------------------------------------------

    @classmethod
    def create(
        cls,
        source_eid: UUID,
        name: str,
        description: str,
        column_analyses: dict[str, ColumnAnalysisData] | None = None,
        inferred_primary_keys: list[str] | None = None,
        inferred_foreign_keys: dict[str, ForeignKeyRef] | None = None,
        inferred_unify_relationships: dict[str, list[UnifyRef]] | None = None,
    ) -> SourceAnalysis:
        """Create a new SourceAnalysis from analysis results.

        Uses the source's eid to link analysis to source without explicit FK.

        Args:
            source_eid: EID of the Source entity this analysis is for
            name: Human-friendly table name
            description: Purpose description (140 chars max)
            column_analyses: Per-column analysis metadata
            inferred_primary_keys: LLM-inferred primary key columns
            inferred_foreign_keys: LLM-inferred foreign key relationships
            inferred_unify_relationships: LLM-inferred soft-join relationships

        Returns:
            A new SourceAnalysis component wrapping the entity
        """
        # Use the source's eid to link analysis to source
        analysis = cls(eid=source_eid)

        # Mark this entity as a SourceAnalysis (identity type marker)
        builtins.source_analysis_type.eids.append(source_eid)

        # Set all fields, letting property setters handle None/empty values
        analysis.name = name
        analysis.description = description

        # Optional fields - only set if provided
        if column_analyses is not None:
            analysis.column_analyses = column_analyses
        if inferred_primary_keys is not None:
            analysis.inferred_primary_keys = inferred_primary_keys
        if inferred_foreign_keys is not None:
            analysis.inferred_foreign_keys = inferred_foreign_keys
        if inferred_unify_relationships is not None:
            analysis.inferred_unify_relationships = inferred_unify_relationships

        return analysis
