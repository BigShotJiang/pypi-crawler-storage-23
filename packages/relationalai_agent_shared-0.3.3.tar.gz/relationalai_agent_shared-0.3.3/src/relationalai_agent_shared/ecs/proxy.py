"""@per_model decorator for model-scoped relations using inheritance.

The @per_model decorator creates a subclass that inherits from the relation class,
solving isinstance() checks and Pydantic validation while dispatching to per-model instances.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

if TYPE_CHECKING:
    from .base import BaseRelation

T = TypeVar("T")


class RowProxy:
    """Proxy for row-style access with transaction enforcement.

    Used when accessing relation[eid] to provide row-style interface.
    """

    def __init__(self, relation: BaseRelation, eid: UUID):
        object.__setattr__(self, "_relation", relation)
        object.__setattr__(self, "_eid", eid)

    def __getattr__(self, field_name: str) -> Any:
        """Get field value for this entity.

        Provides "read your writes" consistency - checks active transaction's
        buffered changes before falling back to committed data.
        """
        from .model import get_active_transaction

        relation = object.__getattribute__(self, "_relation")
        eid = object.__getattribute__(self, "_eid")

        # Get the column (field array)
        if not hasattr(relation, field_name):
            raise AttributeError(f"Relation has no field '{field_name}'")

        column = getattr(relation, field_name)
        if not isinstance(column, list):
            raise AttributeError(f"Field '{field_name}' is not a relation column")

        # Check active transaction's buffered changes first (read your writes)
        transaction = get_active_transaction()
        if transaction is not None and relation.id in transaction.changesets:
            # Look for the most recent change to this field for this eid
            for change in reversed(transaction.changesets[relation.id]):
                if change.eid == eid and change.field_name == field_name:
                    return change.value

        # Fall back to committed data in the relation
        idx = relation._get_index(eid)
        if idx is not None and idx < len(column):
            return column[idx]

        # Not found or sparse - return smart default based on column type
        if len(column) > 0 and isinstance(column[0], list):
            return []  # list[list[T]] → []
        return None  # scalar → None

    def __setattr__(self, field_name: str, value: Any) -> None:
        """Set field value - requires active transaction."""
        from .model import Change, get_active_transaction

        relation = object.__getattribute__(self, "_relation")
        transaction = get_active_transaction()
        if transaction is None:
            raise RuntimeError(
                f"Cannot modify relation {relation.id} outside of transaction. "
                f"Use 'with Transaction(model):' (sync) or 'async with Transaction(model):' (async)."
            )

        eid = object.__getattribute__(self, "_eid")

        # Record change for commit
        transaction.record_change(
            relation.id, Change(field_name=field_name, eid=eid, value=value)
        )


T = TypeVar("T", bound=type)


def per_model(cls: T) -> T:  # type: ignore[type-var]
    """Decorator that creates a singleton instance with per-model dispatch.

    Returns a singleton instance (not a class) that inherits from the relation class.
    This makes isinstance() checks work while dispatching attribute access to
    per-model instances based on active model context.

    The returned singleton uses object.__new__ to bypass Pydantic's __init__, since
    it's just a dispatcher and shouldn't have its own data.

    Usage:
        @per_model
        class Name(BaseRelation):
            value: list[str] = Field(default_factory=list)

        # Name is now a singleton instance (not a class)
        # builtins.py exposes it as: name = Name
    """

    class PerModelRelation(cls):
        """Subclass that dispatches to per-model instances."""

        __wrapped_class__ = cls

        def __new__(cls):
            nonlocal instance
            return instance

        def __init__(self):
            """No-op init - singleton already created in decorator."""
            pass

        def _get_instance(self):
            """Get the per-model instance for the active model."""
            from .model import get_active_model

            model = get_active_model()
            if model is None:
                raise RuntimeError(
                    f"Cannot access {cls.__name__} outside of model context. "
                    f"Use 'with Model(...):' to activate a model context first."
                )

            # Access stored relation ID (set in decorator) using object.__getattribute__
            # to bypass the proxy's __getattribute__ which would cause recursion
            relation_id = object.__getattribute__(self, "_relation_id")
            # FIXME: Lazy instance creation - ideally, per-model instances should be
            # pre-registered when the model is created/loaded, not lazily on first access.
            # This would require refactoring model initialization to iterate through all
            # @per_model relations and create their instances upfront. Current lazy approach
            # works but makes initialization flow less explicit.
            if relation_id not in model._relations:
                instance = cls()
                instance.model_id = model.id
                model._relations[relation_id] = instance
            return model._relations[relation_id]

        def __getattribute__(self, name: str):
            """Dispatch attribute access to per-model instance."""
            # Dispatch to per-model instance for data attributes
            if not name.startswith("_"):
                instance = self._get_instance()
                return getattr(instance, name)

            # Fall back to default behavior for private/dunder attributes
            return object.__getattribute__(self, name)

        def __setattr__(self, name: str, value: Any):
            """Dispatch attribute setting to per-model instance."""
            if name in ("__wrapped_class__",):
                object.__setattr__(self, name, value)
                return

            instance = self._get_instance()
            setattr(instance, name, value)

        def __getitem__(self, eid: UUID):
            """Enable relation[eid] syntax."""
            instance = self._get_instance()
            return RowProxy(instance, eid)

        def model_dump_json(self, **kwargs) -> str:
            """Serialize the active model's relation instance to JSON."""
            instance = self._get_instance()
            return instance.model_dump_json(**kwargs)

        def model_validate_json(self, json_data: str, **kwargs):
            """Deserialize JSON to a relation instance."""
            # Use __wrapped_class__ which is the actual BaseRelation subclass
            return self.__wrapped_class__.model_validate_json(json_data, **kwargs)  # type: ignore[attr-defined]

        def clear(self):
            """Clear the active model's relation instance."""
            instance = self._get_instance()
            instance.clear()

    # Copy class metadata
    PerModelRelation.__name__ = cls.__name__
    PerModelRelation.__qualname__ = cls.__qualname__

    # Create and return singleton instance using __new__ to avoid __init__
    instance = object.__new__(PerModelRelation)
    object.__setattr__(instance, "__wrapped_class__", cls)

    # FIXME: This template instance is an anti-pattern, but it's a symptom of a bigger problem.
    # The coupling of relation classes to id is the original sin here. That just
    # doesn't work for dynamic relations, period. That's the real reason we need to
    # kill off this idea of a 1:1 correspondence between id and class. Having multiple
    # ids point to DynamicRelation (provided it can handle that correctly during creation)
    # is acceptable, but obviously can't happen here at the class level.
    #
    # FIXME: Relatedly, maintaining backcompat support for global relations was a terrible
    # mistake. We need to just make all relations universally require a model context, and
    # use the model as the sole registry, and be id -> instance instead of id -> type.
    # Specifically and _only_ for loading, BuiltinRelation should maintain a registry of
    # all builtin registry subclasses, to use them appropriately for deserializing builtins.

    template = cls()
    object.__setattr__(instance, "_relation_id", template.id)

    # Register in global registry for get_relation_by_id lookup
    from .registry import _RELATION_REGISTRY

    _RELATION_REGISTRY[template.id] = instance

    return PerModelRelation  # type: ignore[return-value]
