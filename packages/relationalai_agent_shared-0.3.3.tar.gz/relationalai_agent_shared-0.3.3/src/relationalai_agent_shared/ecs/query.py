"""Query domain models - interpretations, plans, and execution steps.

These types represent the semantic understanding and execution planning of natural
language queries. They are used by:
- QA pipeline (agent-skills) for internal processing
- Result types (agent-shared/results) for API responses
- Client SDKs for typed query plan inspection
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

# Type alias for normalized confidence scores
Normalized = float  # Should be in range [0.0, 1.0]


# ============================================================================
# Entity References (used in interpretations)
# ============================================================================

# FIXME: Decide if we need these separate from our existing entity type defs in components/
# FIXME: If we do, rename these to, e.g., ConceptEntity -> ConceptRef. We have existing, complete types for the entities, and these aren't them.


class ConceptEntity(BaseModel):
    """Reference to a concept in the model."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["concept"] = "concept"
    id: str


class RelationshipEntity(BaseModel):
    """Reference to a relationship in the model."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["relationship"] = "relationship"
    id: str
    fields: list[str] | None = Field(
        default=None,
        description="The specific field(s) referenced, if any",
    )


class SourceEntity(BaseModel):
    """Reference to a source table in the model."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["source"] = "source"
    id: str
    columns: list[str] | None = Field(
        default=None,
        description="The specific column(s) referenced, if any",
    )


Entity = ConceptEntity | RelationshipEntity | SourceEntity


# ============================================================================
# Query Interpretation Models
# ============================================================================


class Instance(BaseModel):
    """A variable instance in the query interpretation."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    name: str = Field(description="An intuitive and unique title for the instance")
    entity: Annotated[Entity, Field(discriminator="type")] = Field(
        description="What entity this variable is an instance of"
    )
    confidence: Normalized | None = Field(
        None, description="Confidence that this analysis is correct"
    )


class Interpretation(BaseModel):
    """An interpretation of a natural language query.

    Represents one possible semantic understanding of what the user is asking,
    including the entities referenced and how they relate to each other.
    """

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    description: str = Field(
        description="A very concise 40 character max but clear description of what this interprets the question to mean"
    )
    label: str | None = Field(
        default=None,
        description="2-4 word navigation label preserving key terminology (max 35 chars)",
    )
    instances: dict[str, Instance] = Field(
        description="Mapping of unique variable identifiers to referenced instances"
    )
    paths: list[list[str]] = Field(
        description="List of paths representing the arrangement of instances"
    )
    confidence: Normalized | None = Field(
        None, description="Confidence that this analysis is correct"
    )


class InterpretationList(BaseModel):
    """Wrapper for list of interpretations to satisfy Pydantic generic constraints."""

    interpretations: list[Interpretation] = Field(
        description="List of possible query interpretations"
    )


# ============================================================================
# Query Plan Models
# ============================================================================


class GetQueryStep(BaseModel):
    """Introduce new variables containing values for specified properties."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["get"] = "get"
    target: str = Field(description="The id of the instance to retrieve properties for")
    properties: dict[str, str] = Field(
        description="Mapping from unique variable ids to columns of the target"
    )


class JoinQueryStep(BaseModel):
    """Unify two or more variables (join between tables)."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["join"] = "join"
    vars: list[str] = Field(description="The vars to join")


class FilterQueryStep(BaseModel):
    """Filter results based on given input variables."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["filter"] = "filter"
    op: str
    inputs: list[str]


class ComputeQueryStep(BaseModel):
    """Compute value(s) based on given input variables."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["compute"] = "compute"
    op: str
    inputs: list[str]
    outputs: list[str]


class AggregateQueryStep(BaseModel):
    """Compute value(s) based on sets of given input variables."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["aggregate"] = "aggregate"
    op: str
    inputs: list[str]
    group: list[str] = Field(default_factory=list)
    outputs: list[str]


QueryPlanStep = (
    GetQueryStep
    | JoinQueryStep
    | FilterQueryStep
    | ComputeQueryStep
    | AggregateQueryStep
)


class VisualizationSpec(BaseModel):
    """Minimal visualization descriptor. Frontend converts to TileDescriptor.

    Backend emits this clean shape; the frontend shim layer assembles the legacy
    TileDescriptor / TilePartDescriptor / TileBoundRelationship format required
    by ChartTile and MetricTile.
    """

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    type: Literal["line", "bar", "metric"]
    title: str = Field(description="Human-readable chart title")
    # Chart fields (which columns from the data to use)
    x_field: str | None = Field(None, description="Column name for x-axis / categories")
    y_field: str | None = Field(None, description="Column name for y-axis / values")
    time_based: bool = Field(False, description="Hint: x-axis is temporal")
    color: str | None = Field(None, description="Optional series color hex string")
    # Metric-specific
    value_field: str | None = Field(None, description="Column name for metric value")
    label: str | None = Field(None, description="Display label for the metric")
    unit: str | None = Field(None, description='Unit string, e.g. "$" or "%"')
    precision: int | None = Field(None, description="Decimal places for metric display")
    comparison_field: str | None = Field(None, description="Optional comparison column")


class QueryPlan(BaseModel):
    """A logical query plan.

    Represents the execution strategy for answering a query, including the sequence
    of operations (get, join, filter, compute, aggregate) and the variables involved.
    """

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    steps: list[Annotated[QueryPlanStep, Field(discriminator="type")]]
    project: list[str] = Field(
        description="List of variables to include in the query result"
    )
    subjects: list[str] = Field(
        description="Concepts and relationships which are core to this query"
    )
    related: list[str] = Field(
        description="Concepts and relationships which are tangentially relevant"
    )
    confidence: Normalized | None = Field(
        None, description="Confidence that this analysis is correct"
    )
    visualization: VisualizationSpec | None = Field(
        None,
        description=(
            "Optional visualization metadata. When present, the frontend shim converts "
            "this spec + the plan's data rows into ECS Tile entities for rendering. "
            "Separate plans with different visualizations may have different cardinalities."
        ),
    )


# ============================================================================
# SQL Generation Models
# ============================================================================


class SQLQuery(BaseModel):
    """A generated SQL query."""

    type: Literal["sql"] = "sql"
    sql: str = Field(description="Complete Snowflake SQL query")
    confidence: Normalized | None = Field(
        None, description="Confidence that this analysis is correct"
    )
