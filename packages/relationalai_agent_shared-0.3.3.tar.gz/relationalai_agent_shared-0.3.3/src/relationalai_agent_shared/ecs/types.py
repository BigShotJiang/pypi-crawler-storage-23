"""Core ECS type definitions without circular dependencies."""

from __future__ import annotations

from enum import Enum


class Verbosity(str, Enum):
    """Verbosity level for component descriptions.

    - SUMMARY: Minimal information (e.g., "eid:name" or "fqn")
    - DETAILED: Full information including fields, descriptions, etc.
    """

    SUMMARY = "summary"
    DETAILED = "detailed"
