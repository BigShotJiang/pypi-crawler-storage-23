"""Base classes for the ECS (Entity-Component-System) runtime.

This module provides the foundational abstractions:
- BaseRelation: Columnar data storage (arrays of entity data)
- BaseComponent: Virtual wrappers that query relations
"""

from __future__ import annotations

import tempfile
import warnings
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, PrivateAttr, model_validator
from relationalai_agent_shared.persistence.file_adapter import FileAdapter

from .types import Verbosity

if TYPE_CHECKING:
    from relationalai_agent_shared.persistence.adapter import PersistenceAdapter


class RowProxy:
    """Proxy for row-style access to columnar relation data.

    Enables intuitive syntax: relation[eid].field_name
    Writes require an active transaction context.
    """

    def __init__(self, relation: BaseRelation, eid: UUID) -> None:
        object.__setattr__(self, "_relation", relation)
        object.__setattr__(self, "_eid", eid)

    def __getattr__(self, field_name: str) -> Any:
        """Get field value for this entity.

        Provides "read your writes" consistency - checks active transaction's
        buffered changes before falling back to committed data.

        Supports both typed Pydantic fields (BuiltinRelation) and generic
        columns (DynamicRelation via _columns dict).

        Example: married[zack].spouse → UUID
        """
        from .model import get_active_transaction

        relation = object.__getattribute__(self, "_relation")
        eid = object.__getattribute__(self, "_eid")

        # Get the column (abstracted to handle both typed fields and generic columns)
        column = relation.get_column(field_name)

        if not isinstance(column, list):
            raise AttributeError(f"Field '{field_name}' is not a relation column")

        # Check active transaction's buffered changes first (read your writes)
        transaction = get_active_transaction()
        if transaction is not None and relation.id in transaction.changesets:
            # Look for the most recent change to this field for this eid
            for change in reversed(transaction.changesets[relation.id]):
                if change.eid == eid and change.field_name == field_name:
                    return change.value

        # Fall back to committed data in the relation
        idx = relation._get_index(eid)
        if idx is not None and idx < len(column):
            return column[idx]

        # Not found or sparse - return smart default based on column type
        if len(column) > 0 and isinstance(column[0], list):
            return []  # list[list[T]] → []
        return None  # scalar → None

    def __setattr__(self, field_name: str, value: Any) -> None:
        """Set field value for this entity - requires active transaction.

        Supports both typed Pydantic fields (BuiltinRelation) and generic
        columns (DynamicRelation via _columns dict).

        Example:
            with model:
                with Transaction(model):
                    married[zack].spouse = cait
        """
        from .model import Change, get_active_transaction

        relation = object.__getattribute__(self, "_relation")
        eid = object.__getattribute__(self, "_eid")

        # Get the column (abstracted to handle both typed fields and generic columns)
        column = relation.get_column(field_name)

        if not isinstance(column, list):
            raise AttributeError(f"Field '{field_name}' is not a relation column")

        # Transaction is required
        transaction = get_active_transaction()
        if transaction is None:
            raise RuntimeError(
                f"Cannot modify relation {relation.id} outside of transaction. "
                f"Use 'async with Transaction(model):' to start a transaction."
            )

        # Record change for commit
        transaction.record_change(
            relation.id, Change(field_name=field_name, eid=eid, value=value)
        )


# TODO: MOD-1150 sort out the distinction and lack of connection between BaseRelation and Relationship(BaseComponent)
class BaseRelation(BaseModel):
    """Base class for columnar relations.

    Relations store data as parallel arrays (columnar storage), mapping
    directly to Snowflake table structure.

    Provides:
    - Entity ID tracking (eids array)
    - Generic column storage (dict-of-arrays in _columns)
    - Indexed lookups (lazy index building for O(1) access)
    - Common operations (has, delete with auto-cleanup)

    Subclasses (BuiltinRelation) add:
    - Typed Pydantic fields for compile-time type checking
    - IDE autocomplete support

    Optional fields are implicit - if an eid isn't in the eids array,
    that field is "not set" for that entity (sparse storage).
    """

    # Optional persistence adapter - configured per relation class
    persistence_adapter: ClassVar[PersistenceAdapter | None] = None

    # Instance fields
    model_id: str | None = (
        None  # Which model this data belongs to (None for global relations)
    )
    eids: list[UUID] = Field(
        default_factory=list, description="Entity IDs (primary key column)"
    )

    # Generic column storage (dict-of-arrays)
    # Key = column name, Value = array of values (parallel to eids)
    # Used by DynamicRelation for runtime-created columns
    _columns: dict[str, list[Any]] = PrivateAttr(default_factory=dict)

    _index: dict[UUID, int] | None = PrivateAttr(default=None)

    @property
    def id(self) -> str:
        """Relation identifier. Subclasses must implement this property."""
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement id property"
        )

    def __hash__(self):
        """Hash based on relation id and model_id for use in sets/dicts."""
        return hash((self.id, self.model_id))

    def __eq__(self, other):
        """Equality based on relation id and model_id."""
        if not isinstance(other, BaseRelation):
            return False
        return self.id == other.id and self.model_id == other.model_id

    # Generic column access methods
    def get_column(self, column_name: str) -> list[Any]:
        """Get a column by name, handling both typed fields and generic columns.

        For BuiltinRelation: Returns typed Pydantic field if it exists
        For DynamicRelation: Returns generic column from _columns dict

        This abstracts away the distinction so callers don't need to check model_fields.

        Returns:
            Column array (parallel to eids), or empty list if column doesn't exist
        """
        # Check if this is a typed Pydantic field (BuiltinRelation)
        if column_name in self.__class__.model_fields:
            return getattr(self, column_name)

        # Generic column (DynamicRelation or non-field access)
        return self._columns.get(column_name, [])

    def set_column(self, column_name: str, values: list[Any]) -> None:
        """Set a column by name, handling both typed fields and generic columns.

        For BuiltinRelation: Sets typed Pydantic field if it exists
        For DynamicRelation: Sets generic column in _columns dict

        This abstracts away the distinction so callers don't need to check model_fields.

        Args:
            column_name: Name of the column
            values: Array of values (must be parallel to eids)
        """
        # Check if this is a typed Pydantic field (BuiltinRelation)
        if column_name in self.__class__.model_fields:
            setattr(self, column_name, values)
        else:
            # Generic column (DynamicRelation or non-field access)
            self._columns[column_name] = values

    def get_columns_dict(self) -> dict[str, list[Any]]:
        """Get all generic columns as dict-of-arrays.

        Returns:
            Dictionary mapping column names to value arrays
        """
        return self._columns

    def set_columns_dict(self, columns: dict[str, list[Any]]) -> None:
        """Set all generic columns from dict-of-arrays.

        Always uses bulk replacement - clears existing data and sets new data.
        This is efficient for dynamic relations (query results, search results, etc.)

        Args:
            columns: Dictionary mapping column names to value arrays
        """
        from .model import get_active_transaction, Change

        # FIXME: This is violating the guarantee that txn edits aren't applied until commit, needs to be fixed

        # Capture old row count before clearing (needed for bulk replacement publishing)
        old_row_count = 0
        if self._columns:
            first_col = next(iter(self._columns.values()), None)
            if first_col:
                old_row_count = len(first_col)

        # Clear local state
        self._columns.clear()

        # Set new data locally
        for col_name, values in columns.items():
            self._columns[col_name] = list(values)

        # Update eids Pydantic field if provided in columns
        self.eids = columns.get("eids", [])
        self._invalidate_index()

        # Record single bulk replacement change with old row count
        transaction = get_active_transaction()
        if transaction is not None:
            transaction.record_change(
                self.id, Change.replace_all(self._columns, old_row_count)
            )

    def model_post_init(self, __context: Any) -> None:
        """Register relation instance in global registry.

        Only registers if not already present - @per_model decorator takes precedence.
        """
        _ = __context  # Unused but required by Pydantic signature
        # Register in global registry
        from .registry import _RELATION_REGISTRY

        # Only register if not already present (decorator takes precedence)
        if self.id not in _RELATION_REGISTRY:
            _RELATION_REGISTRY[self.id] = self

    def _build_index(self) -> dict[UUID, int]:
        """Build eid → array index mapping (cached).

        Lazily builds a dictionary mapping each eid to its position
        in the eids array for O(1) lookups.
        """
        if self._index is None:
            self._index = {eid: i for i, eid in enumerate(self.eids)}
        return self._index

    def _invalidate_index(self) -> None:
        """Invalidate cached index after mutations.

        Called after any operation that modifies the eids array
        (insert, delete) to force index rebuild on next access.
        """
        self._index = None

    def _get_index(self, eid: UUID) -> int | None:
        """Get array index for eid, or None if not found.

        Helper method for subclasses to use in their get/set methods.
        """
        return self._build_index().get(eid)

    def has(self, eid: UUID) -> bool:
        """Check if entity exists in this relation."""
        return eid in self._build_index()

    def __getitem__(self, eid: UUID) -> RowProxy:
        """Get row-style proxy for entity.

        Enables intuitive syntax: relation[eid].field = value

        Example:
            builtins.name[eid].value = "Jeff"
            builtins.married[zack].spouse = cait
        """
        return RowProxy(self, eid)

    def delete(self, eid: UUID) -> bool:
        """Delete entity from relation. Returns True if existed.

        Automatically removes the entity from ALL list fields at the
        same index position. Uses reflection to find all list fields
        and clean them up together.

        This ensures parallel arrays stay in sync - no orphaned data.
        """
        idx = self._get_index(eid)
        if idx is not None:
            # Delete from ALL list fields at this index
            for field_name in self.__class__.model_fields:
                field_value = getattr(self, field_name)
                if isinstance(field_value, list):
                    del field_value[idx]

            self._invalidate_index()
            return True
        return False

    # @TODO: Let's think about how persistence is implemented and probably push the implementation out into something aware of that
    def clear(self) -> None:
        """Clear all data from this relation.

        Removes all entities and resets all list fields to empty.
        Uses reflection to find all list fields and clear them together.
        """
        for field_name in self.__class__.model_fields:
            field_value = getattr(self, field_name)
            if isinstance(field_value, list):
                field_value.clear()
        self._invalidate_index()

    def _insert_rows(self, start: int, columns: dict[str, list[Any]]) -> None:
        """Insert rows at position (increases length).

        Internal method for sync protocol. Not part of public API.

        Inserts elements into specified columns at the given position.
        All columns should be provided to maintain parallel array integrity.

        Args:
            start: Position to insert at
            columns: Dict of column_name -> values to insert
        """
        for col_name, col_values in columns.items():
            col = getattr(self, col_name)
            for i, value in enumerate(col_values):
                col.insert(start + i, value)
        self._invalidate_index()

    def _update_rows(self, start: int, columns: dict[str, list[Any]]) -> None:
        """Update rows in-place (no length change).

        Internal method for sync protocol. Not part of public API.

        Updates elements at specified positions. Partial columns allowed
        for efficiency - only provided columns are updated.

        Args:
            start: Index to start updating at
            columns: Dict of column_name -> values to update
        """
        for col_name, col_values in columns.items():
            col = getattr(self, col_name)
            for i, value in enumerate(col_values):
                col[start + i] = value
        self._invalidate_index()

    def _delete_rows(self, start: int, count: int) -> None:
        """Delete rows (decreases length).

        Internal method for sync protocol. Not part of public API.

        Removes elements from all columns to maintain parallel array integrity.

        Args:
            start: Start index
            count: Number of rows to delete
        """
        for field_name in self.__class__.model_fields:
            field_value = getattr(self, field_name)
            if isinstance(field_value, list):
                del field_value[start : start + count]
        self._invalidate_index()


def get_persistence_path() -> Path:
    try:
        # FIXME: shouldn't ever reach forward like this.
        # The real issue here is that BuiltinRelation and DynamicRelation
        # are implementation details on the server side, but because of some
        # messy up-front prototyping they ended up in the shared abstraction
        # layer and depended upon all over the place, which is a bigger refactor
        from model_server_new.config import get_config
        return get_config().models.base_path
    except Exception:
        tmpdir = Path(tempfile.mkdtemp())
        warnings.warn(
            f"Failed to load config; using temporary directory for persistence: {tmpdir}. "
            "Configure [models] base_path in config.toml for durable storage.",
            stacklevel=2,
        )
        return tmpdir


class BuiltinRelation(BaseRelation):
    """Base class for builtin relations with class-based IDs.

    Builtin relations are defined in builtins.py and have IDs derived from
    their class names (e.g., "sys::Name", "sys::Description").

    Typed fields provide concise definitions with type hints and IDE support.
    These fields are also mirrored in _columns for unified generic access,
    allowing both typed access (relation.value) and generic access
    (relation.get_column("value")) to work on the same data.

    Subclasses automatically get an ID based on their class name without
    needing to implement the id property.
    """

    persistence_adapter = FileAdapter(get_persistence_path())

    def model_post_init(self, __context: Any) -> None:
        """Mirror typed field values into _columns for unified access."""
        super().model_post_init(__context)

        # Base fields that should NOT be copied to _columns
        base_fields = {"model_id", "eids"}

        # Mirror typed field references to _columns
        # This allows generic access via get_column() to work alongside typed access
        for field_name in self.__class__.model_fields:
            if field_name not in base_fields:
                # Store reference to the Pydantic field list in _columns
                # Both typed access and generic access will use the same list
                self._columns[field_name] = getattr(self, field_name)

    @property
    def id(self) -> str:
        """Return class-based relation ID (e.g., 'sys::Name')."""
        return f"sys::{type(self).__name__}"

    def __getattr__(self, name: str) -> Any:
        """Fall back to _columns for attribute access.

        This enables accessing generic columns (stored in _columns dict) via
        attribute syntax, which is needed when deserializing builtin relations
        whose class isn't available (e.g., test classes not in builtins module).

        When a BuiltinRelation is deserialized without its class definition,
        the fallback code creates a generic BuiltinRelation and stores field
        data in _columns. This __getattr__ makes that data accessible via
        attribute syntax (e.g., loaded.value instead of loaded.get_column('value')).

        Pydantic's __getattr__ is called only when normal attribute lookup fails,
        so this doesn't interfere with typed fields on BuiltinRelation subclasses.
        """
        # Try to get from _columns (if it exists and has been initialized)
        try:
            private = object.__getattribute__(self, "__pydantic_private__")
            columns = private.get("_columns")
            if columns is not None and name in columns:
                return columns[name]
        except (AttributeError, KeyError):
            # _columns not initialized yet or doesn't exist
            pass

        # Not found - let Pydantic's __getattr__ handle it (raises AttributeError if needed)
        return super().__getattr__(name)


class BaseComponent(BaseModel, ABC):
    """Base class for components (virtual entity views).

    Components provide a convenient interface to query relations.
    They store only an entity ID and query data from builtins relations.

    Components define which relations are required for an entity to be
    considered "of this type" via get_required_relations().

    Uses Pydantic for automatic __init__ generation:
        Concept()  # Auto-generates eid
        Concept(eid=known_eid)  # Attaches to existing entity
    """

    # NOTE: If we eventually feel the pain of manual property creation, we can consider a factory creator here.
    # However, handling relations with multiple / optional fields complicates that pattern.

    eid: UUID = Field(default_factory=uuid4)

    @model_validator(mode="wrap")
    @classmethod
    def hydrate_from_data(cls, data: Any, handler: Any) -> "BaseComponent":
        """Populate builtins relations from deserialized data using setters.

        When deserializing from JSON, extract field values from the raw dict,
        construct the object normally, then use property setters to populate
        the builtins relations.

        This also ensures nested Pydantic models (like RelationField, Capability)
        are properly validated and hydrated.
        """
        if isinstance(data, dict):
            # Construct the object (sets eid and entity_type)
            instance = handler(data)

            # Loop over computed fields and set from data if present
            for field_name in cls.model_computed_fields:
                if field_name in data:
                    # Skip read-only computed fields (no setter defined)
                    prop = getattr(cls, field_name, None)
                    if isinstance(prop, property) and prop.fset is None:
                        continue

                    raw_value = data[field_name]

                    # Get the field's return type annotation for validation
                    field_info = cls.model_computed_fields[field_name]
                    return_type = field_info.return_type

                    # Validate nested Pydantic models using TypeAdapter
                    from pydantic import TypeAdapter

                    validated_value = TypeAdapter(return_type).validate_python(
                        raw_value
                    )

                    # Use setter with validated value
                    setattr(instance, field_name, validated_value)

            return instance
        else:
            # Not a dict (maybe already an instance), just pass through
            return handler(data)

    @classmethod
    @abstractmethod
    def get_required_relations(cls) -> list[str]:
        """Return list of relation names required for this component to exist.

        These are the relation types that must have data for this entity
        for it to be queryable as this component type.

        Example:
            return ["name", "description"]
        """
        ...

    # TODO: lets just switch to summary and detail
    @abstractmethod
    def describe(self, verbosity: Verbosity) -> str:
        """Return a string description of this component.

        Args:
            verbosity: Level of detail to include in the description.
                      SUMMARY: Minimal info (e.g., "eid:name")
                      DETAILED: Full info (e.g., "eid:name - description")

        Returns:
            Formatted string representation of the component.
        """
        ...

    @abstractmethod
    def summary(self) -> str:
        """Return terse summary for LLM context (provided upfront in prompts).

        Summary should be as concise as possible while giving the LLM enough
        information to determine relevance. Used to populate model schema
        summaries at the start of agent tasks.

        Returns:
            Single-line string summary of this entity
        """
        ...

    @abstractmethod
    def detail(self) -> str:
        """Return full detail for LLM context (provided on-demand via tools).

        Detail includes everything we know about this entity - descriptions,
        metadata, relationships, constraints, etc. Used when the LLM requests
        more information about specific entities.

        Returns:
            Multi-line detailed description of this entity
        """
        ...

    def exists(self) -> bool:
        """Check if this entity has all required relations.

        Returns True if the entity has data in all relations specified
        by get_required_relations().
        """
        from . import builtins

        return all(
            getattr(builtins, rel).has(self.eid)
            for rel in self.get_required_relations()
        )
