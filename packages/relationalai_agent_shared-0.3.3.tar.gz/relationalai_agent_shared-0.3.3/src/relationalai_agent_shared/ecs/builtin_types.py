"""Builtin type UUIDs and SQL-type mapping for task body Var.type_eid values.

All builtin type EIDs live under the 00000001 namespace. The second UUID
cluster encodes the base type; remaining clusters are zero for non-parameterised
types. Decimal types additionally encode precision and scale in the last two
clusters.

UUID layout:
  00000001-{type:04d}-0000-0000-000000000000       non-parameterised scalar
  00000001-0008-0000-{precision:04d}-{scale:012d}  Decimal(p, s)

Type slot assignments:
  0001  String
  0002  Int
  0003  Float
  0004  Bool
  0005  Date
  0006  DateTime
  0007  (reserved for Time)
  0008  Decimal(p, s)
  0000..0  Unknown (all-zeros sentinel)
"""

from __future__ import annotations

import re as _re
from uuid import UUID

# TypeId is always a UUID — a concept eid or a builtin type eid defined in this module.
# Defined here (rather than in task_body.py) because it is the type system's own alias.
TypeId = UUID

# ---------------------------------------------------------------------------
# Non-parameterised scalar types
# ---------------------------------------------------------------------------

_BUILTIN_TYPE_PREFIX = "00000001-"


def is_primitive_type_eid(eid: TypeId | str) -> bool:
    """True if *eid* is a builtin scalar type UUID (String, Int, Float, Date, etc.).

    All builtin scalar type UUIDs share the ``00000001-`` prefix. Concept eids
    never have this prefix, so this is a reliable way to distinguish scalar types
    from concept types without needing a set of known concept eids.
    """
    return str(eid).startswith(_BUILTIN_TYPE_PREFIX)


SCALAR_TYPE_STRING: TypeId = UUID("00000001-0001-0000-0000-000000000000")
SCALAR_TYPE_INT: TypeId = UUID("00000001-0002-0000-0000-000000000000")
SCALAR_TYPE_FLOAT: TypeId = UUID("00000001-0003-0000-0000-000000000000")
SCALAR_TYPE_BOOL: TypeId = UUID("00000001-0004-0000-0000-000000000000")
SCALAR_TYPE_DATE: TypeId = UUID("00000001-0005-0000-0000-000000000000")
SCALAR_TYPE_DATETIME: TypeId = UUID("00000001-0006-0000-0000-000000000000")
# 0007 reserved for SCALAR_TYPE_TIME
# 0008 = Decimal(p, s) — parameterised, see below
SCALAR_TYPE_UNKNOWN: TypeId = UUID("00000000-0000-0000-0000-000000000000")

BUILTIN_SCALAR_TYPES: dict[TypeId, str] = {
    SCALAR_TYPE_STRING: "String",
    SCALAR_TYPE_INT: "Int",
    SCALAR_TYPE_FLOAT: "Float",
    SCALAR_TYPE_BOOL: "Bool",
    SCALAR_TYPE_DATE: "Date",
    SCALAR_TYPE_DATETIME: "DateTime",
}

# ---------------------------------------------------------------------------
# Parameterised decimal types
# ---------------------------------------------------------------------------

_DECIMAL_UUID_PREFIX = "00000001-0008-0000-"


def decimal_type_eid(precision: int, scale: int) -> TypeId:
    """Return the stable UUID for ``Decimal(precision, scale)``.

    Precision and scale are encoded directly in the UUID fields, making the
    EID self-describing and round-trippable without any registry.
    """
    return UUID(f"{_DECIMAL_UUID_PREFIX}{precision:04d}-{scale:012d}")


def is_decimal_type_eid(eid: TypeId) -> bool:
    """True if *eid* was produced by :func:`decimal_type_eid`."""
    return str(eid).startswith(_DECIMAL_UUID_PREFIX)


def get_decimal_params(eid: TypeId) -> tuple[int, int] | None:
    """Return ``(precision, scale)`` for a decimal type UUID, or ``None``."""
    s = str(eid)
    if not s.startswith(_DECIMAL_UUID_PREFIX):
        return None
    parts = s.split("-")
    return (int(parts[3]), int(parts[4]))


# ---------------------------------------------------------------------------
# Builtin eid → PyRel type name (used by emitter)
# ---------------------------------------------------------------------------


def builtin_eid_to_pyrel_name(eid: TypeId) -> str | None:
    """Map a builtin type UUID to the PyRel type name string, or ``None``.

    Handles both non-parameterised scalars (String, Integer, Float, etc.) and
    parameterised decimals (Number.size(p, s)).  Returns ``None`` for concept
    eids or unknown UUIDs.

    PyRel name conventions:
      - "Integer" (not "Int") — matches PyRel SDK imports and docs
      - "Number.size(p,s)" for parameterised decimals
    """
    # Parameterised decimal first (more specific prefix)
    if is_decimal_type_eid(eid):
        params = get_decimal_params(eid)
        if params:
            return f"Number.size({params[0]},{params[1]})"
        return None

    # Non-parameterised scalar
    _PYREL_NAMES: dict[TypeId, str] = {
        SCALAR_TYPE_STRING: "String",
        SCALAR_TYPE_INT: "Integer",
        SCALAR_TYPE_FLOAT: "Float",
        SCALAR_TYPE_BOOL: "Bool",
        SCALAR_TYPE_DATE: "Date",
        SCALAR_TYPE_DATETIME: "DateTime",
    }
    return _PYREL_NAMES.get(eid)


# ---------------------------------------------------------------------------
# SQL type → builtin type EID
# ---------------------------------------------------------------------------

# Matches NUMBER/DECIMAL/NUMERIC with explicit (precision, scale)
_DECIMAL_SIG_RE = _re.compile(
    r"^(?:NUMBER|DEC|DECIMAL|NUMERIC)\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)"
)


def parse_decimal_sql(sql_type: str) -> tuple[int, int] | None:
    """Parse ``(precision, scale)`` from a decimal SQL type string, or ``None``.

    Matches ``NUMBER(p,s)``, ``DECIMAL(p,s)``, ``NUMERIC(p,s)``, ``DEC(p,s)``.
    Returns ``None`` for bare type names without explicit precision/scale.
    """
    m = _DECIMAL_SIG_RE.match(sql_type.strip().upper())
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)))


def sql_type_to_type_eid(sql_type: str) -> TypeId:
    """Map a SQL column type string to a builtin type UUID.

    Fixed-point types with explicit ``(precision, scale)`` — e.g.
    ``DECIMAL(18,4)``, ``NUMERIC(10,2)``, ``NUMBER(38,6)`` — return a
    parameterised decimal UUID via :func:`decimal_type_eid` so that the
    emitter can recover full precision/scale information.  Types without
    precision/scale (or with scale 0) collapse to ``SCALAR_TYPE_INT``.

    All other mappings follow ``sql_types._SF_BASE_MAPPING`` conventions used
    throughout the model-server.
    """
    t = sql_type.strip().upper()

    params = parse_decimal_sql(t)
    if params is not None:
        precision, scale = params
        if scale > 0:
            return decimal_type_eid(precision, scale)
        return SCALAR_TYPE_INT  # scale == 0 → integer semantics

    if any(k in t for k in ("INT", "NUMBER", "NUMERIC", "BIGINT", "SMALLINT")):
        return SCALAR_TYPE_INT
    if any(k in t for k in ("FLOAT", "REAL", "DOUBLE", "DECIMAL")):
        return SCALAR_TYPE_FLOAT
    if "BOOL" in t:
        return SCALAR_TYPE_BOOL
    if any(k in t for k in ("TIMESTAMP", "DATETIME")):
        return SCALAR_TYPE_DATETIME
    if any(k in t for k in ("DATE", "TIME")):
        return SCALAR_TYPE_DATE
    # VARIANT/OBJECT/ARRAY fall through here. Snowflake returns VARIANT values as
    # JSON-encoded strings, so String is a safe fallback for now. If we need to
    # round-trip semi-structured types through PyRel properly, we'd add a SCALAR_TYPE_VARIANT
    # (or similar) and handle it in the emitter. For now, String is conservative and correct.
    return SCALAR_TYPE_STRING  # VARCHAR, TEXT, CHAR, VARIANT, and anything else
