"""Request types for agent API requests.

These types define the contract for request payloads sent from client SDKs
to the agent server.

Based on the Agent API specification in docs/backend/agent-client-sdk/README.md
"""

from __future__ import annotations

from datetime import timedelta

from pydantic import BaseModel, Field

# Import types from ECS module
from .ecs import ModelFragment


class CapabilityConfig(BaseModel):
    """Controls what operations and output formats the agent can use.

    Attributes:
        query: Execute read queries (default: enabled)
        optimize: Suggest model optimizations (default: disabled)
        predict: Use predictive analytics (default: disabled)
        visualize: Generate charts and visualizations (default: disabled)
    """

    query: bool = True
    optimize: bool = False
    predict: bool = False
    visualize: bool = False


class Quotas(BaseModel):
    """Resource limits for agent execution.

    Attributes:
        max_execution_time: Total wall-clock time for query
        max_compute_units: Total compute resources across all tasks
        max_result_size: Total size of returned data
        max_llm_tokens: Total tokens for planning, analysis, synthesis
        max_llm_calls: Number of LLM invocations
    """

    max_execution_time: timedelta | None = None
    max_compute_units: int | None = None
    max_result_size: int | None = None
    max_llm_tokens: int | None = None
    max_llm_calls: int | None = None


class AskRequest(BaseModel):
    """Request body for asking the agent a question.

    Attributes:
        question: Natural language query
        capabilities: Override allowed operations
        quotas: Override resource limits
        context: Model context (concepts, relationships, sources) for the agent
    """

    question: str = Field(..., description="Natural language query")
    capabilities: CapabilityConfig | None = Field(
        default=None, description="Override allowed operations"
    )
    quotas: Quotas | None = Field(default=None, description="Override resource limits")
    context: ModelFragment | None = Field(
        default=None, description="Model context for the agent"
    )
