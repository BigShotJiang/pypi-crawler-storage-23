"""Sync protocol message types with namespaced operations and fluent builder."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, field_serializer
from pydantic.alias_generators import to_camel
from pydantic.functional_validators import BeforeValidator

from relationalai_agent_shared.ecs.base import BaseRelation


def serialize_relation(relation: BaseRelation) -> str:
    """Convert relation instance to its id."""
    return relation.id


def deserialize_relation(value: str | BaseRelation) -> BaseRelation:
    """Convert id back to relation instance."""
    if isinstance(value, str):
        from relationalai_agent_shared.ecs.registry import get_relation_by_id

        return get_relation_by_id(value)

    # Already a relation (BaseRelation or subclass), return as-is
    return value


# Validator converts string IDs to relation instances, serializer converts back
RelationRef = Annotated[BaseRelation, BeforeValidator(deserialize_relation)]


class Op:
    """Namespace for operation types. Use Op.Insert, Op.Update, Op.Delete."""

    class Insert(BaseModel):
        """Insert elements at position (increases length).

        All columns required to maintain parallel array integrity.

        Example:
            # Insert two entities at position 0
            Op.Insert(
                relation=builtins.name,
                start=0,
                columns={"eids": [uuid1, uuid2], "value": ["Customer", "Order"]}
            )
        """

        model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

        op: Literal["insert"] = "insert"
        relation: RelationRef
        start: int
        columns: dict[str, list[Any]]

        @field_serializer("relation")
        def serialize_relation_field(self, relation: BaseRelation) -> str:
            return serialize_relation(relation)

        def apply(self) -> None:
            """Apply this insert operation to the relation."""
            self.relation._insert_rows(self.start, self.columns)

    class Update(BaseModel):
        """Update elements in-place (no length change).

        Can overwrite entire rows (all columns) or partial rows (subset of columns).
        Partial updates are more efficient for large relations.

        Example (partial row):
            # Update only the value column at position 5
            Op.Update(
                relation=builtins.name,
                start=5,
                columns={"value": ["UpdatedName"]}  # eid stays unchanged
            )

        Example (entire row):
            # Update both eid and value at position 5
            Op.Update(
                relation=builtins.name,
                start=5,
                columns={"eids": [new_uuid], "value": ["NewName"]}
            )
        """

        model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

        op: Literal["update"] = "update"
        relation: RelationRef
        start: int
        columns: dict[str, list[Any]]

        @field_serializer("relation")
        def serialize_relation_field(self, relation: BaseRelation) -> str:
            return serialize_relation(relation)

        def apply(self) -> None:
            """Apply this update operation to the relation.

            Updates elements in-place. Partial columns allowed for efficiency.
            """
            self.relation._update_rows(self.start, self.columns)

    class Delete(BaseModel):
        """Delete elements (decreases length).

        Removes from all columns to maintain parallel array integrity.

        Example:
            # Delete 2 elements starting at position 10
            Op.Delete(
                relation=builtins.name,
                start=10,
                count=2
            )
        """

        model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

        op: Literal["delete"] = "delete"
        relation: RelationRef
        start: int
        count: int

        @field_serializer("relation")
        def serialize_relation_field(self, relation: BaseRelation) -> str:
            return serialize_relation(relation)

        def apply(self) -> None:
            """Apply this delete operation to the relation.

            Removes elements from all columns to maintain parallel array integrity.
            """
            self.relation._delete_rows(self.start, self.count)


Operation = Op.Insert | Op.Update | Op.Delete


class SyncChunk(BaseModel):
    """A chunk of sync operations for streaming relation data.

    Note: Sequence numbering is handled by Envelope.Out.seq, not in the
    chunk payload itself. Each client gets independent sequence numbering
    via Client wrapper.

    Channel routing is handled by Envelope.In.channel, not in the message itself.
    """

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    message_type: Literal["sync_chunk"] = "sync_chunk"
    batch_id: str
    is_last: bool
    operations: list[Operation]

    def apply(self) -> None:
        """Apply all operations in this chunk to their relations."""
        for op in self.operations:
            op.apply()


class ModelMetadata(BaseModel):
    """Metadata about a model published to the models channel.

    Contains basic information about a model without its full entity data.
    Clients subscribe to the models channel to receive a list of available models.

    When the same id is sent again, it represents an update to that model.
    """

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    message_type: Literal["model_metadata"] = "model_metadata"
    id: str
    name: str
    description: str | None = None
    mtime: str  # ISO 8601 timestamp


class RemovedModel(BaseModel):
    """Notification that a model has been removed.

    Published to the models channel when a model is deleted.
    Clients should remove this model from their list.
    """

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    message_type: Literal["removed_model"] = "removed_model"
    id: str
