"""Sync protocol message types (isomorphic - shared between server and clients).

This package provides message types used by both server and clients:
- SyncChunk, Op (Insert/Update/Delete): Data sync operations
- Subscribe, Unsubscribe, etc.: Subscription protocol messages

Note: Channel management and ChunkBuilder are server-side only (agent-core/sync).
"""

from relationalai_agent_shared.sync.messages import (
    ModelMetadata,
    Op,
    Operation,
    RemovedModel,
    SyncChunk,
    deserialize_relation,
    serialize_relation,
)
from relationalai_agent_shared.sync.subscription import (
    Subscribe,
    SubscribeResponse,
    SyncComplete,
    Unsubscribe,
    UnsubscribeResponse,
)

__all__ = [
    # Operation types
    "Op",
    "Operation",
    "SyncChunk",
    # Subscription protocol messages
    "Subscribe",
    "SubscribeResponse",
    "Unsubscribe",
    "UnsubscribeResponse",
    "SyncComplete",
    # Channel messages
    "ModelMetadata",
    "RemovedModel",
    # Serialization helpers
    "serialize_relation",
    "deserialize_relation",
]
