"""Subscription message types for sync protocol."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class Subscribe(BaseModel):
    """Request to subscribe to a sync channel."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    channel: str


class SubscribeResponse(BaseModel):
    """Response to subscription request."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    channel: str
    subscription_id: str
    sync_version: str = "v1"


class Unsubscribe(BaseModel):
    """Request to unsubscribe from a sync channel."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    channel: str


class UnsubscribeResponse(BaseModel):
    """Response to unsubscription request."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    channel: str
    success: bool


class SyncComplete(BaseModel):
    """Notification that initial sync is complete.

    Channel routing is handled by Envelope.In.channel, not in the message itself.
    """

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

    message_type: str = "sync_complete"
    batch_id: str
