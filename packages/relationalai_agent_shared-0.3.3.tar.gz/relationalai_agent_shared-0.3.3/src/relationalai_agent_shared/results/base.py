"""Base result class shared by all result types.

This module contains only the abstract base class that all results inherit from.
"""

from __future__ import annotations

from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

# Type alias for result identifiers
ResultId = str


class _Result(BaseModel):
    """Base class for all result types.

    This defines the minimal data contract shared across all results.
    Client SDKs may extend these types with additional helper methods.

    Results can be either final (data, prose) or intermediate (interpretations, plans).
    Intermediate results are by-products of the execution process that provide visibility
    into pipeline progress, while final results are the actual answers to questions.

    Configured for camelCase serialization to support WebSocket clients.
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,  # Accept snake_case field names on input
        validate_by_alias=True,  # Accept camelCase aliases on input
    )

    id: ResultId = Field(default_factory=lambda: str(uuid4()))
    intermediate: bool = Field(
        default=False,
        description="Whether this is an intermediate result (true) or final answer (false)",
    )
    # type field is defined by subclasses with specific Literal values
