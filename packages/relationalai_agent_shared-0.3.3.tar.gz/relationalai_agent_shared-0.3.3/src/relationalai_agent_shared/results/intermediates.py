"""Intermediate result types for pipeline progress visibility.

These are result wrappers around domain models from ecs.query.
They represent by-products of the execution graph, not final answers.
They provide rich type information for UIs to display pipeline progress.

TODO (Phase 2): Port to redwood2 event system for structured logging
TODO (Phase 2): Integrate result data into data management and syncing system:
  - Ensure created Task for Search is executable (SQLTask for SQL pipeline, TBD for DSL pipeline)
  - Target task to result relation for refresh
  - Inject already-retrieved results into cache to avoid re-execution
  - rest should be completely handled by existing generic systems
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field

# Import domain models from ecs
from ..ecs.query import Interpretation, QueryPlan

# Import base result class
from .base import _Result


class InterpretationResult(_Result):
    """Intermediate result: semantic interpretations of the query.

    Yielded after the interpret phase to show how the pipeline understood
    the user's question in terms of model entities.
    """

    type: Literal["interpretation"] = "interpretation"
    intermediate: bool = True

    interpretations: list[Interpretation] = Field(
        description="Structured interpretation data with entity references"
    )


class QueryPlanResult(_Result):
    """Intermediate result: execution plan for the query.

    Yielded after the plan phase to show the logical steps the pipeline
    will execute to answer the question.
    """

    type: Literal["query_plan"] = "query_plan"
    intermediate: bool = True

    plan: QueryPlan = Field(description="Structured plan with steps")


class CodeGenerationResult(_Result):
    """Intermediate result: generated code preview.

    Yielded when the pipeline generates executable code (SQL, PyRel DSL, etc.)
    to show what will be executed before actually running it.
    """

    type: Literal["code_generation"] = "code_generation"
    intermediate: bool = True

    code: str = Field(description="Generated code to execute")
    language: str = Field(
        description="Programming language or dialect (e.g., 'sql', 'pyrel')"
    )
    preview: str | None = Field(
        default=None, description="Short snippet for UI preview (optional)"
    )
