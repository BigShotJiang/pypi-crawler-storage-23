"""Final result types - actual answers to questions.

These are the terminal outputs of the pipeline that represent complete answers
to user queries, as opposed to intermediate results which show pipeline progress.
There may be multiple of these results if the question is answered in multiple parts
or with additional context.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

from ..ecs.query import VisualizationSpec
from .base import _Result


class DataResult(_Result):
    """Result that presents tabular data.

    Replaces QueryResult from the temporary text-to-SQL implementation.
    Holds structured data rows and pagination metadata.
    """

    type: Literal["data"] = "data"

    data: list[dict[str, Any]] = Field(
        description="Query results as list of dictionaries"
    )
    start_at: int = Field(default=0, ge=0, description="Offset for pagination")
    page_size: int | None = Field(default=None, description="Page size for pagination")
    sql: str | None = Field(
        default=None, description="The SQL query that generated this data"
    )
    entity_id: str | None = Field(
        default=None,
        description="ID of the DynamicRelation entity holding the persisted columnar data",
    )


class ProseSegment(BaseModel):
    """Character offset span marking a subject reference in prose text."""

    model_config = ConfigDict(
        alias_generator=to_camel, validate_by_name=True, validate_by_alias=True
    )

    start: int = Field(description="Start character offset")
    end: int = Field(description="End character offset")
    subject: Any = Field(
        description="The subject being referenced (TODO: define subject type)"
    )


class ProseResult(_Result):
    """Result containing natural language text with optional subject markup."""

    type: Literal["prose"] = "prose"

    text: str = Field(description="Natural language text (always inlined)")
    segments: list[ProseSegment] = Field(
        default_factory=list,
        description="Markup spans identifying subjects referenced in text",
    )


class InsufficientResult(_Result):
    """Result indicating the query cannot be answered with available information.

    Returned when the agent determines it lacks sufficient schema information
    to generate valid SQL for the user's question.
    """

    type: Literal["insufficient"] = "insufficient"

    reason: str = Field(
        description="Human-readable explanation of why the query cannot be answered"
    )
    missing: list[str] = Field(
        default_factory=list,
        description="Specific pieces of information that would be needed to answer",
    )


class QueryResult(_Result):
    """A single plan's execution result, paired with its visualization intent.

    The pipeline yields one QueryResult per QueryPlan. The visualization field
    passes through the spec from the plan untouched — the frontend shim layer
    converts VisualizationSpec + data rows into ECS entities for rendering.
    """

    type: Literal["query_result"] = "query_result"

    data: Annotated[
        DataResult | InsufficientResult,
        Field(discriminator="type"),
    ]
    visualization: VisualizationSpec | None = Field(
        None,
        description="Visualization intent from the originating QueryPlan, if any",
    )
