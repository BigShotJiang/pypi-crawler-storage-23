"""Result types for agent API responses.

This package contains both final results (answers to questions) and intermediate
results (by-products of execution that provide visibility into pipeline progress).
"""

from .base import ResultId, _Result
from .final import (
    DataResult,
    InsufficientResult,
    ProseResult,
    ProseSegment,
    QueryResult,
)
from .intermediates import (
    CodeGenerationResult,
    InterpretationResult,
    QueryPlanResult,
)

# Discriminated union of all result types
Result = (
    DataResult
    | ProseResult
    | InsufficientResult
    | QueryResult
    | InterpretationResult
    | QueryPlanResult
    | CodeGenerationResult
)

__all__ = [
    # Type aliases
    "ResultId",
    # Base class
    "_Result",
    # Final result types
    "DataResult",
    "ProseResult",
    "ProseSegment",
    "InsufficientResult",
    "QueryResult",
    # Intermediate result types
    "InterpretationResult",
    "QueryPlanResult",
    "CodeGenerationResult",
    # Union type
    "Result",
]
