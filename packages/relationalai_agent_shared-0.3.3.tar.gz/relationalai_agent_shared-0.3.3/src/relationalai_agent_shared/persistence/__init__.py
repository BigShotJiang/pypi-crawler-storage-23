"""Persistence adapters for relation storage."""

from .adapter import PersistenceAdapter
from .file_adapter import FileAdapter

__all__ = ["PersistenceAdapter", "FileAdapter"]
