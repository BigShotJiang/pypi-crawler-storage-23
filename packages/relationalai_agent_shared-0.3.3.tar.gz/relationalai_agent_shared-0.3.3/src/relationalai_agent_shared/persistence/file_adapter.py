"""File-based persistence adapter for relation storage."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import UUID

from .adapter import PersistenceAdapter

if TYPE_CHECKING:
    from relationalai_agent_shared.ecs.base import BaseRelation


class FileAdapter(PersistenceAdapter):
    """File-based persistence using JSON files.

    Directory structure:
        base_path/
            __global__/          # Global relations (model_id=None)
                name.json
            model_1/             # Per-model relations
                name.json
            model_2/
                ...
    """

    GLOBAL_DIR = "__global__"

    def __init__(self, base_path: Path | str):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

    def _get_file_path(
        self, model_id: str | None, relation_class: type[BaseRelation]
    ) -> Path:
        """Get file path for a relation class (used for loading builtin relations).

        Maps relation id to path: "sys::Name" → base_path/model_id/sys/name.json

        Note: Relation names are normalized to lowercase for filesystem compatibility.
        """
        # Get the class-level default ID
        relation_id = getattr(
            relation_class, "_default_id", f"sys::{relation_class.__name__}"
        )
        return self._get_file_path_by_id(model_id, relation_id)

    def _get_file_path_by_id(self, model_id: str | None, relation_id: str) -> Path:
        """Get file path for a relation by its ID (used for saving instances).

        Maps relation id to path: "sys::Name" → base_path/model_id/sys/name.json
                                 "uuid-1234" → base_path/model_id/uuid-1234.json

        Note: Relation names are normalized to lowercase for filesystem compatibility.
        """
        # Split id on :: to create directory structure
        parts = relation_id.split("::")
        relation_name = parts[-1].lower()
        namespace_dirs = [
            ns.lower() for ns in parts[:-1]
        ]  # Also lowercase namespace dirs

        # Start with model directory
        dir_name = model_id if model_id is not None else self.GLOBAL_DIR
        model_dir = self.base_path / dir_name

        # Add namespace subdirectories
        for namespace in namespace_dirs:
            model_dir = model_dir / namespace

        model_dir.mkdir(parents=True, exist_ok=True)
        return model_dir / f"{relation_name}.json"

    async def save_relation(self, instance: BaseRelation) -> None:
        """Save relation instance to JSON file (atomic write via tmp file)."""
        # Use instance.id directly - for runtime relations, each instance has a unique ID
        file_path = self._get_file_path_by_id(instance.model_id, instance.id)

        # Standard Pydantic serialization for all relations
        # DynamicRelation uses @computed_field for columns, so it's included automatically
        # by_alias=True so nested models with alias_generator (e.g. VisualizationSpec
        # with to_camel) serialize using their aliases. Safe for models without aliases —
        # they fall back to field names.
        # TODO: consider a shared BaseModel in agent-shared that standardizes camelCase
        # serialization so individual models don't need to configure alias_generator.
        json_data = instance.model_dump_json(indent=2, by_alias=True)

        # Atomic write: write to unique tmp file in same dir, then rename
        with tempfile.NamedTemporaryFile(
            mode="w",
            dir=file_path.parent,
            prefix=f".{file_path.name}.",
            suffix=".tmp",
            delete=False,
        ) as tmp_file:
            tmp_file.write(json_data)
            tmp_path = Path(tmp_file.name)

        # Atomic rename
        tmp_path.replace(file_path)

    async def load_relation_by_id(
        self, model_id: str | None, relation_id: str
    ) -> BaseRelation | None:
        """Load relation instance from JSON file by ID.

        Args:
            model_id: Model identifier (or None for global relations)
            relation_id: Relation ID (e.g., "sys::Name" for builtin or UUID for dynamic)

        Returns:
            Loaded relation instance, or None if file doesn't exist
        """
        file_path = self._get_file_path_by_id(model_id, relation_id)
        if not file_path.exists():
            return None

        json_data = file_path.read_text()

        # Determine which class to use for deserialization
        if relation_id.startswith("sys::"):
            # Builtin relation - use BuiltinRelation subclass
            from relationalai_agent_shared.ecs import builtins
            from relationalai_agent_shared.ecs.base import BuiltinRelation

            # Extract class name from ID (e.g., "sys::Name" -> "Name")
            class_name = relation_id.split("::")[-1]
            relation_class = getattr(builtins, class_name, None)

            if relation_class is None:
                # Class not found in builtins - might be a test class
                # Try to deserialize as generic BuiltinRelation
                # This allows tests to work without registering test classes
                import json

                data = json.loads(json_data)

                # FIXME: This is a hack, we _should_ have a registry of BuiltinRelation types, we just shouldn't rely on it for _anything_ except deserializing in the persistence adapters to builtins, (while still supporting loading everything else as a generic dynamic relation)
                # Create a generic BuiltinRelation instance
                # This won't have typed fields but will preserve the data
                instance = BuiltinRelation(
                    model_id=data.get("model_id"),
                    eids=[
                        UUID(eid) if isinstance(eid, str) else eid
                        for eid in data.get("eids", [])
                    ],
                )
                # Restore any field data into _columns
                for field_name, field_value in data.items():
                    if field_name not in ("model_id", "eids"):
                        instance._columns[field_name] = field_value
                return instance

            # Unwrap proxy if needed - @per_model decorator wraps classes in proxies
            actual_class = getattr(relation_class, "__wrapped_class__", relation_class)
            return actual_class.model_validate_json(json_data)
        else:
            # UUID-based ID = DynamicRelation
            from relationalai_agent_shared.ecs.components.dynamic_relation import (
                DynamicRelation,
            )
            import json

            # Deserialize and restore generic columns
            data = json.loads(json_data)

            # Create instance with base data
            instance = DynamicRelation(
                eid=UUID(relation_id),
                model_id=data.get("model_id"),
                eids=[
                    UUID(eid) if isinstance(eid, str) else eid
                    for eid in data.get("eids", [])
                ],
            )

            # Restore generic columns from _columns dict
            if "columns" in data:
                instance.set_columns_dict(data["columns"])

            return instance

    async def delete_relation(
        self, model_id: str | None, relation_class: type[BaseRelation]
    ) -> None:
        """Delete relation's JSON file if it exists."""
        file_path = self._get_file_path(model_id, relation_class)
        if file_path.exists():
            file_path.unlink()
