"""Persistence adapter interface for relation storage.

Defines the abstract interface that all persistence adapters must implement.
Adapters handle saving/loading relation data to various backends (filesystem, database, etc.).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from relationalai_agent_shared.ecs.base import BaseRelation


class PersistenceAdapter(ABC):
    """Abstract interface for relation persistence.

    Each relation can configure its own adapter. Adapters save/load individual
    relation instances per model. Actually triggering persistence is managed
    by the Transaction context manager.
    """

    @abstractmethod
    async def save_relation(self, instance: BaseRelation) -> None:
        """Save a relation instance, respecting its model_id if set."""
        pass

    @abstractmethod
    async def load_relation_by_id(
        self, model_id: str | None, relation_id: str
    ) -> BaseRelation | None:
        """Load a relation instance by its ID for a specific model or globally.

        Args:
            model_id: Model identifier (or None for global relations)
            relation_id: Relation ID (e.g., "sys::Name" for builtin or UUID for dynamic)

        Returns:
            Loaded relation instance, or None if file doesn't exist
        """
        pass

    @abstractmethod
    async def delete_relation(
        self, model_id: str | None, relation_class: type[BaseRelation]
    ) -> None:
        """Delete a relation instance for a specific model or globally."""
        pass
