"""In-memory persistence adapter for testing.

Stores relations in memory without file I/O, useful for tests that need
persistence functionality without the complexity of disk-based storage.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from relationalai_agent_shared.ecs.base import BaseRelation

GLOBAL_DIR = "__global__"


class MemoryAdapter:
    """In-memory persistence adapter for testing.

    Stores relations in a dict keyed by (model_id, relation_class_name).
    All operations are synchronous and immediate.
    """

    def __init__(self):
        """Initialize empty in-memory storage."""
        self._storage: dict[tuple[str, str], BaseRelation] = {}

    async def save_relation(self, instance: BaseRelation) -> None:
        """Save relation instance to memory.

        Args:
            instance: The relation instance to save
        """
        key = (instance.model_id or GLOBAL_DIR, instance.__class__.__name__)
        # Store a copy to avoid mutations affecting stored data
        self._storage[key] = instance.model_copy(deep=True)

    async def load_relation_by_id(
        self, model_id: str | None, relation_id: str
    ) -> BaseRelation | None:
        """Load relation instance from memory by ID.

        Args:
            model_id: The model identifier
            relation_id: The relation ID (e.g., "sys::Name")

        Returns:
            Loaded relation instance or None if not found
        """
        # Extract class name from relation_id (e.g., "sys::Name" -> "Name")
        class_name = relation_id.split("::")[-1]
        key = (model_id or GLOBAL_DIR, class_name)
        stored = self._storage.get(key)

        if stored is None:
            return None

        # Return a copy to avoid mutations affecting stored data
        return stored.model_copy(deep=True)

    def clear(self):
        """Clear all stored relations (useful between tests)."""
        self._storage.clear()

    def has_relation(
        self, model_id: str | None, relation_class: type[BaseRelation]
    ) -> bool:
        """Check if a relation is stored.

        Args:
            model_id: The model identifier
            relation_class: The relation class to check

        Returns:
            True if the relation is stored, False otherwise
        """
        key = (model_id or GLOBAL_DIR, relation_class.__name__)
        return key in self._storage
