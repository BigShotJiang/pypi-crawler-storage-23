"""Event types for agent API streaming responses.

These types define the contract for server-sent events during agent execution.
Events are emitted by model-server and consumed by client SDKs.

Based on the Agent API specification in docs/backend/agent-client-sdk/README.md
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

from .results import Result


class StreamEvent(BaseModel):
    """Base class for all stream event types.

    Configured for camelCase serialization to support both SSE and WebSocket clients.
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,  # Accept snake_case field names on input
        validate_by_alias=True,  # Accept camelCase aliases on input
    )

    id: str = Field(default_factory=lambda: str(uuid4()))
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    type: str


class PlanEvent(StreamEvent):
    """Event emitted when agent creates or updates execution plan."""

    type: Literal["plan"] = Field(default="plan", frozen=True)
    tasks: list[dict[str, Any]] = Field(
        default_factory=list,
        description="List of tasks in the execution plan",
    )


class TaskStartEvent(StreamEvent):
    """Event emitted when a task begins execution."""

    type: Literal["task_start"] = Field(default="task_start", frozen=True)
    task_id: str


class TaskEndEvent(StreamEvent):
    """Event emitted when a task completes execution."""

    type: Literal["task_end"] = Field(default="task_end", frozen=True)
    task_id: str


class ResultEvent(StreamEvent):
    """Event emitted when a result is available."""

    type: Literal["result"] = Field(default="result", frozen=True)
    result: Result


class ErrorEvent(StreamEvent):
    """Event emitted when an error occurs."""

    type: Literal["error"] = Field(default="error", frozen=True)
    error_message: str
    details: dict[str, Any] | None = None


class StatusEvent(StreamEvent):
    """Event emitted for progress updates."""

    type: Literal["status"] = Field(default="status", frozen=True)
    message: str
    task_id: str | None = None


class ExecuteCodeEvent(StreamEvent):
    """Event emitted to request client-side code execution."""

    type: Literal["execute_code"] = Field(default="execute_code", frozen=True)
    code: str = Field(description="Code to execute on the client")
    language: str = Field(description="Programming language of the code")
    require_results: bool = Field(
        default=True,
        description="Whether the agent needs results back from execution",
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Optional metadata about the code (e.g., dialect, query plan)",
    )


# Discriminated union of all event types
StreamEventType = (
    PlanEvent
    | TaskStartEvent
    | TaskEndEvent
    | ResultEvent
    | ErrorEvent
    | StatusEvent
    | ExecuteCodeEvent
)
