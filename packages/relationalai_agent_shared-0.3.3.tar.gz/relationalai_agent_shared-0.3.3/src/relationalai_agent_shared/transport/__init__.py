"""Transport layer for client-server communication.

This package provides the abstract transport layer interfaces and envelope types
for bidirectional communication between client and server. See specific server
implementations in agent-core and client in pyrel_agent_sdk / the generated api
client.
"""

from .envelope import (
    Envelope,
    ErrorMessage,
    camel_case_config,
)
from .transport import Transport

__all__ = [
    "Envelope",
    "ErrorMessage",
    "Transport",
    "camel_case_config",
]
