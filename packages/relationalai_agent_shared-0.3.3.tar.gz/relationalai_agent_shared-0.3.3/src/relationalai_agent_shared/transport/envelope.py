"""Message envelope definitions for the transport system.

This module defines the envelope structure used for client-server
communication. Envelopes wrap all messages and provide:
- Request-response correlation via UUIDs
- Type-safe expected response tracking (Out[M, R])
- Message type routing
- Streaming support (multi-chunk responses)
- Server-initiated messages (In with in_response_to=None)
- camelCase serialization for TypeScript compatibility
"""

from __future__ import annotations

from typing import Annotated, Any, Generic, Literal, TypeAlias, TypeVar, cast
from uuid import UUID, uuid4

from pydantic import (
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    ValidationInfo,
)
from pydantic.alias_generators import to_camel
from pydantic.dataclasses import dataclass


# Base model configuration with camelCase serialization for TypeScript
# Users can apply this to their BaseModel classes for TypeScript compatibility
camel_case_config = ConfigDict(
    populate_by_name=True,
    alias_generator=to_camel,
    str_strip_whitespace=True,
    json_encoders={UUID: str},
)


@dataclass
class ErrorMessage(Exception):
    """Error message for transport-level errors.

    Can be used as response content to indicate request failure.
    TODO: integration with redwood2 in a follow-up
    """

    name: str = Field(description="Error name/type")
    description: str = Field(description="Human-readable error description")
    status: int = Field(default=500, description="HTTP-style status code")
    internal: bool = Field(
        default=True, description="Whether this is an internal server error"
    )
    location: str | None = Field(
        default=None, description="Optional location/context where error occurred"
    )


def parse_content(v: Any, info: ValidationInfo):
    """Parse envelope content using registered message types.

    Converts generic content dict into the correct Pydantic message type during
    deserialization. Supports primitives, lists, and BaseModel instances.
    Raw dicts not recommended - wrap in BaseModel instead.
    """
    # If not a dict, return as-is (handles primitives, lists, etc.)
    if not isinstance(v, dict):
        return v

    # For dict content, try to parse as registered message type
    if not info.context:
        return v
    message_types: dict[str, type[BaseModel]] = info.context.get("message_types", {})
    message_type_name = info.data.get("message_type")
    mtype = message_types.get(message_type_name) if message_type_name else None
    return mtype.model_validate(v, context=info.context) if mtype else v


M = TypeVar("M")  # Message type
R = TypeVar("R")  # Response type


class Envelope:
    """Container for different envelope types."""

    class Base(BaseModel, Generic[M]):
        """Base envelope for all messages."""

        model_config = camel_case_config

        id: UUID = Field(
            default_factory=lambda: uuid4(),
            description="Unique identifier for this envelope",
        )
        version: str = Field(default="0.0.0", description="API version")
        message_type: str = Field(
            default=cast(str, None), description="Type name of the wrapped message"
        )
        content: Annotated[M, BeforeValidator(parse_content)] = Field(
            description="The actual message payload"
        )

        def model_post_init(self, __context):
            """Auto-populate message_type from content if not provided."""
            if self.message_type is None:
                if self.content is not None:
                    content_type = type(self.content)
                    if hasattr(content_type, "__name__"):
                        self.message_type = content_type.__name__
                    else:
                        self.message_type = "Unknown"
                else:
                    self.message_type = "NoneType"

    class Out(Base[M], Generic[M, R]):
        """Outgoing message.

        R type parameter captures expected response type for type safety.
        """

        type: Literal["out"] = Field(default="out", description="Envelope type")
        in_response_to: UUID | None = Field(
            default=None,
            description="UUID of the message this is responding to (if any)",
        )
        seq: int = Field(
            default=0,
            description="Sequence number for ordering (especially for streaming responses)",
        )
        continued: bool | None = Field(
            default=None,
            description="For streaming responses - True means more coming, False means last",
        )
        channel: str | None = Field(
            default=None,
            description="Channel name for routing (present on channel messages)",
        )

    class In(Base[M], Generic[M]):
        """Incoming message."""

        type: Literal["in"] = Field(default="in", description="Envelope type")
        in_response_to: UUID | None = Field(
            default=None,
            description="UUID of the message this is responding to (if any)",
        )
        seq: int = Field(
            default=0,
            description="Sequence number for ordering (especially for streaming responses)",
        )
        continued: bool | None = Field(
            default=None,
            description="For streaming responses - True means more coming, False means last",
        )
        channel: str | None = Field(
            default=None,
            description="Channel name for routing (present on channel messages)",
        )

    # Type alias for any envelope type
    Any: TypeAlias = Out[Any, Any] | In[Any]
