"""Abstract Transport class for the transport system.

This module defines the base Transport interface that all concrete
transport implementations (like WebSocketTransport) should extend.
The Transport handles the wire protocol layer - sending and receiving
enveloped messages over a network connection.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Callable, Generic, TypeVar

from .envelope import Envelope

InMsg = TypeVar("InMsg")  # Union of all incoming message content types
OutMsg = TypeVar("OutMsg")  # Union of all outgoing message content types


class Transport(Generic[InMsg, OutMsg], ABC):
    """Base transport class for bidirectional communication.

    This abstract class defines the interface for all transport implementations,
    handling the sending and receiving of enveloped messages over a network
    connection (WebSocket, HTTP, etc.).

    The Transport is responsible for:
    - Wire protocol (serialization, connection management)
    - Sending envelopes over the connection
    - Receiving envelopes from the connection
    - Connection lifecycle management

    It is NOT responsible for:
    - Message routing/dispatch (handled by Router)
    - Request-response correlation (handled by Client/Reply)
    - Per-client state (handled by Client)
    """

    def __init__(self):
        self.open = False

        # Optional lifecycle callbacks
        self.on_connected: Callable[[], None] | None = None
        self.on_disconnected: Callable[[int | None, str | None], None] | None = None
        self.on_received: Callable[[Envelope.In[InMsg]], None] | None = None

    @abstractmethod
    async def connect(self, *args, **kwargs) -> None:
        """Establish the connection.

        Should set self.open = True and call self.on_connected() if set.
        """
        ...

    @abstractmethod
    async def disconnect(
        self, code: int | None = None, reason: str | None = None
    ) -> None:
        """Close the connection.

        Should set self.open = False and call self.on_disconnected() if set.
        """
        ...

    @abstractmethod
    async def send(
        self,
        envelope: Envelope.Out[OutMsg, Any],
    ) -> None:
        """Send an envelope over the connection."""
        ...

    @abstractmethod
    def receive(self) -> AsyncIterator[Envelope.In[InMsg]]:
        """Receive envelopes from the connection.

        Should handle connection errors and trigger on_disconnected() callback.
        """
        ...
