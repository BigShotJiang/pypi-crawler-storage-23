"""top level winsign module.

consider importing `winsign.sign` for signing functionality
"""
