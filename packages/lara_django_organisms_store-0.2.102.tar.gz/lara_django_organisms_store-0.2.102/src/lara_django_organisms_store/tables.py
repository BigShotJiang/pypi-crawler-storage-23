"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_organisms_store admin *

:details: lara_django_organisms_store admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev tables_generator lara_django_organisms_store >> tables.py" to update this file
________________________________________________________________________
"""
# django Tests s. https://docs.djangoproject.com/en/4.1/topics/testing/overview/ for lara_django_organisms_store
# generated with django-extensions tests_generator  lara_django_organisms_store > tests.py (LARA-version)

import django_tables2 as tables
from django.utils.html import format_html

from .models import (
    ExtraData,
    OrganismBasket,
    OrganismInstance,
    OrganismOrder,
    OrganismOrderItem,
    OrganismsLocalStore,
    OrganismWishlist,
)


class ExtraDataTable(tables.Table):
    """Table for displaying ExtraData instances."""

    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:extradata-detail', [tables.A('pk')]))

    class Meta:
        """Meta configuration for ExtraDataTable."""

        model = ExtraData

        fields = (
            "data_type",
            "namespace",
            "uri",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )


class OrganismInstanceTable(tables.Table):
    """Table for displaying OrganismInstance records with edit and delete actions."""

    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_organisms_store:organism-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_organisms_store:organism-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_organisms_store:organism-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        """Render edit icon for table row."""
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        """Render delete icon for table row."""
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = OrganismInstance

        fields = (
            "image",
            "name",
            "namespace",
            "barcode1D",
            "url",
            "registration_no",
            "datetime_end_of_warranty",
            "location",
            "description",
            "organism",
            "edit",
            "delete",
        )


class OrganismOrderItemTable(tables.Table):
    """Table for displaying OrganismOrderItem records."""

    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismorderitem-detail', [tables.A('pk')]))  # noqa: E501

    class Meta:
        """Meta configuration for OrganismOrderItemTable."""

        model = OrganismOrderItem

        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
        )


class OrganismWishlistTable(tables.Table):
    """Table for displaying OrganismWishlist records."""

    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismwishlist-detail', [tables.A('pk')]))  # noqa: E501

    class Meta:
        """Meta configuration for OrganismWishlistTable."""

        model = OrganismWishlist

        fields = ("namespace", "name", "user", "datetime_created", "datetime_last_modified")


class OrganismBasketTable(tables.Table):
    """Table for displaying OrganismBasket records."""

    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismbasket-detail', [tables.A('pk')]))  # noqa: E501

    class Meta:
        """Meta configuration for OrganismBasketTable."""

        model = OrganismBasket

        fields = ("namespace", "name", "user", "datetime_created", "datetime_last_modified")


class OrganismOrderTable(tables.Table):
    """Table for displaying OrganismOrder records."""

    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismorder-detail', [tables.A('pk')]))  # noqa: E501

    class Meta:
        """Meta configuration for OrganismOrderTable."""

        model = OrganismOrder

        fields = (
            "namespace",
            "name",
            "iri",
            "user_ordered",
            "user_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_net",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )


class OrganismsLocalStoreTable(tables.Table):
    """Table for displaying OrganismsLocalStore records."""

    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismlocalstore-detail', [tables.A('pk')]))  # noqa: E501

    class Meta:
        """Meta configuration for OrganismsLocalStoreTable."""

        model = OrganismsLocalStore

        fields = (
            "namespace",
            "name",
            "user",
            "datetime_created",
            "datetime_last_modified",
            "location",
        )
