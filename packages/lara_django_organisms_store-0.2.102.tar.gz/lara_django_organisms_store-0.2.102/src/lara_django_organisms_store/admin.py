"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_organisms_store admin *

:details: lara_django_organisms_store admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_organisms_store >> admin.py" to update this file
________________________________________________________________________
"""

# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import (
    ExtraData,
    OrganismBasket,
    OrganismInstance,
    OrganismOrder,
    OrganismOrderItem,
    OrganismsLocalStore,
    OrganismWishlist,
)


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    """Admin configuration for ExtraData model."""

    list_display = (
        "name_full",
        "namespace",
        "data_type",
        "media_type",
        "iri",
        "url",
        "description",
        "extradata_id",
        "file",
    )
    list_filter = ("data_type", "namespace", "media_type")


@admin.register(OrganismInstance)
class OrganismInstanceAdmin(admin.ModelAdmin):
    """Admin configuration for OrganismInstance model."""

    list_display = (
        "name",
        "namespace",
        "barcode",
        "registration_no",
        "vendor",
        "product_id",
        "serial_no",
        "service_no",
        "price",
        "currency",
        "datetime_purchase",
        "datetime_end_of_warranty",
        "location",
        "organism",
        "organisminstance_id",
    )
    list_filter = (
        "namespace",
        "vendor",
        "currency",
        "datetime_purchase",
        "datetime_delivery",
        "datetime_end_of_warranty",
        "location",
        "organism",
    )
    raw_id_fields = ("tags", "data_extra")
    search_fields = ("name",)


@admin.register(OrganismOrderItem)
class OrganismOrderItemAdmin(admin.ModelAdmin):
    """Admin configuration for OrganismOrderItem model."""

    list_display = (
        "quantity",
        "item_price_net",
        "item_price_gross",
        "item_transport_price",
        "item_price_tax",
        "item_toll",
        "toll_number",
        "item_discount",
        "total_price_net",
        "organismorderitem_id",
        "organism_instance",
    )
    list_filter = ("organism_instance",)
    raw_id_fields = ("data_extra",)


@admin.register(OrganismWishlist)
class OrganismWishlistAdmin(admin.ModelAdmin):
    """Admin configuration for OrganismWishlist model."""

    list_display = (
        "namespace",
        "name",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "organismwishlist_id",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(OrganismBasket)
class OrganismBasketAdmin(admin.ModelAdmin):
    """Admin configuration for OrganismBasket model."""

    list_display = (
        "namespace",
        "name",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "organismbasket_id",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(OrganismOrder)
class OrganismOrderAdmin(admin.ModelAdmin):
    """Admin configuration for OrganismOrder model."""

    list_display = (
        "name",
        "namespace",
        "entity_ordered",
        "entity_ordering",
        "datetime_order",
        "order_id_internal",
        "order_id_external",
        "order_barcode",
        "provider",
        "order_quote_id",
        "datetime_order_quote",
        "order_invoice_id",
        "datetime_order_invoice",
        "datetime_order_pay",
        "order_total_price_net",
        "order_total_price_toll",
        "order_currency",
        "order_status",
        "organismorder_id",
    )
    list_filter = (
        "namespace",
        "entity_ordered",
        "entity_ordering",
        "datetime_order",
        "provider",
        "datetime_order_quote",
        "datetime_order_invoice",
        "transport_company",
        "datetime_order_pay",
        "order_currency",
        "order_status",
    )
    raw_id_fields = ("data_extra",)


@admin.register(OrganismsLocalStore)
class OrganismsLocalStoreAdmin(admin.ModelAdmin):
    """Admin configuration for OrganismsLocalStore model."""

    list_display = (
        "name",
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "organismlocalstore_id",
        "location",
    )
    list_filter = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "location",
    )
    raw_id_fields = ("organism_instances",)
