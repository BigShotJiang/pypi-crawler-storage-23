"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_organisms_store admin *

:details: lara_django_organisms_store admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_organisms_store > forms.py" to update this file
________________________________________________________________________
"""

# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

from typing import ClassVar

from django import forms
from django.forms.renderers import TemplatesSetting

from .models import (
    ExtraData,
    OrganismBasket,
    OrganismInstance,
    OrganismInstancesSubset,
    OrganismOrder,
    OrganismOrderItem,
    OrganismsLocalStore,
    OrganismWishlist,
)


class CustomFormRenderer(TemplatesSetting):
    """Custom form renderer for LARA organisms store forms."""

    field_template_name = "lara_django_organisms_store/forms/field_group.html"


class SearchableSelectMultiple(forms.SelectMultiple):
    """Custom widget for searchable multi-select using Alpine.js."""

    template_name = "lara_django_organisms_store/widgets/searchable_select_multiple.html"

    def __init__(self, attrs=None):
        default_attrs = {"class": "searchable-select-multiple"}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)


## -------------- ExtraData -------------- ##


class ExtraDataCreateForm(forms.ModelForm):
    """Form for creating a new extra data entry with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )

        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_full",
            "name_display",
            "version",
            "hash_sha256",
            "data_type",
            "media_type",
        )

        textarea_fields: ClassVar = ("description",)

        json_fields: ClassVar = ("data_json",)

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.Textarea(
                    attrs={"class": "textarea textarea-sm textarea-bordered w-full font-mono", "rows": 5}
                )
                for field in json_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class ExtraDataUpdateForm(forms.ModelForm):
    """Form for updating an existing extra data entry with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )

        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_full",
            "name_display",
            "version",
            "hash_sha256",
            "data_type",
            "media_type",
        )

        textarea_fields: ClassVar = ("description",)

        json_fields: ClassVar = ("data_json",)

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.Textarea(
                    attrs={"class": "textarea textarea-sm textarea-bordered w-full font-mono", "rows": 5}
                )
                for field in json_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


## -------------- OrganismInstance -------------- ##


class OrganismInstanceCreateForm(forms.ModelForm):
    """Form for creating a new organism instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismInstance
        fields = (
            "namespace",
            "name",
            "name_display",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "organism",
            "sex",
            "hybrid",
            "chimeric",
            "organism_instances",
            "traits",
            "genome",
            "genomes",
            "habitat",
            "image",
            "data_extra",
            "resources_external",
            "tags",
        )

        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "barcode",
            "registration_no",
            "serial_no",
            "service_no",
            "hash_sha256",
        )

        textarea_fields: ClassVar = ("description",)

        json_fields: ClassVar = (
            "barcode_json",
            "traits",
            "habitat",
        )

        number_fields: ClassVar = ("price",)

        datetime_fields: ClassVar = (
            "datetime_manufacturing",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
        )

        url_fields: ClassVar = ("iri", "url", "pid", "genome")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.Textarea(
                    attrs={"class": "textarea textarea-sm textarea-bordered w-full font-mono", "rows": 5}
                )
                for field in json_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "sex": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "hybrid": forms.CheckboxInput(attrs={"class": "checkbox checkbox-sm"}),
            "chimeric": forms.CheckboxInput(attrs={"class": "checkbox checkbox-sm"}),
            "location": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "vendor": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "currency": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_instances": SearchableSelectMultiple(),
            "entities_responsible": SearchableSelectMultiple(),
            "genomes": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class OrganismInstanceUpdateForm(forms.ModelForm):
    """Form for updating an existing organism instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismInstance
        fields = (
            "namespace",
            "name",
            "name_display",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "organism",
            "sex",
            "hybrid",
            "chimeric",
            "organism_instances",
            "traits",
            "genome",
            "genomes",
            "habitat",
            "image",
            "data_extra",
            "resources_external",
            "tags",
        )

        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "barcode",
            "registration_no",
            "serial_no",
            "service_no",
            "hash_sha256",
        )

        textarea_fields: ClassVar = ("description",)

        json_fields: ClassVar = (
            "barcode_json",
            "traits",
            "habitat",
        )

        number_fields: ClassVar = ("price",)

        datetime_fields: ClassVar = (
            "datetime_manufacturing",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
        )

        url_fields: ClassVar = ("iri", "url", "pid", "genome")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.Textarea(
                    attrs={"class": "textarea textarea-sm textarea-bordered w-full font-mono", "rows": 5}
                )
                for field in json_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "sex": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "hybrid": forms.CheckboxInput(attrs={"class": "checkbox checkbox-sm"}),
            "chimeric": forms.CheckboxInput(attrs={"class": "checkbox checkbox-sm"}),
            "location": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "vendor": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "currency": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_instances": SearchableSelectMultiple(),
            "entities_responsible": SearchableSelectMultiple(),
            "genomes": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


## -------------- OrganismInstancesSubset -------------- ##


class OrganismInstancesSubsetCreateForm(forms.ModelForm):
    """Form for creating a new organism instances subset with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismInstancesSubset
        fields = (
            "namespace",
            "name",
            "name_display",
            "organism_instances",
            "description",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        textarea_fields: ClassVar = ("description",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_instances": SearchableSelectMultiple(),
        }


class OrganismInstancesSubsetUpdateForm(forms.ModelForm):
    """Form for updating an existing organism instances subset with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismInstancesSubset
        fields = (
            "namespace",
            "name",
            "name_display",
            "organism_instances",
            "description",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        textarea_fields: ClassVar = ("description",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_instances": SearchableSelectMultiple(),
        }


## -------------- OrganismOrderItem -------------- ##


class OrganismOrderItemCreateForm(forms.ModelForm):
    """Form for creating a new organism order item with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
            "organism_wishlist",
            "organism_basket",
            "organism_order",
            "data_extra",
        )

        number_fields: ClassVar = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "item_discount",
            "total_price_net",
        )

        text_fields: ClassVar = ("toll_number",)

        widgets: ClassVar = {
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "organism_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_wishlist": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_basket": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_order": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
        }


class OrganismOrderItemUpdateForm(forms.ModelForm):
    """Form for updating an existing organism order item with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
            "organism_wishlist",
            "organism_basket",
            "organism_order",
            "data_extra",
        )

        number_fields: ClassVar = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "item_discount",
            "total_price_net",
        )

        text_fields: ClassVar = ("toll_number",)

        widgets: ClassVar = {
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "organism_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_wishlist": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_basket": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_order": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
        }


## -------------- OrganismWishlist -------------- ##


class OrganismWishlistCreateForm(forms.ModelForm):
    """Form for creating a new organism wishlist with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismWishlist
        fields = (
            "namespace",
            "name",
            "name_display",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


class OrganismWishlistUpdateForm(forms.ModelForm):
    """Form for updating an existing organism wishlist with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismWishlist
        fields = (
            "namespace",
            "name",
            "name_display",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


## -------------- OrganismBasket -------------- ##


class OrganismBasketCreateForm(forms.ModelForm):
    """Form for creating a new organism basket with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismBasket
        fields = (
            "namespace",
            "name",
            "name_display",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


class OrganismBasketUpdateForm(forms.ModelForm):
    """Form for updating an existing organism basket with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismBasket
        fields = (
            "namespace",
            "name",
            "name_display",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


## -------------- OrganismOrder -------------- ##


class OrganismOrderCreateForm(forms.ModelForm):
    """Form for creating a new organism order with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismOrder
        fields = (
            "namespace",
            "name",
            "name_display",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            "order_quotes",
            "order_invoices",
            "data_extra",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
            "order_barcode",
        )

        number_fields: ClassVar = (
            "transport_price",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
        )

        datetime_fields: ClassVar = (
            "datetime_order",
            "datetime_order_quote",
            "datetime_order_invoice",
            "datetime_order_pay",
        )

        url_fields: ClassVar = ("iri", "budget_url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "entity_ordered": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "entity_ordering": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "provider": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "transport_company": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "order_currency": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "order_status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "order_quotes": SearchableSelectMultiple(),
            "order_invoices": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
        }


class OrganismOrderUpdateForm(forms.ModelForm):
    """Form for updating an existing organism order with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismOrder
        fields = (
            "namespace",
            "name",
            "name_display",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            "order_quotes",
            "order_invoices",
            "data_extra",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
            "order_barcode",
        )

        number_fields: ClassVar = (
            "transport_price",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
        )

        datetime_fields: ClassVar = (
            "datetime_order",
            "datetime_order_quote",
            "datetime_order_invoice",
            "datetime_order_pay",
        )

        url_fields: ClassVar = ("iri", "budget_url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "entity_ordered": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "entity_ordering": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "provider": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "transport_company": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "order_currency": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "order_status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "order_quotes": SearchableSelectMultiple(),
            "order_invoices": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
        }


## -------------- OrganismsLocalStore -------------- ##


class OrganismsLocalStoreCreateForm(forms.ModelForm):
    """Form for creating a new organism local store with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismsLocalStore
        fields = (
            "namespace",
            "name",
            "name_display",
            "location",
            "organism_instances",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "location": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_instances": SearchableSelectMultiple(),
        }


class OrganismsLocalStoreUpdateForm(forms.ModelForm):
    """Form for updating an existing organism local store with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = OrganismsLocalStore
        fields = (
            "namespace",
            "name",
            "name_display",
            "location",
            "organism_instances",
        )

        text_fields: ClassVar = (
            "name",
            "name_display",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "location": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "organism_instances": SearchableSelectMultiple(),
        }
