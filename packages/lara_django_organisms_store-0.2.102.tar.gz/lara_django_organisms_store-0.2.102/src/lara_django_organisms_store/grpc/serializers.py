"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_organisms_store  (LARA-version)

from django_socio_grpc import proto_serializers
from lara_django_base.models import (
    Currency,
    DataType,
    ExternalResource,
    ItemStatus,
    Location,
    MediaType,
    Namespace,
    Tag,
)
from lara_django_organisms.models import Organism
from lara_django_organisms_store_grpc.v1 import lara_django_organisms_store_pb2
from lara_django_people.models import Entity, Group
from rest_framework.serializers import PrimaryKeyRelatedField, UUIDField

from lara_django_organisms_store.models import (
    ExtraData,
    OrganismBasket,
    OrganismInstance,
    OrganismInstancesSubset,
    OrganismOrder,
    OrganismOrderItem,
    OrganismsLocalStore,
    OrganismWishlist,
)


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_organisms_store_pb2.ExtraDataResponse

        proto_class_list = lara_django_organisms_store_pb2.ExtraDataListResponse

        fields = "__all__"  # [data_type', namespace', URI', text', XML', JSON', bin',
        # media_type', IRI', URL', description', file']


class OrganismInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    organism = PrimaryKeyRelatedField(queryset=Organism.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    organism_instances = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = OrganismInstance
        proto_class = lara_django_organisms_store_pb2.OrganismInstanceResponse

        proto_class_list = lara_django_organisms_store_pb2.OrganismInstanceListResponse

        fields = "__all__"  # [namespace', name', name_full', barcode1D', barcode2D', UUID', URL',
        # handle', IRI', registration_no', vendor', serial_no', service_no',
        # datetime_manufacturing', price', currency', datetime_purchase',
        # datetime_delivery', datetime_end_of_warranty', location',
        # hash_sha256', description', organism', image', literature']


class OrganismInstancesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    organism_instances = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )

    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = OrganismInstancesSubset
        proto_class = lara_django_organisms_store_pb2.OrganismInstancesSubsetResponse

        proto_class_list = lara_django_organisms_store_pb2.OrganismInstancesSubsetListResponse

        fields = "__all__"


class OrganismOrderItemProtoSerializer(proto_serializers.ModelProtoSerializer):
    organism_instance = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    organism_wishlist = PrimaryKeyRelatedField(
        queryset=OrganismWishlist.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    organism_basket = PrimaryKeyRelatedField(
        queryset=OrganismBasket.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    organism_order = PrimaryKeyRelatedField(
        queryset=OrganismOrder.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = OrganismOrderItem
        proto_class = lara_django_organisms_store_pb2.OrganismOrderItemResponse

        proto_class_list = lara_django_organisms_store_pb2.OrganismOrderItemListResponse

        fields = "__all__"  # [quantity', item_price_net', item_price_gross', item_transport_price',
        # item_price_tax', item_toll', toll_number', item_discount', total_price_net',
        #  organism_instance']


class OrganismWishlistProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = OrganismWishlist
        proto_class = lara_django_organisms_store_pb2.OrganismWishlistResponse

        proto_class_list = lara_django_organisms_store_pb2.OrganismWishlistListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class OrganismBasketProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))

    class Meta:
        model = OrganismBasket
        proto_class = lara_django_organisms_store_pb2.OrganismBasketResponse

        proto_class_list = lara_django_organisms_store_pb2.OrganismBasketListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class OrganismOrderProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity_ordered = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity_ordering = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group_ordered = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    group_ordering = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    provider = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    transport_company = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    order_currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    order_status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    order_quotes = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    order_invoices = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = OrganismOrder
        proto_class = lara_django_organisms_store_pb2.OrganismOrderResponse

        proto_class_list = lara_django_organisms_store_pb2.OrganismOrderListResponse

        fields = "__all__"  # [namespace', name_full', IRI', entity_ordered', entity_ordering', datetime_order',
        # order_barcode', provider', datetime_order_quote', datetime_order_invoice',
        # transport_company', transport_price', budget_url', datetime_order_pay',
        # order_total_price_net', order_total_price_gross', order_total_price_tax',
        # order_total_price_toll', order_currency', order_status']


class OrganismsLocalStoreProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    organism_instances = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    location = PrimaryKeyRelatedField(queryset=Location.objects.all(), pk_field=UUIDField(format="hex_verbose"))

    class Meta:
        model = OrganismsLocalStore
        proto_class = lara_django_organisms_store_pb2.OrganismsLocalStoreResponse

        proto_class_list = lara_django_organisms_store_pb2.OrganismsLocalStoreListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created',
        # datetime_last_modified', location']
