"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_myproj gRPC services*

:details: lara_django_myproj gRPC services.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_organisms_store  (LARA-version)

import lara_django_organisms_store_grpc.v1.lara_django_organisms_store_pb2 as lara_django_organisms_store_pb2
from django_socio_grpc import generics, mixins
from lara_django_base.grpc.mixins import AsyncDownloadModelMixin, AsyncRetrieveByNameModelMixin, AsyncUploadModelMixin

from lara_django_organisms_store.models import (
    ExtraData,
    OrganismBasket,
    OrganismInstance,
    OrganismInstancesSubset,
    OrganismOrder,
    OrganismOrderItem,
    OrganismsLocalStore,
    OrganismWishlist,
)

from ..filters import ExtraDataFilterSet, OrganismInstanceFilterSet
from .serializers import (
    ExtraDataProtoSerializer,
    OrganismBasketProtoSerializer,
    OrganismInstanceProtoSerializer,
    OrganismInstancesSubsetProtoSerializer,
    OrganismOrderItemProtoSerializer,
    OrganismOrderProtoSerializer,
    OrganismsLocalStoreProtoSerializer,
    OrganismWishlistProtoSerializer,
)


class ExtraDataService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_organisms_store_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    fiterset_class = ExtraDataFilterSet


class OrganismInstanceService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_organisms_store_pb2
    queryset = OrganismInstance.objects.all()
    serializer_class = OrganismInstanceProtoSerializer
    filterset_class = OrganismInstanceFilterSet


class OrganismInstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = OrganismInstancesSubset.objects.all()
    serializer_class = OrganismInstancesSubsetProtoSerializer
    # filterset_class = OrganismInstanceSubsetFilterSet


class OrganismOrderItemService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = OrganismOrderItem.objects.all()
    serializer_class = OrganismOrderItemProtoSerializer


class OrganismWishlistService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = OrganismWishlist.objects.all()
    serializer_class = OrganismWishlistProtoSerializer


class OrganismBasketService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = OrganismBasket.objects.all()
    serializer_class = OrganismBasketProtoSerializer


class OrganismOrderService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = OrganismOrder.objects.all()
    serializer_class = OrganismOrderProtoSerializer


class OrganismsLocalStoreService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = OrganismsLocalStore.objects.all()
    serializer_class = OrganismsLocalStoreProtoSerializer
