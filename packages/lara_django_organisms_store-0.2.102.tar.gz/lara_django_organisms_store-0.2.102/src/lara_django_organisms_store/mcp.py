"""
Model Context Protocol (MCP) handler for lara_django_organisms_store.

_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_organisms_store Model Context Protocol (MCP) handler *

:details: lara_django_organisms_store Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import (
    ExtraData,
    OrderedOrganismsInstancesSubset,
    OrganismBasket,
    OrganismInstance,
    OrganismInstancesSubset,
    OrganismOrder,
    OrganismOrderItem,
    OrganismsLocalStore,
    OrganismWishlist,
)


class ExtraDataQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ExtraData`."""

    model = ExtraData


class OrganismInstanceQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismInstance`."""

    model = OrganismInstance


class OrganismInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismInstancesSubset`."""

    model = OrganismInstancesSubset


class OrderedOrganismsInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedOrganismsInstancesSubset`."""

    model = OrderedOrganismsInstancesSubset


class OrganismOrderItemQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismOrderItem`."""

    model = OrganismOrderItem


class OrganismWishlistQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismWishlist`."""

    model = OrganismWishlist


class OrganismBasketQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismBasket`."""

    model = OrganismBasket


class OrganismOrderQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismOrder`."""

    model = OrganismOrder


class OrganismsLocalStoreQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismsLocalStore`."""

    model = OrganismsLocalStore
