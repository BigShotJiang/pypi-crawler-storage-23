"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_organisms_store celery tasks*

:details: lara_django_organisms_store celery tasks.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

# from config import celery_app

# @celery_app.task()
