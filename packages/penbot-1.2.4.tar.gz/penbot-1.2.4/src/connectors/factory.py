"""Factory for creating target connectors."""

from typing import Dict, Any, Literal
from .base import BaseConnector


def create_connector(
    target_type: Literal["api", "web_ui", "rest", "playwright"],
    config: Dict[str, Any],
) -> BaseConnector:
    """
    Create appropriate connector based on target type.

    Unified factory that returns connectors inheriting from BaseConnector.

    Args:
        target_type: Type of target
            - "api" or "rest" -> GenericRestConnector
            - "web_ui" or "playwright" -> PlaywrightConnector
        config: Configuration dict for the connector.
               For REST: the full 'target' section from YAML config.
               For Playwright: the full 'target' section from YAML config.

    Returns:
        Initialized connector instance (BaseConnector subclass)

    Raises:
        ValueError: If target_type is unknown

    Example:
        >>> connector = create_connector("api", {
        ...     "name": "My Chatbot",
        ...     "connection": {"endpoint": "http://localhost:5000/chat"},
        ...     "format": {"request": {"message_field": "message"}},
        ... })
    """
    if target_type in ("api", "rest"):
        from .rest_connector import GenericRestConnector

        return GenericRestConnector(config)
    elif target_type in ("web_ui", "playwright"):
        from .playwright_connector import PlaywrightConnector

        return PlaywrightConnector(config)
    else:
        raise ValueError(
            f"Unknown target type: {target_type}. "
            f"Supported types: api, rest, web_ui, playwright"
        )
