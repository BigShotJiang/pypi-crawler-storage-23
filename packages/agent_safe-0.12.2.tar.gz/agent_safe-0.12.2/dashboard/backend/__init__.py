"""Dashboard backend — FastAPI application."""
