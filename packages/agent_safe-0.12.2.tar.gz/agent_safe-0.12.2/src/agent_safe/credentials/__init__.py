"""Credential vault-based scoping for execution tickets."""
