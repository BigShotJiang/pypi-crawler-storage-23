"""Rollback pairing — generate compensating actions for reversible operations."""
