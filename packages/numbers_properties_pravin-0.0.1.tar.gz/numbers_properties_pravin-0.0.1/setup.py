import setuptools

# Read the content of README.md
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Package configuration
setuptools.setup(
    name="numbers-properties-pravin",  
    version="0.0.1",
    author="Pravin",
    author_email="pravin@gmail.com",
    description="A Python library to check number properties like even, odd, and multiples",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pypa/sampleproject",  
    packages=setuptools.find_packages(),

    # If your project needs external libraries, list them here
    install_requires=[],

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],

    python_requires=">=3.6",
)