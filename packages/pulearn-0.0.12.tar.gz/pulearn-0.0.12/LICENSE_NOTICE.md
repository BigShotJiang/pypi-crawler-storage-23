Code in the elkanoto.py file was written by Alexndre Drouin, who still reserves the rights to it and released it under the BSD 3-clause license. See ELKANOTO_LICENSE.md for the license file.

Code in the bagging.py file was written by Gilles Louppe (g.louppe@gmail.com), as part of the scikit-learn open source package, and VERY slightly updated by Roy Wright (roy.w.wright@gmail.com).. The author has released it under the BSD 3-clause license.

All other code - packaging, testing and documentation code - was written by Shay Palachy (shay.palachy@gmail.com), who has also released it under the BSD 3-clause license. See LICENSE.md for the license file.
