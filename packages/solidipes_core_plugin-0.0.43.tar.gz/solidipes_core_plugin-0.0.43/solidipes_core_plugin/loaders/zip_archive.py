#!/usr/bin/env python3


from solidipes.loaders.file import File


def get_filetype(ft):
    if ft.IFREG:
        return "REGULAR"
    if ft.IFDIR:
        return "DIR"
    if ft.IFLNK:
        return "SYMLINK"
    if ft.IFCHR:
        return "CHAR"
    if ft.IFBLK:
        return "BLOCK"
    if ft.IFIFO:
        return "FIFO"
    if ft.IFSOCK:
        return "SOCKET"
    return "UNKNOWN"


class ZipArchive(File):
    """Archive loader"""

    from ..viewers.zip_archive import ZipArchive as ZipArchiveViewer

    supported_mime_types = {
        "application/zip": ["zip"],
        "application/x-7z-compressed": ["7z"],
        "application/vnd.rar": ["rar"],
        "application/x-rar-compressed": ["rar"],
        "application/gzip": ["tgz"],
        "application/x-tar": ["tar"],
    }
    _compatible_viewers = [ZipArchiveViewer]

    @File.loadable
    def files(self):
        import libarchive.public

        rows = []
        with libarchive.public.file_reader(self.file_info.path) as entries:
            for e in entries:
                ftype = get_filetype(e.filetype)
                rows.append({
                    "path": e.pathname,
                    "size": e.size if ftype == "REGULAR" else None,
                    "type": ftype,
                })
        import pandas as pd

        return pd.DataFrame(rows)
