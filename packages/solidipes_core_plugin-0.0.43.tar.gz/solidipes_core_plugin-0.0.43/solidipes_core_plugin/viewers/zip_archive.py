#!/usr/bin/env python3

import streamlit as st
from IPython.display import display
from solidipes.viewers import backends as viewer_backends
from solidipes.viewers.viewer import Viewer


# def extract_archive(src_path, dest_dir):
#     from pathlib import Path
#     import libarchive.public
#
#     dest_dir = Path(dest_dir)
#     dest_dir.mkdir(parents=True, exist_ok=True)
#     libarchive.public.extract_file(str(src_path), str(dest_dir))


class ZipArchive(Viewer):
    """Viewer for HDf5"""

    def __init__(self, data=None):
        #: Image to display
        self.datasets = None
        super().__init__(data)

    def add(self, data_container):
        """Replace the viewer's hdf5"""
        self.check_data_compatibility(data_container)
        self.files = data_container.files
        self.archive_name = data_container.file_info.path

    def show(self):
        if viewer_backends.current_backend == "jupyter notebook":
            display(self.files)

        elif viewer_backends.current_backend == "streamlit":
            st.write(self.files)
            # if st.button("Unpack"):
            #     import os
            #
            #     extract_archive(
            #         self.archive_name, os.path.splitext(self.archive_name)[0]
            #     )

        else:  # python
            print(self.files)
