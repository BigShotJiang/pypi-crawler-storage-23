import streamlit as st
from IPython.display import display
from solidipes.viewers import backends as viewer_backends
from solidipes.viewers import Viewer


class Workflow(Viewer):
    def __init__(self, data=None, display_lint=True):
        self.display_lint = display_lint
        if data is not None:
            self.path = data.file_info.path
        super().__init__(data)

    def add(self, data_container):
        """Append code to the viewer"""

        super().add(data_container)
        self.graph = data_container.graph
        self.text = data_container.text

    def show(self):
        if viewer_backends.current_backend == "jupyter notebook":
            # display(self.graph)
            display(self.text)

        elif viewer_backends.current_backend == "streamlit":
            # st.write(self.graph)
            st.code(self.text)

        else:  # pure python
            # print(self.graph)
            print(self.text)
