#!/usr/bin/env sh
pkill wsgidav
rclone config create webdav-local webdav url=http://127.0.0.1:8977 user=test pass=toto
mkdir -p /tmp/webdav_root
rm -r /tmp/webdav_root/*
solidipes init /tmp/webdav_root
mkdir /tmp/webdav_root/data
SOLIDIPES_SRC_PATH=$(python -c "import solidipes;import os;print(os.path.join(os.path.dirname(solidipes.__file__), '..'))")
find "$SOLIDIPES_SRC_PATH/tests/assets" -type f -exec cp '{}' /tmp/webdav_root/data/ ';'
find solidipes/tests/assets -type f -exec cp '{}' /tmp/webdav_root/data/ ';'
find /tmp/webdav_root/data/
nohup wsgidav --config tests/wsgidav.yaml 2>nohup.err &
PID=$!
sleep 2
if kill -0 "$PID" 2>/dev/null; then
    echo "Process running (PID: $PID)"
else
    echo "Process has failed to start"
    tail nohup.out
    tail nohup.out
fi
