"""Taster - Teach AI your taste. Apply it to everything."""
__version__ = "3.5.0"
