"""MCP server for Taster."""
from .server import create_mcp_server

__all__ = ["create_mcp_server"]
