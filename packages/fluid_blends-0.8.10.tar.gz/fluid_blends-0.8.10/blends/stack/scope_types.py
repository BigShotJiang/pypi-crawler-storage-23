from enum import Enum


class ScopeType(str, Enum):
    FILE = "file"
    CLASS = "class"
    FUNCTION = "function"
    BLOCK = "block"
    NAMESPACE = "namespace"
