from __future__ import annotations

from typing import TYPE_CHECKING

from blends.stack.policies.base import ExportPolicy
from blends.stack.scope_types import ScopeType

if TYPE_CHECKING:
    from blends.models import NId, SyntaxGraph


class DefaultExportPolicy(ExportPolicy):
    def is_scope_exported(
        self,
        _graph: SyntaxGraph,
        _node_id: NId,
        scope_type: str | None,
    ) -> bool:
        return scope_type == ScopeType.FILE.value

    def is_definition_exported(
        self,
        graph: SyntaxGraph,
        _node_id: NId,
        parent_scope_id: NId | None,
    ) -> bool:
        if parent_scope_id is None:
            return True
        parent_type = graph.nodes[parent_scope_id].get("stack_graph_scope_type")
        return parent_type == ScopeType.FILE.value
