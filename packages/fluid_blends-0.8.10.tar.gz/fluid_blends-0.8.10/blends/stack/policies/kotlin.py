from __future__ import annotations

from typing import TYPE_CHECKING

from blends.stack.policies.java import JavaExportPolicy

if TYPE_CHECKING:
    from blends.models import NId, SyntaxGraph


class KotlinExportPolicy(JavaExportPolicy):
    def get_visibility_modifier(
        self,
        graph: SyntaxGraph,
        node_id: NId,
    ) -> str | None:
        modifier = super().get_visibility_modifier(graph, node_id)
        if modifier is None:
            return "public"
        return modifier
