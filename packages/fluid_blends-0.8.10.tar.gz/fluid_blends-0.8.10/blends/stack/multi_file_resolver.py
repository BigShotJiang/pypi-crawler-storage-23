from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from blends.stack.criteria import (
    is_definition_endpoint,
    is_reference_endpoint,
)
from blends.stack.multi_file_stitcher import MultiFileForwardStitcher
from blends.stack.partial_path_db import PartialPathDb
from blends.stack.selection import edge_list_shadows

if TYPE_CHECKING:
    from blends.stack.forward_stitcher import ForwardStitcherConfig
    from blends.stack.partial_path import (
        FileHandle,
        PartialPath,
        PartialPathDatabase,
    )
    from blends.stack.selection import PartialPathEdge
    from blends.stack.view import StackGraphView


@dataclass(frozen=True, slots=True)
class MultiFileResolutionStats:
    phases_executed: int
    candidates_considered: int
    concatenations_succeeded: int
    complete_paths_found: int
    cancelled: bool
    cycle_guard_hits: int
    queue_pruned_count: int
    files_considered: int


@dataclass(frozen=True, slots=True)
class MultiFileResolutionRequest:
    file_handle: FileHandle
    ref_node_index: int
    config: ForwardStitcherConfig | None = None
    include_stats: bool = False


@dataclass(frozen=True, slots=True)
class _MultiFileDefinitionCandidate:
    definition_node_index: int
    file_handle: FileHandle
    edges: tuple[PartialPathEdge, ...]


def _build_multi_file_db(
    database: PartialPathDatabase,
    view: StackGraphView,
) -> PartialPathDb:
    db = PartialPathDb(symbols=view.symbols)
    for file_handle in database.list_files():
        record = database.get_file(file_handle)
        if record is None:
            continue
        db.add_file(record)
    return db


def resolve_definitions_multi_file(
    view: StackGraphView,
    database: PartialPathDatabase,
    *,
    request: MultiFileResolutionRequest,
    views: dict[FileHandle, StackGraphView] | None = None,
) -> list[tuple[FileHandle, int]] | tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats]:
    if not is_reference_endpoint(view, request.ref_node_index):
        return _empty_multi_result(include_stats=request.include_stats)

    all_file_handles = database.list_files()
    if request.file_handle not in all_file_handles:
        return _empty_multi_result(include_stats=request.include_stats)
    if not _ref_record_matches_view(view, request, database):
        return _empty_multi_result(include_stats=request.include_stats)

    db = _build_multi_file_db(database, view)
    all_views: dict[FileHandle, StackGraphView] = (
        views if views is not None else {request.file_handle: view}
    )

    stitcher = MultiFileForwardStitcher.from_references(
        view=view,
        file_handle=request.file_handle,
        db=db,
        reference_nodes=(request.ref_node_index,),
        config=request.config,
        views=all_views,
    )

    pairs, latest_stats = _run_resolution_multi_file(view, stitcher, all_file_handles, all_views)
    return _finalize_multi_result(
        pairs, latest_stats, len(all_file_handles), include_stats=request.include_stats
    )


def _empty_multi_result(
    *,
    include_stats: bool,
) -> list[tuple[FileHandle, int]] | tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats]:
    if include_stats:
        return [], MultiFileResolutionStats(
            phases_executed=0,
            candidates_considered=0,
            concatenations_succeeded=0,
            complete_paths_found=0,
            cancelled=False,
            cycle_guard_hits=0,
            queue_pruned_count=0,
            files_considered=0,
        )
    return []


def _collect_multi_file_candidates(
    views: dict[FileHandle, StackGraphView],
    complete_paths: tuple[tuple[FileHandle, PartialPath], ...],
    ref_view: StackGraphView,
) -> list[_MultiFileDefinitionCandidate]:
    new_candidates: list[_MultiFileDefinitionCandidate] = []
    for def_fh, path in complete_paths:
        def_view = views.get(def_fh, ref_view)
        if not is_definition_endpoint(def_view, path.end_node_index):
            continue
        new_candidates.append(
            _MultiFileDefinitionCandidate(
                definition_node_index=path.end_node_index,
                file_handle=def_fh,
                edges=path.edges,
            )
        )
    return new_candidates


def _prune_multi_shadowed(
    candidates: list[_MultiFileDefinitionCandidate],
) -> list[_MultiFileDefinitionCandidate]:
    kept: list[_MultiFileDefinitionCandidate] = []
    for candidate in sorted(candidates, key=lambda c: (c.file_handle, c.definition_node_index)):
        is_dominated = any(edge_list_shadows(k.edges, candidate.edges) for k in kept)
        if is_dominated:
            continue
        kept = [k for k in kept if not edge_list_shadows(candidate.edges, k.edges)]
        kept.append(candidate)
    return kept


def _sort_multi_deterministically(
    candidates: list[_MultiFileDefinitionCandidate],
) -> list[_MultiFileDefinitionCandidate]:
    def sort_key(
        candidate: _MultiFileDefinitionCandidate,
    ) -> tuple[tuple[int, ...], tuple[int, ...], int, int]:
        edge_sources = tuple(edge.source_node_index for edge in candidate.edges)
        edge_precedences = tuple(-edge.precedence for edge in candidate.edges)
        return (
            edge_sources,
            edge_precedences,
            candidate.file_handle,
            candidate.definition_node_index,
        )

    return sorted(candidates, key=sort_key)


def _select_multi_file_definitions(
    candidates: list[_MultiFileDefinitionCandidate],
) -> list[tuple[FileHandle, int]]:
    if not candidates:
        return []
    pruned = _prune_multi_shadowed(candidates)
    ordered = _sort_multi_deterministically(pruned)
    seen: set[tuple[int, int]] = set()
    pairs: list[tuple[FileHandle, int]] = []
    for candidate in ordered:
        key = (candidate.file_handle, candidate.definition_node_index)
        if key in seen:
            continue
        seen.add(key)
        pairs.append(key)
    return pairs


def _run_resolution_multi_file(
    view: StackGraphView,
    stitcher: MultiFileForwardStitcher,
    all_file_handles: tuple[FileHandle, ...],
    all_views: dict[FileHandle, StackGraphView],
) -> tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats | None]:
    candidates: list[_MultiFileDefinitionCandidate] = []
    latest_stats: MultiFileResolutionStats | None = None
    files_considered = len(all_file_handles)

    while not stitcher.is_complete():
        result = stitcher.process_next_phase()
        latest_stats = MultiFileResolutionStats(
            phases_executed=result.stats.phases_executed,
            candidates_considered=result.stats.candidates_considered,
            concatenations_succeeded=result.stats.concatenations_succeeded,
            complete_paths_found=result.stats.complete_paths_found,
            cancelled=result.stats.cancelled,
            cycle_guard_hits=result.stats.cycle_guard_hits,
            queue_pruned_count=result.stats.queue_pruned_count,
            files_considered=files_considered,
        )
        candidates.extend(_collect_multi_file_candidates(all_views, result.complete_paths, view))

    pairs = _select_multi_file_definitions(candidates)
    return pairs, latest_stats


def _finalize_multi_result(
    pairs: list[tuple[FileHandle, int]],
    latest_stats: MultiFileResolutionStats | None,
    files_considered: int,
    *,
    include_stats: bool,
) -> list[tuple[FileHandle, int]] | tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats]:
    if include_stats:
        if latest_stats is None:
            latest_stats = MultiFileResolutionStats(
                phases_executed=0,
                candidates_considered=0,
                concatenations_succeeded=0,
                complete_paths_found=0,
                cancelled=False,
                cycle_guard_hits=0,
                queue_pruned_count=0,
                files_considered=files_considered,
            )
        return pairs, latest_stats
    return pairs


def _ref_record_matches_view(
    view: StackGraphView,
    request: MultiFileResolutionRequest,
    database: PartialPathDatabase,
) -> bool:
    record = database.get_file(request.file_handle)
    if record is None:
        return False
    if record.file_path and view.file_path:
        return record.file_path == view.file_path
    return True
