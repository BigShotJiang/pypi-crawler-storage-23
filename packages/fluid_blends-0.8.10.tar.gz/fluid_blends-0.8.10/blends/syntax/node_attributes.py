ACCESS_MODIFIER = "access_modifier"
ACCESS_MODIFIERS = "access_modifiers"
ARGUMENT_NAME = "argument_name"
ARGUMENTS_ID = "arguments_id"
ATTRIBUTES_ID = "attributes_id"
BLOCK_ID = "block_id"
CASE_EXPRESSION = "case_expression"
CATCH_DECLARATION = "catch_declaration"
COMMENT = "comment"
CONDITION_ID = "condition_id"
CONSTRUCTOR_ID = "constructor_id"
DECLARATION_ID = "declaration_id"
EXPRESSION = "expression"
EXPRESSION_ID = "expression_id"
FALSE_ID = "false_id"
IMPORT_TYPE = "import_type"
IMPORTS = "imports"
INHERITED_CLASS = "inherited_class"
INSTANCES = "instances"
INITIALIZER = "initializer"
INITIALIZER_ID = "initializer_id"
INITIALIZERS = "initializers"
ITERABLE_ITEM_ID = "iterable_item_id"
KEY_ID = "key_id"
LABEL_ALIAS = "label_alias"
LABEL_C = "label_c"
LABEL_L = "label_l"
LABEL_TYPE = "label_type"
LEFT_ID = "left_id"
MEMBER = "member"
METHOD_NAME = "method_name"
MODIFIERS_ID = "modifiers_id"
NAME = "name"
NODE_TYPE = "node_type"
OBJECT = "object"
OBJECT_ID = "object_id"
OPERAND_ID = "operand_id"
OPERATOR = "operator"
PARAMETER_MODE = "parameter_mode"
PARAMETERS_ID = "parameters_id"
PATH = "path"
RESOURCES_ID = "resources_id"
RIGHT_ID = "right_id"
SELECTOR_NAME = "selector_name"
STRUCTURE = "structure"
SG_NODE_TYPE = "sg_node_type"
SYMBOL = "symbol"
TF_REFERENCE = "tf_reference"
TYPE_ANNOTATION = "type_annotation"
TRUE_ID = "true_id"
UPDATE_ID = "update_id"
VALUE = "value"
VALUE_ID = "value_id"
VALUE_TYPE = "value_type"
VARIABLE = "variable"
VARIABLE_ID = "variable_id"
VARIABLE_TYPE = "variable_type"

STACK_GRAPH_IS_DEFINITION = "stack_graph_is_definition"
STACK_GRAPH_IS_EXPORTED = "stack_graph_is_exported"
STACK_GRAPH_IS_REFERENCE = "stack_graph_is_reference"
STACK_GRAPH_KIND = "stack_graph_kind"
STACK_GRAPH_PRECEDENCE = "stack_graph_precedence"
STACK_GRAPH_SCOPE = "stack_graph_scope"
STACK_GRAPH_SCOPE_TYPE = "stack_graph_scope_type"
STACK_GRAPH_SYMBOL = "stack_graph_symbol"

VALID_SYNTAX_ATTRIBUTES: frozenset[str] = frozenset(
    {
        ACCESS_MODIFIER,
        ACCESS_MODIFIERS,
        ARGUMENT_NAME,
        ARGUMENTS_ID,
        ATTRIBUTES_ID,
        BLOCK_ID,
        CASE_EXPRESSION,
        CATCH_DECLARATION,
        COMMENT,
        CONDITION_ID,
        CONSTRUCTOR_ID,
        DECLARATION_ID,
        EXPRESSION,
        EXPRESSION_ID,
        FALSE_ID,
        IMPORT_TYPE,
        IMPORTS,
        INHERITED_CLASS,
        INITIALIZER,
        INITIALIZER_ID,
        INITIALIZERS,
        INSTANCES,
        ITERABLE_ITEM_ID,
        KEY_ID,
        LABEL_ALIAS,
        LABEL_C,
        LABEL_L,
        LABEL_TYPE,
        LEFT_ID,
        MEMBER,
        METHOD_NAME,
        MODIFIERS_ID,
        NAME,
        NODE_TYPE,
        OBJECT,
        OBJECT_ID,
        OPERAND_ID,
        OPERATOR,
        PARAMETER_MODE,
        PARAMETERS_ID,
        PATH,
        RESOURCES_ID,
        RIGHT_ID,
        SELECTOR_NAME,
        SG_NODE_TYPE,
        STACK_GRAPH_IS_DEFINITION,
        STACK_GRAPH_IS_EXPORTED,
        STACK_GRAPH_IS_REFERENCE,
        STACK_GRAPH_KIND,
        STACK_GRAPH_PRECEDENCE,
        STACK_GRAPH_SCOPE,
        STACK_GRAPH_SCOPE_TYPE,
        STACK_GRAPH_SYMBOL,
        STRUCTURE,
        SYMBOL,
        TF_REFERENCE,
        TRUE_ID,
        TYPE_ANNOTATION,
        UPDATE_ID,
        VALUE,
        VALUE_ID,
        VALUE_TYPE,
        VARIABLE,
        VARIABLE_ID,
        VARIABLE_TYPE,
    }
)
