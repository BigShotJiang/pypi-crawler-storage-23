from pathlib import PurePosixPath


def compute_module_path_segments(file_path: str) -> list[str]:
    posix = PurePosixPath(file_path)
    stem = posix.stem

    if stem == "__init__":
        return []

    return [stem]
