class Context:
    def __init__(self, bot, message):
        self.bot = bot
        self.message = message

    async def send(self, content):
        await self.bot.gateway.send({
            "username": self.bot.username,
            "content": content
        })