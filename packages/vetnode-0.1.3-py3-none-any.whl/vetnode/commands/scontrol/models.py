from typing import List
from vetnode.models import CamelModel





class ScontrolOutput(CamelModel):
    hostnames:List[str]     