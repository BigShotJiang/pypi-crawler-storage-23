# Changelog

## 0.0.3 (2026-02-20)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/revoxai/revox-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([e330542](https://github.com/revoxai/revox-python/commit/e330542311ec2ad25ce4ffd8bce90a6fb59669be))
* update SDK settings ([bfa1341](https://github.com/revoxai/revox-python/commit/bfa134107abb388964210f3ab4e249f7a32d09ce))
* update SDK settings ([7589b81](https://github.com/revoxai/revox-python/commit/7589b81319d38b04d6c724fc21e476e057846f83))

## 0.0.2 (2026-02-20)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/revoxai/revox-python/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([01b1cc7](https://github.com/revoxai/revox-python/commit/01b1cc7f27c022f32dc456e6c869546dc0486bc0))
* update SDK settings ([fb013a4](https://github.com/revoxai/revox-python/commit/fb013a4c8762720a500b41ab42e90aa25c9c28d2))
* update SDK settings ([2e58195](https://github.com/revoxai/revox-python/commit/2e58195a2c5a74837ec61bf984e0611e403f9c63))
