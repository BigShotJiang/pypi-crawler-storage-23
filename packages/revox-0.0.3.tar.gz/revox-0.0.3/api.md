# Assistants

Types:

```python
from revox.types import (
    AssistantCreateResponse,
    AssistantRetrieveResponse,
    AssistantUpdateResponse,
    AssistantListResponse,
    AssistantDeleteResponse,
)
```

Methods:

- <code title="post /assistants">client.assistants.<a href="./src/revox/resources/assistants.py">create</a>(\*\*<a href="src/revox/types/assistant_create_params.py">params</a>) -> <a href="./src/revox/types/assistant_create_response.py">AssistantCreateResponse</a></code>
- <code title="get /assistants/{id}">client.assistants.<a href="./src/revox/resources/assistants.py">retrieve</a>(id) -> <a href="./src/revox/types/assistant_retrieve_response.py">AssistantRetrieveResponse</a></code>
- <code title="patch /assistants/{id}">client.assistants.<a href="./src/revox/resources/assistants.py">update</a>(id, \*\*<a href="src/revox/types/assistant_update_params.py">params</a>) -> <a href="./src/revox/types/assistant_update_response.py">AssistantUpdateResponse</a></code>
- <code title="get /assistants">client.assistants.<a href="./src/revox/resources/assistants.py">list</a>() -> <a href="./src/revox/types/assistant_list_response.py">AssistantListResponse</a></code>
- <code title="delete /assistants/{id}">client.assistants.<a href="./src/revox/resources/assistants.py">delete</a>(id) -> <a href="./src/revox/types/assistant_delete_response.py">AssistantDeleteResponse</a></code>

# Call

Types:

```python
from revox.types import CallCreateResponse, CallRetrieveResponse, CallListResponse
```

Methods:

- <code title="post /call">client.call.<a href="./src/revox/resources/call.py">create</a>(\*\*<a href="src/revox/types/call_create_params.py">params</a>) -> <a href="./src/revox/types/call_create_response.py">CallCreateResponse</a></code>
- <code title="get /call/{id}">client.call.<a href="./src/revox/resources/call.py">retrieve</a>(id) -> <a href="./src/revox/types/call_retrieve_response.py">CallRetrieveResponse</a></code>
- <code title="get /call">client.call.<a href="./src/revox/resources/call.py">list</a>(\*\*<a href="src/revox/types/call_list_params.py">params</a>) -> <a href="./src/revox/types/call_list_response.py">CallListResponse</a></code>

# Voices

Types:

```python
from revox.types import VoiceRetrieveResponse, VoiceListResponse
```

Methods:

- <code title="get /voices/{id}">client.voices.<a href="./src/revox/resources/voices.py">retrieve</a>(id, \*\*<a href="src/revox/types/voice_retrieve_params.py">params</a>) -> <a href="./src/revox/types/voice_retrieve_response.py">VoiceRetrieveResponse</a></code>
- <code title="get /voices">client.voices.<a href="./src/revox/resources/voices.py">list</a>() -> <a href="./src/revox/types/voice_list_response.py">VoiceListResponse</a></code>
- <code title="post /voices/preview">client.voices.<a href="./src/revox/resources/voices.py">preview</a>(\*\*<a href="src/revox/types/voice_preview_params.py">params</a>) -> None</code>

# Users

## Me

Types:

```python
from revox.types.users import MeRetrieveResponse, MeUpdateResponse
```

Methods:

- <code title="get /users/me">client.users.me.<a href="./src/revox/resources/users/me.py">retrieve</a>() -> <a href="./src/revox/types/users/me_retrieve_response.py">MeRetrieveResponse</a></code>
- <code title="patch /users/me">client.users.me.<a href="./src/revox/resources/users/me.py">update</a>(\*\*<a href="src/revox/types/users/me_update_params.py">params</a>) -> <a href="./src/revox/types/users/me_update_response.py">MeUpdateResponse</a></code>
