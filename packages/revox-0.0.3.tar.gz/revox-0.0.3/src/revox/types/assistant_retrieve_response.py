# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal, TypeAlias

from .._models import BaseModel

__all__ = [
    "AssistantRetrieveResponse",
    "Calendly",
    "CallRetryConfig",
    "CallRetryConfigCallingWindow",
    "LlmModel",
    "LlmModelUnionMember0",
    "LlmModelUnionMember1",
    "StructuredOutputConfig",
    "Voice",
    "FaqItem",
]


class Calendly(BaseModel):
    connection_id: str
    """
    The connection ID representing the link between your Calendly account and Revox.
    """

    event_type_id: str
    """The event type ID representing the event type to schedule.

    (eg: https://api.calendly.com/event_types/b2330295-2a91-4a1d-bb73-99e7707663d5)
    """


class CallRetryConfigCallingWindow(BaseModel):
    calling_window_end_time: str
    """
    End time for the calling window in the recipient's timezone (or
    timezone_override if provided). Format: 'HH:mm' (24-hour) or 'H:mma' (12-hour).
    Examples: '17:00', '6pm'. Default: '18:00'.
    """

    calling_window_start_time: str
    """
    Start time for the calling window in the recipient's timezone (or
    timezone_override if provided). Format: 'HH:mm' (24-hour) or 'H:mma' (12-hour).
    Examples: '09:00', '10am'. Default: '10:00'.
    """

    retry_delay_seconds: int
    """Delay between retry attempts in seconds. Default: 7200 (2 hours)."""


class CallRetryConfig(BaseModel):
    """
    Configuration for call retry behavior including time windows, delays, and max iterations. If not provided, defaults will be used.
    """

    calling_windows: List[CallRetryConfigCallingWindow]

    max_retry_attempts: int
    """Maximum number of call retry attempts. Default: 3."""

    timezone: Optional[str] = None
    """
    Optional IANA timezone identifier to override the automatic timezone detection
    from phone number. If not provided, timezone is determined from the recipient's
    phone number country code. Examples: 'America/New_York', 'Europe/Paris'.
    """


class LlmModelUnionMember0(BaseModel):
    name: Literal["gpt-4.1", "ministral-3-8b-instruct"]

    type: Literal["dedicated-instance"]


class LlmModelUnionMember1(BaseModel):
    openrouter_model_id: str
    """The model ID to use from OpenRouter. eg: openai/gpt-4.1"""

    openrouter_provider: str
    """The provider to use from OpenRouter. eg: nebius, openai, azure, etc."""

    type: Literal["openrouter"]
    """Use a model from OpenRouter."""


LlmModel: TypeAlias = Union[LlmModelUnionMember0, LlmModelUnionMember1]


class StructuredOutputConfig(BaseModel):
    name: str

    required: bool

    type: Literal["string", "number", "boolean", "enum", "date", "datetime"]

    description: Optional[str] = None

    enum_options: Optional[List[str]] = None


class Voice(BaseModel):
    id: str
    """The ID of the voice."""

    provider: Literal["cartesia", "elevenlabs"]
    """The provider of the voice."""

    speed: Optional[float] = None
    """The speed of the voice.

    Range depends on provider: Cartesia 0.6–1.5, ElevenLabs 0.7–1.2. Default is 1.0.
    """


class FaqItem(BaseModel):
    answer: str

    question: str

    id: Optional[str] = None

    needs_human_answer: Optional[bool] = None

    source: Optional[Literal["human", "ai"]] = None


class AssistantRetrieveResponse(BaseModel):
    id: str

    background_sound: Optional[Literal["audio/office.ogg"]] = None
    """The background sound to play during the call.

    Useful to give the impression that your AI agent is in an office.
    """

    calendly: Optional[Calendly] = None

    call_retry_config: Optional[CallRetryConfig] = None
    """
    Configuration for call retry behavior including time windows, delays, and max
    iterations. If not provided, defaults will be used.
    """

    created_at: object

    end_of_call_sentence: Optional[str] = None

    first_sentence: Optional[str] = None

    first_sentence_delay_ms: int
    """Delay in milliseconds before speaking the first sentence. Default: 400."""

    first_sentence_mode: Literal["generated", "static", "none"]

    ivr_navigation_enabled: bool
    """Enable IVR navigation tools.

    When enabled, the assistant can send DTMF tones and skip turns to navigate phone
    menus.
    """

    llm_model: LlmModel

    max_call_duration_secs: float
    """The maximum duration of the call in seconds.

    This is the maximum time the call will be allowed to run.
    """

    name: str

    organization_id: str

    prompt: str

    structured_output_config: Optional[List[StructuredOutputConfig]] = None
    """The structured output config to use for the call.

    This is used to extract the data from the call (like email, name, company name,
    etc.).
    """

    transfer_phone_number: Optional[str] = None
    """Phone number to transfer calls to when users request to speak to a human agent."""

    updated_at: object

    voice: Optional[Voice] = None

    voicemail_message: Optional[str] = None
    """
    If set, when voicemail is detected the agent will speak this message then hang
    up; if null, hang up immediately.
    """

    webhook_url: Optional[str] = None
    """The webhook URL to call when the call is completed."""

    faq_items: Optional[List[FaqItem]] = None

    pending_faq_count: Optional[float] = None
