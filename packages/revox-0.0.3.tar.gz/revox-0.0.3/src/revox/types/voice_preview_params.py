# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["VoicePreviewParams"]


class VoicePreviewParams(TypedDict, total=False):
    provider: Required[Literal["cartesia", "elevenlabs"]]
    """The provider to use for the preview."""

    voice_id: Required[Annotated[str, PropertyInfo(alias="voiceId")]]
    """The voice ID to generate a preview for."""

    text: str
    """The text to generate a preview for."""
