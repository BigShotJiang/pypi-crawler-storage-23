# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from .._models import BaseModel

__all__ = [
    "CallCreateResponse",
    "Call",
    "CallCallAttempt",
    "CallCallAttemptTranscript",
    "CallCallRetryConfig",
    "CallCallRetryConfigCallingWindow",
    "CallLastCallAttempt",
    "CallLastCallAttemptTranscript",
    "CallLlmModel",
    "CallLlmModelUnionMember0",
    "CallLlmModelUnionMember1",
]


class CallCallAttemptTranscript(BaseModel):
    content: str

    role: Literal["user", "assistant", "tool"]

    tool_arguments: Union[Dict[str, object], str, None] = None

    tool_is_error: Optional[bool] = None

    tool_name: Optional[str] = None


class CallCallAttempt(BaseModel):
    """This represent a single call attempt.

    A call attempt is a single call made to the phone number.
    """

    id: str
    """The ID of the call attempt."""

    answered_at: object
    """The time the call was answered."""

    ended_at: object
    """The time the call ended."""

    phone_number: str
    """The phone number that was called.

    Formatted in E.164 format. Example: +1234567890
    """

    recording_url: Optional[str] = None
    """The URL of the audio recording of the call."""

    result: Optional[Literal["IVR", "voicemail", "human", "unknown"]] = None

    started_at: object
    """The time the call started."""

    status: Literal["queued", "ringing", "ongoing", "completed"]
    """The status of the call attempt."""

    structured_output: Optional[Dict[str, object]] = None
    """
    The data extracted from the call, using the structured output config from the
    parent call object.
    """

    transcript: Optional[List[CallCallAttemptTranscript]] = None
    """The transcript of the call."""


class CallCallRetryConfigCallingWindow(BaseModel):
    calling_window_end_time: str
    """
    End time for the calling window in the recipient's timezone (or
    timezone_override if provided). Format: 'HH:mm' (24-hour) or 'H:mma' (12-hour).
    Examples: '17:00', '6pm'. Default: '18:00'.
    """

    calling_window_start_time: str
    """
    Start time for the calling window in the recipient's timezone (or
    timezone_override if provided). Format: 'HH:mm' (24-hour) or 'H:mma' (12-hour).
    Examples: '09:00', '10am'. Default: '10:00'.
    """

    retry_delay_seconds: int
    """Delay between retry attempts in seconds. Default: 7200 (2 hours)."""


class CallCallRetryConfig(BaseModel):
    """
    Configuration for call retry behavior including time windows, delays, and max iterations. If not provided, defaults will be used.
    """

    calling_windows: List[CallCallRetryConfigCallingWindow]

    max_retry_attempts: int
    """Maximum number of call retry attempts. Default: 3."""

    timezone: Optional[str] = None
    """
    Optional IANA timezone identifier to override the automatic timezone detection
    from phone number. If not provided, timezone is determined from the recipient's
    phone number country code. Examples: 'America/New_York', 'Europe/Paris'.
    """


class CallLastCallAttemptTranscript(BaseModel):
    content: str

    role: Literal["user", "assistant", "tool"]

    tool_arguments: Union[Dict[str, object], str, None] = None

    tool_is_error: Optional[bool] = None

    tool_name: Optional[str] = None


class CallLastCallAttempt(BaseModel):
    """This represent a single call attempt.

    A call attempt is a single call made to the phone number.
    """

    id: str
    """The ID of the call attempt."""

    answered_at: object
    """The time the call was answered."""

    ended_at: object
    """The time the call ended."""

    phone_number: str
    """The phone number that was called.

    Formatted in E.164 format. Example: +1234567890
    """

    recording_url: Optional[str] = None
    """The URL of the audio recording of the call."""

    result: Optional[Literal["IVR", "voicemail", "human", "unknown"]] = None

    started_at: object
    """The time the call started."""

    status: Literal["queued", "ringing", "ongoing", "completed"]
    """The status of the call attempt."""

    structured_output: Optional[Dict[str, object]] = None
    """
    The data extracted from the call, using the structured output config from the
    parent call object.
    """

    transcript: Optional[List[CallLastCallAttemptTranscript]] = None
    """The transcript of the call."""


class CallLlmModelUnionMember0(BaseModel):
    name: Literal["gpt-4.1", "ministral-3-8b-instruct"]

    type: Literal["dedicated-instance"]


class CallLlmModelUnionMember1(BaseModel):
    openrouter_model_id: str
    """The model ID to use from OpenRouter. eg: openai/gpt-4.1"""

    openrouter_provider: str
    """The provider to use from OpenRouter. eg: nebius, openai, azure, etc."""

    type: Literal["openrouter"]
    """Use a model from OpenRouter."""


CallLlmModel: TypeAlias = Union[CallLlmModelUnionMember0, CallLlmModelUnionMember1]


class Call(BaseModel):
    """This represent a call "order" that was requested by the user.

    A call order can be resolved over multiple call attempts spanning up to a few days.
    """

    id: str
    """The ID of the call."""

    call_attempts: List[CallCallAttempt]
    """All call attempts for this call order, ordered by most recent first."""

    call_retry_config: Optional[CallCallRetryConfig] = None
    """
    Configuration for call retry behavior including time windows, delays, and max
    iterations. If not provided, defaults will be used.
    """

    calls_count: float
    """The number of call attempts made."""

    created_at: object
    """The time the call order was created."""

    direction: Literal["inbound", "outbound"]
    """Whether the call is inbound or outbound."""

    first_sentence_delay_ms: int
    """Delay in milliseconds before speaking the first sentence. Default: 400."""

    from_phone_number: str
    """The phone number that made the call.

    Formatted in E.164 format. Example: +1234567890
    """

    is_cancelled: bool
    """Whether the call was cancelled."""

    is_completed: bool
    """Whether the call is completed or still in progress."""

    last_call_attempt: Optional[CallLastCallAttempt] = None
    """This represent a single call attempt.

    A call attempt is a single call made to the phone number.
    """

    llm_model: CallLlmModel

    metadata: Optional[Dict[str, str]] = None
    """Metadata stored with the call."""

    next_call_at: object
    """The next call attempt time."""

    scheduled_at: object
    """The time the call order is scheduled to start."""

    to_phone_number: str
    """The phone number that received the call.

    Formatted in E.164 format. Example: +1234567890
    """


class CallCreateResponse(BaseModel):
    call: Call
    """This represent a call "order" that was requested by the user.

    A call order can be resolved over multiple call attempts spanning up to a few
    days.
    """
