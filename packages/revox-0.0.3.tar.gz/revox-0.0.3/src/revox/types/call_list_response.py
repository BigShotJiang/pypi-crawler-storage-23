# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["CallListResponse", "Call", "CallTranscript"]


class CallTranscript(BaseModel):
    content: str

    role: Literal["user", "assistant", "tool"]

    tool_arguments: Union[Dict[str, object], str, None] = None

    tool_is_error: Optional[bool] = None

    tool_name: Optional[str] = None


class Call(BaseModel):
    """This represent a single call attempt.

    A call attempt is a single call made to the phone number.
    """

    id: str
    """The ID of the call attempt."""

    answered_at: object
    """The time the call was answered."""

    ended_at: object
    """The time the call ended."""

    phone_number: str
    """The phone number that was called.

    Formatted in E.164 format. Example: +1234567890
    """

    recording_url: Optional[str] = None
    """The URL of the audio recording of the call."""

    result: Optional[Literal["IVR", "voicemail", "human", "unknown"]] = None

    started_at: object
    """The time the call started."""

    status: Literal["queued", "ringing", "ongoing", "completed"]
    """The status of the call attempt."""

    structured_output: Optional[Dict[str, object]] = None
    """
    The data extracted from the call, using the structured output config from the
    parent call object.
    """

    transcript: Optional[List[CallTranscript]] = None
    """The transcript of the call."""


class CallListResponse(BaseModel):
    calls: List[Call]
