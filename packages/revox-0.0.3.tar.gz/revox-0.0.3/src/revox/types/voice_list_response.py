# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["VoiceListResponse", "Voice"]


class Voice(BaseModel):
    id: str
    """The ID of the voice."""

    description: str
    """The description of the voice."""

    language: Literal["en", "fr", "es", "de", "it", "pt", "ru", "zh"]
    """The language of the voice."""

    name: str
    """The name of the voice."""

    provider: Literal["cartesia", "elevenlabs"]
    """The provider of the voice."""


class VoiceListResponse(BaseModel):
    voices: List[Voice]
