# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["MeRetrieveResponse", "User"]


class User(BaseModel):
    """The current authenticated user."""

    id: str
    """The unique identifier of the user."""

    created_at: object
    """The time the user was created."""

    email: str
    """The email address of the user."""

    first_name: Optional[str] = None
    """The first name of the user."""

    has_completed_onboarding: bool
    """Whether the user has completed the onboarding tutorial."""

    last_name: Optional[str] = None
    """The last name of the user."""

    organization_id: str
    """The ID of the organization the user belongs to."""

    updated_at: object
    """The time the user was last updated."""


class MeRetrieveResponse(BaseModel):
    user: User
    """The current authenticated user."""
