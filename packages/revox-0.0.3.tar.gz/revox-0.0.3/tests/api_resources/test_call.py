# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from revox import Revox, AsyncRevox
from revox.types import CallListResponse, CallCreateResponse, CallRetrieveResponse
from tests.utils import assert_matches_type
from revox._utils import parse_datetime

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestCall:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Revox) -> None:
        call = client.call.create(
            phone_number="phone_number",
        )
        assert_matches_type(CallCreateResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Revox) -> None:
        call = client.call.create(
            phone_number="phone_number",
            assistant={
                "prompt": "prompt",
                "background_sound": "audio/office.ogg",
                "calendly": {
                    "connection_id": "connection_id",
                    "event_type_id": "event_type_id",
                },
                "call_retry_config": {
                    "calling_windows": [
                        {
                            "calling_window_end_time": "calling_window_end_time",
                            "calling_window_start_time": "calling_window_start_time",
                            "retry_delay_seconds": 1,
                        }
                    ],
                    "max_retry_attempts": 1,
                    "timezone": "timezone",
                },
                "end_of_call_sentence": "end_of_call_sentence",
                "faq_items": [
                    {
                        "answer": "answer",
                        "question": "question",
                    }
                ],
                "first_sentence": "first_sentence",
                "first_sentence_delay_ms": 0,
                "first_sentence_mode": "generated",
                "ivr_navigation_enabled": True,
                "llm_model": {
                    "name": "gpt-4.1",
                    "type": "dedicated-instance",
                },
                "max_call_duration_secs": 0,
                "structured_output_config": [
                    {
                        "name": "x",
                        "required": True,
                        "type": "string",
                        "description": "description",
                        "enum_options": ["string"],
                    }
                ],
                "transfer_phone_number": "transfer_phone_number",
                "voice": {
                    "id": "x",
                    "provider": "cartesia",
                    "speed": 0.6,
                },
                "voicemail_message": "voicemail_message",
                "webhook_url": "webhook_url",
            },
            assistant_id="assistant_id",
            concurrency={
                "key": "key",
                "max": 1,
            },
            force_now=True,
            from_phone_number="from_phone_number",
            metadata={"foo": "string"},
            prompt_variables={"foo": "string"},
            scheduled_at=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(CallCreateResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Revox) -> None:
        response = client.call.with_raw_response.create(
            phone_number="phone_number",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        call = response.parse()
        assert_matches_type(CallCreateResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Revox) -> None:
        with client.call.with_streaming_response.create(
            phone_number="phone_number",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            call = response.parse()
            assert_matches_type(CallCreateResponse, call, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Revox) -> None:
        call = client.call.retrieve(
            "id",
        )
        assert_matches_type(CallRetrieveResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Revox) -> None:
        response = client.call.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        call = response.parse()
        assert_matches_type(CallRetrieveResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Revox) -> None:
        with client.call.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            call = response.parse()
            assert_matches_type(CallRetrieveResponse, call, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Revox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.call.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Revox) -> None:
        call = client.call.list(
            page=0,
            page_size=0,
        )
        assert_matches_type(CallListResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Revox) -> None:
        response = client.call.with_raw_response.list(
            page=0,
            page_size=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        call = response.parse()
        assert_matches_type(CallListResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Revox) -> None:
        with client.call.with_streaming_response.list(
            page=0,
            page_size=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            call = response.parse()
            assert_matches_type(CallListResponse, call, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncCall:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncRevox) -> None:
        call = await async_client.call.create(
            phone_number="phone_number",
        )
        assert_matches_type(CallCreateResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncRevox) -> None:
        call = await async_client.call.create(
            phone_number="phone_number",
            assistant={
                "prompt": "prompt",
                "background_sound": "audio/office.ogg",
                "calendly": {
                    "connection_id": "connection_id",
                    "event_type_id": "event_type_id",
                },
                "call_retry_config": {
                    "calling_windows": [
                        {
                            "calling_window_end_time": "calling_window_end_time",
                            "calling_window_start_time": "calling_window_start_time",
                            "retry_delay_seconds": 1,
                        }
                    ],
                    "max_retry_attempts": 1,
                    "timezone": "timezone",
                },
                "end_of_call_sentence": "end_of_call_sentence",
                "faq_items": [
                    {
                        "answer": "answer",
                        "question": "question",
                    }
                ],
                "first_sentence": "first_sentence",
                "first_sentence_delay_ms": 0,
                "first_sentence_mode": "generated",
                "ivr_navigation_enabled": True,
                "llm_model": {
                    "name": "gpt-4.1",
                    "type": "dedicated-instance",
                },
                "max_call_duration_secs": 0,
                "structured_output_config": [
                    {
                        "name": "x",
                        "required": True,
                        "type": "string",
                        "description": "description",
                        "enum_options": ["string"],
                    }
                ],
                "transfer_phone_number": "transfer_phone_number",
                "voice": {
                    "id": "x",
                    "provider": "cartesia",
                    "speed": 0.6,
                },
                "voicemail_message": "voicemail_message",
                "webhook_url": "webhook_url",
            },
            assistant_id="assistant_id",
            concurrency={
                "key": "key",
                "max": 1,
            },
            force_now=True,
            from_phone_number="from_phone_number",
            metadata={"foo": "string"},
            prompt_variables={"foo": "string"},
            scheduled_at=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(CallCreateResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncRevox) -> None:
        response = await async_client.call.with_raw_response.create(
            phone_number="phone_number",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        call = await response.parse()
        assert_matches_type(CallCreateResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncRevox) -> None:
        async with async_client.call.with_streaming_response.create(
            phone_number="phone_number",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            call = await response.parse()
            assert_matches_type(CallCreateResponse, call, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncRevox) -> None:
        call = await async_client.call.retrieve(
            "id",
        )
        assert_matches_type(CallRetrieveResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncRevox) -> None:
        response = await async_client.call.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        call = await response.parse()
        assert_matches_type(CallRetrieveResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncRevox) -> None:
        async with async_client.call.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            call = await response.parse()
            assert_matches_type(CallRetrieveResponse, call, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncRevox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.call.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncRevox) -> None:
        call = await async_client.call.list(
            page=0,
            page_size=0,
        )
        assert_matches_type(CallListResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncRevox) -> None:
        response = await async_client.call.with_raw_response.list(
            page=0,
            page_size=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        call = await response.parse()
        assert_matches_type(CallListResponse, call, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncRevox) -> None:
        async with async_client.call.with_streaming_response.list(
            page=0,
            page_size=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            call = await response.parse()
            assert_matches_type(CallListResponse, call, path=["response"])

        assert cast(Any, response.is_closed) is True
