# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from revox import Revox, AsyncRevox
from revox.types import (
    AssistantListResponse,
    AssistantCreateResponse,
    AssistantDeleteResponse,
    AssistantUpdateResponse,
    AssistantRetrieveResponse,
)
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAssistants:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Revox) -> None:
        assistant = client.assistants.create(
            name="name",
            prompt="prompt",
        )
        assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Revox) -> None:
        assistant = client.assistants.create(
            name="name",
            prompt="prompt",
            background_sound="audio/office.ogg",
            calendly={
                "connection_id": "connection_id",
                "event_type_id": "event_type_id",
            },
            call_retry_config={
                "calling_windows": [
                    {
                        "calling_window_end_time": "calling_window_end_time",
                        "calling_window_start_time": "calling_window_start_time",
                        "retry_delay_seconds": 1,
                    }
                ],
                "max_retry_attempts": 1,
                "timezone": "timezone",
            },
            end_of_call_sentence="end_of_call_sentence",
            faq_items=[
                {
                    "answer": "answer",
                    "question": "question",
                }
            ],
            first_sentence="first_sentence",
            first_sentence_delay_ms=0,
            first_sentence_mode="generated",
            ivr_navigation_enabled=True,
            llm_model={
                "name": "gpt-4.1",
                "type": "dedicated-instance",
            },
            max_call_duration_secs=0,
            structured_output_config=[
                {
                    "name": "x",
                    "required": True,
                    "type": "string",
                    "description": "description",
                    "enum_options": ["string"],
                }
            ],
            transfer_phone_number="transfer_phone_number",
            voice={
                "id": "x",
                "provider": "cartesia",
                "speed": 0.6,
            },
            voicemail_message="voicemail_message",
            webhook_url="webhook_url",
        )
        assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Revox) -> None:
        response = client.assistants.with_raw_response.create(
            name="name",
            prompt="prompt",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = response.parse()
        assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Revox) -> None:
        with client.assistants.with_streaming_response.create(
            name="name",
            prompt="prompt",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = response.parse()
            assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Revox) -> None:
        assistant = client.assistants.retrieve(
            "id",
        )
        assert_matches_type(AssistantRetrieveResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Revox) -> None:
        response = client.assistants.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = response.parse()
        assert_matches_type(AssistantRetrieveResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Revox) -> None:
        with client.assistants.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = response.parse()
            assert_matches_type(AssistantRetrieveResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Revox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.assistants.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Revox) -> None:
        assistant = client.assistants.update(
            id="id",
        )
        assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Revox) -> None:
        assistant = client.assistants.update(
            id="id",
            background_sound="audio/office.ogg",
            calendly={
                "connection_id": "connection_id",
                "event_type_id": "event_type_id",
            },
            call_retry_config={
                "calling_windows": [
                    {
                        "calling_window_end_time": "calling_window_end_time",
                        "calling_window_start_time": "calling_window_start_time",
                        "retry_delay_seconds": 1,
                    }
                ],
                "max_retry_attempts": 1,
                "timezone": "timezone",
            },
            end_of_call_sentence="end_of_call_sentence",
            faq_items=[
                {
                    "answer": "answer",
                    "question": "question",
                }
            ],
            first_sentence="first_sentence",
            first_sentence_delay_ms=0,
            first_sentence_mode="generated",
            ivr_navigation_enabled=True,
            llm_model={
                "name": "gpt-4.1",
                "type": "dedicated-instance",
            },
            max_call_duration_secs=0,
            name="name",
            prompt="prompt",
            structured_output_config=[
                {
                    "name": "x",
                    "required": True,
                    "type": "string",
                    "description": "description",
                    "enum_options": ["string"],
                }
            ],
            transfer_phone_number="transfer_phone_number",
            voice={
                "id": "x",
                "provider": "cartesia",
                "speed": 0.6,
            },
            voicemail_message="voicemail_message",
            webhook_url="webhook_url",
        )
        assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Revox) -> None:
        response = client.assistants.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = response.parse()
        assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Revox) -> None:
        with client.assistants.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = response.parse()
            assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Revox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.assistants.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Revox) -> None:
        assistant = client.assistants.list()
        assert_matches_type(AssistantListResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Revox) -> None:
        response = client.assistants.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = response.parse()
        assert_matches_type(AssistantListResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Revox) -> None:
        with client.assistants.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = response.parse()
            assert_matches_type(AssistantListResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Revox) -> None:
        assistant = client.assistants.delete(
            "id",
        )
        assert_matches_type(AssistantDeleteResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Revox) -> None:
        response = client.assistants.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = response.parse()
        assert_matches_type(AssistantDeleteResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Revox) -> None:
        with client.assistants.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = response.parse()
            assert_matches_type(AssistantDeleteResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Revox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.assistants.with_raw_response.delete(
                "",
            )


class TestAsyncAssistants:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncRevox) -> None:
        assistant = await async_client.assistants.create(
            name="name",
            prompt="prompt",
        )
        assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncRevox) -> None:
        assistant = await async_client.assistants.create(
            name="name",
            prompt="prompt",
            background_sound="audio/office.ogg",
            calendly={
                "connection_id": "connection_id",
                "event_type_id": "event_type_id",
            },
            call_retry_config={
                "calling_windows": [
                    {
                        "calling_window_end_time": "calling_window_end_time",
                        "calling_window_start_time": "calling_window_start_time",
                        "retry_delay_seconds": 1,
                    }
                ],
                "max_retry_attempts": 1,
                "timezone": "timezone",
            },
            end_of_call_sentence="end_of_call_sentence",
            faq_items=[
                {
                    "answer": "answer",
                    "question": "question",
                }
            ],
            first_sentence="first_sentence",
            first_sentence_delay_ms=0,
            first_sentence_mode="generated",
            ivr_navigation_enabled=True,
            llm_model={
                "name": "gpt-4.1",
                "type": "dedicated-instance",
            },
            max_call_duration_secs=0,
            structured_output_config=[
                {
                    "name": "x",
                    "required": True,
                    "type": "string",
                    "description": "description",
                    "enum_options": ["string"],
                }
            ],
            transfer_phone_number="transfer_phone_number",
            voice={
                "id": "x",
                "provider": "cartesia",
                "speed": 0.6,
            },
            voicemail_message="voicemail_message",
            webhook_url="webhook_url",
        )
        assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncRevox) -> None:
        response = await async_client.assistants.with_raw_response.create(
            name="name",
            prompt="prompt",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = await response.parse()
        assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncRevox) -> None:
        async with async_client.assistants.with_streaming_response.create(
            name="name",
            prompt="prompt",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = await response.parse()
            assert_matches_type(AssistantCreateResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncRevox) -> None:
        assistant = await async_client.assistants.retrieve(
            "id",
        )
        assert_matches_type(AssistantRetrieveResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncRevox) -> None:
        response = await async_client.assistants.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = await response.parse()
        assert_matches_type(AssistantRetrieveResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncRevox) -> None:
        async with async_client.assistants.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = await response.parse()
            assert_matches_type(AssistantRetrieveResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncRevox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.assistants.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncRevox) -> None:
        assistant = await async_client.assistants.update(
            id="id",
        )
        assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncRevox) -> None:
        assistant = await async_client.assistants.update(
            id="id",
            background_sound="audio/office.ogg",
            calendly={
                "connection_id": "connection_id",
                "event_type_id": "event_type_id",
            },
            call_retry_config={
                "calling_windows": [
                    {
                        "calling_window_end_time": "calling_window_end_time",
                        "calling_window_start_time": "calling_window_start_time",
                        "retry_delay_seconds": 1,
                    }
                ],
                "max_retry_attempts": 1,
                "timezone": "timezone",
            },
            end_of_call_sentence="end_of_call_sentence",
            faq_items=[
                {
                    "answer": "answer",
                    "question": "question",
                }
            ],
            first_sentence="first_sentence",
            first_sentence_delay_ms=0,
            first_sentence_mode="generated",
            ivr_navigation_enabled=True,
            llm_model={
                "name": "gpt-4.1",
                "type": "dedicated-instance",
            },
            max_call_duration_secs=0,
            name="name",
            prompt="prompt",
            structured_output_config=[
                {
                    "name": "x",
                    "required": True,
                    "type": "string",
                    "description": "description",
                    "enum_options": ["string"],
                }
            ],
            transfer_phone_number="transfer_phone_number",
            voice={
                "id": "x",
                "provider": "cartesia",
                "speed": 0.6,
            },
            voicemail_message="voicemail_message",
            webhook_url="webhook_url",
        )
        assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncRevox) -> None:
        response = await async_client.assistants.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = await response.parse()
        assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncRevox) -> None:
        async with async_client.assistants.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = await response.parse()
            assert_matches_type(AssistantUpdateResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncRevox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.assistants.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncRevox) -> None:
        assistant = await async_client.assistants.list()
        assert_matches_type(AssistantListResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncRevox) -> None:
        response = await async_client.assistants.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = await response.parse()
        assert_matches_type(AssistantListResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncRevox) -> None:
        async with async_client.assistants.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = await response.parse()
            assert_matches_type(AssistantListResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncRevox) -> None:
        assistant = await async_client.assistants.delete(
            "id",
        )
        assert_matches_type(AssistantDeleteResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncRevox) -> None:
        response = await async_client.assistants.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        assistant = await response.parse()
        assert_matches_type(AssistantDeleteResponse, assistant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncRevox) -> None:
        async with async_client.assistants.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            assistant = await response.parse()
            assert_matches_type(AssistantDeleteResponse, assistant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncRevox) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.assistants.with_raw_response.delete(
                "",
            )
