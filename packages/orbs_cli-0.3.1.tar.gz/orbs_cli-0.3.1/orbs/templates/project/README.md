# orbs
This is Orbs project sample scaffolding

# Run with shortcut
- Open file test_suite.yml or test_case.py
- Press `ctrl + F5`

# Run with command
- Open terminal
- Run: `python .\main.py tests\suites\login_suite.yml`