# pot-sdk-crewai — Build Spec

## Overview
CrewAI integration for ThoughtProof Protocol. Python package.
Two components:
1. **ThoughtProofVerifyTool** — A CrewAI `@tool` that any agent can call to verify claims
2. **ThoughtProofGuardrail** — A task guardrail that verifies agent output before accepting it

## Dependencies
- `requests` — HTTP calls to pot-api or direct model APIs
- No direct pot-sdk dependency (TypeScript) — instead uses HTTP API or wraps model calls natively

## Architecture Decision
Since pot-sdk is TypeScript and CrewAI is Python, we have two options:
- **Option A:** Call pot-api REST endpoint (requires running pot-api server)
- **Option B:** Native Python implementation of multi-model verification (self-contained)

**Choose Option B** — self-contained Python, no server dependency. Uses litellm for model calls.

## Dependencies
- `litellm` — unified LLM API (supports all providers)
- `pydantic` — data models (CrewAI already requires this)

## Module 1: ThoughtProofVerifyTool

```python
from crewai.tools import tool
from pot_sdk_crewai import verify_claim

@tool("Verify Claim")
def verify_claim_tool(claim: str) -> str:
    """Verify a claim using multi-model adversarial verification.
    Use this tool when you need to fact-check a statement or validate reasoning."""
    result = verify_claim(
        claim=claim,
        models=["anthropic/claude-sonnet-4-5", "xai/grok-4-1-fast", "deepseek/deepseek-chat"],
        mode="adversarial"
    )
    return f"Verdict: {result.verdict}, Confidence: {result.confidence}, Convergence: {result.convergence}"
```

Or using the class-based approach:

```python
from pot_sdk_crewai import ThoughtProofVerifyTool

verify_tool = ThoughtProofVerifyTool(
    models=["anthropic/claude-sonnet-4-5", "xai/grok-4-1-fast"],
    mode="adversarial",
    threshold=0.7
)

agent = Agent(
    role="Research Analyst",
    tools=[verify_tool],
    ...
)
```

## Module 2: ThoughtProofGuardrail

```python
from pot_sdk_crewai import ThoughtProofGuardrail

guardrail = ThoughtProofGuardrail(
    models=["anthropic/claude-sonnet-4-5", "deepseek/deepseek-chat"],
    mode="calibrative",
    min_confidence=0.7
)

task = Task(
    description="Analyze market trends",
    agent=analyst,
    guardrail=guardrail.validate  # CrewAI guardrail interface
)
```

The guardrail returns `(True, result)` if verification passes, `(False, "Verification failed: ...")` if not.

## Core verify_claim function

```python
def verify_claim(
    claim: str,
    models: list[str],
    mode: str = "adversarial",  # adversarial | resistant | calibrative
    domain: str | None = None,
    timeout: float = 30.0
) -> VerificationResult:
    """
    Multi-model verification. Each model independently assesses the claim,
    then results are synthesized with dissent preservation.
    """
```

### Verification Flow:
1. Send claim to each model with role-specific prompt (based on mode)
2. Parse each response for verdict + confidence + reasoning
3. Calculate convergence (agreement ratio)
4. Synthesize: majority verdict, mean confidence, preserve dissent
5. Return VerificationResult

## Package Structure
```
pot-sdk-crewai/
├── pot_sdk_crewai/
│   ├── __init__.py
│   ├── verify.py           # Core verify_claim function
│   ├── tool.py             # ThoughtProofVerifyTool (CrewAI BaseTool)
│   ├── guardrail.py        # ThoughtProofGuardrail
│   ├── prompts.py          # Verification prompts per mode
│   └── types.py            # Pydantic models
├── tests/
│   ├── test_verify.py
│   ├── test_tool.py
│   └── test_guardrail.py
├── pyproject.toml
└── README.md
```

## pyproject.toml key fields
- name: `pot-sdk-crewai`
- version: `0.1.0`
- dependencies: `litellm>=1.0.0`, `pydantic>=2.0.0`
- optional-dependencies.crewai: `crewai>=0.60.0`
