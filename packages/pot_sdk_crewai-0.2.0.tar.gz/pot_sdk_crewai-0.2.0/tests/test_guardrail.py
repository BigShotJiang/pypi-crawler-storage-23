"""Tests for ThoughtProofGuardrail."""
from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from pot_sdk_crewai.guardrail import ThoughtProofGuardrail
from pot_sdk_crewai.types import VerificationResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_response(verdict: str, confidence: float, reasoning: str) -> MagicMock:
    payload = json.dumps({"verdict": verdict, "confidence": confidence, "reasoning": reasoning})
    msg = MagicMock()
    msg.content = payload
    choice = MagicMock()
    choice.message = msg
    resp = MagicMock()
    resp.choices = [choice]
    return resp


MODELS = ["mock/model-a", "mock/model-b"]


def _guardrail(**kwargs) -> ThoughtProofGuardrail:
    defaults = dict(models=MODELS, mode="calibrative", min_confidence=0.7)
    defaults.update(kwargs)
    return ThoughtProofGuardrail(**defaults)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestThoughtProofGuardrail:

    # --- init validation ---

    def test_empty_models_raises(self):
        with pytest.raises(ValueError, match="At least one model"):
            ThoughtProofGuardrail(models=[])

    # --- extract_claim ---

    def test_extract_raw_attribute(self):
        g = _guardrail()
        task_output = MagicMock()
        task_output.raw = "The claim from task output."
        assert g._extract_claim(task_output) == "The claim from task output."

    def test_extract_str_fallback(self):
        g = _guardrail()
        assert g._extract_claim("plain string") == "plain string"

    def test_extract_non_string_object(self):
        g = _guardrail()
        result = g._extract_claim(42)
        assert result == "42"

    # --- validate: accept path ---

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_accept_true_high_confidence(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.9, "solid")
        g = _guardrail(min_confidence=0.7)
        ok, val = g.validate("The sky is blue.")
        assert ok is True
        assert isinstance(val, VerificationResult)

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_accept_uncertain_when_allow_uncertain(self, mock_completion):
        mock_completion.return_value = _make_response("UNCERTAIN", 0.75, "idk")
        g = _guardrail(allow_uncertain=True, min_confidence=0.7)
        ok, val = g.validate("A borderline claim.")
        assert ok is True

    # --- validate: reject path ---

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_reject_false_verdict(self, mock_completion):
        mock_completion.return_value = _make_response("UNVERIFIED", 0.9, "wrong")
        g = _guardrail()
        ok, msg = g.validate("2 + 2 = 5")
        assert ok is False
        assert "UNVERIFIED" in msg

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_reject_low_confidence(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.4, "maybe")
        g = _guardrail(min_confidence=0.7)
        ok, msg = g.validate("Uncertain claim.")
        assert ok is False
        assert "confidence" in msg.lower()

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_reject_uncertain_by_default(self, mock_completion):
        mock_completion.return_value = _make_response("UNCERTAIN", 0.9, "dunno")
        g = _guardrail(allow_uncertain=False)
        ok, msg = g.validate("Ambiguous claim.")
        assert ok is False
        assert "UNCERTAIN" in msg

    # --- validate: TaskOutput object ---

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_validates_task_output_object(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.85, "yes")
        task_output = MagicMock()
        task_output.raw = "The Earth orbits the Sun."
        g = _guardrail()
        ok, val = g.validate(task_output)
        assert ok is True
        # Confirm the claim extracted from .raw was actually sent
        call_args = mock_completion.call_args
        user_msg = next(m["content"] for m in call_args.kwargs["messages"] if m["role"] == "user")
        assert "Earth orbits the Sun" in user_msg

    # --- rejection message quality ---

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_rejection_message_includes_verdict_and_confidence(self, mock_completion):
        mock_completion.return_value = _make_response("UNVERIFIED", 0.95, "clearly wrong")
        g = _guardrail()
        ok, msg = g.validate("A false claim.")
        assert ok is False
        assert "verdict" in msg.lower() or "UNVERIFIED" in msg
        assert "confidence" in msg.lower() or "0.95" in msg

    # --- domain forwarding ---

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_domain_forwarded_to_verifier(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.9, "ok")
        g = ThoughtProofGuardrail(models=MODELS, domain="medicine")
        g.validate("Aspirin reduces fever.")
        call_args = mock_completion.call_args
        user_msg = next(m["content"] for m in call_args.kwargs["messages"] if m["role"] == "user")
        assert "medicine" in user_msg
