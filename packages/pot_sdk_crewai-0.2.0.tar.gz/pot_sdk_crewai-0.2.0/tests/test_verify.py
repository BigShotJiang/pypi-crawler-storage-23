"""Tests for pot_sdk_crewai.verify — all LLM calls are mocked."""
from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from pot_sdk_crewai.types import ModelVerdict, VerificationResult
from pot_sdk_crewai.verify import (
    _extract_json,
    _parse_verdict,
    _synthesize,
    verify_claim,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_response(content: str) -> MagicMock:
    """Build a minimal litellm-style response mock."""
    msg = MagicMock()
    msg.content = content
    choice = MagicMock()
    choice.message = msg
    resp = MagicMock()
    resp.choices = [choice]
    return resp


def _json_response(verdict: str, confidence: float, reasoning: str) -> MagicMock:
    payload = json.dumps({"verdict": verdict, "confidence": confidence, "reasoning": reasoning})
    return _make_response(payload)


# ---------------------------------------------------------------------------
# _extract_json
# ---------------------------------------------------------------------------

class TestExtractJson:
    def test_plain_json(self):
        raw = '{"verdict": "VERIFIED", "confidence": 0.9, "reasoning": "ok"}'
        data = _extract_json(raw)
        assert data["verdict"] == "VERIFIED"

    def test_json_with_markdown_fence(self):
        raw = "```json\n{\"verdict\": \"FALSE\", \"confidence\": 0.8, \"reasoning\": \"no\"}\n```"
        data = _extract_json(raw)
        assert data["verdict"] == "FALSE"  # _extract_json returns raw; mapping happens in _parse_verdict

    def test_json_embedded_in_prose(self):
        raw = 'Sure! Here is my answer:\n{"verdict": "UNCERTAIN", "confidence": 0.5, "reasoning": "idk"}\nHope that helps.'
        data = _extract_json(raw)
        assert data["verdict"] == "UNCERTAIN"

    def test_no_json_raises(self):
        with pytest.raises(ValueError, match="No JSON object"):
            _extract_json("This is just plain text with no JSON.")


# ---------------------------------------------------------------------------
# _parse_verdict
# ---------------------------------------------------------------------------

class TestParseVerdict:
    def test_valid_true(self):
        mv = _parse_verdict({"verdict": "VERIFIED", "confidence": 0.9, "reasoning": "solid"}, "model-a")
        assert mv.verdict == "VERIFIED"
        assert mv.confidence == 0.9
        assert mv.model == "model-a"

    def test_confidence_clamping(self):
        mv = _parse_verdict({"verdict": "UNVERIFIED", "confidence": 1.5, "reasoning": "x"}, "m")
        assert mv.confidence == 1.0
        mv2 = _parse_verdict({"verdict": "UNVERIFIED", "confidence": -0.3, "reasoning": "x"}, "m")
        assert mv2.confidence == 0.0

    def test_unknown_verdict_becomes_uncertain(self):
        mv = _parse_verdict({"verdict": "MAYBE", "confidence": 0.5, "reasoning": "dunno"}, "m")
        assert mv.verdict == "UNCERTAIN"

    def test_missing_keys_use_defaults(self):
        mv = _parse_verdict({}, "m")
        assert mv.verdict == "UNCERTAIN"
        assert mv.confidence == 0.5


# ---------------------------------------------------------------------------
# _synthesize
# ---------------------------------------------------------------------------

class TestSynthesize:
    def _mv(self, model: str, verdict: str, confidence: float) -> ModelVerdict:
        return ModelVerdict(model=model, verdict=verdict, confidence=confidence, reasoning="r")  # type: ignore[arg-type]

    def test_unanimous_true(self):
        verdicts = [
            self._mv("a", "VERIFIED", 0.9),
            self._mv("b", "VERIFIED", 0.8),
            self._mv("c", "VERIFIED", 0.7),
        ]
        result = _synthesize("claim", "adversarial", verdicts)
        assert result.verdict == "VERIFIED"
        assert result.convergence == pytest.approx(1.0)
        assert result.confidence == pytest.approx((0.9 + 0.8 + 0.7) / 3, abs=1e-4)
        assert result.dissent == []

    def test_majority_false_with_dissent(self):
        verdicts = [
            self._mv("a", "UNVERIFIED", 0.8),
            self._mv("b", "UNVERIFIED", 0.9),
            self._mv("c", "VERIFIED", 0.6),
        ]
        result = _synthesize("claim", "adversarial", verdicts)
        assert result.verdict == "UNVERIFIED"
        assert result.convergence == pytest.approx(2 / 3, abs=1e-3)
        assert len(result.dissent) == 1
        assert result.dissent[0].model == "c"

    def test_uncertain_when_all_differ(self):
        verdicts = [
            self._mv("a", "VERIFIED", 0.6),
            self._mv("b", "UNVERIFIED", 0.6),
            self._mv("c", "UNCERTAIN", 0.6),
        ]
        result = _synthesize("claim", "calibrative", verdicts)
        # Each verdict appears once — any could win; convergence = 1/3
        assert result.convergence == pytest.approx(1 / 3, abs=1e-3)
        assert result.verdict == "DISSENT"
        assert len(result.dissent) == 0  # DISSENT = all models, none in dissent list

    def test_single_model(self):
        verdicts = [self._mv("solo", "VERIFIED", 0.95)]
        result = _synthesize("claim", "resistant", verdicts)
        assert result.verdict == "VERIFIED"
        assert result.convergence == pytest.approx(1.0)
        assert result.dissent == []


# ---------------------------------------------------------------------------
# verify_claim (integration, mocked litellm)
# ---------------------------------------------------------------------------

MOCK_MODELS = ["mock/model-a", "mock/model-b", "mock/model-c"]


class TestVerifyClaim:
    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_all_true(self, mock_completion):
        mock_completion.return_value = _json_response("VERIFIED", 0.9, "Clearly true.")
        result = verify_claim("Water is H2O.", MOCK_MODELS, mode="adversarial")
        assert result.verdict == "VERIFIED"
        assert result.convergence == pytest.approx(1.0)
        assert mock_completion.call_count == 3

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_majority_false(self, mock_completion):
        responses = [
            _json_response("UNVERIFIED", 0.85, "Wrong."),
            _json_response("UNVERIFIED", 0.80, "Incorrect."),
            _json_response("VERIFIED", 0.55, "Seems right."),
        ]
        mock_completion.side_effect = responses
        result = verify_claim("2+2=5", MOCK_MODELS, mode="resistant")
        assert result.verdict == "UNVERIFIED"
        assert len(result.dissent) == 1

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_model_error_becomes_uncertain(self, mock_completion):
        mock_completion.side_effect = RuntimeError("API timeout")
        result = verify_claim("Some claim.", ["mock/bad-model"], mode="calibrative")
        assert result.verdict == "UNCERTAIN"
        assert result.model_verdicts[0].confidence == pytest.approx(0.1)

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_markdown_fenced_response_parsed(self, mock_completion):
        fenced = "```json\n{\"verdict\": \"TRUE\", \"confidence\": 0.88, \"reasoning\": \"yes\"}\n```"
        mock_completion.return_value = _make_response(fenced)
        result = verify_claim("claim", ["mock/m"], mode="adversarial")
        assert result.verdict == "VERIFIED"
        assert result.confidence == pytest.approx(0.88)

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_domain_passed_through(self, mock_completion):
        mock_completion.return_value = _json_response("VERIFIED", 0.9, "ok")
        verify_claim("Earth orbits the Sun.", ["mock/m"], mode="calibrative", domain="astronomy")
        call_args = mock_completion.call_args
        user_msg = next(m["content"] for m in call_args.kwargs["messages"] if m["role"] == "user")
        assert "astronomy" in user_msg

    def test_empty_models_raises(self):
        with pytest.raises(ValueError, match="At least one model"):
            verify_claim("claim", [], mode="adversarial")

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError, match="Unknown mode"):
            verify_claim("claim", ["mock/m"], mode="bogus")

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_two_models(self, mock_completion):
        mock_completion.side_effect = [
            _json_response("VERIFIED", 0.8, "a"),
            _json_response("UNVERIFIED", 0.7, "b"),
        ]
        result = verify_claim("claim", ["mock/a", "mock/b"], mode="adversarial")
        # 1 of 2 agree with majority — convergence 0.5
        assert result.convergence == pytest.approx(0.5)
        assert len(result.dissent) == 1

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_result_contains_all_model_verdicts(self, mock_completion):
        mock_completion.side_effect = [
            _json_response("VERIFIED", 0.9, "r1"),
            _json_response("VERIFIED", 0.8, "r2"),
        ]
        result = verify_claim("claim", ["mock/a", "mock/b"], mode="calibrative")
        assert len(result.model_verdicts) == 2
        assert {v.model for v in result.model_verdicts} == {"mock/a", "mock/b"}
