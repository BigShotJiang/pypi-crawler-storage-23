"""Tests for ThoughtProofVerifyTool — crewai is mocked out."""
from __future__ import annotations

import json
import sys
from types import ModuleType
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Stub crewai so we can import tool.py without installing crewai
# ---------------------------------------------------------------------------

def _stub_crewai():
    """Insert a minimal crewai stub into sys.modules."""
    if "crewai" in sys.modules:
        return  # already present (real or stubbed)

    crewai_mod = ModuleType("crewai")
    tools_mod = ModuleType("crewai.tools")

    from pydantic import BaseModel

    class BaseTool(BaseModel):
        name: str = ""
        description: str = ""

        def _run(self, *args, **kwargs):  # pragma: no cover
            raise NotImplementedError

        def run(self, *args, **kwargs):
            return self._run(*args, **kwargs)

    tools_mod.BaseTool = BaseTool  # type: ignore[attr-defined]
    crewai_mod.tools = tools_mod  # type: ignore[attr-defined]
    sys.modules["crewai"] = crewai_mod
    sys.modules["crewai.tools"] = tools_mod


_stub_crewai()

from pot_sdk_crewai.tool import ThoughtProofVerifyTool  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_response(verdict: str, confidence: float, reasoning: str) -> MagicMock:
    payload = json.dumps({"verdict": verdict, "confidence": confidence, "reasoning": reasoning})
    msg = MagicMock()
    msg.content = payload
    choice = MagicMock()
    choice.message = msg
    resp = MagicMock()
    resp.choices = [choice]
    return resp


MODELS = ["mock/model-a", "mock/model-b"]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestThoughtProofVerifyTool:
    def _tool(self, **kwargs) -> ThoughtProofVerifyTool:
        defaults = dict(models=MODELS, mode="adversarial", threshold=0.7)
        defaults.update(kwargs)
        return ThoughtProofVerifyTool(**defaults)

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_run_returns_string(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.9, "yes")
        tool = self._tool()
        result = tool._run("Water is wet.")
        assert isinstance(result, str)
        assert "Verdict: VERIFIED" in result
        assert "Confidence:" in result
        assert "Convergence:" in result

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_low_confidence_flag(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.5, "uncertain")
        tool = self._tool(threshold=0.7)
        result = tool._run("A claim.")
        assert "[LOW CONFIDENCE]" in result

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_no_low_confidence_flag_when_above_threshold(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.9, "solid")
        tool = self._tool(threshold=0.7)
        result = tool._run("A claim.")
        assert "[LOW CONFIDENCE]" not in result

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_dissent_shown_in_output(self, mock_completion):
        mock_completion.side_effect = [
            _make_response("VERIFIED", 0.9, "yes"),
            _make_response("UNVERIFIED", 0.8, "no"),
        ]
        tool = self._tool()
        result = tool._run("Contested claim.")
        assert "Dissent" in result

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_verify_returns_result_object(self, mock_completion):
        from pot_sdk_crewai.types import VerificationResult
        mock_completion.return_value = _make_response("VERIFIED", 0.95, "obvious")
        tool = self._tool()
        result = tool.verify("The sky is blue.")
        assert isinstance(result, VerificationResult)
        assert result.verdict == "VERIFIED"

    @patch("pot_sdk_crewai.verify.litellm.completion")
    def test_mode_forwarded(self, mock_completion):
        mock_completion.return_value = _make_response("VERIFIED", 0.9, "ok")
        tool = self._tool(mode="resistant")
        tool._run("A claim.")
        call_args = mock_completion.call_args
        sys_msg = next(m["content"] for m in call_args.kwargs["messages"] if m["role"] == "system")
        assert "resistant" in sys_msg.lower() or "evidence" in sys_msg.lower()

    def test_default_name_and_description(self):
        tool = self._tool()
        assert tool.name == "Verify Claim"
        assert "verify" in tool.description.lower()
