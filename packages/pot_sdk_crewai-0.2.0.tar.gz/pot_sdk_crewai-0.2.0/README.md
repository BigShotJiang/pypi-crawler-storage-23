# pot-sdk-crewai

ThoughtProof Protocol — CrewAI integration for multi-model adversarial claim verification.

## Install

```bash
pip install pot-sdk-crewai                  # core only (no crewai)
pip install "pot-sdk-crewai[crewai]"        # with crewai
```

## Quick start

### Core function (no crewai required)

```python
from pot_sdk_crewai import verify_claim

result = verify_claim(
    claim="The Earth is approximately 4.5 billion years old.",
    models=["openai/gpt-4o", "anthropic/claude-sonnet-4-5", "deepseek/deepseek-chat"],
    mode="adversarial",
)

print(result.verdict)      # "TRUE"
print(result.confidence)   # 0.91
print(result.convergence)  # 1.0
print(result.dissent)      # [] — all models agreed
```

### Verification modes

| Mode | Posture |
|------|---------|
| `adversarial` | Actively challenges the claim, assumes false until proven |
| `resistant` | Requires strong evidence, resists plausible-sounding narratives |
| `calibrative` | Balanced probability assessment, calibrated confidence |

### ThoughtProofVerifyTool (CrewAI tool)

```python
from crewai import Agent
from pot_sdk_crewai import ThoughtProofVerifyTool

verify_tool = ThoughtProofVerifyTool(
    models=["openai/gpt-4o", "anthropic/claude-sonnet-4-5"],
    mode="adversarial",
    threshold=0.7,
)

analyst = Agent(
    role="Research Analyst",
    goal="Produce verified, accurate research reports.",
    tools=[verify_tool],
    llm="openai/gpt-4o",
)
```

The tool's `_run` output:
```
Verdict: TRUE | Confidence: 0.91 | Convergence: 1.00
```

With dissent:
```
Verdict: FALSE | Confidence: 0.85 | Convergence: 0.67 Dissent from: anthropic/claude-sonnet-4-5.
```

### ThoughtProofGuardrail (CrewAI task guardrail)

```python
from crewai import Agent, Task
from pot_sdk_crewai import ThoughtProofGuardrail

guardrail = ThoughtProofGuardrail(
    models=["openai/gpt-4o", "anthropic/claude-sonnet-4-5"],
    mode="calibrative",
    min_confidence=0.7,
    allow_uncertain=False,
)

task = Task(
    description="Summarise the key findings of the 2024 IPCC report.",
    agent=analyst,
    guardrail=guardrail.validate,   # CrewAI guardrail interface
)
```

`guardrail.validate(task_output)` returns:
- `(True, VerificationResult)` — accepted
- `(False, "Verification failed: ...")` — rejected with reason

## VerificationResult fields

| Field | Type | Description |
|-------|------|-------------|
| `verdict` | `"TRUE" \| "FALSE" \| "UNCERTAIN"` | Majority verdict |
| `confidence` | `float` | Mean confidence of majority models |
| `convergence` | `float` | Fraction of models that agreed with majority |
| `model_verdicts` | `list[ModelVerdict]` | Per-model breakdown |
| `dissent` | `list[ModelVerdict]` | Models that disagreed (DPR) |
| `reasoning` | `str` | Concatenated reasoning from all models |

## Dependencies

Runtime: `litellm>=1.0.0`, `pydantic>=2.0.0`
Optional: `crewai>=0.60.0` (for `ThoughtProofVerifyTool`)

## License

MIT
