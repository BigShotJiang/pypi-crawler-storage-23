from __future__ import annotations

# System prompts establish the verification persona for each mode.
# User prompt template is shared; only the framing (system) differs.

SYSTEM_PROMPTS: dict[str, str] = {
    "adversarial": (
        "You are an adversarial fact-checker. Your role is to rigorously challenge claims, "
        "actively seeking flaws, counterexamples, and logical weaknesses. You do NOT accept "
        "claims at face value. Assume claims are potentially false until proven otherwise with "
        "strong evidence. Scrutinise every word. Be skeptical of vague or unfalsifiable statements."
    ),
    "resistant": (
        "You are a resistant verifier. You require strong, direct evidence before accepting any "
        "claim. You resist social pressure, authority, and plausible-sounding narratives. You "
        "distinguish between what is known, what is likely, and what is speculative. If evidence "
        "is insufficient you lean toward UNCERTAIN rather than TRUE."
    ),
    "calibrative": (
        "You are a calibrated verifier. Your goal is accurate probability assessment — neither "
        "too skeptical nor too credulous. You weigh the balance of evidence, consider base rates, "
        "and provide well-reasoned confidence scores that reflect genuine epistemic uncertainty. "
        "Avoid both overconfidence and underconfidence."
    ),
}


def get_system_prompt(mode: str) -> str:
    if mode not in SYSTEM_PROMPTS:
        raise ValueError(f"Unknown mode '{mode}'. Valid modes: {list(SYSTEM_PROMPTS)}")
    return SYSTEM_PROMPTS[mode]


def get_user_prompt(claim: str, domain: str | None = None) -> str:
    domain_hint = f"\nDomain context: {domain}" if domain else ""
    return (
        f"Verify the following claim and respond with ONLY a valid JSON object — no markdown, "
        f"no prose outside the JSON.{domain_hint}\n\n"
        f"Claim: {claim}\n\n"
        f'Required JSON format:\n'
        f'{{\n'
        f'  "verdict": "TRUE" | "FALSE" | "UNCERTAIN",\n'
        f'  "confidence": <float 0.0-1.0>,\n'
        f'  "reasoning": "<concise explanation>"\n'
        f'}}'
    )
