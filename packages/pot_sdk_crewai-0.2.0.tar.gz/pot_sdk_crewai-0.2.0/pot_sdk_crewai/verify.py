from __future__ import annotations

import json
import logging
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import litellm

from .prompts import get_system_prompt, get_user_prompt
from .types import ModelVerdict, VerificationResult

logger = logging.getLogger(__name__)

# Model-native verdict values → ThoughtProof Protocol mapping
_VERDICT_MAP: dict[str, str] = {
    "TRUE":      "VERIFIED",
    "VERIFIED":  "VERIFIED",
    "FALSE":     "UNVERIFIED",
    "UNVERIFIED": "UNVERIFIED",
    "UNCERTAIN": "UNCERTAIN",
    "DISSENT":   "DISSENT",
}
_VERDICT_VALUES = set(_VERDICT_MAP.values())

# Soft cap: prevents token overflow + runaway costs on large TaskOutput blobs
_CLAIM_MAX_CHARS = 4_000


def _call_model(
    model: str,
    system: str,
    user: str,
    timeout: float,
) -> dict[str, Any]:
    response = litellm.completion(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        timeout=timeout,
        temperature=0.0,
    )
    return response  # type: ignore[return-value]


def _extract_json(text: str) -> dict[str, Any]:
    """Extract the first JSON object found in text (handles markdown fences)."""
    # Strip markdown code fences if present
    text = re.sub(r"```(?:json)?\s*", "", text).strip()
    # Find the first { ... } block
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        raise ValueError(f"No JSON object found in model response: {text!r}")
    return json.loads(match.group())


def _parse_verdict(raw: dict[str, Any], model: str) -> ModelVerdict:
    raw_verdict = str(raw.get("verdict", "UNCERTAIN")).upper()
    verdict = _VERDICT_MAP.get(raw_verdict, "UNCERTAIN")
    confidence = float(raw.get("confidence", 0.5))
    confidence = max(0.0, min(1.0, confidence))
    reasoning = str(raw.get("reasoning", ""))
    return ModelVerdict(model=model, verdict=verdict, confidence=confidence, reasoning=reasoning)  # type: ignore[arg-type]


def _synthesize(
    claim: str,
    mode: str,
    verdicts: list[ModelVerdict],
) -> VerificationResult:
    counts: Counter[str] = Counter(v.verdict for v in verdicts)
    majority_verdict, majority_count = counts.most_common(1)[0]

    convergence = majority_count / len(verdicts)

    # DISSENT: no clear majority with 3+ models (every model disagrees) — escalate
    if len(verdicts) >= 3 and convergence <= 1 / len(verdicts):
        majority_verdict = "DISSENT"
        majority_models = verdicts   # all models counted, none are "dissent" from DISSENT
        dissent_models  = []
    else:
        majority_models = [v for v in verdicts if v.verdict == majority_verdict]
        dissent_models  = [v for v in verdicts if v.verdict != majority_verdict]

    mean_confidence = sum(v.confidence for v in majority_models) / len(majority_models)

    reasoning_parts = [f"[{v.model}] {v.reasoning}" for v in verdicts]
    reasoning = " | ".join(reasoning_parts)

    return VerificationResult(
        claim=claim,
        verdict=majority_verdict,  # type: ignore[arg-type]
        confidence=round(mean_confidence, 4),
        convergence=round(convergence, 4),
        mode=mode,
        model_verdicts=verdicts,
        dissent=dissent_models,
        reasoning=reasoning,
    )


def _call_one(model: str, system: str, user: str, timeout: float) -> ModelVerdict:
    """Single-model call with full error handling — used by the parallel executor."""
    try:
        response = _call_model(model, system, user, timeout)
        content = response.choices[0].message.content or ""
        raw = _extract_json(content)
        return _parse_verdict(raw, model)
    except Exception as exc:
        logger.warning("Model %s failed: %s", model, exc)
        return ModelVerdict(
            model=model,
            verdict="UNCERTAIN",
            confidence=0.1,
            reasoning=f"Error during verification: {exc}",
        )


def verify_claim(
    claim: str,
    models: list[str],
    mode: str = "adversarial",
    domain: str | None = None,
    timeout: float = 30.0,
) -> VerificationResult:
    """Multi-model verification with dissent preservation (DPR).

    Sends *claim* to every model in *models* **in parallel** using a
    mode-specific system prompt, parses each verdict, then synthesises
    the results via majority vote.

    Args:
        claim:   The statement to verify. Truncated to 4 000 chars to prevent
                 token overflow when receiving large CrewAI TaskOutput blobs.
        models:  litellm model identifiers, e.g. ``["openai/gpt-4o", "anthropic/claude-sonnet-4-5"]``.
        mode:    Verification posture — ``"adversarial"``, ``"resistant"``, or ``"calibrative"``.
        domain:  Optional domain hint appended to the user prompt.
        timeout: Per-model call timeout in seconds (wall-clock, not total).

    Returns:
        :class:`VerificationResult` with majority verdict, mean confidence of majority,
        convergence ratio, and full per-model breakdown including dissenters.
    """
    if not models:
        raise ValueError("At least one model must be supplied.")

    # Fix 2: Soft cap — warn and truncate if claim is suspiciously long
    if len(claim) > _CLAIM_MAX_CHARS:
        logger.warning(
            "claim truncated from %d to %d chars to prevent token overflow",
            len(claim),
            _CLAIM_MAX_CHARS,
        )
        claim = claim[:_CLAIM_MAX_CHARS]

    system_prompt = get_system_prompt(mode)
    user_prompt = get_user_prompt(claim, domain)

    # Fix 3: Parallel model calls via ThreadPoolExecutor
    verdicts: list[ModelVerdict] = []
    with ThreadPoolExecutor(max_workers=len(models)) as pool:
        futures = {
            pool.submit(_call_one, model, system_prompt, user_prompt, timeout): model
            for model in models
        }
        # Preserve original model order in results
        results: dict[str, ModelVerdict] = {}
        for future in as_completed(futures):
            model = futures[future]
            results[model] = future.result()

    for model in models:
        verdicts.append(results[model])

    return _synthesize(claim, mode, verdicts)
