from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, Type

from pydantic import BaseModel, ConfigDict, Field

from .types import VerificationResult
from .verify import verify_claim as _verify_claim

try:
    from crewai.tools import BaseTool  # type: ignore[import-untyped]
    _CREWAI_AVAILABLE = True
except ImportError:
    _CREWAI_AVAILABLE = False

    class BaseTool(BaseModel):  # type: ignore[no-redef]
        """Minimal BaseTool shim used when crewai is not installed."""

        name: str = ""
        description: str = ""

        def _run(self, *args: Any, **kwargs: Any) -> str:  # pragma: no cover
            raise NotImplementedError

        def run(self, *args: Any, **kwargs: Any) -> str:
            return self._run(*args, **kwargs)


class _VerifyInput(BaseModel):
    claim: str = Field(description="The statement or claim to verify.")


class ThoughtProofVerifyTool(BaseTool):  # type: ignore[misc]
    """CrewAI BaseTool that verifies claims via multi-model adversarial consensus.

    Usage::

        tool = ThoughtProofVerifyTool(
            models=["openai/gpt-4o", "anthropic/claude-sonnet-4-5"],
            mode="adversarial",
            threshold=0.7,
        )
        agent = Agent(role="Researcher", tools=[tool], ...)
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    name: str = "Verify Claim"
    description: str = (
        "Verify a claim using multi-model adversarial verification. "
        "Use this tool when you need to fact-check a statement, validate reasoning, "
        "or confirm the accuracy of information before including it in a report."
    )
    args_schema: ClassVar[Type[BaseModel]] = _VerifyInput

    models: list[str] = Field(
        default_factory=lambda: ["openai/gpt-4o"],
        description="litellm model identifiers to use for verification.",
    )
    mode: str = Field(
        default="adversarial",
        description="Verification mode: 'adversarial', 'resistant', or 'calibrative'.",
    )
    threshold: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Minimum confidence threshold for a definitive verdict.",
    )
    domain: str | None = Field(default=None, description="Optional domain context hint.")
    timeout: float = Field(default=30.0, description="Per-model call timeout in seconds.")

    def _run(self, claim: str) -> str:  # type: ignore[override]
        result: VerificationResult = _verify_claim(
            claim=claim,
            models=self.models,
            mode=self.mode,
            domain=self.domain,
            timeout=self.timeout,
        )
        confidence_flag = "" if result.confidence >= self.threshold else " [LOW CONFIDENCE]"
        dissent_note = (
            f" Dissent from: {', '.join(d.model for d in result.dissent)}."
            if result.dissent
            else ""
        )
        return (
            f"Verdict: {result.verdict}{confidence_flag} | "
            f"Confidence: {result.confidence:.2f} | "
            f"Convergence: {result.convergence:.2f}{dissent_note}"
        )

    def verify(self, claim: str) -> VerificationResult:
        """Return the full :class:`VerificationResult` (not just the string summary)."""
        return _verify_claim(
            claim=claim,
            models=self.models,
            mode=self.mode,
            domain=self.domain,
            timeout=self.timeout,
        )
