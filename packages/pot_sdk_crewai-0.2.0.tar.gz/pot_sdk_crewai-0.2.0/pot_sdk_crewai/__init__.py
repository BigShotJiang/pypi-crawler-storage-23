"""pot-sdk-crewai — ThoughtProof Protocol integration for CrewAI."""

from .guardrail import ThoughtProofGuardrail
from .types import ModelVerdict, VerificationResult
from .verify import verify_claim

__all__ = [
    "verify_claim",
    "VerificationResult",
    "ModelVerdict",
    "ThoughtProofGuardrail",
]

# ThoughtProofVerifyTool is only importable when crewai is installed.
try:
    from .tool import ThoughtProofVerifyTool

    __all__ += ["ThoughtProofVerifyTool"]
except ImportError:
    pass

__version__ = "0.1.0"
