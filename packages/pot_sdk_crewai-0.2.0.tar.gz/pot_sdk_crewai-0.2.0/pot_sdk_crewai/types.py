from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field

# Verdict vocabulary aligned with ThoughtProof Protocol (pot-sdk)
Verdict = Literal["VERIFIED", "UNVERIFIED", "UNCERTAIN", "DISSENT"]


class ModelVerdict(BaseModel):
    model: str
    verdict: Verdict
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str


class VerificationResult(BaseModel):
    claim: str
    verdict: Verdict
    confidence: float = Field(ge=0.0, le=1.0)
    convergence: float = Field(ge=0.0, le=1.0, description="Fraction of models that agreed with majority verdict")
    mode: str
    model_verdicts: list[ModelVerdict]
    dissent: list[ModelVerdict] = Field(default_factory=list, description="Models that disagreed with the majority (DPR)")
    reasoning: str
