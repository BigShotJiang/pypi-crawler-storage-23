from __future__ import annotations

from typing import Any

from pydantic import Field

from .types import VerificationResult
from .verify import verify_claim as _verify_claim


class ThoughtProofGuardrail:
    """Task guardrail that verifies agent output before CrewAI accepts it.

    Implements the CrewAI guardrail interface: the ``validate`` method returns
    ``(True, result)`` on success and ``(False, error_message)`` on failure.

    Usage::

        guardrail = ThoughtProofGuardrail(
            models=["openai/gpt-4o", "anthropic/claude-sonnet-4-5"],
            mode="calibrative",
            min_confidence=0.7,
        )

        task = Task(
            description="Analyse market trends",
            agent=analyst,
            guardrail=guardrail.validate,
        )
    """

    def __init__(
        self,
        models: list[str],
        mode: str = "calibrative",
        min_confidence: float = 0.7,
        allow_uncertain: bool = False,
        domain: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """
        Args:
            models:          litellm model identifiers.
            mode:            Verification posture (``"adversarial"``, ``"resistant"``,
                             ``"calibrative"``).
            min_confidence:  Minimum confidence required to accept output as TRUE.
            allow_uncertain: If ``True``, UNCERTAIN verdicts with sufficient confidence
                             are also accepted.
            domain:          Optional domain hint forwarded to the verifier.
            timeout:         Per-model call timeout in seconds.
        """
        if not models:
            raise ValueError("At least one model must be provided.")
        self.models = models
        self.mode = mode
        self.min_confidence = min_confidence
        self.allow_uncertain = allow_uncertain
        self.domain = domain
        self.timeout = timeout

    def validate(self, task_output: Any) -> tuple[bool, Any]:
        """Validate *task_output* against the ThoughtProof protocol.

        Args:
            task_output: A CrewAI ``TaskOutput`` object or any object whose
                         string representation is the claim to verify.

        Returns:
            ``(True, verification_result)`` if accepted.
            ``(False, error_message_str)`` if rejected.
        """
        claim = self._extract_claim(task_output)
        result: VerificationResult = _verify_claim(
            claim=claim,
            models=self.models,
            mode=self.mode,
            domain=self.domain,
            timeout=self.timeout,
        )
        return self._evaluate(result)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _extract_claim(self, task_output: Any) -> str:
        """Extract a string claim from a CrewAI TaskOutput or any object."""
        # CrewAI TaskOutput exposes `.raw` (str) — use getattr for version safety
        raw = getattr(task_output, "raw", None)
        if raw is not None:
            return str(raw)
        return str(task_output)

    def _evaluate(self, result: VerificationResult) -> tuple[bool, Any]:
        accepted_verdicts = {"VERIFIED"}
        if self.allow_uncertain:
            accepted_verdicts.add("UNCERTAIN")

        if result.verdict not in accepted_verdicts:
            return (
                False,
                (
                    f"Verification failed: verdict={result.verdict}, "
                    f"confidence={result.confidence:.2f}, "
                    f"convergence={result.convergence:.2f}. "
                    f"Reasoning: {result.reasoning}"
                ),
            )

        if result.confidence < self.min_confidence:
            return (
                False,
                (
                    f"Verification failed: confidence {result.confidence:.2f} below "
                    f"threshold {self.min_confidence:.2f} "
                    f"(verdict={result.verdict}, convergence={result.convergence:.2f})."
                ),
            )

        return (True, result)
