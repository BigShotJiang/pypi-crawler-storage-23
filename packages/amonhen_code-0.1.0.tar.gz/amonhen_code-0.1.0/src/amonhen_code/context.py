# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""Fetch and format project context from Amon Hen for system prompt injection."""

from __future__ import annotations

from mcp_amonhen.client import AmonHenClient


async def fetch_project_context(project_id: str, intent: str | None = None) -> dict:
    """Fetch raw assembled context items via GET /v1/projects/{id}/context."""
    client = AmonHenClient()
    return await client.get_context(project_id, intent=intent)


def format_context_for_prompt(context_result: dict) -> str:
    """Format assembled context items as a structured text block for system prompt injection.

    Groups items by type in priority order: rules -> decisions -> code_context -> notes.
    """
    items = context_result.get("context", [])
    if not items:
        return "(No project context items found.)"

    buckets: dict[str, list[str]] = {
        "rule": [],
        "decision": [],
        "code_context": [],
        "note": [],
    }

    for item in items:
        item_type = item.get("item_type", "note")
        content = item.get("content", "")
        if item_type in buckets:
            buckets[item_type].append(content)

    sections = []

    if buckets["rule"]:
        sections.append("## RULES (absolute law — must be followed)")
        for i, r in enumerate(buckets["rule"], 1):
            sections.append(f"{i}. {r}")
        sections.append("")

    if buckets["decision"]:
        sections.append("## DECISIONS (committed team choices — apply, do not revisit)")
        for i, d in enumerate(buckets["decision"], 1):
            sections.append(f"{i}. {d}")
        sections.append("")

    if buckets["code_context"]:
        sections.append("## CODE CONTEXT (implementation patterns)")
        for i, c in enumerate(buckets["code_context"], 1):
            sections.append(f"{i}. {c}")
        sections.append("")

    if buckets["note"]:
        sections.append("## NOTES (observations and context)")
        for i, n in enumerate(buckets["note"], 1):
            sections.append(f"{i}. {n}")
        sections.append("")

    return "\n".join(sections)
