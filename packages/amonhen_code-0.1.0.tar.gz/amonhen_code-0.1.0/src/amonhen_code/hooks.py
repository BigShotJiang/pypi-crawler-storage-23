# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""Agent SDK hooks for Amon Hen Code."""

from __future__ import annotations

from typing import Any


# Accumulate file changes during a session for summary.
_session_changes: list[dict[str, Any]] = []


async def enforce_rules_on_write(
    input_data: dict[str, Any],
    tool_use_id: str | None,
    context: dict[str, Any],
) -> dict[str, Any]:
    """PreToolUse hook: remind the agent to check rules before file writes."""
    tool_name = input_data.get("tool_name", "")
    if tool_name in ("Write", "Edit"):
        return {
            "systemMessage": (
                "REMINDER: Before completing this file write, verify that the "
                "content complies with all project RULES from the Amon Hen "
                "context. If any rule is violated, modify the content to comply "
                "before proceeding."
            )
        }
    return {}


async def track_file_changes(
    input_data: dict[str, Any],
    tool_use_id: str | None,
    context: dict[str, Any],
) -> dict[str, Any]:
    """PostToolUse hook: track file modifications for session summary."""
    tool_name = input_data.get("tool_name", "")
    if tool_name in ("Write", "Edit"):
        file_path = input_data.get("tool_input", {}).get("file_path", "unknown")
        _session_changes.append(
            {
                "tool": tool_name,
                "file_path": file_path,
            }
        )
    return {}


def get_session_changes() -> list[dict[str, Any]]:
    """Return the accumulated file changes for this session."""
    return list(_session_changes)


def clear_session_changes() -> None:
    """Reset the session change tracker."""
    _session_changes.clear()
