# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

