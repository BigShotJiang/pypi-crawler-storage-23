# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""Grounded Code Agent -- modify code while enforcing Amon Hen project rules."""

from __future__ import annotations

from pathlib import Path

from claude_agent_sdk import (
    AssistantMessage,
    HookMatcher,
    ClaudeAgentOptions,
    ResultMessage,
    TextBlock,
    query,
)
from rich.console import Console

from amonhen_code.context import fetch_project_context, format_context_for_prompt
from amonhen_code.hooks import enforce_rules_on_write, track_file_changes
from amonhen_code.prompts import GROUNDED_CODE
from amonhen_code.tools import build_amonhen_server

console = Console()


async def run_grounded_agent(
    *,
    project_id: str,
    cwd: str = ".",
    max_turns: int | None = None,
    task: str | None = None,
) -> None:
    """Launch the Grounded Code Agent."""

    # 1. Fetch project context from Amon Hen (no LLM call).
    console.print("[dim]Fetching project context from Amon Hen...[/dim]")
    context_result = await fetch_project_context(project_id)
    context_block = format_context_for_prompt(context_result)

    item_count = len(context_result.get("context", []))
    console.print(f"[dim]Loaded {item_count} context items.[/dim]")

    # 2. Build system prompt with injected context.
    system_prompt = GROUNDED_CODE.format(context_block=context_block)

    # 3. Build in-process MCP server for Amon Hen tools.
    amonhen_server = build_amonhen_server()

    # 4. Configure the agent.
    prompt = task or (
        "What would you like me to work on? "
        "I will follow the project rules and decisions."
    )

    options = ClaudeAgentOptions(
        system_prompt=system_prompt,
        cwd=str(Path(cwd).resolve()),
        permission_mode="acceptEdits",
        max_turns=max_turns,
        mcp_servers={"amonhen": amonhen_server},
        allowed_tools=[
            "Read",
            "Write",
            "Edit",
            "Bash",
            "Glob",
            "Grep",
            "mcp__amonhen__ask_amon_hen",
            "mcp__amonhen__propose_context_item",
        ],
        hooks={
            "PreToolUse": [
                HookMatcher(
                    matcher="Write|Edit",
                    hooks=[enforce_rules_on_write],
                ),
            ],
            "PostToolUse": [
                HookMatcher(
                    matcher="Write|Edit",
                    hooks=[track_file_changes],
                ),
            ],
        },
    )

    # 5. Run the agent.

    async for message in query(prompt=prompt, options=options):
        if isinstance(message, ResultMessage):
            console.print(f"\n{message.result}")
        elif isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    console.print(block.text)
