# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""CLI entry point for Amon Hen Code."""

import asyncio

import click
from rich.console import Console
from rich.text import Text

console = Console()

_MOUNTAIN_ART = (
    "     /\\\n"
    "    /  \\     /\\\n"
    "   /    \\   /  \\\n"
    "  /      \\_/    \\\n"
    " /________________\\"
)


def _print_banner() -> None:
    console.print(Text(_MOUNTAIN_ART, style="#5E81F4"))
    console.print("[bold]  Amon Hen Code[/bold] [dim]v0.1.0[/dim]")
    console.print("[dim]  Clarity for Complex Projects.[/dim]\n")


@click.group()
@click.version_option(version="0.1.0")
def main():
    """Amon Hen Code -- AI agent grounded in team knowledge."""


@main.command()
def login():
    """Authenticate with Amon Hen (Auth0 device flow)."""
    from mcp_amonhen.auth import login_interactive

    login_interactive()


@main.command()
def logout():
    """Clear stored authentication tokens."""
    from mcp_amonhen.auth import logout

    logout()
    console.print("[green]Logged out.[/green]")


@main.command()
def projects():
    """List your Amon Hen projects."""
    from mcp_amonhen.client import AmonHenClient

    async def _list():
        client = AmonHenClient()
        projs = await client.list_projects()
        if not projs:
            console.print("[dim]No projects found.[/dim]")
            return
        for p in projs:
            name = p.get("name", "?")
            pid = p.get("id", "?")
            count = p.get("context_count", 0)
            console.print(f"  {name}  [dim]{pid}[/dim]  ({count} items)")

    asyncio.run(_list())


@main.command()
@click.option("--project", "-p", required=True, help="Amon Hen project UUID")
@click.option("--cwd", "-d", default=".", help="Working directory for the agent")
@click.option("--max-turns", "-t", default=None, type=int, help="Maximum agent turns")
@click.option("--task", "-m", default=None, help="Task description for the agent")
def code(project, cwd, max_turns, task):
    """Grounded Code Agent -- modify code while enforcing project rules."""
    from amonhen_code.agents.grounded import run_grounded_agent

    _print_banner()
    asyncio.run(
        run_grounded_agent(
            project_id=project,
            cwd=cwd,
            max_turns=max_turns,
            task=task,
        )
    )
