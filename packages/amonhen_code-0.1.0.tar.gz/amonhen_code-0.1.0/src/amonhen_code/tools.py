# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""In-process SDK MCP tools for Amon Hen operations."""

from __future__ import annotations

from typing import Any

from claude_agent_sdk import tool, create_sdk_mcp_server
from mcp_amonhen.client import AmonHenClient

_client = AmonHenClient()


@tool(
    "ask_amon_hen",
    "Ask Amon Hen for project-scoped advisory on a technical question. "
    "Use this when you need guidance grounded in the team's rules and decisions.",
    {"project_id": str, "question": str},
)
async def ask_amon_hen(args: dict[str, Any]) -> dict[str, Any]:
    """Get advisory from Amon Hen, grounded in project context."""
    result = await _client.advise(args["question"], args["project_id"])
    advice = result.get("advice", "No advice returned.")
    hints = result.get("follow_up_hints", [])
    text = advice
    if hints:
        text += "\n\nFollow-up questions you might consider:\n"
        text += "\n".join(f"- {h}" for h in hints)
    return {"content": [{"type": "text", "text": text}]}


@tool(
    "propose_context_item",
    "Propose a new rule, decision, note, or code_context item to the Amon Hen project. "
    "Use this to capture knowledge discovered while working on the codebase.",
    {
        "project_id": str,
        "item_type": str,
        "content": str,
        "rationale": str,
    },
)
async def propose_context_item(args: dict[str, Any]) -> dict[str, Any]:
    """Create a new context item in Amon Hen."""
    result = await _client.create_context(
        project_id=args["project_id"],
        item_type=args["item_type"],
        content=args["content"],
        rationale=args.get("rationale"),
    )
    item_id = result.get("id", "unknown")
    return {
        "content": [
            {
                "type": "text",
                "text": f"Created {args['item_type']} item (id: {item_id}).",
            }
        ]
    }


def build_amonhen_server():
    """Create the in-process MCP server with Amon Hen tools."""
    return create_sdk_mcp_server(
        name="amonhen",
        tools=[ask_amon_hen, propose_context_item],
    )
