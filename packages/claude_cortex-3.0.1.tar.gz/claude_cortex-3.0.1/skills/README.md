# Skills Documentation Moved

To cut down auto-loaded context, the full README was moved to `docs/reference/moved-readmes/skills.md`.
