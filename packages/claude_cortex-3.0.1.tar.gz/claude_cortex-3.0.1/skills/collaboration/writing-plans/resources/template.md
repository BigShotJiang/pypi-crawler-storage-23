# `/ctx:plan` Template Snippet

```
## Objective
<one paragraph>

## Stream: <name>
- Task: … (agent/mode)
- Verification: … (tests, lint, visual)

## Risks
- …
```
