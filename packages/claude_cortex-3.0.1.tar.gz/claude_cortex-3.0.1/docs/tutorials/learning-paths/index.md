---
layout: default
title: Learning Paths
parent: Tutorials
nav_order: 10
has_children: true
permalink: /tutorials/learning-paths/
---

# Learning Paths

Structured paths that guide you from one stage to the next. Each path links to existing tutorials and guides rather than duplicating them.

## Available Paths

<div class="doc-grid">
  <a href="onboarding/" class="doc-card">
    <h3>Onboarding: Zero to Productive</h3>
    <p>Install cortex, learn the core loop (agents, skills, modes), run your first workflow, and pick your next direction.</p>
    <span class="doc-card__arrow">Start Path &rarr;</span>
    <div class="doc-card__meta">
      <span>~40 minutes</span>
      <span>5 stages</span>
      <span>Beginner</span>
    </div>
  </a>
</div>
