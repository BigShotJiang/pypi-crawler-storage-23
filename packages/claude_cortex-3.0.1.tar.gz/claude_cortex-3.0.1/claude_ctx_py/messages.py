"""Shared user-facing message constants."""

RESTART_REQUIRED_TITLE = "Restart Required"
RESTART_REQUIRED_MESSAGE = (
    "Restart required. Please restart Claude Code or the TUI for changes to take effect."
)
