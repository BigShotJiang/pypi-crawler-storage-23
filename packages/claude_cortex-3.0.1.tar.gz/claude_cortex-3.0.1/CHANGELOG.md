# Changelog

All notable changes to this project will be documented in this file automatically by python-semantic-release.

- Entries will be generated from Conventional Commit history the first time the release workflow runs.
