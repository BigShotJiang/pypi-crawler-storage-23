Shortcut: New Research Brief

Instructions:

Create a to-do list with the following items then perform all of them:

1. Review @docs/project/research/ to see the list of recent research briefs.

2. Copy @docs/project/research/template-research-brief.md to
   @docs/project/research/current/research-description.md (filling in an appropriate
   description of the research topic)

3. Begin to fill in the new research brief based on the user’s instructions, stopping
   and asking for clarifications as soon as you need them.
