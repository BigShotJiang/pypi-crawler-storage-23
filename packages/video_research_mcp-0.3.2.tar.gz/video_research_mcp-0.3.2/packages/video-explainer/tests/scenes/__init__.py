"""Tests for scenes module."""
