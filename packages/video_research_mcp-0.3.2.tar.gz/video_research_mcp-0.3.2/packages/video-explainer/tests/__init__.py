"""Tests for video explainer."""
