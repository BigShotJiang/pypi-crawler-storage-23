"""Tests for asap-compliance package."""
