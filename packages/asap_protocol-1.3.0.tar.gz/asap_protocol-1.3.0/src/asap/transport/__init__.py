"""ASAP Protocol HTTP Transport Layer.

This module provides HTTP-based transport for ASAP messages using:
- JSON-RPC 2.0 for request/response wrapping
- FastAPI for server implementation
- httpx for async client implementation
- Handler registry for payload dispatch

Public exports:
    JsonRpcRequest: JSON-RPC 2.0 request wrapper
    JsonRpcResponse: JSON-RPC 2.0 response wrapper
    JsonRpcError: JSON-RPC 2.0 error object
    JsonRpcErrorResponse: JSON-RPC 2.0 error response wrapper
    create_app: FastAPI application factory
    HandlerRegistry: Registry for payload handlers
    HandlerNotFoundError: Error for missing handlers
    Handler: Type alias for handler functions
    create_echo_handler: Factory for echo handler
    create_default_registry: Factory for default registry
    ASAPClient: Async HTTP client for agent communication
    RetryConfig: Configuration dataclass for retry logic and circuit breaker
    ASAPConnectionError: Connection error exception
    ASAPTimeoutError: Timeout error exception
    ASAPRemoteError: Remote error exception

Example:
    >>> from asap.transport import ASAPClient, create_app
    >>> from asap.models.entities import Manifest, Capability, Endpoint, Skill
    >>> manifest = Manifest(
    ...     id="urn:asap:agent:demo",
    ...     name="Demo Agent",
    ...     version="1.0.0",
    ...     description="Demo manifest",
    ...     capabilities=Capability(
    ...         asap_version="0.1",
    ...         skills=[Skill(id="echo", description="Echo")],
    ...         state_persistence=False,
    ...     ),
    ...     endpoints=Endpoint(asap="http://localhost:8000/asap"),
    ... )
    >>> app = create_app(manifest)
"""

from asap.transport.cache import (
    DEFAULT_MAX_SIZE,
    DEFAULT_TTL,
    ManifestCache,
)
from asap.transport.client import (
    ASAPClient,
    ASAPConnectionError,
    ASAPRemoteError,
    ASAPTimeoutError,
    RetryConfig,
)
from asap.transport.compression import (
    COMPRESSION_THRESHOLD,
    CompressionAlgorithm,
    compress_payload,
    decompress_payload,
    get_accept_encoding_header,
    get_supported_encodings,
    is_brotli_available,
    select_best_encoding,
)
from asap.transport.handlers import (
    Handler,
    HandlerNotFoundError,
    HandlerRegistry,
    create_default_registry,
    create_echo_handler,
)
from asap.transport.mtls import MTLSConfig, create_ssl_context, mtls_config_to_uvicorn_kwargs
from asap.transport.jsonrpc import (
    JsonRpcError,
    JsonRpcErrorResponse,
    JsonRpcRequest,
    JsonRpcResponse,
)
from asap.transport.server import ASAPRequestHandler, create_app
from asap.transport.webhook import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_BASE_DELAY,
    DEFAULT_RETRY_MAX_DELAY,
    DEFAULT_WEBHOOK_RATE_PER_SECOND,
    DEFAULT_WEBHOOK_TIMEOUT,
    X_ASAP_SIGNATURE_HEADER,
    DeadLetterEntry,
    RetryPolicy,
    WebhookDelivery,
    WebhookResult,
    WebhookRetryManager,
    compute_signature,
    validate_callback_url,
    verify_signature,
)

__all__ = [
    # JSON-RPC
    "JsonRpcRequest",
    "JsonRpcResponse",
    "JsonRpcError",
    "JsonRpcErrorResponse",
    # mTLS
    "MTLSConfig",
    "create_ssl_context",
    "mtls_config_to_uvicorn_kwargs",
    # Server
    "create_app",
    "ASAPRequestHandler",
    # Handlers
    "HandlerRegistry",
    "HandlerNotFoundError",
    "Handler",
    "create_echo_handler",
    "create_default_registry",
    # Client
    "ASAPClient",
    "ASAPConnectionError",
    "ASAPTimeoutError",
    "ASAPRemoteError",
    "RetryConfig",
    # Cache
    "ManifestCache",
    "DEFAULT_TTL",
    "DEFAULT_MAX_SIZE",
    # Compression
    "COMPRESSION_THRESHOLD",
    "CompressionAlgorithm",
    "compress_payload",
    "decompress_payload",
    "get_accept_encoding_header",
    "get_supported_encodings",
    "is_brotli_available",
    "select_best_encoding",
    # Webhook
    "WebhookDelivery",
    "WebhookResult",
    "WebhookRetryManager",
    "RetryPolicy",
    "DeadLetterEntry",
    "X_ASAP_SIGNATURE_HEADER",
    "DEFAULT_WEBHOOK_TIMEOUT",
    "DEFAULT_MAX_RETRIES",
    "DEFAULT_RETRY_BASE_DELAY",
    "DEFAULT_RETRY_MAX_DELAY",
    "DEFAULT_WEBHOOK_RATE_PER_SECOND",
    "validate_callback_url",
    "compute_signature",
    "verify_signature",
]
