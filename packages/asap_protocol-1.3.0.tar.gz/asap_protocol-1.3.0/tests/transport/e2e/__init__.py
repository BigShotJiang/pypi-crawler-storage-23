"""End-to-end tests for full agent communication flows.

Tests in this directory verify complete request/response cycles,
multi-agent interactions, and real-world scenarios.
"""
