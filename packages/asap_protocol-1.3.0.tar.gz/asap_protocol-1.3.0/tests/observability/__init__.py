"""Tests for ASAP observability module."""
