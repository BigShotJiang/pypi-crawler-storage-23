"""Tests for ASAP crypto module (Ed25519 keys, signing)."""
