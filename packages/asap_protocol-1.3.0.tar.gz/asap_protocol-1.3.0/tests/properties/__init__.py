"""Property-based tests for ASAP protocol (Hypothesis)."""
