"""Compatibility tests for ASAP protocol upgrades."""
