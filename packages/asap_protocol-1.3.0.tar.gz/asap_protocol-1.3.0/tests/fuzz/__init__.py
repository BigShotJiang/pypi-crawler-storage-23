"""Fuzz tests for ASAP protocol (invalid input validation)."""
