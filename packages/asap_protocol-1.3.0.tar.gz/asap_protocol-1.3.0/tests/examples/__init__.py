"""Tests for example agents."""
