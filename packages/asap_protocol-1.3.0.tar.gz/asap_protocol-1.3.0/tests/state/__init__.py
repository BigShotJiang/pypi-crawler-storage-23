"""Tests for ASAP state management."""
