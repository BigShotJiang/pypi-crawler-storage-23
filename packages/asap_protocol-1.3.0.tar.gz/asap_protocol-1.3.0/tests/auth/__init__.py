"""Tests for ASAP auth module."""
