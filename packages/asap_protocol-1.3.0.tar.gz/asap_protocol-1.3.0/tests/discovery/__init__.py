"""Tests for ASAP discovery module (well-known, manifest, caching)."""
