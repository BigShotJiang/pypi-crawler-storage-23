"""
OmniAnti — Windows 11 Edition
Advanced Real System Scanner
"""
__version__ = "2.0.0"
