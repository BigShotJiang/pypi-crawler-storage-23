# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "channel3_sdk"
__version__ = "2.13.0"  # x-release-please-version
