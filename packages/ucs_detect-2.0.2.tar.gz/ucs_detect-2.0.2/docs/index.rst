Welcome to ucs-detect's documentation!
======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   :glob:

   intro
   results

* :ref:`search`
