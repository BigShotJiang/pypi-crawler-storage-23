ambiguous_width: -1
datetime: 2026-02-01 18:54:15 UTC
height: 24
python_version: 3.15.0a5
seconds_elapsed: 0.04763336399628315
session_arguments:
  limit_category_time: 900.0
  limit_codepoints: 0
  limit_errors: 0
  limit_graphemes: 0
  limit_graphemes_pct: 0
  stream: stderr
software_name: xterm.js
software_version: 5.5.0
system: Linux
terminal_results:
  device_attributes:
    extensions:
    - 2
    service_class: 1
  height: 24
  iterm2_features:
    features: {}
    supported: false
  kitty_clipboard_protocol: false
  kitty_graphics: false
  kitty_notifications: false
  kitty_pointer_shapes: false
  modes:
    1004:
      changeable: true
      enabled: false
      mode_description: Send FocusIn/FocusOut events
      mode_name: FOCUS_IN_OUT_EVENTS
      supported: true
      value: 2
      value_description: RESET
    1006:
      changeable: true
      enabled: false
      mode_description: Enable SGR Mouse Mode
      mode_name: MOUSE_EXTENDED_SGR
      supported: true
      value: 2
      value_description: RESET
    2004:
      changeable: true
      enabled: false
      mode_description: Set bracketed paste mode
      mode_name: BRACKETED_PASTE
      supported: true
      value: 2
      value_description: RESET
    2026:
      changeable: false
      enabled: false
      mode_description: Synchronized Output
      mode_name: SYNCHRONIZED_OUTPUT
      supported: false
      value: 0
      value_description: NOT_RECOGNIZED
    2027:
      changeable: false
      enabled: false
      mode_description: Grapheme Clustering
      mode_name: GRAPHEME_CLUSTERING
      supported: false
      value: 0
      value_description: NOT_RECOGNIZED
  number_of_colors: 16777216
  pixels_height: 0
  pixels_width: 0
  sixel: false
  software_name: xterm.js
  software_version: 5.5.0
  tab_stop_width: 8
  text_sizing:
    scale: false
    width: false
  ttype: xterm-256color
  width: 80
  xtgettcap:
    capabilities: {}
    supported: false
test_results:
  emoji_vs15_results: {}
  emoji_vs16_results: {}
  emoji_zwj_results: {}
  language_results: null
  unicode_wide_results: {}
wcwidth_version: 0.5.3
width: 80
