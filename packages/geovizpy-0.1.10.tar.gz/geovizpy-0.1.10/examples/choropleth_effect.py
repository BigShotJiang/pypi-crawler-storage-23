"""Example script demonstrating visual effects (shadow)."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

brazil = {
    "type": "FeatureCollection",
    "features": [f for f in world_data.get("features", []) if f["properties"].get("NAMEen") == "Brazil"]
}

viz = Geoviz(projection="EqualEarth")

viz.effect_shadow(id="myshadow", dx=10, dy=10, opacity=0.5)

viz.outline()
viz.graticule(stroke="white", step=30, strokeWidth=1.2)

viz.choro(
    data=world_data,
    var="gdppc",
    strokeWidth=0.3,
    tip=True,
    leg_type="horizontal",
    leg_title="GDP per capita",
    leg_subtitle="($ per inh.)",
    leg_note="Source: worldbank, 2020",
    leg_pos=[410, 370],
    leg_values_round=0,
    leg_missing_text="Missing values"
)

if brazil["features"]:
    viz.path(
        data=brazil,
        fill="none",
        stroke="red",
        strokeWidth=2,
        filter="url(#myshadow)"
    )

viz.header(
    fontSize=30,
    text="Choropleth with Shadow Effect on Brazil",
    fill="#267A8A",
    fontWeight="bold",
    fontFamily="Tangerine"
)

viz.render_html(os.path.join(output_dir, "choropleth_effect.html"))
