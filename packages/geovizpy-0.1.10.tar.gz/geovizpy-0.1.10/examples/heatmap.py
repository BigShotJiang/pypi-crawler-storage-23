"""Example script for a smooth/heatmap density map."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

viz = Geoviz(projection="EqualEarth")
viz.outline()
viz.graticule(stroke="white", step=30, strokeWidth=1.2)
viz.path(data=world_data, fill="white", fillOpacity=0.3, stroke="none")

viz.smooth(
    data=world_data,
    var="pop",
    colors="Reds",
    bandwidth=25,
    thresholds=30,
    cellSize=2,
    fillOpacity=0.5,
    strokeOpacity=0.1,
    leg_title="Population",
    leg_pos=[20, 20],
)

viz.header(
    fontSize=30,
    text="World Population Density",
    fill="#267A8A",
    fontWeight="bold",
    fontFamily="Tangerine",
)

viz.footer(text="Source: Natural Earth")

viz.render_html(os.path.join(output_dir, "heatmap.html"))
