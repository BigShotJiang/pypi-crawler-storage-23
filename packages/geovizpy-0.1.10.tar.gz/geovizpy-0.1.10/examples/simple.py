"""Example script for a simple world map."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

# Load geojson
# Assuming running from repo root or examples folder
data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

viz = Geoviz(projection="EqualEarth")
viz.outline(fill="#267A8A")
viz.graticule(stroke="white", strokeWidth=0.4)
viz.path(
    data=world_data,
    fill="#F8D993",
    stroke="#ada9a6",
    strokeWidth=0.5,
    tip="$NAMEen"
)
viz.header(
    fontSize=30,
    text="A Simple World Map",
    fill="#267A8A",
    fontWeight="bold",
    fontFamily="Tangerine"
)
viz.render_html(os.path.join(output_dir, "simple.html"))
