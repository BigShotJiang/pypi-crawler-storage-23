"""Example script for exporting the map configuration to JSON."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

viz = Geoviz(projection="EqualEarth")
viz.outline()
viz.graticule(stroke="white", strokeWidth=0.4)
viz.choro(
    data=world_data,
    var="gdppc",
    strokeWidth=0.3,
    tip=True,
    leg_title="GDP per capita"
)
viz.header(text="Map from JSON Config", fontSize=30)

config_json = viz.to_json()
print("Configuration JSON (first 500 chars):")
print(config_json[:500] + "...")

with open(os.path.join(output_dir, "map_config.json"), "w") as f:
    f.write(config_json)
print(f"\nConfiguration saved to {os.path.join(output_dir, 'map_config.json')}")
