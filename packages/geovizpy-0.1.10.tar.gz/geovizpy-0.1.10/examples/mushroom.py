"""Example script for creating a mushroom map (GDP vs Population)."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

dy = 2

viz = Geoviz(projection="EqualEarth", zoomable=True)
viz.outline()
viz.graticule(stroke="white", strokeWidth=0.4)
viz.path(datum=world_data, fill="white", fillOpacity=0.4)

# Top half-circle: GDP
viz.halfcircle(
    data=world_data,
    r="gdp",
    k=30,
    dy=-dy,
    fill="#F13C47",
    stroke="#F13C47",
    strokeWidth=0.3,
    fillOpacity=0.6,
    tip="(d) => `${d.properties.NAMEen}\nGDP: ${Math.round(+d.properties.gdp / 1e6)} M$`",
    id="gdp",
)

# Bottom half-circle: Population
viz.halfcircle(
    data=world_data,
    r="pop",
    k=30,
    dy=dy,
    angle=180,
    fill="#319ABF",
    stroke="#319ABF",
    strokeWidth=0.3,
    fillOpacity=0.6,
    tip="(d) => `${d.properties.NAMEen}\nPop: ${Math.round(+d.properties.pop / 1e3)} k`",
    id="pop",
)

# Mushroom legend
viz.legend_mushrooms(
    pos=[20, 20],
    top_title="GDP",
    top_fill="#F13C47",
    bottom_title="Population",
    bottom_fill="#319ABF",
    top_txt="len per year",
    bottom_txt="len inhabitants",
)

viz.header(
    fontSize=30,
    text="Mushroom Map",
    fill="#267A8A",
    fontWeight="bold",
    fontFamily="Tangerine",
)

viz.footer(text="GDP & Population by country")

viz.render_html(os.path.join(output_dir, "mushroom.html"))
