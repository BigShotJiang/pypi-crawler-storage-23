# Changelog

## [0.5.2](https://github.com/jbussdieker/nau7802/compare/v0.5.1...v0.5.2) (2026-03-01)


### Bug Fixes

* **registers:** correct bitmask for pga_curr in REG_PWR_CTRL ([914859f](https://github.com/jbussdieker/nau7802/commit/914859f40d387de6fa9945840a078f888a347372))


### Documentation

* **readme:** update code examples for adc value access ([e04ec9a](https://github.com/jbussdieker/nau7802/commit/e04ec9ab6d8ff109068b03b23d3261e12173ee6d))
* **readme:** update installation instructions for CLI ([b2e6606](https://github.com/jbussdieker/nau7802/commit/b2e6606f0f6ea36e8c9ca7b070a8a8efc820e1fd))

## [0.5.1](https://github.com/jbussdieker/nau7802/compare/v0.5.0...v0.5.1) (2026-03-01)


### Bug Fixes

* **makefile:** add build and publish commands ([255204d](https://github.com/jbussdieker/nau7802/commit/255204ddd085c29d2798e883c6721378365f6cc4))

## [0.5.0](https://github.com/jbussdieker/nau7802/compare/v0.4.1...v0.5.0) (2026-03-01)


### Features

* **workflow:** add publish job to GitHub Actions ([31f856d](https://github.com/jbussdieker/nau7802/commit/31f856d17c27c19f4c8d471840e8c75befd706de))

## [0.4.1](https://github.com/jbussdieker/nau7802/compare/v0.4.0...v0.4.1) (2026-03-01)


### Bug Fixes

* **cli, device:** improve channel setting validation ([f288b79](https://github.com/jbussdieker/nau7802/commit/f288b79de014644e79d9fc16f3238490b3ca7599))

## [0.4.0](https://github.com/jbussdieker/nau7802/compare/v0.3.0...v0.4.0) (2026-03-01)


### Features

* **cli:** add version option to CLI ([500d8c7](https://github.com/jbussdieker/nau7802/commit/500d8c7b46d99ddd62a38230756ddf864d34914c))

## [0.3.0](https://github.com/jbussdieker/nau7802/compare/v0.2.0...v0.3.0) (2026-03-01)


### Features

* **cli, device:** enhance calibration and register handling ([43c1a2b](https://github.com/jbussdieker/nau7802/commit/43c1a2b66746c367d019c7a57c5d4aadce01eec9))

## [0.2.0](https://github.com/jbussdieker/nau7802/compare/v0.1.0...v0.2.0) (2026-02-25)


### Features

* **cli:** add help option names to CLI group ([29eb032](https://github.com/jbussdieker/nau7802/commit/29eb032428acde59219aa884becd46cca3da0225))
* **device:** add cycle_ready property to NAU7802 class ([4cede6d](https://github.com/jbussdieker/nau7802/commit/4cede6debaabc85f5225738d4b2964e287a88228))


### Documentation

* **readme:** update installation instructions and usage example ([29eb032](https://github.com/jbussdieker/nau7802/commit/29eb032428acde59219aa884becd46cca3da0225))

## 0.1.0 (2026-02-24)


### Features

* initial commit ([b95cfe6](https://github.com/jbussdieker/nau7802/commit/b95cfe6a708aded6634f73ca56904d626266f414))
