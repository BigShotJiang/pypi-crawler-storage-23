from .bus import BusProtocol

__all__ = [
    "BusProtocol",
]
