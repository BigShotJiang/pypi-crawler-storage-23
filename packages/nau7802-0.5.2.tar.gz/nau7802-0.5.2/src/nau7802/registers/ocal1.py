from ..register._int24 import Int24Register


class REG_OCAL1(Int24Register):
    ADDRESS = 0x03
