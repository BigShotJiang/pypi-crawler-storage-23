from .adc_ctrl1 import REG_ADC_CTRL1
from .adc_ctrl3 import REG_ADC_CTRL3
from .adco import REG_ADCO
from .ctrl1 import REG_CTRL1
from .ctrl2 import REG_CTRL2
from .gcal1 import REG_GCAL1
from .gcal2 import REG_GCAL2
from .i2c_control import REG_I2C_CONTROL
from .ocal1 import REG_OCAL1
from .ocal2 import REG_OCAL2
from .pu_ctl import REG_PU_CTRL
from .pwr_ctrl import REG_PWR_CTRL
from .rev_id import REG_REV_ID

__all__ = [
    "REG_ADC_CTRL1",
    "REG_ADC_CTRL3",
    "REG_ADCO",
    "REG_CTRL1",
    "REG_CTRL2",
    "REG_GCAL1",
    "REG_GCAL2",
    "REG_I2C_CONTROL",
    "REG_OCAL1",
    "REG_OCAL2",
    "REG_PU_CTRL",
    "REG_PWR_CTRL",
    "REG_REV_ID",
]
