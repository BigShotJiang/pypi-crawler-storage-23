from ..register._int24 import Int24Register


class REG_OCAL2(Int24Register):
    ADDRESS = 0x0A
