from ..register._int32 import Int32Register


class REG_GCAL1(Int32Register):
    ADDRESS = 0x06
