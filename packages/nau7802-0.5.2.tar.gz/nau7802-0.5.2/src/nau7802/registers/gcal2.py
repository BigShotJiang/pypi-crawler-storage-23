from ..register._int32 import Int32Register


class REG_GCAL2(Int32Register):
    ADDRESS = 0x0D
