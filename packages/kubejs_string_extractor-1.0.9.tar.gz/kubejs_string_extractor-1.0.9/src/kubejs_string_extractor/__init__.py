"""KubeJS String Extractor - Extract translatable strings from KubeJS scripts."""

__version__ = "0.1.0"
