#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional
import hashlib
import json
import os
import re
import shutil
import time

import pandas as pd


class ProjectCache:
    """Workdir-local cache store: <workdir>/.cache."""

    def __init__(self, workdir: str, logger=None, rebuild: bool = False):
        self.logger = logger
        self.workdir = Path(workdir).expanduser().resolve()
        self.root = self.workdir / ".cache"
        self.data_dir = self.root / "data"
        self.summary_dir = self.root / "summary"
        self.named_dir = self.root / "named"
        self.manifest_path = self.root / "manifest.json"
        self.rebuild = bool(rebuild)

        if self.rebuild and self.root.exists():
            shutil.rmtree(self.root, ignore_errors=True)

        self.root.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.summary_dir.mkdir(parents=True, exist_ok=True)
        self.named_dir.mkdir(parents=True, exist_ok=True)

        self.manifest: Dict[str, Any] = self._load_json(
            self.manifest_path,
            default={"schema": 1, "files": {}, "named": {}},
        )

    def _debug(self, msg: str) -> None:
        if self.logger:
            try:
                self.logger.debug(msg)
            except Exception:
                pass

    def _warn(self, msg: str) -> None:
        if self.logger:
            try:
                self.logger.warning(msg)
            except Exception:
                pass

    @staticmethod
    def _load_json(path: Path, default: Dict[str, Any]) -> Dict[str, Any]:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return dict(default)

    def _save_manifest(self) -> None:
        try:
            with open(self.manifest_path, "w", encoding="utf-8") as f:
                json.dump(self.manifest, f, ensure_ascii=True, indent=2, sort_keys=True)
        except Exception as e:
            self._warn(f"Failed writing cache manifest: {e}")

    @staticmethod
    def _canonical_json(payload: Any) -> str:
        return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str)

    @classmethod
    def cache_key(cls, payload: Any) -> str:
        raw = cls._canonical_json(payload).encode("utf-8")
        return hashlib.sha1(raw).hexdigest()

    @staticmethod
    def _md5_file(path: str, chunk_size: int = 8 * 1024 * 1024) -> str:
        md5 = hashlib.md5()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                md5.update(chunk)
        return md5.hexdigest()

    @staticmethod
    def _sha1_file(path: str, chunk_size: int = 8 * 1024 * 1024) -> str:
        sha1 = hashlib.sha1()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                sha1.update(chunk)
        return sha1.hexdigest()

    def source_fingerprint(self, path: str, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        abs_path = str(Path(path).expanduser().resolve())
        try:
            st = os.stat(abs_path)
        except Exception as e:
            self._warn(f"Cannot stat source file '{abs_path}': {e}")
            fp = {"path": abs_path, "size": None, "mtime_ns": None, "md5": None}
            if extra:
                fp.update(extra)
            return fp

        files = self.manifest.setdefault("files", {})
        old = files.get(abs_path, {})

        size = int(st.st_size)
        mtime_ns = int(st.st_mtime_ns)
        md5 = old.get("md5")

        if not (old.get("size") == size and old.get("mtime_ns") == mtime_ns and md5):
            t0 = time.perf_counter()
            md5 = self._md5_file(abs_path)
            dt = time.perf_counter() - t0
            self._debug(f"Computed md5 for '{abs_path}' in {dt:.2f}s")

        files[abs_path] = {"size": size, "mtime_ns": mtime_ns, "md5": md5}
        self._save_manifest()

        fp = {"path": abs_path, "size": size, "mtime_ns": mtime_ns, "md5": md5}
        if extra:
            fp.update(extra)
        return fp

    def get_dataframe(self, key: str):
        if self.rebuild:
            return None
        p = self.data_dir / f"{key}.pkl"
        if not p.exists():
            return None
        try:
            return pd.read_pickle(p)
        except Exception as e:
            self._warn(f"Failed loading dataframe cache '{p}': {e}")
            return None

    def dataframe_cache_path(self, key: str) -> Path:
        return self.data_dir / f"{key}.pkl"

    def is_dataframe_meta_consistent(self, key: str, meta: Optional[Dict[str, Any]]) -> bool:
        if self.rebuild:
            return False
        if not isinstance(meta, dict):
            return False
        p = self.dataframe_cache_path(key)
        if not p.exists():
            return False
        try:
            st = p.stat()
        except Exception:
            return False

        expect_size = meta.get("cache_file_size")
        if expect_size is not None:
            try:
                if int(expect_size) != int(st.st_size):
                    return False
            except Exception:
                return False

        expect_sha1 = meta.get("cache_file_sha1")
        if expect_sha1:
            try:
                real_sha1 = self._sha1_file(str(p))
            except Exception:
                return False
            if str(real_sha1) != str(expect_sha1):
                return False
        return True

    def get_dataframe_meta(self, key: str) -> Optional[Dict[str, Any]]:
        if self.rebuild:
            return None
        p = self.data_dir / f"{key}.json"
        if not p.exists():
            return None
        try:
            with open(p, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if isinstance(obj, dict):
                return obj
            return None
        except Exception as e:
            self._warn(f"Failed loading dataframe cache meta '{p}': {e}")
            return None

    def put_dataframe(self, key: str, df, meta: Optional[Dict[str, Any]] = None) -> None:
        p = self.data_dir / f"{key}.pkl"
        try:
            df.to_pickle(p)
            payload: Dict[str, Any] = {}
            if isinstance(meta, dict):
                payload.update(meta)
            payload.setdefault("cache_schema", "jp-cache-v2")
            payload["cache_key"] = str(key)
            payload["cache_file"] = str(p.resolve())
            try:
                st = p.stat()
                payload["cache_file_size"] = int(st.st_size)
                payload["cache_file_mtime_ns"] = int(st.st_mtime_ns)
            except Exception:
                pass
            try:
                payload["cache_file_sha1"] = self._sha1_file(str(p))
            except Exception:
                pass

            m = self.data_dir / f"{key}.json"
            with open(m, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=True, indent=2, sort_keys=True, default=str)
        except Exception as e:
            self._warn(f"Failed writing dataframe cache '{p}': {e}")

    def _summary_path(self, source_fp: Dict[str, Any]) -> Path:
        key = self.cache_key({"kind": "summary", "source": source_fp})
        return self.summary_dir / f"{key}.txt"

    def get_summary(self, source_fp: Dict[str, Any]) -> Optional[str]:
        if self.rebuild:
            return None
        p = self._summary_path(source_fp)
        if not p.exists():
            return None
        try:
            return p.read_text(encoding="utf-8")
        except Exception:
            return None

    def put_summary(self, source_fp: Dict[str, Any], text: str) -> None:
        p = self._summary_path(source_fp)
        try:
            p.write_text(str(text), encoding="utf-8")
        except Exception as e:
            self._warn(f"Failed writing summary cache '{p}': {e}")

    @staticmethod
    def _safe_name(name: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(name))

    def put_named(self, name: str, signature: str, df) -> None:
        safe = self._safe_name(name)
        slot = self.cache_key({"name": name, "signature": signature})[:12]
        p = self.named_dir / f"{safe}__{slot}.pkl"
        try:
            df.to_pickle(p)
            named = self.manifest.setdefault("named", {})
            sha1 = None
            size = None
            mtime_ns = None
            try:
                st = p.stat()
                size = int(st.st_size)
                mtime_ns = int(st.st_mtime_ns)
            except Exception:
                pass
            try:
                sha1 = self._sha1_file(str(p))
            except Exception:
                sha1 = None
            named[str(name)] = {
                "signature": str(signature),
                "path": str(p.relative_to(self.root)),
                "sha1": sha1,
                "size": size,
                "mtime_ns": mtime_ns,
            }
            self._save_manifest()
        except Exception as e:
            self._warn(f"Failed writing named cache '{name}': {e}")

    def get_named(self, name: str, signature: str):
        if self.rebuild:
            return None
        named = self.manifest.get("named", {})
        item = named.get(str(name))
        if not item:
            return None
        if str(item.get("signature")) != str(signature):
            return None
        try:
            p = self.root / item["path"]
            if not p.exists():
                return None
            try:
                st = p.stat()
                expect_size = item.get("size")
                if expect_size is not None and int(expect_size) != int(st.st_size):
                    return None
            except Exception:
                return None
            expect_sha1 = item.get("sha1")
            if expect_sha1:
                try:
                    real_sha1 = self._sha1_file(str(p))
                except Exception:
                    return None
                if str(real_sha1) != str(expect_sha1):
                    return None
            return pd.read_pickle(p)
        except Exception:
            return None
