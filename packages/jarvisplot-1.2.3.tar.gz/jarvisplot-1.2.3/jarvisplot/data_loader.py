#!/usr/bin/env python3 

from __future__ import annotations
from pathlib import Path
from typing import Optional, Any, Dict, List
import os
import pandas as pd 
import h5py
import numpy as np

class DataSet():
    def __init__(self):
        self._file: Optional[str]   = None
        self.path:  Optional[str]   = None 
        self._type:  Optional[str]  = None
        self.base:  Optional[str]   = None
        self.keys:  Optional[List[str]]  = None 
        self._logger                = None 
        self.data                   = None
        self.group                  = None
        self.columns                = {}
        self.isvalid_policy         = "clean"
        self.full_load              = False
        self.transform              = None
        self._whitelist_base_paths  = None
        self.cache                  = None
        self._loaded                = False
        self._summary_emitted       = False
       
    def setinfo(self, dtinfo, rootpath, eager: bool = False, cache=None):
        self.cache = cache
        raw_path = str(dtinfo['path'])
        p = Path(raw_path).expanduser()
        if p.is_absolute():
            resolved = p
        else:
            base = Path(rootpath or ".").expanduser().resolve()
            resolved = (base / p).resolve()
        self.file = str(resolved)
        self.name = dtinfo['name']
        self.type = dtinfo['type'].lower()
        self.transform = dtinfo.get("transform", None)
        if self.type == "hdf5":
            self.group = dtinfo.get("dataset", None)
            self.columns = dtinfo.get("columns", {})
            if not isinstance(self.columns, dict):
                self.columns = {}
            policy_raw = str(self.columns.get("isvalid_policy", "clean")).strip().lower()
            if policy_raw not in {"clean", "raw"}:
                raise ValueError(
                    "columns.isvalid_policy must be one of: clean, raw. got: {}".format(
                        self.columns.get("isvalid_policy")
                    )
                )
            self.isvalid_policy = policy_raw

        if eager:
            self.load(force=True)
        else:
            self._prepare_lazy_metadata()

    def _prepare_lazy_metadata(self):
        """Fetch cheap metadata only; avoid full table load."""
        if self.type == "csv":
            try:
                head = pd.read_csv(self.path, nrows=0)
                self.keys = list(head.columns)
                if self.logger:
                    self.logger.debug(
                        f"Dataset '{self.name}' registered in lazy mode (csv columns={len(self.keys)})."
                    )
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"Dataset '{self.name}' lazy metadata failed: {e}")
        else:
            if self.logger:
                self.logger.debug(f"Dataset '{self.name}' registered in lazy mode.")

    def fingerprint(self, cache=None):
        cache = cache or self.cache
        extra = {
            "name": self.name,
            "type": self.type,
            "group": self.group,
            "transform": self.transform,
            "columns": self.columns,
            "full_load": bool(getattr(self, "full_load", False)),
        }
        if cache is not None:
            return cache.source_fingerprint(self.path, extra=extra)
        try:
            st = os.stat(self.path)
            return {
                "path": self.path,
                "size": int(st.st_size),
                "mtime_ns": int(st.st_mtime_ns),
                "md5": None,
                **extra,
            }
        except Exception:
            return {"path": self.path, "size": None, "mtime_ns": None, "md5": None, **extra}

    def load(self, force: bool = False):
        if self._loaded and self.data is not None and not force:
            return self.data
        if self.type == "csv":
            self.load_csv()
        elif self.type == "hdf5":
            self.load_hdf5()
        else:
            raise ValueError(f"Unsupported dataset type: {self.type}")
        self._loaded = True
        return self.data

    def get_data(self):
        return self.load(force=False)

    def _summary_name(self) -> str:
        if self.type == "hdf5":
            return f" HDF5 loaded!\n\t name  -> {self.name}\n\t group -> {self.group}\n\t path  -> {self.path}"
        return f" CSV loaded!\n\t name  -> {self.name}\n\t path  -> {self.path}"

    def _emit_summary_text(self, summary_msg: str) -> None:
        if self.logger:
            self.logger.warning("\n" + str(summary_msg))
        else:
            print(summary_msg)
        self._summary_emitted = True

    def emit_summary(self, force_load: bool = True) -> bool:
        """Emit source summary even when data pipeline hits cache.

        Priority:
        1) cached summary text in .cache/summary
        2) build from already loaded dataframe
        3) optional fallback: load source and emit summary from loader
        """
        if self._summary_emitted:
            return True

        source_fp = self.fingerprint()
        if self.cache is not None:
            cached = self.cache.get_summary(source_fp)
            if cached is not None:
                self._emit_summary_text(cached)
                return True

        if self.data is not None:
            try:
                msg = dataframe_summary(self.data, name=self._summary_name())
            except Exception:
                msg = f"DataFrame shape: {self.data.shape}"
            if self.cache is not None:
                self.cache.put_summary(source_fp, msg)
            self._emit_summary_text(msg)
            return True

        if force_load:
            self.load(force=False)
            self._summary_emitted = True
            return True

        return False

    @property 
    def file(self) -> Optional[str]:
        return self._file 
    
    @property
    def type(self) -> Optional[str]:
        return self._type 
    
    @property
    def logger(self): 
        return self._logger
    
    @logger.setter
    def logger(self, logger) -> None: 
        if logger is None: 
            self._logger = None
        self._logger = logger
    
    @file.setter 
    def file(self, value: Optional[str]) -> None: 
        if value is None: 
            self._file  = None
            self.path   = None
            self.base   = None
            
        p = Path(value).expanduser().resolve()
        self._file  = str(p)
        self.path   = os.path.abspath(p)
        self.base   = os.path.basename(p)
        
    @type.setter 
    def type(self, value: Optional[str]) -> None: 
        if value is None: 
            self._type = None
            
        self._type = str(value).lower()
        if self.logger:
            self.logger.debug("Dataset -> {} is assigned as \n\t-> {}\ttype".format(self.base, self.type))

    def _columns_dict(self) -> Dict[str, Any]:
        if isinstance(self.columns, dict):
            return self.columns
        return {}

    def _canonical_dataset_path(self, value: str) -> str:
        sval = str(value).strip()
        if not sval:
            return ""
        if self.group and not sval.startswith(f"{self.group}/"):
            return f"{self.group}/{sval}"
        return sval

    def _path_aliases(self, value: str) -> set[str]:
        sval = str(value).strip()
        if not sval:
            return set()
        aliases = {sval}
        if self.group:
            prefix = f"{self.group}/"
            if sval.startswith(prefix):
                aliases.add(sval[len(prefix):])
            else:
                aliases.add(prefix + sval)
        return aliases

    def _rename_source_by_alias(self) -> Dict[str, str]:
        alias_map: Dict[str, str] = {}
        rename_list = self._columns_dict().get("rename", [])
        if not isinstance(rename_list, list):
            return alias_map

        for item in rename_list:
            if not isinstance(item, dict):
                continue
            source = str(item.get("source", "")).strip()
            target = str(item.get("target", "")).strip()
            if not source:
                continue
            source_canon = self._canonical_dataset_path(source)
            for alias in self._path_aliases(source):
                alias_map[alias] = source_canon
            if target:
                alias_map[target] = source_canon
        return alias_map

    def _build_hdf5_whitelist(self) -> Optional[set[str]]:
        cfg = self._columns_dict()
        raw_whitelist = cfg.get("load_whitelist", None)
        if raw_whitelist is None:
            self._whitelist_base_paths = None
            return None

        use_only_in_list = False
        requested_tokens: List[str] = []

        if isinstance(raw_whitelist, list):
            for item in raw_whitelist:
                if item is None:
                    continue
                sval = str(item).strip()
                if not sval:
                    continue
                requested_tokens.append(sval)
        elif isinstance(raw_whitelist, str):
            sval = raw_whitelist.strip()
            if not sval:
                return None
            if sval == "only_in_list":
                use_only_in_list = True
            else:
                raise ValueError(
                    "columns.load_whitelist only supports a list or the string 'only_in_list'."
                )
        else:
            raise TypeError(
                "columns.load_whitelist must be a list or the string 'only_in_list'."
            )

        if use_only_in_list:
            rename_list = cfg.get("rename", [])
            if not isinstance(rename_list, list):
                raise TypeError(
                    "columns.load_whitelist='only_in_list' requires columns.rename to be a list."
                )
            for item in rename_list:
                if not isinstance(item, dict):
                    continue
                source = str(item.get("source", "")).strip()
                if source:
                    requested_tokens.append(source)

        alias_to_source = self._rename_source_by_alias()
        selected_paths: set[str] = set()
        for token in requested_tokens:
            source = alias_to_source.get(token, token)
            source_canon = self._canonical_dataset_path(source)
            if source_canon:
                selected_paths.add(source_canon)
        self._whitelist_base_paths = {p for p in selected_paths if not p.endswith("_isvalid")}

        # Always add companion validity columns so filtering/keeping works consistently.
        with_isvalid = set(selected_paths)
        for path in list(selected_paths):
            if not path.endswith("_isvalid"):
                with_isvalid.add(f"{path}_isvalid")
        return with_isvalid

    @staticmethod
    def _shape_token(df) -> str:
        if isinstance(df, pd.DataFrame):
            return f"{df.shape}"
        return "NA"

    def _apply_dataset_transform(self, stage: str = "dataset") -> None:
        """
        Apply DataSet-level transforms using the same operators as layer transforms.
        For HDF5 this is called after is_valid policy + columns rename.
        """
        if self.data is None:
            return
        if self.transform is None:
            return
        if not isinstance(self.transform, list):
            if self.logger:
                self.logger.warning(
                    "Dataset '{}' transform ignored: list required, got {}.".format(
                        self.name, type(self.transform)
                    )
                )
            return

        from .Figure.load_data import addcolumn, filter as filter_df, grid_profiling, profiling, sortby

        df = self.data
        before_shape = self._shape_token(df)
        for trans in self.transform:
            if not isinstance(trans, dict):
                if self.logger:
                    self.logger.warning(f"Dataset '{self.name}' invalid transform step skipped -> {trans}")
                continue

            if "filter" in trans:
                df = filter_df(df, trans["filter"], self.logger)
            elif "profile" in trans:
                df = profiling(df, trans["profile"], self.logger)
            elif "grid_profile" in trans:
                cfg = trans.get("grid_profile", {})
                if isinstance(cfg, dict):
                    cfg = cfg.copy()
                    cfg.setdefault("method", "grid")
                else:
                    cfg = {"method": "grid"}
                df = grid_profiling(df, cfg, self.logger)
            elif "sortby" in trans:
                df = sortby(df, trans["sortby"], self.logger)
            elif "add_column" in trans:
                df = addcolumn(df, trans["add_column"], self.logger)

        self.data = df
        if isinstance(self.data, pd.DataFrame):
            self.keys = list(self.data.columns)
        if self.logger:
            self.logger.warning(
                "DataSet transform done:\n\t name \t-> {}\n\t stage \t-> {}\n\t rows \t-> {} -> {}".format(
                    self.name,
                    stage,
                    before_shape,
                    self._shape_token(self.data),
                )
            )
    
    def load_csv(self):
        if self.type == "csv":
            if self.logger:
                self.logger.debug("Loading CSV from {}".format(self.path))

            self.data = pd.read_csv(self.path)
            self.keys = list(self.data.columns)
            self._apply_dataset_transform(stage="csv")

            # Emit the same pretty summary used for HDF5 datasets
            summary_name = self._summary_name()
            summary_msg = None
            source_fp = self.fingerprint()
            if self.cache is not None:
                summary_msg = self.cache.get_summary(source_fp)

            if summary_msg is None:
                try:
                    summary_msg = dataframe_summary(self.data, name=summary_name)
                except Exception:
                    # Fallback minimal summary if something goes wrong
                    summary_msg = f"CSV loaded  {summary_name}\nDataFrame shape: {self.data.shape}"
                if self.cache is not None:
                    self.cache.put_summary(source_fp, summary_msg)

            self._emit_summary_text(summary_msg)
    
    def load_hdf5(self):
            def _iter_datasets(hobj, prefix=""):
                for k, v in hobj.items():
                    path = f"{prefix}/{k}" if prefix else k
                    if isinstance(v, h5py.Dataset):
                        yield path, v
                    elif isinstance(v, h5py.Group):
                        yield from _iter_datasets(v, path)

            def _pick_dataset(hfile: h5py.File):
                # Heuristic: prefer structured arrays, then 2D arrays
                best = None
                for path, ds in _iter_datasets(hfile):
                    shape = getattr(ds, "shape", ())
                    dt = getattr(ds, "dtype", None)
                    score = 0
                    if dt is not None and getattr(dt, "names", None):
                        score += 10  # structured array → good for DataFrame
                    if len(shape) == 2:
                        score += 5
                        if shape[1] >= 2:
                            score += 1
                    if best is None or score > best[0]:
                        best = (score, path, ds)
                if best is None:
                    raise RuntimeError("No datasets found in HDF5 file.")
                _, path, ds = best
                return path, ds[()]

            def _to_dataframe(arr, name=""):
                if isinstance(arr, np.ndarray) and getattr(arr.dtype, "names", None):
                    df = pd.DataFrame.from_records(arr)
                    # prefix columns to keep dataset origin
                    if name:
                        df.columns = [f"{name}:{c}" for c in df.columns]
                    return df
                elif hasattr(arr, "ndim") and arr.ndim == 2:
                    cols = [f"col{i}" for i in range(arr.shape[1])]
                    if name:
                        cols = [f"{name}:{c}" for c in cols]
                    return pd.DataFrame(arr, columns=cols)
                else:
                    col = name if name else "value"
                    return pd.DataFrame({col: np.ravel(arr)})

            def _collect_group_datasets(g: h5py.Group, prefix: str="", whitelist=None):
                """Recursively collect (path, ndarray) for all datasets under a group."""
                items = []
                for k, v in g.items():
                    path = f"{prefix}/{k}" if prefix else k
                    if isinstance(v, h5py.Dataset):
                        if whitelist is None or path in whitelist:
                            items.append((path, v[()]))
                    elif isinstance(v, h5py.Group):
                        items.extend(_collect_group_datasets(v, path, whitelist=whitelist))
                return items

            with h5py.File(self.path, "r") as f1:
                # Log top-level keys to help the user
                print_hdf5_tree_ascii(f1[self.group], root_name=self.group, logger=self.logger)

                if self.group in f1 and isinstance(f1[self.group], h5py.Group):
                    group = f1[self.group]
                    self.logger.debug("Loading HDF5 group '{}' from {}".format(self.group, self.path))

                    whitelist = None
                    if not bool(getattr(self, "full_load", False)):
                        whitelist = self._build_hdf5_whitelist()
                        if whitelist is not None:
                            self.logger.debug(
                                "HDF5 load_whitelist enabled -> {} paths".format(len(whitelist))
                            )

                    # Collect all datasets under the group (recursively)
                    items = _collect_group_datasets(group, prefix=self.group, whitelist=whitelist)
                    if not items:
                        if whitelist is not None:
                            raise RuntimeError(
                                "HDF5 group '{}' has no datasets after applying columns.load_whitelist.".format(
                                    self.group
                                )
                            )
                        raise RuntimeError(f"HDF5 group '{self.group}' contains no datasets.")

                    # If there is only one dataset, behave like before
                    kkeys = []
                    if len(items) == 1:
                        path, arr = items[0]
                        dfs = [(path, _to_dataframe(arr, name=path))]
                        kkeys.append(path)
                    else:
                        # Build a dataframe per dataset
                        dfs = [(p, _to_dataframe(arr, name=p)) for p, arr in items]
                        kkeys = [p for p, arr in items]
                    
                    # Try to concatenate along columns; all datasets must have identical row counts
                    lengths = {len(df) for _, df in dfs}
                    if len(lengths) == 1:
                        # safe to concat by columns → single merged DataFrame only
                        self.data = pd.concat([df for _, df in dfs], axis=1)
                        
                        self.keys = list(self.data.columns)
                        
                        self.apply_is_valid_policy(kkeys)

                        rename_entries = self._columns_dict().get("rename", [])
                        if isinstance(rename_entries, list) and rename_entries:
                            self.logger.warning("{}: Loading Columns Rename Map".format(self.name))
                            cmap = {}
                            for item in rename_entries:
                                if not isinstance(item, dict):
                                    continue
                                source = str(item.get("source", "")).strip()
                                target = str(item.get("target", "")).strip()
                                if not source or not target:
                                    continue
                                source_canon = self._canonical_dataset_path(source)
                                cmap[source_canon] = target
                                cmap[f"{source_canon}_isvalid"] = f"{target}_isvalid"
                            if cmap:
                                self.rename_columns(cmap)
                        self._apply_dataset_transform(stage="hdf5")
                                
                        # Emit a pretty summary BEFORE returning
                        summary_name = self._summary_name()
                        source_fp = self.fingerprint()
                        summary_msg = None
                        if self.cache is not None:
                            summary_msg = self.cache.get_summary(source_fp)
                        if summary_msg is None:
                            summary_msg = dataframe_summary(self.data, name=summary_name)
                            if self.cache is not None:
                                self.cache.put_summary(source_fp, summary_msg)
                        self._emit_summary_text(summary_msg)

                        return  # IMPORTANT: stop here; avoid falling through to single-dataset path
                    else:
                        # Not mergeable → print tree for diagnostics and raise a hard error
                        try:
                            print_hdf5_tree_ascii(group, root_name=self.group, logger=self.logger)
                        except Exception:
                            pass
                        shapes = {p: df.shape for p, df in dfs}
                        raise ValueError(
                            "HDF5 group '{grp}' is invalid for merging: datasets have different row counts. "
                            "Please fix the input or choose a different dataset/group. Details: {details}".format(
                                grp=self.group,
                                details=shapes,
                            )
                        )
                else:
                    path, arr = _pick_dataset(f1)
    
    def apply_is_valid_policy(self, kkeys): 
        if self.data is None:
            self.load(force=False)

        isvalids = []
        all_isvalid_cols = []
        if self.keys is not None:
            for col in self.keys:
                if isinstance(col, str) and col.endswith("_isvalid"):
                    all_isvalid_cols.append(col)

        for kk in kkeys:
            if isinstance(kk, str) and kk.endswith("_isvalid") and kk[:-8] in self.keys:
                isvalids.append(kk)

        # Fallback: if mapping by kkeys fails, still use loaded *_isvalid columns.
        if not isvalids:
            isvalids = all_isvalid_cols[:]

        required_base = self._whitelist_base_paths if isinstance(self._whitelist_base_paths, set) else None
        if required_base is not None:
            loaded_cols = set(self.keys or [])
            missing_base = sorted([c for c in required_base if c not in loaded_cols])
            missing_isvalid = sorted([f"{c}_isvalid" for c in required_base if f"{c}_isvalid" not in loaded_cols])
            if missing_base or missing_isvalid:
                self.logger.warning(
                    "Skip is_valid policy: not all whitelist columns have companion _isvalid columns. "
                    "missing_base={}, missing_isvalid={}".format(missing_base, missing_isvalid)
                )
                self.keys = list(self.data.columns)
                return

        if self.isvalid_policy == "raw":
            self.logger.warning(
                "isvalid_policy=raw -> skip is_valid filtering and keep {} is_valid columns".format(
                    len(all_isvalid_cols)
                )
            )
            self.keys = list(self.data.columns)
            return

        if isvalids:
            self.logger.warning("Filtering Invalid Data from HDF5 Output")
            sps = self.data.shape
            mask = self.data[isvalids].all(axis=1)
            self.data = self.data[mask]
            self.logger.warning(
                "DataSet Shape: \n\t Before filtering -> {}\n\t  After filtering -> {}".format(
                    sps, self.data.shape
                )
            )

        if all_isvalid_cols:
            self.data = self.data.drop(columns=all_isvalid_cols, errors="ignore")
        self.keys = list(self.data.columns)
                
    def rename_columns(self, vdict):
        if self.data is None:
            self.load(force=False)
        self.data = self.data.rename(columns=vdict)
        self.keys = list(self.data.columns)
        
                   
def dataframe_summary(df: pd.DataFrame, name: str = "") -> str:
    """Pretty, compact multi-line summary for a DataFrame.

    Sections:
      • header: dataset path (if any) and shape
      • columns table (first max_cols): name | dtype | non-null% | unique (for small card.) | min..max (numeric)
      • tiny preview of first rows/cols
    """
    import pandas as _pd
    import numpy as _np
    import shutil

    def term_width(default=120):
        try:
            return shutil.get_terminal_size().columns
        except Exception:
            return default

    def trunc(s: str, width: int) -> str:
        if len(s) <= width:
            return s
        # keep both ends
        head = max(0, width // 2 - 2)
        tail = max(0, width - head - 3)
        return s[:head] + "..." + s[-tail:]

    nrows, ncols = df.shape
    cols = list(df.columns)
    show_cols = cols[:]

    # Compute per-column stats for the shown columns
    dtypes = df[show_cols].dtypes.astype(str)
    non_null_pct = (df[show_cols].notna().sum() / max(1, nrows) * 100.0).round(1)

    # numeric min/max; categorical unique count (cap at 20)
    is_num = [_pd.api.types.is_numeric_dtype(df[c]) for c in show_cols]
    num_cols = [c for c, ok in zip(show_cols, is_num) if ok]
    cat_cols = [c for c, ok in zip(show_cols, is_num) if not ok]

    num_min = {}
    num_max = {}
    if num_cols:
        try:
            desc = df[num_cols].agg(["min", "max"]).T
            for c in num_cols:
                mn = desc.loc[c, "min"]
                mx = desc.loc[c, "max"]
                num_min[c] = mn
                num_max[c] = mx
        except Exception:
            pass

    uniques = {}
    if cat_cols:
        for c in cat_cols:
            try:
                u = df[c].nunique(dropna=True)
                uniques[c] = int(u)
            except Exception:
                pass

    # Build a compact table
    tw = term_width()
    name_w = 34 if tw < 120 else 48
    dtype_w = 10
    nn_w = 8
    stat_w = max(12, tw - (name_w + dtype_w + nn_w + 8))  # 8 for separators/padding

    def fmt_stat(c: str) -> str:
        if c in num_min and c in num_max:
            try:
                mn = num_min[c]
                mx = num_max[c]
                return f"{mn:>10.4g} .. {mx:>10.4g}"
            except Exception:
                return f"{str(num_min[c]):>10} .. {str(num_max[c]):>10}"
        if c in uniques:
            return f"uniq={uniques[c]}"
        return ""

    head_lines = []
    if name:
        head_lines.append(f"Selected dataset:{name}")
    head_lines.append(f"DataFrame shape:\n\t {nrows}\t rows × {ncols} \tcols\n")
    head_lines.append("=== DataFrame Summary Table ===")

    # Column table header
    rows = []
    header = f"{'name':<{name_w}}  {'dtype':<{dtype_w}}  {'nonnull%':>{nn_w}}  {'     [min] ..      [max]':<{stat_w}}"
    rows.append("-" * len(header))
    rows.append(header)
    rows.append("-" * len(header))

    for c in show_cols:
        c_name = trunc(str(c), name_w)
        c_dtype = trunc(dtypes[c], dtype_w)
        c_nn = f"{non_null_pct[c]:.1f}%" if nrows else "n/a"
        c_stat = trunc(fmt_stat(c), stat_w)
        rows.append(f"{c_name:<{name_w}}  {c_dtype:<{dtype_w}}  {c_nn:>{nn_w}}  {c_stat:<{stat_w}}")
    rows.append("-" * len(header))


    parts = []
    parts.extend(head_lines)
    if show_cols:
        parts.extend(rows)

    return "\n".join(parts)
                
                
def print_hdf5_tree_ascii(hobj, root_name='/', logger=None, max_depth=None):
    """
    Pretty-print an ASCII tree of an h5py.File or Group.

    Example output:
    /
    ├── data (Group)
    │   ├── samples (Dataset, shape=(1000, 3), dtype=float64)
    │   └── extra (Group)
    │       ├── X (Dataset, shape=(..., ...), dtype=...)
    │       └── Y (Dataset, shape=(..., ...), dtype=...)
    └── metadata (Group)
        └── attrs (Dataset, shape=(...,), dtype=...)

    Parameters
    ----------
    hobj : h5py.File or h5py.Group
    root_name : str
        Name shown at the root.
    logger : logging-like object (optional)
        If provided, uses logger.debug(...) instead of print.
    max_depth : int or None
        Limit recursion depth (0=only root). None = unlimited.
    """
    try:
        import h5py  # noqa: F401
    except Exception:
        raise RuntimeError("h5py is required for HDF5 tree printing.")

    def emit(msg):
        if logger is None:
            print(msg)
        else:
            try:
                logger.debug(msg)
            except Exception:
                print(msg)

    def is_dataset(x):
        import h5py
        return isinstance(x, h5py.Dataset)

    def is_group(x):
        import h5py
        return isinstance(x, h5py.Group)

    def fmt_leaf(name, obj):
        # maxlen = 60
        def shorten(n):
            if len(n) > 50:
                return f"{n[:15]}...{n[-30:]}"
            else:
                return "{:48}".format(n)
            # return n
        if is_dataset(obj):
            shp = getattr(obj, "shape", None)
            # dt  = getattr(obj, "dtype", None)
            extra = []
            if shp is not None:
                extra.append(f"shape -> {shp}")
            # if dt is not None:
            #     extra.append(f"dtype={dt}")
            suffix = f"(Dataset), {', '.join(extra)}" if extra else "(Dataset)"
            return f"{shorten(name)}{suffix:>40}"
        elif is_group(obj):
            return f"{shorten(name)}          (Group)"
        return shorten(name)

    def walk(group, prefix="", depth=0, last=True):
        lines = []
        if depth == 0:
            lines.append("│ {}          (Group)".format(root_name))
        if max_depth is not None and depth >= max_depth:
            return

        keys = list(group.keys())
        keys.sort()
        n = len(keys)
        for i, key in enumerate(keys):
            child = group[key]
            is_last = (i == n - 1)
            connector = "└── " if is_last else "├── "
            line = prefix + connector + fmt_leaf(key, child)
            lines.append(line)

            if is_group(child):
                extension = "    " if is_last else "│   "
                walk(child, prefix + extension, depth + 1, is_last)
        emit("\n".join(lines))

    walk(hobj, "", 0, True)
