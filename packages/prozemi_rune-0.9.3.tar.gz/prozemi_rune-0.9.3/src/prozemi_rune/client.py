import requests
import time
import json
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ProzemiRune:
    BASE_URL = "https://api.programmingzemi.com/api/v1"

    def __init__(self, username=None):
        self.session = requests.Session()
        self.session.verify = False
        
        # あなたの環境から取得した X-Cookiez を固定で使用
        self.session.headers.update({
            "Host": "api.programmingzemi.com",
            "Accept": "*/*",
            "X-Cookiez": "app=com.programmingzemi&device=B81A62DF-A6F2-F9B3-60F2-A5AC6EB616CD&app_ver=1.14.10&build=fc127b0e5&model_name=Dynabook+Inc.+dynabook+VZ%2FHUL&os=win32&os_ver=Windows+10.0+%28Build+26200%29",
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": "ProgrammingZemi/1.14.10",
        })
        
        self.username = username
        self.report_token = None

    def sign_up(self, nickname="test_user"):
        """新規アカウントを作成してトークンを取得する"""
        url = f"{self.BASE_URL}/users/sign_up"
        payload = {
            "last_noticed": "1",
            "nickname": nickname
        }
        
        response = self.session.post(url, json=payload)
        if response.status_code == 201:
            data = response.json()
            if data.get("success") == 1:
                self.username = data.get("username")
                self.report_token = data.get("report_token")
                print(f"[*] Account Created!")
                print(f"    Username: {self.username}")
                print(f"    Token: {self.report_token}")
                return data
        print(f"[!] Sign up failed: {response.text}")
        return None

    def sign_in(self):
        """既存のusernameを使ってログイン(トークン更新)する"""
        if not self.username:
            print("[!] No username provided.")
            return None
            
        url = f"{self.BASE_URL}/users/sign_in"
        payload = {
            "last_noticed": str(int(time.time())),
            "nickname": "PythonBot", # 適当な名前でOK
            "username": self.username
        }
        
        response = self.session.post(url, json=payload)
        if response.status_code == 201:
            data = response.json()
            self.report_token = data.get("report_token")
            return self.report_token
        return None
import os

class ProzemiRune(ProzemiRune): # 前述のクラスを継承
    def get_public_works(self, page=1, per_page=15):
        """みんなの作品一覧を取得"""
        # app_id は wjzZKZ5XF19UDHCyGsG8 (画像から取得)
        app_id = "wjzZKZ5XF19UDHCyGsG8"
        url = f"{self.BASE_URL}/apps/{app_id}/works"
        params = {
            "per_page": per_page,
            "page": page,
            "review_status": 3
        }
        
        response = self.session.get(url, params=params)
        if response.status_code == 201:
            return response.json().get("projects", [])
        return []

    def download_project(self, project_url, save_dir="projects"):
        """ .prozemiproj ファイルを実際にダウンロードする """
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
            
        filename = project_url.split("/")[-1].split("?")[0]
        save_path = os.path.join(save_dir, filename)
        
        # ファイル自体はCDN(CloudFront等)にあるため、session(認証ヘッダー)不要で取れる可能性が高い
        res = requests.get(project_url)
        with open(save_path, "wb") as f:
            f.write(res.content)
        print(f"Downloaded: {filename}")

# --- 実装例 ---
if __name__ == "__main__":
    # 1. アカウントを持っていない場合：新規発行
    rune = ProzemiRune()
    account_info = rune.sign_up(nickname="PyTorch_User")
    
    if account_info:
        # 2. 作品一覧を取得してみる（推測エンドポイント）
        # トークンが必要なAPIを叩くときは self.report_token を使う
        print(f"発行されたユーザー名 '{rune.username}' をメモしておけば、次回からログイン可能です。")
    