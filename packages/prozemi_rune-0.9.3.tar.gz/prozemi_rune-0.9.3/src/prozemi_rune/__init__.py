from .client import ProzemiRune

__version__ = "0.9.2"