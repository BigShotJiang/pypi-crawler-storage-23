"""
Behavioral analytics for releaseops.

Provides metrics aggregation, version comparison, and trace querying
to understand agent behavior patterns across bundle versions.
"""

from llmhq_releaseops.analytics.aggregator import MetricsAggregator
from llmhq_releaseops.analytics.comparator import VersionComparator
from llmhq_releaseops.analytics.models import (
    BehaviorMetrics,
    MetricChange,
    VersionComparison,
)
from llmhq_releaseops.analytics.querier import TraceQuerier

__all__ = [
    "BehaviorMetrics",
    "MetricChange",
    "VersionComparison",
    "MetricsAggregator",
    "VersionComparator",
    "TraceQuerier",
]
