"""
Data models for llmhq-releaseops.

All models are frozen dataclasses with to_dict/from_dict serialization.
"""

from llmhq_releaseops.models.artifact import (
    Artifact,
    ArtifactRef,
    ArtifactType,
)
from llmhq_releaseops.models.bundle import (
    CURRENT_SCHEMA_VERSION,
    BundleManifest,
    BundleMetadata,
    ModelConfig,
)
from llmhq_releaseops.models.environment import (
    BundleMapping,
    EnvironmentConfig,
    EnvironmentMetadata,
    PromotionPolicy,
)
from llmhq_releaseops.models.eval_result import (
    AssertionResult,
    CaseResult,
    EvalReport,
    GateDecision,
    ScoreCard,
)
from llmhq_releaseops.models.eval_suite import (
    Assertion,
    EvalCase,
    EvalSuite,
    JudgeConfig,
    JudgeType,
    PromotionGate,
)
from llmhq_releaseops.models.promotion import (
    ENV_TO_STATE,
    STATE_TO_ENV,
    GateResult,
    GateType,
    PromotionHistory,
    PromotionRecord,
    PromotionState,
)

__all__ = [
    # Artifact
    "ArtifactType",
    "ArtifactRef",
    "Artifact",
    # Bundle
    "BundleManifest",
    "BundleMetadata",
    "ModelConfig",
    # Environment
    "EnvironmentConfig",
    "EnvironmentMetadata",
    "BundleMapping",
    "PromotionPolicy",
    # Promotion
    "PromotionState",
    "PromotionRecord",
    "PromotionHistory",
    "GateType",
    "GateResult",
    "ENV_TO_STATE",
    "STATE_TO_ENV",
    # Eval Suite
    "JudgeType",
    "JudgeConfig",
    "Assertion",
    "EvalCase",
    "EvalSuite",
    "PromotionGate",
    # Eval Result
    "GateDecision",
    "AssertionResult",
    "CaseResult",
    "ScoreCard",
    "EvalReport",
]
