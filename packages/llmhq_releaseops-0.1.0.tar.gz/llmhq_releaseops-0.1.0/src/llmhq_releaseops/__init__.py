"""
llmhq-releaseops: Release engineering infrastructure for AI behavior.

Compose prompts, policies, and model configs into immutable bundles.
Promote through gated environments. Evaluate with automated quality gates.
"""

from llmhq_releaseops._version import __version__

# Models — public API
from llmhq_releaseops.models.artifact import ArtifactRef, ArtifactType
from llmhq_releaseops.models.bundle import BundleManifest, BundleMetadata, ModelConfig
from llmhq_releaseops.models.environment import (
    BundleMapping,
    EnvironmentConfig,
    PromotionPolicy,
)
from llmhq_releaseops.models.eval_result import EvalReport, GateDecision, ScoreCard
from llmhq_releaseops.models.eval_suite import EvalSuite, JudgeType, PromotionGate
from llmhq_releaseops.models.promotion import (
    GateType,
    PromotionHistory,
    PromotionRecord,
    PromotionState,
)

__author__ = "jision"
__email__ = "jisionpc@gmail.com"
