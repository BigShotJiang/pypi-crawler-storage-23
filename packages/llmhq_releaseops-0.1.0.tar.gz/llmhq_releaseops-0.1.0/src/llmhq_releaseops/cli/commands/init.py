"""releaseops init — Initialize .releaseops/ directory structure."""

import typer

from llmhq_releaseops.storage.git_store import GitStore

app = typer.Typer(help="Initialize releaseops in the current project.")


@app.callback(invoke_without_command=True)
def init(
    path: str = typer.Option(".", "--path", "-p", help="Path to repository root"),
):
    """Create .releaseops/ directory structure and default environments."""
    store = GitStore(path)

    if store.is_initialized():
        typer.echo("ReleaseOps is already initialized.")
        return

    store.initialize()
    typer.echo("Initialized .releaseops/ with:")
    typer.echo("  bundles/          — Bundle manifests")
    typer.echo("  environments/     — Environment configs (dev, staging, prod)")
    typer.echo("  evals/            — Eval suite definitions")
    typer.echo("  eval_reports/     — Eval results")
    typer.echo("  policies/         — Context, tool, and safety policies")
    typer.echo("")
    typer.echo("Next steps:")
    typer.echo("  releaseops bundle create <name> --artifact system=<prompt>:<version>")
