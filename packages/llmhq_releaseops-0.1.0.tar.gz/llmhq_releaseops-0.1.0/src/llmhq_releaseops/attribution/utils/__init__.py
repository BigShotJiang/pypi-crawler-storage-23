"""Attribution utility functions."""
