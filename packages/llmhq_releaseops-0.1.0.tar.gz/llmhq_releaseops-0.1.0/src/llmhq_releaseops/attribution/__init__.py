"""
Attribution engine for releaseops.

Analyzes traces to explain why agents made specific decisions
by attributing behavior to specific artifact lines/rules.
"""

from llmhq_releaseops.attribution.analyzer import AttributionAnalyzer
from llmhq_releaseops.attribution.models import Attribution, Influence

__all__ = ["AttributionAnalyzer", "Attribution", "Influence"]
