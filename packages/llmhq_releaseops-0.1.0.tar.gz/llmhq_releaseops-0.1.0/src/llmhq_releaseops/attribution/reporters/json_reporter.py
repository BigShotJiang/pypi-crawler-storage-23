"""
JSON reporter for attribution results.

Formats Attribution objects as machine-readable JSON.
"""

from __future__ import annotations

import json

from llmhq_releaseops.attribution.models import Attribution


class JSONReporter:
    """Formats attribution results as JSON."""

    def report(self, attribution: Attribution) -> str:
        return json.dumps(attribution.to_dict(), indent=2)
