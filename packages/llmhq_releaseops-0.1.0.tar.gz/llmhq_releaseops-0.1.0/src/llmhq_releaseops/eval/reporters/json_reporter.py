"""JSON report renderer for eval results."""

from __future__ import annotations

import json

from llmhq_releaseops.models.eval_result import EvalReport


class JSONReporter:
    """Generates a JSON report from an EvalReport."""

    @staticmethod
    def render(report: EvalReport) -> str:
        return json.dumps(report.to_dict(), indent=2, sort_keys=False)
