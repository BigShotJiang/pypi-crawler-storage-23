"""
Telemetry module for releaseops.

Provides infrastructure to inject bundle metadata into traces and logs,
enabling downstream attribution and analytics.
"""

from llmhq_releaseops.telemetry.context import (
    bundle_context,
    clear_bundle_metadata,
    get_bundle_metadata,
    set_bundle_metadata,
)
from llmhq_releaseops.telemetry.injector import TelemetryInjector
from llmhq_releaseops.telemetry.models import TelemetryContext

__all__ = [
    "TelemetryContext",
    "TelemetryInjector",
    "bundle_context",
    "get_bundle_metadata",
    "set_bundle_metadata",
    "clear_bundle_metadata",
]
