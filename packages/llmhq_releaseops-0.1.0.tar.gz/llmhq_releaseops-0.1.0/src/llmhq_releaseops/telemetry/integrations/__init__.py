"""Telemetry integrations for external observability platforms."""
