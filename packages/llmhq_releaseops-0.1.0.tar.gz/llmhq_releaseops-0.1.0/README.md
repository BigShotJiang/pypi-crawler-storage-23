# llmhq-releaseops

Release engineering for AI agent behavior — bundle prompts, policies, and model configs into versioned artifacts, then promote them through gated environments.

## Why This Exists

AI agents ship behavior through prompts, policies, and model configurations — not deterministic code. When something breaks in production, there's no `git blame` for "why did the agent start approving refunds it shouldn't?" ReleaseOps brings standard release engineering (bundle, promote, rollback, observe) to these behavior artifacts, so you always know what's running, what changed, and why.

## Install

```bash
pip install llmhq-releaseops
```

| Extra | Install | Adds |
|-------|---------|------|
| `eval` | `pip install llmhq-releaseops[eval]` | LLM-as-judge (OpenAI, Anthropic) |
| `langsmith` | `pip install llmhq-releaseops[langsmith]` | LangSmith trace queries |
| `dev` | `pip install llmhq-releaseops[dev]` | pytest, black, mypy |

## Quickstart

**1. Initialize** your project:

```bash
releaseops init
```

Creates `.releaseops/` with environments (dev, staging, prod), bundle storage, and eval directories.

**2. Create a bundle** from your prompts and model config:

```bash
releaseops bundle create support-agent \
  --artifact system=onboarding:v1.2.0 \
  --model claude-sonnet-4-5 --provider anthropic
```

**3. Promote** through environments:

```bash
releaseops promote promote support-agent 1.0.0 dev
releaseops promote promote support-agent 1.0.0 staging
releaseops promote promote support-agent 1.0.0 prod
```

**4. Load at runtime** in your agent code:

```python
from llmhq_releaseops.runtime import RuntimeLoader

loader = RuntimeLoader()
bundle, metadata = loader.load_bundle("support-agent@prod")
# bundle.model_config, bundle.prompts, bundle.policies — all resolved
# metadata is automatically injected into OpenTelemetry spans
```

**5. Compare versions** when something changes:

```bash
releaseops analytics compare support-agent@1.0.0 support-agent@1.1.0
```

## Key Concepts

- **Bundle** — immutable, content-addressed manifest of prompts + policies + model config (SHA-256 verified)
- **Environment** — named deployment target (dev/staging/prod) with a pinned bundle version
- **Promotion** — moving a bundle through environments with optional quality gates (eval, approval, soak)
- **Telemetry** — automatic injection of bundle metadata into OpenTelemetry spans for production observability
- **Attribution** — trace agent behavior back to specific prompt lines and policy rules that caused it

## Documentation

- [IMPLEMENTATION.md](IMPLEMENTATION.md) — full CLI reference, Python SDK guide, data model reference, architecture details

## License

MIT
