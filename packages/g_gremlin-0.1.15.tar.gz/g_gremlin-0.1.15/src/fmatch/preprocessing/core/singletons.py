import threading
from functools import lru_cache


class ThreadSafeBlooomFilter:
    """Thread-safe singleton wrapper for B2C bloom filter"""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def _initialize(self):
        """Lazy initialization of bloom filter"""
        if not self._initialized:
            with self._lock:
                if not self._initialized:
                    from fmatch.core.b2c_bloom_filter import DomainChecker

                    self._checker = DomainChecker.get_instance()
                    self._initialized = True

    def is_b2c_domain(self, domain: str) -> bool:
        self._initialize()
        return self._checker.is_b2c_domain(domain)


# Factory function
@lru_cache(maxsize=1)
def get_b2c_checker():
    """Get thread-safe B2C domain checker"""
    return ThreadSafeBlooomFilter()
