# preprocessing/config/profiles.py
"""Predefined preprocessing profiles for common data sources"""

from typing import List, Dict, Any

PROFILES = {
    "default": {"name": "Default", "description": "Basic preprocessing", "rules": []}
}


def load_profile(profile_name: str) -> List[Dict[str, Any]]:
    """Load rules from a named profile"""
    profile = PROFILES.get(profile_name, PROFILES["default"])
    return profile.get("rules", [])
