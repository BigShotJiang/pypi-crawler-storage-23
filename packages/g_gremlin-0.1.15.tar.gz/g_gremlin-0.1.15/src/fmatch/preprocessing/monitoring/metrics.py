# preprocessing/monitoring/metrics.py
from dataclasses import dataclass
from typing import List


@dataclass
class StageMetrics:
    """Metrics for individual processing stage"""

    stage_name: str
    start_time: float
    end_time: float
    rows_modified: int
    columns_modified: List[str]
    rules_applied: int
    errors_count: int
