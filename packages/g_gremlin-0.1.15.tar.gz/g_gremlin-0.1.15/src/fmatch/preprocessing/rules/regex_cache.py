import re
import threading


class RegexCache:
    """Thread-safe compiled regex cache"""

    _lock = threading.Lock()
    _cache = {}

    @classmethod
    def get_compiled(cls, pattern: str, flags: int = 0) -> re.Pattern:
        cache_key = (pattern, flags)

        if cache_key in cls._cache:
            return cls._cache[cache_key]

        with cls._lock:
            # Double-check after acquiring lock
            if cache_key not in cls._cache:
                cls._cache[cache_key] = re.compile(pattern, flags)
            return cls._cache[cache_key]
