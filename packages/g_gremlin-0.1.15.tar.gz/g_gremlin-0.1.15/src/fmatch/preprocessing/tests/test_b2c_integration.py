import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
import numpy as np
from preprocessing.config.preprocess_config import PreprocessConfig

class TestB2CIntegration(unittest.TestCase):
    """Ensure new preprocessing doesn't break existing B2C"""
    
    def setUp(self):
        # Test data matching your production scenario
        self.test_df = pd.DataFrame({
            'company_name': ['Acme Inc', 'TechCorp', 'DataCo', 'Analytics LLC'],
            'email': ['john@gmail.com', 'info@techcorp.com', 'data@yahoo.com', 'sales@analytics.com'],
            'domain': ['gmail.com', 'techcorp.com', 'yahoo.com', 'analytics.com']
        })
        
    def test_b2c_function_signature_unchanged(self):
        """Ensure we're calling cleanse_domain_field correctly"""
        from fmatch.core.b2c_engine_integration import cleanse_domain_field
        
        # It should return Series, not dict
        result = cleanse_domain_field(self.test_df['domain'])
        self.assertIsInstance(result, pd.Series)
        self.assertEqual(len(result), len(self.test_df))
        
    def test_b2c_filtering_still_works(self):
        """Ensure B2C domains are still filtered with company fallback"""
        from preprocessing.core.pre_domains import DomainFilter
        from preprocessing.config.preprocess_config import PreprocessConfig
        
        config = PreprocessConfig(strip_b2c_domains=True)
        filter = DomainFilter()
        
        result_df, metrics = filter.apply_domain_filtering(self.test_df.copy(), config)
        
        # B2C domains use company fallback (normalized: lowercase, suffix removed)
        expected = ['acme', 'techcorp.com', 'dataco', 'analytics.com']
        self.assertEqual(result_df['domain'].tolist(), expected)
        
    def test_b2c_filtering_without_fallback(self):
        """Ensure B2C domains are filtered to empty when no company fallback"""
        from preprocessing.core.pre_domains import DomainFilter
        from preprocessing.config.preprocess_config import PreprocessConfig
        
        # Test data WITHOUT company column
        test_df_no_company = pd.DataFrame({
            'domain': ['gmail.com', 'techcorp.com', 'yahoo.com', 'analytics.com']
        })
        
        config = PreprocessConfig(strip_b2c_domains=True)
        filter = DomainFilter()
        
        result_df, metrics = filter.apply_domain_filtering(test_df_no_company.copy(), config)
        
        # Without company fallback, B2C domains should be empty
        self.assertEqual(result_df['domain'].tolist(), ['', 'techcorp.com', '', 'analytics.com'])
        
    def test_company_fallback_preserved(self):
        """Ensure company name fallback still works"""
        from fmatch.core.b2c_engine_integration import cleanse_domain_field
        
        result = cleanse_domain_field(
            self.test_df['email'],
            strip_b2c=True,
            extract_from_email=True,
            company_name_fallback=self.test_df['company_name']
        )
        
        # B2C implementation normalizes company names
        expected = ['acme', 'techcorp.com', 'dataco', 'analytics.com']
        self.assertEqual(result.tolist(), expected)
        
    def test_gui_config_compatibility(self):
        """Ensure GUI configuration structure still works"""
        # Simulate GUI config structure
        gui_config = {
            'enabled': True,
            'extract_from_email': True,
            'company_fallback_enabled': True,
            'stats_tracking': True
        }
        
        config = PreprocessConfig(
            strip_b2c_domains=gui_config['enabled'],
            b2c_config=gui_config
        )
        
        self.assertTrue(config.b2c_enabled)  # Using property alias
        self.assertEqual(config.b2c_config, gui_config)

if __name__ == '__main__':
    unittest.main()