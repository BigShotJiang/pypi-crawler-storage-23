"""Public Suffix List utilities for domain extraction.

This module provides utilities for extracting the registrable root
from domains, handling multi-part TLDs like .co.uk correctly.
"""

from __future__ import annotations

from .root import registrable_root

__all__ = ["registrable_root"]
