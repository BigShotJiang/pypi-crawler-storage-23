"""Core exception hierarchy.

These exceptions are used throughout fmatch.core and can be caught
by consumers (g_gremlin, fmatch.saas) for error handling.
"""

from __future__ import annotations


class CoreError(Exception):
    """Base exception for fmatch.core errors."""
    pass


class ResolutionError(CoreError):
    """Raised when company/domain resolution fails."""
    pass


class ValidationError(CoreError):
    """Raised when input validation fails."""
    pass


class ConfigurationError(CoreError):
    """Raised when configuration is invalid or missing."""
    pass


class ProviderError(CoreError):
    """Raised when an external provider (LLM, API) fails."""
    pass
