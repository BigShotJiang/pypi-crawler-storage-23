"""Core type definitions and interfaces for fmatch.

This module provides shared types used across both CLI (g_gremlin) and
SaaS (fmatch.saas) components. All types here have no infrastructure
dependencies.
"""

from __future__ import annotations

from .company import (
    CompanyProfile,
    ResolutionResult,
    ResolverMetrics,
    CircuitBreaker,
)
from .interfaces import (
    IFoundryGraphClient,
    ILLMProvider,
    IRegistryDataSource,
)
from .errors import (
    CoreError,
    ResolutionError,
    ValidationError,
)

__all__ = [
    # Company types
    "CompanyProfile",
    "ResolutionResult",
    "ResolverMetrics",
    "CircuitBreaker",
    # Interfaces
    "IFoundryGraphClient",
    "ILLMProvider",
    "IRegistryDataSource",
    # Errors
    "CoreError",
    "ResolutionError",
    "ValidationError",
]
