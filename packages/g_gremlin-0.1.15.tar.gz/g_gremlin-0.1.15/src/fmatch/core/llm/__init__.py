"""LLM provider interface for AI-powered operations.

This module provides the base interface for LLM providers. Concrete
implementations (Vertex AI, Ollama, etc.) are in fmatch.saas.providers.

The interface is designed to be simple and focused on JSON generation,
which is the primary use case for company resolution and normalization.
"""

from __future__ import annotations

from .base import (
    BaseLLMProvider,
    LLMResponse,
    LLMError,
)

__all__ = [
    "BaseLLMProvider",
    "LLMResponse",
    "LLMError",
]
