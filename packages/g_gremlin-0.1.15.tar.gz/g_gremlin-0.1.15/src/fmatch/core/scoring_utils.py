"""
Scoring utilities for engine v2.0
"""

import numpy as np


def weighted_present_mean(sim: np.ndarray, w: np.ndarray, present: np.ndarray) -> float:
    """
    Calculate weighted mean using only present (non-null) features.

    Args:
        sim: Similarity scores array
        w: Weights array
        present: Boolean mask of present features

    Returns:
        Weighted mean of present features, or 0.0 if no features present
    """
    ww = w * present
    denom = ww.sum()
    return 0.0 if denom <= 0 else float((sim * ww).sum() / denom)


def aggregate_scores(
    sim_vec: np.ndarray,
    weight_vec: np.ndarray,
    present_mask: np.ndarray,
    mode: str = "weighted_mean",
) -> float:
    """
    Aggregate similarity scores based on configuration.

    Args:
        sim_vec: Array of similarity scores
        weight_vec: Array of weights
        present_mask: Boolean mask of present features
        mode: "weighted_mean" (legacy) or "weighted_present_mean" (new)

    Returns:
        Aggregated score
    """
    if mode == "weighted_present_mean":
        return weighted_present_mean(sim_vec, weight_vec, present_mask)
    else:
        # Legacy: use all weights regardless of presence
        denom = weight_vec.sum()
        return float((sim_vec * weight_vec).sum() / max(denom, 1e-9))
