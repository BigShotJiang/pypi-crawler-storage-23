"""Shared schema for FullEnrich contact enrichment."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class EnrichmentResultStatus(str, Enum):
    ENRICHED = "enriched"
    NOT_FOUND = "not_found"
    ERROR = "error"
    SKIPPED = "skipped"


@dataclass
class ContactEnrichmentInput:
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    linkedin_url: Optional[str] = None
    domain: Optional[str] = None
    company_name: Optional[str] = None
    enrich_fields: Optional[List[str]] = None
    custom: Dict[str, Any] = field(default_factory=dict)
    row_index: Optional[int] = None

    @property
    def is_valid(self) -> bool:
        from .validation import is_valid_contact_input

        return is_valid_contact_input(
            self.email,
            self.linkedin_url,
            first_name=self.first_name,
            last_name=self.last_name,
            domain=self.domain,
            company_name=self.company_name,
        )

    @property
    def firstname(self) -> Optional[str]:
        return self.first_name

    @firstname.setter
    def firstname(self, value: Optional[str]) -> None:
        self.first_name = value

    @property
    def lastname(self) -> Optional[str]:
        return self.last_name

    @lastname.setter
    def lastname(self, value: Optional[str]) -> None:
        self.last_name = value

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        # Backward-compatible aliases
        payload["firstname"] = self.first_name
        payload["lastname"] = self.last_name
        return payload


@dataclass
class ContactEnrichmentResult:
    row_index: Optional[int]
    status: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    # Work email (primary)
    email: Optional[str] = None
    emails: List[str] = field(default_factory=list)
    # Personal email
    personal_email: Optional[str] = None
    personal_emails: List[str] = field(default_factory=list)
    # Phone
    phone: Optional[str] = None
    phones: List[str] = field(default_factory=list)
    linkedin_url: Optional[str] = None
    title: Optional[str] = None
    location: Optional[str] = None
    company_name: Optional[str] = None
    company_domain: Optional[str] = None
    error_message: Optional[str] = None
    custom: Dict[str, Any] = field(default_factory=dict)
    raw: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["firstname"] = self.first_name
        payload["lastname"] = self.last_name
        return payload

    @property
    def firstname(self) -> Optional[str]:
        return self.first_name

    @firstname.setter
    def firstname(self, value: Optional[str]) -> None:
        self.first_name = value

    @property
    def lastname(self) -> Optional[str]:
        return self.last_name

    @lastname.setter
    def lastname(self, value: Optional[str]) -> None:
        self.last_name = value
