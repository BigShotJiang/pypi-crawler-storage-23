"""HTTP client utilities with retry and error handling.

This module provides base classes and utilities for building HTTP
integrations with:
- Automatic retries with exponential backoff
- Rate limit handling (429 with Retry-After)
- Error classification (auth, rate limit, transient)
- Structured logging
"""

from __future__ import annotations

from .base import (
    BaseHTTPClient,
    RetryConfig,
    HTTPError,
    AuthenticationError,
    RateLimitError,
    TransientError,
)

__all__ = [
    "BaseHTTPClient",
    "RetryConfig",
    "HTTPError",
    "AuthenticationError",
    "RateLimitError",
    "TransientError",
]
