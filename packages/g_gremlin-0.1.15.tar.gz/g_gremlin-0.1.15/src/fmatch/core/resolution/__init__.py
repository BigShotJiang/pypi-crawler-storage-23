"""Resolution logic for company names and domains.

This module provides multi-stage company-to-domain resolution with
dependency injection for external services (FoundryGraph, LLM, Registry).
"""

from __future__ import annotations

from .validators import (
    generate_domain_candidates,
    probe_domain_dns,
    validate_domain_dns,
    find_valid_domain_candidate,
)
from .llm_predictor import predict_domain_with_llm
from .company_domain import (
    CompanyDomainResolver,
    resolve_company_domain,
    resolve_company_domains,
    get_override_for_name,
)

__all__ = [
    # Validators
    "generate_domain_candidates",
    "probe_domain_dns",
    "validate_domain_dns",
    "find_valid_domain_candidate",
    # LLM predictor
    "predict_domain_with_llm",
    # Company domain resolver
    "CompanyDomainResolver",
    "resolve_company_domain",
    "resolve_company_domains",
    "get_override_for_name",
]
