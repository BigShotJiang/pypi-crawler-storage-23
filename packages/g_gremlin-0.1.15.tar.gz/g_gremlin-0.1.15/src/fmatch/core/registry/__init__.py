"""Domain family registry for company-to-domain resolution.

This module provides the DomainFamilyRegistry class which manages
domain-to-family mappings for company resolution. The registry
accepts a data source adapter to allow different backing stores
(YAML files, databases, in-memory, etc.).
"""

from __future__ import annotations

from .domain_family import (
    DomainFamilyRegistry,
    DomainRelation,
)

__all__ = [
    "DomainFamilyRegistry",
    "DomainRelation",
]
