"""State/province code normalization using static mappings.

This module provides state/province mapping without any external
dependencies - no LLM. It uses only static lookup tables.
"""

from __future__ import annotations

from typing import Optional

from ..heuristics import US_STATE_MAP, CA_PROVINCE_MAP, AU_STATE_MAP


# Reverse mappings: Code → Full Name
US_STATE_NAMES = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "DC": "District of Columbia",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "ME": "Maine",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming",
    "PR": "Puerto Rico",
    "GU": "Guam",
    "AS": "American Samoa",
    "VI": "U.S. Virgin Islands",
}

CA_PROVINCE_NAMES = {
    "AB": "Alberta",
    "BC": "British Columbia",
    "MB": "Manitoba",
    "NB": "New Brunswick",
    "NL": "Newfoundland and Labrador",
    "NS": "Nova Scotia",
    "ON": "Ontario",
    "PE": "Prince Edward Island",
    "QC": "Quebec",
    "SK": "Saskatchewan",
    "NT": "Northwest Territories",
    "NU": "Nunavut",
    "YT": "Yukon",
}

AU_STATE_NAMES = {
    "NSW": "New South Wales",
    "VIC": "Victoria",
    "QLD": "Queensland",
    "SA": "South Australia",
    "WA": "Western Australia",
    "TAS": "Tasmania",
    "ACT": "Australian Capital Territory",
    "NT": "Northern Territory",
}


def map_state_code(value: str, country: str = "US") -> Optional[str]:
    """Map state code or name to full state/province name.

    Handles both directions:
    - Code → Full name: "CA" → "California"
    - Full name → Full name: "california" → "California"

    Args:
        value: State code or name (case-insensitive)
        country: Country code: "US", "CA" (Canada), or "AU" (Australia)

    Returns:
        Full state/province name, or None if not found
    """
    v = (value or "").strip()
    if not v:
        return None

    country = country.upper()

    # Try uppercase match first (code → name)
    v_upper = v.upper()
    if country == "US" and v_upper in US_STATE_NAMES:
        return US_STATE_NAMES[v_upper]
    if country == "CA" and v_upper in CA_PROVINCE_NAMES:
        return CA_PROVINCE_NAMES[v_upper]
    if country == "AU" and v_upper in AU_STATE_NAMES:
        return AU_STATE_NAMES[v_upper]

    # Try case-insensitive match for full names
    v_lower = v.lower()
    if country == "US":
        code = US_STATE_MAP.get(v_lower)
        return US_STATE_NAMES.get(code) if code else None
    if country == "CA":
        code = CA_PROVINCE_MAP.get(v_lower)
        return CA_PROVINCE_NAMES.get(code) if code else None
    if country == "AU":
        code = AU_STATE_MAP.get(v_lower)
        return AU_STATE_NAMES.get(code) if code else None

    # Default fallback: try US
    code = US_STATE_MAP.get(v_lower)
    return US_STATE_NAMES.get(code) if code else None


def normalize_state(value: str, country: str = "US") -> str:
    """Normalize state/province to full name.

    Args:
        value: State code or name (case-insensitive)
        country: Country code: "US", "CA" (Canada), or "AU" (Australia)

    Returns:
        Full state/province name, or empty string if not found

    Note:
        This function does NOT use LLM fallback.
        For LLM-enhanced normalization, use the saas normalize_state operator.
    """
    result = map_state_code(value, country)
    return result or ""
