"""Pure normalization utilities - no external dependencies.

This module provides text normalization functions that use only
heuristics and static data. No LLM, no resolution, no external APIs.

Functions:
- normalize_text: Unicode NFKC normalization
- normalize_company_text: Company name normalization (heuristics only)
- normalize_title_text: Job title normalization (heuristics only)
- normalize_state: State/province code mapping
- normalize_domain: Domain/URL/email → bare domain
"""

from __future__ import annotations

from .text import normalize_text
from .company import normalize_company_text, title_case_tokens
from .title import (
    normalize_title_text,
    classify_title_seniority,
    classify_title_department,
)
from .state import normalize_state, map_state_code
from .domain import normalize_domain

__all__ = [
    # Text normalization
    "normalize_text",
    # Company normalization
    "normalize_company_text",
    "title_case_tokens",
    # Title normalization
    "normalize_title_text",
    "classify_title_seniority",
    "classify_title_department",
    # State normalization
    "normalize_state",
    "map_state_code",
    # Domain normalization
    "normalize_domain",
]
