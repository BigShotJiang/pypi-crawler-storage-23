"""FoundryGraph client for company enrichment.

This module provides HTTP-based access to the FoundryGraph API for:
- Domain lookup (domain -> company profile)
- Name search (company name -> domain + profile)

Note: This is an HTTP-only client. Local DuckDB serving and GCS
artifact management are in fmatch.saas.adapters.
"""

from __future__ import annotations

from .client import (
    FoundryGraphClient,
    FoundryGraphConfig,
    FoundryGraphError,
)

__all__ = [
    "FoundryGraphClient",
    "FoundryGraphConfig",
    "FoundryGraphError",
]
