"""Heuristics data constants for normalization and classification.

This module contains pure data structures with no external dependencies.
All constants are used for text normalization, company classification,
and domain resolution.
"""

from __future__ import annotations

import re


# =============================================================================
# Company Name Normalization
# =============================================================================

LEGAL_SUFFIXES = {
    "inc",
    "inc.",
    "incorporated",
    "llc",
    "llc.",
    "llp",
    "llp.",
    "lp",
    "lp.",
    "ltd",
    "ltd.",
    "limited",
    "corp",
    "corp.",
    "corporation",
    "company",
    "co",
    "co.",
    "gmbh",
    "bvba",
    "s.a.",
    "s.a",
    "sa",
    "srl",
    "plc",
    "s.p.a.",
    "s.p.a",
    "bv",
    "ag",
    "oy",
    "ab",
    "nv",
    "spa",
    "sarl",
    "sas",
    "pte",
    "pty",
    "kk",
    "oyj",
    "aps",
    "as",
    "oy ab",
}

ABBREV_EXPANSIONS = {
    "intl": "international",
    "int'l": "international",
    "intl.": "international",
    "tech": "technologies",
    "tech.": "technologies",
    "mfg": "manufacturing",
    "svc": "services",
    "svcs": "services",
    "dept": "department",
    "biz": "business",
    "dev": "development",
    "ops": "operations",
    "corp": "corporation",
    "corp.": "corporation",
    "co": "company",
    "co.": "company",
}

COMPANY_STOPWORDS = {
    "the",
    "and",
    "of",
    "co",
    "company",
    "holdings",
    "group",
    "intl",
    "inc",
    "llc",
    "ltd",
    "com",
    "net",
    "org",
    "io",
    "sa",
}


# =============================================================================
# State/Province Mappings
# =============================================================================

US_STATE_MAP = {
    # States + DC + territories
    "alabama": "AL",
    "al": "AL",
    "alaska": "AK",
    "ak": "AK",
    "arizona": "AZ",
    "az": "AZ",
    "arkansas": "AR",
    "ar": "AR",
    "california": "CA",
    "ca": "CA",
    "colorado": "CO",
    "co": "CO",
    "connecticut": "CT",
    "ct": "CT",
    "delaware": "DE",
    "de": "DE",
    "district of columbia": "DC",
    "dc": "DC",
    "florida": "FL",
    "fl": "FL",
    "georgia": "GA",
    "ga": "GA",
    "hawaii": "HI",
    "hi": "HI",
    "idaho": "ID",
    "id": "ID",
    "illinois": "IL",
    "il": "IL",
    "indiana": "IN",
    "in": "IN",
    "iowa": "IA",
    "ia": "IA",
    "kansas": "KS",
    "ks": "KS",
    "kentucky": "KY",
    "ky": "KY",
    "louisiana": "LA",
    "la": "LA",
    "maine": "ME",
    "me": "ME",
    "maryland": "MD",
    "md": "MD",
    "massachusetts": "MA",
    "ma": "MA",
    "michigan": "MI",
    "mi": "MI",
    "minnesota": "MN",
    "mn": "MN",
    "mississippi": "MS",
    "ms": "MS",
    "missouri": "MO",
    "mo": "MO",
    "montana": "MT",
    "mt": "MT",
    "nebraska": "NE",
    "ne": "NE",
    "nevada": "NV",
    "nv": "NV",
    "new hampshire": "NH",
    "nh": "NH",
    "new jersey": "NJ",
    "nj": "NJ",
    "new mexico": "NM",
    "nm": "NM",
    "new york": "NY",
    "ny": "NY",
    "north carolina": "NC",
    "nc": "NC",
    "north dakota": "ND",
    "nd": "ND",
    "ohio": "OH",
    "oh": "OH",
    "oklahoma": "OK",
    "ok": "OK",
    "oregon": "OR",
    "or": "OR",
    "pennsylvania": "PA",
    "pa": "PA",
    "rhode island": "RI",
    "ri": "RI",
    "south carolina": "SC",
    "sc": "SC",
    "south dakota": "SD",
    "sd": "SD",
    "tennessee": "TN",
    "tn": "TN",
    "texas": "TX",
    "tx": "TX",
    "utah": "UT",
    "ut": "UT",
    "vermont": "VT",
    "vt": "VT",
    "virginia": "VA",
    "va": "VA",
    "washington": "WA",
    "wa": "WA",
    "west virginia": "WV",
    "wv": "WV",
    "wisconsin": "WI",
    "wi": "WI",
    "wyoming": "WY",
    "wy": "WY",
    "puerto rico": "PR",
    "pr": "PR",
    "guam": "GU",
    "gu": "GU",
    "american samoa": "AS",
    "as": "AS",
    "u.s. virgin islands": "VI",
    "usvi": "VI",
    "vi": "VI",
}

CA_PROVINCE_MAP = {
    "alberta": "AB",
    "ab": "AB",
    "british columbia": "BC",
    "bc": "BC",
    "manitoba": "MB",
    "mb": "MB",
    "new brunswick": "NB",
    "nb": "NB",
    "newfoundland and labrador": "NL",
    "nl": "NL",
    "nova scotia": "NS",
    "ns": "NS",
    "ontario": "ON",
    "on": "ON",
    "prince edward island": "PE",
    "pe": "PE",
    "quebec": "QC",
    "qc": "QC",
    "saskatchewan": "SK",
    "sk": "SK",
    "northwest territories": "NT",
    "nt": "NT",
    "nunavut": "NU",
    "nu": "NU",
    "yukon": "YT",
    "yt": "YT",
}

AU_STATE_MAP = {
    "new south wales": "NSW",
    "nsw": "NSW",
    "victoria": "VIC",
    "vic": "VIC",
    "queensland": "QLD",
    "qld": "QLD",
    "western australia": "WA",
    "wa": "WA",
    "south australia": "SA",
    "sa": "SA",
    "tasmania": "TAS",
    "tas": "TAS",
    "australian capital territory": "ACT",
    "act": "ACT",
    "northern territory": "NT",
    "nt": "NT",
}


# =============================================================================
# Email Domain Classification
# =============================================================================

FREEMAIL_DOMAINS = {
    "gmail.com",
    "yahoo.com",
    "hotmail.com",
    "outlook.com",
    "aol.com",
    "icloud.com",
    "me.com",
    "proton.me",
    "protonmail.com",
    "gmx.com",
    "gmx.net",
    "mail.com",
    "zoho.com",
    "yandex.ru",
    "live.com",
    "msn.com",
    "comcast.net",
    "verizon.net",
    "att.net",
    "sbcglobal.net",
}

TEMP_DOMAINS = {
    # Representative set; TODO sync weekly disposable list
    "10minutemail.com",
    "guerrillamail.com",
    "mailinator.com",
    "temp-mail.org",
    "yopmail.com",
    "throwawaymail.com",
    "getnada.com",
    "dispostable.com",
    "trashmail.com",
}


# =============================================================================
# Title Classification Rules
# =============================================================================

TITLE_SENIORITY_RULES = [
    (re.compile(r"\b(chief|cxo|ceo|cto|cfo|coo|cso|cmo|cio|cdo|cpo)\b", re.I), "CXO"),
    (re.compile(r"\b(vp|vice president|svp|evp)\b", re.I), "VP"),
    (re.compile(r"\b(head|director|dir\.?|principal)\b", re.I), "Director"),
    (re.compile(r"\b(manager|mgr\.?|lead)\b", re.I), "Manager"),
    (re.compile(r"\b(owner|founder|proprietor)\b", re.I), "Owner"),
]

TITLE_DEPT_RULES = [
    (
        re.compile(
            r"\b(sales|biz dev|business development|account( |-)exec|ae|bdm)\b", re.I
        ),
        "Sales",
    ),
    (re.compile(r"\b(marketing|demand gen|growth)\b", re.I), "Marketing"),
    (
        re.compile(
            r"\b(engineer(?:ing)?|developer|software|devops|sre|qa|data scientist)\b",
            re.I,
        ),
        "Engineering",
    ),
    (re.compile(r"\b(finance|accounting|cpa|controller)\b", re.I), "Finance"),
    (re.compile(r"\b(hr|people ops|talent|recruit)\b", re.I), "HR"),
    (re.compile(r"\b(operations|ops|supply chain)\b", re.I), "Operations"),
    (re.compile(r"\b(it|infra(structure)?|network|sysadmin)\b", re.I), "IT"),
    (re.compile(r"\b(product|pm|product manager)\b", re.I), "Product"),
    (
        re.compile(r"\b(customer success|cs|support|helpdesk)\b", re.I),
        "Customer Success",
    ),
    (re.compile(r"\b(legal|counsel|attorney)\b", re.I), "Legal"),
]


# =============================================================================
# Known Company Domains (Hardcoded Fallback)
# =============================================================================

KNOWN_COMPANY_DOMAINS = {
    "google": "google.com",
    "microsoft": "microsoft.com",
    "ibm": "ibm.com",
    "cisco": "cisco.com",
    "amazon": "amazon.com",
    "meta": "meta.com",
    "facebook": "facebook.com",
    "apple": "apple.com",
    "adobe": "adobe.com",
    "oracle": "oracle.com",
}
