"""Heuristics data for normalization and resolution.

This module contains pure data structures (sets, dicts, compiled regexes)
used for text normalization and classification. No external dependencies.
"""

from __future__ import annotations

from .data import (
    # Company normalization
    LEGAL_SUFFIXES,
    ABBREV_EXPANSIONS,
    COMPANY_STOPWORDS,
    KNOWN_COMPANY_DOMAINS,
    # State/province maps
    US_STATE_MAP,
    CA_PROVINCE_MAP,
    AU_STATE_MAP,
    # Email classification
    FREEMAIL_DOMAINS,
    TEMP_DOMAINS,
    # Title classification
    TITLE_SENIORITY_RULES,
    TITLE_DEPT_RULES,
)

__all__ = [
    # Company normalization
    "LEGAL_SUFFIXES",
    "ABBREV_EXPANSIONS",
    "COMPANY_STOPWORDS",
    "KNOWN_COMPANY_DOMAINS",
    # State/province maps
    "US_STATE_MAP",
    "CA_PROVINCE_MAP",
    "AU_STATE_MAP",
    # Email classification
    "FREEMAIL_DOMAINS",
    "TEMP_DOMAINS",
    # Title classification
    "TITLE_SENIORITY_RULES",
    "TITLE_DEPT_RULES",
]
