"""US geographic centroids for proximity calculations."""

from __future__ import annotations

import math
from typing import Dict, Optional, Tuple

US_STATE_CENTROIDS: Dict[str, Tuple[float, float]] = {
    "AL": (32.806671, -86.791130),
    "AK": (61.370716, -152.404419),
    "AZ": (33.729759, -111.431221),
    "AR": (34.969704, -92.373123),
    "CA": (36.116203, -119.681564),
    "CO": (39.059811, -105.311104),
    "CT": (41.597782, -72.755371),
    "DE": (39.318523, -75.507141),
    "DC": (38.897438, -77.026817),
    "FL": (27.766279, -81.686783),
    "GA": (33.040619, -83.643074),
    "HI": (21.094318, -157.498337),
    "ID": (44.240459, -114.478828),
    "IL": (40.349457, -88.986137),
    "IN": (39.849426, -86.258278),
    "IA": (42.011539, -93.210526),
    "KS": (38.526600, -96.726486),
    "KY": (37.668140, -84.670067),
    "LA": (31.169546, -91.867805),
    "ME": (44.693947, -69.381927),
    "MD": (39.063946, -76.802101),
    "MA": (42.230171, -71.530106),
    "MI": (43.326618, -84.536095),
    "MN": (45.694454, -93.900192),
    "MS": (32.741646, -89.678696),
    "MO": (38.456085, -92.288368),
    "MT": (46.921925, -110.454353),
    "NE": (41.125370, -98.268082),
    "NV": (38.313515, -117.055374),
    "NH": (43.452492, -71.563896),
    "NJ": (40.298904, -74.521011),
    "NM": (34.840515, -106.248482),
    "NY": (42.165726, -74.948051),
    "NC": (35.630066, -79.806419),
    "ND": (47.528912, -99.784012),
    "OH": (40.388783, -82.764915),
    "OK": (35.565342, -96.928917),
    "OR": (44.572021, -122.070938),
    "PA": (40.590752, -77.209755),
    "RI": (41.680893, -71.511780),
    "SC": (33.856892, -80.945007),
    "SD": (44.299782, -99.438828),
    "TN": (35.747845, -86.692345),
    "TX": (31.054487, -97.563461),
    "UT": (40.150032, -111.862434),
    "VT": (44.045876, -72.710686),
    "VA": (37.769337, -78.169968),
    "WA": (47.400902, -121.490494),
    "WV": (38.491226, -80.954453),
    "WI": (44.268543, -89.616508),
    "WY": (42.755966, -107.302490),
    "PR": (18.220833, -66.590149),
    "GU": (13.444304, 144.793731),
    "VI": (18.335765, -64.896335),
}

MAJOR_CITY_CENTROIDS: Dict[str, Tuple[float, float]] = {
    "san francisco, ca": (37.7749, -122.4194),
    "los angeles, ca": (34.0522, -118.2437),
    "new york, ny": (40.7128, -74.0060),
    "nyc, ny": (40.7128, -74.0060),
    "chicago, il": (41.8781, -87.6298),
    "houston, tx": (29.7604, -95.3698),
    "dallas, tx": (32.7767, -96.7970),
    "denver, co": (39.7392, -104.9903),
    "seattle, wa": (47.6062, -122.3321),
    "boston, ma": (42.3601, -71.0589),
    "atlanta, ga": (33.7490, -84.3880),
    "miami, fl": (25.7617, -80.1918),
    "phoenix, az": (33.4484, -112.0740),
    "philadelphia, pa": (39.9526, -75.1652),
    "detroit, mi": (42.3314, -83.0458),
    "minneapolis, mn": (44.9778, -93.2650),
    "portland, or": (45.5051, -122.6750),
    "nashville, tn": (36.1627, -86.7816),
    "charlotte, nc": (35.2271, -80.8431),
    "salt lake city, ut": (40.7608, -111.8910),
    "san diego, ca": (32.7157, -117.1611),
    "austin, tx": (30.2672, -97.7431),
    "san antonio, tx": (29.4241, -98.4936),
    "raleigh, nc": (35.7796, -78.6382),
    "tampa, fl": (27.9506, -82.4572),
    "san francisco": (37.7749, -122.4194),
    "los angeles": (34.0522, -118.2437),
    "new york": (40.7128, -74.0060),
    "chicago": (41.8781, -87.6298),
    "houston": (29.7604, -95.3698),
    "dallas": (32.7767, -96.7970),
    "denver": (39.7392, -104.9903),
    "seattle": (47.6062, -122.3321),
    "boston": (42.3601, -71.0589),
    "atlanta": (33.7490, -84.3880),
    "miami": (25.7617, -80.1918),
    "phoenix": (33.4484, -112.0740),
    "philadelphia": (39.9526, -75.1652),
    "detroit": (42.3314, -83.0458),
    "georgia": (33.040619, -83.643074),
    "nyc": (40.7128, -74.0060),
}


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate great-circle distance in miles."""
    radius = 3959
    lat1_rad, lat2_rad = math.radians(lat1), math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    a = (
        math.sin(delta_lat / 2) ** 2
        + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
    )
    return radius * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def get_state_centroid(state_code: str) -> Optional[Tuple[float, float]]:
    """Get centroid for a US state code."""
    if not state_code:
        return None
    return US_STATE_CENTROIDS.get(state_code.upper())


def parse_seed_region_to_coords(seed_region: str) -> Optional[Tuple[float, float]]:
    """
    Parse rep seed_region to coordinates.
    Supports: "CA", "California", "San Francisco", "San Francisco, CA".
    """
    if not seed_region:
        return None
    seed = seed_region.strip()
    seed_lower = seed.lower()

    if seed_lower in MAJOR_CITY_CENTROIDS:
        return MAJOR_CITY_CENTROIDS[seed_lower]

    if "," in seed:
        city_part, state_part = seed.rsplit(",", 1)
        city_state_key = f"{city_part.strip().lower()}, {state_part.strip().lower()}"
        if city_state_key in MAJOR_CITY_CENTROIDS:
            return MAJOR_CITY_CENTROIDS[city_state_key]
        state_code = state_part.strip().upper()
        if len(state_code) == 2 and state_code in US_STATE_CENTROIDS:
            return US_STATE_CENTROIDS[state_code]

    if len(seed) == 2:
        state_code = seed.upper()
        if state_code in US_STATE_CENTROIDS:
            return US_STATE_CENTROIDS[state_code]

    try:
        from fmatch.core.heuristics.data import US_STATE_MAP
    except Exception:
        US_STATE_MAP = None

    if US_STATE_MAP:
        state_code = US_STATE_MAP.get(seed_lower)
        if state_code and state_code in US_STATE_CENTROIDS:
            return US_STATE_CENTROIDS[state_code]

    return None


def get_market_centroid(market_key: str, geo_key_type: str) -> Optional[Tuple[float, float]]:
    """Get centroid for a market key based on geo_key_type."""
    if not market_key or market_key == "(Unknown)":
        return None

    if geo_key_type == "state":
        return US_STATE_CENTROIDS.get(market_key.upper())

    if geo_key_type == "city_state":
        key_lower = market_key.lower()
        if key_lower in MAJOR_CITY_CENTROIDS:
            return MAJOR_CITY_CENTROIDS[key_lower]
        if "," in market_key:
            state_part = market_key.rsplit(",", 1)[1].strip().upper()
            return US_STATE_CENTROIDS.get(state_part)

    return None
