"""HubSpot integration for FoundryOps FuzzyMatcher."""

from .core import HubSpotIntegration, HubSpotCredentials, ApiLimits
from .bulk_api import HubSpotBulkAPI
from .data_validation import HubSpotDataValidator
from .workflows import HubSpotWorkflowEngine
from .gui_integration import (
    show_hubspot_connection_dialog,
    show_hubspot_object_picker,
    show_hubspot_workflow_dialog,
    add_hubspot_menu_items,
)

__all__ = [
    "HubSpotIntegration",
    "HubSpotCredentials",
    "ApiLimits",
    "HubSpotBulkAPI",
    "HubSpotDataValidator",
    "HubSpotWorkflowEngine",
    "show_hubspot_connection_dialog",
    "show_hubspot_object_picker",
    "show_hubspot_workflow_dialog",
    "add_hubspot_menu_items",
]
