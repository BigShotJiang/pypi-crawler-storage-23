"""
Salesforce Integration Package for FoundryMatch
==============================================
Comprehensive Salesforce integration with OAuth, workflows, and compliance.
"""

from .core import (
    SalesforceIntegration,
    SalesforceCredentials,
    SalesforceObject,
    SalesforceField,
    ApiLimits,
)
from .workflows import (
    SalesforceWorkflowEngine,
    DedupeWorkflowConfig,
    LeadToAccountConfig,
)
from .data_validation import SalesforceDataValidator, ValidationResult
from .audit_compliance import AuditLogger, SalesforceAuditIntegration
from .bulk_api import SalesforceBulkAPI

__all__ = [
    "SalesforceIntegration",
    "SalesforceCredentials",
    "SalesforceObject",
    "SalesforceField",
    "ApiLimits",
    "SalesforceWorkflowEngine",
    "DedupeWorkflowConfig",
    "LeadToAccountConfig",
    "SalesforceDataValidator",
    "ValidationResult",
    "AuditLogger",
    "SalesforceAuditIntegration",
    "SalesforceBulkAPI",
]
