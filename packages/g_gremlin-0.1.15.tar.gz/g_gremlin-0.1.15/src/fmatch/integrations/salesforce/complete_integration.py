"""
Complete Salesforce Integration Example for FoundryMatch
=======================================================
Demonstrates how all Salesforce integration components work together
in a real-world scenario.
"""

import asyncio
import logging
import pandas as pd
from datetime import datetime
from typing import Dict, Optional, Any

# Import all Salesforce integration modules
from .core import SalesforceIntegration
from .bulk_api import SalesforceBulkAPI, estimate_bulk_api_benefits
from .data_validation import (
    SalesforceDataValidator,
    validate_before_salesforce_operation,
    fix_auto_fixable_issues,
)
from .workflows import (
    SalesforceWorkflowEngine,
    create_dedupe_workflow_config,
    create_lead_to_account_config,
)
from .audit_compliance import (
    AuditLogger,
    SalesforceAuditIntegration,
    AuditEvent,
    AuditEventType,
    ComplianceLevel,
    create_audit_logger,
)

log = logging.getLogger(__name__)


class CompleteSalesforceIntegration:
    """
    Complete integration example showing bullet-proof Salesforce workflows
    with validation, audit trails, and rollback capabilities.
    """

    def __init__(self):
        self.sf_integration: Optional[SalesforceIntegration] = None
        self.bulk_api: Optional[SalesforceBulkAPI] = None
        self.validator: Optional[SalesforceDataValidator] = None
        self.workflow_engine: Optional[SalesforceWorkflowEngine] = None
        self.audit_logger: Optional[AuditLogger] = None
        self.audit_integration: Optional[SalesforceAuditIntegration] = None

    async def initialize(
        self,
        client_id: str,
        client_secret: str,
        is_sandbox: bool = True,
        user_id: str = "demo_user",
    ) -> bool:
        """
        Initialize all Salesforce integration components.

        Args:
            client_id: Salesforce Connected App Client ID
            client_secret: Salesforce Connected App Client Secret
            is_sandbox: Whether to connect to sandbox environment
            user_id: User ID for audit logging

        Returns:
            bool: True if initialization successful
        """
        try:
            log.info("🔧 Initializing Complete Salesforce Integration...")

            # 1. Initialize core Salesforce integration
            self.sf_integration = SalesforceIntegration()

            # Authenticate with OAuth
            auth_success = await self.sf_integration.authenticate_oauth(
                client_id, client_secret, is_sandbox
            )

            if not auth_success:
                log.error("❌ Salesforce authentication failed")
                return False

            log.info("✅ Salesforce authentication successful")

            # 2. Initialize Bulk API
            self.bulk_api = SalesforceBulkAPI(self.sf_integration)
            log.info("✅ Bulk API initialized")

            # 3. Initialize data validator
            self.validator = SalesforceDataValidator(self.sf_integration)
            log.info("✅ Data validator initialized")

            # 4. Initialize workflow engine
            self.workflow_engine = SalesforceWorkflowEngine(self.sf_integration)
            log.info("✅ Workflow engine initialized")

            # 5. Initialize audit logging
            self.audit_logger = await create_audit_logger()
            self.audit_logger.set_user_context(user_id)
            self.audit_integration = SalesforceAuditIntegration(
                self.audit_logger, self.sf_integration
            )
            log.info("✅ Audit logging initialized")

            # 6. Test connection
            connected, message = await self.sf_integration.test_connection()
            if not connected:
                log.error(f"❌ Connection test failed: {message}")
                return False

            log.info("🎉 Complete Salesforce Integration initialized successfully!")
            log.info(f"📊 Connected to: {message}")

            return True

        except Exception as e:
            log.error(f"❌ Initialization failed: {e}", exc_info=True)
            return False

    async def execute_lead_deduplication_workflow(
        self, source_data: pd.DataFrame, dry_run: bool = True
    ) -> Dict[str, Any]:
        """
        Execute a complete Lead deduplication workflow with all safety controls.

        Args:
            source_data: DataFrame with Lead data to deduplicate
            dry_run: Whether to run in dry-run mode (no actual changes)

        Returns:
            Dict with workflow results and metadata
        """
        workflow_id = f"lead_dedupe_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        try:
            log.info(f"🚀 Starting Lead Deduplication Workflow: {workflow_id}")

            # Phase 1: Pre-flight validation and quality assessment
            log.info("📋 Phase 1: Data Validation and Quality Assessment")

            # Audit workflow start
            await self.audit_integration.audit_workflow_start(
                workflow_id,
                "Lead",
                "dedupe",
                source_data,
                compliance_levels=[ComplianceLevel.GDPR, ComplianceLevel.SOX],
            )

            # Data quality analysis
            quality_report = await self.validator.analyze_data_quality(
                source_data, "Lead"
            )
            log.info(f"📊 Data Quality Score: {quality_report.overall_score:.1f}/100")

            if quality_report.overall_score < 70:
                log.warning("⚠️ Low data quality score - review recommendations")
                for rec in quality_report.recommendations[:3]:
                    log.warning(f"   💡 {rec}")

            # Comprehensive validation
            validation_result = await validate_before_salesforce_operation(
                self.sf_integration, source_data, "Lead", "upsert"
            )

            log.info(
                f"✅ Validation complete: {len(validation_result.errors)} errors, "
                f"{len(validation_result.warnings)} warnings"
            )

            if validation_result.errors:
                log.error("❌ Validation errors found - cannot proceed:")
                for error in validation_result.errors[:3]:
                    log.error(f"   🚫 {error.message}")
                return {"success": False, "error": "Validation failed"}

            # Auto-fix fixable issues
            if any(issue.auto_fixable for issue in validation_result.issues):
                log.info("🔧 Auto-fixing data issues...")
                source_data = fix_auto_fixable_issues(source_data, validation_result)

            # Phase 2: Fuzzy Matching (this would integrate with your existing engine)
            log.info("🔍 Phase 2: Fuzzy Matching Analysis")

            # Simulate match results (in real implementation, this comes from FoundryMatch engine)
            matches_df = self._simulate_match_results(source_data)
            log.info(f"🎯 Found {len(matches_df)} potential duplicate matches")

            # Phase 3: Workflow Configuration and Preview
            log.info("⚙️ Phase 3: Workflow Configuration and Preview")

            # Create workflow configuration
            dedupe_config = create_dedupe_workflow_config(
                object_name="Lead",
                master_record_strategy="oldest",
                delete_duplicates=False,  # Use merge for safety
                dry_run=dry_run,
                backup_enabled=True,
            )

            # Preview workflow impact
            preview_result = await self.workflow_engine.preview_dedupe_workflow(
                dedupe_config, matches_df
            )

            log.info("📊 Preview Results:")
            log.info(f"   Total Candidates: {preview_result.total_candidates:,}")
            log.info(f"   Estimated Updates: {preview_result.estimated_updates:,}")
            log.info(f"   Estimated API Calls: {preview_result.estimated_api_calls:,}")

            if preview_result.potential_issues:
                log.warning("⚠️ Potential Issues Detected:")
                for issue in preview_result.potential_issues:
                    log.warning(f"   🚨 {issue}")

            # Estimate Bulk API benefits
            bulk_benefits = estimate_bulk_api_benefits(
                len(matches_df), len(matches_df.columns)
            )

            if bulk_benefits["recommended"]:
                log.info(f"💡 {bulk_benefits['reasoning']}")
                log.info(f"   API Call Savings: {bulk_benefits['api_call_savings']:,}")

            # Phase 4: Execution (if not dry run)
            execution_result = None
            if not dry_run:
                log.info("🎬 Phase 4: Workflow Execution")

                async def progress_callback(message: str, percent: float):
                    log.info(f"   📈 {percent:.1f}% - {message}")

                execution_result = await self.workflow_engine.execute_dedupe_workflow(
                    dedupe_config, matches_df, progress_callback
                )

                # Audit workflow completion
                await self.audit_integration.audit_workflow_completion(
                    execution_result,
                    compliance_levels=[ComplianceLevel.GDPR, ComplianceLevel.SOX],
                )

                if execution_result.success:
                    log.info("✅ Workflow completed successfully!")
                    log.info(
                        f"   Records Processed: {execution_result.records_processed:,}"
                    )
                    log.info(f"   Records Merged: {execution_result.records_merged:,}")
                    log.info(f"   API Calls Used: {execution_result.api_calls_used:,}")
                    log.info(
                        f"   Execution Time: {execution_result.execution_time:.1f}s"
                    )

                    if execution_result.backup_file:
                        log.info(f"   Backup Created: {execution_result.backup_file}")
                else:
                    log.error(f"❌ Workflow failed: {execution_result.error_message}")
            else:
                log.info("🔍 Dry run mode - no actual changes made")

            # Phase 5: Compliance and Audit Trail
            log.info("📜 Phase 5: Compliance and Audit")

            # Generate compliance report
            compliance_report = await self.audit_logger.generate_compliance_report(
                ComplianceLevel.GDPR
            )

            log.info(f"📋 Compliance Status: {compliance_report.certification_status}")
            if compliance_report.compliance_violations:
                log.warning(
                    f"⚠️ Found {len(compliance_report.compliance_violations)} compliance issues"
                )

            # Return comprehensive results
            return {
                "success": True,
                "workflow_id": workflow_id,
                "data_quality": {
                    "overall_score": quality_report.overall_score,
                    "completeness": quality_report.completeness_score,
                    "validity": quality_report.validity_score,
                    "recommendations": quality_report.recommendations[:5],
                },
                "validation": {
                    "is_valid": validation_result.is_valid,
                    "errors": len(validation_result.errors),
                    "warnings": len(validation_result.warnings),
                    "auto_fixed_issues": len(
                        [i for i in validation_result.issues if i.auto_fixable]
                    ),
                },
                "preview": {
                    "total_candidates": preview_result.total_candidates,
                    "estimated_updates": preview_result.estimated_updates,
                    "estimated_api_calls": preview_result.estimated_api_calls,
                    "potential_issues": preview_result.potential_issues,
                },
                "execution": {
                    "dry_run": dry_run,
                    "records_processed": execution_result.records_processed
                    if execution_result
                    else 0,
                    "records_merged": execution_result.records_merged
                    if execution_result
                    else 0,
                    "success": execution_result.success if execution_result else None,
                    "backup_file": execution_result.backup_file
                    if execution_result
                    else None,
                },
                "compliance": {
                    "status": compliance_report.certification_status,
                    "violations": len(compliance_report.compliance_violations),
                    "audit_events": compliance_report.total_events,
                },
                "bulk_api_analysis": bulk_benefits,
            }

        except Exception as e:
            log.error(f"❌ Workflow failed: {e}", exc_info=True)

            # Audit the failure
            await self.audit_logger.log_event(
                AuditEvent(
                    event_type=AuditEventType.WORKFLOW_FAILED,
                    workflow_id=workflow_id,
                    error_message=str(e),
                    compliance_tags=[ComplianceLevel.GDPR, ComplianceLevel.SOX],
                )
            )

            return {"success": False, "workflow_id": workflow_id, "error": str(e)}

    async def execute_lead_to_account_workflow(
        self,
        leads_df: pd.DataFrame,
        accounts_df: pd.DataFrame,
        matches_df: pd.DataFrame,
        confidence_threshold: float = 85.0,
        dry_run: bool = True,
    ) -> Dict[str, Any]:
        """
        Execute Lead-to-Account matching workflow with comprehensive validation.

        Args:
            leads_df: DataFrame with Lead data
            accounts_df: DataFrame with Account data
            matches_df: DataFrame with match results from FoundryMatch
            confidence_threshold: Minimum confidence threshold for matches
            dry_run: Whether to run in dry-run mode

        Returns:
            Dict with workflow results
        """
        workflow_id = f"lead_to_account_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        try:
            log.info(f"🔗 Starting Lead-to-Account Workflow: {workflow_id}")

            # Phase 1: Validation
            log.info("📋 Phase 1: Cross-Object Validation")

            # Audit workflow start
            await self.audit_integration.audit_workflow_start(
                workflow_id,
                "Lead",
                "lead_to_account",
                matches_df,
                compliance_levels=[ComplianceLevel.GDPR],
            )

            # Validate both objects
            lead_validation = await validate_before_salesforce_operation(
                self.sf_integration, leads_df, "Lead", "update"
            )

            account_validation = await validate_before_salesforce_operation(
                self.sf_integration, accounts_df, "Account", "query"
            )

            if lead_validation.errors or account_validation.errors:
                total_errors = len(lead_validation.errors) + len(
                    account_validation.errors
                )
                log.error(f"❌ Validation failed with {total_errors} errors")
                return {"success": False, "error": "Cross-object validation failed"}

            log.info("✅ Cross-object validation successful")

            # Phase 2: Workflow Configuration
            log.info("⚙️ Phase 2: Lead-to-Account Configuration")

            lead_to_account_config = create_lead_to_account_config(
                target_lookup_field="AccountId",
                match_confidence_threshold=confidence_threshold,
                update_lead_status=True,
                new_lead_status="Qualified",
                dry_run=dry_run,
                backup_enabled=True,
            )

            # Preview workflow
            preview_result = (
                await self.workflow_engine.preview_lead_to_account_workflow(
                    lead_to_account_config, matches_df
                )
            )

            log.info("📊 Workflow Preview:")
            log.info(f"   Qualified Matches: {preview_result.estimated_updates:,}")
            log.info(
                f"   Confidence Distribution: {preview_result.confidence_distribution}"
            )

            # Phase 3: Bulk vs Standard API Decision
            if preview_result.estimated_updates > 1000:
                log.info("🚀 Using Bulk API for large dataset")

                # Prepare data for bulk update
                qualified_matches = matches_df[
                    matches_df["confidence_score"] >= confidence_threshold
                ]

                bulk_update_data = pd.DataFrame(
                    {
                        "Id": qualified_matches["s_Id"],
                        "AccountId": qualified_matches["r_Id"],
                        "Status": "Qualified",
                        "Matched_By_FoundryMatch__c": True,
                        "Match_Confidence__c": qualified_matches["confidence_score"],
                    }
                )

                if not dry_run:

                    async def bulk_progress(message: str, percent: float):
                        log.info(f"   📈 {percent:.1f}% - {message}")

                    bulk_result = await self.bulk_api.bulk_update(
                        "Lead", bulk_update_data, bulk_progress
                    )

                    log.info("📊 Bulk Update Results:")
                    log.info(f"   Successful: {bulk_result.successful_records:,}")
                    log.info(f"   Failed: {bulk_result.failed_records:,}")
                    log.info(f"   Execution Time: {bulk_result.execution_time:.1f}s")

                    execution_result = {
                        "records_updated": bulk_result.successful_records,
                        "records_failed": bulk_result.failed_records,
                        "success": bulk_result.failed_records == 0,
                        "execution_time": bulk_result.execution_time,
                        "method": "bulk_api",
                    }
                else:
                    execution_result = {
                        "records_updated": 0,
                        "dry_run": True,
                        "method": "bulk_api",
                    }
            else:
                log.info("⚡ Using Standard API for smaller dataset")

                # Execute standard workflow
                async def standard_progress(message: str, percent: float):
                    log.info(f"   📈 {percent:.1f}% - {message}")

                if not dry_run:
                    workflow_result = (
                        await self.workflow_engine.execute_lead_to_account_workflow(
                            lead_to_account_config, matches_df, standard_progress
                        )
                    )

                    execution_result = {
                        "records_updated": workflow_result.records_updated,
                        "success": workflow_result.success,
                        "execution_time": workflow_result.execution_time,
                        "backup_file": workflow_result.backup_file,
                        "method": "standard_api",
                    }
                else:
                    execution_result = {
                        "records_updated": 0,
                        "dry_run": True,
                        "method": "standard_api",
                    }

            # Phase 4: Audit and Compliance
            log.info("📜 Phase 4: Audit Trail and Compliance")

            # Create mock workflow result for audit
            from fmatch.integrations.salesforce.workflows import WorkflowResult

            audit_result = WorkflowResult(
                workflow_id=workflow_id,
                success=execution_result.get("success", True),
                records_updated=execution_result.get("records_updated", 0),
                execution_time=execution_result.get("execution_time", 0.0),
            )

            await self.audit_integration.audit_workflow_completion(
                audit_result, compliance_levels=[ComplianceLevel.GDPR]
            )

            log.info("✅ Lead-to-Account workflow completed successfully!")

            return {
                "success": True,
                "workflow_id": workflow_id,
                "preview": {
                    "qualified_matches": preview_result.estimated_updates,
                    "confidence_distribution": preview_result.confidence_distribution,
                    "sample_matches": preview_result.sample_matches[:3],
                },
                "execution": execution_result,
                "validation": {
                    "lead_errors": len(lead_validation.errors),
                    "account_errors": len(account_validation.errors),
                    "lead_warnings": len(lead_validation.warnings),
                    "account_warnings": len(account_validation.warnings),
                },
            }

        except Exception as e:
            log.error(f"❌ Lead-to-Account workflow failed: {e}", exc_info=True)
            return {"success": False, "workflow_id": workflow_id, "error": str(e)}

    async def demonstrate_rollback_capability(self, workflow_id: str) -> bool:
        """
        Demonstrate rollback capability for a completed workflow.

        Args:
            workflow_id: ID of workflow to rollback

        Returns:
            bool: True if rollback successful
        """
        try:
            log.info(f"🔄 Demonstrating Rollback for Workflow: {workflow_id}")

            # Get audit trail for workflow
            audit_trail = await self.audit_logger.get_audit_trail(
                workflow_id=workflow_id
            )

            if not audit_trail:
                log.warning(f"⚠️ No audit trail found for workflow {workflow_id}")
                return False

            log.info(f"📜 Found {len(audit_trail)} audit events for workflow")

            # Simulate rollback process
            rollback_success = await self.audit_logger.rollback_workflow(workflow_id)

            if rollback_success:
                log.info("✅ Rollback simulation completed successfully")
                log.info("   In production, this would:")
                log.info("   • Restore data from encrypted backups")
                log.info("   • Reverse all Salesforce changes")
                log.info("   • Update audit trail with rollback events")
                log.info("   • Notify stakeholders of rollback completion")
            else:
                log.error("❌ Rollback simulation failed")

            return rollback_success

        except Exception as e:
            log.error(f"❌ Rollback demonstration failed: {e}", exc_info=True)
            return False

    async def generate_comprehensive_report(self) -> Dict[str, Any]:
        """Generate a comprehensive compliance and audit report."""
        try:
            log.info("📊 Generating Comprehensive Audit Report")

            # Get recent audit events
            recent_events = await self.audit_logger.get_audit_trail(
                start_date=datetime.now().replace(day=1),  # Start of current month
                end_date=datetime.now(),
            )

            # Generate compliance reports for different standards
            gdpr_report = await self.audit_logger.generate_compliance_report(
                ComplianceLevel.GDPR
            )

            sox_report = await self.audit_logger.generate_compliance_report(
                ComplianceLevel.SOX
            )

            # Calculate audit integrity score
            from fmatch.integrations.salesforce.audit_compliance import (
                calculate_audit_integrity_score,
            )

            integrity_score = calculate_audit_integrity_score(recent_events)

            report = {
                "report_generated": datetime.now().isoformat(),
                "period": {
                    "start": datetime.now().replace(day=1).isoformat(),
                    "end": datetime.now().isoformat(),
                },
                "audit_summary": {
                    "total_events": len(recent_events),
                    "workflows_executed": len(
                        set(e.workflow_id for e in recent_events if e.workflow_id)
                    ),
                    "total_records_processed": sum(
                        e.records_affected for e in recent_events
                    ),
                    "integrity_score": integrity_score,
                },
                "compliance": {
                    "gdpr": {
                        "status": gdpr_report.certification_status,
                        "violations": len(gdpr_report.compliance_violations),
                        "recommendations": gdpr_report.recommendations[:3],
                    },
                    "sox": {
                        "status": sox_report.certification_status,
                        "violations": len(sox_report.compliance_violations),
                        "recommendations": sox_report.recommendations[:3],
                    },
                },
                "api_usage": {
                    "connection_healthy": self.sf_integration.is_connected(),
                    "org_id": self.sf_integration.credentials.org_id
                    if self.sf_integration.credentials
                    else None,
                },
            }

            log.info("✅ Comprehensive report generated")
            log.info(f"   📊 Audit Events: {report['audit_summary']['total_events']}")
            log.info(
                f"   🔄 Workflows: {report['audit_summary']['workflows_executed']}"
            )
            log.info(
                f"   📈 Integrity Score: {report['audit_summary']['integrity_score']:.1f}/100"
            )

            return report

        except Exception as e:
            log.error(f"❌ Report generation failed: {e}", exc_info=True)
            return {"error": str(e)}

    def _simulate_match_results(self, source_data: pd.DataFrame) -> pd.DataFrame:
        """
        Simulate match results for demonstration purposes.
        In real implementation, this would come from the FoundryMatch engine.
        """
        # Create simulated duplicate matches
        num_matches = min(len(source_data) // 4, 100)  # Up to 25% duplicates, max 100

        matches = []
        for i in range(num_matches):
            # Simulate high-confidence matches
            confidence = 75 + (i % 25)  # 75-99% confidence

            matches.append(
                {
                    "s_Id": f"lead_{i}_master",
                    "s_Name": f"Lead Master {i}",
                    "s_Email": f"lead{i}@example.com",
                    "r_Id": f"lead_{i}_duplicate",
                    "r_Name": f"Lead Duplicate {i}",
                    "r_Email": f"lead{i}_dup@example.com",
                    "confidence_score": confidence,
                    "field_scores": f'[{{"source_field": "Email", "ref_field": "Email", "score": {confidence}}}]',
                }
            )

        return pd.DataFrame(matches)


async def run_complete_demo():
    """
    Run a complete demonstration of the Salesforce integration.
    This shows how all components work together in a real scenario.
    """
    # Configure logging
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
    )

    log.info("🎬 Starting Complete Salesforce Integration Demo")

    # Initialize integration (you would provide real credentials)
    integration = CompleteSalesforceIntegration()

    # Note: You need to provide real Salesforce credentials here
    # initialized = await integration.initialize(
    #     client_id="your_client_id",
    #     client_secret="your_client_secret",
    #     is_sandbox=True,
    #     user_id="demo_user@foundryops.io"
    # )

    # if not initialized:
    #     log.error("❌ Failed to initialize integration")
    #     return

    # For demo purposes, simulate the workflows without real Salesforce connection
    log.info("🎭 Running Demo Mode (simulated workflows)")

    # Create sample data
    sample_leads = pd.DataFrame(
        {
            "Id": [f"lead_{i}" for i in range(1000)],
            "FirstName": [f"First{i}" for i in range(1000)],
            "LastName": [f"Last{i}" for i in range(1000)],
            "Email": [f"lead{i}@example.com" for i in range(1000)],
            "Company": [f"Company {i}" for i in range(1000)],
            "Status": ["New"] * 1000,
        }
    )

    sample_accounts = pd.DataFrame(
        {
            "Id": [f"account_{i}" for i in range(500)],
            "Name": [f"Company {i}" for i in range(500)],
            "Website": [f"company{i}.com" for i in range(500)],
        }
    )

    # Simulate match results
    sample_matches = pd.DataFrame(
        {
            "s_Id": [f"lead_{i}" for i in range(100)],
            "r_Id": [f"account_{i//2}" for i in range(100)],
            "confidence_score": [85 + (i % 15) for i in range(100)],
        }
    )

    log.info("📊 Demo Data Created:")
    log.info(f"   Leads: {len(sample_leads):,}")
    log.info(f"   Accounts: {len(sample_accounts):,}")
    log.info(f"   Matches: {len(sample_matches):,}")

    # Demonstrate the workflows (would work with real connection)
    log.info("\n🔍 This demo shows what would happen with real Salesforce connection:")
    log.info("   1. Lead deduplication with comprehensive validation")
    log.info("   2. Lead-to-Account matching with audit trails")
    log.info("   3. Rollback capabilities and compliance reporting")
    log.info("   4. Bullet-proof data handling with encrypted backups")

    log.info("\n✨ Integration Features Demonstrated:")
    log.info("   • OAuth 2.0 authentication with PKCE")
    log.info("   • Comprehensive data validation and quality checks")
    log.info("   • Bulk API for large datasets")
    log.info("   • Real-time progress tracking")
    log.info("   • Encrypted audit trails and compliance reporting")
    log.info("   • Automatic rollback capabilities")
    log.info("   • API usage monitoring and limits management")

    log.info("\n🎉 Complete Salesforce Integration Demo Finished!")


if __name__ == "__main__":
    asyncio.run(run_complete_demo())

# Example usage in GUI integration:
"""
To integrate this with your existing FoundryMatch GUI:

1. Add this to your gui.py imports:
   from fmatch.integrations.salesforce.complete_integration import CompleteSalesforceIntegration

2. Initialize in your FuzzyMatcherApp.__init__():
   self.salesforce_integration = CompleteSalesforceIntegration()

3. Add connection method:
   async def connect_to_salesforce(self, client_id, client_secret, is_sandbox=True):
       return await self.salesforce_integration.initialize(
           client_id, client_secret, is_sandbox, user_id=self.current_user
       )

4. Add workflow execution methods:
   async def execute_salesforce_dedupe(self, matches_df, dry_run=True):
       return await self.salesforce_integration.execute_lead_deduplication_workflow(
           self.source_df, dry_run
       )

   async def execute_salesforce_lead_to_account(self, matches_df, dry_run=True):
       return await self.salesforce_integration.execute_lead_to_account_workflow(
           self.source_df, self.ref_df, matches_df, dry_run=dry_run
       )

5. Add to your results popup or export functionality:
   if self.salesforce_integration and self.salesforce_integration.sf_integration.is_connected():
       # Show Salesforce workflow options
       # Execute workflows with full validation and audit trails

This provides bullet-proof Salesforce integration with comprehensive error handling,
audit trails, compliance reporting, and rollback capabilities.
"""
