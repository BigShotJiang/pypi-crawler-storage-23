"""
Microsoft Dynamics 365 CRM Integration for FoundryMatch

This package provides a complete integration layer for Dynamics 365,
mirroring the Salesforce integration architecture.
"""

# Core components
from .core import (
    DynamicsIntegration,
    DynamicsCredentials,
    DynamicsEntity,
    DynamicsField,
    ApiLimits,
)

# Bulk operations
from .bulk_api import DynamicsBulkAPI, ImportJobResult

# Data validation
from .data_validation import DynamicsDataValidator, ValidationResult, ValidationError

# Workflows
from .workflows import DynamicsWorkflowEngine, WorkflowResult

# Audit integration
from .audit_bridge import DynamicsAuditIntegration

# Helper components
from .dynamics_batch_implementation import BatchRequestBuilder
from .dynamics_rate_limiter import DynamicsRateLimiter

# GUI components (only import if tkinter is available)
try:
    import tkinter
    from .gui_integration import (
        DynamicsConnectionDialog,
        EntitySelector,
        WorkflowDialog,
    )

    # Try to import AsyncTkBridge from shared
    try:
        from ..shared.async_tk_bridge import AsyncTkBridge
    except ImportError:
        # If shared module doesn't exist, get it from gui_integration
        from .gui_integration import AsyncTkBridge

    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False
    AsyncTkBridge = None

__version__ = "1.0.0"
__author__ = "FoundryMatch Engineering"

__all__ = [
    # Core
    "DynamicsIntegration",
    "DynamicsCredentials",
    "DynamicsEntity",
    "DynamicsField",
    "ApiLimits",
    # Bulk
    "DynamicsBulkAPI",
    "ImportJobResult",
    # Validation
    "DynamicsDataValidator",
    "ValidationResult",
    "ValidationError",
    # Workflows
    "DynamicsWorkflowEngine",
    "WorkflowResult",
    # Audit
    "DynamicsAuditIntegration",
    # Helpers
    "BatchRequestBuilder",
    "DynamicsRateLimiter",
    # GUI (conditional)
    "GUI_AVAILABLE",
]

if GUI_AVAILABLE:
    __all__.extend(
        [
            "DynamicsConnectionDialog",
            "EntitySelector",
            "WorkflowDialog",
            "AsyncTkBridge",
        ]
    )
