# src/fmatch/__init__.py
"""
Foundry Match - Fuzzy matching and company resolution.

Core types and utilities are eagerly loaded. Engine components
are lazy-loaded to avoid importing heavy dependencies at startup.
"""

from __future__ import annotations

from importlib.metadata import version
from typing import Any

# --- Version ---
try:
    __version__ = version("foundrymatch")
except Exception:
    __version__ = "0.0.0-local"

# --- Lazy exports (engine components with saas dependencies) ---
_LAZY_EXPORTS = {
    "determine_optimal_blocking_strategy",
    "MatchConfig",
    "DedupeConfig",
}

_lazy_cache: dict[str, Any] = {}


def __getattr__(name: str) -> Any:
    """Lazy load engine components on first access."""
    if name in _LAZY_EXPORTS:
        if name not in _lazy_cache:
            from .core import engine
            _lazy_cache[name] = getattr(engine, name)
        return _lazy_cache[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "determine_optimal_blocking_strategy",
    "MatchConfig",
    "DedupeConfig",
    "__version__",
]
