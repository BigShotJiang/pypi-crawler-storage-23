"""Package entry‑point for `python -m fmatch`.

This file *only* discovers the Typer CLI defined in `fmatch.main`
and delegates control to it. We avoid hard‑coding the variable
name so that refactors inside `main.py` (e.g. changing `cli` ➜
`cli_app`) do not break the module invocation.
"""

from .cli import cli

cli()  # hand-off to Typer
