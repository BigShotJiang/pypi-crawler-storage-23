"""Intelligence layer utilities (scoring, contradictions, LLM shadow metrics)."""

__all__ = ["scoring", "contradictions", "llm_shadow"]
