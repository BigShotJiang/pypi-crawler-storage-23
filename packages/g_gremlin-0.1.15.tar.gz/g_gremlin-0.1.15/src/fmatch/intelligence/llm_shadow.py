from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DistillationMetrics:
    pattern: str
    llm_accuracy: float
    rule_accuracy: float
    coverage: int
    stability_days: int

    @property
    def ready_for_production(self) -> bool:
        """Return True when the distilled rule is stable and accurate enough for prod."""
        return (
            self.rule_accuracy >= 0.90
            and self.llm_accuracy >= 0.85
            and self.coverage >= 100
            and self.stability_days >= 7
        )
