from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import yaml


def load_profile_by_name(profile_name: str) -> Dict[str, Any]:
    """Load a scoring profile by name from configs/scorer/profiles."""
    root = Path(__file__).parents[3] / "configs" / "scorer" / "profiles"
    path = root / f"{profile_name}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Scoring profile not found: {profile_name}")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)
