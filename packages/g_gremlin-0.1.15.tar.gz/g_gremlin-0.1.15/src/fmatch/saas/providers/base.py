from __future__ import annotations

from typing import Any, Dict, Optional


class BaseLLMProvider:
    """Minimal base interface for LLM providers."""

    def __init__(self, model: Optional[str] = None):
        self.model = model or ""

    def generate_json(
        self, prompt: str, schema: Optional[Dict] = None, **opts
    ) -> Dict[str, Any]:
        raise NotImplementedError
