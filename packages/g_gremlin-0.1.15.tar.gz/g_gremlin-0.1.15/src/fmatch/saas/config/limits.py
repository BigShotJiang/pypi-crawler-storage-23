import os

"""Cost and scale guardrail limits for SaaS matching flows."""

MANUAL_SCALE_PAIR_THRESHOLD = int(
    os.getenv("FM_SCALE_PAIR_THRESHOLD", 10_000_000)
)  # pairs; route to scale engine at/above
ABSOLUTE_PAIR_LIMIT = int(
    os.getenv("FM_ABS_PAIR_LIMIT", 100_000_000)
)  # conservative hard cap to bound worst-case cost; tune per tier/env
MAX_JOB_WALLTIME_SEC = int(
    os.getenv("FM_MAX_JOB_WALLTIME_SEC", 30 * 60)
)  # 30-minute circuit breaker (overrides may tier)
DEFAULT_CANDIDATE_CAP = int(
    os.getenv("FM_DEFAULT_CANDIDATE_CAP", 2000)
)  # per-source cap when caller omits
POOR_OVERLAP_REROUTE_P90 = int(
    os.getenv("FM_POOR_OVERLAP_P90", 4000)
)  # reroute to scale when early P90 exceeds this
SHEETS_MAX_OUTPUT_ROWS = int(
    os.getenv("FM_SHEETS_MAX_OUTPUT_ROWS", 200_000)
)  # max rows Sheets can render without overflow

__all__ = [
    "MANUAL_SCALE_PAIR_THRESHOLD",
    "ABSOLUTE_PAIR_LIMIT",
    "MAX_JOB_WALLTIME_SEC",
    "DEFAULT_CANDIDATE_CAP",
    "POOR_OVERLAP_REROUTE_P90",
    "SHEETS_MAX_OUTPUT_ROWS",
]
