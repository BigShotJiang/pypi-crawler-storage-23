"""
DEPRECATED: This module has been renamed to tier_limits.py.

All imports from this module are forwarded to the new location.
Please update imports to use:
    from fmatch.saas.config.tier_limits import TIER_CONFIG, get_tier_config

This file will be removed in a future version.
"""

import warnings

# Emit deprecation warning on import
warnings.warn(
    "fmatch.saas.config.enrichment_pricing is deprecated. "
    "Use fmatch.saas.config.tier_limits instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from tier_limits for backwards compatibility
from .tier_limits import (
    # Config models
    TierLimitsConfig,
    # Loader
    load_tier_limits_config,
)

# Legacy alias for the loader function
load_enrichment_pricing_config = load_tier_limits_config

# Legacy alias for the config class
EnrichmentPricingConfig = TierLimitsConfig
