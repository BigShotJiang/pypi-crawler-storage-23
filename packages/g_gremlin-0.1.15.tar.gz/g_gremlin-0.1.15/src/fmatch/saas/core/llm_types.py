from typing import Any, Dict, Optional, TypedDict, List


class LLMResult(TypedDict, total=False):
    value: Any
    confidence: str
    reasons: List[str]
    provider: str
    model: str
    tokens: int


class LLMRequest(TypedDict, total=False):
    op: str
    prompt: str
    schema: Optional[Dict[str, Any]]
    params: Dict[str, Any]  # temperature, max_tokens, etc.
