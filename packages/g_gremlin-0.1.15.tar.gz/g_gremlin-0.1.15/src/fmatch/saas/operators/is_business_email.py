from __future__ import annotations

import re
from typing import Any, Dict

from fmatch.core.heuristics import FREEMAIL_DOMAINS, TEMP_DOMAINS


_EMAIL_RX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def is_business_email(email: str) -> Dict[str, Any]:
    e = (email or "").strip().lower()
    if not _EMAIL_RX.match(e):
        return {"value": False}
    try:
        local, domain = e.split("@", 1)
    except ValueError:
        return {"value": False}
    if domain in FREEMAIL_DOMAINS or domain in TEMP_DOMAINS:
        return {"value": False}
    return {"value": True}
