from __future__ import annotations

from typing import Any, Dict


COUNTRY_MAP = {
    "usa": "US",
    "us": "US",
    "united states": "US",
    "u.s.": "US",
    "u.s.a.": "US",
    "america": "US",
    "united kingdom": "GB",
    "uk": "GB",
    "gb": "GB",
    "great britain": "GB",
    "canada": "CA",
    "ca": "CA",
    "australia": "AU",
    "au": "AU",
    "germany": "DE",
    "de": "DE",
    "france": "FR",
    "fr": "FR",
    "spain": "ES",
    "es": "ES",
    "italy": "IT",
    "it": "IT",
    "netherlands": "NL",
    "nl": "NL",
    "india": "IN",
    "in": "IN",
    "brazil": "BR",
    "br": "BR",
    "mexico": "MX",
    "mx": "MX",
    "japan": "JP",
    "jp": "JP",
}


def normalize_country(value: str) -> Dict[str, Any]:
    v = (value or "").strip().lower()
    return {"value": COUNTRY_MAP.get(v, "").upper()}
