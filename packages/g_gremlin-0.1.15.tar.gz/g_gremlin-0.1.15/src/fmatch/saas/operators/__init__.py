from __future__ import annotations

import logging
from typing import Any, Dict, List, Tuple

from .assign_global_region import assign_global_region
from .assign_territory import assign_territory
from .assign_us_region import assign_us_region
from .calculate_completeness import calculate_completeness
from .calculate_lead_score import calculate_lead_score
from .classify_lead_source import classify_lead_source
from .classify_revenue_band import classify_revenue_band
from .clean_name import clean_name
from .clean_website import clean_website
from .company_size_bucket import company_size_bucket
from .company_to_domain import (
    company_to_domain,
    resolve_company_to_domain_batch,
)
from .detect_data_quality_issues import detect_data_quality_issues
from .detect_duplicate_likelihood import detect_duplicate_likelihood
from .detect_parent_company import detect_parent_company, detect_parent_company_batch
from .detect_technographics import detect_technographics
from .infer_employee_count import infer_employee_count
from .email_domain_match import email_domain_match
from .extract_domain_root import extract_domain_root
from .extract_domain_from_email import extract_domain_from_email
from .extract_id_from_url import extract_id_from_url
from .extract_subdomain import extract_subdomain

log = logging.getLogger(__name__)

try:
    from .fix_phone_format import fix_phone_format
except Exception as exc:  # pragma: no cover
    fix_phone_format = None  # type: ignore
    log.warning("fix_phone_format operator unavailable: %s", exc)
from .generate_dedup_key import generate_dedup_key
from .is_business_email import is_business_email
from .is_role_based_email import is_role_based_email
from .normalize_company import (
    normalize_company,
    normalize_company_batch,
    normalize_company_batch_async,
)
from .normalize_country import normalize_country
from .normalize_industry import normalize_industry
from .normalize_job_function import normalize_job_function
from .normalize_phone_to_e164 import normalize_phone_to_e164
from .normalize_state import normalize_state
from .state_name_to_code import state_name_to_code
from .normalize_title import normalize_title
from .parse_address_components import parse_address_components
from .parse_email_pattern import parse_email_pattern
from .parse_naics import parse_naics
from .parse_sic import parse_sic
from .split_fullname import split_fullname
from .enrich_company_industry import enrich_company_industry
from .enrich_company_country import enrich_company_country
from .enrich_company_headquarters import enrich_company_headquarters
from .enrich_company_name import enrich_company_name
from .enrich_company_revenue import enrich_company_revenue
from .enrich_from_foundrygraph import enrich_from_foundrygraph
from .enrich_social_handles import enrich_social_handles
from .enrich_stock_info import enrich_stock_info
from .enrich_subsidiaries import enrich_subsidiaries

# Re-export core resolution functions for backward compatibility
# These are now the canonical implementations in fmatch.core
from fmatch.core import (
    resolve_company_domain,
    resolve_company_domains,
    normalize_company_text,
    normalize_domain,
    normalize_state as normalize_state_core,
    normalize_title_text,
)

__all__ = [
    "assign_global_region",
    "assign_territory",
    "assign_us_region",
    "calculate_completeness",
    "calculate_lead_score",
    "classify_lead_source",
    "classify_revenue_band",
    "clean_name",
    "clean_website",
    "company_size_bucket",
    "company_to_domain",
    "resolve_company_to_domain_batch",
    "detect_data_quality_issues",
    "detect_duplicate_likelihood",
    "detect_parent_company",
    "detect_parent_company_batch",
    "detect_technographics",
    "infer_employee_count",
    "email_domain_match",
    "extract_domain_from_email",
    "enrich_company_country",
    "enrich_company_headquarters",
    "enrich_company_industry",
    "enrich_company_name",
    "enrich_company_revenue",
    "enrich_from_foundrygraph",
    "enrich_social_handles",
    "enrich_stock_info",
    "enrich_subsidiaries",
    "extract_domain_root",
    "extract_id_from_url",
    "extract_subdomain",
    "fix_phone_format",
    "generate_dedup_key",
    "is_business_email",
    "is_role_based_email",
    "normalize_company",
    "normalize_company_batch",
    "normalize_company_batch_async",
    "normalize_country",
    "normalize_industry",
    "normalize_job_function",
    "normalize_phone_to_e164",
    "normalize_state",
    "state_name_to_code",
    "normalize_title",
    "parse_address_components",
    "parse_email_pattern",
    "parse_naics",
    "parse_sic",
    "split_fullname",
    # Re-exports from fmatch.core
    "resolve_company_domain",
    "resolve_company_domains",
    "normalize_company_text",
    "normalize_domain",
    "normalize_state_core",
    "normalize_title_text",
]
