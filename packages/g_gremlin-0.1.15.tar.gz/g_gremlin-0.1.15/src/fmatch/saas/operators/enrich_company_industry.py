"""Enrich company industry from Wikidata profiles."""

from typing import Dict, Any, Optional, List
from functools import lru_cache

__transform_id__ = "enrich_company_industry"
__version__ = "1.0.0"
__updated__ = "2025-10-07"


@lru_cache(maxsize=1000)
def normalize_domain(url_or_domain: str) -> str:
    """Extract and normalize domain from URL or domain string."""
    if not url_or_domain:
        return ""

    s = url_or_domain.strip().lower()
    if "://" not in s:
        s = "http://" + s

    try:
        from urllib.parse import urlparse

        parsed = urlparse(s)
        domain = parsed.hostname or parsed.path.split("/")[0]
        # Remove www prefix
        if domain and domain.startswith("www."):
            domain = domain[4:]
        return domain or ""
    except:
        return ""


def _lookup_wikidata_industries(
    domain: Optional[str],
) -> Optional[List[Dict[str, str]]]:
    """Query Wikidata profiles for industry data."""
    try:
        import os

        if os.getenv("FM_COMPANY_TO_DOMAIN_WIKIDATA", "true").lower() != "true":
            return None

        from . import wikidata_profiles

        normalized_domain = (domain or "").lower()
        if not normalized_domain:
            return None

        profile = wikidata_profiles.get_profile_for_domain(normalized_domain)
        if not profile:
            return None

        industries = profile.get("industries", [])
        if industries:
            return industries

        return None

    except Exception:
        return None


def enrich_company_industry(
    company: Optional[str] = None,
    website: Optional[str] = None,
    domain: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Enrich company with industry classification from Wikidata.

    Args:
        company: Company name (not used currently, reserved for future LLM fallback)
        website: Company website URL
        domain: Domain (if already extracted)

    Returns:
        Dict with industry information.

    Examples:
        >>> enrich_company_industry(domain="simbasleep.ca")
        {"industry": "bedding", "industries": ["bedding", "mattress"], "confidence": 1.0}
    """

    dom = normalize_domain(website or domain or "")

    # 1. Check Wikidata profiles (40K+ companies)
    wikidata_industries = _lookup_wikidata_industries(dom)
    if wikidata_industries:
        # Return primary industry (first) and all industries
        industry_labels = [
            ind.get("label", "") for ind in wikidata_industries if ind.get("label")
        ]
        if industry_labels:
            return {
                "industry": industry_labels[0],
                "all_industries": ", ".join(industry_labels),
                "confidence": 1.0,
                "source": "wikidata",
            }

    # 2. No industry data found
    return {
        "industry": "Not Available",
        "all_industries": "",
        "confidence": 0.0,
        "source": None,
    }
