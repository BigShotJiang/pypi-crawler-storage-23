from __future__ import annotations

from typing import Any, Dict
from urllib.parse import urlparse


def clean_website(value: str) -> Dict[str, Any]:
    s = (value or "").strip()
    if not s:
        return {"value": ""}
    if "://" not in s:
        s = "http://" + s
    try:
        p = urlparse(s)
        host = (p.hostname or "").lower()
        path = (p.path or "/").rstrip("/")
        out = host if path in ("", "/") else f"{host}{path}"
        return {"value": out}
    except Exception:
        return {
            "value": s.lower()
            .replace("https://", "")
            .replace("http://", "")
            .lstrip("www.")
            .rstrip("/")
        }
