"""Enrich company country from Wikidata profiles."""

from typing import Dict, Any, Optional, List
from functools import lru_cache

__transform_id__ = "enrich_company_country"
__version__ = "1.0.0"
__updated__ = "2025-10-07"


@lru_cache(maxsize=1000)
def normalize_domain(url_or_domain: str) -> str:
    """Extract and normalize domain from URL or domain string."""
    if not url_or_domain:
        return ""

    s = url_or_domain.strip().lower()
    if "://" not in s:
        s = "http://" + s

    try:
        from urllib.parse import urlparse

        parsed = urlparse(s)
        domain = parsed.hostname or parsed.path.split("/")[0]
        # Remove www prefix
        if domain and domain.startswith("www."):
            domain = domain[4:]
        return domain or ""
    except:
        return ""


def _lookup_wikidata_countries(domain: Optional[str]) -> Optional[List[Dict[str, str]]]:
    """Query Wikidata profiles for country data."""
    try:
        import os

        if os.getenv("FM_COMPANY_TO_DOMAIN_WIKIDATA", "true").lower() != "true":
            return None

        from . import wikidata_profiles

        normalized_domain = (domain or "").lower()
        if not normalized_domain:
            return None

        profile = wikidata_profiles.get_profile_for_domain(normalized_domain)
        if not profile:
            return None

        countries = profile.get("countries", [])
        if countries:
            return countries

        return None

    except Exception:
        return None


def enrich_company_country(
    company: Optional[str] = None,
    website: Optional[str] = None,
    domain: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Enrich company with country information from Wikidata.

    Args:
        company: Company name (not used currently, reserved for future)
        website: Company website URL
        domain: Domain (if already extracted)

    Returns:
        Dict with country information.

    Examples:
        >>> enrich_company_country(domain="heineken.com")
        {"country": "Netherlands", "countries": ["Netherlands"], "confidence": 1.0}
    """

    dom = normalize_domain(website or domain or "")

    # 1. Check Wikidata profiles (40K+ companies, 36.6% have country data)
    wikidata_countries = _lookup_wikidata_countries(dom)
    if wikidata_countries:
        # Return primary country (first) and all countries
        country_labels = [
            cnt.get("label", "") for cnt in wikidata_countries if cnt.get("label")
        ]
        if country_labels:
            return {
                "country": country_labels[0],
                "all_countries": ", ".join(country_labels),
                "confidence": 1.0,
                "source": "wikidata",
            }

    # 2. No country data found
    return {
        "country": "Not Available",
        "all_countries": "",
        "confidence": 0.0,
        "source": None,
    }
