"""Extract domain component from an email address."""

from __future__ import annotations

from typing import Dict

B2C_DOMAINS = {
    "gmail.com",
    "yahoo.com",
    "hotmail.com",
    "outlook.com",
    "icloud.com",
    "live.com",
    "aol.com",
    "msn.com",
    "protonmail.com",
    "pm.me",
}

from ._decorators import safe_transform


@safe_transform
def extract_domain_from_email(email: str, strip_b2c: bool = False) -> Dict[str, str]:
    """Return the registrable domain portion of an email address."""
    if not email or "@" not in str(email):
        return {"value": ""}

    domain = str(email).split("@")[-1].strip().lower()
    if strip_b2c and domain in B2C_DOMAINS:
        return {"value": ""}
    return {"value": domain}
