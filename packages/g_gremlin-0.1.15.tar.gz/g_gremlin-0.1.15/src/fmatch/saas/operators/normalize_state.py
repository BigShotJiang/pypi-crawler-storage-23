from __future__ import annotations

import os
from typing import Any, Dict

# Lazy import for LLM provider to avoid GCP credential discovery at startup
_llm_provider_getter = None

def _get_llm_provider():
    """Lazy loader for get_llm_provider to avoid startup hang."""
    global _llm_provider_getter
    if _llm_provider_getter is None:
        from ..providers import get_llm_provider as _glp
        _llm_provider_getter = _glp
    return _llm_provider_getter()

from fmatch.core.heuristics import US_STATE_MAP, CA_PROVINCE_MAP, AU_STATE_MAP

# Reverse mappings: Code -> Full Name
US_STATE_NAMES = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "DC": "District of Columbia",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "ME": "Maine",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming",
    "PR": "Puerto Rico",
    "GU": "Guam",
    "AS": "American Samoa",
    "VI": "U.S. Virgin Islands",
}

CA_PROVINCE_NAMES = {
    "AB": "Alberta",
    "BC": "British Columbia",
    "MB": "Manitoba",
    "NB": "New Brunswick",
    "NL": "Newfoundland and Labrador",
    "NS": "Nova Scotia",
    "ON": "Ontario",
    "PE": "Prince Edward Island",
    "QC": "Quebec",
    "SK": "Saskatchewan",
    "NT": "Northwest Territories",
    "NU": "Nunavut",
    "YT": "Yukon",
}

AU_STATE_NAMES = {
    "NSW": "New South Wales",
    "VIC": "Victoria",
    "QLD": "Queensland",
    "SA": "South Australia",
    "WA": "Western Australia",
    "TAS": "Tasmania",
    "ACT": "Australian Capital Territory",
    "NT": "Northern Territory",
}


def _map_state(value: str, country: str) -> str | None:
    """Map state code or name to full state name."""
    v = (value or "").strip()
    if not v:
        return None

    # Try uppercase match first (code -> name)
    v_upper = v.upper()
    if country == "US" and v_upper in US_STATE_NAMES:
        return US_STATE_NAMES[v_upper]
    if country == "CA" and v_upper in CA_PROVINCE_NAMES:
        return CA_PROVINCE_NAMES[v_upper]
    if country == "AU" and v_upper in AU_STATE_NAMES:
        return AU_STATE_NAMES[v_upper]

    # Try case-insensitive match for full names
    v_lower = v.lower()
    if country == "US":
        code = US_STATE_MAP.get(v_lower)
        return US_STATE_NAMES.get(code) if code else None
    if country == "CA":
        code = CA_PROVINCE_MAP.get(v_lower)
        return CA_PROVINCE_NAMES.get(code) if code else None
    if country == "AU":
        code = AU_STATE_MAP.get(v_lower)
        return AU_STATE_NAMES.get(code) if code else None

    # Default to US
    code = US_STATE_MAP.get(v_lower)
    return US_STATE_NAMES.get(code) if code else None


def normalize_state(text: str, *, country: str | None = None) -> Dict[str, Any]:
    ctry = (country or os.getenv("DEFAULT_COUNTRY", "US")).upper()
    code = _map_state(text, ctry)

    if code:
        return {"value": code}

    # Fallback to LLM if enabled
    if os.getenv("TRANSFORM_ENABLE_LLM_FALLBACK", "true").lower() == "true":
        provider = _get_llm_provider()
        if provider:
            schema = {
                "type": "object",
                "properties": {"code": {"type": "string"}},
                "required": ["code"],
            }
            prompt = (
                f"Map the region to its official postal/ISO subdivision code for {ctry}. "
                'Output JSON: {"code":"<CODE>"}. Only return a valid code.\n'
                f'Input: "{text}"'
            )
            try:
                out = provider.generate_json(prompt, schema=schema, num_predict=32)
                code = (out.get("value", {}) or {}).get("code")
                if code:
                    return {"value": code}
            except Exception:
                pass

    return {"value": ""}
