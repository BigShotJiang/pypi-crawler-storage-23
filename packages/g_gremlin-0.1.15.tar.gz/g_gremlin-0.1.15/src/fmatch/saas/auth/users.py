from fastapi import Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import get_session
from ..models import User
from ..auth import get_current_account


async def get_current_user(
    account_id: str = Depends(get_current_account),
    db: AsyncSession = Depends(get_session),
) -> User:
    """
    Get the current authenticated user based on account context.
    In a real implementation, this would derive from JWT subject or session.
    For now, we get the first user from the account (to be replaced with proper auth).
    """
    result = await db.execute(
        select(User).where(User.account_id == account_id).limit(1)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(401, "User not found for account")
    return user
