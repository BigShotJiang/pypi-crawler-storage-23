"""
Centralized similarity functions (intelligence layer).
This module wraps rapidfuzz so API/Service layers do not import it directly.
"""

from typing import Any

try:
    from rapidfuzz import fuzz as _fuzz
except Exception:  # pragma: no cover
    _fuzz = None


class _FuzzProxy:
    def __getattr__(self, name: str) -> Any:
        if _fuzz is None:
            raise RuntimeError("rapidfuzz is not installed")
        return getattr(_fuzz, name)


# Expose a fuzz-like object for convenience
fuzz = _FuzzProxy()


# Common helpers (explicit re-exports)
def ratio(a: str, b: str) -> float:
    return float(fuzz.ratio(a, b))


def partial_ratio(a: str, b: str) -> float:
    return float(fuzz.partial_ratio(a, b))


def token_set_ratio(a: str, b: str) -> float:
    return float(fuzz.token_set_ratio(a, b))


def token_sort_ratio(a: str, b: str) -> float:
    return float(fuzz.token_sort_ratio(a, b))
