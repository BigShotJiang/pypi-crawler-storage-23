"""B2B field definitions and patterns for column detection."""

B2B_ONTOLOGY = {
    "account_name": {
        "aliases": [
            "company",
            "account",
            "organization",
            "business",
            "employer",
            "customer",
            "client",
            "vendor",
            "partner",
            "practice",
            "clinic",
            "facility",
            "firm",
            "agency",
            "enterprise",
        ],
        # International corporate markers - comprehensive list
        "hard_markers": (
            r"\b(?:inc|llc|corp|co\.?|ltd|limited|gmbh|ag|s\.a\.|sa|oy|pte|"
            r"bv|nv|kg|ab|aps|as|sas|sasu|srl|spa|plc|pty|pvt|kk|kft|"
            r"zrt|sro|ltda|mbh|ehf|oyj|a\/s|p\.c\.|pc|lp|llp|l\.p\.|"
            r"partnerships?|associates?|group|holdings?|international)\b"
        ),
        "constraints": {
            "min_avg_len": 5,
            "max_null_rate": 0.5,
            "min_unique_ratio": 0.3,  # Companies should have some diversity
            "max_unique_ratio": 0.95,  # But not be completely unique
        },
        "negative_header_markers": (
            r"(?:do\s*not\s*use|old|backup|archive|temp|copy|"
            r"delete|ignore|duplicate|test|sample|dummy|"
            r"_old|_bak|_copy|_temp|\(old\)|\(copy\)|\bv\d{1,2}\b)"
        ),
    },
    "email": {
        "aliases": ["email", "emailaddress", "e-mail", "email_address", "mail"],
        "pattern": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
        "constraints": {
            "min_unique_ratio": 0.7,  # Emails should be fairly unique
            "max_null_rate": 0.7,
        },
    },
    "domain": {
        "aliases": [
            "domain",
            "website",
            "web",
            "site",
            "url",
            "homepage",
            "web_site",
            "webaddress",
        ],
        "tld_pattern": (
            r"\.(?:com|org|net|io|ai|co|edu|gov|biz|info|me|tv|us|uk|ca|au|"
            r"de|fr|jp|cn|in|br|mx|nl|se|no|fi|dk|ch|it|es|pl|ru|kr|"
            r"sg|hk|tw|nz|za|ae|sa|eg|il|tr|th|my|id|vn|ph)\b"
        ),
        "url_pattern": r"^(?:https?://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
        "constraints": {"max_null_rate": 0.8},
    },
    "contact_first": {
        "aliases": [
            "first",
            "firstname",
            "first_name",
            "given",
            "given_name",
            "fname",
            "forename",
        ],
        "constraints": {"max_null_rate": 0.8, "avg_len_range": (2, 12)},
    },
    "contact_last": {
        "aliases": [
            "last",
            "lastname",
            "last_name",
            "surname",
            "family",
            "family_name",
            "lname",
        ],
        "constraints": {"max_null_rate": 0.8, "avg_len_range": (2, 15)},
    },
    "contact_full": {
        "aliases": [
            "name",
            "fullname",
            "full_name",
            "contact",
            "person",
            "contact_name",
        ],
        "constraints": {"max_null_rate": 0.8, "avg_len_range": (5, 30)},
    },
    "linkedin": {
        "aliases": [
            "linkedin",
            "linkedin_url",
            "linkedin profile",
            "linkedin_profile",
            "li",
            "linkedin company",
            "linkedin_company_url",
        ],
        "pattern": r"(?:https?://)?(?:www\.)?linkedin\.com/(?:in|company)/[\w\-_/]+",
        "constraints": {"max_null_rate": 0.9},
    },
}

# Industry patterns for enhanced detection
INDUSTRY_PATTERNS = {
    "healthcare": [
        "hospital",
        "medical",
        "clinic",
        "health",
        "care",
        "practice",
        "pharma",
        "biotech",
    ],
    "finance": [
        "bank",
        "capital",
        "financial",
        "invest",
        "asset",
        "securities",
        "insurance",
        "wealth",
    ],
    "technology": [
        "tech",
        "software",
        "digital",
        "cyber",
        "ai",
        "cloud",
        "saas",
        "data",
        "analytics",
    ],
    "manufacturing": [
        "manufactur",
        "industrial",
        "plant",
        "factory",
        "production",
        "assembly",
    ],
    "retail": ["retail", "store", "shop", "ecommerce", "merchant", "marketplace"],
    "education": [
        "university",
        "college",
        "school",
        "academy",
        "institute",
        "education",
        "learning",
    ],
    "consulting": ["consulting", "advisory", "consultant", "strategy", "management"],
    "real_estate": [
        "realty",
        "property",
        "estate",
        "housing",
        "development",
        "construction",
    ],
}

# Known export fingerprints (>=80% match triggers auto-mapping)
FINGERPRINTS = {
    "salesforce_accounts": {
        "headers": {
            "account name",
            "website",
            "billing city",
            "billing state",
            "industry",
            "type",
        },
        "mappings": {"account name": "account_name", "website": "domain"},
    },
    "salesforce_leads": {
        "headers": {"company", "email", "first name", "last name", "lead source"},
        "mappings": {"company": "account_name", "email": "email"},
    },
    "salesforce_contacts": {
        "headers": {"account name", "email", "first name", "last name", "title"},
        "mappings": {"account name": "account_name", "email": "email"},
    },
    "hubspot_contacts": {
        "headers": {"company", "email", "firstname", "lastname"},
        "mappings": {"company": "account_name", "email": "email"},
    },
    "hubspot_companies": {
        "headers": {"name", "domain", "industry", "city", "state"},
        "mappings": {"name": "account_name", "domain": "domain"},
    },
    "apollo_contacts": {
        "headers": {"organization name", "email", "first name", "last name", "title"},
        "mappings": {"organization name": "account_name", "email": "email"},
    },
    "zoominfo_contacts": {
        "headers": {"company name", "email address", "first name", "last name"},
        "mappings": {"company name": "account_name", "email address": "email"},
    },
}

# Common field combinations that appear together
FIELD_COMBINATIONS = {
    "full_name_split": {
        "components": ["contact_first", "contact_last"],
        "creates": "contact_full",
    },
    "address_split": {
        "components": ["street", "city", "state", "zip", "country"],
        "creates": "full_address",
    },
}
