"""
Adapters for bridging API versions to core services.

This package contains adapters that translate between different API versions
and the core MatchGateway service, ensuring backward compatibility while
enabling centralized matching logic.
"""

from .id_hunter_adapter import IDHunterGatewayAdapter
from .v1_gateway_adapter import V1GatewayAdapter, V1MatchResponse

__all__ = ["IDHunterGatewayAdapter", "V1GatewayAdapter", "V1MatchResponse"]
