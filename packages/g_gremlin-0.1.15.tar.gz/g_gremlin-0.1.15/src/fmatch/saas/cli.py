import typer
import uvicorn
from . import main as fmatch_main  # FastAPI + job helpers live here

cli = typer.Typer(help="FoundryOps Fuzzy-Matcher CLI")


@cli.command()
def run_job(
    file: str = typer.Option(..., "--file"),
    mode: str = typer.Option("duplicate", "--mode"),
    ruleset: str = typer.Option("default", "--ruleset"),
):
    if mode == "duplicate":
        fmatch_main.run_duplicate_job(file, ruleset)
    else:
        fmatch_main.run_match_job(file, ruleset)


@cli.command()
def serve(host: str = "0.0.0.0", port: int = 8000, reload: bool = False):
    uvicorn.run("fmatch.main:app", host=host, port=port, reload=reload)
