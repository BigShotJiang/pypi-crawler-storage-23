"""
Event tracking system for FoundryMatch SaaS.

This package handles:
- Usage events for billing
- Telemetry events for analytics
- Event collection and transport
"""
