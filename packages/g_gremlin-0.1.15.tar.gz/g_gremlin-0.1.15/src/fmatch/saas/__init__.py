"""
SaaS/API Module for FMatch
===========================
Provides async wrappers and API endpoints for the fuzzy matching engine.

Usage:
------
Direct imports (recommended to avoid circular imports):
```python
from fmatch.saas.engine_bridge import (
    dedupe,
    match,
    suggest_blocking,
    shutdown_executor,
    DedupeConfig,
    MatchConfig,
    ProgressEvent,
    ProgressPhase,
    RunStats
)
```

Or import from original locations:
```python
from fmatch.core.engine import DedupeConfig, MatchConfig, RunStats
from fmatch.core.progress_event import ProgressEvent, ProgressPhase
```

Available Functions:
- dedupe: Async deduplication wrapper
- match: Async matching wrapper
- suggest_blocking: Async blocking suggestion
- shutdown_executor: Clean shutdown of thread pool

Available Classes:
- DedupeConfig: Configuration for deduplication
- MatchConfig: Configuration for matching
- ProgressEvent: Progress reporting event
- ProgressPhase: Progress phase enum
- RunStats: Execution statistics
"""

# Note: Due to circular import issues with core.engine importing from saas.worker_pool,
# we don't re-export core classes here. Import them directly from their modules.

__all__ = [
    # Main submodules
    "engine_bridge",
]
