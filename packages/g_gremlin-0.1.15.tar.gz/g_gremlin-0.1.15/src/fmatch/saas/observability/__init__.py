"""Observability helpers for logging and error tracking."""
