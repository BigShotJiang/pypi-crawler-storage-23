from __future__ import annotations
import uuid
import json
import logging
from datetime import datetime
from typing import Dict, Any, List

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

# NOTE: we will reuse the same engine client used in L2A in a follow-up.
# from .engine_client import EngineClient

log = logging.getLogger(__name__)


class IntelligentDedupeService:
    """
    Phase-1 skeleton that mirrors the L2A service shape.
    Next step is to wire the matching engine and persist results.
    """

    def __init__(self, db: AsyncSession, account_id: str):
        self.db = db
        self.account_id = str(account_id)

    async def _ensure_table(self):
        await self.db.execute(
            text("""
        CREATE TABLE IF NOT EXISTS dedupe_suggestions (
            id TEXT PRIMARY KEY,
            account_id TEXT NOT NULL,
            object_type TEXT NOT NULL,
            rec_id_1 TEXT NOT NULL,
            rec_id_2 TEXT NOT NULL,
            score REAL NOT NULL,
            tier TEXT NOT NULL,
            reasons TEXT,
            field_score_details TEXT,
            explanation TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            decided_at TIMESTAMP,
            decided_by TEXT,
            cluster_id TEXT,
            UNIQUE (account_id, object_type, rec_id_1, rec_id_2)
        );
        """)
        )
        # Original indexes
        await self.db.execute(
            text(
                "CREATE INDEX IF NOT EXISTS idx_dedupe_acc_obj ON dedupe_suggestions(account_id, object_type);"
            )
        )
        await self.db.execute(
            text(
                "CREATE INDEX IF NOT EXISTS idx_dedupe_status ON dedupe_suggestions(status);"
            )
        )
        await self.db.execute(
            text(
                "CREATE INDEX IF NOT EXISTS idx_dedupe_score ON dedupe_suggestions(score DESC);"
            )
        )
        await self.db.execute(
            text("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_dedupe_pair
        ON dedupe_suggestions(account_id, object_type, rec_id_1, rec_id_2);
        """)
        )

        # Performance-optimized indexes for production
        await self.db.execute(
            text("""
        CREATE INDEX IF NOT EXISTS idx_dedupe_suggestions_main
        ON dedupe_suggestions(account_id, object_type, status, score DESC);
        """)
        )
        await self.db.execute(
            text("""
        CREATE INDEX IF NOT EXISTS idx_dedupe_suggestions_created
        ON dedupe_suggestions(account_id, object_type, status, created_at);
        """)
        )
        await self.db.commit()

    async def save_suggestions(
        self,
        object_type: str,
        pairs: List[Dict[str, Any]],
        status: str = "pending",
        run_id: str | None = None,
        created_at: datetime | None = None,
    ):
        """
        Persist a batch of candidate pairs.
        `pairs` entries should have: left_id, right_id, score (0..1), tier, reasons, field_score_details, explanation?, sig?
        We normalize the pair order to (min, max) to avoid symmetric duplicates.

        Args:
            created_at: Optional timestamp to use for all records (for consistent flip window comparison)
        """
        await self._ensure_table()
        if not pairs:
            return 0
        # Use provided timestamp or create new one
        timestamp = created_at or datetime.utcnow()
        now = timestamp.isoformat(sep=" ", timespec="seconds")
        sql = text("""
        INSERT INTO dedupe_suggestions
        (id, account_id, object_type, rec_id_1, rec_id_2, score, tier, reasons, field_score_details, explanation, status, created_at)
        VALUES (:id, :account_id, :object_type, :rec1, :rec2, :score, :tier, :reasons, :details, :explanation, :status, :created_at)
        ON CONFLICT (account_id, object_type, rec_id_1, rec_id_2) DO NOTHING
        """)
        for p in pairs:
            # Support both old (left_id/right_id) and new (rec_id_1/rec_id_2) formats
            a = p.get("rec_id_1") or p.get("left_id")
            b = p.get("rec_id_2") or p.get("right_id")
            rec1, rec2 = (a, b) if a <= b else (b, a)

            # Add signal type to reasons if available
            reasons = p.get("reasons", "")
            if p.get("sig"):
                try:
                    reasons_dict = (
                        json.loads(reasons) if reasons and reasons != "{}" else {}
                    )
                    reasons_dict["sig"] = p["sig"]
                    reasons = json.dumps(reasons_dict)
                except:
                    pass

            await self.db.execute(
                sql,
                {
                    "id": str(uuid.uuid4()),
                    "account_id": self.account_id,
                    "object_type": object_type,
                    "rec1": rec1,
                    "rec2": rec2,
                    "score": float(p.get("score", 0.0)),
                    "tier": p.get("tier", "POSSIBLE"),
                    "reasons": reasons,
                    "details": p.get("field_score_details", ""),
                    "explanation": p.get("explanation", ""),
                    "status": status,
                    "created_at": timestamp,
                },
            )
        await self.db.commit()
        return len(pairs)
