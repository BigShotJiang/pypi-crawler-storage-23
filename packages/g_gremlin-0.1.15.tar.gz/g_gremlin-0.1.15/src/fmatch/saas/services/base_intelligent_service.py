from __future__ import annotations
from typing import Any, Dict
from sqlalchemy.ext.asyncio import AsyncSession
import logging

from ..api.intelligence_client import IntelligenceClient

# If you already have an EngineClient, import it; otherwise keep this tiny stub.
try:
    from .engine_client import EngineClient  # existing in your repo?
except Exception:

    class EngineClient:  # stub; wire to core engine when available
        async def dedupe(self, df, config: Dict[str, Any]):
            raise NotImplementedError("EngineClient.dedupe() not wired")


log = logging.getLogger(__name__)


class BaseIntelligentService:
    def __init__(
        self,
        db: AsyncSession,
        account_id: str,
        engine: EngineClient | None = None,
        intel: IntelligenceClient | None = None,
    ):
        self.db = db
        self.account_id = account_id
        self.engine = engine or EngineClient()
        self.intel = intel or IntelligenceClient()

    async def auto_configure(
        self, df_source, df_reference, goal: str = "dedupe"
    ) -> Dict[str, Any]:
        """Ask Intelligence for a full config bundle."""
        return await self.intel.auto_configure(df_source, df_reference, goal=goal)

    async def dedupe_with_engine(self, df, config: Dict[str, Any]):
        """Run Engine with the config (returns engine-produced suggestions)."""
        return await self.engine.dedupe(df, config)
