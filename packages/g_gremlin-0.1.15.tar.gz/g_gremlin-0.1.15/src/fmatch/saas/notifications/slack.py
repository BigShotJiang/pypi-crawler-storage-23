import httpx
from typing import Optional
from .. import settings


async def send_slack(channel: str, text: str, blocks: Optional[dict] = None):
    """Send Slack notification"""
    if not settings.SLACK_BOT_TOKEN:
        return

    async with httpx.AsyncClient() as client:
        await client.post(
            "https://slack.com/api/chat.postMessage",
            headers={"Authorization": f"Bearer {settings.SLACK_BOT_TOKEN}"},
            json={"channel": channel, "text": text, "blocks": blocks},
        )
