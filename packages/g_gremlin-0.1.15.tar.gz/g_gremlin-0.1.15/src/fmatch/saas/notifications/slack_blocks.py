import json


def job_card(
    kind: str,
    job_id: str,
    status: str,
    applied: int,
    skipped: int,
    errors: int,
    approve_needed: bool = False,
) -> dict:
    actions = []
    if status == "waiting_approval" or approve_needed:
        actions.append(
            {
                "type": "button",
                "text": {"type": "plain_text", "text": "Approve"},
                "style": "primary",
                "action_id": "approve",
                "value": json.dumps({"type": kind, "job_id": job_id, "op": "approve"}),
            }
        )
    if status == "completed" and (applied or 0) > 0:
        actions.append(
            {
                "type": "button",
                "text": {"type": "plain_text", "text": "Undo"},
                "action_id": "undo",
                "value": json.dumps({"type": kind, "job_id": job_id, "op": "undo"}),
            }
        )
    blocks = [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*{(kind or '').upper()} job* `{(job_id or '')[:8]}…` — *{status}*",
            },
        },
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"Applied: *{applied or 0}* • Skipped: *{skipped or 0}* • Errors: *{errors or 0}*",
                }
            ],
        },
    ]
    if actions:
        blocks.append({"type": "actions", "elements": actions})
    return {"blocks": blocks}
