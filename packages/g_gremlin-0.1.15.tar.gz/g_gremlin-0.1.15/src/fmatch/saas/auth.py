"""
Unified authentication module for FoundryMatch.
Re-exports authentication functions from auth_security for consistency.
"""

# Re-export from auth_security for backward compatibility
from .auth_security import require_account as get_current_account
from .auth_security import require_user as get_current_user

# Also export the actual names
from .auth_security import require_account, require_user

# Export bearer scheme
from .auth_core import bearer_scheme

__all__ = [
    "get_current_account",
    "get_current_user",
    "require_account",
    "require_user",
    "bearer_scheme",
]
