from __future__ import annotations
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field, EmailStr


class LeadIn(BaseModel):
    lead_id: Optional[str] = None
    email: Optional[EmailStr] = None
    company: Optional[str] = None
    website: Optional[str] = None
    phone: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    employee_count: Optional[int] = None
    account_id: Optional[str] = None  # if caller already knows (rare)


class RouteRequest(BaseModel):
    tenant_id: str
    lead: LeadIn
    preview: bool = False


class RouteResponse(BaseModel):
    decision: str
    reason: str
    owner_id: Optional[str] = None
    pool_id: Optional[str] = None
    rule_id: Optional[str] = None
    context: Dict[str, Any] = Field(default_factory=dict)
    warnings: List[str] = Field(default_factory=list)


# Admin
class PoolCreate(BaseModel):
    tenant_id: str
    pool_id: str
    name: str
    algo: str = "fair_rr"
    daily_cap: Optional[int] = None


class PoolMemberUpsert(BaseModel):
    tenant_id: str
    pool_id: str
    user_id: str
    weight: Optional[int] = 1


class RuleUpsert(BaseModel):
    tenant_id: str
    rule_id: str
    name: str
    priority: int
    active: bool = True
    condition: Dict[str, Any]
    action: Dict[str, Any]
