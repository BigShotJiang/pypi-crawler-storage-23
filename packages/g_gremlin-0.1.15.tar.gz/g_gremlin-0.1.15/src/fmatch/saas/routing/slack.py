from __future__ import annotations
import os
import json
import httpx
import logging

logger = logging.getLogger(__name__)

SLACK_WEBHOOK = os.getenv("ROUTING_SLACK_WEBHOOK_URL")


async def post_decision(decision: dict) -> None:
    if not SLACK_WEBHOOK:
        return
    try:
        text = (
            f"🎯 *Lead routed*\n"
            f"*Decision:* {decision.get('decision')}\n"
            f"*Reason:* {decision.get('reason')}\n"
            f"*Owner:* {decision.get('owner_id')}\n"
            f"*Ctx:* `{json.dumps(decision.get('context') or {})[:300]}`"
        )
        async with httpx.AsyncClient(timeout=5) as cli:
            await cli.post(SLACK_WEBHOOK, json={"text": text})
    except Exception as e:
        logger.debug(f"Slack notify failed: {e}")
