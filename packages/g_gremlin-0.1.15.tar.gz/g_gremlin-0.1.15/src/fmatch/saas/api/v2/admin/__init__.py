"""Admin API endpoints namespace."""

from fastapi import APIRouter

from .maintenance import router as maintenance_router

router = APIRouter()
router.include_router(maintenance_router)

__all__ = ["router"]
