# src/fmatch/saas/api/v2/admin_search.py
from fastapi import APIRouter, Query
from typing import Optional, Dict, List
from pydantic import BaseModel

router = APIRouter(prefix="/api/v2/admin", tags=["admin"])


class SearchResponse(BaseModel):
    total: int
    items: List[Dict]


@router.get("/search", response_model=SearchResponse)
async def search_records(
    object_type: str = Query(..., pattern="^(Lead|Account|Contact)$"),
    q: Optional[str] = None,
    status: Optional[str] = None,
    created_from: Optional[str] = None,
    created_to: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, le=100),
    sort_by: str = "LastModifiedDate",
    sort_dir: str = "desc",
):
    # TODO: Delegate to your Salesforce integration; build SOQL with filters.
    # For now, return mock data for testing

    # Mock data based on object type - standardized lowercase keys
    mock_items = []
    for i in range(min(5, page_size)):
        item_id = f"00{object_type[0]}{str(i).zfill(12)}"
        mock_items.append(
            {
                "id": item_id,
                "name": f"Test {object_type} {(page-1)*page_size + i + 1}",
                "email": f"test{i}@example.com" if object_type != "Account" else None,
                "website": f"https://example{i}.com"
                if object_type == "Account"
                else None,
                "company": f"Company {i}" if object_type == "Lead" else None,
                "phone": f"555-{str(i).zfill(4)}" if object_type != "Account" else None,
                "created_date": "2024-01-01T00:00:00Z",
                "last_modified_date": "2024-01-15T00:00:00Z",
                "status": "unmatched" if i % 2 == 0 else "matched",
                # Add matched account/lead reference for some records
                "account__c": f"001{str(i).zfill(12)}"
                if object_type == "Lead" and i % 2 == 1
                else None,
                "master_record_id": f"00{object_type[0]}{str(0).zfill(12)}"
                if object_type != "Lead" and i % 3 == 0
                else None,
            }
        )

    return SearchResponse(
        total=100,  # Mock total
        items=mock_items,
    )
