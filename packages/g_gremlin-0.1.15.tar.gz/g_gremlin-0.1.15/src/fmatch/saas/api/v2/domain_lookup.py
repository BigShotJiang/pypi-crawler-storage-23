"""Public endpoints for domain family lookups."""

from typing import Dict, Any
from fastapi import APIRouter, Query

router = APIRouter(prefix="/api/v2", tags=["domain-families"])


@router.get("/domain-families/lookup")
async def lookup_domain_family(
    domain: str = Query(..., description="Domain to lookup (e.g., salesforce.com)")
) -> Dict[str, Any]:
    """
    Public endpoint for domain family lookups.
    Returns parent domain and subsidiaries for a given domain.
    """
    from ...services.domain_family import get_registry, domain_normalize

    normalized = domain_normalize(domain)
    if not normalized:
        return {
            "canonical": domain,
            "parent": None,
            "subsidiaries": [],
            "aliases": []
        }

    registry = get_registry()
    family_id = registry.get_domain_family(normalized)

    if not family_id:
        return {
            "canonical": normalized,
            "parent": None,
            "subsidiaries": [],
            "aliases": []
        }

    # Get all domains in this family
    family_domains = registry.get_family_domains(family_id)

    # Get display name if available
    display_name = registry.get_display_name(family_id)

    # Separate parent from subsidiaries
    subsidiaries = [d for d in family_domains if d != family_id]

    return {
        "canonical": family_id,
        "parent": display_name or family_id,
        "subsidiaries": sorted(subsidiaries),
        "aliases": []
    }
