from fastapi import APIRouter, Depends

from ...services.metrics import metrics
from ...auth_security import require_admin


router = APIRouter(prefix="/internal", tags=["internal"])


@router.get("/metrics")
async def get_metrics(_: str = Depends(require_admin)):
    """Return simple counters snapshot. Admin-only."""
    snap = await metrics.snapshot()
    # Normalize keys in expected order
    return {
        "jobs_started": snap.get("job_started", 0),
        "jobs_completed": snap.get("job_completed", 0),
        "suggestions_emitted": snap.get("suggestions_emitted", 0),
        "approvals": snap.get("approvals", 0),
        "reverts": snap.get("reverts", 0),
    }
