"""
Utils API Wrapper - Routes to Intelligent Implementation
=========================================================
This wrapper ensures backward compatibility while routing
all calls to the new intelligent implementation.
"""

import warnings
from .utils_intelligent import (
    intelligent_utils,
    fuzzy_score,
    partial_score,
    token_score,
    suggest_mappings,
)

# Issue deprecation warning on import
warnings.warn(
    "utils.py is deprecated. Use utils_intelligent.py for compliant implementation. "
    "Direct fuzzy library usage violates architecture principles.",
    DeprecationWarning,
    stacklevel=2,
)

# Export the intelligent implementations
__all__ = [
    "intelligent_utils",
    "fuzzy_score",
    "partial_score",
    "token_score",
    "suggest_mappings",
]


# Log usage for monitoring
def log_deprecation_usage():
    """Track deprecated utils usage"""
    try:
        from .v2.monitoring import intelligence_stats

        intelligence_stats.violations_found.append("utils.py import detected")
    except:
        pass


log_deprecation_usage()
