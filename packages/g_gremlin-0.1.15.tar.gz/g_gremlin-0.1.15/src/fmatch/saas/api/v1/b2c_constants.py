"""Centralized B2C email/root domains for server-side checks."""

B2C_TOP = {
    "gmail.com",
    "yahoo.com",
    "hotmail.com",
    "outlook.com",
    "live.com",
    "aol.com",
    "icloud.com",
    "me.com",
    "protonmail.com",
    "proton.me",
    "zoho.com",
    "gmx.com",
    "mail.com",
    "mail.ru",
    "qq.com",
    "163.com",
    "fastmail.com",
}
