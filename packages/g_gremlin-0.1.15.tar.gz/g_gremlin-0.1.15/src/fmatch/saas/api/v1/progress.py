"""
Compatibility shim for tests that import get_redis from api.v1.progress.
Re-exports get_redis from the shared progress module.
"""

from ..progress import get_redis  # noqa: F401

__all__ = ["get_redis"]
