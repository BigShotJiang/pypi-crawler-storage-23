from fmatch.saas.db import Base

__all__ = ["Base"]
