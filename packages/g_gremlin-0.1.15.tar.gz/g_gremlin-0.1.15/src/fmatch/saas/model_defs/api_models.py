from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlmodel import SQLModel, Field


class ApiUsage(SQLModel, table=True):
    __tablename__ = "api_usage"
    __table_args__ = {"extend_existing": True}

    id: Optional[int] = Field(default=None, primary_key=True)
    api_key: str = Field(index=True, description="Key identifier (prefix)")
    period_yyyymm: int = Field(index=True, description="Period as YYYYMM integer")
    calls: int = Field(default=0, description="Number of API calls")
    matches: int = Field(default=0, description="Number of matches processed")
    bytes: int = Field(default=0, description="Payload bytes processed")
    last_update_at: Optional[datetime] = Field(default=None)
