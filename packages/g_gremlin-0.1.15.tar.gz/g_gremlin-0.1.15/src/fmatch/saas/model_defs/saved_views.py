from sqlmodel import Field
from sqlalchemy import Column, Text, DateTime
from datetime import datetime
from fmatch.saas.db import Base
import uuid


class ManualSavedView(Base, table=True):
    __tablename__ = "manual_saved_views"
    __table_args__ = {"extend_existing": True}

    id: str = Field(primary_key=True, default_factory=lambda: str(uuid.uuid4()))
    account_id: str = Field(index=True)
    user_id: str = Field(index=True)
    name: str = Field()

    # object agnostic: 'Lead' | 'Contact'
    object_type: str = Field(default="Lead")

    # 'user' (default) or 'org'
    scope: str = Field(default="user")

    # filters and UI settings payloads
    filters_json: str = Field(sa_column=Column(Text), default="[]")
    settings_json: str = Field(sa_column=Column(Text), default="{}")

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(
        default_factory=datetime.utcnow,
        sa_column=Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow),
    )
