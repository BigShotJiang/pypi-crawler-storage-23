"""
Migration Script - Convert All Services to Intelligence
========================================================
This script automates the migration of all services to use
BaseIntelligentService and eliminate hardcoded configurations.
"""
import os
import re
import ast
from pathlib import Path
from typing import List, Tuple, Dict, Any
from datetime import datetime


class IntelligenceMigrator:
    """Automated migration to intelligence APIs"""
    
    def __init__(self):
        self.violations: List[Path] = []
        self.fixed: List[Path] = []
        self.report: List[str] = []
        
    def scan_file(self, filepath: Path) -> List[Tuple[int, str, str]]:
        """Scan file for violations"""
        violations = []
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                lines = f.readlines()
        except Exception as e:
            print(f"    ⚠️  Could not read {filepath}: {e}")
            return violations
            
        for i, line in enumerate(lines, 1):
            # Check for hardcoded thresholds
            if re.search(r'threshold\s*=\s*0\.\d+', line):
                # Exclude base_intelligent_service.py and models
                if 'base_intelligent' not in str(filepath) and 'models.py' not in str(filepath):
                    violations.append((i, 'HARDCODED_THRESHOLD', line.strip()))
                    
            # Check for rapidfuzz
            if 'from rapidfuzz' in line or 'import rapidfuzz' in line:
                # Exclude core directory
                if 'src/fmatch/core' not in str(filepath).replace('\\', '/'):
                    violations.append((i, 'RAPIDFUZZ_IMPORT', line.strip()))
                    
            # Check for hardcoded field mappings
            if re.search(r'["\'](Company|Email|Name|FirstName|LastName)["\']', line):
                if 'field_mapping' in line or 'source_column' in line or 'reference_column' in line:
                    # Exclude migration and test files
                    if 'migration' not in str(filepath) and 'test' not in str(filepath):
                        violations.append((i, 'HARDCODED_FIELD', line.strip()))
                        
        return violations
    
    def fix_file(self, filepath: Path) -> bool:
        """Auto-fix violations in file"""
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            print(f"    ⚠️  Could not read {filepath}: {e}")
            return False
            
        original = content
        
        # Fix imports - remove rapidfuzz
        content = re.sub(
            r'from rapidfuzz import.*\n',
            '',
            content
        )
        content = re.sub(
            r'import rapidfuzz.*\n',
            '',
            content
        )
        
        # Add intelligence import if missing and it's a service file
        if '_service.py' in str(filepath) or '_matcher.py' in str(filepath):
            if 'BaseIntelligentService' not in content and 'base_intelligent' not in str(filepath):
                # Add import at the top after other imports
                import_line = 'from .base_intelligent_service import BaseIntelligentService\n'
                if 'import' in content:
                    # Find the last import line
                    lines = content.split('\n')
                    last_import_idx = 0
                    for idx, line in enumerate(lines):
                        if line.startswith('import ') or line.startswith('from '):
                            last_import_idx = idx
                    lines.insert(last_import_idx + 1, import_line.strip())
                    content = '\n'.join(lines)
                else:
                    content = import_line + content
        
        # Fix hardcoded thresholds - comment them out and add TODO
        content = re.sub(
            r'(threshold\s*=\s*0\.\d+)',
            r'# TODO: Replace with intelligence API\n    # \1  # HARDCODED - NEEDS FIX',
            content
        )
        
        if content != original:
            try:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                return True
            except Exception as e:
                print(f"    ⚠️  Could not write to {filepath}: {e}")
                return False
            
        return False
    
    def analyze_service(self, filepath: Path) -> Dict[str, Any]:
        """Analyze a service file for compliance"""
        
        analysis = {
            'path': filepath,
            'uses_base_class': False,
            'has_rapidfuzz': False,
            'has_hardcoded_config': False,
            'violations': [],
            'can_auto_fix': False
        }
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Check for BaseIntelligentService usage
            if 'BaseIntelligentService' in content:
                analysis['uses_base_class'] = True
                
            # Check for rapidfuzz
            if 'rapidfuzz' in content and 'src/fmatch/core' not in str(filepath).replace('\\', '/'):
                analysis['has_rapidfuzz'] = True
                
            # Check for hardcoded configs
            if re.search(r'threshold\s*=\s*0\.\d+', content):
                analysis['has_hardcoded_config'] = True
                
            # Get violations
            analysis['violations'] = self.scan_file(filepath)
            
            # Determine if auto-fix is possible
            if analysis['violations'] and not analysis['uses_base_class']:
                analysis['can_auto_fix'] = True
                
        except Exception as e:
            analysis['error'] = str(e)
            
        return analysis
    
    def migrate_service(self, service_path: Path):
        """Migrate a service to use intelligence"""
        
        print(f"\nMigrating {service_path.name}")
        self.report.append(f"\n=== {service_path.name} ===")
        
        # Analyze the service
        analysis = self.analyze_service(service_path)
        
        # Report current state
        if analysis.get('uses_base_class'):
            print(f"  [OK] Already uses BaseIntelligentService")
            self.report.append("  Status: COMPLIANT")
        else:
            # Report violations
            violations = analysis['violations']
            if violations:
                print(f"  [ERROR] Found {len(violations)} violations:")
                self.report.append(f"  Violations: {len(violations)}")
                
                # Show first 3 violations
                for line_no, vtype, content in violations[:3]:
                    print(f"    Line {line_no}: {vtype}")
                    print(f"      {content[:80]}...")
                    self.report.append(f"    - Line {line_no}: {vtype}")
                    
                if len(violations) > 3:
                    print(f"    ... and {len(violations) - 3} more")
                    
                # Attempt auto-fix
                if analysis['can_auto_fix']:
                    if self.fix_file(service_path):
                        print(f"  [FIXED] Auto-fixed {service_path.name}")
                        self.fixed.append(service_path)
                        self.report.append("  Action: AUTO-FIXED")
                    else:
                        print(f"  [WARNING] Manual fix needed for {service_path.name}")
                        self.violations.append(service_path)
                        self.report.append("  Action: MANUAL FIX NEEDED")
                else:
                    print(f"  [WARNING] Manual migration needed for {service_path.name}")
                    self.violations.append(service_path)
                    self.report.append("  Action: MANUAL MIGRATION NEEDED")
            else:
                print(f"  [OK] {service_path.name} is compliant!")
                self.report.append("  Status: COMPLIANT")
    
    def run_migration(self, directory: str = "src/fmatch/saas/services"):
        """Run migration on all services"""
        
        print("Starting Intelligence Migration")
        print("=" * 50)
        self.report.append("INTELLIGENCE MIGRATION REPORT")
        self.report.append(f"Generated: {datetime.now().isoformat()}")
        self.report.append("=" * 50)
        
        service_dir = Path(directory)
        
        # Find all service and matcher files
        service_files = []
        patterns = ["*_service.py", "*_matcher.py", "*_agent.py"]
        
        for pattern in patterns:
            service_files.extend(service_dir.glob(pattern))
        
        # Exclude base files
        service_files = [
            f for f in service_files 
            if 'base_intelligent' not in str(f) and 'migrate' not in str(f)
        ]
        
        print(f"Found {len(service_files)} service files to check")
        self.report.append(f"\nServices analyzed: {len(service_files)}")
        
        # Process each service
        for service_file in sorted(service_files):
            self.migrate_service(service_file)
                
        # Summary
        print("\n" + "=" * 50)
        print("Migration Summary:")
        print(f"  Auto-fixed: {len(self.fixed)} files")
        print(f"  Need manual fix: {len(self.violations)} files")
        print(f"  Total processed: {len(service_files)} files")
        
        self.report.append("\n" + "=" * 50)
        self.report.append("SUMMARY")
        self.report.append(f"  Auto-fixed: {len(self.fixed)}")
        self.report.append(f"  Manual fixes needed: {len(self.violations)}")
        self.report.append(f"  Total processed: {len(service_files)}")
        
        if self.violations:
            print("\nFiles needing manual intervention:")
            self.report.append("\nFiles needing manual intervention:")
            for v in self.violations:
                print(f"    - {v}")
                self.report.append(f"  - {v}")
                
        # Write report to file
        report_path = Path("MIGRATION_REPORT.md")
        with open(report_path, 'w') as f:
            f.write("# Intelligence Migration Report\n\n")
            f.write("```\n")
            f.write('\n'.join(self.report))
            f.write("\n```\n")
            
        print(f"\nFull report saved to: {report_path}")
                
        return len(self.violations) == 0
    
    def generate_conversion_guide(self, service_path: Path):
        """Generate a conversion guide for a specific service"""
        
        analysis = self.analyze_service(service_path)
        
        guide = [
            f"# Conversion Guide for {service_path.name}",
            "",
            "## Current Issues:",
        ]
        
        if analysis['has_rapidfuzz']:
            guide.append("- ❌ Uses rapidfuzz directly")
            guide.append("  Fix: Remove rapidfuzz imports and use engine client")
            
        if analysis['has_hardcoded_config']:
            guide.append("- ❌ Has hardcoded thresholds/configs")
            guide.append("  Fix: Use get_intelligent_config() method")
            
        if not analysis['uses_base_class']:
            guide.append("- ❌ Doesn't inherit from BaseIntelligentService")
            guide.append("  Fix: Change class inheritance")
            
        guide.extend([
            "",
            "## Conversion Steps:",
            "",
            "1. Update class definition:",
            "```python",
            f"from .base_intelligent_service import BaseIntelligentService",
            "",
            f"class YourService(BaseIntelligentService):",
            "    pass",
            "```",
            "",
            "2. Replace hardcoded configs:",
            "```python",
            "# OLD:",
            "threshold = 0.75",
            "",
            "# NEW:",
            "config = await self.get_intelligent_config(source_df, target_df)",
            "threshold = config['threshold']",
            "```",
            "",
            "3. Use engine for matching:",
            "```python",
            "result = await self.match_with_intelligence(",
            "    source_data=df1,",
            "    target_data=df2",
            ")",
            "```",
        ])
        
        return '\n'.join(guide)


if __name__ == "__main__":
    import sys
    
    migrator = IntelligenceMigrator()
    
    # Check if specific service specified
    if len(sys.argv) > 1:
        service_path = Path(sys.argv[1])
        if service_path.exists():
            print(f"Analyzing {service_path}...")
            guide = migrator.generate_conversion_guide(service_path)
            print(guide)
        else:
            print(f"File not found: {service_path}")
    else:
        # Run full migration
        success = migrator.run_migration()
        
        if success:
            print("\nMigration complete! All services now use intelligence.")
        else:
            print("\nSome services need manual fixes. See above and check MIGRATION_REPORT.md")