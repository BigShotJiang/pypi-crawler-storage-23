from pydantic import BaseModel, Field
from typing import List, Dict, Any


class BlockingSuggestionModel(BaseModel):
    """
    Represents the result of a blocking suggestion operation.
    """

    column: str
    blocked_pairs: int
    total_pairs: int


class DuplicateResultModel(BaseModel):
    """
    Represents the result of a deduplication operation.
    """

    class Config:
        arbitrary_types_allowed = True

    matches: List[dict] = Field(default_factory=list)
    total_duration: float


class MatchResultModel(BaseModel):
    """
    Represents the result of a match operation.
    """

    class Config:
        arbitrary_types_allowed = True

    matches: List[dict] = Field(default_factory=list)
    total_duration: float


class ProgressUpdate(BaseModel):
    """
    Represents a progress update from the engine.
    """

    progress: float = Field(ge=0.0, le=1.0)  # Progress as fraction 0.0-1.0
    message: str = ""
    items_processed: int = 0
    total_items: int = 0
    comparisons_delta: int = 0

    def dict(self, **kwargs) -> Dict[str, Any]:
        """Override to ensure compatibility with GUI expectations."""
        data = super().dict(**kwargs)
        # Ensure progress is a float between 0 and 1
        data["progress"] = max(0.0, min(1.0, float(data.get("progress", 0.0))))
        return data
