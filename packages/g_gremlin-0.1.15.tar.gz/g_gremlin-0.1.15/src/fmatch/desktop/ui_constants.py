"""
UI Constants and State Management for FoundryMatch Desktop
"""

from enum import Enum, auto


# UI State Machine
class UIState(Enum):
    EMPTY = auto()
    SOURCE_ONLY = auto()
    REFERENCE_ONLY = auto()
    BOTH_LOADED = auto()


# Dimensions
COMPACT_TILE_HEIGHT = 80
COMPACT_TILE_WIDTH = 180
MAX_TREE_HEIGHT = 6
PREVIEW_ROW_LIMIT = 500

# Feature flags
USE_DROPDOWN_LOADER = True  # Set to False to use tile-based loader

# Colors (can be customized for themes)
COLORS = {
    "primary": "#2c3e50",
    "secondary": "#34495e",
    "success": "#27ae60",
    "danger": "#c0392b",
    "warning": "#f39c12",
    "info": "#2980b9",
    "bg": "#ecf0f1",
    "text": "#2c3e50",
    "placeholder": "#95a5a6",
}

# Fonts
PLACEHOLDER_FONT = ("TkDefaultFont", 10, "italic")
HEADING_FONT = ("TkDefaultFont", 11, "bold")
