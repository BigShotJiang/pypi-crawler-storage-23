"""Connector implementations for external registries (OpenCorporates, CH, SIRENE, ...)."""
