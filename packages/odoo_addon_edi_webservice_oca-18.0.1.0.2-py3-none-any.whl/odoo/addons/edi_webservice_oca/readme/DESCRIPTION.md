Plug webservice module within EDI framework. Allows to configure attach
webservices on an EDI backend and/or on an exchange type.
