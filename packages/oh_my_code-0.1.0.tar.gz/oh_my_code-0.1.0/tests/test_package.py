"""Basic tests for the oh_my_code package."""

import unittest

from oh_my_code import __version__, greet


class PackageTests(unittest.TestCase):
    def test_version_is_defined(self) -> None:
        self.assertEqual(__version__, "0.1.0")

    def test_greet_uses_name(self) -> None:
        self.assertEqual(greet("team"), "Hello, team!")


if __name__ == "__main__":
    unittest.main()
