# oh-my-code

`oh-my-code` is a minimal Python package scaffold, ready to publish on PyPI.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip build
python -m pip install -e .
```

## Usage

```python
from oh_my_code import greet

print(greet("developer"))
```

## Build distribution artifacts

```bash
python -m build
```

## Publish to PyPI

```bash
python -m pip install twine
python -m twine upload dist/*
```
