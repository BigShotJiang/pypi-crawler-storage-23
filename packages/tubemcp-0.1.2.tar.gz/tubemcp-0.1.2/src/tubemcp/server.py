from mcp.server.fastmcp import FastMCP

from tubemcp.config import settings
from tubemcp.youtube import (
    TubeMCPError,
    extract_video_id,
    get_transcript,
    multi_search_youtube,
)

mcp = FastMCP(
    "TubeMCP",
    instructions="""\
YouTube transcript server. Two tools: youtube_search and youtube_get_transcript.

Recommended workflow:
1. Generate 2-3 search queries from different angles. Vary specificity and phrasing.
   Example for "how does async/await work in Python":
   - "python async await explained"
   - "python asyncio tutorial beginner"
   - "python concurrency async vs threading"
2. Call youtube_search with your queries. Results are deduplicated automatically.
3. Review results and rank by relevance (title, channel, duration).
4. Fetch the transcript of the most promising video with youtube_get_transcript.
5. If the answer is found, stop. If not, fetch 1-2 more transcripts.

For simple factual questions, one transcript is often enough.
For broad overviews or comparisons, fetch 2-3 transcripts from different channels.
Avoid fetching all transcripts upfront — be selective to save time and tokens.

If fetched transcripts are low quality or off-topic, generate new queries from a
different angle and search again.

Transcripts include per-segment timestamps. Each segment has text, start (seconds),
and duration. To link to a specific moment, use youtu.be/VIDEO_ID?t=SECONDS
where SECONDS is the integer start value.
""",
)


@mcp.tool()
def youtube_get_transcript(video_url: str) -> dict | str:
    """Fetch the transcript and metadata for a single YouTube video. Accepts a URL
    or video ID. Results are cached locally. Fetch only the videos most relevant
    to the user's question — avoid bulk fetching. The transcript field is an array
    of segments, each with text, start (seconds), and duration (seconds)."""
    try:
        video_id = extract_video_id(video_url)
        return get_transcript(video_id, settings.db_path)
    except ValueError as exc:
        return f"Invalid YouTube URL or video ID: {exc}"
    except TubeMCPError as exc:
        return str(exc)


@mcp.tool()
def youtube_search(queries: list[str], max_results_per_query: int = 3) -> list[dict] | str:
    """Search YouTube with multiple queries for broader coverage. Each query runs
    a separate search; results are deduplicated by video ID. Use 2-3 queries from
    different angles for best results (e.g. a specific query, a broader one, and
    an alternative phrasing). Returns metadata only — no transcripts."""
    try:
        return multi_search_youtube(queries, max_per_query=max_results_per_query)
    except TubeMCPError as exc:
        return str(exc)


def main():
    from tubemcp.db import init_db

    init_db(settings.db_path)
    mcp.run()


if __name__ == "__main__":
    main()
