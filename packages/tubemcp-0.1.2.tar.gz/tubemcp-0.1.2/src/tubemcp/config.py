import os
from pathlib import Path


class Settings:
    def __init__(self):
        self.db_path: Path = Path.home() / ".tubemcp" / "cache.db"
        self.proxy_url: str | None = os.environ.get("TUBEMCP_PROXY_URL")
        self.request_delay: float = float(os.environ.get("TUBEMCP_REQUEST_DELAY", "2.0"))


settings = Settings()
