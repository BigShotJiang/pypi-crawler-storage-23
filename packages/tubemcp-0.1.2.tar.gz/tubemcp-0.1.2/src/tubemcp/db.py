import json
import sqlite3
from pathlib import Path


def init_db(db_path: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS videos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                channel_name TEXT NOT NULL,
                thumbnail_url TEXT,
                duration_seconds INTEGER,
                publish_date TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS transcripts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT NOT NULL REFERENCES videos(video_id),
                language TEXT NOT NULL DEFAULT 'en',
                content TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                UNIQUE(video_id, language)
            );

            CREATE INDEX IF NOT EXISTS idx_videos_video_id ON videos(video_id);
            CREATE INDEX IF NOT EXISTS idx_transcripts_video_id ON transcripts(video_id);
        """)
        conn.commit()
    finally:
        conn.close()


def get_connection(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def get_cached_video(db_path: Path, video_id: str) -> dict | None:
    with get_connection(db_path) as conn:
        row = conn.execute(
            """
            SELECT v.video_id, v.title, v.channel_name, v.thumbnail_url,
                   v.duration_seconds, v.publish_date, t.content AS transcript
            FROM videos v
            JOIN transcripts t ON t.video_id = v.video_id
            WHERE v.video_id = ?
            """,
            (video_id,),
        ).fetchone()
    if row is None:
        return None
    result = dict(row)
    try:
        result["transcript"] = json.loads(result["transcript"])
    except (json.JSONDecodeError, TypeError):
        return None  # old-format entry, treat as cache miss
    return result


def cache_video(db_path: Path, video_id: str, metadata: dict, transcript: list[dict]) -> None:
    with get_connection(db_path) as conn:
        conn.execute(
            """
            INSERT INTO videos (video_id, title, channel_name, thumbnail_url, duration_seconds, publish_date)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(video_id) DO UPDATE SET
                title = excluded.title,
                channel_name = excluded.channel_name,
                thumbnail_url = excluded.thumbnail_url,
                duration_seconds = excluded.duration_seconds,
                publish_date = excluded.publish_date
            """,
            (
                video_id,
                metadata["title"],
                metadata["channel_name"],
                metadata.get("thumbnail_url"),
                metadata.get("duration_seconds"),
                metadata.get("publish_date"),
            ),
        )
        conn.execute(
            """
            INSERT INTO transcripts (video_id, language, content)
            VALUES (?, 'en', ?)
            ON CONFLICT(video_id, language) DO UPDATE SET content = excluded.content
            """,
            (video_id, json.dumps(transcript)),
        )
        conn.commit()
