import re
import time
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import yt_dlp
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import (
    InvalidVideoId,
    IpBlocked,
    NoTranscriptFound,
    RequestBlocked,
    TranscriptsDisabled,
    VideoUnavailable,
)
from youtube_transcript_api.proxies import GenericProxyConfig


class TubeMCPError(Exception):
    pass


class NoCaptionsError(TubeMCPError):
    pass


class VideoNotFoundError(TubeMCPError):
    pass


class RateLimitedError(TubeMCPError):
    pass


class SearchError(TubeMCPError):
    pass


_VIDEO_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{11}$")

_ytt_api: YouTubeTranscriptApi | None = None
_last_request_time: float = 0.0


def _get_api() -> YouTubeTranscriptApi:
    global _ytt_api
    if _ytt_api is None:
        from tubemcp.config import settings

        proxy_config = None
        if settings.proxy_url:
            proxy_config = GenericProxyConfig(https_url=settings.proxy_url)
        _ytt_api = YouTubeTranscriptApi(proxy_config=proxy_config)
    return _ytt_api


def extract_video_id(url_or_id: str) -> str:
    if not url_or_id:
        raise ValueError("Invalid YouTube URL or video ID: empty string")

    # Bare 11-char video ID
    if _VIDEO_ID_RE.match(url_or_id):
        return url_or_id

    parsed = urlparse(url_or_id)

    if parsed.scheme in ("http", "https"):
        host = parsed.netloc.lstrip("www.")

        # youtu.be/<id>
        if host == "youtu.be":
            video_id = parsed.path.lstrip("/")
            if _VIDEO_ID_RE.match(video_id):
                return video_id
            raise ValueError(f"Invalid YouTube URL or video ID: {url_or_id!r}")

        if host == "youtube.com":
            # /watch?v=<id>
            if parsed.path == "/watch":
                params = parse_qs(parsed.query)
                video_id = params.get("v", [None])[0]
                if video_id and _VIDEO_ID_RE.match(video_id):
                    return video_id
                raise ValueError(f"Invalid YouTube URL or video ID: {url_or_id!r}")

            # /embed/<id> or /v/<id>
            path_parts = parsed.path.strip("/").split("/")
            if len(path_parts) >= 2 and path_parts[0] in ("embed", "v"):
                video_id = path_parts[1]
                if _VIDEO_ID_RE.match(video_id):
                    return video_id

            raise ValueError(f"Invalid YouTube URL or video ID: {url_or_id!r}")

    raise ValueError(f"Invalid YouTube URL or video ID: {url_or_id!r}")


def fetch_captions(video_id: str) -> list[dict]:
    global _last_request_time
    from tubemcp.config import settings

    elapsed = time.monotonic() - _last_request_time
    if elapsed < settings.request_delay:
        time.sleep(settings.request_delay - elapsed)

    ytt_api = _get_api()
    _last_request_time = time.monotonic()
    try:
        fetched = ytt_api.fetch(video_id, languages=["en"])
        return [{"text": snippet.text, "start": snippet.start, "duration": snippet.duration} for snippet in fetched]
    except (NoTranscriptFound, TranscriptsDisabled) as exc:
        raise NoCaptionsError(f"No English captions available for video {video_id!r}") from exc
    except (RequestBlocked, IpBlocked) as exc:
        raise RateLimitedError("YouTube is rate-limiting requests. Try again in a few minutes.") from exc
    except (VideoUnavailable, InvalidVideoId) as exc:
        raise VideoNotFoundError(f"Video not found or unavailable: {video_id!r}") from exc


def fetch_metadata(video_id: str) -> dict:
    url = f"https://www.youtube.com/watch?v={video_id}"
    opts = {"quiet": True, "no_warnings": True, "skip_download": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)

    upload_date = info.get("upload_date")
    publish_date = None
    if upload_date and len(upload_date) == 8:
        publish_date = f"{upload_date[:4]}-{upload_date[4:6]}-{upload_date[6:8]}"

    return {
        "title": info.get("title", ""),
        "channel_name": info.get("uploader") or info.get("channel") or "",
        "thumbnail_url": info.get("thumbnail"),
        "duration_seconds": info.get("duration"),
        "publish_date": publish_date,
    }


def search_youtube(query: str, max_results: int = 5) -> list[dict]:
    """Search YouTube and return basic info for top results."""
    opts = {
        "quiet": True,
        "no_warnings": True,
        "extract_flat": "in_playlist",
        "default_search": f"ytsearch{max_results}",
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            result = ydl.extract_info(query, download=False)
    except Exception as exc:
        raise SearchError(f"YouTube search failed for query {query!r}: {exc}") from exc

    entries = result.get("entries") or []
    return [
        {
            "video_id": entry["id"],
            "title": entry.get("title", ""),
            "url": entry.get("url", ""),
            "duration_seconds": entry.get("duration"),
            "channel_name": entry.get("uploader") or entry.get("channel") or "",
        }
        for entry in entries
        if entry.get("id")
    ]


def multi_search_youtube(queries: list[str], max_per_query: int = 3) -> list[dict]:
    """Run multiple searches, deduplicate by video_id, preserve order."""
    seen = set()
    results = []
    for query in queries:
        for entry in search_youtube(query, max_results=max_per_query):
            if entry["video_id"] not in seen:
                seen.add(entry["video_id"])
                results.append(entry)
    return results


def get_transcript(video_id: str, db_path: Path) -> dict:
    from tubemcp.db import cache_video, get_cached_video

    cached = get_cached_video(db_path, video_id)
    if cached is not None:
        return {**cached, "from_cache": True}

    metadata = fetch_metadata(video_id)
    transcript = fetch_captions(video_id)
    cache_video(db_path, video_id, metadata, transcript)

    return {
        "video_id": video_id,
        "title": metadata["title"],
        "channel_name": metadata["channel_name"],
        "thumbnail_url": metadata["thumbnail_url"],
        "duration_seconds": metadata["duration_seconds"],
        "publish_date": metadata["publish_date"],
        "transcript": transcript,
        "from_cache": False,
    }
