[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)

# TubeMCP

MCP server that fetches YouTube transcripts for AI agents. Zero config — just install and go.

**What is MCP?** [Model Context Protocol](https://modelcontextprotocol.io) lets AI assistants like Claude call external tools. TubeMCP gives your AI agent the ability to read any YouTube video's transcript — useful for summarization, Q&A, research, and content analysis.

## Quick Start

### Claude Code

```bash
claude mcp add tubemcp -- uvx tubemcp
```

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "tubemcp": {
      "command": "uvx",
      "args": ["tubemcp"]
    }
  }
}
```

### Cursor

Add to your `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "tubemcp": {
      "command": "uvx",
      "args": ["tubemcp"]
    }
  }
}
```

## What you get

### `youtube_get_transcript`

Fetch the English transcript and metadata for any YouTube video.

**Input:** A YouTube URL or video ID in any of these formats:

- `https://www.youtube.com/watch?v=VIDEO_ID`
- `https://youtu.be/VIDEO_ID`
- `https://www.youtube.com/embed/VIDEO_ID`
- `https://www.youtube.com/v/VIDEO_ID`
- `VIDEO_ID` (bare 11-character ID)

**Returns:**

- `video_id` — the video ID
- `title` — video title
- `channel_name` — channel name
- `thumbnail_url` — thumbnail URL
- `duration_seconds` — video duration
- `publish_date` — publish date
- `transcript` — full transcript text
- `from_cache` — whether the result was served from cache

## Caching

Transcripts are cached locally in `~/.tubemcp/cache.db` (SQLite). Subsequent requests for the same video are served instantly from cache.

## Requirements

- Python 3.10+

## Development

```bash
git clone https://github.com/BlockBenny/tubemcp.git
cd tubemcp
pip install -e ".[dev]"
pytest
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup and guidelines.

## License

MIT
