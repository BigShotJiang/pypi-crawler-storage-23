from unittest.mock import MagicMock, patch

import pytest

import tubemcp.youtube as yt_module

# ---- extract_video_id ----


class TestExtractVideoId:
    def test_watch_url(self):
        from tubemcp.youtube import extract_video_id

        assert extract_video_id("https://www.youtube.com/watch?v=dQw4w9WgXcQ") == "dQw4w9WgXcQ"

    def test_short_url(self):
        from tubemcp.youtube import extract_video_id

        assert extract_video_id("https://youtu.be/dQw4w9WgXcQ") == "dQw4w9WgXcQ"

    def test_embed_url(self):
        from tubemcp.youtube import extract_video_id

        assert extract_video_id("https://www.youtube.com/embed/dQw4w9WgXcQ") == "dQw4w9WgXcQ"

    def test_v_url(self):
        from tubemcp.youtube import extract_video_id

        assert extract_video_id("https://www.youtube.com/v/dQw4w9WgXcQ") == "dQw4w9WgXcQ"

    def test_bare_id(self):
        from tubemcp.youtube import extract_video_id

        assert extract_video_id("dQw4w9WgXcQ") == "dQw4w9WgXcQ"

    def test_raises_for_empty_string(self):
        from tubemcp.youtube import extract_video_id

        with pytest.raises(ValueError, match="Invalid YouTube URL or video ID"):
            extract_video_id("")

    def test_raises_for_non_youtube_url(self):
        from tubemcp.youtube import extract_video_id

        with pytest.raises(ValueError, match="Invalid YouTube URL or video ID"):
            extract_video_id("https://vimeo.com/123456")

    def test_raises_for_url_without_video_id(self):
        from tubemcp.youtube import extract_video_id

        with pytest.raises(ValueError, match="Invalid YouTube URL or video ID"):
            extract_video_id("https://www.youtube.com/watch")


# ---- fetch_captions ----


class TestFetchCaptions:
    @pytest.fixture(autouse=True)
    def _reset_singleton(self):
        yt_module._ytt_api = None
        yt_module._last_request_time = 0.0
        with patch("tubemcp.youtube.time.sleep"):
            yield
        yt_module._ytt_api = None
        yt_module._last_request_time = 0.0

    def test_returns_segment_list(self):
        from tubemcp.youtube import fetch_captions

        mock_snippet1 = MagicMock()
        mock_snippet1.text = "Hello world"
        mock_snippet1.start = 0.0
        mock_snippet1.duration = 2.5
        mock_snippet2 = MagicMock()
        mock_snippet2.text = "this is a test"
        mock_snippet2.start = 2.5
        mock_snippet2.duration = 3.0
        mock_fetched = MagicMock()
        mock_fetched.__iter__ = MagicMock(return_value=iter([mock_snippet1, mock_snippet2]))
        with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_api_cls:
            mock_api_instance = MagicMock()
            mock_api_cls.return_value = mock_api_instance
            mock_api_instance.fetch.return_value = mock_fetched
            result = fetch_captions("dQw4w9WgXcQ")
        assert result == [
            {"text": "Hello world", "start": 0.0, "duration": 2.5},
            {"text": "this is a test", "start": 2.5, "duration": 3.0},
        ]

    def test_raises_no_captions_error_on_no_transcript_found(self):
        from youtube_transcript_api._errors import NoTranscriptFound

        from tubemcp.youtube import NoCaptionsError, fetch_captions

        with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_api_cls:
            mock_api_instance = MagicMock()
            mock_api_cls.return_value = mock_api_instance
            mock_api_instance.fetch.side_effect = NoTranscriptFound("vid", ["en"], MagicMock())
            with pytest.raises(NoCaptionsError):
                fetch_captions("dQw4w9WgXcQ")

    def test_raises_no_captions_error_on_transcripts_disabled(self):
        from youtube_transcript_api._errors import TranscriptsDisabled

        from tubemcp.youtube import NoCaptionsError, fetch_captions

        with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_api_cls:
            mock_api_instance = MagicMock()
            mock_api_cls.return_value = mock_api_instance
            mock_api_instance.fetch.side_effect = TranscriptsDisabled("vid")
            with pytest.raises(NoCaptionsError):
                fetch_captions("dQw4w9WgXcQ")

    def test_raises_video_not_found_on_video_unavailable(self):
        from youtube_transcript_api._errors import VideoUnavailable

        from tubemcp.youtube import VideoNotFoundError, fetch_captions

        with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_api_cls:
            mock_api_instance = MagicMock()
            mock_api_cls.return_value = mock_api_instance
            mock_api_instance.fetch.side_effect = VideoUnavailable("vid")
            with pytest.raises(VideoNotFoundError):
                fetch_captions("dQw4w9WgXcQ")

    def test_raises_rate_limited_error_on_request_blocked(self):
        from youtube_transcript_api._errors import RequestBlocked

        from tubemcp.youtube import RateLimitedError, fetch_captions

        with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_api_cls:
            mock_api_instance = MagicMock()
            mock_api_cls.return_value = mock_api_instance
            mock_api_instance.fetch.side_effect = RequestBlocked("vid")
            with pytest.raises(RateLimitedError, match="rate-limiting"):
                fetch_captions("dQw4w9WgXcQ")

    def test_raises_rate_limited_error_on_ip_blocked(self):
        from youtube_transcript_api._errors import IpBlocked

        from tubemcp.youtube import RateLimitedError, fetch_captions

        with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_api_cls:
            mock_api_instance = MagicMock()
            mock_api_cls.return_value = mock_api_instance
            mock_api_instance.fetch.side_effect = IpBlocked("vid")
            with pytest.raises(RateLimitedError, match="rate-limiting"):
                fetch_captions("dQw4w9WgXcQ")


# ---- fetch_metadata ----


class TestFetchMetadata:
    def _make_mock_info(self):
        return {
            "title": "Never Gonna Give You Up",
            "uploader": "Rick Astley",
            "thumbnail": "https://example.com/thumb.jpg",
            "duration": 213,
            "upload_date": "19870727",
        }

    def test_returns_correct_dict_shape(self):
        from tubemcp.youtube import fetch_metadata

        info = self._make_mock_info()
        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.return_value = info
            result = fetch_metadata("dQw4w9WgXcQ")
        assert result["title"] == "Never Gonna Give You Up"
        assert result["channel_name"] == "Rick Astley"
        assert result["thumbnail_url"] == "https://example.com/thumb.jpg"
        assert result["duration_seconds"] == 213
        assert result["publish_date"] == "1987-07-27"

    def test_converts_upload_date_to_iso_8601(self):
        from tubemcp.youtube import fetch_metadata

        info = self._make_mock_info()
        info["upload_date"] = "20231225"
        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.return_value = info
            result = fetch_metadata("dQw4w9WgXcQ")
        assert result["publish_date"] == "2023-12-25"

    def test_handles_missing_optional_fields(self):
        from tubemcp.youtube import fetch_metadata

        info = {
            "title": "Test Video",
            "uploader": "Test Channel",
        }
        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.return_value = info
            result = fetch_metadata("dQw4w9WgXcQ")
        assert result["thumbnail_url"] is None
        assert result["duration_seconds"] is None
        assert result["publish_date"] is None


# ---- search_youtube ----


class TestSearchYoutube:
    def _make_mock_entries(self):
        return [
            {
                "id": "abc12345678",
                "title": "Video One",
                "url": "https://youtube.com/watch?v=abc12345678",
                "duration": 120,
                "uploader": "Channel A",
            },
            {
                "id": "def12345678",
                "title": "Video Two",
                "url": "https://youtube.com/watch?v=def12345678",
                "duration": 300,
                "channel": "Channel B",
            },
        ]

    def test_returns_correct_structure(self):
        from tubemcp.youtube import search_youtube

        entries = self._make_mock_entries()
        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.return_value = {"entries": entries}
            results = search_youtube("test query", max_results=2)

        assert len(results) == 2
        assert results[0]["video_id"] == "abc12345678"
        assert results[0]["title"] == "Video One"
        assert results[0]["duration_seconds"] == 120
        assert results[0]["channel_name"] == "Channel A"
        assert results[1]["channel_name"] == "Channel B"

    def test_filters_entries_without_id(self):
        from tubemcp.youtube import search_youtube

        entries = [
            {"id": "abc12345678", "title": "Valid"},
            {"title": "No ID entry"},
            {"id": None, "title": "None ID entry"},
        ]
        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.return_value = {"entries": entries}
            results = search_youtube("test query")

        assert len(results) == 1
        assert results[0]["video_id"] == "abc12345678"

    def test_returns_empty_list_for_no_results(self):
        from tubemcp.youtube import search_youtube

        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.return_value = {"entries": []}
            results = search_youtube("obscure query no results")

        assert results == []

    def test_raises_search_error_on_yt_dlp_exception(self):
        from tubemcp.youtube import SearchError, search_youtube

        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.side_effect = Exception("network error")
            with pytest.raises(SearchError, match="YouTube search failed"):
                search_youtube("test query")


# ---- multi_search_youtube ----


class TestMultiSearchYoutube:
    def test_deduplicates_across_queries(self):
        from tubemcp.youtube import multi_search_youtube

        results_q1 = [
            {"video_id": "aaa11111111", "title": "A", "url": "", "duration_seconds": 60, "channel_name": "Ch1"},
            {"video_id": "bbb22222222", "title": "B", "url": "", "duration_seconds": 120, "channel_name": "Ch2"},
        ]
        results_q2 = [
            {
                "video_id": "bbb22222222",
                "title": "B duplicate",
                "url": "",
                "duration_seconds": 120,
                "channel_name": "Ch2",
            },
            {"video_id": "ccc33333333", "title": "C", "url": "", "duration_seconds": 180, "channel_name": "Ch3"},
        ]
        with patch("tubemcp.youtube.search_youtube", side_effect=[results_q1, results_q2]):
            results = multi_search_youtube(["query1", "query2"], max_per_query=2)
        video_ids = [r["video_id"] for r in results]
        assert video_ids == ["aaa11111111", "bbb22222222", "ccc33333333"]

    def test_preserves_order_first_occurrence_wins(self):
        from tubemcp.youtube import multi_search_youtube

        results_q1 = [
            {
                "video_id": "aaa11111111",
                "title": "A from q1",
                "url": "",
                "duration_seconds": 60,
                "channel_name": "Ch1",
            },
            {
                "video_id": "bbb22222222",
                "title": "B from q1",
                "url": "",
                "duration_seconds": 120,
                "channel_name": "Ch2",
            },
        ]
        results_q2 = [
            {
                "video_id": "bbb22222222",
                "title": "B from q2",
                "url": "",
                "duration_seconds": 120,
                "channel_name": "Ch2",
            },
            {
                "video_id": "ccc33333333",
                "title": "C from q2",
                "url": "",
                "duration_seconds": 180,
                "channel_name": "Ch3",
            },
        ]
        with patch("tubemcp.youtube.search_youtube", side_effect=[results_q1, results_q2]):
            results = multi_search_youtube(["query1", "query2"], max_per_query=2)
        # B should keep the title from q1 (first occurrence)
        b_entry = [r for r in results if r["video_id"] == "bbb22222222"][0]
        assert b_entry["title"] == "B from q1"

    def test_single_query_works(self):
        from tubemcp.youtube import multi_search_youtube

        results_q1 = [
            {"video_id": "aaa11111111", "title": "A", "url": "", "duration_seconds": 60, "channel_name": "Ch1"},
        ]
        with patch("tubemcp.youtube.search_youtube", return_value=results_q1):
            results = multi_search_youtube(["single query"], max_per_query=3)
        assert len(results) == 1
        assert results[0]["video_id"] == "aaa11111111"

    def test_empty_queries_returns_empty(self):
        from tubemcp.youtube import multi_search_youtube

        results = multi_search_youtube([])
        assert results == []

    def test_propagates_search_error(self):
        from tubemcp.youtube import SearchError, multi_search_youtube

        with patch("tubemcp.youtube.search_youtube", side_effect=SearchError("fail")):
            with pytest.raises(SearchError):
                multi_search_youtube(["query1"])


# ---- _get_api (proxy wiring) ----


class TestGetApi:
    @pytest.fixture(autouse=True)
    def _reset_singleton(self):
        yt_module._ytt_api = None
        yield
        yt_module._ytt_api = None

    def test_returns_plain_client_without_proxy(self):
        from tubemcp.youtube import _get_api

        with patch("tubemcp.config.settings") as mock_settings:
            mock_settings.proxy_url = None
            with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_cls:
                mock_cls.return_value = MagicMock()
                _get_api()
                mock_cls.assert_called_once_with(proxy_config=None)

    def test_creates_client_with_proxy_config(self):
        from tubemcp.youtube import _get_api

        with patch("tubemcp.config.settings") as mock_settings:
            mock_settings.proxy_url = "http://user:pass@proxy:8080"
            with (
                patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_cls,
                patch("tubemcp.youtube.GenericProxyConfig") as mock_proxy_cls,
            ):
                mock_cls.return_value = MagicMock()
                mock_proxy_cls.return_value = MagicMock()
                _get_api()
                mock_proxy_cls.assert_called_once_with(https_url="http://user:pass@proxy:8080")
                mock_cls.assert_called_once_with(proxy_config=mock_proxy_cls.return_value)

    def test_returns_cached_singleton(self):
        from tubemcp.youtube import _get_api

        with patch("tubemcp.config.settings") as mock_settings:
            mock_settings.proxy_url = None
            with patch("tubemcp.youtube.YouTubeTranscriptApi") as mock_cls:
                mock_cls.return_value = MagicMock()
                api1 = _get_api()
                api2 = _get_api()
                assert api1 is api2
                mock_cls.assert_called_once()


# ---- fetch_captions delay ----


class TestFetchCaptionsDelay:
    @pytest.fixture(autouse=True)
    def _reset_singleton(self):
        yt_module._ytt_api = None
        yt_module._last_request_time = 0.0
        yield
        yt_module._ytt_api = None
        yt_module._last_request_time = 0.0

    def test_sleeps_when_requests_too_close(self):
        import time

        from tubemcp.youtube import fetch_captions

        mock_snippet = MagicMock()
        mock_snippet.text = "hello"
        mock_snippet.start = 0.0
        mock_snippet.duration = 1.0
        mock_fetched = MagicMock()
        mock_fetched.__iter__ = MagicMock(return_value=iter([mock_snippet]))

        # Simulate last request was just now
        yt_module._last_request_time = time.monotonic()

        with (
            patch("tubemcp.youtube._get_api") as mock_get_api,
            patch("tubemcp.youtube.time.sleep") as mock_sleep,
            patch("tubemcp.config.settings") as mock_settings,
        ):
            mock_settings.request_delay = 2.0
            mock_api = MagicMock()
            mock_api.fetch.return_value = mock_fetched
            mock_get_api.return_value = mock_api
            fetch_captions("dQw4w9WgXcQ")
            mock_sleep.assert_called_once()
            sleep_duration = mock_sleep.call_args[0][0]
            assert 1.0 < sleep_duration <= 2.0

    def test_does_not_sleep_when_enough_time_passed(self):
        from tubemcp.youtube import fetch_captions

        mock_snippet = MagicMock()
        mock_snippet.text = "hello"
        mock_snippet.start = 0.0
        mock_snippet.duration = 1.0
        mock_fetched = MagicMock()
        mock_fetched.__iter__ = MagicMock(return_value=iter([mock_snippet]))

        # _last_request_time defaults to 0.0 — monotonic() will be large
        with (
            patch("tubemcp.youtube._get_api") as mock_get_api,
            patch("tubemcp.youtube.time.sleep") as mock_sleep,
            patch("tubemcp.config.settings") as mock_settings,
        ):
            mock_settings.request_delay = 2.0
            mock_api = MagicMock()
            mock_api.fetch.return_value = mock_fetched
            mock_get_api.return_value = mock_api
            fetch_captions("dQw4w9WgXcQ")
            mock_sleep.assert_not_called()
