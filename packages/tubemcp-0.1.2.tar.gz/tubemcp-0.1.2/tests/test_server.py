from unittest.mock import MagicMock, patch


class TestYoutubeGetTranscriptTool:
    def test_returns_correct_response_shape_for_valid_video(self, tmp_db_path):
        from tubemcp.server import youtube_get_transcript

        mock_result = {
            "video_id": "dQw4w9WgXcQ",
            "title": "Never Gonna Give You Up",
            "channel_name": "Rick Astley",
            "thumbnail_url": "https://example.com/thumb.jpg",
            "duration_seconds": 213,
            "publish_date": "1987-07-27",
            "transcript": [{"text": "We're no strangers to love...", "start": 0.0, "duration": 3.0}],
            "from_cache": False,
        }
        with (
            patch("tubemcp.server.get_transcript", return_value=mock_result),
            patch("tubemcp.server.settings") as mock_settings,
        ):
            mock_settings.db_path = tmp_db_path
            result = youtube_get_transcript("https://www.youtube.com/watch?v=dQw4w9WgXcQ")

        assert result["video_id"] == "dQw4w9WgXcQ"
        assert result["title"] == "Never Gonna Give You Up"
        assert result["transcript"] == [{"text": "We're no strangers to love...", "start": 0.0, "duration": 3.0}]
        assert result["from_cache"] is False

    def test_returns_error_string_for_invalid_url(self):
        from tubemcp.server import youtube_get_transcript

        result = youtube_get_transcript("not-a-valid-url-at-all!!")
        assert isinstance(result, str)
        assert "Invalid" in result or "invalid" in result

    def test_returns_error_string_when_no_captions(self):
        from tubemcp.server import youtube_get_transcript
        from tubemcp.youtube import NoCaptionsError

        with (
            patch("tubemcp.server.get_transcript", side_effect=NoCaptionsError("No captions")),
            patch("tubemcp.server.settings") as mock_settings,
        ):
            mock_settings.db_path = MagicMock()
            result = youtube_get_transcript("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_returns_error_string_when_video_not_found(self):
        from tubemcp.server import youtube_get_transcript
        from tubemcp.youtube import VideoNotFoundError

        with (
            patch("tubemcp.server.get_transcript", side_effect=VideoNotFoundError("Not found")),
            patch("tubemcp.server.settings") as mock_settings,
        ):
            mock_settings.db_path = MagicMock()
            result = youtube_get_transcript("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_from_cache_reflects_cache_state(self, tmp_db_path):
        from tubemcp.server import youtube_get_transcript

        mock_cached = {
            "video_id": "dQw4w9WgXcQ",
            "title": "Test",
            "channel_name": "Channel",
            "thumbnail_url": None,
            "duration_seconds": 60,
            "publish_date": None,
            "transcript": [{"text": "cached text", "start": 0.0, "duration": 3.0}],
            "from_cache": True,
        }
        with (
            patch("tubemcp.server.get_transcript", return_value=mock_cached),
            patch("tubemcp.server.settings") as mock_settings,
        ):
            mock_settings.db_path = tmp_db_path
            result = youtube_get_transcript("dQw4w9WgXcQ")
        assert result["from_cache"] is True


class TestYoutubeSearchTool:
    def _make_search_results(self):
        return [
            {
                "video_id": "abc12345678",
                "title": "Video One",
                "url": "https://youtube.com/watch?v=abc12345678",
                "duration_seconds": 120,
                "channel_name": "Channel A",
            },
            {
                "video_id": "def12345678",
                "title": "Video Two",
                "url": "https://youtube.com/watch?v=def12345678",
                "duration_seconds": 300,
                "channel_name": "Channel B",
            },
        ]

    def test_returns_correct_shape(self):
        from tubemcp.server import youtube_search

        search_results = self._make_search_results()
        with patch("tubemcp.server.multi_search_youtube", return_value=search_results):
            result = youtube_search(["test query"], max_results_per_query=2)

        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["video_id"] == "abc12345678"
        assert result[0]["title"] == "Video One"
        assert result[0]["channel_name"] == "Channel A"
        assert result[1]["video_id"] == "def12345678"

    def test_returns_error_string_when_search_fails(self):
        from tubemcp.server import youtube_search
        from tubemcp.youtube import SearchError

        with patch("tubemcp.server.multi_search_youtube", side_effect=SearchError("YouTube search failed")):
            result = youtube_search(["test query"])
        assert isinstance(result, str)
        assert "search failed" in result.lower()
