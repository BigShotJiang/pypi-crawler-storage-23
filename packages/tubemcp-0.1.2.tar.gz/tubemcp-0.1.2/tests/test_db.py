import sqlite3


class TestCacheVideoAndGetCachedVideo:
    def test_store_and_retrieve_video(self, tmp_db_path):
        from tubemcp.db import cache_video, get_cached_video, init_db

        init_db(tmp_db_path)
        metadata = {
            "title": "Test Video",
            "channel_name": "Test Channel",
            "thumbnail_url": "https://example.com/thumb.jpg",
            "duration_seconds": 300,
            "publish_date": "2024-01-15",
        }
        transcript = [{"text": "This is the transcript text.", "start": 0.0, "duration": 3.0}]
        cache_video(tmp_db_path, "abc12345678", metadata, transcript)

        result = get_cached_video(tmp_db_path, "abc12345678")
        assert result is not None
        assert result["video_id"] == "abc12345678"
        assert result["title"] == "Test Video"
        assert result["channel_name"] == "Test Channel"
        assert result["thumbnail_url"] == "https://example.com/thumb.jpg"
        assert result["duration_seconds"] == 300
        assert result["publish_date"] == "2024-01-15"
        assert result["transcript"] == transcript

    def test_returns_none_for_nonexistent_video(self, tmp_db_path):
        from tubemcp.db import get_cached_video, init_db

        init_db(tmp_db_path)
        result = get_cached_video(tmp_db_path, "notexist123")
        assert result is None

    def test_old_plaintext_cache_returns_none(self, tmp_db_path):
        from tubemcp.db import get_cached_video, init_db

        init_db(tmp_db_path)
        # Insert plain text directly into DB (old format)
        conn = sqlite3.connect(tmp_db_path)
        conn.execute(
            "INSERT INTO videos (video_id, title, channel_name) VALUES (?, ?, ?)",
            ("oldformat11", "Old Video", "Channel"),
        )
        conn.execute(
            "INSERT INTO transcripts (video_id, language, content) VALUES (?, 'en', ?)",
            ("oldformat11", "plain text transcript"),
        )
        conn.commit()
        conn.close()

        result = get_cached_video(tmp_db_path, "oldformat11")
        assert result is None

    def test_upsert_updates_existing_record(self, tmp_db_path):
        from tubemcp.db import cache_video, get_cached_video, init_db

        init_db(tmp_db_path)
        metadata_v1 = {
            "title": "Original Title",
            "channel_name": "Channel",
            "thumbnail_url": None,
            "duration_seconds": 100,
            "publish_date": None,
        }
        old_transcript = [{"text": "old transcript", "start": 0.0, "duration": 2.0}]
        cache_video(tmp_db_path, "abc12345678", metadata_v1, old_transcript)

        metadata_v2 = {
            "title": "Updated Title",
            "channel_name": "Channel",
            "thumbnail_url": None,
            "duration_seconds": 100,
            "publish_date": None,
        }
        new_transcript = [{"text": "new transcript", "start": 0.0, "duration": 2.0}]
        cache_video(tmp_db_path, "abc12345678", metadata_v2, new_transcript)

        result = get_cached_video(tmp_db_path, "abc12345678")
        assert result["title"] == "Updated Title"
        assert result["transcript"] == new_transcript


class TestGetTranscriptCacheOrchestration:
    def test_returns_cached_data_without_calling_fetch(self, tmp_db_path, monkeypatch):
        from unittest.mock import patch

        from tubemcp.db import cache_video, init_db

        init_db(tmp_db_path)
        metadata = {
            "title": "Cached Video",
            "channel_name": "Channel",
            "thumbnail_url": None,
            "duration_seconds": 60,
            "publish_date": "2024-06-01",
        }
        transcript = [{"text": "cached transcript text", "start": 0.0, "duration": 3.0}]
        cache_video(tmp_db_path, "cached12345", metadata, transcript)

        with (
            patch("tubemcp.youtube.fetch_metadata") as mock_meta,
            patch("tubemcp.youtube.fetch_captions") as mock_caps,
        ):
            from tubemcp.youtube import get_transcript

            result = get_transcript("cached12345", tmp_db_path)

        mock_meta.assert_not_called()
        mock_caps.assert_not_called()
        assert result["from_cache"] is True
        assert result["transcript"] == transcript

    def test_calls_fetch_on_cache_miss(self, tmp_db_path):
        from unittest.mock import patch

        from tubemcp.db import init_db

        init_db(tmp_db_path)

        metadata = {
            "title": "Fresh Video",
            "channel_name": "Channel",
            "thumbnail_url": None,
            "duration_seconds": 90,
            "publish_date": "2024-07-01",
        }
        fresh_transcript = [{"text": "fresh transcript", "start": 0.0, "duration": 3.0}]
        with (
            patch("tubemcp.youtube.fetch_metadata", return_value=metadata) as mock_meta,
            patch("tubemcp.youtube.fetch_captions", return_value=fresh_transcript) as mock_caps,
        ):
            from tubemcp.youtube import get_transcript

            result = get_transcript("fresh12345x", tmp_db_path)

        mock_meta.assert_called_once_with("fresh12345x")
        mock_caps.assert_called_once_with("fresh12345x")
        assert result["from_cache"] is False
        assert result["transcript"] == fresh_transcript

    def test_stores_result_in_cache_after_miss(self, tmp_db_path):
        from unittest.mock import patch

        from tubemcp.db import get_cached_video, init_db

        init_db(tmp_db_path)

        metadata = {
            "title": "Fresh Video",
            "channel_name": "Channel",
            "thumbnail_url": None,
            "duration_seconds": 90,
            "publish_date": None,
        }
        stored_transcript = [{"text": "stored transcript", "start": 0.0, "duration": 3.0}]
        with (
            patch("tubemcp.youtube.fetch_metadata", return_value=metadata),
            patch("tubemcp.youtube.fetch_captions", return_value=stored_transcript),
        ):
            from tubemcp.youtube import get_transcript

            get_transcript("store12345x", tmp_db_path)

        cached = get_cached_video(tmp_db_path, "store12345x")
        assert cached is not None
        assert cached["transcript"] == stored_transcript

    def test_from_cache_flag_set_correctly(self, tmp_db_path):
        from unittest.mock import patch

        from tubemcp.db import init_db

        init_db(tmp_db_path)

        metadata = {
            "title": "Flag Test",
            "channel_name": "Channel",
            "thumbnail_url": None,
            "duration_seconds": 10,
            "publish_date": None,
        }
        # First call — cache miss
        transcript = [{"text": "transcript", "start": 0.0, "duration": 3.0}]
        with (
            patch("tubemcp.youtube.fetch_metadata", return_value=metadata),
            patch("tubemcp.youtube.fetch_captions", return_value=transcript),
        ):
            from tubemcp.youtube import get_transcript

            result_miss = get_transcript("flagtest123x", tmp_db_path)

        assert result_miss["from_cache"] is False

        # Second call — cache hit
        with (
            patch("tubemcp.youtube.fetch_metadata") as mock_meta,
            patch("tubemcp.youtube.fetch_captions") as mock_caps,
        ):
            from tubemcp.youtube import get_transcript

            result_hit = get_transcript("flagtest123x", tmp_db_path)

        assert result_hit["from_cache"] is True
        mock_meta.assert_not_called()
        mock_caps.assert_not_called()
