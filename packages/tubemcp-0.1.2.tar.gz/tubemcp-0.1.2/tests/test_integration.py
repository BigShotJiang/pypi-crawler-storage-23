"""
Integration tests for TubeMCP.

These tests mock external APIs (YouTube) but use real SQLite and real
URL parsing/caching flows end-to-end.
"""

from unittest.mock import MagicMock, patch


class TestTranscriptFlowEndToEnd:
    def test_fetch_cache_and_refetch_without_external_calls(self, tmp_db_path):
        """Fetch transcript -> verify cached -> re-fetch -> verify from_cache=True, no external calls."""
        from tubemcp.db import init_db
        from tubemcp.server import youtube_get_transcript

        init_db(tmp_db_path)

        mock_metadata = {
            "title": "Integration Test Video",
            "channel_name": "Test Channel",
            "thumbnail_url": "https://example.com/thumb.jpg",
            "duration_seconds": 300,
            "publish_date": "2024-01-01",
        }

        mock_transcript = [{"text": "integration test transcript text", "start": 0.0, "duration": 5.0}]

        with (
            patch("tubemcp.youtube.fetch_metadata", return_value=mock_metadata),
            patch("tubemcp.youtube.fetch_captions", return_value=mock_transcript),
            patch("tubemcp.server.settings") as mock_settings,
        ):
            mock_settings.db_path = tmp_db_path

            # First fetch — cache miss
            result1 = youtube_get_transcript("https://www.youtube.com/watch?v=intgr8test1")

        assert isinstance(result1, dict)
        assert result1["video_id"] == "intgr8test1"
        assert result1["title"] == "Integration Test Video"
        assert result1["transcript"] == mock_transcript
        assert result1["from_cache"] is False

        # Second fetch — cache hit, no external calls
        with (
            patch("tubemcp.youtube.fetch_metadata") as mock_meta2,
            patch("tubemcp.youtube.fetch_captions") as mock_caps2,
            patch("tubemcp.server.settings") as mock_settings2,
        ):
            mock_settings2.db_path = tmp_db_path
            result2 = youtube_get_transcript("https://www.youtube.com/watch?v=intgr8test1")

        mock_meta2.assert_not_called()
        mock_caps2.assert_not_called()
        assert result2["from_cache"] is True
        assert result2["transcript"] == mock_transcript


class TestErrorPropagation:
    def test_invalid_url_returns_descriptive_error(self):
        from tubemcp.server import youtube_get_transcript

        result = youtube_get_transcript("https://not-youtube.com/video/123")
        assert isinstance(result, str)
        assert "Invalid" in result or "invalid" in result

    def test_no_english_captions_returns_error_message(self, tmp_db_path):
        from tubemcp.db import init_db
        from tubemcp.server import youtube_get_transcript
        from tubemcp.youtube import NoCaptionsError

        init_db(tmp_db_path)

        with (
            patch(
                "tubemcp.youtube.fetch_metadata",
                return_value={
                    "title": "No Captions Video",
                    "channel_name": "Channel",
                    "thumbnail_url": None,
                    "duration_seconds": 60,
                    "publish_date": None,
                },
            ),
            patch(
                "tubemcp.youtube.fetch_captions",
                side_effect=NoCaptionsError("No English captions"),
            ),
            patch("tubemcp.server.settings") as mock_settings,
        ):
            mock_settings.db_path = tmp_db_path
            result = youtube_get_transcript("https://www.youtube.com/watch?v=nocaptions1")

        assert isinstance(result, str)
        assert len(result) > 0

    def test_video_not_found_returns_error_message(self, tmp_db_path):
        from tubemcp.db import init_db
        from tubemcp.server import youtube_get_transcript
        from tubemcp.youtube import VideoNotFoundError

        init_db(tmp_db_path)

        with (
            patch("tubemcp.youtube.fetch_metadata", side_effect=VideoNotFoundError("Video not found")),
            patch("tubemcp.server.settings") as mock_settings,
        ):
            mock_settings.db_path = tmp_db_path
            result = youtube_get_transcript("https://www.youtube.com/watch?v=notfound123")

        assert isinstance(result, str)
        assert len(result) > 0


class TestSearchFlow:
    def test_search_returns_metadata_only(self, tmp_db_path):
        """Search returns metadata without fetching transcripts."""
        from tubemcp.server import youtube_search

        mock_search_results = [
            {
                "id": "srch1test11",
                "title": "Search Result 1",
                "url": "https://youtube.com/watch?v=srch1test11",
                "duration": 180,
                "uploader": "Channel X",
            },
            {
                "id": "srch2test22",
                "title": "Search Result 2",
                "url": "https://youtube.com/watch?v=srch2test22",
                "duration": 240,
                "uploader": "Channel Y",
            },
        ]

        with patch("tubemcp.youtube.yt_dlp.YoutubeDL") as mock_ydl_cls:
            mock_ydl = MagicMock()
            mock_ydl_cls.return_value.__enter__ = MagicMock(return_value=mock_ydl)
            mock_ydl_cls.return_value.__exit__ = MagicMock(return_value=False)
            mock_ydl.extract_info.return_value = {"entries": mock_search_results}

            result = youtube_search(["test search query"])

        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["video_id"] == "srch1test11"
        assert result[0]["title"] == "Search Result 1"
        assert result[1]["video_id"] == "srch2test22"
