"""Schema detection from DataFrames and named data sources."""

from __future__ import annotations

import logging
import re
import warnings
from typing import TYPE_CHECKING

import pandas as pd

from datacheck.schema.models import ColumnSchema, ColumnType, TableSchema

if TYPE_CHECKING:
    from datacheck.config.source import SourceConfig
    from datacheck.connectors.base import DatabaseConnector

logger = logging.getLogger(__name__)

# Regex for date-only strings like "2024-01-15"
_DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class SchemaDetector:
    """Detect schema from a pandas DataFrame or directly from a data source."""

    # ------------------------------------------------------------------
    # Public: DataFrame-based detection (used internally after LIMIT 0)
    # ------------------------------------------------------------------

    @staticmethod
    def detect(
        df: pd.DataFrame,
        name: str = "dataset",
        source: str | None = None,
    ) -> TableSchema:
        """Detect schema from a pandas DataFrame.

        Args:
            df: DataFrame to analyse
            name: Name for the schema
            source: Source identifier (file path, table name, etc.)

        Returns:
            TableSchema object
        """
        columns = []

        for position, col_name in enumerate(df.columns):
            col_data = df[col_name]

            dtype = SchemaDetector._detect_column_type(col_data)

            null_count = int(col_data.isnull().sum())
            null_percentage = null_count / len(df) if len(df) > 0 else 0.0
            try:
                unique_count = int(col_data.nunique())
            except (TypeError, NotImplementedError, Exception):
                unique_count = -1

            col_schema = ColumnSchema(
                name=str(col_name),
                dtype=dtype,
                nullable=(null_count > 0) or (len(df) < 10_000),
                position=position,
                unique_values=unique_count,
                null_percentage=null_percentage,
            )

            columns.append(col_schema)

        return TableSchema(
            name=name,
            columns=columns,
            row_count=len(df),
            source=source,
        )

    # ------------------------------------------------------------------
    # Public: Source-based detection (no full data load)
    # ------------------------------------------------------------------

    @staticmethod
    def detect_from_source(
        source_config: SourceConfig,
        name: str = "dataset",
        source_identifier: str | None = None,
        table: str | None = None,
        query: str | None = None,
    ) -> TableSchema:
        """Detect schema using metadata queries — no full data load.

        Dispatches to the most efficient strategy per source type:
        - duckdb / s3 : DuckDB ``SUMMARIZE`` query
        - postgresql / mysql / redshift : ``information_schema.columns`` + COUNT(*)
        - snowflake / bigquery : ``INFORMATION_SCHEMA.COLUMNS`` + COUNT(*)

        Args:
            source_config: Named source configuration
            name: Desired schema name
            source_identifier: Human-readable source label for display
            table: Table or file path override
            query: Custom SQL query (schema inferred from zero-row result)

        Returns:
            TableSchema with column types, nullable flags, and row count
        """
        from datacheck.connectors.factory import create_connector
        from datacheck.exceptions import DataLoadError

        connector = create_connector(source_config)
        stype = source_config.type

        with connector:
            if stype in ("duckdb", "s3"):
                return SchemaDetector._detect_via_summarize(
                    connector, source_config, name,
                    source_identifier, table, query,
                )
            elif stype in ("postgresql", "mysql", "redshift"):
                return SchemaDetector._detect_via_information_schema(
                    connector, source_config, name,
                    source_identifier, table, query,
                )
            elif stype == "snowflake":
                return SchemaDetector._detect_via_snowflake(
                    connector, source_config, name,
                    source_identifier, table, query,
                )
            elif stype == "bigquery":
                return SchemaDetector._detect_via_bigquery(
                    connector, source_config, name,
                    source_identifier, table, query,
                )
            else:
                raise DataLoadError(
                    f"Schema detection is not supported for source type '{stype}'"
                )
        raise AssertionError("unreachable")  # pragma: no cover

    # ------------------------------------------------------------------
    # Private: per-backend detection strategies
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_via_summarize(
        connector: DatabaseConnector,
        source_config: SourceConfig,
        name: str,
        source_identifier: str | None,
        table: str | None,
        query: str | None,
    ) -> TableSchema:
        """DuckDB SUMMARIZE — zero rows transferred, full column stats."""
        from datacheck.exceptions import DataLoadError

        inner = SchemaDetector._build_duckdb_inner(source_config, table, query)
        summarize_sql = f"SUMMARIZE SELECT * FROM {inner}"

        try:
            summ_df = connector.execute_query(summarize_sql)
        except Exception as e:
            raise DataLoadError(f"SUMMARIZE query failed: {e}") from e

        # Row count — cheap COUNT(*) on the same source
        try:
            cnt_df = connector.execute_query(f"SELECT COUNT(*) AS cnt FROM {inner}")
            row_count = int(cnt_df.iloc[0]["cnt"])
        except Exception:
            row_count = 0

        columns = []
        for pos, (_, row) in enumerate(summ_df.iterrows()):
            col_name = str(row["column_name"])
            duckdb_type = str(row.get("column_type", "")).upper()
            null_pct_raw = row.get("null_percentage", 0.0)
            null_pct = float(null_pct_raw) if null_pct_raw is not None else 0.0
            approx_unique = row.get("approx_unique")
            unique_count: int | None = None
            if approx_unique is not None and str(approx_unique) not in ("None", "nan"):
                try:
                    unique_count = int(approx_unique)
                except (ValueError, TypeError) as exc:
                    logger.debug(
                        "Could not parse approx_unique value %r for column %r: %s",
                        approx_unique,
                        col_name,
                        exc,
                    )

            columns.append(ColumnSchema(
                name=col_name,
                dtype=SchemaDetector._map_duckdb_type(duckdb_type),
                nullable=null_pct > 0,
                position=pos,
                unique_values=unique_count,
                null_percentage=null_pct,
            ))

        return TableSchema(
            name=name,
            columns=columns,
            row_count=row_count,
            source=source_identifier or source_config.name,
        )

    @staticmethod
    def _detect_via_information_schema(
        connector: DatabaseConnector,
        source_config: SourceConfig,
        name: str,
        source_identifier: str | None,
        table: str | None,
        query: str | None,
    ) -> TableSchema:
        """PostgreSQL / MySQL / Redshift — information_schema + COUNT(*)."""
        from datacheck.exceptions import DataLoadError

        # Custom query: probe with LIMIT 0 (no rows, correct dtypes)
        if query:
            return SchemaDetector._detect_via_limit0(
                connector, query, name, source_identifier or source_config.name
            )

        if not table:
            raise DataLoadError(
                f"Schema detection for '{source_config.type}' source requires "
                "--table (or --query)"
            )

        connector._validate_table_name(table)  # prevent injection

        # MySQL uses database name as schema; others use 'schema' or 'public'
        if source_config.type == "mysql":
            schema_filter = (
                f"table_schema = '{source_config.connection.get('database', '')}' "
                f"AND table_name = '{table}'"
            )
        else:
            schema_val = source_config.connection.get("schema", "public")
            schema_filter = (
                f"table_schema = '{schema_val}' AND table_name = '{table}'"
            )

        info_sql = (
            "SELECT column_name, data_type, is_nullable, ordinal_position "
            "FROM information_schema.columns "
            f"WHERE {schema_filter} "
            "ORDER BY ordinal_position"
        )

        try:
            info_df = connector.execute_query(info_sql)
        except Exception as e:
            raise DataLoadError(f"information_schema query failed: {e}") from e

        if info_df.empty:
            raise DataLoadError(
                f"No columns found for table '{table}'. "
                "Verify the table name and schema setting."
            )

        try:
            cnt_df = connector.execute_query(
                f'SELECT COUNT(*) AS cnt FROM "{table}"'  # nosec B608
            )
            row_count = int(cnt_df.iloc[0]["cnt"])
        except Exception:
            row_count = 0

        columns = []
        for _, row in info_df.iterrows():
            is_nullable = str(row.get("is_nullable", "YES")).upper() == "YES"
            position = max(0, int(row.get("ordinal_position", 1)) - 1)
            columns.append(ColumnSchema(
                name=str(row["column_name"]),
                dtype=SchemaDetector._map_sql_type(str(row["data_type"])),
                nullable=is_nullable,
                position=position,
                unique_values=None,
                null_percentage=0.0,
            ))

        return TableSchema(
            name=name,
            columns=columns,
            row_count=row_count,
            source=source_identifier or source_config.name,
        )

    @staticmethod
    def _detect_via_snowflake(
        connector: DatabaseConnector,
        source_config: SourceConfig,
        name: str,
        source_identifier: str | None,
        table: str | None,
        query: str | None,
    ) -> TableSchema:
        """Snowflake — INFORMATION_SCHEMA.COLUMNS + COUNT(*)."""
        from datacheck.exceptions import DataLoadError

        if query:
            return SchemaDetector._detect_via_limit0(
                connector, query, name, source_identifier or source_config.name
            )

        if not table:
            raise DataLoadError(
                "Schema detection for Snowflake requires --table (or --query)"
            )

        schema_val = source_config.connection.get("schema", "PUBLIC").upper()
        info_sql = (
            "SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, ORDINAL_POSITION "
            "FROM INFORMATION_SCHEMA.COLUMNS "
            f"WHERE TABLE_NAME = UPPER('{table}') "
            f"AND TABLE_SCHEMA = '{schema_val}' "
            "ORDER BY ORDINAL_POSITION"
        )

        try:
            info_df = connector.execute_query(info_sql)
        except Exception as e:
            raise DataLoadError(f"Snowflake INFORMATION_SCHEMA query failed: {e}") from e

        if info_df.empty:
            raise DataLoadError(f"No columns found for Snowflake table '{table}'.")

        try:
            cnt_df = connector.execute_query(
                f'SELECT COUNT(*) AS cnt FROM "{table}"'  # nosec B608
            )
            row_count = int(cnt_df.iloc[0]["cnt"])
        except Exception:
            row_count = 0

        columns = []
        for _, row in info_df.iterrows():
            is_nullable = str(row.get("IS_NULLABLE", "Y")).upper() in ("Y", "YES")
            position = max(0, int(row.get("ORDINAL_POSITION", 1)) - 1)
            columns.append(ColumnSchema(
                name=str(row["COLUMN_NAME"]),
                dtype=SchemaDetector._map_sql_type(str(row["DATA_TYPE"])),
                nullable=is_nullable,
                position=position,
                unique_values=None,
                null_percentage=0.0,
            ))

        return TableSchema(
            name=name,
            columns=columns,
            row_count=row_count,
            source=source_identifier or source_config.name,
        )

    @staticmethod
    def _detect_via_bigquery(
        connector: DatabaseConnector,
        source_config: SourceConfig,
        name: str,
        source_identifier: str | None,
        table: str | None,
        query: str | None,
    ) -> TableSchema:
        """BigQuery — INFORMATION_SCHEMA.COLUMNS + COUNT(*)."""
        from datacheck.exceptions import DataLoadError

        if query:
            return SchemaDetector._detect_via_limit0(
                connector, query, name, source_identifier or source_config.name
            )

        if not table:
            raise DataLoadError(
                "Schema detection for BigQuery requires --table (or --query)"
            )

        project_id = source_config.connection.get("project_id", "")
        dataset_id = source_config.connection.get("dataset_id", "")

        info_sql = (
            f"SELECT column_name, data_type, is_nullable, ordinal_position "
            f"FROM `{project_id}.{dataset_id}.INFORMATION_SCHEMA.COLUMNS` "
            f"WHERE table_name = '{table}' "
            "ORDER BY ordinal_position"
        )

        try:
            info_df = connector.execute_query(info_sql)
        except Exception as e:
            raise DataLoadError(f"BigQuery INFORMATION_SCHEMA query failed: {e}") from e

        if info_df.empty:
            raise DataLoadError(f"No columns found for BigQuery table '{table}'.")

        try:
            cnt_df = connector.execute_query(
                f"SELECT COUNT(*) AS cnt FROM `{project_id}.{dataset_id}.{table}`"
            )
            row_count = int(cnt_df.iloc[0]["cnt"])
        except Exception:
            row_count = 0

        columns = []
        for _, row in info_df.iterrows():
            is_nullable = str(row.get("is_nullable", "YES")).upper() == "YES"
            position = max(0, int(row.get("ordinal_position", 1)) - 1)
            columns.append(ColumnSchema(
                name=str(row["column_name"]),
                dtype=SchemaDetector._map_sql_type(str(row["data_type"])),
                nullable=is_nullable,
                position=position,
                unique_values=None,
                null_percentage=0.0,
            ))

        return TableSchema(
            name=name,
            columns=columns,
            row_count=row_count,
            source=source_identifier or source_config.name,
        )

    @staticmethod
    def _detect_via_limit0(
        connector: DatabaseConnector,
        query: str,
        name: str,
        source_identifier: str,
    ) -> TableSchema:
        """Probe a custom query with LIMIT 0 — zero rows, correct column types."""
        from datacheck.exceptions import DataLoadError

        probe_sql = f"SELECT * FROM ({query}) AS _schema_probe LIMIT 0"
        try:
            df = connector.execute_query(probe_sql)
        except Exception as e:
            raise DataLoadError(f"Schema probe query failed: {e}") from e

        # Reuse the DataFrame-based detector on the empty result
        schema = SchemaDetector.detect(df, name=name, source=source_identifier)
        # Row count unknown without running the full query
        schema.row_count = 0
        return schema

    # ------------------------------------------------------------------
    # Private: helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_duckdb_inner(
        source_config: SourceConfig,
        table: str | None,
        query: str | None,
    ) -> str:
        """Build the inner expression for a DuckDB SUMMARIZE call."""
        if query:
            return f"({query})"

        if source_config.type == "duckdb":
            ref = table or source_config.connection.get("path", "")
            return "'" + ref.replace("'", "''") + "'"

        # s3
        bucket = source_config.connection.get("bucket", "")
        default_path = source_config.connection.get("path", "")
        if table:
            if table.startswith(("s3://", "s3a://")):
                full_path = table
            else:
                full_path = f"s3://{bucket}/{table.lstrip('/')}"
        else:
            full_path = f"s3://{bucket}/{default_path.lstrip('/')}"
        return "'" + full_path.replace("'", "''") + "'"

    @staticmethod
    def _map_duckdb_type(duckdb_type: str) -> ColumnType:
        """Map a DuckDB type name to ColumnType."""
        t = duckdb_type.upper().split("(")[0].strip()  # strip precision e.g. DECIMAL(18,2)
        if t in {
            "BIGINT", "INTEGER", "INT", "INT4", "INT8", "INT2", "INT1",
            "TINYINT", "SMALLINT", "HUGEINT", "UBIGINT", "UINTEGER",
            "USMALLINT", "UTINYINT", "MEDIUMINT",
        }:
            return ColumnType.INTEGER
        if t in {"FLOAT", "DOUBLE", "REAL", "FLOAT4", "FLOAT8", "DECIMAL", "NUMERIC"}:
            return ColumnType.FLOAT
        if t in {"BOOLEAN", "BOOL"}:
            return ColumnType.BOOLEAN
        if t.startswith("TIMESTAMP") or t in {"DATETIME"}:
            return ColumnType.DATETIME
        if t == "DATE":
            return ColumnType.DATE
        if t in {"VARCHAR", "TEXT", "CHAR", "BLOB", "STRING", "JSON", "UUID"}:
            return ColumnType.STRING
        return ColumnType.UNKNOWN

    @staticmethod
    def _map_sql_type(sql_type: str) -> ColumnType:
        """Map an information_schema data_type string to ColumnType."""
        t = sql_type.lower().strip()
        # Integer
        if t in {
            "integer", "int", "int2", "int4", "int8", "bigint", "smallint",
            "tinyint", "mediumint", "serial", "bigserial", "smallserial",
        }:
            return ColumnType.INTEGER
        # Float
        if t in {"real", "float", "double precision", "float4", "float8"} or \
                t.startswith(("decimal", "numeric", "number")):
            return ColumnType.FLOAT
        # Boolean
        if t in {"boolean", "bool", "bit"}:
            return ColumnType.BOOLEAN
        # Datetime
        if "timestamp" in t or t in {"datetime"}:
            return ColumnType.DATETIME
        # Date
        if t == "date":
            return ColumnType.DATE
        # Fallback to STRING for all text and unknown types
        return ColumnType.STRING

    # ------------------------------------------------------------------
    # Private: dtype detection for DataFrame path
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_column_type(series: pd.Series) -> ColumnType:
        """Detect column type from a pandas Series."""
        dtype_str = str(series.dtype).lower()

        if "int" in dtype_str:
            return ColumnType.INTEGER
        if "float" in dtype_str or "double" in dtype_str:
            return ColumnType.FLOAT
        if "bool" in dtype_str:
            return ColumnType.BOOLEAN
        if "datetime" in dtype_str or "timestamp" in dtype_str:
            return ColumnType.DATETIME
        if "date" in dtype_str and "datetime" not in dtype_str:
            return ColumnType.DATE
        if dtype_str in ("object", "str") or dtype_str.startswith("string"):
            return SchemaDetector._infer_object_type(series)
        if "category" in dtype_str:
            return ColumnType.STRING

        return ColumnType.UNKNOWN

    @staticmethod
    def _infer_object_type(series: pd.Series) -> ColumnType:
        """Infer type for object-dtype columns via sampling."""
        non_null = series.dropna()
        if len(non_null) == 0:
            return ColumnType.STRING

        sample = non_null.head(100)

        if all(isinstance(v, str) for v in sample):
            # Check for date-only strings first (e.g. "2024-01-15")
            if all(_DATE_PATTERN.match(str(v)) for v in sample):
                return ColumnType.DATE

            # Try datetime parsing
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=UserWarning)
                warnings.filterwarnings("ignore", category=FutureWarning)
                try:
                    pd.to_datetime(sample, errors="raise")
                    return ColumnType.DATETIME
                except (ValueError, TypeError):
                    try:
                        pd.to_datetime(sample, errors="raise", utc=True)
                        return ColumnType.DATETIME
                    except (ValueError, TypeError):
                        pass

            return ColumnType.STRING

        # Boolean-like values
        bool_values = {True, False, "true", "false", "True", "False", "1", "0"}

        def _is_bool_like(value: object) -> bool:
            """Safely test membership in bool_values without raising TypeError."""
            try:
                return value in bool_values
            except TypeError:
                return False

        if all(_is_bool_like(v) for v in sample):
            return ColumnType.BOOLEAN

        # Numeric strings
        try:
            pd.to_numeric(sample, errors="raise")
            if all(float(v).is_integer() for v in sample if v is not None):
                return ColumnType.INTEGER
            return ColumnType.FLOAT
        except (ValueError, TypeError):
            pass

        return ColumnType.STRING

    @staticmethod
    def from_dataframe(
        df: pd.DataFrame,
        name: str = "dataset",
        source: str | None = None,
    ) -> TableSchema:
        """Alias for detect()."""
        return SchemaDetector.detect(df, name=name, source=source)
