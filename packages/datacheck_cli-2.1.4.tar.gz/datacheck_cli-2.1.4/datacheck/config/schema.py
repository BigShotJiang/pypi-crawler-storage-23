"""JSON Schema for DataCheck configuration."""

from typing import Any

# Valid rule types supported by DataCheck
VALID_RULE_TYPES = [
    # Basic rules
    "not_null",
    "min",
    "max",
    "unique",
    "regex",
    "allowed_values",
    "type",
    "min_length",
    "max_length",
    # Freshness rules
    "max_age",
    "timestamp_range",
    "date_range",
    "no_future_timestamps",
    "date_format_valid",
    "date_format",
    # Relationship rules
    "sum_equals",
    "unique_combination",
    # Range rules
    "range",
    "positive",
    "non_negative",
    # Boolean rules
    "boolean",
]

# Valid data source types (for named sources in sources_file)
VALID_DATA_SOURCE_TYPES = [
    "postgresql",
    "mysql",
    "snowflake",
    "bigquery",
    "redshift",
    "duckdb",
    "s3",
]

# Valid output formats
VALID_OUTPUT_FORMATS = [
    "terminal",
    "json",
    "sarif",
    "markdown",
    "csv",
]

# JSON Schema for DataCheck configuration
CONFIG_SCHEMA: dict[str, Any] = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "DataCheck Configuration",
    "description": "Configuration schema for DataCheck validation rules",
    "type": "object",
    "properties": {
        "extends": {
            "type": "string",
            "description": "Path to base config to extend (inheritance)",
        },
        "version": {
            "type": "string",
            "description": "Config schema version",
            "pattern": "^[0-9]+\\.[0-9]+$",
        },
        "checks": {
            "type": "array",
            "description": "List of validation checks",
            "items": {
                "type": "object",
                "required": ["name", "column", "rules"],
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Unique check name",
                        "minLength": 1,
                    },
                    "column": {
                        "type": "string",
                        "description": "Column to validate",
                        "minLength": 1,
                    },
                    "rules": {
                        "type": "object",
                        "description": "Validation rules to apply",
                        "minProperties": 1,
                    },
                    "enabled": {
                        "type": "boolean",
                        "default": True,
                        "description": "Whether this check is enabled",
                    },
                    "description": {
                        "type": "string",
                        "description": "Human-readable description of this check",
                    },
                    "severity": {
                        "type": "string",
                        "enum": ["error", "warning", "info"],
                        "default": "error",
                        "description": "Severity level of failures",
                    },
                    "threshold": {
                        "type": "number",
                        "minimum": 0,
                        "maximum": 100,
                        "description": "Maximum allowed violation rate % (0–100). Omit for strict pass/fail.",
                    },
                },
            },
        },
        "reporting": {
            "type": "object",
            "description": "Output and reporting configuration",
            "properties": {
                "format": {
                    "type": "string",
                    "enum": VALID_OUTPUT_FORMATS,
                    "default": "terminal",
                },
                "output_file": {
                    "type": "string",
                    "description": "Path to output file",
                },
                "export_failures": {
                    "type": "boolean",
                    "default": False,
                    "description": "Export failed rows to file",
                },
                "failures_file": {
                    "type": "string",
                    "description": "Path to failures export file",
                },
                "show_summary": {
                    "type": "boolean",
                    "default": True,
                },
                "show_details": {
                    "type": "boolean",
                    "default": True,
                },
            },
        },
        "query": {
            "type": "string",
            "description": "Default custom SQL query (overridable via --query CLI flag)",
        },
        "metadata": {
            "type": "object",
            "description": "Additional metadata",
            "properties": {
                "author": {"type": "string"},
                "created": {"type": "string"},
                "description": {"type": "string"},
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
        },
    },
    "required": ["checks"],
}


def get_valid_rule_types() -> list[str]:
    """Get list of valid rule types."""
    return VALID_RULE_TYPES.copy()


def get_valid_data_source_types() -> list[str]:
    """Get list of valid data source types."""
    return VALID_DATA_SOURCE_TYPES.copy()


__all__ = [
    "CONFIG_SCHEMA",
    "VALID_RULE_TYPES",
    "VALID_DATA_SOURCE_TYPES",
    "VALID_OUTPUT_FORMATS",
    "get_valid_rule_types",
    "get_valid_data_source_types",
]
