"""MySQL database connector."""


import pandas as pd
import logging

try:
    import mysql.connector
    from mysql.connector import Error as MySQLError
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False

from datacheck.connectors.base import DatabaseConnector
from datacheck.exceptions import DataLoadError

logger = logging.getLogger(__name__)


class MySQLConnector(DatabaseConnector):
    """MySQL database connector.

    Connects to MySQL databases using mysql-connector-python and loads data
    into pandas DataFrames.

    Example:
        >>> connector = MySQLConnector("mysql://user:pass@localhost:3306/mydb")
        >>> with connector:
        ...     df = connector.load_table("users")
    """

    def __init__(self, connection_string: str) -> None:
        """Initialize MySQL connector.

        Args:
            connection_string: MySQL connection string

        Raises:
            DataLoadError: If mysql-connector-python is not installed
        """
        if not MYSQL_AVAILABLE:
            raise DataLoadError(
                "MySQL connector dependencies are not installed. "
                "Install with: pip install 'datacheck[mysql]'"
            )

        super().__init__(connection_string)
        self.connection: object = None
        self._parse_connection_string()

    def _parse_connection_string(self) -> None:
        """Parse MySQL connection string into components."""
        # Simple parsing of mysql://user:pass@host:port/database
        try:
            from sqlalchemy.engine.url import make_url
            url = make_url(self.connection_string)

            self.config = {
                "host": url.host or "localhost",
                "port": url.port or 3306,
                "user": url.username,
                "password": url.password,
                "database": url.database,
            }
        except Exception as e:
            raise DataLoadError(f"Invalid MySQL connection string: {e}") from e

    def _make_sa_engine(self) -> object:
        """Create a SQLAlchemy engine for pandas 2.x compatibility."""
        from sqlalchemy import create_engine
        conn_str = self.connection_string
        # SQLAlchemy requires the +mysqlconnector dialect suffix
        if conn_str.startswith("mysql://"):
            conn_str = "mysql+mysqlconnector://" + conn_str[len("mysql://"):]
        return create_engine(conn_str)

    def connect(self) -> None:
        """Establish connection to MySQL database.

        Raises:
            DataLoadError: If connection fails
        """
        try:
            self.connection = mysql.connector.connect(**self.config)
            self._is_connected = True
        except MySQLError as e:
            raise DataLoadError(f"Failed to connect to MySQL: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error connecting to MySQL: {e}") from e

    def disconnect(self) -> None:
        """Close MySQL connection with proper cleanup and error handling."""
        if self.connection:
            try:
                if self.connection.is_connected():  # type: ignore[attr-defined]
                    self.connection.close()  # type: ignore[attr-defined]
                    logger.info("MySQL connection closed successfully")
            except Exception as e:
                logger.warning(f"Error closing MySQL connection: {e}")
            finally:
                self._is_connected = False
                self.connection = None

    def load_table(
        self,
        table_name: str,
        limit: int | None = None,
        columns: set[str] | None = None,
    ) -> pd.DataFrame:
        """Load data from MySQL table.

        Args:
            table_name: Name of the table to load
            limit: Optional row limit
            columns: Optional set of column names to project (SELECT col1, col2).
                     Pass None to load all columns (SELECT *).

        Returns:
            DataFrame containing table data

        Raises:
            DataLoadError: If not connected or table loading fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to database. Call connect() first.")

        self._validate_table_name(table_name)

        try:
            if columns:
                col_list = ", ".join(f"`{c}`" for c in sorted(columns))
                query_parts = [f"SELECT {col_list} FROM `{table_name}`"]  # nosec B608
            else:
                query_parts = [f"SELECT * FROM `{table_name}`"]  # nosec B608

            if limit:
                if not isinstance(limit, int) or limit <= 0:
                    raise DataLoadError(f"Invalid limit: {limit}. Must be a positive integer.")
                query_parts.append(f" LIMIT {int(limit)}")

            query_string = "".join(query_parts)

            # Use SQLAlchemy engine for pandas 2.x compatibility
            engine = self._make_sa_engine()
            with engine.connect() as sa_conn:
                return pd.read_sql_query(query_string, sa_conn)  # type: ignore[call-overload,no-any-return]

        except DataLoadError:
            raise
        except MySQLError as e:
            raise DataLoadError(f"Failed to load table '{table_name}': {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error loading table '{table_name}': {e}") from e

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute SQL query on MySQL database.

        Args:
            query: SQL query to execute

        Returns:
            DataFrame containing query results

        Raises:
            DataLoadError: If not connected or query execution fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to database. Call connect() first.")

        try:
            engine = self._make_sa_engine()
            with engine.connect() as sa_conn:
                return pd.read_sql_query(query, sa_conn)  # type: ignore[call-overload,no-any-return]
        except MySQLError as e:
            raise DataLoadError(f"Failed to execute query: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error executing query: {e}") from e
