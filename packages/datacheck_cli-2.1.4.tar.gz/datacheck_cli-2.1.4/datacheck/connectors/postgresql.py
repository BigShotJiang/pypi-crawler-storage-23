"""PostgreSQL database connector."""


import pandas as pd
import logging

try:
    import psycopg2
    PSYCOPG2_AVAILABLE = True
except ImportError:
    PSYCOPG2_AVAILABLE = False

from datacheck.connectors.base import DatabaseConnector
from datacheck.exceptions import DataLoadError

logger = logging.getLogger(__name__)


class PostgreSQLConnector(DatabaseConnector):
    """PostgreSQL database connector.

    Connects to PostgreSQL databases using psycopg2 and loads data into pandas DataFrames.

    Example:
        >>> connector = PostgreSQLConnector("postgresql://user:pass@localhost:5432/mydb")
        >>> with connector:
        ...     df = connector.load_table("users")
    """

    def __init__(self, connection_string: str) -> None:
        """Initialize PostgreSQL connector.

        Args:
            connection_string: PostgreSQL connection string

        Raises:
            DataLoadError: If psycopg2 is not installed
        """
        if not PSYCOPG2_AVAILABLE:
            raise DataLoadError(
                "PostgreSQL connector dependencies are not installed. "
                "Install with: pip install 'datacheck[postgresql]'"
            )

        super().__init__(connection_string)
        self.connection: object = None

    def _make_sa_engine(self) -> object:
        """Create a SQLAlchemy engine for pandas 2.x compatibility."""
        from sqlalchemy import create_engine
        conn_str = self.connection_string
        # SQLAlchemy requires the +psycopg2 dialect suffix
        if conn_str.startswith("postgresql://"):
            conn_str = "postgresql+psycopg2://" + conn_str[len("postgresql://"):]
        elif conn_str.startswith("postgres://"):
            conn_str = "postgresql+psycopg2://" + conn_str[len("postgres://"):]
        return create_engine(conn_str)

    def connect(self) -> None:
        """Establish connection to PostgreSQL database.

        Raises:
            DataLoadError: If connection fails
        """
        try:
            self.connection = psycopg2.connect(self.connection_string)
            self._is_connected = True
        except psycopg2.Error as e:
            raise DataLoadError(f"Failed to connect to PostgreSQL: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error connecting to PostgreSQL: {e}") from e

    def disconnect(self) -> None:
        """Close PostgreSQL connection with proper cleanup and error handling."""
        if self.connection:
            try:
                self.connection.close()  # type: ignore[attr-defined]
                logger.info("PostgreSQL connection closed successfully")
            except Exception as e:
                logger.warning(f"Error closing PostgreSQL connection: {e}")
            finally:
                self._is_connected = False
                self.connection = None

    def load_table(
        self,
        table_name: str,
        limit: int | None = None,
        columns: set[str] | None = None,
    ) -> pd.DataFrame:
        """Load data from PostgreSQL table.

        Args:
            table_name: Name of the table to load
            limit: Optional row limit
            columns: Optional set of column names to project (SELECT col1, col2).
                     Pass None to load all columns (SELECT *).

        Returns:
            DataFrame containing table data

        Raises:
            DataLoadError: If not connected or table loading fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to database. Call connect() first.")

        self._validate_table_name(table_name)

        try:
            if columns:
                col_list = ", ".join(f'"{c}"' for c in sorted(columns))
                query_parts = [f'SELECT {col_list} FROM "{table_name}"']  # nosec B608
            else:
                query_parts = [f'SELECT * FROM "{table_name}"']  # nosec B608

            if limit:
                if not isinstance(limit, int) or limit <= 0:
                    raise DataLoadError(f"Invalid limit: {limit}. Must be a positive integer.")
                query_parts.append(f" LIMIT {int(limit)}")

            query_string = "".join(query_parts)

            # Use SQLAlchemy engine for pandas 2.x compatibility
            engine = self._make_sa_engine()
            with engine.connect() as sa_conn:
                return pd.read_sql_query(query_string, sa_conn)  # type: ignore[call-overload,no-any-return]

        except DataLoadError:
            raise
        except psycopg2.Error as e:
            raise DataLoadError(f"Failed to load table '{table_name}': {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error loading table '{table_name}': {e}") from e

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute SQL query on PostgreSQL database.

        Args:
            query: SQL query to execute

        Returns:
            DataFrame containing query results

        Raises:
            DataLoadError: If not connected or query execution fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to database. Call connect() first.")

        try:
            engine = self._make_sa_engine()
            # psycopg2 treats bare % as parameter placeholders (e.g. in regex patterns).
            # Doubling %% tells psycopg2 to pass a literal % to PostgreSQL.
            escaped = query.replace("%", "%%")
            with engine.connect() as sa_conn:
                return pd.read_sql_query(escaped, sa_conn)  # type: ignore[call-overload,no-any-return]
        except psycopg2.Error as e:
            raise DataLoadError(f"Failed to execute query: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error executing query: {e}") from e
