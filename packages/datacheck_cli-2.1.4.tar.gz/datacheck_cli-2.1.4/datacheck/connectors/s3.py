"""AWS S3 connector for DataCheck — DuckDB httpfs-powered.

Queries S3 files (CSV, Parquet, JSON) via DuckDB's httpfs extension.
No boto3 required. Supports glob patterns, SQL aggregate pushdown, and all
standard AWS credential methods (explicit keys, IAM roles, env vars, profiles).
"""

from __future__ import annotations

import re

import pandas as pd

from datacheck.connectors.base import DatabaseConnector
from datacheck.exceptions import ConfigurationError, DataLoadError

# Valid S3 URL characters including glob wildcards (* ?)
_S3_PATH_PATTERN = re.compile(r"^[a-zA-Z0-9_./:@\-\*\?]+$")


def _is_s3_url(name: str) -> bool:
    """Return True if name is already a full S3 URL."""
    return name.startswith("s3://") or name.startswith("s3a://")


class S3DuckDBConnector(DatabaseConnector):
    """AWS S3 connector that queries files via DuckDB's httpfs extension.

    Uses DuckDB as the SQL engine to query CSV and Parquet files stored on S3.
    No boto3 or AWS SDK required — DuckDB handles all S3 communication natively.

    Supports all standard AWS credential methods:
    - Explicit ``access_key`` + ``secret_key`` (+ optional ``session_token``
      for STS / assumed roles)
    - AWS credential chain: IAM instance roles, environment variables,
      ``~/.aws/credentials`` (used automatically when no explicit keys provided)
    - Named profile from ``~/.aws/credentials``

    Supports glob patterns in paths::

        s3://my-bucket/data/2024/*/sales.parquet
        s3://my-bucket/raw/**/*.csv

    Also compatible with S3-compatible stores (MinIO, LocalStack, Ceph) via the
    ``endpoint`` parameter.

    Args:
        bucket: S3 bucket name.
        path: Default file path within the bucket (used when no table is
            specified in checks).  May be a glob pattern.
        region: AWS region (default: ``us-east-1``).
        access_key: AWS access key ID.  When omitted, the AWS credential chain
            is used (IAM role → env vars → ``~/.aws/credentials``).
        secret_key: AWS secret access key (required when ``access_key`` is set).
        session_token: AWS session token for temporary STS credentials.
        profile: Named AWS profile from ``~/.aws/credentials``.
        endpoint: Custom S3-compatible endpoint URL (e.g. ``http://localhost:9000``
            for MinIO).  When set, path-style addressing and HTTP are used.
    """

    def __init__(
        self,
        bucket: str,
        path: str = "",
        region: str = "us-east-1",
        access_key: str | None = None,
        secret_key: str | None = None,
        session_token: str | None = None,
        profile: str | None = None,
        endpoint: str | None = None,
    ) -> None:
        if not bucket:
            raise ConfigurationError("S3 bucket name is required")

        super().__init__(connection_string=f"s3://{bucket}")
        self._bucket = bucket
        self._default_path = path
        self._region = region
        self._access_key = access_key
        self._secret_key = secret_key
        self._session_token = session_token
        self._profile = profile
        self._endpoint = endpoint
        self._conn = None

    def connect(self) -> None:
        """Open an in-memory DuckDB connection and configure S3 via httpfs.

        Raises:
            DataLoadError: If DuckDB is not installed or httpfs setup fails.
        """
        try:
            import duckdb
        except ImportError:
            raise DataLoadError(
                "DuckDB is not installed. "
                "Install it with: pip install datacheck-cli"
            )

        self._conn = duckdb.connect(database=":memory:")
        self._is_connected = True

        try:
            self._conn.execute("INSTALL httpfs")
            self._conn.execute("LOAD httpfs")
        except Exception as e:
            self._conn.close()
            self._conn = None
            self._is_connected = False
            raise DataLoadError(
                f"Failed to load DuckDB httpfs extension: {e}"
            ) from e

        self._configure_credentials()

    def _configure_credentials(self) -> None:
        """Configure S3 credentials and region in the DuckDB session."""
        assert self._conn is not None

        if self._region:
            self._conn.execute(f"SET s3_region='{self._region}'")

        if self._endpoint:
            # S3-compatible endpoint (MinIO, LocalStack, Ceph, etc.)
            self._conn.execute(f"SET s3_endpoint='{self._endpoint}'")
            self._conn.execute("SET s3_use_ssl=false")
            self._conn.execute("SET s3_url_style='path'")

        if self._access_key and self._secret_key:
            # Explicit credentials take priority over credential chain
            self._conn.execute(f"SET s3_access_key_id='{self._access_key}'")
            self._conn.execute(f"SET s3_secret_access_key='{self._secret_key}'")
            if self._session_token:
                self._conn.execute(f"SET s3_session_token='{self._session_token}'")
        else:
            # Fall back to AWS credential chain: IAM roles, env vars, ~/.aws/credentials
            try:
                if self._profile:
                    self._conn.execute(f"CALL load_aws_credentials('{self._profile}')")
                else:
                    self._conn.execute("CALL load_aws_credentials()")
            except Exception:
                # load_aws_credentials may not be available in all DuckDB builds.
                # Let the actual query fail with AWS's own credential error.
                pass

    def disconnect(self) -> None:
        """Close the DuckDB connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
        self._is_connected = False

    def load_table(
        self,
        table_name: str,
        limit: int | None = None,
        columns: set[str] | None = None,
    ) -> pd.DataFrame:
        """Load data from an S3 file using DuckDB.

        Args:
            table_name: S3 URL (``s3://bucket/path.parquet``), a glob pattern
                (``s3://bucket/year=2024/*/data.parquet``), or a relative path
                within the configured bucket (``data/sales.parquet``).
            limit: Optional row limit (pushed down to SQL).
            columns: Optional set of column names to project.

        Returns:
            DataFrame containing the loaded data.

        Raises:
            DataLoadError: If the query fails or connector is not connected.
        """
        if self._conn is None:
            raise DataLoadError("S3 connector is not connected")

        s3_path = self._resolve_path(table_name)
        self._validate_s3_path(s3_path)

        table_ref = "'" + s3_path.replace("'", "''") + "'"

        if columns:
            col_list = ", ".join(f'"{c}"' for c in sorted(columns))
        else:
            col_list = "*"

        sql = f"SELECT {col_list} FROM {table_ref}"
        if limit is not None:
            sql += f" LIMIT {limit}"

        try:
            return self._conn.execute(sql).df()
        except Exception as e:
            raise DataLoadError(f"S3 query failed for '{s3_path}': {e}") from e

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute a raw SQL query (use S3 paths directly in FROM clauses).

        Args:
            query: SQL query referencing S3 paths, e.g.
                ``SELECT * FROM 's3://bucket/file.parquet'``.

        Returns:
            DataFrame containing query results.

        Raises:
            DataLoadError: If query fails or connector is not connected.
        """
        if self._conn is None:
            raise DataLoadError("S3 connector is not connected")
        try:
            return self._conn.execute(query).df()
        except Exception as e:
            raise DataLoadError(f"S3 query failed: {e}") from e

    def _resolve_path(self, table_name: str) -> str:
        """Resolve a table name to a full S3 URL.

        - Full S3 URLs (``s3://…``) are returned unchanged.
        - Relative paths are prefixed with ``s3://{bucket}/``.
        """
        if _is_s3_url(table_name):
            return table_name
        key = table_name.lstrip("/")
        return f"s3://{self._bucket}/{key}"

    def _validate_s3_path(self, path: str) -> None:
        """Validate an S3 URL for safe characters (allows glob wildcards)."""
        if not _S3_PATH_PATTERN.match(path):
            raise DataLoadError(
                f"Invalid S3 path '{path}'. "
                "S3 paths must contain only alphanumeric characters, "
                "slashes, dots, hyphens, underscores, and glob wildcards (* ?)."
            )

    def _validate_table_name(self, name: str) -> None:
        """Override base validation to accept S3 URLs and glob patterns."""
        self._validate_s3_path(self._resolve_path(name))


__all__ = ["S3DuckDBConnector"]
