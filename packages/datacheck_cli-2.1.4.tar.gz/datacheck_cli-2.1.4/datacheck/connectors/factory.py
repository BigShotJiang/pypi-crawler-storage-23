"""Connector factory for creating connectors from source configurations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import quote_plus

import pandas as pd

from datacheck.exceptions import ConfigurationError, DataLoadError

if TYPE_CHECKING:
    from datacheck.config.source import SourceConfig
    from datacheck.connectors.base import DatabaseConnector


def create_connector(source: SourceConfig) -> DatabaseConnector:
    """Create a database connector from a SourceConfig.

    Args:
        source: Source configuration

    Returns:
        DatabaseConnector instance (not yet connected)

    Raises:
        ConfigurationError: If source type is not a database type
        DataLoadError: If connector dependencies are not installed
    """
    conn = source.connection

    if source.type == "postgresql":
        from datacheck.connectors.postgresql import PostgreSQLConnector

        connection_string = _build_connection_string(
            "postgresql", conn, default_port=5432
        )
        return PostgreSQLConnector(connection_string)

    if source.type == "mysql":
        from datacheck.connectors.mysql import MySQLConnector

        connection_string = _build_connection_string(
            "mysql", conn, default_port=3306
        )
        return MySQLConnector(connection_string)

    if source.type == "snowflake":
        from datacheck.connectors.snowflake import SnowflakeConnector

        return SnowflakeConnector(
            account=conn["account"],
            user=conn["user"],
            password=conn.get("password"),
            warehouse=conn.get("warehouse"),
            database=conn.get("database"),
            schema=conn.get("schema"),
            role=conn.get("role"),
            authenticator=conn.get("authenticator"),
            private_key_path=conn.get("private_key_path"),
        )

    if source.type == "bigquery":
        from datacheck.connectors.bigquery import BigQueryConnector

        return BigQueryConnector(
            project_id=conn["project_id"],
            dataset_id=conn.get("dataset_id"),
            credentials_path=conn.get("credentials_path"),
            location=conn.get("location", "US"),
        )

    if source.type == "redshift":
        from datacheck.connectors.redshift import RedshiftConnector

        return RedshiftConnector(
            host=conn["host"],
            database=conn["database"],
            user=conn["user"],
            password=conn.get("password"),
            port=conn.get("port", 5439),
            cluster_identifier=conn.get("cluster_identifier"),
            region=conn.get("region"),
            iam_auth=conn.get("iam_auth", False),
            schema=conn.get("schema"),
        )

    if source.type == "duckdb":
        from datacheck.connectors.duckdb import DuckDBConnector

        return DuckDBConnector(path=conn["path"])

    if source.type == "s3":
        from datacheck.connectors.s3 import S3DuckDBConnector

        return S3DuckDBConnector(
            bucket=conn["bucket"],
            path=conn.get("path", ""),
            region=conn.get("region", "us-east-1"),
            access_key=conn.get("access_key"),
            secret_key=conn.get("secret_key"),
            session_token=conn.get("session_token"),
            profile=conn.get("profile"),
            endpoint=conn.get("endpoint"),
        )

    raise ConfigurationError(
        f"Source type '{source.type}' is not a database connector. "
        "Database types: postgresql, mysql, snowflake, bigquery, redshift, duckdb, s3"
    )


def load_source_data(
    source: SourceConfig,
    table: str | None = None,
    query: str | None = None,
    sample_rate: float | None = None,
    limit: int | None = None,
    columns: set[str] | None = None,
) -> pd.DataFrame:
    """Load data from a source configuration.

    Handles all database and S3 sources via their respective connectors.

    Args:
        source: Source configuration
        table: Table name (for database sources)
        query: Custom SQL query (for database sources)
        sample_rate: Sample rate (for warehouse sources that support it)
        limit: Maximum rows to return (pushed down as SQL LIMIT for databases)

    Returns:
        DataFrame with loaded data

    Raises:
        DataLoadError: If loading fails
        ConfigurationError: If source type is invalid
    """
    if source.is_database:
        return _load_from_database(source, table, query, sample_rate, limit, columns)

    raise ConfigurationError(f"Unknown source type: {source.type}")


def _build_connection_string(
    scheme: str, conn: dict[str, Any], default_port: int
) -> str:
    """Build a connection string from connection parameters.

    Args:
        scheme: URL scheme (postgresql, mysql)
        conn: Connection parameters dict
        default_port: Default port for this database type

    Returns:
        Connection string in URI format
    """
    host = conn.get("host", "localhost")
    port = conn.get("port", default_port)
    database = conn["database"]
    user = quote_plus(conn["user"])
    password = quote_plus(conn.get("password", ""))
    return f"{scheme}://{user}:{password}@{host}:{port}/{database}"


def _load_from_database(
    source: SourceConfig,
    table: str | None,
    query: str | None,
    sample_rate: float | None,
    limit: int | None = None,
    columns: set[str] | None = None,
) -> pd.DataFrame:
    """Load data from a database source."""
    connector = create_connector(source)
    warehouse_types = {"snowflake", "bigquery", "redshift"}

    with connector:
        if query:
            return connector.execute_query(query)
        if table:
            kwargs: dict[str, Any] = {}
            if sample_rate is not None and source.type in warehouse_types:
                kwargs["sample_rate"] = sample_rate
            if limit is not None:
                kwargs["limit"] = limit
            if columns is not None:
                kwargs["columns"] = columns
            return connector.load_table(table, **kwargs)
        raise DataLoadError(
            f"Source '{source.name}' is a database source — "
            "either 'table' or 'query' must be specified"
        )


__all__ = ["create_connector", "load_source_data"]
