# DataCheck — Data Validation Made Easy

[![PyPI version](https://img.shields.io/pypi/v/datacheck-cli.svg)](https://pypi.org/project/datacheck-cli/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

**DataCheck is a dataset validation tool.** Define rules in YAML, point it at your data, and it fails fast if anything is wrong — in CI or locally.

---

## Install

```bash
pip install datacheck-cli
```

For database connectivity, install the extras you need:

```bash
pip install datacheck-cli[postgresql]   # PostgreSQL
pip install datacheck-cli[mysql]        # MySQL
pip install datacheck-cli[snowflake]    # Snowflake
pip install datacheck-cli[bigquery]     # BigQuery
pip install datacheck-cli[redshift]     # Redshift
pip install datacheck-cli[s3]           # S3 (CSV/Parquet)
pip install datacheck-cli[all]          # Everything
```

---

## Write a config

```bash
datacheck config init
```

This creates `datacheck.yaml`. Edit it to define your validation rules:

```yaml
# datacheck.yaml
version: "1.0"
sources_file: sources.yaml
source: my_data

checks:
  - column: id
    rules:
      - not_null
      - unique

  - column: email
    rules:
      - not_null
      - regex: "^[^@]+@[^@]+$"

  - column: amount
    rules:
      - type: numeric
      - positive
```

---

## Add sources

Create `sources.yaml` to define where your data lives:

```yaml
# sources.yaml
version: "1.0"

sources:
  # Local CSV or Parquet file
  my_data:
    type: duckdb
    path: ./data/customers.csv

  # PostgreSQL
  # my_data:
  #   type: postgresql
  #   host: ${PG_HOST}
  #   database: ${PG_DATABASE}
  #   user: ${PG_USER}
  #   password: ${PG_PASSWORD}

  # Snowflake
  # my_data:
  #   type: snowflake
  #   account: ${SF_ACCOUNT}
  #   user: ${SF_USER}
  #   password: ${SF_PASSWORD}
  #   warehouse: ${SF_WAREHOUSE}
  #   database: ${SF_DATABASE}
  #   schema: ${SF_SCHEMA}
```

Supported sources: **CSV/Parquet** (via DuckDB), **PostgreSQL**, **MySQL**, **Snowflake**, **BigQuery**, **Redshift**.

Credentials use environment variables — `sources.yaml` never needs secrets hardcoded.

---

## Validate

```bash
datacheck validate
```

DataCheck runs all checks against your source and exits `0` on pass, `1` on failure.

```
✅  id         not_null    passed   10,000 rows
✅  id         unique      passed   10,000 rows
❌  email      regex       FAILED   142/10,000 rows (1.4%)
✅  amount     type        passed   10,000 rows
✅  amount     positive    passed   10,000 rows
```

For database sources validation runs as a single aggregate SQL query — no data is pulled out of your warehouse.

---

## Rules reference

| Category  | Rules                                                                 |
| :-------- | :-------------------------------------------------------------------- |
| Presence  | `not_null`, `unique`                                                  |
| Type      | `type: integer`, `type: numeric`, `type: string`, `type: date`        |
| Numeric   | `positive`, `range: {min, max}`                                       |
| String    | `regex`, `allowed_values`, `min_length`, `max_length`                 |
| Boolean   | `boolean`                                                             |
| Temporal  | `no_future_timestamps`, `date_range: {min, max}`                      |

---

## Documentation

[squrtech.github.io/datacheck](https://squrtech.github.io/datacheck/)

---

## License

Apache 2.0
