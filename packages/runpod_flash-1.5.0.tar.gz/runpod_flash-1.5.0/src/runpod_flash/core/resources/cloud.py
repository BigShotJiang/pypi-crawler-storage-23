import runpod

from runpod_flash.core.credentials import get_api_key

runpod.api_key = get_api_key()
