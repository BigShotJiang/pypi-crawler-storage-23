"""
Basic tests for OGM Platform.
"""

import pytest
from ogm import __version__


def test_version():
    """Test that version is defined."""
    assert __version__ is not None
    assert isinstance(__version__, str)
    assert len(__version__.split(".")) >= 2


def test_imports():
    """Test that main modules can be imported."""
    from ogm.config import OGMConfig
    from ogm import insight

    assert OGMConfig is not None
    assert insight is not None


def test_basic_functionality():
    """Test basic functionality works."""
    # This is a placeholder test - add more comprehensive tests as needed
    assert True