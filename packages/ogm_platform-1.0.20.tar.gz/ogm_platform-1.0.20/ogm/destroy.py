"""Destroy and cleanup module."""

from typing import Dict

try:
    from rich.console import Console
    from rich.prompt import Confirm

    console = Console()
except ImportError:

    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

    class MockConfirm:
        @staticmethod
        def ask(prompt):
            return input(f"{prompt} [y/N]: ").lower() == "y"

    console = MockConsole()  # type: ignore
    Confirm = MockConfirm  # type: ignore


class DestroyManager:
    """Manages destruction and cleanup operations."""

    def __init__(self, config, git_manager, helm_manager, k3s_manager, state_manager):
        self.config = config
        self.git = git_manager
        self.helm = helm_manager
        self.k3s = k3s_manager
        self.state = state_manager

    def destroy_application(
        self, app_name: str, remove_data: bool = False, force: bool = False
    ) -> bool:
        console.print(f"[red]Destroying: {app_name}[/red]")

        if not force and not Confirm.ask(f"Destroy {app_name}?"):
            return False

        # Find chart
        chart_config = None
        for chart in self.config.helm_charts:
            if chart.name == app_name:
                chart_config = chart
                break

        if not chart_config:
            console.print("[yellow]Not found in config[/yellow]")
            return True

        # Uninstall
        success = bool(self.helm.uninstall_chart(chart_config.name, chart_config.namespace))

        # --- PVC/PV Cleanup Logic ---
        if success:
            try:
                from .utils import remove_finalizers, run_command

                # List PVCs in the namespace with app name in label or name
                pvc_list = run_command(
                    [
                        "kubectl",
                        "get",
                        "pvc",
                        "-n",
                        chart_config.namespace,
                        "-o",
                        "jsonpath={.items[*].metadata.name}",
                    ],
                    capture_output=True,
                    check=False,
                )
                if pvc_list:
                    for pvc in pvc_list.split():
                        if app_name in pvc:
                            # Try normal delete first
                            run_command(
                                ["kubectl", "delete", "pvc", pvc, "-n", chart_config.namespace],
                                check=False,
                            )
                            import time

                            time.sleep(3)
                            # If still present, force remove finalizers
                            remove_finalizers("pvc", pvc, chart_config.namespace)
            except Exception as e:
                console.print(f"[yellow]PVC cleanup warning: {e}[/yellow]")
            self.state.remove_deployment(app_name)

        return success

    def destroy_all_applications(
        self, remove_data: bool = False, force: bool = False
    ) -> Dict[str, bool]:
        console.print("[red]Destroying all applications...[/red]")

        if not force and not Confirm.ask("Destroy ALL applications?"):
            return {}

        results = {}
        deployments = self.state.get_deployments()

        for app_name in list(deployments.keys()):
            results[app_name] = self.destroy_application(app_name, remove_data, force=True)

        return results

    def complete_removal(self, force: bool = False) -> bool:
        console.print("[bold red]COMPLETE ENVIRONMENT REMOVAL[/bold red]")

        if not force:
            if not Confirm.ask("Remove EVERYTHING?"):
                return False
            if not Confirm.ask("This cannot be undone. Continue?"):
                return False

        # Destroy applications
        self.destroy_all_applications(remove_data=True, force=True)

        # Uninstall K3s
        self.k3s.uninstall()

        # Remove repositories
        for repo in self.config.repositories:
            self.git.remove_repository(repo.name, force=True)

        # Clean state
        self.state.reset_state()

        console.print("[green]✓ Complete removal finished[/green]")
        return True

    def cleanup_failed_deployments(self) -> Dict[str, bool]:
        console.print("[cyan]Cleaning up failed deployments...[/cyan]")

        results = {}
        releases = self.helm.list_releases(all_namespaces=True)

        for release in releases:
            status = release.get("status", "")
            name = release.get("name", "")
            namespace = release.get("namespace", "")

            if status in ["failed", "pending-install", "pending-upgrade"]:
                console.print(f"[yellow]Found {status} release: {name}[/yellow]")
                success = self.helm.uninstall_chart(name, namespace)
                results[name] = success

        if not results:
            console.print("[green]✓ No failed deployments[/green]")

        return results
