"""
Command-line interface for OGM Platform.

Provides commands for managing Kubernetes clusters, repositories, and deployments.
"""

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from .auth import AuthManager
from .config import load_config
from .state import StateManager

console = Console()


@click.group()
@click.pass_context
def main(ctx):
    """OGM Kubernetes Platform for GenAI Applications."""
    ctx.ensure_object(dict)

    # Load configuration
    config_path = Path.cwd() / ".ogmconfig"
    ctx.obj["config"] = load_config(config_path if config_path.exists() else None)
    ctx.obj["state"] = StateManager(ctx.obj["config"].state_file)


@main.command()
@click.option("--config-only", is_flag=True, help="Only create configuration file")
@click.option("--force", is_flag=True, help="Force initialization even outside CI/CD")
@click.option("--local", is_flag=True, help="Allow local initialization (implies --force)")
@click.option("--dev", is_flag=True, help="Initialize for development environment (K3s by default)")
@click.option("--stage", is_flag=True, help="Initialize for staging environment (full Kubernetes)")
@click.option(
    "--production", is_flag=True, help="Initialize for production environment (full Kubernetes)"
)
@click.option(
    "--enterprise",
    is_flag=True,
    help="Initialize for enterprise environment (full Kubernetes with advanced features)",
)
@click.pass_context
def init(ctx, config_only, force, local, dev, stage, production, enterprise):
    """Initialize Kubernetes cluster and environment."""

    # Check if running in CI/CD pipeline or explicitly allowed locally
    is_ci_cd = os.getenv("CI") or os.getenv("GITLAB_CI")
    is_root = os.geteuid() == 0
    has_sudo = False

    # Check for sudo access
    try:
        import subprocess

        result = subprocess.run(["sudo", "-n", "true"], capture_output=True, timeout=5)
        has_sudo = result.returncode == 0
    except:
        pass

    if not is_ci_cd and not force and not local:
        console.print("[yellow]⚠️  Running ogm init outside CI/CD pipeline[/yellow]")
        console.print(
            "[yellow]This may require root/sudo privileges for cluster installation[/yellow]"
        )
        console.print("")

        if not is_root and not has_sudo:
            console.print("[red]❌ No root or sudo access detected![/red]")
            console.print("[yellow]Please run with sudo or as root:[/yellow]")
            console.print("  sudo ogm init")
            console.print("  # or")
            console.print("  sudo -i  # become root, then run: ogm init")
            sys.exit(1)

        console.print("[yellow]⚠️  Running with elevated privileges[/yellow]")
        if is_root:
            console.print("[green]✓ Running as root[/green]")
        elif has_sudo:
            console.print("[green]✓ Sudo access available[/green]")

    # Additional privilege check for local/force mode
    if (force or local) and not is_ci_cd:
        if not is_root and not has_sudo:
            console.print("[red]❌ Local initialization requires root or sudo privileges[/red]")
            console.print("[yellow]Please run with sudo:[/yellow]")
            console.print("  sudo ogm init --force")
            console.print("  # or")
            console.print("  sudo -i  # become root, then run: ogm init --force")
            sys.exit(1)

        console.print("[yellow]⚠️  Running in local mode with elevated privileges[/yellow]")
        if is_root:
            console.print("[green]✓ Running as root[/green]")
        elif has_sudo:
            console.print("[green]✓ Sudo access available[/green]")

    # Determine cluster type based on environment
    environment = os.getenv("ENVIRONMENT", "dev").lower()

    # Override environment based on explicit flags (enterprise takes highest precedence)
    if enterprise:
        environment = "enterprise"
        console.print("[red]🏢 Initializing for ENTERPRISE environment[/red]")
        console.print(
            "[red]This will configure full multi-zone Kubernetes cluster with enterprise-grade features[/red]"
        )
        console.print(
            "[red]⚠️  This configuration requires significant resources and expertise[/red]"
        )
        console.print()
    elif production:
        environment = "prod"
        console.print("[yellow]⚠️  Initializing for PRODUCTION environment[/yellow]")
        console.print(
            "[yellow]This will configure full Kubernetes cluster for production workloads[/yellow]"
        )
        console.print()
    elif stage:
        environment = "stage"
        console.print("[blue]ℹ️  Initializing for STAGING environment[/blue]")
        console.print(
            "[blue]This will configure full Kubernetes cluster for staging workloads[/blue]"
        )
        console.print()
    elif dev:
        environment = "dev"
        console.print("[green]ℹ️  Initializing for DEVELOPMENT environment[/green]")
        console.print(
            "[green]This will allow cluster type selection for development workloads[/green]"
        )
        console.print()

    # Handle local flag (implies dev environment)
    if local and not (dev or stage or production):
        environment = "dev"
        console.print("[green]ℹ️  Local mode enabled - initializing for development[/green]")

    if environment == "dev":
        # For dev environment, allow user to choose cluster type
        console.print("\n[bold cyan]Development Environment Cluster Selection[/bold cyan]")
        console.print("Choose the Kubernetes distribution for your development environment:")
        console.print("  1. K3s (Lightweight) - Faster startup, lower resource usage")
        console.print("  2. Full Kubernetes - Complete K8s experience, slower startup")
        console.print()

        while True:
            try:
                choice = input("Enter your choice (1 or 2): ").strip()
                if choice == "1":
                    cluster_type = "K3s Custom"
                    break
                elif choice == "2":
                    cluster_type = "K8s Full"
                    break
                else:
                    console.print("[yellow]Please enter 1 or 2[/yellow]")
            except KeyboardInterrupt:
                console.print("\n[yellow]Selection cancelled[/yellow]")
                sys.exit(1)
    else:
        # For stage/prod/enterprise, use full Kubernetes
        if environment == "enterprise":
            cluster_type = "K8s Full Multi-Zone"
        else:
            cluster_type = "K8s Full"

    console.print("\n[bold cyan]═══════════════════════════════════════[/bold cyan]")
    console.print(f"[bold cyan]  {cluster_type} OGM Platform Initialization[/bold cyan]")
    console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]\n")

    # Confirm environment
    console.print(f"[dim]Environment: {environment.upper()}[/dim]")
    console.print(f"[dim]Cluster Type: {cluster_type}[/dim]\n")

    config = ctx.obj["config"]
    state = ctx.obj["state"]

    if config_only:
        config_path = Path.cwd() / ".ogmconfig"
        config.save_to_yaml(config_path)
        console.print(f"[green]✓ Configuration saved to {config_path}[/green]")
        return

    # Install prerequisites if missing
    from .utils import install_prerequisites

    if not install_prerequisites():
        console.print(
            "[red]Failed to install prerequisites. Please install manually and try again.[/red]"
        )
        sys.exit(1)

    from .kubernetes import KubernetesManager

    # Convert cluster_type to format expected by KubernetesManager
    k3s_cluster_type = "k3s" if "k3s" in cluster_type.lower() else "k8s"
    k3s = KubernetesManager(config.k3s, cluster_type=k3s_cluster_type)

    # Install K3s or K8s based on environment
    if k3s.install():
        state.update_k3s_state(
            {
                "installed": True,
                "version": k3s.get_version(),
                "installed_at": state.state.get("initialized_at"),
            }
        )

        # Create the configured namespace
        k3s.create_namespace(config.namespace)

        # Setup storage
        k3s.setup_storage()

        # Setup ingress if enabled and not already configured in helm_charts
        nginx_ingress_in_charts = any(chart.name == "nginx-ingress" for chart in config.helm_charts)
        if config.infrastructure.ingress and not nginx_ingress_in_charts:
            k3s.setup_ingress()

        # Dynamic success message based on cluster type
        environment = os.getenv("ENVIRONMENT", "dev").lower()
        cluster_name = "K3s Custom cluster" if environment == "dev" else "K8s Full cluster"
        console.print(f"\n[green]✓ {cluster_name} initialized successfully![/green]")
        console.print("\n[dim]Next steps:[/dim]")
        console.print("  1. Run [cyan]ogm clone[/cyan] to clone repositories")
        console.print("  2. Run [cyan]ogm deploy[/cyan] to deploy applications")
        console.print("  3. Run [cyan]ogm status[/cyan] to check cluster status")
    else:
        environment = os.getenv("ENVIRONMENT", "dev").lower()
        cluster_name = "K3s Custom" if environment == "dev" else "K8s Full"
        console.print(f"\n[red]✗ {cluster_name} initialization failed[/red]")
        sys.exit(1)


@main.command()
@click.argument("repos", nargs=-1)
@click.pass_context
def clone(ctx, repos):
    """Clone configured repositories."""
    console.print("\n[bold cyan]Cloning Repositories[/bold cyan]\n")

    config = ctx.obj["config"]
    state = ctx.obj["state"]

    from .git_ops import GitManager

    git = GitManager(config.repos_dir)

    # Determine which repos to clone
    if repos:
        repo_configs = [r for r in config.repositories if r.name in repos]
    else:
        repo_configs = config.repositories

    if not repo_configs:
        console.print("[yellow]No repositories configured[/yellow]")
        return

    success_count = 0
    for repo_config in repo_configs:
        repo = git.clone_repository(repo_config)
        if repo:
            state.update_repository_state(
                repo_config.name,
                {"cloned": True, "url": repo_config.url, "branch": repo_config.branch},
            )
            success_count += 1

    console.print(f"\n[green]✓ Cloned {success_count}/{len(repo_configs)} repositories[/green]")


def map_env_to_context(env_name: str) -> Optional[str]:
    """
    Map environment names to kubectl context names.

    Args:
        env_name: Environment name (local, dev, stage, prod, etc.)

    Returns:
        Corresponding kubectl context name or None if unknown
    """
    # Environment to context mapping based on sync-kubeconfigs.sh
    env_context_map = {
        "local": "ogm-dev",  # or current context if ogm-dev doesn't exist
        "dev": "ogm-dev",
        "stage": "ogm-stage",
        "prod": "ogm-prod",
        "production": "ogm-prod",
        "test": "test",
        "testing": "test",
    }

    return env_context_map.get(env_name.lower())


@main.command()
@click.argument("charts", nargs=-1)
@click.option("--dry-run", is_flag=True, help="Simulate deployment")
@click.option(
    "--env",
    "environments",
    multiple=True,
    help="Deploy to specific environments (can be used multiple times)",
)
@click.pass_context
def deploy(ctx, charts, dry_run, environments):
    """Deploy applications using Helm."""
    console.print("\n[bold cyan]Deploying Applications[/bold cyan]\n")

    config = ctx.obj["config"]
    state = ctx.obj["state"]

    from .helm import HelmManager
    from .utils import get_kubectl_context, switch_kubectl_context

    helm = HelmManager()

    # Determine which charts to deploy
    if charts:
        chart_configs = [c for c in config.helm_charts if c.name in charts]
    else:
        chart_configs = config.helm_charts

    if not chart_configs:
        console.print("[yellow]No Helm charts configured[/yellow]")
        return

        # If environments are specified, deploy to each environment
    if environments:
        # Get current context to restore later
        original_context = get_kubectl_context()
        if not original_context:
            console.print("[red]❌ Cannot determine current kubectl context[/red]")
            return

        console.print(f"[dim]Original context: {original_context}[/dim]")

        total_success_count = 0
        successful_environments = 0
        failed_environments = []

        for env in environments:
            console.print(f"\n[bold blue]🚀 Deploying to environment: {env}[/bold blue]")

            # Map environment names to kubectl contexts
            context_name = map_env_to_context(env)
            if not context_name:
                console.print(f"[red]❌ Unknown environment: {env}[/red]")
                failed_environments.append(env)
                continue

            # Check if context exists, handle special cases
            from .utils import get_available_contexts

            available_contexts = get_available_contexts()

            if context_name not in available_contexts:
                if env.lower() == "local":
                    # For local environment, fall back to current context
                    current_ctx = get_kubectl_context()
                    if current_ctx:
                        console.print(
                            f"[yellow]⚠️  Context '{context_name}' not found, using current context '{current_ctx}' for local environment[/yellow]"
                        )
                        context_name = current_ctx
                    else:
                        console.print(
                            f"[red]❌ No kubectl context available for local environment[/red]"
                        )
                        failed_environments.append(env)
                        continue
                else:
                    # For remote environments, suggest running sync script
                    console.print(f"[red]❌ Context '{context_name}' not found[/red]")
                    console.print(
                        f"[yellow]💡 For {env} environment, run the sync script to fetch remote kubeconfigs:[/yellow]"
                    )
                    console.print(f"   ./scripts/rancher/sync-kubeconfigs.sh")
                    console.print(
                        f"[yellow]   Or check available contexts with: kubectl config get-contexts[/yellow]"
                    )
                    failed_environments.append(env)
                    continue

            # Switch to target context
            if not switch_kubectl_context(context_name):
                console.print(f"[red]❌ Failed to switch to context: {context_name}[/red]")
                failed_environments.append(env)
                continue

            console.print(f"[green]✓ Switched to context: {context_name}[/green]")

            # Add Helm repositories
            helm.update_repositories()

            # Deploy charts to this environment
            env_success_count = 0
            for chart_config in chart_configs:
                if helm.upgrade_chart(chart_config, dry_run=dry_run):
                    if not dry_run:
                        state.update_deployment_state(
                            f"{chart_config.name}-{env}",
                            {
                                "deployed": True,
                                "chart": chart_config.chart,
                                "namespace": chart_config.namespace,
                                "environment": env,
                                "context": context_name,
                            },
                        )
                    env_success_count += 1
                    total_success_count += 1

            if env_success_count == len(chart_configs):
                successful_environments += 1
                console.print(
                    f"[green]✓ Environment {env}: {env_success_count}/{len(chart_configs)} applications deployed[/green]"
                )
            else:
                console.print(
                    f"[yellow]⚠️  Environment {env}: {env_success_count}/{len(chart_configs)} applications deployed (partial)[/yellow]"
                )
                failed_environments.append(env)

        # Restore original context
        if switch_kubectl_context(original_context):
            console.print(f"\n[dim]✓ Restored original context: {original_context}[/dim]")
        else:
            console.print(
                f"\n[yellow]⚠️  Warning: Could not restore original context {original_context}[/yellow]"
            )

        # Summary
        console.print(
            f"\n[green]✓ Successfully deployed to {successful_environments}/{len(environments)} environments[/green]"
        )
        console.print(f"[green]✓ Total applications deployed: {total_success_count}[/green]")

        if failed_environments:
            console.print(
                f"[yellow]⚠️  Failed/skipped environments: {', '.join(failed_environments)}[/yellow]"
            )

        # Exit with error if no environments succeeded
        if successful_environments == 0:
            console.print("[red]❌ No environments were successfully deployed to[/red]")
            sys.exit(1)
        else:
            # Original single-context deployment behavior
            # Add Helm repositories
            helm.update_repositories()

            success_count = 0
            for chart_config in chart_configs:
                if helm.install_chart(chart_config, dry_run=dry_run):
                    if not dry_run:
                        state.update_deployment_state(
                            chart_config.name,
                            {
                                "deployed": True,
                                "chart": chart_config.chart,
                                "namespace": chart_config.namespace,
                            },
                        )
                    success_count += 1

            console.print(
                f"\n[green]✓ Deployed {success_count}/{len(chart_configs)} applications[/green]"
            )


@main.command()
@click.argument("items", nargs=-1)
@click.option("--rebuild/--no-rebuild", default=True, help="Rebuild after sync")
@click.pass_context
def sync(ctx, items, rebuild):
    """Synchronize repositories and redeploy."""
    console.print("\n[bold cyan]Synchronizing[/bold cyan]\n")

    config = ctx.obj["config"]
    state = ctx.obj["state"]

    from .git_ops import GitManager
    from .helm import HelmManager
    from .sync import SyncManager

    git = GitManager(config.repos_dir)
    helm = HelmManager()
    sync_mgr = SyncManager(config, git, helm, state)

    if items:
        for item in items:
            sync_mgr.sync_repository(item, rebuild=rebuild)
    else:
        sync_mgr.sync_all_repositories(rebuild=rebuild)


@main.command()
@click.argument("apps", nargs=-1)
@click.option("--all", "destroy_all", is_flag=True, help="Destroy all applications")
@click.option("--remove-data", is_flag=True, help="Remove persistent data")
@click.option("--force", is_flag=True, help="Skip confirmation")
@click.pass_context
def destroy(ctx, apps, destroy_all, remove_data, force):
    """Destroy applications."""
    config = ctx.obj["config"]
    state = ctx.obj["state"]

    from .destroy import DestroyManager
    from .git_ops import GitManager
    from .helm import HelmManager
    from .kubernetes import KubernetesManager

    git = GitManager(config.repos_dir)
    helm = HelmManager()
    k3s = KubernetesManager(config.k3s)
    destroy_mgr = DestroyManager(config, git, helm, k3s, state)

    if destroy_all:
        destroy_mgr.destroy_all_applications(remove_data=remove_data, force=force)
    elif apps:
        for app in apps:
            destroy_mgr.destroy_application(app, remove_data=remove_data, force=force)
    else:
        console.print("[yellow]Specify applications to destroy or use --all[/yellow]")


@main.command()
@click.option("--force", is_flag=True, help="Skip confirmation")
@click.pass_context
def remove(ctx, force):
    """Complete removal of OGM environment."""
    config = ctx.obj["config"]
    state = ctx.obj["state"]

    from .destroy import DestroyManager
    from .git_ops import GitManager
    from .helm import HelmManager
    from .kubernetes import KubernetesManager

    git = GitManager(config.repos_dir)
    helm = HelmManager()
    k3s = KubernetesManager(config.k3s)
    destroy_mgr = DestroyManager(config, git, helm, k3s, state)

    destroy_mgr.complete_removal(force=force)


@main.command()
@click.option("--verbose", "-v", is_flag=True, help="Show detailed information")
@click.pass_context
def status(ctx, verbose):
    """Show cluster and application status."""
    console.print("\n[bold cyan]═══════════════════════════════════════[/bold cyan]")
    console.print("[bold cyan]     OGM Platform Status[/bold cyan]")
    console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]\n")

    config = ctx.obj["config"]

    from .git_ops import GitManager
    from .helm import HelmManager
    from .kubernetes import KubernetesManager

    k3s = KubernetesManager(config.k3s)
    git = GitManager(config.repos_dir)
    helm = HelmManager()

    # Cluster Status
    cluster_type_display = "K3s" if k3s.cluster_type == "k3s" else "Kubernetes"
    console.print(f"[bold]{cluster_type_display} Cluster:[/bold]")
    if k3s.is_installed():
        version = k3s.get_version()
        if version:
            console.print(f"  Version: [green]{version}[/green]")
        else:
            console.print("  Version: [yellow]Unknown[/yellow]")
        console.print("  Status: [green]Running[/green]")

        # Show cluster type detection
        actual_type = k3s._detect_cluster_type()
        if actual_type != k3s.cluster_type:
            console.print(
                f"  [dim]Note: Detected {actual_type.upper()} cluster (configured for {k3s.cluster_type.upper()})[/dim]"
            )
    else:
        console.print("  Status: [red]Not Installed[/red]")

    # Repository Status
    console.print("\n[bold]Repositories:[/bold]")
    statuses = git.get_all_statuses()
    if statuses:
        repo_table = Table()
        repo_table.add_column("Repository", style="cyan")
        repo_table.add_column("Branch", style="blue")
        repo_table.add_column("Commit", style="yellow")
        repo_table.add_column("Status", style="green")

        for status in statuses:
            dirty = "[red]dirty[/red]" if status["is_dirty"] else "[green]clean[/green]"
            repo_table.add_row(status["name"], status["branch"], status["commit"], dirty)
        console.print(repo_table)
    else:
        console.print("  [dim]No repositories cloned[/dim]")

    # Helm Releases
    console.print("\n[bold]Helm Releases:[/bold]")
    releases = helm.list_releases(all_namespaces=True)
    if releases:
        helm.display_releases_table(releases)
    else:
        console.print("  [dim]No releases deployed[/dim]")


@main.command()
@click.argument("app", required=True)
@click.option("--namespace", "-n", default=None, help="Target namespace for the application")
@click.option("--env", default=None, help="Environment (dev, stage, prod)")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed information")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.pass_context
def readiness(ctx, app, namespace, env, verbose, json):
    """Check if OGM environment is ready for a specific GenAI application deployment."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print(f"[bold cyan]  🚀 OGM READINESS CHECK - {app.upper()} Application[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]

    from .readiness import ReadinessManager

    readiness_mgr = ReadinessManager(config)
    readiness_mgr.check_application_readiness(
        app, namespace=namespace, environment=env, verbose=verbose, json_output=json
    )


@main.command()
@click.option("--clean", is_flag=True, help="Clean environment if issues found")
@click.option("--force", is_flag=True, help="Force cleanup without confirmation")
@click.pass_context
def check(ctx, clean, force):
    """Check all requisites, setup kubeconfig path, and ensure environment is ready for K3s installation."""
    console.print("\n[bold cyan]K3s Environment Check & Setup[/bold cyan]\n")

    config = ctx.obj["config"]
    from .kubernetes import KubernetesManager
    from .utils import validate_prerequisites

    k3s = KubernetesManager(config.k3s)

    # Step 1: Check prerequisites
    console.print("[bold]Step 1: Checking Prerequisites[/bold]")
    all_ok, missing = validate_prerequisites()

    if all_ok:
        console.print("  [green]✓ All prerequisites installed[/green]")
    else:
        console.print("  [red]✗ Missing tools:[/red]")
        for tool in missing:
            console.print(f"    - {tool}")
        console.print("\n[yellow]Please install missing tools before proceeding.[/yellow]")
        return

    # Step 2: Setup kubeconfig path
    console.print("\n[bold]Step 2: Setting up Kubeconfig Path[/bold]")
    if not k3s.setup_kubeconfig_path():
        console.print("[red]❌ Failed to setup kubeconfig path[/red]")
        return

    # Step 3: Check environment readiness
    console.print("\n[bold]Step 3: Checking Environment Readiness[/bold]")
    ready, issues = k3s.check_environment_readiness()

    if ready:
        console.print("\n[green]✅ Environment is fully ready for K3s installation![/green]")
        console.print("[green]You can now run 'ogm init' to install K3s.[/green]")
    else:
        console.print(f"\n[red]❌ Found {len(issues)} environment issues:[/red]")
        for i, issue in enumerate(issues, 1):
            console.print(f"  {i}. {issue}")

        # Interactive cleanup prompt
        should_clean = clean  # Use flag if provided

        if not clean and not force:
            # Interactive mode - ask user
            console.print("\n[cyan]Options:[/cyan]")
            console.print("  1. Clean environment automatically")
            console.print("  2. Continue without cleaning")
            console.print("  3. Exit")

            try:
                while True:
                    choice = input("Choose option (1-3): ").strip()
                    if choice == "1":
                        should_clean = True
                        break
                    elif choice == "2":
                        should_clean = False
                        console.print("[yellow]⚠️  Continuing with potential conflicts...[/yellow]")
                        console.print(
                            "[yellow]Note: You can still run 'ogm init' which will offer cleanup again.[/yellow]"
                        )
                        return
                    elif choice == "3":
                        console.print("[cyan]Check cancelled by user[/cyan]")
                        return
                    else:
                        console.print("[red]Invalid choice. Please enter 1, 2, or 3.[/red]")
            except (EOFError, KeyboardInterrupt):
                console.print("\n[cyan]Check cancelled[/cyan]")
                return

        if should_clean:
            console.print("\n[cyan]🧹 Cleaning environment...[/cyan]")
            if k3s.clean_environment(force=force):
                console.print("[green]✅ Environment cleaned successfully[/green]")
                # Re-check after cleaning
                console.print("\n[bold]Re-checking environment after cleanup...[/bold]")
                ready2, issues2 = k3s.check_environment_readiness()
                if ready2:
                    console.print("[green]✅ Environment is now ready![/green]")
                    console.print("[green]You can now run 'ogm init' to install K3s.[/green]")
                else:
                    console.print(f"[yellow]⚠️  Still {len(issues2)} issues after cleaning[/yellow]")
                    for i, issue in enumerate(issues2, 1):
                        console.print(f"  {i}. {issue}")
                    console.print("[yellow]Some issues may require manual intervention.[/yellow]")
            else:
                console.print("[red]❌ Environment cleanup failed[/red]")
        else:
            console.print(
                "\n[yellow]💡 Run 'ogm check --clean' to automatically clean issues[/yellow]"
            )
            console.print(
                "[yellow]💡 Or run 'ogm init' which will offer to clean automatically[/yellow]"
            )


@main.command()
@click.pass_context
def clean(ctx):
    """Clean up failed deployments and resources."""
    console.print("\n[cyan]Cleaning up...[/cyan]\n")

    config = ctx.obj["config"]
    state = ctx.obj["state"]

    from .destroy import DestroyManager
    from .git_ops import GitManager
    from .helm import HelmManager
    from .kubernetes import KubernetesManager

    git = GitManager(config.repos_dir)
    helm = HelmManager()
    k3s = KubernetesManager(config.k3s)
    destroy_mgr = DestroyManager(config, git, helm, k3s, state)

    # Clean up failed deployments
    results = destroy_mgr.cleanup_failed_deployments()

    if results:
        console.print(f"[green]✓ Cleaned up {len(results)} failed deployments[/green]")
    else:
        console.print("[green]✓ No failed deployments found[/green]")


@main.command()
@click.argument("namespace")
@click.option("--force", is_flag=True, help="Skip confirmation")
@click.option("--remove-data", is_flag=True, help="Remove persistent volume claims and data")
@click.option("--delete-namespace", is_flag=True, help="Delete the namespace itself after cleaning")
@click.pass_context
def clean_namespace(ctx, namespace, force, remove_data, delete_namespace):
    """Completely clean a namespace including all resources and optionally PVCs."""
    console.print(f"\n[bold red]🧹 Cleaning namespace: {namespace}[/bold red]\n")

    # Safety check for critical namespaces
    critical_namespaces = ["kube-system", "kube-public", "kube-node-lease", "default"]
    if namespace in critical_namespaces and not force:
        console.print(
            f"[red]❌ Cannot clean critical namespace '{namespace}' without --force[/red]"
        )
        console.print("[yellow]Critical namespaces contain essential cluster components.[/yellow]")
        return

    # Confirm action
    if not force:
        console.print(
            f"[yellow]⚠️  This will delete ALL resources in namespace '{namespace}'[/yellow]"
        )
        if remove_data:
            console.print(
                f"[red]⚠️  This will also delete ALL persistent volume claims and DATA![/red]"
            )
        if delete_namespace:
            console.print(
                f"[red]⚠️  This will also DELETE the namespace '{namespace}' itself![/red]"
            )
        console.print(f"[yellow]This action cannot be undone.[/yellow]")

        try:
            response = input(f"\nType 'yes' to confirm cleaning namespace '{namespace}': ").strip()
            if response.lower() != "yes":
                console.print("[cyan]Operation cancelled[/cyan]")
                return
        except (EOFError, KeyboardInterrupt):
            console.print("\n[cyan]Operation cancelled[/cyan]")
            return

    import subprocess

    # Get all resources in the namespace first
    console.print(f"[cyan]Analyzing resources in namespace '{namespace}'...[/cyan]")

    # Check if namespace exists
    result = subprocess.run(
        ["kubectl", "get", "namespace", namespace], capture_output=True, text=True
    )
    if result.returncode != 0:
        console.print(f"[red]❌ Namespace '{namespace}' does not exist[/red]")
        return

    # List all resource types that can exist in a namespace
    resource_types = [
        "pods",
        "services",
        "deployments",
        "statefulsets",
        "daemonsets",
        "jobs",
        "cronjobs",
        "configmaps",
        "secrets",
        "ingress",
        "networkpolicies",
        "persistentvolumeclaims",
        "serviceaccounts",
        "roles",
        "rolebindings",
    ]

    resources_found = {}
    total_resources = 0

    for resource_type in resource_types:
        try:
            result = subprocess.run(
                ["kubectl", "get", resource_type, "-n", namespace, "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                lines = result.stdout.strip().split("\n")
                count = len(lines)
                resources_found[resource_type] = count
                total_resources += count
        except subprocess.TimeoutExpired:
            console.print(f"[yellow]⚠️  Timeout checking {resource_type}[/yellow]")
        except Exception as e:
            console.print(f"[yellow]⚠️  Error checking {resource_type}: {e}[/yellow]")

    if total_resources == 0:
        console.print(f"[green]✓ Namespace '{namespace}' is already empty[/green]")
        return

    console.print(f"[yellow]Found {total_resources} resources to clean:[/yellow]")
    for resource_type, count in resources_found.items():
        console.print(f"  - {resource_type}: {count}")

    # Start cleaning
    console.print(f"\n[cyan]Starting cleanup of namespace '{namespace}'...[/cyan]")

    cleaned_count = 0
    errors = []

    # First, delete deployments/statefulsets/daemonsets (they manage pods)
    workload_resources = ["deployments", "statefulsets", "daemonsets", "jobs", "cronjobs"]
    for resource_type in workload_resources:
        if resource_type in resources_found:
            console.print(f"[dim]Deleting {resource_type}...[/dim]")
            result = subprocess.run(
                ["kubectl", "delete", resource_type, "--all", "-n", namespace, "--timeout=60s"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                console.print(f"[green]✓ Deleted {resource_type}[/green]")
                cleaned_count += resources_found[resource_type]
            else:
                errors.append(f"Failed to delete {resource_type}: {result.stderr}")

    # Wait a moment for workloads to terminate
    if workload_resources:
        console.print("[dim]Waiting for workloads to terminate...[/dim]")
        import time

        time.sleep(5)

    # Delete pods (in case some weren't managed by workloads)
    if "pods" in resources_found:
        console.print("[dim]Deleting remaining pods...[/dim]")
        result = subprocess.run(
            ["kubectl", "delete", "pods", "--all", "-n", namespace, "--timeout=30s", "--force"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            console.print("[green]✓ Deleted pods[/green]")
            cleaned_count += resources_found["pods"]
        else:
            errors.append(f"Failed to delete pods: {result.stderr}")

    # Delete services
    if "services" in resources_found:
        console.print("[dim]Deleting services...[/dim]")
        result = subprocess.run(
            ["kubectl", "delete", "services", "--all", "-n", namespace, "--timeout=30s"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            console.print("[green]✓ Deleted services[/green]")
            cleaned_count += resources_found["services"]
        else:
            errors.append(f"Failed to delete services: {result.stderr}")

    # Delete ingress
    if "ingress" in resources_found:
        console.print("[dim]Deleting ingress resources...[/dim]")
        result = subprocess.run(
            ["kubectl", "delete", "ingress", "--all", "-n", namespace, "--timeout=30s"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            console.print("[green]✓ Deleted ingress[/green]")
            cleaned_count += resources_found["ingress"]
        else:
            errors.append(f"Failed to delete ingress: {result.stderr}")

    # Handle PVCs - only if remove-data is specified
    if remove_data and "persistentvolumeclaims" in resources_found:
        console.print("[red]Deleting persistent volume claims (this will remove data)...[/red]")
        result = subprocess.run(
            ["kubectl", "delete", "pvc", "--all", "-n", namespace, "--timeout=60s"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            console.print("[green]✓ Deleted persistent volume claims[/green]")
            cleaned_count += resources_found["persistentvolumeclaims"]
        else:
            errors.append(f"Failed to delete PVCs: {result.stderr}")
    elif "persistentvolumeclaims" in resources_found and not remove_data:
        console.print("[yellow]⚠️  Skipping PVCs (use --remove-data to delete them)[/yellow]")

    # Delete remaining resources
    remaining_resources = [
        "configmaps",
        "secrets",
        "networkpolicies",
        "serviceaccounts",
        "roles",
        "rolebindings",
    ]

    for resource_type in remaining_resources:
        if resource_type in resources_found:
            console.print(f"[dim]Deleting {resource_type}...[/dim]")
            result = subprocess.run(
                ["kubectl", "delete", resource_type, "--all", "-n", namespace, "--timeout=30s"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                console.print(f"[green]✓ Deleted {resource_type}[/green]")
                cleaned_count += resources_found[resource_type]
            else:
                errors.append(f"Failed to delete {resource_type}: {result.stderr}")

    # Final verification
    console.print(f"\n[cyan]Verifying cleanup...[/cyan]")
    remaining = 0
    system_resources = []

    for resource_type in resource_types:
        try:
            result = subprocess.run(
                ["kubectl", "get", resource_type, "-n", namespace, "--no-headers"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                lines = result.stdout.strip().split("\n")
                for line in lines:
                    if line.strip():
                        # Check if this is a system resource that should be excluded
                        parts = line.split()
                        if len(parts) > 0:
                            resource_name = parts[0]
                            # Exclude common system resources
                            if not (
                                (
                                    resource_type == "configmaps"
                                    and resource_name == "kube-root-ca.crt"
                                )
                                or (
                                    resource_type == "serviceaccounts"
                                    and resource_name == "default"
                                )
                            ):
                                remaining += 1
                            else:
                                system_resources.append(f"{resource_type}/{resource_name}")
        except:
            pass

    # Summary
    console.print(f"\n[bold cyan]Cleanup Summary for namespace '{namespace}':[/bold cyan]")
    console.print(f"  Resources cleaned: {cleaned_count}")
    if remaining > 0:
        console.print(f"  User resources remaining: {remaining}")
    if system_resources:
        console.print(f"  System resources preserved: {len(system_resources)}")
        for sys_res in system_resources:
            console.print(f"    - {sys_res}")
    if errors:
        console.print(f"  Errors encountered: {len(errors)}")
        for error in errors:
            console.print(f"    - {error}")

    if remaining == 0 and not errors:
        console.print(f"[green]✅ Namespace '{namespace}' completely cleaned![/green]")
        console.print(
            f"[dim]System resources preserved: {', '.join(system_resources) if system_resources else 'None'}[/dim]"
        )

        # Optionally delete the namespace itself
        if delete_namespace:
            console.print(f"\n[cyan]Deleting namespace '{namespace}' itself...[/cyan]")
            result = subprocess.run(
                ["kubectl", "delete", "namespace", namespace, "--timeout=60s"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                console.print(f"[green]✅ Namespace '{namespace}' deleted successfully![/green]")
            else:
                console.print(f"[red]❌ Failed to delete namespace: {result.stderr}[/red]")
                errors.append(f"Failed to delete namespace: {result.stderr}")

    elif remaining == 0:
        console.print(
            f"[yellow]⚠️  Namespace '{namespace}' cleaned with {len(errors)} errors[/yellow]"
        )
    else:
        console.print(f"[red]❌ Cleanup incomplete - {remaining} user resources still remain[/red]")


@main.command()
@click.option("--verbose", "-v", is_flag=True, help="Show detailed information")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.option("--raw", is_flag=True, help="Show only raw kubectl output (like kubectl get all)")
@click.pass_context
def insight(ctx, verbose, json, raw):
    """Comprehensive insight into all OGM resources, services, and dependencies."""

    config = ctx.obj["config"]

    from .insight import InsightManager

    insight_mgr = InsightManager(config)

    if raw:
        insight_mgr.display_raw_kubectl_only(verbose=verbose)
    else:
        console.print(
            "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print("[bold cyan]  🔍 OGM INSIGHT - Comprehensive System Overview[/bold cyan]")
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
        )
        insight_mgr.generate_full_insight(verbose=verbose, json_output=json)


@main.command()
@click.argument("app", required=False, default=None)
@click.option("--namespace", "-n", default=None, help="Filter by namespace")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.pass_context
def summary(ctx, app, namespace, json):
    """Show comprehensive summary of deployed applications with URLs, credentials, and capabilities."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print(
        "[bold cyan]  📋 OGM APPLICATION SUMMARY - Deployed Services Overview[/bold cyan]"
    )
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]

    import subprocess

    from .helm import HelmManager
    from .kubernetes import KubernetesManager

    helm = HelmManager()
    k3s = KubernetesManager(config.k3s)

    # Get all helm releases
    releases = helm.list_releases(all_namespaces=True)

    if not releases:
        console.print("[yellow]No applications deployed[/yellow]")
        return

    # Filter by app name if specified
    if app:
        releases = [r for r in releases if r.get("name", "").lower() == app.lower()]
        if not releases:
            console.print(f"[yellow]Application '{app}' not found[/yellow]")
            return

    # Note: We don't filter releases by namespace here because applications might be deployed
    # to different namespaces than their helm release namespace. The namespace filtering
    # is handled during the service/capability discovery phase.

    if json:
        import json as json_lib

        console.print(json_lib.dumps(releases, indent=2))
        return

    # Process each application
    for release in releases:
        app_name = release.get("name", "Unknown")
        app_namespace = release.get("namespace", "default")
        app_status = release.get("status", "Unknown")
        app_version = release.get("chart", "Unknown")

        # Check both the helm release namespace and potential app-specific namespaces
        namespaces_to_check = [app_namespace]
        if app_name not in ["argocd", "nginx-ingress"]:  # Skip system apps
            namespaces_to_check.append(app_name)

        # If namespace filter is specified, only show apps that have services in that namespace
        if namespace:
            has_services_in_namespace = any(
                get_services_for_app(app_name, ns) for ns in namespaces_to_check if ns == namespace
            )
            if not has_services_in_namespace:
                continue

        console.print(f"[bold blue]📦 Application: {app_name}[/bold blue]")
        console.print(
            f"[dim]   Namespace: {app_namespace} | Status: {app_status} | Chart: {app_version}[/dim]"
        )
        console.print()

        services_found = False
        for ns in namespaces_to_check:
            services = get_services_for_app(app_name, ns)
            if services:
                services_found = True
                console.print("[bold green]🌐 Access URLs:[/bold green]")
                for svc in services:
                    urls = extract_service_urls(svc, ns)
                    for url_info in urls:
                        console.print(f"   {url_info}")
                console.print()
                break  # Use the first namespace that has services

        if not services_found:
            console.print("[dim]🌐 No services found[/dim]")
            console.print()

        # Check credentials in the namespaces
        credentials_found = False
        for ns in namespaces_to_check:
            credentials = get_app_credentials(app_name, ns)
            if credentials:
                credentials_found = True
                console.print("[bold yellow]🔐 Credentials & Configuration:[/bold yellow]")
                for cred in credentials:
                    console.print(f"   {cred}")
                console.print()
                break

        if not credentials_found:
            console.print("[dim]🔐 No credentials found[/dim]")
            console.print()

        # Check capabilities in the namespaces
        capabilities_found = False
        for ns in namespaces_to_check:
            capabilities = get_app_capabilities(app_name, ns)
            if capabilities:
                capabilities_found = True
                console.print("[bold magenta]⚡ Capabilities & Features:[/bold magenta]")
                for cap in capabilities:
                    console.print(f"   {cap}")
                console.print()
                break

        if not capabilities_found:
            console.print("[dim]⚡ No capabilities detected[/dim]")
            console.print()

        # Check resources in the namespaces
        resources_found = False
        for ns in namespaces_to_check:
            resources = get_app_resources(app_name, ns)
            if resources:
                resources_found = True
                console.print("[bold cyan]📊 Resource Usage:[/bold cyan]")
                for res in resources:
                    console.print(f"   {res}")
                console.print()
                break

        if not resources_found:
            console.print("[dim]📊 No resource usage data[/dim]")
            console.print()

        console.print("[dim]" + "─" * 80 + "[/dim]")
        console.print()


def get_services_for_app(app_name, namespace):
    """Get services for a specific application."""
    try:
        # First try the standard label selector
        result = subprocess.run(
            [
                "kubectl",
                "get",
                "services",
                "-n",
                namespace,
                "-l",
                f"app.kubernetes.io/name={app_name},app={app_name}",
                "-o",
                "json",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            import json

            data = json.loads(result.stdout)
            services = data.get("items", [])
            if services:
                return services

        # If no services found, try broader helm-managed services
        result = subprocess.run(
            [
                "kubectl",
                "get",
                "services",
                "-n",
                namespace,
                "-l",
                "app.kubernetes.io/managed-by=Helm",
                "-o",
                "json",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            import json

            data = json.loads(result.stdout)
            all_services = data.get("items", [])

            # Filter services that might belong to this app
            filtered_services = []
            for svc in all_services:
                svc_name = svc.get("metadata", {}).get("name", "").lower()
                # Check if service name contains app name or related terms
                if app_name.lower() in svc_name or any(
                    term in svc_name for term in ["ui", "app", "service"]
                ):
                    filtered_services.append(svc)

            return filtered_services
    except Exception as e:
        print(f"DEBUG: Exception in get_services_for_app: {e}")
    return []


def extract_service_urls(service, namespace):
    """Extract URLs and access information from a service."""
    urls = []
    spec = service.get("spec", {})
    metadata = service.get("metadata", {})
    service_name = metadata.get("name", "unknown")
    service_type = spec.get("type", "ClusterIP")

    if service_type == "NodePort":
        ports = spec.get("ports", [])
        for port in ports:
            node_port = port.get("nodePort")
            port_num = port.get("port", node_port)
            if node_port:
                # Get node IP
                try:
                    node_result = subprocess.run(
                        [
                            "kubectl",
                            "get",
                            "nodes",
                            "-o",
                            "jsonpath='{.items[0].status.addresses[?(@.type==\"InternalIP\")].address}'",
                        ],
                        capture_output=True,
                        text=True,
                        timeout=5,
                    )
                    if node_result.returncode == 0:
                        node_ip = node_result.stdout.strip("'")
                        urls.append(f"🔗 http://{node_ip}:{node_port} (NodePort)")
                    else:
                        urls.append(f"🔗 http://<node-ip>:{node_port} (NodePort)")
                except:
                    urls.append(f"🔗 http://<node-ip>:{node_port} (NodePort)")

    elif service_type == "LoadBalancer":
        # Check for external IP
        status = service.get("status", {})
        lb_status = status.get("loadBalancer", {})
        ingress = lb_status.get("ingress", [])
        if ingress:
            for ing in ingress:
                ip = ing.get("ip")
                hostname = ing.get("hostname")
                if ip:
                    urls.append(f"🔗 http://{ip} (LoadBalancer)")
                elif hostname:
                    urls.append(f"🔗 http://{hostname} (LoadBalancer)")

    elif service_type == "ClusterIP":
        urls.append(f"🔗 http://{service_name}.{namespace}.svc.cluster.local (Internal)")

    # Check for ingress resources
    try:
        ingress_result = subprocess.run(
            [
                "kubectl",
                "get",
                "ingress",
                "-n",
                namespace,
                "-l",
                f"app.kubernetes.io/name={service_name},app={service_name}",
                "-o",
                "json",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if ingress_result.returncode == 0:
            import json

            ingress_data = json.loads(ingress_result.stdout)
            for item in ingress_data.get("items", []):
                spec = item.get("spec", {})
                rules = spec.get("rules", [])
                for rule in rules:
                    host = rule.get("host", "unknown")
                    http = rule.get("http", {})
                    paths = http.get("paths", [])
                    for path in paths:
                        path_str = path.get("path", "/")
                        urls.append(f"🌐 https://{host}{path_str} (Ingress)")
    except:
        pass

    return urls if urls else [f"🔗 Service type: {service_type} (Internal access only)"]


def get_app_credentials(app_name, namespace):
    """Get credentials and configuration for an application."""
    credentials = []

    # Check for secrets - try multiple label selectors
    try:
        # Try standard labels first
        result = subprocess.run(
            [
                "kubectl",
                "get",
                "secrets",
                "-n",
                namespace,
                "-l",
                f"app.kubernetes.io/name={app_name},app={app_name}",
                "-o",
                "json",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            # Try helm-managed secrets
            result = subprocess.run(
                [
                    "kubectl",
                    "get",
                    "secrets",
                    "-n",
                    namespace,
                    "-l",
                    "app.kubernetes.io/managed-by=Helm",
                    "-o",
                    "json",
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )

        if result.returncode == 0:
            import json

            secret_data = json.loads(result.stdout)
            for item in secret_data.get("items", []):
                name = item.get("metadata", {}).get("name", "unknown")
                secret_type = item.get("type", "Opaque")
                credentials.append(f"🔑 Secret: {name} (Type: {secret_type})")
    except:
        pass

    # Check for configmaps - try multiple label selectors
    try:
        result = subprocess.run(
            [
                "kubectl",
                "get",
                "configmaps",
                "-n",
                namespace,
                "-l",
                f"app.kubernetes.io/name={app_name},app={app_name}",
                "-o",
                "json",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            result = subprocess.run(
                [
                    "kubectl",
                    "get",
                    "configmaps",
                    "-n",
                    namespace,
                    "-l",
                    "app.kubernetes.io/managed-by=Helm",
                    "-o",
                    "json",
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )

        if result.returncode == 0:
            import json

            cm_data = json.loads(result.stdout)
            for item in cm_data.get("items", []):
                name = item.get("metadata", {}).get("name", "unknown")
                data_keys = list(item.get("data", {}).keys())
                if data_keys:
                    credentials.append(
                        f"⚙️  ConfigMap: {name} (Keys: {', '.join(data_keys[:3])}{'...' if len(data_keys) > 3 else ''})"
                    )
    except:
        pass

    return credentials


def get_app_capabilities(app_name, namespace):
    """Get capabilities and features for an application."""
    capabilities = []

    # Check pod labels and annotations for capabilities
    try:
        # Try standard labels first
        result = subprocess.run(
            [
                "kubectl",
                "get",
                "pods",
                "-n",
                namespace,
                "-l",
                f"app.kubernetes.io/name={app_name},app={app_name}",
                "-o",
                "json",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            # Try with just app label
            result = subprocess.run(
                ["kubectl", "get", "pods", "-n", namespace, "-l", f"app={app_name}", "-o", "json"],
                capture_output=True,
                text=True,
                timeout=10,
            )
        if result.returncode != 0:
            # Try to get all pods in namespace and filter by name
            result = subprocess.run(
                ["kubectl", "get", "pods", "-n", namespace, "-o", "json"],
                capture_output=True,
                text=True,
                timeout=10,
            )

        if result.returncode == 0:
            import json

            pod_data = json.loads(result.stdout)
            items = pod_data.get("items", [])

            # Filter pods that might belong to this app
            relevant_pods = []
            for pod in items:
                pod_name = pod.get("metadata", {}).get("name", "").lower()
                labels = pod.get("metadata", {}).get("labels", {})

                # Check if pod name contains app name or has relevant labels
                if (
                    app_name.lower() in pod_name
                    or labels.get("app") == app_name
                    or any(app_name.lower() in str(label) for label in labels.values())
                    or
                    # Also check for helm-managed pods in this namespace
                    labels.get("app.kubernetes.io/managed-by") == "Helm"
                ):
                    relevant_pods.append(pod)

            if relevant_pods:
                # Use all relevant pods for analysis
                for pod in relevant_pods:
                    # Get container information
                    containers = pod.get("spec", {}).get("containers", [])
                    for container in containers:
                        image = container.get("image", "unknown")
                        capabilities.append(f"🐳 Container: {image}")

                        # Check for ports
                        ports = container.get("ports", [])
                        if ports:
                            port_list = [str(p.get("containerPort", "unknown")) for p in ports]
                            capabilities.append(f"🔌 Ports: {', '.join(port_list)}")

                        # Check for environment variables (sensitive info masked)
                        env_vars = container.get("env", [])
                        env_from = container.get("envFrom", [])
                        if env_vars or env_from:
                            env_names = [
                                env.get("name", "unknown") for env in env_vars if env.get("name")
                            ]
                            if env_from:
                                env_names.extend(
                                    [
                                        f"from-{ef.get('configMapRef', {}).get('name', 'config')}"
                                        for ef in env_from
                                        if ef.get("configMapRef")
                                    ]
                                )
                                env_names.extend(
                                    [
                                        f"from-{ef.get('secretRef', {}).get('name', 'secret')}"
                                        for ef in env_from
                                        if ef.get("secretRef")
                                    ]
                                )
                            if env_names:
                                capabilities.append(
                                    f"🔧 Environment: {', '.join(env_names[:5])}{'...' if len(env_names) > 5 else ''}"
                                )

                    # Check for volumes
                    volumes = pod.get("spec", {}).get("volumes", [])
                    if volumes:
                        vol_types = []
                        for vol in volumes:
                            if "configMap" in vol:
                                vol_types.append("ConfigMap")
                            elif "secret" in vol:
                                vol_types.append("Secret")
                            elif "persistentVolumeClaim" in vol:
                                vol_types.append("PVC")
                            elif "emptyDir" in vol:
                                vol_types.append("EmptyDir")
                            else:
                                vol_types.append("Other")

                        if vol_types:
                            capabilities.append(f"💾 Volumes: {', '.join(set(vol_types))}")

                    # Check for resource limits
                    resources = containers[0].get("resources", {})
                    limits = resources.get("limits", {})
                    requests = resources.get("requests", {})

                    if limits or requests:
                        res_info = []
                        for res_type in ["cpu", "memory"]:
                            if res_type in limits:
                                res_info.append(f"{res_type}: {limits[res_type]}")
                            elif res_type in requests:
                                res_info.append(f"{res_type}: {requests[res_type]} (req)")

                        if res_info:
                            capabilities.append(f"📊 Resources: {', '.join(res_info)}")

    except:
        pass

    return capabilities


def get_app_resources(app_name, namespace):
    """Get resource usage information for an application."""
    resources = []

    try:
        # Get pod resource usage - try multiple label selectors
        result = subprocess.run(
            [
                "kubectl",
                "top",
                "pods",
                "-n",
                namespace,
                "-l",
                f"app.kubernetes.io/name={app_name},app={app_name}",
                "--no-headers",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            result = subprocess.run(
                [
                    "kubectl",
                    "top",
                    "pods",
                    "-n",
                    namespace,
                    "-l",
                    f"app={app_name}",
                    "--no-headers",
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
        if result.returncode != 0:
            # Get all pods and filter
            result = subprocess.run(
                ["kubectl", "top", "pods", "-n", namespace, "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10,
            )

        if result.returncode == 0 and result.stdout.strip():
            lines = result.stdout.strip().split("\n")
            # Filter lines that contain app-related pod names
            relevant_lines = [line for line in lines if app_name.lower() in line.lower()]
            if relevant_lines:
                resources.append(f"📈 Pods: {len(relevant_lines)} running")
                resources.append(f"⚡ Active pods consuming cluster resources")

    except:
        pass

    # Get PVC information - try multiple label selectors
    try:
        result = subprocess.run(
            [
                "kubectl",
                "get",
                "pvc",
                "-n",
                namespace,
                "-l",
                f"app.kubernetes.io/name={app_name},app={app_name}",
                "--no-headers",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            result = subprocess.run(
                ["kubectl", "get", "pvc", "-n", namespace, "-l", f"app={app_name}", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10,
            )
        if result.returncode != 0:
            result = subprocess.run(
                ["kubectl", "get", "pvc", "-n", namespace, "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10,
            )

        if result.returncode == 0 and result.stdout.strip():
            lines = result.stdout.strip().split("\n")
            relevant_lines = [line for line in lines if app_name.lower() in line.lower()]
            if relevant_lines:
                resources.append(f"💽 Persistent Storage: {len(relevant_lines)} PVC(s)")

    except:
        pass

    return resources


@main.group("diagnostic")
def diagnostic_group():
    """Run diagnostic checks for OGM system components."""
    pass


@diagnostic_group.command("system")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.pass_context
def diagnostic_system(ctx, json):
    """Check system requirements and environment."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🔧 OGM DIAGNOSTIC - System Requirements Check[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]
    from .diagnostic import DiagnosticManager

    diag_mgr = DiagnosticManager(config)

    if json:
        result = diag_mgr.check_environment_info()
        console.print(json.dumps(result, indent=2, default=str))
    else:
        env_info = diag_mgr.check_environment_info()
        console.print(f"Current directory: {env_info['current_directory']}")
        console.print(f"User: {env_info['user']}")

        if env_info["environment_variables"]:
            console.print("OGM environment variables:")
            for var, value in env_info["environment_variables"].items():
                console.print(f"  {var}={value}")
        else:
            console.print("No OGM environment variables found")


@diagnostic_group.command("cluster")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.pass_context
def diagnostic_cluster(ctx, json):
    """Check cluster connectivity and status."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🔧 OGM DIAGNOSTIC - Cluster Status Check[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]
    from .diagnostic import DiagnosticManager

    diag_mgr = DiagnosticManager(config)

    if json:
        result = {
            "kubectl": diag_mgr.check_kubectl_status(),
            "cluster_connectivity": diag_mgr.check_cluster_connectivity(),
            "k3s_service": diag_mgr.check_k3s_service_status(),
            "cluster_resources": diag_mgr.check_basic_cluster_resources(),
        }
        console.print(json.dumps(result, indent=2, default=str))
    else:
        # kubectl Status
        kubectl_status = diag_mgr.check_kubectl_status()
        status = (
            "[green]✓ Available[/green]"
            if kubectl_status["available"]
            else "[red]✗ Unavailable[/red]"
        )
        console.print(f"kubectl available: {status}")
        console.print(f"kubectl version: {kubectl_status['version']}")
        console.print(f"Current context: {kubectl_status['current_context']}")

        if kubectl_status["config_accessible"]:
            console.print("Kubeconfig: [green]✓ Accessible[/green]")
        else:
            console.print("Kubeconfig: [red]✗ Not accessible[/red]")
        console.print()

        # Cluster Connectivity
        connectivity = diag_mgr.check_cluster_connectivity()
        status = (
            "[green]✓ Accessible[/green]"
            if connectivity["cluster_info_accessible"]
            else "[red]✗ Not accessible[/red]"
        )
        console.print(f"Cluster info: {status}")

        status = (
            "[green]✓ Accessible[/green]"
            if connectivity["nodes_accessible"]
            else "[red]✗ Not accessible[/red]"
        )
        console.print(f"Nodes: {status} ({connectivity['node_count']} nodes)")
        console.print()

        # K3s Service Status
        k3s_status = diag_mgr.check_k3s_service_status()
        if k3s_status["systemctl_available"]:
            console.print(f"K3s service status: {k3s_status['k3s_service_status']}")
        else:
            console.print("K3s service: [red]✗ systemctl not available or service not found[/red]")

        console.print(f"K3s processes running: {k3s_status['k3s_processes_running']}")
        console.print()

        # Basic Cluster Resources
        resources = diag_mgr.check_basic_cluster_resources()
        if resources["accessible"]:
            console.print(f"Namespaces: {resources['namespaces']}")
            console.print(f"Pods: {resources['pods']}")
            console.print(f"Services: {resources['services']}")
            console.print(f"Deployments: {resources['deployments']}")
        else:
            console.print("[red]✗ Cluster resources not accessible[/red]")


@diagnostic_group.command("network")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.pass_context
def diagnostic_network(ctx, json):
    """Check network connectivity and DNS resolution."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🔧 OGM DIAGNOSTIC - Network Connectivity Check[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]
    from .diagnostic import DiagnosticManager

    diag_mgr = DiagnosticManager(config)

    # For now, network diagnostics are part of cluster connectivity
    # This could be expanded with specific network checks
    connectivity = diag_mgr.check_cluster_connectivity()

    if json:
        result = {
            "cluster_connectivity": connectivity,
            "network_status": "Network checks integrated with cluster connectivity",
        }
        console.print(json.dumps(result, indent=2, default=str))
    else:
        status = (
            "[green]✓ Accessible[/green]"
            if connectivity["cluster_info_accessible"]
            else "[red]✗ Not accessible[/red]"
        )
        console.print(f"API Server connectivity: {status}")

        status = (
            "[green]✓ Accessible[/green]"
            if connectivity["nodes_accessible"]
            else "[red]✗ Not accessible[/red]"
        )
        console.print(f"Node connectivity: {status}")

        console.print(
            "\n[bold yellow]Note:[/bold yellow] Network diagnostics are currently integrated with cluster connectivity checks."
        )
        console.print(
            "For detailed network troubleshooting, check cluster firewall rules and DNS resolution."
        )


@diagnostic_group.command("health")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.pass_context
def diagnostic_health(ctx, json):
    """Check overall system health and OGM status."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🔧 OGM DIAGNOSTIC - System Health Check[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]
    from .diagnostic import DiagnosticManager

    diag_mgr = DiagnosticManager(config)

    if json:
        result = {
            "helm": diag_mgr.check_helm_status(),
            "ogm_command": diag_mgr.check_ogm_command_status(),
        }
        console.print(json.dumps(result, indent=2, default=str))
    else:
        # Helm Status
        helm_status = diag_mgr.check_helm_status()
        status = (
            "[green]✓ Available[/green]" if helm_status["available"] else "[red]✗ Unavailable[/red]"
        )
        console.print(f"Helm available: {status}")
        console.print(f"Helm version: {helm_status['version']}")

        if helm_status["releases_accessible"]:
            console.print(
                f"Helm releases: [green]✓ Accessible[/green] ({helm_status['releases_count']} releases)"
            )
        else:
            console.print("Helm releases: [red]✗ Not accessible[/red]")
        console.print()

        # OGM Command Status
        ogm_status = diag_mgr.check_ogm_command_status()
        status = (
            "[green]✓ Available[/green]" if ogm_status["available"] else "[red]✗ Unavailable[/red]"
        )
        console.print(f"OGM available: {status}")
        console.print(f"OGM version: {ogm_status['version']}")


@diagnostic_group.command("full")
@click.option("--json", is_flag=True, help="Output in JSON format")
@click.pass_context
def diagnostic_full(ctx, json):
    """Run comprehensive diagnostic checks for all OGM system components."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🔧 OGM DIAGNOSTIC - Full System Component Checks[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]

    from .diagnostic import DiagnosticManager

    diag_mgr = DiagnosticManager(config)
    diag_mgr.run_full_diagnostic(json_output=json)


# ═════════════════════════════════════════════════════════════════════════════
# Authentication Commands
# ═════════════════════════════════════════════════════════════════════════════


@main.group("auth")
def auth_group():
    """Manage authentication credentials."""
    pass


@auth_group.command("git")
@click.option("--username", prompt="Git username", default="", help="Git username")
@click.option(
    "--token",
    prompt="Git token/password",
    hide_input=True,
    default="",
    help="Personal access token",
)
@click.option("--url", default="https://github.com", help="Git server URL")
def configure_git(username, token, url):
    """Configure Git authentication."""
    auth = AuthManager()

    if not username:
        console.print("[yellow]Skipping Git configuration[/yellow]")
        return

    auth.set_git_credentials(username=username, personal_token=token, url=url)


@auth_group.command("registry")
@click.option(
    "--registry", prompt="Registry URL", default="registry.gitlab.com", help="Container registry"
)
@click.option("--username", prompt="Registry username", default="", help="Registry username")
@click.option(
    "--password",
    prompt="Registry password",
    hide_input=True,
    default="",
    help="Registry password/token",
)
def configure_registry(registry, username, password):
    """Configure container registry authentication."""
    auth = AuthManager()

    if not username:
        console.print("[yellow]Skipping registry configuration[/yellow]")
        return

    auth.set_registry_credentials(registry=registry, username=username, password=password)


@auth_group.command("oauth")
@click.option(
    "--provider", prompt="OAuth provider (github/gitlab/google)", default="github", help="Provider"
)
@click.option("--client-id", prompt="Client ID", default="", help="OAuth client ID")
@click.option(
    "--client-secret",
    prompt="Client secret",
    hide_input=True,
    default="",
    help="OAuth client secret",
)
def configure_oauth(provider, client_id, client_secret):
    """Configure OAuth/OIDC credentials."""
    auth = AuthManager()

    if not client_id:
        console.print("[yellow]Skipping OAuth configuration[/yellow]")
        return

    auth.set_oauth_credentials(provider=provider, client_id=client_id, client_secret=client_secret)


@auth_group.command("list")
def list_credentials():
    """Display stored credentials."""
    auth = AuthManager()
    auth.display_credentials_summary()


@auth_group.command("verify")
def verify_credentials():
    """Verify all stored credentials."""
    auth = AuthManager()
    results = auth.verify_all_credentials()

    console.print("\n[bold cyan]Verification Results[/bold cyan]")
    for key, valid in results.items():
        status = "[green]✓[/green]" if valid else "[red]✗[/red]"
        console.print(f"{status} {key}")


@auth_group.command("export-env")
def export_env():
    """Export credentials as environment variables."""
    auth = AuthManager()
    auth.export_credentials_to_env()
    console.print("\n[green]Credentials exported. Use in CI/CD pipelines.[/green]")


@auth_group.command("kubeconfig")
@click.option("--path", default=None, help="Path to kubeconfig file")
def validate_kubeconfig(path):
    """Validate and test Kubernetes configuration."""
    auth = AuthManager()
    if auth.validate_kubeconfig(path):
        console.print("[green]✓ Kubeconfig is valid and accessible[/green]")
    else:
        console.print("[red]✗ Kubeconfig validation failed[/red]")
        sys.exit(1)


# ═════════════════════════════════════════════════════════════════════════════
# Kubernetes Resource Commands
# ═════════════════════════════════════════════════════════════════════════════


@main.group("kubectl")
def kubectl_group():
    """Execute kubectl commands to show Kubernetes resources."""
    pass


@kubectl_group.command("pods")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show pods from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
@click.option("--field-selector", default=None, help="Field selector to filter on")
def get_pods(namespace, all_namespaces, wide, selector, field_selector):
    """Show Kubernetes pods."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes Pods[/bold cyan]\n")

    cmd = ["kubectl", "get", "pods"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    if field_selector:
        cmd.extend(["--field-selector", field_selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("nodes")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_nodes(wide, selector):
    """Show Kubernetes nodes."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes Nodes[/bold cyan]\n")

    cmd = ["kubectl", "get", "nodes"]

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("pv")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_pv(wide, selector):
    """Show Kubernetes persistent volumes."""
    import subprocess

    console.print("\n[bold cyan]Persistent Volumes (PV)[/bold cyan]\n")

    cmd = ["kubectl", "get", "pv"]

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("pvc")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show PVCs from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_pvc(namespace, all_namespaces, wide, selector):
    """Show Kubernetes persistent volume claims."""
    import subprocess

    console.print("\n[bold cyan]Persistent Volume Claims (PVC)[/bold cyan]\n")

    cmd = ["kubectl", "get", "pvc"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("storageclass")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
def get_storageclass(wide):
    """Show Kubernetes storage classes."""
    import subprocess

    console.print("\n[bold cyan]Storage Classes[/bold cyan]\n")

    cmd = ["kubectl", "get", "storageclass"]

    if wide:
        cmd.append("--wide")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("network")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show resources from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
def get_network(namespace, all_namespaces, wide):
    """Show Kubernetes network resources (services, ingresses, network policies)."""
    import subprocess

    console.print("\n[bold cyan]Network Resources[/bold cyan]\n")

    # Show Services
    console.print("[bold yellow]Services:[/bold yellow]")
    cmd_svc = ["kubectl", "get", "services"]

    if all_namespaces:
        cmd_svc.append("--all-namespaces")
    elif namespace:
        cmd_svc.extend(["--namespace", namespace])

    if wide:
        cmd_svc.append("--wide")

    try:
        result_svc = subprocess.run(cmd_svc, capture_output=True, text=True, timeout=30)
        if result_svc.returncode == 0:
            console.print(result_svc.stdout)
        else:
            console.print(f"[red]Error getting services: {result_svc.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")
        return

    console.print("\n[bold yellow]Ingresses:[/bold yellow]")
    cmd_ing = ["kubectl", "get", "ingress"]

    if all_namespaces:
        cmd_ing.append("--all-namespaces")
    elif namespace:
        cmd_ing.extend(["--namespace", namespace])

    if wide:
        cmd_ing.append("--wide")

    try:
        result_ing = subprocess.run(cmd_ing, capture_output=True, text=True, timeout=30)
        if result_ing.returncode == 0:
            console.print(result_ing.stdout)
        else:
            console.print(f"[red]Error getting ingresses: {result_ing.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")

    console.print("\n[bold yellow]Network Policies:[/bold yellow]")
    cmd_np = ["kubectl", "get", "networkpolicy"]

    if all_namespaces:
        cmd_np.append("--all-namespaces")
    elif namespace:
        cmd_np.extend(["--namespace", namespace])

    if wide:
        cmd_np.append("--wide")

    try:
        result_np = subprocess.run(cmd_np, capture_output=True, text=True, timeout=30)
        if result_np.returncode == 0:
            console.print(result_np.stdout)
        else:
            console.print(f"[red]Error getting network policies: {result_np.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")


@kubectl_group.command("deployments")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show deployments from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_deployments(namespace, all_namespaces, wide, selector):
    """Show Kubernetes deployments."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes Deployments[/bold cyan]\n")

    cmd = ["kubectl", "get", "deployments"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("statefulsets")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show statefulsets from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_statefulsets(namespace, all_namespaces, wide, selector):
    """Show Kubernetes statefulsets."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes StatefulSets[/bold cyan]\n")

    cmd = ["kubectl", "get", "statefulsets"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("configmaps")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show configmaps from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_configmaps(namespace, all_namespaces, wide, selector):
    """Show Kubernetes configmaps."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes ConfigMaps[/bold cyan]\n")

    cmd = ["kubectl", "get", "configmaps"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("secrets")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show secrets from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_secrets(namespace, all_namespaces, wide, selector):
    """Show Kubernetes secrets."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes Secrets[/bold cyan]\n")

    cmd = ["kubectl", "get", "secrets"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("jobs")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show jobs from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_jobs(namespace, all_namespaces, wide, selector):
    """Show Kubernetes jobs."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes Jobs[/bold cyan]\n")

    cmd = ["kubectl", "get", "jobs"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("cronjobs")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show cronjobs from all namespaces")
@click.option("--wide", "-w", is_flag=True, help="Show additional information")
@click.option("--selector", "-l", default=None, help="Selector (label query) to filter on")
def get_cronjobs(namespace, all_namespaces, wide, selector):
    """Show Kubernetes cronjobs."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes CronJobs[/bold cyan]\n")

    cmd = ["kubectl", "get", "cronjobs"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    if wide:
        cmd.append("--wide")

    if selector:
        cmd.extend(["--selector", selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("events")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show events from all namespaces")
@click.option("--sort-by", default=".metadata.creationTimestamp", help="Sort events by field")
@click.option("--field-selector", default=None, help="Field selector to filter on")
def get_events(namespace, all_namespaces, sort_by, field_selector):
    """Show Kubernetes events."""
    import subprocess

    console.print("\n[bold cyan]Kubernetes Events[/bold cyan]\n")

    cmd = ["kubectl", "get", "events"]

    if all_namespaces:
        cmd.append("--all-namespaces")
    elif namespace:
        cmd.extend(["--namespace", namespace])

    cmd.extend(["--sort-by", sort_by])

    if field_selector:
        cmd.extend(["--field-selector", field_selector])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            console.print(result.stdout)
        else:
            console.print(f"[red]Error: {result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Command timed out[/red]")
    except FileNotFoundError:
        console.print("[red]kubectl not found. Please install kubectl.[/red]")


@kubectl_group.command("all")
@click.option("--namespace", "-n", default=None, help="Namespace to filter by")
@click.option("--all-namespaces", "-A", is_flag=True, help="Show resources from all namespaces")
def get_all(namespace, all_namespaces):
    """Show all Kubernetes resources in a comprehensive overview."""
    import subprocess

    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  📊 Kubernetes Resources Overview[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    resources = [
        ("nodes", "Nodes"),
        ("namespaces", "Namespaces"),
        ("pods", "Pods"),
        ("services", "Services"),
        ("deployments", "Deployments"),
        ("statefulsets", "StatefulSets"),
        ("jobs", "Jobs"),
        ("cronjobs", "CronJobs"),
        ("configmaps", "ConfigMaps"),
        ("secrets", "Secrets"),
        ("pv", "Persistent Volumes"),
        ("pvc", "Persistent Volume Claims"),
        ("storageclass", "Storage Classes"),
        ("ingress", "Ingresses"),
        ("networkpolicy", "Network Policies"),
    ]

    for resource, display_name in resources:
        console.print(f"[bold yellow]{display_name}:[/bold yellow]")
        cmd = ["kubectl", "get", resource]

        if all_namespaces and resource not in ["nodes", "namespaces", "pv", "storageclass"]:
            cmd.append("--all-namespaces")
        elif namespace and resource not in ["nodes", "namespaces", "pv", "storageclass"]:
            cmd.extend(["--namespace", namespace])

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                # Count lines (subtract 1 for header)
                lines = result.stdout.strip().split("\n")
                count = len(lines) - 1 if len(lines) > 1 else 0
                console.print(f"[green]✓ {count} {display_name.lower()}[/green]")
                if count > 0:
                    console.print(result.stdout)
            else:
                console.print(f"[red]✗ Error getting {display_name.lower()}: {result.stderr}[/red]")
        except subprocess.TimeoutExpired:
            console.print(f"[red]✗ Command timed out for {display_name.lower()}[/red]")
        except FileNotFoundError:
            console.print("[red]kubectl not found. Please install kubectl.[/red]")
            return

        console.print()  # Empty line between resources


@main.command()
@click.pass_context
def version(ctx):
    """Show version and cluster type information."""
    from .kubernetes import KubernetesManager

    config = ctx.obj["config"]

    # Create a mock config object with the correct kubeconfig_path
    class MockConfig:
        def __init__(self, real_config):
            self.kubeconfig_path = real_config.k3s.kubeconfig_path

    mock_config = MockConfig(config)
    k3s_manager = KubernetesManager(mock_config)

    # Determine cluster type based on what's actually running
    cluster_type_display = "Unknown"
    if k3s_manager.is_installed():
        if k3s_manager.cluster_type == "k3s":
            cluster_type_display = "K3s"
        else:
            cluster_type_display = "Full Kubernetes"
    else:
        # If not installed, show based on environment
        if k3s_manager.cluster_type == "k3s":
            cluster_type_display = "K3s (not installed)"
        else:
            cluster_type_display = "Full Kubernetes (not installed)"

    console.print(f"{cluster_type_display} OGM Platform, version 1.0.0")


@main.command()
@click.argument("app", required=False, default=None)
@click.option("--namespace", "-n", default="default", help="Kubernetes namespace")
@click.option("--follow", "-f", is_flag=True, help="Follow log output")
@click.option(
    "--tail", "-t", type=int, default=100, help="Number of lines to show from the end of logs"
)
@click.option("--since", "-s", help="Show logs since timestamp (e.g., 5m, 1h, 2023-01-01T10:00:00)")
@click.option("--level", help="Filter logs by level (DEBUG, INFO, WARN, ERROR)")
@click.pass_context
def logs(ctx, app, namespace, follow, tail, since, level):
    """View application logs from Kubernetes pods."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  📋 OGM LOGS - Application Log Viewer[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]

    # Import required modules
    from .utils import get_kubectl_context, run_command

    kubectl_cmd = get_kubectl_context()
    if not kubectl_cmd:
        console.print(
            "[red]kubectl not found. Please ensure kubectl is installed and configured.[/red]"
        )
        return

    # Build kubectl logs command
    cmd_parts = [kubectl_cmd, "logs"]

    if follow:
        cmd_parts.append("-f")

    if tail != 100:  # Only add if different from default
        cmd_parts.extend(["--tail", str(tail)])

    if since:
        cmd_parts.extend(["--since", since])

    # Find pods for the application
    if app:
        # Get pods matching the app name
        get_pods_cmd = [
            kubectl_cmd,
            "get",
            "pods",
            "-n",
            namespace,
            "-l",
            f"app={app}",
            "--no-headers",
            "-o",
            "custom-columns=NAME:.metadata.name",
        ]

        try:
            pod_result = subprocess.run(get_pods_cmd, capture_output=True, text=True, check=False)
            if pod_result.returncode == 0 and pod_result.stdout.strip():
                pod_names = pod_result.stdout.strip().split("\n")
                if len(pod_names) == 1:
                    cmd_parts.extend(["-n", namespace, pod_names[0]])
                elif len(pod_names) > 1:
                    console.print(f"[yellow]Multiple pods found for app '{app}':[/yellow]")
                    for i, pod in enumerate(pod_names, 1):
                        console.print(f"  {i}. {pod}")
                    console.print(
                        f"[yellow]Showing logs for the first pod: {pod_names[0]}[/yellow]"
                    )
                    cmd_parts.extend(["-n", namespace, pod_names[0]])
                else:
                    console.print(
                        f"[red]No pods found for app '{app}' in namespace '{namespace}'[/red]"
                    )
                    return
            else:
                console.print(
                    f"[red]Failed to find pods for app '{app}' in namespace '{namespace}'[/red]"
                )
                return
        except Exception as e:
            console.print(f"[red]Error finding pods: {e}[/red]")
            return
    else:
        # Show logs for all pods in namespace
        cmd_parts.extend(["-n", namespace, "--all-containers"])

    # Add level filtering if specified
    if level:
        # Note: This is a basic filter - kubectl doesn't have built-in level filtering
        # In a real implementation, you might want to use tools like stern or kubetail
        console.print(
            f"[yellow]Note: Level filtering '{level}' requested but kubectl doesn't support this directly.[/yellow]"
        )
        console.print(
            "[yellow]Consider using 'stern' or 'kubetail' for advanced log filtering.[/yellow]"
        )

    console.print(f"[blue]Executing: {' '.join(cmd_parts)}[/blue]")
    console.print()

    # Execute the logs command
    try:
        if follow:
            # For follow mode, stream output
            import subprocess

            subprocess.run(cmd_parts)
        else:
            # For non-follow mode, capture and display
            logs_result = subprocess.run(cmd_parts, capture_output=True, text=True, check=False)
            if logs_result.returncode == 0:
                console.print(logs_result.stdout)
            else:
                console.print(f"[red]Error getting logs: {logs_result.stderr}[/red]")
    except KeyboardInterrupt:
        console.print("\n[yellow]Log viewing interrupted by user[/yellow]")
    except Exception as e:
        console.print(f"[red]Error viewing logs: {e}[/red]")


@main.group("config")
def config_group():
    """Manage configuration settings."""
    pass


@config_group.command("set")
@click.argument("key")
@click.argument("value")
@click.pass_context
def config_set(ctx, key, value):
    """Set a configuration value."""
    console.print(f"[green]Setting configuration: {key} = {value}[/green]")

    config = ctx.obj["config"]

    # For now, just show that this would set the config
    # In a real implementation, this would update the config file
    console.print("[yellow]Note: Configuration management is not yet fully implemented.[/yellow]")
    console.print(f"[yellow]Would set {key}={value} in configuration.[/yellow]")


@config_group.command("list")
@click.pass_context
def config_list(ctx):
    """List all configuration settings."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  ⚙️  OGM CONFIGURATION - Current Settings[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    config = ctx.obj["config"]

    # Display current configuration
    console.print("[bold blue]Current Configuration:[/bold blue]")
    console.print(f"  State file: {config.state_file}")
    console.print(f"  Config file: {getattr(config, 'config_file', 'Not set')}")

    if hasattr(config, "helm_charts") and config.helm_charts:
        console.print(f"  Helm charts configured: {len(config.helm_charts)}")
    else:
        console.print("  Helm charts: None configured")

    console.print(
        "\n[yellow]Note: Full configuration management is still under development.[/yellow]"
    )


@config_group.command("get")
@click.argument("key")
@click.pass_context
def config_get(ctx, key):
    """Get a configuration value."""
    console.print(f"[blue]Getting configuration: {key}[/blue]")

    config = ctx.obj["config"]

    # For now, just show that this would get the config
    console.print("[yellow]Note: Configuration retrieval is not yet fully implemented.[/yellow]")
    console.print(f"[yellow]Would retrieve value for {key}.[/yellow]")


@main.group("dev")
def dev_group():
    """Development workflow commands."""
    pass


@dev_group.command("shell")
@click.option("--app", help="Application name to connect to")
@click.option("--namespace", "-n", default="default", help="Kubernetes namespace")
@click.pass_context
def dev_shell(ctx, app, namespace):
    """Open an interactive shell in a running container."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🐚 OGM DEV SHELL - Interactive Container Access[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    if not app:
        console.print("[red]Error: --app parameter is required for dev shell[/red]")
        return

    config = ctx.obj["config"]
    from .utils import get_kubectl_context, run_command

    kubectl_cmd = get_kubectl_context()
    if not kubectl_cmd:
        console.print(
            "[red]kubectl not found. Please ensure kubectl is installed and configured.[/red]"
        )
        return

    # Find pods for the application
    get_pods_cmd = [
        kubectl_cmd,
        "get",
        "pods",
        "-n",
        namespace,
        "-l",
        f"app={app}",
        "--no-headers",
        "-o",
        "custom-columns=NAME:.metadata.name",
    ]

    try:
        pod_result = subprocess.run(get_pods_cmd, capture_output=True, text=True, check=False)
        if pod_result.returncode == 0 and pod_result.stdout.strip():
            pod_names = pod_result.stdout.strip().split("\n")
            if len(pod_names) >= 1:
                pod_name = pod_names[0]
                console.print(f"[green]Connecting to pod: {pod_name}[/green]")

                # Execute kubectl exec
                exec_cmd = [
                    kubectl_cmd,
                    "exec",
                    "-it",
                    "-n",
                    namespace,
                    pod_name,
                    "--",
                    "/bin/bash",
                ]

                console.print(f"[blue]Executing: {' '.join(exec_cmd)}[/blue]")
                console.print("[yellow]Type 'exit' to leave the shell[/yellow]")
                console.print()

                try:
                    import subprocess

                    subprocess.run(exec_cmd)
                except KeyboardInterrupt:
                    console.print("\n[yellow]Shell session ended[/yellow]")
            else:
                console.print(
                    f"[red]No pods found for app '{app}' in namespace '{namespace}'[/red]"
                )
        else:
            console.print(
                f"[red]Failed to find pods for app '{app}' in namespace '{namespace}'[/red]"
            )
    except Exception as e:
        console.print(f"[red]Error accessing shell: {e}[/red]")


@main.group("test")
def test_group():
    """Run tests and validation."""
    pass


@test_group.command("unit")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
@click.option("--coverage", is_flag=True, help="Run with coverage")
@click.pass_context
def test_unit(ctx, verbose, coverage):
    """Run unit tests."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🧪 OGM UNIT TESTS - Test Suite Execution[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    import subprocess
    import sys

    # Build pytest command
    cmd = [sys.executable, "-m", "pytest"]

    if verbose:
        cmd.append("-v")

    if coverage:
        cmd.extend(["--cov=ogm", "--cov-report=html", "--cov-report=term"])

    cmd.append("tests/")

    console.print(f"[blue]Executing: {' '.join(cmd)}[/blue]")
    console.print()

    try:
        result = subprocess.run(cmd)
        if result.returncode == 0:
            console.print("[green]✓ All tests passed![/green]")
        else:
            console.print(f"[red]✗ Tests failed with exit code {result.returncode}[/red]")
    except Exception as e:
        console.print(f"[red]Error running tests: {e}[/red]")


@test_group.command("integration")
@click.option("--env", help="Environment to test against")
@click.pass_context
def test_integration(ctx, env):
    """Run integration tests."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🔗 OGM INTEGRATION TESTS - End-to-End Validation[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    console.print("[yellow]Integration tests are not yet implemented.[/yellow]")
    console.print(
        f"[yellow]Would run integration tests against environment: {env or 'default'}[/yellow]"
    )


@main.group("build")
def build_group():
    """Build and package applications."""
    pass


@build_group.command("docker")
@click.argument("app")
@click.option("--tag", "-t", help="Docker image tag")
@click.option("--push", is_flag=True, help="Push image after building")
@click.pass_context
def build_docker(ctx, app, tag, push):
    """Build Docker image for an application."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  🐳 OGM DOCKER BUILD - Container Image Creation[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    import subprocess

    # Default tag if not provided
    if not tag:
        tag = f"{app}:latest"

    console.print(f"[blue]Building Docker image: {tag}[/blue]")

    # Build command
    cmd = ["docker", "build", "-t", tag, "."]

    try:
        console.print(f"[blue]Executing: {' '.join(cmd)}[/blue]")
        result = subprocess.run(cmd)

        if result.returncode == 0:
            console.print(f"[green]✓ Successfully built image: {tag}[/green]")

            if push:
                console.print(f"[blue]Pushing image: {tag}[/blue]")
                push_cmd = ["docker", "push", tag]
                push_result = subprocess.run(push_cmd)
                if push_result.returncode == 0:
                    console.print(f"[green]✓ Successfully pushed image: {tag}[/green]")
                else:
                    console.print(f"[red]✗ Failed to push image: {tag}[/red]")
        else:
            console.print(f"[red]✗ Failed to build image: {tag}[/red]")
    except Exception as e:
        console.print(f"[red]Error building image: {e}[/red]")


@build_group.command("helm")
@click.argument("chart")
@click.option("--version", "-v", help="Chart version")
@click.option("--app-version", help="Application version")
@click.pass_context
def build_helm(ctx, chart, version, app_version):
    """Package Helm chart."""
    console.print(
        "\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]"
    )
    console.print("[bold cyan]  ⎈  OGM HELM BUILD - Chart Packaging[/bold cyan]")
    console.print(
        "[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n"
    )

    import subprocess

    console.print(f"[blue]Packaging Helm chart: {chart}[/blue]")

    # Helm package command
    cmd = ["helm", "package", chart]

    if version:
        cmd.extend(["--version", version])

    if app_version:
        cmd.extend(["--app-version", app_version])

    try:
        console.print(f"[blue]Executing: {' '.join(cmd)}[/blue]")
        result = subprocess.run(cmd)

        if result.returncode == 0:
            console.print(f"[green]✓ Successfully packaged Helm chart: {chart}[/green]")
        else:
            console.print(f"[red]✗ Failed to package Helm chart: {chart}[/red]")
    except Exception as e:
        console.print(f"[red]Error packaging chart: {e}[/red]")


if __name__ == "__main__":
    main()
