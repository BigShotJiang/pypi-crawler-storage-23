"""ScreenGaze GUI package."""
from screen_gaze.gui.main_window import MainWindow

__all__ = ["MainWindow"]
