# j2 from 'macros.j2' import header
# {{ header("Folien aus Test 3", "Slides from Test 3") }}

# %%
import include_me

# %% [markdown]
# We also have an image to include:
# <img src="img/my_image.png" alt="My Image" width="200"/>


# %%
include_me.foo()
