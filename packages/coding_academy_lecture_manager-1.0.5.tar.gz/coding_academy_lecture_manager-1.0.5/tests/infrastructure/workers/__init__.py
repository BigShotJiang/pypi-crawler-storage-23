"""Tests for worker infrastructure."""
