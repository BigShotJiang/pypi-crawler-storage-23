DRAWIO_PROCESS_ROUTING_KEY = "drawio.process"
PLANTUML_PROCESS_ROUTING_KEY = "plantuml.process"

NB_PROCESS_ROUTING_KEY = "notebook.process"

IMG_RESULT_ROUTING_KEY = "img.result"
NB_RESULT_ROUTING_KEY = "notebook.result"
