import logging

log_level = logging.WARNING
logging.basicConfig(level=log_level)
