"""SQLite-based PlantUML converter worker implementation.

This module provides a worker that polls the SQLite job queue for PlantUML
conversion jobs instead of using RabbitMQ.

Workers can operate in two modes:
1. Direct SQLite mode (default): Workers communicate with the database directly
2. REST API mode: Workers communicate via HTTP API (for Docker containers)

The mode is determined by the presence of CLM_API_URL environment variable.
"""

import logging
import os
from pathlib import Path

from clm.infrastructure.database.job_queue import Job
from clm.infrastructure.database.schema import init_database
from clm.infrastructure.workers.worker_base import Worker

# Configuration
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()
DB_PATH = Path(os.environ.get("DB_PATH", "/db/jobs.db"))
API_URL = os.environ.get("CLM_API_URL")  # If set, use REST API mode

# Logging setup
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s - plantuml-worker - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


class PlantUmlWorker(Worker):
    """Worker that processes PlantUML conversion jobs from SQLite queue or REST API."""

    def __init__(self, worker_id: int, db_path: Path | None = None, api_url: str | None = None):
        """Initialize PlantUML worker.

        Args:
            worker_id: Worker ID from database
            db_path: Path to SQLite database (required for direct mode)
            api_url: URL of the Worker API (for Docker mode)
        """
        super().__init__(worker_id, "plantuml", db_path=db_path, api_url=api_url)
        mode = "API" if api_url else "SQLite"
        logger.info(f"PlantUmlWorker {worker_id} initialized in {mode} mode")

    def process_job(self, job: Job):
        """Process a PlantUML conversion job.

        Args:
            job: Job to process
        """
        # Use persistent event loop instead of asyncio.run()
        loop = self._get_or_create_loop()
        try:
            loop.run_until_complete(self._process_job_async(job))
        except Exception as e:
            logger.error(
                f"Worker {self.worker_id} error in event loop for job {job.id}: {e}", exc_info=True
            )
            raise

    async def _process_job_async(self, job: Job):
        """Async implementation of job processing.

        Args:
            job: Job to process
        """
        try:
            # Check if job was cancelled before starting
            if self.job_queue.is_job_cancelled(job.id):
                logger.info(f"Job {job.id} was cancelled before processing, skipping")
                return

            # Extract payload data
            payload_data = job.payload
            logger.debug(f"Processing PlantUML job {job.id}")

            # Determine if we're in Docker mode with source mount
            host_data_dir = os.environ.get("CLM_HOST_DATA_DIR")
            host_workspace = os.environ.get("CLM_HOST_WORKSPACE")

            # Log environment state for debugging Docker mode issues
            if host_data_dir and host_workspace:
                logger.debug(
                    f"Docker source mount mode: CLM_HOST_DATA_DIR={host_data_dir}, "
                    f"CLM_HOST_WORKSPACE={host_workspace}"
                )
            else:
                logger.debug(
                    f"Legacy/direct mode: CLM_HOST_DATA_DIR={'set' if host_data_dir else 'NOT SET'}, "
                    f"CLM_HOST_WORKSPACE={'set' if host_workspace else 'NOT SET'}"
                )

            plantuml_content: str
            if host_data_dir and host_workspace:
                # Docker mode with source mount: read from filesystem
                from clm.infrastructure.workers.worker_base import (
                    convert_input_path_to_container,
                    convert_output_path_to_container,
                )

                input_path = convert_input_path_to_container(job.input_file, host_data_dir)
                logger.debug(f"Docker mode: reading from {input_path}")
                try:
                    plantuml_content = input_path.read_text(encoding="utf-8")
                except FileNotFoundError:
                    # Provide helpful error message for Docker mode
                    raise FileNotFoundError(
                        f"Input file not found in Docker container: {input_path} "
                        f"(host path: {job.input_file}). "
                        f"Verify the file exists and the Docker mount is configured correctly."
                    ) from None

                # Output path may be under workspace or data_dir (for generated images in source tree)
                output_path = convert_output_path_to_container(
                    job.output_file, host_workspace, host_data_dir
                )
                logger.debug(f"Docker mode: writing to {output_path}")
            else:
                # Direct mode or legacy Docker mode: use payload data
                plantuml_content = payload_data.get("data", "")
                if not plantuml_content:
                    # Fallback: try reading from filesystem (direct mode)
                    input_path = Path(job.input_file)
                    if input_path.exists():
                        plantuml_content = input_path.read_text(encoding="utf-8")
                    else:
                        raise FileNotFoundError(
                            f"Input file not found: {input_path} "
                            f"(Job {job.id}: no PlantUML data in payload)"
                        )
                input_path = Path(job.input_file)

                if host_workspace or host_data_dir:
                    from clm.infrastructure.workers.worker_base import (
                        convert_output_path_to_container,
                    )

                    output_path = convert_output_path_to_container(
                        job.output_file, host_workspace, host_data_dir
                    )
                else:
                    output_path = Path(job.output_file)

            logger.debug(f"Processing PlantUML: {input_path.name}")
            output_format = output_path.suffix.lstrip(".")
            if not output_format:
                output_format = "png"  # default

            logger.info(f"Converting {input_path} to {output_format}")

            # Import the conversion function
            from tempfile import TemporaryDirectory

            from clm.workers.plantuml.plantuml_converter import (
                convert_plantuml,
                get_plantuml_output_name,
            )

            # Process in temporary directory
            with TemporaryDirectory() as tmp_dir:
                tmp_input = Path(tmp_dir) / "plantuml.pu"
                output_name = get_plantuml_output_name(plantuml_content, default="plantuml")
                tmp_output = (Path(tmp_dir) / output_name).with_suffix(f".{output_format}")

                # Write input
                tmp_input.write_text(plantuml_content, encoding="utf-8")

                # Convert
                logger.debug(f"Converting {input_path.name} to {output_format}")
                await convert_plantuml(tmp_input, f"job-{job.id}", output_format=output_format)
                logger.debug(f"Conversion complete for {input_path.name}")

                # Read result
                if not tmp_output.exists():
                    # List available files for debugging
                    available = list(Path(tmp_dir).iterdir())
                    logger.error(
                        f"Expected output {tmp_output} not found. Available files: {available}"
                    )
                    raise FileNotFoundError(
                        f"Conversion did not produce expected output: {tmp_output}"
                    )

                result_bytes = tmp_output.read_bytes()

            if len(result_bytes) == 0:
                raise ValueError("Conversion produced empty result")

            # Write output file
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "wb") as f:
                f.write(result_bytes)

            logger.info(f"PlantUML image written to {output_path} ({len(result_bytes)} bytes)")

            # Add to cache (works for both SQLite and API modes)
            self.job_queue.add_to_cache(
                job.output_file,
                job.content_hash,
                {"format": output_format, "size": len(result_bytes)},
            )
            logger.debug(f"Added result to cache for {job.output_file}")

        except Exception as e:
            logger.error(f"Error processing PlantUML job {job.id}: {e}", exc_info=True)
            raise


def main():
    """Main entry point for PlantUML worker."""
    # Determine mode based on environment
    if API_URL:
        logger.info(f"Starting PlantUML worker in API mode (URL: {API_URL})")

        # Get pre-assigned worker ID or register via API
        # This handles both pre-registration (CLM_WORKER_ID set) and legacy registration
        worker_id = Worker.get_or_register_worker(
            db_path=None, api_url=API_URL, worker_type="plantuml"
        )

        # Create worker in API mode (no database access)
        worker = PlantUmlWorker(worker_id, api_url=API_URL)
    else:
        logger.info("Starting PlantUML worker in SQLite mode")

        # Ensure database exists
        if not DB_PATH.exists():
            logger.info(f"Initializing database at {DB_PATH}")
            init_database(DB_PATH)

        # Get pre-assigned worker ID or register with retry logic
        # This handles both pre-registration (CLM_WORKER_ID set) and legacy registration
        worker_id = Worker.get_or_register_worker(
            db_path=DB_PATH, api_url=None, worker_type="plantuml"
        )

        # Create and run worker
        worker = PlantUmlWorker(worker_id, db_path=DB_PATH)

    try:
        worker.run()
    except KeyboardInterrupt:
        logger.info("Received interrupt, shutting down")
        worker.stop()
    except Exception as e:
        logger.error(f"Worker crashed: {e}", exc_info=True)
        raise
    finally:
        # Clean up event loop and other resources
        worker.cleanup()
        logger.info("Worker cleanup completed")


if __name__ == "__main__":
    main()
