import logging
import re
from typing import TypeAlias, cast

from nbformat import NotebookNode

Cell: TypeAlias = NotebookNode


def get_cell_type(cell: Cell) -> str:
    """Return the type of `cell`."""
    return cast(str, cell["cell_type"])


def is_code_cell(cell):
    """Returns whether a cell is a code cell."""
    return get_cell_type(cell) == "code"


def is_markdown_cell(cell):
    """Returns whether a cell is a code cell."""
    return get_cell_type(cell) == "markdown"


def get_tags(cell: Cell) -> list[str]:
    """Return the tags for `cell`."""
    return cast(list[str], cell["metadata"].get("tags", []))


def set_tags(cell: Cell, tags: list["str"]) -> None:
    """Set the tags for `cell`."""
    if tags:
        cell["metadata"]["tags"] = tags
    elif cell["metadata"].get("tags") is not None:
        del cell["metadata"]["tags"]


def has_tag(cell: Cell, tag: str) -> bool:
    """Returns whether a cell has a specific tag."""

    return tag in get_tags(cell)


def get_cell_language(cell: Cell) -> str:
    """Return the language code for a cell.

    An empty language code means the cell has no specified language and should therefore
    be included in all language outputs."""

    return cast(str, cell["metadata"].get("lang", ""))


# Tags that control the behavior of this cell in a slideshow
_SLIDE_TAGS = {"slide", "subslide", "notes"}
# Tags that prevent this cell from being publicly visible
_PRIVATE_TAGS = {"notes", "private"}
# Tags that may appear in any kind of cell
_EXPECTED_GENERIC_TAGS = _SLIDE_TAGS | _PRIVATE_TAGS | {"alt", "del"}
# Tags that may appear in code cells (in addition to generic tags)
_EXPECTED_CODE_TAGS = {"keep", "start"} | _EXPECTED_GENERIC_TAGS
# Tags that may appear in markdown cells (in addition to generic tags)
_EXPECTED_MARKDOWN_TAGS = {"notes", "answer", "nodataurl"} | _EXPECTED_GENERIC_TAGS


def is_deleted_cell(cell: Cell):
    """Return whether a cell has been deleted."""
    return "del" in get_tags(cell)


def is_private_cell(cell: Cell):
    """Return whether a cell is only visible in private documents."""
    return bool(_PRIVATE_TAGS.intersection(get_tags(cell)))


def is_public_cell(cell: Cell):
    """Return whether a cell is visible in public documents."""
    return not is_private_cell(cell)


def is_starting_cell(cell: Cell):
    """Return whether a cell is a starting point for completions.

    Starting points should be completely removed from completed notebooks, but they
    cells should be included in codealongs."""
    return "start" in get_tags(cell)


def is_alternate_solution(cell: Cell):
    """Return whether a cell is an alternate solution.

    Alternate solutions should be present in completed notebooks, but their cells should
    be completely removed from codealongs (not included as empty cells)."""
    return "alt" in get_tags(cell)


def is_answer_cell(cell: Cell):
    """Return whether a cell is an answer to a question.

    Answers should be present in completed notebooks, but their cells should
    be empty in codealongs.

    - Code cells are answers unless they have the `keep` tag.
    - Markdown cells are only answers if they have the `answer` tag."""

    if is_code_cell(cell):
        return not {"keep", "start"}.intersection(get_tags(cell))
    else:
        return "answer" in get_tags(cell)


def get_slide_tag(cell: Cell) -> str | None:
    """Return the slide tag of cell or `None` if it doesn't have one.

    Note: If the cell has multiple slide tags, this logs a warning and
    returns one arbitrarily. Use get_conflicting_slide_tags() to check
    for this condition and report it properly.
    """
    tags = get_tags(cell)
    slide_tags = _SLIDE_TAGS.intersection(tags)
    if slide_tags:
        if len(slide_tags) > 1:
            logging.warning(f"Found more than one slide tag: {slide_tags}. Picking one at random.")
        return slide_tags.pop()
    else:
        return None


def is_cell_included_for_language(cell: Cell, lang: str) -> bool:
    """Return whether a cell should be retained for a particular language.

    Cells without language metadata should be retained for all languages, cells with
    language metadata should obviously only be included in their language."""

    cell_lang = get_cell_language(cell)
    if not cell_lang or cell_lang == lang:
        return True
    else:
        # logging.debug(
        #     f"Skipping cell '{cell.source[:20]}' with language {cell_lang!r} "
        #     "for language {lang!r}."
        # )
        return False


def get_invalid_code_tags(tags: list[str]) -> list[str]:
    """Return list of invalid tags for a code cell.

    Args:
        tags: List of tags from the cell

    Returns:
        List of tags that are not valid for code cells
    """
    return [tag for tag in tags if tag not in _EXPECTED_CODE_TAGS]


def get_invalid_markdown_tags(tags: list[str]) -> list[str]:
    """Return list of invalid tags for a markdown cell.

    Args:
        tags: List of tags from the cell

    Returns:
        List of tags that are not valid for markdown cells
    """
    return [tag for tag in tags if tag not in _EXPECTED_MARKDOWN_TAGS]


def get_conflicting_slide_tags(tags: list[str]) -> list[str] | None:
    """Check if tags contain multiple conflicting slide tags.

    Args:
        tags: List of tags from the cell

    Returns:
        List of conflicting slide tags if there are multiple, None otherwise
    """
    slide_tags = list(_SLIDE_TAGS.intersection(tags))
    if len(slide_tags) > 1:
        return slide_tags
    return None


def warn_on_invalid_code_tags(tags: list[str]) -> None:
    """Log warnings for invalid code cell tags.

    This function is kept for backward compatibility. Consider using
    get_invalid_code_tags() to collect warnings for proper reporting.
    """
    for tag in get_invalid_code_tags(tags):
        logging.warning(f"Unknown tag for code cell: {tag!r}.")


def warn_on_invalid_markdown_tags(tags: list[str]) -> None:
    """Log warnings for invalid markdown cell tags.

    This function is kept for backward compatibility. Consider using
    get_invalid_markdown_tags() to collect warnings for proper reporting.
    """
    for tag in get_invalid_markdown_tags(tags):
        logging.warning(f"Unknown tag for markdown cell: {tag!r}.")


_PARENS_TO_REPLACE = "{}[]"
_REPLACEMENT_PARENS = "()" * (len(_PARENS_TO_REPLACE) // 2)
_CHARS_TO_REPLACE = r"/\$#%&<>*=^€|"
_REPLACEMENT_CHARS = "_" * len(_CHARS_TO_REPLACE)
_CHARS_TO_DELETE = r""";!?"'`.:"""
_STRING_TRANSLATION_TABLE = str.maketrans(
    _PARENS_TO_REPLACE + _CHARS_TO_REPLACE,
    _REPLACEMENT_PARENS + _REPLACEMENT_CHARS,
    _CHARS_TO_DELETE,
)

TITLE_REGEX = re.compile(r"{{\s*header\s*\(\s*[\"'](.*)[\"']\s*,\s*[\"'](.*)[\"']\s*\)\s*}}")
TITLE_LINE1_REGEX = re.compile(r"{{\s*header\s*\(\s*[\"'](.*)[\"'],\s*\n")
TITLE_LINE2_REGEX = re.compile(r"[#/*]*\s*[\"'](.*)[\"']\)\s*}}\s*")


def find_notebook_titles(text: str, default: str) -> dict[str, str]:
    """Find the titles from the source text of a notebook."""
    match = TITLE_REGEX.search(text)
    if match:
        return {
            "en": sanitize_file_name(match[2]),
            "de": sanitize_file_name(match[1]),
        }
    else:
        match1 = TITLE_LINE1_REGEX.search(text)
        if match1:
            start_pos = match1.end()
            match2 = TITLE_LINE2_REGEX.match(text, start_pos)
            if match2:
                return {
                    "en": sanitize_file_name(match2[1]),
                    "de": sanitize_file_name(match1[1]),
                }
    return {"en": default, "de": default}


def sanitize_file_name(text: str):
    sanitized_text = text.strip().translate(_STRING_TRANSLATION_TABLE)
    return sanitized_text
