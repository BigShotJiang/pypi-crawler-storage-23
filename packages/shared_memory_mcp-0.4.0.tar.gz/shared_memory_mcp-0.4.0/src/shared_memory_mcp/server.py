# -*- coding: utf-8 -*-
"""
共享记忆 MCP Server
跨 IDE 共享记忆，支持 Kiro / Cursor / Windsurf / Trae 等多终端
"""

from typing import Optional
from mcp.server.fastmcp import FastMCP

from .database import get_connection

mcp = FastMCP(
    name="shared-memory",
    instructions="跨 IDE 共享记忆服务。Agent 自动调用写入架构决策、里程碑、重要结论等，会话开始时自动读取。",
)

_conn = None


def _get_conn():
    global _conn
    if _conn is None:
        _conn = get_connection()
    return _conn


@mcp.tool()
def memory_write(
    project: str,
    type: str,
    summary: str,
    detail: str,
    tags: Optional[str] = None,
) -> dict:
    """写入一条共享记忆。
    type 可选值: decision(决策), milestone(里程碑), conclusion(结论), context(上下文), issue(问题)
    tags: 可选，逗号分隔的标签"""
    from .database import memory_write as db_write

    mid = db_write(_get_conn(), project, type, summary, detail, tags or "")
    return {"memory_id": mid, "status": "ok"}


@mcp.tool()
def memory_read(
    project: str,
    type: Optional[str] = None,
    query: Optional[str] = None,
    limit: int = 20,
    detail: bool = False,
    hours: Optional[int] = None,
    query_mode: Optional[str] = "or",
) -> dict:
    """读取共享记忆。默认只返回摘要(省token)，detail=true返回详情。
    query: FTS5全文搜索关键词。type: 按类型过滤。hours: 只返回最近N小时内的记忆。
    query_mode: 多关键词连接方式，'or'(默认) 或 'and'。Agent 根据用户语义自行判断选择。"""
    from .database import memory_read as db_read

    rows = db_read(_get_conn(), project, type, query, limit, detail, hours, query_mode or "or")
    if not rows:
        return {"count": 0, "memories": []}
    if not detail:
        lines = []
        for r in rows:
            tag_str = f" #{r['tags']}" if r.get("tags") else ""
            lines.append(f"[{r['id']}] {r['type']} | {r['summary']}{tag_str} | {r['created_at']}")
        return {"count": len(lines), "memories": lines}
    return {"count": len(rows), "memories": rows}


@mcp.tool()
def memory_list(
    project: str,
    type: Optional[str] = None,
    limit: int = 50,
    hours: Optional[int] = None,
) -> str:
    """极简记忆索引，每条一行，最省token。适合快速浏览项目记忆全貌。
    hours: 只返回最近N小时内的记忆。"""
    from .database import memory_list as db_list

    rows, total = db_list(_get_conn(), project, type, limit, hours)
    if not rows:
        return "No memories found."
    lines = [f"[{r['id']}] {r['type']} | {r['summary']} | {r['created_at']}" for r in rows]
    if total > limit:
        lines.append(f"... ({total} total)")
    return "\n".join(lines)


@mcp.tool()
def memory_delete(
    project: str,
    memory_id: int,
) -> dict:
    """删除一条过时或错误的记忆。"""
    from .database import memory_delete as db_delete

    ok = db_delete(_get_conn(), project, memory_id)
    if ok:
        return {"status": "ok", "deleted_id": memory_id}
    return {"status": "not_found"}


def main():
    """入口函数，供 uvx / pip install 后的命令行调用"""
    mcp.run()


if __name__ == "__main__":
    main()
