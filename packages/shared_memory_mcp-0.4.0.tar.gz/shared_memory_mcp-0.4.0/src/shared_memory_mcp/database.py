# -*- coding: utf-8 -*-
"""
共享记忆数据库层
使用 SQLite + FTS5 实现持久化存储和全文搜索
"""

import sqlite3
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional


# 数据库默认存储路径
DB_DIR = Path.home() / ".shared-memory-mcp"
DB_PATH = DB_DIR / "memories.db"


def get_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """获取数据库连接，自动初始化表结构"""
    path = db_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    _init_tables(conn)
    return conn


def _init_tables(conn: sqlite3.Connection) -> None:
    """初始化表结构和 FTS5 索引（使用 trigram 分词器支持中文搜索）"""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project TEXT NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('decision','milestone','conclusion','context','issue')),
            summary TEXT NOT NULL,
            detail TEXT NOT NULL,
            tags TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_memories_project ON memories(project);
        CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(project, type);
        CREATE INDEX IF NOT EXISTS idx_memories_time ON memories(project, created_at DESC);
    """)

    # 检查是否需要迁移：旧表用 unicode61，新表需要 trigram
    _ensure_trigram_fts(conn)
    conn.commit()


def _ensure_trigram_fts(conn: sqlite3.Connection) -> None:
    """确保 FTS5 表使用 trigram 分词器，如果是旧的 unicode61 则迁移"""
    # 检查 FTS 表是否存在
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='memories_fts'"
    ).fetchone()

    if row is None:
        # 表不存在，直接创建 trigram 版本
        conn.execute("""
            CREATE VIRTUAL TABLE memories_fts
            USING fts5(summary, detail, tags, content=memories, content_rowid=id, tokenize='trigram')
        """)
        # 回填已有数据
        conn.execute("""
            INSERT INTO memories_fts(rowid, summary, detail, tags)
            SELECT id, summary, detail, tags FROM memories
        """)
        return

    # 表已存在，检查是否已经是 trigram
    create_sql = row[0] or ""
    if "trigram" in create_sql.lower():
        return  # 已经是 trigram，无需迁移

    # 旧表（unicode61），需要 drop 重建
    conn.execute("DROP TABLE IF EXISTS memories_fts")
    conn.execute("""
        CREATE VIRTUAL TABLE memories_fts
        USING fts5(summary, detail, tags, content=memories, content_rowid=id, tokenize='trigram')
    """)
    # 回填所有已有数据到新索引
    conn.execute("""
        INSERT INTO memories_fts(rowid, summary, detail, tags)
        SELECT id, summary, detail, tags FROM memories
    """)


def memory_write(
    conn: sqlite3.Connection,
    project: str,
    type_: str,
    summary: str,
    detail: str,
    tags: str = "",
) -> int:
    """写入一条记忆，返回 memory_id"""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    cursor = conn.execute(
        "INSERT INTO memories (project, type, summary, detail, tags, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (project, type_, summary, detail, tags, now),
    )
    row_id = cursor.lastrowid
    conn.execute(
        "INSERT INTO memories_fts(rowid, summary, detail, tags) VALUES (?, ?, ?, ?)",
        (row_id, summary, detail, tags),
    )
    conn.commit()
    return row_id


def memory_read(
    conn: sqlite3.Connection,
    project: str,
    type_: Optional[str] = None,
    query: Optional[str] = None,
    limit: int = 20,
    include_detail: bool = False,
    hours: Optional[int] = None,
    query_mode: str = "or",
) -> list[dict]:
    """读取记忆，支持类型过滤、FTS5 全文搜索、时间范围过滤和多关键词搜索。
    query_mode: 多关键词连接方式，'or'(默认) 或 'and'。单关键词时无影响。"""
    time_filter = ""
    time_params: list = []
    if hours is not None and hours > 0:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        time_filter = "AND {prefix}created_at >= ?"
        time_params = [cutoff]

    if query:
        detail_col = ", m.detail" if include_detail else ""
        type_filter = "AND m.type = ?" if type_ else ""
        tf = time_filter.replace("{prefix}", "m.") if time_filter else ""

        # 拆分多关键词
        keywords = query.strip().split()
        connector = " AND " if query_mode == "and" else " OR "

        # trigram 分词器要求每个搜索词至少3字符，短于3字符的词会被静默忽略
        # 如果存在短关键词，直接跳过 FTS5 走 LIKE，避免 AND/OR 语义失真
        has_short_kw = any(len(kw) < 3 for kw in keywords)
        rows = []

        if not has_short_kw:
            # 所有关键词 >=3 字符，走 FTS5 trigram 全文搜索
            fts_match = connector.join(f'"{kw}"' for kw in keywords)
            fts_sql = """
                SELECT m.id, m.type, m.summary, m.tags, m.created_at
                {detail_col}
                FROM memories m
                JOIN memories_fts f ON m.id = f.rowid
                WHERE m.project = ? AND memories_fts MATCH ?
                {type_filter}
                {time_filter}
                ORDER BY rank
                LIMIT ?
            """.replace("{detail_col}", detail_col).replace("{type_filter}", type_filter).replace("{time_filter}", tf)
            params = [project, fts_match] + ([type_] if type_ else []) + time_params + [limit]
            rows = conn.execute(fts_sql, params).fetchall()

        # FTS5 无结果或有短关键词时，fallback 到 LIKE 模糊匹配
        if not rows:
            # 每个关键词生成一组 LIKE 条件，多组之间用 AND/OR 连接
            like_groups = []
            like_params_list: list = [project]
            for kw in keywords:
                pattern = f"%{kw}%"
                like_groups.append("(m.summary LIKE ? OR m.detail LIKE ? OR m.tags LIKE ?)")
                like_params_list.extend([pattern, pattern, pattern])

            like_where = connector.join(like_groups)
            like_sql = """
                SELECT m.id, m.type, m.summary, m.tags, m.created_at
                {detail_col}
                FROM memories m
                WHERE m.project = ?
                  AND ({like_where})
                {type_filter}
                {time_filter}
                ORDER BY m.created_at DESC
                LIMIT ?
            """.replace("{detail_col}", detail_col).replace("{type_filter}", type_filter).replace("{time_filter}", tf).replace("{like_where}", like_where)
            params = like_params_list + ([type_] if type_ else []) + time_params + [limit]
            rows = conn.execute(like_sql, params).fetchall()

        return [dict(r) for r in rows]

    # 无查询关键词，按时间倒序返回
    sql = """
        SELECT id, type, summary, tags, created_at
        {detail_col}
        FROM memories
        WHERE project = ?
        {type_filter}
        {time_filter}
        ORDER BY created_at DESC
        LIMIT ?
    """
    detail_col = ", detail" if include_detail else ""
    type_filter = "AND type = ?" if type_ else ""
    tf = time_filter.replace("{prefix}", "") if time_filter else ""
    sql = sql.replace("{detail_col}", detail_col).replace("{type_filter}", type_filter).replace("{time_filter}", tf)
    params = [project] + ([type_] if type_ else []) + time_params + [limit]

    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def memory_list(
    conn: sqlite3.Connection,
    project: str,
    type_: Optional[str] = None,
    limit: int = 50,
    hours: Optional[int] = None,
) -> tuple[list[dict], int]:
    """极简索引：返回 id, type, summary, created_at。同时返回总数"""
    time_filter = ""
    time_params: list = []
    if hours is not None and hours > 0:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        time_filter = "AND created_at >= ?"
        time_params = [cutoff]

    count_sql = "SELECT COUNT(*) FROM memories WHERE project = ?"
    count_params: list = [project]
    if type_:
        count_sql += " AND type = ?"
        count_params.append(type_)
    if time_filter:
        count_sql += f" {time_filter}"
        count_params.extend(time_params)
    total = conn.execute(count_sql, count_params).fetchone()[0]

    sql = "SELECT id, type, summary, created_at FROM memories WHERE project = ?"
    params: list = [project]
    if type_:
        sql += " AND type = ?"
        params.append(type_)
    if time_filter:
        sql += f" {time_filter}"
        params.extend(time_params)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows], total


def memory_delete(
    conn: sqlite3.Connection,
    project: str,
    memory_id: int,
) -> bool:
    """删除指定记忆，返回是否成功"""
    row = conn.execute(
        "SELECT id FROM memories WHERE id = ? AND project = ?",
        (memory_id, project),
    ).fetchone()
    if not row:
        return False

    old = conn.execute(
        "SELECT summary, detail, tags FROM memories WHERE id = ?", (memory_id,)
    ).fetchone()
    if old:
        conn.execute(
            "INSERT INTO memories_fts(memories_fts, rowid, summary, detail, tags) VALUES('delete', ?, ?, ?, ?)",
            (memory_id, old["summary"], old["detail"], old["tags"]),
        )
    conn.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
    conn.commit()
    return True
