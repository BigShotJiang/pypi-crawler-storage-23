"""Tests for embedding env var parser on gateway startup."""

from __future__ import annotations

from sagellm_gateway.server import parse_embedding_engine_env_vars


def test_parse_single_embedding_env_config() -> None:
    env = {
        "SAGELLM_EMBEDDING_ENGINE_ID": "embed-cpu-0",
        "SAGELLM_EMBEDDING_MODEL": "sentence-transformers/all-MiniLM-L6-v2",
        "SAGELLM_EMBEDDING_HOST": "localhost",
        "SAGELLM_EMBEDDING_PORT": "8890",
    }

    configs = parse_embedding_engine_env_vars(env)
    assert len(configs) == 1
    assert configs[0]["engine_id"] == "embed-cpu-0"
    assert configs[0]["port"] == 8890


def test_parse_multiple_embedding_env_configs() -> None:
    env = {
        "SAGELLM_EMBEDDING_ENGINE_ID_1": "embed-1",
        "SAGELLM_EMBEDDING_MODEL_1": "model-1",
        "SAGELLM_EMBEDDING_HOST_1": "host-1",
        "SAGELLM_EMBEDDING_PORT_1": "8891",
        "SAGELLM_EMBEDDING_ENGINE_ID_2": "embed-2",
        "SAGELLM_EMBEDDING_MODEL_2": "model-2",
        "SAGELLM_EMBEDDING_HOST_2": "host-2",
        "SAGELLM_EMBEDDING_PORT_2": "8892",
    }

    configs = parse_embedding_engine_env_vars(env)
    assert len(configs) == 2
    assert configs[0]["engine_id"] == "embed-1"
    assert configs[1]["engine_id"] == "embed-2"


def test_skip_incomplete_or_invalid_embedding_env_configs() -> None:
    env = {
        "SAGELLM_EMBEDDING_ENGINE_ID": "embed-cpu-0",
        "SAGELLM_EMBEDDING_MODEL": "model-0",
        "SAGELLM_EMBEDDING_HOST": "localhost",
        "SAGELLM_EMBEDDING_PORT": "invalid",
        "SAGELLM_EMBEDDING_ENGINE_ID_1": "embed-1",
        "SAGELLM_EMBEDDING_MODEL_1": "model-1",
        "SAGELLM_EMBEDDING_HOST_1": "localhost",
    }

    configs = parse_embedding_engine_env_vars(env)
    assert configs == []
