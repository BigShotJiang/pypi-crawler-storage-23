from __future__ import annotations

from sagellm_gateway.studio_routes import STUDIO_ROUTES_AVAILABLE, router


def _route_paths() -> set[str]:
    return {route.path for route in router.routes if getattr(route, "path", None)}


def test_studio_routes_availability_flag_matches_route_shape() -> None:
    paths = _route_paths()
    if STUDIO_ROUTES_AVAILABLE:
        assert "/api/llm/status" in paths
        assert "/api/chat/sessions" in paths
        assert "/api/operators" in paths
        assert "/api/config/v1/endpoints" in paths
        assert "/api/auth/me" in paths
    else:
        assert "/api/llm/status" not in paths
        assert "/api/chat/sessions" not in paths


def test_studio_health_route_present_when_available() -> None:
    paths = _route_paths()
    if STUDIO_ROUTES_AVAILABLE:
        assert "/api/health" in paths
