"""Allow running as `python -m octorules`."""

from octorules.cli import main

main()
