"""Octorules — Manage Cloudflare Rules as IaC."""

from importlib.metadata import version

__version__ = version("octorules")
