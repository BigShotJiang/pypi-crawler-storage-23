"""Top-level package for k2eg library."""
from .dml import dml, OperationTimeout, OperationError  # noqa: F401