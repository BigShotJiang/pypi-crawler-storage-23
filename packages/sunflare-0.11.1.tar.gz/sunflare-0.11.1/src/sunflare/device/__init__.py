from ._base import Device, PDevice

__all__ = ["Device", "PDevice"]
