# cli-tool

A terminal task manager CLI — add, update, and list tasks with priorities.

## Install (for everyone)

After the package is published to PyPI, anyone can install it with:

```bash
pip install smart-task-cli
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv tool install smart-task-cli
```

Then run the `cli-tool` command from anywhere.

## Usage

Tasks are stored in a `tasks.json` file in the current directory.

```bash
# Add a task (default priority: medium)
cli-tool add "Buy groceries"
cli-tool add "Fix bug" --priority high

# List all tasks
cli-tool list

# Update a task
cli-tool update 1 --title "Buy groceries and milk"
cli-tool update 1 --completed true
cli-tool update 1 --priority low
```

## Publish to PyPI (for maintainers)

So that **anyone** can install with `pip install smart-task-cli`, publish the package to [PyPI](https://pypi.org/).

### 1. Create a PyPI account

- Sign up at [pypi.org](https://pypi.org/account/register/).
- (Optional) Create an API token at [pypi.org/manage/account/token/](https://pypi.org/manage/account/token/) for uploads.

### 2. Install publish tools

```bash
uv add --dev twine
```

### 3. Build the package

```bash
uv build
```

This creates `dist/smart_task_cli-0.1.0.tar.gz` and a wheel in `dist/`.

### 4. Upload to PyPI

**Using twine (recommended):**

```bash
uv run twine upload dist/*
```

When prompted, use your PyPI username and **API token** as the password (or set `TWINE_USERNAME` and `TWINE_PASSWORD`).

**Using uv:**

```bash
uv publish
```

(Configure PyPI token via `UV_PUBLISH_TOKEN` or keyring.)

### 5. After publishing

- The package will be live at `https://pypi.org/project/smart-task-cli/`.
- Anyone can run: `pip install smart-task-cli` and then `cli-tool add "My task"`, etc.

### Notes

- **Name on PyPI**: The project name is `smart-task-cli` (the `cli-tool` name was too similar to an existing project).
- **Version**: Bump `version` in `pyproject.toml` for each release, then run `uv build` and upload again.
- **Authors**: Update `authors` in `pyproject.toml` with your name and email before publishing.
