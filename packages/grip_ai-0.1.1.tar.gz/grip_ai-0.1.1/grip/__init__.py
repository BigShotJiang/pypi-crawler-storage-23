"""grip - Async-first agentic AI platform."""

__version__ = "0.1.1"
