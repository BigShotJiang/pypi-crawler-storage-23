"""Publish Python packages to CodeArtifact and optionally PyPI.

Builds a wheel from the current directory's pyproject.toml and uploads it
to the Dayhoff CodeArtifact repository. For packages in PYPI_TARGETS,
also publishes to public PyPI by default.
"""

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

# --- CodeArtifact configuration ---
CA_DOMAIN = "dayhoff"
CA_DOMAIN_OWNER = "074735440724"
CA_REPOSITORY = "pypi"
CA_REGION = "us-east-1"

# --- Color constants ---
BLUE = "\033[94m"
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
RESET = "\033[0m"


def _get_codeartifact_token(profile: str | None = None) -> str:
    """Get a CodeArtifact authorization token via boto3.

    Args:
        profile: AWS profile to use. If None, uses current session.

    Returns:
        The authorization token string.

    Raises:
        SystemExit: If token retrieval fails.
    """
    import boto3

    try:
        session = boto3.Session(profile_name=profile) if profile else boto3.Session()
        client = session.client("codeartifact", region_name=CA_REGION)
        response = client.get_authorization_token(
            domain=CA_DOMAIN,
            domainOwner=CA_DOMAIN_OWNER,
        )
        return response["authorizationToken"]
    except Exception as e:
        print(f"{RED}Failed to get CodeArtifact token: {e}{RESET}", file=sys.stderr)
        print(
            f"{YELLOW}Hint: run 'dh aws login' first, or pass --profile{RESET}",
            file=sys.stderr,
        )
        raise SystemExit(1)


def _get_publish_url() -> str:
    """Return the CodeArtifact upload endpoint URL."""
    return (
        f"https://{CA_DOMAIN}-{CA_DOMAIN_OWNER}.d.codeartifact."
        f"{CA_REGION}.amazonaws.com/pypi/{CA_REPOSITORY}/"
    )


def _get_current_version(pyproject_path: str = "pyproject.toml") -> str:
    """Read the version from pyproject.toml."""
    with open(pyproject_path, "r") as f:
        content = f.read()
    match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
    if not match:
        raise ValueError(f"Could not find version in {pyproject_path}")
    return match.group(1)


def _bump_version(current: str, bump_part: str) -> str:
    """Bump a semver version string."""
    try:
        major, minor, patch = map(int, current.split("."))
    except ValueError:
        raise ValueError(f"Cannot parse version '{current}'. Expected X.Y.Z")

    if bump_part == "major":
        return f"{major + 1}.0.0"
    elif bump_part == "minor":
        return f"{major}.{minor + 1}.0"
    else:
        return f"{major}.{minor}.{patch + 1}"


def _write_version(pyproject_path: str, old_version: str, new_version: str) -> None:
    """Replace version string in pyproject.toml."""
    with open(pyproject_path, "r") as f:
        content = f.read()
    pattern = re.compile(f'^version\\s*=\\s*"{re.escape(old_version)}"', re.MULTILINE)
    new_content, count = pattern.subn(f'version = "{new_version}"', content)
    if count == 0:
        raise ValueError(f"Could not find version {old_version} in {pyproject_path}")
    with open(pyproject_path, "w") as f:
        f.write(new_content)


PACKAGE_DIRS = {
    "cli": "packages/dh-cli",
    "batch": "packages/dh-batch",
    "embedders": "packages/dh-embedders",
    "chem": "packages/dh-chem",
}

# Packages that are also published to public PyPI by default.
PYPI_TARGETS = {"cli"}


def _find_repo_root() -> Path:
    """Walk up from cwd to find the dayhoff-tools repo root (has packages/ dir)."""
    current = Path.cwd().resolve()
    while current != current.parent:
        if (current / "packages" / "dh-cli").is_dir():
            return current
        current = current.parent
    # Fallback: try cwd directly
    if (Path.cwd() / "packages" / "dh-cli").is_dir():
        return Path.cwd()
    raise FileNotFoundError(
        "Cannot find dayhoff-tools repo root. "
        "Run this from inside the dayhoff-tools directory."
    )


def _publish_to_pypi(uv_path: str) -> bool:
    """Publish already-built wheel to PyPI.

    Expects the wheel to already exist in dist/ from a prior ``uv build``.

    Args:
        uv_path: Absolute path to the ``uv`` binary.

    Returns:
        True if publish succeeded, False otherwise.
    """
    token = os.environ.get("UV_PUBLISH_TOKEN")
    if not token:
        print(
            f"{RED}UV_PUBLISH_TOKEN is not set — cannot publish to PyPI.{RESET}",
            file=sys.stderr,
        )
        return False

    print(f"Publishing to {BLUE}PyPI{RESET}...")
    try:
        subprocess.run(
            [uv_path, "publish", "--token", token],
            check=True,
        )
        print(f"{GREEN}Published to PyPI.{RESET}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"{RED}PyPI publish failed: {e}{RESET}", file=sys.stderr)
        return False


def publish_to_codeartifact(
    target: str = "cli",
    bump_part: str = "patch",
    profile: str | None = None,
    dry_run: bool = False,
    skip_pypi: bool = False,
) -> None:
    """Build and publish a package to CodeArtifact (and optionally PyPI).

    For targets in PYPI_TARGETS, also publishes to public PyPI unless
    *skip_pypi* is True.

    Args:
        target: Which package to publish ('cli', 'batch', 'embedders', 'chem').
        bump_part: Version part to bump ('major', 'minor', 'patch').
        profile: AWS profile for auth token. Uses current session if None.
        dry_run: Build but don't upload.
        skip_pypi: If True, skip the PyPI publish even for PYPI_TARGETS.
    """
    if target not in PACKAGE_DIRS:
        valid = ", ".join(f"'{k}'" for k in PACKAGE_DIRS)
        print(f"{RED}Unknown target '{target}'. Use {valid}.{RESET}")
        raise SystemExit(1)

    repo_root = _find_repo_root()
    package_dir = repo_root / PACKAGE_DIRS[target]
    print(f"Publishing {BLUE}dh-{target}{RESET} from {package_dir}")
    os.chdir(package_dir)

    pyproject_path = "pyproject.toml"
    if not Path(pyproject_path).exists():
        print(f"{RED}No pyproject.toml found in {package_dir}.{RESET}")
        raise SystemExit(1)

    uv_path = shutil.which("uv")
    if not uv_path:
        print(f"{RED}uv not found. Install it or run via 'pixi run'.{RESET}")
        raise SystemExit(1)

    # Determine if this target should also go to PyPI
    wants_pypi = target in PYPI_TARGETS and not skip_pypi

    # Fail fast: validate PyPI token before bumping version or publishing
    if wants_pypi and not dry_run:
        if not os.environ.get("UV_PUBLISH_TOKEN"):
            print(
                f"{RED}UV_PUBLISH_TOKEN is not set.{RESET}",
                file=sys.stderr,
            )
            print(
                f"{YELLOW}Set it to publish dh-{target} to PyPI, "
                f"or pass --no-pypi for CodeArtifact only.{RESET}",
                file=sys.stderr,
            )
            raise SystemExit(1)

    current_version = _get_current_version(pyproject_path)
    new_version = _bump_version(current_version, bump_part)
    print(f"Version: {current_version} -> {BLUE}{new_version}{RESET}")

    # Bump version in pyproject.toml
    _write_version(pyproject_path, current_version, new_version)

    try:
        # Clean dist/
        dist_dir = Path("dist")
        if dist_dir.exists():
            shutil.rmtree(dist_dir)

        # Build
        print(f"Running: {BLUE}uv build{RESET}")
        subprocess.run([uv_path, "build"], check=True)

        if dry_run:
            print(f"{YELLOW}Dry run — skipping upload.{RESET}")
            return

        # Get auth token
        print(f"Getting CodeArtifact token...")
        token = _get_codeartifact_token(profile)
        publish_url = _get_publish_url()

        # Publish (unset UV_PUBLISH_TOKEN to avoid conflict)
        env = os.environ.copy()
        env.pop("UV_PUBLISH_TOKEN", None)

        print(f"Publishing to: {BLUE}{publish_url}{RESET}")
        subprocess.run(
            [
                uv_path,
                "publish",
                "--publish-url",
                publish_url,
                "--username",
                "aws",
                "--password",
                token,
            ],
            check=True,
            env=env,
        )

        print(f"{GREEN}Published v{new_version} to CodeArtifact.{RESET}")

        # Also publish to PyPI for eligible targets
        if wants_pypi:
            ok = _publish_to_pypi(uv_path)
            if not ok:
                print(
                    f"{YELLOW}CodeArtifact publish succeeded (v{new_version}). "
                    f"PyPI publish failed.{RESET}",
                    file=sys.stderr,
                )
                print(
                    f"{YELLOW}To retry: cd {package_dir} && "
                    f"uv publish --token $UV_PUBLISH_TOKEN{RESET}",
                    file=sys.stderr,
                )
                raise SystemExit(1)

    except subprocess.CalledProcessError as e:
        print(f"{RED}Build/publish failed: {e}{RESET}", file=sys.stderr)
        # Roll back version
        try:
            _write_version(pyproject_path, new_version, current_version)
            print(f"Reverted version to {current_version}.")
        except Exception as revert_err:
            print(f"{YELLOW}Failed to revert version: {revert_err}{RESET}")
        raise SystemExit(1)
