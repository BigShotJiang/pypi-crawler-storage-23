"""
Example: Using TEI with a custom Python agent.

This is the simplest case — your agent is a plain Python function.
"""
import asyncio
from tei_loop import TEILoop


def my_summarizer(text: str) -> str:
    """Your existing agent — any function that takes input and returns output."""
    from openai import OpenAI
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-5-mini",
        messages=[
            {"role": "system", "content": "Summarize the following text concisely."},
            {"role": "user", "content": text},
        ],
    )
    return response.choices[0].message.content


async def main():
    loop = TEILoop(agent=my_summarizer, verbose=True)

    result = await loop.run("The quick brown fox jumped over the lazy dog. "
                            "It was a sunny day in the forest.")
    print(result.summary())


if __name__ == "__main__":
    asyncio.run(main())
