---
name: Feature request
about: Suggest a new tool or enhancement
title: ""
labels: enhancement
assignees: ""
---

**Is this a new tool or an enhancement to an existing one?**
New tool / Enhancement

**Describe the feature**
What Coda API endpoint or workflow should be supported?

**API reference**
Link to the relevant [Coda REST API](https://coda.io/developers/apis/v1) docs.

**Use case**
How would you use this feature?
