"""plone.pgcatalog — PostgreSQL-backed catalog for Plone."""
