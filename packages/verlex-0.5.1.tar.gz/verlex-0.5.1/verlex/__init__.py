"""
Verlex - Run your code in the cloud for the price of a coffee.

A Python SDK that lets you execute code on the cheapest available cloud
infrastructure across AWS, GCP, and Azure - all with a single function call.

Usage:
    >>> import verlex
    >>>
    >>> with verlex.GateWay(api_key="gw_your_key") as gw:
    ...     result = gw.run(my_function)
    ...     print(result)

Quick one-liner:
    >>> result = verlex.cloud(my_function, api_key="gw_your_key")
"""

__version__ = "0.4.4"
__author__ = "Verlex Team"

from verlex.client import (
    AsyncJob,
    AuthSession,
    GateWay,
    JobResult,
    auth,
    cloud,
    get_session,
    logout,
    whoami,
)
from verlex.overflow import overflow
from verlex.agent import AgentDaemon, ProcessScanner, submit_code
from verlex.errors import (
    AuthenticationError,
    ConfigurationError,
    ExecutionError,
    GPUUnavailableError,
    InsufficientCreditsError,
    InvalidAPIKeyError,
    JobFailedError,
    JobTimeoutError,
    NetworkError,
    NotAuthenticatedError,
    QuotaExceededError,
    RateLimitError,
    SerializationError,
    VerlexError,
)

__all__ = [
    # Version
    "__version__",
    "__author__",
    # Primary API
    "GateWay",
    "AsyncJob",
    "JobResult",
    "AuthSession",
    # Authentication
    "auth",
    "logout",
    "whoami",
    "get_session",
    # Quick execution
    "cloud",
    # Resource monitoring
    "overflow",
    # Agent (system-level process watching)
    "AgentDaemon",
    "ProcessScanner",
    "submit_code",
    # Error Types
    "VerlexError",
    "ExecutionError",
    "AuthenticationError",
    "NotAuthenticatedError",
    "InvalidAPIKeyError",
    "InsufficientCreditsError",
    "QuotaExceededError",
    "GPUUnavailableError",
    "JobFailedError",
    "JobTimeoutError",
    "SerializationError",
    "NetworkError",
    "RateLimitError",
    "ConfigurationError",
]
