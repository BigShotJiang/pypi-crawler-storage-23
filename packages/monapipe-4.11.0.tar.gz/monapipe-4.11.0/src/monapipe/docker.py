# SPDX-FileCopyrightText: 2024 Georg-August-Universität Göttingen
#
# SPDX-License-Identifier: CC0-1.0

import logging
import os
import shutil
import subprocess
import time

import docker
import requests

from monapipe.config import DATAVERSE, LOCAL_PATHS


def provide_docker_container(
    dockerfile_dir: str,
    dockerfile: str = "Dockerfile",
    container_port: int = 80,
    host_port: int = 16000,
    data_path_host: str = LOCAL_PATHS["data_path"],
    data_path_container: str = LOCAL_PATHS["data_path_container"],
    debug_mode: bool = False,
    sidecar_container: str = None,
    network_name: str = None,
    environment: dict = None,    
):
    """Function that builds image and container for MONAPipe API components.

    Args:
        dockerfile_dir: Dir name of Dockerfile.
        dockerfile: Name of the Dockerfile.
        container_port: Port to run the API inside the container.
        host_port: Port to expose the API to the host system.
        data_path_host: Local host path mounted into the container at data_path_container
            (local Docker setup only). Set to None for containers whose data is baked into
            the image at build time (e.g. opentapioca_entity_linker_api) — no volume mount
            will be created.
        data_path_container: Path inside the container used by resource_handler.py
            (CONTAINER=True) to access data. In local Docker setup, also the bind target
            for the data_path_host volume mount.
        debug_mode: Flag to enable debug mode.
        sidecar_container: Name of sidecar container to start (e.g., "solr").
        network_name: Name of the Docker network to connect the container to.
        environment: Environment variables to set in the container.

    """
    # Check if Docker is installed and running
    check_docker_installation()
    check_docker_running()

    client = docker.from_env()

    if sidecar_container == "opentapioca_entity_linker_api_solr":
        provide_solr_container(
            dockerfile_dir=dockerfile_dir,
            network_name=network_name or f"{os.path.basename(dockerfile_dir)}_network",
            debug_mode=debug_mode
        )

    # Check if `config.py` and `resource_handler.py` are copied to the Dockerfile directory
    base_path = os.path.join(dockerfile_dir, "app")
    for file_name in ["config.py", "resource_handler.py"]:
        file_path = os.path.join(base_path, file_name)
        if os.path.exists(file_path):
            os.remove(file_path)
        shutil.copy(
            os.path.join(os.path.dirname(__file__), file_name),
            base_path,
        )

    # Generate the tag for the Docker image
    tag = dockerfile_dir.split("/")[-1]

    # Check if the image already exists
    image_exists = False
    try:
        client.images.get(tag)
        image_exists = True
        logging.info("Image %s already exists. Skipping build.", tag)
    except docker.errors.ImageNotFound:
        logging.info("Image %s not found. Building Docker image for {tag}...", tag)

    # build the Docker image
    if not image_exists:
        image, build_logs = client.images.build(
            path=dockerfile_dir,
            dockerfile=dockerfile,
            tag=tag,
            buildargs={
                "PORT": str(container_port),
                "DATAVERSE_API_TOKEN": DATAVERSE.get("api_token", ""),
            },
        )

        if debug_mode:
            # print build logs
            for log in build_logs:
                print(log.get("stream", ""))

    container_name = tag + "_monapipe_container"
    try:
        # check if container already exists
        container = client.containers.get(container_name)

        if container.status == "running":
            logging.info("Container %s already exists and is running.", container.name)
        # if container is not running, start container
        elif container.status != "running":
            container.start()
            logging.info("Container %s already exists and is starting now.", container.name)

    except docker.errors.NotFound:
        # start container from image if not exists

        volumes = {}

        # Mount local data path into container (local Docker setup only).
        # Set data_path_host=None for containers with data baked into the image
        # (currently: opentapioca_entity_linker_api — data downloaded at build time via Dockerfile).
        if data_path_host is not None:
            data_path_host_container_mapping = {
                data_path_host: {"bind": data_path_container, "mode": "rw"}
            }
            volumes.update(data_path_host_container_mapping)

        # Set container configuration
        container_config = {
            'detach': True,
            'name': container_name,
            'ports': {f"{container_port}/tcp": host_port},
            'volumes': volumes
        }

        # Set network configuration if specified
        if network_name:
            container_config['network'] = network_name
        else:
            container_config['network_mode'] = 'bridge'

        # Set environment variables if specified
        if environment:
            container_config['environment'] = environment
        
        container = client.containers.run(
            tag,
            **container_config
        )

        api_url = f"http://localhost:{host_port}/"
        logging.info("Starting Docker container... @ %s", api_url)

        # Check container status
        # container.reload()
        logging.info("Container status: %s", container.status)

        # Wait until API is ready
        if not wait_for_api(api_url):
            raise RuntimeError("API did not become ready in time.")

        logging.info("Container %s started and running.", container.name)

def provide_solr_container(
    dockerfile_dir: str,
    dockerfile: str = "Dockerfile.solr",
    network_name: str = "opentapioca_entity_linker_api_network",
    debug_mode: bool = False
):
    """Function that builds and starts a Solr sidecar container.

    Args:
        dockerfile_dir: Dir name of Dockerfile.
        dockerfile: Name of the Dockerfile.
        network_name: Name of the Docker network to connect the container to.
        debug_mode: Flag to enable debug mode.

    """
    client = docker.from_env()

    # Generate network
    try:
        network = client.networks.get(network_name)
        print(f"Network {network_name} already exists.")
    except docker.errors.NotFound:
        network = client.networks.create(
            network_name,
            driver="bridge",
            check_duplicate=True
        )
        print(f"Created network {network_name}.")

    # Generate the tag and container name for the Solr Docker image
    solr_tag = f"{os.path.basename(dockerfile_dir)}_solr"
    solr_container_name = f"{os.path.basename(dockerfile_dir)}_solr"

    # Build Solr image if not exists
    try:
        client.images.get(solr_tag)
        print(f"Image {solr_tag} already exists.")
    except docker.errors.ImageNotFound:
        print(f"Building Solr image {solr_tag}...")
        sol, build_logs = client.images.build(
            path=dockerfile_dir,
            dockerfile=dockerfile,
            tag=solr_tag,
            buildargs={
                "CONTAINER_PORT": "8983",
                "SOLR_URL": "http://opentapioca_entity_linker_api_solr:8983/solr",
                "SOLR_COLLECTION": "wikidata_20241216_all",
                "DATAVERSE_API_TOKEN": DATAVERSE.get("api_token", ""),
            },
        )
        if debug_mode:
            for log in build_logs:
                if 'stream' in log:
                    print(log['stream'].strip())

    # Generate solr volume if not exists
    solr_volume_name = f"{os.path.basename(dockerfile_dir)}_solr_data"
    try:
        client.volumes.get(solr_volume_name)
    except docker.errors.NotFound:
        client.volumes.create(solr_volume_name)

    # Start Solr container if not exists
    try:
        solr_container = client.containers.get(solr_container_name)
        if solr_container.status != "running":
            solr_container.start()
            print(f"Starting existing Solr container {solr_container_name}...")
        else:
            print(f"Solr container {solr_container_name} already running.")
    except docker.errors.NotFound:
        print(f"Creating new Solr container {solr_container_name}...")
        solr_container = client.containers.run(
            solr_tag,
            detach=True,
            name=solr_container_name,
            ports={"8983/tcp": 8983},
            volumes={
                solr_volume_name: {"bind": "/var/solr/data", "mode": "rw"},
            },
            network=network_name
        )

    # Wait until Solr is ready
    print(f"Waiting for Solr to become available...")
    solr_ready = False
    for i in range(30):
        try:
            response = requests.get(f"http://localhost:8983/solr/")
            if response.status_code == 200:
                solr_ready = True
                print("Solr is ready.")
                
                # Wait for wikidata_20241216_all collection to be ready
                print("Waiting for wikidata_20241216_all collection...")
                for j in range(30):
                    try:
                        # Use tag endpoint (select handler not configured in tapioca configset)
                        response = requests.post(
                            f"http://localhost:8983/solr/wikidata_20241216_all/tag",
                            headers={"Content-Type": "text/plain"},
                            data="test"
                        )
                        if response.status_code == 200:
                            print("Collection wikidata_20241216_all is ready.")
                            return
                    except requests.exceptions.ConnectionError:
                        pass
                    time.sleep(2)
                    print(f"Waiting for wikidata_20241216_all collection... {j+1}/30")
                break
        except requests.exceptions.ConnectionError:
            pass
        time.sleep(2)
        print(f"Waiting for Solr... {i+1}/30")
    
    if not solr_ready:
        raise RuntimeError("Solr did not start in time")


def wait_for_api(url, timeout=9999):
    """Waits until the API is available at the specified URL."""
    start_time = time.time()
    while True:
        try:
            response = requests.get(url)
            if response.status_code == 200:
                logging.info("API is ready.")
                return True
        except requests.exceptions.ConnectionError:
            pass

        if time.time() - start_time > timeout:
            logging.info("API did not become ready in time.")
            return False

        # print("Waiting for API to be ready...")
        time.sleep(2)


def stop_docker_container(name="all", remove=False):
    """Method to stop all running MONAPipe containers."""
    client = docker.from_env()
    if name == "all":
        for container in client.containers.list():
            if container.name.endswith("_monapipe_container"):
                if container.name == name or name == "all":
                    container.stop()
                    if remove:
                        container.remove()


def delete_docker_container(name="all"):
    """Method to delete all running MONAPipe containers."""
    stop_docker_container(name=name, remove=True)


def check_docker_installation():
    """
    Checks if Docker is installed by attempting to run the command `docker --version`.

    :Raises:
        EnvironmentError: If Docker is not installed (FileNotFoundError), if Docker
                          is installed but the service might not be active, or if
                          an unknown OS error occurs (OSError).
    """
    try:
        # Check if Docker is installed
        subprocess.run(
            ["docker", "--version"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
    except FileNotFoundError as e:
        raise EnvironmentError(
            "This MONAPipe implementation needs Docker. Docker is not installed. Please install Docker and try again."
        ) from e
    except subprocess.CalledProcessError as e:
        raise EnvironmentError(
            "This MONAPipe implementation needs Docker. Docker is installed, but the Docker service might not be active."
        ) from e
    except OSError as e:
        raise EnvironmentError(
            "This MONAPipe implementation needs Docker. An OS error occurred while trying to check Docker installation."
        ) from e


def check_docker_running():
    """
    Checks if the Docker daemon is running by executing the command `docker info`.

    :Raises:
        EnvironmentError: If Docker is installed but the daemon is not running (CalledProcessError),
                          if an unknown OS error occurs (OSError), or if any other unexpected error occurs.
    """
    try:
        # Check if Docker daemon is running
        subprocess.run(
            ["docker", "info"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
    except subprocess.CalledProcessError as e:
        raise EnvironmentError(
            "This MONAPipe implementation needs Docker. Docker is installed, but the Docker daemon is not running. Please start the Docker service."
        ) from e
    except OSError as e:
        raise EnvironmentError(
            "This MONAPipe implementation needs Docker. An OS error occurred while trying to check Docker daemon status."
        ) from e
    except Exception as e:
        raise EnvironmentError(f"An unknown error occurred: {e}") from e
