# SPDX-License-Identifier: CC0-1.0

import datetime
import re
import textwrap
import xml.sax.saxutils

from importlib.metadata import version
from typing import Any, Callable, Dict, List, Union
from xml.etree import ElementTree

from spacy.language import Language
from spacy.tokens import Doc, Token

from monapipe.pipeline.formatter.formatter import Formatter
from monapipe.pipeline.methods import deserialize_config_param, optional


@Language.factory(
    "vrt_formatter",
    assigns=Formatter.assigns,
    default_config={
        "column_names": [
            "ID",
            "FORM",
            "LEMMA",
            "UPOS",
            "XPOS",
            "FEATS",
            "HEAD",
            "DEPREL",
            "DEPS",
            "MISC",
        ],
        "column_names_plus": [],
        "column_funcs": {},
        "cwb_version": "v3.4.28",
        "empty_value": "",
        "undef_value": "",
        "comments": True,
    },
)
def vrt_formatter(
    nlp: Language,
    name: str,
    column_names: List[str],
    column_names_plus: List[str],
    column_funcs: Union[str, Dict[str, Callable[[Token], Any]]],
    cwb_version: str,
    empty_value: str,
    undef_value: str,
    comments: bool,
) -> Any:
    r"""spaCy component implementation.
        Create a VRT representation of the document.

        Tokens are grouped into <text>...</text> and <s>...</s> regions.
        Token annotations, i.e. columns, are separated by "\t".

        By default, the VRT output is compatible with CWB v3.4.28 or higher, i.e.:
          - token lines are numbered,
          - the output contains comments starting with "#".

        The legacy format, "v3.4", will:
          - also contain token numbers (*),
          - use XML comments,
          - escape XML entities in token lines.

        (*) cwb-encode assumes the first column to be "word" by default.
        Older versions cannot ignore an initial column of integers (option -n or -N).
        Therefore, output in the legacy format must be encoded with the option "-p-".
        However, the modern format version should be suitable for most setups.

        It is recommended to use the following cwb-encode options:
          - format version "v3.4.28": "-nsB" or "-N id -sB"
          - format version "v3.4": "-xsB"

        For more information on the VRT format:
          - https://cwb.sourceforge.io/files/CWB_Encoding_Tutorial/
          - https://cwb.sourceforge.io/files/CWB_Encoding_Tutorial/3.html
          - https://sourceforge.net/p/cwb/code/HEAD/tree/cwb/trunk/CHANGES

    Args:
        nlp: spaCy object.
        name: Component name.
        column_names: List of columns to be included.
            Per default, these are the 10 columns from the CoNLL-U format.
            If the default values are changed, one should still use "ID" as the first column.
        column_names_plus: List of columns to be included.
            The complete list of columns will be `column_names` + `column_names_plus`.
        column_funcs: (Serialized) dictionary that maps a column name to a function that maps a token to a value.
            If there is a function given for one of the 10 default columns, the given function replaces the default one.
        cwb_version: Minimum CWB version needed for processing the output.
            Currently, only "v3.4.28" and "v3.4" are supported.
        empty_value: Placeholder for empty token annotation, "" by default.
            String must not contain tabs due to VRT format restrictions.
        undef_value: Placeholder for undefined token annotation, "" by default.
            String must not contain tabs due to VRT format restrictions.
        comments: Boolean switch for version and sentence comments.

    Returns:
        `VrtFormatter`.

    """
    return VrtFormatter(
        nlp,
        column_names,
        column_names_plus,
        column_funcs,
        cwb_version,
        empty_value,
        undef_value,
        comments,
    )


class VrtFormatter(Formatter):
    """The class `VrtFormatter`."""

    def __init__(
        self,
        nlp: Language,
        column_names: List[str],
        column_names_plus: List[str],
        column_funcs: Union[str, Dict[str, Callable[[Token], Any]]],
        cwb_version: str,
        empty_value: str,
        undef_value: str,
        comments: bool,
    ):
        optional(self, nlp, ["parser"])

        super().__init__(nlp, column_names, column_names_plus, column_funcs, "\t")

        self.column_names = self.column_names + self.column_names_plus

        column_funcs = deserialize_config_param(self.column_funcs)

        self.column_funcs = {
            "ID": lambda token: (
                list(token.sent).index(token) if token.doc.has_annotation("SENT_START") else token.i
            )
            + 1,
            "FORM": lambda token: (token._.text if hasattr(token._, "text") else token.text),
            "LEMMA": lambda token: token.lemma_,
            "UPOS": lambda token: token.pos_,
            "XPOS": lambda token: token.tag_,
            "FEATS": lambda token: token.morph,
            "HEAD": lambda token: (
                0
                if token.head == token
                else (
                    list(token.sent).index(token.head)
                    if token.doc.has_annotation("SENT_START")
                    else token.head.i
                )
                + 1
            ),
            "DEPREL": lambda token: token.dep_,
        }

        for column_name in column_funcs:
            self.column_funcs[column_name] = column_funcs[column_name]

        # check format version
        if cwb_version not in ["v3.4.28", "v3.4"]:
            # other format versions are not yet supported
            raise ValueError
        self.cwb_version = cwb_version

        if "\t" in empty_value:
            # not allowed in VRT format
            raise ValueError
        self.empty_value = empty_value

        if "\t" in undef_value:
            # not allowed in VRT format
            raise ValueError
        self.undef_value = undef_value

        self.comments = comments

        # save some information about the NLP model for later use
        self._nlp_meta = {
            "name": nlp.meta.get("name", "NA"),
            "version": nlp.meta.get("version", "NA"),
        }

    def __call__(self, doc: Doc) -> Doc:
        # generate comment lines describing the output
        # version information for MONA/spaCy model
        nlp_info = f"name={self._nlp_meta['name']} version={self._nlp_meta['version']}"
        # current time and date in ISO format
        time_now = datetime.datetime.now().replace(microsecond=0, tzinfo=None).isoformat()
        if self.cwb_version == "v3.4.28":
            text_comment = f"""
            # creator: MONAPipe v{version("monapipe")}
            # model: {nlp_info}
            # format: CWB v3.4.28
            # columns: {" ".join(self.column_names)}
            # date: {time_now}
            """
        elif self.cwb_version == "v3.4":
            text_comment = f"""
            <!-- creator: MONAPipe v{version("monapipe")} -->
            <!-- model: {nlp_info}
            <!-- format: CWB v3.4 -->
            <!-- columns: {" ".join(self.column_names)} -->
            <!-- date: {time_now} -->
            """
        else:
            raise ValueError

        if self.comments:
            first_rows = textwrap.dedent(text_comment).strip().splitlines()
        else:
            first_rows = []

        doc_rows = []

        # prepend structural element for start of text
        doc_rows.append("<text>")

        if doc.has_annotation("SENT_START"):
            sents = list(doc.sents)
            is_sentenced = True
        else:
            sents = [doc]
            is_sentenced = False

        for sent in sents:
            sent_rows = []

            # prepend structural element for start of sentence
            if is_sentenced:
                sent_rows.append("<s>")
                if self.comments:
                    try:
                        sent_text = "".join([token._.text_with_ws for token in sent])
                    except (AttributeError, TypeError):  # not normalized or text_with_ws is None
                        sent_text = "".join([token.text_with_ws for token in sent])
                    sent_text = re.sub(r"\s+", " ", sent_text).strip()

                    if self.cwb_version == "v3.4.28":
                        sent_rows.append("# sentence: " + sent_text)
                    elif self.cwb_version == "v3.4":
                        sent_rows.append(_xml_comment("sentence: " + sent_text))
                    else:
                        raise ValueError

            for token in sent:
                row = []
                for column_name in self.column_names:
                    val = self._apply_column_func(token, column_name)
                    val = self._format_value(val)
                    if self.cwb_version == "v3.4":
                        val = _escape_token(val)
                    if "\t" in val:
                        # VRT format does not allow this
                        raise ValueError
                    row.append(val)
                sent_rows.append(row)

            # append structural element for end of sentence
            if is_sentenced:
                sent_rows.append("</s>")

            doc_rows.extend(sent_rows)

            sent._.format_str = self._string_from_rows(sent_rows)

        # append structural element for end of text
        doc_rows.append("</text>")

        doc._.format_str = self._string_from_rows(first_rows + doc_rows)
        return doc

    # NOTE: same code as in conllu_formatter.py; should be extracted to formatter.py
    def _apply_column_func(self, token: Token, column_name: str) -> Any:
        """Determine the value for the token in a given column.

        Args:
            token: The token.
            column_name: The name of the column.

        Returns:
            The value for the token in the given column;
                `None` if there is no corresponding value in the document.

        """
        if column_name in self.column_funcs:
            try:
                return self.column_funcs[column_name](token)
            except Exception:
                # the attribute cannot be computed for the token
                pass
        return None

    def _format_value(self, val: Any) -> str:
        """Stringify a value.

        Args:
            val: The value.

        Returns:
            A string that contains no linebreaks.
                Uses "self.empty_value" to represent known but empty values.
                Uses "self.undef_value" to represent unknown values.

        """
        if val is None:
            return self.undef_value
        val = re.sub(r"\s+", " ", str(val)).strip()
        if val == "":
            return self.empty_value
        return val

    def _string_from_rows(self, rows: List[Union[str, List[str]]]) -> str:
        """Convert a list of rows into the final VRT representation.

        Args:
            rows: The lines of the VRT file.
                Comments and blank lines are already strings;
                    other lines are lists that contain the string values for each column.

        Returns:
            The VRT string representation.

        """
        lines = []
        for row in rows:
            if isinstance(row, str):
                lines.append(row)
            else:
                lines.append(self.column_delimiter.join(row))
        return "\n".join(lines)


def _escape_token(string: str) -> str:
    """Escape the input string so that it can be used as a VRT token.

       As a result, tokens and structural attributes will not be confused by cwb-encode.

    Args:
        string: A string representing a token.

    Returns:
        The input with XML entities escaped.

    """
    return xml.sax.saxutils.escape(string, entities={"'": "&apos;", '"': "&quot;"})


def _xml_comment(string: str) -> str:
    """Format the input string as an XML comment.

    Args:
        string: A string.

    Returns:
        The input embedded in an XML comment tag (<!-- ... -->).

    """
    element = ElementTree.Comment(text=f" {string} ")
    return ElementTree.tostring(element, encoding="utf-8").decode()
