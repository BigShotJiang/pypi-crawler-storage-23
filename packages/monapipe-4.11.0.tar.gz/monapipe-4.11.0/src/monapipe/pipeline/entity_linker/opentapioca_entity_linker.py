# SPDX-FileCopyrightText: 2025 Georg-August-Universität Göttingen
#
# SPDX-License-Identifier: CC0-1.0

import os
import re
import sys
import requests
from typing import Any, Dict, List, Optional, Union

from spacy.language import Language
from spacy.tokens import Doc, Span

from monapipe.config import PORTS
from monapipe.docker import provide_docker_container
from monapipe.pipeline.entity_linker.entity_linker import EntityLinker
from monapipe.pipeline.methods import add_extension

DOCKERFILE_DIR = os.path.join(os.path.dirname(__file__), "opentapioca_entity_linker_api")


@Language.factory(
    "opentapioca_entity_linker",
    assigns=EntityLinker.assigns,
    default_config={
        "dockerfile": "Dockerfile",
        "api_mode": "localhost",
    },
)
def opentapioca_entity_linker(
    nlp: Language,
    name: str,
    dockerfile: str = "Dockerfile",
    api_mode: str = "localhost",
) -> Any:
    """Spacy component implementation.

    Args:
        nlp: Spacy object.
        name: Component name.
        dockerfile: The Dockerfile to build the API container.
        api_mode: API source, localhost by docker ("localhost") or service api for gitlab-ci ("service").
            Online API will be implemented in the future.

    Returns:
        `EntityLinker`.
    """

    return OpenTapiocaEntityLinker(nlp, dockerfile, api_mode)


class OpenTapiocaEntityLinker(EntityLinker):
    """Entity linker using OpenTapioca."""

    def __init__(self, nlp: Language, dockerfile: str, api_mode: str) -> None:
        super().__init__(nlp, dockerfile, api_mode)

        self.host_port = PORTS["opentapioca_entity_linker"]["host_port"]
        self.container_port = PORTS["opentapioca_entity_linker"]["container_port"]

        # Span extension for entity candidates
        add_extension(Span, "candidates", [])

        if self.api_mode == "localhost":
            
            provide_docker_container(
                dockerfile_dir=DOCKERFILE_DIR,
                dockerfile="Dockerfile",
                container_port=self.container_port,
                host_port=self.host_port,
                data_path_host=None,  # data is baked into the image at build time
                sidecar_container="opentapioca_entity_linker_api_solr",
                network_name="opentapioca_entity_linker_api_network",
                environment={
                    "SOLR_URL": f"http://opentapioca_entity_linker_api_solr:8983/solr",
                    "SOLR_COLLECTION": "wikidata_20241216_all",
                    "SOLR_HOST": "opentapioca_entity_linker_api_solr",
                },
            )

    def __call__(self, doc: Doc) -> Doc:
        """Annotate entities in the document with OpenTapioca.

        Args:
            doc: The spaCy Doc to annotate.

        Returns:
            The annotated Doc with candidates attached to entities.
        """
        # Get the full text from the document
        text = doc.text

        # Call OpenTapioca API
        annotations = self._get_opentapioca_annotations(text)

        # Match annotations to existing entities and add candidates
        for entity in doc.ents:
            # Find matching annotations based on character offsets
            matching_annos = [
                anno for anno in annotations
                if anno.get('start') == entity.start_char and anno.get('end') == entity.end_char
            ]

            # Create candidates list from matching annotations
            candidates = []
            for anno in matching_annos:
                # Tags contain the actual entity candidates
                for tag in anno.get('tags', []):
                    candidate = {
                        'id': tag.get('id', ''),
                        'label': tag.get('label', ''),
                        'score': tag.get('score', 0.0),
                        'description': tag.get('desc', '')
                    }
                    candidates.append(candidate)

            entity._.candidates = candidates

        return doc

    def _get_opentapioca_annotations(self, text: str) -> List[Dict]:
        """Call OpenTapioca API to get entity annotations.

        Args:
            text: The text to annotate.

        Returns:
            List of annotation dictionaries.
        """
        if self.api_mode == "localhost":
            url = f"http://localhost:{self.host_port}/api/annotate"
        elif self.api_mode == "service":
            url = f"http://opentapioca:{self.container_port}/api/annotate"
        else:
            sys.exit(
                """
                Please choose provided API mode `localhost` (for local usage)
                or `service` (for gitlab-ci service)."""
            )

        response = requests.post(
            url,
            params={"query": text},
            timeout=10000
        )

        if response.status_code == 200:
            data = response.json()
            return data.get('annotations', [])
        else:
            error_msg = f"Error message: {response.status_code}"
            sys.exit(error_msg)
