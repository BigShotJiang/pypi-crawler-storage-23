# SPDX-FileCopyrightText: 2025 Georg-August-Universität Göttingen
#
# SPDX-License-Identifier: CC0-1.0

from typing import Dict, List, Optional, Union

import numpy as np
from fastapi import Body, FastAPI
from request_opentapioca_entity_linker import request_opentapioca_entity_linker

app = FastAPI()


@app.get("/")
def read_root():
    """Root endpoint.

    Returns:
        API message.
    """
    return {"message": "opentapioca_entity_linker_api based on fastText."}


@app.post("/opentapioca_entity_linker_api/")
def apply_opentapioca_entity_linker(text: str = Body(...)):
    """

    Args:
        text: Input text to be processed by the OpenTapioca entity linker.

    Returns:
        List of dictionaries with GND-ID and similarity score (or None if no candidate embedding existed).

    """
    result_opentapioca_entity_linker = request_opentapioca_entity_linker(text)
    return result_opentapioca_entity_linker
