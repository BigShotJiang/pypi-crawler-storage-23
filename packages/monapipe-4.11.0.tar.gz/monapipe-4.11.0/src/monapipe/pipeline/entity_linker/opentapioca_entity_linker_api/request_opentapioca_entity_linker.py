import spacy


def request_opentapioca_entity_linker(text: str):

    # send text to the OpenTapioca API
    nlp_spacy_trf = spacy.load("de_dep_news_trf")
    nlp_spacy_trf.add_pipe(
        "opentapioca", config={"url": "http://localhost:8457/api/annotate?lc=de"}
    )
    doc = nlp_spacy_trf(text)
    # for span in doc.ents:
    #     print((span.text, span.kb_id_, span.label_, span._.description, span._.score))

    # serialise doc doc to json/python dict
    serialised_doc = dict()
    for i, span in enumerate(doc.ents):
        serialised_doc[i] = {
            "text": span.text,
            "kb_id": span.kb_id_,
            "label": span.label_,
            "description": span._.description,
            "score": span._.score,
            "start": span.start_char,
            "end": span.end_char,
        }

    return serialised_doc
