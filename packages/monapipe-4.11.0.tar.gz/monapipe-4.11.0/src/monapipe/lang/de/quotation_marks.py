# SPDX-FileCopyrightText: 2022 Georg-August-Universität Göttingen
#
# SPDX-License-Identifier: CC0-1.0

QUOTATION_MARKS = [["„", "»", '"'], ["“", "«", '"']]
