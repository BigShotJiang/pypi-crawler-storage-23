#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2025 Georg-August-Universität Göttingen
#
# SPDX-License-Identifier: CC0-1.0

"""
Upload files to GRO.data (Göttingen Research Online Dataverse).

Usage:
    # Upload entire folder recursively:
    python upload_to_dataverse.py --folder <folder_path> [--doi <persistent_id>]

    # Upload single file:
    python upload_to_dataverse.py --file <file_path> [--dir <directory_label>] [--doi <persistent_id>]

Examples:
    # Upload all files from a folder:
    python upload_to_dataverse.py --folder ~/Desktop/opentapioca_entity_linker --doi doi:10.25625/9OBIVL

    # Upload a single file to a specific directory within the dataset:
    python upload_to_dataverse.py \\
        --file ~/Desktop/opentapioca_entity_linker/opentapioca/opentapioca/tagger.py \\
        --dir opentapioca/opentapioca \\
        --doi doi:10.25625/9OBIVL

    # Upload a single file to a nested directory:
    python upload_to_dataverse.py \\
        --file ~/Desktop/configsets/tapioca/solrconfig.xml \\
        --dir opentapioca/configsets/tapioca \\
        --doi doi:10.25625/9OBIVL

    # Upload a file to the root of the dataset (no --dir):
    python upload_to_dataverse.py --file ~/Desktop/README.md --doi doi:10.25625/9OBIVL


GRO.data / Dataverse API Documentation:
---------------------------------------

The Dataverse API allows uploading files to datasets via HTTP POST requests.
API documentation: https://guides.dataverse.org/en/latest/api/native-api.html

Environment variables for curl usage:
    export API_TOKEN=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
    export SERVER_URL=https://data.goettingen-research-online.de
    export PERSISTENT_ID=doi:10.25625/9OBIVL

Upload a file to the dataset root:
    curl -H "X-Dataverse-key:$API_TOKEN" \\
         -X POST \\
         -F "file=@myfile.txt" \\
         -F 'jsonData={"categories":["Data"], "restrict":"false", "tabIngest":"false"}' \\
         "$SERVER_URL/api/datasets/:persistentId/add?persistentId=$PERSISTENT_ID"

Upload a file to a specific directory (directoryLabel):
    curl -H "X-Dataverse-key:$API_TOKEN" \\
         -X POST \\
         -F "file=@myfile.txt" \\
         -F 'jsonData={"description":"My description.","directoryLabel":"data/subdir1","categories":["Data"], "restrict":"false", "tabIngest":"false"}' \\
         "$SERVER_URL/api/datasets/:persistentId/add?persistentId=$PERSISTENT_ID"

JSON parameters:
    - directoryLabel: Path within the dataset where the file should be placed (e.g., "data/subdir1")
    - description: Optional description for the file
    - categories: List of category tags (e.g., ["Data"])
    - restrict: "true" or "false" - whether to restrict access to the file
    - tabIngest: "true" or "false" - whether to allow tabular data ingest

Note: The API does not support uploading directories directly. Each file must be uploaded
individually with the appropriate directoryLabel to recreate the folder structure.
"""

import argparse
import json
import os
import sys
from pathlib import Path

import requests
from tqdm import tqdm

# Add parent directory to path for config import
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DATAVERSE

SERVER_URL = "https://data.goettingen-research-online.de"


def upload_file(
    file_path: str,
    directory_label: str,
    persistent_id: str,
    api_token: str,
    description: str = "",
) -> dict:
    """Upload a single file to Dataverse.

    Args:
        file_path: Path to the file to upload.
        directory_label: Directory path within the dataset (e.g., "data/subdir1").
        persistent_id: DOI of the dataset (e.g., "doi:10.25625/9OBIVL").
        api_token: API token for authentication.
        description: Optional description for the file.

    Returns:
        Response JSON from the API.
    """
    url = f"{SERVER_URL}/api/datasets/:persistentId/add?persistentId={persistent_id}"

    json_data = {
        "description": description,
        "directoryLabel": directory_label,
        "categories": ["Data"],
        "restrict": "false",
        "tabIngest": "false",
    }

    with open(file_path, "rb") as f:
        files = {"file": (os.path.basename(file_path), f)}
        data = {"jsonData": json.dumps(json_data)}
        headers = {"X-Dataverse-key": api_token}

        response = requests.post(url, headers=headers, files=files, data=data)

    return response


def upload_folder(
    folder_path: str,
    persistent_id: str,
    api_token: str,
    description: str = "",
) -> None:
    """Upload all files from a folder recursively to Dataverse.

    Args:
        folder_path: Path to the folder to upload.
        persistent_id: DOI of the dataset.
        api_token: API token for authentication.
        description: Optional description for files.
    """
    folder_path = Path(folder_path).resolve()
    folder_name = folder_path.name

    # Collect all files
    files_to_upload = []
    for root, _, files in os.walk(folder_path):
        for filename in files:
            # Skip hidden files and macOS metadata
            if filename.startswith(".") or filename == ".DS_Store":
                continue

            file_path = Path(root) / filename
            # Get relative path within the folder (excluding the folder name itself)
            relative_path = file_path.relative_to(folder_path)
            # Directory label is the parent directory of the file (relative path without filename)
            directory_label = str(relative_path.parent)
            if directory_label == ".":
                directory_label = ""

            files_to_upload.append((str(file_path), directory_label))

    if not files_to_upload:
        print(f"No files found in {folder_path}")
        return

    print(f"Found {len(files_to_upload)} files to upload from '{folder_name}'")
    print(f"Target dataset: {persistent_id}")
    print()

    # Upload files with progress bar
    success_count = 0
    error_count = 0

    for file_path, directory_label in tqdm(files_to_upload, desc="Uploading"):
        try:
            response = upload_file(
                file_path=file_path,
                directory_label=directory_label,
                persistent_id=persistent_id,
                api_token=api_token,
                description=description,
            )

            if response.status_code == 200:
                success_count += 1
            else:
                error_count += 1
                tqdm.write(f"Error uploading {file_path}: {response.status_code}")
                tqdm.write(f"  Response: {response.text[:200]}")

        except Exception as e:
            error_count += 1
            tqdm.write(f"Exception uploading {file_path}: {e}")

    print()
    print(f"Upload complete: {success_count} successful, {error_count} failed")


def main():
    parser = argparse.ArgumentParser(
        description="Upload files from a folder to GRO.data Dataverse"
    )
    parser.add_argument(
        "--folder",
        default=None,
        help="Path to a folder to upload recursively",
    )
    parser.add_argument(
        "--file",
        default=None,
        help="Path to a single file to upload (use with --dir)",
    )
    parser.add_argument(
        "--dir",
        default="",
        help="Directory label (path within dataset) for single file upload",
    )
    parser.add_argument(
        "--doi",
        default=None,
        help="Persistent ID (DOI) of the dataset. Default: doi:10.25625/9OBIVL",
    )
    parser.add_argument(
        "--description",
        default="",
        help="Description for the uploaded files",
    )
    parser.add_argument(
        "--api-token",
        default=None,
        help="API token (overrides config.py)",
    )

    args = parser.parse_args()

    # Get API token
    api_token = args.api_token or DATAVERSE.get("api_token")
    if not api_token:
        print("Error: No API token provided.")
        print("Set it in config.py DATAVERSE['api_token'] or use --api-token")
        sys.exit(1)

    # Get DOI
    persistent_id = args.doi
    if not persistent_id:
        # Default to opentapioca DOI without version suffix
        persistent_id = DATAVERSE.get("doi_opentapioca_entity_linker", "").split("&")[0]
        if not persistent_id:
            print("Error: No DOI provided. Use --doi to specify the dataset.")
            sys.exit(1)

    # Single file upload mode
    if args.file:
        if not os.path.isfile(args.file):
            print(f"Error: '{args.file}' is not a file")
            sys.exit(1)

        print(f"Uploading single file: {args.file}")
        print(f"Directory label: {args.dir or '(root)'}")
        print(f"Target dataset: {persistent_id}")

        try:
            response = upload_file(
                file_path=args.file,
                directory_label=args.dir,
                persistent_id=persistent_id,
                api_token=api_token,
                description=args.description,
            )

            if response.status_code == 200:
                print("Upload successful!")
            else:
                print(f"Error: {response.status_code}")
                print(f"Response: {response.text[:500]}")
                sys.exit(1)

        except Exception as e:
            print(f"Exception: {e}")
            sys.exit(1)

        return

    # Folder upload mode
    if not args.folder:
        print("Error: Use --folder for folder upload or --file for single file upload")
        parser.print_help()
        sys.exit(1)

    if not os.path.isdir(args.folder):
        print(f"Error: '{args.folder}' is not a directory")
        sys.exit(1)

    upload_folder(
        folder_path=args.folder,
        persistent_id=persistent_id,
        api_token=api_token,
        description=args.description,
    )


if __name__ == "__main__":
    main()
