# SPDX-FileCopyrightText: 2025 Georg-August-Universität Göttingen
#
# SPDX-License-Identifier: CC0-1.0

import os

from monapipe.resource_handler import ResourceHandler

RESOURCE_PATH = os.path.dirname(__file__)

RESOURCE_HANDLER = ResourceHandler(RESOURCE_PATH)


def load():
    """Loading method of the `opentapioca_entity_linker` resource.

    Returns:
        Path to the opentapioca directory containing the OpenTapioca installation.

    """
    # Return the path to the opentapioca directory
    opentapioca_path = os.path.join(RESOURCE_HANDLER.data_path, "opentapioca")

    if not os.path.exists(opentapioca_path):
        raise FileNotFoundError(
            f"OpenTapioca resources not found at {opentapioca_path}. "
            "Please ensure the resources have been downloaded from Dataverse."
        )

    return opentapioca_path
