def hello() -> str:
    return "Hello from airflow-container-utils!"
