from turl.config import TrainConfig


def test_default_config():
    config = TrainConfig()
    assert config.lr == 1e-4
    assert config.batch_size == 32
    assert config.gamma == 0.99
    assert config.clip_range == 0.2


def test_custom_config():
    config = TrainConfig(lr=3e-4, batch_size=64, max_steps=50_000)
    assert config.lr == 3e-4
    assert config.batch_size == 64
    assert config.max_steps == 50_000
