"""turl - RL Training Infrastructure."""

__version__ = "0.1.0"

from turl.config import TrainConfig
from turl.trainer import Trainer

__all__ = ["TrainConfig", "Trainer"]
