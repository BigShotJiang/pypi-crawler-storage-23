"""Training configuration."""

from dataclasses import dataclass, field


@dataclass
class TrainConfig:
    """Configuration for RL training."""

    # Model
    model_name: str = ""
    hidden_size: int = 768

    # Training
    lr: float = 1e-4
    batch_size: int = 32
    max_steps: int = 100_000
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0
    warmup_steps: int = 1000
    weight_decay: float = 0.01
    seed: int = 42

    # RL
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_range: float = 0.2
    value_loss_coef: float = 0.5
    entropy_coef: float = 0.01
    num_rollout_steps: int = 128

    # Logging
    log_interval: int = 10
    save_interval: int = 1000
    output_dir: str = "./outputs"

    # Distributed
    num_gpus: int = 1
    backend: str = "nccl"
