"""RL Trainer."""

import logging
import os
from pathlib import Path

import torch
import torch.nn as nn

from turl.config import TrainConfig

logger = logging.getLogger(__name__)


class Trainer:
    """Base RL trainer."""

    def __init__(self, config: TrainConfig, model: nn.Module):
        self.config = config
        self.model = model
        self.global_step = 0

        self._setup_seed()
        self._setup_device()
        self._setup_optimizer()
        self._setup_output_dir()

    def _setup_seed(self):
        torch.manual_seed(self.config.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(self.config.seed)

    def _setup_device(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = self.model.to(self.device)
        logger.info("Using device: %s", self.device)

    def _setup_optimizer(self):
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.config.lr,
            weight_decay=self.config.weight_decay,
        )

    def _setup_output_dir(self):
        Path(self.config.output_dir).mkdir(parents=True, exist_ok=True)

    def save_checkpoint(self, path: str | None = None):
        """Save model checkpoint."""
        if path is None:
            path = os.path.join(self.config.output_dir, f"checkpoint-{self.global_step}")
        os.makedirs(path, exist_ok=True)
        torch.save(
            {"model": self.model.state_dict(), "optimizer": self.optimizer.state_dict(), "step": self.global_step},
            os.path.join(path, "state.pt"),
        )
        logger.info("Saved checkpoint to %s", path)

    def load_checkpoint(self, path: str):
        """Load model checkpoint."""
        state = torch.load(os.path.join(path, "state.pt"), map_location=self.device, weights_only=True)
        self.model.load_state_dict(state["model"])
        self.optimizer.load_state_dict(state["optimizer"])
        self.global_step = state["step"]
        logger.info("Loaded checkpoint from %s (step %d)", path, self.global_step)

    def train_step(self, batch: dict) -> dict:
        """Single training step. Override in subclass."""
        raise NotImplementedError

    def train(self, dataloader):
        """Main training loop."""
        self.model.train()
        for batch in dataloader:
            if self.global_step >= self.config.max_steps:
                break

            metrics = self.train_step(batch)
            self.global_step += 1

            if self.global_step % self.config.log_interval == 0:
                logger.info("step=%d %s", self.global_step, metrics)

            if self.global_step % self.config.save_interval == 0:
                self.save_checkpoint()
