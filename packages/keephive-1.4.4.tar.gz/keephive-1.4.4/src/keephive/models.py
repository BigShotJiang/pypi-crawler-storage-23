"""Pydantic models for all structured data in keephive.

This is where the root cause of the bash version's bugs gets fixed:
native JSON validation with exact field names and types.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field

# ---- Verify ----


class Verdict(str, Enum):
    VALID = "VALID"
    STALE = "STALE"
    UNCERTAIN = "UNCERTAIN"


class FactVerdict(BaseModel):
    index: int
    verdict: Verdict
    reason: str
    correction: str | None = None


class VerifyResponse(BaseModel):
    verdicts: list[FactVerdict]


# ---- PreCompact ----


class InsightCategory(str, Enum):
    DECISION = "DECISION"
    FACT = "FACT"
    CORRECTION = "CORRECTION"
    TODO = "TODO"
    INSIGHT = "INSIGHT"


class Insight(BaseModel):
    category: InsightCategory
    description: str


class MemoryAction(str, Enum):
    ADD = "add"
    CORRECT = "correct"


class MemoryUpdate(BaseModel):
    action: MemoryAction
    text: str
    replaces: str | None = None  # for corrections: old text to find


class PreCompactResponse(BaseModel):
    insights: list[Insight]
    memory_updates: list[MemoryUpdate] = []
    rule_suggestions: list[str] = []  # short imperative rules, max 2
    completed_todos: list[str] = []  # TODOs resolved in this conversation


# ---- Reflect Analyze ----


class Pattern(BaseModel):
    topic: str
    days: int
    has_guide: bool


class Addition(BaseModel):
    fact: str
    source: str


class Contradiction(BaseModel):
    memory: str
    log: str
    date: str


class ReflectAnalyzeResponse(BaseModel):
    patterns: list[Pattern]
    additions: list[Addition]
    contradictions: list[Contradiction]
    actions: list[str] = []


# ---- Audit ----


class VaultPerspective(BaseModel):
    analysis: str
    issues: list[str] = []


class CleanerPerspective(BaseModel):
    analysis: str
    issues: list[str] = []


class StrategistPerspective(BaseModel):
    analysis: str
    issues: list[str] = []


class AuditPlay(BaseModel):
    issue: str  # One-line problem description
    command: str  # Exact hive command


class AuditSynthesis(BaseModel):
    plays: list[AuditPlay]  # 3-5 ranked actions, most impactful first
    connection: str
    tension: str
    wild_card: str


# ---- Standup ----


class StandupResponse(BaseModel):
    yesterday: list[str]
    today: list[str]
    blockers: list[str]


# ---- Doctor ----


class DuplicateGroup(BaseModel):
    entries: list[str]
    suggestion: str


class DoctorDuplicatesResponse(BaseModel):
    duplicate_groups: list[DuplicateGroup]
    orphaned_todos: list[str]


# ---- Reflect Draft ----


class GuideDraftResponse(BaseModel):
    title: str
    content: str


# ---- Recall Expand ----


class RecallExpandResponse(BaseModel):
    terms: list[str]


# ---- Log Summarize ----


class DailySummaryResponse(BaseModel):
    bullets: list[str]  # 3-5 summary points


# ---- Note Extract ----


class NoteExtractResponse(BaseModel):
    items: list[str]  # extracted action items from freeform text


# ---- KingBee ----


class MorningBriefingResponse(BaseModel):
    content: str = Field(description="The morning briefing text, under 150 words")


class StaleCheckResponse(BaseModel):
    content: str = Field(description="Stale fact warnings, one per line, or 'Nothing stale'")


class SoulUpdateResponse(BaseModel):
    content: str = Field(description="Complete updated SOUL.md content")


class ProposedSkill(BaseModel):
    name: str = Field(description="Slug name for the skill guide, e.g. 'fast-git-summary'")
    rationale: str = Field(description="Why this skill would help, with evidence from logs")
    content: str = Field(description="Complete skill markdown content")


class ProposedTask(BaseModel):
    name: str = Field(description="Task identifier for daemon.json, e.g. 'weekly-git-activity'")
    rationale: str = Field(description="Why this task would help, with evidence from logs")
    config: dict = Field(description="daemon.json task config dict (enabled, time, day)")


class ProposedRule(BaseModel):
    rule: str = Field(description="Behavioral rule text for rules.md")
    rationale: str = Field(description="Evidence from logs (N sessions showing this pattern)")


class ProposedEdit(BaseModel):
    """Refine, prune, or merge existing skills/tasks/rules based on observed usage."""

    action: str = Field(description="'edit' | 'prune' | 'merge'")
    target_type: str = Field(description="'skill' | 'task' | 'rule'")
    target_name: str = Field(description="Name/slug of the existing item to modify")
    rationale: str = Field(description="Evidence from logs: why this edit improves things")
    changes: str = Field(
        description=(
            "For edit: description of what to add, change, or fix — include any specific "
            "new sections verbatim. The apply phase merges this with the full guide. "
            "For prune: reason to remove. "
            "For merge: full merged content combining both."
        )
    )
    merge_with: str | None = Field(
        default=None,
        description="For merge: name of second item to combine with target_name",
    )


class GuideApplyResponse(BaseModel):
    content: str = Field(description="The complete updated guide content in Markdown")


class ImprovementResponse(BaseModel):
    proposed_skills: list[ProposedSkill] = Field(default_factory=list)
    proposed_tasks: list[ProposedTask] = Field(default_factory=list)
    proposed_rules: list[ProposedRule] = Field(default_factory=list)
    proposed_edits: list[ProposedEdit] = Field(default_factory=list)
    summary: str = Field(description="Brief summary of what patterns triggered these proposals")


# ---- Wander ----


class WanderConnection(BaseModel):
    memory_fragment: str = Field(
        description="Exact quote or close paraphrase of the memory/fact this connects to"
    )
    connection: str = Field(description="How the seed topic relates to or reframes this fragment")


class WanderDocument(BaseModel):
    seed: str = Field(description="The topic or seed phrase that triggered this wander")
    seed_source: str = Field(
        description="One of: user-queued, cross-pollination, recurring-topic, stale-todo"
    )
    thinking: str = Field(
        description=(
            "Free-form exploration, 100-200 words. First person, associative. "
            "May include observations from web search if used."
        )
    )
    connections: list[WanderConnection] = Field(
        default_factory=list,
        description="1-3 unexpected links to things already in memory or recent logs",
    )
    hypothesis: str = Field(
        description="One sentence: the insight or pattern this thinking uncovered"
    )
    question: str = Field(
        description="One open question worth surfacing to the user at next session"
    )
    used_web_search: bool = Field(
        default=False,
        description="True if web search was used during this wander",
    )
    action: str = Field(
        default="",
        description=(
            "Optional: if this hypothesis suggests a concrete, specific action "
            "(e.g. 'remove unused skill X', 'add rule about Y'), state it in one sentence. "
            "Leave empty if exploratory only."
        ),
    )
    action_type: str = Field(
        default="none",
        description="One of: run, edit, rule, none. Set to 'none' if action is empty.",
    )


# ---- SubagentStop ----


class SubagentExtractionResponse(BaseModel):
    captured: str = Field(
        default="",
        description=(
            "One sentence capturing the key decision, finding, or output. "
            "Empty string if nothing is worth surfacing."
        ),
    )
    decision: str = Field(
        default="",
        description="The most important choice made. Empty string if none.",
    )


# ---- Loop / Run ----


class LoopExtractionResponse(BaseModel):
    """Silence-valid. Empty lists are acceptable output."""

    facts: list[str] = Field(default_factory=list)  # 0-3 facts learned
    decisions: list[str] = Field(default_factory=list)  # 0-2 decisions made
    todos: list[str] = Field(default_factory=list)  # 0-2 follow-ups
