from .nrpcalc import __authors__
from .nrpcalc import __version__
from .nrpcalc import __doc__
from .nrpcalc import background
from .nrpcalc import finder
from .nrpcalc import maker

__authors__ = __authors__
__version__ = __version__
__doc__     = __doc__
