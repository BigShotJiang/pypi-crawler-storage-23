"""Tools module — registry, built-in tools, and policy-governed executor."""
