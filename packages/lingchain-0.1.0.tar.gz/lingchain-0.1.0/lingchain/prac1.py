PRAC1_CODE = '''from langchain.chat_models import init_chat_model
import os

os.environ["GOOGLE_API_KEY"] = ""

try:
    model = init_chat_model("google_genai:gemini-2.5-flash-lite")
    print("Model Loaded Successfully!\\n")

    while True:
        query = input("Enter Query (type 'quit' to exit): ")

        if query.lower() == "quit":
            print("Exiting the program...")
            break

        response = model.invoke(query)

        print("\\nUser Query:", query)
        print("AI Answer:", response.content)
        print("-" * 50)

except Exception as e:
    print("Error occurred:", e)'''

def main():
    print("=== PRAC 1: GEMINI CHATBOT ===")
    print("=" * 70)
    print(PRAC1_CODE)
    print("\n" + "="*70)
    print("COPY TO NOTEBOOK | LangChain + Google Gemini")
    print("="*70)

if __name__ == "__main__":
    main()