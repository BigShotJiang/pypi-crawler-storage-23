PRAC3_CODE = '''import os
from langchain.chat_models import init_chat_model
from IPython.display import Markdown, display

os.environ["GOOGLE_API_KEY"] = ""

try:
    models = init_chat_model("google_genai:gemini-2.5-flash-lite")
    prompt = "Write a code in Python to perform Bubble Sort algorithm without PREAMBLE and POSTAMBLE."
    response = models.invoke(prompt)
    print(f"User Query: {prompt}")
    print("AI Answer:")
    display(Markdown(response.content))

except Exception as e:
    print("Error occurred:", e)'''

def main():
    print("=== PRAC 3: BUBBLE SORT CODE GENERATION ===")
    print("=" * 70)
    print(PRAC3_CODE)
    print("\n" + "="*70)
    print("COPY TO NOTEBOOK | Code generation prompt")
    print("="*70)

if __name__ == "__main__":
    main()
