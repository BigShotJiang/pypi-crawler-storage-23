PRAC2_CODE = '''from langchain.chat_models import init_chat_model
from IPython.display import Markdown, display
import os

os.environ["GOOGLE_API_KEY"] = ""

try:
    models = init_chat_model("google_genai:gemini-2.5-flash-lite")
    print("Model Loaded Successfully!")

    while True:
        query = input("Enter Query (type 'exit' to stop): ")

        if query.lower() == "exit":
            print("Chat Ended.")
            break

        response = models.invoke(query)
        print(f"Query: {query}")
        print("AI Answer:")
        display(Markdown(response.content))
        print("-" * 50)

except Exception as e:
    print("Error occurred:", e)'''

def main():
    print("=== PRAC 2: GEMINI + IPYTHON DISPLAY ===")
    print("=" * 70)
    print(PRAC2_CODE)
    print("\n" + "="*70)
    print("COPY TO NOTEBOOK | Markdown formatted output")
    print("="*70)

if __name__ == "__main__":
    main()
