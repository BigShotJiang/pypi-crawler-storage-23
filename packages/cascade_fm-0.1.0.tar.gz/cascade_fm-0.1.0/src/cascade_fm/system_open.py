"""Open files in their default system application."""

from __future__ import annotations

import os
import platform
import subprocess
from pathlib import Path


def open_in_default_app(path: Path) -> None:
    """Open a path in the system's default application."""
    if not path.exists():
        raise FileNotFoundError(path)

    system_name = platform.system()
    if system_name == "Windows":
        os.startfile(str(path))  # type: ignore[attr-defined]
        return

    if system_name == "Darwin":
        subprocess.run(["open", str(path)], check=True)
        return

    subprocess.run(["xdg-open", str(path)], check=True)
