"""Backward-compatible import shim for `cascade_fm.types`."""

from __future__ import annotations

from cascade_fm.core.types import FileEntry, OperationResult, PaneState, PaneStatus

__all__ = ["PaneStatus", "FileEntry", "OperationResult", "PaneState"]
