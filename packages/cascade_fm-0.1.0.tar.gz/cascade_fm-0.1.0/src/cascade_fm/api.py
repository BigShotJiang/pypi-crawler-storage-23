"""Backward-compatible import shim for `cascade_fm.api`."""

from __future__ import annotations

from cascade_fm.core.api import CascadeAPI

__all__ = ["CascadeAPI"]
