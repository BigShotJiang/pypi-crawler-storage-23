"""Backward-compatible import shim for `cascade_fm.pipeline`."""

from __future__ import annotations

from cascade_fm.core.pipeline import Pane, Pipeline

__all__ = ["Pane", "Pipeline"]
