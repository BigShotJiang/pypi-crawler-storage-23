"""Backward-compatible import shim for `cascade_fm.commit`."""

from __future__ import annotations

from cascade_fm.core.commit import CommitResult, ConflictPolicy, commit_operation_output

__all__ = ["CommitResult", "ConflictPolicy", "commit_operation_output"]
