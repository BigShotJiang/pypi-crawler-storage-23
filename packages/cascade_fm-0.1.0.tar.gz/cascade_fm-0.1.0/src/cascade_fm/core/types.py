"""Core data types for cascade."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class PaneStatus(Enum):
    """Status of a pane in the pipeline."""

    CONFIGURED = "configured"  # Parameters set, not yet executed
    EXECUTING = "executing"  # Operation is running
    DONE = "done"  # Results available in CAS
    STALE = "stale"  # Upstream pane changed, needs re-execution
    ERROR = "error"  # Operation failed


@dataclass
class FileEntry:
    """Represents a file with metadata."""

    path: Path
    size: int = 0
    mime_type: str = "application/octet-stream"

    @property
    def name(self) -> str:
        """Get filename."""
        return self.path.name

    @property
    def extension(self) -> str:
        """Get file extension including dot."""
        return self.path.suffix


@dataclass
class OperationResult:
    """Result of executing an operation."""

    success: bool
    files: list[Path] = field(default_factory=list)
    error: str | None = None

    @classmethod
    def ok(cls, files: list[Path]) -> OperationResult:
        """Create a successful result."""
        return cls(success=True, files=files)

    @classmethod
    def fail(cls, error: str) -> OperationResult:
        """Create a failed result."""
        return cls(success=False, error=error)


@dataclass
class PaneState:
    """State of a single pane in the pipeline."""

    id: str
    status: PaneStatus
    operation: str | None = None
    params: dict[str, Any] = field(default_factory=dict)
    files: list[Path] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "status": self.status.value,
            "operation": self.operation,
            "params": self.params,
            "files": [str(f) for f in self.files],
            "error": self.error,
        }
