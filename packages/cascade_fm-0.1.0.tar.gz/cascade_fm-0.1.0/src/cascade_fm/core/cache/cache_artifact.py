"""Artifact-cache mixin for operations."""

from __future__ import annotations

from cascade_fm.operations.base import CommitIntent


class ArtifactCacheMixin:
    """Mixin for operations that cache materialized output artifacts."""

    @property
    def caches_artifacts(self) -> bool:
        """Enable artifact caching for this operation."""
        return True

    @property
    def commit_intent(self) -> CommitIntent:
        """Artifact-producing operations commit their materialized outputs."""
        return CommitIntent.MATERIALIZED_OUTPUTS
