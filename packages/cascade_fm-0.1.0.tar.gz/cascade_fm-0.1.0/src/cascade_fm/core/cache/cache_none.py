"""No-cache mixin for operations."""

from __future__ import annotations


class NoCacheMixin:
    """Mixin for operations that should never use cache."""

    @property
    def caches_artifacts(self) -> bool:
        """Disable artifact caching for this operation."""
        return False
