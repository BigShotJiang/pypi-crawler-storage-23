"""Core namespace bridge for system file opening."""

from __future__ import annotations

from cascade_fm.system_open import open_in_default_app

__all__ = ["open_in_default_app"]
