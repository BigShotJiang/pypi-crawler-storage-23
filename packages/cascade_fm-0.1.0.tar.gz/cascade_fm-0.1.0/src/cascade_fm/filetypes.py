"""Backward-compatible import shim for `cascade_fm.filetypes`."""

from __future__ import annotations

from cascade_fm.core.filetypes import classify_file_type, detect_mime_type, summarize_file_types

__all__ = ["detect_mime_type", "classify_file_type", "summarize_file_types"]
