"""Backward-compatible import shim for `cascade_fm.executor`."""

from __future__ import annotations

from cascade_fm.core.executor import OperationExecutor

__all__ = ["OperationExecutor"]
