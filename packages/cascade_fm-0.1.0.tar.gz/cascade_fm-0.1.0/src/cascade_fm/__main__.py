"""Enable 'python -m cascade'."""

from __future__ import annotations

import sys

from cascade_fm.cli import main

if __name__ == "__main__":
    sys.exit(main())
