# Tests Overview

This folder is split by test scope so release confidence is clear.

## Structure

- `tests/unit/`
  - Fast, isolated tests for single modules/functions.
  - No external services and minimal filesystem/process overhead.
  - Runs on every local/CI quality cycle.

- `tests/component/`
  - Cross-module integration checks (CLI ↔ API ↔ pipeline/commit behavior).
  - Uses realistic subprocess/filesystem interactions.
  - Marked with `@pytest.mark.component`.

- `tests/manual/`
  - Human-executed release workflows/checklists.
  - Current release checklist: `tests/manual/test-workflows.md`.

## Typical commands

```bash
# all tests
uv run pytest -q

# unit only
uv run pytest -q -k "not component" tests/unit

# component only
uv run pytest -q -m component tests/component
```

## Release intent

Before release, run:

1. Automated suite (unit + component)
2. Manual release checklist in `tests/manual/test-workflows.md`
