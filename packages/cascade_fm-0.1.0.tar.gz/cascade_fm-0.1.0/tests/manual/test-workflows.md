# Manual Test Workflows

This file contains manual test workflows for release validation.

## Workflow 1: MVP end-to-end (browse -> filter -> save)

1. Start app: `uv run cascade`
2. In browser pane, open a folder containing mixed files.
3. Use browser filtering to narrow selection:
   - set **Type** filter to `image` and/or
   - set **Name** filter pattern (for example `*.jpg`).
4. Select the filtered files.
5. Add operation: `save_to`.
6. Choose an empty target directory.
7. Execute and verify output files are written to target.

Expected:
- Pane states move through configured/executing/done.
- Only filtered files are written.
- No writes happen before `save_to`.

## Workflow 2: Conflict policy behavior

1. Re-run Workflow 1 so target already contains output files.
2. In `save_to`, test each conflict policy:
   - `overwrite`
   - `skip`
   - `fail`

Expected:
- `overwrite`: destination files are replaced.
- `skip`: existing files remain unchanged and skipped count is reflected.
- `fail`: pane enters error state and shows conflict message.

## Workflow 3: Session restore prompt

1. Build a pipeline with 2-3 operation panes.
2. Close app.
3. Re-open app.
4. Accept restore prompt.

Expected:
- Restore prompt appears.
- Pipeline panes and params are restored.

## Workflow 4: Clear saved session intent

Method A (from restore prompt):
1. Build a small pipeline and close app.
2. Re-open app.
3. On restore prompt, click **No**.
4. Close and re-open app again.

Expected:
- No prior session is restored on the second restart.

Method B (from running app):
1. Build or restore a pipeline.
2. Click sidebar **Cancel workflow** (`✕`).
3. Close and re-open app.

Expected:
- Workflow is cleared immediately.
- No prior session is restored on next startup.

## Workflow 5: Stale-session skip

1. Ensure a saved session exists.
2. Start app with: `CASCADE_RESTORE_MAX_AGE_SECONDS=0 uv run cascade`

Expected:
- Restore prompt is not shown.
- Browser status indicates stale session snapshot was skipped.

## Workflow 6: Archive and image operation sanity

1. Select files and run `create_archive` (zip).
2. Select created archive and run `unarchive`.
3. Select image file and run `image_transform` (e.g. resize).

Expected:
- Operations complete successfully.
- Progress/status updates are visible.
- UI remains responsive during execution.

---

## Manual Test Run Record

### Run: 2026-02-28

Release-readiness manual workflows:

- Workflow 1 — MVP end-to-end: ✅ Passed
- Workflow 2 — Conflict policy behavior: ✅ Passed
- Workflow 3 — Session restore prompt: ✅ Passed
- Workflow 4 — Clear saved session intent: ✅ Passed
- Workflow 5 — Stale-session skip: ✅ Passed
- Workflow 6 — Archive and image operation sanity: ✅ Passed

Notes:

- Session restore behavior was validated after fixes for browser context/selection restore.
- Selection-aware execution between panes was validated (upstream pane selection constrains next pane input).
