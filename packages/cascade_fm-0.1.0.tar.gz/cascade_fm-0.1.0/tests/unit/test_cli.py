"""Unit tests for cascade.cli."""

from __future__ import annotations

import json
from unittest.mock import patch

from cascade_fm.cli import main


@patch("cascade_fm.cli.launch_gui")
def test_main_no_args(mock_launch_gui) -> None:
    """Test main() with no arguments."""
    mock_launch_gui.return_value = 0
    result = main([])
    assert result == 0
    mock_launch_gui.assert_called_once()


@patch("cascade_fm.cli.launch_gui")
def test_main_verbose(mock_launch_gui) -> None:
    """Test main() with verbose flag."""
    mock_launch_gui.return_value = 0
    result = main(["--verbose"])
    assert result == 0
    mock_launch_gui.assert_called_once()


def test_main_help() -> None:
    """Test main() with --help flag."""
    try:
        main(["--help"])
    except SystemExit as e:
        assert e.code == 0


def test_main_version() -> None:
    """Test main() with --version flag."""
    try:
        main(["--version"])
    except SystemExit as e:
        assert e.code == 0


@patch("builtins.print")
def test_main_commit_summary_text(mock_print) -> None:
    """Test commit-summary subcommand plain text output."""
    result = main(["commit-summary", "--committed", "2", "--skipped", "1", "--failed", "0"])

    assert result == 0
    mock_print.assert_called_once_with("⚠ Committed 2, skipped 1")


@patch("builtins.print")
def test_main_commit_summary_json(mock_print) -> None:
    """Test commit-summary subcommand JSON output."""
    result = main(
        [
            "commit-summary",
            "--committed",
            "1",
            "--skipped",
            "0",
            "--failed",
            "2",
            "--json",
        ]
    )

    assert result == 0
    payload = json.loads(mock_print.call_args[0][0])
    assert payload == {
        "committed": 1,
        "failed": 2,
        "level": "warning",
        "message": "⚠ Committed 1, skipped 0, failed 2",
        "skipped": 0,
    }
