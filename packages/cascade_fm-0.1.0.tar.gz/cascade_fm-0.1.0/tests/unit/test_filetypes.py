"""Unit tests for file type recognition helpers."""

from __future__ import annotations

from pathlib import Path

from cascade_fm.filetypes import classify_file_type, detect_mime_type, summarize_file_types


def test_detect_mime_type_directory(tmp_path: Path) -> None:
    """Directory paths should resolve to directory mime type."""
    assert detect_mime_type(tmp_path) == "inode/directory"


def test_detect_mime_type_by_extension(tmp_path: Path) -> None:
    """Known file extensions should map to expected mime types."""
    file_path = tmp_path / "photo.jpg"
    file_path.write_text("x")

    assert detect_mime_type(file_path) == "image/jpeg"


def test_detect_mime_type_unknown_extension(tmp_path: Path) -> None:
    """Unknown file extensions should fall back to octet-stream."""
    file_path = tmp_path / "blob.unknown_ext"
    file_path.write_text("x")

    assert detect_mime_type(file_path) == "application/octet-stream"


def test_detect_mime_type_archive_suffix_fallback_tar_gz(tmp_path: Path) -> None:
    """Archive suffix fallback should detect tar.gz files as tar archives."""
    file_path = tmp_path / "bundle.tar.gz"
    file_path.write_text("x")

    assert detect_mime_type(file_path) == "application/x-tar"


def test_detect_mime_type_archive_suffix_fallback_gz(tmp_path: Path) -> None:
    """Archive suffix fallback should detect gzip-compressed files."""
    file_path = tmp_path / "nested_archive.gz"
    file_path.write_text("x")

    assert detect_mime_type(file_path) == "application/gzip"


def test_classify_file_type() -> None:
    """Mime type classification should map to expected categories."""
    assert classify_file_type("inode/directory") == "directory"
    assert classify_file_type("image/png") == "image"
    assert classify_file_type("video/mp4") == "video"
    assert classify_file_type("audio/mpeg") == "audio"
    assert classify_file_type("text/plain") == "text"
    assert classify_file_type("application/pdf") == "document"
    assert classify_file_type("application/octet-stream") == "other"


def test_summarize_file_types(tmp_path: Path) -> None:
    """Summary should include stable count/category output."""
    image_file = tmp_path / "a.jpg"
    text_file = tmp_path / "b.txt"
    image_file.write_text("a")
    text_file.write_text("b")

    summary = summarize_file_types([image_file, text_file, tmp_path])

    assert summary == "1 directory, 1 image, 1 text"
