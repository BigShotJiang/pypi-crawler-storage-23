"""Component/integration tests for cascade CLI."""

from __future__ import annotations

import json
import subprocess
import sys

import pytest


@pytest.mark.component
def test_cli_entrypoint() -> None:
    """Test CLI entry point via console script."""
    result = subprocess.run(
        ["cascade", "--help"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert (
        "A visual, pipeline-driven file manager that turns file operations into composable, repeatable workflows."
        in result.stdout
        or "usage:" in result.stdout
    )


@pytest.mark.component
def test_cli_module_invocation() -> None:
    """Test CLI via python -m invocation."""
    result = subprocess.run(
        [sys.executable, "-m", "cascade_fm", "--help"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert (
        "A visual, pipeline-driven file manager that turns file operations into composable, repeatable workflows."
        in result.stdout
        or "usage:" in result.stdout
    )


@pytest.mark.component
def test_cli_version() -> None:
    """Test CLI --version flag."""
    result = subprocess.run(
        ["cascade", "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert result.stdout.startswith("cascade ")


@pytest.mark.component
def test_cli_commit_summary_json_contract() -> None:
    """CLI commit-summary --json should return the shared API payload contract."""
    result = subprocess.run(
        [
            "cascade",
            "commit-summary",
            "--committed",
            "2",
            "--skipped",
            "1",
            "--failed",
            "0",
            "--json",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0

    payload = json.loads(result.stdout)
    assert payload["level"] == "warning"
    assert payload["message"] == "⚠ Committed 2, skipped 1"
    assert payload["committed"] == 2
    assert payload["skipped"] == 1
    assert payload["failed"] == 0
