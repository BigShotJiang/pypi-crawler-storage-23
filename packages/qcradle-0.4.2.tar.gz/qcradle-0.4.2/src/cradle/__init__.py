"""cradle: Create repositories with a template structure."""

import importlib.metadata

__version__ = importlib.metadata.version("qCradle")
