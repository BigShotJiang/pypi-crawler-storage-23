"""Agentwork MCP server — exposes task management tools for AI agents.

Supports stdio (default) and Streamable HTTP transports.
"""

import argparse
import importlib.metadata
import json
import os

from mcp.server.fastmcp import FastMCP

from agentwork_mcp.client import AgentworkClient

mcp = FastMCP(
    "Agentwork",
    instructions=(
        "Agentwork lets you delegate tasks to AI agents. "
        "Create a task, poll its status, respond to questions, "
        "approve or reject plans and solutions, and fetch the final result."
    ),
    host="0.0.0.0",
    port=int(os.environ.get("PORT", "8000")),
)

_client = AgentworkClient()


def _require_api_key(api_key: str) -> str:
    key = api_key.strip()
    if not key:
        raise RuntimeError("api_key is required for this tool")
    return key


# ------------------------------------------------------------------
# Tools
# ------------------------------------------------------------------


@mcp.tool()
async def agentwork_register(
    email: str,
    name: str = "",
    organization_name: str = "",
) -> str:
    """Register a new Agentwork account and get an API key.

    Call this first if you don't have an API key yet. You only need to
    provide an email address.

    Args:
        email: Your email address (so the Agentwork team can contact you).
        name: Your name (optional).
        organization_name: Organization name (optional, auto-generated if omitted).

    Returns:
        JSON with api_key, organization_id, and user_id.
    """
    result = await _client.register(email, name, organization_name)
    return json.dumps(result, indent=2)


@mcp.tool()
async def agentwork_create_task(
    title: str,
    description: str,
    api_key: str,
) -> str:
    """Create a new task on Agentwork.

    Args:
        title: Short title for the task (max ~70 chars).
        description: Detailed description of what you need done.
        api_key: Your Agentwork API key.

    Returns:
        JSON with task_id and initial status.
    """
    result = await _client.create_task(
        title,
        description,
        api_key=_require_api_key(api_key),
    )
    return json.dumps(result, indent=2)


@mcp.tool()
async def agentwork_get_task_status(
    task_id: str,
    api_key: str,
) -> str:
    """Check the current status of a task.

    The response tells you what action is needed:
    - "processing": The agent is working. Poll again later.
    - "awaiting_reply": The agent asked a question. Use agentwork_send_message to reply.
    - "awaiting_spec_approval": A plan was proposed. Use agentwork_approve_spec to accept/reject.
    - "awaiting_solution_approval": A solution was proposed. Use agentwork_approve_solution to accept/reject.
    - "completed": The task is done. Use agentwork_get_task_result to fetch the output.

    Args:
        task_id: The task ID returned by agentwork_create_task.
        api_key: Your Agentwork API key.

    Returns:
        JSON with task_id, title, status, and optional question/spec/solution details.
    """
    result = await _client.get_task_status(task_id, api_key=_require_api_key(api_key))
    return json.dumps(result, indent=2)


@mcp.tool()
async def agentwork_send_message(
    task_id: str,
    message: str,
    api_key: str,
) -> str:
    """Reply to a question from the Agentwork agent.

    Use this when agentwork_get_task_status returns status "awaiting_reply".
    This covers clarifying questions, accuracy level selection, and general follow-ups.

    Args:
        task_id: The task ID.
        message: Your reply to the agent's question.
        api_key: Your Agentwork API key.

    Returns:
        JSON with success status.
    """
    result = await _client.send_message(
        task_id,
        message,
        api_key=_require_api_key(api_key),
    )
    return json.dumps(result, indent=2)


@mcp.tool()
async def agentwork_approve_spec(
    task_id: str,
    approved: bool,
    api_key: str,
    rejection_reason: str = "",
) -> str:
    """Approve or reject the proposed spec/plan.

    Use this when agentwork_get_task_status returns status "awaiting_spec_approval".

    Args:
        task_id: The task ID.
        approved: True to approve, False to reject.
        api_key: Your Agentwork API key.
        rejection_reason: If rejecting, explain what changes you want.

    Returns:
        JSON with success and new status.
    """
    result = await _client.approve_spec(
        task_id,
        approved,
        api_key=_require_api_key(api_key),
        rejection_reason=rejection_reason or None,
    )
    return json.dumps(result, indent=2)


@mcp.tool()
async def agentwork_approve_solution(
    task_id: str,
    approved: bool,
    api_key: str,
    rejection_reason: str = "",
) -> str:
    """Approve or reject the proposed solution.

    Use this when agentwork_get_task_status returns status "awaiting_solution_approval".

    Args:
        task_id: The task ID.
        approved: True to approve, False to reject.
        api_key: Your Agentwork API key.
        rejection_reason: If rejecting, explain what needs to change.

    Returns:
        JSON with success and new status.
    """
    result = await _client.approve_solution(
        task_id,
        approved,
        api_key=_require_api_key(api_key),
        rejection_reason=rejection_reason or None,
    )
    return json.dumps(result, indent=2)


@mcp.tool()
async def agentwork_get_task_result(
    task_id: str,
    api_key: str,
) -> str:
    """Fetch the completed result of a task (text + file URLs).

    Use this when agentwork_get_task_status returns status "completed".

    Args:
        task_id: The task ID.
        api_key: Your Agentwork API key.

    Returns:
        JSON with result_text and a list of downloadable files.
    """
    result = await _client.get_task_result(task_id, api_key=_require_api_key(api_key))
    return json.dumps(result, indent=2)


@mcp.tool()
async def agentwork_cancel_task(
    task_id: str,
    api_key: str,
) -> str:
    """Cancel a running task.

    Args:
        task_id: The task ID to cancel.
        api_key: Your Agentwork API key.

    Returns:
        JSON with success status.
    """
    result = await _client.cancel_task(task_id, api_key=_require_api_key(api_key))
    return json.dumps(result, indent=2)


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description="Agentwork MCP Server")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {importlib.metadata.version('agentwork-mcp')}",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http"],
        default="stdio",
        help="Transport to use (default: stdio)",
    )
    args = parser.parse_args()

    mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
