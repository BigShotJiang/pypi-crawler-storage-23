"""HTTP client wrapper for the Agentwork public API."""

from typing import Any

import httpx

from agentwork_mcp.config import AGENTWORK_BASE_URL


class AgentworkClient:
    """Thin async wrapper around the Agentwork /api/v1 endpoints."""

    def __init__(
        self,
        base_url: str = AGENTWORK_BASE_URL,
    ) -> None:
        self.base_url = base_url.rstrip("/")

    def _url(self, path: str) -> str:
        return f"{self.base_url}/api/v1{path}"

    @staticmethod
    def _headers(api_key: str | None = None) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    async def _request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        api_key: str | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.request(
                method,
                self._url(path),
                headers=self._headers(api_key),
                json=json,
            )
            resp.raise_for_status()
            return resp.json()

    # ------------------------------------------------------------------
    # Auth (unauthenticated — no API key required)
    # ------------------------------------------------------------------

    async def register(
        self,
        email: str,
        name: str = "",
        organization_name: str = "",
    ) -> dict[str, Any]:
        """Register a new account and get an API key back."""
        body: dict[str, Any] = {"email": email}
        if name:
            body["name"] = name
        if organization_name:
            body["organization_name"] = organization_name
        # No auth header for registration
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                self._url("/auth/register"),
                headers=self._headers(),
                json=body,
            )
            resp.raise_for_status()
            return resp.json()

    # ------------------------------------------------------------------
    # Task operations
    # ------------------------------------------------------------------

    async def create_task(self, title: str, description: str, api_key: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/tasks/",
            json={"title": title, "description": description},
            api_key=api_key,
        )

    async def get_task_status(self, task_id: str, api_key: str) -> dict[str, Any]:
        return await self._request("GET", f"/tasks/{task_id}", api_key=api_key)

    async def get_task_result(self, task_id: str, api_key: str) -> dict[str, Any]:
        return await self._request("GET", f"/tasks/{task_id}/result", api_key=api_key)

    async def send_message(self, task_id: str, message: str, api_key: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            f"/tasks/{task_id}/message",
            json={"message": message},
            api_key=api_key,
        )

    async def approve_spec(
        self,
        task_id: str,
        approved: bool,
        api_key: str,
        rejection_reason: str | None = None,
    ) -> dict[str, Any]:
        status = "CONFIRMED" if approved else "REJECTED"
        body: dict[str, Any] = {"status": status}
        if rejection_reason:
            body["rejection_reason"] = rejection_reason
        return await self._request(
            "POST",
            f"/tasks/{task_id}/spec-status",
            json=body,
            api_key=api_key,
        )

    async def approve_solution(
        self,
        task_id: str,
        approved: bool,
        api_key: str,
        rejection_reason: str | None = None,
    ) -> dict[str, Any]:
        status = "CONFIRMED" if approved else "REJECTED"
        body: dict[str, Any] = {"status": status}
        if rejection_reason:
            body["rejection_reason"] = rejection_reason
        return await self._request(
            "POST",
            f"/tasks/{task_id}/solution-status",
            json=body,
            api_key=api_key,
        )

    async def cancel_task(self, task_id: str, api_key: str) -> dict[str, Any]:
        return await self._request("POST", f"/tasks/{task_id}/cancel", api_key=api_key)

    async def list_tasks(self, api_key: str) -> dict[str, Any]:
        return await self._request("GET", "/tasks/", api_key=api_key)
