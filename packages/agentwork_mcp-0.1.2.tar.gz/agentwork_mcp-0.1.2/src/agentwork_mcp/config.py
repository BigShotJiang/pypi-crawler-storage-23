"""Configuration for the Agentwork MCP server."""

import os

AGENTWORK_BASE_URL = os.environ.get("AGENTWORK_BASE_URL", "https://agentwork.so").rstrip("/")
