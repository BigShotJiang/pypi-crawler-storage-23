"""Allow running with `python -m agentwork_mcp`."""

from agentwork_mcp.server import main

main()
