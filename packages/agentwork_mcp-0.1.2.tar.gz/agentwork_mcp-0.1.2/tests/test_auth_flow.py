import json
from unittest.mock import AsyncMock

import pytest

from agentwork_mcp import server


def test_require_api_key_rejects_blank():
    with pytest.raises(RuntimeError):
        server._require_api_key("")

    with pytest.raises(RuntimeError):
        server._require_api_key("   ")


@pytest.mark.asyncio
async def test_register_is_unauthenticated(monkeypatch):
    register = AsyncMock(
        return_value={"api_key": "aw_live_bootstrap", "organization_id": "org", "user_id": "user"}
    )
    monkeypatch.setattr(server._client, "register", register)

    payload = await server.agentwork_register("user@example.com")

    assert json.loads(payload)["api_key"] == "aw_live_bootstrap"
    register.assert_awaited_once_with("user@example.com", "", "")


@pytest.mark.asyncio
async def test_create_task_requires_api_key(monkeypatch):
    create_task = AsyncMock(return_value={"task_id": "task-1", "status": "processing"})
    monkeypatch.setattr(server._client, "create_task", create_task)

    with pytest.raises(RuntimeError):
        await server.agentwork_create_task("Build page", "Details", api_key="")

    create_task.assert_not_awaited()


@pytest.mark.asyncio
async def test_create_task_passes_explicit_api_key(monkeypatch):
    create_task = AsyncMock(return_value={"task_id": "task-2", "status": "processing"})
    monkeypatch.setattr(server._client, "create_task", create_task)

    payload = await server.agentwork_create_task(
        "Build page",
        "Details",
        api_key="aw_live_explicit",
    )

    assert json.loads(payload)["task_id"] == "task-2"
    create_task.assert_awaited_once_with("Build page", "Details", api_key="aw_live_explicit")


@pytest.mark.asyncio
async def test_approve_solution_requires_api_key(monkeypatch):
    approve_solution = AsyncMock(return_value={"success": True, "status": "completed"})
    monkeypatch.setattr(server._client, "approve_solution", approve_solution)

    with pytest.raises(RuntimeError):
        await server.agentwork_approve_solution("task-1", approved=True, api_key="")

    approve_solution.assert_not_awaited()
