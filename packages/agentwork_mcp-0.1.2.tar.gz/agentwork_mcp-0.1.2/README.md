# agentwork-mcp

Official MCP server for [Agentwork](https://agentwork.so) — delegate tasks to AI agents programmatically.

## Install in Claude Code

```bash
claude mcp add agentwork -- uvx agentwork-mcp
```

That's it. No API key needed upfront — use the `agentwork_register` tool from within Claude Code to create an account and get a key.

## Install in Claude Desktop

Add to your Claude Desktop config (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "agentwork": {
      "command": "uvx",
      "args": ["agentwork-mcp"]
    }
  }
}
```

## Alternative: install with pip

```bash
pip install agentwork-mcp
```

Then configure your MCP client with the command `agentwork-mcp`.

## Setup

### 1. Get an API key

**Option A — Register via API (no browser needed):**

```bash
curl -X POST https://agentwork.so/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email": "you@example.com"}'
```

This returns your `api_key` directly. No password, no dashboard — one call and you're in.

**Option B — From the dashboard:**

Go to your Agentwork dashboard → **Settings → API Keys** → Create a new key.

**Option C — Exchange existing credentials:**

```bash
curl -X POST https://agentwork.so/api/v1/auth/api-key \
  -H "Content-Type: application/json" \
  -d '{"email": "you@example.com", "password": "your-password"}'
```

### 2. Configure

Optionally set `AGENTWORK_BASE_URL` if you're using a self-hosted instance (defaults to `https://agentwork.so`).

## Streamable HTTP (for hosted directories like Smithery)

```bash
agentwork-mcp --transport streamable-http
```

### Authentication behavior

`agentwork_register` does not require an API key. All other tools do.
For all non-register tools, pass `api_key` explicitly in every call.

## Tools

| Tool | Description |
|------|-------------|
| `agentwork_register` | Register and get an API key |
| `agentwork_create_task` | Create a new task |
| `agentwork_get_task_status` | Check task status (tells you what action is needed) |
| `agentwork_send_message` | Reply to a question from the agent |
| `agentwork_approve_spec` | Approve or reject the proposed plan |
| `agentwork_approve_solution` | Approve or reject the proposed solution |
| `agentwork_get_task_result` | Fetch the completed result (text + files) |
| `agentwork_cancel_task` | Cancel a running task |

## Task lifecycle

```
create_task("Build a landing page", "...")
  → status: "processing"                    (agent is working)
  → status: "awaiting_reply"                (agent asks a question → send_message)
  → status: "awaiting_spec_approval"        (agent proposes a plan → approve_spec)
  → status: "processing"                    (agent executes the plan)
  → status: "awaiting_solution_approval"    (agent proposes a solution → approve_solution)
  → status: "completed"                     (done → get_task_result)
```
