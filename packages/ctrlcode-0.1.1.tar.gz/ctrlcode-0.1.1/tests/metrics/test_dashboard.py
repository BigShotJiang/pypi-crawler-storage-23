"""Tests for MetricsDashboard."""

from datetime import datetime

import pytest

from ctrlcode.embeddings.embedder import CodeEmbedder
from ctrlcode.metrics.dashboard import MetricsDashboard, MetricsSummary
from ctrlcode.storage.history_db import (
    BugPattern,
    CodeRecord,
    FuzzingSession,
    HistoryDB,
    OracleRecord,
    StoredTest,
)


@pytest.fixture
def populated_db():
    """Create in-memory database with sample data."""
    db = HistoryDB(":memory:")
    embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

    # Create 5 sessions: 2 with oracle reuse, 3 fresh
    for i in range(5):
        oracle_reused = i < 2  # First 2 sessions reuse oracles
        session = FuzzingSession(
            session_id=f"session_{i}",
            user_request=f"Request {i}",
            generated_code=f"code_{i}",
            oracle=f"oracle_{i}",
            timestamp=datetime.now(),
            num_tests=10 + i,
            num_failures=i,
            oracle_reused=oracle_reused,
            reused_from=f"session_old_{i}" if oracle_reused else None,
            quality_score=0.8 + (i * 0.05),
        )
        db.store_session(session)

        # Store code
        code_embedding = embedder.embed_code(f"code_{i}")
        code_record = CodeRecord(
            code_id=f"code_{i}",
            session_id=f"session_{i}",
            code=f"code_{i}",
            embedding=code_embedding,
            timestamp=datetime.now(),
        )
        db.store_code(code_record)

        # Store oracle
        oracle_embedding = embedder.embed_oracle(f"oracle_{i}")
        oracle_record = OracleRecord(
            oracle_id=f"oracle_{i}",
            session_id=f"session_{i}",
            oracle=f"oracle_{i}",
            embedding=oracle_embedding,
            quality_score=0.9,
            timestamp=datetime.now(),
        )
        db.store_oracle(oracle_record)

    # Add some bugs
    for i in range(3):
        bug_embedding = embedder.embed_code(f"bug_code_{i}")
        bug = BugPattern(
            bug_id=f"bug_{i}",
            session_id=f"session_{i}",
            bug_description=f"Bug {i}",
            code_snippet=f"buggy code {i}",
            embedding=bug_embedding,
            severity="high",
            timestamp=datetime.now(),
        )
        db.store_bug(bug)

    # Add some tests
    for i in range(20):
        test_embedding = embedder.embed_test_case(f"test_{i}")
        test = StoredTest(
            test_id=f"test_{i}",
            session_id=f"session_{i % 5}",
            test_code=f"test_{i}",
            embedding=test_embedding,
            passed=i % 3 != 0,  # ~67% pass rate
            timestamp=datetime.now(),
        )
        db.store_test(test)

    return db


def test_dashboard_initialization(populated_db):
    """Test dashboard initializes correctly."""
    dashboard = MetricsDashboard(populated_db)
    assert dashboard.history_db is populated_db


def test_get_summary(populated_db):
    """Test getting metrics summary."""
    dashboard = MetricsDashboard(populated_db)
    summary = dashboard.get_summary()

    assert isinstance(summary, MetricsSummary)
    assert summary.total_sessions == 5
    assert summary.sessions_with_oracle_reuse == 2
    assert summary.oracle_reuse_rate == 0.4  # 2/5 = 40%
    assert summary.total_bugs_in_db == 3
    assert summary.total_tests == 20


def test_oracle_reuse_rate_calculation(populated_db):
    """Test oracle reuse rate is calculated correctly."""
    dashboard = MetricsDashboard(populated_db)
    summary = dashboard.get_summary()

    # 2 out of 5 sessions reused oracles
    assert summary.oracle_reuse_rate == 0.4


def test_estimated_savings(populated_db):
    """Test estimated token and time savings."""
    dashboard = MetricsDashboard(populated_db)
    summary = dashboard.get_summary()

    # 2 oracle reuses * 2500 tokens each = 5000 tokens
    assert summary.estimated_token_savings == 5000

    # 2 oracle reuses avoided
    assert summary.estimated_llm_call_savings == 2

    # 2 reuses * 25 seconds each = 50 seconds
    assert summary.estimated_time_savings_seconds == 50.0


def test_format_report(populated_db):
    """Test report formatting."""
    dashboard = MetricsDashboard(populated_db)
    report = dashboard.format_report()

    assert "HISTORICAL LEARNING METRICS DASHBOARD" in report
    assert "Total fuzzing sessions: 5" in report
    assert "Sessions with oracle reuse: 2" in report
    assert "Oracle reuse rate: 40.0%" in report
    assert "Bug patterns in database: 3" in report
    assert "Total tests executed: 20" in report
    assert "Token savings: 5,000 tokens" in report
    assert "LLM calls avoided: 2" in report


def test_format_report_with_summary(populated_db):
    """Test formatting report with pre-computed summary."""
    dashboard = MetricsDashboard(populated_db)
    summary = dashboard.get_summary()
    report = dashboard.format_report(summary)

    # Should produce same report as without summary
    assert "Oracle reuse rate: 40.0%" in report


def test_kpi_indicators(populated_db):
    """Test KPI indicator messages."""
    dashboard = MetricsDashboard(populated_db)
    report = dashboard.format_report()

    # With 40% reuse rate, should show EXCELLENT
    assert "EXCELLENT" in report or "GOOD" in report


def test_empty_database():
    """Test dashboard with empty database."""
    empty_db = HistoryDB(":memory:")
    dashboard = MetricsDashboard(empty_db)
    summary = dashboard.get_summary()

    assert summary.total_sessions == 0
    assert summary.oracle_reuse_rate == 0.0
    assert summary.estimated_token_savings == 0


def test_empty_database_report():
    """Test report formatting with empty database."""
    empty_db = HistoryDB(":memory:")
    dashboard = MetricsDashboard(empty_db)
    report = dashboard.format_report()

    assert "Total fuzzing sessions: 0" in report
    assert "Limited data" in report or "LOW" in report


def test_calculate_roi(populated_db):
    """Test ROI calculation."""
    dashboard = MetricsDashboard(populated_db)
    roi = dashboard.calculate_roi()

    assert "total_cost_usd" in roi
    assert "total_benefit_usd" in roi
    assert "net_savings_usd" in roi
    assert "roi_percentage" in roi

    # Should have positive ROI
    assert roi["net_savings_usd"] > 0
    assert roi["roi_percentage"] > 0


def test_roi_breakdown(populated_db):
    """Test ROI includes token and time savings breakdown."""
    dashboard = MetricsDashboard(populated_db)
    roi = dashboard.calculate_roi()

    assert "token_savings_value_usd" in roi
    assert "time_savings_value_usd" in roi

    # Both should contribute to total benefit
    total_benefit = roi["token_savings_value_usd"] + roi["time_savings_value_usd"]
    assert abs(total_benefit - roi["total_benefit_usd"]) < 0.01  # Allow floating point error


def test_get_trend_data(populated_db):
    """Test getting trend data."""
    dashboard = MetricsDashboard(populated_db)
    trends = dashboard.get_trend_data(days=30)

    # Should return structure (even if empty for now)
    assert "oracle_reuse_by_day" in trends
    assert "sessions_by_day" in trends
    assert "quality_by_day" in trends
    assert "bugs_detected_by_day" in trends


def test_get_top_oracles(populated_db):
    """Test getting top oracles."""
    dashboard = MetricsDashboard(populated_db)
    top_oracles = dashboard.get_top_oracles(limit=5)

    # Should return list (even if empty for now)
    assert isinstance(top_oracles, list)


def test_get_common_bug_patterns(populated_db):
    """Test getting common bug patterns."""
    dashboard = MetricsDashboard(populated_db)
    common_bugs = dashboard.get_common_bug_patterns(limit=5)

    # Should return list (even if empty for now)
    assert isinstance(common_bugs, list)


def test_avg_tests_per_session(populated_db):
    """Test average tests per session calculation."""
    dashboard = MetricsDashboard(populated_db)
    summary = dashboard.get_summary()

    # 20 total tests / 5 sessions = 4 tests per session
    assert summary.avg_tests_per_session == 4.0


def test_test_pass_rate(populated_db):
    """Test pass rate calculation."""
    dashboard = MetricsDashboard(populated_db)
    summary = dashboard.get_summary()

    # Created with ~67% pass rate in fixture
    assert 0.6 <= summary.avg_test_pass_rate <= 0.7
