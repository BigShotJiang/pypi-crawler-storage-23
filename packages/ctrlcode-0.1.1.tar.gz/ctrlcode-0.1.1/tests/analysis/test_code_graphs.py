"""Tests for CodeGraphBuilder."""

import pytest

from ctrlcode.analysis.code_graphs import CodeGraphBuilder, CodeGraphs, SymbolInfo


@pytest.fixture
def builder():
    """Create graph builder instance."""
    return CodeGraphBuilder()


def test_empty_code(builder):
    """Test building graphs from empty code."""
    graphs = builder.build_from_code("", "test.py")

    assert graphs.function_count == 0
    assert graphs.class_count == 0
    assert graphs.file_count == 0


def test_simple_function(builder):
    """Test extracting a single function."""
    code = """
def add(a, b):
    return a + b
"""
    graphs = builder.build_from_code(code, "test.py")

    assert graphs.function_count == 1
    assert "add" in graphs.export_map
    assert graphs.export_map["add"].symbol_type == "function"
    assert graphs.export_map["add"].line == 2
    assert graphs.export_map["add"].scope == "module"


def test_multiple_functions(builder):
    """Test extracting multiple functions."""
    code = """
def foo():
    pass

def bar():
    pass

def baz():
    pass
"""
    graphs = builder.build_from_code(code, "test.py")

    assert graphs.function_count == 3
    assert "foo" in graphs.export_map
    assert "bar" in graphs.export_map
    assert "baz" in graphs.export_map


def test_class_definition(builder):
    """Test extracting class."""
    code = """
class MyClass:
    def __init__(self):
        pass

    def method(self):
        pass
"""
    graphs = builder.build_from_code(code, "test.py")

    assert graphs.class_count == 1
    assert "MyClass" in graphs.export_map
    assert graphs.export_map["MyClass"].symbol_type == "class"

    # Methods should be recorded with class prefix
    assert "MyClass.__init__" in graphs.export_map
    assert "MyClass.method" in graphs.export_map
    assert graphs.export_map["MyClass.method"].parent == "MyClass"
    assert graphs.export_map["MyClass.method"].scope == "class"


def test_imports(builder):
    """Test tracking imports."""
    code = """
import os
import sys
from pathlib import Path
from typing import Optional, List
"""
    graphs = builder.build_from_code(code, "test.py")

    assert "test.py" in graphs.import_map
    imports = graphs.import_map["test.py"]
    assert "os" in imports
    assert "sys" in imports
    assert "pathlib" in imports
    assert "typing" in imports


def test_import_aliases(builder):
    """Test import aliases."""
    code = """
import numpy as np
from pathlib import Path as P
"""
    graphs = builder.build_from_code(code, "test.py")

    # Aliases should be recorded as symbols
    assert "np" in graphs.export_map
    assert "P" in graphs.export_map
    assert graphs.export_map["np"].symbol_type == "import"
    assert graphs.export_map["P"].symbol_type == "import"


def test_call_graph_simple(builder):
    """Test building call graph for simple function calls."""
    code = """
def foo():
    bar()
    baz()

def bar():
    pass

def baz():
    pass
"""
    graphs = builder.build_from_code(code, "test.py")

    # foo calls bar and baz
    callees = graphs.get_callees("foo")
    assert "bar" in callees
    assert "baz" in callees

    # bar is called by foo
    callers = graphs.get_callers("bar")
    assert "foo" in callers


def test_call_graph_chained(builder):
    """Test call graph with chained calls."""
    code = """
def a():
    b()

def b():
    c()

def c():
    pass
"""
    graphs = builder.build_from_code(code, "test.py")

    assert graphs.get_callees("a") == ["b"]
    assert graphs.get_callees("b") == ["c"]
    assert graphs.get_callees("c") == []

    assert graphs.get_callers("c") == ["b"]
    assert graphs.get_callers("b") == ["a"]


def test_call_graph_method_calls(builder):
    """Test call graph with method calls."""
    code = """
class MyClass:
    def method1(self):
        self.method2()

    def method2(self):
        pass

def external():
    obj = MyClass()
    obj.method1()
"""
    graphs = builder.build_from_code(code, "test.py")

    # method1 calls method2
    callees = graphs.get_callees("MyClass.method1")
    # Note: self.method2 gets recorded as "self.method2" or "method2" depending on resolution
    assert len(callees) > 0


def test_dependency_graph(builder):
    """Test building dependency graph."""
    code = """
import os
import sys
from pathlib import Path
"""
    graphs = builder.build_from_code(code, "test.py")

    dependencies = graphs.get_dependencies("test.py")
    assert "os" in dependencies
    assert "sys" in dependencies
    assert "pathlib" in dependencies


def test_file_map(builder):
    """Test file symbol mapping."""
    code = """
def func1():
    pass

class Class1:
    def method1(self):
        pass
"""
    graphs = builder.build_from_code(code, "test.py")

    assert "test.py" in graphs.file_map
    symbols = graphs.file_map["test.py"]
    assert "func1" in symbols
    assert "Class1" in symbols
    assert "Class1.method1" in symbols


def test_get_functions_in_file(builder):
    """Test getting functions defined in a file."""
    code = """
def func1():
    pass

def func2():
    pass

class MyClass:
    def method(self):
        pass
"""
    graphs = builder.build_from_code(code, "test.py")

    functions = graphs.get_functions_in_file("test.py")
    assert "func1" in functions
    assert "func2" in functions
    assert "MyClass.method" in functions


def test_async_functions(builder):
    """Test extracting async functions."""
    code = """
async def async_func():
    await something()

def sync_func():
    pass
"""
    graphs = builder.build_from_code(code, "test.py")

    assert "async_func" in graphs.export_map
    assert "sync_func" in graphs.export_map
    assert graphs.function_count == 2


def test_nested_functions(builder):
    """Test nested function definitions."""
    code = """
def outer():
    def inner():
        pass
    inner()
"""
    graphs = builder.build_from_code(code, "test.py")

    # Outer function should be recorded
    assert "outer" in graphs.export_map

    # Inner function should also be recorded (as nested)
    # Note: Current implementation treats it as separate function
    assert "inner" in graphs.export_map


def test_module_level_calls(builder):
    """Test module-level function calls (outside functions)."""
    code = """
def setup():
    pass

# Module-level call
setup()
"""
    graphs = builder.build_from_code(code, "test.py")

    # setup function should be defined
    assert "setup" in graphs.export_map

    # Module-level calls don't create edges (no current_function)
    # This is expected behavior


def test_syntax_error_handling(builder):
    """Test handling of syntax errors."""
    code = """
def broken(:
    pass
"""
    graphs = builder.build_from_code(code, "test.py")

    # Should return empty graphs without crashing
    assert graphs.function_count == 0


def test_complex_call_patterns(builder):
    """Test various call patterns."""
    code = """
def func():
    # Direct call
    foo()

    # Attribute call
    obj.method()

    # Chained attribute
    obj.attr.method()

    # Builtin
    print("test")

def foo():
    pass
"""
    graphs = builder.build_from_code(code, "test.py")

    callees = graphs.get_callees("func")

    # Should capture various call types
    assert "foo" in callees
    assert len(callees) >= 1


def test_multiple_classes(builder):
    """Test multiple class definitions."""
    code = """
class ClassA:
    def method_a(self):
        pass

class ClassB:
    def method_b(self):
        pass
"""
    graphs = builder.build_from_code(code, "test.py")

    assert graphs.class_count == 2
    assert "ClassA" in graphs.export_map
    assert "ClassB" in graphs.export_map
    assert "ClassA.method_a" in graphs.export_map
    assert "ClassB.method_b" in graphs.export_map


def test_graph_properties(builder):
    """Test graph property accessors."""
    code = """
import os

class MyClass:
    pass

def my_func():
    pass
"""
    graphs = builder.build_from_code(code, "test.py")

    assert graphs.file_count == 1
    assert graphs.function_count == 1
    assert graphs.class_count == 1


def test_empty_call_graph_lookups(builder):
    """Test call graph lookups for non-existent functions."""
    graphs = CodeGraphs()

    assert graphs.get_callers("nonexistent") == []
    assert graphs.get_callees("nonexistent") == []
    assert graphs.get_dependencies("nonexistent") == []
    assert graphs.get_dependents("nonexistent") == []


def test_real_world_example(builder):
    """Test with realistic code example."""
    code = """
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class DataProcessor:
    def __init__(self, config: dict):
        self.config = config

    def process(self, data: list) -> list:
        logger.info("Processing data")
        cleaned = self._clean(data)
        return self._transform(cleaned)

    def _clean(self, data: list) -> list:
        return [x for x in data if x]

    def _transform(self, data: list) -> list:
        return [self._apply_transform(x) for x in data]

    def _apply_transform(self, item):
        return item.upper()

def main():
    processor = DataProcessor({})
    result = processor.process([])
    print(result)
"""
    graphs = builder.build_from_code(code, "example.py")

    # Check symbols extracted
    assert "DataProcessor" in graphs.export_map
    assert "DataProcessor.__init__" in graphs.export_map
    assert "DataProcessor.process" in graphs.export_map
    assert "main" in graphs.export_map

    # Check imports
    assert "logging" in graphs.import_map["example.py"]
    assert "typing" in graphs.import_map["example.py"]

    # Check call relationships
    # process calls _clean and _transform
    process_callees = graphs.get_callees("DataProcessor.process")
    assert any("_clean" in c or "clean" in c for c in process_callees)

    # Verify file mapping
    functions = graphs.get_functions_in_file("example.py")
    assert len(functions) >= 5  # __init__, process, _clean, _transform, _apply_transform, main
