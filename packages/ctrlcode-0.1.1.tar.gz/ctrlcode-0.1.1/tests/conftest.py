"""Global test configuration and fixtures."""

import numpy as np
import pytest
from unittest.mock import MagicMock, patch

from ctrlcode.embeddings.embedder import CodeEmbedder


def _deterministic_embedding(text: str, dim: int = 1536) -> list[float]:
    """Return a deterministic normalized float vector for any text."""
    rng = np.random.RandomState(abs(hash(text)) % (2**31))
    vec = rng.randn(dim).astype(np.float32)
    return (vec / np.linalg.norm(vec)).tolist()


def _make_openai_mock():
    client = MagicMock()

    def _create(*, input, model="text-embedding-3-small", **kwargs):
        texts = input if isinstance(input, list) else [input]
        response = MagicMock()
        response.data = []
        for i, text in enumerate(texts):
            item = MagicMock()
            item.embedding = _deterministic_embedding(text)
            item.index = i
            response.data.append(item)
        return response

    client.embeddings.create.side_effect = _create
    return client


@pytest.fixture(autouse=True)
def mock_openai_client():
    """Patch openai.OpenAI for all tests — no real API calls."""
    mock = _make_openai_mock()
    with patch("openai.OpenAI", return_value=mock):
        yield mock


@pytest.fixture(autouse=True)
def mock_embedder_defaults(monkeypatch):
    """Provide default api_key/base_url so CodeEmbedder() works without args in tests."""
    _original_init = CodeEmbedder.__init__

    def _patched_init(self, api_key="test-key", base_url="http://test/v1", **kwargs):
        _original_init(self, api_key, base_url, **kwargs)

    monkeypatch.setattr(CodeEmbedder, "__init__", _patched_init)
