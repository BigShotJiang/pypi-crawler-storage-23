"""
Demonstration of specialized agents with harness-utils integration.

Run this to verify each agent loads correctly and can be instantiated.
"""

from pathlib import Path
from ctrlcode.agents.registry import AgentRegistry


def demo_agent_loading():
    """Demonstrate loading and inspecting each agent type."""
    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    print("=" * 70)
    print("SPECIALIZED AGENT DEMONSTRATION")
    print("=" * 70)
    print()

    # Get all agent configs
    agents = registry.get_agent_configs()

    for agent_type, config in agents.items():
        print(f"📋 {agent_type.upper()} AGENT")
        print("-" * 70)

        # Load system prompt
        try:
            prompt = registry.load_system_prompt(agent_type)
            prompt_lines = len(prompt.splitlines())
            prompt_chars = len(prompt)

            print(f"Name: {config.name}")
            print(f"Prompt file: {config.system_prompt_path}")
            print(f"Prompt size: {prompt_lines} lines, {prompt_chars} chars")
            print(f"Tools: {', '.join(config.tools) if config.tools else 'None (delegates only)'}")
            print(f"Context limits: protect={config.prune_protect}, min={config.prune_minimum}")
            print()

            # Show first few lines of prompt
            print("Prompt excerpt:")
            for line in prompt.splitlines()[:5]:
                print(f"  {line}")
            print()

        except FileNotFoundError as e:
            print(f"❌ Error: {e}")
            print()

        print()


def demo_tool_access_validation():
    """Demonstrate tool access validation."""
    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    print("=" * 70)
    print("TOOL ACCESS VALIDATION")
    print("=" * 70)
    print()

    # Test cases: (agent_type, tool_name, expected_access)
    test_cases = [
        # Planner
        ("planner", "search_files", True),
        ("planner", "write_file", False),
        ("planner", "task_write", True),

        # Coder
        ("coder", "write_file", True),
        ("coder", "read_file", True),
        ("coder", "task_write", False),

        # Reviewer
        ("reviewer", "read_file", True),
        ("reviewer", "write_file", False),
        ("reviewer", "task_update", True),

        # Executor
        ("executor", "run_command", True),
        ("executor", "fetch", True),
        ("executor", "read_file", False),

        # Orchestrator
        ("orchestrator", "read_file", False),
        ("orchestrator", "run_command", False),
    ]

    for agent_type, tool_name, expected in test_cases:
        actual = registry.validate_tool_access(agent_type, tool_name)
        status = "✓" if actual == expected else "✗"
        access = "ALLOWED" if actual else "DENIED"
        print(f"{status} {agent_type:12} → {tool_name:15} = {access}")

    print()


def demo_agent_specialization():
    """Show how agent specialization enforces separation of concerns."""
    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    print("=" * 70)
    print("AGENT SPECIALIZATION & SEPARATION OF CONCERNS")
    print("=" * 70)
    print()

    agents = {
        "planner": "Decomposes tasks, cannot write code",
        "coder": "Writes code, cannot plan tasks",
        "reviewer": "Reviews code, cannot modify it",
        "executor": "Validates runtime, minimal toolset",
        "orchestrator": "Coordinates workflow, delegates only",
    }

    for agent_type, description in agents.items():
        config = registry.get_agent_configs()[agent_type]
        tools = config.tools

        print(f"🔹 {agent_type.upper()}")
        print(f"   Role: {description}")
        print(f"   Tools: {len(tools)} allowed")

        if tools:
            print(f"   → {', '.join(tools)}")
        else:
            print("   → None (delegates to other agents)")

        print()


def demo_prompt_content():
    """Show key excerpts from each agent's specialized prompt."""
    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    print("=" * 70)
    print("AGENT ROLE DEFINITIONS (from system prompts)")
    print("=" * 70)
    print()

    agent_types = ["planner", "coder", "reviewer", "executor"]

    for agent_type in agent_types:
        prompt = registry.load_system_prompt(agent_type)
        lines = prompt.splitlines()

        print(f"📄 {agent_type.upper()}")
        print("-" * 70)

        # Find "Your Role" section
        for i, line in enumerate(lines):
            if "## Your Role" in line:
                # Print the next 3-5 lines
                for j in range(i + 1, min(i + 6, len(lines))):
                    if lines[j].strip() and not lines[j].startswith("##"):
                        print(f"   {lines[j]}")
                    elif lines[j].startswith("##"):
                        break
                break

        print()


if __name__ == "__main__":
    demo_agent_loading()
    demo_tool_access_validation()
    demo_agent_specialization()
    demo_prompt_content()

    print("=" * 70)
    print("✅ All agents verified successfully!")
    print("=" * 70)
