"""Tests for oracle versioning and quality tracking."""

import tempfile
from datetime import datetime
from pathlib import Path

import numpy as np
import pytest

from ctrlcode.embeddings.embedder import CodeEmbedder
from ctrlcode.storage.history_db import HistoryDB, OracleRecord


class TestOracleVersioning:
    """Test oracle versioning functionality."""

    def test_oracle_record_defaults(self):
        """Test OracleRecord has correct version defaults."""
        record = OracleRecord(
            oracle_id="test_1",
            session_id="session_1",
            oracle="{}",
            embedding=np.zeros(384),
            quality_score=0.9,
            timestamp=datetime.now(),
        )

        assert record.oracle_version == 1
        assert record.parent_oracle_id is None
        assert record.reuse_count == 0

    def test_store_oracle_with_versioning(self):
        """Test storing oracle with version info."""
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # Store parent oracle (v1)
        parent = OracleRecord(
            oracle_id="oracle_parent",
            session_id="session_parent",
            oracle='{"test": "parent"}',
            embedding=embedder.embed_oracle('{"test": "parent"}'),
            quality_score=0.9,
            timestamp=datetime.now(),
            oracle_version=1,
            parent_oracle_id=None,
            reuse_count=0,
        )
        db.store_oracle(parent)

        # Store child oracle (v2, derived from parent)
        child = OracleRecord(
            oracle_id="oracle_child",
            session_id="session_child",
            oracle='{"test": "child"}',
            embedding=embedder.embed_oracle('{"test": "child"}'),
            quality_score=0.95,
            timestamp=datetime.now(),
            oracle_version=2,
            parent_oracle_id="oracle_parent",
            reuse_count=0,
        )
        db.store_oracle(child)

        # Verify stored data
        all_oracles = db.get_all_oracle_embeddings()
        assert len(all_oracles) == 2

        retrieved_child = next(o for o in all_oracles if o.oracle_id == "oracle_child")
        assert retrieved_child.oracle_version == 2
        assert retrieved_child.parent_oracle_id == "oracle_parent"

    def test_increment_oracle_reuse(self):
        """Test incrementing oracle reuse count."""
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # Store oracle
        oracle = OracleRecord(
            oracle_id="oracle_1",
            session_id="session_1",
            oracle="{}",
            embedding=embedder.embed_oracle("{}"),
            quality_score=0.9,
            timestamp=datetime.now(),
            reuse_count=0,
        )
        db.store_oracle(oracle)

        # Increment reuse count 3 times
        for _ in range(3):
            db.increment_oracle_reuse("oracle_1")

        # Verify count
        oracles = db.get_all_oracle_embeddings()
        retrieved = oracles[0]
        assert retrieved.reuse_count == 3

    def test_get_golden_oracles(self):
        """Test retrieving golden oracles."""
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # Create mix of oracles
        oracles_data = [
            ("oracle_1", 0.95, 5),  # Golden: high quality, high reuse
            ("oracle_2", 0.85, 4),  # Golden: good quality, good reuse
            ("oracle_3", 0.9, 1),   # Not golden: low reuse
            ("oracle_4", 0.6, 10),  # Not golden: low quality
            ("oracle_5", 0.88, 3),  # Golden: meets thresholds
        ]

        for oracle_id, quality, reuse_count in oracles_data:
            oracle = OracleRecord(
                oracle_id=oracle_id,
                session_id=f"session_{oracle_id}",
                oracle="{}",
                embedding=embedder.embed_oracle("{}"),
                quality_score=quality,
                timestamp=datetime.now(),
                reuse_count=reuse_count,
            )
            db.store_oracle(oracle)

        # Get golden oracles (min_quality=0.8, min_reuse=3)
        golden = db.get_golden_oracles(min_quality=0.8, min_reuse=3)

        # Should get oracles 1, 2, and 5
        assert len(golden) == 3
        oracle_ids = {o.oracle_id for o in golden}
        assert oracle_ids == {"oracle_1", "oracle_2", "oracle_5"}

        # Should be sorted by quality * reuse (descending)
        # oracle_1: 0.95 * 5 = 4.75
        # oracle_2: 0.85 * 4 = 3.40
        # oracle_5: 0.88 * 3 = 2.64
        assert golden[0].oracle_id == "oracle_1"
        assert golden[1].oracle_id == "oracle_2"
        assert golden[2].oracle_id == "oracle_5"

    def test_get_oracle_lineage(self):
        """Test getting oracle lineage (parent chain)."""
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # Create lineage: v1 -> v2 -> v3
        oracles = [
            OracleRecord(
                oracle_id="oracle_v1",
                session_id="session_1",
                oracle='{"version": 1}',
                embedding=embedder.embed_oracle('{"version": 1}'),
                quality_score=0.8,
                timestamp=datetime.now(),
                oracle_version=1,
                parent_oracle_id=None,
            ),
            OracleRecord(
                oracle_id="oracle_v2",
                session_id="session_2",
                oracle='{"version": 2}',
                embedding=embedder.embed_oracle('{"version": 2}'),
                quality_score=0.85,
                timestamp=datetime.now(),
                oracle_version=2,
                parent_oracle_id="oracle_v1",
            ),
            OracleRecord(
                oracle_id="oracle_v3",
                session_id="session_3",
                oracle='{"version": 3}',
                embedding=embedder.embed_oracle('{"version": 3}'),
                quality_score=0.9,
                timestamp=datetime.now(),
                oracle_version=3,
                parent_oracle_id="oracle_v2",
            ),
        ]

        for oracle in oracles:
            db.store_oracle(oracle)

        # Get lineage from v3
        lineage = db.get_oracle_lineage("oracle_v3")

        # Should return [v3, v2, v1]
        assert len(lineage) == 3
        assert lineage[0].oracle_id == "oracle_v3"
        assert lineage[1].oracle_id == "oracle_v2"
        assert lineage[2].oracle_id == "oracle_v1"

        # Verify quality improvement over time
        assert lineage[0].quality_score > lineage[1].quality_score
        assert lineage[1].quality_score > lineage[2].quality_score

    def test_get_oracle_descendants(self):
        """Test getting oracle descendants."""
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # Create tree: v1 -> [v2a, v2b, v2c]
        parent = OracleRecord(
            oracle_id="oracle_v1",
            session_id="session_1",
            oracle="{}",
            embedding=embedder.embed_oracle("{}"),
            quality_score=0.8,
            timestamp=datetime.now(),
            oracle_version=1,
        )
        db.store_oracle(parent)

        # Create 3 descendants
        for i, letter in enumerate(["a", "b", "c"]):
            child = OracleRecord(
                oracle_id=f"oracle_v2{letter}",
                session_id=f"session_2{letter}",
                oracle=f'{{"child": "{letter}"}}',
                embedding=embedder.embed_oracle(f'{{"child": "{letter}"}}'),
                quality_score=0.8 + (i * 0.05),
                timestamp=datetime.now(),
                oracle_version=2,
                parent_oracle_id="oracle_v1",
            )
            db.store_oracle(child)

        # Get descendants of v1
        descendants = db.get_oracle_descendants("oracle_v1")

        assert len(descendants) == 3
        descendant_ids = {d.oracle_id for d in descendants}
        assert descendant_ids == {"oracle_v2a", "oracle_v2b", "oracle_v2c"}

        # All should have same parent
        for descendant in descendants:
            assert descendant.parent_oracle_id == "oracle_v1"
            assert descendant.oracle_version == 2

    def test_circular_lineage_protection(self):
        """Test that lineage traversal handles cycles (shouldn't happen, but protect)."""
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # This shouldn't happen in practice, but test protection
        oracle = OracleRecord(
            oracle_id="oracle_circular",
            session_id="session_1",
            oracle="{}",
            embedding=embedder.embed_oracle("{}"),
            quality_score=0.9,
            timestamp=datetime.now(),
            oracle_version=1,
            parent_oracle_id="oracle_circular",  # Points to itself
        )
        db.store_oracle(oracle)

        # Get lineage - should not infinite loop
        lineage = db.get_oracle_lineage("oracle_circular")

        # Should only return the oracle once
        assert len(lineage) == 1
        assert lineage[0].oracle_id == "oracle_circular"

    def test_migration_adds_columns(self):
        """Test that migration adds versioning columns to existing DB."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"

            # Create DB with old schema (simulate old database)
            # This is tested implicitly by the schema migration logic
            # New DBs will have columns from the start

            db = HistoryDB(str(db_path))
            embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

            # Store oracle
            oracle = OracleRecord(
                oracle_id="test_1",
                session_id="session_1",
                oracle="{}",
                embedding=embedder.embed_oracle("{}"),
                quality_score=0.9,
                timestamp=datetime.now(),
            )
            db.store_oracle(oracle)

            # Retrieve and verify
            oracles = db.get_all_oracle_embeddings()
            assert len(oracles) == 1
            assert oracles[0].oracle_version == 1
            assert oracles[0].parent_oracle_id is None
            assert oracles[0].reuse_count == 0
