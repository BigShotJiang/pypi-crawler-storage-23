"""Test agent registry and specialized prompts."""

import pytest
from pathlib import Path
from ctrlcode.agents.registry import AgentRegistry


@pytest.fixture
def workspace_root():
    """Get workspace root directory."""
    return Path(__file__).parent.parent


@pytest.fixture
def agent_registry(workspace_root):
    """Create agent registry instance."""
    # Mock tool registry (not needed for these tests)
    mock_tool_registry = None
    return AgentRegistry(workspace_root, mock_tool_registry)


class TestAgentConfigs:
    """Test agent configuration creation."""

    def test_planner_config(self, agent_registry):
        """Test Planner agent configuration."""
        config = agent_registry.get_planner_config()

        assert config.name == "planner"
        assert "planner.md" in config.system_prompt_path
        assert set(config.tools) == {
            "search_files",
            "search_code",
            "read_file",
            "list_directory",
            "task_write",
        }
        assert config.prune_protect == 50_000
        assert config.prune_minimum == 25_000

    def test_coder_config(self, agent_registry):
        """Test Coder agent configuration."""
        config = agent_registry.get_coder_config()

        assert config.name == "coder"
        assert "coder.md" in config.system_prompt_path
        assert set(config.tools) == {
            "read_file",
            "write_file",
            "update_file",
            "run_command",
            "search_code",
        }
        assert config.prune_protect == 100_000  # Largest context
        assert config.prune_minimum == 50_000

    def test_coder_config_with_task_id(self, agent_registry):
        """Test Coder agent configuration with task ID."""
        config = agent_registry.get_coder_config(task_id="task-42")

        assert config.name == "coder-task-42"

    def test_reviewer_config(self, agent_registry):
        """Test Reviewer agent configuration."""
        config = agent_registry.get_reviewer_config()

        assert config.name == "reviewer"
        assert "reviewer.md" in config.system_prompt_path
        assert set(config.tools) == {
            "read_file",
            "run_command",
            "search_code",
            "task_update",
        }
        assert config.prune_protect == 75_000

    def test_executor_config(self, agent_registry):
        """Test Executor agent configuration."""
        config = agent_registry.get_executor_config()

        assert config.name == "executor"
        assert "executor.md" in config.system_prompt_path
        assert set(config.tools) == {
            "run_command",
            "fetch",
            "query_logs",
            "query_metrics",
            "screenshot",
            "dom_snapshot",
        }
        assert config.prune_protect == 50_000

    def test_orchestrator_config(self, agent_registry):
        """Test Orchestrator agent configuration."""
        config = agent_registry.get_orchestrator_config()

        assert config.name == "orchestrator"
        assert "orchestrator.md" in config.system_prompt_path
        assert config.tools == []  # No tools - delegates only


class TestSystemPromptLoading:
    """Test system prompt loading from files."""

    def test_load_planner_prompt(self, agent_registry):
        """Test loading Planner system prompt."""
        prompt = agent_registry.load_system_prompt("planner")

        assert len(prompt) > 0
        assert "Planner Agent" in prompt
        assert "task decomposition" in prompt.lower()
        assert "task_write" in prompt

    def test_load_coder_prompt(self, agent_registry):
        """Test loading Coder system prompt."""
        prompt = agent_registry.load_system_prompt("coder")

        assert len(prompt) > 0
        assert "Coder Agent" in prompt
        assert "implementing" in prompt.lower()
        assert "write_file" in prompt

    def test_load_reviewer_prompt(self, agent_registry):
        """Test loading Reviewer system prompt."""
        prompt = agent_registry.load_system_prompt("reviewer")

        assert len(prompt) > 0
        assert "Reviewer Agent" in prompt
        assert "code quality" in prompt.lower()
        assert "security" in prompt.lower()

    def test_load_executor_prompt(self, agent_registry):
        """Test loading Executor system prompt."""
        prompt = agent_registry.load_system_prompt("executor")

        assert len(prompt) > 0
        assert "Executor Agent" in prompt
        assert "runtime validation" in prompt.lower()
        assert "observability" in prompt.lower()

    def test_load_nonexistent_prompt_raises_error(self, agent_registry):
        """Test that loading nonexistent prompt raises error."""
        with pytest.raises(KeyError):
            agent_registry.load_system_prompt("nonexistent")


class TestToolAccessValidation:
    """Test tool access restrictions per agent type."""

    def test_planner_tool_access(self, agent_registry):
        """Test Planner tool access restrictions."""
        # Allowed tools
        assert agent_registry.validate_tool_access("planner", "search_files")
        assert agent_registry.validate_tool_access("planner", "read_file")
        assert agent_registry.validate_tool_access("planner", "task_write")

        # Disallowed tools
        assert not agent_registry.validate_tool_access("planner", "write_file")
        assert not agent_registry.validate_tool_access("planner", "update_file")
        assert not agent_registry.validate_tool_access("planner", "run_command")
        assert not agent_registry.validate_tool_access("planner", "fetch")

    def test_coder_tool_access(self, agent_registry):
        """Test Coder tool access restrictions."""
        # Allowed tools
        assert agent_registry.validate_tool_access("coder", "write_file")
        assert agent_registry.validate_tool_access("coder", "update_file")
        assert agent_registry.validate_tool_access("coder", "read_file")
        assert agent_registry.validate_tool_access("coder", "run_command")

        # Disallowed tools
        assert not agent_registry.validate_tool_access("coder", "task_write")
        assert not agent_registry.validate_tool_access("coder", "task_update")
        assert not agent_registry.validate_tool_access("coder", "fetch")

    def test_reviewer_tool_access(self, agent_registry):
        """Test Reviewer tool access restrictions."""
        # Allowed tools
        assert agent_registry.validate_tool_access("reviewer", "read_file")
        assert agent_registry.validate_tool_access("reviewer", "run_command")
        assert agent_registry.validate_tool_access("reviewer", "search_code")
        assert agent_registry.validate_tool_access("reviewer", "task_update")

        # Disallowed tools
        assert not agent_registry.validate_tool_access("reviewer", "write_file")
        assert not agent_registry.validate_tool_access("reviewer", "update_file")
        assert not agent_registry.validate_tool_access("reviewer", "fetch")

    def test_executor_tool_access(self, agent_registry):
        """Test Executor tool access restrictions."""
        # Allowed tools
        assert agent_registry.validate_tool_access("executor", "run_command")
        assert agent_registry.validate_tool_access("executor", "fetch")

        # Disallowed tools
        assert not agent_registry.validate_tool_access("executor", "read_file")
        assert not agent_registry.validate_tool_access("executor", "write_file")
        assert not agent_registry.validate_tool_access("executor", "search_files")

    def test_orchestrator_tool_access(self, agent_registry):
        """Test Orchestrator has no direct tool access."""
        # No tools allowed
        assert not agent_registry.validate_tool_access("orchestrator", "read_file")
        assert not agent_registry.validate_tool_access("orchestrator", "write_file")
        assert not agent_registry.validate_tool_access("orchestrator", "run_command")


class TestPromptContentValidation:
    """Test that prompts contain expected role descriptions and constraints."""

    def test_planner_prompt_structure(self, agent_registry):
        """Test Planner prompt has correct role and constraints."""
        prompt = agent_registry.load_system_prompt("planner")

        # Role definition
        assert "task decomposition" in prompt.lower() or "break down" in prompt.lower()

        # Tool mentions
        assert "search_files" in prompt or "search_code" in prompt

        # Constraints
        assert "cannot write code" in prompt.lower() or "you cannot write" in prompt.lower()

        # Output format
        assert "json" in prompt.lower()

    def test_coder_prompt_structure(self, agent_registry):
        """Test Coder prompt has correct role and constraints."""
        prompt = agent_registry.load_system_prompt("coder")

        # Role definition
        assert "implement" in prompt.lower() or "write code" in prompt.lower()

        # Tool mentions
        assert "write_file" in prompt or "update_file" in prompt

        # Constraints
        assert "cannot plan" in prompt.lower() or "you cannot plan" in prompt.lower()

        # Quality standards
        assert "test" in prompt.lower()
        assert "golden principle" in prompt.lower()

    def test_reviewer_prompt_structure(self, agent_registry):
        """Test Reviewer prompt has correct role and constraints."""
        prompt = agent_registry.load_system_prompt("reviewer")

        # Role definition
        assert "review" in prompt.lower() or "quality" in prompt.lower()

        # Security focus
        assert "security" in prompt.lower()

        # Constraints
        assert "cannot write code" in prompt.lower() or "you cannot write" in prompt.lower()

        # Decision criteria
        assert "approved" in prompt.lower() or "changes_requested" in prompt.lower()

    def test_executor_prompt_structure(self, agent_registry):
        """Test Executor prompt has correct role and constraints."""
        prompt = agent_registry.load_system_prompt("executor")

        # Role definition
        assert "runtime" in prompt.lower() or "validation" in prompt.lower()
        assert "observability" in prompt.lower()

        # Tool mentions
        assert "run_command" in prompt

        # Validation types
        assert "performance" in prompt.lower() or "functionality" in prompt.lower()


class TestAgentSeparationOfConcerns:
    """Test that agents have distinct, non-overlapping responsibilities."""

    def test_no_overlapping_tools_planner_coder(self, agent_registry):
        """Test Planner and Coder have distinct tool sets."""
        planner_tools = set(agent_registry.get_allowed_tools("planner"))
        coder_tools = set(agent_registry.get_allowed_tools("coder"))

        # Planner cannot write
        assert "write_file" not in planner_tools
        assert "update_file" not in planner_tools

        # Coder cannot plan
        assert "task_write" not in coder_tools

    def test_reviewer_cannot_modify_code(self, agent_registry):
        """Test Reviewer cannot modify code directly."""
        reviewer_tools = set(agent_registry.get_allowed_tools("reviewer"))

        assert "write_file" not in reviewer_tools
        assert "update_file" not in reviewer_tools

    def test_executor_minimal_toolset(self, agent_registry):
        """Test Executor has minimal runtime-focused toolset."""
        executor_tools = set(agent_registry.get_allowed_tools("executor"))

        # Runtime, observability, and browser automation tools
        assert executor_tools == {
            "run_command",
            "fetch",
            "query_logs",
            "query_metrics",
            "screenshot",
            "dom_snapshot",
        }

        # No file manipulation
        assert "read_file" not in executor_tools
        assert "write_file" not in executor_tools
