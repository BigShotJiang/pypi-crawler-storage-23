"""
Integration example: Using specialized agents with harness-utils.

This demonstrates how to instantiate each agent type with ConversationManager
and run simple tasks through them.
"""

from pathlib import Path
from ctrlcode.agents.registry import AgentRegistry
from harnessutils import ConversationManager, Message, TextPart
from harnessutils.config import HarnessConfig
from harnessutils.storage import MemoryStorage


def create_agent_conversation(agent_type: str, registry: AgentRegistry) -> ConversationManager:
    """
    Create a ConversationManager configured for a specific agent type.

    Args:
        agent_type: Agent type (planner, coder, reviewer, executor)
        registry: AgentRegistry instance

    Returns:
        Configured ConversationManager and conversation ID
    """
    # Load agent config
    config = registry.get_agent_configs()[agent_type]

    # Load system prompt
    system_prompt = registry.load_system_prompt(agent_type)

    # Create harness config with agent-specific settings
    harness_config = HarnessConfig()
    harness_config.pruning.prune_protect = config.prune_protect
    harness_config.pruning.prune_minimum = config.prune_minimum
    harness_config.truncation.max_lines = config.max_lines
    harness_config.compaction.use_predictive = config.use_predictive

    # Create conversation manager with memory storage (for demo)
    conv_manager = ConversationManager(
        storage=MemoryStorage(),
        config=harness_config,
    )

    # Create conversation
    conv = conv_manager.create_conversation(project_id=f"agent-{agent_type}")

    # Add system prompt as first message
    system_msg = Message(id="system", role="system")
    system_msg.add_part(TextPart(text=system_prompt))
    conv_manager.add_message(conv.id, system_msg)

    return conv_manager, conv.id


def demo_planner_agent():
    """Demonstrate Planner agent usage."""
    print("=" * 70)
    print("PLANNER AGENT DEMO")
    print("=" * 70)
    print()

    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    # Create conversation for planner
    conv_manager, conv_id = create_agent_conversation("planner", registry)

    # User request
    user_message = Message(id="msg-1", role="user")
    user_message.add_part(TextPart(text="Add a logout button to the UI"))
    conv_manager.add_message(conv_id, user_message)

    print("✓ Created Planner agent conversation")
    print(f"  Conversation ID: {conv_id}")
    print("  User request: 'Add a logout button to the UI'")
    print()

    # Show allowed tools
    allowed_tools = registry.get_allowed_tools("planner")
    print(f"  Allowed tools: {', '.join(allowed_tools)}")
    print()

    # Expected output structure
    print("  Expected output: Task graph with dependencies")
    print("  - Explore current UI structure")
    print("  - Add button to header widget")
    print("  - Implement logout handler")
    print("  - Add tests")
    print()


def demo_coder_agent():
    """Demonstrate Coder agent usage."""
    print("=" * 70)
    print("CODER AGENT DEMO")
    print("=" * 70)
    print()

    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    # Create conversation for coder
    conv_manager, conv_id = create_agent_conversation("coder", registry)

    # Simulated task from Planner
    task_json = """{
  "id": "task-2",
  "description": "Add logout button to header widget",
  "type": "code",
  "files": ["tui/widgets/header.py"],
  "acceptance_criteria": [
    "Logout button visible in header",
    "Calls logout handler on click"
  ]
}"""

    user_message = Message(id="msg-1", role="user")
    user_message.add_part(TextPart(text=f"Implement this task:\n{task_json}"))
    conv_manager.add_message(conv_id, user_message)

    print("✓ Created Coder agent conversation")
    print(f"  Conversation ID: {conv_id}")
    print("  Task: Add logout button to header widget")
    print()

    # Show allowed tools
    allowed_tools = registry.get_allowed_tools("coder")
    print(f"  Allowed tools: {', '.join(allowed_tools)}")
    print()

    # Expected behavior
    print("  Expected behavior:")
    print("  1. Read tui/widgets/header.py")
    print("  2. Update file to add logout button")
    print("  3. Run tests to verify")
    print("  4. Report completion status")
    print()


def demo_reviewer_agent():
    """Demonstrate Reviewer agent usage."""
    print("=" * 70)
    print("REVIEWER AGENT DEMO")
    print("=" * 70)
    print()

    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    # Create conversation for reviewer
    conv_manager, conv_id = create_agent_conversation("reviewer", registry)

    # Simulated completed task
    review_request = """{
  "tasks": [{
    "id": "task-2",
    "description": "Add logout button",
    "files_changed": ["tui/widgets/header.py"],
    "test_output": "1 passed in 0.2s"
  }]
}"""

    user_message = Message(id="msg-1", role="user")
    user_message.add_part(TextPart(text=f"Review this completed work:\n{review_request}"))
    conv_manager.add_message(conv_id, user_message)

    print("✓ Created Reviewer agent conversation")
    print(f"  Conversation ID: {conv_id}")
    print("  Task: Review logout button implementation")
    print()

    # Show allowed tools
    allowed_tools = registry.get_allowed_tools("reviewer")
    print(f"  Allowed tools: {', '.join(allowed_tools)}")
    print()

    # Expected checks
    print("  Expected review process:")
    print("  1. Read changed files")
    print("  2. Run linter (ruff)")
    print("  3. Check security (no vulnerabilities)")
    print("  4. Verify tests pass")
    print("  5. Check golden principles")
    print("  6. Approve or request changes")
    print()


def demo_executor_agent():
    """Demonstrate Executor agent usage."""
    print("=" * 70)
    print("EXECUTOR AGENT DEMO")
    print("=" * 70)
    print()

    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    # Create conversation for executor
    conv_manager, conv_id = create_agent_conversation("executor", registry)

    # Simulated validation request
    validation_request = """{
  "type": "verify_functionality",
  "description": "Ensure logout flow works end-to-end",
  "acceptance_criteria": [
    "Click logout button clears session",
    "Redirects to login screen",
    "Cannot access protected routes"
  ]
}"""

    user_message = Message(id="msg-1", role="user")
    user_message.add_part(TextPart(text=f"Validate runtime behavior:\n{validation_request}"))
    conv_manager.add_message(conv_id, user_message)

    print("✓ Created Executor agent conversation")
    print(f"  Conversation ID: {conv_id}")
    print("  Task: Runtime validation of logout flow")
    print()

    # Show allowed tools
    allowed_tools = registry.get_allowed_tools("executor")
    print(f"  Allowed tools: {', '.join(allowed_tools)}")
    print()

    # Expected validation
    print("  Expected validation process:")
    print("  1. Start TUI application")
    print("  2. Simulate logout button click")
    print("  3. Verify session cleared")
    print("  4. Check logs for errors")
    print("  5. Report pass/fail with evidence")
    print()


def demo_tool_enforcement():
    """Demonstrate tool access enforcement."""
    print("=" * 70)
    print("TOOL ACCESS ENFORCEMENT DEMO")
    print("=" * 70)
    print()

    workspace = Path.cwd()
    registry = AgentRegistry(workspace, tool_registry=None)

    # Test cases that should be blocked
    blocked_cases = [
        ("planner", "write_file", "Planner cannot write code"),
        ("coder", "task_write", "Coder cannot create task graphs"),
        ("reviewer", "update_file", "Reviewer cannot modify code"),
        ("executor", "read_file", "Executor only validates runtime"),
    ]

    print("Testing tool access restrictions:")
    print()

    for agent_type, tool_name, reason in blocked_cases:
        is_allowed = registry.validate_tool_access(agent_type, tool_name)
        status = "✗ BLOCKED" if not is_allowed else "✓ ALLOWED"
        print(f"{status} - {agent_type} attempting {tool_name}")
        print(f"         Reason: {reason}")
        print()


if __name__ == "__main__":
    print()
    print("╔" + "=" * 68 + "╗")
    print("║" + " " * 15 + "SPECIALIZED AGENTS INTEGRATION" + " " * 23 + "║")
    print("╚" + "=" * 68 + "╝")
    print()

    demo_planner_agent()
    demo_coder_agent()
    demo_reviewer_agent()
    demo_executor_agent()
    demo_tool_enforcement()

    print("=" * 70)
    print("✅ Integration examples complete!")
    print()
    print("Next steps:")
    print("  1. Wire agents into workflow orchestration")
    print("  2. Add event streaming for multi-agent coordination")
    print("  3. Test full workflow: Plan → Code → Review → Execute")
    print("=" * 70)
