"""Tests for PR automation."""

import pytest
from unittest.mock import Mock, patch
from ctrlcode.cleanup import PRAutomation, PRConfig


@pytest.fixture
def workspace_root(tmp_path):
    """Create temporary workspace."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    # Create test file
    test_file = workspace / "test.py"
    test_file.write_text("""
def process(data):
    value = data["key"]
    return value
""")

    # Initialize git repo
    import subprocess
    subprocess.run(["git", "init"], cwd=workspace, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=workspace, capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=workspace, capture_output=True)
    subprocess.run(["git", "add", "."], cwd=workspace, capture_output=True)
    subprocess.run(["git", "commit", "--no-gpg-sign", "-m", "Initial"], cwd=workspace, capture_output=True)

    return workspace


@pytest.fixture
def pr_config():
    """Create PR config."""
    return PRConfig(
        enabled=True,
        max_files_per_pr=5,
        require_tests_pass=False,  # Skip tests in tests
        require_linter_pass=False,  # Skip linter in tests
        base_branch="main",
    )


@pytest.fixture
def pr_automation(workspace_root, pr_config):
    """Create PRAutomation instance."""
    return PRAutomation(workspace_root, pr_config)


def test_pr_config_defaults():
    """Test PR config default values."""
    config = PRConfig()

    assert config.enabled is False
    assert config.max_files_per_pr == 5
    assert config.require_tests_pass is True
    assert config.require_linter_pass is True
    assert config.base_branch == "main"


def test_pr_automation_init(pr_automation, workspace_root):
    """Test PR automation initialization."""
    assert pr_automation.workspace_root == workspace_root
    assert pr_automation.config.enabled is True


def test_create_pr_disabled(workspace_root):
    """Test PR creation when disabled."""
    config = PRConfig(enabled=False)
    automation = PRAutomation(workspace_root, config)

    result = automation.create_cleanup_pr({})

    assert result["status"] == "skipped"
    assert "disabled" in result["reason"]


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_check_gh_cli_available(mock_run, pr_automation):
    """Test checking gh CLI availability."""
    mock_run.return_value = Mock(returncode=0)

    assert pr_automation._check_gh_cli() is True
    mock_run.assert_called_once()


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_check_gh_cli_not_available(mock_run, pr_automation):
    """Test checking gh CLI when not available."""
    mock_run.side_effect = Exception("Not found")

    assert pr_automation._check_gh_cli() is False


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_create_pr_no_gh_cli(mock_run, pr_automation):
    """Test PR creation when gh CLI not available."""
    mock_run.side_effect = Exception("Not found")

    result = pr_automation.create_cleanup_pr({})

    assert result["status"] == "error"
    assert "gh CLI" in result["reason"]


def test_apply_fix(pr_automation, workspace_root):
    """Test applying fix to file."""
    test_file = workspace_root / "test.py"

    fix = {
        "file": "test.py",
        "old_content": '    value = data["key"]',
        "new_content": "    value = data.get('key')",
    }

    result = pr_automation._apply_fix(fix)

    assert result is True
    assert "data.get('key')" in test_file.read_text()


def test_apply_fix_file_not_found(pr_automation):
    """Test applying fix when file doesn't exist."""
    fix = {"file": "nonexistent.py", "old_content": "old", "new_content": "new"}

    result = pr_automation._apply_fix(fix)

    assert result is False


def test_apply_fix_content_not_found(pr_automation, workspace_root):
    """Test applying fix when content doesn't match."""
    fix = {
        "file": "test.py",
        "old_content": "this doesn't exist",
        "new_content": "new",
    }

    result = pr_automation._apply_fix(fix)

    assert result is False


def test_generate_commit_message(pr_automation):
    """Test commit message generation."""
    files = ["file1.py", "file2.py"]
    msg = pr_automation._generate_commit_message("no-yolo-parsing", files)

    assert "refactor:" in msg.lower()
    assert "no-yolo-parsing" in msg
    assert "file1.py" in msg
    assert "Cleanup Agent" in msg


def test_generate_commit_message_many_files(pr_automation):
    """Test commit message with many files."""
    files = ["file1.py", "file2.py", "file3.py", "file4.py", "file5.py"]
    msg = pr_automation._generate_commit_message("no-yolo-parsing", files)

    assert "+2 more" in msg  # Shows first 3 + count of rest


def test_generate_pr_body(pr_automation):
    """Test PR body generation."""
    scan_results = {"total_violations": 5, "scan_type": "no-yolo-parsing"}
    files = ["file1.py", "file2.py"]

    body = pr_automation._generate_pr_body("no-yolo-parsing", scan_results, files)

    assert "5" in body  # Violations count
    assert "2" in body  # Files count
    assert "file1.py" in body
    assert "file2.py" in body
    assert "golden-principles" in body
    assert "Cleanup Agent" in body


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_run_tests_pass(mock_run, pr_automation):
    """Test running tests successfully."""
    mock_run.return_value = Mock(returncode=0)

    assert pr_automation._run_tests() is True


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_run_tests_fail(mock_run, pr_automation):
    """Test running tests with failure."""
    mock_run.return_value = Mock(returncode=1)

    assert pr_automation._run_tests() is False


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_run_linter_pass(mock_run, pr_automation):
    """Test running linter successfully."""
    mock_run.return_value = Mock(returncode=0)

    assert pr_automation._run_linter() is True


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_run_linter_fail(mock_run, pr_automation):
    """Test running linter with failure."""
    mock_run.return_value = Mock(returncode=1)

    assert pr_automation._run_linter() is False


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_create_pr_no_fixes(mock_run, pr_automation, workspace_root):
    """Test PR creation with no fixes to apply."""
    # Mock git commands
    mock_run.return_value = Mock(returncode=0, stdout="", stderr="")

    scan_results = {"scan_type": "no-yolo-parsing"}
    result = pr_automation.create_cleanup_pr(scan_results, fixes=[])

    assert result["status"] == "skipped"
    assert "No changes" in result["reason"]


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_create_pr_success(mock_run, pr_automation, workspace_root):
    """Test successful PR creation."""
    # Mock subprocess calls
    def mock_subprocess(cmd, **kwargs):
        if cmd[0] == "gh" and cmd[1] == "--version":
            return Mock(returncode=0)
        elif cmd[0] == "gh" and cmd[1] == "pr":
            return Mock(returncode=0, stdout="https://github.com/user/repo/pull/123", stderr="")
        else:
            return Mock(returncode=0, stdout="", stderr="")

    mock_run.side_effect = mock_subprocess

    scan_results = {"scan_type": "no-yolo-parsing", "total_violations": 2}
    fixes = [
        {
            "file": "test.py",
            "old_content": '    value = data["key"]',
            "new_content": "    value = data.get('key')",
        }
    ]

    result = pr_automation.create_cleanup_pr(scan_results, fixes)

    assert result["status"] == "success"
    assert "pr_url" in result
    assert "pr_number" in result
    assert "files_changed" in result


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_create_pr_with_reviewers(mock_run, workspace_root):
    """Test PR creation with auto-assign reviewers."""
    config = PRConfig(
        enabled=True,
        auto_assign_reviewers=["reviewer1", "reviewer2"],
        require_tests_pass=False,
        require_linter_pass=False,
    )
    automation = PRAutomation(workspace_root, config)

    # Mock subprocess
    def mock_subprocess(cmd, **kwargs):
        if cmd[0] == "gh":
            if cmd[1] == "--version":
                return Mock(returncode=0)
            elif cmd[1] == "pr" and "--reviewer" in cmd:
                assert "reviewer1" in cmd
                assert "reviewer2" in cmd
                return Mock(returncode=0, stdout="https://github.com/user/repo/pull/1", stderr="")
        return Mock(returncode=0, stdout="", stderr="")

    mock_run.side_effect = mock_subprocess

    scan_results = {"scan_type": "no-yolo-parsing"}
    fixes = [
        {
            "file": "test.py",
            "old_content": '    value = data["key"]',
            "new_content": "    value = data.get('key')",
        }
    ]

    result = automation.create_cleanup_pr(scan_results, fixes)

    assert result["status"] == "success"


@patch("ctrlcode.cleanup.pr_automation.subprocess.run")
def test_max_files_per_pr_limit(mock_run, workspace_root):
    """Test that max files per PR is respected."""
    config = PRConfig(enabled=True, max_files_per_pr=2, require_tests_pass=False, require_linter_pass=False)
    automation = PRAutomation(workspace_root, config)

    # Create multiple test files
    for i in range(5):
        (workspace_root / f"test{i}.py").write_text(f"# File {i}")

    # Mock subprocess
    mock_run.return_value = Mock(returncode=0, stdout="https://github.com/user/repo/pull/1", stderr="")

    fixes = [{"file": f"test{i}.py", "old_content": f"# File {i}", "new_content": f"# Fixed {i}"} for i in range(5)]

    result = automation.create_cleanup_pr({"scan_type": "test"}, fixes)

    # Should only process first 2 files
    if result["status"] == "success":
        assert len(result["files_changed"]) <= 2
