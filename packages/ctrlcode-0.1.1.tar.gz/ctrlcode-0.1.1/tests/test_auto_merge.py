"""Tests for auto-merge."""

import json
import pytest
from datetime import datetime
from unittest.mock import Mock, patch
from ctrlcode.cleanup import AutoMerge, AutoMergeConfig


@pytest.fixture
def workspace_root(tmp_path):
    """Create temporary workspace."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    return workspace


@pytest.fixture
def auto_merge_config():
    """Create auto-merge config."""
    return AutoMergeConfig(
        enabled=True,
        wait_minutes=0,  # No wait for tests
        max_files=5,
        max_lines_changed=100,
        excluded_paths=["migrations/", "config/"],
        dry_run=False,
    )


@pytest.fixture
def auto_merge(workspace_root, auto_merge_config):
    """Create AutoMerge instance."""
    return AutoMerge(workspace_root, auto_merge_config)


def test_auto_merge_config_defaults():
    """Test auto-merge config defaults."""
    config = AutoMergeConfig()

    assert config.enabled is False
    assert config.wait_minutes == 60
    assert config.max_files == 5
    assert config.max_lines_changed == 100
    assert config.dry_run is False


def test_auto_merge_init(auto_merge, workspace_root):
    """Test auto-merge initialization."""
    assert auto_merge.workspace_root == workspace_root
    assert auto_merge.config.enabled is True
    assert auto_merge.audit_log_path.parent.exists()


def test_check_and_merge_disabled(workspace_root):
    """Test merge when disabled."""
    config = AutoMergeConfig(enabled=False)
    merger = AutoMerge(workspace_root, config)

    result = merger.check_and_merge_pr(123)

    assert result["status"] == "skipped"
    assert "disabled" in result["reason"].lower()


@patch("ctrlcode.cleanup.auto_merge.subprocess.run")
def test_get_pr_info(mock_run, auto_merge):
    """Test getting PR information."""
    pr_data = {
        "number": 123,
        "title": "Test PR",
        "state": "OPEN",
        "author": {"login": "testuser"},
        "labels": [{"name": "auto-merge-candidate"}],
        "createdAt": "2026-02-14T10:00:00Z",
        "files": [{"path": "file1.py"}],
        "additions": 10,
        "deletions": 5,
        "statusCheckRollup": [],
    }

    mock_run.return_value = Mock(returncode=0, stdout=json.dumps(pr_data), stderr="")

    pr_info = auto_merge._get_pr_info(123)

    assert pr_info is not None
    assert pr_info["number"] == 123
    assert pr_info["title"] == "Test PR"
    assert pr_info["state"] == "OPEN"
    assert "auto-merge-candidate" in pr_info["labels"]


@patch("ctrlcode.cleanup.auto_merge.subprocess.run")
def test_get_pr_info_error(mock_run, auto_merge):
    """Test getting PR info when gh fails."""
    mock_run.return_value = Mock(returncode=1, stderr="Error")

    pr_info = auto_merge._get_pr_info(123)

    assert pr_info is None


def test_check_eligibility_success(auto_merge):
    """Test eligibility check for valid PR."""
    pr_info = {
        "state": "OPEN",
        "labels": ["auto-merge-candidate"],
        "files": [{"path": "file1.py"}, {"path": "file2.py"}],
        "additions": 30,
        "deletions": 20,
        "checks": [{"status": "COMPLETED", "conclusion": "SUCCESS"}],
    }

    result = auto_merge._check_eligibility(pr_info)

    assert result["eligible"] is True


def test_check_eligibility_not_open(auto_merge):
    """Test eligibility when PR not open."""
    pr_info = {"state": "CLOSED", "labels": ["auto-merge-candidate"], "files": [], "additions": 0, "deletions": 0, "checks": []}

    result = auto_merge._check_eligibility(pr_info)

    assert result["eligible"] is False
    assert "not open" in result["reason"].lower()


def test_check_eligibility_missing_label(auto_merge):
    """Test eligibility without auto-merge label."""
    pr_info = {"state": "OPEN", "labels": [], "files": [], "additions": 0, "deletions": 0, "checks": []}

    result = auto_merge._check_eligibility(pr_info)

    assert result["eligible"] is False
    assert "label" in result["reason"].lower()


def test_check_eligibility_too_many_files(auto_merge):
    """Test eligibility with too many files."""
    pr_info = {
        "state": "OPEN",
        "labels": ["auto-merge-candidate"],
        "files": [{"path": f"file{i}.py"} for i in range(10)],
        "additions": 10,
        "deletions": 5,
        "checks": [],
    }

    result = auto_merge._check_eligibility(pr_info)

    assert result["eligible"] is False
    assert "too many files" in result["reason"].lower()


def test_check_eligibility_too_many_lines(auto_merge):
    """Test eligibility with too many lines changed."""
    pr_info = {
        "state": "OPEN",
        "labels": ["auto-merge-candidate"],
        "files": [{"path": "file1.py"}],
        "additions": 100,
        "deletions": 50,
        "checks": [],
    }

    result = auto_merge._check_eligibility(pr_info)

    assert result["eligible"] is False
    assert "too many lines" in result["reason"].lower()


def test_check_eligibility_excluded_path(auto_merge):
    """Test eligibility with excluded path."""
    pr_info = {
        "state": "OPEN",
        "labels": ["auto-merge-candidate"],
        "files": [{"path": "migrations/001_add_table.sql"}],
        "additions": 10,
        "deletions": 0,
        "checks": [],
    }

    result = auto_merge._check_eligibility(pr_info)

    assert result["eligible"] is False
    assert "excluded path" in result["reason"].lower()


def test_check_ci_status_all_passed(auto_merge):
    """Test CI status when all checks pass."""
    checks = [
        {"status": "COMPLETED", "conclusion": "SUCCESS", "name": "test"},
        {"status": "COMPLETED", "conclusion": "SUCCESS", "name": "lint"},
    ]

    result = auto_merge._check_ci_status(checks)

    assert result["all_passed"] is True


def test_check_ci_status_failed(auto_merge):
    """Test CI status with failed check."""
    checks = [
        {"status": "COMPLETED", "conclusion": "SUCCESS", "name": "test"},
        {"status": "COMPLETED", "conclusion": "FAILURE", "name": "lint"},
    ]

    result = auto_merge._check_ci_status(checks)

    assert result["all_passed"] is False
    assert "Failed checks" in result["reason"]


def test_check_ci_status_pending(auto_merge):
    """Test CI status with pending checks."""
    checks = [
        {"status": "COMPLETED", "conclusion": "SUCCESS", "name": "test"},
        {"status": "PENDING", "name": "lint"},
    ]

    result = auto_merge._check_ci_status(checks)

    assert result["all_passed"] is False
    assert "Pending checks" in result["reason"]


def test_check_ci_status_no_checks(auto_merge):
    """Test CI status with no checks configured."""
    result = auto_merge._check_ci_status([])

    assert result["all_passed"] is True


@patch("ctrlcode.cleanup.auto_merge.subprocess.run")
def test_merge_pr_success(mock_run, auto_merge):
    """Test successful PR merge."""
    mock_run.return_value = Mock(
        returncode=0,
        stdout="Successfully merged and deleted branch",
        stderr="",
    )

    result = auto_merge._merge_pr(123)

    assert "output" in result
    mock_run.assert_called_once()


@patch("ctrlcode.cleanup.auto_merge.subprocess.run")
def test_merge_pr_failure(mock_run, auto_merge):
    """Test failed PR merge."""
    mock_run.return_value = Mock(returncode=1, stderr="Merge failed")

    with pytest.raises(RuntimeError, match="Merge failed"):
        auto_merge._merge_pr(123)


def test_log_audit(auto_merge):
    """Test audit logging."""
    pr_info = {
        "title": "Test PR",
        "author": "testuser",
        "files": [{"path": "file1.py"}],
        "additions": 10,
        "deletions": 5,
    }

    auto_merge._log_audit(123, "merged", pr_info, {"merge_sha": "abc123"})

    assert auto_merge.audit_log_path.exists()

    # Read audit log
    with open(auto_merge.audit_log_path) as f:
        entry = json.loads(f.readline())

    assert entry["pr_number"] == 123
    assert entry["action"] == "merged"
    assert entry["merge_sha"] == "abc123"


def test_get_audit_log(auto_merge):
    """Test retrieving audit log."""
    pr_info = {
        "title": "Test",
        "author": "test",
        "files": [],
        "additions": 0,
        "deletions": 0,
    }

    # Log some entries
    for i in range(5):
        auto_merge._log_audit(i, "merged", pr_info)

    entries = auto_merge.get_audit_log(limit=10)

    assert len(entries) == 5
    assert entries[0]["pr_number"] == 0
    assert entries[4]["pr_number"] == 4


def test_get_audit_log_empty(auto_merge):
    """Test audit log when empty."""
    entries = auto_merge.get_audit_log()

    assert entries == []


@patch("ctrlcode.cleanup.auto_merge.subprocess.run")
def test_dry_run_mode(mock_run, workspace_root):
    """Test dry run mode."""
    config = AutoMergeConfig(enabled=True, dry_run=True, wait_minutes=0)
    merger = AutoMerge(workspace_root, config)

    pr_data = {
        "number": 123,
        "title": "Test",
        "state": "OPEN",
        "author": {"login": "test"},
        "labels": [{"name": "auto-merge-candidate"}],
        "createdAt": "2026-02-14T10:00:00Z",
        "files": [{"path": "file1.py"}],
        "additions": 10,
        "deletions": 5,
        "statusCheckRollup": [{"status": "COMPLETED", "conclusion": "SUCCESS"}],
    }

    mock_run.return_value = Mock(returncode=0, stdout=json.dumps(pr_data), stderr="")

    result = merger.check_and_merge_pr(123)

    assert result["status"] == "dry_run"
    assert "Would merge" in result["message"]


@patch("ctrlcode.cleanup.auto_merge.subprocess.run")
@patch("ctrlcode.cleanup.auto_merge.datetime")
def test_wait_period(mock_datetime, mock_run, workspace_root):
    """Test wait period before merge."""
    config = AutoMergeConfig(enabled=True, wait_minutes=60)
    merger = AutoMerge(workspace_root, config)

    # Mock current time
    now = datetime(2026, 2, 14, 11, 0, 0)
    created = datetime(2026, 2, 14, 10, 30, 0)  # 30 minutes ago

    mock_datetime.now.return_value = now.replace(tzinfo=None)
    mock_datetime.fromisoformat = datetime.fromisoformat

    pr_data = {
        "number": 123,
        "title": "Test",
        "state": "OPEN",
        "author": {"login": "test"},
        "labels": [{"name": "auto-merge-candidate"}],
        "createdAt": created.isoformat() + "Z",
        "files": [{"path": "file1.py"}],
        "additions": 10,
        "deletions": 5,
        "statusCheckRollup": [],
    }

    mock_run.return_value = Mock(returncode=0, stdout=json.dumps(pr_data), stderr="")

    result = merger.check_and_merge_pr(123)

    assert result["status"] == "waiting"
    assert "30m" in result["reason"]


@patch("ctrlcode.cleanup.auto_merge.subprocess.run")
def test_ineligible_pr(mock_run, auto_merge):
    """Test ineligible PR."""
    pr_data = {
        "number": 123,
        "title": "Test",
        "state": "OPEN",
        "author": {"login": "test"},
        "labels": [],  # Missing label
        "createdAt": "2026-02-14T10:00:00Z",
        "files": [],
        "additions": 0,
        "deletions": 0,
        "statusCheckRollup": [],
    }

    mock_run.return_value = Mock(returncode=0, stdout=json.dumps(pr_data), stderr="")

    result = auto_merge.check_and_merge_pr(123)

    assert result["status"] == "ineligible"
    assert "reason" in result
