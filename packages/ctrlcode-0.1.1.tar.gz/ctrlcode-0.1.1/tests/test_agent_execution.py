"""Tests for agent execution and coordination."""

import pytest
from pathlib import Path

from ctrlcode.agents.registry import AgentRegistry
from ctrlcode.agents.communication import AgentCoordinator, AgentVerbosity
from ctrlcode.agents.workflow import WorkflowOrchestrator, TaskGraph
from ctrlcode.tools.registry import ToolRegistry

from .mocks.mock_provider import (
    MockProvider,
    create_text_response,
    create_tool_call_response,
    create_planner_response
)


@pytest.fixture
def mock_provider():
    """Create mock provider with default responses."""
    return MockProvider()


@pytest.fixture
def tool_registry():
    """Create tool registry for testing."""
    registry = ToolRegistry()

    # Register task_write tool for planner tests
    registry.register_builtin(
        name="task_write",
        description="Write task graph",
        input_schema={
            "type": "object",
            "properties": {
                "tasks": {"type": "array"},
                "parallel_groups": {"type": "array"},
                "risks": {"type": "array"},
                "checkpoints": {"type": "array"}
            }
        },
        function=lambda **kwargs: {"status": "success", "task_graph": kwargs}
    )

    # Register other common tools
    registry.register_builtin(
        name="read_file",
        description="Read file contents",
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"}
            }
        },
        function=lambda path: {"status": "success", "content": f"Contents of {path}"}
    )

    registry.register_builtin(
        name="search_files",
        description="Search for files",
        input_schema={
            "type": "object",
            "properties": {
                "pattern": {"type": "string"}
            }
        },
        function=lambda pattern: {"status": "success", "files": []}
    )

    return registry


@pytest.fixture
def agent_registry(tool_registry):
    """Create agent registry for testing."""
    return AgentRegistry(
        workspace_root=Path.cwd(),
        tool_registry=tool_registry
    )


@pytest.fixture
def coordinator(agent_registry, mock_provider, tool_registry):
    """Create agent coordinator for testing."""
    return AgentCoordinator(
        agent_registry=agent_registry,
        storage_path=Path("/tmp/test_agents"),
        provider=mock_provider,
        tool_registry=tool_registry
    )


@pytest.mark.anyio
async def test_spawn_agent_basic(coordinator, mock_provider):
    """Test basic agent spawning and execution."""
    # Configure mock response
    mock_provider.responses = [
        create_text_response("Task completed successfully", tokens=15)
    ]

    # Spawn agent
    result = await coordinator.spawn_agent(
        agent_type="planner",
        task={"description": "Test task"}
    )

    # Verify result structure
    assert result["status"] == "completed"
    assert result["agent_type"] == "planner"
    assert "agent_id" in result
    assert "conv_id" in result
    assert result["usage_tokens"] == 15


@pytest.mark.anyio
async def test_spawn_planner_agent(coordinator, mock_provider):
    """Test spawning planner agent with task graph."""
    # Create task graph
    task_graph = {
        "tasks": [
            {"id": "task-1", "description": "Implement feature X"},
            {"id": "task-2", "description": "Write tests"}
        ],
        "parallel_groups": [["task-1"], ["task-2"]],
        "risks": ["Risk: API changes"],
        "checkpoints": ["After task-1"]
    }

    # Configure mock planner response
    mock_provider.responses = [
        create_planner_response(task_graph, tokens=50),
        create_text_response("Planning complete", tokens=10)  # Final summary
    ]

    # Spawn planner
    result = await coordinator.spawn_agent(
        agent_type="planner",
        task={"user_intent": "Build feature X with tests"}
    )

    # Verify result
    assert result["status"] == "completed"
    assert result["agent_type"] == "planner"
    assert "task_graph" in result

    # Verify task graph structure
    parsed_graph = result["task_graph"]
    assert len(parsed_graph["tasks"]) == 2
    assert parsed_graph["tasks"][0]["id"] == "task-1"
    assert len(parsed_graph["parallel_groups"]) == 2


@pytest.mark.anyio
async def test_spawn_coder_agent(coordinator, mock_provider):
    """Test spawning coder agent with file operations."""
    # Configure mock coder response with tool calls
    mock_provider.responses = [
        create_tool_call_response(
            tool_name="write_file",
            tool_input={"path": "/tmp/test.py", "content": "print('hello')"},
            call_id="write-1",
            tokens=30
        ),
        create_text_response("File written successfully", tokens=10)  # Final summary
    ]

    # Spawn coder
    result = await coordinator.spawn_agent(
        agent_type="coder",
        task={"description": "Create test.py with hello world"}
    )

    # Verify result
    assert result["status"] == "completed"
    assert result["agent_type"] == "coder"
    assert "files_changed" in result

    # Verify files tracked
    files_changed = result["files_changed"]
    assert len(files_changed["files_written"]) > 0


@pytest.mark.anyio
async def test_spawn_reviewer_agent(coordinator, mock_provider):
    """Test spawning reviewer agent with approval."""
    # Configure mock reviewer response
    mock_provider.responses = [
        create_text_response("Code looks good. Approved!", tokens=20)
    ]

    # Spawn reviewer
    result = await coordinator.spawn_agent(
        agent_type="reviewer",
        task={"tasks": [{"id": "task-1"}], "files_changed": ["test.py"]}
    )

    # Verify result
    assert result["status"] == "completed"
    assert result["agent_type"] == "reviewer"
    assert "review" in result

    # Verify review status
    review = result["review"]
    assert review["status"] in ["approved", "changes_requested", "inconclusive"]


@pytest.mark.anyio
async def test_spawn_executor_agent(coordinator, mock_provider):
    """Test spawning executor agent with validation."""
    # Configure mock executor response
    mock_provider.responses = [
        create_tool_call_response(
            tool_name="bash",
            tool_input={"command": "pytest tests/", "description": "Run tests"},
            call_id="test-1",
            tokens=40
        ),
        create_text_response("All tests passed ✓", tokens=15)  # Final summary
    ]

    # Spawn executor
    result = await coordinator.spawn_agent(
        agent_type="executor",
        task={"type": "verify_functionality", "tasks": []}
    )

    # Verify result
    assert result["status"] == "completed"
    assert result["agent_type"] == "executor"
    assert "validation" in result

    # Verify validation status
    validation = result["validation"]
    assert "validation_status" in validation


@pytest.mark.anyio
async def test_agent_verbosity_filtering(coordinator, mock_provider):
    """Test event filtering based on verbosity level."""
    events_received = []

    def event_callback(event):
        events_received.append(event)

    # Configure simple response
    mock_provider.responses = [
        create_text_response("Response", tokens=10)
    ]

    # Test SILENT verbosity
    events_received.clear()
    _result = await coordinator.spawn_agent(
        agent_type="planner",
        task={"description": "Test"},
        verbosity=AgentVerbosity.SILENT,
        event_callback=event_callback
    )

    # Should receive no events in SILENT mode
    assert len(events_received) == 0

    # Test WORKFLOW verbosity
    events_received.clear()
    mock_provider.reset()
    mock_provider.responses = [
        create_text_response("Response", tokens=10)
    ]

    _result = await coordinator.spawn_agent(
        agent_type="planner",
        task={"description": "Test"},
        verbosity=AgentVerbosity.WORKFLOW,
        event_callback=event_callback
    )

    # Should receive only workflow-level events
    assert len(events_received) > 0


@pytest.mark.anyio
async def test_agent_error_handling(coordinator, mock_provider):
    """Test agent error handling."""
    # Configure mock to raise error
    mock_provider.responses = []  # Empty responses will cause error

    # Spawn agent (should handle error gracefully)
    result = await coordinator.spawn_agent(
        agent_type="planner",
        task={"description": "Test"}
    )

    # Verify error handling
    # Note: Actual error handling depends on implementation
    assert "agent_id" in result
    assert "status" in result


@pytest.mark.anyio
async def test_workflow_orchestrator_integration(agent_registry, mock_provider, tool_registry):
    """Test full workflow orchestration."""
    # Configure mock responses for full workflow
    task_graph = {
        "tasks": [{"id": "task-1", "description": "Do something"}],
        "parallel_groups": [["task-1"]],
        "risks": [],
        "checkpoints": []
    }

    mock_provider.responses = [
        # Planner response
        create_planner_response(task_graph, tokens=50),
        create_text_response("Planning complete", tokens=10),
        # Coder response
        create_text_response("Implementation complete", tokens=30),
        # Reviewer response
        create_text_response("Approved", tokens=20),
        # Executor response
        create_text_response("Tests passed", tokens=25),
    ]

    # Create orchestrator
    orchestrator = WorkflowOrchestrator(
        agent_registry=agent_registry,
        storage_path=Path("/tmp/test_workflow"),
        provider=mock_provider,
        tool_registry=tool_registry
    )

    # Execute workflow
    result = await orchestrator.handle_user_request("Test workflow")

    # Verify workflow completed
    assert "status" in result
    assert "workflow" in result


@pytest.mark.anyio
async def test_parallel_agent_spawning(coordinator, mock_provider):
    """Test spawning multiple agents in parallel."""
    # Configure responses for multiple agents
    mock_provider.responses = [
        create_text_response("Agent 1 complete", tokens=15),
        create_text_response("Agent 2 complete", tokens=15),
        create_text_response("Agent 3 complete", tokens=15),
    ]

    # Spawn agents in parallel
    agents_tasks = [
        {"type": "coder", "task": {"description": "Task 1"}},
        {"type": "coder", "task": {"description": "Task 2"}},
        {"type": "coder", "task": {"description": "Task 3"}},
    ]

    results = await coordinator.spawn_agents_parallel(agents_tasks)

    # Verify all agents completed
    assert len(results) == 3
    for result in results:
        assert result["status"] == "completed"
        assert result["agent_type"] == "coder"


@pytest.mark.anyio
async def test_task_graph_structure():
    """Test TaskGraph dataclass functionality."""
    task_graph = TaskGraph(
        tasks=[
            {"id": "task-1", "description": "First task"},
            {"id": "task-2", "description": "Second task"}
        ],
        parallel_groups=[["task-1"], ["task-2"]],
        risks=["Risk 1", "Risk 2"],
        checkpoints=["Checkpoint 1"]
    )

    # Test get_task
    task1 = task_graph.get_task("task-1")
    assert task1 is not None
    assert task1["description"] == "First task"

    # Test get_parallel_group
    group0 = task_graph.get_parallel_group(0)
    assert group0 == ["task-1"]

    # Test non-existent task
    no_task = task_graph.get_task("task-999")
    assert no_task is None
