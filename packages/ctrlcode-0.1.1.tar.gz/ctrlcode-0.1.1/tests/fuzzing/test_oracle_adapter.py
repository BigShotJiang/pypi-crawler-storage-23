"""Tests for OracleAdapter."""

import pytest

from ctrlcode.fuzzing.context import (
    ContextDerivation,
    ImplicitAssumption,
    IntegrationContract,
    SystemPlacement,
)
from ctrlcode.fuzzing.oracle_adapter import OracleAdapter
from ctrlcode.providers.base import Provider


class MockProvider(Provider):
    """Mock LLM provider for testing."""

    def __init__(self, response_text: str):
        self.response_text = response_text

    async def generate(self, messages: list[dict], **kwargs) -> dict:
        return {"text": self.response_text}

    async def stream(self, messages: list[dict], **kwargs):
        """Not used in oracle adapter tests."""
        yield {"type": "text", "data": {"text": self.response_text}}

    def normalize_tool_call(self, tool_call: dict) -> dict:
        """Not used in oracle adapter tests."""
        return tool_call


@pytest.fixture
def sample_oracle():
    """Create sample historical oracle."""
    return ContextDerivation(
        system_placement=SystemPlacement(
            system_type="web service",
            layer="HTTP handler",
            callers="HTTP router",
            callees="database layer",
        ),
        environmental_constraints={"language": "Python 3.12", "async": True},
        integration_contracts=[
            IntegrationContract(
                system="PostgreSQL",
                contract="Read user data",
                implicit_requirements=["Connection pooling", "Timeout handling"],
            )
        ],
        behavioral_invariants=[
            "Must return user data for valid ID",
            "Must return 404 for invalid ID",
        ],
        edge_case_surface=["Database connection failure", "Timeout"],
        implicit_assumptions=[
            ImplicitAssumption(
                assumption="User ID is always positive integer",
                risk="SAFE",
                explanation="Standard database primary key",
            )
        ],
        function_invariants={"get_user": ["Must validate ID", "Must handle DB errors"]},
    )


@pytest.mark.asyncio
async def test_adapter_initialization():
    """Test adapter initializes correctly."""
    provider = MockProvider("")
    adapter = OracleAdapter(provider)

    assert adapter.provider is provider


@pytest.mark.asyncio
async def test_adapt_oracle_success(sample_oracle):
    """Test successful oracle adaptation."""
    # Mock response with adapted oracle
    adapted_response = """{
        "system_placement": {
            "system_type": "web service",
            "layer": "HTTP handler",
            "callers": "HTTP router",
            "callees": "database layer"
        },
        "environmental_constraints": {
            "language": "Python 3.12",
            "async": true
        },
        "integration_contracts": [
            {
                "system": "PostgreSQL",
                "contract": "Read user data by email",
                "implicit_requirements": ["Connection pooling", "Timeout handling", "Email validation"]
            }
        ],
        "behavioral_invariants": [
            "Must return user data for valid email",
            "Must return 404 for invalid email"
        ],
        "edge_case_surface": [
            "Database connection failure",
            "Timeout",
            "Invalid email format"
        ],
        "implicit_assumptions": [
            {
                "assumption": "Email is always lowercase",
                "risk": "RISKY",
                "explanation": "Not enforced at database level"
            }
        ],
        "function_invariants": {
            "get_user_by_email": ["Must validate email", "Must handle DB errors"]
        }
    }"""

    provider = MockProvider(adapted_response)
    adapter = OracleAdapter(provider)

    old_code = "def get_user(user_id): return db.query(user_id)"
    new_code = "def get_user_by_email(email): return db.query(email=email)"

    result = await adapter.adapt_oracle(
        sample_oracle, old_code, new_code, "Get user by email", 0.87
    )

    assert result is not None
    assert isinstance(result, ContextDerivation)
    assert "email" in result.behavioral_invariants[0].lower()
    assert "get_user_by_email" in result.function_invariants


@pytest.mark.asyncio
async def test_adapt_oracle_json_in_code_block(sample_oracle):
    """Test adaptation with JSON in markdown code block."""
    adapted_response = """```json
{
    "system_placement": {
        "system_type": "web service",
        "layer": "HTTP handler",
        "callers": "HTTP router",
        "callees": "database layer"
    },
    "environmental_constraints": {"language": "Python 3.12"},
    "integration_contracts": [],
    "behavioral_invariants": ["Adapted invariant"],
    "edge_case_surface": [],
    "implicit_assumptions": [],
    "function_invariants": {}
}
```"""

    provider = MockProvider(adapted_response)
    adapter = OracleAdapter(provider)

    result = await adapter.adapt_oracle(
        sample_oracle,
        "old code",
        "new code",
        "specification",
        0.9,
    )

    assert result is not None
    assert result.behavioral_invariants == ["Adapted invariant"]


@pytest.mark.asyncio
async def test_adapt_oracle_invalid_json(sample_oracle):
    """Test adaptation with invalid JSON response."""
    provider = MockProvider("Not valid JSON at all")
    adapter = OracleAdapter(provider)

    result = await adapter.adapt_oracle(
        sample_oracle, "old code", "new code", "spec", 0.9
    )

    # Should return None on failure
    assert result is None


@pytest.mark.asyncio
async def test_adapt_oracle_missing_fields(sample_oracle):
    """Test adaptation with missing required fields."""
    incomplete_response = """{
        "system_placement": {
            "system_type": "web service",
            "layer": "HTTP handler",
            "callers": "router",
            "callees": "db"
        }
    }"""

    provider = MockProvider(incomplete_response)
    adapter = OracleAdapter(provider)

    result = await adapter.adapt_oracle(
        sample_oracle, "old code", "new code", "spec", 0.9
    )

    # Should return None if required fields missing
    assert result is None


@pytest.mark.asyncio
async def test_adapter_preserves_similarity_score(sample_oracle):
    """Test that similarity score is passed to LLM for context."""
    captured_messages = []

    class CapturingProvider(Provider):
        async def generate(self, messages: list[dict], **kwargs) -> dict:
            captured_messages.extend(messages)
            return {
                "text": """{
                "system_placement": {"system_type": "web", "layer": "api", "callers": "x", "callees": "y"},
                "environmental_constraints": {},
                "integration_contracts": [],
                "behavioral_invariants": [],
                "edge_case_surface": [],
                "implicit_assumptions": [],
                "function_invariants": {}
            }"""
            }

        async def stream(self, messages: list[dict], **kwargs):
            yield {"type": "text", "data": {"text": "test"}}

        def normalize_tool_call(self, tool_call: dict) -> dict:
            return tool_call

    provider = CapturingProvider()
    adapter = OracleAdapter(provider)

    await adapter.adapt_oracle(sample_oracle, "old", "new", "spec", 0.87)

    # Check that similarity score appears in user message
    user_message = captured_messages[1]["content"]
    assert "87" in user_message and "%" in user_message  # Match "87.00%"
