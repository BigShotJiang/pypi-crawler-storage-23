"""Tests for persistent vector store in ContextDerivationEngine."""

import asyncio
import tempfile
from pathlib import Path

import pytest

from ctrlcode.embeddings.embedder import CodeEmbedder
from ctrlcode.fuzzing.context import ContextDerivationEngine
from ctrlcode.providers.base import Provider
from ctrlcode.storage.history_db import CodeRecord, HistoryDB
from datetime import datetime


class MockProvider(Provider):
    """Mock LLM provider for testing."""

    async def generate(self, messages: list[dict], **kwargs) -> dict:
        return {"text": "{}"}

    async def stream(self, messages: list[dict], **kwargs):
        yield {"type": "text", "data": {"text": "{}"}}

    def normalize_tool_call(self, tool_call: dict) -> dict:
        return tool_call


@pytest.mark.asyncio
async def test_vector_store_initializes_empty():
    """Test that vector store initializes empty when no existing index."""
    with tempfile.TemporaryDirectory() as tmpdir:
        provider = MockProvider()
        db = HistoryDB(":memory:")

        engine = ContextDerivationEngine(
            provider=provider,
            history_db=db,
            vector_store_path=Path(tmpdir) / "vs",
        )

        assert engine.vector_store.size == 0
        assert len(engine._indexed_code_ids) == 0


@pytest.mark.asyncio
async def test_vector_store_loads_existing_index():
    """Test that vector store loads existing index on startup."""
    with tempfile.TemporaryDirectory() as tmpdir:
        provider = MockProvider()
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        vs_path = Path(tmpdir) / "vs"

        # Create first engine and add embeddings
        engine1 = ContextDerivationEngine(
            provider=provider,
            history_db=db,
            vector_store_path=vs_path,
            auto_save_interval=1,
        )

        # Add code to DB
        code = "def test(): pass"
        code_embedding = embedder.embed_code(code)
        code_record = CodeRecord(
            code_id="code_1",
            session_id="session_1",
            code=code,
            embedding=code_embedding,
            timestamp=datetime.now(),
        )
        db.store_code(code_record)

        # Trigger search to populate vector store
        await engine1._search_similar_oracle(code_embedding, code, "Test")

        # Verify vector store has 1 embedding
        assert engine1.vector_store.size == 1

        # Create second engine - should load existing index
        engine2 = ContextDerivationEngine(
            provider=provider,
            history_db=db,
            vector_store_path=vs_path,
        )

        # Should load with 1 embedding
        assert engine2.vector_store.size == 1
        assert "code_1" in engine2._indexed_code_ids


@pytest.mark.asyncio
async def test_incremental_additions():
    """Test that only new embeddings are added incrementally."""
    with tempfile.TemporaryDirectory() as tmpdir:
        provider = MockProvider()
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        vs_path = Path(tmpdir) / "vs"

        engine = ContextDerivationEngine(
            provider=provider,
            history_db=db,
            vector_store_path=vs_path,
            auto_save_interval=10,
        )

        # Add first code to DB
        code1 = "def test1(): pass"
        code1_embedding = embedder.embed_code(code1)
        db.store_code(
            CodeRecord(
                code_id="code_1",
                session_id="session_1",
                code=code1,
                embedding=code1_embedding,
                timestamp=datetime.now(),
            )
        )

        # First search - should add 1 embedding
        await engine._search_similar_oracle(code1_embedding, code1, "Test")
        assert engine.vector_store.size == 1
        assert "code_1" in engine._indexed_code_ids

        # Add second code to DB
        code2 = "def test2(): pass"
        code2_embedding = embedder.embed_code(code2)
        db.store_code(
            CodeRecord(
                code_id="code_2",
                session_id="session_2",
                code=code2,
                embedding=code2_embedding,
                timestamp=datetime.now(),
            )
        )

        # Second search - should add only 1 new embedding (incremental)
        await engine._search_similar_oracle(code2_embedding, code2, "Test")
        assert engine.vector_store.size == 2
        assert "code_2" in engine._indexed_code_ids

        # Third search with existing code - should not add anything
        await engine._search_similar_oracle(code1_embedding, code1, "Test")
        assert engine.vector_store.size == 2  # Still 2, no duplicate


@pytest.mark.asyncio
async def test_auto_save_after_interval():
    """Test that vector store auto-saves after N additions."""
    with tempfile.TemporaryDirectory() as tmpdir:
        provider = MockProvider()
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        vs_path = Path(tmpdir) / "vs"

        engine = ContextDerivationEngine(
            provider=provider,
            history_db=db,
            vector_store_path=vs_path,
            auto_save_interval=3,  # Save after 3 additions
        )

        # Add first code to DB
        code0 = "def test0(): pass"
        code0_embedding = embedder.embed_code(code0)
        db.store_code(
            CodeRecord(
                code_id="code_0",
                session_id="session_0",
                code=code0,
                embedding=code0_embedding,
                timestamp=datetime.now(),
            )
        )

        # First search - adds 1 embedding
        await engine._search_similar_oracle(code0_embedding, code0, "Test")
        assert engine._additions_since_save == 1
        assert not (vs_path / "faiss.index").exists()

        # Add second code to DB
        code1 = "def test1(): pass"
        code1_embedding = embedder.embed_code(code1)
        db.store_code(
            CodeRecord(
                code_id="code_1",
                session_id="session_1",
                code=code1,
                embedding=code1_embedding,
                timestamp=datetime.now(),
            )
        )

        # Second search - adds 1 more
        await engine._search_similar_oracle(code1_embedding, code1, "Test")
        assert engine._additions_since_save == 2
        assert not (vs_path / "faiss.index").exists()

        # Add third code to DB
        code2 = "def test2(): pass"
        code2_embedding = embedder.embed_code(code2)
        db.store_code(
            CodeRecord(
                code_id="code_2",
                session_id="session_2",
                code=code2,
                embedding=code2_embedding,
                timestamp=datetime.now(),
            )
        )

        # Third search - adds 1 more, triggers auto-save
        await engine._search_similar_oracle(code2_embedding, code2, "Test")
        assert engine._additions_since_save == 0  # Reset after save

        # Index file should exist now
        assert (vs_path / "faiss.index").exists()
        assert (vs_path / "id_map.txt").exists()


@pytest.mark.asyncio
async def test_no_rebuild_on_repeated_searches():
    """Test that repeated searches don't rebuild the vector store."""
    with tempfile.TemporaryDirectory() as tmpdir:
        provider = MockProvider()
        db = HistoryDB(":memory:")
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        vs_path = Path(tmpdir) / "vs"

        engine = ContextDerivationEngine(
            provider=provider,
            history_db=db,
            vector_store_path=vs_path,
        )

        # Add code to DB
        code = "def test(): return 42"
        code_embedding = embedder.embed_code(code)
        db.store_code(
            CodeRecord(
                code_id="code_1",
                session_id="session_1",
                code=code,
                embedding=code_embedding,
                timestamp=datetime.now(),
            )
        )

        # First search
        await engine._search_similar_oracle(code_embedding, code, "Test")
        initial_size = engine.vector_store.size
        assert initial_size == 1

        # Store the vector store instance ID
        vs_id = id(engine.vector_store)

        # Second search with same code
        await engine._search_similar_oracle(code_embedding, code, "Test")

        # Vector store should be same instance (not rebuilt)
        assert id(engine.vector_store) == vs_id
        assert engine.vector_store.size == initial_size


@pytest.mark.asyncio
async def test_persistence_across_engine_restarts():
    """Test that embeddings persist across engine restarts."""
    with tempfile.TemporaryDirectory() as tmpdir:
        provider = MockProvider()
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        vs_path = Path(tmpdir) / "vs"

        # Use same DB file for both engines
        db_path = Path(tmpdir) / "test.db"
        db1 = HistoryDB(str(db_path))

        # First engine: add embeddings and save
        engine1 = ContextDerivationEngine(
            provider=provider,
            history_db=db1,
            vector_store_path=vs_path,
            auto_save_interval=1,
        )

        # Add 5 codes
        for i in range(5):
            code = f"def func{i}(): return {i}"
            code_embedding = embedder.embed_code(code)
            db1.store_code(
                CodeRecord(
                    code_id=f"code_{i}",
                    session_id=f"session_{i}",
                    code=code,
                    embedding=code_embedding,
                    timestamp=datetime.now(),
                )
            )

        # Trigger searches to populate and save
        for i in range(5):
            code = f"def func{i}(): return {i}"
            await engine1._search_similar_oracle(
                embedder.embed_code(code), code, "Test"
            )

        # Close first engine
        del engine1

        # Create new DB connection and engine
        db2 = HistoryDB(str(db_path))
        engine2 = ContextDerivationEngine(
            provider=provider,
            history_db=db2,
            vector_store_path=vs_path,
        )

        # Should load all 5 embeddings from disk
        assert engine2.vector_store.size == 5
        assert len(engine2._indexed_code_ids) == 5

        # Should have all code IDs
        for i in range(5):
            assert f"code_{i}" in engine2._indexed_code_ids

        # Search with new code - should only add 1 new embedding
        new_code = "def new_func(): return 99"
        new_embedding = embedder.embed_code(new_code)
        db2.store_code(
            CodeRecord(
                code_id="code_new",
                session_id="session_new",
                code=new_code,
                embedding=new_embedding,
                timestamp=datetime.now(),
            )
        )

        await engine2._search_similar_oracle(new_embedding, new_code, "Test")
        assert engine2.vector_store.size == 6  # 5 loaded + 1 new
