"""Tests for technical debt metrics tracking."""

import pytest
from datetime import datetime

from ctrlcode.metrics import TechDebtMetrics, TechDebtSnapshot


@pytest.fixture
def metrics_db(tmp_path):
    """Create temporary metrics database."""
    return TechDebtMetrics(tmp_path / "metrics", project_path=tmp_path)


def test_init_creates_database(tmp_path):
    """Test database initialization."""
    _metrics = TechDebtMetrics(tmp_path / "metrics", project_path=tmp_path)

    assert (tmp_path / "metrics" / "tech_debt.db").exists()


def test_record_snapshot(metrics_db):
    """Test recording a tech debt snapshot."""
    snapshot = TechDebtSnapshot(
        timestamp=datetime.now().isoformat(),
        total_violations=10,
        violations_by_type={"yolo-parsing": 5, "hand-rolled-utils": 5},
        violations_by_file={"src/file1.py": 3, "src/file2.py": 7},
        stale_docs_count=2,
        code_smells={"complexity": 3, "duplication": 2},
        cleanup_prs={"created": 1, "merged": 0, "rejected": 0}
    )

    snapshot_id = metrics_db.record_snapshot(snapshot)

    assert snapshot_id > 0


def test_get_current_state(metrics_db):
    """Test retrieving current tech debt state."""
    # Record a snapshot
    snapshot = TechDebtSnapshot(
        timestamp=datetime.now().isoformat(),
        total_violations=15,
        violations_by_type={"yolo-parsing": 10, "hand-rolled-utils": 5},
        violations_by_file={},
        stale_docs_count=3,
        code_smells={"complexity": 5},
        cleanup_prs={}
    )

    metrics_db.record_snapshot(snapshot)

    # Get current state
    current = metrics_db.get_current_state()

    assert current["total_violations"] == 15
    assert current["stale_docs_count"] == 3
    assert "yolo-parsing" in current["violations_by_type"]


def test_get_current_state_empty(metrics_db):
    """Test current state with no snapshots."""
    current = metrics_db.get_current_state()

    assert current["total_violations"] == 0
    assert current["stale_docs_count"] == 0
    assert current["timestamp"] is None


def test_record_cleanup_pr(metrics_db):
    """Test recording cleanup PRs."""
    metrics_db.record_cleanup_pr(
        pr_number=123,
        status="merged",
        files_changed=5,
        violations_fixed=10,
        created_at=datetime.now().isoformat(),
        merged_at=datetime.now().isoformat()
    )

    velocity = metrics_db.get_cleanup_velocity(days=30)

    assert velocity["merged"] == 1
    assert velocity["violations_fixed"] == 10


def test_get_trend(metrics_db):
    """Test getting tech debt trend."""
    # Record multiple snapshots
    now = datetime.now()

    for i in range(5):
        snapshot = TechDebtSnapshot(
            timestamp=now.isoformat(),
            total_violations=10 + i,
            violations_by_type={},
            violations_by_file={},
            stale_docs_count=i,
            code_smells={},
            cleanup_prs={}
        )
        metrics_db.record_snapshot(snapshot)

    trend = metrics_db.get_trend(days=1)

    assert len(trend) == 5
    assert trend[0]["total_violations"] == 10
    assert trend[-1]["total_violations"] == 14


def test_get_cleanup_velocity(metrics_db):
    """Test cleanup velocity calculation."""
    now = datetime.now().isoformat()

    # Record some PRs
    metrics_db.record_cleanup_pr(123, "merged", 3, 5, now, now)
    metrics_db.record_cleanup_pr(124, "merged", 2, 3, now, now)
    metrics_db.record_cleanup_pr(125, "open", 1, 0, now, None)

    velocity = metrics_db.get_cleanup_velocity(days=30)

    assert velocity["merged"] == 2
    assert velocity["violations_fixed"] == 8  # Sum of both merged PRs (5 + 3)
    assert velocity["created"] == 1


def test_get_hot_spots_empty(metrics_db):
    """Test hot spots with no data."""
    hot_spots = metrics_db.get_hot_spots()

    assert hot_spots == []


def test_generate_dashboard_html(metrics_db):
    """Test dashboard HTML generation."""
    # Record a snapshot
    snapshot = TechDebtSnapshot(
        timestamp=datetime.now().isoformat(),
        total_violations=25,
        violations_by_type={"yolo-parsing": 15, "hand-rolled-utils": 10},
        violations_by_file={},
        stale_docs_count=5,
        code_smells={"complexity": 8},
        cleanup_prs={}
    )

    metrics_db.record_snapshot(snapshot)

    html = metrics_db.generate_dashboard_html()

    assert "Tech Debt Dashboard" in html
    assert "25" in html  # Total violations
    assert "5" in html  # Stale docs
    assert "yolo-parsing" in html
    assert "chart.js" in html  # Includes charting library


def test_save_dashboard(metrics_db, tmp_path):
    """Test saving dashboard to file."""
    # Record a snapshot
    snapshot = TechDebtSnapshot(
        timestamp=datetime.now().isoformat(),
        total_violations=10,
        violations_by_type={},
        violations_by_file={},
        stale_docs_count=2,
        code_smells={},
        cleanup_prs={}
    )

    metrics_db.record_snapshot(snapshot)

    output_path = tmp_path / "dashboard.html"
    result_path = metrics_db.save_dashboard(output_path)

    assert result_path.exists()
    assert result_path == output_path
    assert "Tech Debt Dashboard" in result_path.read_text()


def test_multiple_snapshots_trend(metrics_db):
    """Test trend with increasing violations."""
    now = datetime.now()

    # Simulate worsening tech debt
    for i in range(3):
        snapshot = TechDebtSnapshot(
            timestamp=now.isoformat(),
            total_violations=10 * (i + 1),
            violations_by_type={"yolo-parsing": 5 * (i + 1)},
            violations_by_file={},
            stale_docs_count=i + 1,
            code_smells={},
            cleanup_prs={}
        )
        metrics_db.record_snapshot(snapshot)

    trend = metrics_db.get_trend(days=1)

    assert len(trend) == 3
    assert trend[0]["total_violations"] == 10
    assert trend[1]["total_violations"] == 20
    assert trend[2]["total_violations"] == 30
    # Trend shows increasing debt


def test_dashboard_with_no_data(metrics_db):
    """Test dashboard generation with no data."""
    html = metrics_db.generate_dashboard_html()

    assert "Tech Debt Dashboard" in html
    assert "0" in html  # Zero violations
