"""Tests for custom linters."""

import pytest
from pathlib import Path
from ctrlcode.linters import lint_yolo_parsing, lint_hand_rolled_utils


@pytest.fixture
def tmp_python_file(tmp_path):
    """Create a temporary Python file for testing."""
    def _create_file(content: str) -> Path:
        file_path = tmp_path / "test_code.py"
        file_path.write_text(content)
        return file_path
    return _create_file


# YOLO Parsing Tests

def test_yolo_parsing_detects_direct_dict_access(tmp_python_file):
    """Test detection of direct dictionary access."""
    code = """
def process(data):
    value = data["key"]
    return value
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    assert len(violations) == 1
    assert violations[0].principle == "no-yolo-parsing"
    assert 'data["key"]' in violations[0].message


def test_yolo_parsing_detects_nested_dict_access(tmp_python_file):
    """Test detection of nested dictionary access."""
    code = """
def process(data):
    email = data["user"]["email"]
    return email
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    # Should detect the nested access
    assert len(violations) >= 1
    assert violations[0].principle == "no-yolo-parsing"
    assert "Nested dict access" in violations[0].message or "user" in violations[0].message


def test_yolo_parsing_skips_validation_context(tmp_python_file):
    """Test that validation contexts don't trigger violations."""
    code = """
def process(data):
    try:
        value = data["key"]
    except KeyError:
        value = None
    return value
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    # Should not detect violations in try/except KeyError
    assert len(violations) == 0


def test_yolo_parsing_skips_validated_names(tmp_python_file):
    """Test that validated names don't trigger violations."""
    code = """
from dataclasses import dataclass

@dataclass
class Config:
    key: str

def process(data):
    config = Config(**data)
    value = config.key
    return value
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    # Should not detect violations after dataclass validation
    # Note: config.key is attribute access, not subscript
    assert len(violations) == 0


def test_yolo_parsing_skips_safe_patterns(tmp_python_file):
    """Test that safe patterns (self, cls, os, sys) are skipped."""
    code = """
class MyClass:
    def method(self):
        return self["key"]

def get_env():
    return os["HOME"]
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    # Should skip self and os
    assert len(violations) == 0


def test_yolo_parsing_multiple_violations(tmp_python_file):
    """Test detection of multiple violations in one file."""
    code = """
def process(data):
    name = data["name"]
    email = data["email"]
    age = data["age"]
    return name, email, age
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    # Should detect 3 violations
    assert len(violations) == 3


def test_yolo_parsing_invalid_syntax(tmp_python_file):
    """Test handling of files with syntax errors."""
    code = """
def process(data):
    value = data["key"
    # Missing closing bracket
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    # Should return empty list on syntax error
    assert len(violations) == 0


# Hand-Rolled Utils Tests

def test_hand_rolled_detects_retry_loop(tmp_python_file):
    """Test detection of retry loops."""
    code = """
def fetch_data():
    for i in range(3):
        try:
            return requests.get("http://example.com")
        except Exception:
            continue
"""
    file_path = tmp_python_file(code)
    violations = lint_hand_rolled_utils(file_path)

    # Should detect retry pattern
    assert any(v.principle == "prefer-shared-utils" and "retry" in v.message.lower()
               for v in violations)


def test_hand_rolled_detects_retry_function(tmp_python_file):
    """Test detection of custom retry functions."""
    code = """
def retry_operation(func, max_attempts=3):
    for i in range(max_attempts):
        try:
            return func()
        except Exception:
            continue
"""
    file_path = tmp_python_file(code)
    violations = lint_hand_rolled_utils(file_path)

    # Should detect custom retry function
    assert any(v.principle == "prefer-shared-utils" and "retry" in v.message.lower()
               for v in violations)


def test_hand_rolled_detects_print_statements(tmp_python_file):
    """Test detection of print statements."""
    code = """
def process(data):
    print(f"Processing {data}")
    result = data * 2
    print("Done")
    return result
"""
    file_path = tmp_python_file(code)
    violations = lint_hand_rolled_utils(file_path)

    # Should detect both print statements
    print_violations = [v for v in violations if "print" in v.message.lower()]
    assert len(print_violations) == 2
    assert all(v.principle == "structured-logging" for v in print_violations)


def test_hand_rolled_skips_commented_print(tmp_python_file):
    """Test that commented print statements are skipped."""
    code = """
def process(data):
    # print(f"Debug: {data}")
    result = data * 2
    return result
"""
    file_path = tmp_python_file(code)
    violations = lint_hand_rolled_utils(file_path)

    # Should not detect commented print
    print_violations = [v for v in violations if "print" in v.message.lower()]
    assert len(print_violations) == 0


def test_hand_rolled_multiple_violations(tmp_python_file):
    """Test detection of multiple violation types."""
    code = """
def retry_fetch():
    print("Starting fetch")
    for i in range(3):
        try:
            print(f"Attempt {i}")
            return fetch()
        except Exception:
            continue
"""
    file_path = tmp_python_file(code)
    violations = lint_hand_rolled_utils(file_path)

    # Should detect: retry function name + retry loop + 2 prints
    assert len(violations) >= 3


def test_hand_rolled_normal_for_loop(tmp_python_file):
    """Test that normal for loops without retry don't trigger violations."""
    code = """
def process_items(items):
    for item in items:
        process(item)
"""
    file_path = tmp_python_file(code)
    violations = lint_hand_rolled_utils(file_path)

    # Should not detect normal for loop
    retry_violations = [v for v in violations if "retry" in v.message.lower()]
    assert len(retry_violations) == 0


def test_hand_rolled_invalid_syntax(tmp_python_file):
    """Test handling of files with syntax errors."""
    code = """
def process():
    print("test"
    # Missing closing paren
"""
    file_path = tmp_python_file(code)
    violations = lint_hand_rolled_utils(file_path)

    # Should return empty list on syntax error
    assert len(violations) == 0


# Integration Tests

def test_violation_has_required_fields(tmp_python_file):
    """Test that violations have all required fields."""
    code = """
def process(data):
    print(data["key"])
"""
    file_path = tmp_python_file(code)

    # Test both linters
    for linter in [lint_yolo_parsing, lint_hand_rolled_utils]:
        violations = linter(file_path)
        if violations:
            v = violations[0]
            assert hasattr(v, "file")
            assert hasattr(v, "line")
            assert hasattr(v, "column")
            assert hasattr(v, "message")
            assert hasattr(v, "severity")
            assert hasattr(v, "fix_suggestion")
            assert hasattr(v, "principle")
            assert isinstance(v.file, str)
            assert isinstance(v.line, int)
            assert isinstance(v.column, int)
            assert v.line > 0
            assert v.column >= 0


def test_fix_suggestion_references_docs(tmp_python_file):
    """Test that fix suggestions reference golden principles docs."""
    code = """
def process(data):
    value = data["key"]
"""
    file_path = tmp_python_file(code)
    violations = lint_yolo_parsing(file_path)

    assert len(violations) == 1
    assert "docs/golden-principles" in violations[0].fix_suggestion
    assert violations[0].principle in violations[0].fix_suggestion
