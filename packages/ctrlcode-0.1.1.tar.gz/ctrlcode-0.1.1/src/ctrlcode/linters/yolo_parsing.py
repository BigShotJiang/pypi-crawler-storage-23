"""YOLO parsing linter - detects dict access without validation."""

import ast
from pathlib import Path
from typing import Iterator
from dataclasses import dataclass


@dataclass
class Violation:
    """A linting violation."""

    file: str
    line: int
    column: int
    message: str
    severity: str
    fix_suggestion: str
    principle: str


class YoloParsingDetector(ast.NodeVisitor):
    """AST visitor to detect dictionary access without validation."""

    def __init__(self, filepath: str):
        """
        Initialize detector.

        Args:
            filepath: Path to file being analyzed
        """
        self.filepath = filepath
        self.violations: list[Violation] = []
        self.in_validation_context = False
        self.validated_names: set[str] = set()

    def visit_Try(self, node: ast.Try) -> None:
        """Track try blocks (might be validation)."""
        # Check if this is validation pattern (try/except KeyError)
        has_keyerror = any(
            isinstance(handler.type, ast.Name) and handler.type.id == "KeyError"
            for handler in node.handlers
            if handler.type
        )

        if has_keyerror:
            self.in_validation_context = True
            self.generic_visit(node)
            self.in_validation_context = False
        else:
            self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        """Track validation function calls."""
        # Check for schema validation patterns
        if isinstance(node.func, ast.Attribute):
            # Pydantic: Model(**data), Model.parse(data)
            if node.func.attr in ("parse", "parse_obj", "parse_raw"):
                if node.args:
                    arg = node.args[0]
                    if isinstance(arg, ast.Name):
                        self.validated_names.add(arg.id)

        # Check for dataclass instantiation
        if isinstance(node.func, ast.Name):
            # Assuming uppercase names are classes/validators
            if node.func.id and node.func.id[0].isupper():
                for keyword in node.keywords:
                    if isinstance(keyword.value, ast.Name):
                        self.validated_names.add(keyword.value.id)

        self.generic_visit(node)

    def visit_Subscript(self, node: ast.Subscript) -> None:
        """Detect dictionary subscript access."""
        # Skip if in validation context
        if self.in_validation_context:
            self.generic_visit(node)
            return

        # Check if this is dict access on a variable
        if isinstance(node.value, ast.Name):
            var_name = node.value.id

            # Skip if already validated
            if var_name in self.validated_names:
                self.generic_visit(node)
                return

            # Skip common safe patterns
            if var_name in ("self", "cls", "os", "sys"):
                self.generic_visit(node)
                return

            # Nested subscript (e.g., data["user"]["email"])
            if isinstance(node.slice, ast.Constant) and isinstance(node.slice.value, str):
                # This looks like YOLO dict access
                key = node.slice.value

                violation = Violation(
                    file=self.filepath,
                    line=node.lineno,
                    column=node.col_offset,
                    message=f'Accessing {var_name}["{key}"] without validation',
                    severity="warning",
                    fix_suggestion=f"""Use schema validation at boundary:

from dataclasses import dataclass

@dataclass
class DataSchema:
    {key}: str  # Define expected structure

validated = DataSchema(**{var_name})
value = validated.{key}

Why: Prevents runtime crashes from unexpected data shapes.
See: docs/golden-principles/no-yolo-parsing.md""",
                    principle="no-yolo-parsing"
                )

                self.violations.append(violation)

        # Check for chained subscripts (data["user"]["email"])
        elif isinstance(node.value, ast.Subscript):
            # This is nested dict access - likely YOLO
            violation = Violation(
                file=self.filepath,
                line=node.lineno,
                column=node.col_offset,
                message="Nested dict access without validation",
                severity="warning",
                fix_suggestion="""Use schema validation to define structure:

from dataclasses import dataclass

@dataclass
class UserData:
    user: dict  # Or better: user: User (nested dataclass)

validated = UserData(**data)
value = validated.user["field"]

Why: Makes data contract explicit and fails fast on malformed input.
See: docs/golden-principles/no-yolo-parsing.md""",
                principle="no-yolo-parsing"
            )

            self.violations.append(violation)

        self.generic_visit(node)


def lint_file(filepath: Path) -> list[Violation]:
    """
    Lint a Python file for YOLO parsing violations.

    Args:
        filepath: Path to Python file

    Returns:
        List of violations found
    """
    try:
        source = filepath.read_text()
        tree = ast.parse(source, filename=str(filepath))

        detector = YoloParsingDetector(str(filepath))
        detector.visit(tree)

        return detector.violations

    except SyntaxError:
        # File has syntax errors, skip
        return []
    except Exception:
        # Other errors, skip
        return []


def lint_directory(directory: Path, pattern: str = "**/*.py") -> Iterator[Violation]:
    """
    Lint all Python files in directory.

    Args:
        directory: Root directory to search
        pattern: Glob pattern for files to lint

    Yields:
        Violations found
    """
    for filepath in directory.glob(pattern):
        if filepath.is_file():
            for violation in lint_file(filepath):
                yield violation


def format_violation(violation: Violation) -> str:
    """
    Format violation for output.

    Args:
        violation: Violation to format

    Returns:
        Formatted string
    """
    severity_symbol = "⚠️" if violation.severity == "warning" else "❌"

    return f"""{severity_symbol} YOLO Parsing Detected
File: {violation.file}:{violation.line}:{violation.column}
Rule: golden-principles/{violation.principle}.md

{violation.message}

FIX: {violation.fix_suggestion}
"""
