"""Hand-rolled utilities linter - detects duplicate patterns."""

import ast
import re
from pathlib import Path
from typing import Iterator
from dataclasses import dataclass


@dataclass
class Violation:
    """A linting violation."""

    file: str
    line: int
    column: int
    message: str
    severity: str
    fix_suggestion: str
    principle: str


class HandRolledUtilsDetector(ast.NodeVisitor):
    """AST visitor to detect hand-rolled utility patterns."""

    def __init__(self, filepath: str, source: str):
        """
        Initialize detector.

        Args:
            filepath: Path to file being analyzed
            source: Source code content
        """
        self.filepath = filepath
        self.source = source
        self.violations: list[Violation] = []

    def visit_For(self, node: ast.For) -> None:
        """Detect retry patterns in for loops."""
        # Pattern: for i in range(N): try: ... except: ...
        if isinstance(node.iter, ast.Call):
            if isinstance(node.iter.func, ast.Name) and node.iter.func.id == "range":
                # Check if body has try/except
                has_try_except = any(isinstance(stmt, ast.Try) for stmt in node.body)

                if has_try_except:
                    # Get source snippet
                    try:
                        source_lines = self.source.split("\n")
                        snippet = source_lines[node.lineno - 1][:50] + "..."
                    except Exception:
                        snippet = "retry loop"

                    violation = Violation(
                        file=self.filepath,
                        line=node.lineno,
                        column=node.col_offset,
                        message=f"Hand-rolled retry logic detected: {snippet}",
                        severity="info",
                        fix_suggestion="""Use shared retry utility:

from ctrlcode.utils import retry

@retry(max_attempts=3, backoff_base=2.0)
def your_function():
    # Your code here
    pass

Why: Centralizes retry logic, ensures consistency across codebase.
See: docs/golden-principles/prefer-shared-utils.md""",
                        principle="prefer-shared-utils"
                    )

                    self.violations.append(violation)

        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Detect common utility function patterns."""
        # Check for retry in function name
        if "retry" in node.name.lower():
            violation = Violation(
                file=self.filepath,
                line=node.lineno,
                column=node.col_offset,
                message=f"Custom retry function '{node.name}' - consider using shared utility",
                severity="info",
                fix_suggestion="""Use shared retry utility instead:

from ctrlcode.utils import retry

# Remove this function and use decorator:
@retry(max_attempts=3)
def your_function():
    pass

Why: Shared utilities are tested, maintained, and consistent.
See: docs/golden-principles/prefer-shared-utils.md""",
                principle="prefer-shared-utils"
            )

            self.violations.append(violation)

        self.generic_visit(node)


def detect_print_statements(filepath: Path, source: str) -> list[Violation]:
    """
    Detect print statements (should use logging).

    Args:
        filepath: Path to file
        source: Source code

    Returns:
        List of violations
    """
    violations = []

    for lineno, line in enumerate(source.split("\n"), start=1):
        # Skip comments
        if line.strip().startswith("#"):
            continue

        # Detect print() calls (not in strings)
        if re.search(r'\bprint\s*\(', line):
            violations.append(Violation(
                file=str(filepath),
                line=lineno,
                column=line.find("print"),
                message="Using print() instead of structured logging",
                severity="warning",
                fix_suggestion="""Use structured logging:

import structlog
logger = structlog.get_logger(__name__)

# Instead of:
# print(f"Processing {item}")

# Use:
logger.info("processing.started", item=item)

Why: Enables log querying, filtering, and agent analysis.
See: docs/golden-principles/structured-logging.md""",
                principle="structured-logging"
            ))

    return violations


def lint_file(filepath: Path) -> list[Violation]:
    """
    Lint a Python file for hand-rolled utilities.

    Args:
        filepath: Path to Python file

    Returns:
        List of violations found
    """
    try:
        source = filepath.read_text()
        tree = ast.parse(source, filename=str(filepath))

        detector = HandRolledUtilsDetector(str(filepath), source)
        detector.visit(tree)

        # Add print statement detection
        print_violations = detect_print_statements(filepath, source)
        detector.violations.extend(print_violations)

        return detector.violations

    except SyntaxError:
        return []
    except Exception:
        return []


def lint_directory(directory: Path, pattern: str = "**/*.py") -> Iterator[Violation]:
    """
    Lint all Python files in directory.

    Args:
        directory: Root directory to search
        pattern: Glob pattern for files to lint

    Yields:
        Violations found
    """
    for filepath in directory.glob(pattern):
        if filepath.is_file():
            # Skip test files and virtual environments
            if "test" in str(filepath) or ".venv" in str(filepath):
                continue

            for violation in lint_file(filepath):
                yield violation


def format_violation(violation: Violation) -> str:
    """
    Format violation for output.

    Args:
        violation: Violation to format

    Returns:
        Formatted string
    """
    severity_symbol = "ℹ️" if violation.severity == "info" else "⚠️"

    return f"""{severity_symbol} Hand-Rolled Utility Detected
File: {violation.file}:{violation.line}:{violation.column}
Rule: golden-principles/{violation.principle}.md

{violation.message}

FIX: {violation.fix_suggestion}
"""
