"""User permission system for file operations."""

import asyncio
import logging
from dataclasses import dataclass
from typing import Callable, Optional
from uuid import uuid4

logger = logging.getLogger(__name__)


@dataclass
class PermissionRequest:
    """Request for user permission."""

    operation: str  # "write_file", "read_file", etc.
    path: str  # Path being accessed
    reason: str  # Why permission is needed
    details: Optional[dict] = None  # Additional context


class PermissionManager:
    """Manages user permissions for file operations."""

    def __init__(self, approval_callback: Optional[Callable[[str, PermissionRequest], None]] = None):
        """Initialize permission manager.

        Args:
            approval_callback: Async function to send permission request to TUI
                             Called with (request_id, request)
                             If None, all requests are auto-approved (dev mode)
        """
        self.approval_callback = approval_callback
        self._approved_paths: set[str] = set()  # Paths approved this session
        self._pending_requests: dict[str, asyncio.Future] = {}  # request_id -> Future[bool]

    async def request_permission_async(
        self,
        operation: str,
        path: str,
        reason: str,
        details: Optional[dict] = None,
        remember: bool = False,
        timeout: float = 60.0
    ) -> bool:
        """Request user permission for an operation (async).

        Args:
            operation: Operation name
            path: File/directory path
            reason: Human-readable reason
            details: Additional context
            remember: If True, remember approval for this path
            timeout: Timeout in seconds (default 60)

        Returns:
            True if approved, False if denied
        """
        # Check if already approved this session
        cache_key = f"{operation}:{path}"
        if cache_key in self._approved_paths:
            logger.debug(f"Permission cached for {operation} on {path}")
            return True

        # No callback = auto-approve (dev mode)
        if not self.approval_callback:
            logger.warning(f"Auto-approving {operation} on {path} (no callback)")
            return True

        # Create permission request
        request = PermissionRequest(
            operation=operation,
            path=path,
            reason=reason,
            details=details
        )

        # Generate unique request ID
        request_id = str(uuid4())

        # Create future for response
        future: asyncio.Future[bool] = asyncio.Future()
        self._pending_requests[request_id] = future

        try:
            # Send request to TUI via callback
            await self.approval_callback(request_id, request)

            # Wait for response with timeout
            approved = await asyncio.wait_for(future, timeout=timeout)

            if approved and remember:
                self._approved_paths.add(cache_key)
                logger.info(f"Cached approval for {operation} on {path}")

            return approved

        except asyncio.TimeoutError:
            logger.warning(f"Permission request timed out for {operation} on {path}")
            return False  # Deny on timeout

        except Exception as e:
            logger.error(f"Permission request error: {e}")
            return False  # Fail closed

        finally:
            # Clean up pending request
            self._pending_requests.pop(request_id, None)

    def handle_permission_response(self, request_id: str, approved: bool) -> None:
        """Handle permission response from TUI.

        Args:
            request_id: Request ID
            approved: Whether user approved
        """
        future = self._pending_requests.get(request_id)

        if not future:
            logger.warning(f"No pending request for ID {request_id}")
            return

        if future.done():
            logger.warning(f"Request {request_id} already completed")
            return

        # Set result to unblock waiting task
        future.set_result(approved)
        logger.info(f"Permission {'approved' if approved else 'denied'} for request {request_id}")

    def clear_cache(self):
        """Clear all cached approvals."""
        self._approved_paths.clear()


# Global instance (set by server on init)
_permission_manager: Optional[PermissionManager] = None


def set_permission_manager(manager: PermissionManager):
    """Set global permission manager."""
    global _permission_manager
    _permission_manager = manager


def get_permission_manager() -> Optional[PermissionManager]:
    """Get global permission manager."""
    return _permission_manager


async def request_permission(
    operation: str,
    path: str,
    reason: str,
    details: Optional[dict] = None,
    remember: bool = False,
    timeout: float = 60.0
) -> bool:
    """Request permission using global manager (async).

    Args:
        operation: Operation name
        path: File/directory path
        reason: Human-readable reason
        details: Additional context
        remember: Cache approval for session
        timeout: Timeout in seconds

    Returns:
        True if approved, False if denied
    """
    manager = get_permission_manager()

    if not manager:
        # No manager = dev mode, auto-approve
        logger.warning(f"No permission manager, auto-approving {operation} on {path}")
        return True

    return await manager.request_permission_async(operation, path, reason, details, remember, timeout)
