"""FAISS-based vector storage for fast similarity search."""

import logging
from pathlib import Path
from typing import Optional

import faiss
import numpy as np

logger = logging.getLogger(__name__)


class VectorStore:
    """Fast approximate nearest neighbor search using FAISS HNSW index.

    Supports efficient similarity search over thousands of embeddings.
    Uses HNSW (Hierarchical Navigable Small World) algorithm for sub-millisecond queries.
    """

    def __init__(
        self,
        dimension: int = 384,  # Default for all-MiniLM-L6-v2
        index_type: str = "hnsw",
        M: int = 32,  # HNSW construction parameter (connectivity)
        ef_construction: int = 200,  # HNSW build quality
        ef_search: int = 64,  # HNSW search quality
    ):
        """Initialize vector store with FAISS index.

        Args:
            dimension: Embedding vector dimension
            index_type: Index type (hnsw or flat)
            M: HNSW parameter - higher = better recall, more memory
            ef_construction: HNSW build-time search depth
            ef_search: HNSW query-time search depth
        """
        self.dimension = dimension
        self.index_type = index_type
        self.M = M
        self.ef_construction = ef_construction
        self.ef_search = ef_search

        # Initialize index
        # Note: For cosine similarity with normalized vectors:
        # - Flat index uses inner product (IP) directly
        # - HNSW uses L2 distance (converted to cosine in search results)
        if index_type == "hnsw":
            # IndexHNSWFlat uses L2 distance only
            self.index = faiss.IndexHNSWFlat(dimension, M)
            self.index.hnsw.efConstruction = ef_construction
            self.index.hnsw.efSearch = ef_search
        elif index_type == "flat":
            # Exact search for small datasets with inner product
            self.index = faiss.IndexFlatIP(dimension)  # Inner product (cosine for normalized)
        else:
            raise ValueError(f"Unknown index type: {index_type}")

        # Track IDs separately (FAISS uses integer IDs)
        self.id_map: list[str] = []

    def add(
        self,
        embeddings: np.ndarray | list[np.ndarray],
        ids: list[str],
    ) -> None:
        """Add embeddings to the index.

        Args:
            embeddings: Single embedding or array of embeddings
            ids: Corresponding string IDs
        """
        # Convert single embedding to batch
        if isinstance(embeddings, list):
            embeddings = np.array(embeddings)

        if embeddings.ndim == 1:
            embeddings = embeddings.reshape(1, -1)

        if embeddings.shape[0] != len(ids):
            raise ValueError(f"Mismatch: {embeddings.shape[0]} embeddings, {len(ids)} IDs")

        if embeddings.shape[1] != self.dimension:
            raise ValueError(f"Wrong dimension: {embeddings.shape[1]}, expected {self.dimension}")

        # Ensure float32 for FAISS
        embeddings = embeddings.astype(np.float32)

        # Add to index
        self.index.add(embeddings)
        self.id_map.extend(ids)

        logger.debug(f"Added {len(ids)} embeddings to index (total: {len(self.id_map)})")

    def search(
        self,
        query_embedding: np.ndarray,
        k: int = 5,
        min_similarity: Optional[float] = None,
    ) -> list[tuple[str, float]]:
        """Search for k most similar embeddings.

        Args:
            query_embedding: Query vector
            k: Number of results to return
            min_similarity: Minimum similarity threshold (filter results)

        Returns:
            List of (id, similarity_score) tuples, sorted by similarity (descending)
        """
        if len(self.id_map) == 0:
            return []

        # Reshape query
        if query_embedding.ndim == 1:
            query_embedding = query_embedding.reshape(1, -1)

        query_embedding = query_embedding.astype(np.float32)

        # Limit k to available items
        k = min(k, len(self.id_map))

        # Search
        distances, indices = self.index.search(query_embedding, k)

        # Convert to (id, score) tuples
        results = []
        for idx, dist in zip(indices[0], distances[0]):
            if idx < 0 or idx >= len(self.id_map):
                continue  # Invalid index

            # Convert distance to similarity based on index type
            if self.index_type == "hnsw":
                # For L2 distance on normalized vectors: cosine_sim = 1 - (L2²/2)
                # FAISS returns squared L2 distance
                similarity = float(1.0 - (dist / 2.0))
            else:
                # For inner product, distance IS similarity
                similarity = float(dist)

            # Filter by threshold
            if min_similarity is not None and similarity < min_similarity:
                continue

            results.append((self.id_map[idx], similarity))

        return results

    def save(self, path: Path) -> None:
        """Save index and ID map to disk.

        Args:
            path: Directory to save to
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        # Save FAISS index
        index_file = path / "faiss.index"
        faiss.write_index(self.index, str(index_file))

        # Save ID map
        id_map_file = path / "id_map.txt"
        with open(id_map_file, "w") as f:
            f.write("\n".join(self.id_map))

        logger.info(f"Saved vector store to {path} ({len(self.id_map)} embeddings)")

    def load(self, path: Path) -> None:
        """Load index and ID map from disk.

        Args:
            path: Directory to load from
        """
        path = Path(path)

        # Load FAISS index
        index_file = path / "faiss.index"
        if not index_file.exists():
            raise FileNotFoundError(f"Index file not found: {index_file}")

        self.index = faiss.read_index(str(index_file))

        # Update ef_search for HNSW
        if self.index_type == "hnsw" and hasattr(self.index, "hnsw"):
            self.index.hnsw.efSearch = self.ef_search

        # Load ID map
        id_map_file = path / "id_map.txt"
        if not id_map_file.exists():
            raise FileNotFoundError(f"ID map not found: {id_map_file}")

        with open(id_map_file, "r") as f:
            self.id_map = [line.strip() for line in f if line.strip()]

        logger.info(f"Loaded vector store from {path} ({len(self.id_map)} embeddings)")

    @property
    def size(self) -> int:
        """Number of embeddings in the index."""
        return len(self.id_map)

    def clear(self) -> None:
        """Clear all embeddings from the index."""
        # Reinitialize index
        if self.index_type == "hnsw":
            self.index = faiss.IndexHNSWFlat(self.dimension, self.M)
            self.index.hnsw.efConstruction = self.ef_construction
            self.index.hnsw.efSearch = self.ef_search
        else:
            self.index = faiss.IndexFlatIP(self.dimension)

        self.id_map = []
        logger.debug("Cleared vector store")
