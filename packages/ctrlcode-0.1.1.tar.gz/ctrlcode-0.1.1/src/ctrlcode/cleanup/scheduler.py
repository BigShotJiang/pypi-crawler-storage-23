"""Cleanup agent scheduler for automated code quality scans."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

logger = logging.getLogger(__name__)


class CleanupScheduler:
    """Scheduler for automated cleanup agent runs."""

    def __init__(
        self,
        workspace_root: Path,
        results_dir: Path | None = None,
        on_scan_complete: Callable[[dict[str, Any]], None] | None = None,
    ):
        """
        Initialize cleanup scheduler.

        Args:
            workspace_root: Root directory of workspace
            results_dir: Directory to store scan results (defaults to .ctrlcode/cleanup/results/)
            on_scan_complete: Optional callback when scan completes
        """
        self.workspace_root = Path(workspace_root)
        self.results_dir = results_dir or (self.workspace_root / ".ctrlcode" / "cleanup" / "results")
        self.results_dir.mkdir(parents=True, exist_ok=True)

        self.on_scan_complete = on_scan_complete
        self.scheduler = BackgroundScheduler()
        self.is_running = False

    def start(self):
        """Start the scheduler."""
        if not self.is_running:
            self.scheduler.start()
            self.is_running = True
            logger.info("Cleanup scheduler started")

    def stop(self):
        """Stop the scheduler."""
        if self.is_running:
            self.scheduler.shutdown()
            self.is_running = False
            logger.info("Cleanup scheduler stopped")

    def add_nightly_scan(self, scan_type: str, hour: int = 2, minute: int = 0):
        """
        Add nightly scan job.

        Args:
            scan_type: Type of scan to run
            hour: Hour to run (0-23, default: 2am)
            minute: Minute to run (0-59, default: 0)
        """
        trigger = CronTrigger(hour=hour, minute=minute)
        job_id = f"nightly_{scan_type}"

        self.scheduler.add_job(
            func=self._run_scan,
            trigger=trigger,
            args=[scan_type],
            id=job_id,
            name=f"Nightly {scan_type} scan",
            replace_existing=True,
        )

        logger.info(f"Scheduled nightly {scan_type} scan at {hour:02d}:{minute:02d}")

    def add_weekly_scan(self, scan_type: str, day_of_week: int = 0, hour: int = 2, minute: int = 0):
        """
        Add weekly scan job.

        Args:
            scan_type: Type of scan to run
            day_of_week: Day of week (0=Monday, 6=Sunday)
            hour: Hour to run (0-23, default: 2am)
            minute: Minute to run (0-59, default: 0)
        """
        trigger = CronTrigger(day_of_week=day_of_week, hour=hour, minute=minute)
        job_id = f"weekly_{scan_type}"

        self.scheduler.add_job(
            func=self._run_scan,
            trigger=trigger,
            args=[scan_type],
            id=job_id,
            name=f"Weekly {scan_type} scan",
            replace_existing=True,
        )

        logger.info(f"Scheduled weekly {scan_type} scan on day {day_of_week} at {hour:02d}:{minute:02d}")

    def add_interval_scan(self, scan_type: str, hours: int = 0, minutes: int = 0):
        """
        Add interval-based scan job.

        Args:
            scan_type: Type of scan to run
            hours: Interval in hours
            minutes: Interval in minutes
        """
        trigger = IntervalTrigger(hours=hours, minutes=minutes)
        job_id = f"interval_{scan_type}"

        self.scheduler.add_job(
            func=self._run_scan,
            trigger=trigger,
            args=[scan_type],
            id=job_id,
            name=f"Interval {scan_type} scan",
            replace_existing=True,
        )

        logger.info(f"Scheduled interval {scan_type} scan every {hours}h {minutes}m")

    def remove_scan(self, scan_type: str, schedule_type: str):
        """
        Remove scheduled scan.

        Args:
            scan_type: Type of scan
            schedule_type: Schedule type (nightly, weekly, interval)
        """
        job_id = f"{schedule_type}_{scan_type}"
        try:
            self.scheduler.remove_job(job_id)
            logger.info(f"Removed {schedule_type} {scan_type} scan")
        except Exception as e:
            logger.error(f"Failed to remove scan {job_id}: {e}")

    def run_scan_now(self, scan_type: str) -> dict[str, Any]:
        """
        Run scan immediately (synchronous).

        Args:
            scan_type: Type of scan to run

        Returns:
            Scan results
        """
        return self._run_scan(scan_type)

    def _run_scan(self, scan_type: str) -> dict[str, Any]:
        """
        Execute cleanup scan.

        Args:
            scan_type: Type of scan to run

        Returns:
            Scan results
        """
        logger.info(f"Running {scan_type} cleanup scan")
        start_time = datetime.now()

        try:
            # Run the appropriate scan
            if scan_type == "golden_principles":
                results = self._scan_golden_principles()
            elif scan_type == "stale_docs":
                results = self._scan_stale_docs()
            elif scan_type == "code_smells":
                results = self._scan_code_smells()
            elif scan_type == "duplicates":
                results = self._scan_duplicates()
            else:
                raise ValueError(f"Unknown scan type: {scan_type}")

            # Add metadata
            results["scan_type"] = scan_type
            results["timestamp"] = start_time.isoformat()
            results["duration_seconds"] = (datetime.now() - start_time).total_seconds()
            results["status"] = "completed"

            # Store results
            self._store_results(scan_type, results)

            # Notify callback
            if self.on_scan_complete:
                self.on_scan_complete(results)

            logger.info(f"Completed {scan_type} scan in {results['duration_seconds']:.2f}s")
            return results

        except Exception as e:
            logger.error(f"Scan {scan_type} failed: {e}", exc_info=True)
            error_results = {
                "scan_type": scan_type,
                "timestamp": start_time.isoformat(),
                "status": "failed",
                "error": str(e),
            }
            self._store_results(scan_type, error_results)
            return error_results

    def _scan_golden_principles(self) -> dict[str, Any]:
        """Scan for golden principles violations."""
        from ..linters import lint_yolo_parsing, lint_hand_rolled_utils

        violations = []
        violation_counts = {}

        # Scan all Python files
        for py_file in self.workspace_root.rglob("*.py"):
            # Skip test directories and virtual environments
            path_parts = py_file.parts
            if ".venv" in path_parts or "tests" in path_parts or "__pycache__" in path_parts:
                continue

            # Run linters
            for linter_name, linter_func in [
                ("yolo_parsing", lint_yolo_parsing),
                ("hand_rolled_utils", lint_hand_rolled_utils),
            ]:
                file_violations = linter_func(py_file)
                for v in file_violations:
                    violations.append({
                        "file": v.file,
                        "line": v.line,
                        "column": v.column,
                        "message": v.message,
                        "severity": v.severity,
                        "principle": v.principle,
                        "linter": linter_name,
                    })
                    violation_counts[v.principle] = violation_counts.get(v.principle, 0) + 1

        return {
            "total_violations": len(violations),
            "violations_by_principle": violation_counts,
            "violations": violations[:100],  # Limit to first 100 for storage
        }

    def _scan_stale_docs(self) -> dict[str, Any]:
        """Scan for stale documentation."""
        import subprocess

        stale_docs = []

        # Find markdown files
        for md_file in self.workspace_root.rglob("*.md"):
            if ".venv" in str(md_file):
                continue

            # Get last modified time
            try:
                result = subprocess.run(
                    ["git", "log", "-1", "--format=%ct", str(md_file)],
                    cwd=self.workspace_root,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )

                if result.returncode == 0 and result.stdout.strip():
                    last_modified = int(result.stdout.strip())
                    days_old = (datetime.now().timestamp() - last_modified) / 86400

                    # Flag as stale if > 90 days old
                    if days_old > 90:
                        stale_docs.append({
                            "file": str(md_file.relative_to(self.workspace_root)),
                            "days_old": int(days_old),
                        })
            except Exception:
                continue

        return {
            "total_stale": len(stale_docs),
            "stale_docs": sorted(stale_docs, key=lambda x: x["days_old"], reverse=True),
        }

    def _scan_code_smells(self) -> dict[str, Any]:
        """Scan for code smells using static analysis."""
        import subprocess

        smells = {}

        # Run pylint for complexity metrics
        try:
            result = subprocess.run(
                ["python", "-m", "pylint", "--disable=all", "--enable=R", str(self.workspace_root / "src")],
                capture_output=True,
                text=True,
                timeout=60,
            )

            # Parse output for complexity warnings
            for line in result.stdout.split("\n"):
                if "too-many" in line.lower():
                    smells["complexity"] = smells.get("complexity", 0) + 1
        except Exception:
            pass

        return {"total_smells": sum(smells.values()), "smells_by_type": smells}

    def _scan_duplicates(self) -> dict[str, Any]:
        """Scan for duplicate code patterns."""
        # Placeholder - would integrate with tools like jscpd or similar
        return {"total_duplicates": 0, "duplicate_blocks": []}

    def _store_results(self, scan_type: str, results: dict[str, Any]):
        """Store scan results to file."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{scan_type}_{timestamp}.json"
        filepath = self.results_dir / filename

        with open(filepath, "w") as f:
            json.dump(results, f, indent=2)

        logger.info(f"Stored scan results: {filepath}")

    def get_latest_results(self, scan_type: str) -> dict[str, Any] | None:
        """
        Get latest results for scan type.

        Args:
            scan_type: Type of scan

        Returns:
            Latest scan results or None
        """
        pattern = f"{scan_type}_*.json"
        result_files = sorted(self.results_dir.glob(pattern), reverse=True)

        if result_files:
            with open(result_files[0]) as f:
                return json.load(f)

        return None

    def get_scheduled_jobs(self) -> list[dict[str, Any]]:
        """
        Get list of scheduled jobs.

        Returns:
            List of job info dicts
        """
        jobs = []
        for job in self.scheduler.get_jobs():
            jobs.append({
                "id": job.id,
                "name": job.name,
                "next_run": job.next_run_time.isoformat() if job.next_run_time else None,
                "trigger": str(job.trigger),
            })
        return jobs
