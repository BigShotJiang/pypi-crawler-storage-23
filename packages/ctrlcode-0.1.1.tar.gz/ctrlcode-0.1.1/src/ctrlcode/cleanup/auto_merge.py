"""Auto-merge capability for cleanup PRs."""

import json
import logging
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class AutoMergeConfig:
    """Configuration for auto-merge."""

    enabled: bool = False
    wait_minutes: int = 60
    max_files: int = 5
    max_lines_changed: int = 100
    excluded_paths: list[str] | None = None
    dry_run: bool = False


class AutoMerge:
    """Auto-merge logic for cleanup PRs."""

    def __init__(self, workspace_root: Path, config: AutoMergeConfig | None = None, audit_log_path: Path | None = None):
        """
        Initialize auto-merge.

        Args:
            workspace_root: Root directory of workspace
            config: Auto-merge configuration
            audit_log_path: Path to audit log file
        """
        self.workspace_root = Path(workspace_root)
        self.config = config or AutoMergeConfig()
        self.audit_log_path = audit_log_path or (self.workspace_root / ".ctrlcode" / "auto_merge_audit.jsonl")
        self.audit_log_path.parent.mkdir(parents=True, exist_ok=True)

    def check_and_merge_pr(self, pr_number: int) -> dict[str, Any]:
        """
        Check if PR meets auto-merge criteria and merge if eligible.

        Args:
            pr_number: PR number to check

        Returns:
            Dict with merge status and details
        """
        if not self.config.enabled:
            return {"status": "skipped", "reason": "Auto-merge disabled"}

        try:
            # Get PR details
            pr_info = self._get_pr_info(pr_number)

            if not pr_info:
                return {"status": "error", "reason": "Failed to get PR info"}

            # Check eligibility
            eligibility = self._check_eligibility(pr_info)

            if not eligibility["eligible"]:
                return {
                    "status": "ineligible",
                    "reason": eligibility["reason"],
                    "pr_number": pr_number,
                }

            # Wait for review period
            if self.config.wait_minutes > 0:
                created_at_str = pr_info["created_at"].replace("Z", "+00:00")
                created_at = datetime.fromisoformat(created_at_str)

                # Strip timezone for simpler comparison
                if created_at.tzinfo:
                    created_at = created_at.replace(tzinfo=None)

                wait_until = created_at + timedelta(minutes=self.config.wait_minutes)
                now = datetime.now()

                if now < wait_until:
                    remaining = (wait_until - now).total_seconds() / 60
                    return {
                        "status": "waiting",
                        "reason": f"Waiting {remaining:.0f}m for review period",
                        "pr_number": pr_number,
                    }

            # Dry run mode
            if self.config.dry_run:
                self._log_audit(pr_number, "dry_run", pr_info)
                return {
                    "status": "dry_run",
                    "message": "Would merge PR (dry run mode)",
                    "pr_number": pr_number,
                }

            # Merge the PR
            merge_result = self._merge_pr(pr_number)

            self._log_audit(pr_number, "merged", pr_info, merge_result)

            return {
                "status": "merged",
                "pr_number": pr_number,
                "merge_sha": merge_result.get("merge_sha"),
            }

        except Exception as e:
            logger.error(f"Failed to auto-merge PR #{pr_number}: {e}", exc_info=True)
            return {"status": "error", "reason": str(e), "pr_number": pr_number}

    def _get_pr_info(self, pr_number: int) -> dict[str, Any] | None:
        """Get PR information from GitHub."""
        try:
            result = subprocess.run(
                [
                    "gh",
                    "pr",
                    "view",
                    str(pr_number),
                    "--json",
                    "number,title,state,author,labels,createdAt,files,additions,deletions,statusCheckRollup",
                ],
                cwd=self.workspace_root,
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                logger.error(f"Failed to get PR info: {result.stderr}")
                return None

            pr_data = json.loads(result.stdout)

            return {
                "number": pr_data["number"],
                "title": pr_data["title"],
                "state": pr_data["state"],
                "author": pr_data["author"]["login"],
                "labels": [label["name"] for label in pr_data.get("labels", [])],
                "created_at": pr_data["createdAt"],
                "files": pr_data.get("files", []),
                "additions": pr_data.get("additions", 0),
                "deletions": pr_data.get("deletions", 0),
                "checks": pr_data.get("statusCheckRollup", []),
            }

        except Exception as e:
            logger.error(f"Error getting PR info: {e}")
            return None

    def _check_eligibility(self, pr_info: dict[str, Any]) -> dict[str, Any]:
        """
        Check if PR meets auto-merge criteria.

        Args:
            pr_info: PR information

        Returns:
            Dict with eligible status and reason
        """
        # Check if PR is open
        if pr_info["state"] != "OPEN":
            return {"eligible": False, "reason": "PR is not open"}

        # Check for auto-merge label
        if "auto-merge-candidate" not in pr_info["labels"]:
            return {"eligible": False, "reason": "Missing auto-merge-candidate label"}

        # Check file count
        file_count = len(pr_info["files"])
        if file_count > self.config.max_files:
            return {
                "eligible": False,
                "reason": f"Too many files changed ({file_count} > {self.config.max_files})",
            }

        # Check lines changed
        lines_changed = pr_info["additions"] + pr_info["deletions"]
        if lines_changed > self.config.max_lines_changed:
            return {
                "eligible": False,
                "reason": f"Too many lines changed ({lines_changed} > {self.config.max_lines_changed})",
            }

        # Check excluded paths
        if self.config.excluded_paths:
            for file in pr_info["files"]:
                file_path = file.get("path", "")
                for excluded in self.config.excluded_paths:
                    if excluded in file_path:
                        return {
                            "eligible": False,
                            "reason": f"Changes in excluded path: {excluded}",
                        }

        # Check CI status
        checks_status = self._check_ci_status(pr_info["checks"])
        if not checks_status["all_passed"]:
            return {"eligible": False, "reason": checks_status["reason"]}

        return {"eligible": True, "reason": "All criteria met"}

    def _check_ci_status(self, checks: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Check CI status for all checks.

        Args:
            checks: List of status checks

        Returns:
            Dict with all_passed status and reason
        """
        if not checks:
            # No checks configured - allow merge
            return {"all_passed": True, "reason": "No checks configured"}

        failed_checks = []
        pending_checks = []

        for check in checks:
            # Handle both check runs and status contexts
            status = check.get("status") or check.get("state")
            conclusion = check.get("conclusion")

            if status == "COMPLETED" and conclusion == "SUCCESS":
                continue
            elif status in ("PENDING", "IN_PROGRESS", "QUEUED"):
                pending_checks.append(check.get("name", "unknown"))
            else:
                failed_checks.append(check.get("name", "unknown"))

        if failed_checks:
            return {
                "all_passed": False,
                "reason": f"Failed checks: {', '.join(failed_checks)}",
            }

        if pending_checks:
            return {
                "all_passed": False,
                "reason": f"Pending checks: {', '.join(pending_checks)}",
            }

        return {"all_passed": True, "reason": "All checks passed"}

    def _merge_pr(self, pr_number: int) -> dict[str, Any]:
        """
        Merge the PR using gh CLI.

        Args:
            pr_number: PR number to merge

        Returns:
            Dict with merge result
        """
        result = subprocess.run(
            [
                "gh",
                "pr",
                "merge",
                str(pr_number),
                "--auto",
                "--squash",  # Squash commits for clean history
                "--delete-branch",  # Clean up after merge
            ],
            cwd=self.workspace_root,
            capture_output=True,
            text=True,
            timeout=30,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Merge failed: {result.stderr}")

        # Parse merge SHA from output
        merge_sha = None
        for line in result.stdout.split("\n"):
            if "merged" in line.lower():
                # Extract SHA if present
                parts = line.split()
                for part in parts:
                    if len(part) == 40 and all(c in "0123456789abcdef" for c in part):
                        merge_sha = part
                        break

        return {"merge_sha": merge_sha, "output": result.stdout}

    def _log_audit(
        self,
        pr_number: int,
        action: str,
        pr_info: dict[str, Any],
        merge_result: dict[str, Any] | None = None,
    ):
        """
        Log audit entry for auto-merge action.

        Args:
            pr_number: PR number
            action: Action taken (merged, dry_run, rejected)
            pr_info: PR information
            merge_result: Merge result if applicable
        """
        audit_entry = {
            "timestamp": datetime.now().isoformat(),
            "pr_number": pr_number,
            "action": action,
            "pr_title": pr_info.get("title"),
            "pr_author": pr_info.get("author"),
            "files_changed": len(pr_info.get("files", [])),
            "lines_changed": pr_info.get("additions", 0) + pr_info.get("deletions", 0),
        }

        if merge_result:
            audit_entry["merge_sha"] = merge_result.get("merge_sha")

        with open(self.audit_log_path, "a") as f:
            f.write(json.dumps(audit_entry) + "\n")

        logger.info(f"Audit log: {action} PR #{pr_number}")

    def get_audit_log(self, limit: int = 100) -> list[dict[str, Any]]:
        """
        Get recent audit log entries.

        Args:
            limit: Maximum number of entries to return

        Returns:
            List of audit entries
        """
        if not self.audit_log_path.exists():
            return []

        entries = []
        with open(self.audit_log_path) as f:
            for line in f:
                try:
                    entries.append(json.loads(line))
                except Exception:
                    continue

        return entries[-limit:]
