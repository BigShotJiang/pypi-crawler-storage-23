"""Automated PR creation for cleanup refactorings."""

import logging
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PRConfig:
    """Configuration for auto-PR creation."""

    enabled: bool = False
    max_files_per_pr: int = 5
    require_tests_pass: bool = True
    require_linter_pass: bool = True
    auto_assign_reviewers: list[str] | None = None
    base_branch: str = "main"


class PRAutomation:
    """Automated PR creation for cleanup refactorings."""

    def __init__(self, workspace_root: Path, config: PRConfig | None = None):
        """
        Initialize PR automation.

        Args:
            workspace_root: Root directory of workspace
            config: PR configuration
        """
        self.workspace_root = Path(workspace_root)
        self.config = config or PRConfig()

    def create_cleanup_pr(
        self,
        scan_results: dict[str, Any],
        fixes: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """
        Create PR for cleanup refactoring.

        Args:
            scan_results: Results from cleanup scan
            fixes: Optional list of fixes to apply

        Returns:
            Dict with PR info or error
        """
        if not self.config.enabled:
            return {"status": "skipped", "reason": "PR automation disabled"}

        if not self._check_gh_cli():
            return {"status": "error", "reason": "gh CLI not available"}

        # Determine principle being fixed
        principle = scan_results.get("scan_type", "unknown")

        # Create branch name
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        branch_name = f"refactor/{principle}-{timestamp}"

        try:
            # Create and checkout new branch
            self._run_git(["checkout", "-b", branch_name])

            # Apply fixes if provided
            files_changed = []
            if fixes:
                for fix in fixes[:self.config.max_files_per_pr]:
                    if self._apply_fix(fix):
                        files_changed.append(fix.get("file"))

            if not files_changed:
                # No changes made, cleanup branch
                self._run_git(["checkout", self.config.base_branch])
                self._run_git(["branch", "-D", branch_name])
                return {"status": "skipped", "reason": "No changes to commit"}

            # Run tests if required
            if self.config.require_tests_pass:
                if not self._run_tests():
                    self._cleanup_branch(branch_name)
                    return {"status": "failed", "reason": "Tests failed"}

            # Run linter if required
            if self.config.require_linter_pass:
                if not self._run_linter():
                    self._cleanup_branch(branch_name)
                    return {"status": "failed", "reason": "Linter failed"}

            # Commit changes
            commit_msg = self._generate_commit_message(principle, files_changed)
            self._run_git(["add"] + files_changed)
            self._run_git(["commit", "-m", commit_msg])

            # Push to remote
            self._run_git(["push", "-u", "origin", branch_name])

            # Create PR
            pr_info = self._create_pr(principle, scan_results, files_changed, branch_name)

            return {
                "status": "success",
                "branch": branch_name,
                "pr_url": pr_info.get("url"),
                "pr_number": pr_info.get("number"),
                "files_changed": files_changed,
            }

        except Exception as e:
            logger.error(f"Failed to create PR: {e}", exc_info=True)
            self._cleanup_branch(branch_name)
            return {"status": "error", "reason": str(e)}

    def _check_gh_cli(self) -> bool:
        """Check if gh CLI is available."""
        try:
            result = subprocess.run(
                ["gh", "--version"],
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False

    def _run_git(self, args: list[str], check: bool = True) -> subprocess.CompletedProcess:
        """Run git command."""
        result = subprocess.run(
            ["git"] + args,
            cwd=self.workspace_root,
            capture_output=True,
            text=True,
            timeout=30,
        )

        if check and result.returncode != 0:
            raise RuntimeError(f"Git command failed: {result.stderr}")

        return result

    def _apply_fix(self, fix: dict[str, Any]) -> bool:
        """
        Apply a single fix to file.

        Args:
            fix: Fix specification with file, old_content, new_content

        Returns:
            True if fix was applied
        """
        try:
            file_path = self.workspace_root / fix["file"]

            if not file_path.exists():
                logger.warning(f"File not found: {file_path}")
                return False

            content = file_path.read_text()

            # Simple replacement for now
            old = fix.get("old_content")
            new = fix.get("new_content")

            if old and old in content:
                updated = content.replace(old, new, 1)
                file_path.write_text(updated)
                logger.info(f"Applied fix to {file_path}")
                return True

            return False

        except Exception as e:
            logger.error(f"Failed to apply fix: {e}")
            return False

    def _run_tests(self) -> bool:
        """Run tests to verify changes."""
        try:
            result = subprocess.run(
                ["pytest", "-x"],  # Stop on first failure
                cwd=self.workspace_root,
                capture_output=True,
                timeout=300,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Tests failed: {e}")
            return False

    def _run_linter(self) -> bool:
        """Run linter to verify code quality."""
        try:
            result = subprocess.run(
                ["ruff", "check"],
                cwd=self.workspace_root,
                capture_output=True,
                timeout=60,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Linter failed: {e}")
            return False

    def _generate_commit_message(self, principle: str, files_changed: list[str]) -> str:
        """Generate commit message."""
        file_list = ", ".join(Path(f).name for f in files_changed[:3])
        if len(files_changed) > 3:
            file_list += f", +{len(files_changed) - 3} more"

        return f"""refactor: fix {principle} violations

Automated cleanup of {principle} violations in {file_list}.

Co-Authored-By: Cleanup Agent <noreply@ctrlcode.dev>"""

    def _create_pr(
        self,
        principle: str,
        scan_results: dict[str, Any],
        files_changed: list[str],
        branch_name: str,
    ) -> dict[str, Any]:
        """Create GitHub PR using gh CLI."""
        title = f"Refactor: Fix {principle} violations"

        body = self._generate_pr_body(principle, scan_results, files_changed)

        # Build gh pr create command
        cmd = [
            "gh",
            "pr",
            "create",
            "--title",
            title,
            "--body",
            body,
            "--base",
            self.config.base_branch,
            "--head",
            branch_name,
            "--label",
            "automated-cleanup",
            "--label",
            "auto-merge-candidate",
        ]

        # Add reviewers if configured
        if self.config.auto_assign_reviewers:
            for reviewer in self.config.auto_assign_reviewers:
                cmd.extend(["--reviewer", reviewer])

        result = subprocess.run(
            cmd,
            cwd=self.workspace_root,
            capture_output=True,
            text=True,
            timeout=30,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Failed to create PR: {result.stderr}")

        # Parse PR URL from output
        pr_url = result.stdout.strip()

        # Get PR number
        pr_number = None
        if pr_url:
            pr_number = pr_url.split("/")[-1]

        return {"url": pr_url, "number": pr_number}

    def _generate_pr_body(
        self, principle: str, scan_results: dict[str, Any], files_changed: list[str]
    ) -> str:
        """Generate PR body."""
        violations_count = scan_results.get("total_violations", 0)

        body = f"""## Summary

Automated cleanup of **{principle}** violations.

**Violations fixed:** {violations_count}
**Files changed:** {len(files_changed)}

## Changes

"""

        for file in files_changed:
            body += f"- `{file}`\n"

        body += f"""

## Principle

This PR addresses violations of the **{principle}** golden principle.

See: `docs/golden-principles/{principle}.md`

## Testing

- [x] All existing tests pass
- [x] Linter passes

## Notes

This PR was automatically generated by the Cleanup Agent. Changes are focused
and minimal to reduce review burden.

---

🤖 Generated with Cleanup Agent
"""

        return body

    def _cleanup_branch(self, branch_name: str):
        """Cleanup branch after failure."""
        try:
            self._run_git(["checkout", self.config.base_branch], check=False)
            self._run_git(["branch", "-D", branch_name], check=False)
        except Exception:
            pass
