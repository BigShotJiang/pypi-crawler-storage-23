"""Reusable ReAct loop execution for agents and sessions."""

import logging
import json
from typing import Any, Callable
from dataclasses import dataclass

from harnessutils import ConversationManager, Message, TextPart

from ..providers.base import Provider, StreamEvent
from ..tools.executor import ToolExecutor

logger = logging.getLogger(__name__)


@dataclass
class ReActResult:
    """Result from executing a ReAct loop."""

    assistant_text: str
    tool_calls: list[dict[str, Any]]
    usage_tokens: int
    continuation_count: int


class AgentReActLoop:
    """Execute ReAct (Reason + Act) loops with tool calling."""

    def __init__(self):
        """Initialize ReAct loop executor."""
        self.msg_id_counter = 0

    def _generate_msg_id(self) -> str:
        """Generate unique message ID."""
        self.msg_id_counter += 1
        return f"msg_{self.msg_id_counter}"

    async def execute(
        self,
        provider: Provider,
        conv_manager: ConversationManager,
        conv_id: str,
        tool_executor: ToolExecutor,
        tools: list[dict[str, Any]],
        allowed_tools: list[str] | None = None,
        max_continuations: int = 50,
        event_callback: Callable[[StreamEvent], None] | None = None,
    ) -> ReActResult:
        """
        Execute ReAct loop with tool calling.

        Args:
            provider: LLM provider to stream from
            conv_manager: Conversation manager
            conv_id: Conversation ID
            tool_executor: Tool executor for running tools
            tools: Tool definitions to pass to LLM
            allowed_tools: Optional list of allowed tool names (for filtering)
            max_continuations: Maximum continuation iterations
            event_callback: Optional callback for streaming events

        Returns:
            ReActResult with aggregated output
        """
        usage_tokens = 0
        accumulated_text: list[str] = []
        all_tool_calls: list[dict] = []

        # Get current messages
        messages = conv_manager.to_model_format(conv_id)

        # First pass: stream and collect tool calls
        assistant_text = []
        tool_calls: list[dict] = []
        current_tool_call: dict | None = None

        async for event in provider.stream(messages, tools=tools):
            if event_callback:
                event_callback(event)

            if event.type == "text":
                text_chunk = event.data["text"]
                assistant_text.append(text_chunk)
                accumulated_text.append(text_chunk)

            elif event.type == "usage":
                usage = event.data.get("usage", {})
                usage_tokens += usage.get("completion_tokens", 0)

            elif event.type == "tool_call_start":
                current_tool_call = {
                    "tool": event.data["tool"],
                    "call_id": event.data["call_id"],
                    "input": ""
                }

            elif event.type == "tool_call_delta":
                if current_tool_call:
                    current_tool_call["input"] += event.data.get("delta", "")

            elif event.type == "content_block_stop":
                if current_tool_call:
                    try:
                        current_tool_call["input"] = json.loads(current_tool_call["input"])
                    except json.JSONDecodeError:
                        current_tool_call["input"] = {}
                    tool_calls.append(current_tool_call)
                    all_tool_calls.append(current_tool_call)
                    current_tool_call = None

        # Execute tools if any were called
        if tool_calls and tool_executor:
            # Add assistant message with tool use
            assistant_msg = Message(id=self._generate_msg_id(), role="assistant")
            if assistant_text:
                assistant_msg.add_part(TextPart(text="".join(assistant_text)))
            conv_manager.add_message(conv_id, assistant_msg)

            # Execute all tools
            for tool_call in tool_calls:
                # Filter by allowed_tools if specified
                if allowed_tools and tool_call["tool"] not in allowed_tools:
                    logger.warning(f"Tool {tool_call['tool']} not in allowed list, skipping")
                    continue

                result = await tool_executor.execute(
                    tool_name=tool_call["tool"],
                    arguments=tool_call["input"],
                    call_id=tool_call["call_id"]
                )

                # Emit tool result event
                if event_callback:
                    event_callback(StreamEvent(
                        type="tool_result",
                        data={
                            "tool": tool_call["tool"],
                            "success": result.success,
                            "result": result.result if result.success else result.error
                        }
                    ))

                # Add tool result message
                tool_result_msg = Message(id=self._generate_msg_id(), role="user")
                result_text = f"[Tool: {tool_call['tool']}]\n"
                if result.success:
                    result_text += f"Result: {result.result}"
                else:
                    result_text += f"Error: {result.error}"
                tool_result_msg.add_part(TextPart(text=result_text))
                conv_manager.add_message(conv_id, tool_result_msg)

            # Continuation loop: keep calling tools until LLM stops
            continuation_count = 0

            while tool_calls and continuation_count < max_continuations:
                continuation_count += 1
                logger.info(f"ReAct continuation {continuation_count}/{max_continuations}")

                # Add continuation prompt
                reminder_msg = Message(id=self._generate_msg_id(), role="user")
                reminder_msg.add_part(TextPart(
                    text="Continue using tools to complete the task. Call more tools if needed."
                ))
                conv_manager.add_message(conv_id, reminder_msg)

                # Get updated messages
                messages = conv_manager.to_model_format(conv_id)

                # Stream continuation
                continuation_text = []
                continuation_tool_calls = []
                current_continuation_tool = None

                async for event in provider.stream(messages, tools=tools):
                    if event_callback:
                        event_callback(event)

                    if event.type == "text":
                        continuation_text.append(event.data["text"])
                        accumulated_text.append(event.data["text"])

                    elif event.type == "usage":
                        usage = event.data.get("usage", {})
                        usage_tokens += usage.get("completion_tokens", 0)

                    elif event.type == "tool_call_start":
                        current_continuation_tool = {
                            "tool": event.data["tool"],
                            "call_id": event.data["call_id"],
                            "input": ""
                        }

                    elif event.type == "tool_call_delta":
                        if current_continuation_tool:
                            current_continuation_tool["input"] += event.data.get("delta", "")

                    elif event.type == "content_block_stop":
                        if current_continuation_tool:
                            try:
                                current_continuation_tool["input"] = json.loads(
                                    current_continuation_tool["input"]
                                )
                            except json.JSONDecodeError:
                                current_continuation_tool["input"] = {}
                            continuation_tool_calls.append(current_continuation_tool)
                            all_tool_calls.append(current_continuation_tool)
                            current_continuation_tool = None

                # Add continuation assistant message
                cont_assistant_msg = Message(id=self._generate_msg_id(), role="assistant")
                if continuation_text:
                    cont_assistant_msg.add_part(TextPart(text="".join(continuation_text)))
                conv_manager.add_message(conv_id, cont_assistant_msg)

                # Execute continuation tools
                if continuation_tool_calls:
                    for tool_call in continuation_tool_calls:
                        # Filter by allowed_tools
                        if allowed_tools and tool_call["tool"] not in allowed_tools:
                            logger.warning(f"Tool {tool_call['tool']} not allowed, skipping")
                            continue

                        result = await tool_executor.execute(
                            tool_name=tool_call["tool"],
                            arguments=tool_call["input"],
                            call_id=tool_call["call_id"]
                        )

                        # Emit tool result
                        if event_callback:
                            event_callback(StreamEvent(
                                type="tool_result",
                                data={
                                    "tool": tool_call["tool"],
                                    "success": result.success,
                                    "result": result.result if result.success else result.error,
                                    "continuation": True,
                                    "continuation_index": continuation_count
                                }
                            ))

                        # Add tool result message
                        tool_result_msg = Message(id=self._generate_msg_id(), role="user")
                        result_text = f"[Tool: {tool_call['tool']}]\n"
                        if result.success:
                            result_text += f"Result: {result.result}"
                        else:
                            result_text += f"Error: {result.error}"
                        tool_result_msg.add_part(TextPart(text=result_text))
                        conv_manager.add_message(conv_id, tool_result_msg)

                    # Update tool_calls for next iteration
                    tool_calls = continuation_tool_calls
                else:
                    # No more tools called, exit loop
                    logger.info(f"ReAct loop ending after {continuation_count} continuations")
                    break

            # Emit continuation summary
            if event_callback:
                event_callback(StreamEvent(
                    type="continuation_complete",
                    data={
                        "iterations": continuation_count,
                        "tool_count": len(all_tool_calls)
                    }
                ))

            # Final summary call (no tools)
            messages = conv_manager.to_model_format(conv_id)
            final_text = []

            async for event in provider.stream(messages, tools=tools):
                if event_callback:
                    event_callback(event)

                if event.type == "text":
                    final_text.append(event.data["text"])
                    accumulated_text.append(event.data["text"])

                elif event.type == "usage":
                    usage = event.data.get("usage", {})
                    usage_tokens += usage.get("completion_tokens", 0)

            # Add final assistant message
            if final_text:
                final_msg = Message(id=self._generate_msg_id(), role="assistant")
                final_msg.add_part(TextPart(text="".join(final_text)))
                conv_manager.add_message(conv_id, final_msg)

        return ReActResult(
            assistant_text="".join(accumulated_text),
            tool_calls=all_tool_calls,
            usage_tokens=usage_tokens,
            continuation_count=continuation_count if tool_calls else 0
        )
