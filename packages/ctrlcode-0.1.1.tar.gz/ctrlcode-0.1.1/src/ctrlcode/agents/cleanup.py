"""Cleanup agent implementation for continuous tech debt paydown."""

import re
from typing import Any
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Violation:
    """Code violation found during scan."""

    principle: str
    file: str
    line: int
    snippet: str
    severity: str  # "high" | "medium" | "low"
    fix_suggestion: str
    auto_fixable: bool


@dataclass
class CleanupMetrics:
    """Metrics from cleanup scan."""

    scan_date: str
    violations_by_principle: dict[str, int]
    code_smells: dict[str, int]
    stale_docs: int
    total_issues: int
    high_priority: int
    auto_fixable: int


class GoldenPrinciplesScanner:
    """Scanner for golden principle violations."""

    PRINCIPLES = {
        "no-bare-excepts": {
            "pattern": r"except\s*:",
            "description": "Bare except clause",
            "severity": "high",
        },
        "no-print-statements": {
            "pattern": r"\bprint\s*\(",
            "description": "Print statement in production code",
            "severity": "medium",
        },
        "prefer-shared-utils": {
            "patterns": [
                r"for\s+\w+\s+in\s+range\(\d+\):\s*try:",  # Hand-rolled retry
                r"def\s+retry_\w+\(",  # Custom retry function
            ],
            "description": "Hand-rolled utility (use shared library)",
            "severity": "medium",
        },
    }

    def scan_principle(
        self,
        principle: str,
        code_content: str,
        file_path: str
    ) -> list[Violation]:
        """
        Scan code for specific principle violation.

        Args:
            principle: Principle name (e.g., "no-bare-excepts")
            code_content: File content to scan
            file_path: File path for reporting

        Returns:
            List of violations found
        """
        violations = []

        if principle not in self.PRINCIPLES:
            return violations

        rule = self.PRINCIPLES[principle]
        patterns = rule.get("patterns", [rule.get("pattern")])

        for pattern in patterns:
            for match in re.finditer(pattern, code_content, re.MULTILINE):
                line_num = code_content[:match.start()].count('\n') + 1

                # Extract snippet (3 lines context)
                lines = code_content.splitlines()
                start_line = max(0, line_num - 2)
                end_line = min(len(lines), line_num + 1)
                snippet = '\n'.join(lines[start_line:end_line])

                violations.append(Violation(
                    principle=principle,
                    file=file_path,
                    line=line_num,
                    snippet=snippet,
                    severity=rule["severity"],
                    fix_suggestion=self._get_fix_suggestion(principle),
                    auto_fixable=self._is_auto_fixable(principle)
                ))

        return violations

    def _get_fix_suggestion(self, principle: str) -> str:
        """Get fix suggestion for principle."""
        suggestions = {
            "no-bare-excepts": "Replace with specific exception type and add logging",
            "no-print-statements": "Replace with logger.info() or logger.debug()",
            "prefer-shared-utils": "Use tenacity or other established library",
        }
        return suggestions.get(principle, "Review and refactor")

    def _is_auto_fixable(self, principle: str) -> bool:
        """Determine if violation is auto-fixable."""
        # Only simple cases are auto-fixable
        auto_fixable = {"no-print-statements"}
        return principle in auto_fixable


class CodeSmellDetector:
    """Detector for code smells and anti-patterns."""

    def detect_long_functions(
        self,
        code_content: str,
        file_path: str,
        threshold: int = 50
    ) -> list[dict[str, Any]]:
        """
        Find functions exceeding line count threshold.

        Args:
            code_content: File content
            file_path: File path
            threshold: Maximum lines per function

        Returns:
            List of long function issues
        """
        issues = []
        lines = code_content.splitlines()

        # Find function definitions
        func_pattern = r'^(\s*)def\s+(\w+)\s*\('

        for i, line in enumerate(lines):
            match = re.match(func_pattern, line)
            if not match:
                continue

            indent = len(match.group(1))
            func_name = match.group(2)
            start_line = i + 1

            # Count lines until next function at same indent level
            func_lines = 0
            for j in range(i + 1, len(lines)):
                if re.match(r'^\s*def\s+', lines[j]):
                    # Check indent level
                    next_indent = len(lines[j]) - len(lines[j].lstrip())
                    if next_indent <= indent:
                        break
                func_lines += 1

            if func_lines > threshold:
                issues.append({
                    "type": "long_function",
                    "file": file_path,
                    "line": start_line,
                    "function": func_name,
                    "lines": func_lines,
                    "threshold": threshold,
                    "suggestion": f"Extract subfunctions from {func_name} ({func_lines} lines)"
                })

        return issues

    def detect_duplicated_imports(
        self,
        code_content: str,
        file_path: str
    ) -> list[dict[str, Any]]:
        """
        Find duplicate import statements.

        Args:
            code_content: File content
            file_path: File path

        Returns:
            List of duplicate import issues
        """
        issues = []
        imports_seen = {}

        import_pattern = r'^(from\s+[\w.]+\s+)?import\s+([\w,\s]+)'

        for i, line in enumerate(code_content.splitlines()):
            match = re.match(import_pattern, line.strip())
            if not match:
                continue

            import_stmt = match.group(0)

            if import_stmt in imports_seen:
                issues.append({
                    "type": "duplicate_import",
                    "file": file_path,
                    "line": i + 1,
                    "import": import_stmt,
                    "previous_line": imports_seen[import_stmt],
                    "suggestion": "Remove duplicate import"
                })
            else:
                imports_seen[import_stmt] = i + 1

        return issues


class DocFreshnessChecker:
    """Checker for documentation freshness."""

    def check_markdown_links(
        self,
        content: str,
        file_path: str
    ) -> list[dict[str, Any]]:
        """
        Find broken markdown links.

        Args:
            content: Markdown content
            file_path: File path

        Returns:
            List of broken link issues
        """
        issues = []

        # Find markdown links [text](url)
        link_pattern = r'\[([^\]]+)\]\(([^\)]+)\)'

        for match in re.finditer(link_pattern, content):
            link_text = match.group(1)
            link_url = match.group(2)
            line_num = content[:match.start()].count('\n') + 1

            # Check for broken internal links (files that don't exist)
            if not link_url.startswith(('http://', 'https://', '#')):
                # Internal file link
                issues.append({
                    "type": "internal_link",
                    "file": file_path,
                    "line": line_num,
                    "link": link_url,
                    "text": link_text,
                    "suggestion": "Verify link target exists"
                })

        return issues


class CleanupAgent:
    """Coordinates cleanup scans and refactoring tasks."""

    def __init__(self):
        """Initialize cleanup agent."""
        self.principles_scanner = GoldenPrinciplesScanner()
        self.smell_detector = CodeSmellDetector()
        self.doc_checker = DocFreshnessChecker()

    def scan_golden_principles(
        self,
        files: list[tuple[str, str]],
        principles: list[str] | None = None
    ) -> list[Violation]:
        """
        Scan files for golden principle violations.

        Args:
            files: List of (file_path, content) tuples
            principles: Optional list of specific principles to check

        Returns:
            List of violations found
        """
        all_violations = []

        principles_to_check = principles or list(
            self.principles_scanner.PRINCIPLES.keys()
        )

        for file_path, content in files:
            for principle in principles_to_check:
                violations = self.principles_scanner.scan_principle(
                    principle,
                    content,
                    file_path
                )
                all_violations.extend(violations)

        return all_violations

    def scan_code_smells(
        self,
        files: list[tuple[str, str]]
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Scan files for code smells.

        Args:
            files: List of (file_path, content) tuples

        Returns:
            Dict mapping smell type to list of issues
        """
        all_issues = {
            "long_functions": [],
            "duplicate_imports": [],
        }

        for file_path, content in files:
            # Detect long functions
            long_funcs = self.smell_detector.detect_long_functions(
                content,
                file_path
            )
            all_issues["long_functions"].extend(long_funcs)

            # Detect duplicate imports
            dup_imports = self.smell_detector.detect_duplicated_imports(
                content,
                file_path
            )
            all_issues["duplicate_imports"].extend(dup_imports)

        return all_issues

    def generate_metrics(
        self,
        violations: list[Violation],
        code_smells: dict[str, list[dict[str, Any]]],
        stale_docs: int
    ) -> CleanupMetrics:
        """
        Generate cleanup metrics summary.

        Args:
            violations: List of principle violations
            code_smells: Code smell issues by type
            stale_docs: Count of stale documents

        Returns:
            CleanupMetrics summary
        """
        violations_by_principle = {}
        for violation in violations:
            violations_by_principle[violation.principle] = \
                violations_by_principle.get(violation.principle, 0) + 1

        code_smell_counts = {
            smell_type: len(issues)
            for smell_type, issues in code_smells.items()
        }

        total_violations = len(violations)
        total_smells = sum(code_smell_counts.values())
        total_issues = total_violations + total_smells + stale_docs

        high_priority = sum(
            1 for v in violations if v.severity == "high"
        )

        auto_fixable = sum(
            1 for v in violations if v.auto_fixable
        )

        return CleanupMetrics(
            scan_date=datetime.utcnow().isoformat(),
            violations_by_principle=violations_by_principle,
            code_smells=code_smell_counts,
            stale_docs=stale_docs,
            total_issues=total_issues,
            high_priority=high_priority,
            auto_fixable=auto_fixable
        )
