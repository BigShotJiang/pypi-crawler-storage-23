"""Parse agent execution results into structured outputs."""

import json
import logging
import re
from typing import Any

logger = logging.getLogger(__name__)


class AgentResultParser:
    """Parse outputs from different agent types."""

    @staticmethod
    def parse_planner_result(assistant_text: str, tool_calls: list[dict]) -> dict[str, Any]:
        """
        Extract task graph from planner output.

        Priority:
        1. task_write tool call with JSON task graph
        2. JSON blocks in assistant text
        3. Fallback: error with raw text

        Args:
            assistant_text: Full text response from planner
            tool_calls: All tool calls made by planner

        Returns:
            Task graph dictionary
        """
        # Priority 1: Look for task_write tool call
        for tool_call in tool_calls:
            if tool_call.get("tool") == "task_write":
                tool_input = tool_call.get("input", {})

                # Check if input already has task graph structure
                if "tasks" in tool_input:
                    logger.info("Parsed task graph from task_write tool call (direct)")
                    return tool_input

                # Otherwise try to parse from content field
                content = tool_input.get("content", "")
                if content:
                    try:
                        task_graph = json.loads(content)
                        logger.info("Parsed task graph from task_write tool call")
                        return task_graph
                    except json.JSONDecodeError as e:
                        logger.warning(f"Failed to parse task_write content: {e}")

        # Priority 2: Extract JSON from text (look for code blocks or raw JSON)
        json_blocks = re.findall(r'```(?:json)?\s*(\{.*?\})\s*```', assistant_text, re.DOTALL)
        for block in json_blocks:
            try:
                task_graph = json.loads(block)
                logger.info("Parsed task graph from JSON code block")
                return task_graph
            except json.JSONDecodeError:
                continue

        # Try raw JSON in text
        try:
            # Look for first { to last }
            start = assistant_text.find('{')
            end = assistant_text.rfind('}')
            if start != -1 and end != -1:
                potential_json = assistant_text[start:end + 1]
                task_graph = json.loads(potential_json)
                logger.info("Parsed task graph from raw JSON in text")
                return task_graph
        except (json.JSONDecodeError, ValueError):
            pass

        # Priority 3: Fallback - return error
        logger.error("Failed to parse task graph from planner output")
        return {
            "tasks": [],
            "parallel_groups": [],
            "risks": [],
            "checkpoints": [],
            "error": "Failed to parse task graph",
            "raw_text": assistant_text[:500]  # First 500 chars for debugging
        }

    @staticmethod
    def parse_coder_result(assistant_text: str, tool_calls: list[dict]) -> dict[str, Any]:
        """
        Extract files changed and implementation details from coder output.

        Args:
            assistant_text: Full text response from coder
            tool_calls: All tool calls made by coder

        Returns:
            Coder result dictionary
        """
        # Extract file operations from tool calls
        files_written = []
        files_edited = []
        files_read = []

        for tool_call in tool_calls:
            tool_name = tool_call.get("tool", "")
            tool_input = tool_call.get("input", {})

            if tool_name == "write_file":
                files_written.append(tool_input.get("path", "unknown"))
            elif tool_name == "edit_file":
                files_edited.append(tool_input.get("path", "unknown"))
            elif tool_name == "read_file":
                files_read.append(tool_input.get("path", "unknown"))

        return {
            "files_written": files_written,
            "files_edited": files_edited,
            "files_read": files_read,
            "summary": assistant_text,
            "tool_count": len(tool_calls)
        }

    @staticmethod
    def parse_reviewer_result(assistant_text: str, tool_calls: list[dict]) -> dict[str, Any]:
        """
        Extract approval/feedback from reviewer output.

        Looks for:
        - task_update with approval status
        - Explicit approval/changes_requested keywords
        - Feedback items

        Args:
            assistant_text: Full text response from reviewer
            tool_calls: All tool calls made by reviewer

        Returns:
            Reviewer result dictionary
        """
        # Look for task_update tool call
        for tool_call in tool_calls:
            if tool_call.get("tool") == "task_update":
                tool_input = tool_call.get("input", {})
                status = tool_input.get("status", "")

                if status == "completed":
                    return {
                        "status": "approved",
                        "feedback": assistant_text,
                        "changes_required": []
                    }
                elif "changes" in status.lower():
                    return {
                        "status": "changes_requested",
                        "feedback": assistant_text,
                        "changes_required": _extract_feedback_items(assistant_text)
                    }

        # Parse from text
        text_lower = assistant_text.lower()
        if any(keyword in text_lower for keyword in ["approved", "looks good", "lgtm"]):
            return {
                "status": "approved",
                "feedback": assistant_text,
                "changes_required": []
            }
        elif any(keyword in text_lower for keyword in ["changes requested", "needs work", "issues found"]):
            return {
                "status": "changes_requested",
                "feedback": assistant_text,
                "changes_required": _extract_feedback_items(assistant_text)
            }

        # Default: inconclusive
        return {
            "status": "inconclusive",
            "feedback": assistant_text,
            "changes_required": []
        }

    @staticmethod
    def parse_executor_result(assistant_text: str, tool_calls: list[dict]) -> dict[str, Any]:
        """
        Extract validation status and test results from executor output.

        Args:
            assistant_text: Full text response from executor
            tool_calls: All tool calls made by executor

        Returns:
            Executor result dictionary
        """
        # Look for bash/test tool calls
        test_results = []
        commands_run = []

        for tool_call in tool_calls:
            tool_name = tool_call.get("tool", "")
            tool_input = tool_call.get("input", {})

            if tool_name == "bash":
                command = tool_input.get("command", "")
                commands_run.append(command)

                # Detect test commands
                if any(test_cmd in command for test_cmd in ["pytest", "npm test", "go test", "cargo test"]):
                    test_results.append({
                        "command": command,
                        "type": "test"
                    })

        # Parse validation status from text
        text_lower = assistant_text.lower()
        if any(keyword in text_lower for keyword in ["all tests pass", "validation successful", "✓"]):
            validation_status = "passed"
        elif any(keyword in text_lower for keyword in ["tests fail", "validation failed", "✗", "error"]):
            validation_status = "failed"
        else:
            validation_status = "inconclusive"

        return {
            "validation_status": validation_status,
            "test_results": test_results,
            "commands_run": commands_run,
            "output": assistant_text
        }


def _extract_feedback_items(text: str) -> list[str]:
    """Extract bulleted or numbered feedback items from text."""
    items = []

    # Look for markdown lists (- or 1.)
    lines = text.split('\n')
    for line in lines:
        stripped = line.strip()
        # Bullet points
        if stripped.startswith('- ') or stripped.startswith('* '):
            items.append(stripped[2:].strip())
        # Numbered lists
        elif re.match(r'^\d+\.\s+', stripped):
            items.append(re.sub(r'^\d+\.\s+', '', stripped))

    return items
