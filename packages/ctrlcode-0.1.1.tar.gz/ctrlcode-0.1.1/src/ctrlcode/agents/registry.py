"""Agent registry for creating specialized agents."""

from pathlib import Path
from typing import Any

# Note: harness-utils integration will be added when we integrate
# For now, this is the structure/interface


class AgentConfig:
    """Configuration for a specialized agent."""

    def __init__(
        self,
        name: str,
        system_prompt_path: str,
        tools: list[str],
        prune_protect: int = 50_000,
        prune_minimum: int = 25_000,
        max_lines: int = 3000,
        use_predictive: bool = True,
    ):
        """
        Initialize agent configuration.

        Args:
            name: Agent identifier (e.g., "planner", "coder")
            system_prompt_path: Path to agent-specific prompt file
            tools: List of allowed tool names
            prune_protect: Context size before pruning starts (tokens)
            prune_minimum: Minimum context after pruning (tokens)
            max_lines: Maximum lines in tool output
            use_predictive: Enable predictive overflow detection
        """
        self.name = name
        self.system_prompt_path = system_prompt_path
        self.tools = tools
        self.prune_protect = prune_protect
        self.prune_minimum = prune_minimum
        self.max_lines = max_lines
        self.use_predictive = use_predictive


class AgentRegistry:
    """Registry of specialized agent configurations."""

    def __init__(self, workspace_root: Path, tool_registry: Any):
        """
        Initialize agent registry.

        Args:
            workspace_root: Root directory of workspace
            tool_registry: ToolRegistry instance
        """
        self.workspace = workspace_root
        self.tools = tool_registry
        self.prompts_dir = workspace_root / "prompts" / "agents"

    def get_planner_config(self) -> AgentConfig:
        """Get configuration for Planner agent."""
        return AgentConfig(
            name="planner",
            system_prompt_path=str(self.prompts_dir / "planner.md"),
            tools=[
                "search_files",
                "search_code",
                "read_file",
                "list_directory",
                "task_write",
            ],
            prune_protect=50_000,  # Moderate - needs context for planning
            prune_minimum=25_000,
            max_lines=3000,
            use_predictive=True,
        )

    def get_coder_config(self, task_id: str | None = None) -> AgentConfig:
        """
        Get configuration for Coder agent.

        Args:
            task_id: Optional task identifier for naming
        """
        name = f"coder-{task_id}" if task_id else "coder"

        return AgentConfig(
            name=name,
            system_prompt_path=str(self.prompts_dir / "coder.md"),
            tools=[
                "read_file",
                "write_file",
                "update_file",
                "run_command",
                "search_code",
            ],
            prune_protect=100_000,  # Large - needs full context for coding
            prune_minimum=50_000,
            max_lines=5000,
            use_predictive=True,
        )

    def get_reviewer_config(self) -> AgentConfig:
        """Get configuration for Reviewer agent."""
        return AgentConfig(
            name="reviewer",
            system_prompt_path=str(self.prompts_dir / "reviewer.md"),
            tools=[
                "read_file",
                "run_command",
                "search_code",
                "task_update",
            ],
            prune_protect=75_000,  # Moderate-large - needs context for review
            prune_minimum=40_000,
            max_lines=4000,
            use_predictive=True,
        )

    def get_executor_config(self) -> AgentConfig:
        """Get configuration for Executor agent."""
        return AgentConfig(
            name="executor",
            system_prompt_path=str(self.prompts_dir / "executor.md"),
            tools=[
                "run_command",
                "fetch",
                "query_logs",
                "query_metrics",
                "screenshot",
                "dom_snapshot",
            ],
            prune_protect=50_000,  # Moderate - runtime validation
            prune_minimum=25_000,
            max_lines=3000,
            use_predictive=True,
        )

    def get_orchestrator_config(self) -> AgentConfig:
        """Get configuration for Orchestrator agent."""
        return AgentConfig(
            name="orchestrator",
            system_prompt_path=str(self.prompts_dir / "orchestrator.md"),
            tools=[],  # Orchestrator delegates, doesn't use tools directly
            prune_protect=30_000,  # Small - just coordinates
            prune_minimum=15_000,
            max_lines=2000,
            use_predictive=True,
        )

    def get_agent_configs(self) -> dict[str, AgentConfig]:
        """
        Get all agent configurations.

        Returns:
            Dict mapping agent type to AgentConfig
        """
        return {
            "planner": self.get_planner_config(),
            "coder": self.get_coder_config(),
            "reviewer": self.get_reviewer_config(),
            "executor": self.get_executor_config(),
            "orchestrator": self.get_orchestrator_config(),
        }

    def load_system_prompt(self, agent_type: str) -> str:
        """
        Load system prompt for agent type.

        Args:
            agent_type: Agent type (planner, coder, reviewer, executor, orchestrator)

        Returns:
            System prompt content

        Raises:
            FileNotFoundError: If prompt file doesn't exist
        """
        config = self.get_agent_configs()[agent_type]
        prompt_path = Path(config.system_prompt_path)

        if not prompt_path.exists():
            raise FileNotFoundError(f"Prompt file not found: {prompt_path}")

        return prompt_path.read_text()

    def get_allowed_tools(self, agent_type: str) -> list[str]:
        """
        Get list of tools allowed for agent type.

        Args:
            agent_type: Agent type

        Returns:
            List of tool names
        """
        config = self.get_agent_configs()[agent_type]
        return config.tools

    def validate_tool_access(self, agent_type: str, tool_name: str) -> bool:
        """
        Check if agent is allowed to use tool.

        Args:
            agent_type: Agent type
            tool_name: Tool to check

        Returns:
            True if allowed, False otherwise
        """
        allowed_tools = self.get_allowed_tools(agent_type)
        return tool_name in allowed_tools
