"""OpenAI provider implementation."""

import json
import logging
from typing import Any, AsyncIterator
from openai import AsyncOpenAI

from .base import StreamEvent

logger = logging.getLogger(__name__)


class OpenAIProvider:
    """OpenAI GPT provider with streaming support."""

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4",
        base_url: str | None = None
    ):
        """
        Initialize OpenAI provider.

        Args:
            api_key: OpenAI API key
            model: Model to use (default: gpt-4)
            base_url: Optional base URL for API endpoint (for proxies/alternative endpoints)
        """
        self.api_key = api_key
        self.base_url = base_url
        self.client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        self.model = model

    def _convert_tools_to_openai_format(self, tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert Anthropic tool format to OpenAI format."""
        openai_tools = []
        for tool in tools:
            # Anthropic format: {name, description, input_schema}
            # OpenAI format: {type: "function", function: {name, description, parameters}}
            openai_tools.append({
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["input_schema"]  # OpenAI calls it "parameters" not "input_schema"
                }
            })
        return openai_tools

    async def stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any
    ) -> AsyncIterator[StreamEvent]:
        """Stream completion with normalized events."""
        # Convert tools to OpenAI format
        openai_tools = []
        if tools:
            openai_tools = self._convert_tools_to_openai_format(tools)
            logger.info(f"OpenAIProvider.stream called with {len(openai_tools)} tools")
            logger.debug(f"Tool names: {[t['function']['name'] for t in openai_tools]}")

        # Log message structure and first tool schema for diagnostics
        for i, msg in enumerate(messages):
            role = msg.get("role", "?")
            content = msg.get("content", "") or ""
            logger.info(f"Message[{i}] role={role} len={len(content)} preview={repr(content[:80])}")
        if openai_tools:
            logger.info(f"First tool schema: {json.dumps(openai_tools[0])}")

        create_kwargs: dict[str, Any] = dict(
            model=self.model,
            messages=messages,  # type: ignore[arg-type]
            stream=True,
            stream_options={"include_usage": True},
            **kwargs
        )
        if openai_tools:
            create_kwargs["tools"] = openai_tools  # type: ignore[assignment]
            create_kwargs["tool_choice"] = "auto"

        # Qwen3 models default to thinking mode which interferes with tool calling.
        # Disable thinking mode so vLLM's tool call parser sees clean JSON output.
        if "qwen" in self.model.lower() and "extra_body" not in create_kwargs:
            create_kwargs["extra_body"] = {"chat_template_kwargs": {"enable_thinking": False}}
            logger.info("Qwen model detected: disabled thinking mode for reliable tool calling")

        stream = await self.client.chat.completions.create(**create_kwargs)  # type: ignore[arg-type]

        tool_calls_seen = set()

        async for chunk in stream:  # type: ignore[union-attr]
            # Check for usage info (OpenAI sends this in a final chunk with no choices)
            if chunk.usage:
                yield StreamEvent(
                    type="usage",
                    data={
                        "usage": {
                            "prompt_tokens": chunk.usage.prompt_tokens,
                            "completion_tokens": chunk.usage.completion_tokens,
                            "total_tokens": chunk.usage.total_tokens
                        }
                    }
                )

            if not chunk.choices:
                continue

            delta = chunk.choices[0].delta

            # Text content
            if delta.content:
                yield StreamEvent(
                    type="text",
                    data={"text": delta.content}
                )

            # Tool calls
            if delta.tool_calls:
                logger.info(f"tool_call delta received: {delta.tool_calls}")
                for tool_call in delta.tool_calls:
                    # OpenAI sends multiple deltas for same tool call
                    # Track which ones we've seen to emit start event only once
                    if tool_call.function and tool_call.function.name:
                        if tool_call.id not in tool_calls_seen:
                            tool_calls_seen.add(tool_call.id)
                            # Tool call start
                            yield StreamEvent(
                                type="tool_call_start",
                                data={
                                    "tool": tool_call.function.name,
                                    "call_id": tool_call.id
                                }
                            )

                    if tool_call.function and tool_call.function.arguments:
                        # Tool arguments (may be partial)
                        yield StreamEvent(
                            type="tool_call_delta",
                            data={"delta": tool_call.function.arguments}
                        )

            # Completion
            if chunk.choices[0].finish_reason:
                logger.info(f"finish_reason: {chunk.choices[0].finish_reason}")
                # Emit content_block_stop for tool calls
                if chunk.choices[0].finish_reason == "tool_calls":
                    yield StreamEvent(
                        type="content_block_stop",
                        data={}
                    )

    async def generate(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any
    ) -> dict[str, Any]:
        """Generate non-streaming completion."""
        # Convert tools to OpenAI format
        openai_tools = None
        if tools:
            openai_tools = self._convert_tools_to_openai_format(tools)

        response = await self.client.chat.completions.create(  # type: ignore[arg-type]
            model=self.model,
            messages=messages,  # type: ignore[arg-type]
            tools=openai_tools,  # type: ignore[arg-type]
            **kwargs
        )

        choice = response.choices[0]
        text_content = choice.message.content or ""

        usage_dict = {}
        if response.usage:
            usage_dict = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens
            }

        return {
            "text": text_content,
            "usage": usage_dict,
            "model": response.model,
        }

    def normalize_tool_call(self, raw: dict[str, Any]) -> dict[str, Any]:
        """Normalize OpenAI tool call format."""
        return {
            "name": raw.get("function", {}).get("name"),
            "call_id": raw.get("id"),
            "input": json.loads(raw.get("function", {}).get("arguments", "{}"))
        }
