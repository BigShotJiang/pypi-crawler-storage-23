"""Anthropic (Claude) provider implementation."""

import logging
from typing import Any, AsyncIterator
from anthropic import AsyncAnthropic

from .base import StreamEvent

logger = logging.getLogger(__name__)


class AnthropicProvider:
    """Anthropic Claude provider with streaming support."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-5-20250929",
        base_url: str | None = None
    ):
        """
        Initialize Anthropic provider.

        Args:
            api_key: Anthropic API key
            model: Model to use (default: claude-sonnet-4.5)
            base_url: Optional base URL for API endpoint (for proxies/alternative endpoints)
        """
        self.client = AsyncAnthropic(api_key=api_key, base_url=base_url)
        self.model = model

    async def stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any
    ) -> AsyncIterator[StreamEvent]:
        """Stream completion with normalized events."""
        logger.info(f"AnthropicProvider.stream called with {len(tools or [])} tools")
        if tools:
            logger.debug(f"Tool names: {[t.get('name') for t in tools]}")

        async with self.client.messages.stream(  # type: ignore[arg-type]
            model=self.model,
            messages=messages,  # type: ignore[arg-type]
            tools=tools or [],  # type: ignore[arg-type]
            max_tokens=kwargs.pop("max_tokens", 4096),
            **kwargs
        ) as stream:
            async for event in stream:
                if event.type == "content_block_delta":
                    if event.delta.type == "text_delta":
                        yield StreamEvent(
                            type="text",
                            data={"text": event.delta.text}
                        )
                    elif event.delta.type == "input_json_delta":
                        # Tool call in progress
                        yield StreamEvent(
                            type="tool_call_delta",
                            data={"delta": event.delta.partial_json}
                        )

                elif event.type == "content_block_start":
                    if event.content_block.type == "tool_use":
                        yield StreamEvent(
                            type="tool_call_start",
                            data={
                                "tool": event.content_block.name,
                                "call_id": event.content_block.id
                            }
                        )
                    elif event.content_block.type == "text":
                        # Text block starting
                        yield StreamEvent(
                            type="content_block_start",
                            data={"block_type": "text"}
                        )

                elif event.type == "content_block_stop":
                    # Content block (text or tool_use) is complete
                    yield StreamEvent(
                        type="content_block_stop",
                        data={"index": event.index}
                    )

                elif event.type == "message_stop":
                    # Final message with usage
                    message = await stream.get_final_message()
                    yield StreamEvent(
                        type="usage",
                        data={
                            "usage": {
                                "prompt_tokens": message.usage.input_tokens,
                                "completion_tokens": message.usage.output_tokens,
                                "total_tokens": message.usage.input_tokens + message.usage.output_tokens
                            }
                        }
                    )

    async def generate(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any
    ) -> dict[str, Any]:
        """Generate non-streaming completion."""
        response = await self.client.messages.create(  # type: ignore[arg-type]
            model=self.model,
            messages=messages,  # type: ignore[arg-type]
            tools=tools or [],  # type: ignore[arg-type]
            max_tokens=kwargs.pop("max_tokens", 4096),
            **kwargs
        )

        # Extract text content
        text_content = ""
        for block in response.content:
            if block.type == "text":
                text_content += block.text

        return {
            "text": text_content,
            "usage": {
                "prompt_tokens": response.usage.input_tokens,
                "completion_tokens": response.usage.output_tokens,
                "total_tokens": response.usage.input_tokens + response.usage.output_tokens
            },
            "model": response.model,
        }

    def normalize_tool_call(self, raw: dict[str, Any]) -> dict[str, Any]:
        """Normalize Anthropic tool call format."""
        return {
            "name": raw.get("name"),
            "call_id": raw.get("id"),
            "input": raw.get("input", {})
        }
