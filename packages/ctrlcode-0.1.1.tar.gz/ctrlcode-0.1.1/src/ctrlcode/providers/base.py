"""Base provider protocol and types for LLM providers."""

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator
from dataclasses import dataclass


@dataclass
class StreamEvent:
    """Normalized event from provider streaming."""

    type: str  # "text", "tool_call", "usage", "error"
    data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Convert to JSON-serializable dict."""
        return {
            "type": self.type,
            "data": self.data
        }


class Provider(ABC):
    """Base class for LLM providers with streaming support."""

    @abstractmethod
    async def stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any
    ) -> AsyncIterator[StreamEvent]:
        """
        Stream completion with normalized events.

        Args:
            messages: Conversation messages in provider format
            tools: Optional tool definitions
            **kwargs: Provider-specific parameters (temperature, etc.)

        Yields:
            StreamEvent: Normalized streaming events
        """
        ...

    @abstractmethod
    async def generate(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any
    ) -> dict[str, Any]:
        """
        Generate non-streaming completion.

        Args:
            messages: Conversation messages
            tools: Optional tool definitions
            **kwargs: Provider-specific parameters

        Returns:
            Complete response with text and metadata
        """
        ...

    @abstractmethod
    def normalize_tool_call(self, raw: dict[str, Any]) -> dict[str, Any]:
        """
        Normalize provider-specific tool call format.

        Args:
            raw: Provider-specific tool call data

        Returns:
            Normalized tool call dict with keys: name, call_id, input
        """
        ...
