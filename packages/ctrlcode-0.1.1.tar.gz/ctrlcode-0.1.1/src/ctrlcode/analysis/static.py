"""Static analysis for code quality metrics."""

import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path


@dataclass
class StaticAnalysisResult:
    """Result of static analysis."""

    variant_id: str
    type_errors: int = 0
    lint_issues: int = 0
    complexity_score: float = 0.0
    maintainability_index: float = 0.0
    quality_score: float = 0.0  # Overall 0-1 score


class StaticAnalyzer:
    """Performs static analysis on code."""

    def analyze(self, code: str, variant_id: str) -> StaticAnalysisResult:
        """
        Run static analysis on code.

        Args:
            code: Code to analyze
            variant_id: Identifier for variant

        Returns:
            StaticAnalysisResult with quality metrics
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            code_file = tmppath / "code.py"
            code_file.write_text(code)

            # Run analyses
            type_errors = self._run_mypy(code_file)
            lint_issues = self._run_ruff(code_file)
            complexity = self._calculate_complexity(code)

            # Calculate overall quality score
            quality = self._calculate_quality(
                type_errors=type_errors,
                lint_issues=lint_issues,
                complexity=complexity,
            )

            return StaticAnalysisResult(
                variant_id=variant_id,
                type_errors=type_errors,
                lint_issues=lint_issues,
                complexity_score=complexity,
                quality_score=quality,
            )

    def _run_mypy(self, file_path: Path) -> int:
        """
        Run mypy type checker.

        Args:
            file_path: Path to code file

        Returns:
            Number of type errors
        """
        try:
            result = subprocess.run(
                ["mypy", str(file_path), "--ignore-missing-imports"],
                capture_output=True,
                text=True,
                timeout=10,
            )

            # Count error lines
            errors = 0
            for line in result.stdout.split("\n"):
                if "error:" in line.lower():
                    errors += 1

            return errors

        except (subprocess.TimeoutExpired, FileNotFoundError):
            return 0  # If mypy unavailable, assume no errors

    def _run_ruff(self, file_path: Path) -> int:
        """
        Run ruff linter.

        Args:
            file_path: Path to code file

        Returns:
            Number of lint issues
        """
        try:
            result = subprocess.run(
                ["ruff", "check", str(file_path)],
                capture_output=True,
                text=True,
                timeout=10,
            )

            # Count issue lines
            issues = 0
            for line in result.stdout.split("\n"):
                if line.strip() and not line.startswith("Found"):
                    issues += 1

            return issues

        except (subprocess.TimeoutExpired, FileNotFoundError):
            return 0  # If ruff unavailable, assume no issues

    def _calculate_complexity(self, code: str) -> float:
        """
        Calculate code complexity.

        Uses simple heuristics:
        - Lines of code
        - Nesting depth
        - Number of branches

        Args:
            code: Code to analyze

        Returns:
            Complexity score (lower is better)
        """
        lines = [line for line in code.split("\n") if line.strip() and not line.strip().startswith("#")]
        loc = len(lines)

        # Calculate max nesting depth
        max_depth = 0

        for line in lines:
            # Count leading spaces
            stripped = line.lstrip()
            if stripped:
                indent = len(line) - len(stripped)
                depth = indent // 4  # Assuming 4-space indents
                max_depth = max(max_depth, depth)

        # Count branches (if, for, while, try)
        branches = sum(
            1 for line in lines
            if any(line.strip().startswith(kw) for kw in ["if ", "elif ", "for ", "while ", "try:", "except"])
        )

        # Complexity = weighted sum
        complexity = (loc * 0.1) + (max_depth * 2) + (branches * 1.5)

        return complexity

    def _calculate_quality(
        self,
        type_errors: int,
        lint_issues: int,
        complexity: float,
    ) -> float:
        """
        Calculate overall quality score.

        Args:
            type_errors: Number of type errors
            lint_issues: Number of lint issues
            complexity: Complexity score

        Returns:
            Quality score between 0.0 and 1.0 (higher is better)
        """
        # Penalties
        type_penalty = min(type_errors * 0.1, 0.4)  # Max 40% penalty
        lint_penalty = min(lint_issues * 0.05, 0.3)  # Max 30% penalty
        complexity_penalty = min(complexity / 50, 0.3)  # Max 30% penalty

        # Start with perfect score and subtract penalties
        score = 1.0 - (type_penalty + lint_penalty + complexity_penalty)

        return max(0.0, min(1.0, score))
