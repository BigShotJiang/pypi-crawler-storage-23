"""Test execution for code variants."""

import tempfile
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class TestResult:
    """Result of test execution."""

    variant_id: str
    passed: bool
    total_tests: int = 0
    passed_tests: int = 0
    failed_tests: int = 0
    errors: list[str] = field(default_factory=list)
    output: str = ""
    execution_time: float = 0.0

    @property
    def pass_rate(self) -> float:
        """Calculate test pass rate."""
        if self.total_tests == 0:
            return 0.0
        return self.passed_tests / self.total_tests


class TestExecutor:
    """Executes tests against code variants."""

    def __init__(self, test_template: str | None = None):
        """
        Initialize test executor.

        Args:
            test_template: Optional template for generating tests
        """
        self.test_template = test_template

    async def run_tests(
        self,
        code: str,
        variant_id: str,
        test_code: str | None = None
    ) -> TestResult:
        """
        Run tests against code.

        Args:
            code: Code to test
            variant_id: Identifier for variant
            test_code: Optional test code (if None, auto-generate basic tests)

        Returns:
            TestResult with execution results
        """
        # Create temp directory for test
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)

            # Write code to file
            code_file = tmppath / "code.py"
            code_file.write_text(code)

            # Write test file
            if test_code:
                test_file = tmppath / "test_code.py"
                test_file.write_text(test_code)
            else:
                # Generate basic tests
                test_file = tmppath / "test_code.py"
                basic_tests = self._generate_basic_tests(code)
                test_file.write_text(basic_tests)

            # Run pytest
            result = subprocess.run(
                ["pytest", str(test_file), "-v", "--tb=short"],
                capture_output=True,
                text=True,
                cwd=str(tmppath),
                timeout=30,  # 30 second timeout
            )

            # Parse results
            return self._parse_pytest_output(
                variant_id=variant_id,
                returncode=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
            )

    def _generate_basic_tests(self, code: str) -> str:
        """
        Generate basic smoke tests for code.

        Args:
            code: Code to test

        Returns:
            Test code as string
        """
        # Very basic: just try to import and call functions
        return """
import sys
import pytest
from code import *

def test_imports():
    '''Test that code imports without errors.'''
    assert True

def test_no_syntax_errors():
    '''Verify code compiles.'''
    import code
    assert code is not None

# Add more specific tests based on code analysis
"""

    def _parse_pytest_output(
        self,
        variant_id: str,
        returncode: int,
        stdout: str,
        stderr: str,
    ) -> TestResult:
        """
        Parse pytest output.

        Args:
            variant_id: Variant identifier
            returncode: Process return code
            stdout: Standard output
            stderr: Standard error

        Returns:
            Parsed test result
        """
        passed = returncode == 0
        output = stdout + "\n" + stderr

        # Parse test counts from output
        # Pytest output format: "X passed, Y failed in Z.XXs"
        import re

        total_tests = 0
        passed_tests = 0
        failed_tests = 0
        errors = []

        # Look for summary line
        summary_pattern = r"(\d+) passed"
        passed_match = re.search(summary_pattern, output)
        if passed_match:
            passed_tests = int(passed_match.group(1))

        failed_pattern = r"(\d+) failed"
        failed_match = re.search(failed_pattern, output)
        if failed_match:
            failed_tests = int(failed_match.group(1))

        total_tests = passed_tests + failed_tests

        # Extract error messages
        if not passed:
            # Look for FAILED lines
            for line in output.split("\n"):
                if "FAILED" in line or "ERROR" in line:
                    errors.append(line.strip())

        # Extract execution time
        time_pattern = r"in ([\d.]+)s"
        time_match = re.search(time_pattern, output)
        execution_time = 0.0
        if time_match:
            execution_time = float(time_match.group(1))

        return TestResult(
            variant_id=variant_id,
            passed=passed,
            total_tests=total_tests,
            passed_tests=passed_tests,
            failed_tests=failed_tests,
            errors=errors,
            output=output,
            execution_time=execution_time,
        )
