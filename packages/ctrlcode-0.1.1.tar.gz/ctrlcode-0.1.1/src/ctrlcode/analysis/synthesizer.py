"""Feedback synthesis from differential analysis."""

from dataclasses import dataclass

from .ast_diff import ASTDiff
from .semantic import SemanticDiff
from .tests import TestResult
from .static import StaticAnalysisResult


@dataclass
class AnalysisResult:
    """Complete analysis from all methods."""

    structural_diffs: list[ASTDiff]
    semantic_diffs: list[SemanticDiff]
    test_results: list[TestResult]
    static_results: list[StaticAnalysisResult]
    elapsed_time: float


@dataclass
class Feedback:
    """Synthesized feedback for improvement."""

    improvement_prompt: str
    quality_score: float
    consensus: list[str]
    discrepancies: list[str]
    changes_made: list[str]


class FeedbackSynthesizer:
    """Synthesizes analysis results into actionable feedback."""

    def __init__(self, weights: dict[str, float] | None = None):
        """
        Initialize feedback synthesizer.

        Args:
            weights: Quality scoring weights for each analysis type
        """
        self.weights = weights or {
            "tests": 0.4,
            "static": 0.3,
            "semantic": 0.3,
        }

    def synthesize(
        self,
        analysis: AnalysisResult,
        iteration: int,
        user_request: str,
    ) -> Feedback:
        """
        Generate improvement feedback from analysis.

        Args:
            analysis: Complete analysis results
            iteration: Current iteration number
            user_request: Original user request

        Returns:
            Feedback with improvement prompt and scores
        """
        # Extract consensus patterns
        consensus = self._find_consensus(analysis)

        # Extract discrepancies
        discrepancies = self._find_discrepancies(analysis)

        # Calculate quality score
        quality_score = self._calculate_quality(analysis)

        # Build improvement prompt
        improvement_prompt = self._build_improvement_prompt(
            consensus=consensus,
            discrepancies=discrepancies,
            analysis=analysis,
            iteration=iteration,
            user_request=user_request,
        )

        return Feedback(
            improvement_prompt=improvement_prompt,
            quality_score=quality_score,
            consensus=consensus,
            discrepancies=discrepancies,
            changes_made=[],  # Will be populated after improvement
        )

    def _find_consensus(self, analysis: AnalysisResult) -> list[str]:
        """
        Find patterns agreed upon by all variants.

        Args:
            analysis: Analysis results

        Returns:
            List of consensus patterns
        """
        consensus = []

        # Check semantic agreement
        if analysis.semantic_diffs:
            high_agreement = [
                d for d in analysis.semantic_diffs
                if d.agreement_score > 0.8
            ]
            if len(high_agreement) == len(analysis.semantic_diffs):
                consensus.append("All variants show high semantic agreement")

        # Check structural similarity
        if analysis.structural_diffs:
            similar = [
                d for d in analysis.structural_diffs
                if d.structural_similarity > 0.8
            ]
            if len(similar) == len(analysis.structural_diffs):
                consensus.append("All variants have similar structure")

        # Check test passing
        if analysis.test_results:
            all_passed = all(t.passed for t in analysis.test_results)
            if all_passed:
                consensus.append("All variants pass tests")

        # Check common improvements
        improvements: dict[str, int] = {}
        for sem_diff in analysis.semantic_diffs:
            for imp in sem_diff.improvements:
                improvements[imp] = improvements.get(imp, 0) + 1

        # Improvements mentioned by multiple variants
        common_improvements = [
            imp for imp, count in improvements.items()
            if count >= len(analysis.semantic_diffs) // 2
        ]
        consensus.extend(common_improvements)

        return consensus

    def _find_discrepancies(self, analysis: AnalysisResult) -> list[str]:
        """
        Find significant differences between variants.

        Args:
            analysis: Analysis results

        Returns:
            List of discrepancy descriptions
        """
        discrepancies = []

        # Test failures
        if analysis.test_results:
            failed = [t for t in analysis.test_results if not t.passed]
            if failed:
                discrepancies.append(
                    f"{len(failed)}/{len(analysis.test_results)} variants failed tests"
                )

        # Semantic disagreements
        if analysis.semantic_diffs:
            low_agreement = [
                d for d in analysis.semantic_diffs
                if d.agreement_score < 0.5
            ]
            if low_agreement:
                discrepancies.append(
                    f"{len(low_agreement)} variants have low semantic agreement"
                )

            # Collect concerns
            for sem_diff in analysis.semantic_diffs:
                for concern in sem_diff.concerns:
                    if concern not in discrepancies:
                        discrepancies.append(f"Concern: {concern}")

        # Structural differences
        if analysis.structural_diffs:
            syntax_errors = [d for d in analysis.structural_diffs if d.has_syntax_error]
            if syntax_errors:
                discrepancies.append(f"{len(syntax_errors)} variants have syntax errors")

        # Static analysis issues
        if analysis.static_results:
            high_errors = [s for s in analysis.static_results if s.type_errors > 3]
            if high_errors:
                discrepancies.append(
                    f"{len(high_errors)} variants have multiple type errors"
                )

            high_complexity = [s for s in analysis.static_results if s.complexity_score > 20]
            if high_complexity:
                discrepancies.append(
                    f"{len(high_complexity)} variants have high complexity"
                )

        return discrepancies

    def _calculate_quality(self, analysis: AnalysisResult) -> float:
        """
        Calculate aggregate quality score.

        Args:
            analysis: Analysis results

        Returns:
            Quality score between 0.0 and 1.0
        """
        score = 0.0

        # Test passing rate
        if analysis.test_results:
            passing_rate = sum(
                1 for t in analysis.test_results if t.passed
            ) / len(analysis.test_results)
            score += passing_rate * self.weights["tests"]

        # Static analysis score
        if analysis.static_results:
            avg_static = sum(
                s.quality_score for s in analysis.static_results
            ) / len(analysis.static_results)
            score += avg_static * self.weights["static"]

        # Semantic coherence
        if analysis.semantic_diffs:
            avg_semantic = sum(
                d.agreement_score for d in analysis.semantic_diffs
            ) / len(analysis.semantic_diffs)
            score += avg_semantic * self.weights["semantic"]

        return min(1.0, max(0.0, score))

    def _build_improvement_prompt(
        self,
        consensus: list[str],
        discrepancies: list[str],
        analysis: AnalysisResult,
        iteration: int,
        user_request: str,
    ) -> str:
        """Build prompt for generating improved version."""
        prompt = f"""Based on fuzzing iteration {iteration}, improve the code for: "{user_request}"

**Consensus (keep these patterns):**
{chr(10).join(f"- {c}" for c in consensus) if consensus else "- No strong consensus"}

**Issues to resolve:**
{chr(10).join(f"- {d}" for d in discrepancies) if discrepancies else "- No major issues"}

**Quality metrics:**
"""

        # Add test results
        if analysis.test_results:
            pass_rate = sum(1 for t in analysis.test_results if t.passed) / len(analysis.test_results)
            prompt += f"\n- Test pass rate: {pass_rate:.1%}"

        # Add static analysis
        if analysis.static_results:
            avg_quality = sum(s.quality_score for s in analysis.static_results) / len(analysis.static_results)
            prompt += f"\n- Static analysis quality: {avg_quality:.1%}"

        # Add complexity
        if analysis.static_results:
            avg_complexity = sum(s.complexity_score for s in analysis.static_results) / len(analysis.static_results)
            prompt += f"\n- Average complexity: {avg_complexity:.1f}"

        prompt += "\n\n**Task:**\nGenerate an improved version that:\n"
        prompt += "1. Maintains consensus elements\n"
        prompt += "2. Resolves identified issues\n"
        prompt += "3. Improves quality metrics\n"
        prompt += "4. Handles edge cases properly\n"
        prompt += "\n**IMPORTANT:** Respond with ONLY the improved output directly. "
        prompt += "Do NOT include explanations, meta-commentary, or descriptions of changes. "
        prompt += "Just provide the final improved result as you would respond to the original request.\n"

        return prompt
