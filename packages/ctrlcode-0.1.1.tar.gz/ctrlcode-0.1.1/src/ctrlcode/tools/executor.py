"""Tool execution coordinator."""

import logging
from typing import Any
from dataclasses import dataclass

from .registry import ToolRegistry

logger = logging.getLogger(__name__)


@dataclass
class ToolCallResult:
    """Result of a tool call."""

    tool_name: str
    call_id: str
    success: bool
    result: Any = None
    error: str | None = None


class ToolExecutor:
    """Executes tool calls (both MCP and built-in)."""

    def __init__(self, registry: ToolRegistry):
        """
        Initialize tool executor.

        Args:
            registry: Tool registry with MCP clients and built-in tools
        """
        self.registry = registry

    async def execute(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        call_id: str,
    ) -> ToolCallResult:
        """
        Execute a tool call.

        Args:
            tool_name: Name of tool to call
            arguments: Tool arguments
            call_id: Unique call identifier

        Returns:
            ToolCallResult with execution result
        """
        # Get tool definition
        tool = self.registry.get_tool(tool_name)
        if not tool:
            logger.error(f"Tool not found: {tool_name}")
            return ToolCallResult(
                tool_name=tool_name,
                call_id=call_id,
                success=False,
                error=f"Tool '{tool_name}' not found",
            )

        # Execute based on tool type
        try:
            if self.registry.is_builtin(tool_name):
                # Built-in tool - call function directly
                from .registry import BuiltinTool
                import inspect
                builtin_tool = tool
                assert isinstance(builtin_tool, BuiltinTool)

                # Check if function is async and await if needed
                if inspect.iscoroutinefunction(builtin_tool.function):
                    result = await builtin_tool.function(**arguments)
                else:
                    result = builtin_tool.function(**arguments)

                # Check if tool returned an error (error key exists and is not None)
                if isinstance(result, dict) and "error" in result and result["error"] is not None:
                    logger.error(f"Built-in tool '{tool_name}' returned error: {result['error']}")
                    return ToolCallResult(
                        tool_name=tool_name,
                        call_id=call_id,
                        success=False,
                        error=result["error"],
                    )

                logger.info(f"Built-in tool '{tool_name}' executed successfully")
                return ToolCallResult(
                    tool_name=tool_name,
                    call_id=call_id,
                    success=True,
                    result=result,
                )

            else:
                # MCP tool - call via client
                from .mcp import MCPTool
                mcp_tool = tool
                assert isinstance(mcp_tool, MCPTool)

                client = self.registry.get_client(mcp_tool.server_name)
                if not client:
                    logger.error(f"Client not found for server: {mcp_tool.server_name}")
                    return ToolCallResult(
                        tool_name=tool_name,
                        call_id=call_id,
                        success=False,
                        error=f"Server '{mcp_tool.server_name}' not available",
                    )

                result = await client.call_tool(tool_name, arguments)
                logger.info(f"MCP tool '{tool_name}' executed successfully")

                return ToolCallResult(
                    tool_name=tool_name,
                    call_id=call_id,
                    success=True,
                    result=result,
                )

        except Exception as e:
            logger.error(f"Tool execution failed: {e}")
            return ToolCallResult(
                tool_name=tool_name,
                call_id=call_id,
                success=False,
                error=str(e),
            )

    async def execute_batch(
        self,
        tool_calls: list[dict[str, Any]]
    ) -> list[ToolCallResult]:
        """
        Execute multiple tool calls.

        Args:
            tool_calls: List of tool call dicts with name, arguments, call_id

        Returns:
            List of results
        """
        results = []
        for call in tool_calls:
            result = await self.execute(
                tool_name=call["name"],
                arguments=call["arguments"],
                call_id=call["call_id"],
            )
            results.append(result)

        return results
