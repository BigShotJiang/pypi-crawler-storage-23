"""Built-in web fetch tools for making HTTP requests."""

import urllib.request
import urllib.error
from typing import Any


class WebFetchTools:
    """Built-in tools for fetching web content."""

    def fetch(
        self,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: str | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        """
        Make an HTTP request.

        Args:
            url: URL to fetch
            method: HTTP method (GET, POST, PUT, DELETE)
            headers: Optional HTTP headers
            body: Optional request body (for POST/PUT)
            timeout: Timeout in seconds (default 30, max 120)

        Returns:
            Dict with response body, status code, and headers
        """
        try:
            # Validate URL protocol
            if not url.startswith(("http://", "https://")):
                return {"error": "Only http and https protocols are supported"}

            # Basic SSRF protection - block localhost
            if any(
                host in url.lower()
                for host in ["localhost", "127.0.0.1", "0.0.0.0", "[::1]"]
            ):
                return {"error": "Cannot fetch from localhost"}

            # Enforce timeout limits
            if timeout > 120:
                timeout = 120
            if timeout < 1:
                timeout = 1

            # Validate HTTP method
            method = method.upper()
            if method not in ["GET", "POST", "PUT", "DELETE", "HEAD", "PATCH"]:
                return {"error": f"Unsupported HTTP method: {method}"}

            # Prepare request
            request_headers = headers or {}
            request_body = body.encode("utf-8") if body else None

            req = urllib.request.Request(
                url,
                data=request_body,
                headers=request_headers,
                method=method,
            )

            # Execute request
            with urllib.request.urlopen(req, timeout=timeout) as response:
                response_body = response.read().decode("utf-8")
                response_headers = dict(response.headers)
                status_code = response.status

            return {
                "body": response_body,
                "status_code": status_code,
                "headers": response_headers,
                "url": url,
                "method": method,
                "success": True,
            }

        except urllib.error.HTTPError as e:
            # HTTP errors (4xx, 5xx)
            error_body = e.read().decode("utf-8") if e.fp else ""
            return {
                "error": f"HTTP {e.code}: {e.reason}",
                "status_code": e.code,
                "body": error_body,
                "url": url,
                "success": False,
            }

        except urllib.error.URLError as e:
            # Network errors (DNS, connection, etc.)
            return {
                "error": f"Request failed: {str(e.reason)}",
                "url": url,
                "success": False,
            }

        except TimeoutError:
            return {
                "error": f"Request timed out after {timeout} seconds",
                "url": url,
                "success": False,
            }

        except Exception as e:
            return {"error": str(e), "url": url, "success": False}


# Tool schemas for LLM providers (Anthropic/OpenAI format)
WEBFETCH_TOOL_SCHEMAS = [
    {
        "name": "fetch",
        "description": "Make HTTP requests to fetch web content or call APIs. Supports GET, POST, PUT, DELETE with custom headers and body.",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL to fetch (must be http or https)",
                },
                "method": {
                    "type": "string",
                    "description": "HTTP method",
                    "enum": ["GET", "POST", "PUT", "DELETE", "HEAD", "PATCH"],
                    "default": "GET",
                },
                "headers": {
                    "type": "object",
                    "description": "Optional HTTP headers as key-value pairs",
                    "additionalProperties": {"type": "string"},
                },
                "body": {
                    "type": "string",
                    "description": "Optional request body (for POST/PUT/PATCH)",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default 30, max 120)",
                    "default": 30,
                },
            },
            "required": ["url"],
        },
    },
]
