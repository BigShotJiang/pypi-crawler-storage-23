"""Built-in bash execution tools for running shell commands."""

import subprocess
from pathlib import Path
from typing import Any


class BashTools:
    """Built-in tools for executing bash commands."""

    def __init__(self, workspace_root: str | Path):
        """
        Initialize bash tools.

        Args:
            workspace_root: Root directory for command execution
        """
        self.workspace_root = Path(workspace_root).resolve()

    def run_command(
        self,
        command: str,
        timeout: int = 30,
        cwd: str | None = None,
    ) -> dict[str, Any]:
        """
        Execute a shell command.

        Args:
            command: Shell command to execute
            timeout: Timeout in seconds (default 30, max 300)
            cwd: Working directory for command (relative to workspace root)

        Returns:
            Dict with stdout, stderr, returncode, and metadata
        """
        try:
            # Enforce timeout limits
            if timeout > 300:
                timeout = 300
            if timeout < 1:
                timeout = 1

            # Determine working directory
            work_dir = self.workspace_root
            if cwd:
                work_dir = (self.workspace_root / cwd).resolve()

                # Security: ensure cwd is within workspace
                if not str(work_dir).startswith(str(self.workspace_root)):
                    return {"error": "Working directory outside workspace"}

                if not work_dir.exists():
                    return {"error": "Working directory does not exist"}

                if not work_dir.is_dir():
                    return {"error": "Working directory is not a directory"}

            # Execute command
            result = subprocess.run(
                command,
                shell=True,
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "command": command,
                "cwd": str(work_dir.relative_to(self.workspace_root)),
                "success": result.returncode == 0,
            }

        except subprocess.TimeoutExpired:
            return {
                "error": f"Command timed out after {timeout} seconds",
                "command": command,
            }
        except Exception as e:
            return {"error": str(e), "command": command}


# Tool schemas for LLM providers (Anthropic/OpenAI format)
BASH_TOOL_SCHEMAS = [
    {
        "name": "run_command",
        "description": "Execute a shell command in the workspace. Use for git operations, testing, build tools, etc. Commands run in a bash shell.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Shell command to execute (e.g., 'git status', 'npm test', 'make build')",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default 30, max 300)",
                    "default": 30,
                },
                "cwd": {
                    "type": "string",
                    "description": "Working directory relative to workspace root (e.g., 'src', 'tests')",
                },
            },
            "required": ["command"],
        },
    },
]
