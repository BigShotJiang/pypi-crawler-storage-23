"""MCP client for tool integration."""

from typing import Any, Optional
from dataclasses import dataclass
from contextlib import AsyncExitStack

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


@dataclass
class MCPTool:
    """MCP tool definition."""

    name: str
    description: str
    input_schema: dict[str, Any]
    server_name: str


class MCPClient:
    """Client for MCP server communication."""

    def __init__(self, server_config: dict[str, Any]):
        """
        Initialize MCP client.

        Args:
            server_config: Server configuration with command, args, env
        """
        self.server_name = server_config.get("name", "unknown")
        self.server_params = StdioServerParameters(
            command=server_config["command"][0],
            args=server_config["command"][1:],
            env=server_config.get("env"),
        )
        self.session: Optional[ClientSession] = None
        self.read = None
        self.write = None
        self._exit_stack: Optional[AsyncExitStack] = None

    async def start(self) -> None:
        """Start MCP server and initialize session."""
        self._exit_stack = AsyncExitStack()

        # Enter the stdio_client context and keep it alive
        streams = await self._exit_stack.enter_async_context(
            stdio_client(self.server_params)  # type: ignore[arg-type]
        )
        self.read, self.write = streams

        # Initialize session
        self.session = ClientSession(self.read, self.write)  # type: ignore[arg-type]
        await self.session.initialize()

    async def stop(self) -> None:
        """Stop MCP server and close session."""
        if self._exit_stack:
            await self._exit_stack.aclose()
            self._exit_stack = None
        self.session = None

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        """
        Execute tool via MCP protocol.

        Args:
            name: Tool name
            arguments: Tool arguments

        Returns:
            Tool result
        """
        if not self.session:
            raise RuntimeError("MCP session not initialized")

        result = await self.session.call_tool(name, arguments)
        return result.content

    async def list_tools(self) -> list[MCPTool]:
        """
        Get available tools from server.

        Returns:
            List of available tools
        """
        if not self.session:
            raise RuntimeError("MCP session not initialized")

        tools_result = await self.session.list_tools()
        return [
            MCPTool(
                name=tool.name,
                description=tool.description or "",
                input_schema=tool.inputSchema,
                server_name=self.server_name,
            )
            for tool in tools_result.tools
        ]

    async def __aenter__(self):
        """Async context manager entry."""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.stop()
