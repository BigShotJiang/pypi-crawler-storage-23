"""Configuration management for ctrl-code."""

import os
import secrets
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

from ctrlcode.paths import get_cache_dir, get_config_dir

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore # Python < 3.11


@dataclass
class ServerConfig:
    """Server configuration."""

    host: str = "127.0.0.1"
    port: int = 8765
    api_key: str | None = None  # API key for authentication (generated if not set)


@dataclass
class ProviderConfig:
    """Provider configuration."""

    api_key: str
    model: str
    base_url: str | None = None


@dataclass
class EmbeddingsConfig:
    """Embeddings configuration."""

    api_key: str
    base_url: str
    model: str = "text-embedding-3-small"


@dataclass
class ContextConfig:
    """Context window management configuration."""

    prune_protect: int = 40000
    default_limit: int = 200000


@dataclass
class FuzzingConfig:
    """Differential fuzzing configuration (derived context architecture)."""

    enabled: bool = True
    max_iterations: int = 10
    budget_tokens: int = 100000
    budget_seconds: int = 30

    # Test distribution
    input_fuzz_ratio: float = 0.3
    environment_fuzz_ratio: float = 0.4
    combined_fuzz_ratio: float = 0.2
    invariant_fuzz_ratio: float = 0.1

    # Oracle settings
    oracle_confidence_threshold: float = 0.8  # Min confidence to apply oracle corrections
    context_re_derivation_on_mismatch: bool = True

    # Skip fuzzing conditions
    simple_edits: bool = True
    under_lines: int = 10


@dataclass
class SecurityConfig:
    """Security configuration."""

    # Input validation
    max_input_length: int = 200000  # 200K chars (roughly matches context window), -1 = unlimited

    # Rate limiting
    rate_limit_enabled: bool = True
    rate_limit_window_seconds: float = 60.0  # 1 minute
    rate_limit_max_requests: int = 30  # Requests per window


@dataclass
class MCPServerConfig:
    """MCP server configuration."""

    name: str
    command: list[str]
    env: dict[str, str] = field(default_factory=dict)


@dataclass
class Config:
    """Main configuration."""

    server: ServerConfig = field(default_factory=ServerConfig)
    anthropic: Optional[ProviderConfig] = None
    openai: Optional[ProviderConfig] = None
    embeddings: Optional[EmbeddingsConfig] = None
    context: ContextConfig = field(default_factory=ContextConfig)
    fuzzing: FuzzingConfig = field(default_factory=FuzzingConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    mcp_servers: list[MCPServerConfig] = field(default_factory=list)
    skills_directory: Optional[Path] = None
    storage_path: Optional[Path] = None
    workspace_root: Optional[Path] = None

    @staticmethod
    def _validate_config_permissions(config_path: Path) -> None:
        """
        Validate config file has secure permissions.

        Args:
            config_path: Path to config file

        Raises:
            ValueError: If permissions are insecure
        """
        import stat

        # Check file permissions
        file_stat = config_path.stat()
        mode = file_stat.st_mode

        # Check if world-writable or group-writable
        if mode & stat.S_IWOTH:
            raise ValueError(
                f"Config file {config_path} is world-writable (insecure). "
                f"Run: chmod 600 {config_path}"
            )
        if mode & stat.S_IWGRP:
            raise ValueError(
                f"Config file {config_path} is group-writable (insecure). "
                f"Run: chmod 600 {config_path}"
            )

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> "Config":
        """
        Load configuration from TOML file.

        Args:
            config_path: Path to config file (default: ~/.config/ctrlcode/config.toml)

        Returns:
            Config instance
        """
        if config_path is None:
            config_path = get_config_dir() / "config.toml"

        if not config_path.exists():
            # Return default config
            return cls()

        # Security: validate file permissions before loading
        cls._validate_config_permissions(config_path)

        with open(config_path, "rb") as f:
            data = tomllib.load(f)

        # Parse server config
        server_data = data.get("server", {})

        # Generate API key if not present
        if "api_key" not in server_data or not server_data["api_key"]:
            server_data["api_key"] = secrets.token_urlsafe(32)
            # Save generated key back to config
            if config_path:
                cls._save_api_key(config_path, server_data["api_key"])

        server = ServerConfig(**server_data)

        # Parse provider configs
        anthropic = None
        if "providers" in data and "anthropic" in data["providers"]:
            anthropic_data = data["providers"]["anthropic"]
            # Get API key from env or config
            api_key = os.environ.get("ANTHROPIC_API_KEY", anthropic_data.get("api_key"))
            if api_key:
                anthropic = ProviderConfig(
                    api_key=api_key,
                    model=anthropic_data.get("model", "claude-sonnet-4-5-20250929"),
                    base_url=anthropic_data.get("base_url")
                )

        openai = None
        if "providers" in data and "openai" in data["providers"]:
            openai_data = data["providers"]["openai"]
            # Get API key from env or config
            api_key = os.environ.get("OPENAI_API_KEY", openai_data.get("api_key"))
            if api_key:
                openai = ProviderConfig(
                    api_key=api_key,
                    model=openai_data.get("model", "gpt-4"),
                    base_url=openai_data.get("base_url")
                )

        # Parse embeddings config
        embeddings = None
        if "embeddings" in data:
            embeddings_data = data["embeddings"]
            # Get API key from env or config
            api_key = os.environ.get("EMBEDDINGS_API_KEY", embeddings_data.get("api_key"))
            base_url = embeddings_data.get("base_url")
            if api_key and base_url:
                embeddings = EmbeddingsConfig(
                    api_key=api_key,
                    base_url=base_url,
                    model=embeddings_data.get("model", "text-embedding-3-small")
                )

        # Parse context config
        context = ContextConfig(**data.get("context", {}))

        # Parse security config
        security = SecurityConfig(**data.get("security", {}))

        # Parse fuzzing config
        fuzzing_data = data.get("fuzzing", {})
        fuzzing = FuzzingConfig(
            enabled=fuzzing_data.get("enabled", True),
            max_iterations=fuzzing_data.get("max_iterations", 10),
            budget_tokens=fuzzing_data.get("budget_tokens", 100000),
            budget_seconds=fuzzing_data.get("budget_seconds", 30),
            input_fuzz_ratio=fuzzing_data.get("distribution", {}).get("input_fuzz_ratio", 0.3),
            environment_fuzz_ratio=fuzzing_data.get("distribution", {}).get("environment_fuzz_ratio", 0.4),
            combined_fuzz_ratio=fuzzing_data.get("distribution", {}).get("combined_fuzz_ratio", 0.2),
            invariant_fuzz_ratio=fuzzing_data.get("distribution", {}).get("invariant_fuzz_ratio", 0.1),
            oracle_confidence_threshold=fuzzing_data.get("oracle", {}).get("confidence_threshold", 0.8),
            context_re_derivation_on_mismatch=fuzzing_data.get("oracle", {}).get("re_derivation_on_mismatch", True),
            simple_edits=fuzzing_data.get("skip", {}).get("simple_edits", True),
            under_lines=fuzzing_data.get("skip", {}).get("under_lines", 10),
        )

        # Parse MCP servers with security validation
        mcp_servers = []
        for server_data in data.get("mcp", {}).get("servers", []):
            # Security: validate MCP server executable
            command = server_data["command"]
            if not command:
                raise ValueError(f"MCP server '{server_data['name']}' has empty command")

            # IMPORTANT: Expand all paths FIRST, then validate the expanded result
            # This prevents TOCTOU (Time of Check Time of Use) vulnerabilities
            expanded_command = [
                str(Path(part).expanduser()) if part.startswith("~") else part
                for part in command
            ]

            executable = expanded_command[0]

            # Resolve to absolute path (follows symlinks, removes ..)
            exe_path = Path(executable).resolve()

            # Security: Check for path traversal attempts
            # After resolve(), if path still contains .., something is wrong
            if ".." in exe_path.parts:
                raise ValueError(
                    f"MCP server '{server_data['name']}' executable contains path traversal: {executable}"
                )

            # Allow executables from trusted locations
            trusted_prefixes = [
                Path(sys.prefix).resolve() / "bin",  # Virtual environment
                Path(sys.prefix).resolve() / "Scripts",  # Windows venv
                (Path.home() / ".local" / "bin").resolve(),  # User installs
                Path("/usr/local/bin").resolve(),  # System-wide
                Path("/usr/bin").resolve(),  # System
                (Path(get_config_dir()) / "mcp-servers").resolve(),  # User MCP servers directory
            ]

            # Check if resolved path is within any trusted prefix
            is_trusted = any(
                exe_path.is_relative_to(prefix)
                for prefix in trusted_prefixes
                if prefix.exists()
            )

            if not is_trusted:
                raise ValueError(
                    f"MCP server '{server_data['name']}' executable '{exe_path}' "
                    f"is not in a trusted location. Expected in: "
                    f"{', '.join(str(p) for p in trusted_prefixes if p.exists())}"
                )

            # Verify it's an executable file
            if not exe_path.is_file():
                raise ValueError(f"MCP server '{server_data['name']}' executable '{exe_path}' is not a file")

            if not os.access(exe_path, os.X_OK):
                raise ValueError(f"MCP server '{server_data['name']}' executable '{exe_path}' is not executable")

            # Update command with resolved absolute path (prevents symlink attacks)
            expanded_command[0] = str(exe_path)

            mcp_servers.append(MCPServerConfig(
                name=server_data["name"],
                command=expanded_command,
                env=server_data.get("env", {})
            ))

        # Parse skills directory
        skills_dir = None
        if "skills" in data and "directory" in data["skills"]:
            skills_dir = Path(data["skills"]["directory"]).expanduser()

        # Storage path
        storage_path = get_cache_dir() / "conversations"

        # Workspace root (default to cwd, can be overridden in config)
        workspace_root = Path.cwd()
        if "workspace" in data and "root" in data["workspace"]:
            workspace_root = Path(data["workspace"]["root"]).expanduser()

        return cls(
            server=server,
            anthropic=anthropic,
            openai=openai,
            embeddings=embeddings,
            context=context,
            fuzzing=fuzzing,
            security=security,
            mcp_servers=mcp_servers,
            skills_directory=skills_dir,
            storage_path=storage_path,
            workspace_root=workspace_root,
        )

    @staticmethod
    def _save_api_key(config_path: Path, api_key: str) -> None:
        """
        Save generated API key to config file.

        Args:
            config_path: Path to config file
            api_key: Generated API key
        """
        import tomllib

        # Read existing config
        if config_path.exists():
            with open(config_path, "rb") as f:
                data = tomllib.load(f)
        else:
            data = {}

        # Add API key to server section
        if "server" not in data:
            data["server"] = {}
        data["server"]["api_key"] = api_key

        # Write back as TOML
        with open(config_path, "w") as f:
            f.write("# Ctrl+Code Configuration\n\n")
            f.write("[server]\n")
            for key, value in data.get("server", {}).items():
                if isinstance(value, str):
                    f.write(f'{key} = "{value}"\n')
                else:
                    f.write(f'{key} = {value}\n')

            # Write other sections if they exist
            for section, content in data.items():
                if section != "server" and isinstance(content, dict):
                    f.write(f"\n[{section}]\n")
                    for key, value in content.items():
                        if isinstance(value, str):
                            f.write(f'{key} = "{value}"\n')
                        else:
                            f.write(f'{key} = {value}\n')

        # Set secure file permissions (user read/write only)
        config_path.chmod(0o600)
