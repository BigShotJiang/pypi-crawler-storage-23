"""Oracle adaptation engine - adapts historical oracles to new code."""

import logging
from typing import Optional

from ..providers.base import Provider
from .context import ContextDerivation

logger = logging.getLogger(__name__)


class OracleAdapter:
    """Adapts historical oracles to new code using LLM reasoning.

    When similar code is found in history, instead of deriving a fresh oracle
    from scratch, we adapt the existing oracle to the new code. This saves
    LLM calls and maintains consistency across similar implementations.
    """

    def __init__(self, provider: Provider):
        """Initialize oracle adapter.

        Args:
            provider: LLM provider for adaptation
        """
        self.provider = provider

    async def adapt_oracle(
        self,
        old_oracle: ContextDerivation,
        old_code: str,
        new_code: str,
        user_request: str,
        similarity_score: float,
    ) -> Optional[ContextDerivation]:
        """Adapt historical oracle to new code.

        Args:
            old_oracle: Historical context derivation to adapt
            old_code: Historical code the oracle was derived from
            new_code: New code to adapt oracle for
            user_request: User specification for new code
            similarity_score: Cosine similarity between old and new code

        Returns:
            Adapted ContextDerivation or None if adaptation fails
        """
        system_prompt = """You are a senior systems analyst specializing in adapting behavioral
contracts to similar code implementations.

You will be given:
1. An EXISTING behavioral oracle derived from similar code
2. The ORIGINAL code that oracle was derived from
3. The NEW code that needs an oracle
4. The user's specification for the new code
5. The similarity score between old and new code

Your job is to ADAPT the existing oracle to the new code, rather than deriving
from scratch. Focus on:
- What changed between old and new code?
- Which behavioral invariants remain the same?
- Which invariants need updating?
- Any new integration contracts or edge cases?

Output the ADAPTED oracle as structured JSON matching the original format with
all 6 sections + function_invariants:

1. system_placement
2. environmental_constraints
3. integration_contracts
4. behavioral_invariants
5. edge_case_surface
6. implicit_assumptions
7. function_invariants (dict mapping function names to their specific invariants)

Be conservative: if you're unsure whether an invariant still applies, include it
with a note. Better to over-specify than under-specify."""

        user_message = f"""## Similarity Score
{similarity_score:.2%} match with historical code

## Historical Code
```python
{old_code}
```

## Historical Oracle
```json
{old_oracle.to_json()}
```

## New Code
```python
{new_code}
```

## User Specification for New Code
{user_request}

## Task
Adapt the historical oracle to the new code. Identify what changed and update
the oracle accordingly. Output as structured JSON."""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

        try:
            response = await self.provider.generate(messages)
            response_text = response.get("text", "").strip()

            # Parse JSON response
            if "```json" in response_text:
                start = response_text.find("```json") + 7
                end = response_text.find("```", start)
                response_text = response_text[start:end].strip()
            elif "```" in response_text:
                start = response_text.find("```") + 3
                end = response_text.find("```", start)
                response_text = response_text[start:end].strip()

            import json

            data = json.loads(response_text)
            adapted = ContextDerivation.from_dict(data)

            logger.info(
                f"Successfully adapted oracle from historical code (similarity: {similarity_score:.2%})"
            )
            return adapted

        except Exception as e:
            logger.warning(f"Failed to adapt historical oracle: {e}")
            return None
