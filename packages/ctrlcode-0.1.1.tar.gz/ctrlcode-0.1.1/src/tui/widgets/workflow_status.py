"""Workflow status bar widget."""

from textual.widgets import Static
from textual.reactive import reactive


class WorkflowStatusBar(Static):
    """Display current workflow phase and progress."""

    DEFAULT_CSS = """
    WorkflowStatusBar {
        height: 3;
        background: $panel;
        border: solid $primary;
        padding: 1;
    }
    """

    phase = reactive("idle")
    progress = reactive(0.0)
    status_text = reactive("")

    def __init__(self, *args, **kwargs):
        """Initialize workflow status bar."""
        super().__init__(*args, **kwargs)
        self.phases = ["planning", "execution", "review", "validation", "complete"]

    def render(self) -> str:
        """Render workflow status bar."""
        if self.phase == "idle":
            return "[dim]No active workflow[/]"

        # Build phase indicator
        phase_indicators = []
        for p in self.phases:
            if p == self.phase:
                phase_indicators.append(f"[bold green]{p.title()}[/]")
            elif self.phases.index(p) < self.phases.index(self.phase):
                phase_indicators.append(f"[green]✓ {p.title()}[/]")
            else:
                phase_indicators.append(f"[dim]{p.title()}[/]")

        phase_line = " ▸ ".join(phase_indicators)

        # Build progress bar
        bar_width = 30
        filled = int(self.progress * bar_width)
        empty = bar_width - filled
        progress_bar = f"[{'█' * filled}{'░' * empty}] {int(self.progress * 100)}%"

        # Status text
        status = self.status_text or f"Phase: {self.phase}"

        return f"{phase_line}\n{progress_bar}\n[dim]{status}[/]"

    def set_phase(self, phase: str):
        """
        Update current workflow phase.

        Args:
            phase: Phase name (planning, execution, review, validation, complete)
        """
        if phase in self.phases or phase == "idle":
            self.phase = phase

    def set_progress(self, completed: int, total: int):
        """
        Update progress bar.

        Args:
            completed: Number of completed items
            total: Total number of items
        """
        if total > 0:
            self.progress = min(1.0, completed / total)
        else:
            self.progress = 0.0

    def set_status(self, status: str):
        """
        Set status text.

        Args:
            status: Status message
        """
        self.status_text = status
