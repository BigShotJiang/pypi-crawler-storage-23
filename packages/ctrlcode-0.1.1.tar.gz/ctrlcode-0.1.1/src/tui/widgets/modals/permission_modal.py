"""Permission approval modal."""

from textual.containers import Container
from textual.widgets import Static, Button

from ..modal_base import ModalBase


class PermissionModal(ModalBase):
    """Modal for requesting user permission."""

    DEFAULT_CSS = """
    PermissionModal Button {
        margin: 1 2;
    }

    PermissionModal .permission-details {
        padding: 1 2;
        background: $surface-darken-1;
        margin: 1 0;
    }

    PermissionModal .warning {
        color: $warning;
        text-style: bold;
    }
    """

    def __init__(
        self,
        request_id: str,
        operation: str,
        path: str,
        reason: str,
        details: dict | None = None,
    ):
        """Initialize permission modal.

        Args:
            request_id: Unique request ID
            operation: Operation being requested
            path: Path being accessed
            reason: Human-readable reason
            details: Additional context
        """
        super().__init__()
        self.request_id = request_id
        self.operation = operation
        self.path = path
        self.reason = reason
        self.details = details or {}

    def compose(self):
        """Compose modal widgets."""
        with Container():
            yield Static("⚠️  Permission Required", classes="modal-title warning")

            with Container(classes="permission-details"):
                yield Static(f"[b]Operation:[/b] {self.operation}")
                yield Static(f"[b]Path:[/b] {self.path}")
                yield Static(f"[b]Reason:[/b] {self.reason}")

                # Show additional details if provided
                if "workspace" in self.details:
                    yield Static(f"[dim]Workspace: {self.details['workspace']}[/dim]")

            with Container():
                yield Button("✓ Approve", id="approve", variant="success")
                yield Button("✗ Deny", id="deny", variant="error")

            yield Static(
                "[dim]Approving allows this operation to proceed.[/dim]",
                classes="modal-footer"
            )

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        approved = event.button.id == "approve"

        # Send response to server
        try:
            await self.app.client.send_permission_response(self.request_id, approved)
        except Exception as e:
            self.app.notify(f"Failed to send permission response: {e}", severity="error")

        # Close modal
        self.dismiss()
