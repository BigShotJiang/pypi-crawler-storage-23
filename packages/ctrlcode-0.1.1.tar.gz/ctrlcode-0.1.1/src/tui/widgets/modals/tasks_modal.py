"""Tasks modal - shows task graph with dependencies."""

from textual.widgets import Static, Tree
from textual.containers import VerticalScroll

from ..modal_base import ModalBase


class TasksModal(ModalBase):
    """
    Shows task graph with dependencies.

    Displays:
    - Task ID and description
    - Status (pending, in_progress, complete, error)
    - Dependencies
    - Assigned agent
    """

    DEFAULT_CSS = """
    TasksModal {
        width: 70%;
        height: 80%;
    }

    TasksModal .task-complete {
        color: $success;
    }

    TasksModal .task-in-progress {
        color: $warning;
    }

    TasksModal .task-pending {
        color: $text-muted;
    }

    TasksModal .task-error {
        color: $error;
    }
    """

    def __init__(self, task_graph: dict):
        super().__init__()
        self.graph = task_graph

    def compose(self):
        from textual.containers import Container

        with Container():
            yield Static("Task Graph", classes="modal-title")

            # Task tree
            with VerticalScroll(classes="modal-content"):
                if not self.graph or "tasks" not in self.graph:
                    yield Static("No tasks available", classes="task-pending")
                else:
                    tree = Tree("Tasks")
                    self._build_task_tree(tree.root, self.graph["tasks"])
                    yield tree

            yield Static("Press ESC to close", classes="modal-footer")

    def _build_task_tree(self, parent, tasks: list[dict]):
        """Build tree structure from task graph."""
        for task in tasks:
            task_id = task.get("id", "unknown")
            description = task.get("description", "")
            status = task.get("status", "pending")
            dependencies = task.get("dependencies", [])

            # Icon based on status
            icon = "✓" if status == "complete" else "⏳" if status == "in_progress" else "⏸" if status == "pending" else "❌"

            # Label with icon and description
            label = f"{icon} {task_id}: {description}"

            # Add to tree
            node = parent.add(label, expand=True)

            # Add dependency info
            if dependencies:
                deps_str = ", ".join(dependencies)
                node.add_leaf(f"└─ Depends on: {deps_str}")
