"""Agents modal - shows all active agents and their status."""

from textual.widgets import Static, ProgressBar
from textual.containers import VerticalScroll

from ..modal_base import ModalBase


class AgentRow(Static):
    """Single agent row in the agents modal."""

    DEFAULT_CSS = """
    AgentRow {
        height: auto;
        padding: 1;
        border-bottom: solid $surface-lighten-1;
    }

    AgentRow .agent-header {
        text-style: bold;
    }

    AgentRow .agent-status-complete {
        color: $success;
    }

    AgentRow .agent-status-active {
        color: $warning;
    }

    AgentRow .agent-status-waiting {
        color: $text-muted;
    }

    AgentRow .agent-task {
        color: $text;
        padding-left: 2;
    }
    """

    def __init__(self, agent: dict):
        super().__init__()
        self.agent = agent

    def compose(self):
        agent_id = self.agent["id"]
        agent_type = self.agent["type"]
        status = self.agent["status"]
        task = self.agent.get("task", "")
        progress = self.agent.get("progress", 0.0)

        # Icon based on status
        icon = "✓" if status == "complete" else "⏳" if status == "active" else "⏸"

        # Status class for color coding
        status_class = f"agent-status-{status}"

        # Header: icon + type + status
        header = f"{icon} {agent_type.capitalize():<15} [{status.upper()}]"
        yield Static(header, classes=f"agent-header {status_class}")

        # Task info
        if task:
            yield Static(f"  {task}", classes="agent-task")

        # Progress bar if active
        if status == "active" and progress > 0:
            progress_bar = ProgressBar(total=100, show_percentage=True)
            progress_bar.update(progress=int(progress * 100))
            yield progress_bar


class AgentsModal(ModalBase):
    """
    Shows all agents and their status.

    Displays:
    - Agent type (planner, coder, reviewer, executor)
    - Current status (complete, active, waiting)
    - Current task
    - Progress bar (if active)
    """

    DEFAULT_CSS = """
    AgentsModal {
        width: 60%;
        height: 70%;
    }
    """

    def __init__(self, agents_data: list[dict]):
        super().__init__()
        self.agents = agents_data

    def compose(self):
        from textual.containers import Container

        with Container():
            yield Static("Active Agents", classes="modal-title")

            # Agent list
            with VerticalScroll(classes="modal-content"):
                if not self.agents:
                    yield Static("No active agents", classes="agent-task")
                else:
                    for agent in self.agents:
                        yield AgentRow(agent)

            yield Static("Press ESC to close", classes="modal-footer")
