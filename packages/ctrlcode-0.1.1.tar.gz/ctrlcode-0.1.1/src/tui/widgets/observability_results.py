"""Observability validation results widget."""

from textual.widgets import Static


class ObservabilityResultsWidget(Static):
    """Display validation results from executor agent."""

    DEFAULT_CSS = """
    ObservabilityResultsWidget {
        height: auto;
        max-height: 15;
        background: $surface;
        border: solid $success;
        padding: 1;
        overflow-y: auto;
    }
    """

    def __init__(self, *args, **kwargs):
        """Initialize observability results widget."""
        super().__init__(*args, **kwargs)
        self.test_results: dict = {}
        self.performance_metrics: dict = {}
        self.log_analysis: dict = {}
        self.recommendation: str = ""

    def render(self) -> str:
        """Render validation results."""
        if not self.test_results and not self.performance_metrics:
            return "[bold]✓ Validation Results[/]\n[dim]No validation run yet[/]"

        lines = ["[bold]✓ Validation Results[/]", ""]

        # Test results
        if self.test_results:
            passed = self.test_results.get("passed", 0)
            failed = self.test_results.get("failed", 0)
            duration = self.test_results.get("duration", 0.0)

            if failed > 0:
                color = "red"
                icon = "✗"
            else:
                color = "green"
                icon = "✓"

            lines.append(f"[{color}]{icon} Tests:[/] {passed} passed, {failed} failed")
            lines.append(f"Duration: {duration:.1f}s")
            lines.append("")

        # Performance metrics
        if self.performance_metrics:
            lines.append("[bold]Performance:[/]")
            threshold = self.performance_metrics.get("threshold", 0)

            for metric_name, value in self.performance_metrics.items():
                if metric_name == "threshold":
                    continue

                if isinstance(value, (int, float)):
                    # Check against threshold
                    if threshold > 0 and value > threshold:
                        status = "⚠"
                        color = "yellow"
                    else:
                        status = "✓"
                        color = "green"

                    lines.append(f"  {metric_name}: {value}ms [{color}]{status}[/]")

            if threshold > 0:
                lines.append(f"  [dim](threshold: {threshold}ms)[/]")
            lines.append("")

        # Log analysis
        if self.log_analysis:
            errors = self.log_analysis.get("errors", 0)
            warnings = self.log_analysis.get("warnings", 0)

            if errors > 0:
                color = "red"
            elif warnings > 0:
                color = "yellow"
            else:
                color = "green"

            lines.append(f"[{color}]Logs:[/] {errors} errors, {warnings} warnings")
            lines.append("")

        # Recommendation
        if self.recommendation:
            if "approve" in self.recommendation.lower():
                color = "green"
                icon = "✓"
            else:
                color = "yellow"
                icon = "⚠"

            lines.append(f"[{color}]{icon} Recommendation:[/] {self.recommendation}")

        return "\n".join(lines)

    def set_test_results(self, results: dict):
        """
        Display test execution results.

        Args:
            results: Dict with keys: passed, failed, duration
        """
        self.test_results = results
        self.refresh()

    def set_performance_metrics(self, metrics: dict, threshold: float = 0.0):
        """
        Display performance metrics with threshold comparison.

        Args:
            metrics: Dict of metric_name: value pairs
            threshold: Performance threshold for comparison
        """
        self.performance_metrics = metrics.copy()
        if threshold > 0:
            self.performance_metrics["threshold"] = threshold
        self.refresh()

    def set_log_analysis(self, analysis: dict):
        """
        Display log health summary.

        Args:
            analysis: Dict with keys: errors, warnings
        """
        self.log_analysis = analysis
        self.refresh()

    def set_recommendation(self, recommendation: str):
        """
        Display final recommendation.

        Args:
            recommendation: Recommendation text
        """
        self.recommendation = recommendation
        self.refresh()

    def clear(self):
        """Clear all results."""
        self.test_results = {}
        self.performance_metrics = {}
        self.log_analysis = {}
        self.recommendation = ""
        self.refresh()
