"""Task graph visualization widget."""

from textual.widgets import Static


class TaskGraphWidget(Static):
    """Display task graph with dependencies."""

    DEFAULT_CSS = """
    TaskGraphWidget {
        height: auto;
        max-height: 20;
        background: $surface;
        border: solid $accent;
        padding: 1;
        overflow-y: auto;
    }
    """

    def __init__(self, *args, **kwargs):
        """Initialize task graph widget."""
        super().__init__(*args, **kwargs)
        self.task_graph: dict = {}
        self.expanded_tasks: set[str] = set()

    def render(self) -> str:
        """Render task graph."""
        if not self.task_graph:
            return "[bold]Task Graph[/]\n[dim]No tasks[/]"

        lines = ["[bold]Task Graph[/]", ""]

        tasks = self.task_graph.get("tasks", [])
        parallel_groups = self.task_graph.get("parallel_groups", [])

        if not tasks:
            return "[bold]Task Graph[/]\n[dim]No tasks defined[/]"

        # Build task lookup
        task_map = {task["id"]: task for task in tasks}

        # Group tasks by parallel groups
        grouped_tasks = []
        seen_task_ids = set()

        for group in parallel_groups:
            group_tasks = []
            for task_id in group:
                if task_id in task_map:
                    group_tasks.append(task_map[task_id])
                    seen_task_ids.add(task_id)
            grouped_tasks.append(group_tasks)

        # Add any ungrouped tasks
        for task in tasks:
            if task["id"] not in seen_task_ids:
                grouped_tasks.append([task])

        # Render grouped tasks
        for i, group in enumerate(grouped_tasks):
            if len(group) > 1:
                lines.append(f"[cyan]Parallel Group {i + 1}:[/]")

            for task in group:
                task_id = task["id"]
                description = task.get("description", task_id)
                status = task.get("status", "pending")
                depends_on = task.get("depends_on", [])

                # Status icon
                if status == "completed":
                    icon = "✓"
                    color = "green"
                elif status == "in_progress":
                    icon = "⏳"
                    color = "cyan"
                elif status == "error":
                    icon = "✗"
                    color = "red"
                else:
                    icon = "○"
                    color = "dim"

                # Task line
                prefix = "  " if len(group) > 1 else ""
                lines.append(f"{prefix}[{color}]{icon} {task_id}:[/] {description}")

                # Dependencies
                if depends_on:
                    dep_str = ", ".join(depends_on)
                    lines.append(f"{prefix}  └─ Depends on: {dep_str}")

            lines.append("")  # Blank line between groups

        return "\n".join(lines)

    def set_task_graph(self, task_graph: dict):
        """
        Set full task graph from planner.

        Args:
            task_graph: Task graph dict with 'tasks' and 'parallel_groups'
        """
        self.task_graph = task_graph
        self.refresh()

    def update_task_status(self, task_id: str, status: str):
        """
        Update individual task status.

        Args:
            task_id: Task identifier
            status: New status (pending, in_progress, completed, error)
        """
        tasks = self.task_graph.get("tasks", [])
        for task in tasks:
            if task["id"] == task_id:
                task["status"] = status
                break
        self.refresh()

    def expand_task(self, task_id: str):
        """
        Expand task details.

        Args:
            task_id: Task identifier
        """
        self.expanded_tasks.add(task_id)
        self.refresh()

    def collapse_task(self, task_id: str):
        """
        Collapse task details.

        Args:
            task_id: Task identifier
        """
        self.expanded_tasks.discard(task_id)
        self.refresh()

    def clear(self):
        """Clear task graph."""
        self.task_graph = {}
        self.expanded_tasks.clear()
        self.refresh()
