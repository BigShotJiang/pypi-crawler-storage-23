"""JSON-RPC client for ctrl-code server."""

import json
from typing import Any, AsyncIterator

import httpx


class RPCClient:
    """Async JSON-RPC client."""

    def __init__(self, base_url: str = "http://127.0.0.1:8765", api_key: str | None = None):
        """
        Initialize RPC client.

        Args:
            base_url: Base URL of ctrl-code server
            api_key: API key for authentication
        """
        self.base_url = base_url
        self.api_key = api_key
        self.request_id = 0

    def _get_headers(self) -> dict[str, str]:
        """Get headers including auth."""
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _next_id(self) -> int:
        """Generate next request ID."""
        self.request_id += 1
        return self.request_id

    async def create_session(self, provider: str | None = None) -> dict[str, Any]:
        """
        Create new session.

        Args:
            provider: Optional provider name (anthropic, openai)

        Returns:
            Session info with session_id and provider
        """
        params = {}
        if provider:
            params["provider"] = provider

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "session.create",
                    "params": params,
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=30.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]

    async def process_turn(
        self, session_id: str, user_input: str, tools: list[dict[str, Any]] | None = None
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Process conversation turn with streaming.

        Args:
            session_id: Session identifier
            user_input: User message
            tools: Optional list of MCP tools

        Yields:
            Stream events as dicts
        """
        params: dict[str, Any] = {"session_id": session_id, "input": user_input}
        if tools:
            params["tools"] = tools

        async with httpx.AsyncClient() as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "turn.process",
                    "params": params,
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=300.0,  # 5 min timeout for long fuzzing runs
            ) as response:
                async for line in response.aiter_lines():
                    if line.strip():
                        event = json.loads(line)
                        yield event

    async def get_baseline(self, session_id: str) -> dict[str, Any]:
        """
        Get baseline code for session.

        Args:
            session_id: Session identifier

        Returns:
            Baseline info with code, file_path, language
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "session.baseline",
                    "params": {"session_id": session_id},
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=30.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]

    async def get_stats(self, session_id: str) -> dict[str, Any]:
        """Get context statistics for session."""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "session.stats",
                    "params": {"session_id": session_id},
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=30.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]

    async def get_history_metrics(self) -> dict[str, Any]:
        """Get historical learning metrics."""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "session.get_history_metrics",
                    "params": {},
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=30.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]

    async def send_permission_response(self, request_id: str, approved: bool) -> dict[str, Any]:
        """Send permission response to server.

        Args:
            request_id: Permission request ID
            approved: Whether user approved the operation

        Returns:
            Response from server
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "permission.response",
                    "params": {
                        "request_id": request_id,
                        "approved": approved
                    },
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=5.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]

    async def compact_session(self, session_id: str) -> dict[str, Any]:
        """Compact conversation history."""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "session.compact",
                    "params": {"session_id": session_id},
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=30.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]

    async def clear_conversation(self, session_id: str) -> dict[str, Any]:
        """Clear conversation history."""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "session.clear",
                    "params": {"session_id": session_id},
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=30.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]

    async def call_tool(
        self, session_id: str, tool_name: str, tool_input: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Call a tool directly.

        Args:
            session_id: Session identifier
            tool_name: Name of the tool to call
            tool_input: Tool input parameters

        Returns:
            Tool result
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/rpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "tool.call",
                    "params": {
                        "session_id": session_id,
                        "tool_name": tool_name,
                        "tool_input": tool_input,
                    },
                    "id": self._next_id(),
                },
                headers=self._get_headers(),
                timeout=30.0,
            )
            data = response.json()

            if "error" in data:
                raise RuntimeError(f"RPC error: {data['error']}")

            return data["result"]
