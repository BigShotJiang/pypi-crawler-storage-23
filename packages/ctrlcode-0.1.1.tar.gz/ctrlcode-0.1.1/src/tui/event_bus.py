"""
Central event bus for TUI.

All components publish events to the bus.
Components subscribe to events they care about.
No direct coupling between components.

Architecture:
    Workflow → EventBus → Subscribers (StatusLine, ChatLog, Modals, etc.)
"""

from collections import defaultdict
from typing import Callable, Any
import asyncio
from datetime import datetime


class Event:
    """Event published to the bus."""

    def __init__(self, event_type: str, data: dict[str, Any], source: str = "unknown"):
        self.type = event_type
        self.data = data
        self.source = source
        self.timestamp = datetime.now()

    def __repr__(self):
        return f"Event(type={self.type}, source={self.source}, data={self.data})"

    def to_dict(self):
        """Convert to dict for serialization."""
        return {
            "type": self.type,
            "data": self.data,
            "source": self.source,
            "timestamp": self.timestamp.isoformat(),
        }


class EventBus:
    """
    Central event bus for pub/sub messaging.

    Components publish events without knowing who's listening.
    Components subscribe to events they care about.
    """

    def __init__(self):
        # Map: event_type -> list of handlers
        self._subscribers: dict[str, list[Callable]] = defaultdict(list)

        # Event history for debugging/replay
        self._history: list[Event] = []
        self._max_history = 1000

    def subscribe(self, event_type: str, handler: Callable):
        """
        Subscribe to an event type.

        Args:
            event_type: Event type to listen for (e.g., "workflow_phase_change")
                       Use "*" to subscribe to all events
            handler: Async function to call when event occurs
                    Signature: async def handler(event: Event) -> None
        """
        self._subscribers[event_type].append(handler)

    def unsubscribe(self, event_type: str, handler: Callable):
        """Unsubscribe from an event type."""
        if event_type in self._subscribers:
            self._subscribers[event_type].remove(handler)

    async def publish(self, event_type: str, data: dict[str, Any], source: str = "unknown"):
        """
        Publish an event to the bus.

        All subscribers to this event type will be notified.
        Wildcard subscribers ("*") will also be notified.

        Args:
            event_type: Type of event (e.g., "workflow_phase_change")
            data: Event payload
            source: Source component (for debugging)
        """
        event = Event(event_type, data, source)

        # Add to history
        self._history.append(event)
        if len(self._history) > self._max_history:
            self._history.pop(0)

        # Notify specific subscribers
        handlers = self._subscribers.get(event_type, [])

        # Notify wildcard subscribers
        handlers.extend(self._subscribers.get("*", []))

        # Call all handlers
        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                # Don't let one handler failure stop others
                print(f"Error in event handler: {e}")
                import traceback
                traceback.print_exc()

    def get_history(self, event_type: str | None = None) -> list[Event]:
        """
        Get event history.

        Args:
            event_type: Filter by event type, or None for all events

        Returns:
            List of events in chronological order
        """
        if event_type is None:
            return self._history.copy()
        else:
            return [e for e in self._history if e.type == event_type]

    def clear_history(self):
        """Clear event history."""
        self._history.clear()


# ========================================
# Event Type Catalog
# ========================================

class EventTypes:
    """
    Catalog of all event types in the system.

    Organized by category for easy discovery.
    """

    # === Workflow Events ===
    WORKFLOW_PHASE_CHANGE = "workflow_phase_change"
    WORKFLOW_AGENT_SPAWNED = "workflow_agent_spawned"
    WORKFLOW_AGENT_UPDATED = "workflow_agent_updated"
    WORKFLOW_AGENT_COMPLETED = "workflow_agent_completed"
    WORKFLOW_TASK_GRAPH_CREATED = "workflow_task_graph_created"
    WORKFLOW_TASK_UPDATED = "workflow_task_updated"
    WORKFLOW_REVIEW_FEEDBACK = "workflow_review_feedback"
    WORKFLOW_OBSERVABILITY_RESULTS = "workflow_observability_results"
    WORKFLOW_PARALLEL_START = "workflow_parallel_start"
    WORKFLOW_PARALLEL_PROGRESS = "workflow_parallel_progress"
    WORKFLOW_ERROR = "workflow_error"
    WORKFLOW_COMPLETE = "workflow_complete"

    # === UI Events ===
    UI_MODAL_OPENED = "ui_modal_opened"
    UI_MODAL_CLOSED = "ui_modal_closed"
    UI_COMMAND_ENTERED = "ui_command_entered"
    UI_MESSAGE_SENT = "ui_message_sent"

    # === System Events ===
    SYSTEM_INFO = "system_info"
    SYSTEM_WARNING = "system_warning"
    SYSTEM_ERROR = "system_error"

    # === Single-Agent Events ===
    AGENT_THINKING = "agent_thinking"
    AGENT_TOOL_CALL = "agent_tool_call"
    AGENT_TOOL_RESULT = "agent_tool_result"
    AGENT_RESPONSE = "agent_response"

    @classmethod
    def all_workflow_events(cls) -> list[str]:
        """Get all workflow event types."""
        return [
            cls.WORKFLOW_PHASE_CHANGE,
            cls.WORKFLOW_AGENT_SPAWNED,
            cls.WORKFLOW_AGENT_UPDATED,
            cls.WORKFLOW_AGENT_COMPLETED,
            cls.WORKFLOW_TASK_GRAPH_CREATED,
            cls.WORKFLOW_TASK_UPDATED,
            cls.WORKFLOW_REVIEW_FEEDBACK,
            cls.WORKFLOW_OBSERVABILITY_RESULTS,
            cls.WORKFLOW_PARALLEL_START,
            cls.WORKFLOW_PARALLEL_PROGRESS,
            cls.WORKFLOW_ERROR,
            cls.WORKFLOW_COMPLETE,
        ]

    @classmethod
    def all_ui_events(cls) -> list[str]:
        """Get all UI event types."""
        return [
            cls.UI_MODAL_OPENED,
            cls.UI_MODAL_CLOSED,
            cls.UI_COMMAND_ENTERED,
            cls.UI_MESSAGE_SENT,
        ]

    @classmethod
    def all_system_events(cls) -> list[str]:
        """Get all system event types."""
        return [
            cls.SYSTEM_INFO,
            cls.SYSTEM_WARNING,
            cls.SYSTEM_ERROR,
        ]


# ========================================
# Event Payload Schemas (Documentation)
# ========================================

class EventSchemas:
    """
    Documentation for event payload schemas.

    Use this as reference when publishing/handling events.
    """

    WORKFLOW_PHASE_CHANGE = {
        "phase": "str - planning|execution|review|validation|complete",
        "progress": "float - 0.0 to 1.0",
        "active_agents": "int - optional, number of active agents",
    }

    WORKFLOW_AGENT_SPAWNED = {
        "agent_id": "str - unique agent ID",
        "type": "str - planner|coder|reviewer|executor",
        "task": "str - optional, task description",
    }

    WORKFLOW_AGENT_UPDATED = {
        "agent_id": "str - agent ID",
        "status": "str - optional, active|waiting|complete",
        "progress": "float - 0.0 to 1.0",
        "task": "str - optional, current task",
    }

    WORKFLOW_TASK_GRAPH_CREATED = {
        "task_graph": {
            "tasks": "list[dict] - task definitions",
            "parallel_groups": "list[list[str]] - parallel task groups",
        }
    }

    WORKFLOW_REVIEW_FEEDBACK = {
        "feedback": [
            {
                "severity": "str - blocker|error|info",
                "file": "str - file path",
                "line": "int - line number",
                "message": "str - issue description",
                "suggestion": "str - fix recommendation",
                "status": "str - pending|in_progress|fixed",
            }
        ]
    }

    WORKFLOW_OBSERVABILITY_RESULTS = {
        "results": {
            "tests": {
                "passed": "int",
                "failed": "int",
                "duration": "str",
            },
            "performance": {
                "p50": "int - milliseconds",
                "p95": "int - milliseconds",
                "p99": "int - milliseconds",
                "threshold": "int - milliseconds",
            },
            "logs": {
                "errors": "int",
                "warnings": "int",
            },
            "recommendation": "str - approve|reject",
        }
    }

    UI_COMMAND_ENTERED = {
        "command": "str - command name (without /)",
        "args": "str - optional, command arguments",
    }

    SYSTEM_ERROR = {
        "message": "str - error message",
        "exception": "str - optional, exception type",
        "traceback": "str - optional, stack trace",
    }
