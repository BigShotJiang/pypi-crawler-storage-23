"""Ctrl+Code TUI client."""

__version__ = "0.1.1"
