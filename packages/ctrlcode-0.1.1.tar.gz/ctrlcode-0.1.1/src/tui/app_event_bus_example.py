"""
Event Bus Based TUI App

Components communicate only through the event bus.
No direct coupling between components.
"""

from textual.app import App, ComposeResult
from textual.binding import Binding

from .event_bus import EventBus, EventTypes, Event
from .widgets.status_line import StatusLine
from .widgets.chat_log import ChatLog
from .widgets.input_box import InputBox
from .widgets.modals import (
    AgentsModal,
    TasksModal,
    StatusModal,
    ReviewModal,
    MetricsModal,
)


class CtrlCodeApp(App):
    """
    Event-driven TUI app.

    All communication happens through the event bus:
    - Workflow publishes events
    - UI components subscribe to events
    - Components react independently
    """

    CSS = """
    StatusLine {
        dock: top;
        height: 1;
    }

    ChatLog {
        height: 1fr;
    }

    InputBox {
        dock: bottom;
        height: 3;
    }
    """

    BINDINGS = [
        Binding("ctrl+a", "show_agents", "Agents"),
        Binding("ctrl+t", "show_tasks", "Tasks"),
        Binding("ctrl+s", "show_status", "Status"),
        Binding("ctrl+r", "show_review", "Review"),
        Binding("ctrl+m", "show_metrics", "Metrics"),
        Binding("ctrl+c", "quit", "Quit"),
    ]

    def __init__(self):
        super().__init__()

        # Create event bus (single instance for entire app)
        self.event_bus = EventBus()

        # Workflow state (for modals)
        # Updated by listening to events
        self.workflow_active = False
        self.agents_data = []
        self.task_graph = {}
        self.review_feedback = []
        self.metrics_data = {}

    def compose(self) -> ComposeResult:
        """Minimal layout."""
        yield StatusLine()
        yield ChatLog()
        yield InputBox()

    def on_mount(self):
        """Subscribe to events on app startup."""
        bus = self.event_bus

        # Subscribe to workflow events to track state
        bus.subscribe(EventTypes.WORKFLOW_PHASE_CHANGE, self._track_workflow_state)
        bus.subscribe(EventTypes.WORKFLOW_AGENT_SPAWNED, self._track_agent_spawned)
        bus.subscribe(EventTypes.WORKFLOW_AGENT_UPDATED, self._track_agent_updated)
        bus.subscribe(EventTypes.WORKFLOW_TASK_GRAPH_CREATED, self._track_task_graph)
        bus.subscribe(EventTypes.WORKFLOW_REVIEW_FEEDBACK, self._track_review_feedback)
        bus.subscribe(EventTypes.WORKFLOW_OBSERVABILITY_RESULTS, self._track_metrics)

        # Subscribe to UI events
        bus.subscribe(EventTypes.UI_COMMAND_ENTERED, self._handle_command)

    # ========================================
    # State Tracking (from events)
    # ========================================

    async def _track_workflow_state(self, event: Event):
        """Track workflow state from phase change events."""
        phase = event.data["phase"]
        if phase != "idle":
            self.workflow_active = True
        elif phase == "complete":
            self.workflow_active = False

    async def _track_agent_spawned(self, event: Event):
        """Track agent spawning."""
        self.agents_data.append({
            "id": event.data["agent_id"],
            "type": event.data["type"],
            "status": "active",
            "progress": 0.0,
            "task": event.data.get("task", ""),
        })

    async def _track_agent_updated(self, event: Event):
        """Track agent updates."""
        agent_id = event.data["agent_id"]
        for agent in self.agents_data:
            if agent["id"] == agent_id:
                if "status" in event.data:
                    agent["status"] = event.data["status"]
                if "progress" in event.data:
                    agent["progress"] = event.data["progress"]
                if "task" in event.data:
                    agent["task"] = event.data["task"]
                break

    async def _track_task_graph(self, event: Event):
        """Track task graph creation."""
        self.task_graph = event.data["task_graph"]

    async def _track_review_feedback(self, event: Event):
        """Track review feedback."""
        self.review_feedback.extend(event.data["feedback"])

    async def _track_metrics(self, event: Event):
        """Track observability metrics."""
        self.metrics_data = event.data["results"]

    # ========================================
    # Command Handling (from events)
    # ========================================

    async def _handle_command(self, event: Event):
        """Handle UI commands (published by InputBox)."""
        command = event.data["command"].lower()

        if command == "agents":
            self.action_show_agents()
        elif command == "tasks":
            self.action_show_tasks()
        elif command == "status":
            self.action_show_status()
        elif command == "review":
            self.action_show_review()
        elif command == "metrics":
            self.action_show_metrics()
        elif command == "clear":
            self.query_one(ChatLog).clear()
        elif command == "help":
            await self._show_help()
        else:
            await self.event_bus.publish(
                EventTypes.SYSTEM_INFO,
                {"message": f"Unknown command: /{command}. Type /help for commands."},
                source="app"
            )

    # ========================================
    # Modal Actions
    # ========================================

    def action_show_agents(self):
        """Show agents modal."""
        if self.workflow_active and self.agents_data:
            modal = AgentsModal(self.agents_data)
            self.mount(modal)

            # Publish event
            self.event_bus.publish(
                EventTypes.UI_MODAL_OPENED,
                {"modal_type": "agents"},
                source="app"
            )
        else:
            self.event_bus.publish(
                EventTypes.SYSTEM_INFO,
                {"message": "No agents active"},
                source="app"
            )

    def action_show_tasks(self):
        """Show tasks modal."""
        if self.task_graph:
            modal = TasksModal(self.task_graph)
            self.mount(modal)

            self.event_bus.publish(
                EventTypes.UI_MODAL_OPENED,
                {"modal_type": "tasks"},
                source="app"
            )
        else:
            self.event_bus.publish(
                EventTypes.SYSTEM_INFO,
                {"message": "No task graph available"},
                source="app"
            )

    def action_show_status(self):
        """Show status modal (bus viewer)."""
        # Pass event history to modal
        history = self.event_bus.get_history()
        modal = StatusModal([e.to_dict() for e in history])
        self.mount(modal)

        self.event_bus.publish(
            EventTypes.UI_MODAL_OPENED,
            {"modal_type": "status"},
            source="app"
        )

    def action_show_review(self):
        """Show review modal."""
        if self.review_feedback:
            modal = ReviewModal(self.review_feedback)
            self.mount(modal)

            self.event_bus.publish(
                EventTypes.UI_MODAL_OPENED,
                {"modal_type": "review"},
                source="app"
            )
        else:
            self.event_bus.publish(
                EventTypes.SYSTEM_INFO,
                {"message": "No review feedback"},
                source="app"
            )

    def action_show_metrics(self):
        """Show metrics modal."""
        if self.metrics_data:
            modal = MetricsModal(self.metrics_data)
            self.mount(modal)

            self.event_bus.publish(
                EventTypes.UI_MODAL_OPENED,
                {"modal_type": "metrics"},
                source="app"
            )
        else:
            self.event_bus.publish(
                EventTypes.SYSTEM_INFO,
                {"message": "No metrics available"},
                source="app"
            )

    async def _show_help(self):
        """Show help (via system info event)."""
        help_text = """
Available commands:
  /agents   - Show active agents
  /tasks    - Show task graph
  /status   - Show event bus
  /review   - Show review feedback
  /metrics  - Show observability results
  /clear    - Clear chat
  /help     - Show this help

Keyboard shortcuts:
  Ctrl+A    - Show agents
  Ctrl+T    - Show tasks
  Ctrl+S    - Show status (bus viewer)
  Ctrl+R    - Show review
  Ctrl+M    - Show metrics
  Ctrl+C    - Quit
        """
        await self.event_bus.publish(
            EventTypes.SYSTEM_INFO,
            {"message": help_text.strip()},
            source="app"
        )


# ========================================
# Example: How Workflow Publishes Events
# ========================================

class WorkflowOrchestrator:
    """
    Example of how workflow orchestrator publishes events.

    The workflow doesn't know about the TUI.
    It just publishes events to the bus.
    """

    def __init__(self, event_bus: EventBus):
        self.bus = event_bus

    async def execute_workflow(self, user_intent: str):
        """Execute workflow and publish events."""

        # Planning phase
        await self.bus.publish(
            EventTypes.WORKFLOW_PHASE_CHANGE,
            {"phase": "planning", "progress": 0.0, "active_agents": 0},
            source="workflow"
        )

        # Spawn planner
        await self.bus.publish(
            EventTypes.WORKFLOW_AGENT_SPAWNED,
            {"agent_id": "planner-1", "type": "planner", "task": "Decompose intent"},
            source="workflow"
        )

        # Planner creates task graph
        task_graph = {
            "tasks": [
                {"id": "task-1", "description": "Read auth code", "dependencies": []},
                {"id": "task-2", "description": "Add JWT utils", "dependencies": ["task-1"]},
            ],
            "parallel_groups": [["task-1"], ["task-2"]],
        }

        await self.bus.publish(
            EventTypes.WORKFLOW_TASK_GRAPH_CREATED,
            {"task_graph": task_graph},
            source="workflow"
        )

        # Complete planner
        await self.bus.publish(
            EventTypes.WORKFLOW_AGENT_COMPLETED,
            {"agent_id": "planner-1", "result": "success"},
            source="workflow"
        )

        # Execution phase
        await self.bus.publish(
            EventTypes.WORKFLOW_PHASE_CHANGE,
            {"phase": "execution", "progress": 0.25, "active_agents": 1},
            source="workflow"
        )

        # Spawn coder
        await self.bus.publish(
            EventTypes.WORKFLOW_AGENT_SPAWNED,
            {"agent_id": "coder-1", "type": "coder", "task": "task-1"},
            source="workflow"
        )

        # Coder makes progress
        await self.bus.publish(
            EventTypes.WORKFLOW_AGENT_UPDATED,
            {"agent_id": "coder-1", "progress": 0.5},
            source="workflow"
        )

        # Task complete
        await self.bus.publish(
            EventTypes.WORKFLOW_TASK_UPDATED,
            {"task_id": "task-1", "status": "complete"},
            source="workflow"
        )

        # Review phase
        await self.bus.publish(
            EventTypes.WORKFLOW_PHASE_CHANGE,
            {"phase": "review", "progress": 0.75, "active_agents": 1},
            source="workflow"
        )

        # Reviewer finds issue
        await self.bus.publish(
            EventTypes.WORKFLOW_REVIEW_FEEDBACK,
            {
                "feedback": [
                    {
                        "severity": "blocker",
                        "file": "src/auth.py",
                        "line": 42,
                        "message": "Password not hashed",
                        "suggestion": "Use bcrypt",
                        "status": "pending",
                    }
                ]
            },
            source="workflow"
        )

        # Complete
        await self.bus.publish(
            EventTypes.WORKFLOW_COMPLETE,
            {"status": "success", "summary": "All tasks complete"},
            source="workflow"
        )


# ========================================
# Example: How Components Subscribe
# ========================================

# Enhanced StatusLine that subscribes to events
class StatusLineEventDriven(StatusLine):
    """StatusLine that updates from event bus."""

    def on_mount(self):
        """Subscribe to events on mount."""
        bus = self.app.event_bus

        # Subscribe to phase changes
        bus.subscribe(EventTypes.WORKFLOW_PHASE_CHANGE, self._on_phase_change)

        # Subscribe to errors
        bus.subscribe(EventTypes.SYSTEM_ERROR, self._on_error)

    def on_unmount(self):
        """Unsubscribe on unmount."""
        bus = self.app.event_bus
        bus.unsubscribe(EventTypes.WORKFLOW_PHASE_CHANGE, self._on_phase_change)
        bus.unsubscribe(EventTypes.SYSTEM_ERROR, self._on_error)

    async def _on_phase_change(self, event: Event):
        """Handle phase change event."""
        phase = event.data["phase"]
        progress = event.data["progress"]
        active_agents = event.data.get("active_agents", 0)
        self.set_workflow(phase, progress, active_agents)

    async def _on_error(self, event: Event):
        """Handle error event."""
        message = event.data["message"]
        self.set_error(message)


# Enhanced ChatLog that subscribes to events
class ChatLogEventDriven(ChatLog):
    """ChatLog that displays events inline."""

    def on_mount(self):
        """Subscribe to all events."""
        bus = self.app.event_bus
        bus.subscribe("*", self._on_any_event)  # Wildcard: all events

    def on_unmount(self):
        """Unsubscribe."""
        bus = self.app.event_bus
        bus.unsubscribe("*", self._on_any_event)

    async def _on_any_event(self, event: Event):
        """Display event inline in chat."""
        # Map event types to icons
        icon_map = {
            EventTypes.WORKFLOW_AGENT_SPAWNED: "🔵",
            EventTypes.WORKFLOW_AGENT_COMPLETED: "✅",
            EventTypes.WORKFLOW_TASK_UPDATED: "📝",
            EventTypes.WORKFLOW_REVIEW_FEEDBACK: "🔴",
            EventTypes.WORKFLOW_COMPLETE: "🎉",
            EventTypes.SYSTEM_ERROR: "❌",
            EventTypes.SYSTEM_WARNING: "⚠️",
            EventTypes.SYSTEM_INFO: "ℹ️",
        }

        icon = icon_map.get(event.type, "•")

        # Format message based on event type
        message = self._format_event_message(event)

        if message:
            self.add_workflow_event(event.type, message, icon)

    def _format_event_message(self, event: Event) -> str:
        """Format event for display."""
        if event.type == EventTypes.WORKFLOW_AGENT_SPAWNED:
            return f"{event.data['type'].capitalize()} spawned"

        elif event.type == EventTypes.WORKFLOW_PHASE_CHANGE:
            phase = event.data["phase"]
            progress = event.data["progress"]
            return f"Phase: {phase} ({progress:.0%})"

        elif event.type == EventTypes.WORKFLOW_TASK_GRAPH_CREATED:
            num_tasks = len(event.data["task_graph"]["tasks"])
            return f"Task graph: {num_tasks} tasks"

        elif event.type == EventTypes.WORKFLOW_REVIEW_FEEDBACK:
            num_issues = len(event.data["feedback"])
            blockers = sum(1 for f in event.data["feedback"] if f["severity"] == "blocker")
            return f"Review: {num_issues} issues ({blockers} blockers)"

        elif event.type == EventTypes.SYSTEM_INFO:
            return event.data["message"]

        elif event.type == EventTypes.SYSTEM_ERROR:
            return f"Error: {event.data['message']}"

        return ""


# Enhanced InputBox that publishes commands as events
class InputBoxEventDriven(InputBox):
    """InputBox that publishes command events."""

    async def on_input_submitted(self, message: str):
        """Handle input submission."""
        bus = self.app.event_bus

        if message.startswith("/"):
            # Slash command
            command = message[1:].strip()
            await bus.publish(
                EventTypes.UI_COMMAND_ENTERED,
                {"command": command, "args": ""},
                source="input_box"
            )
        else:
            # Regular message
            await bus.publish(
                EventTypes.UI_MESSAGE_SENT,
                {"message": message},
                source="input_box"
            )
