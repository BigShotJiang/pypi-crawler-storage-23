"""Ctrl+Code TUI application."""

import asyncio
import json
import time
from datetime import datetime
from pathlib import Path
from textual.app import App, ComposeResult
from textual.containers import Container
from textual.widgets import Footer, Input, Static
from textual.binding import Binding

from .client import RPCClient
from .event_bus_new import EventBus, Event
from .launcher import ServerLauncher
from .widgets import (
    CollapsibleCodeBlock,
    HistoryInput,
    TodoModal,
    AgentActivityPanel,
    TaskGraphWidget,
    ReviewFeedbackWidget,
    ParallelExecutionWidget,
    ObservabilityResultsWidget,
)
from .widgets.status_line import StatusLine
from .widgets.modals import (
    AgentsModal,
    TasksModal,
    StatusModal,
    ReviewModal,
    MetricsModal,
    HistoryModal,
    PermissionModal,
)


class SessionLogger:
    """Log session events to JSONL file."""

    def __init__(self, session_id: str, sessions_dir: Path):
        """Initialize logger with session ID and directory."""
        self.session_id = session_id
        self.log_file = sessions_dir / f"{session_id}.jsonl"

        # Create the file on init (will be empty initially)
        self.log_file.touch(exist_ok=True)

    def log(self, event_type: str, data: dict | None = None):
        """Log an event to JSONL file (append mode)."""
        event = {
            "timestamp": datetime.now().isoformat(),
            "type": event_type,
            "session_id": self.session_id,
        }
        if data:
            event.update(data)

        # Append to file
        with open(self.log_file, "a") as f:
            f.write(json.dumps(event) + "\n")


class CtrlCodeTUI(App):
    """Ctrl+Code TUI application."""

    COMMANDS = {
        "/clear": "Clear chat history",
        "/help": "Show this help message",
        "/compact": "Compact conversation history",
        "/summarize": "Summarize conversation",
        "/stats": "Show context statistics",
        "/todos": "Show todo list",
        "/details": "Show/hide continuation exploration details",
        "/agents": "Show active agents (multi-agent mode)",
        "/tasks": "Show task graph (multi-agent mode)",
        "/status": "Show event bus viewer",
        "/review": "Show review feedback (multi-agent mode)",
        "/metrics": "Show observability results (multi-agent mode)",
        "/history": "Show historical learning metrics",
        "/copy": "Copy last assistant message to clipboard",
        "/exit": "Exit the application",
        "/quit": "Exit the application",
    }

    # Hint for text selection
    TITLE = "Ctrl+Code TUI (Shift+Mouse to select text)"

    CSS = """
    #chat-container {
        height: 1fr;
        overflow-y: auto;
        background: $background;
    }

    #chat-container:focus {
        background: $background;
    }

    .hidden {
        display: none;
    }

    #task-graph, #review-feedback, #parallel-execution, #observability-results, #agent-panel {
        height: auto;
        max-height: 15;
        margin: 1 0;
    }

    #status-indicator {
        height: 0;
        padding: 0 1;
        background: $panel;
        color: $text-muted;
    }

    #status-indicator.visible {
        height: 1;
    }

    .streaming-message {
        color: $text;
        padding: 0 1;
        height: auto;
        min-height: 0;
        background: $background;
    }

    #command-menu {
        display: none;
        background: $panel;
        border: solid $primary;
        padding: 1;
        margin-bottom: 1;
        height: auto;
    }

    #command-menu.visible {
        display: block;
    }

    #context-counter {
        dock: top;
        width: 100%;
        height: 1;
        text-align: right;
        padding-right: 2;
        color: $text-muted;
        background: $background;
    }

    Input {
        border: solid $accent;
        margin-bottom: 1;
    }
    """

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit", show=True),
        Binding("escape", "cancel_request", "Cancel", show=True),
        Binding("ctrl+o", "toggle_code_block", "Expand", show=False),
        Binding("ctrl+e", "toggle_continuation_details", "Details", show=False),
        Binding("ctrl+c", "copy_text", "Copy", show=False),
        Binding("ctrl+v", "paste_text", "Paste", show=False),
    ]

    def __init__(self, server_url: str = "http://127.0.0.1:8765", **kwargs):
        """
        Initialize TUI app.

        Args:
            server_url: URL of ctrl-code server
            **kwargs: Additional app kwargs
        """
        super().__init__(**kwargs)

        # Load config to get API key
        from ctrlcode.config import Config
        config = Config.load()
        api_key = config.server.api_key

        self.server_url = server_url
        self.launcher = ServerLauncher(server_url, api_key=api_key)
        self.client = RPCClient(server_url, api_key=api_key)
        self.session_id: str | None = None
        self.sessions_dir: Path | None = None
        self.events: EventBus | None = None
        self.logger: SessionLogger | None = None
        self.current_assistant_text = ""
        self.request_start_time: float | None = None
        self._status_base_text = ""
        self.status_colors = ["bright_cyan", "bright_blue", "bright_magenta", "green"]
        self.status_color_index = 0
        self.current_tokens = 0
        self.streaming_task: asyncio.Task | None = None
        self.cancel_requested = False
        self.context_used = 0
        self.context_max = 0  # Will be set from server
        self.max_input_length = 200000  # Default, will be set from server
        self.turn_start_tokens = 0  # Track tokens at start of turn
        self.pending_code_blocks = []  # Buffer code blocks until turn complete
        self.last_turn_tokens = {}  # Store token breakdown for last turn
        self.multi_agent_mode = False  # Track if in multi-agent workflow
        self.continuation_tools = []  # Store hidden continuation tool results
        self.continuation_count = 0  # Count continuation iterations
        self.show_continuation_details = False  # Toggle for showing/hiding details
        self.in_continuation = False  # Track if currently in continuation phase
        self.continuation_text = []  # Store hidden continuation text

        # Multi-agent state for modals
        self.agents_data = []  # Track active agents
        self.task_graph = {}  # Task graph from planner
        self.review_feedback = []  # Review feedback items
        self.metrics_data = {}  # Observability results
        self.history_data = {}  # Historical learning metrics

        # Security: workspace root for path validation
        self.workspace_root = Path.cwd().resolve()

        # Reconnection state
        self._conn_state: str = "connected"   # "connected" | "reconnecting" | "failed"
        self._reconnect_attempts: int = 0

    def _validate_path(self, path: str | Path) -> Path:
        """
        Validate and resolve a path.

        Args:
            path: Path to validate

        Returns:
            Resolved absolute path

        Note:
            Paths outside workspace are allowed - server will request permission if needed.
        """
        try:
            # Just resolve to absolute path - server handles permission for paths outside workspace
            resolved_path = Path(path).resolve()
            return resolved_path

        except Exception as e:
            raise ValueError(f"Invalid path: {path} - {e}")

    @staticmethod
    def _is_connection_error(e: Exception) -> bool:
        import httpx
        return isinstance(e, (httpx.ConnectError, httpx.TimeoutException, httpx.ReadError))

    def _load_history_from_jsonl(self, session_id: str) -> list[str]:
        """Load user message history from session JSONL file (most recent first)."""
        if not self.sessions_dir:
            return []
        log_file = self.sessions_dir / f"{session_id}.jsonl"

        if not log_file.exists():
            return []

        messages = []
        try:
            with open(log_file, "r") as f:
                for line in f:
                    event = json.loads(line.strip())
                    if event.get("type") == "user_message":
                        content = event.get("content", "")
                        if content:
                            messages.append(content)
        except Exception:
            return []

        # Reverse to get most recent first
        return list(reversed(messages))

    def _add_message(self, content: str, classes: str = "") -> None:
        """Add a message widget to chat container."""
        message = Static(content, markup=True, classes=f"chat-message {classes}")
        chat_container = self.query_one("#chat-container")
        streaming_message = self.query_one("#streaming-message")
        chat_container.mount(message, before=streaming_message)
        chat_container.scroll_end(animate=False)

    def _subscribe_ui_handlers(self) -> None:
        """Subscribe UI update handlers to eventbus."""
        self.events.subscribe("text", self._on_text_event)
        self.events.subscribe("content_block_start", self._on_content_block_start)
        self.events.subscribe("tool_call_start", self._on_tool_call_start)
        self.events.subscribe("tool_result", self._on_tool_result)
        self.events.subscribe("continuation_complete", self._on_continuation_complete)
        self.events.subscribe("fuzzing_progress", self._on_fuzzing_progress)
        self.events.subscribe("user_message", self._on_user_message)
        self.events.subscribe("token_usage", self._on_token_usage)
        self.events.subscribe("assistant_message_complete", self._on_assistant_message_complete)
        self.events.subscribe("request_cancelled", self._on_request_cancelled)
        self.events.subscribe("request_error", self._on_request_error)

        # Multi-agent workflow events
        self.events.subscribe("workflow_phase_change", self._on_workflow_phase_change)
        self.events.subscribe("workflow_agent_spawned", self._on_workflow_agent_spawned)
        self.events.subscribe("workflow_agent_updated", self._on_workflow_agent_updated)
        self.events.subscribe("workflow_agent_completed", self._on_workflow_agent_completed)
        self.events.subscribe("workflow_task_graph_created", self._on_workflow_task_graph_created)
        self.events.subscribe("workflow_task_updated", self._on_workflow_task_updated)
        self.events.subscribe("workflow_review_feedback", self._on_workflow_review_feedback)
        self.events.subscribe("workflow_observability_results", self._on_workflow_observability_results)
        self.events.subscribe("workflow_parallel_start", self._on_workflow_parallel_start)
        self.events.subscribe("workflow_parallel_progress", self._on_workflow_parallel_progress)
        self.events.subscribe("workflow_oracle_reused", self._on_workflow_oracle_reused)
        self.events.subscribe("workflow_bug_pattern_detected", self._on_workflow_bug_pattern_detected)
        self.events.subscribe("workflow_history_updated", self._on_workflow_history_updated)

    async def _emit(self, event_type: str, data: dict | None = None) -> None:
        """Log event to JSONL and publish to async event bus."""
        if self.logger:
            self.logger.log(event_type, data)
        if self.events:
            await self.events.publish(event_type, data or {})

    async def _on_text_event(self, event: Event) -> None:
        """Handle streaming text event."""
        import logging
        logger = logging.getLogger(__name__)

        data = event.data
        text = data.get("text", "")

        # If in continuation, hide the text (just accumulate for later viewing)
        if self.in_continuation:
            self.continuation_text.append(text)
            logger.debug(f"TEXT EVENT (continuation): hiding {len(text)} chars")
            return  # Don't render continuation text

        status_indicator = self.query_one("#status-indicator", Static)

        # Show streaming status on first token
        if not self.current_assistant_text:
            self._status_base_text = "Streaming..."
            status_indicator.add_class("visible")

        # Stream text by updating Static widget
        logger.info(f"TEXT EVENT: got {len(text)} chars, total now: {len(self.current_assistant_text)}")
        self.current_assistant_text += text

        # Estimate tokens (rough: 1 token ≈ 4 chars)
        self.current_tokens = len(self.current_assistant_text) // 4

        # Update streaming widget
        streaming_widget = self.query_one("#streaming-message", Static)
        streaming_widget.update(f"[bold green]Assistant:[/] {self.current_assistant_text}")

        # Auto-scroll container to bottom
        container = self.query_one("#chat-container")
        container.scroll_end(animate=False)

    async def _on_content_block_start(self, event: Event) -> None:
        """Handle content block start event."""
        data = event.data
        status_indicator = self.query_one("#status-indicator", Static)
        block_type = data.get("type", "text")

        # Only say "Thinking" if it's actually a thinking block
        if block_type == "thinking":
            self._status_base_text = "Thinking..."
        else:
            self._status_base_text = "Processing..."

        status_indicator.add_class("visible")

    async def _on_tool_call_start(self, event: Event) -> None:
        """Handle tool call start event."""
        data = event.data
        status_indicator = self.query_one("#status-indicator", Static)
        tool_name = data.get("tool", "unknown")
        self._status_base_text = f"Using tool: {tool_name}"
        status_indicator.add_class("visible")

    async def _on_tool_result(self, event: Event) -> None:
        """Handle tool result event."""
        data = event.data
        # Check if this is a continuation tool result - if so, hide it
        is_continuation = data.get("continuation", False)

        if is_continuation:
            # Mark that we've entered continuation phase
            if not self.in_continuation:
                self.in_continuation = True

            # Store for later viewing, but don't render
            self.continuation_tools.append(data)
            self.continuation_count += 1
            # Update status silently
            status_indicator = self.query_one("#status-indicator", Static)
            tool_name = data.get("tool", "unknown")
            self._status_base_text = f"Exploring ({self.continuation_count} files)..."
            status_indicator.add_class("visible")
            return  # Don't render continuation tool results

        status_indicator = self.query_one("#status-indicator", Static)
        tool_name = data.get("tool", "unknown")
        success = data.get("success", False)
        result = data.get("result", {})

        self._status_base_text = f"Processing results from {tool_name}..."
        status_indicator.add_class("visible")

        # Track if we added any code blocks (will mount them at the end)
        _blocks_added = len(self.pending_code_blocks)

        if tool_name == "write_file" and success:
            # Buffer code block to mount after assistant message
            path = result.get("path", "unknown")
            try:
                from rich.markup import escape

                # Validate path to prevent traversal attacks
                file_path = self._validate_path(path)
                content = file_path.read_text()

                # Create code block and buffer it (escape path to prevent markup injection)
                safe_path = escape(str(path))
                code_block = CollapsibleCodeBlock(path=safe_path, content=content)
                self.pending_code_blocks.append(code_block)

            except ValueError as e:
                # Path validation error
                self.notify(f"Security error: {e}", severity="error", timeout=5)
                self._add_message(f"[red]Security error: {e}[/]")
            except Exception as e:
                import traceback
                self.notify(f"Failed to create code block: {e}", severity="error", timeout=5)
                self._add_message(f"[red]Error: {e}[/]")
                self._add_message(f"[dim]{traceback.format_exc()}[/]")

        elif tool_name == "run_command" and success:
            # Show bash command output in collapsible block
            try:
                from rich.markup import escape

                command = result.get("command", "unknown command")
                stdout = result.get("stdout", "")
                stderr = result.get("stderr", "")
                returncode = result.get("returncode", 0)

                # Combine output
                output_parts = []
                if stdout:
                    output_parts.append(f"# stdout\n{stdout}")
                if stderr:
                    output_parts.append(f"# stderr\n{stderr}")
                output_parts.append(f"# exit code: {returncode}")

                content = "\n\n".join(output_parts)
                # Escape command to prevent markup injection
                safe_command = escape(command)
                code_block = CollapsibleCodeBlock(path=f"$ {safe_command}", content=content)
                self.pending_code_blocks.append(code_block)

            except Exception as e:
                import traceback
                self.notify(f"Failed to create bash output block: {e}", severity="error", timeout=5)
                self._add_message(f"[red]Error: {e}[/]")
                self._add_message(f"[dim]{traceback.format_exc()}[/]")

        elif tool_name == "fetch" and success:
            # Show URL and status as static text (content goes to context, not displayed)
            try:
                from rich.markup import escape

                url = result.get("url", "unknown url")
                method = result.get("method", "GET")
                status_code = result.get("status_code", 0)

                # Escape URL to prevent markup injection
                safe_url = escape(url)
                safe_method = escape(method)

                # Show simple status message
                self._add_message(f"[dim]🌐 Fetched {safe_method} {safe_url} → HTTP {status_code}[/]")

            except Exception as e:
                import traceback
                self.notify(f"Failed to display fetch result: {e}", severity="error", timeout=5)
                self._add_message(f"[red]Error: {e}[/]")
                self._add_message(f"[dim]{traceback.format_exc()}[/]")

        elif tool_name == "update_file" and success:
            # Show updated file content in collapsible block
            try:
                from rich.markup import escape

                path = result.get("path", "unknown")
                operation = result.get("operation", "update")

                # Validate path to prevent traversal attacks
                file_path = self._validate_path(path)
                content = file_path.read_text()

                # Escape path to prevent markup injection
                safe_path = escape(str(path))
                safe_operation = escape(operation)
                code_block = CollapsibleCodeBlock(path=f"{safe_path} ({safe_operation})", content=content)
                self.pending_code_blocks.append(code_block)

            except ValueError as e:
                # Path validation error
                self.notify(f"Security error: {e}", severity="error", timeout=5)
                self._add_message(f"[red]Security error: {e}[/]")
            except Exception as e:
                import traceback
                self.notify(f"Failed to create update file block: {e}", severity="error", timeout=5)
                self._add_message(f"[red]Error: {e}[/]")
                self._add_message(f"[dim]{traceback.format_exc()}[/]")

        elif tool_name == "read_file" and success:
            # Show file content in collapsible block
            try:
                from rich.markup import escape

                # Result can be string content directly or dict with content
                if isinstance(result, str):
                    content = result
                    path = "file"
                else:
                    path = result.get("path", result.get("file", "file"))
                    content = result.get("content", str(result))

                # Escape path to prevent markup injection
                safe_path = escape(path)
                code_block = CollapsibleCodeBlock(path=safe_path, content=content)
                self.pending_code_blocks.append(code_block)

            except Exception as e:
                self.notify(f"Failed to create read_file block: {e}", severity="error", timeout=5)
                self._add_message(f"[red]Error: {e}[/]")

        elif tool_name == "list_directory" and success:
            # Show directory listing
            try:
                from rich.markup import escape

                # Result can be a list directly or a dict
                if isinstance(result, list):
                    entries = result
                    path = "directory"
                else:
                    path = result.get("path", "directory")
                    entries = result.get("entries", result.get("files", []))

                # Escape path and entries to prevent markup injection
                safe_path = escape(path)
                if entries:
                    safe_entries = [escape(str(e)) for e in entries[:50]]
                    listing = "\n".join([f"  {e}" for e in safe_entries])  # Show first 50
                    if len(entries) > 50:
                        listing += f"\n  ... and {len(entries) - 50} more"

                    self._add_message(f"[dim]📁 {safe_path}:[/]\n{listing}")
                else:
                    self._add_message(f"[dim]📁 {safe_path}: (empty)[/]")

            except Exception as e:
                self._add_message(f"[red]Error displaying directory: {e}[/]")

        elif tool_name == "search_files" and success:
            # Show search results
            try:
                from rich.markup import escape

                # Result can be a list directly or a dict with matches
                if isinstance(result, list):
                    matches = result
                    _pattern = "pattern"
                else:
                    _pattern = result.get("pattern", "pattern")
                    matches = result.get("matches", result.get("files", []))

                if matches:
                    # Escape matches to prevent markup injection
                    safe_matches = [escape(str(m)) for m in matches[:20]]
                    match_list = "\n".join([f"  • {m}" for m in safe_matches])
                    if len(matches) > 20:
                        match_list += f"\n  ... and {len(matches) - 20} more"

                    self._add_message(f"[dim]🔍 Found {len(matches)} files:[/]\n{match_list}")
                else:
                    self._add_message("[dim]🔍 No files found[/]")

            except Exception as e:
                self._add_message(f"[red]Error displaying search results: {e}[/]")

        elif tool_name == "search_code" and success:
            # Show code search results
            try:
                from rich.markup import escape

                # Result can be a list directly or a dict
                if isinstance(result, list):
                    matches = result
                    _query = "query"
                else:
                    _query = result.get("query", "query")
                    matches = result.get("matches", result.get("results", []))

                if matches:
                    # Handle both dict format {file, line} and string format
                    # Escape to prevent markup injection
                    match_list_items = []
                    for m in matches[:20]:
                        if isinstance(m, dict):
                            safe_file = escape(str(m.get('file', '?')))
                            safe_line = escape(str(m.get('line', '?')))
                            match_list_items.append(f"  • {safe_file}:{safe_line}")
                        else:
                            match_list_items.append(f"  • {escape(str(m))}")

                    match_list = "\n".join(match_list_items)
                    if len(matches) > 20:
                        match_list += f"\n  ... and {len(matches) - 20} more"

                    self._add_message(f"[dim]🔍 Found {len(matches)} code matches:[/]\n{match_list}")
                else:
                    self._add_message("[dim]🔍 No code matches found[/]")

            except Exception as e:
                self._add_message(f"[red]Error displaying search results: {e}[/]")

        elif not success:
            # Show error
            error = data.get("result", "Unknown error")
            self._add_message(f"[dim]✗ Tool error: {error}[/]")

        # Code blocks will be mounted at message complete, not here
        # This ensures they appear after all assistant text

    async def _on_continuation_complete(self, event: Event) -> None:
        """Handle continuation complete event - show hint about hidden tools."""
        data = event.data
        # Exit continuation phase
        self.in_continuation = False

        iterations = data.get("iterations", 0)
        tool_count = len(self.continuation_tools)

        if tool_count > 0:
            # Show hint message about hidden continuation details
            hint_msg = f"[dim]🔍 Explored {tool_count} files across {iterations} iterations[/] [cyan](press Ctrl+E for details or type /details)[/]"
            self._add_message(hint_msg)

    async def _on_fuzzing_progress(self, event: Event) -> None:
        """Handle fuzzing progress event."""
        data = event.data
        message = data.get("message", "Fuzzing...")
        self._status_base_text = f"Fuzzing: {message}"

    async def _on_token_usage(self, event: Event) -> None:
        """Handle token usage event from server."""
        data = event.data
        # Store token breakdown for display in completion message
        self.last_turn_tokens = {
            "turn": data.get("turn_tokens", 0),  # Total tokens this turn
            "input": data.get("input_tokens", 0),  # Input tokens this turn
            "output": data.get("output_tokens", 0),  # Output tokens this turn
        }
        # Update context counter with cumulative total
        self.context_used = data.get("total_tokens", 0)

    async def _on_user_message(self, event: Event) -> None:
        """Handle user message event."""
        from rich.markup import escape

        data = event.data
        content = data.get("content", "")
        # Security: escape user input to prevent markup injection
        safe_content = escape(content)
        self._add_message(f"[bold cyan]You:[/] {safe_content}")
        self._add_message("")  # Blank line

    async def _on_assistant_message_complete(self, event: Event) -> None:
        """Handle assistant message completion event."""
        import re

        # Parse markdown code blocks from assistant text and create widgets
        if self.current_assistant_text:
            text = self.current_assistant_text

            # Find all markdown code blocks: ```language\ncode\n```
            code_block_pattern = r'```(\w+)?\n(.*?)```'
            matches = list(re.finditer(code_block_pattern, text, re.DOTALL))

            if matches:
                # Don't extract assistant text code blocks into collapsible widgets —
                # tool results already show command/file output in collapsibles.
                # Just render assistant markdown inline.
                pass

            if text:  # Show text if any remains after extracting code blocks
                self._add_message(f"[bold green]Assistant:[/] {text}")
            elif self.pending_code_blocks:
                # All text was code blocks - show empty assistant prefix
                self._add_message("[bold green]Assistant:[/]")
        elif self.pending_code_blocks:
            # Tool-only response - show empty assistant message
            self._add_message("[bold green]Assistant:[/]")

        # Mount any pending code blocks (after assistant message, before completion)
        if self.pending_code_blocks:
            chat_container = self.query_one("#chat-container")
            streaming_message = self.query_one("#streaming-message")
            for code_block in self.pending_code_blocks:
                chat_container.mount(code_block, before=streaming_message)
            self.pending_code_blocks.clear()
            chat_container.scroll_end(animate=False)

        # Always add completion summary with token breakdown
        if self.request_start_time:
            elapsed = time.time() - self.request_start_time

            # Show output tokens generated this turn
            if self.last_turn_tokens:
                output = self.last_turn_tokens.get("output", 0)
                self._add_message(f"[dim]Completed in {elapsed:.1f}s ({output} tokens)[/]")
            else:
                # Fallback if token_usage event not received
                self._add_message(f"[dim]Completed in {elapsed:.1f}s[/]")

            self._add_message("")  # Blank line

        # Clear streaming widget
        streaming_widget = self.query_one("#streaming-message", Static)
        streaming_widget.update("")

        # Clear status indicator
        status_indicator = self.query_one("#status-indicator", Static)
        status_indicator.remove_class("visible")
        self.request_start_time = None
        self._status_base_text = ""
        self.current_tokens = 0
        self.current_assistant_text = ""
        self.last_turn_tokens = {}  # Clear for next turn

    async def _on_request_cancelled(self, event: Event) -> None:
        """Handle request cancellation event."""
        self._add_message("[yellow]Request cancelled by user[/]")
        self._add_message("")  # Blank line

        # Clear status
        status_indicator = self.query_one("#status-indicator", Static)
        status_indicator.remove_class("visible")
        self.request_start_time = None
        self._status_base_text = ""
        self.current_tokens = 0

    async def _on_request_error(self, event: Event) -> None:
        """Handle request error event."""
        data = event.data
        error = data.get("error", "Unknown error")
        details = data.get("details", "")
        self._add_message(f"[bold red]Error:[/] {error}")
        self._add_message(f"[dim]{details}[/]")

        # Clear status
        status_indicator = self.query_one("#status-indicator", Static)
        status_indicator.remove_class("visible")
        self.request_start_time = None
        self._status_base_text = ""
        self.current_tokens = 0

    async def _on_workflow_phase_change(self, event: Event) -> None:
        """Handle workflow phase change event."""
        data = event.data
        phase = data.get("phase", "idle")
        status = data.get("status", "")

        self.multi_agent_mode = True

        # Show phase change as a chat message with status indicator
        if status:
            phase_emoji = {
                "planning": "🎯",
                "execution": "⚙️",
                "review": "🔍",
                "validation": "✅",
                "complete": "🎉"
            }.get(phase, "📋")

            self._add_message(f"[cyan]{phase_emoji} {status}[/]")

        # Update status line
        status_indicator = self.query_one("#status-indicator", Static)
        if phase != "idle" and phase != "complete":
            self._status_base_text = status or f"Phase: {phase}"
            status_indicator.add_class("visible")
        else:
            status_indicator.remove_class("visible")

    async def _on_workflow_agent_spawned(self, event: Event) -> None:
        """Handle agent spawned event."""
        data = event.data
        agent_type = data.get("type")
        agent_id = data.get("agent_id")
        task = data.get("task", "")

        # Track agent for modals
        self.agents_data.append({
            "id": agent_id,
            "type": agent_type,
            "status": "active",
            "progress": 0.0,
            "task": task,
        })

        # Show agent activity inline in chat
        if agent_type and task:
            agent_emoji = {
                "planner": "🎯",
                "coder": "💻",
                "reviewer": "🔍",
                "executor": "🧪"
            }.get(agent_type, "🤖")

            self._add_message(f"[dim]{agent_emoji} {agent_type.title()}: {task}[/]")

    async def _on_workflow_agent_updated(self, event: Event) -> None:
        """Handle agent status update event."""
        data = event.data
        agent_id = data.get("agent_id")
        status = data.get("status")
        progress = data.get("progress", 0.0)

        # Update agent data for modals
        for agent in self.agents_data:
            if agent["id"] == agent_id:
                if status:
                    agent["status"] = status
                agent["progress"] = progress
                break

    async def _on_workflow_agent_completed(self, event: Event) -> None:
        """Handle agent completion event."""
        # Completion shown via phase change messages
        pass

    async def _on_workflow_task_graph_created(self, event: Event) -> None:
        """Handle task graph creation event."""
        data = event.data
        task_graph = data.get("task_graph", {})

        # Store for modal
        self.task_graph = task_graph

        # Show task breakdown inline
        tasks = task_graph.get("tasks", [])
        if tasks:
            self._add_message("[cyan]📋 Task breakdown:[/]")
            for i, task in enumerate(tasks[:5]):  # Show first 5 tasks
                task_desc = task.get("description", task.get("id", ""))
                self._add_message(f"  {i+1}. {task_desc}")
            if len(tasks) > 5:
                self._add_message(f"  ... and {len(tasks) - 5} more tasks")
            self._add_message(f"[dim](Type /tasks for full graph)[/]")

    async def _on_workflow_task_updated(self, event: Event) -> None:
        """Handle task status update event."""
        # Task updates shown inline with task graph
        pass

    async def _on_workflow_review_feedback(self, event: Event) -> None:
        """Handle review feedback event."""
        data = event.data
        feedback_items = data.get("feedback", [])

        # Store for modal
        self.review_feedback.extend(feedback_items)

        # Show review feedback inline
        if feedback_items:
            self._add_message("[yellow]🔍 Review feedback:[/]")
            for item in feedback_items:
                severity = item.get("severity", "info")
                message = item.get("message", "")
                indicator = {"blocker": "🔴", "error": "🟡", "info": "🟢"}.get(severity, "ℹ️")
                self._add_message(f"  {indicator} {message}")
            self._add_message(f"[dim](Type /review for details)[/]")

    async def _on_workflow_observability_results(self, event: Event) -> None:
        """Handle observability results event."""
        data = event.data
        results = data.get("results", {})

        # Store for modal
        self.metrics_data = results

        # Show validation results inline
        self._add_message("[green]✅ Validation results:[/]")

        if "tests" in results:
            tests = results["tests"]
            passed = tests.get("passed", 0)
            failed = tests.get("failed", 0)
            status = "✓" if failed == 0 else "✗"
            self._add_message(f"  {status} Tests: {passed} passed, {failed} failed")

        if "recommendation" in results:
            rec = results["recommendation"]
            self._add_message(f"  → {rec}")

        self._add_message(f"[dim](Type /metrics for full details)[/]")

    async def _on_workflow_parallel_start(self, event: Event) -> None:
        """Handle parallel execution start event."""
        data = event.data
        task_ids = data.get("task_ids", [])

        try:
            parallel_widget = self.query_one(ParallelExecutionWidget)
            parallel_widget.set_tasks(task_ids)
        except Exception:
            pass

    async def _on_workflow_parallel_progress(self, event: Event) -> None:
        """Handle parallel task progress event."""
        data = event.data
        task_id = data.get("task_id")
        progress = data.get("progress", 0.0)
        description = data.get("description", "")

        if task_id:
            try:
                parallel_widget = self.query_one(ParallelExecutionWidget)
                parallel_widget.update_task_progress(task_id, progress, description)
            except Exception:
                pass

    async def _on_workflow_oracle_reused(self, event: Event) -> None:
        """Handle oracle reuse event."""
        data = event.data
        reused_from = data.get("reused_from_session", "previous session")
        token_savings = data.get("token_savings", 2500)
        time_savings = data.get("time_savings_seconds", 25.0)

        # Show inline hint
        self._add_message(f"[green]✨ Oracle reused from similar code[/]")
        self._add_message(f"   Saved ~{token_savings:,} tokens, ~{time_savings:.0f}s")
        self._add_message(f"[dim](Type /history for full metrics)[/]")

    async def _on_workflow_bug_pattern_detected(self, event: Event) -> None:
        """Handle bug pattern detection event."""
        data = event.data
        count = data.get("count", 0)
        patterns = data.get("patterns", [])

        # Show inline warning
        self._add_message(f"[yellow]⚠️  Detected {count} similar bug pattern{'s' if count != 1 else ''} from history[/]")

        # Show top patterns
        for pattern in patterns[:2]:  # Show top 2
            severity = pattern.get("severity", "MEDIUM")
            description = pattern.get("description", "")
            confidence = pattern.get("confidence", 0.0)

            severity_color = "red" if severity == "HIGH" else "yellow"
            self._add_message(f"   [{severity_color}]{severity}[/]: {description} (confidence: {confidence:.1%})")

        if count > 2:
            self._add_message(f"   ... and {count - 2} more")

        self._add_message(f"[dim](Type /history for details)[/]")

    async def _on_workflow_history_updated(self, event: Event) -> None:
        """Handle history update event."""
        data = event.data
        session_id = data.get("session_id", "")
        oracle_reused = data.get("oracle_reused", False)
        bug_patterns = data.get("bug_patterns_detected", 0)
        total_tests = data.get("total_tests", 0)

        # Update history_data for modal
        # Fetch latest stats from history DB if available
        # For now, just store the event data
        self.history_data = {
            "last_session_id": session_id,
            "last_oracle_reused": oracle_reused,
            "last_bug_patterns": bug_patterns,
            "last_total_tests": total_tests,
        }

    def compose(self) -> ComposeResult:
        """Compose app layout."""
        # Context counter in top right
        yield Static("0/200,000", id="context-counter")

        # Simple scrollable chat area
        # Messages are mounted as individual Static widgets (not RichLog)
        with Container(id="chat-container"):
            yield Static("", id="streaming-message", classes="streaming-message")

        # Hidden workflow widgets (only shown when active, minimal footprint)
        yield TaskGraphWidget(id="task-graph", classes="hidden")
        yield ReviewFeedbackWidget(id="review-feedback", classes="hidden")
        yield ParallelExecutionWidget(id="parallel-execution", classes="hidden")
        yield ObservabilityResultsWidget(id="observability-results", classes="hidden")
        yield AgentActivityPanel(id="agent-panel", classes="hidden")

        yield Static("", id="status-indicator", markup=True)
        yield Static("", id="command-menu", markup=True)
        yield HistoryInput(placeholder="Type a message or /command...", id="user-input")
        yield Footer()

    async def on_mount(self) -> None:
        """Initialize session on mount."""
        # Ensure server is running (auto-launch if needed)
        if not await self.launcher.ensure_server_running():
            self.notify("Failed to start server", severity="error")
            self.exit(1)
            return

        try:
            session_info = await self.client.create_session()
            self.session_id = session_info["session_id"]
            self.context_max = session_info.get("context_limit", 200000)
            self.max_input_length = session_info.get("max_input_length", 200000)
            self.sessions_dir = Path(session_info["sessions_dir"])
            self.events = EventBus()
            self.logger = SessionLogger(self.session_id, self.sessions_dir)

            # Subscribe UI handlers to eventbus
            self._subscribe_ui_handlers()

            await self._emit("session_created", {
                "provider": session_info["provider"],
                "context_limit": self.context_max
            })
            self._update_context_counter()

            # Load history from JSONL
            history = self._load_history_from_jsonl(self.session_id)
            history_input = self.query_one("#user-input", HistoryInput)
            history_input.load_history(history)

            self.notify(f"Connected. Provider: {session_info['provider']}")
        except Exception as e:
            self.notify(f"Failed to connect: {e}", severity="error")
            self._conn_state = "failed"
            self._status_base_text = "Disconnected – send a message to retry"
            status_indicator = self.query_one("#status-indicator", Static)
            status_indicator.update(f"[red]{self._status_base_text}[/]")
            status_indicator.add_class("visible")

        # Focus input field
        self.query_one("#user-input", HistoryInput).focus()

        # Start status animation timer
        self.set_interval(1.0, self._update_status_animation)

    def _update_status_animation(self) -> None:
        """Update status indicator with animation and elapsed time."""
        if not self._status_base_text:
            return

        # During reconnect: yellow, no elapsed time/tokens
        if self._conn_state == "reconnecting":
            status_indicator = self.query_one("#status-indicator", Static)
            status_indicator.update(f"[yellow]{self._status_base_text}[/]")
            return

        if not self.request_start_time:
            return

        # Calculate elapsed time
        elapsed = int(time.time() - self.request_start_time)

        # Cycle through colors
        color = self.status_colors[self.status_color_index]
        self.status_color_index = (self.status_color_index + 1) % len(self.status_colors)

        # Update status with color, time, and tokens
        status_text = f"[{color}]{self._status_base_text}[/] [{elapsed}s]"
        if self.current_tokens > 0:
            status_text += f" • {self.current_tokens} tokens"

        status_indicator = self.query_one("#status-indicator", Static)
        status_indicator.update(status_text)

    def _update_context_counter(self) -> None:
        """Update context counter widget."""
        percentage = (self.context_used / self.context_max * 100) if self.context_max > 0 else 0.0
        counter = self.query_one("#context-counter", Static)

        # Color based on usage
        if percentage >= 90:
            color = "red"
        elif percentage >= 75:
            color = "yellow"
        else:
            color = "dim"

        counter.update(
            f"[{color}]{self.context_used:,}/{self.context_max:,}[/]"
        )

    async def _refresh_context_stats(self) -> None:
        """Fetch and update context stats from server."""
        if not self.session_id:
            return

        try:
            stats = await self.client.get_stats(self.session_id)
            estimated = stats.get("estimated_tokens", 0)
            max_tokens = stats.get("max_tokens", self.context_max)

            self.context_used = estimated
            self.context_max = max_tokens
            self._update_context_counter()
        except Exception as e:
            # Log error but don't interrupt
            self.notify(f"Failed to refresh context stats: {e}", severity="warning", timeout=3)

    def on_input_changed(self, event: Input.Changed) -> None:
        """Show command menu when typing /."""
        value = event.value
        command_menu = self.query_one("#command-menu", Static)

        if value.startswith("/") and len(value) > 0:
            # Filter commands that match
            matching = [
                f"[cyan]{cmd}[/] - {desc}"
                for cmd, desc in self.COMMANDS.items()
                if cmd.startswith(value) or value == "/"
            ]

            if matching:
                command_menu.update("\n".join(matching))
                command_menu.add_class("visible")
            else:
                command_menu.remove_class("visible")
        else:
            command_menu.remove_class("visible")

    def _validate_user_input(self, user_input: str) -> tuple[bool, str]:
        """
        Validate user input before sending to server.

        Args:
            user_input: Raw user input string

        Returns:
            Tuple of (is_valid, error_message)
        """
        # Length validation (from server config, -1 = unlimited)
        if self.max_input_length > 0 and len(user_input) > self.max_input_length:
            return False, f"Input too long ({len(user_input)} chars, max {self.max_input_length})"

        # Check for null bytes (security risk)
        if "\x00" in user_input:
            return False, "Input contains null bytes"

        return True, ""

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle user input submission."""
        user_input = event.value.strip()
        if not user_input:
            return

        event.input.value = ""

        # Security: validate input before processing
        is_valid, error_msg = self._validate_user_input(user_input)
        if not is_valid:
            self.notify(f"Invalid input: {error_msg}", severity="error")
            return

        # Add to history (includes commands)
        history_input = self.query_one("#user-input", HistoryInput)
        history_input.add_to_history(user_input)

        # Handle commands
        if user_input.startswith("/"):
            await self._handle_command(user_input)
            return

        if not self.session_id:
            self.notify("No active session", severity="warning")
            return

        # Handle failed/reconnecting states
        if self._conn_state == "reconnecting":
            self.notify("Reconnection in progress, please wait", severity="warning")
            return
        if self._conn_state == "failed":
            reconnected = await self._reconnect_loop()
            if not reconnected:
                return

        # Create streaming task
        self.cancel_requested = False
        self.streaming_task = asyncio.create_task(
            self._stream_response(user_input)
        )

    async def _reconnect_loop(self) -> bool:
        """Exponential backoff reconnect. Returns True on success."""
        self._conn_state = "reconnecting"
        status_indicator = self.query_one("#status-indicator", Static)
        status_indicator.add_class("visible")
        input_field = self.query_one("#user-input", HistoryInput)
        input_field.disabled = True

        MAX_ATTEMPTS = 10
        for attempt in range(1, MAX_ATTEMPTS + 1):
            self._reconnect_attempts = attempt
            self._status_base_text = f"Reconnecting... ({attempt}/{MAX_ATTEMPTS})"
            status_indicator.update(f"[yellow]{self._status_base_text}[/]")

            if await self.launcher.ensure_server_running():
                try:
                    session_info = await self.client.create_session()
                    self.session_id = session_info["session_id"]
                    self.context_max = session_info.get("context_limit", self.context_max)
                    self.max_input_length = session_info.get("max_input_length", self.max_input_length)
                    if self.sessions_dir:
                        self.events = EventBus()
                        self.logger = SessionLogger(self.session_id, self.sessions_dir)
                        self._subscribe_ui_handlers()
                    self._conn_state = "connected"
                    self._reconnect_attempts = 0
                    self._status_base_text = ""
                    status_indicator.remove_class("visible")
                    input_field.disabled = False
                    self.notify("Reconnected", severity="information")
                    return True
                except Exception:
                    pass  # session creation failed — keep retrying

            wait = min(2 ** (attempt - 1), 30)  # 1s, 2s, 4s … 30s cap
            await asyncio.sleep(wait)

        # All attempts exhausted
        self._conn_state = "failed"
        self._status_base_text = "Disconnected – send a message to retry"
        status_indicator.update(f"[red]{self._status_base_text}[/]")
        status_indicator.add_class("visible")
        input_field.disabled = False
        self.notify("Disconnected from server", severity="error")
        return False

    async def _stream_response(self, user_input: str, *, _emit_user_msg: bool = True) -> None:
        """Stream response for user input."""
        # Emit user message event (UI handler will render it)
        if _emit_user_msg:
            await self._emit("user_message", {"content": user_input})

        # Start timing the request and track starting token count
        self.request_start_time = time.time()
        self.turn_start_tokens = self.context_used
        self._status_base_text = "Working..."
        self.status_color_index = 0
        self.current_tokens = 0

        # Show status indicator immediately
        status_indicator = self.query_one("#status-indicator", Static)
        status_indicator.add_class("visible")

        # Reset continuation tracking for new request
        self.continuation_tools = []
        self.continuation_count = 0
        self.show_continuation_details = False
        self.in_continuation = False
        self.continuation_text = []

        # Stream assistant response
        self.current_assistant_text = ""
        try:
            async for stream_event in self.client.process_turn(self.session_id, user_input):
                # Check for cancellation
                if self.cancel_requested:
                    break
                # Forward event to eventbus (UI handlers will update UI)
                await self._handle_stream_event(stream_event)

            # Refresh context stats to get actual token usage
            if self.session_id:
                await self._refresh_context_stats()

            # Calculate actual tokens used this turn
            tokens_used = self.context_used - self.turn_start_tokens

            # Emit completion event with actual token count
            await self._emit("assistant_message_complete", {
                "tokens_used": tokens_used
            })

        except asyncio.CancelledError:
            await self._emit("request_cancelled", {})

        except Exception as e:
            if self._is_connection_error(e):
                self._add_message("[yellow]Connection lost. Attempting to reconnect...[/]")
                reconnected = await self._reconnect_loop()
                if reconnected and user_input:
                    self.streaming_task = asyncio.create_task(
                        self._stream_response(user_input, _emit_user_msg=False)
                    )
            else:
                import traceback
                error_details = traceback.format_exc()
                await self._emit("request_error", {"error": str(e), "details": error_details})
                self.notify(f"Error: {e}", severity="error")

    async def _handle_permission_request(self, event: dict) -> None:
        """Handle permission request from server.

        Args:
            event: Permission request event with request_id, operation, path, reason, details
        """
        request_id = event.get("request_id")
        operation = event.get("operation", "unknown")
        path = event.get("path", "")
        reason = event.get("reason", "")
        details = event.get("details", {})

        # Show permission modal
        modal = PermissionModal(
            request_id=request_id,
            operation=operation,
            path=path,
            reason=reason,
            details=details
        )

        await self.push_screen(modal)

    async def _handle_stream_event(self, event: dict) -> None:
        """Forward streaming event to eventbus - UI handlers will update UI."""
        event_type = event.get("type")
        data = event.get("data", {})

        # Handle permission requests
        if event_type == "permission_request":
            await self._handle_permission_request(event)
            return

        # Emit all events to eventbus (subscribed UI handlers will update UI)
        await self._emit(event_type, data)

    async def _handle_command(self, cmd: str) -> None:
        """
        Handle slash commands.

        Args:
            cmd: Command string (with leading /)
        """
        cmd = cmd.lower()

        if cmd == "/clear":
            await self._clear_all()

        elif cmd == "/help":
            self._show_help()

        elif cmd == "/stats":
            await self._show_stats()

        elif cmd == "/compact":
            await self._compact_conversation()

        elif cmd == "/summarize":
            self.notify("Summarization not yet implemented", severity="warning")

        elif cmd == "/todos":
            await self._show_todos()

        elif cmd == "/details":
            self.action_toggle_continuation_details()

        elif cmd == "/agents":
            await self._show_agents_modal()

        elif cmd == "/tasks":
            await self._show_tasks_modal()

        elif cmd == "/status":
            await self._show_status_modal()

        elif cmd == "/review":
            await self._show_review_modal()

        elif cmd == "/metrics":
            await self._show_metrics_modal()

        elif cmd == "/history":
            await self._show_history_modal()

        elif cmd == "/copy":
            self.action_copy_text()

        elif cmd == "/exit" or cmd == "/quit":
            await self.action_quit()

        else:
            self.notify(f"Unknown command: {cmd}", severity="warning")

    async def _clear_all(self) -> None:
        """Clear chat log and conversation context."""
        if not self.session_id:
            self.notify("No active session", severity="warning")
            return

        try:
            # Clear server-side conversation context
            await self.client.clear_conversation(self.session_id)

            # Clear all chat content (messages and code blocks)
            chat_container = self.query_one("#chat-container")
            for widget in list(chat_container.children):
                if widget.id != "streaming-message":
                    widget.remove()

            # Reset context counter
            self.context_used = 0
            self._update_context_counter()

            # Clear input history
            history_input = self.query_one("#user-input", HistoryInput)
            history_input.clear_history()
        except Exception as e:
            self.notify(f"Failed to clear context: {e}", severity="error")

    def action_cancel_request(self) -> None:
        """Cancel ongoing request."""
        if self.streaming_task and not self.streaming_task.done():
            self.cancel_requested = True
            self.streaming_task.cancel()
            self.notify("Cancelling request...", severity="warning")

    def action_toggle_code_block(self) -> None:
        """Toggle most recent code block expansion."""
        # Find all code blocks in the chat container
        chat_container = self.query_one("#chat-container")
        code_blocks = list(chat_container.query(CollapsibleCodeBlock))
        if code_blocks:
            # Toggle the last one (most recent)
            code_blocks[-1].toggle()

    def action_toggle_continuation_details(self) -> None:
        """Show/hide continuation tool details."""
        if not self.continuation_tools:
            self.notify("No continuation details available", severity="information")
            return

        self.show_continuation_details = not self.show_continuation_details

        if self.show_continuation_details:
            # Show all the hidden continuation tool results
            self._add_message(f"\n[cyan]═══ Continuation Details ({len(self.continuation_tools)} tools) ═══[/]")
            for i, tool_data in enumerate(self.continuation_tools, 1):
                tool_name = tool_data.get("tool", "unknown")
                success = tool_data.get("success", False)
                result = tool_data.get("result", {})

                # Show tool header
                status_icon = "✓" if success else "✗"
                self._add_message(f"[dim]{i}. {status_icon} {tool_name}[/]")

                # Show result preview (abbreviated for read_file)
                if tool_name == "read_file" and isinstance(result, dict):
                    path = result.get("path", "unknown")
                    content = result.get("content", "")
                    lines = content.split("\n")
                    preview = f"{path} ({len(lines)} lines)"
                    self._add_message(f"   [dim]{preview}[/]")
                elif tool_name == "list_directory":
                    if isinstance(result, list):
                        self._add_message(f"   [dim]Found {len(result)} items[/]")
                elif tool_name == "search_files":
                    if isinstance(result, list):
                        self._add_message(f"   [dim]Found {len(result)} matches[/]")

            self._add_message("[cyan]═══ End Details ═══[/]\n")
            self.notify("Showing continuation details", severity="information")
        else:
            self._add_message("[dim]Continuation details hidden[/]")
            self.notify("Hiding continuation details", severity="information")

    def action_copy_text(self) -> None:
        """Copy text to clipboard."""
        import pyperclip

        # Try to copy from focused widget
        focused = self.focused

        # If input field is focused, copy its content
        if isinstance(focused, Input):
            text = focused.value
            if text:
                try:
                    pyperclip.copy(text)
                    self.notify("Copied to clipboard", severity="information")
                except Exception as e:
                    self.notify(f"Failed to copy: {e}", severity="error")
            return

        # Try to find and copy the most recent code block
        chat_container = self.query_one("#chat-container")
        code_blocks = list(chat_container.query(CollapsibleCodeBlock))
        if code_blocks:
            # Get the most recent code block
            last_block = code_blocks[-1]
            # Access the code content from the block
            if hasattr(last_block, "content"):
                try:
                    pyperclip.copy(last_block.content)
                    self.notify(f"Copied {last_block.path}", severity="information")
                    return
                except Exception as e:
                    self.notify(f"Failed to copy: {e}", severity="error")
                    return

        # Fallback: copy the current assistant text
        if self.current_assistant_text:
            try:
                # Strip markdown formatting for cleaner copy
                import re
                text = re.sub(r'\[.*?\]', '', self.current_assistant_text)
                pyperclip.copy(text)
                self.notify("Text copied to clipboard", severity="information")
            except Exception as e:
                self.notify(f"Failed to copy: {e}", severity="error")
        else:
            self.notify("Nothing to copy", severity="warning")

    def action_paste_text(self) -> None:
        """Paste text from clipboard into input field."""
        import pyperclip

        try:
            # Get text from clipboard
            text = pyperclip.paste()

            if not text:
                self.notify("Clipboard is empty", severity="warning")
                return

            # Get the input field
            input_field = self.query_one("#user-input", Input)

            # Insert text at cursor position
            current = input_field.value
            cursor_pos = input_field.cursor_position

            # Insert clipboard text at cursor position
            new_value = current[:cursor_pos] + text + current[cursor_pos:]
            input_field.value = new_value

            # Move cursor to end of pasted text
            input_field.cursor_position = cursor_pos + len(text)

            # Focus the input field
            input_field.focus()

            self.notify("Pasted from clipboard", severity="information")

        except Exception as e:
            self.notify(f"Failed to paste: {e}", severity="error")

    async def action_quit(self) -> None:
        """Quit app and shutdown server if we launched it."""
        await self.launcher.shutdown()
        self.exit()

    async def _show_stats(self) -> None:
        """Show context statistics."""
        if not self.session_id:
            self.notify("No active session", severity="warning")
            return

        try:
            stats = await self.client.get_stats(self.session_id)
            self._add_message(f"""[bold yellow]Context Statistics:[/]

[cyan]Messages:[/] {stats['message_count']}
[cyan]Estimated Tokens:[/] {stats['estimated_tokens']:,}
[cyan]Max Tokens:[/] {stats['max_tokens']:,}
[cyan]Usage:[/] {stats['estimated_tokens'] / stats['max_tokens'] * 100:.1f}%
""")
        except Exception as e:
            self.notify(f"Error getting stats: {e}", severity="error")

    async def _compact_conversation(self) -> None:
        """Compact conversation history."""
        if not self.session_id:
            self.notify("No active session", severity="warning")
            return

        try:
            await self.client.compact_session(self.session_id)
            self.notify("Conversation compacted")

            # Refresh stats
            stats = await self.client.get_stats(self.session_id)
            self.context_used = stats.get("estimated_tokens", 0)
            self._update_context_counter()
        except Exception as e:
            self.notify(f"Error compacting: {e}", severity="error")

    def _show_help(self) -> None:
        """Show help message in chat."""
        self._add_message(
            """[bold yellow]Ctrl+Code Commands:[/]

[cyan]/clear[/]       - Clear chat history
[cyan]/help[/]        - Show this help message
[cyan]/stats[/]       - Show context statistics
[cyan]/compact[/]     - Compact conversation history
[cyan]/summarize[/]   - Summarize conversation (not yet implemented)
[cyan]/todos[/]       - Show todo list
[cyan]/details[/]     - Show/hide continuation exploration details
[cyan]/copy[/]        - Copy last assistant message or code block
[cyan]/exit[/]       - Exit the application
[cyan]/quit[/]       - Exit the application

[bold yellow]Multi-Agent Workflow Commands:[/]

[cyan]/agents[/]      - Show active agents
[cyan]/tasks[/]       - Show task graph
[cyan]/status[/]      - Show event bus viewer
[cyan]/review[/]      - Show review feedback
[cyan]/metrics[/]     - Show observability results
[cyan]/history[/]     - Show historical learning metrics

[bold yellow]Keyboard Shortcuts:[/]

[cyan]Ctrl+L[/]          - Clear chat
[cyan]Ctrl+Q[/]          - Quit (or type /exit or /quit)
[cyan]Escape[/]          - Cancel request
[cyan]Ctrl+E[/]          - Toggle continuation details
[cyan]Ctrl+C[/]          - Copy text/code block
[cyan]Ctrl+V[/]          - Paste from clipboard

[bold yellow]Copy/Paste:[/]

[cyan]Shift+Mouse[/]     - Select text to copy (terminal native)
[cyan]/copy[/]           - Copy last message/code block to clipboard
"""
        )

    async def _show_todos(self) -> None:
        """Show todo list modal."""
        if not self.session_id:
            self.notify("No active session", severity="warning")
            return

        try:
            # Call todo_list tool via RPC with session_id
            result = await self.client.call_tool(self.session_id, "todo_list", {
                "session_id": self.session_id
            })

            if result.get("success"):
                todos = result.get("todos", [])
                # Show modal
                await self.push_screen(TodoModal(todos))
            else:
                error = result.get("error", "Unknown error")
                self.notify(f"Failed to load todos: {error}", severity="error")
        except Exception as e:
            self.notify(f"Error loading todos: {e}", severity="error")

    async def _show_agents_modal(self) -> None:
        """Show agents modal."""
        if not self.multi_agent_mode or not self.agents_data:
            self.notify("No agents active (not in multi-agent mode)", severity="info")
            return

        await self.push_screen(AgentsModal(self.agents_data))

    async def _show_tasks_modal(self) -> None:
        """Show task graph modal."""
        if not self.task_graph:
            self.notify("No task graph available", severity="info")
            return

        await self.push_screen(TasksModal(self.task_graph))

    async def _show_status_modal(self) -> None:
        """Show event bus viewer modal."""
        # Get event history from event bus
        history = self.events.get_history()
        # Convert Event objects to dicts
        history_dicts = [e.to_dict() if hasattr(e, 'to_dict') else e for e in history]
        await self.push_screen(StatusModal(history_dicts))

    async def _show_review_modal(self) -> None:
        """Show review feedback modal."""
        if not self.review_feedback:
            self.notify("No review feedback available", severity="info")
            return

        await self.push_screen(ReviewModal(self.review_feedback))

    async def _show_metrics_modal(self) -> None:
        """Show observability results modal."""
        if not self.metrics_data:
            self.notify("No metrics available", severity="info")
            return

        await self.push_screen(MetricsModal(self.metrics_data))

    async def _show_history_modal(self) -> None:
        """Show historical learning metrics modal."""
        # Fetch latest history metrics from server
        try:
            history_data = await self.client.get_history_metrics()
            if not history_data or history_data.get("total_sessions", 0) == 0:
                self.notify("No fuzzing sessions recorded yet", severity="info")
                return

            await self.push_screen(HistoryModal(history_data))
        except Exception as e:
            self.notify(f"Failed to fetch history metrics: {e}", severity="error")


def main():
    """Entry point for TUI."""
    import argparse
    parser = argparse.ArgumentParser(description="ctrl+code TUI")
    parser.add_argument(
        "--server",
        default="http://127.0.0.1:8765",
        help="Server URL (default: http://127.0.0.1:8765)"
    )
    args = parser.parse_args()

    app = CtrlCodeTUI(server_url=args.server)
    app.run()


if __name__ == "__main__":
    main()
