"""
Simplified TUI App - Example Implementation

This shows the core structure of the refactored app.py:
- Clean 3-widget layout (status + chat + input)
- On-demand modals via slash commands
- Keyboard shortcuts
- Inline workflow events in chat
"""

import time
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.message import Message

from .widgets.status_line import StatusLine
from .widgets.chat_log import ChatLog
from .widgets.input_box import InputBox
from .widgets.modals import (
    AgentsModal,
    TasksModal,
    StatusModal,
    ReviewModal,
    MetricsModal,
)


class SlashCommand(Message):
    """Message posted when user enters a slash command."""

    def __init__(self, command: str):
        super().__init__()
        self.command = command


class CtrlCodeApp(App):
    """
    Simplified TUI - chat-first with on-demand modals.

    Layout:
        ┌─────────────────────────────────────┐
        │ Status Line (1 line)                │
        ├─────────────────────────────────────┤
        │ Chat Log (main area)                │
        │                                     │
        │ Workflow events appear inline       │
        ├─────────────────────────────────────┤
        │ Input Box (3 lines)                 │
        └─────────────────────────────────────┘

    Modals (on-demand):
        /agents  or Ctrl+A  → Show agents
        /tasks   or Ctrl+T  → Show task graph
        /status  or Ctrl+S  → Show event bus
        /review  or Ctrl+R  → Show review feedback
        /metrics or Ctrl+M  → Show metrics
    """

    CSS = """
    StatusLine {
        dock: top;
        height: 1;
    }

    ChatLog {
        height: 1fr;
    }

    InputBox {
        dock: bottom;
        height: 3;
    }
    """

    BINDINGS = [
        Binding("ctrl+a", "show_agents", "Agents"),
        Binding("ctrl+t", "show_tasks", "Tasks"),
        Binding("ctrl+s", "show_status", "Status"),
        Binding("ctrl+r", "show_review", "Review"),
        Binding("ctrl+m", "show_metrics", "Metrics"),
        Binding("ctrl+c", "quit", "Quit"),
    ]

    def __init__(self):
        super().__init__()

        # Workflow state
        self.workflow_active = False
        self.agents_data = []
        self.task_graph = {}
        self.event_history = []
        self.review_feedback = []
        self.metrics_data = {}

    def compose(self) -> ComposeResult:
        """Minimal layout: status + chat + input."""
        yield StatusLine()
        yield ChatLog()
        yield InputBox()

    # ========================================
    # Modal Actions (Ctrl+X or /command)
    # ========================================

    def action_show_agents(self):
        """Show agents modal (Ctrl+A or /agents)."""
        if self.workflow_active and self.agents_data:
            self.mount(AgentsModal(self.agents_data))
        else:
            self._show_info("No agents active")

    def action_show_tasks(self):
        """Show tasks modal (Ctrl+T or /tasks)."""
        if self.task_graph:
            self.mount(TasksModal(self.task_graph))
        else:
            self._show_info("No task graph available")

    def action_show_status(self):
        """Show status modal (Ctrl+S or /status)."""
        self.mount(StatusModal(self.event_history))

    def action_show_review(self):
        """Show review modal (Ctrl+R or /review)."""
        if self.review_feedback:
            self.mount(ReviewModal(self.review_feedback))
        else:
            self._show_info("No review feedback")

    def action_show_metrics(self):
        """Show metrics modal (Ctrl+M or /metrics)."""
        if self.metrics_data:
            self.mount(MetricsModal(self.metrics_data))
        else:
            self._show_info("No metrics available")

    # ========================================
    # Slash Command Handling
    # ========================================

    def on_slash_command(self, message: SlashCommand):
        """Handle slash commands from input."""
        command = message.command.lower()

        # View commands (open modals)
        if command == "agents":
            self.action_show_agents()
        elif command == "tasks":
            self.action_show_tasks()
        elif command == "status":
            self.action_show_status()
        elif command == "review":
            self.action_show_review()
        elif command == "metrics":
            self.action_show_metrics()

        # Action commands
        elif command == "clear":
            self.query_one(ChatLog).clear()
        elif command == "help":
            self._show_help()

        # Unknown command
        else:
            self._show_info(f"Unknown command: /{command}. Type /help for commands.")

    def _show_help(self):
        """Show help message in chat."""
        help_text = """
Available commands:
  /agents   - Show active agents
  /tasks    - Show task graph
  /status   - Show event bus
  /review   - Show review feedback
  /metrics  - Show observability results
  /clear    - Clear chat
  /help     - Show this help

Keyboard shortcuts:
  Ctrl+A    - Show agents
  Ctrl+T    - Show tasks
  Ctrl+S    - Show status
  Ctrl+R    - Show review
  Ctrl+M    - Show metrics
  Ctrl+C    - Quit
        """
        chat_log = self.query_one(ChatLog)
        chat_log.add_message("system", help_text.strip())

    def _show_info(self, message: str):
        """Show info message in chat."""
        chat_log = self.query_one(ChatLog)
        chat_log.add_message("system", message)

    # ========================================
    # Workflow Event Handlers
    # ========================================

    async def on_workflow_phase_change(self, event):
        """Handle workflow phase change."""
        phase = event.data["phase"]
        progress = event.data["progress"]
        active_agents = event.data.get("active_agents", 0)

        # Update status line
        status_line = self.query_one(StatusLine)
        status_line.set_workflow(phase, progress, active_agents)

        # Add inline event to chat
        chat_log = self.query_one(ChatLog)
        chat_log.add_workflow_event(
            "phase_change",
            f"Phase: {phase} ({progress:.0%})",
            "📝"
        )

        # Store in event history
        self._add_to_event_history("workflow_phase_change", event.data)

    async def on_workflow_agent_spawned(self, event):
        """Handle agent spawned."""
        agent_id = event.data["agent_id"]
        agent_type = event.data["type"]
        task = event.data.get("task", "")

        # Track agent
        self.agents_data.append({
            "id": agent_id,
            "type": agent_type,
            "status": "active",
            "progress": 0.0,
            "task": task,
        })

        # Add inline event to chat
        chat_log = self.query_one(ChatLog)
        chat_log.add_workflow_event(
            "agent_spawned",
            f"{agent_type.capitalize()} spawned",
            "🔵"
        )

        # Store in event history
        self._add_to_event_history("workflow_agent_spawned", event.data)

    async def on_workflow_agent_updated(self, event):
        """Handle agent status update."""
        agent_id = event.data["agent_id"]
        status = event.data.get("status")
        progress = event.data.get("progress", 0.0)

        # Update agent data
        for agent in self.agents_data:
            if agent["id"] == agent_id:
                if status:
                    agent["status"] = status
                agent["progress"] = progress
                break

        # Add inline event to chat (only if significant progress)
        if progress > 0 and progress % 0.25 < 0.01:  # Every 25%
            chat_log = self.query_one(ChatLog)
            chat_log.add_workflow_event(
                "agent_progress",
                f"{agent_id} ({progress:.0%})",
                "⏳"
            )

        # Store in event history
        self._add_to_event_history("workflow_agent_updated", event.data)

    async def on_workflow_task_graph_created(self, event):
        """Handle task graph creation."""
        self.task_graph = event.data["task_graph"]

        num_tasks = len(self.task_graph.get("tasks", []))

        # Add inline event to chat
        chat_log = self.query_one(ChatLog)
        chat_log.add_workflow_event(
            "task_graph_created",
            f"Task graph: {num_tasks} tasks",
            "📋"
        )

        # Store in event history
        self._add_to_event_history("workflow_task_graph_created", event.data)

    async def on_workflow_review_feedback(self, event):
        """Handle review feedback."""
        feedback = event.data["feedback"]
        self.review_feedback.extend(feedback)

        # Count by severity
        blockers = sum(1 for f in feedback if f.get("severity") == "blocker")

        # Add inline event to chat
        icon = "🔴" if blockers > 0 else "🟡"
        chat_log = self.query_one(ChatLog)
        chat_log.add_workflow_event(
            "review_feedback",
            f"Review: {len(feedback)} issues ({blockers} blockers)",
            icon
        )

        # Store in event history
        self._add_to_event_history("workflow_review_feedback", event.data)

    async def on_workflow_observability_results(self, event):
        """Handle observability results."""
        self.metrics_data = event.data["results"]

        # Add inline event to chat
        recommendation = self.metrics_data.get("recommendation", "").upper()
        icon = "✅" if recommendation == "APPROVE" else "❌"

        chat_log = self.query_one(ChatLog)
        chat_log.add_workflow_event(
            "observability_results",
            f"Validation: {recommendation}",
            icon
        )

        # Store in event history
        self._add_to_event_history("workflow_observability_results", event.data)

    # ========================================
    # Helpers
    # ========================================

    def _add_to_event_history(self, event_type: str, data: dict):
        """Add event to history for bus viewer."""
        self.event_history.append({
            "timestamp": time.time(),
            "type": event_type,
            "data": data,
        })

        # Update status modal if open
        try:
            status_modal = self.query_one(StatusModal)
            status_modal.add_event(self.event_history[-1])
        except:
            pass  # Modal not open, that's fine
