def main():
    print("Hello from ctrlcode!")


if __name__ == "__main__":
    main()
