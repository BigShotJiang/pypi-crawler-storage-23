# Multi-Agent TUI Integration Plan

**Status:** Planning
**Started:** 2026-02-13
**Owner:** Core Team

---

## Overview

Integrate multi-agent orchestration system with TUI to provide real-time visibility into agent workflows, parallel execution, and review feedback loops.

**Goal:** Users see what agents are doing, understand task decomposition, and track progress through multi-agent workflows.

---

## Current TUI State

**Location:** `tui/ctrlcode_tui/`

**Main components:**
- `app.py` - Main Textual app
- `widgets/chat_log.py` - Conversation display
- `widgets/todo_modal.py` - Todo list modal
- `widgets/input_box.py` - User input

**Current behavior:**
- Single-agent conversation view
- Messages appear sequentially
- Tool calls shown inline
- No visibility into agent orchestration

---

## Requirements

### 1. Workflow Status Display

**What:** Top-level status bar showing current workflow phase

**Display:**
```
┌─────────────────────────────────────────┐
│ Workflow: Planning ▸ Execution ▸ Review │
│          [████████░░░░░░░░░░░░] 35%     │
└─────────────────────────────────────────┘
```

**States:**
- Planning (Planner agent active)
- Execution (Coder agents active)
- Review (Reviewer agent active)
- Validation (Executor agent active)
- Complete (All done)

### 2. Agent Activity Panel

**What:** Side panel showing active agents and their status

**Display:**
```
╔══════════════════════╗
║ Active Agents        ║
╠══════════════════════╣
║ ✓ Planner           ║
║   └─ 5 tasks created║
║                      ║
║ ⏳ Coder #1          ║
║   └─ task-2 (60%)   ║
║                      ║
║ ⏳ Coder #2          ║
║   └─ task-3 (45%)   ║
║                      ║
║ ⏸  Reviewer         ║
║   └─ waiting...     ║
╚══════════════════════╝
```

**Info per agent:**
- Agent type (icon + name)
- Current task
- Progress indicator
- Status (active, waiting, complete, error)

### 3. Task Graph Visualization

**What:** Expandable view of planner's task breakdown

**Display:**
```
┌─ Task Graph ────────────────────────┐
│ ✓ task-1: Read auth implementation  │
│ │                                    │
│ ├─⏳ task-2: Add JWT utility funcs   │
│ │  └─ Depends on: task-1            │
│ │                                    │
│ ├─⏳ task-3: Update user model       │
│ │  └─ Depends on: task-1            │
│ │  └─ Parallel with: task-2         │
│ │                                    │
│ └─⏸ task-4: Integration tests       │
│    └─ Depends on: task-2, task-3    │
└─────────────────────────────────────┘
```

**Features:**
- Dependency arrows
- Parallel group indicators
- Real-time status updates
- Expandable/collapsible

### 4. Review Feedback Display

**What:** Inline display of reviewer feedback with severity

**Display:**
```
╔════════════════════════════════════════╗
║ 🔍 Review Feedback                     ║
╠════════════════════════════════════════╣
║ 🔴 BLOCKER                             ║
║ File: src/api/routes.py:47             ║
║ Password stored in plaintext           ║
║                                        ║
║ Fix: Use bcrypt.hashpw()               ║
║ Status: ⏳ Coder addressing...         ║
╠════════════════════════════════════════╣
║ 🟡 ERROR                               ║
║ File: tests/test_login.py:15           ║
║ Missing test for invalid credentials   ║
║                                        ║
║ Fix: Add test_login_invalid()          ║
║ Status: ✓ Fixed                        ║
╚════════════════════════════════════════╝
```

**Features:**
- Severity color coding (🔴 blocker, 🟡 error, 🟢 info)
- File/line references
- Fix suggestions
- Re-execution status tracking

### 5. Parallel Execution Indicator

**What:** Show multiple agents working concurrently

**Display:**
```
┌─ Parallel Execution ─────────────────┐
│ Running 3 tasks in parallel:         │
│                                      │
│ [████████████████░░░░] task-2 (80%) │
│ [██████████░░░░░░░░░░] task-3 (50%) │
│ [████░░░░░░░░░░░░░░░░] task-4 (20%) │
└──────────────────────────────────────┘
```

**Features:**
- Progress bars per parallel task
- Task IDs/descriptions
- Completion percentage

### 6. Observability Results Display

**What:** Show executor agent's runtime validation results

**Display:**
```
╔════════════════════════════════════╗
║ ✓ Validation Results               ║
╠════════════════════════════════════╣
║ Tests: 5 passed, 0 failed          ║
║ Duration: 0.3s                     ║
║                                    ║
║ Performance:                       ║
║   p50: 145ms ✓                     ║
║   p99: 201ms ⚠ (threshold: 200ms)  ║
║                                    ║
║ Logs: 0 errors, 2 warnings         ║
║                                    ║
║ Recommendation: Approve            ║
╚════════════════════════════════════╝
```

**Features:**
- Test results summary
- Performance metrics with thresholds
- Log health
- Final recommendation

---

## New TUI Components

### 1. WorkflowStatusBar

**File:** `tui/ctrlcode_tui/widgets/workflow_status.py`

**Responsibilities:**
- Display current workflow phase
- Show overall progress percentage
- Update in real-time as workflow progresses

**API:**
```python
class WorkflowStatusBar(Static):
    def set_phase(self, phase: str):
        """Update current phase (planning, execution, review, validation)."""

    def set_progress(self, completed: int, total: int):
        """Update progress bar."""

    def set_status(self, status: str):
        """Set status text (e.g., "Planning task decomposition...")."""
```

### 2. AgentActivityPanel

**File:** `tui/ctrlcode_tui/widgets/agent_panel.py`

**Responsibilities:**
- List active agents
- Show per-agent status and current task
- Update dynamically as agents spawn/complete

**API:**
```python
class AgentActivityPanel(Static):
    def add_agent(self, agent_id: str, agent_type: str):
        """Add agent to active list."""

    def update_agent(self, agent_id: str, status: str, task: str, progress: float):
        """Update agent status and progress."""

    def remove_agent(self, agent_id: str):
        """Remove completed agent from list."""
```

### 3. TaskGraphWidget

**File:** `tui/ctrlcode_tui/widgets/task_graph.py`

**Responsibilities:**
- Render task graph as tree structure
- Show dependencies and parallel groups
- Update task status in real-time

**API:**
```python
class TaskGraphWidget(Static):
    def set_task_graph(self, task_graph: dict):
        """Set full task graph from planner."""

    def update_task_status(self, task_id: str, status: str):
        """Update individual task status (pending, in_progress, complete, error)."""

    def expand_task(self, task_id: str):
        """Expand task details."""

    def collapse_task(self, task_id: str):
        """Collapse task details."""
```

### 4. ReviewFeedbackWidget

**File:** `tui/ctrlcode_tui/widgets/review_feedback.py`

**Responsibilities:**
- Display reviewer feedback items
- Color-code by severity
- Track fix status

**API:**
```python
class ReviewFeedbackWidget(Static):
    def add_feedback(self, feedback: dict):
        """Add feedback item (file, line, severity, message, suggestion)."""

    def update_feedback_status(self, feedback_id: str, status: str):
        """Update fix status (pending, in_progress, fixed)."""

    def clear_feedback(self):
        """Clear all feedback items."""
```

### 5. ParallelExecutionWidget

**File:** `tui/ctrlcode_tui/widgets/parallel_execution.py`

**Responsibilities:**
- Show progress bars for parallel tasks
- Update in real-time

**API:**
```python
class ParallelExecutionWidget(Static):
    def set_tasks(self, task_ids: list[str]):
        """Initialize progress bars for parallel tasks."""

    def update_task_progress(self, task_id: str, progress: float):
        """Update task progress (0.0 to 1.0)."""

    def complete_task(self, task_id: str):
        """Mark task as complete."""
```

### 6. ObservabilityResultsWidget

**File:** `tui/ctrlcode_tui/widgets/observability_results.py`

**Responsibilities:**
- Display validation results from executor
- Show metrics with pass/fail indicators

**API:**
```python
class ObservabilityResultsWidget(Static):
    def set_test_results(self, results: dict):
        """Display test execution results."""

    def set_performance_metrics(self, metrics: dict, threshold: float):
        """Display performance metrics with threshold comparison."""

    def set_log_analysis(self, analysis: dict):
        """Display log health summary."""

    def set_recommendation(self, recommendation: str):
        """Display final recommendation."""
```

---

## Layout Design

### Proposed Layout

```
┌─────────────────────────────────────────────────────────────────┐
│ Workflow: Planning ▸ Execution ▸ Review ▸ Validation  [40%]    │ WorkflowStatusBar
├─────────────────────────┬───────────────────────────────────────┤
│ ╔═════════════════════╗ │                                       │
│ ║ Active Agents       ║ │  Chat Log / Conversation             │
│ ╠═════════════════════╣ │  (existing chat_log.py)              │
│ ║ ✓ Planner          ║ │                                       │
│ ║ ⏳ Coder #1         ║ │  Messages from agents appear here    │
│ ║ ⏳ Coder #2         ║ │                                       │
│ ║ ⏸  Reviewer        ║ │                                       │
│ ╚═════════════════════╝ │                                       │
│                         │                                       │
│ AgentActivityPanel      │                                       │
│                         ├───────────────────────────────────────┤
│                         │ Task Graph (expandable)               │
│                         │ ✓ task-1                              │
│                         │ ├─⏳ task-2                           │
│                         │ └─⏳ task-3                           │
│                         │                                       │
│                         │ TaskGraphWidget                       │
├─────────────────────────┴───────────────────────────────────────┤
│ > User input here                                               │ InputBox
└─────────────────────────────────────────────────────────────────┘
```

**Key:**
- Left panel: Agent activity (collapsible)
- Center: Chat log + expandable task graph
- Bottom: User input
- Top: Workflow status bar

---

## Integration Points

### 1. Server ↔ TUI Communication

**Current:** RPC calls for chat, tool execution

**Additions needed:**

```python
# New RPC methods in server.py

async def handle_workflow_update(self, session_id: str, update: dict):
    """
    Send workflow update to TUI.

    Update types:
    - "phase_change": {"phase": "execution", "progress": 0.4}
    - "agent_spawned": {"agent_id": "coder-1", "type": "coder", "task": {...}}
    - "agent_updated": {"agent_id": "coder-1", "status": "in_progress", "progress": 0.6}
    - "agent_completed": {"agent_id": "coder-1", "result": {...}}
    - "task_graph_created": {"task_graph": {...}}
    - "task_updated": {"task_id": "task-2", "status": "complete"}
    - "review_feedback": {"feedback": [...]}
    - "observability_results": {"results": {...}}
    """
    # Send to TUI via existing message channel
```

### 2. WorkflowOrchestrator Hooks

**Modify:** `src/ctrlcode/agents/workflow.py`

**Add hooks at key points:**

```python
class MultiAgentWorkflow:
    def __init__(self, coordinator, tui_callback=None):
        self.coordinator = coordinator
        self.tui_callback = tui_callback  # Callback to send updates to TUI

    async def _planning_phase(self, user_intent: str):
        # Send phase change
        if self.tui_callback:
            await self.tui_callback({
                "type": "phase_change",
                "phase": "planning",
                "progress": 0.0
            })

        planner_result = await self.coordinator.spawn_agent(...)

        # Send task graph
        if self.tui_callback:
            await self.tui_callback({
                "type": "task_graph_created",
                "task_graph": task_graph_data
            })

        return task_graph

    async def _execution_phase(self, task_graph):
        # Send phase change
        if self.tui_callback:
            await self.tui_callback({
                "type": "phase_change",
                "phase": "execution",
                "progress": 0.25
            })

        # Track agent spawning
        # Send updates per agent
        ...
```

### 3. App.py Integration

**Modify:** `tui/ctrlcode_tui/app.py`

**Add:**

```python
from .widgets.workflow_status import WorkflowStatusBar
from .widgets.agent_panel import AgentActivityPanel
from .widgets.task_graph import TaskGraphWidget
from .widgets.review_feedback import ReviewFeedbackWidget

class CtrlCodeApp(App):
    def compose(self):
        yield WorkflowStatusBar()
        yield AgentActivityPanel()
        yield ChatLog()
        yield TaskGraphWidget()
        yield InputBox()

    async def on_workflow_update(self, update: dict):
        """Handle workflow updates from server."""
        update_type = update["type"]

        if update_type == "phase_change":
            self.query_one(WorkflowStatusBar).set_phase(update["phase"])
            self.query_one(WorkflowStatusBar).set_progress(update["progress"])

        elif update_type == "agent_spawned":
            self.query_one(AgentActivityPanel).add_agent(
                update["agent_id"],
                update["type"]
            )

        elif update_type == "task_graph_created":
            self.query_one(TaskGraphWidget).set_task_graph(update["task_graph"])

        # ... handle other update types
```

---

## Implementation Plan

### Step 1: Create Widget Skeletons

**Create files:**
- `tui/ctrlcode_tui/widgets/workflow_status.py`
- `tui/ctrlcode_tui/widgets/agent_panel.py`
- `tui/ctrlcode_tui/widgets/task_graph.py`
- `tui/ctrlcode_tui/widgets/review_feedback.py`
- `tui/ctrlcode_tui/widgets/parallel_execution.py`
- `tui/ctrlcode_tui/widgets/observability_results.py`

**Implement basic rendering** (no data, just UI structure)

### Step 2: Add RPC Communication

**Server-side:**
- Add `handle_workflow_update()` method
- Add message type for workflow updates
- Wire into existing RPC system

**TUI-side:**
- Add `on_workflow_update()` handler
- Subscribe to workflow update messages
- Route updates to appropriate widgets

### Step 3: Instrument WorkflowOrchestrator

**Add callbacks at:**
- Phase transitions
- Agent spawning
- Agent status changes
- Task graph creation
- Task status updates
- Review feedback generation
- Observability results

**Send updates via tui_callback**

### Step 4: Wire Widgets to Data

**Update widget implementations:**
- Handle data updates (set_task_graph, update_agent, etc.)
- Render data dynamically
- Add interactivity (expand/collapse, filtering)

### Step 5: Layout Integration

**Update app.py:**
- Add new widgets to layout
- Configure grid/container structure
- Handle responsive resizing
- Add keyboard shortcuts for panel toggling

### Step 6: Testing

**Test scenarios:**
- Simple task (single agent)
- Medium task (3 tasks, sequential)
- Complex task (parallel execution)
- Review feedback loop
- Error handling (agent failure)

### Step 7: Polish

**Add:**
- Animations (phase transitions, progress bars)
- Color coding (success green, error red, warning yellow)
- Keyboard shortcuts (`t` = toggle task graph, `a` = toggle agent panel)
- Help text / tooltips

---

## Technical Considerations

### State Management

**Challenge:** TUI state vs server state synchronization

**Solution:**
- Server is source of truth
- TUI updates reactively based on server messages
- No TUI state mutations, only renders

### Performance

**Challenge:** High-frequency updates during parallel execution

**Solution:**
- Debounce updates (max 10 updates/sec)
- Batch updates where possible
- Use Textual's reactive system efficiently

### Error Handling

**Challenge:** Agent failures, network issues

**Solution:**
- Show error states in AgentActivityPanel (🔴 agent-id: error)
- Display error details in chat log
- Allow user to retry or cancel workflow

### Backwards Compatibility

**Challenge:** Single-agent mode should still work

**Solution:**
- Detect workflow type (simple vs multi-agent)
- Hide multi-agent widgets if single-agent mode
- Graceful degradation

---

## Success Criteria

1. **Visibility:** User can see all active agents and their current tasks
2. **Progress:** User understands workflow phase and overall progress
3. **Task Graph:** User can inspect planner's task breakdown
4. **Feedback:** Review feedback is clearly displayed with severity
5. **Parallel:** User sees multiple agents working concurrently
6. **Results:** Observability results are human-readable
7. **Performance:** UI updates smoothly, no lag during parallel execution
8. **UX:** Intuitive keyboard shortcuts and collapsible panels

---

## Open Questions

1. **Modal vs inline?** Task graph as modal or inline in chat log?
   - **Recommendation:** Inline, expandable section (less disruptive)

2. **Agent conversation visibility?** Show individual agent reasoning?
   - **Recommendation:** Collapsed by default, expandable per agent

3. **Notification system?** Alert user when review feedback appears?
   - **Recommendation:** Yes, visual indicator + optional sound

4. **Historical workflows?** Save/replay past multi-agent workflows?
   - **Recommendation:** Future enhancement, not v1

5. **Manual control?** Allow user to pause/resume workflow?
   - **Recommendation:** Future enhancement, not v1

---

## Future Enhancements

**Post-v1:**
- Workflow history viewer
- Agent conversation inspection (expand agent to see its full ReAct loop)
- Manual workflow control (pause, resume, cancel)
- Task graph editing (modify plan before execution)
- Agent performance metrics (tokens used, time taken per agent)
- Export workflow report (markdown summary of multi-agent execution)

---

## References

- `docs/WORLD_CLASS_AGENT_PROPOSAL.md` - Multi-agent architecture design
- `docs/active-plans/multi-agent-architecture.md` - Implementation status
- `tui/ctrlcode_tui/app.py` - Current TUI implementation
- `src/ctrlcode/agents/workflow.py` - Workflow orchestration
- Textual docs: https://textual.textualize.io/

---

**Next Steps:**

1. Review this plan
2. Start with Step 1 (create widget skeletons)
3. Test incrementally
4. Iterate based on user feedback
