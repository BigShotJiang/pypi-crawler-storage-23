# Simplified TUI Redesign

**Date:** 2026-02-14
**Status:** Planning
**Replaces:** multi-agent-tui-integration.md (too complex)

---

## Philosophy

**Keep it simple:** Chat-first interface with on-demand modals. No permanent panels cluttering the view.

**Slash commands:** Activate behaviors and open modals via `/command` syntax.

**Bus visibility:** Single status view shows all events flowing through the system.

---

## New Architecture

### Core Layout

```
┌─────────────────────────────────────────┐
│ Status: Workflow Running [Planning]     │ <- StatusLine widget
├─────────────────────────────────────────┤
│                                         │
│  Chat / Conversation                    │ <- ChatLog widget
│                                         │
│  Workflow events appear inline:         │
│  🔵 Planner spawned                     │
│  ⏳ Coder #1 working (60%)              │
│  ✅ Reviewer approved                   │
│                                         │
├─────────────────────────────────────────┤
│ > /command or message                   │ <- InputBox widget
└─────────────────────────────────────────┘
```

**Only 3 widgets always visible:**
1. StatusLine (top)
2. ChatLog (center)
3. InputBox (bottom)

### Modal System

Modals open on-demand via slash commands or keyboard shortcuts.

**Available modals:**
- `/agents` or `Ctrl+A` → Agents modal
- `/tasks` or `Ctrl+T` → Task graph modal
- `/status` or `Ctrl+S` → Bus viewer modal
- `/review` or `Ctrl+R` → Review feedback modal
- `/metrics` or `Ctrl+M` → Observability modal
- `/workflow` or `Ctrl+W` → Workflow progress modal

All modals:
- Press `ESC` to close
- Overlay on top of chat
- Show live-updating data
- Can be scrolled if content exceeds screen

---

## Slash Commands

### Input Parsing

When user types `/command`:
1. InputBox detects leading `/`
2. Parse command name
3. Route to appropriate handler
4. Open corresponding modal or execute action

### Command List

**View commands (open modals):**
- `/agents` - Show all agents (active, waiting, completed)
- `/tasks` - Show task graph with dependencies
- `/status` - Show event bus stream
- `/review` - Show reviewer feedback
- `/metrics` - Show observability results
- `/workflow` - Show workflow progress overview

**Action commands:**
- `/clear` - Clear chat history
- `/help` - Show command reference
- `/debug` - Toggle debug mode (verbose events)

**Future commands:**
- `/pause` - Pause workflow execution
- `/resume` - Resume paused workflow
- `/cancel` - Cancel workflow
- `/retry <task-id>` - Retry failed task

---

## Widget Specifications

### 1. StatusLine

**File:** `tui/ctrlcode_tui/widgets/status_line.py`

**Purpose:** Single-line status at top showing current state

**Display modes:**

```python
# Idle
"Ready"

# Single-agent mode
"Thinking..." | "Running tool: read_file" | "Complete"

# Multi-agent workflow
"Workflow: Planning [25%]"
"Workflow: Execution [60%] - 2 agents active"
"Workflow: Review [80%]"
"Workflow: Complete ✓"

# Error state
"Error: Task failed - /status for details"
```

**API:**
```python
class StatusLine(Static):
    def set_idle(self):
        """Reset to idle state."""

    def set_single_agent(self, status: str):
        """Set status for single-agent mode."""

    def set_workflow(self, phase: str, progress: float, active_agents: int = 0):
        """Set status for workflow mode."""

    def set_error(self, message: str):
        """Show error state."""
```

### 2. ChatLog (Enhanced)

**File:** `tui/ctrlcode_tui/widgets/chat_log.py` (modify existing)

**Additions:**

**Inline workflow events:**
```python
def add_workflow_event(self, event_type: str, details: str, icon: str):
    """
    Add workflow event inline in chat.

    Examples:
    - add_workflow_event("agent_spawned", "Planner", "🔵")
    - add_workflow_event("task_complete", "task-2: Add JWT utils", "✅")
    - add_workflow_event("review_issue", "Security issue found", "🔴")
    """
```

**Event formatting:**
```
[14:32:01] 🔵 Agent spawned: Planner
[14:32:05] 📝 Task graph created: 5 tasks
[14:32:10] ⏳ Coder #1 working on task-2 (60%)
[14:32:15] ✅ Task complete: task-2
[14:32:20] 🔍 Reviewer checking...
[14:32:25] 🔴 Review issue: Password not hashed (blocker)
[14:32:30] ⏳ Coder #1 fixing issue...
[14:32:35] ✅ Issue resolved
[14:32:40] 🎉 Workflow complete
```

**Icons:**
- 🔵 Agent spawned
- ⏳ In progress
- ✅ Success/complete
- 🔴 Error/blocker
- 🟡 Warning
- 🔍 Review
- 📝 Planning
- 🎉 Complete
- ⚡ Running tool
- 💬 User message
- 🤖 Agent message

### 3. InputBox (Enhanced)

**File:** `tui/ctrlcode_tui/widgets/input_box.py` (modify existing)

**Slash command detection:**
```python
def on_key(self, event: events.Key):
    """Detect slash commands as user types."""
    if self.value.startswith('/'):
        # Show autocomplete suggestions
        self._show_command_suggestions()

    if event.key == "enter" and self.value.startswith('/'):
        command = self.value[1:].strip()
        self.post_message(SlashCommand(command))
        self.clear()
```

**Autocomplete for slash commands:**
```
> /ag
  ┌─────────────────────────┐
  │ /agents - Show agents   │
  │ /help - Show help       │
  └─────────────────────────┘
```

### 4. Modal Base Class

**File:** `tui/ctrlcode_tui/widgets/modal_base.py`

**Purpose:** Base class for all modals

```python
from textual.widgets import Static
from textual.containers import Container

class ModalBase(Container):
    """Base class for modal overlays."""

    DEFAULT_CSS = """
    ModalBase {
        width: 80%;
        height: 80%;
        border: thick $primary;
        background: $surface;
        layer: overlay;
    }
    """

    def on_key(self, event: events.Key):
        """Close modal on ESC."""
        if event.key == "escape":
            self.remove()

    def compose(self):
        """Override in subclasses."""
        yield Static("Modal content")
```

### 5. Modals

#### AgentsModal

**File:** `tui/ctrlcode_tui/widgets/modals/agents_modal.py`

```python
class AgentsModal(ModalBase):
    """Show all agents and their status."""

    def __init__(self, agents_data: list[dict]):
        super().__init__()
        self.agents = agents_data

    def compose(self):
        yield Static("Active Agents", classes="modal-title")
        for agent in self.agents:
            yield AgentRow(agent)  # Shows icon, name, status, progress
```

**Display:**
```
╔══════════════════════════════════════╗
║ Active Agents                        ║
╠══════════════════════════════════════╣
║ ✓ Planner          [Complete]       ║
║   Created 5 tasks                    ║
║                                      ║
║ ⏳ Coder #1        [In Progress 60%] ║
║   task-2: Add JWT utils              ║
║   [████████████░░░░░░░░░░] 60%       ║
║                                      ║
║ ⏸ Reviewer        [Waiting]          ║
║   Pending task completion            ║
╚══════════════════════════════════════╝
Press ESC to close
```

#### TasksModal

**File:** `tui/ctrlcode_tui/widgets/modals/tasks_modal.py`

```python
class TasksModal(ModalBase):
    """Show task graph with dependencies."""

    def __init__(self, task_graph: dict):
        super().__init__()
        self.graph = task_graph

    def compose(self):
        yield Static("Task Graph", classes="modal-title")
        yield TaskTree(self.graph)  # Tree widget showing deps
```

**Display:**
```
╔══════════════════════════════════════╗
║ Task Graph                           ║
╠══════════════════════════════════════╣
║ ✓ task-1: Read auth implementation   ║
║ │                                    ║
║ ├─⏳ task-2: Add JWT utils [60%]     ║
║ │  └─ Depends on: task-1            ║
║ │  └─ Assigned: Coder #1            ║
║ │                                    ║
║ ├─⏸ task-3: Update user model        ║
║ │  └─ Depends on: task-1            ║
║ │  └─ Parallel with: task-2         ║
║ │                                    ║
║ └─⏸ task-4: Integration tests        ║
║    └─ Depends on: task-2, task-3    ║
╚══════════════════════════════════════╝
Press ESC to close
```

#### StatusModal (Bus Viewer)

**File:** `tui/ctrlcode_tui/widgets/modals/status_modal.py`

```python
class StatusModal(ModalBase):
    """Event bus viewer - shows all events in real-time."""

    def __init__(self, event_history: list[dict]):
        super().__init__()
        self.events = event_history
        self.auto_scroll = True

    def add_event(self, event: dict):
        """Add new event to stream."""
        self.events.append(event)
        if self.auto_scroll:
            self.scroll_end()

    def compose(self):
        yield Static("Event Bus Stream", classes="modal-title")
        yield EventList(self.events)  # Scrollable event list
```

**Display:**
```
╔══════════════════════════════════════╗
║ Event Bus Stream                     ║
╠══════════════════════════════════════╣
║ 14:32:01 workflow_phase_change       ║
║          phase: idle → planning      ║
║          progress: 0%                ║
║                                      ║
║ 14:32:05 workflow_agent_spawned      ║
║          agent_id: planner-1         ║
║          type: planner               ║
║                                      ║
║ 14:32:08 workflow_task_graph_created ║
║          tasks: 5                    ║
║          parallel_groups: 2          ║
║                                      ║
║ 14:32:12 workflow_agent_completed    ║
║          agent_id: planner-1         ║
║          result: success             ║
║                                      ║
║ 14:32:15 workflow_phase_change       ║
║          phase: planning → execution ║
║          progress: 25%               ║
╚══════════════════════════════════════╝
[Auto-scroll ON] Press ESC to close
```

**Features:**
- Real-time updates (events appear as they happen)
- Auto-scroll toggle (`Space` to toggle)
- Filter by event type (`f` then select type)
- Copy event JSON (`c` on selected event)
- Export to file (`e`)

#### ReviewModal

**File:** `tui/ctrlcode_tui/widgets/modals/review_modal.py`

```python
class ReviewModal(ModalBase):
    """Show reviewer feedback items."""

    def __init__(self, feedback_items: list[dict]):
        super().__init__()
        self.feedback = feedback_items

    def compose(self):
        yield Static("Review Feedback", classes="modal-title")
        for item in self.feedback:
            yield FeedbackItem(item)  # Shows severity, file, message, fix
```

**Display:**
```
╔══════════════════════════════════════╗
║ Review Feedback                      ║
╠══════════════════════════════════════╣
║ 🔴 BLOCKER                           ║
║ File: src/api/routes.py:47           ║
║ Issue: Password stored in plaintext  ║
║                                      ║
║ Recommendation:                      ║
║   Use bcrypt.hashpw() before storing ║
║                                      ║
║ Status: ✅ Fixed                     ║
║ Resolved by: Coder #1                ║
╠══════════════════════════════════════╣
║ 🟡 WARNING                           ║
║ File: tests/test_login.py:15         ║
║ Issue: Missing edge case test        ║
║                                      ║
║ Recommendation:                      ║
║   Add test_login_invalid_credentials ║
║                                      ║
║ Status: ⏳ In Progress               ║
╚══════════════════════════════════════╝
Press ESC to close
```

#### MetricsModal

**File:** `tui/ctrlcode_tui/widgets/modals/metrics_modal.py`

```python
class MetricsModal(ModalBase):
    """Show observability results."""

    def __init__(self, metrics: dict):
        super().__init__()
        self.metrics = metrics

    def compose(self):
        yield Static("Observability Results", classes="modal-title")
        yield MetricsView(self.metrics)
```

**Display:**
```
╔══════════════════════════════════════╗
║ Observability Results                ║
╠══════════════════════════════════════╣
║ Tests                                ║
║   ✅ 5 passed                        ║
║   ❌ 0 failed                        ║
║   Duration: 0.3s                     ║
║                                      ║
║ Performance                          ║
║   p50: 145ms ✅ (< 200ms)            ║
║   p95: 189ms ✅ (< 200ms)            ║
║   p99: 201ms ⚠️  (>= 200ms)          ║
║                                      ║
║ Logs                                 ║
║   Errors: 0                          ║
║   Warnings: 2                        ║
║   Info: 45                           ║
║                                      ║
║ Recommendation: ✅ APPROVE           ║
║   All checks passed                  ║
╚══════════════════════════════════════╝
Press ESC to close
```

---

## App.py Refactor

**File:** `tui/ctrlcode_tui/app.py`

### Simplified Structure

```python
from textual.app import App, ComposeResult
from textual.binding import Binding

from .widgets.status_line import StatusLine
from .widgets.chat_log import ChatLog
from .widgets.input_box import InputBox
from .widgets.modals.agents_modal import AgentsModal
from .widgets.modals.tasks_modal import TasksModal
from .widgets.modals.status_modal import StatusModal
from .widgets.modals.review_modal import ReviewModal
from .widgets.modals.metrics_modal import MetricsModal

class CtrlCodeApp(App):
    """Simplified TUI - chat-first with on-demand modals."""

    CSS = """
    StatusLine {
        dock: top;
        height: 1;
        background: $primary;
    }

    ChatLog {
        height: 1fr;
    }

    InputBox {
        dock: bottom;
        height: 3;
    }
    """

    BINDINGS = [
        Binding("ctrl+a", "show_agents", "Agents"),
        Binding("ctrl+t", "show_tasks", "Tasks"),
        Binding("ctrl+s", "show_status", "Status"),
        Binding("ctrl+r", "show_review", "Review"),
        Binding("ctrl+m", "show_metrics", "Metrics"),
        Binding("ctrl+c", "quit", "Quit"),
    ]

    def __init__(self):
        super().__init__()
        # State
        self.workflow_active = False
        self.agents_data = []
        self.task_graph = {}
        self.event_history = []
        self.review_feedback = []
        self.metrics_data = {}

    def compose(self) -> ComposeResult:
        """Minimal layout: status + chat + input."""
        yield StatusLine()
        yield ChatLog()
        yield InputBox()

    # === Modal Actions ===

    def action_show_agents(self):
        """Show agents modal (Ctrl+A or /agents)."""
        if self.workflow_active and self.agents_data:
            self.mount(AgentsModal(self.agents_data))

    def action_show_tasks(self):
        """Show tasks modal (Ctrl+T or /tasks)."""
        if self.task_graph:
            self.mount(TasksModal(self.task_graph))

    def action_show_status(self):
        """Show status modal (Ctrl+S or /status)."""
        self.mount(StatusModal(self.event_history))

    def action_show_review(self):
        """Show review modal (Ctrl+R or /review)."""
        if self.review_feedback:
            self.mount(ReviewModal(self.review_feedback))

    def action_show_metrics(self):
        """Show metrics modal (Ctrl+M or /metrics)."""
        if self.metrics_data:
            self.mount(MetricsModal(self.metrics_data))

    # === Event Handlers ===

    def on_slash_command(self, message: SlashCommand):
        """Handle slash commands from input."""
        command = message.command.lower()

        if command == "agents":
            self.action_show_agents()
        elif command == "tasks":
            self.action_show_tasks()
        elif command == "status":
            self.action_show_status()
        elif command == "review":
            self.action_show_review()
        elif command == "metrics":
            self.action_show_metrics()
        elif command == "clear":
            self.query_one(ChatLog).clear()
        elif command == "help":
            self._show_help()
        else:
            self.query_one(ChatLog).add_message(
                f"Unknown command: /{command}. Type /help for commands."
            )

    def _show_help(self):
        """Show help message in chat."""
        help_text = """
Available commands:
  /agents   - Show active agents
  /tasks    - Show task graph
  /status   - Show event bus
  /review   - Show review feedback
  /metrics  - Show observability results
  /clear    - Clear chat
  /help     - Show this help

Keyboard shortcuts:
  Ctrl+A    - Show agents
  Ctrl+T    - Show tasks
  Ctrl+S    - Show status
  Ctrl+R    - Show review
  Ctrl+M    - Show metrics
  Ctrl+C    - Quit
        """
        self.query_one(ChatLog).add_message(help_text)

    # === Workflow Event Handlers ===

    async def on_workflow_phase_change(self, event):
        """Update status line with new phase."""
        phase = event.data["phase"]
        progress = event.data["progress"]
        self.query_one(StatusLine).set_workflow(phase, progress)

        # Add to chat
        self.query_one(ChatLog).add_workflow_event(
            "phase_change",
            f"Phase: {phase} ({progress:.0%})",
            "📝"
        )

        # Add to event history
        self.event_history.append({
            "timestamp": time.time(),
            "type": "workflow_phase_change",
            "data": event.data
        })

    async def on_workflow_agent_spawned(self, event):
        """Track new agent."""
        agent_id = event.data["agent_id"]
        agent_type = event.data["type"]

        self.agents_data.append({
            "id": agent_id,
            "type": agent_type,
            "status": "active",
            "progress": 0.0,
            "task": event.data.get("task", "")
        })

        # Add to chat
        self.query_one(ChatLog).add_workflow_event(
            "agent_spawned",
            f"{agent_type.capitalize()} spawned",
            "🔵"
        )

        # Add to event history
        self.event_history.append({
            "timestamp": time.time(),
            "type": "workflow_agent_spawned",
            "data": event.data
        })

    async def on_workflow_task_graph_created(self, event):
        """Store task graph."""
        self.task_graph = event.data["task_graph"]

        num_tasks = len(self.task_graph.get("tasks", []))

        # Add to chat
        self.query_one(ChatLog).add_workflow_event(
            "task_graph_created",
            f"Task graph created: {num_tasks} tasks",
            "📋"
        )

        # Add to event history
        self.event_history.append({
            "timestamp": time.time(),
            "type": "workflow_task_graph_created",
            "data": event.data
        })

    async def on_workflow_review_feedback(self, event):
        """Store review feedback."""
        feedback = event.data["feedback"]
        self.review_feedback.extend(feedback)

        # Count by severity
        blockers = sum(1 for f in feedback if f["severity"] == "blocker")

        # Add to chat
        icon = "🔴" if blockers > 0 else "🟡"
        self.query_one(ChatLog).add_workflow_event(
            "review_feedback",
            f"Review: {len(feedback)} issues ({blockers} blockers)",
            icon
        )

        # Add to event history
        self.event_history.append({
            "timestamp": time.time(),
            "type": "workflow_review_feedback",
            "data": event.data
        })

    # ... other event handlers
```

---

## Event Flow

### Before (Complex)

```
Workflow Event
    ↓
Server emits
    ↓
TUI receives
    ↓
Route to specific widget handler
    ↓
Update widget state
    ↓
6+ widgets fighting for updates
```

### After (Simple)

```
Workflow Event
    ↓
Server emits
    ↓
TUI receives
    ↓
1. Update StatusLine (phase/progress)
2. Add inline event to ChatLog
3. Store in event_history
4. Update modal data (if applicable)
    ↓
Modals update on-demand when opened
```

---

## Implementation Steps

### Step 1: Core Refactor

- [ ] Create `StatusLine` widget
- [ ] Enhance `ChatLog` with `add_workflow_event()`
- [ ] Enhance `InputBox` with slash command detection
- [ ] Strip out all complex widgets from `app.py`
- [ ] Simplify layout to 3 widgets

### Step 2: Modal System

- [ ] Create `ModalBase` class
- [ ] Implement `AgentsModal`
- [ ] Implement `TasksModal`
- [ ] Implement `StatusModal` (bus viewer)
- [ ] Implement `ReviewModal`
- [ ] Implement `MetricsModal`

### Step 3: Slash Commands

- [ ] Add slash command parser in `InputBox`
- [ ] Add `SlashCommand` message type
- [ ] Add command routing in `app.py`
- [ ] Add autocomplete for commands
- [ ] Add `/help` command

### Step 4: Event Handling

- [ ] Refactor event handlers to update:
  - StatusLine (phase/progress)
  - ChatLog (inline events)
  - Event history (for bus viewer)
  - Modal data (agents, tasks, etc.)
- [ ] Remove individual widget update logic

### Step 5: Polish

- [ ] Add keyboard shortcuts (Ctrl+A, Ctrl+T, etc.)
- [ ] Add icons to inline events
- [ ] Add color coding
- [ ] Test modal open/close
- [ ] Test with real workflow

### Step 6: Documentation

- [ ] Update README with slash commands
- [ ] Add screenshots
- [ ] Document keyboard shortcuts
- [ ] Create quick reference guide

---

## Migration from Current TUI

### Files to Remove

```
tui/ctrlcode_tui/widgets/workflow_status.py    ❌ Delete
tui/ctrlcode_tui/widgets/agent_panel.py        ❌ Delete
tui/ctrlcode_tui/widgets/task_graph.py         ❌ Delete (move to modal)
tui/ctrlcode_tui/widgets/review_feedback.py    ❌ Delete (move to modal)
tui/ctrlcode_tui/widgets/parallel_execution.py ❌ Delete
tui/ctrlcode_tui/widgets/observability_results.py ❌ Delete (move to modal)
```

### Files to Create

```
tui/ctrlcode_tui/widgets/status_line.py        ✅ Create
tui/ctrlcode_tui/widgets/modal_base.py         ✅ Create
tui/ctrlcode_tui/widgets/modals/               ✅ Create dir
tui/ctrlcode_tui/widgets/modals/agents_modal.py     ✅ Create
tui/ctrlcode_tui/widgets/modals/tasks_modal.py      ✅ Create
tui/ctrlcode_tui/widgets/modals/status_modal.py     ✅ Create
tui/ctrlcode_tui/widgets/modals/review_modal.py     ✅ Create
tui/ctrlcode_tui/widgets/modals/metrics_modal.py    ✅ Create
```

### Files to Modify

```
tui/ctrlcode_tui/app.py           📝 Simplify layout, add modal actions
tui/ctrlcode_tui/widgets/chat_log.py   📝 Add add_workflow_event()
tui/ctrlcode_tui/widgets/input_box.py  📝 Add slash command detection
```

---

## Benefits of Simplified Design

### Before
- ❌ 6+ widgets competing for space
- ❌ Complex layout management
- ❌ Always-visible panels clutter view
- ❌ Hard to find specific info
- ❌ Overwhelming for new users

### After
- ✅ Clean chat-first interface
- ✅ Simple 3-widget layout
- ✅ On-demand detail viewing
- ✅ Discoverable slash commands
- ✅ Complete event visibility (bus viewer)
- ✅ Easy to add new modals
- ✅ Keyboard-driven workflow

---

## Future Enhancements

1. **Modal history** - Navigate between previously opened modals
2. **Custom views** - User-defined modal layouts
3. **Event filtering** - Filter bus viewer by type, severity
4. **Event export** - Export event history to JSON/CSV
5. **Modal pinning** - Pin modal to stay open
6. **Split view** - Show chat + modal side-by-side
7. **Themes** - Custom color schemes for events

---

## Success Criteria

- [ ] TUI launches with clean 3-widget layout
- [ ] Slash commands work (`/agents`, `/tasks`, etc.)
- [ ] Modals open/close with ESC
- [ ] Keyboard shortcuts work (Ctrl+A, Ctrl+T, etc.)
- [ ] Workflow events appear inline in chat
- [ ] Status line updates with phase/progress
- [ ] Bus viewer shows all events
- [ ] `/help` shows command reference

---

## References

- **Replaces:** `docs/active-plans/multi-agent-tui-integration.md`
- **Workflow:** `src/ctrlcode/agents/workflow.py`
- **Current TUI:** `tui/ctrlcode_tui/app.py`
- **Textual docs:** https://textual.textualize.io/

---

**Next:** Start with Step 1 - create StatusLine and refactor app.py layout.
