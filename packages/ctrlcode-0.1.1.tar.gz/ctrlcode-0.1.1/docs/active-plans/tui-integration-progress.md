# Multi-Agent TUI Integration - Progress Report

**Date:** 2026-02-13
**Status:** In Progress (Phase 1 Complete)

---

## What's Been Implemented

### ✅ Phase 1: TUI Widgets & Frontend (COMPLETE)

#### New Widget Files Created

All widget skeletons with basic rendering implemented:

1. **`tui/ctrlcode_tui/widgets/workflow_status.py`**
   - WorkflowStatusBar widget
   - Displays current phase (planning → execution → review → validation)
   - Progress bar with percentage
   - Status text display
   - Methods: `set_phase()`, `set_progress()`, `set_status()`

2. **`tui/ctrlcode_tui/widgets/agent_panel.py`**
   - AgentActivityPanel widget
   - Lists active agents with status icons
   - Shows current task and progress per agent
   - Methods: `add_agent()`, `update_agent()`, `remove_agent()`

3. **`tui/ctrlcode_tui/widgets/task_graph.py`**
   - TaskGraphWidget
   - Renders task graph with dependencies
   - Shows parallel groups
   - Status indicators per task
   - Methods: `set_task_graph()`, `update_task_status()`

4. **`tui/ctrlcode_tui/widgets/review_feedback.py`**
   - ReviewFeedbackWidget
   - Displays reviewer feedback with severity (🔴 blocker, 🟡 error, 🟢 info)
   - File locations and suggestions
   - Fix status tracking
   - Methods: `add_feedback()`, `update_feedback_status()`

5. **`tui/ctrlcode_tui/widgets/parallel_execution.py`**
   - ParallelExecutionWidget
   - Progress bars for parallel tasks
   - Real-time progress updates
   - Methods: `set_tasks()`, `update_task_progress()`, `complete_task()`

6. **`tui/ctrlcode_tui/widgets/observability_results.py`**
   - ObservabilityResultsWidget
   - Test results display
   - Performance metrics with threshold comparison
   - Log analysis summary
   - Final recommendation
   - Methods: `set_test_results()`, `set_performance_metrics()`, `set_log_analysis()`

#### TUI App Integration

**File:** `tui/ctrlcode_tui/app.py`

**Changes:**
- ✅ Imported all new widgets
- ✅ Added `multi_agent_mode` flag to track workflow state
- ✅ Added 10 new event handlers for workflow updates:
  - `_on_workflow_phase_change()`
  - `_on_workflow_agent_spawned()`
  - `_on_workflow_agent_updated()`
  - `_on_workflow_agent_completed()`
  - `_on_workflow_task_graph_created()`
  - `_on_workflow_task_updated()`
  - `_on_workflow_review_feedback()`
  - `_on_workflow_observability_results()`
  - `_on_workflow_parallel_start()`
  - `_on_workflow_parallel_progress()`
- ✅ Updated `_subscribe_ui_handlers()` to register workflow event listeners
- ✅ Updated `compose()` to include all new widgets in layout:
  - WorkflowStatusBar at top
  - AgentActivityPanel in left sidebar
  - TaskGraphWidget, ReviewFeedbackWidget, ParallelExecutionWidget, ObservabilityResultsWidget in center column
- ✅ Updated CSS for new layout structure
- ✅ Added keyboard shortcuts:
  - `a` = Toggle agent panel
  - `t` = Toggle task graph

**Layout Structure:**
```
┌─────────────────────────────────────────────────────┐
│ WorkflowStatusBar (top)                             │
├──────────────┬──────────────────────────────────────┤
│ Agent Panel  │ Chat Log                             │
│ (left)       │                                      │
│              │                                      │
│              ├──────────────────────────────────────┤
│              │ Task Graph (expandable)              │
│              ├──────────────────────────────────────┤
│              │ Review Feedback (when active)        │
│              ├──────────────────────────────────────┤
│              │ Parallel Execution (when active)     │
│              ├──────────────────────────────────────┤
│              │ Observability Results (when active)  │
└──────────────┴──────────────────────────────────────┘
│ Input Box                                           │
└─────────────────────────────────────────────────────┘
```

---

### ✅ Phase 2: Backend Integration (COMPLETE)

#### Workflow Instrumentation

**File:** `src/ctrlcode/agents/workflow.py`

**Changes:**
- ✅ Added `event_callback` parameter to `MultiAgentWorkflow.__init__()`
- ✅ Added `_emit_event()` helper method
- ✅ Instrumented all workflow phases with event emission:
  - **Planning phase:** Emits agent spawn, completion, task graph creation
  - **Execution phase:** Emits agent spawn/update/complete, task status updates, parallel execution tracking
  - **Review phase:** Emits reviewer agent events, feedback items
  - **Validation phase:** Emits executor agent events, observability results
  - **Review feedback loop:** Emits feedback status updates (pending → in_progress → fixed)
- ✅ Added progress tracking through workflow phases (0% → 100%)
- ✅ Updated `WorkflowOrchestrator` to accept and forward event callback

**Events emitted:**
- `workflow_phase_change` - Phase transitions with progress
- `workflow_agent_spawned` - Agent creation
- `workflow_agent_updated` - Agent status/progress updates
- `workflow_agent_completed` - Agent completion
- `workflow_task_graph_created` - Task breakdown from planner
- `workflow_task_updated` - Task status changes
- `workflow_review_feedback` - Reviewer feedback items
- `workflow_observability_results` - Validation test results
- `workflow_parallel_start` - Parallel execution group start
- `workflow_parallel_progress` - Individual parallel task progress

#### Session Manager Integration

**File:** `src/ctrlcode/session/manager.py`

**Changes:**
- ✅ Added workflow imports (`WorkflowOrchestrator`, `AgentRegistry`)
- ✅ Added `workflow_events_queue` to `Session` dataclass
- ✅ Added `workflow_orchestrator` and `workflow_enabled` to SessionManager
- ✅ Created `_create_workflow_event_callback()` method to queue events
- ✅ Added `_should_use_workflow()` heuristic to detect multi-agent requests
- ✅ Integrated workflow detection into `process_turn()` method
- ✅ Added placeholder workflow event emission (ready for full integration)

---

## What's Still Needed

### ⏳ Phase 3: Full Workflow Execution

#### 1. Complete Workflow Execution in SessionManager

**File to modify:** `src/ctrlcode/session/manager.py`

**Need to add:**
- Full workflow execution in `process_turn()` (currently placeholder)
- Yield workflow events from queue as they arrive
- Handle workflow orchestrator initialization
- Pass agent registry to workflow orchestrator

**Approach:**
```python
# In process_turn, after detecting workflow mode:
if use_workflow:
    # Initialize orchestrator if needed
    if not self.workflow_orchestrator:
        agent_registry = AgentRegistry()  # Need to create/inject this
        self.workflow_orchestrator = WorkflowOrchestrator(
            agent_registry,
            storage_path,
            session.provider,
            event_callback
        )

    # Execute workflow in background task
    workflow_task = asyncio.create_task(
        self.workflow_orchestrator.handle_user_request(user_input)
    )

    # Yield queued events as they arrive
    while not workflow_task.done():
        if session.workflow_events_queue:
            event = session.workflow_events_queue.pop(0)
            yield StreamEvent(type=event["type"], data=event["data"])
        await asyncio.sleep(0.1)

    # Get final result
    result = await workflow_task
```

#### 2. Agent Registry Setup

**Need to create/configure:**
- Agent registry with agent configurations
- Agent prompts for planner, coder, reviewer, executor
- Integration with session manager

#### 3. Server Configuration

**File to check:** `src/ctrlcode/server.py`

**May need:**
- Enable workflow mode flag in config
- Pass workflow_enabled to session manager
- No RPC changes needed - events flow through existing streaming

---

## Next Steps (Prioritized)

### Step 1: Test Widget Rendering
- Run TUI and verify new widgets appear (they'll be empty initially)
- Check layout with `ctrl+code tui`
- Test keyboard shortcuts (`a` for agents, `t` for tasks)

### Step 2: Add Backend Event Emission
- Instrument `MultiAgentWorkflow` with callback parameter
- Add event emission at each phase transition
- Emit agent spawn/update/complete events

### Step 3: Wire Server → TUI Event Flow
- Ensure workflow events reach TUI via existing streaming mechanism
- Test with mock workflow events
- Verify EventBus forwards events to widget handlers

### Step 4: End-to-End Testing
- Test with real multi-agent workflow
- Verify all widgets update correctly
- Check parallel execution display

### Step 5: Polish
- Add animations (phase transitions, progress bars)
- Color coding consistency
- Better error handling when widgets not mounted
- Add help text / tooltips

---

## Testing Plan

### Manual Testing Checklist

#### Basic Widget Display
- [ ] TUI launches without errors
- [ ] All widgets render (even if empty)
- [ ] Agent panel shows "No active agents"
- [ ] Workflow status shows "No active workflow"
- [ ] Task graph shows "No tasks"
- [ ] Keyboard shortcuts work (`a`, `t`)

#### Single-Agent Mode
- [ ] Simple request works as before
- [ ] No workflow widgets shown/updated
- [ ] Chat log works normally

#### Multi-Agent Mode
- [ ] Workflow status updates through phases
- [ ] Agent panel shows spawned agents
- [ ] Task graph displays planner's breakdown
- [ ] Parallel execution shows concurrent tasks
- [ ] Review feedback displays issues
- [ ] Observability results show validation

---

## Known Issues / TODOs

1. **Layout refinement needed:**
   - Agent panel width may need adjustment
   - Widget spacing and borders
   - Scrolling behavior for long task lists

2. **Conditional visibility:**
   - Hide workflow widgets in single-agent mode
   - Show/hide widgets based on phase (e.g., review feedback only during review)

3. **Error handling:**
   - Current handlers catch all exceptions - should log them
   - Better handling when widgets not mounted

4. **Performance:**
   - High-frequency updates during parallel execution
   - May need debouncing/batching

5. **Backend integration:**
   - WorkflowOrchestrator not yet wired to session manager
   - Need to detect when to use multi-agent vs single-agent workflow
   - Streaming event propagation from workflow → server → TUI

---

## Architecture Notes

### Event Flow

```
MultiAgentWorkflow
    ↓ (callback)
SessionManager / Server
    ↓ (RPC streaming)
TUI EventBus
    ↓ (subscriptions)
Widget Event Handlers
    ↓ (update methods)
Widget Render
```

### Widget State Management

- **Principle:** Server is source of truth
- **TUI:** Reactive rendering based on events
- **No TUI mutations:** Only renders from server data
- **EventBus:** Decouples event emission from handling

---

## References

- **Plan doc:** `docs/active-plans/multi-agent-tui-integration.md`
- **Architecture:** `docs/WORLD_CLASS_AGENT_PROPOSAL.md`
- **Workflow code:** `src/ctrlcode/agents/workflow.py`
- **TUI app:** `tui/ctrlcode_tui/app.py`
- **Server:** `src/ctrlcode/server.py`
