# Event-Driven TUI Architecture - Summary

**Date:** 2026-02-14
**Status:** Design Complete

---

## What We Built

A **simple, event-driven TUI** where:
1. ✅ Clean 3-widget layout (status + chat + input)
2. ✅ On-demand modals via slash commands
3. ✅ **Central event bus** - all events flow through one place
4. ✅ Components subscribe to what they care about
5. ✅ **Bus viewer modal** - see everything happening on the bus

---

## Architecture Diagram

```
                    ┌─────────────────────┐
                    │    Event Bus        │
                    │  (Central Broker)   │
                    └──────────┬──────────┘
                               │
         ┌─────────────────────┼─────────────────────┐
         │                     │                     │
    Publishers            Subscribers           History
         │                     │                     │
┌────────▼────────┐   ┌────────▼────────┐   ┌──────▼──────┐
│  Workflow       │   │  StatusLine     │   │ StatusModal │
│  Orchestrator   │   │  (phase/error)  │   │ (bus viewer)│
└─────────────────┘   └─────────────────┘   └─────────────┘
│                     │  ChatLog        │
│  publish("workflow  │  (all events)   │
│   _phase_change")   └─────────────────┘
│                     │  AgentsModal    │
│                     │  (agent events) │
│                     └─────────────────┘
│                     │  TasksModal     │
│                     │  (task events)  │
│                     └─────────────────┘
│
├─ Server/Session   ─┐
│  (bridge to TUI)   │
└────────────────────┘
```

---

## Event Flow Example

### Scenario: Workflow executes and user checks status

```
1. Workflow starts
   └─ publish("workflow_phase_change", {phase: "planning", progress: 0.0})

2. Event bus receives event
   └─ Notifies all subscribers

3. Components react independently:
   ├─ StatusLine updates: "Workflow: Planning [0%]"
   ├─ ChatLog adds inline: "📝 Phase: planning (0%)"
   └─ Event stored in bus history

4. User presses Ctrl+S
   └─ App opens StatusModal

5. StatusModal loads event history
   └─ Displays all events in bus viewer

6. User sees:
   ╔══════════════════════════════════════╗
   ║ Event Bus Stream                     ║
   ╠══════════════════════════════════════╣
   ║ 14:32:01 workflow_phase_change       ║
   ║          phase: idle → planning      ║
   ║          progress: 0.0               ║
   ╚══════════════════════════════════════╝

7. Workflow spawns agent
   └─ publish("workflow_agent_spawned", {agent_id: "planner-1", type: "planner"})

8. Components react:
   ├─ ChatLog adds: "🔵 Planner spawned"
   ├─ App tracks agent in agents_data[]
   └─ StatusModal auto-updates (if open)

9. User types /agents
   └─ InputBox publishes: publish("ui_command_entered", {command: "agents"})

10. App handles command event
    └─ Opens AgentsModal with tracked agents_data

11. AgentsModal shows:
    ╔══════════════════════════════════════╗
    ║ Active Agents                        ║
    ╠══════════════════════════════════════╣
    ║ ⏳ Planner         [Active]          ║
    ║   Decomposing user intent            ║
    ╚══════════════════════════════════════╝
```

**Key points:**
- Workflow doesn't know about TUI
- TUI components don't know about workflow
- Everything communicates through events
- Complete audit trail in bus history

---

## Component Responsibilities

### 1. EventBus (`event_bus.py`)

**What it does:**
- Central message broker
- Routes events to subscribers
- Maintains event history
- Supports wildcards ("*" for all events)

**API:**
```python
bus = EventBus()

# Publish
await bus.publish("workflow_phase_change", {data}, source="workflow")

# Subscribe
bus.subscribe("workflow_phase_change", handler_function)

# Wildcard
bus.subscribe("*", on_any_event)

# History
history = bus.get_history()
```

### 2. StatusLine

**Subscribes to:**
- `workflow_phase_change` → Update phase/progress
- `system_error` → Show error state

**Displays:**
- "Ready" (idle)
- "Workflow: Planning [25%]" (active)
- "Error: Task failed" (error)

### 3. ChatLog

**Subscribes to:**
- `*` (all events) → Display inline

**Displays:**
```
[14:32:01] 🔵 Planner spawned
[14:32:05] 📝 Task graph created: 5 tasks
[14:32:10] ⏳ Coder #1 working (60%)
[14:32:15] 🔴 Review issue: Password not hashed
[14:32:20] ✅ Workflow complete
```

### 4. InputBox

**Publishes:**
- `ui_command_entered` when user types `/command`
- `ui_message_sent` when user sends message

**Detects:**
- Slash commands (`/agents`, `/status`, etc.)
- Auto-complete suggestions

### 5. StatusModal (Bus Viewer)

**Subscribes to:**
- `*` (all events) → Add to event list

**Displays:**
```
╔══════════════════════════════════════╗
║ Event Bus Stream                     ║
╠══════════════════════════════════════╣
║ 14:32:01 workflow_phase_change       ║
║          phase: idle → planning      ║
║          progress: 0.0               ║
║                                      ║
║ 14:32:05 workflow_agent_spawned      ║
║          agent_id: planner-1         ║
║          type: planner               ║
╚══════════════════════════════════════╝
[Auto-scroll ON] Press Space to toggle
```

**Features:**
- Real-time updates
- Auto-scroll toggle (Space)
- Shows ALL events (complete transparency)
- Perfect for debugging

### 6. AgentsModal

**Subscribes to:**
- `workflow_agent_spawned` → Add agent
- `workflow_agent_updated` → Update status/progress
- `workflow_agent_completed` → Mark complete

**Displays:**
```
╔══════════════════════════════════════╗
║ Active Agents                        ║
╠══════════════════════════════════════╣
║ ✓ Planner          [Complete]       ║
║ ⏳ Coder #1        [Active 60%]      ║
║ ⏸ Reviewer        [Waiting]          ║
╚══════════════════════════════════════╝
```

### 7. TasksModal

**Subscribes to:**
- `workflow_task_graph_created` → Load graph
- `workflow_task_updated` → Update task status

**Displays:**
```
╔══════════════════════════════════════╗
║ Task Graph                           ║
╠══════════════════════════════════════╣
║ ✓ task-1: Read auth                  ║
║ ├─⏳ task-2: Add JWT [60%]           ║
║ └─⏸ task-3: Update model             ║
╚══════════════════════════════════════╝
```

### 8. App (Coordinator)

**Subscribes to:**
- All workflow events → Track state for modals
- `ui_command_entered` → Handle commands

**Maintains state:**
```python
self.agents_data = []       # For AgentsModal
self.task_graph = {}        # For TasksModal
self.review_feedback = []   # For ReviewModal
self.metrics_data = {}      # For MetricsModal
```

**Routes commands:**
- `/agents` → Open AgentsModal
- `/tasks` → Open TasksModal
- `/status` → Open StatusModal
- etc.

---

## Slash Commands

| Command    | Shortcut | Action                  |
|------------|----------|-------------------------|
| `/agents`  | Ctrl+A   | Show agents modal       |
| `/tasks`   | Ctrl+T   | Show task graph modal   |
| `/status`  | Ctrl+S   | Show event bus viewer   |
| `/review`  | Ctrl+R   | Show review feedback    |
| `/metrics` | Ctrl+M   | Show observability data |
| `/clear`   | -        | Clear chat history      |
| `/help`    | -        | Show command reference  |

---

## Event Catalog

### Workflow Events

| Event Type                      | Description                  |
|---------------------------------|------------------------------|
| `workflow_phase_change`         | Phase transition + progress  |
| `workflow_agent_spawned`        | New agent created            |
| `workflow_agent_updated`        | Agent status/progress update |
| `workflow_agent_completed`      | Agent finished               |
| `workflow_task_graph_created`   | Planner created task graph   |
| `workflow_task_updated`         | Task status changed          |
| `workflow_review_feedback`      | Reviewer found issues        |
| `workflow_observability_results`| Executor validated changes   |
| `workflow_error`                | Workflow error occurred      |
| `workflow_complete`             | Workflow finished            |

### UI Events

| Event Type          | Description             |
|---------------------|-------------------------|
| `ui_command_entered`| User typed slash command|
| `ui_message_sent`   | User sent message       |
| `ui_modal_opened`   | Modal was opened        |
| `ui_modal_closed`   | Modal was closed        |

### System Events

| Event Type       | Description      |
|------------------|------------------|
| `system_info`    | Info message     |
| `system_warning` | Warning message  |
| `system_error`   | Error message    |

---

## Benefits

### 1. Loose Coupling
- Workflow doesn't know about TUI
- TUI doesn't know about workflow internals
- Components don't know about each other
- Easy to add/remove components

### 2. Debuggability
- **Bus viewer shows EVERYTHING**
- Complete audit trail of all events
- Filter/search event history
- Export events for analysis

### 3. Testability
- Mock event bus for testing
- Test components in isolation
- Verify events are published
- Replay events for debugging

### 4. Extensibility
- New components just subscribe
- No changes to existing code
- Add new event types easily

### 5. Observability
- See exactly what's happening
- When it happened
- Who published it
- What data was sent

---

## Implementation Files

### Created

```
tui/ctrlcode_tui/
├── event_bus.py                        # EventBus + EventTypes
├── widgets/
│   ├── status_line.py                  # Single-line status
│   ├── modal_base.py                   # Base modal class
│   └── modals/
│       ├── __init__.py
│       ├── status_modal.py             # Bus viewer ⭐
│       ├── agents_modal.py
│       ├── tasks_modal.py
│       ├── review_modal.py
│       └── metrics_modal.py
└── app_event_bus_example.py            # Event-driven app

docs/
├── active-plans/
│   ├── simplified-tui-redesign.md      # TUI redesign plan
│   └── event-driven-tui-summary.md     # This file
└── architectural-patterns/
    └── event-bus-architecture.md       # Event bus patterns
```

### To Modify

```
tui/ctrlcode_tui/
├── app.py                # Replace with event-driven version
├── widgets/
│   ├── chat_log.py       # Add add_workflow_event()
│   └── input_box.py      # Add slash command detection
```

### To Remove

```
tui/ctrlcode_tui/widgets/
├── workflow_status.py       ❌ Delete (replaced by StatusLine)
├── agent_panel.py           ❌ Delete (replaced by AgentsModal)
├── task_graph.py            ❌ Delete (replaced by TasksModal)
├── review_feedback.py       ❌ Delete (replaced by ReviewModal)
├── parallel_execution.py    ❌ Delete (not needed)
└── observability_results.py ❌ Delete (replaced by MetricsModal)
```

---

## Next Steps

### 1. Enhance Existing Widgets

- [ ] Add `add_workflow_event()` to ChatLog
- [ ] Add slash command detection to InputBox
- [ ] Test with mock events

### 2. Integrate Event Bus

- [ ] Wire event bus into app.py
- [ ] Subscribe components to events
- [ ] Test event flow

### 3. Connect to Workflow

- [ ] Modify workflow orchestrator to publish events
- [ ] Bridge server → event bus
- [ ] Test end-to-end

### 4. Polish

- [ ] Icons for all event types
- [ ] Color coding
- [ ] Animations
- [ ] Keyboard shortcuts

### 5. Test

- [ ] Single-agent mode
- [ ] Multi-agent workflow
- [ ] Modals open/close
- [ ] Bus viewer real-time updates
- [ ] Error handling

---

## Key Innovation: Bus Viewer

The **StatusModal (bus viewer)** is the key feature that makes debugging workflows transparent:

**What you see:**
- Every single event that flows through the system
- When it happened (timestamp)
- What type of event
- All data fields
- Who published it

**Why it matters:**
- No more black box workflows
- See exactly what agents are doing
- Debug issues in real-time
- Complete transparency

**Use cases:**
- "Why is the workflow stuck?" → Open bus, see last event
- "What did the planner create?" → Search for task_graph_created
- "When did the error happen?" → Filter by workflow_error
- "What events fired during execution?" → Replay event history

---

## Comparison: Before vs After

### Before (Complex)

```
6+ always-visible widgets
├─ WorkflowStatusBar
├─ AgentActivityPanel
├─ TaskGraphWidget
├─ ReviewFeedbackWidget
├─ ParallelExecutionWidget
└─ ObservabilityResultsWidget

Direct method calls:
workflow → app.update_status_bar()
workflow → app.update_agent_panel()
workflow → app.update_task_graph()
...

Result: Cluttered, tightly coupled, hard to debug
```

### After (Simple + Event-Driven)

```
3 always-visible widgets
├─ StatusLine (1 line)
├─ ChatLog (shows events inline)
└─ InputBox

5 on-demand modals
├─ /agents
├─ /tasks
├─ /status (bus viewer ⭐)
├─ /review
└─ /metrics

Event-driven communication:
workflow → bus.publish("event")
            ↓
components subscribe → react independently

Result: Clean, loosely coupled, fully transparent
```

---

## Success Criteria

- [x] Event bus implemented
- [x] Event catalog defined
- [x] StatusLine created
- [x] 5 modals created (including bus viewer)
- [x] Slash commands designed
- [x] Event-driven app example
- [ ] Integration with existing TUI
- [ ] Integration with workflow orchestrator
- [ ] End-to-end testing

---

## References

- **Event Bus:** `tui/ctrlcode_tui/event_bus.py`
- **App Example:** `tui/ctrlcode_tui/app_event_bus_example.py`
- **Architecture:** `docs/architectural-patterns/event-bus-architecture.md`
- **TUI Plan:** `docs/active-plans/simplified-tui-redesign.md`
