# Tool Registry

*Auto-generated documentation of available tools.*

**Last Updated:** Auto-generated

## Exploration Tools

### `search_files`

**Description:** Search for files by pattern/name in workspace.

**Parameters:** `pattern, path?`

### `search_code`

**Description:** Search for code content using regex in workspace.

**Parameters:** `pattern, path?, file_pattern?`

### `read_file`

**Description:** Read file contents with optional line range.

**Parameters:** `path, start_line?, end_line?`

### `list_directory`

**Description:** List directory contents.

**Parameters:** `path`

### `get_file_info`

**Description:** Get file metadata (size, modified time, etc.).

**Parameters:** `path`

## Modification Tools

### `write_file`

**Description:** Create new file with content.

**Parameters:** `path, content`

### `update_file`

**Description:** Update existing file by line range (replace/insert/delete).

**Parameters:** `path, operation, start_line?, end_line?, content?, search_pattern?`

## Execution Tools

### `run_command`

**Description:** Execute shell command in workspace.

**Parameters:** `command, timeout?, cwd?`

### `fetch`

**Description:** Make HTTP request (GET/POST/PUT/DELETE).

**Parameters:** `url, method?, headers?, body?, timeout?`

## Task Management Tools

### `todo_write / task_write`

**Description:** Create new todo/task.

**Parameters:** `task, session_id?`

### `todo_list / task_list`

**Description:** List all todos/tasks.

**Parameters:** `session_id?`

### `todo_update / task_update`

**Description:** Update todo/task status.

**Parameters:** `task_id, completed, session_id?`

