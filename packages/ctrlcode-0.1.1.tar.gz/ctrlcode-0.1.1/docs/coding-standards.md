# Coding Standards

How we write code in ctrl+code.

## Language: Python 3.12+

**Type hints required**:
```python
def process_task(task_id: str, context: dict[str, Any]) -> TaskResult:
    ...
```

**Use dataclasses** for structured data:
```python
from dataclasses import dataclass

@dataclass
class AgentMessage:
    from_agent: str
    to_agent: str
    payload: dict[str, Any]
```

## Code Style

**Formatter**: ruff (configured in pyproject.toml)
**Linter**: ruff + mypy
**Line length**: 100 characters

**Import order**:
1. Standard library
2. Third-party packages
3. Local modules

```python
import asyncio
from pathlib import Path

from harnessutils import ConversationManager

from .registry import AgentRegistry
```

## Naming Conventions

**Files**: `snake_case.py`
**Classes**: `PascalCase`
**Functions/methods**: `snake_case()`
**Constants**: `UPPER_SNAKE_CASE`
**Private**: `_leading_underscore()`

## Error Handling

**Be specific**:
```python
# Good
try:
    data = json.loads(content)
except json.JSONDecodeError as e:
    logger.error(f"Invalid JSON: {e}")
    
# Bad
try:
    data = json.loads(content)
except Exception:
    pass
```

**Log errors with context**:
```python
logger.error(f"Failed to process task {task_id}: {error}", exc_info=True)
```

## Async/Await

**Use async for I/O-bound operations**:
```python
async def fetch_data(url: str) -> dict:
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        return response.json()
```

**Gather for parallel execution**:
```python
results = await asyncio.gather(*[
    process_task(task) for task in tasks
])
```

## Logging

**Use structured logging**:
```python
import logging
logger = logging.getLogger(__name__)

logger.info(f"Processing task {task_id} for user {user_id}")
logger.debug(f"Task details: {task}")
logger.error(f"Task failed: {error}", exc_info=True)
```

**Log levels**:
- DEBUG: Detailed diagnostic info
- INFO: General operational events
- WARNING: Unexpected but handled situations
- ERROR: Errors that need attention

## Testing

**File structure**: `tests/` mirrors `src/`
**Naming**: `test_*.py` files, `test_*()` functions
**Framework**: pytest

```python
def test_task_decomposition():
    planner = PlannerAgent()
    result = planner.decompose("Add login feature")
    assert len(result.tasks) > 0
    assert "endpoint" in result.tasks[0].description.lower()
```

## Documentation

**Docstrings for public APIs**:
```python
def spawn_agent(agent_type: str, task: dict) -> AgentResult:
    """
    Spawn a specialized agent to handle a task.
    
    Args:
        agent_type: Type of agent ("planner", "coder", etc.)
        task: Task specification with description and context
        
    Returns:
        AgentResult with status and output
        
    Raises:
        ValueError: If agent_type is unknown
    """
```

**Comments for complex logic only**:
```python
# Don't comment obvious code
x = y + 1  # Increment by one  ❌

# Do comment non-obvious decisions
# Use exponential backoff to avoid rate limiting when fuzzing
delay = 2 ** retry_count  ✅
```

## File Organization

**One class per file** (unless tightly coupled)
**Group related functions** in modules
**Keep files < 500 lines** (refactor if growing)

## Dependencies

**Prefer established libraries**:
- httpx over requests (async support)
- pathlib over os.path (modern, typed)
- tiktoken for token counting (official)

**Pin major versions** in pyproject.toml:
```toml
dependencies = [
    "harness-utils>=0.3.0",
    "anthropic>=0.40.0",
]
```

## Git Commits

**Semantic commit messages**:
```
feat: add multi-agent orchestration
fix: resolve race condition in agent bus
refactor: extract task graph logic
docs: update architecture patterns
```

**Keep commits focused** (one logical change per commit)
**Reference issues** when relevant: `feat: add login endpoint (#123)`
