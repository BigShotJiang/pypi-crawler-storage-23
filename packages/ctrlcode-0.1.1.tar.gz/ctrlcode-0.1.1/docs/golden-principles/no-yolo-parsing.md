# Golden Principle: No YOLO Parsing

## Principle Statement

**Always validate data at system boundaries. Never probe data shapes "YOLO-style" (accessing fields without validation).**

## Why This Matters

### For Humans
- Prevents runtime crashes from unexpected upstream data shapes
- Makes data contracts explicit and discoverable
- Catches API breaking changes immediately, not in production
- Self-documents what data structure code expects

### For Agents
When an agent can't tell what shape data *should* be (only what the code *assumes*), it can't reason about correctness. Explicit validation makes the contract legible in-context.

**From agent's perspective:**
- ❌ `user.email` → What if `user` is None? What if `email` is missing?
- ✅ `UserSchema.parse(data).email` → Clear: must be valid User with email field

## Violations

### ❌ Bad: Dictionary Access Without Validation

```python
def process_user(data: dict):
    # YOLO - assumes shape without checking
    email = data["user"]["email"]
    name = data["user"]["profile"]["name"]
    return f"{name} <{email}>"
```

**Problems:**
- KeyError if `user` missing
- KeyError if `email` missing
- KeyError if `profile` missing
- TypeError if any intermediate value is None
- Silent bugs if structure changes upstream

### ❌ Bad: Optional Chaining Still Assumes Shape

```python
def process_user(data: dict):
    # Better, but still probing
    email = data.get("user", {}).get("email")
    if email:
        return email
```

**Problems:**
- Silently accepts malformed data (returns None instead of failing)
- Can't distinguish between "email missing" vs "user missing"
- No documentation of expected structure

### ❌ Bad: Try/Except Hides Root Cause

```python
def process_user(data: dict):
    try:
        return data["user"]["email"]
    except (KeyError, TypeError):
        return "unknown@example.com"  # Swallows error!
```

**Problems:**
- Masks upstream bugs
- Debugging nightmare (where did data go wrong?)
- Violates fail-fast principle

## Correct Approaches

### ✅ Good: Dataclass Validation

```python
from dataclasses import dataclass

@dataclass
class UserProfile:
    name: str

@dataclass
class User:
    email: str
    profile: UserProfile

def process_user(data: dict) -> str:
    # Validate at boundary - fails fast with clear error
    user = User(**data["user"])
    return f"{user.profile.name} <{user.email}>"
```

**Benefits:**
- Explicit structure definition
- Automatic validation
- Type hints for IDE/agent
- Clear error messages

### ✅ Good: Pydantic Models

```python
from pydantic import BaseModel, EmailStr

class UserProfile(BaseModel):
    name: str

class User(BaseModel):
    email: EmailStr  # Extra validation!
    profile: UserProfile

def process_user(data: dict) -> str:
    user = User(**data["user"])  # Validates + coerces types
    return f"{user.profile.name} <{user.email}>"
```

**Benefits:**
- Runtime validation
- Type coercion
- Custom validators
- JSON schema generation

### ✅ Good: Manual Validation with Clear Errors

```python
def process_user(data: dict) -> str:
    # Validate each level explicitly
    if "user" not in data:
        raise ValueError("Missing 'user' field in data")

    user = data["user"]
    if not isinstance(user, dict):
        raise TypeError(f"Expected user to be dict, got {type(user)}")

    if "email" not in user:
        raise ValueError("Missing 'email' in user data")

    if "profile" not in user or "name" not in user["profile"]:
        raise ValueError("Missing profile.name in user data")

    return f"{user['profile']['name']} <{user['email']}>"
```

**Benefits:**
- Explicit error messages (debuggable)
- Fails fast at boundary
- Self-documenting expectations

## Where to Apply

### System Boundaries (REQUIRED)

- **API request/response parsing** - External data, untrusted
- **File I/O** - JSON/YAML/TOML parsing from disk
- **Database query results** - Especially raw SQL
- **LLM tool call arguments** - Agents can send malformed data
- **External service responses** - HTTP APIs, webhooks
- **Environment variables** - User configuration

### Internal Code (OPTIONAL)

- Between modules: Recommended if contract complex
- Within module: Not required if types enforce structure
- Test fixtures: Use validation to catch fixture bugs

## Enforcement

**Custom linter** (see Task #2) will detect:

```
❌ YOLO Parsing Detected
File: src/api/handler.py:23
Rule: golden-principles/no-yolo-parsing.md

Violation:
    email = request_data["user"]["email"]

FIX: Validate at boundary with dataclass or schema

    @dataclass
    class RequestData:
        user: User

    data = RequestData(**request_data)
    email = data.user.email

Why: Prevents runtime crashes from unexpected data shapes.
See: docs/golden-principles/no-yolo-parsing.md
```

## Exceptions

**When YOLO parsing is acceptable:**

1. **Internal data you control 100%** - e.g., hardcoded constants
2. **Already validated upstream** - Pass typed objects, not dicts
3. **Performance-critical hot path** - Validate once at boundary, trust internally

**Even then:** Add assertion or comment explaining why it's safe.

## Related

- **Tools**: Pydantic, dataclasses, marshmallow, TypedDict
- **Principle**: Fail fast at boundaries, trust internally
- **Pattern**: Parse, don't validate (make illegal states unrepresentable)

## Examples from Codebase

### Good Example: Tool Registry

```python
# src/ctrlcode/tools/registry.py
class ToolDefinition(BaseModel):  # ✅ Validates structure
    name: str
    description: str
    input_schema: dict
    function: Callable

def register_tool(self, tool_dict: dict):
    tool = ToolDefinition(**tool_dict)  # ✅ Fails fast if invalid
    self.tools[tool.name] = tool
```

### Bad Example (hypothetical - needs fixing if found):

```python
def process_tool_call(raw_call: dict):
    tool_name = raw_call["tool"]  # ❌ YOLO
    args = raw_call["input"]      # ❌ YOLO
    return self.execute(tool_name, **args)
```

Should be:

```python
@dataclass
class ToolCall:
    tool: str
    input: dict

def process_tool_call(raw_call: dict):
    call = ToolCall(**raw_call)  # ✅ Validates
    return self.execute(call.tool, **call.input)
```

## Summary

**Don't probe. Parse.**

Every dict access without validation is a latent bug waiting for upstream changes. Make data contracts explicit, fail fast at boundaries, and let agents (and future developers) reason about correctness from type signatures alone.
