# Golden Principle: Structured Logging

## Principle Statement

**Use structured logging with consistent format across the codebase. Include relevant context. Use log levels consistently.**

## Why This Matters

### For Humans
- Makes logs searchable and filterable
- Enables log aggregation and analysis
- Faster debugging (grep for specific fields)
- Consistent log levels help prioritize issues

### For Agents
Unstructured logs are noise. Structured logs are data that agents can query, analyze, and act on.

**From agent's perspective:**
- ❌ `print("User login failed")` → Unsearchable, no context, can't act on it
- ✅ `logger.info("auth.login.failed", user_id="123", reason="invalid_password")` → Queryable, actionable, debuggable

When Executor agent (Task #3) gets `query_logs` tool, it can only work with structured logs.

## Violations

### ❌ Bad: Print Statements

```python
def login(user_id: str, password: str):
    print(f"Login attempt for user {user_id}")
    if not validate_password(password):
        print("Password validation failed!")
        return False
    print("Login successful")
    return True
```

**Problems:**
- Goes to stdout, not log system
- No timestamp
- No log level
- No structured fields
- Can't filter or search efficiently
- Agent can't parse

### ❌ Bad: Unstructured String Logging

```python
import logging

def login(user_id: str, password: str):
    logging.info(f"Login attempt for user {user_id} at {datetime.now()}")
    if not validate_password(password):
        logging.error(f"Password validation failed for {user_id}!")
        return False
    logging.info(f"User {user_id} logged in successfully")
    return True
```

**Problems:**
- Context buried in string (hard to parse)
- Inconsistent format (sometimes includes timestamp, sometimes not)
- Can't filter by user_id efficiently
- Agent has to parse natural language

### ❌ Bad: Inconsistent Log Levels

```python
# Different files using levels inconsistently

# File 1: Uses info for errors
logging.info("Database connection failed")  # Should be error!

# File 2: Uses warning for debug
logging.warning(f"Processing item {i} of {n}")  # Should be debug!

# File 3: Uses error for info
logging.error("User logged in")  # Should be info!
```

**Problems:**
- Can't filter by severity
- Log monitoring alerts on wrong things
- Noise in error logs

### ❌ Bad: Missing Context

```python
def process_task(task_id: str):
    logging.info("Starting task")  # Which task?

    try:
        result = do_work()
        logging.info("Task complete")  # Which task? What result?
    except Exception as e:
        logging.error("Task failed")  # Which task? What error?
```

**Problems:**
- Can't correlate logs to specific task
- Debugging requires reading all logs sequentially
- Can't filter to single task's lifecycle

## Correct Approaches

### ✅ Good: Structured Logging with Context

```python
import structlog

logger = structlog.get_logger()

def login(user_id: str, password: str) -> bool:
    # Bind context for all subsequent logs
    log = logger.bind(user_id=user_id, action="login")

    log.info("auth.login.attempt")

    if not validate_password(password):
        log.warning("auth.login.failed", reason="invalid_password")
        return False

    log.info("auth.login.success")
    return True

# Output:
# {"event": "auth.login.attempt", "user_id": "123", "action": "login", "timestamp": "2026-02-14T15:30:00Z"}
# {"event": "auth.login.success", "user_id": "123", "action": "login", "timestamp": "2026-02-14T15:30:01Z"}
```

**Benefits:**
- Every log has user_id and action
- Machine-readable JSON
- Filterable: `jq 'select(.user_id == "123")'`
- Agent can query: `query_logs('{user_id="123"}')`

### ✅ Good: Python Standard Library with Structured Extras

```python
import logging

logger = logging.getLogger(__name__)

def process_task(task_id: str, task_type: str):
    extra = {"task_id": task_id, "task_type": task_type}

    logger.info("task.started", extra=extra)

    try:
        result = do_work()
        logger.info(
            "task.completed",
            extra={**extra, "result_size": len(result)}
        )
        return result
    except Exception as e:
        logger.error(
            "task.failed",
            extra={**extra, "error": str(e)},
            exc_info=True  # Include stack trace
        )
        raise
```

**With proper formatter:**
```python
# Configure formatter to output JSON
import json

class StructuredFormatter(logging.Formatter):
    def format(self, record):
        log_data = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "event": record.getMessage(),
            "module": record.module,
            **record.__dict__.get("extra", {})
        }
        return json.dumps(log_data)
```

### ✅ Good: Consistent Log Levels

```python
# Follow standard log level semantics

# DEBUG: Detailed diagnostic info (verbose, only in development)
logger.debug("cache.lookup", key=cache_key, hit=True)

# INFO: General informational events (important business events)
logger.info("task.completed", task_id=task_id, duration_ms=elapsed)
logger.info("user.registered", user_id=user_id, plan="free")

# WARNING: Unexpected but recoverable situations
logger.warning("rate_limit.approaching", current=95, limit=100)
logger.warning("retry.attempt", attempt=2, max_attempts=3)

# ERROR: Errors that prevented operation from completing
logger.error("database.query.failed", query=sql, error=str(e))
logger.error("api.request.failed", url=url, status_code=500)

# CRITICAL: System-level failures (rare, indicates serious problem)
logger.critical("database.connection.lost", host=db_host)
logger.critical("disk.full", usage_percent=99)
```

### ✅ Good: Contextual Logging

```python
import structlog

logger = structlog.get_logger()

def handle_request(request_id: str, user_id: str, endpoint: str):
    # Bind context at top of request
    log = logger.bind(
        request_id=request_id,
        user_id=user_id,
        endpoint=endpoint
    )

    log.info("request.started")

    # Context automatically included in all child logs
    result = process_endpoint(log, endpoint)

    log.info("request.completed", status_code=200, duration_ms=result.duration)

def process_endpoint(log, endpoint: str):
    # Inherit parent context, add more
    log.info("processing.started")

    # Any exceptions automatically include request_id, user_id, endpoint
    data = fetch_data()
    log.debug("data.fetched", size=len(data))

    return transform(data)
```

## Standard Log Format

### Required Fields

All logs MUST include:
- `timestamp` - ISO 8601 format
- `level` - DEBUG/INFO/WARNING/ERROR/CRITICAL
- `event` - Dot-separated event name (e.g., "task.completed")
- `module` - Python module name

### Recommended Context Fields

Include when available:
- `request_id` - Unique request identifier
- `user_id` - User performing action
- `task_id` - Task being processed
- `agent_id` - Agent performing work (multi-agent system)
- `session_id` - Session identifier
- `correlation_id` - For distributed tracing

### Event Naming Convention

Use dot-separated hierarchical names:

```
{domain}.{action}.{status}

Examples:
- auth.login.attempt
- auth.login.success
- auth.login.failed
- task.started
- task.completed
- task.failed
- agent.spawned
- agent.completed
- database.query.executed
- database.connection.lost
```

## Configuration

### Setup Structured Logging

```python
# src/ctrlcode/logging_config.py
import structlog
import logging

def setup_logging(level: str = "INFO", format: str = "json"):
    """Configure structured logging for ctrl+code.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format: Output format (json, console)
    """
    # Configure standard library logging
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format="%(message)s"
    )

    # Configure structlog
    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
    ]

    if format == "json":
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper())
        ),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )

# Usage in main.py
from ctrlcode.logging_config import setup_logging

setup_logging(level="INFO", format="json")
```

### Usage in Code

```python
import structlog

logger = structlog.get_logger(__name__)

def my_function():
    logger.info("event.name", key="value", another_key=42)
```

## Querying Structured Logs

### With jq (JSON query)

```bash
# Find all failed login attempts
cat logs/app.log | jq 'select(.event == "auth.login.failed")'

# Find logs for specific user
cat logs/app.log | jq 'select(.user_id == "123")'

# Count errors by type
cat logs/app.log | jq 'select(.level == "ERROR") | .event' | sort | uniq -c
```

### With query_logs Tool (Task #3)

```python
# Agent can query logs
executor_agent.query_logs(
    query='{event="auth.login.failed"}',
    time_range="1h"
)
# Returns structured list of failed login attempts
```

### With Log Aggregation (Future)

```
# LogQL (Loki)
{app="ctrlcode"} |= "error" | json

# Filter by level
{app="ctrlcode"} | json level="ERROR"

# Filter by user
{app="ctrlcode"} | json user_id="123"
```

## Enforcement

**Custom linter** (see Task #2) will detect:

```
❌ Unstructured Logging Detected
File: src/api/handler.py:45
Rule: golden-principles/structured-logging.md

Violation: Using print statement instead of logger

    print(f"Processing request {request_id}")

FIX: Use structured logging

    import structlog
    logger = structlog.get_logger(__name__)

    logger.info("request.processing", request_id=request_id)

Why: Enables log querying, filtering, and agent analysis.
See: docs/golden-principles/structured-logging.md
```

```
❌ Missing Context Detected
File: src/tasks/processor.py:67

Violation: Log missing context fields

    logger.info("Task started")  # Which task?

FIX: Include relevant context

    logger.info("task.started", task_id=task_id, task_type=task_type)

Why: Logs need context to be debuggable.
```

## Migration from Existing Logs

### Phase 1: Add Structured Logger
```python
# Add alongside existing logging
import logging
import structlog

old_logger = logging.getLogger(__name__)
logger = structlog.get_logger(__name__)

# Gradually migrate
old_logger.info(f"Task {task_id} started")  # Old
logger.info("task.started", task_id=task_id)  # New
```

### Phase 2: Replace Print Statements
```python
# Find all: grep -r "print(" src/
# Replace with logger.info/debug
```

### Phase 3: Add Context
```python
# Add task_id, user_id, request_id to all relevant logs
```

### Phase 4: Standardize Event Names
```python
# Convert ad-hoc strings to dot-separated events
"Task started" → "task.started"
"Login failed" → "auth.login.failed"
```

## Related Tools

- **structlog** - Structured logging library
- **python-json-logger** - JSON formatter for stdlib logging
- **Loki** - Log aggregation (future integration)
- **jq** - JSON query tool for log analysis

## Examples from Codebase

### Good Example: Session Manager

```python
# src/ctrlcode/session/manager.py
import structlog

logger = structlog.get_logger(__name__)

def create_session(session_id: str, provider: str):
    log = logger.bind(session_id=session_id, provider=provider)

    log.info("session.created")

    try:
        session = Session(id=session_id, provider=provider)
        log.info("session.initialized")
        return session
    except Exception as e:
        log.error("session.creation.failed", error=str(e), exc_info=True)
        raise
```

### Bad Example (needs fixing):

```python
# Hypothetical - if found, needs fixing
def process():
    print("Starting")  # ❌ Should use logger
    logging.info(f"Value: {x}")  # ❌ Should use structured format
```

## Summary

**Structure your logs. Your future self (and the agents) will thank you.**

Logs are data, not prose. Structured logs enable:
- Machine parsing and querying
- Automated analysis by Executor agent
- Efficient debugging and monitoring
- Correlation across distributed systems

Every `print()` statement is a missed opportunity for observability.
