# Architectural Patterns

System design patterns and structure for ctrl+code.

## System Architecture

```
┌─────────────────────────────────────────────────┐
│                    TUI Client                    │
│         (Textual-based terminal UI)             │
└────────────┬────────────────────────────────────┘
             │ JSON-RPC over HTTP
┌────────────▼────────────────────────────────────┐
│              Server (FastAPI/aiohttp)           │
│  ┌───────────────────────────────────────────┐  │
│  │         Session Manager                   │  │
│  │  (harness-utils ConversationManager)      │  │
│  └───────┬──────────────────┬────────────────┘  │
│          │                  │                    │
│  ┌───────▼────────┐  ┌─────▼──────────────────┐ │
│  │ Multi-Agent    │  │  Tool Registry &       │ │
│  │ Orchestrator   │  │  Executor              │ │
│  └───────┬────────┘  └────────────────────────┘ │
│          │                                       │
│  ┌───────▼─────────────────────────────────┐    │
│  │    AgentCoordinator + AgentBus          │    │
│  │  (Inter-agent communication)            │    │
│  └────┬──────┬──────┬──────┬───────────────┘    │
│       │      │      │      │                     │
│  ┌────▼──┐┌──▼───┐┌▼────┐┌▼──────┐             │
│  │Planner││Coder ││Review││Executor│             │
│  │ Agent ││Agent ││Agent ││ Agent  │             │
│  └───────┘└──────┘└─────┘└────────┘             │
└──────────────────────────────────────────────────┘
             │
┌────────────▼────────────────────────────────────┐
│          Fuzzing Pipeline                       │
│  (Differential fuzzing for code quality)        │
└─────────────────────────────────────────────────┘
```

## Multi-Agent Workflow Pattern

**Phase 1: Planning**
```python
user_intent → Orchestrator
              ↓
          Planner Agent
              ↓
          Task Graph (with dependencies)
```

**Phase 2: Execution**
```python
Task Graph → Orchestrator
              ↓
          Parallel Coder Agents
          (one per independent task)
              ↓
          Code Changes + Test Results
```

**Phase 3: Review**
```python
Code Changes → Orchestrator
               ↓
           Reviewer Agent
               ↓
           Approved / Changes Requested
               ↓ (if changes requested)
           Back to Coder Agent(s)
```

**Phase 4: Validation**
```python
Approved Changes → Orchestrator
                   ↓
               Executor Agent
                   ↓
               Runtime Verification
                   ↓
               Pass / Fail
```

## Agent Communication Pattern

**Message Structure**:
```python
@dataclass
class AgentMessage:
    from_agent: str        # Source agent ID
    to_agent: str          # Target agent ID
    message_type: str      # "task" | "result" | "feedback" | "question"
    payload: dict[str, Any]  # Message data
    context: dict[str, Any] | None  # Additional context
```

**AgentBus** handles message routing:
```python
bus = AgentBus()
bus.register_handler("coder-1", coder_message_handler)
await bus.send(AgentMessage(
    from_agent="planner",
    to_agent="coder-1",
    message_type="task",
    payload={"task_id": "task-1", "description": "Add endpoint"}
))
```

## Session Management Pattern

**Per-session state**:
```python
@dataclass
class Session:
    id: str                     # Unique session ID
    conv_id: str                # harness-utils conversation ID
    provider: Provider          # LLM provider (Anthropic, OpenAI)
    cumulative_tokens: int      # Token usage tracking
```

**Session lifecycle**:
1. Client creates session → SessionManager assigns ID + provider
2. Client sends messages → SessionManager routes to orchestrator or single-agent
3. Orchestrator spawns specialized agents as needed
4. Session maintains conversation history via harness-utils ConversationManager
5. Context window managed automatically (pruning, summarization)

## Tool Registry Pattern

**Tool Definition**:
```python
{
    "name": "read_file",
    "description": "Read file contents",
    "input_schema": {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
        },
        "required": ["path"]
    }
}
```

**Tool Executor**:
- Validates input against schema
- Executes tool function
- Returns structured result
- Logs execution for observability

**Tool Subsets** per agent:
- Planner: `search_files`, `search_code`, `read_file`, `list_directory`
- Coder: `read_file`, `write_file`, `update_file`, `run_command`
- Reviewer: `read_file`, `run_command`, `search_code`
- Executor: `run_command`, `fetch`

## Event Streaming Pattern

**Server → Client events**:
```python
StreamEvent(type="text", data={"text": "Processing..."})
StreamEvent(type="tool_call_start", data={"tool": "read_file"})
StreamEvent(type="tool_result", data={"success": True, "result": "..."})
StreamEvent(type="workflow_phase_change", data={"phase": "execution"})
```

**Client EventBus** distributes to handlers:
```python
events.subscribe("workflow_phase_change", _on_phase_change)
events.emit("workflow_phase_change", {"phase": "execution"})
```

## Fuzzing Pipeline Pattern

**Trigger**: Code block detected in LLM output

**Flow**:
1. Extract code from response
2. Generate variants via LLM
3. Run all variants through test suite
4. Compare outputs (differential fuzzing)
5. Select best variant
6. Return to user

**Integration**: Happens between code generation and file write

## Progressive Disclosure Pattern

**Load minimal context upfront**:
```python
# Load AGENTS.md (~500 tokens) as map
system_prompt = load_file("docs/AGENTS.md")

# Fetch specific docs as needed
if task_requires_auth:
    system_prompt += load_file("docs/architectural-patterns.md#auth")
```

**Benefits**:
- Smaller context window usage
- Faster response times
- More focused agent reasoning
- Scales to larger codebases

## Error Recovery Pattern

**Levels of escalation**:
1. **Agent retry**: Same agent, different approach
2. **Agent replacement**: Different agent instance
3. **Human escalation**: Orchestrator asks for help
4. **Fallback mode**: Switch to single-agent execution

**Example**:
```python
try:
    result = await coder_agent.run(task)
except AgentError as e:
    logger.warning(f"Coder failed, retrying: {e}")
    result = await coder_agent.run(task)  # Retry
    
    if not result.success:
        logger.error(f"Coder failed twice, escalating to human")
        await orchestrator.escalate_to_human(task, error=e)
```

## Data Flow

**User message**:
```
User Input (TUI)
    → RPC Client
    → Server SessionManager
    → Orchestrator (if multi-agent) OR Single Agent
    → Tool Execution
    → LLM Provider
    → Stream Events back to TUI
```

**Workflow state**:
- Stored in Orchestrator
- Task graph tracked via task management tools
- Agent status emitted as events
- TUI widgets render real-time status

## Testing Strategy

**Unit tests**: Individual agent logic, tool execution
**Integration tests**: Multi-agent workflows end-to-end
**Manual tests**: TUI interaction, visual verification
**Fuzzing**: Code quality validation

Test files mirror source structure in `tests/` directory.
