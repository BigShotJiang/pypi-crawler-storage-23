"""Benchmark LRU cache performance in oracle retrieval."""

import asyncio
import time
from datetime import datetime

from ctrlcode.embeddings.embedder import CodeEmbedder
from ctrlcode.fuzzing.context import ContextDerivation, ContextDerivationEngine
from ctrlcode.providers.base import Provider
from ctrlcode.storage.history_db import CodeRecord, HistoryDB, OracleRecord


class MockProvider(Provider):
    """Mock LLM provider for benchmarking."""

    async def generate(self, messages: list[dict], **kwargs) -> dict:
        return {"text": "{}"}

    async def stream(self, messages: list[dict], **kwargs):
        yield {"type": "text", "data": {"text": "{}"}}

    def normalize_tool_call(self, tool_call: dict) -> dict:
        return tool_call


def create_sample_oracle(code: str) -> ContextDerivation:
    """Create sample oracle for testing."""
    from ctrlcode.fuzzing.context import (
        ImplicitAssumption,
        IntegrationContract,
        SystemPlacement,
    )

    return ContextDerivation(
        system_placement=SystemPlacement(
            system_type="web service",
            layer="data access",
            callers="API",
            callees="database",
        ),
        environmental_constraints={"language": "Python"},
        integration_contracts=[
            IntegrationContract(
                system="Database",
                contract="Query data",
                implicit_requirements=["Connection"],
            )
        ],
        behavioral_invariants=["Returns data"],
        edge_case_surface=["Not found"],
        implicit_assumptions=[
            ImplicitAssumption(assumption="Valid input", risk="SAFE", explanation="OK")
        ],
    )


async def populate_history_db(db: HistoryDB, num_entries: int = 100):
    """Populate history DB with sample data."""
    embedder = CodeEmbedder()

    for i in range(num_entries):
        code = f"def function_{i}(x): return x * {i}"
        code_embedding = embedder.embed_code(code)

        # Store code
        code_record = CodeRecord(
            code_id=f"code_{i}",
            session_id=f"session_{i}",
            code=code,
            embedding=code_embedding,
            timestamp=datetime.now(),
        )
        db.store_code(code_record)

        # Store oracle
        oracle = create_sample_oracle(code)
        oracle_embedding = embedder.embed_oracle(oracle.to_json())
        oracle_record = OracleRecord(
            oracle_id=f"oracle_{i}",
            session_id=f"session_{i}",
            oracle=oracle.to_json(),
            embedding=oracle_embedding,
            quality_score=0.9,
            timestamp=datetime.now(),
        )
        db.store_oracle(oracle_record)


async def benchmark_without_cache():
    """Benchmark oracle search without caching."""
    print("\n" + "=" * 60)
    print("BENCHMARK: Oracle Search WITHOUT Cache")
    print("=" * 60)

    db = HistoryDB(":memory:")
    await populate_history_db(db, num_entries=100)

    provider = MockProvider()
    engine = ContextDerivationEngine(
        provider=provider, history_db=db, cache_size=0  # Disable cache
    )

    # Manually clear cache to ensure no caching
    engine.oracle_cache.clear()
    engine.oracle_cache.max_size = 0

    test_code = "def function_50(x): return x * 50"  # Exact match to entry 50
    code_embedding = engine.embedder.embed_code(test_code)

    # Warmup
    await engine._search_similar_oracle(code_embedding, test_code, "Test")

    # Benchmark: search same code 10 times
    iterations = 10
    start = time.perf_counter()

    for _ in range(iterations):
        await engine._search_similar_oracle(code_embedding, test_code, "Test")

    elapsed = time.perf_counter() - start
    avg_time_ms = (elapsed / iterations) * 1000

    print(f"\nResults (no cache):")
    print(f"  Total searches: {iterations}")
    print(f"  Total time: {elapsed * 1000:.2f} ms")
    print(f"  Avg per search: {avg_time_ms:.2f} ms")

    return avg_time_ms


async def benchmark_with_cache():
    """Benchmark oracle search with caching."""
    print("\n" + "=" * 60)
    print("BENCHMARK: Oracle Search WITH Cache")
    print("=" * 60)

    db = HistoryDB(":memory:")
    await populate_history_db(db, num_entries=100)

    provider = MockProvider()
    engine = ContextDerivationEngine(
        provider=provider, history_db=db, cache_size=100  # Enable cache
    )

    test_code = "def function_50(x): return x * 50"  # Exact match to entry 50
    code_embedding = engine.embedder.embed_code(test_code)

    # First search: cache miss (populate cache)
    await engine._search_similar_oracle(code_embedding, test_code, "Test")

    # Benchmark: search same code 10 times (all cache hits)
    iterations = 10
    start = time.perf_counter()

    for _ in range(iterations):
        await engine._search_similar_oracle(code_embedding, test_code, "Test")

    elapsed = time.perf_counter() - start
    avg_time_ms = (elapsed / iterations) * 1000

    print(f"\nResults (with cache):")
    print(f"  Total searches: {iterations}")
    print(f"  Total time: {elapsed * 1000:.2f} ms")
    print(f"  Avg per search: {avg_time_ms:.2f} ms")
    print(f"\nCache statistics:")
    print(f"  Cache hits: {engine.oracle_cache.hits}")
    print(f"  Cache misses: {engine.oracle_cache.misses}")
    print(f"  Hit rate: {engine.oracle_cache.hit_rate:.1%}")
    print(f"  Cache size: {engine.oracle_cache.size}")

    return avg_time_ms


async def benchmark_cache_performance():
    """Benchmark cache hit vs miss performance."""
    print("\n" + "=" * 60)
    print("BENCHMARK: Cache Hit vs Miss Performance")
    print("=" * 60)

    db = HistoryDB(":memory:")
    await populate_history_db(db, num_entries=100)

    provider = MockProvider()
    engine = ContextDerivationEngine(provider=provider, history_db=db, cache_size=100)

    # Measure cache MISS time
    unique_codes = [f"def unique_{i}(): pass" for i in range(10)]
    miss_times = []

    for code in unique_codes:
        embedding = engine.embedder.embed_code(code)
        start = time.perf_counter()
        await engine._search_similar_oracle(embedding, code, "Test")
        elapsed = time.perf_counter() - start
        miss_times.append(elapsed * 1000)

    avg_miss_time = sum(miss_times) / len(miss_times)

    # Measure cache HIT time
    hit_code = unique_codes[0]  # Already in cache
    hit_embedding = engine.embedder.embed_code(hit_code)
    hit_times = []

    for _ in range(10):
        start = time.perf_counter()
        await engine._search_similar_oracle(hit_embedding, hit_code, "Test")
        elapsed = time.perf_counter() - start
        hit_times.append(elapsed * 1000)

    avg_hit_time = sum(hit_times) / len(hit_times)

    print(f"\nCache MISS:")
    print(f"  Avg time: {avg_miss_time:.3f} ms")
    print(f"  Min time: {min(miss_times):.3f} ms")
    print(f"  Max time: {max(miss_times):.3f} ms")

    print(f"\nCache HIT:")
    print(f"  Avg time: {avg_hit_time:.3f} ms")
    print(f"  Min time: {min(hit_times):.3f} ms")
    print(f"  Max time: {max(hit_times):.3f} ms")

    speedup = avg_miss_time / avg_hit_time if avg_hit_time > 0 else 0
    print(f"\nSpeedup: {speedup:.1f}x faster for cache hits")

    print(f"\nCache statistics:")
    print(f"  Total hits: {engine.oracle_cache.hits}")
    print(f"  Total misses: {engine.oracle_cache.misses}")
    print(f"  Hit rate: {engine.oracle_cache.hit_rate:.1%}")

    return speedup


async def main():
    """Run all benchmarks."""
    print("=" * 60)
    print("LRU CACHE PERFORMANCE BENCHMARKING")
    print("=" * 60)

    # Benchmark 1: With vs without cache
    time_without_cache = await benchmark_without_cache()
    time_with_cache = await benchmark_with_cache()

    improvement = time_without_cache / time_with_cache if time_with_cache > 0 else 0

    print("\n" + "=" * 60)
    print("COMPARISON SUMMARY")
    print("=" * 60)
    print(f"\nAvg search time without cache: {time_without_cache:.2f} ms")
    print(f"Avg search time with cache: {time_with_cache:.2f} ms")
    print(f"Performance improvement: {improvement:.1f}x")

    # Benchmark 2: Cache hit vs miss
    speedup = await benchmark_cache_performance()

    # Final summary
    print("\n" + "=" * 60)
    print("FINAL RESULTS")
    print("=" * 60)
    print(f"\n✓ Cache enabled vs disabled: {improvement:.1f}x faster")
    print(f"✓ Cache hit vs miss: {speedup:.1f}x faster")
    print(f"\n⚡ Expected speedup range: 10-50x")
    print(f"✅ Target met: {'YES' if speedup >= 10 else 'NO'}")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
