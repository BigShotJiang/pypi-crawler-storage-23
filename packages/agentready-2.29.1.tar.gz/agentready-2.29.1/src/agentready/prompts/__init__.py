"""LLM prompt templates loaded from package resources."""

from .loader import load_prompt

__all__ = ["load_prompt"]
