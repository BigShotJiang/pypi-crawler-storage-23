"""Fixers for automated remediation of failing attributes."""

from agentready.fixers.base import BaseFixer

__all__ = ["BaseFixer"]
