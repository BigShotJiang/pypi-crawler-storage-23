# pypistats-cli

CLI tool for PyPI package analytics from [pypistats.com](https://pypistats.com).

## Install

```bash
pip install pypistats-cli
```

## Usage

```bash
# Check a package
pypistats check requests
pypistats check fastapi --days 7

# Help
pypistats --help
```

## Optional: API Key

Set `PYPISTATS_API_KEY` for higher rate limits:

```bash
export PYPISTATS_API_KEY=your-key-here
```
