from .generator import generate_report
