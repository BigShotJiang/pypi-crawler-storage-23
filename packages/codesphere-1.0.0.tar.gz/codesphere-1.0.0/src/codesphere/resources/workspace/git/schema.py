from __future__ import annotations

from ....core.base import CamelModel


class GitHead(CamelModel):
    head: str
