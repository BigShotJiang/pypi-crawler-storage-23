"""fixPI — LLM-powered remote Raspberry Pi display repair agent."""
