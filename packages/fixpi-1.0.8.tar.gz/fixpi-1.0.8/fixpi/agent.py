"""Main fixPI agent — orchestrates SSH diagnostics + LLM decision loop."""

import logging
import time
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt, Confirm

from .ssh_client import SSHClient
from .llm_agent import LLMAgent
from .diagnostics import collect_state, format_state_for_llm, DisplayState

log = logging.getLogger("fixPI.agent")
console = Console()


class FixPIAgent:
    """
    LLM-powered agent that:
    1. Connects to RPi via SSH
    2. Collects display diagnostic state
    3. Runs decision tree to identify issues
    4. Uses LLM to decide next action
    5. Executes fixes, reboots, re-diagnoses
    6. Asks user interactively when info is missing
    """

    def __init__(
        self,
        ssh: SSHClient,
        llm: LLMAgent,
        max_reboot_cycles: int = 3,
        interactive: bool = True,
        display_config: Optional[dict] = None,
    ):
        self.ssh = ssh
        self.llm = llm
        self.max_reboot_cycles = max_reboot_cycles
        self.interactive = interactive
        self.display_config = display_config or {}
        self.reboot_count = 0
        self.action_count = 0
        self.max_actions = 30  # Safety limit

    def run(self) -> bool:
        """
        Main agent loop. Returns True if displays are working.
        """
        console.print(Panel(
            "[bold cyan]fixPI — RPi Display Repair Agent[/bold cyan]\n"
            f"Host: {self.ssh.host} | Model: {self.llm.model}\n"
            f"Max reboots: {self.max_reboot_cycles} | Interactive: {self.interactive}",
            title="fixPI",
            border_style="cyan",
        ))

        # ── Step 1: Connect ──────────────────────────────────────────────
        console.print("\n[bold]Step 1:[/bold] Connecting to RPi...")
        if not self.ssh.connect():
            console.print("[red]Failed to connect via SSH. Check credentials.[/red]")
            return False
        console.print("[green]Connected.[/green]")

        # ── Step 2: Initial diagnostics ──────────────────────────────────
        console.print("\n[bold]Step 2:[/bold] Collecting diagnostic data...")
        state = collect_state(self.ssh)
        self._print_state_summary(state)

        # ── Step 3: Quick fixes (decision tree, no LLM needed) ───────────
        console.print("\n[bold]Step 3:[/bold] Applying decision-tree fixes...")
        quick_fixed = self._apply_quick_fixes(state)
        if quick_fixed:
            console.print(f"[yellow]Applied {len(quick_fixed)} quick fixes. Re-collecting state...[/yellow]")
            state = collect_state(self.ssh)
            self._print_state_summary(state)

        # ── Step 4: LLM diagnosis loop ───────────────────────────────────
        if state.issues:
            console.print(f"\n[bold]Step 4:[/bold] {len(state.issues)} issues remain — starting LLM agent loop...")
            return self._llm_loop(state)
        else:
            if state.dsi_detected and state.hdmi_detected:
                console.print("\n[bold green]Both displays detected! No issues found.[/bold green]")
                return True
            elif not state.wlr_randr_output:
                console.print("\n[yellow]Cannot verify displays (no wlr-randr output over SSH).[/yellow]")
                console.print("[yellow]Starting LLM agent to investigate further...[/yellow]")
                return self._llm_loop(state)
            else:
                console.print("\n[bold]Step 4:[/bold] No issues in decision tree but displays incomplete — starting LLM...")
                return self._llm_loop(state)

    def _llm_loop(self, state: DisplayState) -> bool:
        """LLM-driven fix loop."""
        # Build initial context
        diag_report = format_state_for_llm(state)
        display_info = ""
        if self.display_config:
            display_info = f"\n\nUSER DISPLAY CONFIGURATION:\n{self._format_display_config()}"

        initial_prompt = (
            f"I need you to diagnose and fix the display configuration on this Raspberry Pi.\n"
            f"Here is the current diagnostic report:\n\n{diag_report}{display_info}\n\n"
            f"What should we do first? Respond with a JSON action."
        )

        result = self.llm.analyze(initial_prompt)

        while self.action_count < self.max_actions:
            self.action_count += 1
            action = result.get("action", "fail")

            console.print(f"\n[dim]── Action {self.action_count} ──[/dim]")
            console.print(f"[bold]Analysis:[/bold] {result.get('analysis', '?')}")
            console.print(f"[bold]Action:[/bold] [cyan]{action}[/cyan]")

            if action == "done":
                console.print(Panel(
                    f"[green]{result.get('summary', 'Repair complete.')}[/green]",
                    title="Done",
                    border_style="green",
                ))
                return True

            elif action == "fail":
                console.print(Panel(
                    f"[red]{result.get('summary', 'Could not fix the issue.')}[/red]",
                    title="Failed",
                    border_style="red",
                ))
                return False

            elif action == "next_command":
                cmd = result.get("command", "")
                if not cmd:
                    result = self._llm_respond("Error: no command provided. Please provide a command.")
                    continue

                console.print(f"[bold]Command:[/bold] [yellow]{cmd}[/yellow]")

                if self.interactive and self._is_dangerous(cmd):
                    if not Confirm.ask(f"[red]Execute potentially dangerous command?[/red]", default=False):
                        result = self._llm_respond("User declined to run this command. Suggest an alternative.")
                        continue

                exit_code, stdout, stderr = self.ssh.run_sudo(cmd, timeout=60)
                output = f"exit_code={exit_code}\nstdout:\n{stdout}\nstderr:\n{stderr}"
                console.print(f"[dim]{output[:500]}{'...' if len(output) > 500 else ''}[/dim]")

                result = self._llm_respond(
                    f"Command result:\n{output}\n\nWhat should we do next?"
                )

            elif action == "edit_file":
                file_path = result.get("file_path", "")
                file_content = result.get("file_content", "")
                if not file_path or not file_content:
                    result = self._llm_respond("Error: file_path and file_content required for edit_file.")
                    continue

                console.print(f"[bold]Edit file:[/bold] {file_path}")
                console.print(f"[dim]{file_content[:300]}{'...' if len(file_content) > 300 else ''}[/dim]")

                if self.interactive:
                    if not Confirm.ask("Apply this file edit?", default=True):
                        result = self._llm_respond("User declined file edit. Suggest alternative approach.")
                        continue

                success = self.ssh.write_file(file_path, file_content)
                if success:
                    # Verify
                    actual = self.ssh.read_file(file_path) or ""
                    result = self._llm_respond(
                        f"File written successfully. Verification (first 500 chars):\n{actual[:500]}\n\nWhat next?"
                    )
                else:
                    result = self._llm_respond("Failed to write file. What should we try instead?")

            elif action == "reboot":
                if self.reboot_count >= self.max_reboot_cycles:
                    result = self._llm_respond(
                        f"Reboot limit reached ({self.max_reboot_cycles}). "
                        f"Cannot reboot again. Find a different approach or declare failure."
                    )
                    continue

                console.print(f"[yellow]Rebooting RPi... (reboot {self.reboot_count + 1}/{self.max_reboot_cycles})[/yellow]")

                if self.interactive:
                    if not Confirm.ask("Proceed with reboot?", default=True):
                        result = self._llm_respond("User declined reboot. What else can we try?")
                        continue

                self.reboot_count += 1
                if self.ssh.reboot_and_wait():
                    console.print("[green]RPi back online after reboot.[/green]")
                    # Re-collect state
                    state = collect_state(self.ssh)
                    diag_report = format_state_for_llm(state)
                    self._print_state_summary(state)
                    result = self._llm_respond(
                        f"Reboot complete. New diagnostic report:\n\n{diag_report}\n\n"
                        f"Has the issue been resolved? What should we do next?"
                    )
                else:
                    console.print("[red]RPi did not come back after reboot![/red]")
                    # Try to reconnect a few more times
                    for attempt in range(3):
                        console.print(f"[yellow]Retry connect {attempt + 1}/3...[/yellow]")
                        time.sleep(15)
                        if self.ssh.connect():
                            console.print("[green]Reconnected.[/green]")
                            state = collect_state(self.ssh)
                            diag_report = format_state_for_llm(state)
                            result = self._llm_respond(
                                f"Reconnected after delayed reboot. New state:\n\n{diag_report}\n\nWhat next?"
                            )
                            break
                    else:
                        return False

            elif action == "ask_user":
                question = result.get("question", "What additional information do you have?")
                console.print(Panel(f"[bold yellow]{question}[/bold yellow]", title="LLM asks"))
                if self.interactive:
                    answer = Prompt.ask("[cyan]Your answer[/cyan]")
                    result = self._llm_respond(f"User answered: {answer}")
                else:
                    result = self._llm_respond(
                        "Running in non-interactive mode. Skip this question and proceed with best guess."
                    )

            else:
                result = self._llm_respond(
                    f"Unknown action '{action}'. Valid actions: next_command, edit_file, reboot, ask_user, done, fail"
                )

        console.print("[red]Max actions reached. Stopping.[/red]")
        return False

    def _llm_respond(self, message: str) -> dict:
        """Send follow-up to LLM."""
        return self.llm.analyze(message)

    def _apply_quick_fixes(self, state: DisplayState) -> list[str]:
        """
        Apply obvious fixes from decision tree without needing LLM.
        Returns list of fixes applied.
        """
        fixes = []

        # Fix 1: Commented-out DSI overlay
        if "COMMENTED_OVERLAY" in str(state.issues):
            console.print("  [yellow]Fix: Uncommenting DSI overlay in config.txt[/yellow]")
            self.ssh.run_sudo(
                f"sed -i 's/^#\\(dtoverlay=WS_xinchDSI_Screen\\)/\\1/' {state.boot_config_path}"
            )
            self.ssh.run_sudo(
                f"sed -i 's/^#\\(dtoverlay=WS_xinchDSI_Touch\\)/\\1/' {state.boot_config_path}"
            )
            fixes.append("Uncommented DSI overlays")

        # Fix 2: Missing ignore_lcd
        if "NO_IGNORE_LCD" in str(state.issues) and state.has_ws_dsi_overlay:
            console.print("  [yellow]Fix: Adding ignore_lcd=1[/yellow]")
            self.ssh.run_sudo(
                f"sed -i '/dtoverlay=WS_xinchDSI_Screen/i ignore_lcd=1' {state.boot_config_path}"
            )
            fixes.append("Added ignore_lcd=1")

        # Fix 3: Missing i2c_vc
        if "NO_I2C_VC" in str(state.issues):
            console.print("  [yellow]Fix: Adding dtparam=i2c_vc=on[/yellow]")
            self.ssh.run_sudo(
                f"sed -i '/dtoverlay=WS_xinchDSI_Screen/i dtparam=i2c_vc=on' {state.boot_config_path}"
            )
            fixes.append("Added dtparam=i2c_vc=on")

        # Fix 4: Stale entries
        for issue in state.issues:
            if issue.startswith("STALE_ENTRY:"):
                entry = issue.split(": ", 1)[1].split(" still")[0]
                console.print(f"  [yellow]Fix: Removing stale {entry}[/yellow]")
                self.ssh.run_sudo(f"sed -i '/^{entry}/d' {state.boot_config_path}")
                fixes.append(f"Removed stale {entry}")

        # Fix 5: Missing dtbo files
        if "MISSING_DTBO" in str(state.issues) and state.ws_repo_exists:
            console.print("  [yellow]Fix: Copying dtbo files from WaveShare repo[/yellow]")
            # Find best kernel dir
            kern_short = state.kernel.split("+")[0] if "+" in state.kernel else state.kernel
            bits = "64" if state.arch == "aarch64" else "32"
            best_dir = ""
            for d in state.ws_repo_kernel_dirs:
                best_dir = d
                if kern_short.startswith(d):
                    break
            if best_dir:
                src = f"/opt/Waveshare-DSI-LCD/{best_dir}/{bits}/pi3"
                self.ssh.run_sudo(f"cp {src}/*.dtbo {state.overlay_dir}/ 2>/dev/null")
                fixes.append(f"Copied dtbo from {src}")

        return fixes

    def _print_state_summary(self, state: DisplayState):
        """Print a compact summary of display state."""
        dsi_status = "[green]✓[/green]" if state.dsi_detected else "[red]✗[/red]"
        hdmi_status = "[green]✓[/green]" if state.hdmi_detected else "[red]✗[/red]"
        dtbo_status = "[green]✓[/green]" if state.ws_screen_dtbo_exists else "[red]✗[/red]"
        overlay_status = "[green]✓[/green]" if state.has_ws_dsi_overlay else "[red]✗[/red]"

        lines = [
            f"  Kernel: {state.kernel} | OS: {state.os_codename}",
            f"  DSI-1 detected:  {dsi_status}  |  HDMI-A-1 detected: {hdmi_status}",
            f"  DSI dtbo on disk: {dtbo_status}  |  DSI overlay in config: {overlay_status}",
            f"  ignore_lcd=1: {'✓' if state.has_ignore_lcd else '✗'}  |  i2c_vc=on: {'✓' if state.has_i2c_vc else '✗'}",
        ]
        if state.issues:
            lines.append(f"  [red]Issues: {len(state.issues)}[/red]")
            for issue in state.issues[:5]:
                lines.append(f"    ❌ {issue}")
            if len(state.issues) > 5:
                lines.append(f"    ... and {len(state.issues) - 5} more")
        else:
            lines.append("  [green]No issues detected[/green]")

        console.print(Panel("\n".join(lines), title="Display State", border_style="blue"))

    def _format_display_config(self) -> str:
        """Format user's desired display configuration."""
        parts = []
        for key, val in self.display_config.items():
            parts.append(f"  {key}: {val}")
        return "\n".join(parts)

    @staticmethod
    def _is_dangerous(cmd: str) -> bool:
        """Check if command is potentially dangerous."""
        dangerous = ["rm -rf", "mkfs", "dd if=", "wipefs", "> /dev/"]
        return any(d in cmd for d in dangerous)
