"""SSH client with reboot handling and reconnection logic."""

import time
import socket
import logging
from typing import Optional

import paramiko

log = logging.getLogger("fixPI.ssh")


class SSHClient:
    """Manages SSH connection to RPi with reboot/reconnect support."""

    def __init__(
        self,
        host: str,
        user: str,
        password: str,
        port: int = 22,
        timeout: int = 30,
        reboot_wait: int = 90,
        post_reboot_settle: int = 15,
    ):
        self.host = host
        self.user = user
        self.password = password
        self.port = port
        self.timeout = timeout
        self.reboot_wait = reboot_wait
        self.post_reboot_settle = post_reboot_settle
        self._client: Optional[paramiko.SSHClient] = None

    def connect(self) -> bool:
        """Establish SSH connection. Returns True on success."""
        try:
            self.disconnect()
            self._client = paramiko.SSHClient()
            self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self._client.connect(
                hostname=self.host,
                port=self.port,
                username=self.user,
                password=self.password,
                timeout=self.timeout,
                allow_agent=False,
                look_for_keys=False,
            )
            log.info(f"Connected to {self.user}@{self.host}:{self.port}")
            return True
        except Exception as e:
            log.error(f"SSH connect failed: {e}")
            return False

    def disconnect(self):
        """Close SSH connection."""
        if self._client:
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None

    def is_connected(self) -> bool:
        """Check if SSH session is alive."""
        if not self._client:
            return False
        try:
            transport = self._client.get_transport()
            if transport and transport.is_active():
                transport.send_ignore()
                return True
        except Exception:
            pass
        return False

    def run(self, cmd: str, timeout: int = 60, sudo: bool = False) -> tuple[int, str, str]:
        """
        Execute command over SSH.
        Returns (exit_code, stdout, stderr).
        """
        if not self.is_connected():
            if not self.connect():
                return (-1, "", "SSH not connected")

        if sudo and not cmd.startswith("sudo "):
            cmd = f"echo '{self.password}' | sudo -S {cmd}"

        log.debug(f"RUN: {cmd[:120]}{'...' if len(cmd) > 120 else ''}")
        try:
            stdin, stdout, stderr = self._client.exec_command(cmd, timeout=timeout)
            exit_code = stdout.channel.recv_exit_status()
            out = stdout.read().decode("utf-8", errors="replace").strip()
            err = stderr.read().decode("utf-8", errors="replace").strip()
            if exit_code != 0:
                log.debug(f"  exit={exit_code} err={err[:200]}")
            return (exit_code, out, err)
        except Exception as e:
            log.error(f"Command failed: {e}")
            return (-1, "", str(e))

    def run_sudo(self, cmd: str, timeout: int = 60) -> tuple[int, str, str]:
        """Shortcut for sudo commands."""
        return self.run(cmd, timeout=timeout, sudo=True)

    def read_file(self, path: str) -> Optional[str]:
        """Read remote file contents."""
        code, out, err = self.run(f"cat {path}")
        if code == 0:
            return out
        code, out, err = self.run_sudo(f"cat {path}")
        return out if code == 0 else None

    def write_file(self, path: str, content: str) -> bool:
        """Write content to remote file (via sudo tee)."""
        # Escape content for shell
        escaped = content.replace("\\", "\\\\").replace("'", "'\\''")
        code, _, err = self.run_sudo(f"bash -c \"cat > {path} << 'FIXPI_EOF'\n{content}\nFIXPI_EOF\"")
        if code != 0:
            log.error(f"write_file {path} failed: {err}")
        return code == 0

    def file_exists(self, path: str) -> bool:
        """Check if remote file exists."""
        code, _, _ = self.run(f"test -f {path}")
        return code == 0

    def reboot_and_wait(self) -> bool:
        """
        Reboot RPi and wait for SSH to come back.
        Returns True if reconnected successfully.
        """
        log.info(f"Rebooting {self.host}...")
        try:
            self.run_sudo("reboot")
        except Exception:
            pass

        self.disconnect()

        # Wait for host to go down
        log.info(f"Waiting {10}s for host to go down...")
        time.sleep(10)

        # Poll for SSH availability
        log.info(f"Waiting up to {self.reboot_wait}s for host to come back...")
        start = time.time()
        while time.time() - start < self.reboot_wait:
            if self._port_open():
                log.info(f"Port {self.port} open after {int(time.time() - start)}s")
                # Give services time to settle
                log.info(f"Settling {self.post_reboot_settle}s...")
                time.sleep(self.post_reboot_settle)
                if self.connect():
                    log.info("Reconnected after reboot")
                    return True
            time.sleep(5)

        log.error(f"Host did not come back within {self.reboot_wait}s")
        return False

    def _port_open(self) -> bool:
        """Check if SSH port is reachable."""
        try:
            sock = socket.create_connection((self.host, self.port), timeout=5)
            sock.close()
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()
