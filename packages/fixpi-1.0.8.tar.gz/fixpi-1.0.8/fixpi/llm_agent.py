"""LLM agent for fixpi — supports any litellm-compatible provider."""

import json
import logging
import os
import time
from typing import Optional

import litellm

log = logging.getLogger("fixpi.llm")

PROVIDERS: dict[str, dict] = {
    "groq": {
        "env_key": "GROQ_API_KEY",
        "models": [
            "groq/llama-3.3-70b-versatile",
            "groq/llama-3.1-70b-versatile",
            "groq/llama-3.1-8b-instant",
            "groq/mixtral-8x7b-32768",
        ],
        "desc": "Groq — fast inference, generous free tier",
    },
    "openrouter": {
        "env_key": "OPENROUTER_API_KEY",
        "models": [
            "openrouter/google/gemma-3-27b-it:free",
            "openrouter/google/gemini-2.0-flash-exp:free",
            "openrouter/anthropic/claude-3.5-sonnet",
            "openrouter/openai/gpt-4o-mini",
        ],
        "desc": "OpenRouter — multi-model, many free options",
    },
    "anthropic": {
        "env_key": "ANTHROPIC_API_KEY",
        "models": [
            "anthropic/claude-3-5-sonnet-20241022",
            "anthropic/claude-3-haiku-20240307",
        ],
        "desc": "Anthropic Claude — best reasoning",
    },
    "openai": {
        "env_key": "OPENAI_API_KEY",
        "models": ["gpt-4o-mini", "gpt-4o"],
        "desc": "OpenAI GPT — widely supported",
    },
    "gemini": {
        "env_key": "GEMINI_API_KEY",
        "models": [
            "gemini/gemini-2.0-flash-exp",
            "gemini/gemini-1.5-pro",
        ],
        "desc": "Google Gemini — large context window",
    },
    "ollama": {
        "env_key": None,
        "models": [
            "ollama/llama3.2",
            "ollama/qwen2.5-coder",
            "ollama/phi3",
        ],
        "desc": "Ollama — local, no API key required",
    },
    "mistral": {
        "env_key": "MISTRAL_API_KEY",
        "models": [
            "mistral/mistral-small-latest",
            "mistral/mistral-large-latest",
        ],
        "desc": "Mistral AI — efficient European models",
    },
}

SYSTEM_PROMPT = """\
You are an expert Linux/Raspberry Pi system configuration assistant for fixpi.
You help diagnose and fix display, hardware, and OS configuration issues remotely via SSH.

HARDWARE CONTEXT (configurable):
- Target device: Raspberry Pi 3 (BCM2837, aarch64) running Debian Trixie, kernel 6.12.x
- DSI display: WaveShare 7.9" — overlay vc4-kms-dsi-waveshare-panel,7_9_inch (mainline, kernel 6.12+)
  - 400x1280 native portrait, Transform:90 by Wayland compositor
  - Touch via goodix/ilitek built-in mainline overlay
- HDMI display: auto-detect via hdmi_force_hotplug=1
- Boot config: /boot/firmware/config.txt
- Overlays: /boot/firmware/overlays/
- Compositor: Wayland (labwc or wayfire)

KEY FACTS:
- panel-waveshare-dsi.ko is built into kernel 6.12+ — no WaveShare repo .ko needed
- vc4-kms-v3d must be active (not commented out)
- display_auto_detect=1 conflicts with manual DSI overlay — disable it
- wlr-randr shows outputs: WAYLAND_DISPLAY + XDG_RUNTIME_DIR required over SSH

RESPONSE FORMAT — always valid JSON:
{
  "analysis": "brief analysis",
  "action": "next_command" | "edit_file" | "reboot" | "ask_user" | "done" | "fail",
  "command": "shell command (if action=next_command)",
  "file_path": "/path/to/file (if action=edit_file)",
  "file_content": "full new content (if action=edit_file)",
  "question": "question for user (if action=ask_user)",
  "summary": "result summary (if action=done or fail)"
}
"""


def _detect_provider(model: str) -> Optional[str]:
    """Detect provider name from model string prefix."""
    for provider in PROVIDERS:
        if model.startswith(f"{provider}/"):
            return provider
    return None


def normalize_model(model: str) -> str:
    """
    Normalize litellm model name.
    Fixes double-prefix like groq/groq/llama-... → groq/llama-...
    """
    for provider in PROVIDERS:
        double = f"{provider}/{provider}/"
        if model.startswith(double):
            model = f"{provider}/{model[len(double):]}"
            log.debug(f"Normalized model: {model}")
            break
    return model


def set_api_key(model: str, api_key: Optional[str]) -> None:
    """Set the correct environment variable for the detected provider."""
    if not api_key:
        return
    provider = _detect_provider(model)
    if provider and PROVIDERS[provider]["env_key"]:
        env_key = PROVIDERS[provider]["env_key"]
        os.environ[env_key] = api_key
        log.debug(f"Set {env_key} for provider={provider}")
    else:
        # Fallback — try to detect from common env var names passed in
        litellm.api_key = api_key


class LLMAgent:
    """LLM-powered diagnostic agent using litellm (any provider)."""

    def __init__(self, model: str, api_key: Optional[str] = None):
        self.model = normalize_model(model)
        set_api_key(self.model, api_key)

        # Also load any provider keys already in environment
        for prov, cfg in PROVIDERS.items():
            env_key = cfg["env_key"]
            if env_key and os.environ.get(env_key):
                log.debug(f"Found existing env {env_key}")

        self.messages: list[dict] = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.max_history = 40
        self._supports_json_format = self._check_json_format_support()

    def _check_json_format_support(self) -> bool:
        """Some providers don't support response_format=json_object."""
        unsupported = ("ollama/", "groq/", "mistral/")
        return not any(self.model.startswith(p) for p in unsupported)

    def analyze(self, context: str) -> dict:
        """Send context to LLM, get structured JSON action response."""
        self.messages.append({"role": "user", "content": context})
        self._trim_history()

        kwargs: dict = {
            "model": self.model,
            "messages": self.messages,
            "temperature": 0.1,
            "max_tokens": 2000,
        }
        if self._supports_json_format:
            kwargs["response_format"] = {"type": "json_object"}

        for attempt in range(5):
            try:
                log.debug(f"LLM ({self.model}) attempt {attempt + 1}")
                response = litellm.completion(**kwargs)
                content = response.choices[0].message.content.strip()
                self.messages.append({"role": "assistant", "content": content})
                return self._parse_json(content)

            except Exception as e:
                msg = str(e)
                if "429" in msg or "rate" in msg.lower():
                    wait = 2 ** (attempt + 1)
                    log.warning(f"Rate limited — retrying in {wait}s")
                    time.sleep(wait)
                    continue
                log.error(f"LLM error: {e}")
                return {"analysis": f"LLM error: {e}", "action": "fail", "summary": msg}

        return {
            "analysis": "Rate limit — all retries exhausted",
            "action": "fail",
            "summary": "Try a different model or wait before retrying",
        }

    def _parse_json(self, content: str) -> dict:
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            for delim in ("```json", "```"):
                if delim in content:
                    try:
                        inner = content.split(delim)[1].split("```")[0].strip()
                        return json.loads(inner)
                    except Exception:
                        pass
            log.error(f"Non-JSON from LLM: {content[:200]}")
            return {"analysis": "LLM returned non-JSON", "action": "fail", "summary": content[:500]}

    def add_context(self, role: str, content: str) -> None:
        self.messages.append({"role": role, "content": content})

    def _trim_history(self) -> None:
        if len(self.messages) > self.max_history:
            system = self.messages[0]
            self.messages = [system] + self.messages[-(self.max_history - 1):]
