"""fixPI CLI shell — interactive menu using clickmd."""

import os
import sys
from pathlib import Path
from typing import Optional

# Add clickmd dev path if not installed globally
_dev_paths = [
    Path(__file__).parents[4] / "wronai/contract",  # ~/github/wronai/contract
    Path.home() / "github/wronai/contract",
]
for _p in _dev_paths:
    if (_p / "clickmd").exists() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
        break

import clickmd

from .llm_agent import PROVIDERS, LLMAgent, normalize_model, set_api_key


# ── Config helpers ────────────────────────────────────────────────────────────

def _load_env(env_path: Path) -> dict:
    """Load key=value pairs from .env file."""
    cfg: dict = {}
    if not env_path.exists():
        return cfg
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            cfg[k.strip()] = v.strip()
    return cfg


def _save_env(env_path: Path, cfg: dict) -> None:
    """Write cfg to .env file, preserving comments from existing file."""
    existing_lines: list[str] = []
    if env_path.exists():
        existing_lines = env_path.read_text().splitlines()

    written_keys: set = set()
    new_lines: list[str] = []

    for line in existing_lines:
        stripped = line.strip()
        if stripped.startswith("#") or not stripped:
            new_lines.append(line)
            continue
        if "=" in stripped:
            k = stripped.split("=", 1)[0].strip()
            if k in cfg:
                new_lines.append(f"{k}={cfg[k]}")
                written_keys.add(k)
            else:
                new_lines.append(line)
        else:
            new_lines.append(line)

    # Append new keys not in original file
    for k, v in cfg.items():
        if k not in written_keys:
            new_lines.append(f"{k}={v}")

    env_path.write_text("\n".join(new_lines) + "\n")


def _get_env_path() -> Path:
    return Path(__file__).parent / ".env"


# ── LLM config wizard ─────────────────────────────────────────────────────────

def _configure_llm(cfg: dict) -> dict:
    """Interactive LLM configuration wizard. Returns updated cfg."""
    clickmd.md("---\n## Configure LLM Provider\n")

    current_model = cfg.get("LLM_MODEL", "")
    if current_model:
        clickmd.md(f"> Current: `{current_model}`\n")

    provider_list = [
        (name, info["desc"]) for name, info in PROVIDERS.items()
    ]
    choice = clickmd.menu("### Select Provider", provider_list, exit_option="Cancel")
    if choice == 0:
        return cfg

    provider_name = list(PROVIDERS.keys())[choice - 1]
    provider_info = PROVIDERS[provider_name]

    clickmd.md(f"\n### Select Model (`{provider_name}`)\n")
    models = provider_info["models"]
    model_choice = clickmd.menu(
        f"Models for {provider_name}",
        models + ["Enter custom model name"],
        exit_option="Back",
    )
    if model_choice == 0:
        return cfg

    if model_choice == len(models) + 1:
        custom = clickmd.prompt("Custom model name (e.g. groq/llama-3.3-70b-versatile)")
        model = normalize_model(str(custom))
    else:
        model = models[model_choice - 1]

    cfg["LLM_MODEL"] = model
    clickmd.md(f"\n> Model set: `{model}`\n")

    # API key
    env_key = provider_info.get("env_key")
    if env_key:
        existing_key = cfg.get(env_key, os.environ.get(env_key, ""))
        masked = f"{existing_key[:8]}..." if len(existing_key) > 8 else existing_key
        prompt_text = f"API key ({env_key})" + (f" [current: {masked}]" if existing_key else "")
        new_key = clickmd.prompt(prompt_text, default=existing_key, hide_input=True)
        if new_key and new_key != existing_key:
            cfg[env_key] = str(new_key)
            set_api_key(model, str(new_key))
    else:
        clickmd.md(f"> `{provider_name}` — no API key required (local)\n")

    clickmd.md(f"\n✅ LLM configured: `{model}`\n")
    return cfg


# ── SSH config wizard ─────────────────────────────────────────────────────────

def _configure_ssh(cfg: dict) -> dict:
    """Interactive SSH configuration wizard."""
    clickmd.md("---\n## Configure SSH Connection\n")

    host = clickmd.prompt("Host or IP", default=cfg.get("RPI_HOST", "raspberrypi"))
    user = clickmd.prompt("Username", default=cfg.get("RPI_USER", "pi"))
    password = clickmd.prompt("Password", default=cfg.get("RPI_PASSWORD", ""), hide_input=True)
    port = clickmd.prompt("Port", default=cfg.get("RPI_PORT", "22"))

    cfg["RPI_HOST"] = str(host)
    cfg["RPI_USER"] = str(user)
    cfg["RPI_PASSWORD"] = str(password)
    cfg["RPI_PORT"] = str(port)

    clickmd.md(
        f"\n✅ SSH configured:\n"
        f"- Host: `{host}`\n"
        f"- User: `{user}`\n"
        f"- Port: `{port}`\n"
    )
    return cfg


# ── View config ───────────────────────────────────────────────────────────────

def _show_config(cfg: dict) -> None:
    """Display current configuration as markdown table."""
    clickmd.md("---\n## Current Configuration\n")
    if not cfg:
        clickmd.md("> No configuration loaded. Create a `.env` file.\n")
        return

    rows = []
    sensitive = {"RPI_PASSWORD", "OPENROUTER_API_KEY", "GROQ_API_KEY",
                 "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY",
                 "MISTRAL_API_KEY"}
    for k, v in sorted(cfg.items()):
        masked = f"{v[:8]}..." if k in sensitive and len(v) > 8 else v
        rows.append((k, masked))

    clickmd.table(["Key", "Value"], rows)


# ── Test LLM connection ───────────────────────────────────────────────────────

def _test_llm(cfg: dict) -> None:
    """Send a test prompt to the configured LLM."""
    model = cfg.get("LLM_MODEL")
    if not model:
        clickmd.md("> ❌ No `LLM_MODEL` configured.\n")
        return

    model = normalize_model(model)
    # Set API key from cfg
    for prov, info in PROVIDERS.items():
        env_key = info.get("env_key")
        if env_key and env_key in cfg:
            os.environ[env_key] = cfg[env_key]

    clickmd.md(f"\n## Testing LLM: `{model}`\n\nSending test prompt...\n")
    try:
        import litellm
        resp = litellm.completion(
            model=model,
            messages=[{"role": "user", "content": "Reply with exactly: OK"}],
            max_tokens=10,
            temperature=0,
        )
        answer = resp.choices[0].message.content.strip()
        clickmd.md(f"✅ **LLM test passed** — response: `{answer}`\n")
    except Exception as e:
        clickmd.md(f"❌ **LLM test failed**: `{e}`\n")


# ── Run agent ─────────────────────────────────────────────────────────────────

def _run_agent(cfg: dict, diagnose_only: bool = False) -> None:
    """Launch the fixpi repair agent."""
    required = ["RPI_HOST", "RPI_USER", "RPI_PASSWORD", "LLM_MODEL"]
    missing = [k for k in required if not cfg.get(k)]
    if missing:
        clickmd.md(f"\n❌ Missing config: `{', '.join(missing)}`\n\nRun **Configure SSH** and **Configure LLM** first.\n")
        return

    clickmd.md(
        f"---\n## Running fixpi Agent\n\n"
        f"- **Host**: `{cfg.get('RPI_HOST')}`\n"
        f"- **Model**: `{cfg.get('LLM_MODEL')}`\n"
        f"- **Mode**: {'Diagnostics only' if diagnose_only else 'Diagnose & Fix'}\n"
    )

    # Set all provider API keys from cfg
    for prov, info in PROVIDERS.items():
        env_key = info.get("env_key")
        if env_key and env_key in cfg:
            os.environ[env_key] = cfg[env_key]

    try:
        from .ssh_client import SSHClient
        from .agent import FixPIAgent
    except ImportError as _e:
        clickmd.md(f"> ❌ import error: `{_e}`\n")
        return

    model = normalize_model(cfg["LLM_MODEL"])
    api_key = None
    provider = None
    for prov, info in PROVIDERS.items():
        if model.startswith(f"{prov}/"):
            provider = prov
            env_key = info.get("env_key")
            api_key = cfg.get(env_key, "") if env_key else None
            break

    ssh = SSHClient(
        host=cfg["RPI_HOST"],
        user=cfg["RPI_USER"],
        password=cfg["RPI_PASSWORD"],
        port=int(cfg.get("RPI_PORT", 22)),
        timeout=int(cfg.get("SSH_TIMEOUT", 30)),
        reboot_wait=int(cfg.get("REBOOT_WAIT", 90)),
        post_reboot_settle=int(cfg.get("POST_REBOOT_SETTLE", 15)),
    )
    llm = LLMAgent(model=model, api_key=api_key)
    agent = FixPIAgent(
        ssh=ssh,
        llm=llm,
        max_reboot_cycles=int(cfg.get("MAX_REBOOT_CYCLES", 3)),
        interactive=cfg.get("INTERACTIVE", "true").lower() in ("true", "1"),
        display_config={k: v for k, v in cfg.items() if k.startswith(("DSI_", "HDMI_"))},
    )

    try:
        success = agent.run()
        if success:
            clickmd.md("\n✅ **Agent completed successfully.**\n")
        else:
            clickmd.md("\n⚠️ **Agent finished with issues.** Check logs above.\n")
    except KeyboardInterrupt:
        clickmd.md("\n> Interrupted by user.\n")
        ssh.disconnect()


# ── Main interactive shell ────────────────────────────────────────────────────

def run_shell(env_path: Optional[Path] = None) -> None:
    """
    Launch the fixpi interactive menu shell.
    Loads config from .env, saves changes on exit.
    """
    if env_path is None:
        env_path = _get_env_path()

    cfg = _load_env(env_path)
    cfg_changed = False

    clickmd.md(
        "# fixpi — Remote OS Repair Agent\n\n"
        f"Config: `{env_path}`  \n"
        f"LLM: `{cfg.get('LLM_MODEL', 'not configured')}`  \n"
        f"Host: `{cfg.get('RPI_HOST', 'not configured')}`\n"
    )

    while True:
        choice = clickmd.menu(
            "## Main Menu",
            [
                ("run", "Run agent — diagnose & fix"),
                ("diagnose", "Diagnostics only — no changes"),
                ("test-llm", "Test LLM connection"),
                ("config-llm", "Configure LLM provider & model"),
                ("config-ssh", "Configure SSH connection"),
                ("show-config", "View current configuration"),
                ("save", f"Save config → {env_path.name}"),
            ],
            exit_option="Exit",
            default=1,
        )

        if choice == 0:
            if cfg_changed:
                if clickmd.confirm(f"Save changes to {env_path.name}?", default=True):
                    _save_env(env_path, cfg)
                    clickmd.md(f"\n✅ Config saved to `{env_path}`\n")
            clickmd.md("\nGoodbye.\n")
            break

        elif choice == 1:
            _run_agent(cfg, diagnose_only=False)

        elif choice == 2:
            _run_agent(cfg, diagnose_only=True)

        elif choice == 3:
            _test_llm(cfg)

        elif choice == 4:
            cfg = _configure_llm(cfg)
            cfg_changed = True

        elif choice == 5:
            cfg = _configure_ssh(cfg)
            cfg_changed = True

        elif choice == 6:
            _show_config(cfg)

        elif choice == 7:
            _save_env(env_path, cfg)
            cfg_changed = False
            clickmd.md(f"\n✅ Config saved to `{env_path}`\n")
