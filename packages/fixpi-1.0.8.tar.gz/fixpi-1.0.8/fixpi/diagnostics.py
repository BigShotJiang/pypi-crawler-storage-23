"""Decision-tree based RPi display diagnostics — runs before/alongside LLM."""

import logging
from dataclasses import dataclass, field
from typing import Optional

from .ssh_client import SSHClient

log = logging.getLogger("fixPI.diag")


@dataclass
class DisplayState:
    """Collected diagnostic state from RPi."""
    # System
    kernel: str = ""
    arch: str = ""
    os_codename: str = ""
    boot_config_path: str = ""
    overlay_dir: str = ""

    # config.txt
    config_txt: str = ""
    has_ws_dsi_overlay: bool = False
    has_ignore_lcd: bool = False
    has_i2c_vc: bool = False
    has_hdmi_config: bool = False
    dsi_overlay_commented: bool = False

    # Overlays on disk
    ws_screen_dtbo_exists: bool = False
    ws_touch_dtbo_exists: bool = False
    dtbo_files: list[str] = field(default_factory=list)

    # Runtime
    wlr_randr_output: str = ""
    dsi_detected: bool = False
    hdmi_detected: bool = False
    hdmi_resolution: str = ""
    dmesg_dsi: str = ""
    dmesg_drm: str = ""
    lsmod_dsi: str = ""
    vclog: str = ""

    # WaveShare repo
    ws_repo_exists: bool = False
    ws_repo_kernel_dirs: list[str] = field(default_factory=list)

    # Errors found
    issues: list[str] = field(default_factory=list)
    fixes_applied: list[str] = field(default_factory=list)


def collect_state(ssh: SSHClient) -> DisplayState:
    """Gather all diagnostic information from RPi."""
    s = DisplayState()

    # ── System info ──────────────────────────────────────────────────────
    _, s.kernel, _ = ssh.run("uname -r")
    _, s.arch, _ = ssh.run("uname -m")
    _, s.os_codename, _ = ssh.run("bash -c '. /etc/os-release && echo $VERSION_CODENAME'")

    # Boot config location
    if ssh.file_exists("/boot/firmware/config.txt"):
        s.boot_config_path = "/boot/firmware/config.txt"
        s.overlay_dir = "/boot/firmware/overlays"
    elif ssh.file_exists("/boot/config.txt"):
        s.boot_config_path = "/boot/config.txt"
        s.overlay_dir = "/boot/overlays"

    log.info(f"System: kernel={s.kernel} arch={s.arch} os={s.os_codename}")
    log.info(f"Boot config: {s.boot_config_path}")

    # ── config.txt analysis ──────────────────────────────────────────────
    s.config_txt = ssh.read_file(s.boot_config_path) or ""
    for line in s.config_txt.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            if "WS_xinchDSI_Screen" in stripped:
                s.dsi_overlay_commented = True
            continue
        if "WS_xinchDSI_Screen" in stripped and "dtoverlay=" in stripped:
            s.has_ws_dsi_overlay = True
        if stripped.startswith("ignore_lcd=1"):
            s.has_ignore_lcd = True
        if "i2c_vc=on" in stripped:
            s.has_i2c_vc = True
        if "hdmi_force_hotplug" in stripped or "hdmi_timings=" in stripped:
            s.has_hdmi_config = True

    # ── Overlay files on disk ────────────────────────────────────────────
    _, out, _ = ssh.run(f"ls {s.overlay_dir}/WS_xinchDSI_*.dtbo 2>/dev/null")
    s.dtbo_files = [f for f in out.splitlines() if f.strip()]
    s.ws_screen_dtbo_exists = any("Screen" in f for f in s.dtbo_files)
    s.ws_touch_dtbo_exists = any("Touch" in f for f in s.dtbo_files)

    # ── WaveShare repo ───────────────────────────────────────────────────
    code, _, _ = ssh.run("test -d /opt/Waveshare-DSI-LCD")
    s.ws_repo_exists = code == 0
    if s.ws_repo_exists:
        _, dirs, _ = ssh.run("ls /opt/Waveshare-DSI-LCD | grep -E '^[0-9]+\\.[0-9]+' | sort -V")
        s.ws_repo_kernel_dirs = [d.strip() for d in dirs.splitlines() if d.strip()]

    # ── Runtime display state ────────────────────────────────────────────
    # wlr-randr needs WAYLAND_DISPLAY — try common values
    wlr_out = ""
    for wayland_disp in ["wayland-1", "wayland-0"]:
        code, out, _ = ssh.run(
            f"WAYLAND_DISPLAY={wayland_disp} XDG_RUNTIME_DIR=/run/user/$(id -u) wlr-randr 2>/dev/null"
        )
        if code == 0 and out.strip():
            wlr_out = out
            break
    # Also try as the kiosk user
    if not wlr_out:
        _, user, _ = ssh.run("echo $SUDO_USER")
        user = user.strip() or "tom"
        _, uid, _ = ssh.run(f"id -u {user}")
        uid = uid.strip()
        if uid:
            for wayland_disp in ["wayland-1", "wayland-0"]:
                code, out, _ = ssh.run(
                    f"sudo -u {user} WAYLAND_DISPLAY={wayland_disp} "
                    f"XDG_RUNTIME_DIR=/run/user/{uid} wlr-randr 2>/dev/null"
                )
                if code == 0 and out.strip():
                    wlr_out = out
                    break

    s.wlr_randr_output = wlr_out
    s.dsi_detected = "DSI-1" in wlr_out or "DSI" in wlr_out
    s.hdmi_detected = "HDMI-A-1" in wlr_out or "HDMI" in wlr_out

    if s.hdmi_detected:
        # Extract current HDMI resolution
        for line in wlr_out.splitlines():
            if "current" in line and "px" in line:
                s.hdmi_resolution = line.strip().split(" px")[0].strip()
                break

    # ── Kernel logs ──────────────────────────────────────────────────────
    _, s.dmesg_dsi, _ = ssh.run_sudo("dmesg | grep -i 'dsi\\|mipi' | tail -20")
    _, s.dmesg_drm, _ = ssh.run_sudo("dmesg | grep -i 'drm\\|display\\|hdmi\\|panel' | tail -30")
    _, s.lsmod_dsi, _ = ssh.run("lsmod | grep -iE 'dsi|panel|ili|ws|touch|goodix|i2c'")
    _, s.vclog, _ = ssh.run_sudo("vclog --msg 2>/dev/null | tail -20")

    # ── Identify issues ──────────────────────────────────────────────────
    _analyze_issues(s)

    return s


def _analyze_issues(s: DisplayState):
    """Populate s.issues based on collected state."""
    if not s.boot_config_path:
        s.issues.append("CRITICAL: Cannot find /boot/firmware/config.txt or /boot/config.txt")
        return

    if not s.ws_screen_dtbo_exists:
        s.issues.append("MISSING_DTBO: WS_xinchDSI_Screen.dtbo not in overlay dir")

    if not s.ws_touch_dtbo_exists:
        s.issues.append("MISSING_DTBO: WS_xinchDSI_Touch.dtbo not in overlay dir")

    if s.dsi_overlay_commented and not s.has_ws_dsi_overlay:
        s.issues.append("COMMENTED_OVERLAY: dtoverlay=WS_xinchDSI_Screen is commented out in config.txt")

    if not s.has_ws_dsi_overlay:
        s.issues.append("NO_DSI_OVERLAY: dtoverlay=WS_xinchDSI_Screen not active in config.txt")

    if not s.has_ignore_lcd:
        s.issues.append("NO_IGNORE_LCD: ignore_lcd=1 missing — display_auto_detect may conflict")

    if not s.has_i2c_vc:
        s.issues.append("NO_I2C_VC: dtparam=i2c_vc=on missing — touch I2C won't work")

    if not s.dsi_detected and s.has_ws_dsi_overlay and s.ws_screen_dtbo_exists:
        s.issues.append("DSI_NOT_DETECTED: Overlay configured and dtbo exists but DSI-1 not in wlr-randr — possible hardware or kernel issue")

    if s.dsi_detected and not s.hdmi_detected:
        s.issues.append("HDMI_NOT_DETECTED: DSI works but HDMI-A-1 not detected")

    if not s.dsi_detected and not s.hdmi_detected and not s.wlr_randr_output:
        s.issues.append("NO_WLR_RANDR: Could not get wlr-randr output — Wayland compositor may not be running")

    # Check for stale entries
    stale_patterns = ["framebuffer_width=400", "framebuffer_height=1280", "display_lcd_rotate=0"]
    for pat in stale_patterns:
        if pat in s.config_txt:
            active = any(
                line.strip() == pat
                for line in s.config_txt.splitlines()
                if not line.strip().startswith("#")
            )
            if active:
                s.issues.append(f"STALE_ENTRY: {pat} still active in config.txt (from old script run)")


def format_state_for_llm(s: DisplayState) -> str:
    """Format diagnostic state as context string for LLM."""
    parts = [
        "=== RPi Display Diagnostic Report ===",
        f"Kernel: {s.kernel}",
        f"Arch: {s.arch}",
        f"OS: {s.os_codename}",
        f"Boot config: {s.boot_config_path}",
        "",
        "--- config.txt analysis ---",
        f"DSI overlay active: {s.has_ws_dsi_overlay}",
        f"DSI overlay commented out: {s.dsi_overlay_commented}",
        f"ignore_lcd=1: {s.has_ignore_lcd}",
        f"dtparam=i2c_vc=on: {s.has_i2c_vc}",
        f"HDMI config present: {s.has_hdmi_config}",
        "",
        "--- Overlay files ---",
        f"WS_xinchDSI_Screen.dtbo exists: {s.ws_screen_dtbo_exists}",
        f"WS_xinchDSI_Touch.dtbo exists: {s.ws_touch_dtbo_exists}",
        f"dtbo files: {s.dtbo_files}",
        "",
        "--- WaveShare repo ---",
        f"Repo exists: {s.ws_repo_exists}",
        f"Available kernel dirs: {s.ws_repo_kernel_dirs}",
        "",
        "--- Runtime (wlr-randr) ---",
        f"DSI-1 detected: {s.dsi_detected}",
        f"HDMI-A-1 detected: {s.hdmi_detected}",
        f"HDMI resolution: {s.hdmi_resolution}",
        "wlr-randr output:",
        s.wlr_randr_output or "(empty — compositor not running or not accessible via SSH)",
        "",
        "--- Kernel logs (dmesg DSI/MIPI) ---",
        s.dmesg_dsi or "(no DSI/MIPI messages)",
        "",
        "--- Kernel logs (dmesg DRM/display) ---",
        s.dmesg_drm or "(no DRM messages)",
        "",
        "--- Loaded modules ---",
        s.lsmod_dsi or "(no relevant modules loaded)",
        "",
        "--- vclog ---",
        s.vclog or "(vclog not available)",
        "",
        "--- config.txt (full) ---",
        s.config_txt,
        "",
    ]

    if s.issues:
        parts.append("=== ISSUES FOUND ===")
        for issue in s.issues:
            parts.append(f"  ❌ {issue}")
    else:
        parts.append("=== NO ISSUES DETECTED ===")

    return "\n".join(parts)
