"""fixPI entry point — python -m fixpi [run|config|diagnose|test|list-models]"""

import sys
from pathlib import Path

# Add clickmd dev path if not installed as a package
for _p in [Path(__file__).parents[3] / "wronai/contract", Path.home() / "github/wronai/contract"]:
    if (_p / "clickmd").exists() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
        break

import clickmd
from dotenv import load_dotenv


def _find_env() -> Path:
    for p in [Path(__file__).parent / ".env", Path(__file__).parent.parent / ".env"]:
        if p.exists():
            return p
    return Path(__file__).parent / ".env"


@clickmd.group(cls=clickmd.MarkdownGroup, invoke_without_command=True)
@clickmd.version_option("1.0.2", prog_name="fixpi")
@clickmd.pass_context
def cli(ctx: clickmd.Context) -> None:
    """
    # fixPI — Remote OS Repair Agent

    SSH into any Linux device and use an LLM to diagnose and fix issues.
    Supports **any litellm provider**: Groq, OpenRouter, Anthropic, OpenAI, Gemini, Ollama.

    ## Usage

    ```bash
    fixpi                # interactive menu shell (default)
    fixpi run            # run agent with .env config
    fixpi diagnose       # diagnostics only, no changes
    fixpi config         # configure LLM & SSH
    fixpi test           # test LLM connection
    fixpi list-models    # show all supported models
    ```

    ## Quick start

    ```bash
    cp .env.example .env   # fill in SSH + LLM credentials
    fixpi
    ```
    """
    env_path = _find_env()
    load_dotenv(env_path)
    ctx.ensure_object(dict)
    ctx.obj["env_path"] = env_path

    if ctx.invoked_subcommand is None:
        from .cli import run_shell
        run_shell(env_path)


@cli.command(cls=clickmd.MarkdownCommand)
@clickmd.pass_context
def run(ctx: clickmd.Context) -> None:
    """
    ## Run fixPI Agent

    Connect via SSH and run the LLM-powered repair loop.
    Uses settings from `.env` file.
    """
    from .cli import _load_env, _run_agent
    _run_agent(_load_env(ctx.obj["env_path"]), diagnose_only=False)


@cli.command(cls=clickmd.MarkdownCommand)
@clickmd.pass_context
def diagnose(ctx: clickmd.Context) -> None:
    """
    ## Diagnostics Only

    Collect device state and show LLM analysis — **no changes applied**.
    """
    from .cli import _load_env, _run_agent
    _run_agent(_load_env(ctx.obj["env_path"]), diagnose_only=True)


@cli.command(cls=clickmd.MarkdownCommand)
@clickmd.pass_context
def config(ctx: clickmd.Context) -> None:
    """
    ## Configure fixPI

    Interactive wizard: set LLM provider, model, API key and SSH connection.
    """
    from .cli import _load_env, _configure_llm, _configure_ssh, _save_env
    env_path = ctx.obj["env_path"]
    cfg = _load_env(env_path)
    choice = clickmd.menu(
        "## Configure",
        [("llm", "LLM provider & model"), ("ssh", "SSH connection")],
        exit_option="Cancel",
    )
    if choice == 1:
        cfg = _configure_llm(cfg)
    elif choice == 2:
        cfg = _configure_ssh(cfg)
    if choice in (1, 2) and clickmd.confirm(f"Save to {env_path.name}?", default=True):
        _save_env(env_path, cfg)
        clickmd.md(f"\n✅ Saved to `{env_path}`\n")


@cli.command(cls=clickmd.MarkdownCommand)
@clickmd.pass_context
def test(ctx: clickmd.Context) -> None:
    """
    ## Test LLM Connection

    Send a test prompt to verify the configured LLM works.
    """
    from .cli import _load_env, _test_llm
    _test_llm(_load_env(ctx.obj["env_path"]))


@cli.command(name="list-models", cls=clickmd.MarkdownCommand)
def list_models() -> None:
    """
    ## Available LLM Models

    Lists all supported providers and their preset models.
    """
    from .llm_agent import PROVIDERS
    rows = []
    for provider, info in PROVIDERS.items():
        for model in info["models"]:
            rows.append((provider, model, info.get("env_key") or "—"))
    clickmd.md("## Supported LLM Providers & Models\n")
    clickmd.table(["Provider", "Model", "Env key"], rows)


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
