"""Unit tests for fixpi.cli — config load/save helpers, no I/O required."""

import sys
import pytest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))

from fixpi.cli import _load_env, _save_env, _get_env_path


class TestLoadEnv:
    def test_missing_file_returns_empty(self, tmp_path):
        result = _load_env(tmp_path / "nonexistent.env")
        assert result == {}

    def test_parses_key_value(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("FOO=bar\nBAZ=qux\n")
        result = _load_env(env)
        assert result["FOO"] == "bar"
        assert result["BAZ"] == "qux"

    def test_ignores_comments(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("# comment\nFOO=bar\n")
        result = _load_env(env)
        assert "# comment" not in result
        assert result["FOO"] == "bar"

    def test_ignores_blank_lines(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("\nFOO=bar\n\nBAZ=qux\n")
        result = _load_env(env)
        assert len(result) == 2

    def test_value_with_equals(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("KEY=val=ue\n")
        result = _load_env(env)
        assert result["KEY"] == "val=ue"


class TestSaveEnv:
    def test_saves_new_file(self, tmp_path):
        path = tmp_path / ".env"
        _save_env(path, {"A": "1", "B": "2"})
        content = path.read_text()
        assert "A=1" in content
        assert "B=2" in content

    def test_updates_existing_key(self, tmp_path):
        path = tmp_path / ".env"
        path.write_text("KEY=old\n")
        _save_env(path, {"KEY": "new"})
        content = path.read_text()
        assert "KEY=new" in content
        assert "KEY=old" not in content

    def test_preserves_comments(self, tmp_path):
        path = tmp_path / ".env"
        path.write_text("# My comment\nKEY=old\n")
        _save_env(path, {"KEY": "new"})
        content = path.read_text()
        assert "# My comment" in content

    def test_round_trip(self, tmp_path):
        path = tmp_path / ".env"
        original = {"HOST": "rpi", "USER": "pi", "MODEL": "groq/llama-3.3-70b-versatile"}
        _save_env(path, original)
        loaded = _load_env(path)
        assert loaded == original
