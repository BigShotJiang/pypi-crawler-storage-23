"""Unit tests for fixpi.llm_agent — no LLM API calls required."""

import pytest
import sys
from pathlib import Path

# Allow running without installing the package
sys.path.insert(0, str(Path(__file__).parents[1]))

from fixpi.llm_agent import normalize_model, set_api_key, PROVIDERS, LLMAgent


class TestNormalizeModel:
    def test_double_groq_prefix(self):
        assert normalize_model("groq/groq/llama-3.3-70b-versatile") == "groq/llama-3.3-70b-versatile"

    def test_double_openrouter_prefix(self):
        assert normalize_model("openrouter/openrouter/gpt-4o") == "openrouter/gpt-4o"

    def test_double_anthropic_prefix(self):
        assert normalize_model("anthropic/anthropic/claude-3-haiku") == "anthropic/claude-3-haiku"

    def test_already_correct(self):
        assert normalize_model("groq/llama-3.3-70b-versatile") == "groq/llama-3.3-70b-versatile"

    def test_openai_no_prefix(self):
        assert normalize_model("gpt-4o-mini") == "gpt-4o-mini"

    def test_ollama(self):
        assert normalize_model("ollama/llama3.2") == "ollama/llama3.2"

    def test_unknown_model_unchanged(self):
        assert normalize_model("some/custom/model") == "some/custom/model"


class TestProviders:
    def test_all_providers_have_models(self):
        for name, info in PROVIDERS.items():
            assert len(info["models"]) > 0, f"{name} has no models"

    def test_groq_has_api_key(self):
        assert PROVIDERS["groq"]["env_key"] == "GROQ_API_KEY"

    def test_ollama_has_no_key(self):
        assert PROVIDERS["ollama"]["env_key"] is None

    def test_required_providers_present(self):
        required = {"groq", "openrouter", "anthropic", "openai", "ollama"}
        assert required.issubset(PROVIDERS.keys())

    def test_all_groq_models_prefixed(self):
        for model in PROVIDERS["groq"]["models"]:
            assert model.startswith("groq/"), f"Groq model missing prefix: {model}"


class TestSetApiKey:
    def test_groq_sets_env_var(self, monkeypatch):
        monkeypatch.delenv("GROQ_API_KEY", raising=False)
        set_api_key("groq/llama-3.3-70b-versatile", "test-groq-key")
        import os
        assert os.environ.get("GROQ_API_KEY") == "test-groq-key"

    def test_openrouter_sets_env_var(self, monkeypatch):
        monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
        set_api_key("openrouter/google/gemma-3", "test-or-key")
        import os
        assert os.environ.get("OPENROUTER_API_KEY") == "test-or-key"

    def test_no_key_for_ollama(self, monkeypatch):
        import os
        monkeypatch.delenv("GROQ_API_KEY", raising=False)
        # Ollama has no env_key — set_api_key with None should not crash
        set_api_key("ollama/llama3.2", None)


class TestLLMAgentInit:
    def test_normalizes_model_on_init(self):
        agent = LLMAgent(model="groq/groq/llama-3.3-70b-versatile")
        assert agent.model == "groq/llama-3.3-70b-versatile"

    def test_history_starts_with_system(self):
        agent = LLMAgent(model="groq/llama-3.3-70b-versatile")
        assert agent.messages[0]["role"] == "system"
        assert len(agent.messages[0]["content"]) > 100

    def test_json_format_disabled_for_groq(self):
        agent = LLMAgent(model="groq/llama-3.3-70b-versatile")
        assert agent._supports_json_format is False

    def test_json_format_enabled_for_openai(self):
        agent = LLMAgent(model="gpt-4o-mini")
        assert agent._supports_json_format is True

    def test_trim_history(self):
        agent = LLMAgent(model="groq/llama-3.3-70b-versatile")
        # Add many messages
        for i in range(50):
            agent.messages.append({"role": "user", "content": f"msg {i}"})
        agent._trim_history()
        assert len(agent.messages) <= agent.max_history
        assert agent.messages[0]["role"] == "system"  # system prompt preserved
