# fixpi — Remote OS Repair Agent

SSH into any Linux device, let an LLM diagnose and fix it.

## Quick Start

```bash
cd fixPI
cp .env.example .env          # fill in SSH + LLM credentials
pip install -e ".[clickmd]"   # or: pip install -e ~/github/wronai/contract/clickmd

fixpi                         # interactive menu shell
```

## LLM Providers

Any [litellm](https://docs.litellm.ai/docs/providers)-compatible provider:

| Provider | Model example | Env key |
| -------- | ------------ | ------- |
| **Groq** | `groq/llama-3.3-70b-versatile` | `GROQ_API_KEY` |
| **OpenRouter** | `openrouter/google/gemma-3-27b-it:free` | `OPENROUTER_API_KEY` |
| **Anthropic** | `anthropic/claude-3-5-sonnet-20241022` | `ANTHROPIC_API_KEY` |
| **OpenAI** | `gpt-4o-mini` | `OPENAI_API_KEY` |
| **Gemini** | `gemini/gemini-2.0-flash-exp` | `GEMINI_API_KEY` |
| **Ollama** | `ollama/llama3.2` | *(none — local)* |

```bash
# Groq example (.env)
LLM_MODEL=groq/llama-3.3-70b-versatile
GROQ_API_KEY=gsk_...
```

> **Note**: `groq/groq/llama-...` is automatically normalized to `groq/llama-...`

## CLI Commands

```bash
fixpi                   # interactive menu shell (default)
fixpi run               # run agent immediately
fixpi diagnose          # diagnostics only, no changes
fixpi config            # configure LLM / SSH wizard
fixpi test              # test LLM connection
fixpi list-models       # show all supported models
```

## What it fixes (RPi3 + WaveShare)

Verified 2026-02-19 — **both displays working**:

| Output | Display | Resolution | Status |
| ------ | ------- | ---------- | ------ |
| `DSI-1` | WaveShare 7.9" | 400×1280 native, Transform:90 | ✅ |
| `HDMI-A-1` | ASEM 7" | 1280×800 auto-detect | ✅ |

**Root cause** was kernel module mismatch: WaveShare repo `.ko` compiled for 6.6.x,
RPi3 running 6.12.x. **Fix**: use mainline `panel-waveshare-dsi.ko` (built into 6.12+):

```ini
# /boot/firmware/config.txt
dtoverlay=vc4-kms-v3d
# display_auto_detect=1   ← disable this
dtoverlay=vc4-kms-dsi-waveshare-panel,7_9_inch
hdmi_force_hotplug=1
```

## Architecture

```text
fixPI/                        ← project root
├── pyproject.toml
├── Makefile
├── README.md
├── LICENSE
├── .env.example
├── tests/                    ← unit tests (not distributed)
│   ├── test_llm_agent.py
│   └── test_cli.py
└── fixpi/                    ← installable package
    ├── __init__.py
    ├── __main__.py           ← CLI entry (fixpi / python -m fixpi)
    ├── cli.py                ← interactive menu shell (clickmd)
    ├── llm_agent.py          ← multi-provider LLM (litellm)
    ├── ssh_client.py         ← paramiko SSH with reboot/reconnect
    ├── diagnostics.py        ← RPi display state collector
    └── agent.py              ← orchestrator (LLM decision loop)
```

## License

Apache License 2.0 - see [LICENSE](LICENSE) for details.

## Author

Created by **Tom Sapletta** - [tom@sapletta.com](mailto:tom@sapletta.com)
