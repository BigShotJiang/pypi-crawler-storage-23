"""
MyWork-AI Framework Tests
=========================
Test suite for the MyWork-AI framework tools.
"""
