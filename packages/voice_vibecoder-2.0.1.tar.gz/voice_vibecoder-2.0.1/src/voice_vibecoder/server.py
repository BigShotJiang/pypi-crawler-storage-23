"""WebSocket server for browser-based voice coding.

Bridges browser WebSocket connections to the existing RealtimeSession.
Each connection gets its own session, provider, and instance registry.
The browser sends/receives JSON frames — never talks to OpenAI directly.

Protocol (client -> server):
  {"type": "auth", "token": "<JWT>"}           — must be the first message when auth is enabled
  {"type": "sync_state"}                       — request full state sync from backend
  {"type": "audio", "data": "<base64 PCM16 24kHz>"}
  {"type": "audio.commit"}

Protocol (server -> client):
  {"type": "auth_ok"}
  {"type": "audio", "data": "<base64>"}
  {"type": "transcript", "role": "user"|"assistant", "text": "..."}
  {"type": "status", "status": "ready"|"listening"|"processing"|"responding"}
  {"type": "agent_output", "instanceId": "...", "line": "..."}
  {"type": "instance_status", "instanceId": "...", "status": "...", "branch": "..."}
  {"type": "tool_call", "name": "...", "arguments": {...}}
  {"type": "ui_command", "instanceId": "...", "action": "show_diff"|"show_output"|"fullscreen"|"remove", "data": {...}}
  {"type": "interrupt"}
  {"type": "error", "message": "..."}
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import jwt
import websockets
from websockets.asyncio.server import ServerConnection
from websockets.http11 import Request, Response

from voice_vibecoder.app_config import VoiceConfig
from voice_vibecoder.config import RealtimeSettings
from voice_vibecoder.instances import InstanceStatus
from voice_vibecoder.session import RealtimeSession
from voice_vibecoder.voice_providers.openai import OpenAIVoiceProvider

logger = logging.getLogger(__name__)

# ── JWT validation for Azure AD ──────────────────────────────────────────────

_JWKS_CACHE_TTL = 3600  # 1 hour


class _JWKSEntry:
    __slots__ = ("client", "fetched_at")

    def __init__(self, client: jwt.PyJWKClient, fetched_at: float) -> None:
        self.client = client
        self.fetched_at = fetched_at


_jwks_cache: dict[str, _JWKSEntry] = {}


def _get_jwks_client(tenant_id: str) -> jwt.PyJWKClient:
    """Return a cached JWKS client for the given Azure AD tenant."""
    now = time.monotonic()
    entry = _jwks_cache.get(tenant_id)
    if entry and (now - entry.fetched_at) < _JWKS_CACHE_TTL:
        return entry.client

    jwks_url = f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"
    client = jwt.PyJWKClient(jwks_url)
    _jwks_cache[tenant_id] = _JWKSEntry(client, now)
    return client


def validate_token(token: str, tenant_id: str, audience: str) -> dict:
    """Validate an Azure AD JWT and return decoded claims.

    Raises ValueError if the token is invalid.
    """
    try:
        jwks_client = _get_jwks_client(tenant_id)
        signing_key = jwks_client.get_signing_key_from_jwt(token)
        # Accept both v1 (aud=client_id) and v2 (aud=api://client_id) tokens,
        # and both v1/v2 issuer formats.
        audiences = [audience]
        if audience.startswith("api://"):
            audiences.append(audience[len("api://"):])
        issuers = [
            f"https://login.microsoftonline.com/{tenant_id}/v2.0",
            f"https://sts.windows.net/{tenant_id}/",
        ]
        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            audience=audiences,
            issuer=issuers,
        )
        return claims
    except jwt.ExpiredSignatureError:
        raise ValueError("Token has expired")
    except jwt.InvalidAudienceError:
        raise ValueError("Invalid audience")
    except jwt.InvalidIssuerError:
        raise ValueError("Invalid issuer")
    except Exception as exc:
        raise ValueError(f"Token validation failed: {exc}")


# ── Auth timeout ─────────────────────────────────────────────────────────────

AUTH_TIMEOUT_SECONDS = 10


class WebSocketBridge:
    """One bridge per browser connection. Thin adapter between WS frames and RealtimeSession."""

    def __init__(
        self,
        ws: ServerConnection,
        settings: RealtimeSettings,
        repo_root: Path,
        voice_config: VoiceConfig | None = None,
        user_email: str | None = None,
        user_jwt: str | None = None,
    ) -> None:
        self._ws = ws
        self._settings = settings
        self._repo_root = repo_root
        self._session: RealtimeSession | None = None
        self._voice_config = voice_config
        self._user_email = user_email
        self._user_jwt = user_jwt

    async def run(self) -> None:
        provider = OpenAIVoiceProvider(
            ws_url=self._settings.ws_url,
            ws_headers=self._settings.ws_headers,
        )

        self._session = RealtimeSession(
            provider=provider,
            settings=self._settings,
            repo_root=self._repo_root,
            voice_config=self._voice_config,
            user_email=self._user_email,
            user_jwt=self._user_jwt,
            on_audio=self._on_audio,
            on_transcript=self._on_transcript,
            on_status=self._on_status,
            on_tool_call=self._on_tool_call,
            on_agent_output=self._on_agent_output,
            on_instance_status=self._on_instance_status,
            on_interrupt=self._on_interrupt,
            on_ui_command=self._on_ui_command,
        )

        # Load saved instances and create default helper
        restored = self._session.registry.load_state()

        helper_name = self._voice_config.default_instance_name if self._voice_config else "helper"
        saved_cb = self._session.registry.on_status_change
        self._session.registry.on_status_change = None
        default_inst = self._session.registry.create_instance(
            helper_name, str(self._repo_root)
        )
        # Add helpful description for the helper instance (only when freshly created)
        if default_inst and default_inst.instance_id and not default_inst.output_buffer:
            help_text = (
                "Generell agent for spørsmål, oppgaver og orkestrering.\n"
                "\n"
                "**Eksempler:**\n"
                "- 'Hva gjør denne filen?'\n"
                "- 'Lag en ny branch for feature X'\n"
                "- 'Lag en PR for branchen'\n"
                "- 'Hva er status på Jira-issue PROJ-123?'"
            )
            default_inst.output_buffer = help_text
            self._session.registry._save_state()
        self._session.registry.on_status_change = saved_cb

        await self._session.connect()
        await self._session.configure_session()
        # Don't sync state here — the frontend sends sync_state after
        # connecting (and after auth), which triggers _sync_state_to_frontend.
        # Sending it here too would cause duplicate output lines.
        self._send({"type": "status", "status": "ready"})

        receive_task = asyncio.create_task(self._receive_loop())
        messages_task = asyncio.create_task(self._session.handle_messages())

        try:
            done, pending = await asyncio.wait(
                [receive_task, messages_task],
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
        finally:
            if self._session.connected:
                await self._session.disconnect()

    async def _receive_loop(self) -> None:
        try:
            async for raw in self._ws:
                try:
                    msg = json.loads(raw)
                except (json.JSONDecodeError, TypeError):
                    continue

                msg_type = msg.get("type")
                if msg_type == "audio":
                    data = msg.get("data", "")
                    if data and self._session:
                        await self._session.send_audio(data)
                elif msg_type == "audio.commit":
                    if self._session:
                        await self._session.commit_audio()
                elif msg_type == "sync_state":
                    # Frontend requests full state sync from backend
                    self._send({"type": "status", "status": "syncing"})
                    await self._sync_state_to_frontend()
                    self._send({"type": "status", "status": "ready"})
        except websockets.ConnectionClosed:
            pass

    async def _sync_state_to_frontend(self) -> None:
        """Send full backend state to frontend - all instances with their conversation history."""
        if not self._session:
            return

        # Send transcript history (voice conversation)
        transcripts = self._session.registry.get_transcripts()
        logger.info(f"[SYNC_STATE] Sending {len(transcripts)} transcripts to frontend")
        for entry in transcripts:
            self._send({
                "type": "transcript",
                "role": entry["role"],
                "text": entry["text"],
            })

        # Send instance status and history for all instances
        for inst in self._session.registry.get_all():
            self._send({
                "type": "instance_status",
                "instanceId": inst.instance_id,
                "status": inst.status.value,
                "branch": inst.branch,
                "agentType": inst.agent_type,
            })
            # Send buffered output from previous session
            if inst.output_buffer:
                self._send({
                    "type": "agent_output",
                    "instanceId": inst.instance_id,
                    "line": f"text:{inst.output_buffer}",
                })

    # -- Callbacks (called from RealtimeSession, possibly from background threads) --

    def _send(self, msg: dict[str, Any]) -> None:
        try:
            data = json.dumps(msg)
            loop = self._session._loop if self._session else None
            if not loop or not loop.is_running():
                return
            # If called from the event loop thread, create a task directly
            # so the send is processed immediately on the next await.
            # From other threads (agent background tasks), use the
            # thread-safe scheduler which wakes the loop.
            try:
                running_loop = asyncio.get_running_loop()
            except RuntimeError:
                running_loop = None
            if running_loop is loop:
                asyncio.ensure_future(self._ws.send(data), loop=loop)
            else:
                future = asyncio.run_coroutine_threadsafe(self._ws.send(data), loop)
                future.add_done_callback(_log_send_error)
        except Exception:
            logger.warning("Failed to send WS frame", exc_info=True)

    def _on_audio(self, base64_chunk: str) -> None:
        self._send({"type": "audio", "data": base64_chunk})

    def _on_transcript(self, role: str, text: str) -> None:
        self._send({"type": "transcript", "role": role, "text": text})

    def _on_status(self, status: str) -> None:
        self._send({"type": "status", "status": status})

    def _on_agent_output(self, instance_id: str, line: str) -> None:
        self._send({"type": "agent_output", "instanceId": instance_id, "line": line})

    def _on_instance_status(self, instance_id: str, status: InstanceStatus) -> None:
        inst = self._session.registry.get_by_id(instance_id) if self._session else None
        branch = inst.branch if inst else ""
        agent_type = inst.agent_type if inst else "claude"
        self._send({
            "type": "instance_status",
            "instanceId": instance_id,
            "status": status.value,
            "branch": branch,
            "agentType": agent_type,
        })

    def _on_tool_call(self, name: str, arguments: dict) -> None:
        self._send({"type": "tool_call", "name": name, "arguments": arguments})

    def _on_ui_command(self, instance_id: str, action: str, data: Any) -> None:
        self._send({"type": "ui_command", "instanceId": instance_id, "action": action, "data": data})

    def _on_interrupt(self) -> None:
        self._send({"type": "interrupt"})


def _log_send_error(future: asyncio.Future) -> None:
    """Callback for run_coroutine_threadsafe — log exceptions instead of losing them."""
    exc = future.exception()
    if exc:
        logger.warning("WS send failed: %s", exc)


async def _authenticate_ws(
    ws: ServerConnection,
    tenant_id: str,
    audience: str,
) -> tuple[str, str] | None:
    """Wait for an auth message as the first frame.

    Returns ``(user_email, raw_token)`` on success, ``None`` on failure.
    """
    try:
        raw = await asyncio.wait_for(ws.recv(), timeout=AUTH_TIMEOUT_SECONDS)
        msg = json.loads(raw)
    except asyncio.TimeoutError:
        await ws.send(json.dumps({"type": "error", "message": "Auth timeout"}))
        return None
    except (json.JSONDecodeError, TypeError, websockets.ConnectionClosed):
        return None

    if msg.get("type") != "auth" or not isinstance(msg.get("token"), str):
        await ws.send(json.dumps({"type": "error", "message": "Expected auth message"}))
        return None

    token = msg["token"]
    if token.startswith("Bearer "):
        token = token[7:]

    try:
        claims = validate_token(token, tenant_id, audience)
    except ValueError as exc:
        logger.warning("JWT validation failed: %s", exc)
        await ws.send(json.dumps({"type": "error", "message": "Authentication failed"}))
        return None

    await ws.send(json.dumps({"type": "auth_ok"}))
    user_email = claims.get("email") or claims.get("preferred_username") or claims.get("upn") or "unknown"
    return (user_email, token)


async def _handle_connection(
    ws: ServerConnection,
    settings: RealtimeSettings,
    repo_root: Path,
    voice_config: VoiceConfig | None,
    auth_enabled: bool,
    tenant_id: str,
    audience: str,
) -> None:
    remote = ws.remote_address
    logger.info("Client connected from %s", remote)

    user_email = None
    user_jwt = None
    if auth_enabled:
        auth_result = await _authenticate_ws(ws, tenant_id, audience)
        if not auth_result:
            logger.warning("Auth failed for %s — closing", remote)
            await ws.close(4001, "Unauthorized")
            return
        user_email, user_jwt = auth_result
        logger.info("Authenticated user: %s", user_email)

    bridge = WebSocketBridge(ws, settings, repo_root, voice_config, user_email=user_email, user_jwt=user_jwt)
    try:
        await bridge.run()
    except Exception:
        logger.error("Bridge error", exc_info=True)
    finally:
        logger.info("Client disconnected: %s", remote)


async def serve(
    host: str = "127.0.0.1",
    port: int = 8765,
    repo_root: Path | None = None,
    voice_config: VoiceConfig | None = None,
    settings: RealtimeSettings | None = None,
    no_auth: bool = False,
    allowed_origins: list[str] | None = None,
) -> None:
    """Start the WebSocket server. Blocks until stopped."""
    if repo_root is None:
        repo_root = Path.cwd()

    # Browser cookie headers can exceed the default 8 KiB line limit.
    import websockets.http11
    websockets.http11.MAX_LINE_LENGTH = 32768

    if settings is None:
        settings = RealtimeSettings.load()
    if not settings.is_configured:
        logger.error("Not configured. Run 'vibecoder' TUI first to set API keys.")
        return

    # JWT auth — enabled when both env vars are set
    tenant_id = os.environ.get("AZURE_AD_TENANT_ID", "")
    client_id = os.environ.get("AZURE_AD_CLIENT_ID", "")
    auth_enabled = bool(tenant_id and client_id) and not no_auth
    if auth_enabled:
        audience = f"api://{client_id}"
        logger.info("JWT auth enabled  tenant=%s  audience=%s", tenant_id, audience)
    elif no_auth:
        audience = ""
        logger.warning("JWT auth explicitly disabled via --no-auth")
    else:
        audience = ""
        logger.warning(
            "JWT auth disabled (AZURE_AD_TENANT_ID / AZURE_AD_CLIENT_ID not set). "
            "Set these env vars or pass --no-auth to suppress this warning."
        )

    # Origin checking — build allowed set from env var + explicit param
    origin_env = os.environ.get("VOICE_ALLOWED_ORIGINS", "")
    _allowed_origins: set[str] = set()
    if allowed_origins:
        _allowed_origins.update(allowed_origins)
    if origin_env:
        _allowed_origins.update(o.strip() for o in origin_env.split(",") if o.strip())

    def process_request(connection: ServerConnection, request: Request) -> Response | None:
        """Check Origin header before completing the WebSocket handshake."""
        if _allowed_origins:
            origin = request.headers.get("Origin", "")
            if origin not in _allowed_origins:
                logger.warning("Rejected connection from origin: %s", origin)
                return Response(403, "Forbidden", websockets.Headers())
        return None

    logger.info(
        "Starting voice server on ws://%s:%d  repo=%s  provider=%s",
        host, port, repo_root, settings.provider_label,
    )

    async def handler(ws: ServerConnection) -> None:
        await _handle_connection(ws, settings, repo_root, voice_config, auth_enabled, tenant_id, audience)

    async with websockets.serve(handler, host, port, process_request=process_request):
        await asyncio.Future()  # Block forever
