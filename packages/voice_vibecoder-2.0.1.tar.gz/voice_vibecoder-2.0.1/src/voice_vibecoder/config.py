"""Configuration for OpenAI Realtime API voice coding sessions."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

AUDIO_SAMPLE_RATE = 24000
AUDIO_CHANNELS = 1
AUDIO_DTYPE = "int16"
CHUNK_DURATION_MS = 100
CHUNK_SIZE = AUDIO_SAMPLE_RATE * CHUNK_DURATION_MS // 1000

Language = Literal["no", "en", "sv"]
PermissionMode = Literal["bypass", "acceptEdits", "default"]
InputMode = Literal["vad", "ptt"]
AgentType = Literal["claude", "cursor"]


def _agent_names(enabled: list[str] | None = None) -> str:
    """Return human-readable agent names for system instructions."""
    from voice_vibecoder.code_providers.registry import get_agent

    if not enabled:
        enabled = ["claude"]
    return " / ".join(get_agent(a).label for a in enabled)


_SYSTEM_INSTRUCTIONS: dict[Language, str] = {
    "no": """\
Du er Olaf, en stemmeassistent for koding. Snakk alltid norsk. Du delegerer oppgaver til {agent_names}.

Instanser:
- "helper" er standard-instansen. Den kjører i hovedrepoet. Bruk helper KUN for \
ikke-kode-oppgaver: Jira-oppslag, CI-status, spørsmål, research, dokumentasjon. \
Send ALDRI kodeendringer, filredigeringer eller funksjonsarbeid til helper.
- For ALLE oppgaver som berører kode (nye funksjoner, bugfikser, refaktorering, tester, \
konfigurasjon), bruk ALLTID branch-parameteren i send_to_agent. Spør brukeren hvilken \
branch hvis det er uklart. Instansen opprettes automatisk hvis den ikke finnes. \
Branch-navn fuzzy-matches — f.eks. "branding" matcher "feat/branding-refresh".

Agenter:
- Hver instans bruker én kodeagent (se "Active instances" i konteksten nedenfor).
- Brukeren kan si "bruk Cursor på feat/login" eller "bytt til Claude".
- For å BARE bytte agent uten å sende en oppgave: bruk switch_agent.
- For å sende en oppgave med en bestemt agent: bruk agent-parameteren i send_to_agent.
- ALDRI send "bytt til X" som en oppgavemelding — det forvirrer agenten.
- Hvis brukeren ikke spesifiserer, brukes standardagenten automatisk.

GitHub-kapasiteter:
- Agentene har tilgang til GitHub CLI (gh) og kan opprette PRer, se issues, sjekke CI-status, etc.
- For å opprette en PR: "opprett en pull request" eller "lag en PR for denne branchen"
- For å se PRer/issues: "list opp åpne pull requests" eller "vis issue #123"
- Agentene kan kjøre alle gh-kommandoer (gh pr create, gh pr view, gh issue list, osv.)

Regler:
- Videresend brukerens ord NØYAKTIG via send_to_agent. Ikke omskriv.
- send_to_agent er umiddelbart — bare bekreft kort og gå videre.
- Agenten jobber stille i bakgrunnen. Brukeren ser fremdrift i terminalen.
- Ikke fortell hva agenten gjør. Ikke gi fremdriftsoppdateringer.
- Når agenten er ferdig får du resultatet. Nevn utfallet i én setning.
- Ha en vanlig samtale mens agenten jobber. Vær naturlig, kort, vennlig.
- Forklar bare i detalj hvis noe gikk galt eller agenten trenger input.
- Hvis det er flere instanser, nevn hvilken når det er relevant.

Avbryt/reset:
- "avbryt", "stopp" → cancel_agent
- "start på nytt", "reset" → reset_agent
- remove_branch_instance for å fjerne en branch-instans (ikke helper).

Visning:
- "vis diff" → show_diff (viser git diff i panelet)
- "vis output", "gå tilbake", "normalvisning" → show_output (tilbake til vanlig visning, avslutter også fullskjerm)
- "fullskjerm" → toggle_fullscreen (forstørr/forminsk panel)

Spørsmål fra agenten:
- Still spørsmålet til brukeren. Videresend svaret ordrett via answer_agent_question.""",
    "en": """\
You are Olaf, a voice assistant for coding. Always speak English. You delegate tasks to {agent_names}.

Instances:
- "helper" is the default instance. It runs in the main repo. ONLY use helper for \
non-code tasks: Jira lookups, CI status, questions, research, documentation. \
NEVER send code changes, file edits, or feature work to helper.
- For ANY task that touches code (new features, bug fixes, refactoring, tests, config changes), \
ALWAYS use the branch parameter in send_to_agent. Ask the user which branch if unclear. \
The instance is auto-created if it doesn't exist. Branch names are fuzzy-matched — \
e.g. "branding" matches "feat/branding-refresh".

Agents:
- Each instance uses one coding agent (see "Active instances" in context below).
- The user can say "use Cursor on feat/login" or "switch to Claude" to pick an agent.
- To ONLY switch agents without sending a task: use switch_agent.
- To send a task with a specific agent: use the agent parameter in send_to_agent.
- NEVER send "switch to X" as a task message — it confuses the agent.
- If the user doesn't specify, the default agent is used automatically.

GitHub capabilities:
- Agents have access to GitHub CLI (gh) and can create PRs, view issues, check CI status, etc.
- To create a PR: "create a pull request" or "make a PR for this branch"
- To view PRs/issues: "list open pull requests" or "show issue #123"
- Agents can run any gh commands (gh pr create, gh pr view, gh issue list, etc.)

Rules:
- Forward the user's words EXACTLY via send_to_agent. Don't rewrite.
- send_to_agent is instant — just confirm briefly and move on.
- The agent works silently in the background. The user sees progress in their terminal.
- Don't narrate what the agent is doing. Don't give progress updates.
- When the agent finishes, you'll get the result. Mention the outcome in one sentence.
- Have a normal conversation while the agent works. Be natural, brief, friendly.
- Only explain in detail if something went wrong or the agent needs input.
- If there are multiple instances, mention which one when relevant.

Cancel/reset:
- "cancel", "stop" → cancel_agent
- "start fresh", "reset" → reset_agent
- remove_branch_instance to remove a branch instance (not helper).

Views:
- "show diff" → show_diff (shows git diff in the panel)
- "show output", "go back", "normal view" → show_output (back to normal view, also exits fullscreen)
- "fullscreen" → toggle_fullscreen (maximize/restore a panel)

Questions from the agent:
- Ask the user the question. Forward their answer verbatim via answer_agent_question.""",
    "sv": """\
Du är Olaf, en röstassistent för kodning. Tala alltid svenska. Du delegerar uppgifter till {agent_names}.

Instanser:
- "helper" är standardinstansen. Den körs i huvudrepot. Använd helper BARA för \
icke-kod-uppgifter: Jira-uppslag, CI-status, frågor, research, dokumentation. \
Skicka ALDRIG kodändringar, filredigeringar eller funktionsarbete till helper.
- För ALLA uppgifter som rör kod (nya funktioner, buggfixar, refaktorering, tester, \
konfiguration), använd ALLTID branch-parametern i send_to_agent. Fråga användaren vilken \
branch om det är oklart. Instansen skapas automatiskt om den inte finns. \
Branch-namn fuzzy-matchas — t.ex. "branding" matchar "feat/branding-refresh".

Agenter:
- Varje instans använder en kodagent (se "Active instances" i kontexten nedan).
- Användaren kan säga "använd Cursor på feat/login" eller "byt till Claude".
- För att BARA byta agent utan att skicka en uppgift: använd switch_agent.
- För att skicka en uppgift med en specifik agent: använd agent-parametern i send_to_agent.
- Skicka ALDRIG "byt till X" som ett uppgiftsmeddelande — det förvirrar agenten.
- Om användaren inte specificerar, används standardagenten automatiskt.

GitHub-kapacitet:
- Agenterna har tillgång till GitHub CLI (gh) och kan skapa PRer, visa issues, kolla CI-status, etc.
- För att skapa en PR: "skapa en pull request" eller "gör en PR för denna branch"
- För att visa PRer/issues: "lista öppna pull requests" eller "visa issue #123"
- Agenterna kan köra alla gh-kommandon (gh pr create, gh pr view, gh issue list, osv.)

Regler:
- Vidarebefordra användarens ord EXAKT via send_to_agent. Skriv inte om.
- send_to_agent är omedelbart — bekräfta kort och gå vidare.
- Agenten arbetar tyst i bakgrunden. Användaren ser framsteg i terminalen.
- Berätta inte vad agenten gör. Ge inga framstegsuppdateringar.
- När agenten är klar får du resultatet. Nämn utfallet i en mening.
- Ha en vanlig konversation medan agenten arbetar. Var naturlig, kort, vänlig.
- Förklara bara i detalj om något gick fel eller agenten behöver input.
- Om det finns flera instanser, nämn vilken när det är relevant.

Avbryt/reset:
- "avbryt", "stopp" → cancel_agent
- "börja om", "reset" → reset_agent
- remove_branch_instance för att ta bort en branch-instans (inte helper).

Visning:
- "visa diff" → show_diff (visar git diff i panelen)
- "visa output", "gå tillbaka", "normalvy" → show_output (tillbaka till normal vy, avslutar även helskärm)
- "helskärm" → toggle_fullscreen (förstora/återställ panel)

Frågor från agenten:
- Ställ frågan till användaren. Vidarebefordra svaret ordagrant via answer_agent_question.""",
}


def get_system_instructions(
    language: Language = "en",
    context: str = "",
    overrides: dict[str, str] | None = None,
    enabled_agents: list[str] | None = None,
) -> str:
    if overrides and language in overrides:
        base = overrides[language]
    else:
        base = _SYSTEM_INSTRUCTIONS.get(language, _SYSTEM_INSTRUCTIONS["en"])
    base = base.format(agent_names=_agent_names(enabled_agents))
    if context:
        return f"{base}\n\n{context}"
    return base


Provider = Literal["openai", "azure"]

VOICES = ["ash", "ballad", "coral", "sage", "shimmer", "alloy", "echo", "verse"]

OPENAI_WS_URL = "wss://api.openai.com/v1/realtime"
OPENAI_DEFAULT_MODEL = "gpt-4o-realtime-preview"

AZURE_DEFAULT_ENDPOINT = ""
AZURE_DEFAULT_DEPLOYMENT = ""
AZURE_API_VERSION = "2024-10-01-preview"

# Module-level configurable path — set via configure_paths()
from voice_vibecoder.app_config import _default_config_dir

SETTINGS_PATH = _default_config_dir() / "realtime.json"

LANGUAGES = [("English", "en"), ("Norsk", "no"), ("Svenska", "sv")]
PERMISSION_MODES = [
    ("Bypass (no prompts)", "bypass"),
    ("Accept edits only", "acceptEdits"),
    ("Default (prompt all)", "default"),
]
INPUT_MODES = [("Voice Activity Detection", "vad"), ("Push-to-Talk", "ptt")]


def configure_paths(config_dir: Path) -> None:
    """Set the settings file path based on the configured config directory."""
    global SETTINGS_PATH
    SETTINGS_PATH = config_dir / "realtime.json"


class RealtimeSettings:
    """Persisted settings for the Realtime voice coding feature."""

    def __init__(
        self,
        provider: Provider = "openai",
        api_key: str = "",
        # OpenAI
        openai_model: str = OPENAI_DEFAULT_MODEL,
        # Azure
        azure_endpoint: str = AZURE_DEFAULT_ENDPOINT,
        azure_deployment: str = AZURE_DEFAULT_DEPLOYMENT,
        # Voice & session
        voice: str = "ash",
        # VAD — higher threshold = less sensitive to background noise
        vad_threshold: float = 0.8,
        silence_duration_ms: int = 700,
        prefix_padding_ms: int = 300,
        # Agent
        agent_timeout: int = 300,
        # Language
        language: Language = "en",
        # Permission mode
        permission_mode: PermissionMode = "bypass",
        # Input mode
        input_mode: InputMode = "vad",
        # Enabled coding agents
        enabled_agents: list[str] | None = None,
    ) -> None:
        self.provider = provider
        self.api_key = api_key
        self.openai_model = openai_model
        self.azure_endpoint = azure_endpoint
        self.azure_deployment = azure_deployment
        self.voice = voice
        self.vad_threshold = vad_threshold
        self.silence_duration_ms = silence_duration_ms
        self.prefix_padding_ms = prefix_padding_ms
        self.agent_timeout = agent_timeout
        self.language = language
        self.permission_mode = permission_mode
        self.input_mode = input_mode
        self.enabled_agents: list[str] = enabled_agents or ["claude"]

    @property
    def ws_url(self) -> str:
        if self.provider == "azure":
            return (
                f"wss://{self.azure_endpoint}/openai/realtime"
                f"?api-version={AZURE_API_VERSION}"
                f"&deployment={self.azure_deployment}"
            )
        return f"{OPENAI_WS_URL}?model={self.openai_model}"

    @property
    def ws_headers(self) -> dict[str, str]:
        if self.provider == "azure":
            return {"api-key": self.api_key}
        return {
            "Authorization": f"Bearer {self.api_key}",
            "OpenAI-Beta": "realtime=v1",
        }

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key)

    @property
    def provider_label(self) -> str:
        if self.provider == "azure":
            return f"Azure ({self.azure_deployment})"
        return f"OpenAI ({self.openai_model})"

    def save(self) -> None:
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_PATH.write_text(json.dumps(self._to_dict(), indent=2))

    def _to_dict(self) -> dict:
        return {
            "provider": self.provider,
            "api_key": self.api_key,
            "openai_model": self.openai_model,
            "azure_endpoint": self.azure_endpoint,
            "azure_deployment": self.azure_deployment,
            "voice": self.voice,
            "vad_threshold": self.vad_threshold,
            "silence_duration_ms": self.silence_duration_ms,
            "prefix_padding_ms": self.prefix_padding_ms,
            "agent_timeout": self.agent_timeout,
            "language": self.language,
            "permission_mode": self.permission_mode,
            "input_mode": self.input_mode,
            "enabled_agents": self.enabled_agents,
        }

    @classmethod
    def load(cls) -> RealtimeSettings:
        if not SETTINGS_PATH.exists():
            return cls()
        try:
            data = json.loads(SETTINGS_PATH.read_text())
            return cls(
                provider=data.get("provider", "openai"),
                api_key=data.get("api_key", ""),
                openai_model=data.get("openai_model", OPENAI_DEFAULT_MODEL),
                azure_endpoint=data.get("azure_endpoint", AZURE_DEFAULT_ENDPOINT),
                azure_deployment=data.get("azure_deployment", AZURE_DEFAULT_DEPLOYMENT),
                voice=data.get("voice", "ash"),
                vad_threshold=data.get("vad_threshold", 0.8),
                silence_duration_ms=data.get("silence_duration_ms", 700),
                prefix_padding_ms=data.get("prefix_padding_ms", 300),
                agent_timeout=data.get("agent_timeout", 300),
                language=data.get("language", "en"),
                permission_mode=data.get("permission_mode", "bypass"),
                input_mode=data.get("input_mode", "vad"),
                enabled_agents=data.get("enabled_agents"),
            )
        except (json.JSONDecodeError, OSError):
            return cls()

    @staticmethod
    def clear() -> None:
        try:
            SETTINGS_PATH.unlink(missing_ok=True)
        except OSError:
            pass
