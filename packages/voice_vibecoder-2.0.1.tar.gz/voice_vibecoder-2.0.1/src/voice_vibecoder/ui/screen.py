"""Voice coding TUI screen with multi-instance grid view.

Every agent instance (including the default/current branch) gets its own
dedicated grid panel. The transcript strip shows only the voice conversation
(You/ChatGPT messages). Saves conversation logs to <state_dir>/logs/voice/.
"""

import atexit
import asyncio
import signal
import threading
from datetime import datetime
from pathlib import Path

from textual import work
from textual.binding import Binding
from textual.containers import Grid, Vertical
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, RichLog

from voice_vibecoder.app_config import VoiceConfig
from voice_vibecoder.ui.callbacks import CallbackMixin
from voice_vibecoder.ui.panels import PanelMixin
from voice_vibecoder.ui.state import SessionState
from voice_vibecoder.ui.styles import VOICE_SCREEN_CSS, strip_markup


class VoiceCodingScreen(PanelMixin, CallbackMixin, Screen):
    """Full-screen voice coding session with ChatGPT Realtime + coding agents."""

    BINDINGS = [
        Binding("q", "quit_voice", "Quit", priority=True),
        Binding("escape", "quit_voice", "Quit", priority=True),
        Binding("h", "show_help", "Help", priority=True),
        Binding("m", "toggle_mute", "Mute/Unmute", priority=True),
        Binding("s", "show_setup", "Settings", priority=True),
        Binding("c", "cancel_agent", "Cancel", priority=True),
        Binding("space", "toggle_ptt", "Talk", priority=True),
    ]

    CSS = VOICE_SCREEN_CSS

    def __init__(self, root: Path, config: VoiceConfig | None = None) -> None:
        super().__init__()
        self.root = root
        self._config = config or VoiceConfig()
        self._session = None
        self._audio = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._ws_thread: threading.Thread | None = None
        self._log_file = None
        self._log_path: Path | None = None
        self._ptt_recording = False
        self._input_mode = "vad"
        self._default_instance_id: str | None = None
        self._fullscreen_id: str | None = None
        self._state = SessionState()

        # Configure all module-level paths from VoiceConfig
        self._configure_paths()

    def _configure_paths(self) -> None:
        """Set module-level paths based on VoiceConfig directories."""
        from voice_vibecoder.config import configure_paths as configure_config_paths
        from voice_vibecoder.instances import configure_paths as configure_instance_paths
        from voice_vibecoder.ui.state import configure_paths as configure_state_paths
        from voice_vibecoder.worktrees import configure_paths as configure_worktree_paths

        configure_config_paths(self._config.config_dir)
        configure_instance_paths(self._config.data_dir)
        configure_state_paths(self._config.data_dir)
        worktrees_dir = self._config.worktrees_dir or self.root.parent
        configure_worktree_paths(worktrees_dir)

    def compose(self):
        yield Header(show_clock=True)
        with Vertical(id="voice-container"):
            yield Grid(id="agent-grid")
            yield RichLog(id="voice-transcript", highlight=True, markup=True)
            yield Static(
                "[bold]Initializing...[/bold]",
                id="voice-status-bar",
            )
        yield Footer()

    def on_mount(self) -> None:
        self._open_log_file()
        self._log("[bold cyan]Voice Coding[/bold cyan]")
        self._log("")
        self._check_and_start()

    # -- Log file --

    def _open_log_file(self) -> None:
        log_dir = self._config.log_dir / "voice"
        log_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self._log_path = log_dir / f"{ts}.log"
        self._log_file = open(self._log_path, "a", encoding="utf-8", buffering=1)
        self._log_file.write(f"=== Voice coding session started {ts} ===\n")

    def _write_log_file(self, text: str) -> None:
        if self._log_file:
            try:
                plain = strip_markup(text)
                ts = datetime.now().strftime("%H:%M:%S")
                self._log_file.write(f"[{ts}] {plain}\n")
            except Exception:
                pass

    def _close_log_file(self) -> None:
        if self._log_file:
            try:
                self._log_file.write("=== Session ended ===\n")
                self._log_file.close()
            except Exception:
                pass
            self._log_file = None

    # -- Startup --

    @work(thread=True)
    def _check_and_start(self) -> None:
        try:
            import sounddevice  # noqa: F401
        except ImportError:
            self.app.call_from_thread(
                self._log,
                "[bold red]Missing dependency: sounddevice[/bold red]\n"
                "Install with: pip install sounddevice\n"
                "On macOS you also need: brew install portaudio",
            )
            self.app.call_from_thread(self._set_status, "[red]Missing dependencies[/red]")
            return

        try:
            import websockets  # noqa: F401
        except ImportError:
            self.app.call_from_thread(
                self._log,
                "[bold red]Missing dependency: websockets[/bold red]\n"
                "Install with: pip install websockets",
            )
            self.app.call_from_thread(self._set_status, "[red]Missing dependencies[/red]")
            return

        # Check for updates (non-blocking, best-effort)
        self._check_for_update()

        from voice_vibecoder.config import RealtimeSettings

        settings = RealtimeSettings.load()
        if not settings.is_configured:
            self.app.call_from_thread(self._prompt_setup)
            return

        self._input_mode = settings.input_mode

        self.app.call_from_thread(
            self._log, f"[dim]{settings.provider_label}  |  voice: {settings.voice}[/dim]"
        )
        self.app.call_from_thread(self._log, "[dim]Connecting...[/dim]")
        self.app.call_from_thread(self._start_session, settings)

    def _check_for_update(self) -> None:
        """Check PyPI for a newer version and prompt to update."""
        import json
        import urllib.request

        from voice_vibecoder import __version__

        try:
            req = urllib.request.Request(
                "https://pypi.org/pypi/voice-vibecoder/json",
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
            latest = data.get("info", {}).get("version", "")
            if not latest or latest == __version__:
                return
            # Simple tuple-based version comparison
            def _parse_ver(v: str) -> tuple[int, ...]:
                return tuple(int(x) for x in v.split(".") if x.isdigit())
            if _parse_ver(latest) <= _parse_ver(__version__):
                return
        except Exception:
            return

        self._update_event = threading.Event()
        self._update_accepted = False
        self.app.call_from_thread(self._show_update_modal, __version__, latest)

        # Block startup until user responds (max 30s)
        self._update_event.wait(timeout=30)

        if self._update_accepted:
            self._run_update(latest)

        # Cleanup
        for attr in ("_update_event", "_update_accepted"):
            if hasattr(self, attr):
                delattr(self, attr)

    def _show_update_modal(self, current: str, latest: str) -> None:
        from voice_vibecoder.ui.update_modal import UpdateModal

        def on_result(accepted: bool) -> None:
            self._update_accepted = accepted
            event = getattr(self, "_update_event", None)
            if event:
                event.set()

        self.app.push_screen(UpdateModal(current, latest), on_result)

    def _run_update(self, version: str) -> None:
        """Actually run the update and restart (called from the startup thread)."""
        import subprocess
        import sys
        import os

        self.app.call_from_thread(self._log, f"[yellow]Updating to v{version}...[/yellow]")
        success = False
        try:
            result = subprocess.run(
                ["uv", "pip", "install", "--upgrade", "voice-vibecoder"],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0:
                success = True
            else:
                result = subprocess.run(
                    ["pip", "install", "--upgrade", "voice-vibecoder"],
                    capture_output=True, text=True, timeout=60,
                )
                if result.returncode == 0:
                    success = True
                else:
                    self.app.call_from_thread(
                        self._log, f"[red]Update failed: {result.stderr[:200]}[/red]"
                    )
        except Exception as e:
            self.app.call_from_thread(self._log, f"[red]Update failed: {e}[/red]")

        if success:
            self.app.call_from_thread(
                self._log, f"[green]Updated to v{version}. Restarting...[/green]"
            )
            import time
            time.sleep(1)
            # Exit with special return value so the outer runner can restart
            self.app.call_from_thread(self.app.exit, "_restart")

    def _prompt_setup(self) -> None:
        from voice_vibecoder.config import SETTINGS_PATH

        if not SETTINGS_PATH.exists():
            self._show_wizard()
        else:
            self._log("[yellow]No API key configured.[/yellow]")
            self._log("[dim]Opening setup...[/dim]")
            self._show_setup()

    def _show_wizard(self) -> None:
        from voice_vibecoder.ui.wizard import SetupWizardScreen

        def on_wizard_done(result) -> None:
            if result is None:
                self.dismiss()
                return
            self._input_mode = result.input_mode
            self._log(f"[green]Saved: {result.provider_label}[/green]")
            self._log("[dim]Connecting...[/dim]")
            self._start_session(result)

        self.app.push_screen(SetupWizardScreen(), on_wizard_done)

    def _show_setup(self) -> None:
        from voice_vibecoder.config import RealtimeSettings
        from voice_vibecoder.ui.setup import VoiceCodingSetupScreen

        existing = RealtimeSettings.load()

        def on_setup_done(result) -> None:
            if result is None:
                self._log("[dim]Setup cancelled.[/dim]")
                self._set_status(
                    "[yellow]Not configured[/yellow]  |  [dim]s[/dim] settings  |  [dim]q[/dim] quit"
                )
                return
            self._input_mode = result.input_mode
            self._log(f"[green]Saved: {result.provider_label}[/green]")
            self._log("[dim]Connecting...[/dim]")
            self._start_session(result)

        self.app.push_screen(VoiceCodingSetupScreen(existing), on_setup_done)

    # -- Session lifecycle --

    def _start_session(self, settings) -> None:
        from voice_vibecoder.voice_providers.openai import OpenAIVoiceProvider
        from voice_vibecoder.session import RealtimeSession

        helper_name = self._config.default_instance_name

        provider = OpenAIVoiceProvider(
            ws_url=settings.ws_url,
            ws_headers=settings.ws_headers,
            transcription_model="gpt-4o-mini-transcribe",
        )

        self._session = RealtimeSession(
            provider=provider,
            settings=settings,
            repo_root=self.root,
            voice_config=self._config,
            on_audio=self._on_audio,
            on_transcript=self._on_transcript,
            on_status=self._on_status,
            on_tool_call=self._on_tool_call,
            on_agent_output=self._on_agent_output,
            on_instance_status=self._on_instance_status,
            on_interrupt=self._on_interrupt,
            on_ui_command=self._on_ui_command,
        )

        # Load saved instances BEFORE creating helper (so _save_state doesn't overwrite)
        restored = self._session.registry.load_state()

        saved_cb = self._session.registry.on_status_change
        self._session.registry.on_status_change = None
        default_inst = self._session.registry.create_instance(
            helper_name, str(self.root)
        )
        self._session.registry.on_status_change = saved_cb
        self._default_instance_id = default_inst.instance_id

        # Batch-create all panels at once
        all_instances = [default_inst] + [
            inst for inst in restored if inst.instance_id != self._default_instance_id
        ]
        self._create_panels_batch(all_instances)

        self._restore_session_state()

        # Register emergency save so state persists on force exit (Ctrl+C, SIGTERM)
        self._register_emergency_save()

        self._loop = asyncio.new_event_loop()
        self._ws_thread = threading.Thread(
            target=self._run_session_loop, daemon=True
        )
        self._ws_thread.start()

    def _run_session_loop(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._session_lifecycle())

    async def _session_lifecycle(self) -> None:
        try:
            await self._session.connect()
            await self._session.configure_session()

            from voice_vibecoder.audio import AudioManager

            self._audio = AudioManager(on_audio_chunk=self._send_audio_chunk)
            self._audio.start()

            self.app.call_from_thread(self._log, "[green]Connected — start speaking[/green]")
            if self._log_path:
                self.app.call_from_thread(
                    self._log, f"[dim]Log: {self._log_path}[/dim]"
                )
            self.app.call_from_thread(self._update_status_bar, "ready")

            # Run custom startup callback if configured
            if self._config.on_startup:
                self._run_startup_callback()

            await self._session.handle_messages()
        except Exception as e:
            self.app.call_from_thread(
                self._log, f"[bold red]Connection error: {e}[/bold red]"
            )
            self.app.call_from_thread(
                self._set_status,
                f"[red]Error[/red]  |  [dim]s[/dim] settings  |  [dim]q[/dim] quit",
            )

    def _run_startup_callback(self) -> None:
        """Run the on_startup callback, providing agent control helpers."""
        from voice_vibecoder.tools.agent_task import _handle_send_to_agent
        from voice_vibecoder.tools.handlers import _handle_switch_agent

        def send_to_agent(message: str, branch: str | None = None, agent: str | None = None) -> str:
            return _handle_send_to_agent(message, branch, agent)

        def switch_agent(agent: str, branch: str | None = None) -> str:
            return _handle_switch_agent(agent, branch)

        try:
            self._config.on_startup(send_to_agent, switch_agent)
        except TypeError:
            # Backwards compat: old callbacks only accept send_to_agent
            try:
                self._config.on_startup(send_to_agent)
            except Exception:
                pass
        except Exception:
            pass

    def _restore_session_state(self) -> None:
        saved = SessionState.load()

        # Restore transcript
        transcript_lines = saved.get("transcript", [])
        if transcript_lines:
            try:
                log = self.query_one("#voice-transcript", RichLog)
                for line in transcript_lines:
                    log.write(line)
            except Exception:
                pass
            self._state._transcript = list(transcript_lines)

        # Restore instance output (prefer SessionState styled lines, fall back to output_buffer)
        saved_instance_lines = saved.get("instances", {})
        has_restored = False
        if self._session:
            for inst in self._session.registry.get_all():
                lines = saved_instance_lines.get(inst.branch, [])
                if lines:
                    self._state._instances[inst.branch] = list(lines)
                    has_restored = True
                elif inst.output_buffer:
                    # Fall back to raw output_buffer from instance state
                    lines = [f"[dim]{l}[/dim]" for l in inst.output_buffer.splitlines() if l.strip()]
                    self._state._instances[inst.branch] = list(lines)
                    has_restored = True

        # Restore fullscreen state
        fullscreen_branch = saved.get("fullscreen_branch")
        if fullscreen_branch and self._session:
            inst = self._session.registry.get_by_branch(fullscreen_branch)
            if inst:
                self._state._fullscreen_branch = fullscreen_branch

        # Defer widget writes and fullscreen to ensure panels are mounted
        if transcript_lines or has_restored or fullscreen_branch:
            self.set_timer(0.1, self._apply_restored_output)
            self._log("[dim]--- Resumed previous session ---[/dim]")

    def _apply_restored_output(self) -> None:
        """Write restored instance lines to panel widgets after mount."""
        if not self._session:
            return
        for inst in self._session.registry.get_all():
            lines = self._state._instances.get(inst.branch, [])
            if lines and inst.output_widget:
                for line in lines:
                    inst.output_widget.write(line)

        # Restore fullscreen
        if self._state._fullscreen_branch:
            inst = self._session.registry.get_by_branch(self._state._fullscreen_branch)
            if inst:
                self._toggle_fullscreen(inst.instance_id)

    # -- UI helpers --

    def _log(self, text: str) -> None:
        try:
            log = self.query_one("#voice-transcript", RichLog)
            log.write(text)
        except Exception:
            pass
        self._state.add_transcript_line(text)
        self._write_log_file(text)

    def _set_status(self, text: str) -> None:
        try:
            bar = self.query_one("#voice-status-bar", Static)
            bar.update(text)
        except Exception:
            pass

    def _update_status_bar(self, status: str) -> None:
        status_display = {
            "connected": "[green]Connected[/green]",
            "disconnected": "[red]Disconnected[/red]",
            "listening": "[cyan]Listening...[/cyan]",
            "processing": "[yellow]Processing...[/yellow]",
            "responding": "[green]Speaking...[/green]",
            "ready": "[green bold]Ready[/green bold]",
            "cancelling": "[yellow]Cancelling...[/yellow]",
        }

        display = status_display.get(status)
        if display is None:
            if status.startswith("running:"):
                tool = status.split(":", 1)[1].strip()
                display = f"[yellow]Running {tool}...[/yellow]"
            elif status.startswith("error:"):
                display = f"[red]{status}[/red]"
            elif status.startswith("reconnecting"):
                display = f"[yellow]{status}[/yellow]"
            else:
                display = status

        instance_count = self._session.registry.count if self._session else 0
        count_label = f"{instance_count} instance{'s' if instance_count != 1 else ''}"

        mute_label = "[red]muted[/red]" if self._audio and self._audio.muted else "[dim]m[/dim] mute"
        parts = [display, count_label, mute_label, "[dim]c[/dim] cancel"]
        if self._input_mode == "ptt":
            ptt_label = "[cyan]recording[/cyan]" if self._ptt_recording else "[dim]space[/dim] talk"
            parts.append(ptt_label)
        from voice_vibecoder import __version__
        parts.extend(["[dim]h[/dim] help", "[dim]s[/dim] settings", "[dim]q[/dim] quit", f"[dim]v{__version__}[/dim]"])
        self._set_status("  |  ".join(parts))

    # -- Actions --

    def action_toggle_mute(self) -> None:
        if self._audio:
            new_state = not self._audio.muted
            self._audio.set_muted(new_state)
            if new_state:
                self._log("[red]Microphone muted[/red]")
            else:
                self._log("[green]Microphone unmuted[/green]")
            self._update_status_bar("ready")

    def action_cancel_agent(self) -> None:
        from voice_vibecoder.tools import cancel_all_tasks, cancel_instance_task

        if not self._session:
            return

        focused = self.app.focused
        if focused:
            node = focused
            while node:
                node_id = getattr(node, "id", "") or ""
                if node_id.startswith("panel-"):
                    instance_id = node_id.removeprefix("panel-")
                    inst = self._session.registry.get_by_id(instance_id)
                    if inst:
                        self._log(f"[yellow]Cancelling agent on '{inst.branch}'...[/yellow]")
                        self._update_status_bar("cancelling")
                        if cancel_instance_task(inst):
                            self._log(f"[green]Task on '{inst.branch}' cancelled.[/green]")
                        else:
                            self._log(f"[dim]No active task on '{inst.branch}'.[/dim]")
                        self._update_status_bar("ready")
                        return
                node = node.parent

        self._log("[yellow]Cancelling all agent tasks...[/yellow]")
        self._update_status_bar("cancelling")
        count = cancel_all_tasks()
        if count > 0:
            self._log(f"[green]Cancelled {count} task(s).[/green]")
        else:
            self._log("[dim]No active tasks to cancel.[/dim]")
        self._update_status_bar("ready")

    def action_toggle_ptt(self) -> None:
        if self._input_mode != "ptt":
            return
        if not self._session or not self._loop:
            return
        if self._ptt_recording:
            self._ptt_recording = False
            asyncio.run_coroutine_threadsafe(
                self._session.commit_audio(), self._loop
            )
            self._update_status_bar("processing")
        else:
            self._ptt_recording = True
            self._update_status_bar("listening")

    def action_show_help(self) -> None:
        from voice_vibecoder.ui.help_modal import HelpModal
        self.app.push_screen(HelpModal())

    def action_show_setup(self) -> None:
        self._cleanup()
        self._log("")
        self._log("[dim]Reconfiguring...[/dim]")
        self._show_setup()

    def action_quit_voice(self) -> None:
        self._cleanup()
        self.dismiss()

    def on_unmount(self) -> None:
        self._cleanup()

    def _cleanup(self) -> None:
        self._emergency_save()
        if self._audio:
            self._audio.stop()
            self._audio = None
        if self._session and self._loop:
            future = asyncio.run_coroutine_threadsafe(
                self._session.disconnect(), self._loop
            )
            try:
                future.result(timeout=3)
            except Exception:
                pass
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
            self._loop = None
        self._session = None
        self._close_log_file()

    def _register_emergency_save(self) -> None:
        """Register atexit + signal handlers to persist state on force exit."""
        atexit.register(self._emergency_save)

        def _signal_handler(signum, frame):
            self._emergency_save()
            # Re-raise with default handler so the process actually exits
            signal.signal(signum, signal.SIG_DFL)
            signal.raise_signal(signum)

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, _signal_handler)
            except (OSError, ValueError):
                pass  # Can't set signal handler from non-main thread

    def _emergency_save(self) -> None:
        """Persist session state + instance registry (safe to call from any context)."""
        try:
            self._state.save()
        except Exception:
            pass
        try:
            if self._session:
                self._session.registry._save_state_now()
        except Exception:
            pass
