"""Chart helper functions — annotations, reference lines, legends, color patterns.

All functions accept matplotlib Axes or Figure objects and modify them in-place
or return color lists. Nothing here creates figures — see charts.py and flow.py
for figure-creating functions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import matplotlib.pyplot as plt

from flowmpl.design import COLORS, CONTEXT, FONTS, INK_LIGHT, LEGEND_DEFAULTS
from flowmpl.design import RULE as _RULE

if TYPE_CHECKING:
    from collections.abc import Sequence


def focus_colors(
    items: Sequence[str],
    focus: str | set[str],
    color_map: dict[str, str],
    *,
    context: str | None = None,
) -> list[str]:
    """Apply SWD gray+accent pattern to a list of items.

    Items in *focus* get their mapped color; everything else gets context gray.
    Works with any color mapping (COMPANY_COLORS, FUEL_COLORS, CATEGORICAL
    by index, etc.).

    Parameters
    ----------
    items : sequence of str
        Item keys in the order they appear on the chart.
    focus : str or set of str
        Which items should be colored (the story).
    color_map : dict
        Mapping from item key to color hex string.
    context : str, optional
        Override the default CONTEXT gray.

    Returns
    -------
    list[str]
        One color per item — accent for focus, gray for context.

    Example
    -------
    >>> focus_colors(
    ...     ["MSFT", "AMZN", "GOOGL", "META"],
    ...     focus="AMZN",
    ...     color_map=COMPANY_COLORS,
    ... )
    ['#c0c0c0', '#ff9900', '#c0c0c0', '#c0c0c0']
    """
    ctx = context or CONTEXT
    if isinstance(focus, str):
        focus = {focus}
    return [
        color_map.get(item, ctx) if item in focus else ctx
        for item in items
    ]


def chart_title(
    fig: plt.Figure,
    title: str,
    *,
    fontsize: int | None = None,
    color: str | None = None,
) -> None:
    """Add a subtle, left-aligned insight title to a figure.

    Designed to coexist with Marimo H1 headings: small enough not to
    dominate in the notebook, but present for standalone PNG use.
    Positioned above the axes area using fig.text().

    Parameters
    ----------
    fig : matplotlib Figure
    title : str
        Insight-driven title (e.g., "Capex doubled in two years").
    fontsize : int, optional
        Override default (FONTS["caption"]).
    color : str, optional
        Override default (COLORS["text_light"]).
    """
    fig.suptitle(
        title,
        fontsize=fontsize or FONTS["suptitle"],
        color=color or COLORS["text_light"],
        fontstyle="italic",
        x=0.02, ha="left",
    )
    # Re-run layout so tight_layout accounts for the suptitle; without this
    # the suptitle overlaps the top of the axes area.
    try:
        fig.tight_layout(rect=[0, 0, 1, 0.94])
    except Exception:
        pass  # no-op if figure uses constrained_layout


def annotate_point(
    ax: plt.Axes,
    text: str,
    xy: tuple[float, float],
    xytext: tuple[float, float],
    *,
    color: str | None = None,
    fontsize: int | None = None,
    arrowstyle: str = "->",
    arrow_lw: float = 1.5,
    bbox: bool = True,
    ha: str = "center",
    **kwargs: object,
) -> None:
    """Annotate a data point with consistent arrow + text styling.

    Parameters
    ----------
    ax : Axes
        Target axes.
    text : str
        Annotation text.
    xy : (x, y)
        Point to annotate (data coordinates).
    xytext : (x, y)
        Text position (data coordinates).
    color : str, optional
        Text and arrow color.  Defaults to COLORS["text_light"].
    fontsize : int, optional
        Font size.  Defaults to FONTS["annotation"].
    arrowstyle : str
        Matplotlib arrow style string.
    arrow_lw : float
        Arrow line width.
    bbox : bool
        Whether to draw a rounded box behind the text.
    ha : str
        Horizontal alignment.
    **kwargs
        Forwarded to ax.annotate().
    """
    color = color or COLORS["text_light"]
    fontsize = fontsize or FONTS["annotation"]

    from flowmpl.design import PAPER
    bbox_props = (
        {"boxstyle": "round,pad=0.3", "fc": PAPER, "ec": color, "alpha": 0.8}
        if bbox
        else None
    )

    ax.annotate(
        text,
        xy=xy,
        xytext=xytext,
        fontsize=fontsize,
        fontweight="bold",
        color=color,
        ha=ha,
        arrowprops={"arrowstyle": arrowstyle, "color": color, "lw": arrow_lw},
        bbox=bbox_props,
        **kwargs,
    )


def reference_line(
    ax: plt.Axes,
    value: float,
    orientation: str = "h",
    *,
    label: str | None = None,
    color: str | None = None,
    linestyle: str = "--",
    linewidth: float = 1.5,
    alpha: float = 0.7,
    label_pos: str = "right",
) -> None:
    """Add a labeled reference line (horizontal or vertical).

    Parameters
    ----------
    ax : Axes
        Target axes.
    value : float
        Position of the line.
    orientation : "h" or "v"
        Horizontal or vertical line.
    label : str, optional
        Text label placed near the line.
    color : str, optional
        Line and label color.  Defaults to COLORS["reference"].
    linestyle : str
        Line style.
    linewidth : float
        Line width.
    alpha : float
        Line transparency.
    label_pos : "left" or "right" (for h) / "top" or "bottom" (for v)
        Where to place the label text.
    """
    color = color or COLORS["reference"]
    line_fn = ax.axhline if orientation == "h" else ax.axvline
    line_fn(value, color=color, linestyle=linestyle, linewidth=linewidth, alpha=alpha)

    if label:
        if orientation == "h":
            _x = ax.get_xlim()[1] if label_pos == "right" else ax.get_xlim()[0]
            _ha = "right" if label_pos == "right" else "left"
            ax.text(
                _x, value, f" {label} ",
                fontsize=FONTS["small"], color=color, fontweight="bold",
                va="bottom", ha=_ha,
            )
        else:
            _y = ax.get_ylim()[1] if label_pos == "top" else ax.get_ylim()[0]
            _va = "top" if label_pos == "top" else "bottom"
            ax.text(
                value, _y, f" {label} ",
                fontsize=FONTS["small"], color=color, fontweight="bold",
                va=_va, ha="left",
            )


def add_source(
    fig: plt.Figure,
    text: str,
    *,
    color: str | None = None,
    fontsize: int | None = None,
) -> None:
    """Add a source attribution line at bottom-right of the figure.

    Parameters
    ----------
    fig : Figure
    text : str
        e.g. "Source: EIA Form 860, 2024"
    color : str, optional
        Defaults to INK_LIGHT.
    fontsize : int, optional
        Defaults to FONTS["caption"].
    """
    fig.text(
        0.98, 0.012,
        text,
        ha="right", va="bottom",
        fontsize=fontsize or FONTS["caption"],
        color=color or INK_LIGHT,
        transform=fig.transFigure,
    )


def add_rule(
    ax: plt.Axes,
    *,
    color: str | None = None,
    linewidth: float = 1.0,
    position: str = "bottom",
) -> None:
    """Draw a thin horizontal rule at the top or bottom of the axes frame.

    A single line used consistently is the lightest possible signature element.

    Parameters
    ----------
    ax : Axes
    color : str, optional
        Defaults to RULE (matches site --rule).
    linewidth : float
        Default 1.0.
    position : str
        "top" or "bottom". Default "bottom".
    """
    from matplotlib.lines import Line2D
    c = color or _RULE
    pos = ax.get_position()
    y = pos.y0 if position == "bottom" else pos.y1
    ax.figure.add_artist(
        Line2D(
            [pos.x0, pos.x1], [y, y],
            transform=ax.figure.transFigure,
            color=c, linewidth=linewidth, clip_on=False,
        )
    )


def add_brand_mark(
    fig: plt.Figure,
    *,
    logo_path: str | None = None,
    text: str = "TZD Labs",
    color: str | None = None,
    fontsize: int | None = None,
    logo_height: float = 0.04,
) -> None:
    """Place the TZD Labs brand mark in the lower-left corner of the figure.

    Uses the logo PNG if *logo_path* is provided and the file exists;
    falls back to text-only if not.

    Parameters
    ----------
    fig : Figure
    logo_path : path to the TZD Labs transparent logo PNG.
        Typically passed as ``str(Path(__file__).parent / "assets/tzdlabs_mark.png")``
        or an absolute path resolved by the notebook.
    text : fallback text when logo is absent. Default "TZD Labs".
    color : text color. Defaults to INK_LIGHT.
    fontsize : text size. Defaults to FONTS["caption"].
    logo_height : logo height as fraction of figure height. Default 0.04.
    """
    from pathlib import Path as _Path

    _color = color or INK_LIGHT
    _fontsize = fontsize or FONTS["caption"]

    _logo = _Path(logo_path) if logo_path else None
    if _logo and _logo.exists():
        from matplotlib.image import imread  # noqa: PLC0415
        from matplotlib.offsetbox import AnnotationBbox, OffsetImage  # noqa: PLC0415

        img = imread(str(_logo))
        ax_logo = fig.add_axes([0.0, 0.0, 1.0, 1.0], zorder=10)
        ax_logo.set_axis_off()
        im = OffsetImage(img, zoom=logo_height * 0.5)
        ab = AnnotationBbox(
            im, (0.02, 0.02),
            xycoords="figure fraction",
            frameon=False,
            box_alignment=(0, 0),
        )
        ax_logo.add_artist(ab)
    else:
        fig.text(
            0.02, 0.012,
            text,
            ha="left", va="bottom",
            fontsize=_fontsize,
            color=_color,
            transform=fig.transFigure,
        )


def legend_below(
    ax: plt.Axes,
    *,
    ncol: int | None = None,
    handles: list | None = None,
    labels: list[str] | None = None,
    **kwargs: object,
) -> None:
    """Place legend below the axes in a horizontal column layout.

    Works with save_fig's ``bbox_inches='tight'`` to auto-expand the
    saved figure so the legend is never clipped.

    Parameters
    ----------
    ax : Axes
        The axes whose legend to relocate.
    ncol : int, optional
        Number of columns.  Defaults to ``min(len(handles), 5)``.
    handles, labels : optional
        Explicit legend handles/labels.  When *None*, pulled from *ax*.
    **kwargs
        Forwarded to ``ax.legend()``.
    """
    if handles is None:
        h, lab = ax.get_legend_handles_labels()
        handles = h
        if labels is None:
            labels = lab
    elif labels is None:
        labels = [h.get_label() for h in handles]
    if not handles:
        return
    if ncol is None:
        ncol = min(len(handles), 5)
    old = ax.get_legend()
    if old:
        old.remove()
    _anchor = kwargs.pop("bbox_to_anchor", (0.5, -0.15))
    _fontsize = kwargs.pop("fontsize", FONTS["legend"])
    _merged = {**LEGEND_DEFAULTS, **kwargs}
    ax.legend(
        handles, labels,
        loc="upper center",
        bbox_to_anchor=_anchor,
        ncol=ncol,
        fontsize=_fontsize,
        frameon=False,
        **_merged,
    )
