"""Virtual machine snapshots management module."""

from abc import abstractmethod
from dataclasses import InitVar, dataclass, field
from datetime import datetime


@dataclass(frozen=True, slots=True)
class Snapshot:
    """Data structure that contains the virtual machine snapshot info."""

    id: str
    created_at: datetime = field(init=False)
    created_at_ts: InitVar[int]
    name: str
    parent_name: str | None
    is_applied: bool
    cpus: int
    ram: int
    description: str | None

    def __post_init__(self, created_at_ts: int):
        object.__setattr__(self, 'created_at', datetime.fromtimestamp(created_at_ts))

    @abstractmethod
    async def apply(self) -> None:
        """Apply the snapshot."""

    @abstractmethod
    async def destroy(self) -> None:
        """Destroy the snapshot."""
