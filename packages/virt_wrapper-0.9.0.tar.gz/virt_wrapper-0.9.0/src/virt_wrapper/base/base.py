"""Base module."""

import enum
from dataclasses import dataclass


@enum.unique
class HypervisorPlatform(enum.Enum):
    """Type of virtualization platform."""

    KVM = 'kvm'
    HYPERV = 'hyperv'


@dataclass(frozen=True, slots=True)
class AuthData:
    user: str
    password: str
