"""Virtual machine networks management module."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class VirtualNetworkInteface:
    """Data structure that contains the virtual machine network info."""

    mac: str
    switch: str
    addresses: list[str]

    def __post_init__(self):
        object.__setattr__(self, 'mac', self.mac.upper())
