"""Virtual machine disks management module."""

from abc import abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class VirtualDisk:
    """Data structure that contains the virtual machine disk info."""

    name: str
    path: str
    storage: str
    size: int
    used: int

    @abstractmethod
    async def resize(self, required_size: int) -> int:
        """Resize the virtual disk."""
