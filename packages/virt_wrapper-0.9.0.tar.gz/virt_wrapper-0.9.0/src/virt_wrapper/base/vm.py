"""Virtual machine management module."""

import enum
from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass

from .disk import VirtualDisk
from .memory import MemoryStat
from .network import VirtualNetworkInteface
from .snapshot import Snapshot


@enum.unique
class VirtualMachineState(enum.Enum):
    """Possible virtual machine states."""

    # Common states
    RUNNING = 'Running'
    PAUSED = 'Paused'
    # KVM states

    BLOCKED = 'Blocked'
    SHUTDOWN = 'Shutdown'
    SHUTOFF = 'Shutoff'
    CRASHED = 'Crashed'
    NOSTATE = 'No state'

    # Hyper-V states
    OTHER = 'Other'
    OFF = 'Off'
    STOPPING = 'Stopping'
    SAVED = 'Saved'
    STARTING = 'Starting'
    RESET = 'Reset'
    SAVING = 'Saving'
    PAUSING = 'Pausing'
    RESUMING = 'Resuming'
    FAST_SAVED = 'FastSaved'
    FAST_SAVING = 'FastSaving'
    FORCE_SHUTDOWN = 'ForceShutdown'
    FORCE_REBOOT = 'ForceReboot'
    HIBERNATED = 'Hibernated'
    RUNNING_CRITICAL = 'RunningCritical'
    OFF_CRITICAL = 'OffCritical'
    STOPPING_CRITICAL = 'StoppingCritical'
    SAVED_CRITICAL = 'SavedCritical'
    PAUSED_CRITICAL = 'PausedCritical'
    STARTING_CRITICAL = 'StartingCritical'
    RESET_CRITICAL = 'ResetCritical'
    SAVING_CRITICAL = 'SavingCritical'
    PAUSING_CRITICAL = 'PausingCritical'
    RESUMING_CRITICAL = 'ResumingCritical'
    FAST_SAVED_CRITICAL = 'FastSavedCritical'
    FAST_SAVING_CRITICAL = 'FastSavingCritical'


@dataclass(frozen=True, slots=True)
class VirtualMachine(ABC):
    """Essential class for managing the virtual machine."""

    id: str

    @abstractmethod
    async def get_name(self) -> str:
        """Get the virtual machine name."""

    @abstractmethod
    async def set_name(self, name: str) -> None:
        """Set new the virtual machine name."""

    @abstractmethod
    async def state(self) -> VirtualMachineState:
        """Get the virtual machine state."""

    @abstractmethod
    async def description(self) -> str | None:
        """Get the virtual machine description."""

    @abstractmethod
    async def guest_os(self) -> str | None:
        """Get the name of the virtual machine guest operating system."""

    @abstractmethod
    async def memory_stat(self) -> MemoryStat:
        """Get the memory statistic of the virtual machine."""

    @abstractmethod
    async def cpus(self) -> int:
        """Get cores number."""

    @abstractmethod
    async def set_cpus(self, cpus: int) -> None:
        """Change number of cores."""

    @abstractmethod
    async def snapshots(self) -> Sequence[Snapshot]:
        """Get the list of the virtual machine snapshots."""

    @abstractmethod
    async def disks(self) -> Sequence[VirtualDisk]:
        """Get the list of the virtual machine connected disks."""

    @abstractmethod
    async def networks(self) -> Sequence[VirtualNetworkInteface]:
        """Get the list of the virtual machine network adapters."""

    @abstractmethod
    async def run(self) -> None:
        """Power on the virtual machine."""

    @abstractmethod
    async def shutdown(self) -> None:
        """Shutdown the virtual machine."""

    @abstractmethod
    async def poweroff(self) -> None:
        """Force off the virtual machine."""

    @abstractmethod
    async def save(self) -> None:
        """Pause the virtual machine and temporarily saving its memory state to a file."""

    @abstractmethod
    async def suspend(self) -> None:
        """Pause the virtual machine and temporarily saving its memory state."""

    @abstractmethod
    async def resume(self) -> None:
        """Unpause the suspended virtual machine."""

    @abstractmethod
    async def snapshot_create(self, name: str, description: str) -> None:
        """Create a new snapshot of virtual machine."""

    @abstractmethod
    async def export(self, storage: str) -> str:
        """Export the virtual machine to a storage destination."""
