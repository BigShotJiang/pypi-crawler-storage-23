"""KVM snapshot driver."""

from dataclasses import dataclass, field

import libvirt

from ..base.snapshot import Snapshot
from .base import to_async


@dataclass(frozen=True, slots=True)
class KernelVirtualSnapshot(Snapshot):
    """Driver for managing the KVM snapshot."""

    domain: libvirt.virDomain = field(repr=False)
    snapshot: libvirt.virDomainSnapshot = field(repr=False)

    async def apply(self) -> None:
        await to_async(self.domain.revertToSnapshot, self.snapshot)

    async def destroy(self) -> None:
        await to_async(self.snapshot.delete)
