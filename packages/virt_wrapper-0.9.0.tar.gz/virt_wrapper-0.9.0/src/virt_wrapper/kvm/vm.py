"""Driver for libvirt virtual machine."""

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import cast
from xml.etree import ElementTree as ET

import libvirt

from ..base.exceptions import VirtWrapperError
from ..base.memory import MemoryStat
from ..base.network import VirtualNetworkInteface
from ..base.vm import VirtualMachine, VirtualMachineState
from .base import to_async
from .disk import KernelVirtualDisk
from .exceptions import wrap_libvirt
from .snapshot import KernelVirtualSnapshot

STATES = {
    libvirt.VIR_DOMAIN_RUNNING: 'Running',
    libvirt.VIR_DOMAIN_BLOCKED: 'Blocked',
    libvirt.VIR_DOMAIN_PAUSED: 'Paused',
    libvirt.VIR_DOMAIN_SHUTDOWN: 'Shutdown',
    libvirt.VIR_DOMAIN_SHUTOFF: 'Shutoff',
    libvirt.VIR_DOMAIN_CRASHED: 'Crashed',
    libvirt.VIR_DOMAIN_NOSTATE: 'No state',
}


@wrap_libvirt()
@dataclass(frozen=True, slots=True)
class KernelVirtualMachine(VirtualMachine):
    """Driver for managing the KVM virtual machine."""

    connect: libvirt.virConnect
    domain: libvirt.virDomain

    async def get_name(self) -> str:
        def _get_name() -> str:
            try:
                return self.domain.metadata(libvirt.VIR_DOMAIN_METADATA_TITLE, None)
            except libvirt.libvirtError:
                return self.domain.name()

        return await to_async(_get_name)

    async def state(self) -> VirtualMachineState:
        state, _ = await to_async(self.domain.state)
        return VirtualMachineState(STATES[state])

    async def set_name(self, name: str) -> None:
        await to_async(self.domain.setMetadata, libvirt.VIR_DOMAIN_METADATA_TITLE, name, None, None)

    async def description(self) -> str | None:
        try:
            return await to_async(self.domain.metadata, libvirt.VIR_DOMAIN_METADATA_DESCRIPTION, None)
        except libvirt.libvirtError:
            return None

    async def guest_os(self) -> str | None:
        try:
            guest_info = await to_async(self.domain.guestInfo)
            return guest_info.get('os.pretty-name')
        except libvirt.libvirtError:
            return None

    async def memory_stat(self) -> MemoryStat:
        def _collect() -> tuple[int, int, int, int]:
            if self.domain.state()[0] == libvirt.VIR_DOMAIN_SHUTOFF:
                actual = 0
                demand = 0
            else:
                memory_stats = self.domain.memoryStats()
                actual = memory_stats.get('actual')
                demand = actual - memory_stats.get('unused', actual)

            startup = self.domain.info()[2]
            maximum = self.domain.maxMemory()
            return startup, maximum, demand, actual

        startup, maximum, demand, actual = await to_async(_collect)

        return MemoryStat(
            startup=startup * 1024,
            maximum=maximum * 1024,
            demand=demand * 1024 if demand >= 0 else 0,
            assigned=actual * 1024,
        )

    async def cpus(self) -> int:
        return (await to_async(self.domain.info))[3]

    async def set_cpus(self, cpus: int) -> None:
        def _set() -> None:
            self.domain.setVcpusFlags(
                cpus,
                libvirt.VIR_DOMAIN_VCPU_MAXIMUM | libvirt.VIR_DOMAIN_AFFECT_CONFIG,
            )
            self.domain.setVcpusFlags(cpus, libvirt.VIR_DOMAIN_AFFECT_CONFIG)

        await to_async(_set)

    async def snapshots(self) -> Sequence[KernelVirtualSnapshot]:
        def _collect() -> Sequence[KernelVirtualSnapshot]:
            result = []

            snapshots_list = self.domain.listAllSnapshots()
            try:
                current_snapshot = self.domain.snapshotCurrent()
            except libvirt.libvirtError:
                return []
            current_snapshot_name = current_snapshot.getName()

            for snap in snapshots_list:
                snap_name = snap.getName()
                snap_xml = snap.getXMLDesc()
                tree_snap = ET.fromstring(snap_xml)

                cpus = tree_snap.find('domain/vcpu')
                ram = tree_snap.find('domain/currentMemory')
                description = tree_snap.find('description')
                created_at_ts = tree_snap.find('creationTime')

                try:
                    parent = snap.getParent().getName()
                except libvirt.libvirtError:
                    parent = None
                result.append(
                    KernelVirtualSnapshot(
                        id=snap_name,
                        name=snap_name,
                        description=description.text if description is not None else None,
                        parent_name=parent,
                        created_at_ts=int(created_at_ts.text or 0) if created_at_ts is not None else 0,
                        is_applied=snap_name == current_snapshot_name,
                        cpus=int(cpus.text or 0) if cpus is not None else 0,
                        ram=int(ram.text or 0) * 1024 if ram is not None else 0,
                        domain=self.domain,
                        snapshot=snap,
                    ),
                )
            return result

        return await to_async(_collect)

    async def disks(self) -> Sequence[KernelVirtualDisk]:
        def _collect_disks() -> Sequence[KernelVirtualDisk]:
            result = []
            domain_xml = self.domain.XMLDesc()

            for src in ET.fromstring(domain_xml).findall('devices/disk/source'):
                try:
                    if src.get('pool'):
                        storage_pool = self.connect.storagePoolLookupByName(src.get('pool'))
                        volume = storage_pool.storageVolLookupByName(src.get('volume'))
                    else:
                        volume = self.connect.storageVolLookupByPath(src.get('file'))
                        storage_pool = volume.storagePoolLookupByVolume()
                    _, size, used = volume.info()

                    parent_volume = volume
                    backing_path = ET.fromstringlist(volume.XMLDesc()).find('backingStore/path')
                    while backing_path is not None and backing_path.text:
                        if parent_volume is None:
                            msg = 'Unable to find parent volume path'
                            raise VirtWrapperError(msg)
                        parent_volume = self.connect.storageVolLookupByPath(backing_path.text)
                        backing_path = ET.fromstringlist(parent_volume.XMLDesc()).find('backingStore/path')

                    result.append(
                        KernelVirtualDisk(
                            name=parent_volume.name(),
                            path=volume.path(),
                            storage=storage_pool.name(),
                            size=size,
                            used=used,
                            volume=volume,
                            domain=self.domain,
                        ),
                    )
                except libvirt.libvirtError:
                    continue
            return result

        return await to_async(_collect_disks)

    async def networks(self) -> Sequence[VirtualNetworkInteface]:
        def _collect_networks() -> Sequence[VirtualNetworkInteface]:
            result = []
            domain_xml = self.domain.XMLDesc()
            domain_state, *_ = self.domain.state()
            addresses_map = {}
            if domain_state == libvirt.VIR_DOMAIN_RUNNING:
                try:
                    nets = self.domain.interfaceAddresses(libvirt.VIR_DOMAIN_INTERFACE_ADDRESSES_SRC_AGENT)
                except libvirt.libvirtError:
                    nets = self.domain.interfaceAddresses(libvirt.VIR_DOMAIN_INTERFACE_ADDRESSES_SRC_ARP)
                for data in nets.values():
                    if hwaddr := data.get('hwaddr'):
                        addrs = data.get('addrs')
                        addresses_map[hwaddr] = [addr.get('addr') for addr in addrs]

            for interface in ET.fromstring(domain_xml).findall('devices/interface'):
                mac = interface.find('mac')
                mac_address = '' if mac is None else mac.get('address', '')

                source = interface.find('source')
                switch_name = '' if source is None else source.get('bridge', '')

                result.append(
                    VirtualNetworkInteface(
                        mac=mac_address,
                        switch=switch_name,
                        addresses=addresses_map.get(mac_address, []),
                    ),
                )
            return result

        return await to_async(_collect_networks)

    async def get_displays(self) -> list[dict]:
        """Get virtual displays."""
        domain_xml = await to_async(self.domain.XMLDesc, libvirt.VIR_DOMAIN_XML_SECURE)

        return [
            {'Type': display.get('type'), 'Port': display.get('port'), 'Password': display.get('passwd')}
            for display in ET.fromstring(domain_xml).findall('devices/graphics')
        ]

    async def run(self) -> None:
        def _run() -> None:
            if self.domain.state()[0] != libvirt.VIR_DOMAIN_RUNNING:
                self.domain.create()

        return await to_async(_run)

    async def shutdown(self) -> None:
        await to_async(self.domain.shutdown)

    async def poweroff(self) -> None:
        await to_async(self.domain.destroy)

    async def save(self) -> None:
        await to_async(self.domain.managedSave)

    async def suspend(self) -> None:
        await to_async(self.domain.suspend)

    async def resume(self) -> None:
        await to_async(self.domain.resume)

    async def snapshot_create(self, name: str, description: str) -> None:
        """Create a new snapshot of virtual machine."""
        snapshot_xml_template = f"""<domainsnapshot>
            <name>{name}</name>
            <description>{description}</description>
        </domainsnapshot>"""
        await to_async(self.domain.snapshotCreateXML, snapshot_xml_template, libvirt.VIR_DOMAIN_SNAPSHOT_CREATE_ATOMIC)

    async def export(self, storage: str) -> str:
        """Export the virtual machine to a storage destination."""
        domain_name = await self.get_name()
        domain_disks = await self.disks()

        def _export_pool_and_prepare_path() -> tuple[libvirt.virStoragePool, str]:
            pool = self.connect.storagePoolLookupByName(storage)

            pool_xml = pool.XMLDesc()
            pool = ET.fromstring(pool_xml).find('target/path')
            if pool is None or pool.text is None:
                msg = 'Unable to find pool'
                raise ValueError(msg)

            target_pool_path = Path(pool.text) / domain_name
            target_pool_name = f'export_{domain_name}'

            xml_pool = f"""<pool type='dir'>
<name>{target_pool_name}</name>
<target>
    <path>{target_pool_path}</path>
    <permissions>
    <mode>0777</mode>
    </permissions>
</target>
</pool>
"""
            target_pool = cast(
                libvirt.virStoragePool,
                self.connect.storagePoolCreateXML(
                    xml_pool,
                    libvirt.VIR_STORAGE_POOL_CREATE_WITH_BUILD,
                ),
            )
            return target_pool, str(target_pool_path)

        def _export_disk(disk: KernelVirtualDisk, target_pool: libvirt.virStoragePool) -> str:
            volume = self.connect.storageVolLookupByPath(disk.path)
            xml_vol = f"""<volume>
<name>{volume.name()}</name>
<target>
    <permissions>
    <mode>0644</mode>
    <label>virt_image_t</label>
    </permissions>
</target>
</volume>"""
            target_pool.createXMLFrom(xml_vol, volume, 0)
            return volume.name()

        def _write_config(target_pool_path: str) -> None:
            config_path = Path(target_pool_path) / 'config.xml'
            with config_path.open('w', encoding='utf-8') as config:
                config.write(
                    self.domain.XMLDesc(
                        libvirt.VIR_DOMAIN_XML_INACTIVE
                        | libvirt.VIR_DOMAIN_XML_UPDATE_CPU
                        | libvirt.VIR_DOMAIN_XML_MIGRATABLE,
                    ),
                )

        target_pool = None
        try:
            target_pool, target_pool_path = await to_async(_export_pool_and_prepare_path)

            # Parallel disk export
            for disk in domain_disks:
                await to_async(_export_disk, disk, target_pool)
            await to_async(_write_config, target_pool_path)
        except libvirt.libvirtError:
            raise
        else:
            return target_pool_path
        finally:
            if target_pool is not None:
                target_pool.destroy()
