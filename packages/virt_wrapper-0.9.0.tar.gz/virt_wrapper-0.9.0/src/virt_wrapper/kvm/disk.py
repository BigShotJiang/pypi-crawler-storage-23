"""KVM virtual disk driver."""

from dataclasses import dataclass, field

import libvirt

from ..base.disk import VirtualDisk
from .base import to_async


@dataclass(frozen=True, slots=True)
class KernelVirtualDisk(VirtualDisk):
    """Driver for managing the KVM virtual disk."""

    domain: libvirt.virDomain = field(repr=False)
    volume: libvirt.virStorageVol = field(repr=False)

    async def resize(self, required_size: int) -> int:
        domain_state = await to_async(self.domain.state)
        if domain_state[0] == libvirt.VIR_DOMAIN_RUNNING:
            await to_async(lambda: self.domain.blockResize(self.volume.path(), required_size))
        else:
            await to_async(self.volume.resize, required_size, libvirt.VIR_STORAGE_VOL_RESIZE_SHRINK)

        new_size = (await to_async(self.volume.info))[1]
        object.__setattr__(self, 'size', new_size)
        return new_size
