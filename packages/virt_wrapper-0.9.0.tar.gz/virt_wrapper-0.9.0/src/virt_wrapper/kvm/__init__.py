"""__init__."""

import libvirt

from .disk import KernelVirtualDisk
from .hypervisor import KernelVirtualHost
from .snapshot import KernelVirtualSnapshot
from .vm import KernelVirtualMachine


def libvirt_callback(ctx, err) -> None:  # pylint: disable=unused-argument
    """Avoid printing error messages."""


libvirt.registerErrorHandler(f=libvirt_callback, ctx=None)

__all__ = [
    'KernelVirtualDisk',
    'KernelVirtualHost',
    'KernelVirtualMachine',
    'KernelVirtualSnapshot',
]
