"""KVM drivers."""

import asyncio
from collections.abc import Callable

import libvirt


def request_cred(user: str, password: str):
    """Callback function for authentication."""

    def inner(credentials: list, user_data) -> int:  # pylint: disable=unused-argument
        for credential in credentials:
            if credential[0] == libvirt.VIR_CRED_AUTHNAME:
                credential[4] = user
            elif credential[0] == libvirt.VIR_CRED_PASSPHRASE:
                credential[4] = password
        return 0

    return inner


async def to_async[T](func: Callable[..., T], *args, **kwargs) -> T:
    return await asyncio.to_thread(func, *args, **kwargs)
