"""Hyper-V virtual disk driver."""

from dataclasses import dataclass, field

import psrp

from ..base.disk import VirtualDisk

from .base import HyperVirtualDriver


@dataclass(frozen=True, slots=True)
class HyperVirtualDisk(VirtualDisk, HyperVirtualDriver):
    """Driver for managing the Hyper-V virtual disk."""

    conn: psrp.WSManInfo = field(repr=False)

    async def resize(self, required_size: int) -> int:
        async with self.get_ps() as ps:
            ps.add_command('Resize-VHD')
            ps.add_parameters(Path=self.path, SizeBytes=required_size)
            ps.add_statement()
            ps.add_command('Get-VHD')
            ps.add_parameter('Path', self.path)
            ps.add_command('Select')
            ps.add_parameter('Property', 'Size')
            result = await self.exec_ps(ps)
        new_size = result[0].Size
        object.__setattr__(self, 'size', new_size)
        return new_size
