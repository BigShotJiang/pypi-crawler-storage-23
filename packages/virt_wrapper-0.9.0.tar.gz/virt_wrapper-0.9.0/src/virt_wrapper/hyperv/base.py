"""Base for Hyper-V driver."""

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

import psrp

from ..base.exceptions import (
    VirtualMachineError,
    VirtualMachineNotFoundError,
    VirtualMachineStateError,
    VirtWrapperError,
)

EXCEPTIONS_MAP = {
    'Microsoft.HyperV.PowerShell.Commands.GetVM': {
        'ObjectNotFound': VirtualMachineNotFoundError,
        'Default': VirtualMachineError,
    },
    'Microsoft.HyperV.PowerShell.Commands.SaveVM': {
        'InvalidState': VirtualMachineStateError,
        'Default': VirtualMachineError,
    },
    'Microsoft.HyperV.PowerShell.Commands.SuspendVM': {
        'InvalidState': VirtualMachineStateError,
        'Default': VirtualMachineError,
    },
    'Microsoft.HyperV.PowerShell.Commands.ResumeVM': {
        'InvalidState': VirtualMachineStateError,
        'Default': VirtualMachineError,
    },
    'Microsoft.HyperV.PowerShell.Commands.ImportVM': {
        'ObjectNotFound': VirtualMachineNotFoundError,
    },
}


class HyperVirtualDriver:
    """Common class for connecting to Hyper-V server."""

    conn: psrp.WSManInfo

    @asynccontextmanager
    async def get_ps(self) -> AsyncGenerator[psrp.AsyncPowerShell, None]:
        """Get powershell."""
        async with psrp.AsyncRunspacePool(self.conn) as rp:
            yield psrp.AsyncPowerShell(rp)

    async def exec_ps(self, ps: psrp.AsyncPowerShell) -> list[Any]:
        """Execute powershell command."""
        result = await ps.invoke()
        if ps.had_errors:
            error = ps.streams.error[0]
            try:
                error_id, source = error.FullyQualifiedErrorId.split(',')
            except ValueError as exc:
                raise VirtWrapperError(str(error)) from exc

            if source in EXCEPTIONS_MAP:
                exception = EXCEPTIONS_MAP[source].get(error_id, 'Default')
                raise exception(str(error))
            raise VirtWrapperError(str(error))
        return result
