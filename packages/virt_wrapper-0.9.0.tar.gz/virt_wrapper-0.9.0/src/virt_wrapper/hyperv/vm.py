"""Driver for Hyper-V virtual machine."""

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import psrp

from ..base.memory import MemoryStat
from ..base.network import VirtualNetworkInteface
from ..base.vm import VirtualMachine, VirtualMachineState
from .base import HyperVirtualDriver
from .disk import HyperVirtualDisk
from .snapshot import HyperVirtualSnapshot


@dataclass(frozen=True, slots=True)
class HyperVirtualMachine(VirtualMachine, HyperVirtualDriver):
    """Driver for managing the Hyper-V virtual machine."""

    conn: psrp.WSManInfo

    async def __get_vm_property(self, prop: str | list[str]) -> Any:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Select')
            ps.add_parameter('Property', prop)
            result = await self.exec_ps(ps=ps)
        return result[0]

    async def get_name(self) -> str:
        result = await self.__get_vm_property('Name')
        return result.Name

    async def set_name(self, name: str) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Rename-VM')
            ps.add_parameter('NewName', name)
            await self.exec_ps(ps=ps)
        object.__setattr__(self, 'name', name)

    async def state(self) -> VirtualMachineState:
        result = await self.__get_vm_property('State')
        return VirtualMachineState(str(result.State))

    async def description(self) -> str | None:
        result = await self.__get_vm_property('Notes')
        return result.Notes

    async def guest_os(self) -> str | None:
        async with self.get_ps() as ps:
            ps.add_command('Get-WmiObject')
            ps.add_parameter('Namespace', r'root\virtualization\v2')
            ps.add_parameter('Query', f"Select * From Msvm_SummaryInformation Where Name='{self.id}'")
            ps.add_command('Select')
            ps.add_parameter('Property', 'GuestOperatingSystem')
            result = await self.exec_ps(ps=ps)
        return result[0].GuestOperatingSystem

    async def memory_stat(self) -> MemoryStat:
        result = await self.__get_vm_property(['MemoryStartup', 'MemoryMaximum', 'MemoryDemand', 'MemoryAssigned'])
        return MemoryStat(
            startup=result.MemoryStartup,
            maximum=result.MemoryMaximum,
            demand=result.MemoryDemand,
            assigned=result.MemoryAssigned,
        )

    async def cpus(self) -> int:
        result = await self.__get_vm_property('ProcessorCount')
        return result.ProcessorCount

    async def set_cpus(self, cpus: int) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Set-VMProcessor')
            ps.add_parameter('Count', cpus)
            await self.exec_ps(ps=ps)

    async def snapshots(self) -> Sequence[HyperVirtualSnapshot]:
        vm_parent_snapshot = await self.__get_vm_property('ParentSnapshotName')
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Get-VMSnapshot')
            ps.add_command('Select')
            ps.add_parameter(
                'Property',
                ['Id', 'Name', 'Notes', 'ParentSnapshotName', 'CreationTime', 'ProcessorCount', 'MemoryStartup'],
            )
            result = await self.exec_ps(ps)
        snapshots = []
        for r in result:
            snapshots.append(
                HyperVirtualSnapshot(
                    id=str(r.Id),
                    name=r.Name,
                    description=r.Notes,
                    parent_name=r.ParentSnapshotName,
                    created_at_ts=r.CreationTime.timestamp(),
                    is_applied=r.Name == vm_parent_snapshot.ParentSnapshotName,
                    cpus=r.ProcessorCount,
                    ram=r.MemoryStartup,
                    conn=self.conn,
                ),
            )
        return snapshots

    async def disks(self) -> Sequence[HyperVirtualDisk]:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Get-VMHardDiskDrive').add_command('Get-VHD')

            result = await self.exec_ps(ps)
        disks = []
        for d in result:
            disks.append(
                HyperVirtualDisk(
                    name=str(d.Path).rsplit('\\', maxsplit=1)[-1],
                    path=d.Path,
                    storage=d.Path[0],
                    size=d.Size,
                    used=d.FileSize,
                    conn=self.conn,
                ),
            )
        return disks

    async def networks(self) -> Sequence[VirtualNetworkInteface]:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('VMNetworkAdapter')
            ps.add_command('Select')
            ps.add_parameter('Property', ['MacAddress', 'SwitchName', 'IPAddresses'])
            result = await self.exec_ps(ps)
        networks = []
        for n in result:
            networks.append(
                VirtualNetworkInteface(
                    mac=bytes.fromhex(n.MacAddress).hex(':'),
                    switch=n.SwitchName,
                    addresses=n.IPAddresses,
                ),
            )
        return networks

    async def run(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Start-VM')
            await self.exec_ps(ps)

    async def shutdown(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Stop-VM')
            ps.add_parameter('Force', True)
            await self.exec_ps(ps)

    async def poweroff(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Stop-VM')
            ps.add_parameter('TurnOff', True)
            await self.exec_ps(ps)

    async def save(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Save-VM')
            await self.exec_ps(ps)

    async def suspend(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Suspend-VM')
            await self.exec_ps(ps)

    async def resume(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Resume-VM')
            await self.exec_ps(ps)

    async def snapshot_create(self, name: str, description: str) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Checkpoint-VM')
            ps.add_parameter('SnapshotName', name)
            ps.add_parameter('-Passthru', True)
            ps.add_command('Select')
            ps.add_parameter('Property', 'Id')
            result = await self.exec_ps(ps)

        snapshot_id = result[0].Id

        async with self.get_ps() as ps:
            ps.add_script(rf"""
                $snapshot = Get-CimInstance -Namespace root\virtualization\v2 -Query "SELECT * FROM Msvm_VirtualSystemSettingData WHERE InstanceID LIKE '%{snapshot_id}%'"

                $snapshot.Notes = "{description}"
                $serializer = [Microsoft.Management.Infrastructure.Serialization.CimSerializer]::Create()
                $snapshotBytes = $serializer.Serialize( $snapshot, [Microsoft.Management.Infrastructure.Serialization.InstanceSerializationOptions]::None )
                $snapshotStr   = [Text.Encoding]::Unicode.GetString( $snapshotBytes )
                $service = Get-CimInstance -Namespace 'root\virtualization\v2' -class 'Msvm_VirtualSystemManagementService'
                $result = $service | Invoke-CimMethod -MethodName ModifySystemSettings -Arguments @{{ SystemSettings = $snapshotStr }}

                if( $result.ReturnValue -notin 0, 4096 ) {{
                    $PSCmdlet.WriteError( [Management.Automation.ErrorRecord]::new(
                        [Exception]::new("Failed to set VM notes for snapshot '$SnapshotName' of VM '$VmName'"), 'ModifySystemSettingsFailed', [Management.Automation.ErrorCategory]::InvalidResult, $result.ReturnValue ))
                    return
                }}
            """)
            result = await self.exec_ps(ps)

    async def export(self, storage: str) -> str:
        destination_path = Path(f'{storage}:') / 'hyperv' / 'export'
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', self.id)
            ps.add_command('Export-VM')
            ps.add_parameter('Path', str(destination_path))
            await self.exec_ps(ps)

        return str(Path(destination_path) / await self.get_name())
