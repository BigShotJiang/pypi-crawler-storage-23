"""Hyper-V snapshot driver."""

from dataclasses import dataclass, field

import psrp

from ..base.snapshot import Snapshot
from .base import HyperVirtualDriver


@dataclass(frozen=True, slots=True)
class HyperVirtualSnapshot(Snapshot, HyperVirtualDriver):
    """Driver for managing the Hyper-V snapshot."""

    conn: psrp.WSManInfo = field(repr=False)

    async def apply(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VMSnapshot')
            ps.add_parameter('Id', self.id)
            ps.add_command('Restore-VMSnapshot')
            ps.add_parameter('Confirm', False)
            await self.exec_ps(ps)

    async def destroy(self) -> None:
        async with self.get_ps() as ps:
            ps.add_command('Get-VMSnapshot')
            ps.add_parameter('Id', self.id)
            ps.add_command('Remove-VMSnapshot')
            ps.add_parameter('Confirm', False)
            await self.exec_ps(ps)
