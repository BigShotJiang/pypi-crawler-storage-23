# Description

Python wrapper for managing virtual infrastructure based on Hyper-V or KVM (libvirt)

# Example usage
## Get all VMs on particular hypervisor
```python
import asyncio

from virt_wrapper import AuthData, Hypervisor, HypervisorPlatform


async def main():
    async with Hypervisor.create(
        HypervisorPlatform.KVM,  # Or HypervisorPlatform.HYPERV
        host='localhost',
        auth=AuthData('user', 'pass')
    ) as srv:
        for vm in await srv.get_vms():
            print(await vm.get_name())
            
        # Get VM by ID
        vm = await srv.get_vm(vm_id='71e8f28b-0cb5-42f4-95b3-5ffc68738733')
        print(await vm.get_name())


if __name__ == '__main__':
    asyncio.run(main())
```


# Requirements
## KVM

- SSH-key must be imported on target server
- User must have full access to libvirt
```sh
usermod <your_user> -aG libvirt
systemctl restart libvirtd
```

## Hyper-V
- User must have full access to Hyper-V
- WinRM must be enabled with this parameters
    - HTTPS
    - Basic auth

```powershell
# Enables the WinRM service and sets up the HTTP listener
Enable-PSRemoting -Force

# Create HTTPS listener
$httpsParams = @{
    ResourceURI = 'winrm/config/listener'
    SelectorSet = @{
        Transport = "HTTPS"
        Address   = "*"
    }
    ValueSet = @{
        CertificateThumbprint = ""
        Enabled               = $true
    }
}
New-WSManInstance @httpsParams

# Enable basic auth
Set-Item -Path WSMan:\localhost\Service\Auth\Basic -Value $true

# Opens port 5986 for all profiles
$firewallParams = @{
    Action      = 'Allow'
    Description = 'Inbound rule for Windows Remote Management via WS-Management. [TCP 5986]'
    Direction   = 'Inbound'
    DisplayName = 'Windows Remote Management (HTTPS-In)'
    LocalPort   = 5986
    Profile     = 'Any'
    Protocol    = 'TCP'
}
New-NetFirewallRule @firewallParams
```

# Available functions:
- [x] Managing snapshots
- [x] Managing virtual disks
- [x] Managing networks
- [x] Getting info about VM (state, description, guest OS, etc.)
- [x] Controling VM (run, shutdown, pause, etc)
- [x] Export/Import virtual machines
- [ ] Migrating
- [ ] Cloning
