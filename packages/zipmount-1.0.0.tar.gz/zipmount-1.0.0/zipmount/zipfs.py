#!/usr/bin/env python3
"""FUSE filesystem that mounts a ZIP file as a read/write directory.

Data safety guarantees:
- CRC32 verification on every file read from ZIP
- Backup (.bak) kept before every save
- fsync on written file AND parent directory
- Post-save verification (re-read + CRC check)
- Append-only journal for crash recovery
- fcntl exclusive lock prevents concurrent mounts
- Dirty tracking — only saves when state actually changed
"""

import os
import sys
import stat
import time
import errno
import zipfile
import json
import base64
import fcntl
import zlib

from fuse import FUSE, FuseOSError, Operations


class Journal:
    """Append-only write-ahead log. Survives crashes so no mutation is ever lost."""

    def __init__(self, path):
        self.path = path
        self._fd = None

    def open(self):
        self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)

    def log(self, entry):
        """Write one journal entry and fsync to guarantee it's on disk."""
        line = json.dumps(entry, separators=(',', ':')) + '\n'
        os.write(self._fd, line.encode())
        os.fsync(self._fd)

    def replay(self):
        """Read all entries from an existing journal file."""
        if not os.path.isfile(self.path):
            return []
        entries = []
        with open(self.path, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        break  # Partial write at crash point — stop here
        return entries

    def clear(self):
        """Delete journal after a successful save."""
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None
        if os.path.isfile(self.path):
            os.unlink(self.path)
        self.open()

    def close(self):
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None


class ZipFS(Operations):
    def __init__(self, zippath):
        self.zippath = os.path.abspath(zippath)
        self.bakpath = self.zippath + '.bak'
        self.now = time.time()
        self.files = {}       # path -> bytes
        self.dirs = set()
        self.dirs.add('/')
        self._dirty = False
        self._lock_fd = None
        self._journal = Journal(self.zippath + '.journal')

        self._acquire_lock()
        self._recover_if_needed()
        self._load_zip()
        self._replay_journal()
        self._journal.open()

    # ── Lock ──────────────────────────────────────────────────────────

    def _acquire_lock(self):
        """Exclusive lock prevents two mounts on the same ZIP."""
        lockpath = self.zippath + '.lock'
        self._lock_fd = os.open(lockpath, os.O_WRONLY | os.O_CREAT, 0o644)
        try:
            fcntl.flock(self._lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            os.close(self._lock_fd)
            print(f"Error: '{self.zippath}' is already mounted by another process", file=sys.stderr)
            sys.exit(1)

    def _release_lock(self):
        if self._lock_fd is not None:
            fcntl.flock(self._lock_fd, fcntl.LOCK_UN)
            os.close(self._lock_fd)
            self._lock_fd = None
            lockpath = self.zippath + '.lock'
            if os.path.isfile(lockpath):
                os.unlink(lockpath)

    # ── Crash recovery ────────────────────────────────────────────────

    def _recover_if_needed(self):
        """If a .bak exists with a corrupt/missing main ZIP, restore from backup."""
        if os.path.isfile(self.bakpath):
            if not os.path.isfile(self.zippath) or not self._verify_zip(self.zippath):
                print(f"Recovery: restoring from backup '{self.bakpath}'", file=sys.stderr)
                os.replace(self.bakpath, self.zippath)
            else:
                os.unlink(self.bakpath)

    def _replay_journal(self):
        """Replay journal entries to recover mutations lost in a crash."""
        entries = self._journal.replay()
        if not entries:
            return
        print(f"Recovery: replaying {len(entries)} journal entries", file=sys.stderr)
        for e in entries:
            op = e.get('op')
            if op == 'write':
                path = e['path']
                data = base64.b64decode(e['data'])
                offset = e['offset']
                if path not in self.files:
                    self.files[path] = b''
                content = self.files[path]
                if offset > len(content):
                    content = content + b'\x00' * (offset - len(content))
                self.files[path] = content[:offset] + data + content[offset + len(data):]
            elif op == 'create':
                self.files[e['path']] = b''
                parent = os.path.dirname(e['path'])
                if parent and parent != '/':
                    self.dirs.add(parent)
            elif op == 'truncate':
                path = e['path']
                if path in self.files:
                    self.files[path] = self.files[path][:e['length']]
            elif op == 'unlink':
                self.files.pop(e['path'], None)
            elif op == 'mkdir':
                self.dirs.add(e['path'])
            elif op == 'rmdir':
                self.dirs.discard(e['path'])
            elif op == 'rename':
                old, new = e['old'], e['new']
                if old in self.files:
                    self.files[new] = self.files.pop(old)
                elif old in self.dirs:
                    self.dirs.discard(old)
                    self.dirs.add(new)
                    prefix = old.rstrip('/') + '/'
                    newprefix = new.rstrip('/') + '/'
                    for p in list(self.files):
                        if p.startswith(prefix):
                            self.files[newprefix + p[len(prefix):]] = self.files.pop(p)
                    for d in list(self.dirs):
                        if d.startswith(prefix):
                            self.dirs.discard(d)
                            self.dirs.add(newprefix + d[len(prefix):])
        self._dirty = True
        # Immediately persist recovered state
        self._save_zip()

    # ── ZIP I/O with integrity checks ─────────────────────────────────

    def _load_zip(self):
        """Load ZIP contents with CRC32 verification on every file."""
        with zipfile.ZipFile(self.zippath, 'r') as zf:
            # Check for any ZIP-level errors first
            bad = zf.testzip()
            if bad is not None:
                print(f"Error: corrupt file in ZIP: '{bad}'", file=sys.stderr)
                sys.exit(1)

            for info in zf.infolist():
                path = '/' + info.filename
                if info.is_dir():
                    self.dirs.add(path.rstrip('/'))
                else:
                    data = zf.read(info.filename)
                    # Verify CRC32 matches what the ZIP header says
                    if zlib.crc32(data) & 0xFFFFFFFF != info.CRC:
                        print(f"Error: CRC mismatch for '{info.filename}'", file=sys.stderr)
                        sys.exit(1)
                    self.files[path] = data
                # Ensure parent dirs exist
                parts = path.strip('/').split('/')
                for i in range(1, len(parts)):
                    self.dirs.add('/' + '/'.join(parts[:i]))

    @staticmethod
    def _verify_zip(path):
        """Return True if the ZIP at path is valid and all CRCs pass."""
        try:
            with zipfile.ZipFile(path, 'r') as zf:
                return zf.testzip() is None
        except (zipfile.BadZipFile, OSError):
            return False

    @staticmethod
    def _fsync_dir(dirpath):
        """fsync a directory to ensure rename/unlink metadata is on disk."""
        fd = os.open(dirpath, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

    def _save_zip(self):
        """Atomic save: write tmp → fsync → verify → backup original → rename → fsync dir → clear journal."""
        if not self._dirty:
            return

        tmppath = self.zippath + '.tmp'
        parent_dir = os.path.dirname(self.zippath)

        # 1. Write to temp file
        with zipfile.ZipFile(tmppath, 'w', zipfile.ZIP_DEFLATED) as zf:
            for d in sorted(self.dirs):
                if d != '/':
                    zf.writestr(d.lstrip('/') + '/', '')
            for path, data in sorted(self.files.items()):
                zf.writestr(path.lstrip('/'), data)

        # 2. fsync the temp file to guarantee bits are on disk
        fd = os.open(tmppath, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

        # 3. Verify the temp file is a valid ZIP with correct CRCs
        if not self._verify_zip(tmppath):
            os.unlink(tmppath)
            print("Error: written ZIP failed verification, aborting save", file=sys.stderr)
            return

        # 4. Backup original (so we can recover if rename fails)
        if os.path.isfile(self.zippath):
            os.replace(self.zippath, self.bakpath)
            self._fsync_dir(parent_dir)

        # 5. Atomic rename tmp → original (same device = atomic)
        os.rename(tmppath, self.zippath)
        self._fsync_dir(parent_dir)

        # 6. Remove backup — save fully committed
        if os.path.isfile(self.bakpath):
            os.unlink(self.bakpath)

        # 7. Clear journal — all mutations are now in the ZIP
        self._journal.clear()
        self._dirty = False

    # ── FUSE operations ───────────────────────────────────────────────

    def getattr(self, path, fh=None):
        if path in self.dirs:
            return dict(st_mode=stat.S_IFDIR | 0o755, st_nlink=2,
                        st_uid=os.getuid(), st_gid=os.getgid(),
                        st_atime=self.now, st_mtime=self.now, st_ctime=self.now)
        if path in self.files:
            return dict(st_mode=stat.S_IFREG | 0o644, st_nlink=1,
                        st_size=len(self.files[path]),
                        st_uid=os.getuid(), st_gid=os.getgid(),
                        st_atime=self.now, st_mtime=self.now, st_ctime=self.now)
        raise FuseOSError(errno.ENOENT)

    def readdir(self, path, fh):
        entries = ['.', '..']
        prefix = path.rstrip('/') + '/'
        seen = set()
        for p in list(self.files.keys()) + [d for d in self.dirs if d != '/']:
            if p.startswith(prefix):
                name = p[len(prefix):].split('/')[0]
                if name and name not in seen:
                    seen.add(name)
                    entries.append(name)
        return entries

    def read(self, path, size, offset, fh):
        if path not in self.files:
            raise FuseOSError(errno.ENOENT)
        return self.files[path][offset:offset + size]

    def write(self, path, data, offset, fh):
        if path not in self.files:
            raise FuseOSError(errno.ENOENT)
        # Journal FIRST, then mutate — guarantees recoverability
        self._journal.log({'op': 'write', 'path': path,
                           'data': base64.b64encode(data).decode(), 'offset': offset})
        content = self.files[path]
        # Pad with zeros if writing beyond current length
        if offset > len(content):
            content = content + b'\x00' * (offset - len(content))
        self.files[path] = content[:offset] + data + content[offset + len(data):]
        self._dirty = True
        return len(data)

    def create(self, path, mode, fi=None):
        self._journal.log({'op': 'create', 'path': path})
        self.files[path] = b''
        parent = os.path.dirname(path)
        if parent and parent != '/':
            self.dirs.add(parent)
        self._dirty = True
        return 0

    def truncate(self, path, length, fh=None):
        if path not in self.files:
            raise FuseOSError(errno.ENOENT)
        self._journal.log({'op': 'truncate', 'path': path, 'length': length})
        self.files[path] = self.files[path][:length]
        self._dirty = True

    def unlink(self, path):
        if path not in self.files:
            raise FuseOSError(errno.ENOENT)
        self._journal.log({'op': 'unlink', 'path': path})
        del self.files[path]
        self._dirty = True

    def mkdir(self, path, mode):
        self._journal.log({'op': 'mkdir', 'path': path})
        self.dirs.add(path)
        self._dirty = True

    def rmdir(self, path):
        prefix = path.rstrip('/') + '/'
        for p in list(self.files.keys()) + list(self.dirs):
            if p.startswith(prefix):
                raise FuseOSError(errno.ENOTEMPTY)
        self._journal.log({'op': 'rmdir', 'path': path})
        self.dirs.discard(path)
        self._dirty = True

    def rename(self, old, new):
        if old not in self.files and old not in self.dirs:
            raise FuseOSError(errno.ENOENT)
        self._journal.log({'op': 'rename', 'old': old, 'new': new})
        if old in self.files:
            self.files[new] = self.files.pop(old)
        elif old in self.dirs:
            self.dirs.discard(old)
            self.dirs.add(new)
            prefix = old.rstrip('/') + '/'
            newprefix = new.rstrip('/') + '/'
            for p in list(self.files):
                if p.startswith(prefix):
                    self.files[newprefix + p[len(prefix):]] = self.files.pop(p)
            for d in list(self.dirs):
                if d.startswith(prefix):
                    self.dirs.discard(d)
                    self.dirs.add(newprefix + d[len(prefix):])
        self._dirty = True

    def flush(self, path, fh):
        self._save_zip()
        return 0

    def release(self, path, fh):
        self._save_zip()
        return 0

    def destroy(self, path):
        self._save_zip()
        self._journal.close()
        self._release_lock()

    # No-ops needed for compatibility
    def chmod(self, path, mode): return 0
    def chown(self, path, uid, gid): return 0
    def utimens(self, path, times=None): return 0
    def open(self, path, flags): return 0


def mount(zippath, mountpoint, foreground=True):
    if not os.path.isfile(zippath):
        print(f"Error: '{zippath}' not found", file=sys.stderr)
        sys.exit(1)
    os.makedirs(mountpoint, exist_ok=True)
    print(f"Mounting '{zippath}' at '{mountpoint}'")
    print(f"Unmount with: umount '{mountpoint}'")
    FUSE(ZipFS(zippath), mountpoint, foreground=foreground, nothreads=True, allow_other=False)
