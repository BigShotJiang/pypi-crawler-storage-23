#!/usr/bin/env python3
"""CLI entry point for zipmount. Installs core files to ~/.zipmount on first run."""

import argparse
import os
import sys
import shutil
import subprocess
import venv

INSTALL_DIR = os.path.expanduser("~/.zipmount")
VENV_DIR = os.path.join(INSTALL_DIR, ".venv")


def _ensure_installed():
    """Set up ~/.zipmount with a venv and fusepy on first run."""
    marker = os.path.join(INSTALL_DIR, ".installed")
    if os.path.isfile(marker):
        return

    os.makedirs(INSTALL_DIR, exist_ok=True)

    # Copy core files
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    for f in ("zipfs.py", "__init__.py"):
        src = os.path.join(pkg_dir, f)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(INSTALL_DIR, f))

    # Create venv + install fusepy
    if not os.path.isdir(VENV_DIR):
        venv.create(VENV_DIR, with_pip=True)
    pip = os.path.join(VENV_DIR, "bin", "pip")
    subprocess.run([pip, "install", "-q", "fusepy"], check=True)

    # Write marker
    with open(marker, "w") as f:
        f.write("1")

    print(f"zipmount installed to {INSTALL_DIR}")


def main():
    parser = argparse.ArgumentParser(
        prog="zipmount",
        description="Mount a ZIP file as a directory. ls, cat, vim, VS Code — everything works.")
    parser.add_argument("zipfile", help="Path to the ZIP file")
    parser.add_argument("mountpoint", nargs="?", help="Mount directory (default: <zipname>_mounted)")
    parser.add_argument("-b", "--background", action="store_true", help="Run in background")
    args = parser.parse_args()

    _ensure_installed()

    # Import from the installed venv
    venv_site = os.path.join(VENV_DIR, "lib")
    for d in os.listdir(venv_site):
        sp = os.path.join(venv_site, d, "site-packages")
        if os.path.isdir(sp) and sp not in sys.path:
            sys.path.insert(0, sp)

    from zipmount.zipfs import mount

    zippath = os.path.abspath(args.zipfile)
    if not os.path.isfile(zippath):
        print(f"Error: '{args.zipfile}' not found", file=sys.stderr)
        sys.exit(1)

    mountpoint = args.mountpoint or os.path.splitext(zippath)[0] + "_mounted"
    mount(zippath, os.path.abspath(mountpoint), foreground=not args.background)


if __name__ == "__main__":
    main()
