"""zipmount — Mount ZIP files as virtual directories."""
__version__ = "1.0.0"
