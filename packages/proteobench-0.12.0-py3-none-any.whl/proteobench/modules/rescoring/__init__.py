"""
Rescoring module for the ProteoBench pipeline.
"""
