# JSON config for table on parameters to edit before submission

- used in the last tab of a module after parameters are parsed automatically based
  on a data analysis tools parameter file.

