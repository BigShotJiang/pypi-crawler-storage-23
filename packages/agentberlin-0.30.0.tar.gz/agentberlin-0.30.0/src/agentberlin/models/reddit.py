"""Pydantic models for Reddit API responses."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class RedditPost(BaseModel):
    """A Reddit post."""

    id: str
    title: str
    author: str
    subreddit: str
    score: int
    upvote_ratio: float
    num_comments: int
    created: datetime
    url: str
    permalink: str
    is_self: bool
    selftext: Optional[str] = None
    domain: str
    nsfw: bool
    spoiler: bool
    locked: bool
    stickied: bool


class RedditComment(BaseModel):
    """A Reddit comment."""

    id: str
    author: str
    body: str
    score: int
    created: datetime
    permalink: str
    depth: int
    is_op: bool
    replies: List["RedditComment"] = Field(default_factory=list)


class SubredditInfo(BaseModel):
    """Subreddit metadata."""

    name: str
    title: str
    description: str
    public_description: str
    subscribers: int
    active_users: int
    created: datetime
    nsfw: bool
    icon_url: Optional[str] = None
    banner_url: Optional[str] = None


class SubredditPostsResponse(BaseModel):
    """Response from getting subreddit posts."""

    posts: List[RedditPost] = Field(default_factory=list)
    after: Optional[str] = None


class RedditSearchResponse(BaseModel):
    """Response from Reddit search."""

    query: str
    posts: List[RedditPost] = Field(default_factory=list)
    after: Optional[str] = None


class PostCommentsResponse(BaseModel):
    """Response from getting post comments."""

    post: RedditPost
    comments: List[RedditComment] = Field(default_factory=list)


# Allow recursive model references
RedditComment.model_rebuild()
