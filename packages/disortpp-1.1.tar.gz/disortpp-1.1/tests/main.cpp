#include "testing.hpp"

int main() {
  return testing::run_all();
}
