"""Resolve source-file language before analysis so the correct analyzer is dispatched.

Two strategies are available: extension-based lookup (high confidence, fast)
and content-heuristic scanning (lower confidence, used when no path is
supplied). The MCP server and CLI invoke these detectors early in the request
lifecycle to route code to the appropriate language-specific pipeline.
"""

from __future__ import annotations

import re

from pathlib import Path

from pydantic import BaseModel


EXTENSION_LANGUAGE_MAP: dict[str, str] = {
    ".py": "python",
    ".rb": "ruby",
    ".rs": "rust",
    ".go": "go",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".sh": "bash",
    ".bash": "bash",
    ".pwsh": "powershell",
    ".ps1": "powershell",
    ".css": "css",
    ".scss": "css",
    ".less": "css",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".toml": "toml",
    ".json": "json",
    ".xml": "xml",
    ".svg": "svg",
    ".sql": "sql",
    ".ddl": "sql",
    ".dml": "sql",
    ".tf": "terraform",
    ".tfvars": "terraform",
    ".md": "markdown",
    ".markdown": "markdown",
    ".mdx": "markdown",
    ".tex": "latex",
    ".ltx": "latex",
    ".sty": "latex",
    ".bib": "latex",
    ".dockerfile": "dockerfile",
}

GITLAB_CI_FILENAMES = {".gitlab-ci.yml", ".gitlab-ci.yaml"}
YAML_EXTENSIONS = {".yml", ".yaml"}
ANSIBLE_PATH_SEGMENTS = {"tasks", "handlers", "vars", "defaults"}
ANSIBLE_SIGNAL_THRESHOLD = 2
ANSIBLE_DETECTION_READ_LIMIT = 16 * 1024


class DetectionResult(BaseModel):
    """Outcome of a language detection attempt, carrying the inferred language and reliability signals.

    Attributes:
        language: Canonical language identifier (e.g. ``"python"``, ``"typescript"``).
        confidence: Score between 0 and 1 indicating detection reliability.
        method: Strategy that produced this result (``"extension"`` or ``"heuristics"``).
        notes: Optional free-text annotation explaining the detection rationale.
    """

    language: str
    confidence: float = 0.9
    method: str | None = None
    notes: str | None = None

    def as_dict(self) -> dict:
        """Serialize the detection result to a plain dictionary via Pydantic's ``model_dump``.

        Returns:
            dict: A dict with keys ``language``, ``confidence``, ``method``, and ``notes``.
        """
        return self.model_dump()


def _is_ansible_path(path_obj: Path) -> bool:
    parts = {part.lower() for part in path_obj.parts}
    parent_name = path_obj.parent.name.lower()
    return (
        parent_name in {"group_vars", "host_vars"}
        or ("roles" in parts and parent_name in ANSIBLE_PATH_SEGMENTS)
        or path_obj.name.lower()
        in {"playbook.yml", "playbook.yaml", "site.yml", "site.yaml"}
    )


def _is_ansible_yaml_content(text: str) -> bool:
    lowered = text.lower()
    signals = 0
    if re.search(r"(?m)^\s*-\s*hosts\s*:", lowered):
        signals += 1
    if re.search(r"(?m)^\s*(tasks|handlers|pre_tasks|post_tasks)\s*:", lowered):
        signals += 1
    if re.search(r"(?m)^\s*(become|gather_facts|roles)\s*:", lowered):
        signals += 1
    if re.search(
        r"(?m)^\s*(?:ansible\.builtin\.[a-z_]+|-\s*(?:command|shell))\s*:",
        lowered,
    ):
        signals += 1
    return signals >= ANSIBLE_SIGNAL_THRESHOLD


def _detect_ansible_yaml(path_obj: Path, ext: str) -> DetectionResult | None:
    if ext not in YAML_EXTENSIONS or not path_obj.exists():
        return None
    if _is_ansible_path(path_obj):
        return DetectionResult(
            language="ansible",
            confidence=0.99,
            method="extension",
            notes="Matched Ansible-specific YAML path",
        )
    try:
        with path_obj.open(encoding="utf-8", errors="ignore") as handle:
            contents = handle.read(ANSIBLE_DETECTION_READ_LIMIT)
    except OSError:
        return None
    if contents and _is_ansible_yaml_content(contents):
        return DetectionResult(
            language="ansible",
            confidence=0.9,
            method="extension",
            notes="Matched Ansible YAML structure",
        )
    return None


def detect_language_by_extension(path: str) -> DetectionResult:  # noqa: PLR0911
    """Look up the file extension in ``EXTENSION_LANGUAGE_MAP`` and return a high-confidence result.

    This is the primary detection strategy and the fastest path. It
    extracts the suffix with ``os.path.splitext``, normalises to lowercase,
    and matches against the static extension map. Unknown extensions yield
    ``language="unknown"`` so callers can fall back to content heuristics.

    Args:
        path (str): Filesystem path (absolute or relative) whose extension is inspected.

    Returns:
        DetectionResult: A ``DetectionResult`` with ``method="extension"`` and confidence 0.95
        for known extensions, or ``language="unknown"`` for unrecognised ones.
    """
    path_obj = Path(path)
    parts = path_obj.parts
    ext = path_obj.suffix.lower()
    file_name = path_obj.name.lower()
    if ext in {".yml", ".yaml"} and ".github" in parts and "workflows" in parts:
        github_index = parts.index(".github")
        if github_index + 1 < len(parts) and parts[github_index + 1] == "workflows":
            return DetectionResult(
                language="github-actions",
                confidence=0.99,
                method="extension",
                notes="Matched .github/workflows YAML path",
            )
    if file_name in GITLAB_CI_FILENAMES:
        return DetectionResult(
            language="gitlab_ci", confidence=0.99, method="extension"
        )
    if "gitlab-ci" in {part.lower() for part in parts} and ext in YAML_EXTENSIONS:
        return DetectionResult(
            language="gitlab_ci", confidence=0.98, method="extension"
        )
    if file_name == "dockerfile" or file_name.startswith("dockerfile."):
        return DetectionResult(
            language="dockerfile", confidence=0.98, method="extension"
        )
    if file_name in {
        "docker-compose.yml",
        "docker-compose.yaml",
        "compose.yml",
        "compose.yaml",
    }:
        return DetectionResult(
            language="docker_compose",
            confidence=0.98,
            method="extension",
        )
    if ansible_result := _detect_ansible_yaml(path_obj, ext):
        return ansible_result
    lang = EXTENSION_LANGUAGE_MAP.get(ext, "unknown")
    return DetectionResult(language=lang, confidence=0.95, method="extension")


def detect_language_from_content(code: str) -> DetectionResult:
    """Infer the programming language by scanning *code* for characteristic keywords.

    Used as a fallback when no file path is available. The heuristic checks
    for ``def `` (Python), ``interface``/``=>`` (TypeScript), and ``function``/
    ``const``/``let`` (JavaScript) in order of decreasing specificity.
    Confidence scores are lower than extension-based detection to reflect
    the inherent ambiguity of keyword matching.

    Args:
        code (str): Raw source text to scan for language-indicative
            patterns.

    Returns:
        DetectionResult: A ``DetectionResult`` with
        ``method="heuristics"`` and a confidence between 0.1 (unknown)
        and 0.9 (strong keyword match).
    """
    if _is_ansible_yaml_content(code):
        return DetectionResult(language="ansible", confidence=0.85, method="heuristics")
    if "def " in code:
        return DetectionResult(language="python", confidence=0.9, method="heuristics")
    if "interface " in code or "=>" in code or "function " in code:
        return DetectionResult(
            language="typescript",
            confidence=0.85,
            method="heuristics",
        )
    if "const " in code or "let " in code:
        return DetectionResult(
            language="javascript",
            confidence=0.8,
            method="heuristics",
        )
    return DetectionResult(language="unknown", confidence=0.1, method="heuristics")
