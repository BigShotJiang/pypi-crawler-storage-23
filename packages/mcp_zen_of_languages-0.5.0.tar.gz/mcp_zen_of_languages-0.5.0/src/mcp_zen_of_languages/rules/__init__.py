"""Zen of Languages — Rules Package.

This package owns the ``ZEN_REGISTRY``, the in-memory mapping from language
keys (e.g. ``"python"``, ``"rust"``) to ``LanguageZenPrinciples`` models.
The registry is **lazy-loaded** on first access via ``_initialize_registry``
to avoid circular imports between rule definitions and analyzer code.

Public API:

* ``get_language_zen(language)`` — retrieve principles for one language.
* ``get_all_languages()`` — list every registered language key.
* ``get_principle_by_id(id)`` — cross-language principle lookup.
* ``get_all_principles_by_category(cat)`` — filter by ``PrincipleCategory``.
* ``get_all_critical_principles()`` — severity ≥ 9 across all languages.
* ``get_registry_stats()`` — ``RegistryStats`` Pydantic model.

Examples::

    from mcp_zen_of_languages.rules import ZEN_REGISTRY, get_language_zen

    python_zen = get_language_zen("python")
    all_languages = get_all_languages()
    critical = python_zen.get_by_severity(min_severity=9)
"""

# typing imports not required at module level
from .base_models import AnalysisResult
from .base_models import LanguageSummary
from .base_models import LanguageZenPrinciples
from .base_models import PrincipleCategory
from .base_models import RegistryStats
from .base_models import SeverityLevel
from .base_models import ViolationReport
from .base_models import ZenPrinciple
from .base_models import get_missing_detector_rules
from .base_models import get_number_of_principles
from .base_models import get_number_of_priniciple
from .base_models import get_registry_detector_gaps
from .base_models import get_registry_rule_id_gaps
from .base_models import get_rule_id_coverage
from .base_models import get_rule_ids
from .base_models import get_total_principles


# Central registry of all language zen principles (lazy-loaded to avoid circular imports)
ZEN_REGISTRY: dict[str, LanguageZenPrinciples] = {}


def _initialize_registry() -> None:
    """Populate ``ZEN_REGISTRY`` by importing each language's canonical rule module.

    Called lazily on the first ``get_*`` access.  Subsequent calls are
    no-ops because the guard ``if ZEN_REGISTRY`` short-circuits.
    """
    if ZEN_REGISTRY:
        return  # Already initialized

    # Language modules are canonical; use languages.* directly.
    from mcp_zen_of_languages.languages.ansible.rules import ANSIBLE_ZEN
    from mcp_zen_of_languages.languages.bash.rules import BASH_ZEN
    from mcp_zen_of_languages.languages.cpp.rules import CPP_ZEN
    from mcp_zen_of_languages.languages.csharp.rules import CSHARP_ZEN
    from mcp_zen_of_languages.languages.css.rules import CSS_ZEN
    from mcp_zen_of_languages.languages.docker_compose.rules import DOCKER_COMPOSE_ZEN
    from mcp_zen_of_languages.languages.dockerfile.rules import DOCKERFILE_ZEN
    from mcp_zen_of_languages.languages.github_actions.rules import GITHUB_ACTIONS_ZEN
    from mcp_zen_of_languages.languages.gitlab_ci.rules import GITLAB_CI_ZEN
    from mcp_zen_of_languages.languages.go.rules import GO_ZEN
    from mcp_zen_of_languages.languages.javascript.rules import JAVASCRIPT_ZEN
    from mcp_zen_of_languages.languages.json.rules import JSON_ZEN
    from mcp_zen_of_languages.languages.latex.rules import LATEX_ZEN
    from mcp_zen_of_languages.languages.markdown.rules import MARKDOWN_ZEN
    from mcp_zen_of_languages.languages.powershell.rules import POWERSHELL_ZEN
    from mcp_zen_of_languages.languages.python.rules import PYTHON_ZEN
    from mcp_zen_of_languages.languages.ruby.rules import RUBY_ZEN
    from mcp_zen_of_languages.languages.rust.rules import RUST_ZEN
    from mcp_zen_of_languages.languages.sql.rules import SQL_ZEN
    from mcp_zen_of_languages.languages.svg.rules import SVG_ZEN
    from mcp_zen_of_languages.languages.terraform.rules import TERRAFORM_ZEN
    from mcp_zen_of_languages.languages.toml.rules import TOML_ZEN
    from mcp_zen_of_languages.languages.typescript.rules import TYPESCRIPT_ZEN
    from mcp_zen_of_languages.languages.xml.rules import XML_ZEN
    from mcp_zen_of_languages.languages.yaml.rules import YAML_ZEN

    ZEN_REGISTRY.update(
        {
            "python": PYTHON_ZEN,
            "javascript": JAVASCRIPT_ZEN,
            "typescript": TYPESCRIPT_ZEN,
            "ruby": RUBY_ZEN,
            "go": GO_ZEN,
            "json": JSON_ZEN,
            "sql": SQL_ZEN,
            "terraform": TERRAFORM_ZEN,
            "markdown": MARKDOWN_ZEN,
            "rust": RUST_ZEN,
            "svg": SVG_ZEN,
            "cpp": CPP_ZEN,
            "csharp": CSHARP_ZEN,
            "css": CSS_ZEN,
            "docker_compose": DOCKER_COMPOSE_ZEN,
            "dockerfile": DOCKERFILE_ZEN,
            "bash": BASH_ZEN,
            "ansible": ANSIBLE_ZEN,
            "powershell": POWERSHELL_ZEN,
            "yaml": YAML_ZEN,
            "github-actions": GITHUB_ACTIONS_ZEN,
            "gitlab_ci": GITLAB_CI_ZEN,
            "toml": TOML_ZEN,
            "xml": XML_ZEN,
            "latex": LATEX_ZEN,
        },
    )


def get_language_zen(language: str) -> "LanguageZenPrinciples | None":
    """Retrieve the ``LanguageZenPrinciples`` for *language*, or ``None`` if unsupported.

    Args:
        language (str): Case-insensitive language key (e.g. ``"Python"`` → ``"python"``).

    Returns:
        'LanguageZenPrinciples | None': The matching ``LanguageZenPrinciples``, or ``None``.
    """
    _initialize_registry()
    return ZEN_REGISTRY.get(language.lower())


def get_all_languages() -> list[str]:
    """Return every language key registered in ``ZEN_REGISTRY``.

    Returns:
        list[str]: Sorted insertion-order list of language keys.
    """
    _initialize_registry()
    return list(ZEN_REGISTRY.keys())


def get_principle_by_id(principle_id: str) -> "ZenPrinciple | None":
    """Search all languages for a principle matching *principle_id*.

    Args:
        principle_id (str): Globally unique ID (e.g. ``"python-003"``).

    Returns:
        'ZenPrinciple | None': The matching ``ZenPrinciple``, or ``None`` if no language defines it.
    """
    _initialize_registry()
    for lang_zen in ZEN_REGISTRY.values():
        if principle := lang_zen.get_by_id(principle_id):
            return principle
    return None


def get_all_principles_by_category(
    category: PrincipleCategory,
) -> dict[str, list[ZenPrinciple]]:
    """Collect principles matching *category* across every registered language.

    Args:
        category (PrincipleCategory): The ``PrincipleCategory`` to filter by.

    Returns:
        dict[str, list[ZenPrinciple]]: ``{language_key: [ZenPrinciple, …]}`` — languages with no matches
        are omitted.
    """
    _initialize_registry()
    result = {}
    for lang, lang_zen in ZEN_REGISTRY.items():
        if principles := lang_zen.get_by_category(category):
            result[lang] = principles
    return result


def get_all_critical_principles() -> dict[str, list[ZenPrinciple]]:
    """Collect principles with severity ≥ 9 across all languages.

    Returns:
        dict[str, list[ZenPrinciple]]: ``{language_key: [ZenPrinciple, …]}`` — languages with no critical
        principles are omitted.
    """
    _initialize_registry()
    result = {}
    for lang, lang_zen in ZEN_REGISTRY.items():
        if critical := lang_zen.get_by_severity(min_severity=9):
            result[lang] = critical
    return result


def get_registry_stats() -> "RegistryStats":
    """Snapshot the registry into a ``RegistryStats`` Pydantic model.

    Returns:
        RegistryStats: Aggregated language counts, principle totals, and
        per-language summaries.
    """
    _initialize_registry()
    return RegistryStats.from_registry(ZEN_REGISTRY)


from .coverage import RuleConfigCoverageMap  # noqa: E402
from .coverage import RuleCoverageMap  # noqa: E402
from .coverage import build_all_explicit_rule_config_coverage  # noqa: E402
from .coverage import build_all_explicit_rule_coverage  # noqa: E402
from .coverage import build_all_rule_config_coverage  # noqa: E402
from .coverage import build_all_rule_coverage  # noqa: E402
from .coverage import build_explicit_rule_config_coverage  # noqa: E402
from .coverage import build_explicit_rule_coverage  # noqa: E402
from .coverage import build_rule_config_coverage  # noqa: E402
from .coverage import build_rule_coverage  # noqa: E402


# Export all public symbols
__all__ = [
    # Registry
    "ZEN_REGISTRY",
    "AnalysisResult",
    "LanguageSummary",
    # Base models
    "LanguageZenPrinciples",
    "PrincipleCategory",
    "RegistryStats",
    "RuleConfigCoverageMap",
    "RuleCoverageMap",
    "SeverityLevel",
    "ViolationReport",
    "ZenPrinciple",
    "build_all_explicit_rule_config_coverage",
    "build_all_explicit_rule_coverage",
    "build_all_rule_config_coverage",
    "build_all_rule_coverage",
    "build_explicit_rule_config_coverage",
    "build_explicit_rule_coverage",
    "build_rule_config_coverage",
    "build_rule_coverage",
    "get_all_critical_principles",
    "get_all_languages",
    "get_all_principles_by_category",
    # Functions
    "get_language_zen",
    "get_missing_detector_rules",
    "get_number_of_principles",
    "get_number_of_priniciple",
    "get_principle_by_id",
    "get_registry_detector_gaps",
    "get_registry_rule_id_gaps",
    "get_registry_stats",
    "get_rule_id_coverage",
    "get_rule_ids",
    "get_total_principles",
]
