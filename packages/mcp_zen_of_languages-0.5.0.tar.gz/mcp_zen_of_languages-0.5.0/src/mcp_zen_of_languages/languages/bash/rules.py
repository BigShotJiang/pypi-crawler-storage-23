"""Bash zen principles as Pydantic models."""

from pydantic import HttpUrl

from mcp_zen_of_languages.rules.base_models import LanguageZenPrinciples
from mcp_zen_of_languages.rules.base_models import PrincipleCategory
from mcp_zen_of_languages.rules.base_models import ZenPrinciple


BASH_ZEN = LanguageZenPrinciples(
    language="bash",
    name="Bash",
    philosophy="Shell Scripting Best Practices",
    source_text="Google Shell Style Guide",
    source_url=HttpUrl("https://google.github.io/styleguide/shellguide.html"),
    principles=[
        ZenPrinciple(
            id="bash-001",
            principle="Always use set -euo pipefail",
            category=PrincipleCategory.ERROR_HANDLING,
            severity=9,
            description="Enable strict error handling at script start",
            violations=[
                "Scripts without set -e",
                "Not using set -u for undefined variables",
                "Not using set -o pipefail",
                "Missing error handling",
            ],
            detectable_patterns=["#!/bin/bash without set -euo pipefail"],
            recommended_alternative="set -euo pipefail at beginning of script",
        ),
        ZenPrinciple(
            id="bash-002",
            principle="Quote all variables",
            category=PrincipleCategory.CORRECTNESS,
            severity=8,
            description="Always quote variable expansions to prevent word splitting",
            violations=[
                "Unquoted $variable",
                "Unquoted ${variable}",
                "Unquoted command substitutions",
                "Unquoted array expansions",
            ],
            detectable_patterns=[
                "$variable without quotes",
                "$(command) without quotes",
            ],
            recommended_alternative='"$variable" or "${variable}"',
        ),
        ZenPrinciple(
            id="bash-003",
            principle="Use [[ ]] over [ ]",
            category=PrincipleCategory.IDIOMS,
            severity=7,
            description="Prefer [[ ]] for conditional expressions",
            violations=[
                "Using [ ] for tests",
                "Not using [[ ]] for string comparisons",
                "Using test command",
            ],
            detectable_patterns=["[ condition ]", "test condition"],
            recommended_alternative="[[ condition ]]",
        ),
        ZenPrinciple(
            id="bash-004",
            principle="Use $() over backticks",
            category=PrincipleCategory.READABILITY,
            severity=6,
            description="Prefer $() for command substitution",
            violations=[
                "Using backticks `command`",
                "Nested backticks",
                "Hard to read command substitution",
            ],
            detectable_patterns=["`command`"],
            recommended_alternative="$(command)",
        ),
        ZenPrinciple(
            id="bash-005",
            principle="Check command exit codes",
            category=PrincipleCategory.ERROR_HANDLING,
            severity=8,
            description="Always verify command success",
            violations=[
                "Not checking $? after commands",
                "Ignoring command failures",
                "Not using || or && for error handling",
            ],
            detectable_patterns=["!$?"],
            recommended_alternative=(
                "if ! command; then ... fi or command || handle_error"
            ),
        ),
        ZenPrinciple(
            id="bash-006",
            principle="Use functions for reusable code",
            category=PrincipleCategory.ORGANIZATION,
            severity=6,
            description="Extract repeated code into functions",
            violations=[
                "Duplicated code blocks",
                "Long scripts without functions",
                "No code organization",
            ],
            metrics={"max_script_length_without_functions": 50},
        ),
        ZenPrinciple(
            id="bash-007",
            principle="Use local variables in functions",
            category=PrincipleCategory.SCOPE,
            severity=7,
            description="Declare function variables as local",
            violations=[
                "Function variables without local",
                "Global variable pollution",
                "Variable scope leakage",
            ],
            detectable_patterns=["!local "],
        ),
        ZenPrinciple(
            id="bash-008",
            principle="Avoid eval",
            category=PrincipleCategory.SECURITY,
            severity=9,
            description="Don't use eval except when absolutely necessary",
            violations=[
                "eval usage",
                "Constructing code from user input",
                "Security vulnerabilities",
            ],
            detectable_patterns=["eval"],
        ),
        ZenPrinciple(
            id="bash-009",
            principle="Use readonly for constants",
            category=PrincipleCategory.IMMUTABILITY,
            severity=6,
            description="Mark constants as readonly",
            violations=[
                "Constants without readonly",
                "Magic values not in constants",
                "Mutable configuration values",
            ],
            detectable_patterns=["!readonly "],
        ),
        ZenPrinciple(
            id="bash-010",
            principle="Validate input and arguments",
            category=PrincipleCategory.ROBUSTNESS,
            severity=8,
            description="Check script arguments and user input",
            violations=[
                "No argument count validation",
                "Not checking for required arguments",
                "No input sanitization",
                "Missing usage information",
            ],
            detectable_patterns=["!$#"],
        ),
        ZenPrinciple(
            id="bash-011",
            principle="Use meaningful variable names",
            category=PrincipleCategory.READABILITY,
            severity=7,
            description="Avoid single-letter or cryptic names",
            violations=[
                "Single letter variables (except i, j in loops)",
                "Abbreviations without context",
                "Unclear variable names",
            ],
            metrics={"min_variable_name_length": 3},
        ),
        ZenPrinciple(
            id="bash-012",
            principle="Handle signals properly",
            category=PrincipleCategory.ROBUSTNESS,
            severity=7,
            description="Use trap for cleanup and signal handling",
            violations=[
                "No trap for cleanup",
                "Temporary files not cleaned up",
                "Missing EXIT trap",
                "No interrupt handling",
            ],
            detectable_patterns=["!trap "],
            recommended_alternative="trap cleanup EXIT INT TERM",
        ),
        ZenPrinciple(
            id="bash-013",
            principle="Use arrays instead of string splitting",
            category=PrincipleCategory.CORRECTNESS,
            severity=7,
            description="Store lists in arrays, not space-separated strings",
            violations=[
                "Splitting strings on spaces",
                "Not using arrays for lists",
                "Improper iteration over items",
            ],
            detectable_patterns=["IFS=", "for item in $"],
            recommended_alternative='array=(item1 item2); for item in "${array[@]}"',
        ),
        ZenPrinciple(
            id="bash-014",
            principle="Include usage information",
            category=PrincipleCategory.USABILITY,
            severity=6,
            description="Provide help text and usage examples",
            violations=[
                "Scripts without usage function",
                "No help flag (-h/--help)",
                "Missing documentation",
            ],
            detectable_patterns=["!usage"],
        ),
    ],
)
