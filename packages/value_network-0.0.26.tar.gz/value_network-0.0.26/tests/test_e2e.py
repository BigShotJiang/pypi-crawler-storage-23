import os
import shutil
import subprocess
from pathlib import Path
import torch
import numpy as np
import pytest
from memmap_replay_buffer import ReplayBuffer

@pytest.mark.parametrize("use_td_trainer, use_ema", [
    (False, False),
    (True, False),
    (True, True)
])
def test_e2e_pipeline(use_td_trainer, use_ema):
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    auto_output_buffer = fixtures_dir.with_suffix('.memmap')
    
    suffix = "td" if use_td_trainer else "base"
    if use_ema:
        suffix += "_ema"

    trained_model = project_root / 'tests' / f'e2e_model_{suffix}.pt'
    test_frame = fixtures_dir / 'test_frame.png'

    # 1. clean up
    if auto_output_buffer.exists():
        shutil.rmtree(auto_output_buffer)
    
    if trained_model.exists():
        os.remove(trained_model)

    # 2. run train with --trajectories-folder (auto-generation)
    print(f"\nRunning train (TD={use_td_trainer}, EMA={use_ema})...")
    
    cmd = [
        'python3', '-m', 'value_network.cli', 'train',
        '--trajectories-folder', str(fixtures_dir),
        '--max-steps', '1',
        '--batch_size', '2',
        '--model_output_path', str(trained_model)
    ]
    
    if use_td_trainer:
        cmd.append('--use-td-trainer')
        
    if use_ema:
        cmd.append('--ema')

    subprocess.run(cmd, check=True, env={**os.environ, 'PYTHONPATH': str(project_root), 'ACCELERATE_USE_CPU': 'true'})

    assert trained_model.exists(), f"Model not found at {trained_model}"
    assert auto_output_buffer.exists()

    # verify buffer creation
    rb = ReplayBuffer.from_folder(auto_output_buffer)
    assert rb.num_episodes >= 2
    
    successes = rb.meta_data['success']
    assert True in successes
    assert False in successes
    
    # 3. run predict-value
    print("\nRunning predict-value...")
    result = subprocess.run([
        'python3', '-m', 'value_network.cli', 'predict-value',
        str(trained_model),
        str(test_frame)
    ], check=True, capture_output=True, text=True, env={**os.environ, 'PYTHONPATH': str(project_root)})
    
    print(result.stdout)
    assert 'predicted value:' in result.stdout

def test_e2e_sequential_training():
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    auto_output_buffer = fixtures_dir.with_suffix('.memmap')
    trained_model = project_root / 'tests' / 'e2e_model_sequential.pt'
    test_frame = fixtures_dir / 'test_frame.png'

    # 1. clean up
    if auto_output_buffer.exists():
        shutil.rmtree(auto_output_buffer)
    
    if trained_model.exists():
        os.remove(trained_model)

    # 2. run sequential training
    # Phase 1: 1 step, Phase 2: 1 step
    print("\nRunning sequential train...")
    
    cmd = [
        'python3', '-m', 'value_network.cli', 'train',
        '--trajectories-folder', str(fixtures_dir),
        '--max-steps', '1',
        '--td-steps', '1',
        '--batch_size', '2',
        '--model_output_path', str(trained_model)
    ]
    
    subprocess.run(cmd, check=True, env={**os.environ, 'PYTHONPATH': str(project_root), 'ACCELERATE_USE_CPU': 'true'})

    assert trained_model.exists(), "Sequential training failed to save model"
    assert auto_output_buffer.exists()

    # also verify we can predict with it
    result = subprocess.run([
        'python3', '-m', 'value_network.cli', 'predict-value',
        str(trained_model),
        str(test_frame)
    ], check=True, capture_output=True, text=True, env={**os.environ, 'PYTHONPATH': str(project_root)})
    
    assert 'predicted value:' in result.stdout
    print("Sequential training E2E passed!")

def test_e2e_video_prediction():
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    auto_output_buffer = fixtures_dir.with_suffix('.memmap')
    trained_model = project_root / 'tests' / 'e2e_model_base.pt'
    test_video = fixtures_dir / 'short.mp4'
    output_npy = test_video.with_suffix('.npy')

    # 1. clean up existing npy files
    for f in fixtures_dir.glob('short*.npy'):
        os.remove(f)

    # 2. run predict-value on video
    print("\nRunning predict-value on video...")
    
    cmd = [
        'python3', '-m', 'value_network.cli', 'predict-value',
        str(trained_model),
        str(test_video),
        '--batch_size', '4',
        '--cuda'
    ]
    
    subprocess.run(cmd, check=True, env={**os.environ, 'PYTHONPATH': str(project_root)})

    assert output_npy.exists(), "Video prediction failed to save .npy file"
    data = np.load(output_npy)
    assert data.ndim == 1, f"Expected 1D array of values, got {data.ndim}D"
    assert data.shape[0] == 2, f"Expected 2 values, got {data.shape[0]}"
    # 3. verify collision handling
    print("\nRunning predict-value on video (collision check)...")
    subprocess.run(cmd, check=True, env={**os.environ, 'PYTHONPATH': str(project_root)})
    
    collision_npy = fixtures_dir / 'short.1.npy'
    assert collision_npy.exists(), f"Collision handling failed: {collision_npy} not found"
    print("Collision handling E2E passed!")


if __name__ == '__main__':
    # allow running directly as before, but with default param
    try:
        test_e2e_pipeline(use_td_trainer = False)
        test_e2e_pipeline(use_td_trainer = True)
        print("\nAll E2E Tests Passed!")
    except Exception as e:
        print(f"\nE2E Test Failed: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
