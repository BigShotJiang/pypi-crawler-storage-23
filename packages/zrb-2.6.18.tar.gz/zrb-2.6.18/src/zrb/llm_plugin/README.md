# Zrb Default Plugin\n\nThis directory contains built-in skills and sub-agents.
