# Redactor

::: enforcecore.redactor.engine.Redactor

::: enforcecore.redactor.engine.RedactionResult

::: enforcecore.redactor.engine.DetectedEntity
