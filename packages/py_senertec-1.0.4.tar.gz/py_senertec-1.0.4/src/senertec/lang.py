from enum import Enum


class lang(Enum):
    """Represents all available languages."""
    English = "en-gb"
    German = "de-de"
