class SenertecError(Exception):
    """Raised on errors with senertec platform.

    """
    pass
