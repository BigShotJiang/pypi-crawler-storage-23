"""Named stdio entrypoint module for package users."""

from src.stdio_main import run


if __name__ == "__main__":
    run()
