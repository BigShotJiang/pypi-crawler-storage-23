"""Public entrypoint namespace for AgentChatBus console and module execution."""

__all__ = ["main"]
