"""JKAnime package."""

from ani_scrapy.jkanime.scraper import JKAnimeScraper

__all__ = ["JKAnimeScraper"]
