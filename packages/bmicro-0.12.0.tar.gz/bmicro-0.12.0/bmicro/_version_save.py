#!/usr/bin/env python
# This file was created automatically
longversion = '0.12.0'
