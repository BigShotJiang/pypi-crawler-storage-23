"""
Provides play_helpers git information.
"""
from play_helpers.ph_git import PhGit

GIT_SUMMARY = PhGit.get_git_summary()
