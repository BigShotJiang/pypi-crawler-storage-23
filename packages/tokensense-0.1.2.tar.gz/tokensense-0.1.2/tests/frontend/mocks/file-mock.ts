// Stub for binary asset imports (SVG, PNG, etc.)
export default "test-file-stub"
