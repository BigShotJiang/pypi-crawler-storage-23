// Stub for CSS / image imports in Jest
export default {}
