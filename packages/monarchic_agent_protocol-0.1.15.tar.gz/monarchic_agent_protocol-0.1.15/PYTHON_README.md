# monarchic-agent-protocol (Python)

Generated Python protobuf bindings for Monarchic AI protocol.

## Build locally

```bash
python -m pip install --upgrade build
python -m build
```

The build step expects `monarchic_agent_protocol_pb2.py` to be generated via `protoc` prior to packaging.
