"""Monarchic AI protocol protobuf bindings for Python."""

from .monarchic_agent_protocol_pb2 import *  # noqa: F401,F403
