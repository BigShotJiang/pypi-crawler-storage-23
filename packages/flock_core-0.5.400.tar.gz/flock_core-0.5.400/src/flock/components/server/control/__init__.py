"""Module for ControlRoutesServerComponent."""

from flock.components.server.control.control_routes_component import (
    ControlRoutesComponent,
    ControlRoutesComponentConfig,
)


__all__ = ["ControlRoutesComponent", "ControlRoutesComponentConfig"]
