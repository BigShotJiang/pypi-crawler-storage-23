## Why

Phase 1 implementation is complete but invisible to users. No examples, no docs update, no README mention. Users discovering Flock won't know OpenClaw integration exists.

## What Changes

- Add working examples in `examples/11-openclaw/` showcasing the integration.
- Add guide doc at `docs/guides/openclaw.md` covering setup, usage, and patterns.
- Update root README.md with prominent OpenClaw section alongside other major features.
- Update AGENTS.md quick reference with OpenClaw snippets.

## Capabilities

### New Capabilities
- `openclaw-examples`: Working example scripts demonstrating OpenClaw integration patterns.
- `openclaw-docs`: User guide for OpenClaw integration setup and usage.
- `openclaw-readme`: README section showcasing OpenClaw as a headline feature.

## Impact

- **New files:** `examples/11-openclaw/*.py`, `docs/guides/openclaw.md`
- **Modified files:** `README.md`, `AGENTS.md`
- **No code changes** — documentation and examples only.
