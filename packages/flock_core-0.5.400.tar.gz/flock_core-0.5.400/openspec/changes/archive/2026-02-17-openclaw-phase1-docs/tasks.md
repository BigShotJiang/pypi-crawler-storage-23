## 1. Examples

- [x] 1.1 (flock-repo-cv5.1) Create `examples/11-openclaw/01_pizza_with_openclaw.py` — simplest possible OpenClaw agent (mirrors 01-getting-started/01).
- [x] 1.2 (flock-repo-cv5.1) Create `examples/11-openclaw/02_mixed_pipeline.py` — OpenClaw + native agent in one workflow.
- [x] 1.3 (flock-repo-cv5.1) Create `examples/11-openclaw/03_env_config.py` — environment-based gateway discovery.
- [x] 1.4 (flock-repo-cv5.1) Create `examples/11-openclaw/README.md` — example index and setup instructions.

## 2. Documentation

- [x] 2.1 (flock-repo-cv5.2) Create `docs/guides/openclaw.md` — setup guide, config patterns, usage examples.
- [x] 2.2 (flock-repo-cv5.2) Update `docs/guides/index.md` to include OpenClaw guide link.
- [x] 2.3 (flock-repo-cv5.2) Add `guides/openclaw.md` to `mkdocs.yml` nav.

## 3. README

- [x] 3.1 (flock-repo-cv5.3) Add OpenClaw integration section to README.md (after Timer Scheduling section).
- [x] 3.2 (flock-repo-cv5.3) Update AGENTS.md quick reference with OpenClaw code snippets.

## 4. Review

- [x] 4.1 (flock-repo-cv5.4) Codie review pass on all docs/examples.
