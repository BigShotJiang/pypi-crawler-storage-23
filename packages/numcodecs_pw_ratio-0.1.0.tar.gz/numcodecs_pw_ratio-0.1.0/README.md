[![image](https://img.shields.io/github/actions/workflow/status/juntyr/numcodecs-pw-ratio/ci.yml?branch=main)](https://github.com/juntyr/numcodecs-pw-ratio/actions/workflows/ci.yml?query=branch%3Amain)
[![image](https://img.shields.io/pypi/v/numcodecs-pw-ratio.svg)](https://pypi.python.org/pypi/numcodecs-pw-ratio)
[![image](https://img.shields.io/pypi/l/numcodecs-pw-ratio.svg)](https://github.com/juntyr/numcodecs-pw-ratio/blob/main/LICENSE)
[![image](https://img.shields.io/python/required-version-toml?tomlFilePath=https%3A%2F%2Fraw.githubusercontent.com%2Fjuntyr%2Fnumcodecs-pw-ratio%2Frefs%2Fheads%2Fmain%2Fpyproject.toml)](https://pypi.python.org/pypi/numcodecs-pw-ratio)
[![image](https://readthedocs.org/projects/numcodecs-pw-ratio/badge/?version=latest)](https://numcodecs-pw-ratio.readthedocs.io/en/latest/?badge=latest)

# numcodecs-pw-ratio

Meta codec for bounding the pointwise ratio error in the [`numcodecs`] buffer compression API.

[`numcodecs`]: https://numcodecs.readthedocs.io/en/stable/

## License

Licensed under the Mozilla Public License, Version 2.0 ([LICENSE](LICENSE) or https://www.mozilla.org/en-US/MPL/2.0/).


## Funding

The `numcodecs-pw-ratio` package has been developed as part of [ESiWACE3](https://www.esiwace.eu), the third phase of the Centre of Excellence in Simulation of Weather and Climate in Europe.

Funded by the European Union. This work has received funding from the European High Performance Computing Joint Undertaking (JU) under grant agreement No 101093054.
