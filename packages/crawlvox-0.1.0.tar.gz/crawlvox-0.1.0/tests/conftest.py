"""Shared pytest fixtures for crawlvox tests."""

import pytest

from crawlvox.storage import init_database


@pytest.fixture
async def db_path(tmp_path):
    """
    Async fixture providing a path to an initialized test database.

    Creates a fresh SQLite database in a temporary directory per test.
    Used by test_storage.py and test_fetcher.py (Plan 02).
    """
    path = str(tmp_path / "test.db")
    await init_database(path)
    return path
