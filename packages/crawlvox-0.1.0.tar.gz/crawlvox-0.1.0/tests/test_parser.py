"""Tests for URL resolution, content-type classification, link extraction, and content extraction."""

from crawlvox.parser import (
    classify_content_type,
    extract_content_with_fallback,
    extract_links,
    resolve_url,
)

# ---------------------------------------------------------------------------
# Sample HTML for content extraction tests
# ---------------------------------------------------------------------------

HTML_ARTICLE = """
<html><head><title>Test Article</title></head><body>
<article>
<h1>Test Article Title</h1>
<p>This is the first paragraph of a test article that contains enough text content
for trafilatura to successfully extract it. The extraction engine needs a reasonable
amount of content to distinguish article text from boilerplate navigation elements.</p>
<p>Here is a second paragraph providing additional content depth. Web scraping tools
need substantial text to identify the main content area and separate it from headers,
footers, sidebars, and other non-article elements on the page.</p>
<p>A third paragraph ensures we are well above the minimum content length threshold
of 200 characters that triggers the fallback extraction mechanism in our parser.</p>
</article>
</body></html>
"""


# ---------------------------------------------------------------------------
# resolve_url tests
# ---------------------------------------------------------------------------


def test_resolve_url_relative():
    """Relative URLs should be resolved against the base URL."""
    result = resolve_url("https://example.com/blog/", "../about")
    assert result == "https://example.com/about"


def test_resolve_url_absolute_unchanged():
    """Absolute URLs should be returned unchanged."""
    result = resolve_url("https://example.com/", "https://other.com/page")
    assert result == "https://other.com/page"


def test_resolve_url_protocol_relative():
    """Protocol-relative URLs should inherit the base URL scheme."""
    result = resolve_url("https://example.com/", "//cdn.example.com/img.jpg")
    assert result == "https://cdn.example.com/img.jpg"


# ---------------------------------------------------------------------------
# classify_content_type tests
# ---------------------------------------------------------------------------


def test_classify_html():
    """text/html and variants should classify as 'html'."""
    assert classify_content_type("text/html") == "html"
    assert classify_content_type("text/html; charset=utf-8") == "html"


def test_classify_pdf():
    """application/pdf should classify as 'pdf'."""
    assert classify_content_type("application/pdf") == "pdf"


def test_classify_pdf_url_fallback():
    """Generic content-type with a .pdf URL extension should classify as 'pdf'."""
    result = classify_content_type(
        "application/octet-stream", "https://example.com/doc.pdf"
    )
    assert result == "pdf"


def test_classify_image():
    """image/* MIME types should classify as 'image'."""
    assert classify_content_type("image/png") == "image"


# ---------------------------------------------------------------------------
# extract_links tests
# ---------------------------------------------------------------------------


def test_extract_links_basic():
    """HTML with internal and external links should return both, classified correctly."""
    html = """
    <html><body>
    <a href="/about">About</a>
    <a href="https://other.com">External</a>
    </body></html>
    """
    links = extract_links(html, "https://example.com/")
    assert len(links) == 2

    internal = [l for l in links if l.is_internal]
    external = [l for l in links if not l.is_internal]

    assert len(internal) == 1
    assert internal[0].href_abs == "https://example.com/about"

    assert len(external) == 1
    assert external[0].href_abs == "https://other.com"


def test_extract_links_ignores_javascript():
    """Links with javascript: scheme should be filtered out."""
    html = '<html><body><a href="javascript:void(0)">Click</a></body></html>'
    links = extract_links(html, "https://example.com/")
    assert len(links) == 0


def test_extract_links_filters_mailto():
    """Links with mailto: scheme should be filtered out."""
    html = '<html><body><a href="mailto:test@example.com">Mail</a></body></html>'
    links = extract_links(html, "https://example.com/")
    assert len(links) == 0


# ---------------------------------------------------------------------------
# extract_content_with_fallback tests
# ---------------------------------------------------------------------------


def test_extract_content_with_fallback_success():
    """Substantial article HTML should be extracted successfully."""
    result = extract_content_with_fallback(HTML_ARTICLE, "https://example.com/article")
    assert result.success is True
    assert result.text is not None
    assert len(result.text) > 0
    assert result.extraction_method in ("trafilatura", "readability")


def test_extract_content_with_fallback_empty_html():
    """Empty body HTML should result in a failed extraction."""
    result = extract_content_with_fallback(
        "<html><body></body></html>", "https://example.com/"
    )
    assert result.success is False or result.extraction_method == "failed"
