"""Tests for URL normalization, scope checking, and trap detection."""

from crawlvox.url_utils import ScopeChecker, TrapDetector, normalize_url


# ---------------------------------------------------------------------------
# normalize_url tests
# ---------------------------------------------------------------------------


def test_normalize_url_strips_fragment():
    """Fragment identifiers should be removed from normalized URLs."""
    result = normalize_url("https://example.com/page#section")
    assert "#section" not in result
    assert "example.com/page" in result


def test_normalize_url_removes_tracking_params():
    """UTM and other tracking parameters should be stripped; non-tracking params kept."""
    result = normalize_url("https://example.com/?utm_source=google&q=test")
    assert "utm_source" not in result
    assert "q=test" in result


def test_normalize_url_lowercase_scheme_and_host():
    """Scheme and host should be lowercased; path case preserved."""
    result = normalize_url("HTTP://Example.COM/Path")
    assert result.startswith("http://")
    assert "example.com" in result
    assert "/Path" in result


def test_normalize_url_trailing_slash_removed():
    """Trailing slash on non-root paths should be removed."""
    result = normalize_url("https://example.com/path/")
    assert not result.endswith("/")
    assert "example.com/path" in result


def test_normalize_url_root_trailing_slash_preserved():
    """Root path trailing slash should be preserved."""
    result = normalize_url("https://example.com/")
    assert result.endswith("/")


def test_normalize_url_fail_safe_returns_original():
    """Invalid URLs should not raise exceptions and should return a string."""
    # url_normalize is lenient and transforms even garbage strings into URL-like forms;
    # the fail-safe ensures no exception is raised regardless of input.
    invalid_url = "not a url at all"
    result = normalize_url(invalid_url)
    assert isinstance(result, str)
    assert len(result) > 0


# ---------------------------------------------------------------------------
# ScopeChecker tests
# ---------------------------------------------------------------------------


def test_scope_checker_allows_same_domain():
    """URLs on the configured start domain should be allowed."""
    checker = ScopeChecker(start_domains=["example.com"], same_domain_only=True)
    assert checker.is_allowed("https://example.com/page") is True


def test_scope_checker_blocks_other_domain():
    """URLs on a different domain should be blocked."""
    checker = ScopeChecker(start_domains=["example.com"], same_domain_only=True)
    assert checker.is_allowed("https://other.com/page") is False


def test_scope_checker_allows_subdomain():
    """Subdomains of the configured start domain should be allowed."""
    checker = ScopeChecker(start_domains=["example.com"], same_domain_only=True)
    assert checker.is_allowed("https://blog.example.com/post") is True


def test_scope_checker_deny_overrides_allow():
    """Deny patterns take priority over allow patterns."""
    checker = ScopeChecker(
        start_domains=["example.com"],
        allow_patterns=[r"/blog/"],
        deny_patterns=[r"/private/"],
    )
    # URL matches both allow (/blog/) and deny (/private/), deny wins
    assert checker.is_allowed("https://example.com/private/blog/post") is False


# ---------------------------------------------------------------------------
# TrapDetector tests
# ---------------------------------------------------------------------------


def test_trap_detector_below_threshold():
    """Calls at or below max_visits_per_pattern threshold should not trigger trap detection."""
    detector = TrapDetector(max_visits_per_pattern=3)
    # /page/1 matches the /page/\d+ trap pattern
    # 3 calls at threshold should all return False
    results = [detector.is_trap("https://example.com/page/1") for _ in range(3)]
    assert all(r is False for r in results)


def test_trap_detector_above_threshold():
    """Fourth call on a URL matching a trap pattern should be flagged as a trap."""
    detector = TrapDetector(max_visits_per_pattern=3)
    # Call 3 times (at threshold, still False)
    for _ in range(3):
        detector.is_trap("https://example.com/page/2")
    # 4th call exceeds max_visits of 3 -> True
    assert detector.is_trap("https://example.com/page/2") is True
