"""Async tests for SQLite storage operations.

Covers: init_database, save_page, save_links, get_visited_urls.
Uses the db_path fixture from conftest.py (fresh DB per test, no persistent state).
"""

import aiosqlite

from crawlvox.storage import (
    create_run,
    get_visited_urls,
    init_database,
    save_links,
    save_page,
)


# ---------------------------------------------------------------------------
# init_database tests
# ---------------------------------------------------------------------------


async def test_init_database_creates_tables(db_path):
    """init_database creates all expected tables in the SQLite file."""
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ) as cursor:
            rows = await cursor.fetchall()

    table_names = {row[0] for row in rows}
    for expected in ("pages", "runs", "links", "images", "documents", "run_pages"):
        assert expected in table_names, f"Expected table '{expected}' not found in DB"


async def test_init_database_idempotent(db_path):
    """Calling init_database twice does not raise and tables remain intact."""
    # Second call -- CREATE TABLE IF NOT EXISTS should be a no-op
    await init_database(db_path)

    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ) as cursor:
            rows = await cursor.fetchall()

    table_names = {row[0] for row in rows}
    for expected in ("pages", "runs", "links", "images", "documents", "run_pages"):
        assert expected in table_names, f"Table '{expected}' missing after second init"


# ---------------------------------------------------------------------------
# save_page tests
# ---------------------------------------------------------------------------


async def test_save_page_inserts_record(db_path):
    """save_page inserts a record retrievable by URL with correct status_code and title."""
    await save_page(
        db_path=db_path,
        url="https://example.com/",
        final_url="https://example.com/",
        status_code=200,
        content_type="text/html",
        title="Home",
        description="Desc",
        main_text="Welcome",
        error=None,
    )

    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT status_code, title FROM pages WHERE url = ?",
            ("https://example.com/",),
        ) as cursor:
            row = await cursor.fetchone()

    assert row is not None, "No row found for inserted URL"
    assert row[0] == 200
    assert row[1] == "Home"


async def test_save_page_upsert_replaces(db_path):
    """INSERT OR REPLACE: second save with same URL updates title; only 1 row exists."""
    url = "https://example.com/page"

    await save_page(
        db_path=db_path,
        url=url,
        final_url=url,
        status_code=200,
        content_type="text/html",
        title="Original Title",
        description=None,
        main_text=None,
        error=None,
    )

    await save_page(
        db_path=db_path,
        url=url,
        final_url=url,
        status_code=200,
        content_type="text/html",
        title="Updated Title",
        description=None,
        main_text=None,
        error=None,
    )

    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT COUNT(*), title FROM pages WHERE url = ?", (url,)
        ) as cursor:
            row = await cursor.fetchone()

    assert row[0] == 1, "Expected exactly 1 row after upsert"
    assert row[1] == "Updated Title"


async def test_save_page_with_error(db_path):
    """save_page stores error string; status_code is None for failed fetches."""
    url = "https://example.com/bad-ssl"
    error_msg = "SSL: CERTIFICATE_VERIFY_FAILED"

    await save_page(
        db_path=db_path,
        url=url,
        final_url=None,
        status_code=None,
        content_type=None,
        title=None,
        description=None,
        main_text=None,
        error=error_msg,
    )

    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT status_code, error FROM pages WHERE url = ?", (url,)
        ) as cursor:
            row = await cursor.fetchone()

    assert row is not None, "No row found for error page"
    assert row[0] is None, "status_code should be NULL for error page"
    assert row[1] == error_msg


# ---------------------------------------------------------------------------
# save_links tests
# ---------------------------------------------------------------------------


async def test_save_links_inserts_records(db_path):
    """save_links inserts 2 link records associated with the parent page URL."""
    page_url = "https://example.com/"

    # Save parent page first (FK constraint)
    await save_page(
        db_path=db_path,
        url=page_url,
        final_url=page_url,
        status_code=200,
        content_type="text/html",
        title="Home",
        description=None,
        main_text=None,
        error=None,
    )

    links = [
        ("https://example.com/about", "About", None, True),
        ("https://other.com/", "External", None, False),
    ]
    await save_links(db_path, page_url, links)

    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT href_abs FROM links WHERE page_url = ? ORDER BY href_abs",
            (page_url,),
        ) as cursor:
            rows = await cursor.fetchall()

    hrefs = {row[0] for row in rows}
    assert len(hrefs) == 2
    assert "https://example.com/about" in hrefs
    assert "https://other.com/" in hrefs


async def test_save_links_empty_list(db_path):
    """save_links with empty list does not raise and inserts 0 rows."""
    page_url = "https://example.com/empty"

    # Save parent page first
    await save_page(
        db_path=db_path,
        url=page_url,
        final_url=page_url,
        status_code=200,
        content_type="text/html",
        title="Empty",
        description=None,
        main_text=None,
        error=None,
    )

    # Should not raise
    await save_links(db_path, page_url, [])

    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT COUNT(*) FROM links WHERE page_url = ?", (page_url,)
        ) as cursor:
            row = await cursor.fetchone()

    assert row[0] == 0


# ---------------------------------------------------------------------------
# get_visited_urls tests
# ---------------------------------------------------------------------------


async def test_get_visited_urls_returns_set(db_path):
    """get_visited_urls returns the set of URLs saved with a specific run_id."""
    run_id = "run-test-001"
    await create_run(db_path, run_id, "{}")

    url1 = "https://example.com/"
    url2 = "https://example.com/about"

    await save_page(
        db_path=db_path,
        url=url1,
        final_url=url1,
        status_code=200,
        content_type="text/html",
        title="Home",
        description=None,
        main_text=None,
        error=None,
        run_id=run_id,
    )
    await save_page(
        db_path=db_path,
        url=url2,
        final_url=url2,
        status_code=200,
        content_type="text/html",
        title="About",
        description=None,
        main_text=None,
        error=None,
        run_id=run_id,
    )

    visited = await get_visited_urls(db_path, run_id)

    assert visited == {url1, url2}


async def test_get_visited_urls_empty_run(db_path):
    """get_visited_urls returns empty set when no pages have been saved to the run."""
    run_id = "run-empty-001"
    await create_run(db_path, run_id, "{}")

    visited = await get_visited_urls(db_path, run_id)

    assert visited == set()
