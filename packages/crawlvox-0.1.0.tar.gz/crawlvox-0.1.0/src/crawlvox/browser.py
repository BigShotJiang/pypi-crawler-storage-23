"""Playwright browser manager for JavaScript-rendered page fetching."""

from __future__ import annotations

import structlog
from playwright.async_api import async_playwright, Playwright, Browser

logger = structlog.get_logger(__name__)


class BrowserManager:
    """Manages a shared Playwright Chromium browser for dynamic page rendering.

    Uses async context manager pattern (same as Fetcher):
    - __aenter__: Start Playwright, launch shared Chromium browser
    - __aexit__: Close browser, stop Playwright
    - fetch_dynamic: Create fresh BrowserContext per request (closed in finally)

    Architecture decisions (from research):
    - Single shared Browser for entire crawler lifecycle (context creation is instant)
    - Fresh BrowserContext per request prevents memory leaks
    - wait_until='domcontentloaded' (NOT networkidle - hangs on SPAs)
    - Resource blocking via context.route() for 60-80% speedup
    """

    def __init__(
        self,
        timeout: float = 30.0,
        block_resources: bool = True,
        user_agent: str | None = None,
    ):
        self.timeout = timeout
        self.block_resources = block_resources
        self.user_agent = user_agent
        self._playwright: Playwright | None = None
        self._browser: Browser | None = None

    async def __aenter__(self) -> BrowserManager:
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(headless=True)
        logger.info("browser_launched", browser="chromium", headless=True)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        logger.info("browser_closed")

    async def fetch_dynamic(self, url: str) -> str | None:
        """Fetch page with JavaScript rendering via Playwright.

        Creates a fresh BrowserContext per request and closes it in a finally block
        to prevent memory leaks during long crawls.

        Args:
            url: URL to fetch and render

        Returns:
            Rendered HTML string, or None on error
        """
        if not self._browser:
            raise RuntimeError("BrowserManager must be used as async context manager")

        context = await self._browser.new_context(
            user_agent=self.user_agent or None,
        )

        try:
            # Block unnecessary resources for text-only extraction
            if self.block_resources:
                await context.route(
                    "**/*.{png,jpg,jpeg,gif,svg,webp,css,woff,woff2,ttf,eot,ico}",
                    lambda route: route.abort(),
                )

            page = await context.new_page()

            # Navigate with domcontentloaded (NOT networkidle - hangs on SPAs)
            await page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=self.timeout * 1000,  # Playwright uses milliseconds
            )

            html = await page.content()

            logger.info(
                "dynamic_fetch_complete",
                url=url,
                html_length=len(html) if html else 0,
            )

            return html

        except Exception as e:
            logger.error("dynamic_fetch_error", url=url, error=str(e))
            return None

        finally:
            # CRITICAL: Always close context to prevent memory leaks
            await context.close()
