"""Structured logging configuration using structlog."""

import logging
import sys

import structlog
from structlog.processors import (
    JSONRenderer,
    StackInfoRenderer,
    TimeStamper,
    add_log_level,
    dict_tracebacks,
    format_exc_info,
)
from structlog.dev import ConsoleRenderer
from structlog.contextvars import merge_contextvars


def configure_logging(log_level: str = "INFO") -> None:
    """Configure structured logging with appropriate renderer.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
    """
    # Build shared processors
    shared_processors = [
        merge_contextvars,
        add_log_level,
        TimeStamper(fmt="iso"),
        StackInfoRenderer(),
        format_exc_info,
    ]

    # Choose renderer based on TTY
    if sys.stderr.isatty():
        # Development mode: Pretty console output
        shared_processors.append(ConsoleRenderer())
    else:
        # Production mode: JSON output
        shared_processors.append(dict_tracebacks)
        shared_processors.append(JSONRenderer())

    # Configure structlog
    structlog.configure(
        processors=shared_processors,
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, log_level.upper())
        ),
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger():
    """Get a structured logger instance.

    Returns:
        Bound logger instance
    """
    return structlog.get_logger()
