"""Pydantic Settings configuration with validation."""

from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class ScraperConfig(BaseSettings):
    """CrawlVox configuration with validation."""

    model_config = SettingsConfigDict(
        env_prefix="CRAWLVOX_",
        case_sensitive=False,
        validate_default=True,
    )

    database_path: str = Field(
        default="crawlvox.db",
        description="Path to SQLite database file",
    )
    max_workers: int = Field(
        default=10,
        gt=0,
        le=100,
        description="Number of concurrent fetch workers",
    )
    request_timeout: float = Field(
        default=30.0,
        gt=0,
        description="HTTP request timeout in seconds",
    )
    max_pages: int = Field(
        default=100,
        gt=0,
        description="Maximum pages to crawl per run",
    )
    max_depth: int = Field(
        default=3,
        gt=0,
        le=20,
        description="Maximum crawl depth from start URL",
    )
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(
        default="INFO",
        description="Logging level",
    )
    user_agent: str = Field(
        default="CrawlVox/0.1",
        description="HTTP User-Agent header",
    )
    respect_robots_txt: bool = Field(
        default=True,
        description="Whether to respect robots.txt",
    )
    rate_limit: float = Field(
        default=2.0,
        gt=0,
        description="Maximum requests per second per domain",
    )
    max_retries: int = Field(
        default=3,
        ge=1,
        le=10,
        description="Maximum retry attempts for failed requests",
    )
    include_patterns: list[str] = Field(
        default_factory=list,
        description="Regex patterns for URL allowlist (empty = allow all)",
    )
    exclude_patterns: list[str] = Field(
        default_factory=list,
        description="Regex patterns for URL denylist",
    )
    same_domain_only: bool = Field(
        default=True,
        description="Only crawl URLs on the same domain as start URLs",
    )
    cookie_file: str | None = Field(
        default=None,
        description="Path to cookie file for session persistence (LWP format). None disables cookie persistence.",
    )
    min_content_length: int = Field(
        default=200,
        ge=0,
        description="Minimum content length (chars) before fallback extraction triggers",
    )
    dynamic_mode: Literal["off", "auto", "always"] = Field(
        default="auto",
        description="JavaScript rendering mode: off=never use browser, auto=fallback when static extraction yields insufficient content, always=render all pages with browser",
    )
    playwright_timeout: float = Field(
        default=30.0,
        gt=0,
        description="Playwright page load timeout in seconds",
    )
    block_resources: bool = Field(
        default=True,
        description="Block images/CSS/fonts during browser rendering for faster text extraction",
    )
    download_images: bool = Field(
        default=False,
        description="Enable binary image downloading",
    )
    image_dir: str = Field(
        default="images",
        description="Directory for downloaded images",
    )
    image_scope: Literal["same-domain", "all"] = Field(
        default="same-domain",
        description="Image download scope: same-domain=only images from crawled domains, all=include external CDNs and third-party sources",
    )
    max_image_size: int = Field(
        default=10_485_760,
        gt=0,
        description="Maximum image file size in bytes (default 10MB)",
    )
    process_documents: bool = Field(
        default=False,
        description="Enable PDF document processing via Docling",
    )
    ocr_mode: Literal["off", "auto", "always"] = Field(
        default="auto",
        description="OCR mode: off=skip OCR, auto=PyMuPDF detect then OCR if needed, always=force full OCR",
    )
    ocr_language: str = Field(
        default="en",
        description="OCR language code for EasyOCR (2-letter: en, fr, de, es)",
    )
    max_document_size: int = Field(
        default=52_428_800,
        gt=0,
        description="Maximum PDF file size in bytes (default 50MB)",
    )
    max_document_pages: int = Field(
        default=500,
        gt=0,
        description="Maximum PDF page count (default 500)",
    )
    store_html: bool = Field(
        default=False,
        description="Store raw HTML in database (rendered DOM for dynamic pages)",
    )
    quiet: bool = Field(
        default=False,
        description="Suppress progress and summary output (only errors shown)",
    )

    @field_validator("database_path")
    @classmethod
    def validate_database_path(cls, v: str) -> str:
        """Validate that database path ends with .db or .sqlite."""
        if not (v.endswith(".db") or v.endswith(".sqlite")):
            raise ValueError("Database path must end with .db or .sqlite")
        return v
