"""URL queue management and worker orchestration for multi-page crawling."""

import asyncio
import json
import sys
from urllib.parse import urlparse

import structlog

from crawlvox.browser import BrowserManager
from crawlvox.config import ScraperConfig
from crawlvox.documents import DocumentProcessor
from crawlvox.fetcher import Fetcher
from crawlvox.media import ImageDownloader
from crawlvox.parser import classify_content_type, extract_content_with_fallback, extract_links, extract_metadata, extract_images
from crawlvox.robots import RobotsCache
from crawlvox.sitemap import extract_sitemap_urls
from crawlvox.storage import create_run, get_image_ids_for_page, get_pending_urls, get_visited_urls, init_database, save_links, save_page, save_images, update_run_status
from crawlvox.url_utils import TrapDetector, ScopeChecker, normalize_url


class Crawler:
    """Crawler engine with asyncio worker pool and BFS traversal."""

    def __init__(self, config: ScraperConfig):
        """Initialize crawler with configuration.

        Args:
            config: Validated scraper configuration
        """
        self.config = config
        self.logger = structlog.get_logger()
        self._queue: asyncio.Queue[tuple[str, int]] = asyncio.Queue()
        self._seen: set[str] = set()
        self._pages_crawled: int = 0
        self._lock = asyncio.Lock()  # Protects _pages_crawled and _seen for safety

        # Phase 9 shutdown and run tracking
        self._shutdown_event = asyncio.Event()
        self._run_id: str | None = None

        # Phase 4 components (scope_checker initialized in crawl() when start_urls known)
        self._scope_checker: ScopeChecker | None = None
        self._trap_detector = TrapDetector()
        self._robots: RobotsCache | None = (
            RobotsCache(config.user_agent) if config.respect_robots_txt else None
        )

        # Phase 7 image downloading components
        self._image_downloader: ImageDownloader | None = None
        self._image_tasks: list[asyncio.Task] = []  # Background download tasks for cleanup

        # Phase 8 document processing components
        self._document_processor: DocumentProcessor | None = None

        # Phase 12 error tracking for end-of-crawl summary
        self._error_counts: dict[str, int] = {}

    def canonicalize_url(self, url: str) -> str:
        """Canonicalize URL using enhanced normalization.

        Args:
            url: URL to canonicalize

        Returns:
            Canonical URL with normalization applied
        """
        return normalize_url(url)

    def _add_url(self, url: str, depth: int) -> bool:
        """Add URL to crawl queue if not already seen and within limits.

        Args:
            url: URL to add
            depth: Depth level for this URL

        Returns:
            True if URL was added, False if skipped (duplicate, depth limit, page limit, shutdown)
        """
        # Check if shutdown is in progress (Phase 9: stop accepting new URLs)
        if self._shutdown_event.is_set():
            return False

        # Canonicalize URL
        canonical = self.canonicalize_url(url)

        # Check if already seen (deduplication)
        if canonical in self._seen:
            return False

        # Check depth limit
        if depth > self.config.max_depth:
            return False

        # Check page limit
        if len(self._seen) >= self.config.max_pages:
            return False

        # Check scope (if scope_checker initialized)
        if self._scope_checker and not self._scope_checker.is_allowed(canonical):
            self.logger.debug("url_out_of_scope", url=canonical)
            return False

        # Check trap detection
        if self._trap_detector.is_trap(canonical):
            self.logger.info("trap_detected", url=canonical)
            return False

        # Add to seen set BEFORE queue.put() to prevent race condition duplicates
        self._seen.add(canonical)

        # Enqueue for processing
        self._queue.put_nowait((canonical, depth))

        return True

    def _classify_error(self, error_str: str) -> str:
        """Classify an error string into a category for the error summary."""
        error_lower = error_str.lower()
        if "ssl" in error_lower or "certificate" in error_lower or "tls" in error_lower:
            return "ssl"
        elif "timeout" in error_lower or "timed out" in error_lower:
            return "timeout"
        elif "connect" in error_lower or "connection" in error_lower:
            return "connection"
        elif any(code in error_lower for code in ["400", "401", "403", "404", "429"]):
            return "http_error"
        elif any(code in error_lower for code in ["500", "502", "503", "504"]):
            return "server_error"
        return "other"

    async def _worker(self, worker_id: int, fetcher: Fetcher, browser: BrowserManager | None, db_path: str) -> None:
        """Worker coroutine that processes URLs from the queue.

        Args:
            worker_id: Unique identifier for this worker
            fetcher: Shared Fetcher instance for HTTP requests
            browser: Optional BrowserManager for dynamic content rendering
            db_path: Path to SQLite database
        """
        while True:
            # Get URL from queue (CancelledError propagates up if task is cancelled)
            url, depth = await self._queue.get()

            try:
                # Check if we've reached max_pages limit
                async with self._lock:
                    if self._pages_crawled >= self.config.max_pages:
                        self.logger.debug(
                            "worker_skipping_max_pages",
                            worker_id=worker_id,
                            url=url,
                        )
                        continue

                # Check robots.txt (if enabled)
                if self._robots and fetcher.client:
                    allowed = await self._robots.can_fetch(url, fetcher.client)
                    if not allowed:
                        self.logger.info("robots_disallowed", url=url)
                        continue

                # Step 1: Detect content type
                content_type = await fetcher.detect_content_type(url)
                classification = classify_content_type(content_type, url)

                if classification == "pdf":
                    # PDF: route to DocumentProcessor when enabled, else skip gracefully
                    if self.config.process_documents and self._document_processor:
                        self.logger.info(
                            "worker_processing_document",
                            worker_id=worker_id,
                            url=url,
                        )
                        await self._document_processor.process_document(url, content_type)
                    else:
                        self.logger.debug(
                            "worker_skipping_document",
                            url=url,
                        )
                        await save_page(
                            db_path=db_path,
                            url=url,
                            final_url=None,
                            status_code=None,
                            content_type=content_type,
                            title=None,
                            description=None,
                            main_text=None,
                            error="Skipped: PDF processing not enabled",
                            run_id=self._run_id,
                        )
                    async with self._lock:
                        self._pages_crawled += 1
                    continue

                elif classification != "html":
                    self.logger.info(
                        "worker_skipping_non_html",
                        worker_id=worker_id,
                        url=url,
                        content_type=content_type,
                    )
                    await save_page(
                        db_path=db_path,
                        url=url,
                        final_url=None,
                        status_code=None,
                        content_type=content_type,
                        title=None,
                        description=None,
                        main_text=None,
                        error=f"Skipped: unsupported content type '{content_type}'",
                        run_id=self._run_id,
                    )
                    continue

                # Step 2: Fetch HTML
                result = await fetcher.fetch(url)

                if not result.success:
                    self.logger.warning(
                        "worker_fetch_failed",
                        worker_id=worker_id,
                        url=url,
                        error=result.error,
                    )
                    await save_page(
                        db_path=db_path,
                        url=url,
                        final_url=result.final_url,
                        status_code=result.status_code,
                        content_type=content_type,
                        title=None,
                        description=None,
                        main_text=None,
                        error=result.error,
                        run_id=self._run_id,
                    )
                    # Track error type for end-of-crawl summary
                    error_type = self._classify_error(result.error or "unknown")
                    self._error_counts[error_type] = self._error_counts.get(error_type, 0) + 1
                    continue

                # Warn on empty 200 responses (save with empty content -- data is accurate)
                if result.success and (not result.html or result.html.strip() == ""):
                    self.logger.warning("empty_response", url=url, status_code=result.status_code)

                # Step 3: Extract content with fallback
                parsed = extract_content_with_fallback(
                    result.html,
                    result.final_url or url,
                    min_length=self.config.min_content_length
                )

                # Step 3.5: Dynamic fallback - re-fetch with browser if content insufficient
                needs_dynamic = False
                if self.config.dynamic_mode == "always":
                    needs_dynamic = True
                elif self.config.dynamic_mode == "auto":
                    # Auto-detect: content too short after static extraction
                    needs_dynamic = (
                        not parsed.success
                        or not parsed.text
                        or len(parsed.text) < self.config.min_content_length
                    )
                # dynamic_mode == "off" -> needs_dynamic stays False

                if needs_dynamic and browser:
                    self.logger.info(
                        "dynamic_fallback_triggered",
                        worker_id=worker_id,
                        url=url,
                        reason="always" if self.config.dynamic_mode == "always" else "insufficient_content",
                        static_length=len(parsed.text) if parsed.text else 0,
                    )
                    dynamic_html = await browser.fetch_dynamic(url)
                    if dynamic_html:
                        # Re-extract content from rendered HTML
                        parsed = extract_content_with_fallback(
                            dynamic_html,
                            result.final_url or url,
                            min_length=self.config.min_content_length,
                        )
                        # Use rendered HTML for subsequent metadata/image/link extraction
                        result.html = dynamic_html

                # Capture raw HTML for storage (AFTER dynamic fallback so rendered DOM is stored)
                raw_html = result.html if self.config.store_html else None

                # Step 4: Extract metadata
                metadata = extract_metadata(result.html, result.final_url or url)

                # Step 5: Extract images
                images = extract_images(result.html, result.final_url or url)

                # Step 6: Extract links
                links = extract_links(result.html, result.final_url or url)

                # Convert Link objects to tuples for storage
                link_tuples = [
                    (link.href_abs, link.anchor_text, link.rel, link.is_internal)
                    for link in links
                ]

                # Convert Image objects to tuples for storage
                image_tuples = [
                    (img.src_abs, img.alt, img.width, img.height, img.srcset)
                    for img in images
                ]

                # Step 7: Save page to database (with run_id for run_pages mapping)
                await save_page(
                    db_path=db_path,
                    url=url,
                    final_url=result.final_url,
                    status_code=result.status_code,
                    content_type=content_type,
                    title=parsed.title,
                    description=parsed.description,
                    main_text=parsed.text,
                    error=parsed.error if not parsed.success else None,
                    extraction_method=parsed.extraction_method,
                    canonical_url=metadata.canonical_url,
                    og_title=metadata.og_title,
                    og_description=metadata.og_description,
                    og_image=metadata.og_image,
                    language=metadata.language,
                    raw_html=raw_html,
                    run_id=self._run_id,
                )

                # Step 8: Save links to database (with source_depth for resume reconstruction)
                await save_links(db_path, url, link_tuples, source_depth=depth)

                # Step 9: Save images to database
                await save_images(db_path, url, image_tuples)

                # Step 9.5: Fire background image downloads (non-blocking)
                if self.config.download_images and self._image_downloader:
                    image_ids = await get_image_ids_for_page(db_path, url)
                    if image_ids:
                        task = asyncio.create_task(
                            self._image_downloader.download_page_images(url, image_ids)
                        )
                        self._image_tasks.append(task)

                # Step 10: Increment pages crawled counter
                async with self._lock:
                    self._pages_crawled += 1
                    current_pages = self._pages_crawled

                # Step 11: Enqueue internal links if depth allows
                if depth < self.config.max_depth:
                    internal_links = [link for link in links if link.is_internal]
                    added_count = 0
                    for link in internal_links:
                        if self._add_url(link.href_abs, depth + 1):
                            added_count += 1

                    if added_count > 0:
                        self.logger.debug(
                            "worker_enqueued_links",
                            worker_id=worker_id,
                            url=url,
                            added=added_count,
                            depth=depth + 1,
                        )

                # Log progress
                self.logger.info(
                    "worker_processed_page",
                    worker_id=worker_id,
                    url=url,
                    depth=depth,
                    pages_crawled=current_pages,
                    queue_size=self._queue.qsize(),
                    seen_count=len(self._seen),
                    links_found=len(links),
                    images_found=len(images),
                    extraction_method=parsed.extraction_method,
                )

            except Exception as e:
                # Catch-all for unexpected errors during processing
                self.logger.error(
                    "worker_error",
                    worker_id=worker_id,
                    url=url,
                    error=str(e),
                    exc_info=True,
                )
                # Track error type for end-of-crawl summary
                error_type = self._classify_error(str(e))
                self._error_counts[error_type] = self._error_counts.get(error_type, 0) + 1

            finally:
                # MUST call task_done() in finally block to prevent hang
                self._queue.task_done()

    async def crawl(self, start_urls: list[str], run_id: str, resume: bool = False, recrawl: bool = False) -> None:
        """Execute crawl starting from given URLs.

        Args:
            start_urls: List of seed URLs to start crawling from
            run_id: Unique identifier for this crawl run
            resume: If True, resume from an interrupted run by pre-seeding _seen and reconstructing queue
            recrawl: If True on resume, re-process already-visited pages (skip _seen pre-seeding)
        """
        self._run_id = run_id
        self.logger.info("crawl_starting", run_id=run_id, start_urls=start_urls, resume=resume, recrawl=recrawl)

        # Extract start domains for scope checking
        start_domains = []
        for url in start_urls:
            parsed = urlparse(url)
            if parsed.netloc:
                start_domains.append(parsed.netloc)

        # Initialize scope checker with start domains
        self._scope_checker = ScopeChecker(
            start_domains=start_domains,
            same_domain_only=self.config.same_domain_only,
            allow_patterns=self.config.include_patterns or None,
            deny_patterns=self.config.exclude_patterns or None,
        )

        # Initialize database
        await init_database(self.config.database_path)

        if resume:
            # Resume mode: pre-seed _seen set from visited URLs (unless recrawl)
            if not recrawl:
                visited = await get_visited_urls(self.config.database_path, run_id)
                self._seen = visited
                self._pages_crawled = len(visited)
                self.logger.info("resume_loaded_visited", count=len(visited))

            # Reconstruct queue from discovered-but-not-visited URLs
            pending = await get_pending_urls(self.config.database_path, run_id)
            for pending_url, pending_depth in pending:
                self._add_url(pending_url, pending_depth)
            self.logger.info("resume_loaded_pending", count=len(pending))
        else:
            # Fresh run: create run record with start_urls_json for resume matching
            start_urls_json = json.dumps(sorted(normalize_url(u) for u in start_urls))
            await create_run(self.config.database_path, run_id, self.config.model_dump_json(), start_urls_json=start_urls_json)

        # Seed queue with start URLs
        if not resume:
            # Fresh run: seed queue with start URLs at depth 0
            for url in start_urls:
                added = self._add_url(url, 0)
                if added:
                    self.logger.info("seed_url_added", url=url)
                else:
                    self.logger.warning("seed_url_skipped", url=url)
        elif recrawl:
            # Recrawl mode: re-seed from start URLs (_seen was not pre-populated)
            for url in start_urls:
                added = self._add_url(url, 0)
                if added:
                    self.logger.info("recrawl_seed_url_added", url=url)

        # Create Fetcher (always needed)
        async with Fetcher(
            user_agent=self.config.user_agent,
            timeout=self.config.request_timeout,
            max_retries=self.config.max_retries,
            rate_limit=self.config.rate_limit,
            cookie_file=self.config.cookie_file,
        ) as fetcher:
            # Create BrowserManager only if dynamic mode is not off
            browser: BrowserManager | None = None
            if self.config.dynamic_mode != "off":
                browser_mgr = BrowserManager(
                    timeout=self.config.playwright_timeout,
                    block_resources=self.config.block_resources,
                    user_agent=self.config.user_agent,
                )
                browser = await browser_mgr.__aenter__()

            # Create ImageDownloader if image downloading is enabled
            if self.config.download_images:
                self._image_downloader = ImageDownloader(
                    client=fetcher.client,
                    image_dir=self.config.image_dir,
                    max_image_size=self.config.max_image_size,
                    image_scope=self.config.image_scope,
                    db_path=self.config.database_path,
                )
                self._image_downloader = await self._image_downloader.__aenter__()
                # Pre-load hashes from previous runs for cross-run deduplication
                await self._image_downloader.load_existing_hashes()
                self.logger.info("image_downloader_ready", image_dir=self.config.image_dir)

            # Create DocumentProcessor if document processing is enabled
            if self.config.process_documents:
                self._document_processor = DocumentProcessor(
                    client=fetcher.client,
                    db_path=self.config.database_path,
                    ocr_mode=self.config.ocr_mode,
                    ocr_language=self.config.ocr_language,
                    max_file_size=self.config.max_document_size,
                    max_pages=self.config.max_document_pages,
                )
                self._document_processor = await self._document_processor.__aenter__()
                self.logger.info(
                    "document_processor_ready",
                    ocr_mode=self.config.ocr_mode,
                )

            workers: list[asyncio.Task] = []

            try:
                # Sitemap seeding (after Fetcher is available for robots.txt fetch)
                if self.config.respect_robots_txt and self._robots:
                    for url in start_urls:
                        # Pre-fetch robots.txt to populate cache
                        await self._robots.can_fetch(url, fetcher.client)

                        # Check crawl-delay and adjust rate limiter if needed
                        crawl_delay = self._robots.get_crawl_delay(url)
                        if crawl_delay and crawl_delay > (1.0 / self.config.rate_limit):
                            domain = urlparse(url).netloc
                            self.logger.info("respecting_crawl_delay", domain=domain, delay=crawl_delay)
                            # Override the fetcher's rate limiter for this domain
                            from aiolimiter import AsyncLimiter
                            fetcher._rate_limiters[domain] = AsyncLimiter(
                                max_rate=1.0 / crawl_delay,
                                time_period=1.0,
                            )

                        # Discover sitemap URLs
                        sitemap_urls_from_robots = self._robots.get_sitemaps(url)
                        if sitemap_urls_from_robots:
                            self.logger.info("sitemaps_found_in_robots", url=url, count=len(sitemap_urls_from_robots))

                    # Parse sitemaps and seed URLs
                    for url in start_urls:
                        sitemap_urls = extract_sitemap_urls(url, max_urls=self.config.max_pages)
                        if sitemap_urls:
                            added_count = 0
                            for sitemap_url in sitemap_urls:
                                if self._add_url(sitemap_url, 1):  # depth 1 (discovered, not seed)
                                    added_count += 1
                            self.logger.info("sitemap_urls_seeded", start_url=url, added=added_count, total_found=len(sitemap_urls))

                # Create worker tasks
                workers = [
                    asyncio.create_task(self._worker(i, fetcher, browser, self.config.database_path))
                    for i in range(self.config.max_workers)
                ]

                self.logger.info("workers_started", worker_count=self.config.max_workers)

                # Wait for queue to be fully processed
                await self._queue.join()

                self.logger.info("queue_complete", pages_crawled=self._pages_crawled)

                # Cancel workers (normal completion)
                for worker in workers:
                    worker.cancel()

                # Wait for workers to finish cancellation
                await asyncio.gather(*workers, return_exceptions=True)

                self.logger.info("workers_stopped")

            except asyncio.CancelledError:
                # Graceful shutdown: Ctrl+C was pressed, CancelledError propagated from asyncio.run()
                self._shutdown_event.set()
                in_flight = sum(1 for w in workers if not w.done())
                self.logger.info("shutdown_graceful_start", in_flight=in_flight)

                # Print user-facing shutdown feedback
                print(f"\nShutting down gracefully... Finishing {in_flight} in-flight pages...", file=sys.stderr, flush=True)

                # Cancel workers so they exit after completing current page
                for worker in workers:
                    worker.cancel()
                await asyncio.gather(*workers, return_exceptions=True)

                print("Saving state... Done.", file=sys.stderr, flush=True)
                print("Run with --resume to continue.", file=sys.stderr, flush=True)

                self.logger.info("shutdown_graceful_complete", pages_crawled=self._pages_crawled)

                # Re-raise so async_crawl() can catch and set run status to 'interrupted'
                raise

            finally:
                # Close DocumentProcessor if it was opened
                if self._document_processor:
                    await self._document_processor.__aexit__(None, None, None)

                # Wait for any remaining image download tasks to complete
                # (must finish before Fetcher closes its httpx client)
                if self._image_tasks:
                    self.logger.info(
                        "waiting_for_image_downloads",
                        pending=len([t for t in self._image_tasks if not t.done()]),
                    )
                    await asyncio.gather(*self._image_tasks, return_exceptions=True)
                    self.logger.info("image_downloads_complete")

                # Close ImageDownloader if it was opened
                if self._image_downloader:
                    await self._image_downloader.__aexit__(None, None, None)

                # Close browser if it was opened
                if browser:
                    await browser.__aexit__(None, None, None)

        # Log completion
        self.logger.info(
            "crawl_complete",
            run_id=run_id,
            pages_crawled=self._pages_crawled,
            total_urls_seen=len(self._seen),
        )

        if self.config.download_images:
            self.logger.info(
                "image_download_summary",
                tasks_fired=len(self._image_tasks),
            )

        if self.config.process_documents:
            self.logger.info(
                "document_processing_summary",
                enabled=True,
                ocr_mode=self.config.ocr_mode,
            )
