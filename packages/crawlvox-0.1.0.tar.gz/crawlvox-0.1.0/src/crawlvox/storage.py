"""SQLite storage layer with WAL mode for async concurrency safety."""

import csv
import io
import json
import os
import re
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import aiofiles
import aiofiles.os
import aiosqlite
import structlog


def get_logger():
    """Get a structured logger instance."""
    return structlog.get_logger()


async def init_database(db_path: str) -> None:
    """Initialize SQLite database with WAL mode and schema.

    Args:
        db_path: Path to SQLite database file

    Creates:
        - pages table: Stores scraped page content and metadata
        - runs table: Stores crawl run records
    """
    async with aiosqlite.connect(db_path) as db:
        # Enable WAL mode for async concurrency safety
        await db.execute("PRAGMA journal_mode=WAL")
        # Set synchronous to NORMAL for better performance with WAL
        await db.execute("PRAGMA synchronous=NORMAL")
        # Enable foreign key constraints
        await db.execute("PRAGMA foreign_keys=ON")

        # Create pages table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pages (
                url TEXT PRIMARY KEY,
                final_url TEXT,
                status_code INTEGER,
                fetch_method TEXT,
                fetched_at TEXT,
                title TEXT,
                description TEXT,
                main_text TEXT,
                content_type TEXT,
                raw_html_path TEXT,
                error TEXT,
                extraction_method TEXT,
                canonical_url TEXT,
                og_title TEXT,
                og_description TEXT,
                og_image TEXT,
                language TEXT
            )
        """)

        # Create runs table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS runs (
                run_id TEXT PRIMARY KEY,
                started_at TEXT NOT NULL,
                config_json TEXT NOT NULL,
                notes TEXT
            )
        """)

        # Create links table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                page_url TEXT NOT NULL,
                href_abs TEXT NOT NULL,
                anchor_text TEXT,
                rel TEXT,
                is_internal BOOLEAN NOT NULL,
                FOREIGN KEY (page_url) REFERENCES pages(url) ON DELETE CASCADE
            )
        """)

        # Create indexes for links table
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_links_page_url ON links(page_url)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_links_href_abs ON links(href_abs)
        """)

        # Create images table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                page_url TEXT NOT NULL,
                src_abs TEXT NOT NULL,
                alt TEXT,
                width INTEGER,
                height INTEGER,
                srcset TEXT,
                fetched_at TEXT NOT NULL,
                local_path TEXT,
                sha256 TEXT,
                FOREIGN KEY (page_url) REFERENCES pages(url) ON DELETE CASCADE
            )
        """)

        # Create indexes for images table
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_images_page_url ON images(page_url)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_images_src_abs ON images(src_abs)
        """)

        # Create index for pages canonical_url
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_pages_canonical ON pages(canonical_url)
        """)

        # Add Phase 5 columns to existing databases (no-op on fresh databases)
        for col, col_type in [
            ("extraction_method", "TEXT"),
            ("canonical_url", "TEXT"),
            ("og_title", "TEXT"),
            ("og_description", "TEXT"),
            ("og_image", "TEXT"),
            ("language", "TEXT"),
        ]:
            try:
                await db.execute(f"ALTER TABLE pages ADD COLUMN {col} {col_type}")
            except Exception:
                pass  # Column already exists

        # Add Phase 7 columns to existing databases (no-op on fresh databases)
        for col, col_type in [
            ("local_path", "TEXT"),
            ("sha256", "TEXT"),
        ]:
            try:
                await db.execute(f"ALTER TABLE images ADD COLUMN {col} {col_type}")
            except Exception:
                pass  # Column already exists

        # Add index for SHA256 deduplication queries
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_images_sha256 ON images(sha256)
        """)

        # Create documents table (standalone, no FK to pages -- locked decision)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                url TEXT PRIMARY KEY,
                fetched_at TEXT NOT NULL,
                content_type TEXT,
                page_count INTEGER,
                has_ocr INTEGER NOT NULL DEFAULT 0,
                extracted_text TEXT,
                file_size_bytes INTEGER,
                error TEXT,
                status TEXT NOT NULL
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status)
        """)

        # Phase 9 columns for resumability
        for col, col_type in [
            ("status", "TEXT NOT NULL DEFAULT 'running'"),
            ("completed_at", "TEXT"),
            ("start_urls_json", "TEXT"),
        ]:
            try:
                await db.execute(f"ALTER TABLE runs ADD COLUMN {col} {col_type}")
            except Exception:
                pass  # Column already exists

        # Create run_pages join table (scopes pages to runs for resume queries)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS run_pages (
                run_id TEXT NOT NULL,
                url TEXT NOT NULL,
                PRIMARY KEY (run_id, url),
                FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE,
                FOREIGN KEY (url) REFERENCES pages(url) ON DELETE CASCADE
            )
        """)

        # Index on run_id for efficient run-scoped queries
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_run_pages_run_id ON run_pages(run_id)
        """)

        # Phase 9: depth tracking for resume queue reconstruction
        try:
            await db.execute("ALTER TABLE links ADD COLUMN source_depth INTEGER")
        except Exception:
            pass  # Column already exists

        # Phase 10: raw HTML storage column
        try:
            await db.execute("ALTER TABLE pages ADD COLUMN raw_html TEXT")
        except Exception:
            pass  # Column already exists

        # Phase 11: Performance indexes for export, purge, and reverse lookup
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_pages_status_code ON pages(status_code)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_runs_started_at ON runs(started_at)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_run_pages_url ON run_pages(url)
        """)

        await db.commit()


async def create_run(
    db_path: str,
    run_id: str,
    config_json: str,
    notes: str | None = None,
    start_urls_json: str | None = None,
) -> None:
    """Create a new crawl run record.

    Args:
        db_path: Path to SQLite database file
        run_id: Unique identifier for this run
        config_json: JSON string of configuration
        notes: Optional notes about this run
        start_urls_json: JSON-serialized sorted list of start URLs for resume matching
    """
    logger = get_logger()
    started_at = datetime.now(timezone.utc).isoformat()

    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            "INSERT INTO runs (run_id, started_at, config_json, notes, status, start_urls_json) VALUES (?, ?, ?, ?, 'running', ?)",
            (run_id, started_at, config_json, notes, start_urls_json),
        )
        await db.commit()

    logger.info("run_created", run_id=run_id, started_at=started_at)


async def save_page(
    db_path: str,
    url: str,
    final_url: str | None,
    status_code: int | None,
    content_type: str | None,
    title: str | None,
    description: str | None,
    main_text: str | None,
    error: str | None,
    fetch_method: str = "static",
    extraction_method: str | None = None,
    canonical_url: str | None = None,
    og_title: str | None = None,
    og_description: str | None = None,
    og_image: str | None = None,
    language: str | None = None,
    raw_html: str | None = None,
    run_id: str | None = None,
) -> None:
    """Save page fetch and parse results to database.

    Args:
        db_path: Path to SQLite database file
        url: Original requested URL (PRIMARY KEY)
        final_url: Final URL after redirects
        status_code: HTTP status code
        content_type: Content-Type header value
        title: Extracted page title
        description: Extracted meta description
        main_text: Extracted main content text
        error: Error message if fetch/parse failed
        fetch_method: Fetch method used ('static' for Phase 2)
        extraction_method: Content extraction method used (Phase 5)
        canonical_url: Canonical URL from metadata (Phase 5)
        og_title: OpenGraph title from metadata (Phase 5)
        og_description: OpenGraph description from metadata (Phase 5)
        og_image: OpenGraph image URL from metadata (Phase 5)
        language: Page language from metadata (Phase 5)
        raw_html: Raw HTML content for storage (rendered DOM for dynamic pages) (Phase 10)
        run_id: Run identifier for run_pages mapping (Phase 9)
    """
    logger = get_logger()
    fetched_at = datetime.now(timezone.utc).isoformat()

    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            """
            INSERT OR REPLACE INTO pages (
                url, final_url, status_code, fetch_method, fetched_at,
                title, description, main_text, content_type, raw_html_path, error,
                extraction_method, canonical_url, og_title, og_description, og_image, language,
                raw_html
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                url,
                final_url,
                status_code,
                fetch_method,
                fetched_at,
                title,
                description,
                main_text,
                content_type,
                None,  # raw_html_path - NULL (legacy column, not used)
                error,
                extraction_method,
                canonical_url,
                og_title,
                og_description,
                og_image,
                language,
                raw_html,
            ),
        )

        # Record page-to-run mapping for resume support
        if run_id:
            await db.execute(
                "INSERT OR IGNORE INTO run_pages (run_id, url) VALUES (?, ?)",
                (run_id, url),
            )

        await db.commit()

    logger.info(
        "page_saved",
        url=url,
        status_code=status_code,
        has_text=(main_text is not None),
    )


async def save_links(
    db_path: str,
    page_url: str,
    links: list[tuple[str, str | None, str | None, bool]],
    source_depth: int | None = None,
) -> None:
    """Save extracted links to database.

    Args:
        db_path: Path to SQLite database file
        page_url: Source page URL (must exist in pages table)
        links: List of (href_abs, anchor_text, rel, is_internal) tuples
        source_depth: Crawl depth of the source page for queue reconstruction (Phase 9)

    Note:
        Uses batch insert with executemany for efficiency when processing
        many pages in Phase 3 crawler.
    """
    logger = get_logger()

    # Handle empty links list gracefully
    if not links:
        logger.debug("no_links_to_save", page_url=page_url)
        return

    async with aiosqlite.connect(db_path) as db:
        await db.executemany(
            """
            INSERT INTO links (page_url, href_abs, anchor_text, rel, is_internal, source_depth)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [(page_url, href, text, rel, internal, source_depth) for href, text, rel, internal in links],
        )
        await db.commit()

    logger.info("links_saved", page_url=page_url, count=len(links))


async def save_images(
    db_path: str,
    page_url: str,
    images: list[tuple[str, str | None, int | None, int | None, str | None]],
) -> None:
    """Save extracted images to database.

    Args:
        db_path: Path to SQLite database file
        page_url: Source page URL (must exist in pages table)
        images: List of (src_abs, alt, width, height, srcset) tuples

    Note:
        Uses batch insert with executemany for efficiency when processing
        many pages in Phase 5 content quality extraction.
    """
    logger = get_logger()

    # Handle empty images list gracefully
    if not images:
        logger.debug("no_images_to_save", page_url=page_url)
        return

    fetched_at = datetime.now(timezone.utc).isoformat()

    async with aiosqlite.connect(db_path) as db:
        await db.executemany(
            """
            INSERT INTO images (page_url, src_abs, alt, width, height, srcset, fetched_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            [(page_url, src, alt, width, height, srcset, fetched_at)
             for src, alt, width, height, srcset in images],
        )
        await db.commit()

    logger.info("images_saved", page_url=page_url, count=len(images))


async def update_image_download(
    db_path: str,
    image_id: int,
    local_path: str,
    sha256: str,
) -> None:
    """Update an image record with download results.

    Args:
        db_path: Path to SQLite database file
        image_id: Primary key of the image record to update
        local_path: Absolute path to the downloaded image file
        sha256: SHA256 hex digest of the image content
    """
    logger = get_logger()

    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            "UPDATE images SET local_path=?, sha256=? WHERE id=?",
            (local_path, sha256, image_id),
        )
        await db.commit()

    logger.debug("image_download_updated", image_id=image_id, sha256=sha256[:16])


async def get_existing_image_hashes(db_path: str) -> dict[str, str]:
    """Load existing image SHA256 hashes and local paths from database.

    Used for cross-run deduplication: pre-populate the hash cache
    so previously-downloaded images are not re-downloaded.

    Args:
        db_path: Path to SQLite database file

    Returns:
        Dict mapping SHA256 hex digest to absolute local file path
    """
    logger = get_logger()
    result: dict[str, str] = {}

    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT sha256, local_path FROM images WHERE sha256 IS NOT NULL AND local_path IS NOT NULL"
        ) as cursor:
            async for row in cursor:
                sha256_val, local_path_val = row
                if sha256_val not in result:
                    result[sha256_val] = local_path_val

    logger.info("existing_hashes_loaded", count=len(result))
    return result


async def get_image_ids_for_page(
    db_path: str,
    page_url: str,
) -> list[tuple[int, str]]:
    """Get image IDs and source URLs for a page.

    Args:
        db_path: Path to SQLite database file
        page_url: Page URL to look up images for

    Returns:
        List of (id, src_abs) tuples for images belonging to this page
    """
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT id, src_abs FROM images WHERE page_url=?",
            (page_url,),
        ) as cursor:
            return [(row[0], row[1]) for row in await cursor.fetchall()]


async def update_run_status(db_path: str, run_id: str, status: str) -> None:
    """Update the status of a crawl run.

    Args:
        db_path: Path to SQLite database file
        run_id: Run identifier to update
        status: New status ('completed', 'interrupted', 'failed')
    """
    logger = get_logger()
    completed_at = datetime.now(timezone.utc).isoformat() if status in ("completed", "interrupted", "failed") else None

    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            "UPDATE runs SET status=?, completed_at=? WHERE run_id=?",
            (status, completed_at, run_id),
        )
        await db.commit()

    logger.info("run_status_updated", run_id=run_id, status=status)


async def get_interrupted_runs(db_path: str, start_urls_json: str) -> list[tuple[str, str, int]]:
    """Find interrupted runs matching the given start URLs.

    Args:
        db_path: Path to SQLite database file
        start_urls_json: JSON-serialized sorted list of start URLs to match

    Returns:
        List of (run_id, started_at, pages_crawled) tuples, ordered by started_at DESC
    """
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            """
            SELECT r.run_id, r.started_at,
                   (SELECT COUNT(*) FROM run_pages rp WHERE rp.run_id = r.run_id) as pages_crawled
            FROM runs r
            WHERE r.status = 'interrupted'
              AND r.start_urls_json = ?
            ORDER BY r.started_at DESC
            """,
            (start_urls_json,),
        ) as cursor:
            return [(row[0], row[1], row[2]) for row in await cursor.fetchall()]


async def get_visited_urls(db_path: str, run_id: str) -> set[str]:
    """Get all URLs already processed in a run (for seeding _seen set on resume).

    Args:
        db_path: Path to SQLite database file
        run_id: Run identifier

    Returns:
        Set of URL strings already visited in this run
    """
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT url FROM run_pages WHERE run_id = ?",
            (run_id,),
        ) as cursor:
            rows = await cursor.fetchall()
            return {row[0] for row in rows}


async def get_pending_urls(db_path: str, run_id: str) -> list[tuple[str, int]]:
    """Get URLs discovered but not yet visited for queue reconstruction on resume.

    Finds internal links from pages in this run that haven't been visited yet.
    Returns (url, depth) tuples where depth = source_depth + 1.

    Args:
        db_path: Path to SQLite database file
        run_id: Run identifier

    Returns:
        List of (url, depth) tuples for re-seeding the crawl queue
    """
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            """
            SELECT DISTINCT l.href_abs, COALESCE(l.source_depth + 1, 1) as depth
            FROM links l
            JOIN run_pages rp ON l.page_url = rp.url
            LEFT JOIN run_pages rp2 ON l.href_abs = rp2.url AND rp2.run_id = ?
            WHERE rp.run_id = ?
              AND l.is_internal = 1
              AND rp2.url IS NULL
            """,
            (run_id, run_id),
        ) as cursor:
            return [(row[0], row[1]) for row in await cursor.fetchall()]


async def get_status_distribution(db_path: str, run_id: str) -> dict[int | None, int]:
    """Get status code distribution for pages in a specific run.

    Args:
        db_path: Path to SQLite database file
        run_id: Run identifier

    Returns:
        Dict mapping status_code (int or None for errors) to count
    """
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            """
            SELECT p.status_code, COUNT(*) as cnt
            FROM pages p
            JOIN run_pages rp ON p.url = rp.url
            WHERE rp.run_id = ?
            GROUP BY p.status_code
            """,
            (run_id,),
        ) as cursor:
            rows = await cursor.fetchall()
    return {row[0]: row[1] for row in rows}


async def save_document(
    db_path: str,
    url: str,
    content_type: str | None,
    page_count: int | None,
    has_ocr: bool,
    extracted_text: str | None,
    file_size_bytes: int | None,
    error: str | None,
    status: str,
) -> None:
    """Save a document processing result to the documents table.

    Args:
        db_path: Path to SQLite database file
        url: Document URL (PRIMARY KEY)
        content_type: MIME content type (e.g., 'application/pdf')
        page_count: Number of pages in the document
        has_ocr: Whether OCR was applied during extraction
        extracted_text: Full extracted text content
        file_size_bytes: File size in bytes
        error: Error message if processing failed
        status: Processing status: 'success', 'failed', or 'skipped'
    """
    logger = get_logger()
    fetched_at = datetime.now(timezone.utc).isoformat()

    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            """
            INSERT OR REPLACE INTO documents (
                url, fetched_at, content_type, page_count, has_ocr,
                extracted_text, file_size_bytes, error, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                url,
                fetched_at,
                content_type,
                page_count,
                1 if has_ocr else 0,
                extracted_text,
                file_size_bytes,
                error,
                status,
            ),
        )
        await db.commit()

    logger.info(
        "document_saved",
        url=url,
        status=status,
        has_ocr=has_ocr,
        page_count=page_count,
    )


def _build_page_query(
    run_id: str | None = None,
    url_pattern: str | None = None,
    status_filter: str | None = None,
    include_html: bool = False,
) -> tuple[str, list]:
    """Build the filtered page SELECT query used by all export formats.

    Args:
        run_id: Filter to pages from this run only
        url_pattern: SQL LIKE filter on URL
        status_filter: 'ok' (no error), 'error' (has error), or None (all)
        include_html: Include raw_html column

    Returns:
        Tuple of (query_string, params_list)
    """
    fields = (
        "p.url, p.final_url, p.title, p.description, p.main_text, p.fetched_at, "
        "p.status_code, p.fetch_method, p.extraction_method, p.canonical_url, "
        "p.og_title, p.og_description, p.og_image, p.language, p.content_type, p.error"
    )
    if include_html:
        fields += ", p.raw_html"
    else:
        fields += ", NULL as raw_html"

    params: list = []

    if run_id:
        query = f"SELECT {fields} FROM pages p JOIN run_pages rp ON p.url = rp.url WHERE rp.run_id = ?"
        params.append(run_id)
    else:
        query = f"SELECT {fields} FROM pages p WHERE 1=1"

    if url_pattern:
        query += " AND p.url LIKE ?"
        params.append(f"%{url_pattern}%")

    if status_filter == "ok":
        query += " AND p.error IS NULL"
    elif status_filter == "error":
        query += " AND p.error IS NOT NULL"

    return query, params


async def _export_jsonl(
    db_path: str,
    output_path: str,
    run_id: str | None,
    url_pattern: str | None,
    status_filter: str | None,
    include_html: bool,
) -> int:
    """Export pages and documents to a JSONL file (internal implementation).

    Args:
        db_path: Path to SQLite database file
        output_path: Path to write JSONL output file
        run_id: Optional run ID to filter pages (only pages from this run)
        url_pattern: Optional URL pattern filter (SQL LIKE with %pattern%)
        status_filter: 'ok' (no error), 'error' (has error), or None (all)
        include_html: If True, include raw_html field in page records

    Returns:
        Total number of records written
    """
    logger = get_logger()
    count = 0

    async with aiosqlite.connect(db_path) as db:
        db.row_factory = aiosqlite.Row

        page_query, params = _build_page_query(run_id, url_pattern, status_filter, include_html)

        # Pre-load all images into a dict for efficient per-page lookup
        images_by_page: dict[str, list[dict]] = {}
        async with db.execute("SELECT page_url, src_abs, alt, local_path FROM images") as img_cursor:
            async for img_row in img_cursor:
                page_url = img_row["page_url"]
                if page_url not in images_by_page:
                    images_by_page[page_url] = []
                images_by_page[page_url].append({
                    "src": img_row["src_abs"],
                    "alt": img_row["alt"],
                    "local_path": img_row["local_path"],
                })

        async with aiofiles.open(output_path, "w", encoding="utf-8") as f:
            # Write pages with timing
            t0 = time.perf_counter()
            async with db.execute(page_query, params) as cursor:
                async for row in cursor:
                    record = {
                        "type": "page",
                        "url": row["url"],
                        "final_url": row["final_url"],
                        "title": row["title"],
                        "description": row["description"],
                        "text": row["main_text"],
                        "fetched_at": row["fetched_at"],
                        "status_code": row["status_code"],
                        "fetch_method": row["fetch_method"],
                        "extraction_method": row["extraction_method"],
                        "canonical_url": row["canonical_url"],
                        "og_title": row["og_title"],
                        "og_description": row["og_description"],
                        "og_image": row["og_image"],
                        "language": row["language"],
                        "content_type": row["content_type"],
                        "error": row["error"],
                        "images": images_by_page.get(row["url"], []),
                    }
                    if include_html:
                        record["raw_html"] = row["raw_html"]
                    await f.write(json.dumps(record, ensure_ascii=False) + "\n")
                    count += 1
            t1 = time.perf_counter()
            logger.debug("jsonl_pages_query_time", elapsed_ms=round((t1 - t0) * 1000, 2))

            # Build documents query (not filtered by run_id — documents have no run association)
            doc_conditions = []
            doc_params: list = []
            if url_pattern:
                doc_conditions.append("url LIKE ?")
                doc_params.append(f"%{url_pattern}%")
            if status_filter == "error":
                doc_conditions.append("error IS NOT NULL")
            elif status_filter == "ok":
                doc_conditions.append("error IS NULL")

            doc_where = f" WHERE {' AND '.join(doc_conditions)}" if doc_conditions else ""
            doc_query = f"SELECT url, fetched_at, content_type, page_count, has_ocr, extracted_text, file_size_bytes, error, status FROM documents{doc_where}"

            # Write documents
            async with db.execute(doc_query, doc_params) as cursor:
                async for row in cursor:
                    record = {
                        "type": "document",
                        "url": row["url"],
                        "fetched_at": row["fetched_at"],
                        "content_type": row["content_type"],
                        "page_count": row["page_count"],
                        "has_ocr": bool(row["has_ocr"]),
                        "text": row["extracted_text"],
                        "file_size_bytes": row["file_size_bytes"],
                        "error": row["error"],
                        "status": row["status"],
                    }
                    await f.write(json.dumps(record, ensure_ascii=False) + "\n")
                    count += 1

    logger.info(
        "jsonl_exported",
        output_path=output_path,
        count=count,
        run_id=run_id,
        url_pattern=url_pattern,
        include_html=include_html,
        status_filter=status_filter,
    )
    return count


async def export_to_jsonl(
    db_path: str,
    output_path: str,
    run_id: str | None = None,
    url_pattern: str | None = None,
    include_html: bool = False,
) -> int:
    """Export pages and documents to a JSONL file.

    Backward-compatible public wrapper around _export_jsonl().
    Called directly by async_crawl() for --export-jsonl inline flag.

    Args:
        db_path: Path to SQLite database file
        output_path: Path to write JSONL output file
        run_id: Optional run ID to filter pages (only pages from this run)
        url_pattern: Optional URL pattern filter (SQL LIKE with %pattern%)
        include_html: If True, include raw_html field in page records

    Returns:
        Total number of records written
    """
    # Ensure schema is up to date (handles old databases without raw_html column)
    await init_database(db_path)
    return await _export_jsonl(db_path, output_path, run_id, url_pattern, None, include_html)


async def _export_csv(
    db_path: str,
    output_path: str,
    run_id: str | None,
    url_pattern: str | None,
    status_filter: str | None,
) -> int:
    """Export pages to a CSV file.

    Columns: url, title, word_count, status_code, fetched_at, language, error

    Args:
        db_path: Path to SQLite database file
        output_path: Path to write CSV output file
        run_id: Optional run ID to filter pages
        url_pattern: Optional URL pattern filter (SQL LIKE)
        status_filter: 'ok' (no error), 'error' (has error), or None (all)

    Returns:
        Number of rows written (excluding header)
    """
    logger = get_logger()
    count = 0

    async with aiosqlite.connect(db_path) as db:
        db.row_factory = aiosqlite.Row

        page_query, params = _build_page_query(run_id, url_pattern, status_filter, include_html=False)

        t0 = time.perf_counter()
        async with db.execute(page_query, params) as cursor:
            t1 = time.perf_counter()
            logger.debug("csv_pages_query_time", elapsed_ms=round((t1 - t0) * 1000, 2))

            # Use StringIO buffer — csv.writer cannot accept aiofiles file objects directly
            buf = io.StringIO()
            writer = csv.writer(buf)
            writer.writerow(["url", "title", "word_count", "status_code", "fetched_at", "language", "error"])

            async with aiofiles.open(output_path, "w", encoding="utf-8", newline="") as f:
                await f.write(buf.getvalue())
                buf.seek(0)
                buf.truncate(0)

                async for row in cursor:
                    word_count = len(row["main_text"].split()) if row["main_text"] else 0
                    writer.writerow([
                        row["url"],
                        row["title"],
                        word_count,
                        row["status_code"],
                        row["fetched_at"],
                        row["language"],
                        row["error"],
                    ])
                    await f.write(buf.getvalue())
                    buf.seek(0)
                    buf.truncate(0)
                    count += 1

    logger.info(
        "csv_exported",
        output_path=output_path,
        count=count,
        run_id=run_id,
        url_pattern=url_pattern,
        status_filter=status_filter,
    )
    return count


def _url_to_md_filename(url: str) -> str:
    """Convert a URL to a safe Markdown filename.

    Args:
        url: The page URL to convert

    Returns:
        A safe filename string ending in .md (max 200 chars + .md suffix)
    """
    parsed = urlparse(url)
    path = parsed.netloc + parsed.path + parsed.query
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", path)
    safe = re.sub(r"_+", "_", safe).strip("_")[:200]
    return (safe or "page") + ".md"


def _build_frontmatter(row) -> str:
    """Build YAML frontmatter for a page row.

    Builds manually without pyyaml dependency.
    Quotes values containing colons, quotes, or special YAML characters.

    Args:
        row: Database row (aiosqlite.Row) with page fields

    Returns:
        YAML frontmatter string including --- delimiters
    """
    def _yaml_val(val: str) -> str:
        """Quote a string value if it contains special YAML characters."""
        if val is None:
            return "null"
        s = str(val)
        # Quote if contains colon followed by space, leading/trailing space,
        # hash, quote chars, or special YAML block indicators
        if (": " in s or s.startswith(("#", "'", '"', "{", "[", "|", ">", "!"))
                or s != s.strip() or '"' in s or "'" in s):
            escaped = s.replace("\\", "\\\\").replace('"', '\\"')
            return f'"{escaped}"'
        return s

    lines = ["---"]
    lines.append(f"url: {_yaml_val(row['url'])}")

    title = row["title"]
    if title is not None:
        lines.append(f"title: {_yaml_val(title)}")

    lines.append(f"fetched_at: {_yaml_val(row['fetched_at'])}")
    lines.append(f"status_code: {row['status_code']}")

    # Conditional fields — only include if non-None
    for field, key in [
        ("language", "language"),
        ("description", "description"),
        ("canonical_url", "canonical_url"),
        ("og_title", "og_title"),
        ("og_image", "og_image"),
    ]:
        val = row[field]
        if val is not None:
            lines.append(f"{key}: {_yaml_val(val)}")

    lines.append("---")
    return "\n".join(lines)


async def _export_markdown(
    db_path: str,
    output_path: str,
    run_id: str | None,
    url_pattern: str | None,
    status_filter: str | None,
) -> int:
    """Export pages as Markdown files in a flat directory.

    Creates one .md file per page with YAML frontmatter + body text.
    Handles filename collisions with counter suffix.

    Args:
        db_path: Path to SQLite database file
        output_path: Directory path to write Markdown files into
        run_id: Optional run ID to filter pages
        url_pattern: Optional URL pattern filter (SQL LIKE)
        status_filter: 'ok' (no error), 'error' (has error), or None (all)

    Returns:
        Number of Markdown files written
    """
    logger = get_logger()
    count = 0

    # Create output directory (async)
    await aiofiles.os.makedirs(output_path, exist_ok=True)

    async with aiosqlite.connect(db_path) as db:
        db.row_factory = aiosqlite.Row

        page_query, params = _build_page_query(run_id, url_pattern, status_filter, include_html=False)

        used_filenames: set[str] = set()

        t0 = time.perf_counter()
        async with db.execute(page_query, params) as cursor:
            t1 = time.perf_counter()
            logger.debug("markdown_pages_query_time", elapsed_ms=round((t1 - t0) * 1000, 2))

            async for row in cursor:
                # Resolve filename collision
                base_name = _url_to_md_filename(row["url"])
                if base_name not in used_filenames:
                    filename = base_name
                else:
                    stem = base_name[:-3]  # strip .md
                    counter = 2
                    while True:
                        candidate = f"{stem}_{counter}.md"
                        if candidate not in used_filenames:
                            filename = candidate
                            break
                        counter += 1

                used_filenames.add(filename)

                frontmatter = _build_frontmatter(row)
                body = row["main_text"] or ""
                content = frontmatter + "\n\n" + body

                file_path = os.path.join(output_path, filename)
                async with aiofiles.open(file_path, "w", encoding="utf-8") as f:
                    await f.write(content)

                count += 1

    logger.info(
        "markdown_exported",
        output_path=output_path,
        count=count,
        run_id=run_id,
        url_pattern=url_pattern,
        status_filter=status_filter,
    )
    return count


async def export_to_file(
    db_path: str,
    output_path: str,
    format: str = "jsonl",
    run_id: str | None = None,
    url_pattern: str | None = None,
    status_filter: str | None = None,
    include_html: bool = False,
) -> int:
    """Export crawl data to a file in the specified format.

    Dispatcher that routes to the appropriate format-specific helper.

    Args:
        db_path: Path to SQLite database file
        output_path: Output file path (or directory for markdown format)
        format: Export format: 'jsonl', 'csv', or 'markdown'
        run_id: Optional run ID to filter pages
        url_pattern: Optional URL pattern filter (SQL LIKE)
        status_filter: 'ok' (no error), 'error' (has error), or None (all)
        include_html: Include raw HTML in JSONL export (ignored for CSV/Markdown)

    Returns:
        Number of records/files written

    Raises:
        ValueError: If format is not one of 'jsonl', 'csv', 'markdown'
    """
    # Ensure schema is up to date
    await init_database(db_path)

    if format == "jsonl":
        return await _export_jsonl(db_path, output_path, run_id, url_pattern, status_filter, include_html)
    elif format == "csv":
        return await _export_csv(db_path, output_path, run_id, url_pattern, status_filter)
    elif format == "markdown":
        return await _export_markdown(db_path, output_path, run_id, url_pattern, status_filter)
    else:
        raise ValueError(f"Unknown export format: {format!r}. Supported formats: jsonl, csv, markdown")


def _human_size(n: int | float) -> str:
    """Format byte count as human-readable string."""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _parse_duration(s: str) -> timedelta:
    """Parse duration string (7d, 2w, 24h, 30m) to timedelta."""
    import re as _re
    match = _re.fullmatch(r"(\d+)(d|w|h|m)", s.strip().lower())
    if not match:
        raise ValueError(f"Invalid duration: {s!r}. Use format: 7d, 2w, 24h, 30m")
    val, unit = int(match.group(1)), match.group(2)
    return {"d": timedelta(days=val), "w": timedelta(weeks=val),
            "h": timedelta(hours=val), "m": timedelta(minutes=val)}[unit]


async def get_storage_summary(db_path: str) -> dict:
    """Get storage statistics for the status command.

    Returns dict with keys: db_size, db_size_human, pages, pages_with_html,
    runs, links, images, documents.
    """
    db_size = os.path.getsize(db_path)
    async with aiosqlite.connect(db_path) as db:
        counts = {}
        for table in ("pages", "runs", "links", "images", "documents"):
            row = await (await db.execute(f"SELECT COUNT(*) FROM {table}")).fetchone()
            counts[table] = row[0]
        html_count = (await (await db.execute(
            "SELECT COUNT(*) FROM pages WHERE raw_html IS NOT NULL"
        )).fetchone())[0]
    return {
        "db_size": db_size,
        "db_size_human": _human_size(db_size),
        "pages": counts["pages"],
        "pages_with_html": html_count,
        "runs": counts["runs"],
        "links": counts["links"],
        "images": counts["images"],
        "documents": counts["documents"],
    }


async def get_purge_preview(
    db_path: str,
    run_id: str | None = None,
    older_than: str | None = None,
) -> list[dict]:
    """Preview what a purge operation would delete.

    Args:
        db_path: Path to SQLite database file
        run_id: Specific run ID to purge
        older_than: Duration string (7d, 2w, 24h) - purge runs older than this

    Returns:
        List of dicts, each with: run_id, started_at, status, page_count,
        link_count, image_count, orphan_image_count, estimated_size_human.
    """
    logger = get_logger()
    results = []

    async with aiosqlite.connect(db_path) as db:
        db.row_factory = aiosqlite.Row

        # Find runs to purge
        if run_id:
            runs = await (await db.execute(
                "SELECT run_id, started_at, status FROM runs WHERE run_id = ?",
                (run_id,)
            )).fetchall()
        elif older_than:
            duration = _parse_duration(older_than)
            # Match the format used by existing code (utcnow().isoformat())
            cutoff = (datetime.now(timezone.utc).replace(tzinfo=None) - duration).isoformat()
            runs = await (await db.execute(
                "SELECT run_id, started_at, status FROM runs WHERE started_at < ?",
                (cutoff,)
            )).fetchall()
        else:
            return []

        # Get total page count for size estimation
        total_pages = (await (await db.execute("SELECT COUNT(*) FROM pages")).fetchone())[0]
        db_size = os.path.getsize(db_path)

        for run_row in runs:
            rid = run_row["run_id"]
            run_status = run_row["status"]

            # Count pages in this run
            page_count = (await (await db.execute(
                "SELECT COUNT(*) FROM run_pages WHERE run_id = ?", (rid,)
            )).fetchone())[0]

            # Get page URLs for this run (needed for link/image counts)
            page_urls = [r[0] for r in await (await db.execute(
                "SELECT url FROM run_pages WHERE run_id = ?", (rid,)
            )).fetchall()]

            link_count = 0
            image_count = 0
            orphan_image_count = 0

            if page_urls:
                placeholders = ",".join("?" for _ in page_urls)

                link_count = (await (await db.execute(
                    f"SELECT COUNT(*) FROM links WHERE page_url IN ({placeholders})",
                    page_urls
                )).fetchone())[0]

                image_count = (await (await db.execute(
                    f"SELECT COUNT(*) FROM images WHERE page_url IN ({placeholders})",
                    page_urls
                )).fetchone())[0]

                # Count orphan images (sha256 not referenced by any page OUTSIDE this run)
                images_in_run = await (await db.execute(
                    f"SELECT sha256, local_path FROM images WHERE page_url IN ({placeholders}) AND sha256 IS NOT NULL AND local_path IS NOT NULL",
                    page_urls
                )).fetchall()

                for img_sha, img_path in images_in_run:
                    other_refs = (await (await db.execute(
                        f"SELECT COUNT(*) FROM images WHERE sha256 = ? AND page_url NOT IN ({placeholders})",
                        (img_sha, *page_urls)
                    )).fetchone())[0]
                    if other_refs == 0:
                        orphan_image_count += 1

            # Proportional size estimate
            estimated_size = int(db_size * page_count / total_pages) if total_pages > 0 else 0

            results.append({
                "run_id": rid,
                "started_at": run_row["started_at"],
                "status": run_status,
                "page_count": page_count,
                "link_count": link_count,
                "image_count": image_count,
                "orphan_image_count": orphan_image_count,
                "estimated_size_human": _human_size(estimated_size),
            })

    return results


async def execute_purge(db_path: str, run_ids: list[str]) -> dict:
    """Execute purge for the given run IDs.

    Deletes: run record, run_pages entries, associated pages (if not in other runs),
    links, images (DB rows), and orphaned image files from filesystem.

    Args:
        db_path: Path to SQLite database file
        run_ids: List of run IDs to purge

    Returns:
        Dict with counts: pages_deleted, links_deleted, images_deleted, files_deleted
    """
    logger = get_logger()
    pages_deleted = 0
    links_deleted = 0
    images_deleted = 0
    files_deleted = 0

    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA foreign_keys=ON")

        for rid in run_ids:
            # Get page URLs for this run
            page_urls = [r[0] for r in await (await db.execute(
                "SELECT url FROM run_pages WHERE run_id = ?", (rid,)
            )).fetchall()]

            if page_urls:
                placeholders = ",".join("?" for _ in page_urls)

                # Find orphan image files to delete from filesystem
                images_in_run = await (await db.execute(
                    f"SELECT sha256, local_path FROM images WHERE page_url IN ({placeholders}) AND sha256 IS NOT NULL AND local_path IS NOT NULL",
                    page_urls
                )).fetchall()

                orphan_files = []
                for img_sha, img_path in images_in_run:
                    other_refs = (await (await db.execute(
                        f"SELECT COUNT(*) FROM images WHERE sha256 = ? AND page_url NOT IN ({placeholders})",
                        (img_sha, *page_urls)
                    )).fetchone())[0]
                    if other_refs == 0 and img_path:
                        orphan_files.append(img_path)

                # Count what will be deleted
                link_ct = (await (await db.execute(
                    f"SELECT COUNT(*) FROM links WHERE page_url IN ({placeholders})",
                    page_urls
                )).fetchone())[0]
                img_ct = (await (await db.execute(
                    f"SELECT COUNT(*) FROM images WHERE page_url IN ({placeholders})",
                    page_urls
                )).fetchone())[0]

                # Delete DB records: images, links, then pages
                await db.execute(
                    f"DELETE FROM images WHERE page_url IN ({placeholders})", page_urls
                )
                await db.execute(
                    f"DELETE FROM links WHERE page_url IN ({placeholders})", page_urls
                )

                # Only delete pages not referenced by OTHER runs
                for page_url in page_urls:
                    other_run_refs = (await (await db.execute(
                        "SELECT COUNT(*) FROM run_pages WHERE url = ? AND run_id != ?",
                        (page_url, rid)
                    )).fetchone())[0]
                    if other_run_refs == 0:
                        await db.execute("DELETE FROM pages WHERE url = ?", (page_url,))
                        pages_deleted += 1

                links_deleted += link_ct
                images_deleted += img_ct

                # Delete filesystem orphan image files
                for fpath in orphan_files:
                    try:
                        if os.path.exists(fpath):
                            os.remove(fpath)
                            files_deleted += 1
                    except OSError as e:
                        logger.warning("purge_file_delete_failed", path=fpath, error=str(e))

            # Delete run_pages and run record
            await db.execute("DELETE FROM run_pages WHERE run_id = ?", (rid,))
            await db.execute("DELETE FROM runs WHERE run_id = ?", (rid,))

        await db.commit()

    logger.info(
        "purge_complete",
        run_ids=run_ids,
        pages_deleted=pages_deleted,
        links_deleted=links_deleted,
        images_deleted=images_deleted,
        files_deleted=files_deleted,
    )

    return {
        "pages_deleted": pages_deleted,
        "links_deleted": links_deleted,
        "images_deleted": images_deleted,
        "files_deleted": files_deleted,
    }


class Database:
    """Async context manager for reusable database connections.

    Example:
        async with Database("crawlvox.db") as db:
            cursor = await db.execute("SELECT * FROM pages")
            rows = await cursor.fetchall()
    """

    def __init__(self, db_path: str) -> None:
        """Initialize database connection manager.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path
        self._connection: aiosqlite.Connection | None = None

    async def __aenter__(self) -> aiosqlite.Connection:
        """Open connection with WAL mode enabled."""
        self._connection = await aiosqlite.connect(self.db_path)
        await self._connection.execute("PRAGMA journal_mode=WAL")
        await self._connection.execute("PRAGMA synchronous=NORMAL")
        return self._connection

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Close database connection."""
        if self._connection:
            await self._connection.close()
