"""HTTP fetching with httpx async client, retry logic, and rate limiting."""

import asyncio
import random
from dataclasses import dataclass
from http.cookiejar import LWPCookieJar
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
import structlog
from aiolimiter import AsyncLimiter
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_random_exponential,
)

logger = structlog.get_logger(__name__)


@dataclass
class FetchResult:
    """Result from fetching a URL."""

    url: str
    final_url: str | None = None
    status_code: int | None = None
    html: str | None = None
    content_type: str | None = None
    error: str | None = None
    success: bool = False


class Fetcher:
    """HTTP fetcher with connection pooling, retry logic, and rate limiting."""

    def __init__(
        self,
        user_agent: str,
        timeout: float = 30.0,
        max_retries: int = 3,
        rate_limit: float = 2.0,
        max_connections: int = 100,
        cookie_file: str | None = None,
    ):
        """Initialize fetcher.

        Args:
            user_agent: User-Agent header value
            timeout: Read timeout in seconds
            max_retries: Maximum retry attempts for transient errors
            rate_limit: Maximum requests per second per domain
            max_connections: Maximum concurrent connections
            cookie_file: Path to cookie file for session persistence (None = disabled)
        """
        self.user_agent = user_agent
        self.timeout = timeout
        self.max_retries = max_retries
        self.rate_limit = rate_limit
        self.max_connections = max_connections
        self.cookie_file = cookie_file
        self.client: httpx.AsyncClient | None = None
        self.cookiejar: LWPCookieJar | None = None
        self._rate_limiters: dict[str, AsyncLimiter] = {}

    async def __aenter__(self) -> "Fetcher":
        """Create shared httpx AsyncClient with connection pooling."""
        # Initialize cookie jar if cookie_file provided
        if self.cookie_file:
            self.cookiejar = LWPCookieJar(filename=self.cookie_file)
            try:
                # Load existing cookies (ignore_discard keeps session cookies, ignore_expires keeps expired)
                self.cookiejar.load(ignore_discard=True, ignore_expires=True)
                cookie_count = len(self.cookiejar)
                logger.info("cookies_loaded", cookie_file=self.cookie_file, count=cookie_count)
            except FileNotFoundError:
                # First run, no cookies yet - this is normal
                logger.debug("cookie_file_not_found", cookie_file=self.cookie_file, reason="first_run")
            except Exception as e:
                # Log warning but continue without cookies
                logger.warning("cookie_load_failed", cookie_file=self.cookie_file, error=str(e))
                self.cookiejar = None
        else:
            logger.debug("cookies_disabled", reason="no_cookie_file")

        self.client = httpx.AsyncClient(
            headers={"User-Agent": self.user_agent},
            limits=httpx.Limits(
                max_keepalive_connections=100,
                max_connections=self.max_connections,
                keepalive_expiry=30.0,
            ),
            timeout=httpx.Timeout(self.timeout, connect=60.0),
            follow_redirects=True,
            cookies=self.cookiejar,
        )
        logger.info(
            "httpx_client_created",
            max_connections=self.max_connections,
            timeout=self.timeout,
        )
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Close httpx client and cleanup resources."""
        # Save cookies before closing client
        if self.cookiejar and self.cookie_file:
            try:
                # Ensure parent directory exists
                Path(self.cookie_file).parent.mkdir(parents=True, exist_ok=True)
                # Save cookies (ignore_discard keeps session cookies, ignore_expires keeps expired)
                self.cookiejar.save(ignore_discard=True, ignore_expires=True)
                cookie_count = len(self.cookiejar)
                logger.info("cookies_saved", cookie_file=self.cookie_file, count=cookie_count)
            except Exception as e:
                # Log error but don't raise - cookie save failure should not crash crawler
                logger.error("cookie_save_failed", cookie_file=self.cookie_file, error=str(e))

        if self.client:
            await self.client.aclose()
            logger.info("httpx_client_closed")

    def _get_limiter(self, url: str) -> AsyncLimiter:
        """Get or create rate limiter for URL's domain.

        Args:
            url: URL to extract domain from

        Returns:
            AsyncLimiter instance for the domain
        """
        domain = urlparse(url).netloc
        if domain not in self._rate_limiters:
            self._rate_limiters[domain] = AsyncLimiter(
                max_rate=self.rate_limit,
                time_period=1.0,
            )
            logger.debug("rate_limiter_created", domain=domain, rate=self.rate_limit)
        return self._rate_limiters[domain]

    async def _fetch_with_retry(self, url: str) -> httpx.Response:
        """Fetch URL with retry on transient errors.

        Args:
            url: URL to fetch

        Returns:
            httpx Response object

        Raises:
            httpx.HTTPStatusError: On HTTP error status
            httpx.TimeoutException: On timeout after all retries
            httpx.ConnectError: On connection error after all retries
        """
        if not self.client:
            raise RuntimeError("Fetcher must be used as async context manager")

        @retry(
            stop=stop_after_attempt(self.max_retries),
            wait=wait_random_exponential(multiplier=1, max=60),
            retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError, httpx.HTTPStatusError)),
            reraise=True,
        )
        async def _retry_get() -> httpx.Response:
            """Inner function with retry decorator."""
            response = await self.client.get(url)
            # Trigger retry on 429, 503, and other server errors (5xx)
            if response.status_code in (429, 503) or response.status_code >= 500:
                # Check for Retry-After header on 429
                if response.status_code == 429:
                    retry_after = response.headers.get("Retry-After")
                    if retry_after:
                        try:
                            wait_seconds = float(retry_after)
                            logger.info("retry_after_header", url=url, wait_seconds=wait_seconds)
                            await asyncio.sleep(wait_seconds)
                        except ValueError:
                            pass  # Non-numeric Retry-After (date format), fall through to exponential backoff
                logger.warning("retriable_status", url=url, status_code=response.status_code)
                response.raise_for_status()
            return response

        return await _retry_get()

    async def detect_content_type(self, url: str) -> str:
        """Detect content type via HEAD request.

        Args:
            url: URL to check

        Returns:
            Content type string (e.g., 'text/html', 'application/pdf')
        """
        if not self.client:
            raise RuntimeError("Fetcher must be used as async context manager")

        try:
            response = await self.client.head(url, follow_redirects=True)
            content_type = response.headers.get("Content-Type", "text/html")
            # Parse content type (strip charset and whitespace)
            parsed_type = content_type.split(";")[0].strip().lower()
            logger.debug("content_type_detected", url=url, content_type=parsed_type)
            return parsed_type
        except Exception as e:
            # Fall back to text/html if HEAD fails (some servers don't support it)
            logger.warning(
                "content_type_detection_failed",
                url=url,
                error=str(e),
                fallback="text/html",
            )
            return "text/html"

    async def fetch(self, url: str) -> FetchResult:
        """Fetch URL with rate limiting, retry, and error handling.

        Args:
            url: URL to fetch

        Returns:
            FetchResult with response data or error information
        """
        if not self.client:
            raise RuntimeError("Fetcher must be used as async context manager")

        # Apply per-domain rate limiting
        limiter = self._get_limiter(url)

        # Add jitter: random 0-250ms delay to prevent synchronized bursts
        jitter = random.uniform(0.0, 0.25)
        await asyncio.sleep(jitter)

        async with limiter:
            logger.info("fetch_start", url=url)

            try:
                import time

                start_time = time.time()
                response = await self._fetch_with_retry(url)
                elapsed = time.time() - start_time

                # Extract content type from response headers
                content_type_header = response.headers.get("Content-Type", "text/html")
                content_type = content_type_header.split(";")[0].strip().lower()

                logger.info(
                    "fetch_complete",
                    url=url,
                    status_code=response.status_code,
                    content_type=content_type,
                    elapsed=f"{elapsed:.2f}s",
                )

                return FetchResult(
                    url=url,
                    final_url=str(response.url),
                    status_code=response.status_code,
                    html=response.text,
                    content_type=content_type,
                    success=True,
                )

            except httpx.HTTPStatusError as e:
                logger.warning(
                    "fetch_http_error",
                    url=url,
                    status_code=e.response.status_code,
                    error=str(e),
                )
                return FetchResult(
                    url=url,
                    status_code=e.response.status_code,
                    error=str(e),
                    success=False,
                )

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                logger.error("fetch_connection_error", url=url, error=str(e))
                return FetchResult(
                    url=url,
                    error=str(e),
                    success=False,
                )
