"""
Robots.txt handler with per-domain caching and permission checking.

Fetches, caches, and interprets robots.txt using protego. All operations are
fail-open: network errors or missing robots.txt allow all URLs.
"""

import httpx
import protego
import structlog
from urllib.parse import urlparse

logger = structlog.get_logger()


class RobotsCache:
    """Per-domain robots.txt cache with permission checking.

    Fetches robots.txt once per domain, caches parsed results, and provides
    can_fetch, crawl_delay, and sitemap URL access.

    All operations fail-open: errors allow crawling to continue.
    """

    def __init__(self, user_agent: str):
        """Initialize robots cache.

        Args:
            user_agent: User-agent string for permission checks
        """
        self.user_agent = user_agent
        self._cache: dict[str, protego.Protego] = {}

    async def can_fetch(self, url: str, http_client: httpx.AsyncClient) -> bool:
        """Check if URL can be fetched per robots.txt.

        Fetches and caches robots.txt on first access per domain. Returns True
        if URL is allowed, False if disallowed. Fails open on errors.

        Args:
            url: URL to check permission for
            http_client: httpx client for fetching robots.txt

        Returns:
            True if allowed to fetch, False if disallowed
        """
        parsed = urlparse(url)
        domain = f"{parsed.scheme}://{parsed.netloc}"

        # Fetch and cache robots.txt if not cached
        if domain not in self._cache:
            robots_url = f"{domain}/robots.txt"
            try:
                response = await http_client.get(robots_url, timeout=10.0)
                if response.status_code == 200:
                    # Parse and cache robots.txt
                    self._cache[domain] = protego.Protego.parse(response.text)
                    logger.info(
                        "robots.txt cached",
                        domain=domain,
                        user_agent=self.user_agent,
                    )
                else:
                    # Non-200 status: allow all (fail open)
                    self._cache[domain] = protego.Protego.parse("")
                    logger.info(
                        "robots.txt not found, allowing all",
                        domain=domain,
                        status_code=response.status_code,
                    )
            except Exception as e:
                # Network error: allow all (fail open)
                self._cache[domain] = protego.Protego.parse("")
                logger.warning(
                    "robots.txt fetch failed, allowing all",
                    domain=domain,
                    error=str(e),
                )

        # Check permission with cached robots.txt
        return self._cache[domain].can_fetch(url, self.user_agent)

    def get_crawl_delay(self, url: str) -> float | None:
        """Get crawl delay for URL's domain from cached robots.txt.

        Args:
            url: URL to get crawl delay for

        Returns:
            Crawl delay in seconds, or None if not cached or not specified
        """
        parsed = urlparse(url)
        domain = f"{parsed.scheme}://{parsed.netloc}"

        if domain in self._cache:
            return self._cache[domain].crawl_delay(self.user_agent)

        return None

    def get_sitemaps(self, url: str) -> list[str]:
        """Get sitemap URLs from cached robots.txt.

        Args:
            url: URL to get sitemaps for

        Returns:
            List of sitemap URLs, or empty list if not cached
        """
        parsed = urlparse(url)
        domain = f"{parsed.scheme}://{parsed.netloc}"

        if domain in self._cache:
            return list(self._cache[domain].sitemaps)

        return []
