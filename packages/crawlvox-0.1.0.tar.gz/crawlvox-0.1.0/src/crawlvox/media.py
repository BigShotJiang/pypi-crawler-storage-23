"""Image downloading, deduplication, and file storage for Phase 7."""

import asyncio
import hashlib
import mimetypes
import re
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import aiofiles
import aiosqlite
import httpx
import structlog

from crawlvox.storage import get_existing_image_hashes, update_image_download


# Allowed image content types — JPEG, PNG, GIF, WebP, SVG only
ALLOWED_CONTENT_TYPES = {
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "image/svg+xml",
}

# Override dict for deterministic extension mapping (avoids OS-dependent mimetypes results)
CONTENT_TYPE_EXT_MAP = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
    "image/webp": ".webp",
    "image/svg+xml": ".svg",
}

# Minimum image size in bytes — filters tracking pixels, spacer GIFs, tiny icons
MIN_IMAGE_SIZE = 1024  # 1KB minimum


class ImageDownloader:
    """Downloads images with streaming SHA256 hashing and two-tier deduplication.

    Deduplication strategy:
    - Tier 1: URL check (in-memory dict) — skip if same URL already processed this run
    - Tier 2: Content hash check (in-memory dict) — same content at different URL shares one file
    - Cross-run: Pre-loads existing hashes from DB at startup to avoid re-downloading

    Usage:
        async with ImageDownloader(client, image_dir, ...) as downloader:
            await downloader.load_existing_hashes()
            result = await downloader.download_image(src_url, page_url)
    """

    def __init__(
        self,
        client: httpx.AsyncClient,
        image_dir: str,
        max_image_size: int,
        image_scope: str,
        db_path: str,
        concurrency: int = 5,
    ) -> None:
        """Initialize ImageDownloader.

        Args:
            client: Shared httpx.AsyncClient from Fetcher (not owned by this class)
            image_dir: Base directory for storing downloaded images
            max_image_size: Maximum allowed image size in bytes
            image_scope: "same-domain" or "all" — controls which images to download
            db_path: Path to SQLite database for updating image records
            concurrency: Maximum concurrent downloads (default 5)

        Note:
            asyncio.Semaphore is NOT created here — it is created in __aenter__ to
            avoid "no running event loop" errors (Python 3.10+ requirement).
        """
        self._client = client
        self._image_dir = Path(image_dir).resolve()
        self._max_image_size = max_image_size
        self._image_scope = image_scope
        self._db_path = db_path
        self._concurrency = concurrency

        # DO NOT create asyncio.Semaphore here — event loop may not be running yet
        self._semaphore: asyncio.Semaphore | None = None

        # Tier 1 dedup: URL -> (local_path, sha256) or None (skipped)
        # Storing sha256 alongside local_path ensures DB updates have the correct hash
        self._url_seen: dict[str, tuple[str, str] | None] = {}

        # Tier 2 dedup: sha256 hex -> local_path (str)
        self._hash_seen: dict[str, str] = {}

        self.logger = structlog.get_logger()

    async def __aenter__(self) -> "ImageDownloader":
        """Create semaphore inside running event loop and return self."""
        self._semaphore = asyncio.Semaphore(self._concurrency)
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """No cleanup needed — client lifecycle is owned by Fetcher."""
        pass

    async def load_existing_hashes(self) -> None:
        """Pre-populate dedup caches from previous crawl runs.

        Loads SHA256 -> local_path from DB into _hash_seen, and
        src_abs -> local_path from DB into _url_seen, for cross-run dedup.
        Validates file existence before adding to cache (handles deleted files).
        """
        # Load hash -> local_path from storage function
        existing_hashes = await get_existing_image_hashes(self._db_path)
        valid_count = 0
        missing_count = 0

        for sha256, local_path in existing_hashes.items():
            if Path(local_path).exists():
                self._hash_seen[sha256] = local_path
                valid_count += 1
            else:
                self.logger.debug(
                    "existing_image_file_missing",
                    sha256=sha256[:16],
                    local_path=local_path,
                )
                missing_count += 1

        # Also populate _url_seen from DB to skip already-downloaded URLs
        async with aiosqlite.connect(self._db_path) as db:
            async with db.execute(
                "SELECT src_abs, local_path, sha256 FROM images WHERE local_path IS NOT NULL"
            ) as cursor:
                async for row in cursor:
                    src_abs, local_path, sha256_val = row
                    if src_abs and local_path and Path(local_path).exists():
                        self._url_seen[src_abs] = (local_path, sha256_val or "")

        self.logger.info(
            "existing_hashes_loaded",
            hash_count=valid_count,
            missing_files=missing_count,
            url_count=len(self._url_seen),
        )

    def _is_in_scope(self, image_url: str, page_url: str) -> bool:
        """Check if image URL is within the configured download scope.

        Args:
            image_url: URL of the image to potentially download
            page_url: URL of the page containing the image

        Returns:
            True if image should be downloaded per current scope setting
        """
        if self._image_scope == "all":
            return True
        # "same-domain": only download images from the same domain as the page
        image_domain = urlparse(image_url).netloc
        page_domain = urlparse(page_url).netloc
        return image_domain == page_domain

    def _build_filename(self, url: str, sha256: str, content_type: str) -> str:
        """Build a safe, unique filename from URL, SHA256 hash, and content type.

        Format: {sha256_prefix}_{sanitized_basename}{ext}
        Example: a1b2c3d4e5f6a1b2_hero-banner.jpg

        Args:
            url: Original image URL (for basename extraction)
            sha256: Full SHA256 hex digest of the image content
            content_type: Content-Type header value from the response

        Returns:
            Safe filename string suitable for use on Windows and Linux
        """
        # Extension: use override dict first (deterministic), then stdlib, then fallback
        ext = CONTENT_TYPE_EXT_MAP.get(
            content_type,
            mimetypes.guess_extension(content_type) or ".bin",
        )

        # Extract and sanitize URL basename
        basename = urlparse(url).path.split("/")[-1]
        # Keep only safe characters for cross-platform filenames
        safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", basename)
        # Remove extension from URL basename (we use content-type extension)
        safe_name = re.sub(r"\.[^.]+$", "", safe_name)
        # Truncate to 60 chars, default to "image" if empty
        safe_name = safe_name[:60] or "image"

        return f"{sha256[:16]}_{safe_name}{ext}"

    def _get_domain_dir(self, url: str) -> Path:
        """Get (and create) the per-domain subdirectory for image storage.

        Args:
            url: Image URL — domain is extracted from this

        Returns:
            Path to the domain subdirectory (guaranteed to exist)
        """
        domain = urlparse(url).netloc
        domain_dir = self._image_dir / domain
        domain_dir.mkdir(parents=True, exist_ok=True)
        return domain_dir

    async def _stream_download(self, url: str, dest_path: Path) -> tuple[str, str]:
        """Stream-download an image to dest_path while computing SHA256.

        One network pass produces both the file on disk and its SHA256 hash —
        no second read required.

        Args:
            url: URL to download
            dest_path: Destination file path (should be a temp path)

        Returns:
            Tuple of (sha256_hex, content_type)

        Raises:
            ValueError: If content type is unsupported, or size limits violated
            httpx.HTTPError: On HTTP-level errors
        """
        async with self._client.stream("GET", url, follow_redirects=True) as response:
            response.raise_for_status()

            # Validate content type before writing any bytes
            content_type = (
                response.headers.get("content-type", "")
                .split(";")[0]
                .strip()
                .lower()
            )
            if content_type not in ALLOWED_CONTENT_TYPES:
                raise ValueError(f"Unsupported content type: {content_type}")

            # Content-Length hint check (may be absent or incorrect — still enforce during stream)
            content_length_str = response.headers.get("content-length")
            if content_length_str:
                try:
                    content_length = int(content_length_str)
                    if content_length > self._max_image_size:
                        raise ValueError(
                            f"Image exceeds max size (Content-Length): {content_length} > {self._max_image_size}"
                        )
                except (ValueError, TypeError) as e:
                    if "exceeds max size" in str(e):
                        raise
                    # Non-integer Content-Length header — ignore and enforce during streaming

            hasher = hashlib.sha256()
            downloaded = 0

            async with aiofiles.open(dest_path, "wb") as f:
                async for chunk in response.aiter_bytes(chunk_size=65536):
                    downloaded += len(chunk)
                    if downloaded > self._max_image_size:
                        # Clean up partial file before raising
                        await f.close()
                        dest_path.unlink(missing_ok=True)
                        raise ValueError(
                            f"Image exceeds max size during streaming: {downloaded} > {self._max_image_size}"
                        )
                    hasher.update(chunk)
                    await f.write(chunk)

            # Enforce minimum size after full download
            if downloaded < MIN_IMAGE_SIZE:
                dest_path.unlink(missing_ok=True)
                raise ValueError(
                    f"Image below minimum size: {downloaded} < {MIN_IMAGE_SIZE}"
                )

        return (hasher.hexdigest(), content_type)

    async def download_image(
        self, src_url: str, page_url: str
    ) -> tuple[str, str] | None:
        """Download a single image with two-tier deduplication.

        Returns (local_path, sha256) if downloaded or deduped to existing file,
        or None if skipped (scope filter, unsupported type, size limit, error).

        Args:
            src_url: Absolute URL of the image to download
            page_url: URL of the page containing the image (for scope check)

        Returns:
            (local_path, sha256) tuple or None if image was skipped
        """
        # Tier 1: URL dedup — if already processed this URL, return cached result
        if src_url in self._url_seen:
            cached = self._url_seen[src_url]
            if cached is not None:
                return cached  # (local_path, sha256) tuple
            return None

        # Scope check — skip images outside download scope
        if not self._is_in_scope(src_url, page_url):
            self.logger.debug("image_out_of_scope", src_url=src_url, page_url=page_url)
            self._url_seen[src_url] = None
            return None

        # Acquire semaphore to limit concurrent downloads
        assert self._semaphore is not None, "ImageDownloader must be used as async context manager"
        async with self._semaphore:
            # Get (and create) the domain-specific subdirectory
            domain_dir = self._get_domain_dir(src_url)
            temp_path = domain_dir / f"_tmp_{uuid.uuid4().hex}"

            try:
                sha256, content_type = await self._stream_download(src_url, temp_path)
            except ValueError as e:
                self.logger.debug(
                    "image_download_skipped",
                    src_url=src_url,
                    reason=str(e),
                )
                self._url_seen[src_url] = None
                temp_path.unlink(missing_ok=True)
                return None
            except httpx.HTTPError as e:
                self.logger.warning(
                    "image_download_http_error",
                    src_url=src_url,
                    error=str(e),
                )
                self._url_seen[src_url] = None
                temp_path.unlink(missing_ok=True)
                return None
            except Exception as e:
                self.logger.warning(
                    "image_download_error",
                    src_url=src_url,
                    error=str(e),
                )
                self._url_seen[src_url] = None
                temp_path.unlink(missing_ok=True)
                return None

            # Tier 2: Hash dedup — same content at different URL shares one file
            if sha256 in self._hash_seen:
                existing_path = self._hash_seen[sha256]
                # Discard duplicate download; point to existing file
                temp_path.unlink(missing_ok=True)
                self._url_seen[src_url] = (existing_path, sha256)
                self.logger.debug(
                    "image_hash_dedup",
                    src_url=src_url,
                    existing_path=existing_path,
                    sha256=sha256[:16],
                )
                return (existing_path, sha256)

            # New unique image — rename temp file to final path (atomic on same filesystem)
            filename = self._build_filename(src_url, sha256, content_type)
            final_path = domain_dir / filename
            temp_path.rename(final_path)

            # Store absolute path in DB (avoids CWD dependency for downstream readers)
            local_path_str = str(final_path.resolve())
            self._hash_seen[sha256] = local_path_str
            self._url_seen[src_url] = (local_path_str, sha256)

            self.logger.debug(
                "image_downloaded",
                src_url=src_url,
                local_path=local_path_str,
                sha256=sha256[:16],
            )
            return (local_path_str, sha256)

    async def download_page_images(
        self, page_url: str, image_ids: list[tuple[int, str]]
    ) -> None:
        """Download all images for a page and update DB records.

        This is the method called from the crawler as a background asyncio.Task.
        Individual image failures are logged but never propagate — one bad image
        cannot stop the rest.

        Args:
            page_url: URL of the page (for scope checking and logging)
            image_ids: List of (image_id, src_abs) tuples from get_image_ids_for_page()
        """
        downloaded_count = 0
        skipped_count = 0

        for image_id, src_url in image_ids:
            try:
                result = await self.download_image(src_url, page_url)
                if result is not None:
                    local_path, sha256 = result
                    # Only update DB if we have a real sha256 (empty string means
                    # URL was already in DB from a previous run — DB already has correct values)
                    if sha256:
                        await update_image_download(self._db_path, image_id, local_path, sha256)
                    downloaded_count += 1
                else:
                    skipped_count += 1
            except Exception as e:
                # Catch-all per image — prevent one failure stopping the rest
                self.logger.warning(
                    "page_image_download_error",
                    image_id=image_id,
                    src_url=src_url,
                    error=str(e),
                )
                skipped_count += 1

        self.logger.info(
            "page_images_downloaded",
            page_url=page_url,
            total=len(image_ids),
            downloaded=downloaded_count,
            skipped=skipped_count,
        )
