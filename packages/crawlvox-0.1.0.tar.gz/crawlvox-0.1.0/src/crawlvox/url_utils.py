"""URL utilities for normalization, scope checking, and trap detection."""

import re
from collections import defaultdict
from urllib.parse import urlparse, urlunparse, parse_qs, urlencode

import structlog
from url_normalize import url_normalize

logger = structlog.get_logger(__name__)

# Comprehensive set of tracking parameters to strip
TRACKING_PARAMS = {
    # UTM parameters
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    # Social click IDs
    "fbclid",
    "gclid",
    "msclkid",
    "ttclid",
    "twclid",
    "li_fat_id",
    # Session/analytics
    "sessionid",
    "sid",
    "_ga",
    "_gl",
    "_gid",
    "mc_cid",
    "mc_eid",
    # Additional tracking
    "ref",
    "source",
    "yclid",
    "wickedid",
    "dclid",
    "zanpid",
}


def normalize_url(url: str, remove_tracking: bool = True) -> str:
    """
    Normalize a URL for consistent comparison and deduplication.

    Steps:
    1. Apply url_normalize() for scheme/host lowercasing and percent-encoding
    2. Remove fragment
    3. Remove tracking parameters (optional)
    4. Normalize trailing slashes (remove for non-root paths)

    Args:
        url: The URL to normalize
        remove_tracking: Whether to remove tracking parameters (default: True)

    Returns:
        Normalized URL string
    """
    try:
        # Step 1: Apply url_normalize for scheme/host normalization
        normalized = url_normalize(url)

        # Step 2: Parse and remove fragment
        parsed = urlparse(normalized)
        parsed = parsed._replace(fragment="")

        # Step 3: Remove tracking parameters if requested
        if remove_tracking and parsed.query:
            # Parse query parameters, keeping blank values
            params = parse_qs(parsed.query, keep_blank_values=True)

            # Filter out tracking parameters
            filtered_params = {
                key: value
                for key, value in params.items()
                if key not in TRACKING_PARAMS
            }

            # Rebuild query string
            new_query = urlencode(filtered_params, doseq=True) if filtered_params else ""
            parsed = parsed._replace(query=new_query)

        # Step 4: Trailing slash consistency - remove for non-root paths
        if parsed.path and parsed.path != "/" and parsed.path.endswith("/"):
            parsed = parsed._replace(path=parsed.path.rstrip("/"))

        # Step 5: Return urlunparse result
        return urlunparse(parsed)

    except Exception as e:
        # Fail-safe: return original URL on error
        logger.warning("url_normalization_failed", url=url, error=str(e))
        return url


class ScopeChecker:
    """
    Check if URLs are within crawling scope.

    Supports:
    - Same-domain checking (with subdomain support)
    - Regex allowlist patterns
    - Regex denylist patterns (deny overrides allow)
    """

    def __init__(
        self,
        start_domains: list[str],
        same_domain_only: bool = True,
        allow_patterns: list[str] | None = None,
        deny_patterns: list[str] | None = None,
    ):
        """
        Initialize scope checker.

        Args:
            start_domains: List of allowed domain strings
            same_domain_only: Whether to enforce same-domain constraint (default: True)
            allow_patterns: List of regex patterns - URLs must match at least one to be allowed
            deny_patterns: List of regex patterns - URLs matching any are denied (overrides allow)
        """
        self.start_domains = start_domains
        self.same_domain_only = same_domain_only

        # Compile regex patterns at init time (skip invalid patterns gracefully)
        self.allow_patterns = []
        for pattern in (allow_patterns or []):
            try:
                self.allow_patterns.append(re.compile(pattern))
            except re.error as e:
                logger.warning("invalid_allow_pattern", pattern=pattern, error=str(e))

        self.deny_patterns = []
        for pattern in (deny_patterns or []):
            try:
                self.deny_patterns.append(re.compile(pattern))
            except re.error as e:
                logger.warning("invalid_deny_pattern", pattern=pattern, error=str(e))

    def is_allowed(self, url: str) -> bool:
        """
        Check if a URL is within scope.

        Args:
            url: The URL to check

        Returns:
            True if URL is allowed, False otherwise
        """
        # Step 1: Check deny patterns FIRST (deny overrides allow)
        for pattern in self.deny_patterns:
            if pattern.search(url):
                return False

        # Step 2: Check allow patterns
        if self.allow_patterns:
            # If allow patterns exist, URL must match at least one
            if not any(pattern.search(url) for pattern in self.allow_patterns):
                return False

        # Step 3: Check same-domain constraint if enabled
        if self.same_domain_only:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()

            # Use suffix matching to handle subdomains
            # e.g., blog.example.com matches when start_domain is example.com
            allowed = False
            for start_domain in self.start_domains:
                start_domain_lower = start_domain.lower()
                if domain == start_domain_lower or domain.endswith(f".{start_domain_lower}"):
                    allowed = True
                    break

            if not allowed:
                return False

        # Step 4: All checks passed
        return True


class TrapDetector:
    """
    Detect infinite crawl patterns using URL heuristics.

    Tracks visits per pattern and blocks after threshold exceeded.
    """

    # Common trap patterns
    TRAP_PATTERNS = [
        r"/page/\d+",           # Pagination
        r"/\d{4}/\d{2}/\d{2}",  # Calendar dates
        r"[?&]year=\d+",        # Year parameter
        r"[?&]month=\d+",       # Month parameter
        r"[?&]page=\d+",        # Page query parameter
        r"[?&]offset=\d+",      # Offset parameter
        r"[?&]sort=",           # Sort parameter (faceted search)
        r"[?&]filter=",         # Filter parameter (faceted search)
        r"[?&]category=",       # Category parameter (faceted search)
        r"sessionid=",          # Session IDs
    ]

    def __init__(self, max_visits_per_pattern: int = 100):
        """
        Initialize trap detector.

        Args:
            max_visits_per_pattern: Maximum visits allowed per pattern before blocking (default: 100)
        """
        self.max_visits = max_visits_per_pattern
        self.pattern_counters = defaultdict(int)

        # Compile patterns at init time
        self.compiled_patterns = [re.compile(pattern) for pattern in self.TRAP_PATTERNS]

    def is_trap(self, url: str) -> bool:
        """
        Check if a URL is part of an infinite trap pattern.

        Args:
            url: The URL to check

        Returns:
            True if URL is a trap (pattern exceeded threshold), False otherwise
        """
        for pattern in self.compiled_patterns:
            if pattern.search(url):
                # Increment counter for this pattern
                pattern_key = pattern.pattern
                self.pattern_counters[pattern_key] += 1

                # Check if threshold exceeded
                if self.pattern_counters[pattern_key] > self.max_visits:
                    return True

        return False
