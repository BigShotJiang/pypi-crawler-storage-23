"""
Sitemap.xml URL extraction with memory-efficient parsing.

Uses ultimate-sitemap-parser to discover and extract URLs from sitemap.xml.
All operations are fail-safe: parsing errors return empty list.
"""

import structlog
from usp.tree import sitemap_tree_for_homepage

logger = structlog.get_logger()


def extract_sitemap_urls(start_url: str, max_urls: int = 10000) -> list[str]:
    """Extract URLs from sitemap.xml with memory-efficient iteration.

    Discovers sitemaps from start_url, parses them, and extracts page URLs.
    Uses generator-based iteration to handle large sitemaps efficiently.

    Args:
        start_url: Homepage URL to discover sitemaps from
        max_urls: Maximum number of URLs to extract (default 10000)

    Returns:
        List of URL strings from sitemap, or empty list on error

    Note:
        This function is SYNCHRONOUS (uses requests internally). Acceptable
        because it runs once at crawl initialization, not per-URL.
    """
    try:
        # Discover and parse sitemaps
        tree = sitemap_tree_for_homepage(start_url)

        # Extract URLs with max_urls limit
        urls = []
        for page in tree.all_pages():
            urls.append(page.url)
            if len(urls) >= max_urls:
                logger.info(
                    "sitemap URL limit reached",
                    start_url=start_url,
                    max_urls=max_urls,
                )
                break

        logger.info(
            "sitemap URLs extracted",
            start_url=start_url,
            url_count=len(urls),
        )
        return urls

    except Exception as e:
        # Sitemap parsing is best-effort: fail safe
        logger.warning(
            "sitemap extraction failed, returning empty list",
            start_url=start_url,
            error=str(e),
        )
        return []
