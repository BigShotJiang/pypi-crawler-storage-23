"""CrawlVox - Web scraping and content extraction tool."""

__version__ = "0.1.0"
