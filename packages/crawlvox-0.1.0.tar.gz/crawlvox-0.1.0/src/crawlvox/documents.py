"""PDF document processing via PyMuPDF pre-scan and Docling conversion (Phase 8)."""

import asyncio
import io
from typing import Any, Literal
from urllib.parse import urlparse

import fitz  # PyMuPDF
import httpx
import structlog

from crawlvox.storage import save_document


# Minimum words per page to consider text layer sufficient (skip OCR)
MIN_WORDS_PER_PAGE = 10


class DocumentProcessor:
    """Downloads PDFs, detects text layers, and converts to Markdown via Docling.

    Processing pipeline:
    1. Stream-download PDF with size limit enforcement
    2. Check page count against limit
    3. PyMuPDF pre-scan to detect if OCR is needed (auto mode)
    4. Docling conversion in thread pool (thread-safe via per-call DocumentConverter)
    5. Retry once on conversion failure
    6. Save result to documents table via save_document()

    Usage:
        async with DocumentProcessor(client, db_path, ...) as processor:
            await processor.process_document(url, content_type)

    Notes:
        - Semaphore(1) serializes Docling calls (PDF backends have global locks)
        - DocumentConverter created per-call inside asyncio.to_thread (not shared)
        - Docling imported inside thread function to avoid import-time side effects
    """

    def __init__(
        self,
        client: httpx.AsyncClient,
        db_path: str,
        ocr_mode: Literal["off", "auto", "always"],
        ocr_language: str,
        max_file_size: int,
        max_pages: int,
    ) -> None:
        """Initialize DocumentProcessor.

        Args:
            client: Shared httpx.AsyncClient from Fetcher (not owned by this class)
            db_path: Path to SQLite database for saving document records
            ocr_mode: OCR strategy: off=skip, auto=detect, always=force
            ocr_language: 2-letter EasyOCR language code (e.g. "en")
            max_file_size: Maximum allowed PDF size in bytes
            max_pages: Maximum allowed page count

        Note:
            asyncio.Semaphore is NOT created here — it is created in __aenter__ to
            avoid "no running event loop" errors (Python 3.10+ requirement).
        """
        self._client = client
        self._db_path = db_path
        self._ocr_mode = ocr_mode
        self._ocr_language = ocr_language
        self._max_file_size = max_file_size
        self._max_pages = max_pages

        # DO NOT create asyncio.Semaphore here — event loop may not be running yet
        self._semaphore: asyncio.Semaphore | None = None

        self.logger = structlog.get_logger()

    async def __aenter__(self) -> "DocumentProcessor":
        """Create semaphore inside running event loop and return self.

        Semaphore(1) serializes Docling calls — PDF backends have global locks
        and are not safe for concurrent use (Docling discussion #2285).
        """
        self._semaphore = asyncio.Semaphore(1)
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """No cleanup needed — client lifecycle is owned by Fetcher."""
        pass

    async def _download_pdf(self, url: str) -> bytes | None:
        """Stream-download a PDF with size limit enforcement.

        Args:
            url: URL of the PDF to download

        Returns:
            Raw PDF bytes, or None if download failed or size limit exceeded
        """
        try:
            async with self._client.stream("GET", url, follow_redirects=True) as response:
                response.raise_for_status()

                # Early Content-Length check before downloading
                content_length_str = response.headers.get("content-length")
                if content_length_str:
                    try:
                        content_length = int(content_length_str)
                        if content_length > self._max_file_size:
                            self.logger.warning(
                                "document_size_limit_exceeded_early",
                                url=url,
                                content_length=content_length,
                                max_file_size=self._max_file_size,
                            )
                            return None
                    except (ValueError, TypeError):
                        # Non-integer Content-Length — ignore and enforce during streaming
                        pass

                # Rolling size check during streaming
                chunks: list[bytes] = []
                downloaded = 0

                async for chunk in response.aiter_bytes(chunk_size=65536):
                    downloaded += len(chunk)
                    if downloaded > self._max_file_size:
                        self.logger.warning(
                            "document_size_limit_exceeded_streaming",
                            url=url,
                            downloaded=downloaded,
                            max_file_size=self._max_file_size,
                        )
                        return None
                    chunks.append(chunk)

                return b"".join(chunks)

        except httpx.HTTPError as e:
            self.logger.warning(
                "document_download_http_error",
                url=url,
                error=str(e),
            )
            return None
        except Exception as e:
            self.logger.warning(
                "document_download_error",
                url=url,
                error=str(e),
            )
            return None

    def _get_page_count(self, pdf_bytes: bytes) -> int | None:
        """Get the page count of a PDF using PyMuPDF.

        Args:
            pdf_bytes: Raw PDF bytes

        Returns:
            Page count, or None if PyMuPDF fails to open the PDF
        """
        doc = None
        try:
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            return doc.page_count
        except Exception as e:
            self.logger.warning(
                "document_page_count_error",
                error=str(e),
            )
            return None
        finally:
            if doc is not None:
                doc.close()

    def _needs_ocr(self, pdf_bytes: bytes) -> bool:
        """Check if PDF requires OCR by scanning text word count per page.

        Uses PyMuPDF to scan each page for existing text words.
        If ANY page has fewer than MIN_WORDS_PER_PAGE words, OCR is needed.

        Args:
            pdf_bytes: Raw PDF bytes

        Returns:
            True if OCR is needed, False if all pages have sufficient text.
            Fail-open: returns True on any exception (assume OCR needed).
        """
        doc = None
        try:
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            for page in doc:
                if len(page.get_text_words()) < MIN_WORDS_PER_PAGE:
                    return True
            return False
        except Exception as e:
            self.logger.warning(
                "document_ocr_detection_error",
                error=str(e),
            )
            # Fail-open: assume OCR needed if we can't determine
            return True
        finally:
            if doc is not None:
                doc.close()

    async def _convert_async(
        self,
        pdf_bytes: bytes,
        url: str,
        do_ocr: bool,
        force_full_page_ocr: bool,
    ) -> str | None:
        """Convert PDF to Markdown via Docling in a thread pool.

        Creates a fresh DocumentConverter for each call (thread-safe).
        Docling is imported inside the thread function to avoid import-time
        side effects when document processing is not enabled.

        Args:
            pdf_bytes: Raw PDF bytes to convert
            url: Source URL (used for DocumentStream name)
            do_ocr: Whether to enable OCR
            force_full_page_ocr: Whether to force full-page OCR (used with do_ocr=True)

        Returns:
            Markdown string, or None if conversion failed
        """
        # Capture self attributes for use inside thread (avoid closure issues)
        ocr_language = self._ocr_language
        # Extract filename from URL for DocumentStream name
        url_path = urlparse(url).path
        doc_name = url_path.split("/")[-1] if url_path.split("/")[-1] else "document.pdf"
        if not doc_name.lower().endswith(".pdf"):
            doc_name = "document.pdf"

        def _sync_convert() -> str | None:
            """Synchronous Docling conversion — runs inside asyncio.to_thread."""
            # Import inside thread function to avoid import-time side effects
            from docling.document_converter import DocumentConverter, PdfFormatOption
            from docling.datamodel.pipeline_options import PdfPipelineOptions, EasyOcrOptions
            from docling.datamodel.base_models import InputFormat
            from docling.datamodel.document import ConversionStatus
            from docling_core.types.io import DocumentStream

            # Configure PDF pipeline options
            pipeline_options = PdfPipelineOptions(
                do_ocr=do_ocr,
                ocr_options=EasyOcrOptions(
                    lang=[ocr_language],
                    force_full_page_ocr=force_full_page_ocr,
                ),
                do_table_structure=True,
                do_code_enrichment=False,
                do_formula_enrichment=False,
                do_picture_classification=False,
            )

            # Create DocumentConverter INSIDE thread (DO NOT share across threads)
            converter = DocumentConverter(
                format_options={
                    InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
                }
            )

            # Create DocumentStream from PDF bytes
            doc_stream = DocumentStream(
                name=doc_name,
                stream=io.BytesIO(pdf_bytes),
            )

            # Convert (raises_on_error=False so we can inspect status)
            result = converter.convert(doc_stream, raises_on_error=False)

            # FAILURE = return None; SUCCESS or PARTIAL_SUCCESS = extract text
            if result.status == ConversionStatus.FAILURE:
                return None

            return result.document.export_to_markdown()

        try:
            return await asyncio.to_thread(_sync_convert)
        except Exception as e:
            self.logger.error(
                "document_conversion_error",
                url=url,
                error=str(e),
            )
            return None

    async def process_document(self, url: str, content_type: str) -> None:
        """Main entry point: download, scan, convert, and save a PDF document.

        Pipeline:
        1. Download PDF (with size limit)
        2. Check page count (against max_pages limit)
        3. Determine OCR settings from ocr_mode
        4. Convert via Docling under semaphore
        5. Retry once if conversion fails
        6. Save result to documents table

        Args:
            url: URL of the PDF document
            content_type: Content-Type header value (stored in documents table)
        """
        assert self._semaphore is not None, "DocumentProcessor must be used as async context manager"

        # Step 1: Download PDF bytes
        pdf_bytes = await self._download_pdf(url)
        if pdf_bytes is None:
            self.logger.warning("document_download_failed", url=url)
            await save_document(
                db_path=self._db_path,
                url=url,
                content_type=content_type,
                page_count=None,
                has_ocr=False,
                extracted_text=None,
                file_size_bytes=None,
                error="download_failed_or_size_limit",
                status="failed",
            )
            return

        file_size_bytes = len(pdf_bytes)

        # Step 2: Get page count and enforce limit
        page_count = self._get_page_count(pdf_bytes)
        if page_count is not None and page_count > self._max_pages:
            self.logger.warning(
                "document_page_limit_exceeded",
                url=url,
                page_count=page_count,
                max_pages=self._max_pages,
            )
            await save_document(
                db_path=self._db_path,
                url=url,
                content_type=content_type,
                page_count=page_count,
                has_ocr=False,
                extracted_text=None,
                file_size_bytes=file_size_bytes,
                error="page_limit_exceeded",
                status="failed",
            )
            return

        # Step 3: Determine OCR settings based on ocr_mode
        if self._ocr_mode == "off":
            do_ocr = False
            force_full_page_ocr = False
            has_ocr = False
        elif self._ocr_mode == "always":
            do_ocr = True
            force_full_page_ocr = True
            has_ocr = True
        else:
            # "auto": use PyMuPDF to detect if OCR is needed
            needs_ocr = self._needs_ocr(pdf_bytes)
            if needs_ocr:
                do_ocr = True
                force_full_page_ocr = False
                has_ocr = True
            else:
                do_ocr = False
                force_full_page_ocr = False
                has_ocr = False

        # Step 4: Convert under semaphore (Docling is not thread-safe for concurrent use)
        async with self._semaphore:
            markdown = await self._convert_async(pdf_bytes, url, do_ocr, force_full_page_ocr)

        # Step 5: Retry once if conversion failed
        if markdown is None:
            self.logger.info(
                "document_conversion_retry",
                url=url,
            )
            async with self._semaphore:
                markdown = await self._convert_async(pdf_bytes, url, do_ocr, force_full_page_ocr)

        # Step 6: Save result to documents table
        if markdown is not None:
            await save_document(
                db_path=self._db_path,
                url=url,
                content_type=content_type,
                page_count=page_count,
                has_ocr=has_ocr,
                extracted_text=markdown,
                file_size_bytes=file_size_bytes,
                error=None,
                status="success",
            )
            self.logger.info(
                "document_processed",
                url=url,
                page_count=page_count,
                has_ocr=has_ocr,
                text_length=len(markdown),
            )
        else:
            await save_document(
                db_path=self._db_path,
                url=url,
                content_type=content_type,
                page_count=page_count,
                has_ocr=has_ocr,
                extracted_text=None,
                file_size_bytes=file_size_bytes,
                error="conversion_failed",
                status="failed",
            )
            self.logger.warning(
                "document_conversion_failed",
                url=url,
                page_count=page_count,
            )
