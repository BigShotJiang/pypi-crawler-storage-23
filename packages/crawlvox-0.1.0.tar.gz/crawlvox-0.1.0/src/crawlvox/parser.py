"""HTML parsing and content extraction."""

import json
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse

import structlog
import trafilatura
from bs4 import BeautifulSoup
from readability import Document

logger = structlog.get_logger()


@dataclass
class ParseResult:
    """Result of HTML content extraction."""

    title: str | None = None
    text: str | None = None
    description: str | None = None
    author: str | None = None
    date: str | None = None
    error: str | None = None
    success: bool = False
    extraction_method: str | None = None  # "trafilatura", "readability", "failed", or None


@dataclass
class Metadata:
    """Rich metadata extracted from HTML meta tags."""

    title: str | None = None
    description: str | None = None
    canonical_url: str | None = None
    og_title: str | None = None
    og_description: str | None = None
    og_image: str | None = None
    og_type: str | None = None
    twitter_card: str | None = None
    twitter_title: str | None = None
    twitter_description: str | None = None
    twitter_image: str | None = None
    language: str | None = None


@dataclass
class Image:
    """Represents an extracted image from a web page."""

    src_abs: str  # Absolute URL of image source
    alt: str | None  # Alt text (None if empty/missing)
    width: int | None  # Width in pixels (None if not specified)
    height: int | None  # Height in pixels (None if not specified)
    srcset: str | None  # Raw srcset attribute value


@dataclass
class Link:
    """Represents an extracted hyperlink from a web page."""

    href_abs: str  # Absolute URL after resolution
    anchor_text: str  # Visible link text (stripped)
    rel: str | None  # rel attribute value (first item if list)
    is_internal: bool  # True if same domain as source page


def extract_content(html: str, url: str) -> ParseResult:
    """
    Extract clean text and metadata from HTML using trafilatura.

    Args:
        html: Raw HTML string to parse
        url: Source URL for metadata resolution

    Returns:
        ParseResult with extracted content or error details
    """
    try:
        result = trafilatura.extract(
            html,
            output_format="json",
            include_formatting=True,
            include_links=True,
            include_images=False,
            with_metadata=True,
            url=url,
        )

        if result is None:
            logger.warning("extraction_failed", url=url, reason="trafilatura returned None")
            return ParseResult(
                error="Extraction failed - trafilatura returned None",
                success=False,
            )

        # Parse JSON result
        data = json.loads(result)

        return ParseResult(
            title=data.get("title"),
            text=data.get("text"),
            description=data.get("description"),
            author=data.get("author"),
            date=data.get("date"),
            success=True,
        )

    except Exception as e:
        logger.error("extraction_error", url=url, error=str(e))
        return ParseResult(
            error=str(e),
            success=False,
        )


def extract_content_with_fallback(html: str, url: str, min_length: int = 200) -> ParseResult:
    """
    Extract content using trafilatura first, falling back to readability-lxml if needed.

    Args:
        html: Raw HTML string to parse
        url: Source URL for metadata resolution
        min_length: Minimum acceptable content length (default 200 chars)

    Returns:
        ParseResult with extracted content, including extraction_method field
    """
    # Try trafilatura first
    result = extract_content(html, url)

    # Check if trafilatura succeeded with sufficient content
    if result.success and result.text and len(result.text) >= min_length:
        result.extraction_method = "trafilatura"
        return result

    # Log fallback trigger
    reason = "no text" if not result.text else f"text too short ({len(result.text)} chars)"
    logger.info("fallback_extraction", url=url, reason=reason, min_length=min_length)

    # Try readability-lxml fallback
    try:
        doc = Document(html)
        fallback_html = doc.summary()
        fallback_title = doc.title()

        # Extract text from cleaned HTML
        soup = BeautifulSoup(fallback_html, "lxml")
        fallback_text = soup.get_text(separator="\n", strip=True)

        # Validate fallback content length
        if fallback_text and len(fallback_text) >= min_length:
            return ParseResult(
                title=fallback_title or result.title,
                text=fallback_text,
                description=result.description,
                author=result.author,
                date=result.date,
                success=True,
                extraction_method="readability",
            )
        else:
            logger.warning(
                "fallback_also_failed",
                url=url,
                fallback_length=len(fallback_text) if fallback_text else 0,
            )
            result.extraction_method = "failed"
            return result

    except Exception as e:
        logger.error("fallback_error", url=url, error=str(e))
        result.extraction_method = "failed"
        return result


def _get_meta_property(soup: BeautifulSoup, property_name: str) -> str | None:
    """Helper to extract OpenGraph meta property value."""
    tag = soup.find("meta", property=property_name)
    return tag.get("content") if tag and tag.get("content") else None


def _get_meta_name(soup: BeautifulSoup, name: str) -> str | None:
    """Helper to extract meta tag by name attribute."""
    tag = soup.find("meta", attrs={"name": name})
    return tag.get("content") if tag and tag.get("content") else None


def extract_metadata(html: str, page_url: str) -> Metadata:
    """
    Extract rich metadata from HTML including OpenGraph, Twitter cards, and canonical URL.

    Args:
        html: Raw HTML string to parse
        page_url: Source URL for resolving relative URLs

    Returns:
        Metadata object with all extracted fields (None if not found)
    """
    try:
        soup = BeautifulSoup(html, "lxml")

        # Basic metadata
        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else None

        description = _get_meta_name(soup, "description")

        # Canonical URL
        canonical_tag = soup.find("link", rel="canonical")
        canonical_url = None
        if canonical_tag and canonical_tag.get("href"):
            canonical_url = urljoin(page_url, canonical_tag["href"])

        # Language
        language = None
        html_tag = soup.find("html")
        if html_tag:
            language = html_tag.get("lang")
        if not language:
            lang_meta = soup.find("meta", attrs={"http-equiv": "content-language"})
            if lang_meta:
                language = lang_meta.get("content")

        # OpenGraph tags
        og_title = _get_meta_property(soup, "og:title")
        og_description = _get_meta_property(soup, "og:description")
        og_type = _get_meta_property(soup, "og:type")

        og_image_raw = _get_meta_property(soup, "og:image")
        og_image = urljoin(page_url, og_image_raw) if og_image_raw else None

        # Twitter card tags
        twitter_card = _get_meta_name(soup, "twitter:card")
        twitter_title = _get_meta_name(soup, "twitter:title")
        twitter_description = _get_meta_name(soup, "twitter:description")

        twitter_image_raw = _get_meta_name(soup, "twitter:image")
        twitter_image = urljoin(page_url, twitter_image_raw) if twitter_image_raw else None

        return Metadata(
            title=title,
            description=description,
            canonical_url=canonical_url,
            og_title=og_title,
            og_description=og_description,
            og_image=og_image,
            og_type=og_type,
            twitter_card=twitter_card,
            twitter_title=twitter_title,
            twitter_description=twitter_description,
            twitter_image=twitter_image,
            language=language,
        )

    except Exception as e:
        logger.error("extraction_error", url=page_url, error=str(e), context="metadata")
        return Metadata()


def resolve_url(base_url: str, relative_url: str) -> str:
    """
    Resolve a relative URL against a base URL.

    Args:
        base_url: The base URL to resolve against
        relative_url: The relative (or absolute) URL to resolve

    Returns:
        Absolute URL string
    """
    return urljoin(base_url, relative_url)


def resolve_urls(base_url: str, relative_urls: list[str]) -> list[str]:
    """
    Resolve multiple relative URLs against a base URL.

    Args:
        base_url: The base URL to resolve against
        relative_urls: List of relative (or absolute) URLs to resolve

    Returns:
        List of absolute URL strings
    """
    return [resolve_url(base_url, url) for url in relative_urls]


def classify_content_type(content_type: str, url: str | None = None) -> str:
    """
    Classify a content-type string into broad categories.

    Content-type header is the primary detection method. If the content-type
    does not match a known category AND a URL is provided, falls back to checking
    the URL path extension for .pdf (locked decision DOC-01).

    Args:
        content_type: Content-Type header value (e.g., 'text/html', 'application/pdf')
        url: Optional source URL for extension-based fallback detection

    Returns:
        Classification: 'html', 'pdf', 'image', or 'other'
    """
    if content_type.startswith("text/html") or content_type == "application/xhtml+xml":
        return "html"
    elif content_type == "application/pdf":
        return "pdf"
    elif content_type.startswith("image/"):
        return "image"
    else:
        # URL extension fallback: handle servers that return wrong/generic content-type
        # for PDFs (e.g., application/octet-stream for a .pdf URL)
        if url is not None:
            path = urlparse(url).path
            if path.lower().endswith(".pdf"):
                return "pdf"
        return "other"


def extract_links(html: str, page_url: str) -> list[Link]:
    """
    Extract all hyperlinks from HTML page.

    Args:
        html: Raw HTML string to parse
        page_url: Source URL for link resolution and internal/external classification

    Returns:
        List of Link objects with resolved absolute URLs, anchor text, rel attributes,
        and internal/external classification. Returns empty list on parsing errors.
    """
    try:
        soup = BeautifulSoup(html, "lxml")
        page_domain = urlparse(page_url).netloc
        links = []

        for tag in soup.find_all("a", href=True):
            href = tag.get("href")

            # Skip empty/None hrefs
            if not href:
                continue

            # Skip non-HTTP schemes
            if href.startswith(("mailto:", "tel:", "javascript:", "data:")):
                continue

            # Resolve to absolute URL
            href_abs = urljoin(page_url, href)

            # Get anchor text
            anchor_text = tag.get_text(strip=True) or ""

            # Get rel attribute (can be list or None)
            rel_value = tag.get("rel")
            rel = rel_value[0] if isinstance(rel_value, list) and rel_value else None

            # Classify internal/external by domain
            link_domain = urlparse(href_abs).netloc
            is_internal = link_domain == page_domain

            links.append(
                Link(
                    href_abs=href_abs,
                    anchor_text=anchor_text,
                    rel=rel,
                    is_internal=is_internal,
                )
            )

        return links

    except Exception as e:
        logger.error("link_extraction_error", url=page_url, error=str(e))
        return []


def _parse_dimension(value: str | None) -> int | None:
    """
    Parse dimension value (width/height) from string to int.

    Args:
        value: Dimension string (e.g., "400", "400px", None)

    Returns:
        Integer dimension or None if invalid/missing
    """
    if not value:
        return None

    # Strip "px" suffix if present
    value_str = str(value).strip()
    if value_str.endswith("px"):
        value_str = value_str[:-2]

    try:
        return int(value_str)
    except ValueError:
        return None


def _parse_srcset_best(srcset: str) -> str | None:
    """
    Parse srcset attribute and return the highest quality image URL.

    Args:
        srcset: Raw srcset attribute value (e.g., "small.jpg 400w, large.jpg 1200w")

    Returns:
        URL of highest width candidate, or None if parsing fails
    """
    if not srcset:
        return None

    try:
        candidates = []

        # Split on commas to get individual candidates
        for candidate_str in srcset.split(","):
            parts = candidate_str.strip().split()
            if not parts:
                continue

            url = parts[0]
            width = 0

            # Parse descriptor if present
            if len(parts) > 1:
                descriptor = parts[1]
                if descriptor.endswith("w"):
                    # Width descriptor (e.g., "800w")
                    try:
                        width = int(descriptor[:-1])
                    except ValueError:
                        pass
                elif descriptor.endswith("x"):
                    # Density descriptor (e.g., "2x") - treat as width for sorting
                    try:
                        density = float(descriptor[:-1])
                        width = int(density * 1000)  # 2x = 2000 for sorting
                    except ValueError:
                        pass
            else:
                # No descriptor, assume it's a default (treat as single option)
                candidates.append((url, 0))
                continue

            candidates.append((url, width))

        if not candidates:
            return None

        # Sort by width descending and return highest
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0]

    except Exception as e:
        logger.debug("srcset_parse_error", srcset=srcset, error=str(e))
        return None


def extract_images(html: str, page_url: str) -> list[Image]:
    """
    Extract all images from HTML page with srcset parsing for best quality selection.

    Args:
        html: Raw HTML string to parse
        page_url: Source URL for image URL resolution

    Returns:
        List of Image objects with absolute URLs, alt text, dimensions, and srcset.
        Returns empty list on parsing errors.
    """
    try:
        soup = BeautifulSoup(html, "lxml")
        images = []

        for img in soup.find_all("img"):
            # Try to get best quality src from srcset first
            srcset_raw = img.get("srcset")
            best_src = None

            if srcset_raw:
                best_src = _parse_srcset_best(srcset_raw)

            # Fallback to src or data-src
            src = best_src or img.get("src") or img.get("data-src")

            # Skip if no src found
            if not src:
                continue

            # Resolve to absolute URL
            src_abs = urljoin(page_url, src)

            # Extract alt text (empty string becomes None)
            alt_raw = img.get("alt", "").strip()
            alt = alt_raw if alt_raw else None

            # Parse dimensions
            width = _parse_dimension(img.get("width"))
            height = _parse_dimension(img.get("height"))

            images.append(
                Image(
                    src_abs=src_abs,
                    alt=alt,
                    width=width,
                    height=height,
                    srcset=srcset_raw,
                )
            )

        return images

    except Exception as e:
        logger.error("image_extraction_error", url=page_url, error=str(e))
        return []
