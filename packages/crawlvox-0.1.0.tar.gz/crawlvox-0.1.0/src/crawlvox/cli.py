"""Typer CLI entry point for CrawlVox."""

import asyncio
import json
import sys
import time
import uuid
from typing import List, Optional

import typer
from pydantic import ValidationError
from rich.console import Console

from crawlvox.config import ScraperConfig
from crawlvox.crawler import Crawler
from crawlvox.logging import configure_logging, get_logger
from crawlvox.storage import get_interrupted_runs, init_database, update_run_status
from crawlvox.url_utils import normalize_url

app = typer.Typer(
    help="CrawlVox - Web scraping and content extraction tool",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def parse_size(size_str: str) -> int:
    """Parse human-readable size string to bytes.

    Supports formats: '10mb', '50MB', '1gb', '1024kb', '5242880' (plain bytes).
    """
    s = size_str.strip().lower()
    units = {"kb": 1024, "mb": 1024**2, "gb": 1024**3, "b": 1}
    for suffix, mult in sorted(units.items(), key=lambda x: -len(x[0])):
        if s.endswith(suffix):
            return int(float(s[: -len(suffix)]) * mult)
    return int(s)


def _print_summary(
    pages_crawled: int,
    elapsed: float,
    db_path: str,
    export_path: str | None = None,
    error_counts: dict[str, int] | None = None,
    status_distribution: dict[int | None, int] | None = None,
) -> None:
    """Print end-of-crawl summary to stderr."""
    console = Console(stderr=True)
    console.print()
    console.print("[bold]Crawl summary[/bold]")
    console.print(f"  Pages crawled : [green]{pages_crawled}[/green]")
    console.print(f"  Elapsed       : {elapsed:.1f}s")

    # Throughput (always shown)
    pages_per_sec = pages_crawled / elapsed if elapsed > 0 else 0.0
    console.print(f"  Throughput    : {pages_per_sec:.1f} pages/sec")

    console.print(f"  Database      : {db_path}")
    if export_path:
        console.print(f"  JSONL export  : {export_path}")

    # Status code distribution (shown when data available)
    if status_distribution:
        ok = sum(v for k, v in status_distribution.items() if k is not None and 200 <= k < 300)
        redirects = sum(v for k, v in status_distribution.items() if k is not None and 300 <= k < 400)
        client_errors = sum(v for k, v in status_distribution.items() if k is not None and 400 <= k < 500)
        server_errors = sum(v for k, v in status_distribution.items() if k is not None and k >= 500)
        no_status = sum(v for k, v in status_distribution.items() if k is None)
        parts = []
        if ok:
            parts.append(f"{ok} OK")
        if redirects:
            parts.append(f"{redirects} redirect")
        if client_errors:
            parts.append(f"{client_errors} client error")
        if server_errors:
            parts.append(f"{server_errors} server error")
        if no_status:
            parts.append(f"{no_status} failed")
        if parts:
            console.print(f"  Status codes  : {', '.join(parts)}")

    # Error breakdown (shown when errors occurred)
    if error_counts:
        total_errors = sum(error_counts.values())
        breakdown = ", ".join(
            f"{count} {etype}"
            for etype, count in sorted(error_counts.items(), key=lambda x: -x[1])
        )
        console.print(f"  Errors        : {total_errors} failed ({breakdown})")


@app.callback(invoke_without_command=True)
def default(ctx: typer.Context) -> None:
    """CrawlVox - Web scraping and content extraction tool.

    Quick start: crawlvox <url> (equivalent to crawlvox crawl <url>)
    """
    if ctx.invoked_subcommand is None:
        # ctx.args contains any extra positional arguments (bare URL invocation)
        urls = [arg for arg in ctx.args if not arg.startswith("-")]
        if urls:
            ctx.invoke(crawl, urls=urls)
        else:
            typer.echo(ctx.get_help())


@app.command()
def crawl(
    urls: List[str] = typer.Argument(..., help="One or more starting URLs to crawl"),
    database: str = typer.Option(
        "crawlvox.db", "--database", "-d", help="Path to SQLite database"
    ),
    max_workers: int = typer.Option(
        10,
        "--workers",
        "-w",
        min=1,
        max=100,
        help="Concurrent workers",
        rich_help_panel="Crawling",
    ),
    max_pages: int = typer.Option(
        100,
        "--max-pages",
        "-p",
        min=1,
        help="Maximum pages to crawl",
        rich_help_panel="Crawling",
    ),
    max_depth: int = typer.Option(
        3,
        "--max-depth",
        min=1,
        max=20,
        help="Maximum crawl depth",
        rich_help_panel="Crawling",
    ),
    timeout: float = typer.Option(
        30.0,
        "--timeout",
        "-t",
        min=1.0,
        help="Request timeout in seconds",
        rich_help_panel="Crawling",
    ),
    rate_limit: float = typer.Option(
        2.0,
        "--rate-limit",
        "-r",
        min=0.1,
        help="Max requests per second per domain",
        rich_help_panel="Crawling",
    ),
    no_robots: bool = typer.Option(
        False,
        "--no-robots",
        help="Disable robots.txt respect",
        rich_help_panel="Crawling",
    ),
    same_domain: bool = typer.Option(
        True,
        "--same-domain/--cross-domain",
        help="Restrict crawling to same domain",
        rich_help_panel="Crawling",
    ),
    include: List[str] = typer.Option(
        [],
        "--include",
        "-i",
        help="Regex patterns for URL allowlist (can specify multiple)",
        rich_help_panel="Crawling",
    ),
    exclude: List[str] = typer.Option(
        [],
        "--exclude",
        "-e",
        help="Regex patterns for URL denylist (can specify multiple)",
        rich_help_panel="Crawling",
    ),
    cookie_file: str = typer.Option(
        None,
        "--cookie-file",
        help="Path to cookie file for session persistence (LWP format)",
        rich_help_panel="Crawling",
    ),
    user_agent: str = typer.Option(
        "CrawlVox/0.1",
        "--user-agent",
        help="HTTP User-Agent header",
        rich_help_panel="Crawling",
    ),
    dynamic: str = typer.Option(
        "auto",
        "--dynamic",
        help="JavaScript rendering: off=never, auto=fallback on low content, always=render all pages",
        rich_help_panel="JavaScript",
    ),
    min_content_length: int = typer.Option(
        200,
        "--min-content-length",
        min=0,
        help="Minimum content length before fallback extraction",
        rich_help_panel="JavaScript",
    ),
    download_images: bool = typer.Option(
        False,
        "--download-images",
        help="Enable binary image downloading with deduplication",
        rich_help_panel="Images",
    ),
    image_dir: str = typer.Option(
        "images",
        "--image-dir",
        help="Directory for downloaded images (default: ./images/)",
        rich_help_panel="Images",
    ),
    image_scope: str = typer.Option(
        "same-domain",
        "--image-scope",
        help="Image scope: same-domain or all (includes CDNs, external sources)",
        rich_help_panel="Images",
    ),
    max_image_size: str = typer.Option(
        "10mb",
        "--max-image-size",
        help="Max image file size (e.g., 10mb, 50mb, 1gb)",
        rich_help_panel="Images",
    ),
    process_documents: bool = typer.Option(
        False,
        "--process-documents",
        help="Enable PDF text extraction via Docling",
        rich_help_panel="Documents",
    ),
    ocr_mode: str = typer.Option(
        "auto",
        "--ocr-mode",
        help="OCR mode: off|auto|always (default: auto)",
        rich_help_panel="Documents",
    ),
    ocr_language: str = typer.Option(
        "en",
        "--ocr-language",
        help="OCR language 2-letter code (en, fr, de, es)",
        rich_help_panel="Documents",
    ),
    max_document_size: str = typer.Option(
        "50mb",
        "--max-document-size",
        help="Max PDF file size (e.g., 50mb, 100mb)",
        rich_help_panel="Documents",
    ),
    max_document_pages: int = typer.Option(
        500,
        "--max-document-pages",
        help="Max PDF page count (default 500)",
        rich_help_panel="Documents",
    ),
    store_html: bool = typer.Option(
        False,
        "--store-html",
        help="Store raw HTML in database (rendered DOM for dynamic pages)",
        rich_help_panel="Output",
    ),
    export_jsonl: str = typer.Option(
        None,
        "--export-jsonl",
        help="Auto-export crawl data to JSONL file after completion",
        rich_help_panel="Output",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress progress and summary (only errors shown)",
        rich_help_panel="Output",
    ),
    log_level: str = typer.Option(
        "INFO",
        "--log-level",
        "-l",
        help="Log level: DEBUG, INFO, WARNING, ERROR",
        rich_help_panel="Output",
    ),
    resume: bool = typer.Option(
        False,
        "--resume",
        help="Resume an interrupted crawl for these URLs",
        rich_help_panel="Resume",
    ),
    recrawl: bool = typer.Option(
        False,
        "--recrawl",
        help="Re-process already-completed pages on resume (useful when extraction logic changes)",
        rich_help_panel="Resume",
    ),
) -> None:
    """Crawl one or more websites starting from provided URLs."""
    # Create and validate configuration first (before logging setup)
    try:
        config = ScraperConfig(
            database_path=database,
            max_workers=max_workers,
            max_pages=max_pages,
            max_depth=max_depth,
            request_timeout=timeout,
            log_level=log_level,
            rate_limit=rate_limit,
            user_agent=user_agent,
            include_patterns=include,
            exclude_patterns=exclude,
            respect_robots_txt=not no_robots,
            same_domain_only=same_domain,
            cookie_file=cookie_file,
            min_content_length=min_content_length,
            dynamic_mode=dynamic,
            download_images=download_images,
            image_dir=image_dir,
            image_scope=image_scope,
            max_image_size=parse_size(max_image_size),
            process_documents=process_documents,
            ocr_mode=ocr_mode,
            ocr_language=ocr_language,
            max_document_size=parse_size(max_document_size),
            max_document_pages=max_document_pages,
            store_html=store_html,
            quiet=quiet,
        )
    except ValidationError as e:
        typer.echo(f"Configuration error: {e}", err=True)
        raise typer.Exit(code=1)

    # Configure logging after validation
    configure_logging(config.log_level)

    # Run async crawl with graceful KeyboardInterrupt handling
    try:
        asyncio.run(
            async_crawl(
                urls,
                config,
                resume=resume,
                recrawl=recrawl,
                export_jsonl=export_jsonl,
            )
        )
    except KeyboardInterrupt:
        pass  # Graceful shutdown already handled inside async_crawl via CancelledError


@app.command()
def export(
    database: str = typer.Option(
        "crawlvox.db", "--database", "-d", help="SQLite database path"
    ),
    output: str = typer.Option(..., "--output", "-o", help="Output file path (or directory for markdown format)"),
    format: str = typer.Option(
        "jsonl", "--format", "-f", help="Export format: jsonl, csv, or markdown"
    ),
    run_id: str = typer.Option(
        None, "--run-id", help="Export only pages from this run ID"
    ),
    url_pattern: str = typer.Option(
        None,
        "--url-pattern",
        help="Filter by URL pattern (SQL LIKE, e.g. %/blog/%)",
    ),
    status: str = typer.Option(
        None,
        "--status",
        help="Filter by page status: ok (successful) or error (failed)",
    ),
    include_html: bool = typer.Option(
        False,
        "--include-html",
        help="Include raw HTML in JSONL export (ignored for other formats)",
    ),
) -> None:
    """Export crawl data from an existing database.

    Formats: jsonl (default), csv, markdown.
    For markdown, --output is treated as a directory (one .md file per page).
    """
    import asyncio as _asyncio

    from crawlvox.storage import export_to_file

    # Validate format
    if format not in ("jsonl", "csv", "markdown"):
        typer.echo(f"Invalid format: {format!r}. Use: jsonl, csv, or markdown", err=True)
        raise typer.Exit(code=1)

    # Validate status filter
    if status is not None and status not in ("ok", "error"):
        typer.echo(f"Invalid status filter: {status!r}. Use: ok or error", err=True)
        raise typer.Exit(code=1)

    # Validate markdown output is not a file extension path
    if format == "markdown" and output.endswith((".jsonl", ".csv", ".json")):
        typer.echo("For markdown format, --output must be a directory path (not a file)", err=True)
        raise typer.Exit(code=1)

    async def _export():
        count = await export_to_file(
            db_path=database,
            output_path=output,
            format=format,
            run_id=run_id,
            url_pattern=url_pattern,
            status_filter=status,
            include_html=include_html,
        )
        return count

    count = _asyncio.run(_export())
    if format == "markdown":
        typer.echo(f"Exported {count} pages as Markdown to {output}/")
    else:
        typer.echo(f"Exported {count} records to {output}")


@app.command()
def status(
    database: str = typer.Option(
        "crawlvox.db", "--database", "-d", help="SQLite database path"
    ),
    limit: int = typer.Option(10, "--limit", help="Number of recent runs to show"),
) -> None:
    """Show crawl run history and statistics."""
    import asyncio as _asyncio

    import aiosqlite
    from rich.table import Table

    from crawlvox.storage import init_database

    async def _status():
        await init_database(database)
        async with aiosqlite.connect(database) as db:
            async with db.execute(
                """
                SELECT r.run_id, r.started_at, r.completed_at, r.status,
                       r.start_urls_json,
                       (SELECT COUNT(*) FROM run_pages rp WHERE rp.run_id = r.run_id) as pages
                FROM runs r
                ORDER BY r.started_at DESC
                LIMIT ?
                """,
                (limit,),
            ) as cursor:
                runs = await cursor.fetchall()

        console = Console()
        if not runs:
            console.print("No crawl runs found in database.")
            return

        table = Table(title="Recent Crawl Runs")
        table.add_column("Run ID", style="cyan", no_wrap=True)
        table.add_column("Started", no_wrap=True)
        table.add_column("Status", style="bold")
        table.add_column("Pages", justify="right")
        table.add_column("URLs", max_width=60)

        for run_id_val, started_at, completed_at, run_status, start_urls, pages in runs:
            status_style = {
                "completed": "green",
                "interrupted": "yellow",
                "running": "blue",
                "failed": "red",
            }.get(run_status, "white")
            urls_display = (
                start_urls[:57] + "..."
                if start_urls and len(start_urls) > 60
                else (start_urls or "")
            )
            table.add_row(
                run_id_val[:12],
                started_at[:19] if started_at else "",
                f"[{status_style}]{run_status}[/{status_style}]",
                str(pages),
                urls_display,
            )

        console.print(table)

        # Storage summary
        from crawlvox.storage import get_storage_summary
        summary = await get_storage_summary(database)

        console.print()
        console.print("[bold]Storage Summary[/bold]")
        console.print(f"  Database size  : {summary['db_size_human']}")
        console.print(f"  Pages          : {summary['pages']} ({summary['pages_with_html']} with raw HTML)")
        console.print(f"  Runs           : {summary['runs']}")
        console.print(f"  Links          : {summary['links']}")
        console.print(f"  Images         : {summary['images']}")
        console.print(f"  Documents      : {summary['documents']}")

    _asyncio.run(_status())


@app.command()
def purge(
    database: str = typer.Option(
        "crawlvox.db", "--database", "-d", help="SQLite database path"
    ),
    run: str = typer.Option(
        None, "--run", help="Specific run ID to purge"
    ),
    older_than: str = typer.Option(
        None, "--older-than", help="Purge runs older than duration (e.g., 7d, 2w, 24h, 30m)"
    ),
) -> None:
    """Purge old crawl runs and associated data.

    Removes run records, pages, links, images (DB rows), and orphaned
    image files from the filesystem. Images shared with other runs are preserved.

    Must specify either --run or --older-than (not both, not neither).
    """
    import asyncio as _asyncio

    from crawlvox.storage import execute_purge, get_purge_preview, init_database

    # Validate exactly one selector
    if not run and not older_than:
        typer.echo("Must specify --run <id> or --older-than <duration>", err=True)
        raise typer.Exit(code=1)
    if run and older_than:
        typer.echo("Cannot use both --run and --older-than at the same time", err=True)
        raise typer.Exit(code=1)

    async def _purge():
        await init_database(database)
        previews = await get_purge_preview(
            db_path=database,
            run_id=run,
            older_than=older_than,
        )

        if not previews:
            typer.echo("No matching runs found to purge.")
            return

        # Check for 'running' status runs
        running_runs = [p for p in previews if p["status"] == "running"]
        purgeable = [p for p in previews if p["status"] != "running"]

        if running_runs:
            for r in running_runs:
                typer.echo(
                    f"Skipping run {r['run_id'][:12]} — status is 'running' (cannot purge active runs)",
                    err=True,
                )

        if not purgeable:
            typer.echo("No purgeable runs found (active runs are excluded).")
            return

        # Show preview using Rich
        from rich.panel import Panel

        console = Console(stderr=True)

        for p in purgeable:
            console.print(Panel(
                f"[bold]Run:[/bold] {p['run_id']}\n"
                f"[bold]Started:[/bold] {p['started_at']}\n"
                f"[bold]Status:[/bold] {p['status']}\n"
                f"[bold]Pages:[/bold] {p['page_count']}\n"
                f"[bold]Links:[/bold] {p['link_count']}\n"
                f"[bold]Images:[/bold] {p['image_count']} ({p['orphan_image_count']} filesystem files to delete)\n"
                f"[bold]Estimated size:[/bold] ~{p['estimated_size_human']}",
                title="[red]Purge Preview[/red]",
                border_style="red",
            ))

        total_pages = sum(p["page_count"] for p in purgeable)
        total_runs = len(purgeable)
        console.print(
            f"\n[bold]Total:[/bold] {total_runs} run(s), {total_pages} page(s)"
        )

        # Confirm
        confirmed = typer.confirm(
            "Delete these runs? This cannot be undone", default=False
        )
        if not confirmed:
            typer.echo("Purge cancelled.")
            raise typer.Exit(0)

        # Execute purge
        run_ids = [p["run_id"] for p in purgeable]
        result = await execute_purge(database, run_ids)

        console.print(
            f"\n[green]Purge complete:[/green] {result['pages_deleted']} pages, "
            f"{result['links_deleted']} links, {result['images_deleted']} image records, "
            f"{result['files_deleted']} files deleted"
        )

    _asyncio.run(_purge())


async def async_crawl(
    urls: list[str],
    config: ScraperConfig,
    resume: bool = False,
    recrawl: bool = False,
    export_jsonl: str | None = None,
) -> None:
    """Async crawl implementation with resume support.

    Args:
        urls: List of starting URLs to crawl
        config: Validated scraper configuration
        resume: If True, attempt to resume an interrupted crawl
        recrawl: If True, re-process already-completed pages on resume
        export_jsonl: Optional path to auto-export JSONL after crawl completes
    """
    logger = get_logger()
    logger.info("crawl_starting", url_count=len(urls), config=config.model_dump())

    start_time = time.monotonic()

    # Normalize and sort start URLs for consistent matching
    normalized_urls = sorted(normalize_url(u) for u in urls)
    start_urls_json = json.dumps(normalized_urls)

    run_id = None
    resuming = False

    if resume:
        # Initialize database first (needed for queries)
        await init_database(config.database_path)

        # Look for interrupted runs matching these start URLs
        interrupted_runs = await get_interrupted_runs(config.database_path, start_urls_json)

        if not interrupted_runs:
            logger.warning("no_interrupted_run_found", start_urls=normalized_urls)
            typer.echo("No interrupted run found for these URLs, starting fresh.")
            # Fall through to fresh run
        elif len(interrupted_runs) == 1:
            run_id = interrupted_runs[0][0]
            started_at = interrupted_runs[0][1]
            pages_crawled = interrupted_runs[0][2]
            resuming = True
            typer.echo(f"Resuming run from {started_at} ({pages_crawled} pages crawled)")
            logger.info(
                "resuming_run",
                run_id=run_id,
                started_at=started_at,
                pages_crawled=pages_crawled,
            )
        else:
            # Multiple interrupted runs -- prompt user to choose
            typer.echo(f"\nFound {len(interrupted_runs)} interrupted runs:")
            for i, (rid, started_at, pages_crawled) in enumerate(interrupted_runs, 1):
                typer.echo(
                    f"  {i}. {started_at} -- {pages_crawled} pages crawled (run: {rid[:8]}...)"
                )

            choice = typer.prompt(f"Select run to resume (1-{len(interrupted_runs)})", type=int)
            if 1 <= choice <= len(interrupted_runs):
                run_id = interrupted_runs[choice - 1][0]
                started_at = interrupted_runs[choice - 1][1]
                pages_crawled = interrupted_runs[choice - 1][2]
                resuming = True
                typer.echo(f"Resuming run from {started_at}")
                logger.info(
                    "resuming_run",
                    run_id=run_id,
                    started_at=started_at,
                    pages_crawled=pages_crawled,
                )
            else:
                typer.echo("Invalid selection, starting fresh.")

        # Update run status back to 'running' for the resumed run
        if resuming and run_id:
            await update_run_status(config.database_path, run_id, "running")

    # Generate new run_id if not resuming
    if run_id is None:
        run_id = uuid.uuid4().hex[:12]
        resuming = False

    # Use normalized URLs for the crawl
    crawl_urls = normalized_urls

    crawler = Crawler(config)

    # Determine whether to show Rich Live progress
    use_live = not config.quiet and sys.stderr.isatty()

    try:
        if use_live:
            from rich.live import Live
            from rich.text import Text

            with Live(
                "Starting crawl...",
                refresh_per_second=4,
                console=Console(stderr=True),
            ) as live:

                async def _update_progress():
                    while True:
                        elapsed = time.monotonic() - start_time
                        pages = crawler._pages_crawled
                        queue_size = crawler._queue.qsize()
                        live.update(
                            Text(
                                f"[{elapsed:.0f}s] {pages} pages crawled | queue: {queue_size} pending"
                            )
                        )
                        await asyncio.sleep(0.25)

                progress_task = asyncio.create_task(_update_progress())
                try:
                    await crawler.crawl(crawl_urls, run_id, resume=resuming, recrawl=recrawl)
                finally:
                    progress_task.cancel()
                    await asyncio.gather(progress_task, return_exceptions=True)
        else:
            await crawler.crawl(crawl_urls, run_id, resume=resuming, recrawl=recrawl)

        # Normal completion: update run status
        await update_run_status(config.database_path, run_id, "completed")
        logger.info("crawl_complete", run_id=run_id)

        # Auto-export JSONL if --export-jsonl was specified
        if export_jsonl:
            from crawlvox.storage import export_to_jsonl

            count = await export_to_jsonl(config.database_path, export_jsonl, run_id=run_id)
            if not config.quiet:
                typer.echo(f"Exported {count} records to {export_jsonl}", err=True)

        # Print end-of-crawl summary (unless --quiet)
        if not config.quiet:
            elapsed = time.monotonic() - start_time
            from crawlvox.storage import get_status_distribution
            status_dist = await get_status_distribution(config.database_path, run_id)
            _print_summary(
                pages_crawled=crawler._pages_crawled,
                elapsed=elapsed,
                db_path=config.database_path,
                export_path=export_jsonl,
                error_counts=crawler._error_counts or None,
                status_distribution=status_dist or None,
            )

    except asyncio.CancelledError:
        # Graceful shutdown (Ctrl+C) -- crawler already handled cleanup and user feedback
        await update_run_status(config.database_path, run_id, "interrupted")
        logger.info("crawl_interrupted", run_id=run_id)

        # Print summary even on interruption (unless --quiet)
        if not config.quiet:
            elapsed = time.monotonic() - start_time
            try:
                from crawlvox.storage import get_status_distribution
                status_dist = await get_status_distribution(config.database_path, run_id)
            except Exception:
                status_dist = None
            _print_summary(
                pages_crawled=crawler._pages_crawled,
                elapsed=elapsed,
                db_path=config.database_path,
                error_counts=crawler._error_counts or None,
                status_distribution=status_dist,
            )

    except Exception as e:
        # Unexpected error: mark as failed
        await update_run_status(config.database_path, run_id, "failed")
        logger.error("crawl_failed", run_id=run_id, error=str(e))
        raise


if __name__ == "__main__":
    app()
