"""Configuration for cacheguardian."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class PricingConfig:
    """Per-model pricing rates (per million tokens)."""

    base_input: float = 0.0
    cache_read: float = 0.0
    cache_write_5m: float = 0.0
    cache_write_1h: float = 0.0
    output: float = 0.0
    storage_per_hour: float = 0.0  # Gemini only


# Default pricing tables (as of Feb 2026)
# Source: https://platform.claude.com/docs/en/about-claude/pricing
ANTHROPIC_PRICING: dict[str, PricingConfig] = {
    # Opus 4.5 / 4.6 — same pricing tier
    "claude-opus-4-6": PricingConfig(
        base_input=5.00, cache_read=0.50, cache_write_5m=6.25,
        cache_write_1h=10.00, output=25.00,
    ),
    "claude-opus-4-5": PricingConfig(
        base_input=5.00, cache_read=0.50, cache_write_5m=6.25,
        cache_write_1h=10.00, output=25.00,
    ),
    # Opus 4 / 4.1 — same pricing tier
    "claude-opus-4-1": PricingConfig(
        base_input=15.00, cache_read=1.50, cache_write_5m=18.75,
        cache_write_1h=30.00, output=75.00,
    ),
    "claude-opus-4-20250514": PricingConfig(
        base_input=15.00, cache_read=1.50, cache_write_5m=18.75,
        cache_write_1h=30.00, output=75.00,
    ),
    # Sonnet 4 / 4.5 / 4.6 — same pricing tier
    "claude-sonnet-4-6": PricingConfig(
        base_input=3.00, cache_read=0.30, cache_write_5m=3.75,
        cache_write_1h=6.00, output=15.00,
    ),
    "claude-sonnet-4-5": PricingConfig(
        base_input=3.00, cache_read=0.30, cache_write_5m=3.75,
        cache_write_1h=6.00, output=15.00,
    ),
    "claude-sonnet-4-20250514": PricingConfig(
        base_input=3.00, cache_read=0.30, cache_write_5m=3.75,
        cache_write_1h=6.00, output=15.00,
    ),
    # Haiku 4.5
    "claude-haiku-4-5": PricingConfig(
        base_input=1.00, cache_read=0.10, cache_write_5m=1.25,
        cache_write_1h=2.00, output=5.00,
    ),
    # Haiku 3.5
    "claude-haiku-3-5": PricingConfig(
        base_input=0.80, cache_read=0.08, cache_write_5m=1.00,
        cache_write_1h=1.60, output=4.00,
    ),
}

OPENAI_PRICING: dict[str, PricingConfig] = {
    "gpt-4o": PricingConfig(
        base_input=2.50, cache_read=1.25, output=10.00,
    ),
    "gpt-4o-mini": PricingConfig(
        base_input=0.15, cache_read=0.075, output=0.60,
    ),
    "o1": PricingConfig(
        base_input=15.00, cache_read=7.50, output=60.00,
    ),
    "o3-mini": PricingConfig(
        base_input=1.10, cache_read=0.55, output=4.40,
    ),
}

GEMINI_PRICING: dict[str, PricingConfig] = {
    "gemini-2.5-flash": PricingConfig(
        base_input=0.15, cache_read=0.0375, output=0.60,
        storage_per_hour=4.50,
    ),
    "gemini-2.5-pro": PricingConfig(
        base_input=1.25, cache_read=0.3125, output=10.00,
        storage_per_hour=4.50,
    ),
}

ALL_PRICING: dict[str, dict[str, PricingConfig]] = {
    "anthropic": ANTHROPIC_PRICING,
    "openai": OPENAI_PRICING,
    "gemini": GEMINI_PRICING,
}


@dataclass
class CacheGuardConfig:
    """Configuration for cacheguardian middleware."""

    # General
    auto_fix: bool = True
    """Automatically apply safe optimizations (tool sorting, cache_control injection)."""

    strict_mode: bool = False
    """Raise exceptions on cache-breaking changes instead of just warning."""

    log_level: str = "INFO"
    """Logging level: DEBUG, INFO, WARNING, ERROR."""

    # TTL strategy
    ttl_strategy: str = "auto"
    """TTL selection: 'auto' (based on think time), '5m', '1h'."""

    # Privacy
    privacy_mode: bool = False
    """Add timing jitter to prevent cache-timing side-channel attacks."""

    privacy_jitter_ms: tuple[int, int] = (50, 200)
    """Range of jitter in milliseconds (min, max) for fixed jitter mode."""

    privacy_jitter_mode: str = "fixed"
    """Jitter mode: 'fixed' (constant range) or 'adaptive' (scales with response size)."""

    # OpenAI routing
    cache_key_fn: Optional[Callable[[Any], str]] = None
    """Function to derive prompt_cache_key for OpenAI (e.g., lambda ctx: f'{ctx.user_id}')."""

    # L2 backend
    l2_backend: Optional[str] = None
    """Redis URL for L2 distributed cache (e.g., 'redis://localhost:6379')."""

    # Pricing overrides
    pricing_overrides: dict[str, dict[str, PricingConfig]] = field(default_factory=dict)
    """Override default pricing: {'anthropic': {'model-name': PricingConfig(...)}}."""

    # Logging
    quiet_early_turns: int = 3
    """Suppress MISS logging during the first N turns (cold-start warmup)."""

    # Gemini
    gemini_explicit_threshold: int = 32768
    """Minimum estimated tokens before promoting to explicit Gemini cache.
    Below this, implicit caching (free of storage fees) is preferred."""

    # Model recommendations
    model_recommendations: bool = True
    """Suggest cheaper models when prompt is below current model's cache threshold.
    Only evaluates when log_level is DEBUG or INFO (skipped in production ERROR/WARNING mode)."""

    # Alerts
    min_cache_hit_rate: float = 0.7
    """Alert when session cache hit rate drops below this threshold."""

    def get_pricing(self, provider: str, model: str) -> PricingConfig:
        """Get pricing for a provider/model, checking overrides first."""
        overrides = self.pricing_overrides.get(provider, {})
        if model in overrides:
            return overrides[model]

        defaults = ALL_PRICING.get(provider, {})
        if model in defaults:
            return defaults[model]

        # Fuzzy match: try prefix matching for versioned model names
        for key, pricing in {**defaults, **overrides}.items():
            if model.startswith(key) or key.startswith(model):
                return pricing

        # Return zero pricing if model unknown (metrics still work, costs show 0)
        return PricingConfig()
