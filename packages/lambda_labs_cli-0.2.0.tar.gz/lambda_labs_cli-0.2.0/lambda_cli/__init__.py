"""Lambda Labs Cloud CLI."""
__version__ = "0.2.0"
