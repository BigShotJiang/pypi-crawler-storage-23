from flask import Flask,jsonify,render_template,request,url_for
import os
#import pathlib as p
import subprocess
from .filman import FilMan
app=Flask(__name__)
print(os.getcwd())
fm=FilMan("jjsr")
form= fm.form
@app.route("/",methods=["GET","POST"])
def home():
    nav= fm.Details(fm.File_Struct(os.getcwd()))
    return render_template("index.html",path=os.getcwd(),nav=nav)
@app.route("/themes")
def themes():
    return render_template("themes.html")
@app.route("/windows")
def js_windows():
    return render_template("jswindows.html")
@app.route("/file-manager-response",methods=["GET","POST"])
def file_manager_response():
    try:
        cwd= os.getcwd()
        if  request.method=="POST":
            path=request.form["path"]
            nano = request.form["nano"]
            terminal=request.form["terminal"]
            #print(f"++++++++ {terminal}")
            #print(f"The output is  \033[33m{nano}")
            form["nano"]=fm.FileRead(os.path.join(cwd,path)) if nano== "" else fm.WriteToFile(nano,os.path.join(cwd,path))
            form["terminal"]= "" if terminal=="" else fm.RunTerminal(terminal) 
            #print(f"++++++++====={form['terminal']}")
            return jsonify({"nano":form["nano"],
            "terminal":form["terminal"]})
        return  "No Nano"
    except BaseException as e:
        return str(e)
def main():
    app.run()
if __name__=="__main__":
    main()

