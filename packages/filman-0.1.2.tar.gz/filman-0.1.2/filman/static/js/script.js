//alert("script2");
let navs=document.querySelectorAll("[data-type='file']");
let currentpath="";
let path= document.querySelector("#path");
let selected =document.querySelector("#selected"); 
let nano = document.querySelector("#nano");
let terminal = document.querySelector("#terminal");
let commandHistory = document.querySelector("#history");
let commands = document.querySelector("#commands");
let nav=document.querySelector("#navigation-panel");
let navBtn= document.querySelector("#nav-btn");
let saveBtn= document.querySelector("#save-btn");
let runBtn= document.querySelector("#run-btn");
navBtn.onclick=function(){
//alert("hi");
try{
nav.classList.toggle("hide-element");
nav.classList.toggle("navigation-panel");
}catch(ee){
alert(ee);
}
}

class FileManagerUI{
constructor(name){
this.name=name;
}


sayHi(){
alert("Hi "+this.name);
}


CreateElem(tag,className,value, content,parent){
let elem= document.createElement(tag);
elem.classList.add(className);
elem.setAttribute("value",value);
elem.innerHTML = content;
parent.appendChild(elem);
return elem;
}


static NanoValue(text1,text2){
//alert(text);
nano.value= text1;
commandHistory.innerText += commands.value;
commandHistory.innerText+= text2;
 }


SendAjaxRequest(url,method,data){
try{
//let data =[];
let req=new XMLHttpRequest()
req.open(method,url)
req.setRequestHeader("Content-Type",
"application/x-www-form-urlencoded")
req.onreadystatechange=function(){
if(this.readyState==4 && this.status==200){
let output=JSON.parse(this.responseText);
//alert(output["terminal"]);
FileManagerUI.NanoValue(output["nano"],
output["terminal"]);
}

}
req.send(data);
}catch(err){
alert(err);
}
}
}
function ReturnPath(elem){
let path=[];
while(elem.dataset.name!='navigation'){
path.unshift(elem.dataset.name);
elem=elem.parentNode;
}
return path.join("/");
}


function main(){
try{
let fm= new FileManagerUI("JJSR");
for (let i of navs){
i.addEventListener("click",function(){
currentpath=ReturnPath(i);
document.querySelector(
"#total-path"
).innerHTML=currentpath
fm.SendAjaxRequest(MyConstants["url"],
MyConstants["method"],
"path="+currentpath+"&nano=&terminal=");

 });
}
saveBtn.addEventListener("click",function(){
fm.SendAjaxRequest(MyConstants["url"],
MyConstants["method"],
"path="+currentpath+"&nano="+encodeURIComponent(
nano.value)+"&terminal=");
});

runBtn.addEventListener("click",function(){
//alert("runBtn");
fm.SendAjaxRequest(MyConstants["url"],
MyConstants["method"],
"path="+currentpath+"&nano="+encodeURIComponent(
nano.value)+"&terminal="+encodeURIComponent(
commands.value));
});
}catch(e){
alert(e);
}
}
main();
