Various small utilities in Python.

Installation:

```
pip install pyjumble
```
