""" Author: Lionel Guez """

import string
import itertools

import numpy as np
from matplotlib import pyplot as plt, dates, ticker


def stairs2(values, bounds, ax=None, **kwargs):
    """bounds is a two-dimensional numpy array, following the CF
    convention.

    """
    if ax == None:
        fig, ax = plt.subplots()

    edges = np.hstack((bounds[:, 0], bounds[-1, 1]))
    return ax.stairs(values, edges, **kwargs)


def draw_bbox(xmin, xmax, ymin, ymax, colors="k", label=""):
    plt.hlines([ymin, ymax], xmin, xmax, colors=colors, label=label)
    plt.vlines([xmin, xmax], ymin, ymax, colors=colors)


def label_axes(fig, labels=None, loc=None, **kwargs):
    """
    Walks through axes and labels each.

    kwargs are collected and passed to `annotate`

    Parameters
    ----------
    fig : Figure
         Figure object to work on

    labels : iterable or None
        iterable of strings to use to label the axes.
        If None, lower case letters are used.

    loc : len=2 tuple of floats
        Where to put the label in axes-fraction units
    """
    if labels is None:
        labels = string.ascii_lowercase

    # re-use labels rather than stop labeling
    labels = itertools.cycle(labels)
    if loc is None:
        loc = (0.9, 0.9)
    for ax, lab in zip(fig.axes, labels):
        ax.annotate(lab, xy=loc, xycoords="axes fraction", **kwargs)


def xlabel_months(ax):
    ax.xaxis.set_major_locator(dates.MonthLocator())
    ax.xaxis.set_minor_locator(dates.MonthLocator(bymonthday=15))

    ax.xaxis.set_major_formatter(ticker.NullFormatter())
    ax.xaxis.set_minor_formatter(dates.DateFormatter("%b"))

    for tick in ax.xaxis.get_minor_ticks():
        tick.tick1line.set_markersize(0)
        tick.tick2line.set_markersize(0)
        tick.label1.set_horizontalalignment("center")


def plot_tail_distr(x, label=None, ax=None):
    """Plot the probability that X >= x."""

    x_sorted = np.sort(x)
    nx = np.size(x)

    if nx != 0:
        if ax is None:
            fig, ax = plt.subplots()
        ax.plot(x_sorted, np.arange(nx, 0, -1) / nx, label=label)

        print("minimum value:", x_sorted[0])
        print("maximum value:", x_sorted[-1])

    print("number of values:", nx, "\n")


def plot_distr_funct(x, label=None, ax=None):
    """Plot distribution function. x should be a Numpy array. label is
    used in legend."""

    x_sorted = np.sort(x)
    nx = np.size(x)

    if nx != 0:
        if ax is None:
            fig, ax = plt.subplots()
        ax.plot(x_sorted, (1 + np.arange(nx)) / nx, label=label)
        print("minimum value:", x_sorted[0])
        print("maximum value:", x_sorted[-1])

    print("number of values:", nx, "\n")


def fig_hist(xlabel, x, label=None):
    """Creates a complete figure with histogram. x and label can also be
    sequences."""

    fig, ax = plt.subplots()
    ax.hist(x, bins="auto", histtype="step", label=label)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("number of occurrences")
    if label is not None:
        ax.legend()
    return fig


def fig_distr_funct(xlabel, x, label=None):
    """Creates a complete figure with distribution function. x must be a
    sequence of Numpy arrays and label None or a sequence of strings.

    """

    fig, ax = plt.subplots()
    print(xlabel + ":")

    label_None = label is None
    if label_None:
        label = itertools.repeat(None)

    for xi, li in zip(x, label):
        plot_distr_funct(xi, li, ax)

    ax.set_xlabel(xlabel)
    ax.set_ylabel("distribution function")
    if not label_None:
        ax.legend()
    return fig, ax
