"""Circumventing issue 1179 of cartopy."""

import numpy as np
from numpy import ma
import cartopy.crs as ccrs
from cartopy.mpl import geoaxes

src_crs = ccrs.PlateCarree()


def wind_to_src_crs(u, v, lat, magnitude=None):
    if lat.ndim == 1 and u.ndim == 2:
        u_src_crs = u / np.cos(np.deg2rad(lat[:, np.newaxis]))
    else:
        u_src_crs = u / np.cos(np.deg2rad(lat))

    v_src_crs = v
    magn_src_crs = ma.sqrt(u_src_crs**2 + v_src_crs**2)

    if magnitude is None:
        magnitude = ma.sqrt(u**2 + v**2)

    my_ratio = magnitude / magn_src_crs
    return u_src_crs * my_ratio, v_src_crs * my_ratio


def plot(ax: geoaxes.GeoAxes, lon, lat, u, v, **kwargs):
    """lon, lat, u, v should be numpy arrays, not NetCDF4 variables
    nor xarray DataArray instances.

    """

    u_src_crs, v_src_crs = wind_to_src_crs(u, v, lat)
    quiver_return = ax.quiver(
        lon,
        lat,
        u_src_crs,
        v_src_crs,
        transform=src_crs,
        angles="xy",
        **kwargs
    )
    return quiver_return
