#!/usr/bin/env python3

# Author: Lionel GUEZ
# Note: it is also possible to use the "function" argument of set_[xy]scale.

from matplotlib import scale, transforms
import numpy as np
from numpy import ma


class PowerScale(scale.ScaleBase):
    """Scales strictly positive data.

    The scale function: y**exponent. The inverse scale function:
    y**(1/exponent).

    """

    name = "power"

    def __init__(self, axis, **kwargs):
        scale.ScaleBase.__init__(self)
        exponent = kwargs.pop("exponent", 1)

        if exponent == 0:
            raise ValueError("exponent must not be 0")

        self.exponent = exponent

    def get_transform(self):
        return self.PowerTransform(self.exponent)

    def set_default_locators_and_formatters(self, axis):
        pass

    def limit_range_for_scale(self, vmin, vmax, minpos):
        """
        Limit the domain to positive values.
        """
        return (vmin <= 0.0 and minpos or vmin, vmax <= 0.0 and minpos or vmax)

    class PowerTransform(transforms.Transform):
        input_dims = 1
        output_dims = 1
        is_separable = True

        def __init__(self, exponent):
            transforms.Transform.__init__(self)
            self.exponent = exponent

        def transform_non_affine(self, a):
            mask = a <= 0.0

            if mask.any():
                a = np.where(mask, np.nan, a)

            return a**self.exponent

        def inverted(self):
            return PowerScale.InvertedPowerTransform(self.exponent)

    class InvertedPowerTransform(transforms.Transform):
        input_dims = 1
        output_dims = 1
        is_separable = True

        def __init__(self, exponent):
            transforms.Transform.__init__(self)
            self.exponent = exponent

        def transform_non_affine(self, a):
            return a ** (1 / self.exponent)

        def inverted(self):
            return PowerScale.PowerTransform(self.exponent)


scale.register_scale(PowerScale)


class SineScale(scale.ScaleBase):
    r"""
    From Proplot.
    Axis scale that is linear in the *sine* of *x*. The axis limits are
    constrained to fall between ``-90`` and ``+90`` degrees. The scale
    function is as follows:

    .. math::

        y = \sin(\pi x/180)

    The inverse scale function is as follows:

    .. math::

        x = 180\arcsin(y)/\pi
    """

    #: The registered scale name
    name = "sine"

    def __init__(self, axis):
        scale.ScaleBase.__init__(self, axis)

    def get_transform(self):
        return SineTransform()

    def set_default_locators_and_formatters(self, axis):
        pass

    def limit_range_for_scale(self, vmin, vmax, minpos):
        """
        Return the range *vmin* and *vmax* limited to within +/-90 degrees
        (inclusive).
        """
        return max(vmin, -90), min(vmax, 90)


class SineTransform(transforms.Transform):
    input_dims = 1
    output_dims = 1
    is_separable = True
    has_inverse = True

    def __init__(self):
        transforms.Transform.__init__(self)

    def inverted(self):
        return InvertedSineTransform()

    def transform_non_affine(self, a):
        # NOTE: Critical to truncate valid range inside transform *and*
        # in limit_range_for_scale or get weird duplicate tick labels. This
        # is not necessary for positive-only scales because it is harder to
        # run up right against the scale boundaries.
        with np.errstate(divide="ignore", invalid="ignore"):
            m = ma.masked_where((a < -90) | (a > 90), a)

            if m.mask.any():
                return ma.sin(np.deg2rad(m))
            else:
                return np.sin(np.deg2rad(a))


class InvertedSineTransform(transforms.Transform):
    input_dims = 1
    output_dims = 1
    is_separable = True
    has_inverse = True

    def __init__(self):
        super().__init__()

    def inverted(self):
        return SineTransform()

    def transform_non_affine(self, a):
        with np.errstate(divide="ignore", invalid="ignore"):
            return np.rad2deg(np.arcsin(a))


scale.register_scale(SineScale)

if __name__ == "__main__":
    import matplotlib.pyplot as plt

    plt.figure()
    t = np.arange(-180.0, 180.0, 0.1)
    s = np.radians(t) / 2.0

    plt.plot(t, s, "-", lw=2)
    plt.gca().set_yscale("power", exponent=2)
    plt.grid(True)

    plt.show()
