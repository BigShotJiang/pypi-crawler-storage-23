.. include:: links.inc
.. include:: changes/contributors.inc

.. _whats_new:

What's new
==========

.. towncrier-draft-entries:: |release|

.. towncrier release notes start

Julearn 0.3.5 (2026-03-06)
--------------------------

Bugfixes
^^^^^^^^

- Fix parenthesis escaping in column names by `Synchon Mandal`_ (:gh:`226`)
- Fix :class:`.StratifiedBootstrap` behaviour to not leak test and train
  indices during splitting by `Synchon Mandal`_ (:gh:`254`)
- Fix a bug in which inspecting predictions from
  :class:`.ContinuousStratifiedKFold` would provide overlapping fold results by
  `Fede Raimondo`_ (:gh:`285`)
- Fix a bug in which the :class:`.PipelineInspector` will fail for pipelines
  with hyperparameter tuning by `Fede Raimondo`_ (:gh:`286`)
- Fix a bug in which inspecting predictions will result in NaNs if y had a
  custom index by `Fede Raimondo`_ (:gh:`288`)
- Change minimum scikit-learn version to 1.5.0 by `Fede Raimondo`_. (:gh:`291`)
- Fix a bug in which ``OptunaSearchCV`` would fail when expecting the ``group``
  parameter in the ``fit`` method by `Fede Raimondo`_. (:gh:`297`)
- Enable and use metadata routing for hyperparameter tuning estimators by `Fede
  Raimondo`_ (:gh:`298`)


API Changes
^^^^^^^^^^^

- Remove ``test_size`` and ``train_size`` parameters and change default value
  of ``n_splits`` from 5 to 200 for :class:`.StratifiedBootstrap` by `Synchon
  Mandal`_ (:gh:`254`)


Improved Documentation
^^^^^^^^^^^^^^^^^^^^^^

- Include documentation on how to use the `joblib`_ and `joblib-htcondor`_
  library to parallelize computation by `Fede Raimondo`_ (:gh:`278`)
- Update citation in README by `Synchon Mandal`_ (:gh:`279`)
- Update joblib usage docs by `Synchon Mandal`_ (:gh:`282`)
- Add JuRSE Code Pick shield in README by `Synchon Mandal`_ (:gh:`283`)


Enhancements
^^^^^^^^^^^^

- Avoid parallel calls in :class:`.FilterColumns` if not specified by the user
  in the :mod:`.config` module by `Fede Raimondo`_ (:gh:`277`)


Features
^^^^^^^^

- Add a new global config option ``"enable_auto_escape_parenthesis"`` to escape
  parenthesis in column names by `Synchon Mandal`_ (:gh:`226`)


Misc
^^^^

- Regular repository maintenance by updating ``.pre-commit-config.yaml``,
  replacing ``black`` with ``ruff-format``, updating tool configs and GitHub
  Actions workflows and dependency version constraints, dropping support for
  Python 3.8 and adding support for Python 3.12 and 3.13 by `Synchon Mandal`_
  (:gh:`284`)
- Update julearn.viz module to support param version 2.3.0 by `Fede Raimondo`_
  (:gh:`297`)
- Update versions of dependencies in pyproject.toml to support pandas 3.X.X,
  numpy 2.X.X and scikit-learn 1.8.X by `Fede Raimondo`_ (:gh:`299`)


Julearn 0.3.4 (2024-10-17)
--------------------------

Bugfixes
^^^^^^^^

- Fix usage of optuna distributions as hyperparameters in older versions of
  scikit-learn by `Fede Raimondo`_. (:gh:`268`)


Enhancements
^^^^^^^^^^^^

- Remove final model fit requirement for inspector to be returned by
  :func:`.run_cross_validation` by `Fede Raimondo`_. (:gh:`270`)
- Add :func:`.run_fit` that implements a model fitting procedure with the same
  API as :func:`.run_cross_validation` by `Fede Raimondo`_. (:gh:`271`)
- Optimise wrapping of steps and models in the pipeline only when a subset of
  features is being used, by `Fede Raimondo`_ (:gh:`274`)
- Place the final model CV split at the beginning instead of the end of the CV
  iterator wrapper by `Fede Raimondo`_ (:gh:`275`)
- Change the internal logic of :func:`.run_cross_validation` to optimise joblib
  calls by `Fede Raimondo`_ (:gh:`293`)


Julearn 0.3.3 (2024-05-16)
--------------------------

Bugfixes
^^^^^^^^

- Fix ``OptunaSearchCV`` issue
  (https://github.com/optuna/optuna-integration/issues/118) with an internal
  implementation until the issue is fixed in ``optuna-integration`` by `Fede
  Raimondo`_ (:gh:`265`)


Improved Documentation
^^^^^^^^^^^^^^^^^^^^^^

- Fixed a typo in cross validation by `Dante Culaciati`_ (:gh:`258`)


Julearn 0.3.2 (2024-05-03)
--------------------------

Bugfixes
^^^^^^^^

- Fix a bug in which tuning hyperparemters while using a target transformer
  will not work as a result of target transformation detection by `Fede
  Raimondo`_ (:gh:`249`)
- Update bokeh api calls to remove warnings by `Fede Raimondo`_ (:gh:`255`)


Improved Documentation
^^^^^^^^^^^^^^^^^^^^^^

- Update documentation on Hyperparameter Tuning by `Fede Raimondo`_ (:gh:`262`)


Enhancements
^^^^^^^^^^^^

- Add :class:`~skopt.BayesSearchCV` to the list of available searchers as
  'bayes' by `Fede Raimondo`_ (:gh:`260`)
- Refactor how hyperparmeters' distributions are specified by `Fede Raimondo`_
  (:gh:`262`)


Features
^^^^^^^^

- Add :class:`~optuna_integration.OptunaSearchCV` to the list of
  available searchers as ``optuna`` by `Fede Raimondo`_ (:gh:`262`)


Misc
^^^^

- Add a new GitHub Action to mark stale issues by `Synchon Mandal`_ (:gh:`224`)
- Add support for ``scikit-learn 1.4.x`` by `Synchon Mandal`_ (:gh:`244`)
- Remove ``pytest-lazy-fixture`` and enable support for ``pytest >= 8.0.0`` by
  `Synchon Mandal`_ (:gh:`251`)
- Add ``all`` as optional dependencies to install all functional dependencies
  by `Fede Raimondo`_ (:gh:`260`)


Julearn 0.3.1 (2024-01-23)
--------------------------

Bugfixes
^^^^^^^^

- Add ``BaseEstimator`` to ``ConfoundRemoval`` for Target by `Sami Hamdan`_
  (:gh:`151`)
- Skip wrapping scorers when target transformers can inverse transform and
  avoid logging filtered warnings by `Fede Raimondo`_ (:gh:`236`)
- Fix ``alternative`` parameter not being used in the corrected t-test `Fede
  Raimondo`_ (:gh:`245`)
- Fix hyperparameter not being set in ``PipelineCreator.add`` when an object is
  used as model, by `Fede Raimondo`_ (:gh:`247`)


Improved Documentation
^^^^^^^^^^^^^^^^^^^^^^

- Fix cross-referencing links in documentation by `Synchon Mandal`_ (:gh:`168`)
- Standardize ``Sphinx`` section and header ordering format by `Synchon
  Mandal`_ (:gh:`234`)
- Improve documentation language, fix typos and code snippets by `Synchon
  Mandal`_ (:gh:`235`)


Enhancements
^^^^^^^^^^^^

- Make CBPM use sum by default by `Sami Hamdan`_ (:gh:`170`)


Features
^^^^^^^^

- Add support for multiple grids in hyperparameter tuning by `Fede Raimondo`_
  (:gh:`47`)


Misc
^^^^

- Adopt ``ruff`` as the only linter for the codebase by `Synchon Mandal`_
  (:gh:`231`)
- Improve ``codespell`` support and fix typos in documentation by `Synchon
  Mandal`_ (:gh:`232`)
- Adopt ``pre-commit`` for adding and managing git pre-commit hooks by `Synchon
  Mandal`_ (:gh:`233`)


Julearn 0.3.0 (2023-07-19)
--------------------------

The general API and behavior of Julearn has been changed to make it easier to
define and use pipelines. The documentation has been updated to reflect these
changes. Basic functionality from the previous API is still
present. However, it might require setting a few more parameters in the
:func:`.run_cross_validation` function.


Julearn 0.2.5 (2022-07-21)
--------------------------

API Changes
^^^^^^^^^^^

- Make API surrounding registering consistently use overwrite by `Sami Hamdan`_
- Inner ``cv`` needs to be provided using ``search_params``. Deprecating ``cv`` in
  ``model_params`` by `Sami Hamdan`_ (:gh:`146`)
- Add ``n_jobs`` and ``verbose`` to ``run_cross_validation`` by `Sami Hamdan`_


Bugfixes
^^^^^^^^

- Fix a hyperparameters setting issue where the parameter had an iterable of
  only one element by `Sami Hamdan`_ (:gh:`96`)
- Fix installations instruction for latest development version (add ``--pre``)
  by `Fede Raimondo`_
- Fix target transformers that only normal transformers are wrapped by
  `Sami Hamdan`_ (:gh:`94`)
- Fix compatibility with new scikit-learn release 0.24 by `Sami Hamdan`_
  (:gh:`108`)
- Fix compatibility with multiprocessing in scikit-learn by `Sami Hamdan`_
- Raise error message when columns in the dataframe are nos strings by
  `Fede Raimondo`_ (:gh:`77`)
- Fix not implemented bug for decision_function in ExtendedDataFramePipeline by
  `Sami Hamdan`_ (:gh:`135`)
- Fix Bug in the transformer wrapper implementation by `Sami Hamdan`_
  (:gh:`122`)
- Fix Bug Target Transformer missing BaseEstimator by `Sami Hamdan`_ (:gh:`151`)
- Fix Bug of showing Warnings when using confound removal by `Sami Hamdan`_
  (:gh:`152`)
- Fix Bug registered scorer not working in dictionary for scoring by `Sami Hamdan`_


Improved Documentation
^^^^^^^^^^^^^^^^^^^^^^

- Add *What's new* section in DOC to document changes by `Fede Raimondo`_
- Add information on updating the *What's new* section before releasing by
  `Fede Raimondo`_
- Update docs to make it more uniform by `Kaustubh Patil`_
- Add example for ``tranform_until`` by `Shammi More`_ (:gh:`63`)
- Add documentation/example for parallelization by `Sami Hamdan`_


Enhancements
^^^^^^^^^^^^

- Bump minimum python version to 3.7 by `Fede Raimondo`_
- Refactor scoring to allow for registering and callable scorers by
  `Sami Hamdan`_
- Update :mod:`.model_selection` and add capabilities to register searchers by
  `Sami Hamdan`_
- Update default behavior of setting inner cv according to scikit-learn instead
  of using outer cv as default by `Sami Hamdan`_
- Add tests and more algorithms to ``DynamicSelection`` by `Sami Hamdan`_ and
  `Shammi More`_

Features
^^^^^^^^

- Add user facing ``create_pipeline`` function by `Sami Hamdan`_
- Add CV schemes for stratifying continuous variables, useful for
  regression problems. Check :class:`.ContinuousStratifiedKFold` and
  :class:`.RepeatedContinuousStratifiedKFold` by
  `Fede Raimondo`_ and `Shammi More`_
- Add ``CBPM`` transformer by `Sami Hamdan`_
- Add ``register_model`` by `Sami Hamdan`_ (:gh:`105`)
