"""Entry point for `python -m ghst`."""

from ghst.cli import main

main()
