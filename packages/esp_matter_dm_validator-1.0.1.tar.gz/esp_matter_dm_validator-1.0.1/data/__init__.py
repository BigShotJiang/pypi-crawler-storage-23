"""
Package marker for validation data resources.
"""

