# ctrl+code

Adaptive coding harness with differential fuzzing - transforms AI slop into production-ready code.

**NOTE**: *This is **beta** software, there are rough edges. Please report anything you find*

## Configuration

ctrl+code follows platform conventions for config and data storage:

| Platform | Config | Data | Cache |
|----------|--------|------|-------|
| **Linux** | `~/.config/ctrlcode/` | `~/.local/share/ctrlcode/` | `~/.cache/ctrlcode/` |
| **macOS** | `~/Library/Application Support/ctrlcode/` | `~/Library/Application Support/ctrlcode/` | `~/Library/Caches/ctrlcode/` |
| **Windows** | `%APPDATA%\ctrlcode\` | `%LOCALAPPDATA%\ctrlcode\` | `%LOCALAPPDATA%\ctrlcode\Cache\` |

### Environment Variables

Override default directories:
- `CTRLCODE_CONFIG_DIR`: Config file location
- `CTRLCODE_DATA_DIR`: Session logs and persistent data
- `CTRLCODE_CACHE_DIR`: Conversation storage and temp files

### Configuration File

Copy `config.example.toml` to your config directory as `config.toml` and fill in your API keys.

### Agent Instructions (AGENT.md)

Customize agent behavior with `AGENT.md` files, loaded hierarchically:

1. **Global** (`~/.config/ctrlcode/AGENT.md`) - Your personal defaults across all projects
2. **Project** (`<workspace>/AGENT.md`) - Project-specific instructions

Example global `AGENT.md`:
```markdown
# Global Agent Defaults

- Always use semantic commit messages
- Show tool results explicitly
- Prefer built-in tools over scripts
```

Example project `AGENT.md`:
```markdown
# MyProject Instructions

## Architecture
- Frontend: React + TypeScript
- Backend: FastAPI + PostgreSQL

## Style
- Use async/await for all I/O
- Prefer functional components
```

Instructions are injected into the system prompt, giving the agent context about your preferences and project structure.

## Installation

```bash
pip install ctrlcode
```

## Usage

Start the TUI (auto-launches server):
```bash
ctrlcode
```

Or start server separately:
```bash
ctrlcode-server
```
