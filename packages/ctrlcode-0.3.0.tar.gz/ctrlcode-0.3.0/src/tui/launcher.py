"""Server subprocess lifecycle management."""

import asyncio
import os
import shutil
import subprocess
import sys
from pathlib import Path
import httpx


class ServerLauncher:
    """Manages server subprocess lifecycle."""

    def __init__(self, server_url: str = "http://127.0.0.1:8765", api_key: str | None = None):
        self.server_url = server_url
        self.api_key = api_key
        self.process: subprocess.Popen | None = None
        self.launched_by_us = False

    def _validate_executable(self, exe_name: str) -> Path:
        """
        Validate and locate a trusted executable.

        Args:
            exe_name: Name of executable to find

        Returns:
            Absolute path to validated executable

        Raises:
            ValueError: If executable not found or untrusted
        """
        # Find executable using shutil.which (respects PATH)
        exe_path = shutil.which(exe_name)

        if not exe_path:
            raise ValueError(f"Executable '{exe_name}' not found in PATH")

        exe_path = Path(exe_path).resolve()

        # Validate executable is in expected locations
        # Allow: virtualenv bin, user bin, system bin
        trusted_prefixes = [
            Path(sys.prefix) / "bin",  # Virtual environment
            Path(sys.prefix) / "Scripts",  # Windows venv
            Path.home() / ".local" / "bin",  # User installs
            Path("/usr/local/bin"),  # System-wide
            Path("/usr/bin"),  # System
        ]

        # Check if executable is under any trusted prefix
        is_trusted = any(
            exe_path.is_relative_to(prefix)
            for prefix in trusted_prefixes
            if prefix.exists()
        )

        if not is_trusted:
            raise ValueError(
                f"Executable '{exe_path}' is not in a trusted location. "
                f"Expected in: {', '.join(str(p) for p in trusted_prefixes if p.exists())}"
            )

        # Verify it's an executable file
        if not exe_path.is_file():
            raise ValueError(f"'{exe_path}' is not a file")

        if not os.access(exe_path, os.X_OK):
            raise ValueError(f"'{exe_path}' is not executable")

        return exe_path

    async def ensure_server_running(self) -> bool:
        """Check if server is running, launch if needed."""
        # Try to connect to existing server
        if await self._check_server_alive():
            return True  # Already running

        # Validate executable before launching
        try:
            server_exe = self._validate_executable("ctrlcode-server")
        except ValueError as e:
            print(f"Security error: {e}")
            return False

        # Launch server subprocess with validated executable
        self.process = subprocess.Popen(
            [str(server_exe)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True  # Detach from parent
        )
        self.launched_by_us = True

        # Wait for server to be ready (max 5 seconds)
        for _ in range(50):  # 50 * 0.1s = 5s
            await asyncio.sleep(0.1)
            if await self._check_server_alive():
                return True

        # Failed to start
        return False

    async def _check_server_alive(self) -> bool:
        """Ping server to check if it's responsive."""
        try:
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"

            async with httpx.AsyncClient(timeout=1.0) as client:
                # Use ping method for health check
                response = await client.post(
                    f"{self.server_url}/rpc",
                    json={"jsonrpc": "2.0", "method": "ping", "id": 0},
                    headers=headers
                )
                return response.status_code == 200
        except (httpx.ConnectError, httpx.TimeoutException):
            return False

    async def shutdown(self):
        """Shutdown server if we launched it."""
        if self.launched_by_us and self.process:
            self.process.terminate()
            try:
                await asyncio.wait_for(
                    asyncio.to_thread(self.process.wait),
                    timeout=5.0
                )
            except asyncio.TimeoutError:
                self.process.kill()
                await asyncio.to_thread(self.process.wait)
