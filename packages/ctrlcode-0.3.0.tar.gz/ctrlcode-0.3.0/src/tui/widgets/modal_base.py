"""Base class for modal overlays."""

from textual import events
from textual.screen import Screen
from textual.widgets import Static
from textual.containers import Container


class ModalBase(Screen):
    """
    Base class for modal overlays.

    Features:
    - Overlays on top of main UI
    - Press ESC to close
    - 80% width/height by default
    - Border and background styling
    """

    DEFAULT_CSS = """
    ModalBase {
        align: center middle;
    }

    ModalBase > Container {
        width: 80%;
        height: 80%;
        border: thick $primary;
        background: $surface;
    }

    ModalBase .modal-title {
        background: $primary;
        color: $text;
        padding: 0 1;
        text-align: center;
        width: 100%;
    }

    ModalBase .modal-content {
        height: 1fr;
        overflow-y: auto;
    }

    ModalBase .modal-footer {
        background: $surface-darken-1;
        color: $text-muted;
        padding: 0 1;
        text-align: center;
    }
    """

    def on_key(self, event: events.Key):
        """Close modal on ESC."""
        if event.key == "escape":
            self.dismiss()

    def compose(self):
        """Override in subclasses - wrap in Container."""
        with Container():
            yield Static("Modal Base - Override compose()", classes="modal-title")
            yield Static("Press ESC to close", classes="modal-footer")
