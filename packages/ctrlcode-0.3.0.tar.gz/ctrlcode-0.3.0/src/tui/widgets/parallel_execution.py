"""Parallel execution progress widget."""

from textual.widgets import Static


class ParallelExecutionWidget(Static):
    """Display progress bars for parallel task execution."""

    DEFAULT_CSS = """
    ParallelExecutionWidget {
        height: auto;
        max-height: 10;
        background: $surface;
        border: solid $accent;
        padding: 1;
        overflow-y: auto;
    }
    """

    def __init__(self, *args, **kwargs):
        """Initialize parallel execution widget."""
        super().__init__(*args, **kwargs)
        self.tasks: dict[str, dict] = {}

    def render(self) -> str:
        """Render parallel execution progress."""
        if not self.tasks:
            return "[bold]Parallel Execution[/]\n[dim]No parallel tasks[/]"

        lines = ["[bold]Parallel Execution[/]", f"Running {len(self.tasks)} tasks in parallel:", ""]

        for task_id, info in self.tasks.items():
            progress = info.get("progress", 0.0)
            description = info.get("description", task_id)
            status = info.get("status", "in_progress")

            # Build progress bar
            bar_width = 20
            filled = int(progress * bar_width)
            empty = bar_width - filled
            progress_bar = f"[{'█' * filled}{'░' * empty}]"

            # Status indicator
            if status == "completed":
                status_text = "[green]✓[/]"
            elif status == "error":
                status_text = "[red]✗[/]"
            else:
                status_text = "[cyan]⏳[/]"

            # Task line
            desc_short = description[:30] + "..." if len(description) > 30 else description
            lines.append(f"{status_text} {progress_bar} {desc_short} ({int(progress * 100)}%)")

        return "\n".join(lines)

    def set_tasks(self, task_ids: list[str]):
        """
        Initialize progress bars for parallel tasks.

        Args:
            task_ids: List of task identifiers
        """
        self.tasks = {
            task_id: {
                "progress": 0.0,
                "description": task_id,
                "status": "in_progress"
            }
            for task_id in task_ids
        }
        self.refresh()

    def update_task_progress(self, task_id: str, progress: float, description: str = ""):
        """
        Update task progress.

        Args:
            task_id: Task identifier
            progress: Progress value (0.0 to 1.0)
            description: Optional task description
        """
        if task_id in self.tasks:
            self.tasks[task_id]["progress"] = min(1.0, max(0.0, progress))
            if description:
                self.tasks[task_id]["description"] = description
            self.refresh()

    def complete_task(self, task_id: str):
        """
        Mark task as complete.

        Args:
            task_id: Task identifier
        """
        if task_id in self.tasks:
            self.tasks[task_id]["progress"] = 1.0
            self.tasks[task_id]["status"] = "completed"
            self.refresh()

    def error_task(self, task_id: str):
        """
        Mark task as errored.

        Args:
            task_id: Task identifier
        """
        if task_id in self.tasks:
            self.tasks[task_id]["status"] = "error"
            self.refresh()

    def clear(self):
        """Clear all tasks."""
        self.tasks.clear()
        self.refresh()
