"""Variant comparison widget."""

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Label, Static


class VariantComparison(Vertical):
    """Widget showing side-by-side variant comparison."""

    def __init__(self, **kwargs):
        """Initialize variant comparison widget."""
        super().__init__(**kwargs)
        self.variants: list[tuple[str, str]] = []  # (code, quality_info)

    def compose(self) -> ComposeResult:
        """Compose widget."""
        yield Label("[bold magenta]Variant Comparison[/]", id="variant-title")
        with Horizontal(id="variant-columns"):
            with Vertical(id="variant-1"):
                yield Label("[cyan]Variant 1[/]")
                yield Static("", id="variant-1-code")
            with Vertical(id="variant-2"):
                yield Label("[cyan]Variant 2[/]")
                yield Static("", id="variant-2-code")
            with Vertical(id="variant-3"):
                yield Label("[cyan]Variant 3[/]")
                yield Static("", id="variant-3-code")

    def update_variants(self, variants: list[tuple[str, str]]) -> None:
        """
        Update variant displays.

        Args:
            variants: List of (code, quality_info) tuples
        """
        self.variants = variants

        for i, (code, quality) in enumerate(variants[:3], 1):
            code_widget = self.query_one(f"#variant-{i}-code", Static)
            # Truncate code for display
            truncated = code[:300] + "\n..." if len(code) > 300 else code
            code_widget.update(f"```python\n{truncated}\n```\n\n{quality}")

    def clear(self) -> None:
        """Clear all variants."""
        for i in range(1, 4):
            code_widget = self.query_one(f"#variant-{i}-code", Static)
            code_widget.update("")
        self.variants = []
