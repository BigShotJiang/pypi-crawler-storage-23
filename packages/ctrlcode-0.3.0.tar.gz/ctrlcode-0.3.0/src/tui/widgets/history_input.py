"""Input widget with arrow key history navigation."""

from textual.events import Key
from textual.widgets import Input


class HistoryInput(Input):
    """Input widget with up/down arrow key navigation through message history."""

    def __init__(self, *args, **kwargs):
        """Initialize input with empty history."""
        super().__init__(*args, **kwargs)
        self.history: list[str] = []  # Index 0 = most recent
        self.history_index: int = -1  # -1 = not navigating
        self.draft: str = ""  # Save current input when entering history mode

    def _on_key(self, event: Key) -> None:
        """Intercept arrow keys for history navigation."""
        if event.key == "up":
            self._navigate_history_up()
            event.prevent_default()
        elif event.key == "down":
            self._navigate_history_down()
            event.prevent_default()
        else:
            # Any other key exits history navigation
            if self.history_index != -1:
                self.history_index = -1
                self.draft = ""
            super()._on_key(event)

    def _navigate_history_up(self) -> None:
        """Navigate to older message in history."""
        if not self.history:
            return

        # First time entering history mode - save draft
        if self.history_index == -1:
            self.draft = self.value
            self.history_index = 0
        # Move to older message
        elif self.history_index < len(self.history) - 1:
            self.history_index += 1

        self.value = self.history[self.history_index]
        self.cursor_position = len(self.value)

    def _navigate_history_down(self) -> None:
        """Navigate to newer message in history."""
        if self.history_index <= 0:
            # At newest or not navigating - restore draft
            self.value = self.draft
            self.cursor_position = len(self.value)
            self.history_index = -1
            self.draft = ""
        else:
            # Move to newer message
            self.history_index -= 1
            self.value = self.history[self.history_index]
            self.cursor_position = len(self.value)

    def add_to_history(self, message: str) -> None:
        """Add a new user message to history (most recent first)."""
        if message:
            self.history.insert(0, message)

    def load_history(self, messages: list[str]) -> None:
        """Load history from list (most recent first)."""
        self.history = messages.copy()

    def clear_history(self) -> None:
        """Clear all history."""
        self.history = []
        self.history_index = -1
        self.draft = ""
