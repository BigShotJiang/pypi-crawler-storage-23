"""Event bus viewer modal - shows all workflow events."""

import time
from datetime import datetime
from textual import events
from textual.widgets import Static, Label
from textual.containers import VerticalScroll

from ..modal_base import ModalBase


class EventItem(Static):
    """Single event in the bus viewer."""

    DEFAULT_CSS = """
    EventItem {
        height: auto;
        padding: 1;
        border-bottom: solid $surface-lighten-1;
    }

    EventItem .event-timestamp {
        color: $text-muted;
    }

    EventItem .event-type {
        color: $primary;
        text-style: bold;
    }

    EventItem .event-data {
        color: $text;
        padding-left: 2;
    }
    """

    def __init__(self, event: dict):
        super().__init__()
        self.event = event

    def compose(self):
        timestamp = datetime.fromtimestamp(self.event["timestamp"]).strftime("%H:%M:%S")
        event_type = self.event["type"]
        event_data = self.event["data"]

        # Format timestamp and type
        yield Label(f"[{timestamp}] {event_type}", classes="event-type")

        # Format data (pretty print)
        for key, value in event_data.items():
            yield Label(f"  {key}: {value}", classes="event-data")


class StatusModal(ModalBase):
    """
    Event bus viewer - shows all workflow events in real-time.

    Features:
    - Scrollable event list
    - Auto-scroll (toggle with Space)
    - Shows timestamp, type, and data for each event
    - Real-time updates as events arrive
    """

    DEFAULT_CSS = """
    StatusModal {
        width: 90%;
        height: 90%;
    }

    StatusModal .event-list {
        height: 1fr;
        overflow-y: auto;
    }
    """

    def __init__(self, event_history: list[dict]):
        super().__init__()
        self.events = event_history
        self.auto_scroll = True

    def compose(self):
        from textual.containers import Container

        with Container():
            yield Static("Event Bus Stream", classes="modal-title")

            # Event list container
            with VerticalScroll(classes="event-list"):
                for event in self.events:
                    yield EventItem(event)

            # Footer with auto-scroll indicator
            footer_text = "[Auto-scroll ON] Press Space to toggle, ESC to close"
            yield Static(footer_text, classes="modal-footer")

    def on_key(self, event: events.Key):
        """Handle keyboard shortcuts."""
        if event.key == "escape":
            self.dismiss()
        elif event.key == "space":
            # Toggle auto-scroll
            self.auto_scroll = not self.auto_scroll
            status = "ON" if self.auto_scroll else "OFF"
            footer = self.query_one(".modal-footer", Static)
            footer.update(f"[Auto-scroll {status}] Press Space to toggle, ESC to close")
            event.prevent_default()

    def add_event(self, event: dict):
        """
        Add new event to the stream.

        Called when workflow emits new event while modal is open.
        """
        self.events.append(event)

        # Add to UI
        event_list = self.query_one(".event-list", VerticalScroll)
        event_list.mount(EventItem(event))

        # Auto-scroll to bottom if enabled
        if self.auto_scroll:
            event_list.scroll_end(animate=False)
