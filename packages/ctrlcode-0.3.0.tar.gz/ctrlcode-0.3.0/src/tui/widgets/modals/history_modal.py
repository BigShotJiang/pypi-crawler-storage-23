"""History modal - shows historical learning metrics."""

from textual.widgets import Static
from textual.containers import VerticalScroll

from ..modal_base import ModalBase


class HistoryModal(ModalBase):
    """
    Shows historical learning metrics.

    Displays:
    - Oracle reuse rate and savings
    - Bug pattern detection stats
    - Test clustering effectiveness
    - Cache performance
    - Storage metrics
    """

    DEFAULT_CSS = """
    HistoryModal {
        width: 70%;
        height: 70%;
    }

    HistoryModal .metric-excellent {
        color: $success;
    }

    HistoryModal .metric-good {
        color: #00ff00;
    }

    HistoryModal .metric-fair {
        color: $warning;
    }

    HistoryModal .metric-low {
        color: $error;
    }

    HistoryModal .section-header {
        text-style: bold;
        padding-top: 1;
    }

    HistoryModal .metric-label {
        color: $text-muted;
    }
    """

    def __init__(self, history_data: dict):
        super().__init__()
        self.history_data = history_data

    def compose(self):
        from textual.containers import Container

        with Container():
            yield Static("📊 Historical Learning Metrics", classes="modal-title")

            with VerticalScroll(classes="modal-content"):
                # Session statistics
                yield Static("Session Statistics", classes="section-header")
                total_sessions = self.history_data.get("total_sessions", 0)
                sessions_with_reuse = self.history_data.get("sessions_with_oracle_reuse", 0)
                oracle_reuse_rate = self.history_data.get("oracle_reuse_rate", 0.0)

                yield Static(f"  Total fuzzing sessions: {total_sessions}")
                yield Static(f"  Sessions with oracle reuse: {sessions_with_reuse}")

                # Oracle reuse rate with color coding
                if oracle_reuse_rate >= 0.3:
                    rate_class = "metric-excellent"
                    rate_label = "EXCELLENT"
                elif oracle_reuse_rate >= 0.2:
                    rate_class = "metric-good"
                    rate_label = "GOOD"
                elif oracle_reuse_rate >= 0.1:
                    rate_class = "metric-fair"
                    rate_label = "FAIR"
                else:
                    rate_class = "metric-low"
                    rate_label = "LOW"

                yield Static(
                    f"  Oracle reuse rate: {oracle_reuse_rate:.1%} ({rate_label})",
                    classes=rate_class
                )

                # Efficiency gains
                yield Static("Efficiency Gains", classes="section-header")
                token_savings = self.history_data.get("estimated_token_savings", 0)
                time_savings = self.history_data.get("estimated_time_savings_seconds", 0.0)
                llm_calls_saved = self.history_data.get("estimated_llm_call_savings", 0)

                yield Static(
                    f"  💰 Token savings: {token_savings:,} tokens",
                    classes="metric-excellent" if token_savings > 0 else ""
                )
                yield Static(
                    f"  ⚡ Time saved: {time_savings:.1f}s ({time_savings / 60:.1f} min)",
                    classes="metric-excellent" if time_savings > 0 else ""
                )
                yield Static(
                    f"  🔄 LLM calls avoided: {llm_calls_saved}",
                    classes="metric-excellent" if llm_calls_saved > 0 else ""
                )

                # Bug detection
                if "total_bugs_in_db" in self.history_data:
                    yield Static("Bug Pattern Detection", classes="section-header")
                    total_bugs = self.history_data.get("total_bugs_in_db", 0)
                    bug_warnings = self.history_data.get("sessions_with_bug_warnings", 0)
                    bug_detection_rate = self.history_data.get("bug_detection_rate", 0.0)

                    yield Static(f"  Bug patterns in database: {total_bugs}")
                    yield Static(f"  Sessions with warnings: {bug_warnings}")
                    if bug_detection_rate > 0:
                        yield Static(
                            f"  Detection rate: {bug_detection_rate:.1%}",
                            classes="metric-excellent"
                        )

                # Test statistics
                if "total_tests" in self.history_data:
                    yield Static("Test Execution", classes="section-header")
                    total_tests = self.history_data.get("total_tests", 0)
                    avg_tests_per_session = self.history_data.get("avg_tests_per_session", 0.0)
                    avg_pass_rate = self.history_data.get("avg_test_pass_rate", 0.0)

                    yield Static(f"  Total tests executed: {total_tests}")
                    yield Static(f"  Avg tests per session: {avg_tests_per_session:.1f}")
                    if avg_pass_rate > 0:
                        pass_class = "metric-excellent" if avg_pass_rate >= 0.9 else "metric-good"
                        yield Static(
                            f"  Avg test pass rate: {avg_pass_rate:.1%}",
                            classes=pass_class
                        )

                # Cache performance
                if "cache_stats" in self.history_data:
                    yield Static("Cache Performance", classes="section-header")
                    cache = self.history_data["cache_stats"]
                    cache_size = cache.get("size", 0)
                    cache_hits = cache.get("hits", 0)
                    cache_misses = cache.get("misses", 0)
                    cache_hit_rate = cache.get("hit_rate", 0.0)

                    yield Static(f"  Cache size: {cache_size} oracles")
                    yield Static(f"  Hits: {cache_hits}")
                    yield Static(f"  Misses: {cache_misses}")

                    if cache_hit_rate > 0:
                        hit_class = "metric-excellent" if cache_hit_rate >= 0.5 else "metric-good"
                        yield Static(
                            f"  Hit rate: {cache_hit_rate:.1%}",
                            classes=hit_class
                        )

                # Storage metrics
                if "vector_store_size" in self.history_data:
                    yield Static("Storage", classes="section-header")
                    vs_size = self.history_data.get("vector_store_size", 0)
                    code_embeddings = self.history_data.get("total_code_embeddings", 0)
                    oracle_embeddings = self.history_data.get("total_oracle_embeddings", 0)

                    yield Static(f"  Vector store size: {vs_size} embeddings")
                    yield Static(f"  Code embeddings: {code_embeddings}")
                    yield Static(f"  Oracle embeddings: {oracle_embeddings}")

                # Quality metrics
                if "avg_oracle_quality" in self.history_data:
                    yield Static("Quality Metrics", classes="section-header")
                    oracle_quality = self.history_data.get("avg_oracle_quality", 0.0)
                    session_quality = self.history_data.get("avg_session_quality", 0.0)

                    if oracle_quality > 0:
                        quality_class = "metric-excellent" if oracle_quality >= 0.9 else "metric-good"
                        yield Static(
                            f"  Avg oracle quality: {oracle_quality:.2f}/1.0",
                            classes=quality_class
                        )
                    if session_quality > 0:
                        yield Static(f"  Avg session quality: {session_quality:.2f}/1.0")

                # Empty state
                if total_sessions == 0:
                    yield Static("")
                    yield Static("  No fuzzing sessions recorded yet.", classes="metric-label")
                    yield Static("  Start fuzzing to build historical knowledge!", classes="metric-label")

            yield Static("Press ESC to close", classes="modal-footer")
