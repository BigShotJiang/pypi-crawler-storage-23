"""Metrics modal - shows observability results."""

from textual.widgets import Static
from textual.containers import VerticalScroll

from ..modal_base import ModalBase


class MetricsModal(ModalBase):
    """
    Shows observability results.

    Displays:
    - Test results (passed/failed)
    - Performance metrics (latency percentiles)
    - Log analysis (errors/warnings)
    - Final recommendation
    """

    DEFAULT_CSS = """
    MetricsModal {
        width: 70%;
        height: 70%;
    }

    MetricsModal .metric-pass {
        color: $success;
    }

    MetricsModal .metric-fail {
        color: $error;
    }

    MetricsModal .metric-warn {
        color: $warning;
    }

    MetricsModal .section-header {
        text-style: bold;
        padding-top: 1;
    }
    """

    def __init__(self, metrics: dict):
        super().__init__()
        self.metrics = metrics

    def compose(self):
        from textual.containers import Container

        with Container():
            yield Static("Observability Results", classes="modal-title")

            with VerticalScroll(classes="modal-content"):
                # Tests
                if "tests" in self.metrics:
                    yield Static("Tests", classes="section-header")
                    tests = self.metrics["tests"]
                    passed = tests.get("passed", 0)
                    failed = tests.get("failed", 0)
                    duration = tests.get("duration", "")

                    pass_class = "metric-pass" if failed == 0 else "metric-fail"
                    yield Static(f"  ✅ {passed} passed", classes="metric-pass")
                    if failed > 0:
                        yield Static(f"  ❌ {failed} failed", classes="metric-fail")
                    if duration:
                        yield Static(f"  Duration: {duration}")

                # Performance
                if "performance" in self.metrics:
                    yield Static("Performance", classes="section-header")
                    perf = self.metrics["performance"]
                    threshold = perf.get("threshold", 200)

                    for percentile in ["p50", "p95", "p99"]:
                        if percentile in perf:
                            value = perf[percentile]
                            status = "✅" if value < threshold else "⚠️"
                            status_class = "metric-pass" if value < threshold else "metric-warn"
                            yield Static(
                                f"  {percentile}: {value}ms {status} (< {threshold}ms)",
                                classes=status_class
                            )

                # Logs
                if "logs" in self.metrics:
                    yield Static("Logs", classes="section-header")
                    logs = self.metrics["logs"]
                    errors = logs.get("errors", 0)
                    warnings = logs.get("warnings", 0)

                    if errors == 0:
                        yield Static(f"  Errors: {errors}", classes="metric-pass")
                    else:
                        yield Static(f"  Errors: {errors}", classes="metric-fail")

                    if warnings == 0:
                        yield Static(f"  Warnings: {warnings}", classes="metric-pass")
                    else:
                        yield Static(f"  Warnings: {warnings}", classes="metric-warn")

                # Recommendation
                if "recommendation" in self.metrics:
                    yield Static("Recommendation", classes="section-header")
                    rec = self.metrics["recommendation"]
                    if rec.lower() == "approve":
                        yield Static(f"  ✅ {rec.upper()}", classes="metric-pass")
                    else:
                        yield Static(f"  ❌ {rec.upper()}", classes="metric-fail")

            yield Static("Press ESC to close", classes="modal-footer")
