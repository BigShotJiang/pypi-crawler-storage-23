"""Review modal - shows reviewer feedback."""

from textual.widgets import Static
from textual.containers import VerticalScroll

from ..modal_base import ModalBase


class FeedbackItem(Static):
    """Single feedback item from reviewer."""

    DEFAULT_CSS = """
    FeedbackItem {
        height: auto;
        padding: 1;
        border-bottom: solid $surface-lighten-1;
    }

    FeedbackItem .severity-blocker {
        color: $error;
        text-style: bold;
    }

    FeedbackItem .severity-error {
        color: $warning;
    }

    FeedbackItem .severity-info {
        color: $text-muted;
    }

    FeedbackItem .file-location {
        color: $primary;
    }

    FeedbackItem .fix-status-fixed {
        color: $success;
    }

    FeedbackItem .fix-status-in_progress {
        color: $warning;
    }
    """

    def __init__(self, feedback: dict):
        super().__init__()
        self.feedback = feedback

    def compose(self):
        severity = self.feedback.get("severity", "info")
        file_path = self.feedback.get("file", "")
        line = self.feedback.get("line", "")
        message = self.feedback.get("message", "")
        suggestion = self.feedback.get("suggestion", "")
        status = self.feedback.get("status", "pending")

        # Icon and severity
        icon = "🔴" if severity == "blocker" else "🟡" if severity == "error" else "🟢"
        severity_class = f"severity-{severity}"

        yield Static(f"{icon} {severity.upper()}", classes=severity_class)

        # File location
        if file_path:
            location = f"File: {file_path}:{line}" if line else f"File: {file_path}"
            yield Static(location, classes="file-location")

        # Message
        yield Static(f"Issue: {message}")

        # Suggestion
        if suggestion:
            yield Static(f"Recommendation: {suggestion}")

        # Fix status
        status_icon = "✅" if status == "fixed" else "⏳" if status == "in_progress" else "⏸"
        status_class = f"fix-status-{status}"
        yield Static(f"Status: {status_icon} {status.capitalize()}", classes=status_class)


class ReviewModal(ModalBase):
    """
    Shows reviewer feedback items.

    Displays:
    - Severity (blocker, error, info)
    - File location
    - Issue description
    - Fix recommendation
    - Fix status
    """

    DEFAULT_CSS = """
    ReviewModal {
        width: 80%;
        height: 80%;
    }
    """

    def __init__(self, feedback_items: list[dict]):
        super().__init__()
        self.feedback = feedback_items

    def compose(self):
        from textual.containers import Container

        with Container():
            yield Static("Review Feedback", classes="modal-title")

            # Feedback list
            with VerticalScroll(classes="modal-content"):
                if not self.feedback:
                    yield Static("No feedback items", classes="severity-info")
                else:
                    for item in self.feedback:
                        yield FeedbackItem(item)

            yield Static("Press ESC to close", classes="modal-footer")
