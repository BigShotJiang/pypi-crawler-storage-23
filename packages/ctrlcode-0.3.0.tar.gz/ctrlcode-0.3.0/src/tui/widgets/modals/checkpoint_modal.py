"""Checkpoint pause modal for workflow execution."""

from textual.containers import Container
from textual.widgets import Static, Button

from ..modal_base import ModalBase


class CheckpointModal(ModalBase):
    """Modal that pauses workflow and asks user to continue or abort."""

    DEFAULT_CSS = """
    CheckpointModal Button {
        margin: 1 2;
    }

    CheckpointModal .checkpoint-description {
        padding: 1 2;
        background: $surface-darken-1;
        margin: 1 0;
    }

    CheckpointModal .task-list {
        padding: 0 2;
        margin: 0 0 1 0;
        color: $text-muted;
    }

    CheckpointModal .section-label {
        color: $accent;
        text-style: bold;
        padding: 0 2;
        margin-top: 1;
    }

    CheckpointModal .progress-info {
        color: $text-muted;
        text-style: italic;
        padding: 0 2;
        margin-bottom: 1;
    }
    """

    def __init__(
        self,
        checkpoint_id: str,
        description: str,
        completed_tasks: list[str],
        next_tasks: list[str],
        progress: str,
    ):
        """Initialize checkpoint modal.

        Args:
            checkpoint_id: Unique checkpoint ID
            description: Planner's checkpoint description
            completed_tasks: Task descriptions just completed
            next_tasks: Task descriptions coming next
            progress: Progress string e.g. "Group 1 of 3 complete"
        """
        super().__init__()
        self.checkpoint_id = checkpoint_id
        self.description = description
        self.completed_tasks = completed_tasks
        self.next_tasks = next_tasks
        self.progress = progress

    def compose(self):
        """Compose modal widgets."""
        with Container():
            yield Static("⏸  Checkpoint", classes="modal-title")

            with Container(classes="checkpoint-description"):
                yield Static(self.description)

            if self.progress:
                yield Static(self.progress, classes="progress-info")

            if self.completed_tasks:
                yield Static("Completed:", classes="section-label")
                with Container(classes="task-list"):
                    for task in self.completed_tasks:
                        yield Static(f"  ✓ {task}")

            if self.next_tasks:
                yield Static("Up next:", classes="section-label")
                with Container(classes="task-list"):
                    for task in self.next_tasks:
                        yield Static(f"  → {task}")

            with Container():
                yield Button("▶  Continue", id="continue", variant="success")
                yield Button("✗  Abort", id="abort", variant="error")

            yield Static(
                "[dim]Continue to proceed with the next group, or Abort to stop here.[/dim]",
                classes="modal-footer"
            )

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        action = "continue" if event.button.id == "continue" else "abort"

        try:
            await self.app.client.send_checkpoint_response(self.checkpoint_id, action)
        except Exception as e:
            self.app.notify(f"Failed to send checkpoint response: {e}", severity="error")

        self.dismiss()
