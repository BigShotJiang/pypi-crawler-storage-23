"""Todo list modal widget."""

from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.containers import Vertical, VerticalScroll
from textual.widgets import Static, Label
from textual.binding import Binding


class TodoModal(ModalScreen):
    """Modal screen for displaying todo list."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=True),
        Binding("enter", "dismiss", "Close", show=False),
        Binding("q", "dismiss", "Close", show=False),
    ]

    CSS = """
    TodoModal {
        align: center middle;
    }

    #todo-dialog {
        width: auto;
        min-width: 50;
        max-width: 100;
        height: auto;
        max-height: 30;
        background: $panel;
        border: thick $primary;
        padding: 1 2;
    }

    #todo-title {
        width: 100%;
        content-align: center middle;
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }

    #todo-list {
        width: 100%;
        height: auto;
        max-height: 20;
        border: solid $accent;
        background: $background;
        padding: 1;
    }

    .todo-item {
        width: 100%;
        height: auto;
        padding: 0 1;
        margin-bottom: 1;
    }

    .todo-pending {
        color: $text;
    }

    .todo-in_progress {
        color: $warning;
    }

    .todo-completed {
        color: $success;
    }

    #empty-state {
        width: 100%;
        height: auto;
        content-align: center middle;
        color: $text-muted;
        padding: 2;
    }
    """

    def __init__(self, todos: list[dict], **kwargs):
        """
        Initialize todo modal.

        Args:
            todos: List of todo items
        """
        super().__init__(**kwargs)
        self.todos = todos

    def compose(self) -> ComposeResult:
        """Compose modal layout."""
        with Vertical(id="todo-dialog"):
            yield Label("📋 Todo List", id="todo-title")

            if not self.todos:
                yield Static("No todos yet. Use todo_write to create tasks.", id="empty-state")
            else:
                with VerticalScroll(id="todo-list"):
                    for todo in self.todos:
                        yield self._render_todo(todo)

    def _render_todo(self, todo: dict) -> Static:
        """
        Render a single todo item.

        Args:
            todo: Todo dict with content, status, priority

        Returns:
            Static widget with formatted todo
        """
        status = todo.get("status", "pending")
        priority = todo.get("priority", "medium")
        content = todo.get("content", "")

        # Status icon
        status_icon = {
            "pending": "○",
            "in_progress": "◐",
            "completed": "●",
        }.get(status, "○")

        # Priority indicator
        priority_marker = {
            "high": "🔴",
            "medium": "🟡",
            "low": "🟢",
        }.get(priority, "🟡")

        # Format text with markup
        text = f"{status_icon} {priority_marker} {content}"

        return Static(text, classes=f"todo-item todo-{status}")

    def action_dismiss(self) -> None:
        """Dismiss the modal."""
        self.dismiss()
