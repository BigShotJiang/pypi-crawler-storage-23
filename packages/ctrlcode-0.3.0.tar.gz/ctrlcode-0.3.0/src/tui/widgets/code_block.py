"""Collapsible code block widget for file contents."""

from textual.app import ComposeResult
from textual.containers import Container
from textual.widgets import Static
from textual.reactive import reactive


class CollapsibleCodeBlock(Container, can_focus=True):
    """A collapsible code block widget."""

    DEFAULT_CSS = """
    CollapsibleCodeBlock {
        width: 100%;
        background: $surface-darken-1;
        margin: 0;
        margin-bottom: 1;
        padding: 1;
    }

    CollapsibleCodeBlock.collapsed {
        height: auto;
    }

    CollapsibleCodeBlock.expanded {
        height: auto;
        max-height: 30;
        overflow-y: auto;
    }

    CollapsibleCodeBlock .code-header {
        color: $text;
        text-style: bold;
    }

    CollapsibleCodeBlock .code-content {
        margin-top: 1;
        color: $text;
    }

    CollapsibleCodeBlock .code-preview {
        color: $text-muted;
        margin-top: 1;
    }
    """

    expanded = reactive(False)

    def __init__(self, path: str, content: str, **kwargs):
        """
        Initialize collapsible code block.

        Args:
            path: File path
            content: Full file content
            **kwargs: Additional widget arguments
        """
        super().__init__(**kwargs)
        self.path = path
        self.content = content
        self.lines = content.splitlines()
        self.add_class("collapsed")

    def compose(self) -> ComposeResult:
        """Compose widget with header and content."""
        # Count tokens (rough estimate: 1 token ≈ 4 chars)
        token_count = len(self.content) // 4

        # Header with file info
        header = f"📄 {self.path} ({len(self.lines)} lines, ~{token_count} tokens)"
        yield Static(header, classes="code-header")

        # Show preview or full content based on state
        if self.expanded:
            yield Static(self.content, classes="code-content")
        else:
            # Show first 3 lines + indicator
            preview_lines = self.lines[:3]
            remaining = len(self.lines) - 3
            if remaining > 0:
                preview = "\n".join(preview_lines) + f"\n... ({remaining} more lines)"
            else:
                preview = "\n".join(preview_lines)
            yield Static(preview, classes="code-preview")

    def toggle(self) -> None:
        """Toggle expanded/collapsed state."""
        self.expanded = not self.expanded
        if self.expanded:
            self.remove_class("collapsed")
            self.add_class("expanded")
        else:
            self.remove_class("expanded")
            self.add_class("collapsed")

        # Remove old content and recompose
        self.remove_children()
        self.mount(*self.compose())

    def on_click(self) -> None:
        """Toggle on click."""
        self.toggle()
