"""Single-line status bar at top of TUI."""

from textual.widgets import Static


class StatusLine(Static):
    """
    Single-line status display at top of TUI.

    Shows current state:
    - Idle: "Ready"
    - Single-agent: "Thinking..." | "Running: read_file"
    - Workflow: "Workflow: Planning [25%]"
    - Error: "Error: Task failed - /status for details"
    """

    DEFAULT_CSS = """
    StatusLine {
        background: $primary;
        color: $text;
        padding: 0 1;
        text-align: left;
    }
    """

    def __init__(self):
        super().__init__()
        self.set_idle()

    def set_idle(self):
        """Reset to idle state."""
        self.update("Ready")

    def set_single_agent(self, status: str):
        """Set status for single-agent mode."""
        self.update(status)

    def set_workflow(self, phase: str, progress: float, active_agents: int = 0):
        """
        Set status for workflow mode.

        Args:
            phase: Current phase (planning, execution, review, validation)
            progress: Progress 0.0 to 1.0
            active_agents: Number of active agents
        """
        progress_pct = int(progress * 100)

        if active_agents > 0:
            self.update(
                f"Workflow: {phase.capitalize()} [{progress_pct}%] - {active_agents} agents active"
            )
        else:
            self.update(f"Workflow: {phase.capitalize()} [{progress_pct}%]")

    def set_error(self, message: str):
        """Show error state."""
        self.update(f"Error: {message} - /status for details")
