"""Agent activity panel widget."""

from textual.widgets import Static


class AgentActivityPanel(Static):
    """Display active agents and their status."""

    DEFAULT_CSS = """
    AgentActivityPanel {
        width: 30;
        height: 1fr;
        background: $panel;
        border: solid $accent;
        padding: 1;
        overflow-y: auto;
    }
    """

    def __init__(self, *args, **kwargs):
        """Initialize agent activity panel."""
        super().__init__(*args, **kwargs)
        self.agents: dict[str, dict] = {}

    def render(self) -> str:
        """Render agent activity panel."""
        if not self.agents:
            return "[bold]Active Agents[/]\n\n[dim]No active agents[/]"

        lines = ["[bold]Active Agents[/]", ""]

        for agent_id, info in self.agents.items():
            agent_type = info.get("type", "unknown")
            status = info.get("status", "pending")
            task = info.get("task", "")
            progress = info.get("progress", 0.0)

            # Status icon
            if status == "completed":
                icon = "✓"
                color = "green"
            elif status == "in_progress":
                icon = "⏳"
                color = "cyan"
            elif status == "error":
                icon = "✗"
                color = "red"
            elif status == "waiting":
                icon = "⏸"
                color = "yellow"
            else:
                icon = "○"
                color = "dim"

            # Agent line
            lines.append(f"[{color}]{icon} {agent_type.title()}[/]")

            # Task info
            if task:
                task_short = task[:40] + "..." if len(task) > 40 else task
                lines.append(f"  └─ {task_short}")

            # Progress
            if status == "in_progress" and progress > 0:
                lines.append(f"  └─ {int(progress * 100)}%")

            lines.append("")  # Blank line between agents

        return "\n".join(lines)

    def add_agent(self, agent_id: str, agent_type: str):
        """
        Add agent to active list.

        Args:
            agent_id: Unique agent identifier
            agent_type: Type of agent (planner, coder, reviewer, etc.)
        """
        self.agents[agent_id] = {
            "type": agent_type,
            "status": "pending",
            "task": "",
            "progress": 0.0,
        }
        self.refresh()

    def update_agent(self, agent_id: str, status: str, task: str = "", progress: float = 0.0):
        """
        Update agent status and progress.

        Args:
            agent_id: Agent identifier
            status: Agent status (pending, in_progress, completed, error, waiting)
            task: Current task description
            progress: Progress value (0.0 to 1.0)
        """
        if agent_id in self.agents:
            self.agents[agent_id]["status"] = status
            self.agents[agent_id]["task"] = task
            self.agents[agent_id]["progress"] = progress
            self.refresh()

    def remove_agent(self, agent_id: str):
        """
        Remove completed agent from list.

        Args:
            agent_id: Agent identifier
        """
        if agent_id in self.agents:
            del self.agents[agent_id]
            self.refresh()

    def clear(self):
        """Clear all agents."""
        self.agents.clear()
        self.refresh()
