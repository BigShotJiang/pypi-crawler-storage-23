"""Review feedback display widget."""

from textual.widgets import Static


class ReviewFeedbackWidget(Static):
    """Display reviewer feedback with severity indicators."""

    DEFAULT_CSS = """
    ReviewFeedbackWidget {
        height: auto;
        max-height: 15;
        background: $surface;
        border: solid $warning;
        padding: 1;
        overflow-y: auto;
    }
    """

    def __init__(self, *args, **kwargs):
        """Initialize review feedback widget."""
        super().__init__(*args, **kwargs)
        self.feedback_items: list[dict] = []

    def render(self) -> str:
        """Render review feedback."""
        if not self.feedback_items:
            return "[bold]🔍 Review Feedback[/]\n[dim]No feedback[/]"

        lines = ["[bold]🔍 Review Feedback[/]", ""]

        for item in self.feedback_items:
            _feedback_id = item.get("id", "")
            severity = item.get("severity", "info")
            file_path = item.get("file", "")
            line_no = item.get("line", "")
            message = item.get("message", "")
            suggestion = item.get("suggestion", "")
            fix_status = item.get("fix_status", "pending")

            # Severity indicator
            if severity == "blocker":
                indicator = "🔴 BLOCKER"
                color = "red"
            elif severity == "error":
                indicator = "🟡 ERROR"
                color = "yellow"
            else:
                indicator = "🟢 INFO"
                color = "blue"

            lines.append(f"[{color}]{indicator}[/]")

            # File location
            if file_path:
                location = f"{file_path}"
                if line_no:
                    location += f":{line_no}"
                lines.append(f"File: {location}")

            # Message
            lines.append(message)

            # Suggestion
            if suggestion:
                lines.append(f"Fix: {suggestion}")

            # Fix status
            if fix_status == "fixed":
                lines.append("[green]Status: ✓ Fixed[/]")
            elif fix_status == "in_progress":
                lines.append("[cyan]Status: ⏳ Coder addressing...[/]")
            else:
                lines.append("[dim]Status: Pending[/]")

            lines.append("")  # Separator

        return "\n".join(lines)

    def add_feedback(self, feedback: dict):
        """
        Add feedback item.

        Args:
            feedback: Feedback dict with keys: id, severity, file, line, message, suggestion
        """
        # Generate ID if not provided
        if "id" not in feedback:
            import uuid
            feedback["id"] = str(uuid.uuid4())[:8]

        # Set default fix status
        if "fix_status" not in feedback:
            feedback["fix_status"] = "pending"

        self.feedback_items.append(feedback)
        self.refresh()

    def update_feedback_status(self, feedback_id: str, status: str):
        """
        Update fix status for feedback item.

        Args:
            feedback_id: Feedback item identifier
            status: New status (pending, in_progress, fixed)
        """
        for item in self.feedback_items:
            if item.get("id") == feedback_id:
                item["fix_status"] = status
                break
        self.refresh()

    def clear_feedback(self):
        """Clear all feedback items."""
        self.feedback_items.clear()
        self.refresh()
