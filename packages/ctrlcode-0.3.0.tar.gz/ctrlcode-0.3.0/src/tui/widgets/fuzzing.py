"""Fuzzing progress widget."""

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Label, ProgressBar, Static


class FuzzingProgress(Vertical):
    """Widget showing fuzzing iteration progress."""

    def __init__(self, **kwargs):
        """Initialize fuzzing progress widget."""
        super().__init__(**kwargs)
        self.iteration = 0
        self.max_iterations = 5
        self.variants_tested = 0
        self.quality_score = 0.0

    def compose(self) -> ComposeResult:
        """Compose widget."""
        yield Label("[bold cyan]Fuzzing Progress[/]", id="fuzzing-title")
        yield Static("", id="fuzzing-status")
        yield ProgressBar(total=self.max_iterations, show_eta=False, id="fuzzing-bar")
        yield Static("", id="fuzzing-metrics")

    def update_progress(
        self,
        iteration: int,
        max_iterations: int,
        variants_tested: int,
        quality_score: float,
    ) -> None:
        """
        Update fuzzing progress.

        Args:
            iteration: Current iteration number
            max_iterations: Maximum iterations
            variants_tested: Total variants tested
            quality_score: Current quality score (0-1)
        """
        self.iteration = iteration
        self.max_iterations = max_iterations
        self.variants_tested = variants_tested
        self.quality_score = quality_score

        status_widget = self.query_one("#fuzzing-status", Static)
        status_widget.update(
            f"Iteration: {iteration}/{max_iterations} | Variants: {variants_tested}"
        )

        bar = self.query_one("#fuzzing-bar", ProgressBar)
        bar.update(total=max_iterations, progress=iteration)

        metrics_widget = self.query_one("#fuzzing-metrics", Static)
        score_color = "green" if quality_score > 0.8 else "yellow" if quality_score > 0.5 else "red"
        metrics_widget.update(f"Quality Score: [{score_color}]{quality_score:.2f}[/]")

    def reset(self) -> None:
        """Reset fuzzing progress."""
        self.update_progress(0, self.max_iterations, 0, 0.0)
