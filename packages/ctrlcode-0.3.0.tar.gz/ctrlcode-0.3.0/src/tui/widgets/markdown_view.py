"""Markdown view widget for assistant messages."""

from textual.app import ComposeResult
from textual.containers import Container
from textual.widgets import Static, Markdown


class MarkdownView(Container):
    """Renders assistant messages with full markdown support."""

    DEFAULT_CSS = """
    MarkdownView {
        width: 100%;
        height: auto;
        margin: 0 0 1 0;
        padding: 0 1;
        background: $background;
    }

    MarkdownView .md-header {
        color: $text;
        text-style: bold;
        height: auto;
        margin: 0;
        padding: 0;
    }

    MarkdownView Markdown {
        margin: 0;
        padding: 0;
        height: auto;
    }

    /* --- Reset all sub-widget margins to prevent whitespace explosion --- */

    MarkdownView MarkdownH1 {
        color: $accent;
        text-style: bold;
        margin: 1 0 0 0;
        padding: 0;
    }

    MarkdownView MarkdownH2 {
        color: $accent;
        text-style: bold;
        margin: 1 0 0 0;
        padding: 0;
    }

    MarkdownView MarkdownH3,
    MarkdownView MarkdownH4,
    MarkdownView MarkdownH5,
    MarkdownView MarkdownH6 {
        color: $accent;
        margin: 1 0 0 0;
        padding: 0;
    }

    MarkdownView MarkdownParagraph {
        margin: 0;
        padding: 0;
    }

    MarkdownView MarkdownFence {
        background: $surface-darken-1;
        margin: 0;
        padding: 1;
    }

    MarkdownView MarkdownBlockQuote {
        background: $surface;
        border-left: thick $primary;
        margin: 0;
        padding: 0 1;
    }

    MarkdownView MarkdownBulletList {
        margin: 0;
        padding: 0 0 0 2;
    }

    MarkdownView MarkdownOrderedList {
        margin: 0;
        padding: 0 0 0 2;
    }

    MarkdownView MarkdownListItem {
        margin: 0;
        padding: 0;
    }

    MarkdownView MarkdownHorizontalRule {
        margin: 0;
        padding: 0;
        height: 1;
    }

    MarkdownView MarkdownTable {
        margin: 0;
    }
    """

    def __init__(self, content: str, header: str = "[bold green]Assistant:[/]", **kwargs):
        """Initialize markdown view.

        Args:
            content: Markdown text to render.
            header: Rich markup header label.
        """
        super().__init__(**kwargs)
        self._md_content = content
        self._header = header

    def compose(self) -> ComposeResult:
        yield Static(self._header, markup=True, classes="md-header")
        yield Markdown(self._md_content)

    def update_content(self, text: str) -> None:
        """Replace the markdown body with new text."""
        self._md_content = text
        try:
            md_widget = self.query_one(Markdown)
            md_widget.update(text)
        except Exception:
            pass
