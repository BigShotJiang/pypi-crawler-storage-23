"""Tool inspection panel widget."""

from textual.app import ComposeResult
from textual.containers import Vertical, VerticalScroll
from textual.widgets import Label, RichLog


class ToolPanel(Vertical):
    """Widget showing tool calls and results."""

    def __init__(self, **kwargs):
        """Initialize tool panel."""
        super().__init__(**kwargs)

    def compose(self) -> ComposeResult:
        """Compose widget."""
        yield Label("[bold yellow]Tool Calls[/]", id="tool-panel-title")
        with VerticalScroll():
            yield RichLog(id="tool-log", highlight=True, markup=True)

    def log_tool_call(
        self, tool: str, call_id: str, args: dict | None = None
    ) -> None:
        """
        Log a tool call.

        Args:
            tool: Tool name
            call_id: Unique call identifier
            args: Tool arguments
        """
        log = self.query_one("#tool-log", RichLog)
        log.write(f"[bold cyan]→ {tool}[/]")
        if args:
            log.write(f"  [dim]ID: {call_id[:8]}...[/]")
            for key, value in args.items():
                log.write(f"  [yellow]{key}:[/] {value}")
        log.write("")

    def log_tool_result(self, call_id: str, result: str) -> None:
        """
        Log a tool result.

        Args:
            call_id: Tool call identifier
            result: Tool result (truncated if long)
        """
        log = self.query_one("#tool-log", RichLog)
        truncated = result[:200] + "..." if len(result) > 200 else result
        log.write(f"[bold green]← Result[/] [dim]({call_id[:8]}...)[/]")
        log.write(f"  {truncated}")
        log.write("")

    def clear(self) -> None:
        """Clear tool log."""
        log = self.query_one("#tool-log", RichLog)
        log.clear()
