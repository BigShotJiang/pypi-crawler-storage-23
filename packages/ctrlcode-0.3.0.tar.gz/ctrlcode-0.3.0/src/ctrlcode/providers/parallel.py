"""Parallel execution of provider calls for fuzzing."""

import asyncio
from typing import Any
from dataclasses import dataclass

from .base import Provider


@dataclass
class ProviderOutput:
    """Result from a provider execution."""

    code: str
    provider_name: str
    variant_id: str
    tokens: int
    elapsed_time: float
    quality_score: float = 0.0


class ParallelExecutor:
    """Execute multiple provider calls in parallel."""

    @staticmethod
    async def execute_all(
        variants: list[dict[str, Any]],
        providers: list[Provider],
        context: list[dict[str, Any]],
    ) -> list[ProviderOutput]:
        """
        Execute variants across providers in parallel.

        Args:
            variants: List of variant prompts/parameters
            providers: List of provider instances to use
            context: Conversation context messages

        Returns:
            List of outputs from all executions
        """
        tasks = []

        for i, variant in enumerate(variants):
            # Round-robin across providers
            provider = providers[i % len(providers)]
            task = ParallelExecutor._execute_variant(
                provider=provider,
                variant=variant,
                variant_id=f"v{i}",
                context=context,
            )
            tasks.append(task)

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter out exceptions and return successful results
        outputs: list[ProviderOutput] = []
        for result in results:
            if isinstance(result, Exception):
                # Log error but continue
                print(f"Variant execution failed: {result}")
                continue
            outputs.append(result)  # type: ignore[arg-type]

        return outputs

    @staticmethod
    async def _execute_variant(
        provider: Provider,
        variant: dict[str, Any],
        variant_id: str,
        context: list[dict[str, Any]],
    ) -> ProviderOutput:
        """Execute a single variant."""
        import time

        start_time = time.time()
        tokens_used = 0
        generated_text = []

        # Build messages with variant prompt
        messages = context + [{"role": "user", "content": variant["prompt"]}]

        # Stream from provider
        async for event in provider.stream(  # type: ignore[attr-defined]
            messages,
            temperature=variant.get("temperature", 0.8),
            top_p=variant.get("top_p", 0.95),
        ):
            if event.type == "text":
                generated_text.append(event.data["text"])
            elif event.type == "usage":
                tokens_used = event.data.get("usage", {}).get("total_tokens", 0)

        elapsed = time.time() - start_time

        return ProviderOutput(
            code="".join(generated_text),
            provider_name=provider.__class__.__name__,
            variant_id=variant_id,
            tokens=tokens_used,
            elapsed_time=elapsed,
        )
