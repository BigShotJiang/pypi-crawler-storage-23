"""AST-based structural code comparison."""

import ast
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ASTDiff:
    """Result of AST comparison."""

    variant_id: str
    has_syntax_error: bool = False
    error_message: Optional[str] = None
    function_count: int = 0
    class_count: int = 0
    import_count: int = 0
    complexity_estimate: int = 0
    structural_similarity: float = 0.0
    differences: list[str] = field(default_factory=list)


class ASTAnalyzer:
    """Analyzes code structure using Python AST."""

    def compare(self, baseline: str, variant: str, variant_id: str) -> ASTDiff:
        """
        Compare AST structures of baseline and variant.

        Args:
            baseline: Baseline code
            variant: Variant code
            variant_id: Identifier for variant

        Returns:
            ASTDiff with comparison results
        """
        # Parse baseline
        try:
            baseline_ast = ast.parse(baseline)
            baseline_stats = self._analyze_ast(baseline_ast)
        except SyntaxError as e:
            return ASTDiff(
                variant_id=variant_id,
                has_syntax_error=True,
                error_message=f"Baseline syntax error: {e}"
            )

        # Parse variant
        try:
            variant_ast = ast.parse(variant)
            variant_stats = self._analyze_ast(variant_ast)
        except SyntaxError as e:
            return ASTDiff(
                variant_id=variant_id,
                has_syntax_error=True,
                error_message=f"Variant syntax error: {e}"
            )

        # Compare structures
        differences = self._find_differences(baseline_stats, variant_stats)
        similarity = self._calculate_similarity(baseline_stats, variant_stats)

        return ASTDiff(
            variant_id=variant_id,
            has_syntax_error=False,
            function_count=variant_stats["functions"],
            class_count=variant_stats["classes"],
            import_count=variant_stats["imports"],
            complexity_estimate=variant_stats["complexity"],
            structural_similarity=similarity,
            differences=differences,
        )

    def _analyze_ast(self, tree: ast.AST) -> dict[str, int]:
        """
        Analyze AST and extract statistics.

        Args:
            tree: AST tree

        Returns:
            Dict with structural stats
        """
        stats = {
            "functions": 0,
            "classes": 0,
            "imports": 0,
            "complexity": 0,
            "loops": 0,
            "conditionals": 0,
            "try_blocks": 0,
        }

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                stats["functions"] += 1
            elif isinstance(node, ast.ClassDef):
                stats["classes"] += 1
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                stats["imports"] += 1
            elif isinstance(node, (ast.For, ast.While)):
                stats["loops"] += 1
                stats["complexity"] += 1
            elif isinstance(node, ast.If):
                stats["conditionals"] += 1
                stats["complexity"] += 1
            elif isinstance(node, ast.Try):
                stats["try_blocks"] += 1
                stats["complexity"] += 1

        return stats

    def _find_differences(
        self,
        baseline_stats: dict[str, int],
        variant_stats: dict[str, int]
    ) -> list[str]:
        """Find structural differences between baseline and variant."""
        differences = []

        for key in baseline_stats:
            baseline_val = baseline_stats[key]
            variant_val = variant_stats[key]

            if baseline_val != variant_val:
                diff = variant_val - baseline_val
                sign = "+" if diff > 0 else ""
                differences.append(f"{key}: {baseline_val} → {variant_val} ({sign}{diff})")

        return differences

    def _calculate_similarity(
        self,
        baseline_stats: dict[str, int],
        variant_stats: dict[str, int]
    ) -> float:
        """
        Calculate structural similarity score.

        Returns:
            Similarity score between 0.0 (completely different) and 1.0 (identical)
        """
        total_diff = 0
        total_magnitude = 0

        for key in baseline_stats:
            baseline_val = baseline_stats[key]
            variant_val = variant_stats[key]

            # Absolute difference
            diff = abs(variant_val - baseline_val)
            total_diff += diff

            # Maximum of the two values
            total_magnitude += max(baseline_val, variant_val)

        if total_magnitude == 0:
            return 1.0  # Both empty

        # Similarity = 1 - (normalized difference)
        similarity = 1.0 - (total_diff / max(total_magnitude, 1))
        return max(0.0, min(1.0, similarity))
