"""Bug pattern detection using historical fuzzing results."""

import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

from ..embeddings.embedder import CodeEmbedder
from ..embeddings.vector_store import VectorStore
from ..storage.history_db import BugPattern, HistoryDB

logger = logging.getLogger(__name__)


@dataclass
class DetectedPattern:
    """A similar bug pattern detected in historical data."""

    bug_id: str
    description: str
    code_snippet: str
    severity: str
    similarity: float
    session_id: str

    @property
    def confidence(self) -> str:
        """Confidence level based on similarity."""
        if self.similarity >= 0.9:
            return "HIGH"
        elif self.similarity >= 0.8:
            return "MEDIUM"
        else:
            return "LOW"


class BugPatternDetector:
    """Detects similar bug patterns in code using historical fuzzing data.

    Before fuzzing new code, search for similar bugs in history and warn
    the user if risky patterns are detected. This enables proactive bug
    prevention based on past failures.
    """

    def __init__(
        self,
        history_db: HistoryDB,
        embedder: Optional[CodeEmbedder] = None,
        similarity_threshold: float = 0.75,
    ):
        """Initialize bug pattern detector.

        Args:
            history_db: History database with bug patterns
            embedder: Optional code embedder (created if not provided)
            similarity_threshold: Minimum similarity for pattern matching (default: 0.75)
        """
        self.history_db = history_db
        self.embedder = embedder or CodeEmbedder()
        self.similarity_threshold = similarity_threshold

    def check_patterns(self, code: str) -> list[DetectedPattern]:
        """Check code for similar historical bug patterns.

        Args:
            code: Code to check for risky patterns

        Returns:
            List of similar bug patterns found, sorted by similarity (descending)
        """
        # Embed the code
        code_embedding = self.embedder.embed_code(code)

        # Get all historical bug patterns
        bug_records = self.history_db.get_all_bug_embeddings(limit=1000)

        if not bug_records:
            logger.debug("No historical bug patterns in database")
            return []

        # Build vector store from bug embeddings
        vector_store = VectorStore(dimension=code_embedding.shape[0])

        embeddings = np.array([bug.embedding for bug in bug_records])
        ids = [bug.bug_id for bug in bug_records]

        vector_store.add(embeddings, ids)

        # Search for similar bugs
        results = vector_store.search(
            code_embedding,
            k=10,
            min_similarity=self.similarity_threshold,
        )

        if not results:
            logger.debug(f"No similar bugs found above threshold {self.similarity_threshold}")
            return []

        # Convert to DetectedPattern instances
        detected_patterns = []

        for bug_id, similarity in results:
            # Find the bug record
            bug_record = next((b for b in bug_records if b.bug_id == bug_id), None)
            if not bug_record:
                continue

            pattern = DetectedPattern(
                bug_id=bug_record.bug_id,
                description=bug_record.bug_description,
                code_snippet=bug_record.code_snippet,
                severity=bug_record.severity,
                similarity=similarity,
                session_id=bug_record.session_id,
            )
            detected_patterns.append(pattern)

        logger.info(f"Detected {len(detected_patterns)} similar bug patterns")
        return detected_patterns

    def format_warnings(self, patterns: list[DetectedPattern]) -> str:
        """Format detected patterns as human-readable warnings.

        Args:
            patterns: List of detected patterns

        Returns:
            Formatted warning message
        """
        if not patterns:
            return ""

        lines = ["⚠️  SIMILAR BUG PATTERNS DETECTED", ""]

        for i, pattern in enumerate(patterns[:5], 1):  # Limit to top 5
            lines.append(f"{i}. {pattern.description}")
            lines.append(f"   Severity: {pattern.severity}")
            lines.append(f"   Confidence: {pattern.confidence} ({pattern.similarity:.1%} similar)")
            lines.append(f"   Code snippet:")
            lines.append(f"   ```")
            for line in pattern.code_snippet.split("\n")[:5]:  # First 5 lines
                lines.append(f"   {line}")
            lines.append(f"   ```")
            lines.append("")

        lines.append("Consider reviewing these patterns before proceeding with fuzzing.")
        return "\n".join(lines)
