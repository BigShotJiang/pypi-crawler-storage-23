"""Code relationship graphs using AST analysis and NetworkX."""

import ast
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import networkx as nx

logger = logging.getLogger(__name__)


@dataclass
class SymbolInfo:
    """Information about a code symbol (function, class, variable)."""

    name: str
    symbol_type: str  # 'function', 'class', 'import', 'variable'
    file: str
    line: int
    scope: str  # 'module', 'class', 'function'
    parent: Optional[str] = None  # Parent class/function name


@dataclass
class CodeGraphs:
    """Collection of code relationship graphs and symbol maps."""

    # Symbol resolution maps (O(1) lookup)
    file_map: dict[str, list[str]] = field(default_factory=dict)  # file -> symbols
    export_map: dict[str, SymbolInfo] = field(default_factory=dict)  # symbol -> info
    import_map: dict[str, list[str]] = field(default_factory=dict)  # file -> imported modules

    # Relationship graphs (NetworkX directed graphs)
    call_graph: nx.DiGraph = field(default_factory=nx.DiGraph)  # function -> called functions
    dependency_graph: nx.DiGraph = field(default_factory=nx.DiGraph)  # file -> imported files

    @property
    def function_count(self) -> int:
        """Total number of functions."""
        return sum(1 for s in self.export_map.values() if s.symbol_type == "function")

    @property
    def class_count(self) -> int:
        """Total number of classes."""
        return sum(1 for s in self.export_map.values() if s.symbol_type == "class")

    @property
    def file_count(self) -> int:
        """Total number of files analyzed."""
        return len(self.file_map)

    def get_functions_in_file(self, file: str) -> list[str]:
        """Get all function names defined in a file."""
        symbols = self.file_map.get(file, [])
        return [s for s in symbols if self.export_map[s].symbol_type == "function"]

    def get_callers(self, function: str) -> list[str]:
        """Get all functions that call the given function."""
        if function not in self.call_graph:
            return []
        return list(self.call_graph.predecessors(function))

    def get_callees(self, function: str) -> list[str]:
        """Get all functions called by the given function."""
        if function not in self.call_graph:
            return []
        return list(self.call_graph.successors(function))

    def get_dependencies(self, file: str) -> list[str]:
        """Get all files imported by the given file."""
        if file not in self.dependency_graph:
            return []
        return list(self.dependency_graph.successors(file))

    def get_dependents(self, file: str) -> list[str]:
        """Get all files that import the given file."""
        if file not in self.dependency_graph:
            return []
        return list(self.dependency_graph.predecessors(file))


class CodeGraphBuilder:
    """Build code graphs from Python source code using AST analysis."""

    def build_from_code(self, code: str, file_path: str = "<string>") -> CodeGraphs:
        """Build graphs from a single Python source file.

        Args:
            code: Python source code
            file_path: Path to the file (for tracking)

        Returns:
            CodeGraphs with symbol maps and relationship graphs
        """
        graphs = CodeGraphs()

        try:
            tree = ast.parse(code, filename=file_path)
        except SyntaxError as e:
            logger.warning(f"Syntax error in {file_path}: {e}")
            return graphs

        # Build symbol maps and graphs
        visitor = _SymbolVisitor(file_path, graphs)
        visitor.visit(tree)

        return graphs

    def build_from_files(self, file_paths: list[str | Path]) -> CodeGraphs:
        """Build graphs from multiple Python files.

        Args:
            file_paths: List of file paths to analyze

        Returns:
            CodeGraphs combining all files
        """
        graphs = CodeGraphs()

        for path in file_paths:
            path = Path(path)
            if not path.exists():
                logger.warning(f"File not found: {path}")
                continue

            try:
                code = path.read_text()
                file_graphs = self.build_from_code(code, str(path))

                # Merge into combined graphs
                self._merge_graphs(graphs, file_graphs)

            except Exception as e:
                logger.error(f"Error processing {path}: {e}")

        return graphs

    def _merge_graphs(self, target: CodeGraphs, source: CodeGraphs) -> None:
        """Merge source graphs into target graphs.

        Args:
            target: Target graphs to merge into
            source: Source graphs to merge from
        """
        # Merge symbol maps
        for file, symbols in source.file_map.items():
            target.file_map.setdefault(file, []).extend(symbols)

        target.export_map.update(source.export_map)

        for file, imports in source.import_map.items():
            target.import_map.setdefault(file, []).extend(imports)

        # Merge graphs
        target.call_graph = nx.compose(target.call_graph, source.call_graph)
        target.dependency_graph = nx.compose(target.dependency_graph, source.dependency_graph)


class _SymbolVisitor(ast.NodeVisitor):
    """AST visitor that extracts symbols and builds relationship graphs."""

    def __init__(self, file_path: str, graphs: CodeGraphs):
        self.file_path = file_path
        self.graphs = graphs
        self.current_scope = "module"
        self.current_function: Optional[str] = None
        self.current_class: Optional[str] = None
        self.scope_stack: list[str] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Visit function definition."""
        # Determine full qualified name
        if self.current_class:
            full_name = f"{self.current_class}.{node.name}"
            parent = self.current_class
            scope = "class"
        else:
            full_name = node.name
            parent = None
            scope = "module"

        # Record symbol
        symbol = SymbolInfo(
            name=full_name,
            symbol_type="function",
            file=self.file_path,
            line=node.lineno,
            scope=scope,
            parent=parent,
        )
        self.graphs.export_map[full_name] = symbol
        self.graphs.file_map.setdefault(self.file_path, []).append(full_name)

        # Add node to call graph
        self.graphs.call_graph.add_node(full_name)

        # Visit function body to find calls
        prev_function = self.current_function
        self.current_function = full_name
        self.scope_stack.append(scope)

        self.generic_visit(node)

        self.current_function = prev_function
        self.scope_stack.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """Visit async function definition."""
        # Treat same as regular function
        self.visit_FunctionDef(node)  # type: ignore

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """Visit class definition."""
        full_name = node.name

        # Record symbol
        symbol = SymbolInfo(
            name=full_name,
            symbol_type="class",
            file=self.file_path,
            line=node.lineno,
            scope="module",
            parent=None,
        )
        self.graphs.export_map[full_name] = symbol
        self.graphs.file_map.setdefault(self.file_path, []).append(full_name)

        # Visit class body
        prev_class = self.current_class
        self.current_class = full_name
        self.scope_stack.append("class")

        self.generic_visit(node)

        self.current_class = prev_class
        self.scope_stack.pop()

    def visit_Import(self, node: ast.Import) -> None:
        """Visit import statement."""
        for alias in node.names:
            module = alias.name
            self.graphs.import_map.setdefault(self.file_path, []).append(module)

            # Record import symbol
            import_name = alias.asname if alias.asname else alias.name
            symbol = SymbolInfo(
                name=import_name,
                symbol_type="import",
                file=self.file_path,
                line=node.lineno,
                scope=self.current_scope,
            )
            self.graphs.export_map[import_name] = symbol

            # Add to dependency graph
            self.graphs.dependency_graph.add_edge(self.file_path, module)

        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        """Visit from...import statement."""
        if node.module:
            self.graphs.import_map.setdefault(self.file_path, []).append(node.module)

            # Add to dependency graph
            self.graphs.dependency_graph.add_edge(self.file_path, node.module)

            # Record imported symbols
            for alias in node.names:
                import_name = alias.asname if alias.asname else alias.name
                symbol = SymbolInfo(
                    name=import_name,
                    symbol_type="import",
                    file=self.file_path,
                    line=node.lineno,
                    scope=self.current_scope,
                )
                self.graphs.export_map[import_name] = symbol

        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        """Visit function call."""
        if self.current_function is None:
            # Call outside function (module-level)
            self.generic_visit(node)
            return

        # Extract called function name
        called_name = self._extract_call_name(node)

        if called_name:
            # Add edge in call graph
            self.graphs.call_graph.add_edge(self.current_function, called_name)

        self.generic_visit(node)

    def _extract_call_name(self, node: ast.Call) -> Optional[str]:
        """Extract function name from call node.

        Args:
            node: Call AST node

        Returns:
            Function name or None
        """
        func = node.func

        if isinstance(func, ast.Name):
            # Simple call: foo()
            return func.id
        elif isinstance(func, ast.Attribute):
            # Method call: obj.foo() or module.foo()
            # Try to resolve the full name
            parts = []
            current = func

            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value

            if isinstance(current, ast.Name):
                parts.append(current.id)

            return ".".join(reversed(parts))

        return None
