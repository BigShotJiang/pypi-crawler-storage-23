"""Semantic analysis using LLM to compare code behavior."""

from dataclasses import dataclass

from ..providers.base import Provider


@dataclass
class SemanticDiff:
    """Result of semantic comparison."""

    variant_id: str
    agreement_score: float  # 0.0 to 1.0
    behavioral_differences: list[str]
    correctness_assessment: str  # "correct", "incorrect", "uncertain"
    edge_cases: list[str]
    improvements: list[str]
    concerns: list[str]

    def __post_init__(self):
        if not self.behavioral_differences:
            self.behavioral_differences = []
        if not self.edge_cases:
            self.edge_cases = []
        if not self.improvements:
            self.improvements = []
        if not self.concerns:
            self.concerns = []


class SemanticAnalyzer:
    """Analyzes code semantics using LLM."""

    def __init__(self, provider: Provider):
        """
        Initialize semantic analyzer.

        Args:
            provider: LLM provider for analysis
        """
        self.provider = provider

    async def compare(
        self,
        baseline: str,
        variant: str,
        variant_id: str,
        user_request: str,
    ) -> SemanticDiff:
        """
        Compare semantic behavior of baseline and variant.

        Args:
            baseline: Baseline code
            variant: Variant code
            variant_id: Identifier for variant
            user_request: Original user request

        Returns:
            SemanticDiff with behavioral comparison
        """
        prompt = self._build_comparison_prompt(
            baseline=baseline,
            variant=variant,
            user_request=user_request
        )

        # Get analysis from LLM
        messages = [{"role": "user", "content": prompt}]
        response = await self.provider.generate(messages, temperature=0.3)

        # Parse response
        analysis_text = response.get("text", "")
        return self._parse_analysis(analysis_text, variant_id)

    def _build_comparison_prompt(
        self,
        baseline: str,
        variant: str,
        user_request: str
    ) -> str:
        """Build prompt for semantic comparison."""
        return f"""Compare these two code implementations for the request: "{user_request}"

Baseline:
```python
{baseline}
```

Variant:
```python
{variant}
```

Analyze the following:

1. **Behavioral Equivalence**: Do they produce the same behavior? Score 0-10.

2. **Differences**: What are the semantic differences?
   - Different approach?
   - Different edge case handling?
   - Different error handling?

3. **Correctness**: Which implementation is more correct for the request?
   - State "correct", "incorrect", or "uncertain"
   - Explain why

4. **Edge Cases**: What edge cases does each handle (or not handle)?

5. **Improvements**: What does the variant do better than baseline?

6. **Concerns**: Any issues, bugs, or problems in the variant?

Format your response as:
SCORE: <0-10>
DIFFERENCES:
- <difference 1>
- <difference 2>
CORRECTNESS: <correct|incorrect|uncertain>
REASON: <explanation>
EDGE_CASES:
- <edge case 1>
- <edge case 2>
IMPROVEMENTS:
- <improvement 1>
- <improvement 2>
CONCERNS:
- <concern 1>
- <concern 2>
"""

    def _parse_analysis(self, text: str, variant_id: str) -> SemanticDiff:
        """
        Parse LLM analysis response.

        Args:
            text: Analysis text from LLM
            variant_id: Variant identifier

        Returns:
            SemanticDiff with parsed results
        """
        lines = text.strip().split("\n")

        # Extract sections
        score = 5.0  # Default
        differences = []
        correctness = "uncertain"
        edge_cases = []
        improvements = []
        concerns = []

        current_section = None

        for line in lines:
            line = line.strip()

            if line.startswith("SCORE:"):
                try:
                    score_text = line.split(":", 1)[1].strip()
                    score = float(score_text.split()[0]) / 10.0  # Normalize to 0-1
                except (ValueError, IndexError):
                    pass

            elif line.startswith("DIFFERENCES:"):
                current_section = "differences"

            elif line.startswith("CORRECTNESS:"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    correctness = parts[1].strip().lower()
                current_section = None

            elif line.startswith("EDGE_CASES:"):
                current_section = "edge_cases"

            elif line.startswith("IMPROVEMENTS:"):
                current_section = "improvements"

            elif line.startswith("CONCERNS:"):
                current_section = "concerns"

            elif line.startswith("REASON:"):
                current_section = None

            elif line.startswith("-") and current_section:
                item = line.lstrip("- ").strip()
                if current_section == "differences":
                    differences.append(item)
                elif current_section == "edge_cases":
                    edge_cases.append(item)
                elif current_section == "improvements":
                    improvements.append(item)
                elif current_section == "concerns":
                    concerns.append(item)

        return SemanticDiff(
            variant_id=variant_id,
            agreement_score=score,
            behavioral_differences=differences,
            correctness_assessment=correctness,
            edge_cases=edge_cases,
            improvements=improvements,
            concerns=concerns,
        )
