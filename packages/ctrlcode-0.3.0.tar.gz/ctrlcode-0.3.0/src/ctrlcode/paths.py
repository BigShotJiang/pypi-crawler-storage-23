"""Cross-platform path resolution for ctrl+code.

Provides platform-aware directory paths following OS conventions:
- Linux: XDG Base Directory Specification
- macOS: ~/Library/Application Support and ~/Library/Caches
- Windows: AppData directories

Environment variable overrides:
- CTRLCODE_CONFIG_DIR: Override config directory
- CTRLCODE_DATA_DIR: Override data directory
- CTRLCODE_CACHE_DIR: Override cache directory
"""

import os
from pathlib import Path

from platformdirs import user_cache_dir, user_config_dir, user_data_dir

APP_NAME = "ctrlcode"
APP_AUTHOR = "ctrlcode"  # Required for Windows paths


def get_config_dir() -> Path:
    """Get platform-specific config directory.

    Returns:
        Path to config directory (contains config.toml, skills/, etc.)

    Platform defaults:
        Linux:   ~/.config/ctrlcode/
        macOS:   ~/Library/Application Support/ctrlcode/
        Windows: %APPDATA%\\ctrlcode\\
    """
    if override := os.getenv("CTRLCODE_CONFIG_DIR"):
        return Path(override).expanduser()
    return Path(user_config_dir(APP_NAME, APP_AUTHOR))


def get_data_dir() -> Path:
    """Get platform-specific data directory.

    Returns:
        Path to data directory (contains sessions/, persistent data)

    Platform defaults:
        Linux:   ~/.local/share/ctrlcode/
        macOS:   ~/Library/Application Support/ctrlcode/
        Windows: %LOCALAPPDATA%\\ctrlcode\\
    """
    if override := os.getenv("CTRLCODE_DATA_DIR"):
        return Path(override).expanduser()
    return Path(user_data_dir(APP_NAME, APP_AUTHOR))


def get_cache_dir() -> Path:
    """Get platform-specific cache directory.

    Returns:
        Path to cache directory (contains conversations/, temp files)

    Platform defaults:
        Linux:   ~/.cache/ctrlcode/
        macOS:   ~/Library/Caches/ctrlcode/
        Windows: %LOCALAPPDATA%\\ctrlcode\\Cache\\
    """
    if override := os.getenv("CTRLCODE_CACHE_DIR"):
        return Path(override).expanduser()
    return Path(user_cache_dir(APP_NAME, APP_AUTHOR))
