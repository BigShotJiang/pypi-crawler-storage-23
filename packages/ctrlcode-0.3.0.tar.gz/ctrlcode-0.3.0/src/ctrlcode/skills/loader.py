"""Skill loading from TOML files."""

import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore # Python < 3.11

logger = logging.getLogger(__name__)


@dataclass
class Skill:
    """A skill definition."""

    name: str
    prompt: str
    description: str = ""
    requires_args: bool = False
    examples: list[str] = field(default_factory=list)


class SkillLoader:
    """Loads skills from TOML files."""

    def __init__(self, skills_dir: Optional[Path] = None):
        """
        Initialize skill loader.

        Args:
            skills_dir: Directory containing skill TOML files
        """
        self.skills_dir = skills_dir

    def load_skill(self, skill_path: Path) -> Skill:
        """
        Load a skill from TOML file.

        Args:
            skill_path: Path to skill TOML file

        Returns:
            Loaded skill
        """
        with open(skill_path, "rb") as f:
            data = tomllib.load(f)

        return Skill(
            name=data["name"],
            prompt=data["prompt"],
            description=data.get("description", ""),
            requires_args=data.get("requires_args", False),
            examples=data.get("examples", []),
        )

    def load_all(self) -> dict[str, Skill]:
        """
        Load all skills from directory.

        Returns:
            Dict mapping skill name to skill
        """
        skills: dict[str, Skill] = {}

        if not self.skills_dir or not self.skills_dir.exists():
            logger.warning(f"Skills directory not found: {self.skills_dir}")
            return skills

        for skill_file in self.skills_dir.glob("*.toml"):
            try:
                skill = self.load_skill(skill_file)
                skills[skill.name] = skill
                logger.info(f"Loaded skill: {skill.name}")
            except Exception as e:
                logger.error(f"Failed to load skill {skill_file}: {e}")

        return skills

    def load_from_paths(self, paths: list[Path]) -> dict[str, Skill]:
        """
        Load skills from multiple directories.

        Args:
            paths: List of directory paths

        Returns:
            Dict mapping skill name to skill
        """
        skills = {}

        for path in paths:
            if not path.exists():
                logger.warning(f"Skill path not found: {path}")
                continue

            for skill_file in path.glob("*.toml"):
                try:
                    skill = self.load_skill(skill_file)
                    if skill.name in skills:
                        logger.warning(f"Skill '{skill.name}' already loaded, skipping")
                    else:
                        skills[skill.name] = skill
                        logger.info(f"Loaded skill: {skill.name}")
                except Exception as e:
                    logger.error(f"Failed to load skill {skill_file}: {e}")

        return skills
