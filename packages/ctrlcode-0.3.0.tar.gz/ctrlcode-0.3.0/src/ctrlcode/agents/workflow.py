"""Multi-agent workflow execution."""

from typing import Any, Callable, Optional
from dataclasses import dataclass
import logging
from uuid import uuid4

from .communication import AgentCoordinator, AgentVerbosity

logger = logging.getLogger(__name__)


@dataclass
class TaskGraph:
    """Task graph with dependencies."""

    tasks: list[dict[str, Any]]
    parallel_groups: list[list[str]]
    risks: list[str]
    checkpoints: list[dict]

    def get_task(self, task_id: str) -> dict[str, Any] | None:
        """
        Get task by ID.

        Args:
            task_id: Task identifier

        Returns:
            Task dict or None if not found
        """
        for task in self.tasks:
            if task["id"] == task_id:
                return task
        return None

    def get_parallel_group(self, group_index: int) -> list[str]:
        """
        Get task IDs in parallel group.

        Args:
            group_index: Index of parallel group

        Returns:
            List of task IDs
        """
        if 0 <= group_index < len(self.parallel_groups):
            return self.parallel_groups[group_index]
        return []


class MultiAgentWorkflow:
    """Orchestrates multi-agent task execution."""

    def __init__(
        self,
        coordinator: AgentCoordinator,
        event_callback=None,
        checkpoint_callback: Optional[Callable] = None,
    ):
        """
        Initialize workflow executor.

        Args:
            coordinator: AgentCoordinator instance
            event_callback: Optional async callback for workflow events
            checkpoint_callback: Optional async callable(checkpoint_id) -> bool
        """
        self.coordinator = coordinator
        self.bus = coordinator.bus
        self.event_callback = event_callback
        self.checkpoint_callback = checkpoint_callback

    async def execute(self, user_intent: str) -> dict[str, Any]:
        """
        Execute multi-agent workflow for user intent.

        Args:
            user_intent: User's request/goal

        Returns:
            Workflow execution results
        """
        results = {
            "status": "in_progress",
            "user_intent": user_intent,
            "task_graph": None,
            "completed_tasks": [],
            "errors": [],
        }

        try:
            # Phase 1: Planning
            await self._emit_event("workflow_phase_change", {
                "phase": "planning",
                "progress": 0.0,
                "status": "Analyzing request and creating task breakdown..."
            })

            task_graph = await self._planning_phase(user_intent)
            results["task_graph"] = task_graph

            # Phase 2: Execution
            await self._emit_event("workflow_phase_change", {
                "phase": "execution",
                "progress": 0.25,
                "completed": 1,
                "total": 4,
                "status": "Executing tasks..."
            })

            completed_tasks = await self._execution_phase(task_graph)
            results["completed_tasks"] = completed_tasks

            # Phase 3: Review
            await self._emit_event("workflow_phase_change", {
                "phase": "review",
                "progress": 0.5,
                "completed": 2,
                "total": 4,
                "status": "Reviewing changes..."
            })

            review_result = await self._review_phase(completed_tasks)

            # Handle review feedback loop
            if review_result["status"] == "changes_requested":
                # Emit feedback
                await self._emit_event("workflow_review_feedback", {
                    "feedback": review_result.get("feedback", [])
                })

                # Go back to execution phase
                await self._emit_event("workflow_phase_change", {
                    "phase": "execution",
                    "progress": 0.5,
                    "status": "Addressing review feedback..."
                })

                completed_tasks = await self._handle_review_feedback(
                    review_result,
                    task_graph
                )
                results["completed_tasks"] = completed_tasks

                # Re-review
                await self._emit_event("workflow_phase_change", {
                    "phase": "review",
                    "progress": 0.65,
                    "status": "Re-reviewing changes..."
                })
                review_result = await self._review_phase(completed_tasks)

            results["review"] = review_result

            # Phase 4: Validation
            await self._emit_event("workflow_phase_change", {
                "phase": "validation",
                "progress": 0.75,
                "completed": 3,
                "total": 4,
                "status": "Running tests and validation..."
            })

            validation_result = await self._validation_phase(completed_tasks)
            results["validation"] = validation_result

            # Emit validation results
            await self._emit_event("workflow_observability_results", {
                "results": validation_result
            })

            # Determine final status
            if validation_result["status"] == "pass":
                await self._emit_event("workflow_phase_change", {
                    "phase": "complete",
                    "progress": 1.0,
                    "completed": 4,
                    "total": 4,
                    "status": "Workflow completed successfully"
                })
                results["status"] = "completed"
            else:
                await self._emit_event("workflow_phase_change", {
                    "phase": "complete",
                    "progress": 1.0,
                    "status": "Workflow completed with validation failures"
                })
                results["status"] = "failed"
                results["errors"].append(
                    f"Validation failed: {validation_result.get('error')}"
                )

        except Exception as e:
            await self._emit_event("workflow_phase_change", {
                "phase": "idle",
                "progress": 0.0,
                "status": f"Workflow error: {str(e)}"
            })
            results["status"] = "error"
            results["errors"].append(str(e))

        return results

    async def _emit_event(self, event_type: str, data: dict[str, Any]):
        """
        Emit workflow event via callback.

        Args:
            event_type: Type of event
            data: Event data
        """
        if self.event_callback:
            try:
                await self.event_callback(event_type, data)
            except Exception:
                # Don't let event emission failures break workflow
                pass

    async def _planning_phase(self, user_intent: str) -> TaskGraph:
        """
        Execute planning phase.

        Args:
            user_intent: User's request

        Returns:
            TaskGraph with tasks and dependencies
        """
        # Spawn planner agent
        planner_result = await self.coordinator.spawn_agent(
            agent_type="planner",
            task={
                "user_intent": user_intent,
                "context": {},
            },
            verbosity=AgentVerbosity.WORKFLOW
        )

        # Emit agent spawned event
        agent_id = planner_result.get("agent_id")
        await self._emit_event("workflow_agent_spawned", {
            "agent_id": agent_id,
            "type": "planner",
            "task": "Creating task breakdown"
        })

        # Handle error case
        if planner_result.get("status") == "error":
            await self._emit_event("workflow_error", {
                "phase": "planning",
                "error": planner_result.get("error")
            })
            logger.error(f"Planning phase failed: {planner_result.get('error')}")
            # Return empty task graph
            return TaskGraph(tasks=[], parallel_groups=[], risks=[], checkpoints=[])

        # Emit agent completion
        await self._emit_event("workflow_agent_completed", {
            "agent_id": agent_id
        })

        # Extract task graph from planner result (now structured)
        task_graph_data = planner_result.get("task_graph", {
            "tasks": [],
            "parallel_groups": [],
            "risks": [],
            "checkpoints": [],
        })

        # Check for parsing errors
        if "error" in task_graph_data:
            logger.warning(f"Task graph parsing had issues: {task_graph_data.get('error')}")

        task_graph = TaskGraph(
            tasks=task_graph_data.get("tasks", []),
            parallel_groups=task_graph_data.get("parallel_groups", []),
            risks=task_graph_data.get("risks", []),
            checkpoints=task_graph_data.get("checkpoints", [])
        )

        # Emit task graph created event
        await self._emit_event("workflow_task_graph_created", {
            "task_graph": {
                "tasks": task_graph.tasks,
                "parallel_groups": task_graph.parallel_groups,
                "risks": task_graph.risks,
                "checkpoints": task_graph.checkpoints,
            }
        })

        return task_graph

    async def _execution_phase(
        self,
        task_graph: TaskGraph
    ) -> list[dict[str, Any]]:
        """
        Execute all tasks from task graph.

        Args:
            task_graph: TaskGraph to execute

        Returns:
            List of completed task results
        """
        completed_tasks = []

        # Execute each parallel group sequentially
        for group_index, group in enumerate(task_graph.parallel_groups):
            if len(group) == 1:
                # Single task - execute sequentially
                task_id = group[0]
                task = task_graph.get_task(task_id)

                if task:
                    # Emit task status update
                    await self._emit_event("workflow_task_updated", {
                        "task_id": task_id,
                        "status": "in_progress"
                    })

                    # Spawn coder agent
                    result = await self.coordinator.spawn_agent(
                        agent_type="coder",
                        task=task
                    )

                    # Emit agent events
                    agent_id = result.get("agent_id")
                    await self._emit_event("workflow_agent_spawned", {
                        "agent_id": agent_id,
                        "type": "coder",
                        "task": task.get("description", task_id)
                    })

                    await self._emit_event("workflow_agent_updated", {
                        "agent_id": agent_id,
                        "status": "in_progress",
                        "task": task.get("description", task_id),
                        "progress": 0.5
                    })

                    completed_tasks.append(result)

                    # Emit completion events
                    await self._emit_event("workflow_agent_completed", {
                        "agent_id": agent_id
                    })

                    await self._emit_event("workflow_task_updated", {
                        "task_id": task_id,
                        "status": "completed"
                    })

            else:
                # Multiple tasks - execute in parallel
                tasks = [task_graph.get_task(tid) for tid in group]
                tasks = [t for t in tasks if t is not None]  # Filter None

                # Emit parallel execution start
                task_ids = [t["id"] for t in tasks]
                await self._emit_event("workflow_parallel_start", {
                    "task_ids": task_ids
                })

                # Update task statuses
                for task_id in task_ids:
                    await self._emit_event("workflow_task_updated", {
                        "task_id": task_id,
                        "status": "in_progress"
                    })

                agents_tasks = [
                    {"type": "coder", "task": task}
                    for task in tasks
                ]

                results = await self.coordinator.spawn_agents_parallel(
                    agents_tasks
                )

                # Emit agent events for each
                for i, result in enumerate(results):
                    agent_id = result.get("agent_id")
                    task_id = task_ids[i] if i < len(task_ids) else f"task-{i}"

                    await self._emit_event("workflow_agent_spawned", {
                        "agent_id": agent_id,
                        "type": "coder",
                        "task": tasks[i].get("description", task_id)
                    })

                    # Emit progress
                    await self._emit_event("workflow_parallel_progress", {
                        "task_id": task_id,
                        "progress": 1.0,
                        "description": tasks[i].get("description", task_id)
                    })

                    await self._emit_event("workflow_agent_completed", {
                        "agent_id": agent_id
                    })

                    await self._emit_event("workflow_task_updated", {
                        "task_id": task_id,
                        "status": "completed"
                    })

                completed_tasks.extend(results)

            # Check for checkpoint after this group
            checkpoint = next(
                (c for c in task_graph.checkpoints if c.get("after_group") == group_index),
                None
            )
            if checkpoint and self.checkpoint_callback:
                completed_group_descs = []
                for task_id in group:
                    task = task_graph.get_task(task_id)
                    completed_group_descs.append(
                        task.get("description", task_id) if task else task_id
                    )

                next_tasks = []
                if group_index + 1 < len(task_graph.parallel_groups):
                    for task_id in task_graph.parallel_groups[group_index + 1]:
                        task = task_graph.get_task(task_id)
                        next_tasks.append(
                            task.get("description", task_id) if task else task_id
                        )

                checkpoint_id = str(uuid4())
                await self._emit_event("workflow_checkpoint_reached", {
                    "checkpoint_id": checkpoint_id,
                    "group_index": group_index,
                    "description": checkpoint["description"],
                    "completed_tasks": completed_group_descs,
                    "next_tasks": next_tasks,
                    "progress": (
                        f"{group_index + 1} of {len(task_graph.parallel_groups)} groups complete"
                    ),
                })

                should_continue = await self.checkpoint_callback(checkpoint_id)
                if not should_continue:
                    logger.info(f"Workflow aborted at checkpoint after group {group_index}")
                    break

        return completed_tasks

    async def _review_phase(
        self,
        completed_tasks: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """
        Execute review phase.

        Args:
            completed_tasks: List of completed tasks

        Returns:
            Review result
        """
        # Spawn reviewer agent
        reviewer_result = await self.coordinator.spawn_agent(
            agent_type="reviewer",
            task={
                "tasks": completed_tasks,
                "files_changed": self._extract_changed_files(completed_tasks),
            },
            verbosity=AgentVerbosity.WORKFLOW
        )

        # Emit reviewer agent events
        agent_id = reviewer_result.get("agent_id")
        await self._emit_event("workflow_agent_spawned", {
            "agent_id": agent_id,
            "type": "reviewer",
            "task": "Reviewing completed tasks"
        })

        # Handle error case
        if reviewer_result.get("status") == "error":
            await self._emit_event("workflow_error", {
                "phase": "review",
                "error": reviewer_result.get("error")
            })
            logger.error(f"Review phase failed: {reviewer_result.get('error')}")
            # Return inconclusive review
            return {
                "status": "inconclusive",
                "feedback": "Review failed",
                "error": reviewer_result.get("error")
            }

        await self._emit_event("workflow_agent_completed", {
            "agent_id": agent_id
        })

        # Extract structured review data
        review_data = reviewer_result.get("review", {})

        return {
            "status": review_data.get("status", "inconclusive"),
            "feedback": review_data.get("feedback", ""),
            "changes_required": review_data.get("changes_required", [])
        }

    async def _validation_phase(
        self,
        completed_tasks: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """
        Execute validation phase.

        Args:
            completed_tasks: List of completed tasks

        Returns:
            Validation result
        """
        # Spawn executor agent
        executor_result = await self.coordinator.spawn_agent(
            agent_type="executor",
            task={
                "type": "verify_functionality",
                "tasks": completed_tasks,
            },
            verbosity=AgentVerbosity.WORKFLOW
        )

        # Emit executor agent events
        agent_id = executor_result.get("agent_id")
        await self._emit_event("workflow_agent_spawned", {
            "agent_id": agent_id,
            "type": "executor",
            "task": "Running validation tests"
        })

        await self._emit_event("workflow_agent_updated", {
            "agent_id": agent_id,
            "status": "in_progress",
            "task": "Executing tests and checks",
            "progress": 0.5
        })

        # Handle error case
        if executor_result.get("status") == "error":
            await self._emit_event("workflow_error", {
                "phase": "validation",
                "error": executor_result.get("error")
            })
            logger.error(f"Validation phase failed: {executor_result.get('error')}")
            return {
                "status": "fail",
                "error": executor_result.get("error"),
                "test_results": []
            }

        await self._emit_event("workflow_agent_completed", {
            "agent_id": agent_id
        })

        # Extract structured validation data
        validation_data = executor_result.get("validation", {})

        return {
            "status": "pass" if validation_data.get("validation_status") == "passed" else "fail",
            "test_results": validation_data.get("test_results", []),
            "output": validation_data.get("output", "")
        }

    async def _handle_review_feedback(
        self,
        review_result: dict[str, Any],
        task_graph: TaskGraph
    ) -> list[dict[str, Any]]:
        """
        Handle review feedback by re-executing tasks.

        Args:
            review_result: Review result with feedback
            task_graph: Original task graph

        Returns:
            Updated completed tasks
        """
        completed_tasks = []

        # Extract tasks that need changes
        feedback_items = review_result.get("feedback", [])

        for feedback_item in feedback_items:
            task_id = feedback_item.get("task_id")
            if not task_id:
                continue

            # Get original task
            task = task_graph.get_task(task_id)
            if not task:
                continue

            # Update feedback status to in_progress
            feedback_id = feedback_item.get("id")
            if feedback_id:
                await self._emit_event("workflow_review_feedback", {
                    "feedback": [{
                        **feedback_item,
                        "fix_status": "in_progress"
                    }]
                })

            # Add feedback to task context
            task["context"] = task.get("context", {})
            task["context"]["reviewer_feedback"] = feedback_item

            # Update task status
            await self._emit_event("workflow_task_updated", {
                "task_id": task_id,
                "status": "in_progress"
            })

            # Re-execute task
            result = await self.coordinator.spawn_agent(
                agent_type="coder",
                task=task
            )

            # Emit agent events
            agent_id = result.get("agent_id")
            await self._emit_event("workflow_agent_spawned", {
                "agent_id": agent_id,
                "type": "coder",
                "task": f"Addressing feedback for {task_id}"
            })

            await self._emit_event("workflow_agent_completed", {
                "agent_id": agent_id
            })

            await self._emit_event("workflow_task_updated", {
                "task_id": task_id,
                "status": "completed"
            })

            # Update feedback status to fixed
            if feedback_id:
                await self._emit_event("workflow_review_feedback", {
                    "feedback": [{
                        **feedback_item,
                        "fix_status": "fixed"
                    }]
                })

            completed_tasks.append(result)

        return completed_tasks

    def _extract_changed_files(
        self,
        completed_tasks: list[dict[str, Any]]
    ) -> list[str]:
        """
        Extract list of changed files from tasks.

        Args:
            completed_tasks: List of completed tasks

        Returns:
            List of file paths
        """
        files = set()

        for task in completed_tasks:
            task_files = task.get("task", {}).get("files", [])
            files.update(task_files)

        return list(files)


class WorkflowOrchestrator:
    """High-level orchestrator for managing workflows."""

    def __init__(
        self,
        agent_registry: Any,
        storage_path: Any,
        provider: Any,
        tool_registry: Any | None = None,
        event_callback=None,
        checkpoint_callback: Optional[Callable] = None,
    ):
        """
        Initialize orchestrator.

        Args:
            agent_registry: AgentRegistry instance
            storage_path: Base path for agent storage
            provider: LLM provider instance
            tool_registry: Optional ToolRegistry for tool access
            event_callback: Optional async callback for workflow events
            checkpoint_callback: Optional async callable(checkpoint_id) -> bool
        """
        self.coordinator = AgentCoordinator(
            agent_registry,
            storage_path,
            provider,
            tool_registry
        )
        self.workflow = MultiAgentWorkflow(
            self.coordinator, event_callback, checkpoint_callback
        )

    async def handle_user_request(
        self,
        user_intent: str,
        context: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Handle user request with multi-agent workflow.

        Args:
            user_intent: User's request
            context: Optional additional context

        Returns:
            Workflow execution results
        """
        # Classify intent
        is_trivial = self._is_trivial_request(user_intent)

        if is_trivial:
            # Skip planning, execute directly
            result = await self.coordinator.spawn_agent(
                agent_type="coder",
                task={"description": user_intent}
            )
            return {
                "status": "completed",
                "workflow": "simple",
                "result": result,
            }

        else:
            # Full multi-agent workflow
            result = await self.workflow.execute(user_intent)
            return {
                "status": result["status"],
                "workflow": "multi_agent",
                "result": result,
            }

    def _is_trivial_request(self, user_intent: str) -> bool:
        """
        Determine if request is trivial (single-agent).

        Args:
            user_intent: User's request

        Returns:
            True if trivial, False otherwise
        """
        trivial_keywords = [
            "fix typo",
            "change color",
            "update readme",
            "add comment",
        ]

        user_intent_lower = user_intent.lower()

        return any(keyword in user_intent_lower for keyword in trivial_keywords)
