"""Multi-agent system for ctrl+code."""

from .registry import AgentRegistry
from .communication import AgentMessage, AgentBus, AgentCoordinator
from .workflow import TaskGraph, MultiAgentWorkflow, WorkflowOrchestrator
from .observability import (
    ObservabilityTools,
    TestOutputParser,
    PerformanceParser,
    LogParser,
)
from .cleanup import CleanupAgent, GoldenPrinciplesScanner, CodeSmellDetector

__all__ = [
    "AgentRegistry",
    "AgentMessage",
    "AgentBus",
    "AgentCoordinator",
    "TaskGraph",
    "MultiAgentWorkflow",
    "WorkflowOrchestrator",
    "ObservabilityTools",
    "TestOutputParser",
    "PerformanceParser",
    "LogParser",
    "CleanupAgent",
    "GoldenPrinciplesScanner",
    "CodeSmellDetector",
]
