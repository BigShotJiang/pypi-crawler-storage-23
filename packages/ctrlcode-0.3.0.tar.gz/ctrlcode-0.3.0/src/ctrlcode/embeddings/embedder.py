"""Code embedding generation using provider's OpenAI-compatible embeddings endpoint."""

import logging
from typing import Optional, Literal

import numpy as np

logger = logging.getLogger(__name__)


class CodeEmbedder:
    """Generate semantic embeddings for code, oracles, tests, and bug patterns.

    Uses OpenAI-compatible embeddings endpoint (/v1/embeddings).
    Works with any OpenAI-compatible server (vLLM, LM Studio, Ollama, etc.).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model_name: str = "text-embedding-3-small",
        normalize: bool = True,
    ):
        """Initialize embedder with embeddings endpoint configuration.

        Args:
            api_key: API key for embeddings endpoint
            base_url: Base URL for OpenAI-compatible embeddings API
            model_name: Embedding model name (default: text-embedding-3-small)
            normalize: L2-normalize embeddings for cosine similarity
        """
        if not api_key or not base_url:
            raise ValueError("api_key and base_url required for embeddings")

        self.api_key = api_key
        self.base_url = base_url
        self.model_name = model_name
        self.normalize = normalize
        self._embedding_dim: Optional[int] = None
        self.backend = "api"

    @property
    def embedding_dim(self) -> int:
        """Dimension of embedding vectors."""
        if self._embedding_dim is None:
            # text-embedding-3-small: 1536 dimensions
            # text-embedding-ada-002: 1536 dimensions
            # Most OpenAI-compatible endpoints use 1536
            self._embedding_dim = 1536
        return self._embedding_dim

    def embed_code(self, code: str) -> np.ndarray:
        """Embed source code into semantic vector.

        Args:
            code: Source code string

        Returns:
            Normalized embedding vector (numpy array)
        """
        return self._embed_single(code)

    def embed_oracle(self, oracle: str) -> np.ndarray:
        """Embed behavioral oracle/invariants.

        Args:
            oracle: Oracle specification text

        Returns:
            Normalized embedding vector
        """
        return self._embed_single(oracle)

    def embed_test_case(self, test_case: str) -> np.ndarray:
        """Embed test case code.

        Args:
            test_case: Test code string

        Returns:
            Normalized embedding vector
        """
        return self._embed_single(test_case)

    def embed_bug_pattern(self, bug_description: str) -> np.ndarray:
        """Embed bug pattern description.

        Args:
            bug_description: Bug description and context

        Returns:
            Normalized embedding vector
        """
        return self._embed_single(bug_description)

    def embed_batch(self, texts: list[str]) -> np.ndarray:
        """Embed multiple texts efficiently.

        Args:
            texts: List of text strings to embed

        Returns:
            Array of embeddings (shape: [len(texts), embedding_dim])
        """
        if not texts:
            return np.array([])

        return self._embed_batch_api(texts)

    def _embed_single(self, text: str) -> np.ndarray:
        """Internal method to embed single text."""
        return self._embed_single_api(text)

    def _embed_single_api(self, text: str) -> np.ndarray:
        """Embed using OpenAI-compatible API endpoint."""
        import openai

        client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)

        try:
            response = client.embeddings.create(
                input=text,
                model=self.model_name
            )

            # Check if response has data
            if not hasattr(response, 'data') or not response.data:
                logger.error(f"No embedding data received. Response: {response}")
                raise ValueError("No embedding data received")

            # Extract embedding
            embedding = np.array(response.data[0].embedding, dtype=np.float32)

            # Normalize if requested
            if self.normalize:
                norm = np.linalg.norm(embedding)
                if norm > 0:
                    embedding = embedding / norm

            return embedding

        except Exception as e:
            logger.error(f"Embedding API error: {e}")
            # Return zero vector as fallback
            return np.zeros(self.embedding_dim, dtype=np.float32)

    def _embed_batch_api(self, texts: list[str]) -> np.ndarray:
        """Embed batch using OpenAI-compatible API endpoint."""
        import openai

        client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)

        try:
            response = client.embeddings.create(
                input=texts,
                model=self.model_name
            )

            # Check if response has data
            if not hasattr(response, 'data') or not response.data:
                logger.error(f"No embedding data received. Response: {response}")
                raise ValueError("No embedding data received")

            # Extract embeddings in order
            embeddings = [np.array(item.embedding, dtype=np.float32) for item in response.data]
            embeddings = np.array(embeddings)

            # Normalize if requested
            if self.normalize:
                norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
                embeddings = np.where(norms > 0, embeddings / norms, embeddings)

            return embeddings

        except Exception as e:
            logger.error(f"Batch embedding API error: {e}")
            # Return zero vectors as fallback
            return np.zeros((len(texts), self.embedding_dim), dtype=np.float32)

    def cosine_similarity(self, emb1: np.ndarray, emb2: np.ndarray) -> float:
        """Calculate cosine similarity between two embeddings.

        Args:
            emb1: First embedding (normalized)
            emb2: Second embedding (normalized)

        Returns:
            Similarity score in [0, 1] (assumes normalized embeddings)
        """
        # For normalized vectors, cosine similarity = dot product
        return float(np.dot(emb1, emb2))
