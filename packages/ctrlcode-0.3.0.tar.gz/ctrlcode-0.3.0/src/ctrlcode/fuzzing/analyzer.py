"""Enhanced analyzer with oracle bug detection."""

import json
from dataclasses import dataclass, asdict
from typing import Literal, Any

from ..providers.base import Provider
from .context import ContextDerivation
from .context_fuzzer import FuzzTestCase


@dataclass
class DiagnosedDivergence:
    """Analyzed divergence with root cause and fix."""

    divergence_id: str
    diagnosis: str
    root_cause: str
    source: Literal["MODEL_BUG", "ORACLE_BUG", "SPEC_GAP", "ENVIRONMENT_MISMATCH"]
    confidence: float  # 0-1
    fix: dict[str, Any]  # Patch, corrected invariant, or clarification question
    regression_test: str
    follow_up_guidance: list[str]
    impact: str
    blast_radius: str

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return asdict(self)


class DerivedOracleAnalyzer:
    """
    Analyzes divergences in derived context testing.

    Key innovation: Detects when the ORACLE is wrong, not just the code.
    """

    def __init__(self, provider: Provider):
        """
        Initialize analyzer.

        Args:
            provider: LLM provider for analysis
        """
        self.provider = provider

    async def analyze_divergence(
        self,
        spec: str,
        code: str,
        context: ContextDerivation,
        test_case: FuzzTestCase,
        actual_output: dict,
        expected_output: dict,
        previous_analyses: list[DiagnosedDivergence] = [],
    ) -> DiagnosedDivergence:
        """
        Analyze a divergence between actual and expected behavior.

        Args:
            spec: Original specification
            code: Generated code
            context: Derived context
            test_case: The test case that revealed the divergence
            actual_output: What the code actually produced
            expected_output: What was expected (from derived oracle)
            previous_analyses: Previous divergence analyses (for learning)

        Returns:
            DiagnosedDivergence with root cause and fix

        This determines whether the divergence is due to:
        - MODEL_BUG: Code is wrong
        - ORACLE_BUG: Derived expectation was wrong
        - SPEC_GAP: Specification is ambiguous
        - ENVIRONMENT_MISMATCH: Wrong environmental assumptions
        """
        # Build system prompt (from DIFFFUZZTEST.md lines 396-445)
        system_prompt = """You are a senior software engineer performing root cause analysis. You operate
in a pipeline where code is tested against DERIVED behavioral expectations
rather than a running system.

This means divergences could come from three sources:
1. The MODEL'S CODE is wrong (most common)
2. The DERIVED EXPECTATION is wrong (the context analysis misjudged what the
   code should do)
3. The SPECIFICATION is ambiguous or incomplete
4. The ENVIRONMENTAL ASSUMPTIONS don't match reality

For each divergence:

## 1. DIAGNOSE
Identify the root cause. Point to specific code, specific invariant, or
specific spec clause.

## 2. DETERMINE SOURCE
- MODEL_BUG: The code doesn't match what the spec and context require.
- ORACLE_BUG: The derived expectation was wrong — the code is actually fine,
  but the context derivation made an incorrect inference about what the
  behavior should be. (This is important — flag it so the context derivation
  improves over time.)
- SPEC_GAP: The specification doesn't address this case. Neither the code
  nor the derived oracle can be judged correct.
- ENVIRONMENT_MISMATCH: The environmental assumptions in the context report
  don't match reality (e.g., assumed async but code is sync).

## 3. PROPOSE FIX
- MODEL_BUG → Code patch (minimal diff)
- ORACLE_BUG → Corrected invariant/expectation + note to adjust context derivation
- SPEC_GAP → Clarification question for the user + both possible interpretations
- ENVIRONMENT_MISMATCH → Corrected context assumptions + re-derive affected invariants

## 4. CONFIDENCE & IMPACT
- Confidence (0-1): How certain are you about the diagnosis?
- Impact: What else could break if this bug exists in production?
  (e.g., "If retries aren't bounded, a single failing upstream could
  consume all connection pool slots and cascade-fail the entire service")
- Blast radius: Just this function? Its callers? The whole service?

## 5. REGRESSION TEST
Concrete test code covering this case.

## 6. FOLLOW-UP FUZZING GUIDANCE
- Inputs/scenarios the fuzzer should try next
- If ORACLE_BUG: note which invariants to re-derive

Output as JSON."""

        # Build user message
        previous_section = (
            json.dumps([a.to_dict() for a in previous_analyses], indent=2)
            if previous_analyses
            else "No previous analyses."
        )

        user_message = f"""## Specification
{spec}

## Generated Code
```
{code}
```

## Derived Context
{context.to_json()}

## Test Case
{json.dumps(test_case.to_dict(), indent=2)}

## Actual Output
{json.dumps(actual_output, indent=2)}

## Expected Output
{json.dumps(expected_output, indent=2)}

## Previous Analyses
{previous_section}

Analyze this divergence and provide a diagnosis with fix."""

        # Call LLM
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

        response = await self.provider.generate(messages)
        response_text = response.get("text", "").strip()

        # Parse JSON response
        try:
            # Extract JSON from markdown code blocks if present
            if "```json" in response_text:
                start = response_text.find("```json") + 7
                end = response_text.find("```", start)
                response_text = response_text[start:end].strip()
            elif "```" in response_text:
                start = response_text.find("```") + 3
                end = response_text.find("```", start)
                response_text = response_text[start:end].strip()

            data = json.loads(response_text)

            return DiagnosedDivergence(
                divergence_id=test_case.id,
                diagnosis=data["diagnosis"],
                root_cause=data["root_cause"],
                source=data["source"],
                confidence=data["confidence"],
                fix=data["fix"],
                regression_test=data["regression_test"],
                follow_up_guidance=data["follow_up_guidance"],
                impact=data.get("impact", "Unknown impact"),
                blast_radius=data.get("blast_radius", "Unknown blast radius"),
            )

        except (json.JSONDecodeError, KeyError) as e:
            raise ValueError(f"Failed to parse analyzer response: {e}\nResponse: {response_text}")


    async def check_invariants(
        self,
        output: dict,
        invariants: list[str],
        context: ContextDerivation,
    ) -> dict[str, Any]:
        """
        Check if output satisfies behavioral invariants.

        Used in MODE 2 (oracle-from-invariants) when no system is available.

        Args:
            output: Function output to check
            invariants: List of invariants that must hold
            context: Full context derivation

        Returns:
            Dict with invariant_results, overall status, and violations
        """
        system_prompt = """You are a behavioral oracle. You will receive:
1. A function's output for a given input
2. A set of behavioral invariants that MUST hold
3. The system context

For each invariant, determine: HOLDS or VIOLATED.

Be precise. An invariant is only VIOLATED if the output definitively
contradicts it. If the output is consistent with the invariant but you
can't fully verify (e.g., you can't observe internal timing), mark it
as UNVERIFIABLE rather than assuming it holds.

Respond as:
{
  "invariant_results": [
    {
      "invariant": "Total retry delay must be bounded",
      "result": "HOLDS | VIOLATED | UNVERIFIABLE",
      "evidence": "..."
    }
  ],
  "overall": "PASS | FAIL | PARTIAL",
  "violations": ["list of violated invariant names"]
}"""

        user_message = f"""## Output
{json.dumps(output, indent=2)}

## Invariants to Check
{json.dumps(invariants, indent=2)}

## System Context
{context.to_json()}

Check each invariant and respond with results."""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

        response = await self.provider.generate(messages)
        response_text = response.get("text", "").strip()

        # Parse JSON response
        try:
            # Extract JSON from markdown code blocks if present
            if "```json" in response_text:
                start = response_text.find("```json") + 7
                end = response_text.find("```", start)
                response_text = response_text[start:end].strip()
            elif "```" in response_text:
                start = response_text.find("```") + 3
                end = response_text.find("```", start)
                response_text = response_text[start:end].strip()

            return json.loads(response_text)

        except (json.JSONDecodeError, KeyError) as e:
            raise ValueError(f"Failed to parse invariant check response: {e}\nResponse: {response_text}")
