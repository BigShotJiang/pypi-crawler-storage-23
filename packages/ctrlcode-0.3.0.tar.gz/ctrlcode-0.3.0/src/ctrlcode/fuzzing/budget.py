"""Budget management for fuzzing iterations."""

import time
from dataclasses import dataclass


@dataclass
class BudgetConfig:
    """Budget configuration."""

    max_tokens: int
    max_seconds: float
    max_iterations: int


class BudgetManager:
    """Manages time and token budgets for fuzzing."""

    def __init__(self, config: BudgetConfig):
        """
        Initialize budget manager.

        Args:
            config: Budget configuration
        """
        self.config = config
        self.start_time = time.time()
        self.tokens_used = 0
        self.iterations = 0

    def consume(self, tokens: int, elapsed_time: float) -> None:
        """
        Consume budget resources.

        Args:
            tokens: Number of tokens used
            elapsed_time: Time elapsed in seconds
        """
        self.tokens_used += tokens
        self.iterations += 1

    def exhausted(self) -> bool:
        """
        Check if budget is exhausted.

        Returns:
            True if any budget limit is reached
        """
        # Check iteration limit
        if self.iterations >= self.config.max_iterations:
            return True

        # Check token limit
        if self.tokens_used >= self.config.max_tokens:
            return True

        # Check time limit
        elapsed = time.time() - self.start_time
        if elapsed >= self.config.max_seconds:
            return True

        return False

    def remaining_tokens(self) -> int:
        """Get remaining token budget."""
        return max(0, self.config.max_tokens - self.tokens_used)

    def remaining_time(self) -> float:
        """Get remaining time budget in seconds."""
        elapsed = time.time() - self.start_time
        return max(0.0, self.config.max_seconds - elapsed)

    def remaining_iterations(self) -> int:
        """Get remaining iteration budget."""
        return max(0, self.config.max_iterations - self.iterations)

    def progress(self) -> dict[str, float]:
        """
        Get budget progress.

        Returns:
            Dict with progress percentages for each budget type
        """
        elapsed = time.time() - self.start_time

        return {
            "tokens": self.tokens_used / self.config.max_tokens,
            "time": elapsed / self.config.max_seconds,
            "iterations": self.iterations / self.config.max_iterations,
        }

    def summary(self) -> dict[str, int | float]:
        """
        Get budget summary.

        Returns:
            Dict with used and remaining amounts
        """
        return {
            "tokens_used": self.tokens_used,
            "tokens_remaining": self.remaining_tokens(),
            "time_elapsed": time.time() - self.start_time,
            "time_remaining": self.remaining_time(),
            "iterations_done": self.iterations,
            "iterations_remaining": self.remaining_iterations(),
        }

    def reset(self) -> None:
        """Reset budget counters."""
        self.start_time = time.time()
        self.tokens_used = 0
        self.iterations = 0
