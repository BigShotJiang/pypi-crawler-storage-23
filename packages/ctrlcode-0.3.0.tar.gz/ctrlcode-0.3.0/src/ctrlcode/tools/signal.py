"""Signal tools for LLM ↔ loop communication."""


SIGNAL_TOOL_SCHEMAS = [
    {
        "name": "task_complete",
        "description": (
            "Call this tool when you have finished the user's request. "
            "Provide a brief summary of what was accomplished. "
            "Do NOT call any other tools after this."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "summary": {
                    "type": "string",
                    "description": "Brief summary of what was accomplished",
                },
            },
            "required": ["summary"],
        },
    },
]


def task_complete(summary: str) -> dict:
    """Signal that the current task is complete."""
    return {"success": True, "summary": summary}
