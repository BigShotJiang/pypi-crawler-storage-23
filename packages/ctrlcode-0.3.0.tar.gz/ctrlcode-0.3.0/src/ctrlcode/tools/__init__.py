"""MCP tool system for ctrl-code."""

from pathlib import Path

from .mcp import MCPClient, MCPTool
from .registry import ToolRegistry, BuiltinTool
from .executor import ToolExecutor, ToolCallResult
from .explore import ExploreTools, EXPLORE_TOOL_SCHEMAS
from .todo import TodoTools, TODO_TOOL_SCHEMAS
from .bash import BashTools, BASH_TOOL_SCHEMAS
from .webfetch import WebFetchTools, WEBFETCH_TOOL_SCHEMAS
from .update import UpdateFileTools, UPDATE_TOOL_SCHEMAS
from .observability import ObservabilityTools, OBSERVABILITY_TOOL_SCHEMAS
from .browser import BrowserTools, BROWSER_TOOL_SCHEMAS, get_browser_tools
from .signal import SIGNAL_TOOL_SCHEMAS, task_complete


def setup_explore_tools(registry: ToolRegistry, workspace_root: str | Path) -> None:
    """
    Register built-in exploration tools.

    Args:
        registry: Tool registry to register tools in
        workspace_root: Root directory for file exploration
    """
    explore = ExploreTools(workspace_root)

    # Register each tool with its schema and function
    for schema in EXPLORE_TOOL_SCHEMAS:
        tool_name = schema["name"]

        # Map tool name to method
        function = getattr(explore, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )


def setup_todo_tools(registry: ToolRegistry, data_dir: str | Path) -> None:
    """
    Register built-in todo tools.

    Args:
        registry: Tool registry to register tools in
        data_dir: Data directory for storing todos
    """
    todo = TodoTools(data_dir)

    # Register each tool with its schema and function
    for schema in TODO_TOOL_SCHEMAS:
        tool_name = schema["name"]

        # Map tool name to method
        function = getattr(todo, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )

        # Also register as task_* alias for user flexibility
        task_alias = tool_name.replace("todo_", "task_")
        registry.register_builtin(
            name=task_alias,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )


def setup_bash_tools(registry: ToolRegistry, workspace_root: str | Path) -> None:
    """
    Register built-in bash tools.

    Args:
        registry: Tool registry to register tools in
        workspace_root: Root directory for command execution
    """
    bash = BashTools(workspace_root)

    # Register each tool with its schema and function
    for schema in BASH_TOOL_SCHEMAS:
        tool_name = schema["name"]

        # Map tool name to method
        function = getattr(bash, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )


def setup_webfetch_tools(registry: ToolRegistry) -> None:
    """
    Register built-in web fetch tools.

    Args:
        registry: Tool registry to register tools in
    """
    webfetch = WebFetchTools()

    # Register each tool with its schema and function
    for schema in WEBFETCH_TOOL_SCHEMAS:
        tool_name = schema["name"]

        # Map tool name to method
        function = getattr(webfetch, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )


def setup_update_tools(registry: ToolRegistry, workspace_root: str | Path) -> None:
    """
    Register built-in update file tools.

    Args:
        registry: Tool registry to register tools in
        workspace_root: Root directory for file operations
    """
    update = UpdateFileTools(workspace_root)

    # Register each tool with its schema and function
    for schema in UPDATE_TOOL_SCHEMAS:
        tool_name = schema["name"]

        # Map tool name to method
        function = getattr(update, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )


def setup_observability_tools(registry: ToolRegistry, log_dir: str | Path | None = None) -> None:
    """
    Register built-in observability tools.

    Args:
        registry: Tool registry to register tools in
        log_dir: Directory containing log files (optional)
    """
    observability = ObservabilityTools(log_dir)

    # Register each tool with its schema and function
    for schema in OBSERVABILITY_TOOL_SCHEMAS:
        tool_name = schema["name"]

        # Map tool name to method
        function = getattr(observability, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )


def setup_signal_tools(registry: ToolRegistry) -> None:
    """Register signal tools (task_complete, etc.)."""
    for schema in SIGNAL_TOOL_SCHEMAS:
        registry.register_builtin(
            name=schema["name"],
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=task_complete,
        )


def setup_browser_tools(registry: ToolRegistry) -> None:
    """
    Register built-in browser automation tools.

    Args:
        registry: Tool registry to register tools in
    """
    browser = get_browser_tools()

    # Register each tool with its schema and function
    for schema in BROWSER_TOOL_SCHEMAS:
        tool_name = schema["name"]

        # Map tool name to method
        function = getattr(browser, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=schema["description"],
            input_schema=schema["input_schema"],
            function=function,
        )


__all__ = [
    "MCPClient",
    "MCPTool",
    "ToolRegistry",
    "BuiltinTool",
    "ToolExecutor",
    "ToolCallResult",
    "ExploreTools",
    "TodoTools",
    "BashTools",
    "WebFetchTools",
    "UpdateFileTools",
    "ObservabilityTools",
    "BrowserTools",
    "setup_explore_tools",
    "setup_todo_tools",
    "setup_bash_tools",
    "setup_webfetch_tools",
    "setup_update_tools",
    "setup_observability_tools",
    "setup_signal_tools",
    "setup_browser_tools",
]
