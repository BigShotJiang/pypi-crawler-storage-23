"""Tool registry for managing MCP servers and tools."""

from typing import Any, Optional, Callable
import logging
from dataclasses import dataclass

from .mcp import MCPClient, MCPTool

logger = logging.getLogger(__name__)


@dataclass
class BuiltinTool:
    """Built-in tool definition."""

    name: str
    description: str
    input_schema: dict[str, Any]
    function: Callable


class ToolRegistry:
    """Registry for MCP and built-in tools."""

    def __init__(self):
        """Initialize tool registry."""
        self.clients: dict[str, MCPClient] = {}
        self.mcp_tools: dict[str, MCPTool] = {}  # tool_name -> MCPTool
        self.builtin_tools: dict[str, BuiltinTool] = {}  # tool_name -> BuiltinTool

    async def add_server(self, server_config: dict[str, Any]) -> None:
        """
        Add and start an MCP server.

        Args:
            server_config: Server configuration
        """
        server_name = server_config.get("name", "unknown")

        try:
            client = MCPClient(server_config)
            await client.start()

            # List tools
            tools = await client.list_tools()
            logger.info(f"Server '{server_name}' provides {len(tools)} tools")

            # Register tools
            for tool in tools:
                if tool.name in self.mcp_tools or tool.name in self.builtin_tools:
                    logger.warning(f"Tool '{tool.name}' already registered, skipping")
                else:
                    self.mcp_tools[tool.name] = tool

            # Store client
            self.clients[server_name] = client

        except Exception as e:
            logger.error(f"Failed to start server '{server_name}': {e}")

    def register_builtin(
        self,
        name: str,
        description: str,
        input_schema: dict[str, Any],
        function: Callable,
    ) -> None:
        """
        Register a built-in tool.

        Args:
            name: Tool name
            description: Tool description
            input_schema: JSON schema for tool inputs
            function: Callable that implements the tool
        """
        if name in self.mcp_tools or name in self.builtin_tools:
            logger.warning(f"Tool '{name}' already registered, skipping")
            return

        tool = BuiltinTool(
            name=name,
            description=description,
            input_schema=input_schema,
            function=function,
        )

        self.builtin_tools[name] = tool
        logger.info(f"Registered built-in tool: {name}")

    async def remove_server(self, server_name: str) -> None:
        """
        Remove and stop an MCP server.

        Args:
            server_name: Name of server to remove
        """
        if server_name in self.clients:
            client = self.clients[server_name]
            await client.stop()
            del self.clients[server_name]

            # Remove tools from this server
            self.mcp_tools = {
                name: tool
                for name, tool in self.mcp_tools.items()
                if tool.server_name != server_name
            }

    def get_tool(self, tool_name: str) -> Optional[MCPTool | BuiltinTool]:
        """
        Get tool by name (MCP or built-in).

        Args:
            tool_name: Name of tool

        Returns:
            Tool or None if not found
        """
        return self.mcp_tools.get(tool_name) or self.builtin_tools.get(tool_name)

    def is_builtin(self, tool_name: str) -> bool:
        """Check if tool is built-in."""
        return tool_name in self.builtin_tools

    def list_tools(self) -> list[MCPTool | BuiltinTool]:
        """
        List all available tools (MCP and built-in).

        Returns:
            List of all registered tools
        """
        return list(self.mcp_tools.values()) + list(self.builtin_tools.values())

    def get_client(self, server_name: str) -> Optional[MCPClient]:
        """
        Get MCP client by server name.

        Args:
            server_name: Server name

        Returns:
            Client or None if not found
        """
        return self.clients.get(server_name)

    def get_tool_definitions(self) -> list[dict[str, Any]]:
        """
        Get tool definitions in provider format (both MCP and built-in).

        Returns:
            List of tool definitions for LLM providers
        """
        definitions = []

        # MCP tools
        for tool in self.mcp_tools.values():
            definitions.append({
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.input_schema,
            })

        # Built-in tools
        for tool in self.builtin_tools.values():
            definitions.append({
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.input_schema,
            })

        return definitions

    def get_tool_definitions_filtered(self, allowed_tools: list[str]) -> list[dict[str, Any]]:
        """
        Get tool definitions filtered by allowed tool names.

        Args:
            allowed_tools: List of tool names to include

        Returns:
            Filtered list of tool definitions
        """
        all_tools = self.get_tool_definitions()
        return [tool for tool in all_tools if tool["name"] in allowed_tools]

    async def close_all(self) -> None:
        """Close all MCP clients."""
        for client in self.clients.values():
            await client.stop()
        self.clients.clear()
        self.mcp_tools.clear()
        self.builtin_tools.clear()
