"""Browser automation tools for UI validation via Chrome DevTools Protocol."""

import logging
import tempfile
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class BrowserTools:
    """Browser automation tools for screenshot capture and DOM inspection."""

    def __init__(self):
        """Initialize browser tools."""
        self._playwright = None
        self._browser = None

    async def _ensure_browser(self):
        """Ensure playwright browser is launched."""
        if self._browser is not None:
            return

        try:
            from playwright.async_api import async_playwright
        except ImportError:
            raise RuntimeError(
                "playwright not installed. Run: uv add playwright && uv run playwright install chromium"
            )

        if self._playwright is None:
            self._playwright = await async_playwright().start()

        self._browser = await self._playwright.chromium.launch(headless=True)

    async def _cleanup(self):
        """Cleanup browser resources."""
        if self._browser:
            await self._browser.close()
            self._browser = None
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None

    async def screenshot(
        self,
        url: str,
        output: str | None = None,
        full_page: bool = True,
        viewport_width: int = 1280,
        viewport_height: int = 720,
        wait_for: str | None = None,
        timeout: int = 30000,
    ) -> dict[str, Any]:
        """
        Capture screenshot of a web page.

        Args:
            url: URL to navigate to
            output: Output file path (defaults to temp file)
            full_page: Capture full scrollable page (default: True)
            viewport_width: Viewport width in pixels (default: 1280)
            viewport_height: Viewport height in pixels (default: 720)
            wait_for: CSS selector to wait for before screenshot (optional)
            timeout: Page load timeout in milliseconds (default: 30000)

        Returns:
            Dict with:
                - success: Whether screenshot succeeded
                - file_path: Path to screenshot file
                - url: URL that was captured
                - width: Image width
                - height: Image height
                - error: Error message if failed
        """
        try:
            await self._ensure_browser()

            # Create context with viewport
            context = await self._browser.new_context(
                viewport={"width": viewport_width, "height": viewport_height}
            )

            # Create page
            page = await context.new_page()

            # Navigate to URL
            await page.goto(url, timeout=timeout, wait_until="networkidle")

            # Wait for specific element if requested
            if wait_for:
                await page.wait_for_selector(wait_for, timeout=timeout)

            # Determine output path
            if output is None:
                screenshots_dir = Path.cwd() / ".ctrlcode" / "screenshots"
                screenshots_dir.mkdir(parents=True, exist_ok=True)
                temp_file = tempfile.NamedTemporaryFile(
                    suffix=".png", delete=False, dir=screenshots_dir
                )
                output = temp_file.name
                temp_file.close()
            else:
                output = str(Path(output).resolve())
                # Ensure output directory exists
                Path(output).parent.mkdir(parents=True, exist_ok=True)

            # Take screenshot
            await page.screenshot(path=output, full_page=full_page)

            # Get dimensions
            if full_page:
                dimensions = await page.evaluate(
                    "() => ({ width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight })"
                )
            else:
                dimensions = {"width": viewport_width, "height": viewport_height}

            await context.close()

            return {
                "success": True,
                "file_path": output,
                "url": url,
                "width": dimensions["width"],
                "height": dimensions["height"],
            }

        except Exception as e:
            logger.error(f"Screenshot failed: {e}", exc_info=True)
            return {"success": False, "error": str(e), "url": url}

    async def dom_snapshot(
        self,
        url: str,
        selector: str | None = None,
        include_styles: bool = False,
        timeout: int = 30000,
    ) -> dict[str, Any]:
        """
        Capture DOM structure snapshot for HTML inspection.

        Args:
            url: URL to navigate to
            selector: CSS selector to extract (defaults to full page)
            include_styles: Include computed styles (default: False)
            timeout: Page load timeout in milliseconds (default: 30000)

        Returns:
            Dict with:
                - success: Whether snapshot succeeded
                - url: URL that was captured
                - html: HTML content
                - text_content: Extracted text content
                - element_count: Number of elements
                - links: List of links found
                - forms: List of forms found
                - error: Error message if failed
        """
        try:
            await self._ensure_browser()

            # Create context
            context = await self._browser.new_context()
            page = await context.new_page()

            # Navigate to URL
            await page.goto(url, timeout=timeout, wait_until="networkidle")

            # Get element handle
            if selector:
                element = await page.query_selector(selector)
                if not element:
                    return {
                        "success": False,
                        "error": f"Selector '{selector}' not found",
                        "url": url,
                    }
                html = await element.inner_html()
                text_content = await element.text_content()
            else:
                html = await page.content()
                text_content = await page.evaluate("() => document.body.textContent")

            # Extract metadata
            element_count = await page.evaluate("() => document.querySelectorAll('*').length")

            # Extract links
            links = await page.evaluate(
                """() => {
                    return Array.from(document.querySelectorAll('a[href]')).map(a => ({
                        text: a.textContent.trim(),
                        href: a.href,
                        target: a.target
                    }));
                }"""
            )

            # Extract forms
            forms = await page.evaluate(
                """() => {
                    return Array.from(document.querySelectorAll('form')).map(form => ({
                        action: form.action,
                        method: form.method,
                        fields: Array.from(form.querySelectorAll('input, textarea, select')).map(field => ({
                            name: field.name,
                            type: field.type,
                            id: field.id
                        }))
                    }));
                }"""
            )

            await context.close()

            return {
                "success": True,
                "url": url,
                "html": html,
                "text_content": text_content.strip() if text_content else "",
                "element_count": element_count,
                "links": links,
                "forms": forms,
            }

        except Exception as e:
            logger.error(f"DOM snapshot failed: {e}", exc_info=True)
            return {"success": False, "error": str(e), "url": url}

    async def close(self):
        """Close browser and cleanup resources."""
        await self._cleanup()


# Singleton instance
_browser_tools = None


def get_browser_tools() -> BrowserTools:
    """Get or create singleton BrowserTools instance."""
    global _browser_tools
    if _browser_tools is None:
        _browser_tools = BrowserTools()
    return _browser_tools


async def cleanup_browser_tools():
    """Cleanup singleton browser tools."""
    global _browser_tools
    if _browser_tools is not None:
        await _browser_tools.close()
        _browser_tools = None


BROWSER_TOOL_SCHEMAS = [
    {
        "name": "screenshot",
        "description": """Capture screenshot of a web page for UI validation.

Useful for verifying:
- Page renders correctly after changes
- UI elements are visible and positioned correctly
- Visual regressions
- Responsive design at different viewports

Returns file path to PNG screenshot that can be analyzed.

Examples:
- screenshot(url="http://localhost:8000") - Capture full page
- screenshot(url="http://localhost:8000/login", wait_for=".login-form") - Wait for element
- screenshot(url="http://localhost:8000", full_page=False) - Viewport only""",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL to navigate to and capture"
                },
                "output": {
                    "type": "string",
                    "description": "Output file path (optional, defaults to temp file)"
                },
                "full_page": {
                    "type": "boolean",
                    "description": "Capture full scrollable page (default: true)",
                    "default": True
                },
                "viewport_width": {
                    "type": "integer",
                    "description": "Viewport width in pixels (default: 1280)",
                    "default": 1280
                },
                "viewport_height": {
                    "type": "integer",
                    "description": "Viewport height in pixels (default: 720)",
                    "default": 720
                },
                "wait_for": {
                    "type": "string",
                    "description": "CSS selector to wait for before screenshot (optional)"
                },
                "timeout": {
                    "type": "integer",
                    "description": "Page load timeout in milliseconds (default: 30000)",
                    "default": 30000
                }
            },
            "required": ["url"]
        }
    },
    {
        "name": "dom_snapshot",
        "description": """Capture DOM structure snapshot for HTML inspection.

Useful for:
- Verifying page structure and content
- Extracting text, links, forms
- Debugging rendering issues
- Validating SEO elements

Returns HTML content, text, element count, links, and forms.

Examples:
- dom_snapshot(url="http://localhost:8000") - Full page snapshot
- dom_snapshot(url="http://localhost:8000", selector=".main-content") - Specific element
- dom_snapshot(url="http://localhost:8000/api/docs", include_styles=True) - With styles""",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL to navigate to and capture"
                },
                "selector": {
                    "type": "string",
                    "description": "CSS selector to extract (optional, defaults to full page)"
                },
                "include_styles": {
                    "type": "boolean",
                    "description": "Include computed styles (default: false)",
                    "default": False
                },
                "timeout": {
                    "type": "integer",
                    "description": "Page load timeout in milliseconds (default: 30000)",
                    "default": 30000
                }
            },
            "required": ["url"]
        }
    }
]
