"""Built-in file update tools for modifying existing files."""

import fcntl
import re
from pathlib import Path
from typing import Any
import signal
from contextlib import contextmanager


class UpdateFileTools:
    """Built-in tools for updating file contents."""

    def __init__(self, workspace_root: str | Path):
        """
        Initialize update tools.

        Args:
            workspace_root: Root directory for file operations
        """
        self.workspace_root = Path(workspace_root).resolve()

    @staticmethod
    def _validate_regex_pattern(pattern: str) -> tuple[bool, str]:
        """
        Validate regex pattern to prevent ReDoS attacks.

        Args:
            pattern: Regex pattern to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        # Length limit to prevent excessive complexity
        if len(pattern) > 500:
            return False, "Pattern too long (max 500 chars)"

        # Check for dangerous nested quantifiers that cause catastrophic backtracking
        dangerous_patterns = [
            r'\([^)]*\+[^)]*\)\+',  # (a+)+ style
            r'\([^)]*\*[^)]*\)\+',  # (a*)+ style
            r'\([^)]*\+[^)]*\)\*',  # (a+)* style
            r'\([^)]*\*[^)]*\)\*',  # (a*)* style
        ]

        for dangerous in dangerous_patterns:
            if re.search(dangerous, pattern):
                return False, "Pattern contains nested quantifiers that may cause ReDoS"

        # Try to compile pattern to check validity
        try:
            re.compile(pattern)
        except re.error as e:
            return False, f"Invalid regex pattern: {e}"

        return True, ""

    @contextmanager
    def _regex_timeout(self, seconds: int = 1):
        """Context manager to timeout regex operations."""
        def timeout_handler(signum, frame):
            raise TimeoutError("Regex search timed out")

        # Set alarm (Unix only)
        old_handler = signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(seconds)
        try:
            yield
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

    def update_file(
        self,
        path: str,
        operation: str,
        start_line: int | None = None,
        end_line: int | None = None,
        content: str | None = None,
        search_pattern: str | None = None,
    ) -> dict[str, Any]:
        """
        Update a file by replacing, inserting, or deleting lines.

        Args:
            path: File path relative to workspace root
            operation: Operation to perform (replace, insert, delete)
            start_line: Start line number (1-indexed, inclusive)
            end_line: End line number (1-indexed, inclusive)
            content: Content for replace/insert operations
            search_pattern: Regex pattern to find target lines (alternative to line numbers)

        Returns:
            Dict with success status and metadata
        """
        try:
            file_path = (self.workspace_root / path).resolve()

            # Security: ensure path is within workspace
            if not str(file_path).startswith(str(self.workspace_root)):
                return {"error": "Path outside workspace"}

            if not file_path.exists():
                msg = f"File not found: '{path}'."
                if not file_path.parent.exists():
                    msg += " Parent directory does not exist."
                msg += " Use write_file to create it (write_file creates parent directories automatically)."
                return {"error": msg}

            if not file_path.is_file():
                return {"error": "Not a file"}

            # Validate operation
            if operation not in ["replace", "insert", "delete"]:
                return {"error": f"Invalid operation: {operation}"}

            # Read file
            with open(file_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            total_lines = len(lines)
            original_line_count = total_lines

            # Determine target line range
            if search_pattern:
                # Security: validate regex pattern to prevent ReDoS
                is_valid, error_msg = self._validate_regex_pattern(search_pattern)
                if not is_valid:
                    return {"error": f"Invalid search pattern: {error_msg}"}

                # Find lines matching pattern with timeout protection
                matches = []
                try:
                    with self._regex_timeout(seconds=2):
                        compiled_pattern = re.compile(search_pattern)
                        for i, line in enumerate(lines, 1):
                            if compiled_pattern.search(line):
                                matches.append(i)
                except TimeoutError:
                    return {"error": "Regex search timed out - pattern may be too complex"}

                if not matches:
                    return {
                        "error": f"Pattern '{search_pattern}' not found in '{path}'. File may have changed since last read.",
                        "current_content": "".join(lines),
                        "total_lines": total_lines,
                    }

                # Use first match for single-line operations, or all matches for multi-line
                if operation == "delete" and len(matches) > 1:
                    # Delete all matching lines
                    start_line = matches[0]
                    end_line = matches[-1]
                else:
                    start_line = matches[0]
                    end_line = matches[0]

            # Validate line numbers
            if start_line is None:
                return {"error": "start_line or search_pattern required"}

            if start_line < 1 or start_line > total_lines:
                return {
                    "error": f"start_line {start_line} out of range — file has {total_lines} lines. File may have changed since last read.",
                    "current_content": "".join(lines),
                    "total_lines": total_lines,
                }

            if end_line is None:
                end_line = start_line

            if end_line < start_line or end_line > total_lines:
                return {
                    "error": f"end_line {end_line} invalid (valid range: {start_line}–{total_lines}). File may have changed since last read.",
                    "current_content": "".join(lines),
                    "total_lines": total_lines,
                }

            # Perform operation
            if operation == "replace":
                if content is None:
                    return {"error": "content required for replace operation"}

                # Ensure content ends with newline
                if not content.endswith("\n"):
                    content += "\n"

                # Replace lines
                new_lines = lines[: start_line - 1] + [content] + lines[end_line:]

            elif operation == "insert":
                if content is None:
                    return {"error": "content required for insert operation"}

                # Ensure content ends with newline
                if not content.endswith("\n"):
                    content += "\n"

                # Insert at line (before start_line)
                new_lines = lines[: start_line - 1] + [content] + lines[start_line - 1 :]

            elif operation == "delete":
                # Delete lines
                new_lines = lines[: start_line - 1] + lines[end_line:]

            else:
                return {"error": f"Unsupported operation: {operation}"}

            # Write file atomically with locking
            temp_path = file_path.with_suffix(file_path.suffix + ".tmp")

            try:
                # Write to temp file with exclusive lock
                with open(temp_path, "w", encoding="utf-8") as f:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                    try:
                        f.writelines(new_lines)
                        f.flush()
                    finally:
                        fcntl.flock(f.fileno(), fcntl.LOCK_UN)

                # Atomic rename
                temp_path.replace(file_path)

            except Exception as e:
                if temp_path.exists():
                    temp_path.unlink()
                raise e

            return {
                "success": True,
                "path": str(file_path),  # Return absolute path so TUI can read it back
                "operation": operation,
                "lines_before": original_line_count,
                "lines_after": len(new_lines),
                "affected_range": f"{start_line}-{end_line}",
            }

        except UnicodeDecodeError:
            return {"error": "File is binary or uses unsupported encoding"}
        except Exception as e:
            return {"error": str(e)}


# Tool schemas for LLM providers (Anthropic/OpenAI format)
UPDATE_TOOL_SCHEMAS = [
    {
        "name": "update_file",
        "description": "**USE THIS** to modify existing files. Replaces, inserts, or deletes specific line ranges. WORKFLOW: (1) read_file to see current content, (2) determine which lines to modify, (3) call update_file with line numbers and new content.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "File path relative to workspace root",
                },
                "operation": {
                    "type": "string",
                    "description": "Operation to perform",
                    "enum": ["replace", "insert", "delete"],
                },
                "start_line": {
                    "type": "integer",
                    "description": "Start line number (1-indexed, inclusive). Required unless using search_pattern.",
                },
                "end_line": {
                    "type": "integer",
                    "description": "End line number (1-indexed, inclusive). Defaults to start_line if not specified.",
                },
                "content": {
                    "type": "string",
                    "description": "Content for replace/insert operations",
                },
                "search_pattern": {
                    "type": "string",
                    "description": "Regex pattern to find target lines (alternative to line numbers)",
                },
            },
            "required": ["path", "operation"],
        },
    },
]
