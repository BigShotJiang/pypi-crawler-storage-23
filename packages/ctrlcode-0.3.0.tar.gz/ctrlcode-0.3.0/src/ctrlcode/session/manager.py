"""Session management using harness-utils."""

import asyncio
import logging
from typing import Any, AsyncIterator, Callable, Optional
from dataclasses import dataclass
from pathlib import Path
import uuid

from harnessutils import ConversationManager, Message, TextPart
from harnessutils.storage import FilesystemStorage
from harnessutils.config import HarnessConfig, StorageConfig

from ..providers.base import Provider, StreamEvent
from .baseline import BaselineManager, Baseline
from ..fuzzing.derived_orchestrator import DerivedFuzzingOrchestrator
from ..tools.executor import ToolExecutor
from ..tools.registry import ToolRegistry
from ..skills.registry import SkillRegistry

logger = logging.getLogger(__name__)


@dataclass
class ReactConfig:
    """Configuration for the ReAct loop."""

    mid_task_compaction: bool = False   # Tier 3 LLM summarization mid-task (costly)
    doom_loop_threshold: int = 3        # Identical calls in a row before bail-out
    max_continuations: int = 50         # Safety cap on iterations


class LLMClientAdapter:
    """Bridges ctrl+code Provider to harness-utils LLMClient (synchronous interface).

    compact() is synchronous and called from a thread executor.
    invoke() submits provider.generate() to the running event loop and blocks.
    """

    def __init__(self, provider: Provider, loop: asyncio.AbstractEventLoop):
        self._provider = provider
        self._loop = loop

    def invoke(
        self,
        messages: list[dict],
        system: list[str] | None = None,
        model: str | None = None,
    ) -> dict:
        all_messages = messages
        if system:
            all_messages = [{"role": "system", "content": "\n".join(system)}] + messages
        future = asyncio.run_coroutine_threadsafe(
            self._provider.generate(all_messages), self._loop
        )
        result = future.result(timeout=120)
        return {
            "content": result.get("text", ""),
            "usage": {
                "input": result.get("usage", {}).get("prompt_tokens", 0),
                "output": result.get("usage", {}).get("completion_tokens", 0),
            },
            "model": result.get("model", ""),
        }


def strip_markdown_fences(content: str) -> str:
    """Remove markdown code fences from content if present."""
    lines = content.splitlines()

    # Check if first line is a code fence
    if lines and lines[0].strip().startswith("```"):
        # Remove first line
        lines = lines[1:]

    # Check if last line is a closing fence
    if lines and lines[-1].strip() == "```":
        # Remove last line
        lines = lines[:-1]

    # Remove any trailing instruction lines (e.g., "Run with: ...")
    while lines and lines[-1].strip().startswith("Run with:"):
        lines = lines[:-1]

    return "\n".join(lines)


@dataclass
class Session:
    """Represents a conversation session."""

    id: str
    conv_id: str
    provider: Provider
    cumulative_tokens: int = 0  # Track total tokens used across all turns


class SessionManager:
    """Manages conversation sessions with baseline tracking."""

    def __init__(
        self,
        provider: Provider,
        storage_path: str,
        config: Optional[HarnessConfig] = None,
        fuzzing_orchestrator: Optional[DerivedFuzzingOrchestrator] = None,
        fuzzing_enabled: bool = False,
        tool_executor: Optional[ToolExecutor] = None,
        tool_registry: Optional[ToolRegistry] = None,
        skill_registry: Optional[SkillRegistry] = None,
        context_limit: int = 200000,
        workspace_root: Optional[Path] = None,
        react_config: Optional[ReactConfig] = None,
    ):
        """
        Initialize session manager.

        Args:
            provider: LLM provider to use
            storage_path: Path for conversation storage
            config: Optional harness config
            fuzzing_orchestrator: Optional fuzzing orchestrator
            fuzzing_enabled: Whether to use fuzzing
            tool_executor: Optional tool executor for MCP tools
            tool_registry: Optional tool registry for tool definitions
            skill_registry: Optional skill registry
            context_limit: Context window limit
            workspace_root: Workspace root for AGENT.md lookup
        """
        storage_config = StorageConfig(base_path=Path(storage_path))
        self.conv_manager = ConversationManager(
            storage=FilesystemStorage(storage_config),
            config=config or HarnessConfig()
        )
        self.provider = provider
        self.sessions: dict[str, Session] = {}
        self.baseline_manager = BaselineManager()
        self.fuzzing_orchestrator = fuzzing_orchestrator
        self.fuzzing_enabled = fuzzing_enabled
        self.tool_executor = tool_executor
        self.tool_registry = tool_registry
        self.skill_registry = skill_registry
        self.context_limit = context_limit
        self.workspace_root = workspace_root
        self.react_config = react_config or ReactConfig()
        self._base_prompt = self._load_base_prompt()
        self._agent_instructions = self._load_agent_instructions()

    def _load_base_prompt(self) -> str:
        """
        Load base system prompt from prompts/SYSTEM_PROMPT.md.

        Search order:
        1. {workspace_root}/prompts/SYSTEM_PROMPT.md  (project override)
        2. ~/.config/ctrlcode/SYSTEM_PROMPT.md         (user global override)
        3. Bundled default

        Returns:
            Base system prompt content.
        """
        candidates = []

        # 1. Project-local override
        if self.workspace_root:
            candidates.append(self.workspace_root / "prompts" / "SYSTEM_PROMPT.md")

        # 2. User global override
        try:
            from platformdirs import user_config_dir
            candidates.append(Path(user_config_dir("ctrlcode")) / "SYSTEM_PROMPT.md")
        except Exception:
            pass

        for prompt_file in candidates:
            if prompt_file.exists():
                try:
                    content = prompt_file.read_text(encoding="utf-8")
                    logger.info(f"Loaded system prompt from {prompt_file} ({len(content)} chars)")
                    return content
                except Exception as e:
                    logger.warning(f"Failed to load {prompt_file}: {e}")

        # 3. Bundled default
        logger.debug("Using bundled default system prompt")
        return """You are Ctrl+Code, Canoozie's personal coding assistant.

## CRITICAL: Never introduce yourself

**NEVER** say "I'm ready to help", "I have access to tools", or introduce your capabilities.
**NEVER** greet the user or ask what they want when they've already told you.

## Response strategy

Match your approach to the task:

### Quick tasks (single file, clear target)
Act immediately with tool calls. No preamble.
- "show me the last git commit" → `run_command` with `git log -1`
- "read app.py" → `read_file` with `app.py`

### Project creation (new app, service, or library)
Think before acting. Plan the structure, then create files one by one.
1. Config/dependencies first (go.mod, package.json, pyproject.toml)
2. Scaffold structure following language-standard layouts
3. Separate concerns: thin entry point, logic in modules, types in own files
4. Verify: run build/compile to confirm it works

**Never dump everything into a single file.**

### Existing codebase work
Explore first, then modify. Read relevant files, match existing conventions, verify with tests/builds.

## Tools available

- `run_command` — run shell commands (git, tests, builds, etc.)
- `read_file` — read a file's contents
- `write_file` — create a new file
- `update_file` — edit an existing file
- `search_files` — find files by glob pattern
- `search_code` — search for code by content
- `list_directory` — list directory contents
- `web_fetch` — fetch a URL
- `task_complete` — **call this when you are done** with the user's request, passing a summary

## Tool usage rules

- Call tools directly — no "let me..." preamble
- Call ALL independent tools in a SINGLE response when possible
- Use `run_command` for git operations, tests, builds, and any shell commands
- Use `read_file` / `search_files` / `search_code` for exploring the codebase
- Use `update_file` to edit existing files, `write_file` only for new files
- When referencing code, include `file_path:line_number` so the user can navigate to it
- **Always call `task_complete`** as the final tool call when the task is finished

## Workspace and file paths

- Use relative paths (`src/main.py`) not absolute paths (`/home/user/src/main.py`)
- If unsure of a file's location, call `search_files` first

## Tone

- Be concise and direct. No emojis unless asked. Output renders in a monospace terminal."""

    def _load_agent_instructions(self) -> str:
        """
        Load AGENT.md instructions hierarchically.

        Order (most general to most specific):
        1. Global: ~/.config/ctrlcode/AGENT.md
        2. Project: {workspace_root}/AGENT.md

        Returns combined instructions with clear section markers.
        """
        instructions = []

        # 1. Global config AGENT.md
        try:
            from platformdirs import user_config_dir
            config_dir = Path(user_config_dir("ctrlcode"))
            global_agent = config_dir / "AGENT.md"
            if global_agent.exists():
                content = global_agent.read_text(encoding="utf-8")
                instructions.append(f"# Global Agent Instructions\n\n{content}")
                logger.info(f"Loaded global AGENT.md ({len(content)} chars)")
        except Exception as e:
            logger.debug(f"No global AGENT.md: {e}")

        # 2. Project AGENT.md
        if self.workspace_root:
            project_agent = self.workspace_root / "AGENT.md"
            if project_agent.exists():
                try:
                    content = project_agent.read_text(encoding="utf-8")
                    instructions.append(f"# Project-Specific Instructions\n\n{content}")
                    logger.info(f"Loaded project AGENT.md ({len(content)} chars)")
                except Exception as e:
                    logger.warning(f"Failed to load project AGENT.md: {e}")

        return "\n\n---\n\n".join(instructions) if instructions else ""

    def create_session(self, provider: Optional[Provider] = None) -> Session:
        """
        Create a new session.

        Args:
            provider: Optional provider override

        Returns:
            New session instance
        """
        conv = self.conv_manager.create_conversation(project_id="ctrl-code")
        session = Session(
            id=str(uuid.uuid4()),
            conv_id=conv.id,
            provider=provider or self.provider
        )
        self.sessions[session.id] = session
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        """Get session by ID."""
        return self.sessions.get(session_id)

    async def process_turn(
        self,
        session_id: str,
        user_input: str,
        tools: list[dict] | None = None
    ) -> AsyncIterator[StreamEvent]:
        """
        Process a conversation turn.

        Args:
            session_id: Session identifier
            user_input: User's input message
            tools: Optional tool definitions

        Yields:
            StreamEvent: Streaming events from provider
        """
        session = self.sessions.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")

        # Expand skills if present
        if self.skill_registry:
            expanded_input, was_skill = self.skill_registry.process_input(user_input)
            if was_skill:
                yield StreamEvent(
                    type="skill_expanded",
                    data={"original": user_input, "expanded": expanded_input}
                )
                user_input = expanded_input

        # Extract baseline if present
        baseline_code = self.baseline_manager.extract_from_request(user_input)
        if baseline_code:
            self.baseline_manager.store(session_id, Baseline(code=baseline_code))

        # Prune before adding new user message (makes room for the new turn)
        self.conv_manager.prune_before_turn(session.conv_id)

        # Add user message
        user_msg = Message(id=self._generate_msg_id(), role="user")
        user_msg.add_part(TextPart(text=user_input))
        self.conv_manager.add_message(session.conv_id, user_msg)

        # Track context size before LLM call for accurate token delta
        session.context_before_turn = self.conv_manager.calculate_context_usage(
            session.conv_id,
            model=session.provider.model
        )

        # Get messages for LLM
        messages = self.conv_manager.to_model_format(session.conv_id)
        logger.info(f"to_model_format: {len(messages)} messages, roles={[m.get('role') for m in messages]}")

        # Get tool definitions from registry if not provided
        if tools is None and self.tool_registry:
            tools = self.tool_registry.get_tool_definitions()
            logger.info(f"Fetched {len(tools)} tool definitions from registry")
        else:
            logger.info(f"Tools parameter: {tools}")

        # Build system prompt once; reuse for all continuation calls
        system_prompt_msg: dict | None = None
        if not messages or messages[0].get("role") != "system":
            agent_section = ""
            if self._agent_instructions:
                agent_section = f"\n\n{self._agent_instructions}"

            import platform
            from datetime import date
            work_dir = self.workspace_root or Path.cwd()
            is_git = (work_dir / ".git").exists()
            env_section = f"""
**Environment:**
```
Working directory: {work_dir}
Is directory a git repo: {"Yes" if is_git else "No"}
Platform: {platform.system().lower()}
OS Version: {platform.platform()}
Today's date: {date.today().isoformat()}
```"""

            system_prompt_msg = {
                "role": "system",
                "content": f"{self._base_prompt}{agent_section}{env_section}"
            }

        # Messages for fuzzing context — include system prompt
        fuzz_messages = [system_prompt_msg] + messages if system_prompt_msg else messages

        # Build mid-task compaction adapter if enabled
        compaction_client: LLMClientAdapter | None = None
        if self.react_config.mid_task_compaction:
            compaction_client = LLMClientAdapter(
                session.provider, asyncio.get_running_loop()
            )

        # Delegate to AgentReActLoop
        from ..agents.react_loop import AgentReActLoop

        usage_tokens = 0
        loop = AgentReActLoop()

        async for event in loop.stream(
            provider=session.provider,
            conv_manager=self.conv_manager,
            conv_id=session.conv_id,
            tool_executor=self.tool_executor,
            tools=tools,
            system_prompt_msg=system_prompt_msg,
            max_continuations=self.react_config.max_continuations,
            doom_loop_threshold=self.react_config.doom_loop_threshold,
            compaction_client=compaction_client,
            pre_tool_hook=self._make_pre_tool_hook(user_input, session_id, fuzz_messages),
            post_tool_hook=self._make_post_tool_hook(session_id),
        ):
            if event.type == "usage":
                usage_tokens += event.data.get("usage", {}).get("completion_tokens", 0)
                # Emit intermediate token_usage so TUI context counter updates each LLM turn
                intermediate_context = self.conv_manager.calculate_context_usage(
                    session.conv_id, model=session.provider.model
                )
                yield StreamEvent(
                    type="token_usage",
                    data={
                        "total_tokens": intermediate_context,
                        "output_tokens": usage_tokens,
                        "turn_tokens": 0,
                        "input_tokens": 0,
                    },
                )
            yield event

        # Calculate exact token usage AFTER turn
        context_after = self.conv_manager.calculate_context_usage(
            session.conv_id,
            model=session.provider.model
        )
        context_before = session.context_before_turn if hasattr(session, 'context_before_turn') else 0
        total_turn_tokens = context_after - context_before

        if usage_tokens > 0:
            session.cumulative_tokens += usage_tokens

        yield StreamEvent(
            type="token_usage",
            data={
                "total_tokens": context_after,
                "turn_tokens": total_turn_tokens,
                "output_tokens": usage_tokens,
                "input_tokens": total_turn_tokens - usage_tokens if total_turn_tokens > usage_tokens else 0,
            }
        )

    def _make_pre_tool_hook(
        self,
        user_input: str,
        session_id: str,
        messages: list[dict],
    ) -> Callable:
        """Build a pre-tool hook that strips markdown and optionally fuzzes content."""
        async def hook(tool_call: dict) -> AsyncIterator[StreamEvent]:
            # Strip markdown fences from write/update content
            if tool_call["tool"] in ("write_file", "update_file"):
                content = tool_call["input"].get("content", "")
                if content:
                    tool_call["input"]["content"] = strip_markdown_fences(content)

            # Fuzz write/update content if fuzzing is enabled
            async for ev in self._maybe_fuzz_tool_content(
                tool_call, user_input, session_id, messages
            ):
                yield ev

        return hook

    def _make_post_tool_hook(self, session_id: str) -> Callable:
        """Build a post-tool hook that handles auto-chaining."""
        async def hook(tool_call: dict, result: Any) -> AsyncIterator[StreamEvent]:
            session = self.sessions.get(session_id)
            if not session or not result.success:
                return

            chained = self._check_auto_chain(tool_call["tool"], result.result)
            if not chained:
                return

            logger.info(f"Auto-chaining: {tool_call['tool']} → {chained['tool']}")
            res = await self.tool_executor.execute(
                tool_name=chained["tool"],
                arguments=chained["arguments"],
                call_id=chained["call_id"],
            )

            yield StreamEvent(
                type="tool_result",
                data={
                    "tool": chained["tool"],
                    "success": res.success,
                    "result": res.result if res.success else res.error,
                },
            )

            # Persist chained result to conversation
            result_msg = Message(id=self._generate_msg_id(), role="user")
            result_text = f"[Tool: {chained['tool']}]\n"
            result_text += f"Result: {res.result}" if res.success else f"Error: {res.error}"
            result_msg.add_part(TextPart(text=result_text))
            self.conv_manager.add_message(session.conv_id, result_msg)

        return hook


    def get_baseline(self, session_id: str) -> Optional[Baseline]:
        """Get baseline for session."""
        return self.baseline_manager.get(session_id)

    def get_context_stats(self, session_id: str) -> dict[str, Any]:
        """Get context statistics for session."""
        session = self.sessions.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")

        # Get conversation messages from harness-utils
        messages = self.conv_manager.to_model_format(session.conv_id)

        # Calculate exact token count using harness-utils
        token_count = self.conv_manager.calculate_context_usage(
            session.conv_id,
            model=session.provider.model
        )

        logger.info(f"Context stats for {session_id}: {len(messages)} messages, {token_count} tokens")

        return {
            "message_count": len(messages),
            "estimated_tokens": token_count,
            "max_tokens": self.context_limit,
        }

    def compact_conversation(self, session_id: str) -> None:
        """Compact conversation using harness-utils."""
        session = self.sessions.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")

        # Trigger compaction manually
        self.conv_manager.prune_before_turn(session.conv_id)

    def clear_conversation(self, session_id: str) -> None:
        """Clear conversation history."""
        session = self.sessions.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")

        # Create a new conversation to replace the old one
        old_conv_id = session.conv_id
        new_conv = self.conv_manager.create_conversation(project_id="ctrl-code")
        session.conv_id = new_conv.id

        # Reset cumulative tokens
        session.cumulative_tokens = 0

        logger.info(f"Cleared conversation history for session {session_id} (old: {old_conv_id}, new: {new_conv.id})")

    def _generate_msg_id(self) -> str:
        """Generate message ID."""
        return f"msg_{uuid.uuid4().hex[:12]}"

    async def _maybe_fuzz_tool_content(
        self,
        tool_call: dict,
        user_input: str,
        session_id: str,
        messages: list[dict],
    ) -> AsyncIterator[StreamEvent]:
        """Fuzz write_file/update_file content in-place before execution.

        No-ops for non-write tools or when fuzzing is disabled.
        Mutates tool_call["input"]["content"] with the fuzzed output.

        Yields:
            StreamEvent: fuzzing_progress and fuzzing_complete events.
        """
        if tool_call["tool"] not in ("write_file", "update_file"):
            return
        if not self.fuzzing_enabled or not self.fuzzing_orchestrator:
            return

        content = tool_call["input"].get("content", "")
        if not content:
            return

        path = tool_call["input"].get("path", "<unknown>")

        # Skip fuzzing for trivially small files (configs, manifests, etc.)
        _SKIP_EXTENSIONS = {
            ".json", ".toml", ".yaml", ".yml", ".lock", ".env",
            ".gitignore", ".editorconfig", ".prettierrc",
        }
        _SKIP_SUFFIXES = {
            "config.js", "config.ts", "config.mjs", "config.cjs",
        }
        MIN_FUZZ_LINES = 20

        ext = Path(path).suffix.lower()
        name = Path(path).name.lower()
        line_count = content.count("\n") + 1

        if ext in _SKIP_EXTENSIONS or any(name.endswith(s) for s in _SKIP_SUFFIXES):
            logger.info(f"Skipping fuzzing for config/manifest file: {path}")
            return
        if line_count < MIN_FUZZ_LINES:
            logger.info(f"Skipping fuzzing for small file ({line_count} lines): {path}")
            return

        logger.info(f"Inline fuzzing {tool_call['tool']} for {path} ({line_count} lines)")

        yield StreamEvent(
            type="fuzzing_progress",
            data={"stage": "starting", "message": f"Improving {path}..."},
        )

        from ..fuzzing.derived_orchestrator import FuzzingResult

        result = None
        async for event in self.fuzzing_orchestrator.fuzz(
            user_request=user_input,
            generated_code=content,
            context_messages=messages,
        ):
            if isinstance(event, FuzzingResult):
                result = event
                yield StreamEvent(
                    type="fuzzing_complete",
                    data={
                        "iterations": result.iterations,
                        "quality_score": result.quality_score,
                        "budget_used": result.budget_used,
                        "divergences_found": result.divergences_found,
                        "divergences_fixed": result.divergences_fixed,
                        "oracle_corrections": result.oracle_corrections,
                    },
                )
            else:
                yield event

        if result:
            tool_call["input"]["content"] = strip_markdown_fences(result.final_output)
            logger.info(f"Fuzzed {path}: score={result.quality_score}")

    def _check_auto_chain(self, tool_name: str, result: dict) -> dict | None:
        """
        Check if we should auto-chain to another tool call.

        Args:
            tool_name: Name of the tool that just executed
            result: Result from the tool

        Returns:
            Dict with tool call info if should chain, None otherwise
        """
        # search_files → read_file (if exactly 1 file found)
        if tool_name == "search_files":
            # Result is a list of file paths
            if isinstance(result, list) and len(result) == 1:
                file_path = result[0]
                return {
                    "tool": "read_file",
                    "arguments": {"path": file_path},
                    "call_id": f"auto_{uuid.uuid4().hex[:12]}"
                }

        return None

