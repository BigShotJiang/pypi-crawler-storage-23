"""Baseline code tracking for differential analysis."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Baseline:
    """Stores baseline code for comparison during fuzzing."""

    code: str
    file_path: Optional[str] = None
    language: str = "python"
    context: dict[str, str] = field(default_factory=dict)


class BaselineManager:
    """Manages baseline code extraction and storage."""

    def __init__(self):
        self.baselines: dict[str, Baseline] = {}

    def store(self, session_id: str, baseline: Baseline) -> None:
        """Store baseline for a session."""
        self.baselines[session_id] = baseline

    def get(self, session_id: str) -> Optional[Baseline]:
        """Retrieve baseline for a session."""
        return self.baselines.get(session_id)

    def has_baseline(self, session_id: str) -> bool:
        """Check if session has a baseline."""
        return session_id in self.baselines

    def clear(self, session_id: str) -> None:
        """Clear baseline for a session."""
        if session_id in self.baselines:
            del self.baselines[session_id]

    def extract_from_request(self, user_input: str) -> Optional[str]:
        """
        Extract existing code from user request.

        Looks for code blocks in the request that represent
        the current implementation to be improved.
        """
        # Simple extraction: look for ```python blocks
        import re

        pattern = r"```(?:python)?\n(.*?)\n```"
        matches = re.findall(pattern, user_input, re.DOTALL)

        if matches:
            # Return first code block as baseline
            return matches[0]

        return None
