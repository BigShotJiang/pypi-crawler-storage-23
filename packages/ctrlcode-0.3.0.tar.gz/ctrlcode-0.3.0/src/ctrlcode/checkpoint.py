"""Checkpoint manager for workflow execution pauses."""

import asyncio
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class CheckpointManager:
    """Manages workflow checkpoint pauses via asyncio.Future-based blocking."""

    def __init__(self):
        self._pending: dict[str, asyncio.Future] = {}

    async def request_checkpoint(self, checkpoint_id: str, timeout: float = 300.0) -> bool:
        """Block until user responds to checkpoint.

        Args:
            checkpoint_id: Unique checkpoint ID
            timeout: Seconds to wait before auto-continuing (default 5 min)

        Returns:
            True to continue, False to abort
        """
        future: asyncio.Future[bool] = asyncio.Future()
        self._pending[checkpoint_id] = future

        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning(f"Checkpoint {checkpoint_id} timed out — auto-continuing")
            return True
        finally:
            self._pending.pop(checkpoint_id, None)

    def handle_checkpoint_response(self, checkpoint_id: str, action: str) -> None:
        """Handle checkpoint response from TUI.

        Args:
            checkpoint_id: Checkpoint ID
            action: "continue" or "abort"
        """
        future = self._pending.get(checkpoint_id)

        if not future:
            logger.warning(f"No pending checkpoint for ID {checkpoint_id}")
            return

        if future.done():
            logger.warning(f"Checkpoint {checkpoint_id} already resolved")
            return

        future.set_result(action == "continue")
        logger.info(f"Checkpoint {checkpoint_id}: {action}")


# Global singleton (set by server on init)
_checkpoint_manager: Optional[CheckpointManager] = None


def set_checkpoint_manager(manager: CheckpointManager) -> None:
    """Set global checkpoint manager."""
    global _checkpoint_manager
    _checkpoint_manager = manager


def get_checkpoint_manager() -> Optional[CheckpointManager]:
    """Get global checkpoint manager."""
    return _checkpoint_manager
