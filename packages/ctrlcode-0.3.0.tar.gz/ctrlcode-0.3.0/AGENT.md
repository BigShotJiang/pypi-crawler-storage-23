# ctrl+code Project Instructions

> Note: This is the project-level AGENT.md. Global defaults are in ~/.config/ctrlcode/AGENT.md

## Project Overview

This is a differential fuzzing harness for AI-assisted coding. It generates code variants, runs tests, and uses static/semantic analysis to find the best implementation.

## Architecture

- **Server** (`src/ctrlcode/server.py`): JSON-RPC server handling sessions
- **Session Manager** (`src/ctrlcode/session/manager.py`): Conversation orchestration
- **Providers** (`src/ctrlcode/providers/`): LLM integrations (OpenAI, Anthropic)
- **Tools** (`src/ctrlcode/tools/`): Built-in explore tools + MCP support
- **Skills** (`src/ctrlcode/skills/`): Reusable command templates
- **Fuzzing** (`src/ctrlcode/fuzzing/`): Variant generation and analysis
- **TUI** (`tui/`): Textual-based interface

## Code Style

- Use Python 3.12+ features (type hints, match/case, etc.)
- Prefer async/await for I/O operations
- Keep functions focused and single-purpose
- Use dataclasses for structured data
- Follow existing logging patterns (`logger.info/warning/error`)

## Tool Usage

When exploring this codebase:
- Use `search_code` to find class/function definitions
- Use `search_files` to locate files by pattern
- Use `read_file` to examine implementation details
- Check related files (e.g., if editing a provider, check base.py first)

## Testing

- Run tests with `uv run pytest`
- Skills are in `src/ctrlcode/skills/builtin/`
- Test execution uses `analysis/tests.py`

## Key Patterns

- All RPC methods are in `server.py` and call into `SessionManager`
- Tool execution loop is in `session/manager.py:process_turn()`
- Streaming events use `StreamEvent` dataclass from `providers/base.py`
- Skills expand via `SkillRegistry.process_input()`
