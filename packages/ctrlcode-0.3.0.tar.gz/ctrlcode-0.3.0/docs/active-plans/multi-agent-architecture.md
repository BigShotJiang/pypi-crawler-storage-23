# Multi-Agent Architecture Implementation

**Status:** Phases 1-5 Complete - Implementation Ready
**Started:** 2026-02-13
**Completed:** 2026-02-13
**Owner:** Core Team

## Overview

Transform ctrl+code from single-agent ReAct loop to orchestrated multi-agent system with specialized agents for planning, coding, review, execution, and cleanup.

## Goals

1. **10x Productivity:** Via specialization and parallelization (OpenAI achieved this)
2. **Higher Quality:** Agent-to-agent review catches issues before human review
3. **Autonomous Workflows:** 6-hour runs on complex tasks without human intervention
4. **Continuous Maintenance:** Background cleanup agents prevent tech debt accumulation

## Implementation Phases

### Phase 1: Documentation Infrastructure ✅ COMPLETE

**Timeline:** Week 1-2
**Goal:** Agent-first docs structure with progressive disclosure.

**Tasks:**
- [x] Create `docs/` directory structure
- [x] Write `docs/AGENTS.md` (table of contents, <100 lines)
- [x] Write `docs/core-beliefs.md`
- [x] Write `docs/coding-standards.md`
- [x] Write `docs/golden-principles/index.md`
- [x] Write `docs/architectural-patterns.md`
- [ ] Write `docs/references/harness-utils-api.md`
- [ ] Write `docs/references/differential-fuzzing.md`
- [ ] Auto-generate `docs/generated/tool-registry.md`
- [ ] Update `prompts/SYSTEM_PROMPT.md` to reference AGENTS.md
- [ ] Create doc structure linter
- [ ] Measure context savings (before/after)

**Success Criteria:**
- docs/ structure exists and is populated
- AGENTS.md is <100 lines
- Can navigate from AGENTS.md to any specific doc
- Measurable context reduction

### Phase 2: Agent Specialization ✅ COMPLETE

**Timeline:** Week 3-4
**Goal:** Create specialized prompts and test single-agent instances.

**Tasks:**
- [x] Create `prompts/agents/planner.md`
- [x] Create `prompts/agents/coder.md`
- [x] Create `prompts/agents/reviewer.md`
- [x] Create `prompts/agents/executor.md`
- [x] Create `prompts/agents/orchestrator.md`
- [x] Create `prompts/agents/cleanup.md`
- [x] Implement `src/ctrlcode/agents/registry.py`
- [ ] Test each agent independently (pending full execution loop)
- [x] Verify harness-utils integration

**Success Criteria:**
- ✅ 6 agent types created (planner, coder, reviewer, executor, orchestrator, cleanup)
- ✅ AgentRegistry manages configurations
- ✅ Tool access properly restricted per agent
- ✅ Context management configured per agent

### Phase 3: Orchestration Layer ✅ COMPLETE

**Timeline:** Week 5-6
**Goal:** Build orchestrator and implement task graph execution.

**Tasks:**
- [x] Implement `src/ctrlcode/agents/communication.py`
- [x] Implement orchestrator agent logic
- [x] Implement `src/ctrlcode/agents/workflow.py`
- [x] Add parallel execution support (asyncio.gather)
- [x] Add review feedback loop
- [x] Integrate harness-utils ConversationManager per agent
- [ ] Test end-to-end workflows (pending full execution loop)

**Success Criteria:**
- ✅ AgentBus for message passing
- ✅ AgentCoordinator spawns agents with isolated conversations
- ✅ MultiAgentWorkflow executes 4-phase pipeline
- ✅ Parallel execution via spawn_agents_parallel()
- ✅ Review feedback loops implemented
- ✅ WorkflowOrchestrator high-level API

### Phase 4: Observability Integration ✅ COMPLETE

**Timeline:** Week 7-8
**Goal:** Make runtime behavior legible to agents.

**Tasks:**
- [x] Enhance Executor agent tools
- [x] Structured log parsing (LogParser)
- [x] Test output interpretation (TestOutputParser)
- [x] Performance metrics extraction (PerformanceParser)
- [x] Create ObservabilityTools high-level API
- [ ] Integrate fuzzing with review phase (existing system)
- [ ] Create verification loops (pending execution loop)

**Success Criteria:**
- ✅ TestOutputParser parses pytest/generic output
- ✅ PerformanceParser parses wrk/ab benchmarks
- ✅ LogParser extracts errors/warnings
- ✅ ObservabilityTools provides recommendations
- ✅ Structured output with status and metrics

### Phase 5: Continuous Cleanup ✅ COMPLETE

**Timeline:** Week 9-10
**Goal:** Background agents for tech debt paydown.

**Tasks:**
- [x] Implement Cleanup agent (CleanupAgent)
- [x] Golden principles scanner (GoldenPrinciplesScanner)
- [x] Code smell detector (CodeSmellDetector)
- [x] Doc freshness checker (DocFreshnessChecker)
- [x] Cleanup metrics tracking (CleanupMetrics)
- [x] Cleanup agent prompt
- [ ] Schedule cleanup runs (requires execution loop)
- [ ] Automated refactoring PRs (requires execution loop)

**Success Criteria:**
- ✅ Cleanup agent scans for violations
- ✅ Detects bare-excepts, long functions, stale docs
- ✅ Priority scoring (impact × effort)
- ✅ Metrics tracking over time
- ✅ Auto-fix capability for low-risk changes

## Agent Type Specifications

### Planner Agent

**Role:** Decompose user intent into executable task graph.

**Tools:** search_files, search_code, read_file, list_directory, task_write

**Output:** Task graph with dependencies

### Coder Agent

**Role:** Execute individual coding tasks.

**Tools:** read_file, write_file, update_file, run_command, search_code

**Output:** Code changes + test results

**Parallelization:** Multiple instances on independent tasks

### Reviewer Agent

**Role:** Validate changes before merge.

**Tools:** read_file, run_command, search_code, task_update

**Output:** Review decision (approved | changes_requested)

### Executor Agent

**Role:** Runtime validation and observability.

**Tools:** run_command, fetch, (future: query_logs, query_metrics, screenshot)

**Output:** Observability report

### Cleanup Agent

**Role:** Continuous tech debt paydown.

**Tools:** search_files, search_code, read_file, update_file, task_write

**Runs:** Scheduled (nightly, weekly) or triggered

**Output:** Refactoring PRs

### Orchestrator Agent

**Role:** Coordinate all agents, manage workflow.

**Tools:** spawn_agent, task_write, task_list, task_update

**Decision Tree:** Routes to appropriate agents based on task type

## Key Design Decisions

### One ConversationManager Per Agent

**Decision:** Each agent gets its own harness-utils ConversationManager.

**Rationale:**
- Context isolation (no contamination)
- Independent compaction strategies
- Parallel execution support
- Easy cleanup when agent completes

**Implementation:** See harness-utils MULTI_AGENT_GUIDE.md

### Selective Context Loading

**Decision:** Don't load entire subagent conversation into main agent.

**Rationale:**
- Prevents context explosion
- Focuses on relevant information
- Enables longer autonomous runs

**Implementation:** Use `query_messages()` and `get_context_summary()`

### Manual Message Passing

**Decision:** No built-in AgentBus (harness-utils doesn't provide it).

**Rationale:**
- Simpler to reason about
- Explicit context sharing
- harness-utils provides primitives, we build coordination

**Implementation:** Extract findings from subagent, add to main agent via selective loading

### Reviewer First

**Decision:** Build Reviewer agent before Planner.

**Rationale:**
- Immediate quality improvement
- Works with existing single-agent workflow
- Proves agent communication pattern
- Lower risk than full orchestration

## Open Questions

### 1. Minimal Viable Multi-Agent

**Question:** What's the simplest workflow to prove the concept?

**Proposal:** User intent → Planner (task graph) → Single Coder (all tasks) → Reviewer → Report

**Why:** Proves agent handoff without parallel complexity

### 2. Agent Communication Protocol

**Question:** How do we structure messages between agents?

**Options:**
- A: Plain text summaries
- B: Structured JSON
- C: Hybrid (structured metadata + text description)

**Recommendation:** Option C (rich but readable)

### 3. Error Recovery

**Question:** What happens when an agent fails?

**Strategy:**
- Phase 1: Escalate to human
- Future: Automatic retry with different agent instance

### 4. Context Sharing

**Question:** How much context does each agent need?

**Strategy:**
- Task graph: shared across all agents
- Reasoning: isolated per agent
- Results: selective loading (summaries, high-importance only)

## Metrics to Track

### Baseline (Current Single-Agent)

- Task completion rate: TBD
- Review pass rate (first attempt): TBD
- Average time to completion: TBD
- Token usage per task: TBD
- Human intervention rate: TBD

### Target (Multi-Agent)

- Task completion rate: >90%
- Review pass rate: >70% first attempt
- Time to completion: -50% (via parallelization)
- Token usage: <1.5x (acceptable for quality improvement)
- Human intervention: <10%

## References

- `docs/WORLD_CLASS_AGENT_PROPOSAL.md` - Full proposal
- `docs/references/multi-agent-guide.md` - harness-utils patterns
- `docs/architectural-patterns.md#multi-agent` - Architecture overview

## Status Summary

**Completed:**
- ✅ Phase 1: Documentation infrastructure
- ✅ Phase 2: Agent specialization (6 agent types)
- ✅ Phase 3: Orchestration layer (workflow, communication)
- ✅ Phase 4: Observability integration (parsers, metrics)
- ✅ Phase 5: Continuous cleanup (scanners, detectors)
- ✅ harness-utils 0.3.0 integration
- ✅ ConversationManager per agent with isolated contexts

**Remaining:**
- Implement full agent execution loop (LLM invocation + tool calling)
- End-to-end workflow testing
- Integration with existing session management
- Scheduled cleanup runs
- Context savings measurement

**Next Steps:**
1. Implement agent execution loop in spawn_agent()
2. Test individual agents
3. Test multi-agent workflows
4. Integrate with main server
5. Measure performance vs single-agent baseline
