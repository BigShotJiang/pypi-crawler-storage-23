# World-Class Coding Agent Architecture Proposal for ctrl+code

**Date**: February 13, 2026
**Context**: Based on OpenAI harness engineering findings and 2026 agentic coding research

---

## Executive Summary

This document outlines a comprehensive architecture proposal to transform ctrl+code from a single-agent ReAct loop into a world-class multi-agent coding system. The proposal integrates:

1. **OpenAI's harness engineering lessons** (from `openai-codex-harness-findings.md`)
2. **Modern agentic loop patterns** (ReAct, multi-agent orchestration)
3. **harness-utils 0.3.0 capabilities** (context window management already available)
4. **2026 agentic coding trends** (specialized agents, orchestration, continuous feedback)

**Core Philosophy**: "Humans steer. Agents execute."

---

## Research Findings

### 1. OpenAI Harness Engineering Key Insights

From `openai-codex-harness-findings.md`:

- **Productivity**: 1M lines of code in 5 months with 0 manually-written lines
- **Speed**: 10x faster than manual coding (3.5 PRs/engineer/day)
- **Autonomy**: 6+ hour autonomous runs while humans sleep
- **Agent-First**: Everything optimized for agent legibility, not human preferences

**Critical Success Factors**:
1. Repository structure as system prompt (docs/ as table of contents, not monolith)
2. Progressive disclosure (agents get map, fetch details as needed)
3. Mechanical enforcement (linters inject remediation into context)
4. Fast iteration with cheap corrections
5. Continuous cleanup via background agents
6. Agent-to-agent review workflows

**What Failed**:
- "One big AGENTS.md" approach (too much context, rots instantly, no guidance)

**What Worked**:
- Short AGENTS.md (~100 lines) as map to structured docs/
- Golden principles enforced mechanically
- Automated doc-gardening agents
- Making UI, logs, metrics legible to agents (CDP integration, ephemeral observability)

### 2. Agentic Loop Architecture Research

**Sources**:
- [Agentic Loops Explained](https://www.ikangai.com/the-agentic-loop-explained-what-every-pm-should-know-about-how-ai-agents-actually-work/)
- [ReAct Pattern Guide](https://www.promptingguide.ai/techniques/react)
- [IBM on ReAct Agents](https://www.ibm.com/think/topics/react-agent)
- [Vellum's Agentic Workflows Guide](https://www.vellum.ai/blog/agentic-workflows-emerging-architectures-and-design-patterns)
- [Agentic AI Handbook](https://www.nibzard.com/agentic-handbook/)
- [Simon Willison on Designing Agentic Loops](https://simonwillison.net/2025/Sep/30/designing-agentic-loops/)

#### Core Agentic Loop

At its core, an agentic loop is: **Perceive → Reason → Act → Observe → Repeat**

An agent is an LLM wrapped in a loop that can:
- Observe state
- Call tools
- Record results
- Decide when it's done (or when to ask for help)

#### ReAct Pattern (Reasoning + Acting)

**What it is**: A breakthrough pattern from 2022 (Princeton/Google) where the model alternates between thinking out loud and taking actions.

**Core cycle**: Think → Act → Observe → Repeat

**How it works**:
1. Model generates verbal reasoning trace ("I need to find the authentication code")
2. Model selects and calls a tool (search_files("**/auth*.py"))
3. Model observes the result ([list of auth files])
4. Model reasons about next step
5. Loop continues until task complete

**Key benefits**:
- Reduces hallucinations by grounding reasoning with actions
- Improves performance on interactive tasks
- Enables dynamic planning and adjustment
- Makes agent behavior more transparent and debuggable

**Modern implementation**: Most frameworks (LangChain, LangGraph, etc.) use function-calling to implement the "think, act, observe" loop.

#### Production-Ready Patterns

From [Agentic AI Handbook](https://www.nibzard.com/agentic-handbook/):

**Agentic patterns** are repeatable mini-architectures for building loops that work in production:
- Constrained
- Testable
- Observable
- Safe

**Key insight**: Agentic AI isn't a new model capability—it's a new software shape: an LLM inside a loop, with tools, state, and stopping conditions.

**Most effective agents**: Not the most independent—the most bounded, observable, and auditable.

### 3. 2026 Agentic Coding Trends

**Sources**:
- [Anthropic's 2026 Agentic Coding Trends Report](https://resources.anthropic.com/hubfs/2026%20Agentic%20Coding%20Trends%20Report.pdf)
- [Eight Trends Defining Software in 2026](https://claude.com/blog/eight-trends-defining-how-software-gets-built-in-2026)
- [5 Key Trends Shaping Agentic Development](https://thenewstack.io/5-key-trends-shaping-agentic-development-in-2026/)

#### Multi-Agent Orchestration

**Shift**: From single coding agents to groups of specialized agents working in parallel under an orchestrator.

**Architecture**: Each agent handles a defined role, improving speed and task coverage.

**Three Key Roles**:
1. **Planners**: Explore codebase, create task graphs, identify dependencies
2. **Workers**: Execute assigned tasks in parallel
3. **Judges**: Determine quality, whether to continue at each cycle end

**Why it works**: Hierarchical structure enables scale—specialized agents are more reliable than general-purpose ones trying to do everything.

#### Common Workflow Pattern

**INTENT → SPEC → PLAN → IMPLEMENT → VERIFY → DOCS → REVIEW → RELEASE → MONITOR → ITERATE**

Breaking this down:
- **INTENT**: User describes what they want
- **SPEC**: Acceptance criteria, constraints, non-goals
- **PLAN**: Task graph, risk flags, checkpoints
- **IMPLEMENT**: Code changes
- **VERIFY**: Tests, linters, security scans
- **DOCS**: Documentation, changelog, runbook delta
- **REVIEW**: Human + automated validation
- **RELEASE**: Deploy + post-deploy checks
- **MONITOR**: SLO impact, errors, regressions
- **ITERATE**: Fix-forward or rollback

#### Key Architectural Patterns

From [Navigating Modern LLM Agent Architectures](https://www.wollenlabs.com/blog-posts/navigating-modern-llm-agent-architectures-multi-agents-plan-and-execute-rewoo-tree-of-thoughts-and-react):

**Plan-and-Execute**: Agent first creates a complete plan, then executes steps sequentially or in parallel.

**Multi-Agent**: Different agents with different roles collaborate on a task.

**ReWOO (Reasoning WithOut Observation)**: Separates reasoning from observation to reduce token usage and improve planning.

**Tree of Thoughts**: Explores multiple reasoning paths in parallel, pruning unsuccessful branches.

---

## Current State: ctrl+code Architecture Analysis

### What We Have Now

ctrl+code is essentially a **single-agent ReAct loop**:

```
User provides intent
    ↓
Model reasons about approach
    ↓
Model calls tools (read_file, write_file, update_file, search_files, etc.)
    ↓
Model observes results
    ↓
Model continues or completes
```

**Tools available**:
- Exploration: `search_files`, `search_code`, `read_file`, `list_directory`, `get_file_info`
- Modification: `write_file`, `update_file`
- Execution: `run_command`
- Web: `fetch`
- Task management: `todo_write`, `todo_list`, `todo_update` (+ `task_*` aliases)

**Current strengths**:
- Simple, predictable behavior
- Direct user interaction
- Fuzzing pipeline for code quality
- Auto-chaining (search → read)
- Continuation support (tools in follow-up turns)

**Current limitations**:
- Single agent tries to do everything
- No task decomposition
- No parallel execution
- No specialized validation
- No long-running autonomous workflows
- Limited observability (can't see runtime behavior, test results, etc.)
- No automated cleanup/maintenance

### What's Missing for World-Class

Comparing to OpenAI's harness and 2026 trends:

1. **Agent-First Documentation Structure**
   - Current: CLAUDE.md + AGENT.md + SYSTEM_PROMPT.md (growing into monoliths)
   - Needed: docs/ structure with progressive disclosure

2. **Multi-Agent Orchestration**
   - Current: Single agent doing planning, coding, testing
   - Needed: Specialized agents (Planner, Coder, Reviewer, Executor)

3. **Mechanical Enforcement**
   - Current: Fuzzing pipeline (good start!)
   - Needed: Linters that inject remediation, golden principles enforcement

4. **Observability**
   - Current: Can run commands but can't interpret runtime behavior
   - Needed: Logs, metrics, test output legible to agents

5. **Autonomous Workflows**
   - Current: User-driven, turn-by-turn
   - Needed: 6-hour autonomous runs on complex tasks

6. **Continuous Cleanup**
   - Current: Manual
   - Needed: Background agents for tech debt, doc gardening

---

## Proposal: Multi-Agent Harness Architecture

### Vision

Transform ctrl+code from **single agent** to **orchestrated agent team**, where each agent is a specialized harness instance optimized for specific responsibilities.

### Architecture Overview

```
┌─────────────────────────────────────────────────┐
│           Orchestrator Agent                    │
│  (Manages workflow, delegates tasks,            │
│   coordinates communication)                    │
└────────────┬────────────────────────────────────┘
             │
      ┌──────┴──────┬──────────┬──────────┬────────┐
      │             │          │          │        │
┌─────▼─────┐ ┌────▼────┐ ┌───▼────┐ ┌───▼────┐ ┌▼────────┐
│  Planner  │ │ Coder₁  │ │Reviewer│ │Executor│ │ Cleanup │
│  Agent    │ │ Agent   │ │ Agent  │ │ Agent  │ │ Agent   │
│           │ │         │ │        │ │        │ │(Background)
│           │ ├─────────┤ │        │ │        │ └─────────┘
│           │ │ Coder₂  │ │        │ │        │
│           │ │ Agent   │ │        │ │        │
│           │ │(parallel)│ │        │ │        │
└───────────┘ └─────────┘ └────────┘ └────────┘
```

**Key Principles**:
- Each agent is a harness-utils instance
- Specialized system prompts per agent type
- Subset of tools per agent (principle of least privilege)
- Own ReAct loop per agent
- Agents can run in parallel where tasks are independent

---

## Level 1: Foundation - Agent-First Documentation

**Status**: harness-utils 0.3.0 already provides context window management, so we focus on structure.

### New Documentation Structure

```
docs/
├── AGENTS.md                      # Table of contents (~100 lines)
├── core-beliefs.md                # Non-negotiable principles
├── coding-standards.md            # How we write code
├── architectural-patterns.md      # System design patterns
│
├── golden-principles/             # Mechanically enforced rules
│   ├── index.md
│   ├── no-yolo-parsing.md        # Always validate at boundaries
│   ├── prefer-shared-utils.md    # Don't hand-roll helpers
│   └── structured-logging.md     # Standard log format
│
├── active-plans/                  # Current execution plans
│   ├── multi-agent-architecture.md
│   └── observability-integration.md
│
├── completed-plans/               # Historical context
│   └── fuzzing-pipeline.md
│
├── tech-debt/                     # Known issues, prioritized
│   └── tracker.md
│
├── references/                    # External docs, internalized
│   ├── harness-utils-api.md
│   └── textual-widgets.md
│
└── generated/                     # Auto-maintained by agents
    └── tool-registry.md
```

### AGENTS.md Template

```markdown
# Agent Documentation Map

This file is the entry point for all agents. It's intentionally short (~100 lines).

## Core Beliefs
See `docs/core-beliefs.md` for non-negotiable principles.

## Coding Standards
See `docs/coding-standards.md` for how we write code.

## Golden Principles (Mechanically Enforced)
See `docs/golden-principles/` for rules that linters enforce.

## Current Work
See `docs/active-plans/` for in-progress execution plans.

## Architecture
See `docs/architectural-patterns.md` for system design.

## References
See `docs/references/` for external documentation we've internalized.

## Tools
See `docs/generated/tool-registry.md` for available tools (auto-generated).

## How to Navigate
1. Start here (AGENTS.md)
2. Follow links to specific docs as needed
3. Keep context focused—don't load everything at once
4. If stuck, check active-plans/ for current work context
```

### Progressive Disclosure in Practice

**Bad (old way)**:
```
Load 10,000 line AGENTS.md into context
→ Crowds out task details, code, relevant docs
→ Everything is "important" so nothing is
→ Hard to tell what's current vs stale
```

**Good (new way)**:
```
1. Load AGENTS.md (~100 lines) - get map
2. Task: "Add login endpoint"
3. Agent: "I need auth patterns" → reads docs/architectural-patterns.md#auth
4. Agent: "What are golden principles?" → reads docs/golden-principles/index.md
5. Agent: "Is there active work on auth?" → checks docs/active-plans/
6. Total context: ~500 lines instead of 10,000
```

### Mechanical Enforcement

**Custom linters** (written by agents!) that:
- Validate docs are up-to-date
- Check cross-linking between docs
- Verify structure is correct
- Inject remediation instructions into agent context when rules violated

**Example lint error**:
```
❌ YOLO Parsing Detected
File: src/api/parser.py:45
Rule: golden-principles/no-yolo-parsing.md

You're accessing data.user.email without validation.

FIX: Use Zod schema at boundary:
  const userData = UserSchema.parse(data)
  return userData.user.email

Why: Prevents runtime crashes from unexpected upstream shapes.
See: docs/golden-principles/no-yolo-parsing.md
```

---

## Level 2: Multi-Agent Orchestration Architecture

### Agent Type Specifications

#### 1. Planner Agent

**Role**: Decompose user intent into executable task graph with dependencies.

**System Prompt Focus**:
- Task decomposition strategies
- Dependency identification
- Risk assessment
- Checkpoint planning

**Tools Available**:
- `search_files` - Find relevant code
- `search_code` - Search by content
- `read_file` - Understand current implementation
- `list_directory` - Explore structure
- `task_write` - Create execution plan

**Input**: User intent (high-level goal)

**Output**: Structured task graph
```json
{
  "tasks": [
    {
      "id": "task-1",
      "description": "Read current auth implementation",
      "type": "explore",
      "dependencies": [],
      "files": ["src/auth/manager.py"]
    },
    {
      "id": "task-2",
      "description": "Add login endpoint",
      "type": "code",
      "dependencies": ["task-1"],
      "files": ["src/api/routes.py"],
      "tests": ["tests/test_login.py"]
    },
    {
      "id": "task-3",
      "description": "Add login UI component",
      "type": "code",
      "dependencies": ["task-2"],
      "files": ["tui/widgets/login.py"]
    }
  ],
  "parallel_groups": [
    ["task-1"],
    ["task-2"],
    ["task-3"]
  ],
  "risks": [
    "Auth token format must match existing sessions"
  ],
  "checkpoints": [
    "After task-2: Verify endpoint works via curl"
  ]
}
```

**ReAct Loop Example**:
```
Think: "User wants login feature. What exists?"
Act: search_files("**/auth*.py")
Observe: ["src/auth/manager.py", "src/auth/session.py"]

Think: "Need to understand current auth flow"
Act: read_file("src/auth/manager.py")
Observe: [file content showing session-based auth]

Think: "Login needs: 1) endpoint, 2) UI, 3) tests. Endpoint first."
Act: task_write({tasks: [...], dependencies: [...]})
Observe: {success: true, task_graph_id: "tg-123"}
```

#### 2. Coder Agent (Worker)

**Role**: Execute individual coding tasks from plan.

**System Prompt Focus**:
- Code quality and style
- Golden principles adherence
- Test-driven development
- Clear commit messages

**Tools Available**:
- `read_file` - Read existing code
- `write_file` - Create new files
- `update_file` - Modify existing files
- `run_command` - Run tests
- `search_code` - Find usage patterns

**Input**: Single task from plan
```json
{
  "id": "task-2",
  "description": "Add login endpoint",
  "files": ["src/api/routes.py"],
  "tests": ["tests/test_login.py"],
  "acceptance_criteria": [
    "POST /api/login accepts {email, password}",
    "Returns JWT token on success",
    "Returns 401 on invalid credentials"
  ]
}
```

**Output**: Code changes + test results
```json
{
  "task_id": "task-2",
  "files_changed": ["src/api/routes.py", "tests/test_login.py"],
  "tests_passed": true,
  "test_output": "2 passed in 0.3s",
  "status": "complete"
}
```

**Multiple Instances**: Can run in parallel on independent tasks (task-2 and task-3 if no dependency).

**ReAct Loop Example**:
```
Think: "Task: Add POST /login endpoint to routes.py"
Act: read_file("src/api/routes.py")
Observe: [existing routes structure]

Think: "Should add after line 45, following RESTful pattern"
Act: update_file(
  path="src/api/routes.py",
  operation="insert",
  start_line=45,
  content="@router.post('/login')\nasync def login(...):\n    ..."
)
Observe: {success: true}

Think: "Now need tests"
Act: write_file(
  path="tests/test_login.py",
  content="import pytest\n\ndef test_login_success():\n    ..."
)
Observe: {success: true}

Think: "Run tests to verify"
Act: run_command("pytest tests/test_login.py -v")
Observe: {stdout: "2 passed in 0.3s", returncode: 0}

Think: "Task complete"
```

#### 3. Reviewer Agent

**Role**: Validate changes before merge, enforce quality gates.

**System Prompt Focus**:
- Golden principles verification
- Security best practices
- Test coverage requirements
- Code review standards

**Tools Available**:
- `read_file` - Read changed files
- `run_command` - Run tests, linters, security scans
- `search_code` - Find similar patterns for consistency
- `task_update` - Approve or request changes

**Input**: Completed tasks + changed files
```json
{
  "task_id": "task-2",
  "files_changed": ["src/api/routes.py", "tests/test_login.py"],
  "diff": "...",
  "acceptance_criteria": [...]
}
```

**Output**: Review decision
```json
{
  "task_id": "task-2",
  "status": "approved" | "changes_requested",
  "feedback": [
    {
      "file": "src/api/routes.py",
      "line": 47,
      "type": "security",
      "message": "Password should be hashed before comparison",
      "severity": "blocker"
    }
  ],
  "checks": {
    "tests_pass": true,
    "linter_pass": true,
    "security_scan": false,
    "golden_principles": true
  }
}
```

**ReAct Loop Example**:
```
Think: "Review task-2: login endpoint. Check tests first."
Act: run_command("pytest tests/test_login.py -v")
Observe: {stdout: "2 passed", returncode: 0}

Think: "Tests pass. Check linter."
Act: run_command("ruff check src/api/routes.py")
Observe: {stdout: "", returncode: 0}

Think: "Linter clean. Check security."
Act: run_command("bandit src/api/routes.py")
Observe: {stdout: "Issue: Password not hashed [HIGH]", returncode: 1}

Think: "Security issue found. Read code to understand."
Act: read_file("src/api/routes.py", start_line=45, end_line=60)
Observe: [login function with plaintext password comparison]

Think: "Critical security issue. Request changes."
Act: task_update(
  id="task-2",
  status="changes_requested",
  feedback=[{security issue details}]
)
```

#### 4. Executor Agent

**Role**: Run commands, gather observability data, make runtime behavior legible to other agents.

**System Prompt Focus**:
- Interpreting logs and metrics
- Identifying performance issues
- Debugging runtime behavior
- Extracting actionable insights

**Tools Available**:
- `run_command` - Execute arbitrary commands
- `fetch` - HTTP requests for API testing
- Custom observability tools (future):
  - `query_logs` - LogQL queries
  - `query_metrics` - PromQL queries
  - `screenshot` - UI snapshots (via CDP)
  - `dom_snapshot` - HTML structure

**Purpose**: Like OpenAI's CDP integration - make UI, logs, metrics directly legible.

**Input**: Task requiring runtime validation
```json
{
  "type": "verify_performance",
  "description": "Ensure login endpoint responds in <200ms",
  "endpoint": "POST /api/login"
}
```

**Output**: Observability report
```json
{
  "performance": {
    "p50": 145,
    "p95": 189,
    "p99": 201
  },
  "status": "pass",
  "evidence": {
    "test_runs": 100,
    "failures": 1
  }
}
```

**ReAct Loop Example**:
```
Think: "Need to verify login performance <200ms"
Act: run_command("ab -n 100 -c 10 http://localhost:8000/api/login")
Observe: {stdout: "Time per request: 145ms (mean)", ...}

Think: "P50 looks good at 145ms. Check p99."
Act: run_command("wrk -t4 -c100 -d30s http://localhost:8000/api/login")
Observe: {stdout: "Latency 99%: 189ms", ...}

Think: "p99 at 189ms, under 200ms requirement. Pass."
```

#### 5. Cleanup Agent (Background)

**Role**: Continuous tech debt paydown, doc maintenance, pattern enforcement.

**System Prompt Focus**:
- Identifying code smells
- Recognizing stale documentation
- Enforcing golden principles retroactively
- Creating targeted refactoring PRs

**Tools Available**:
- `search_files`, `search_code` - Find patterns
- `read_file` - Analyze code
- `update_file` - Apply fixes
- `task_write` - Create cleanup tasks

**Runs**: Scheduled (nightly, weekly) or triggered (after N PRs merged)

**Input**: Scan target
```json
{
  "type": "golden_principles_scan",
  "scope": "src/",
  "principles": ["no-yolo-parsing", "prefer-shared-utils"]
}
```

**Output**: Refactoring PRs
```json
{
  "violations_found": 5,
  "prs_created": [
    {
      "title": "Refactor: Replace hand-rolled retry with shared utility",
      "files": ["src/api/client.py"],
      "auto_merge": true
    }
  ]
}
```

---

### Orchestrator Agent

**Role**: Coordinate all agents, manage workflow, decide which agents to invoke and when.

**System Prompt Focus**:
- Task routing strategies
- Dependency management
- Error recovery
- Escalation to human

**Tools Available**:
- `spawn_agent` - Launch specialized agent (Planner, Coder, Reviewer, etc.)
- `task_write`, `task_list`, `task_update` - Manage task graph
- Direct access to no tools - delegates everything

**Decision Tree**:
```
User Intent
    ↓
Is this exploratory or implementation?
    ├─ Exploratory → Spawn Planner → Present plan to user
    └─ Implementation → Spawn Planner → Get task graph
                            ↓
                    Any parallel tasks?
                    ├─ Yes → Spawn multiple Coders in parallel
                    └─ No → Spawn single Coder sequentially
                            ↓
                    All tasks complete?
                    ├─ No → Continue spawning Coders
                    └─ Yes → Spawn Reviewer
                            ↓
                    Review approved?
                    ├─ No → Send feedback to Coder, iterate
                    └─ Yes → Spawn Executor for final validation
                            ↓
                    Validation passed?
                    ├─ No → Escalate to human
                    └─ Yes → Report success to user
```

**ReAct Loop Example**:
```
User: "Add login feature"

Think: "This is complex, needs planning"
Act: spawn_agent(type="planner", task="Add login feature")
Observe: {task_graph with 3 tasks, dependencies mapped}

Think: "Task-1 has no deps, task-2 depends on task-1, task-3 depends on task-2"
Act: spawn_agent(type="coder", task=task-1)
Observe: {task-1 complete}

Think: "Task-1 done, now task-2"
Act: spawn_agent(type="coder", task=task-2)
Observe: {task-2 complete}

Think: "Task-2 done, now task-3"
Act: spawn_agent(type="coder", task=task-3)
Observe: {task-3 complete}

Think: "All coding done, send to reviewer"
Act: spawn_agent(type="reviewer", tasks=[task-1, task-2, task-3])
Observe: {changes_requested: "Security issue in task-2"}

Think: "Reviewer found issue, send back to coder"
Act: spawn_agent(type="coder", task=task-2, context={reviewer_feedback})
Observe: {task-2 revised, security issue fixed}

Think: "Re-review"
Act: spawn_agent(type="reviewer", tasks=[task-2])
Observe: {approved: true}

Think: "All approved, final validation"
Act: spawn_agent(type="executor", task="verify login works")
Observe: {success: true, all tests pass}

Think: "Feature complete"
Report to user: "Login feature implemented with 3 files changed, all tests passing"
```

---

## Level 3: Harness Implementation

Using harness-utils 0.3.0, each agent would be implemented as:

### Agent Registry

```python
# src/ctrlcode/agents/registry.py

from harnessutils import Agent, ConversationManager
from pathlib import Path

class AgentRegistry:
    """Registry of specialized agents."""

    def __init__(self, workspace_root: Path, tool_registry):
        self.workspace = workspace_root
        self.tools = tool_registry
        self.agents = {}

    def create_planner(self) -> Agent:
        """Create a Planner agent instance."""
        return Agent(
            name="planner",
            system_prompt=self._load_prompt("agents/planner.md"),
            tools=self._get_tools([
                "search_files",
                "search_code",
                "read_file",
                "list_directory",
                "task_write"
            ]),
            max_context=50000,  # harness-utils handles windowing
        )

    def create_coder(self, task_id: str) -> Agent:
        """Create a Coder agent instance for specific task."""
        return Agent(
            name=f"coder-{task_id}",
            system_prompt=self._load_prompt("agents/coder.md"),
            tools=self._get_tools([
                "read_file",
                "write_file",
                "update_file",
                "run_command",
                "search_code"
            ]),
            max_context=100000,
        )

    def create_reviewer(self) -> Agent:
        """Create a Reviewer agent instance."""
        return Agent(
            name="reviewer",
            system_prompt=self._load_prompt("agents/reviewer.md"),
            tools=self._get_tools([
                "read_file",
                "run_command",
                "search_code",
                "task_update"
            ]),
            max_context=75000,
        )

    def create_executor(self) -> Agent:
        """Create an Executor agent instance."""
        return Agent(
            name="executor",
            system_prompt=self._load_prompt("agents/executor.md"),
            tools=self._get_tools([
                "run_command",
                "fetch"
            ]),
            max_context=50000,
        )

    def create_orchestrator(self) -> Agent:
        """Create the Orchestrator agent."""
        return Agent(
            name="orchestrator",
            system_prompt=self._load_prompt("agents/orchestrator.md"),
            tools=[],  # Orchestrator delegates, doesn't use tools directly
            max_context=30000,
            sub_agents={
                "planner": self.create_planner,
                "coder": self.create_coder,
                "reviewer": self.create_reviewer,
                "executor": self.create_executor,
            }
        )

    def _load_prompt(self, path: str) -> str:
        """Load agent-specific system prompt."""
        prompt_file = self.workspace / "prompts" / path
        return prompt_file.read_text()

    def _get_tools(self, tool_names: list[str]) -> list:
        """Get tool definitions by name."""
        return [self.tools.get_tool(name) for name in tool_names]
```

### Agent Communication Protocol

```python
# src/ctrlcode/agents/communication.py

from dataclasses import dataclass
from typing import Any

@dataclass
class AgentMessage:
    """Message passed between agents."""
    from_agent: str
    to_agent: str
    message_type: str  # "task", "result", "feedback", "question"
    payload: dict[str, Any]
    context: dict[str, Any] | None = None

class AgentBus:
    """Event bus for inter-agent communication."""

    def __init__(self):
        self.message_queue = []
        self.handlers = {}

    async def send(self, message: AgentMessage):
        """Send message to target agent."""
        self.message_queue.append(message)

        # Find handler for target agent
        if message.to_agent in self.handlers:
            await self.handlers[message.to_agent](message)

    def register_handler(self, agent_name: str, handler):
        """Register message handler for agent."""
        self.handlers[agent_name] = handler
```

### Workflow Execution

```python
# src/ctrlcode/agents/workflow.py

class MultiAgentWorkflow:
    """Orchestrates multi-agent task execution."""

    def __init__(self, registry: AgentRegistry, bus: AgentBus):
        self.registry = registry
        self.bus = bus
        self.orchestrator = registry.create_orchestrator()

    async def execute(self, user_intent: str):
        """Execute multi-agent workflow for user intent."""

        # Phase 1: Planning
        planner = self.registry.create_planner()
        task_graph = await planner.run(user_intent)

        # Phase 2: Parallel execution
        results = []
        for parallel_group in task_graph["parallel_groups"]:
            # Spawn coder for each task in parallel group
            coders = [
                self.registry.create_coder(task_id)
                for task_id in parallel_group
            ]

            # Execute in parallel (asyncio.gather)
            group_results = await asyncio.gather(*[
                coder.run(task_graph["tasks"][task_id])
                for coder in coders
            ])

            results.extend(group_results)

        # Phase 3: Review
        reviewer = self.registry.create_reviewer()
        review_result = await reviewer.run({
            "tasks": task_graph["tasks"],
            "results": results
        })

        if not review_result["approved"]:
            # Iterate: send feedback to coder, re-run
            # ... (implementation details)
            pass

        # Phase 4: Final validation
        executor = self.registry.create_executor()
        validation = await executor.run({
            "type": "integration_test",
            "tasks": task_graph["tasks"]
        })

        return {
            "success": validation["success"],
            "task_graph": task_graph,
            "results": results,
            "validation": validation
        }
```

---

## Level 4: Workflow Comparison

### Current Single-Agent Flow

```
User: "Add login feature"
    ↓
Model thinks: "I'll add endpoint, tests, UI"
    ↓
Model: search_files("**/auth*.py")
    ↓
Model: read_file("src/auth/manager.py")
    ↓
Model: update_file("src/api/routes.py", ...)
    ↓
Model: write_file("tests/test_login.py", ...)
    ↓
Model: run_command("pytest tests/")
    ↓
Model: "Done! Added login feature."
```

**Problems**:
- No decomposition (tried to do everything at once)
- No validation (no separate reviewer)
- No observability (can't see if it actually works in runtime)
- No parallelization (sequential even when tasks independent)
- No specialization (same prompt for planning, coding, testing)

### Proposed Multi-Agent Flow

```
User: "Add login feature"
    ↓
Orchestrator: "This needs planning"
    ↓
Planner Agent:
    - search_files("**/auth*.py")
    - read_file("src/auth/manager.py")
    - Creates task graph: [task-1: endpoint, task-2: tests, task-3: UI]
    - Identifies dependencies: task-2 depends on task-1, task-3 on task-2
    ↓
Orchestrator: "Task-1 ready, spawn coder"
    ↓
Coder Agent #1 (task-1):
    - read_file("src/api/routes.py")
    - update_file("src/api/routes.py", add endpoint)
    - run_command("pytest tests/test_routes.py")
    - Status: Complete
    ↓
Orchestrator: "Task-1 done, task-2 ready, spawn coder"
    ↓
Coder Agent #2 (task-2):
    - write_file("tests/test_login.py")
    - run_command("pytest tests/test_login.py")
    - Status: Complete
    ↓
Orchestrator: "All tasks done, send to reviewer"
    ↓
Reviewer Agent:
    - run_command("pytest tests/")
    - run_command("ruff check src/")
    - run_command("bandit src/api/routes.py")
    - Finds: Security issue (password not hashed)
    - Status: Changes requested
    ↓
Orchestrator: "Review failed, send feedback to coder"
    ↓
Coder Agent #1 (task-1 revision):
    - read_file("src/api/routes.py")
    - update_file("src/api/routes.py", add password hashing)
    - run_command("pytest tests/")
    - Status: Complete
    ↓
Orchestrator: "Re-review"
    ↓
Reviewer Agent:
    - run_command("bandit src/api/routes.py")
    - Status: Approved
    ↓
Orchestrator: "Validation phase"
    ↓
Executor Agent:
    - run_command("curl -X POST http://localhost:8000/api/login")
    - Observes: Response time, success rate, error logs
    - Status: Pass
    ↓
Orchestrator → User: "Login feature complete. 2 files changed, security validated, tests passing, runtime verified."
```

**Benefits**:
- Clear task decomposition
- Specialized agents (better prompts, better results)
- Validation gates (reviewer catches security issue)
- Observability (executor verifies runtime behavior)
- Extensible (can add more agent types)

---

## Level 5: Implementation Roadmap

### Phase 1: Documentation Infrastructure (Week 1-2)

**Goal**: Establish agent-first documentation structure.

**Tasks**:
1. Create `docs/` directory structure
   - AGENTS.md (table of contents)
   - core-beliefs.md
   - coding-standards.md
   - architectural-patterns.md
   - golden-principles/ (index + individual principles)
   - active-plans/
   - completed-plans/
   - tech-debt/
   - references/
   - generated/

2. Migrate content from existing CLAUDE.md/AGENT.md
   - Extract core beliefs
   - Extract coding standards
   - Create golden principles from fuzzing rules
   - Document current architecture

3. Create custom linters
   - Doc structure validator
   - Cross-link checker
   - Freshness checker (last modified date)
   - Start simple: just validate structure exists

4. Update SYSTEM_PROMPT.md
   - Add progressive disclosure instructions
   - Reference AGENTS.md as entry point
   - Remove redundant content (rely on docs/)

**Success Criteria**:
- docs/ structure exists and is populated
- AGENTS.md is <100 lines
- Linters run in CI
- Can navigate from AGENTS.md to any specific doc

### Phase 2: Agent Specialization (Week 3-4)

**Goal**: Create specialized system prompts and test single-agent instances.

**Tasks**:
1. Create agent-specific prompts
   - prompts/agents/planner.md
   - prompts/agents/coder.md
   - prompts/agents/reviewer.md
   - prompts/agents/executor.md
   - prompts/agents/orchestrator.md

2. Implement AgentRegistry
   - Agent creation methods
   - Tool subset assignment
   - Prompt loading
   - Context limits per agent type

3. Test agents independently
   - Planner: Give user intent → verify task graph output
   - Coder: Give task → verify code changes
   - Reviewer: Give changes → verify feedback quality
   - Executor: Give validation task → verify observability data

4. Verify harness-utils integration
   - Context windowing works per-agent
   - Conversation management per-agent
   - Agent state isolation

**Success Criteria**:
- 5 agent types created and tested
- Each agent can run independently
- Tool access properly restricted
- Context management working

### Phase 3: Orchestration Layer (Week 5-6)

**Goal**: Build orchestrator and implement task graph execution.

**Tasks**:
1. Implement AgentBus
   - Message passing between agents
   - Handler registration
   - Queue management

2. Implement Orchestrator agent
   - Decision tree for agent routing
   - Task graph management
   - Parallel execution coordination
   - Error recovery

3. Implement MultiAgentWorkflow
   - Phase 1: Planning (Planner)
   - Phase 2: Execution (Coders in parallel)
   - Phase 3: Review (Reviewer)
   - Phase 4: Validation (Executor)

4. Test end-to-end workflow
   - Simple task: "Add a function"
   - Medium task: "Add API endpoint with tests"
   - Complex task: "Refactor auth system"

**Success Criteria**:
- Orchestrator can route to appropriate agents
- Parallel execution works (multiple coders)
- Review feedback loop works (coder → reviewer → coder)
- End-to-end workflow completes successfully

### Phase 4: Observability Integration (Week 7-8)

**Goal**: Make runtime behavior legible to agents.

**Tasks**:
1. Enhance Executor agent tools
   - Structured log parsing (extract errors, warnings)
   - Test output interpretation (pass/fail, coverage)
   - Performance metrics extraction (latency, throughput)

2. Add observability feedback to workflow
   - Executor validates changes in runtime
   - Performance regression detection
   - Error rate monitoring

3. Integrate with fuzzing pipeline
   - Fuzzing as part of review phase
   - Fuzzer feedback to coder
   - Quality metrics tracking

4. Create verification loops
   - Coder → Executor → Feedback → Coder
   - Automated fix-forward on failures

**Success Criteria**:
- Executor can interpret logs and metrics
- Performance issues detected automatically
- Fuzzing integrated into workflow
- Verification loops work end-to-end

### Phase 5: Continuous Cleanup (Week 9-10)

**Goal**: Background agents for tech debt paydown.

**Tasks**:
1. Implement Cleanup agent
   - Scan for golden principle violations
   - Identify code smells
   - Find stale documentation
   - Create refactoring tasks

2. Schedule cleanup runs
   - Nightly scans
   - Weekly doc gardening
   - Post-merge pattern checks

3. Automated refactoring PRs
   - Small, focused changes
   - Auto-merge if tests pass
   - Human review for large changes

4. Track tech debt metrics
   - Violations over time
   - Cleanup velocity
   - Debt accumulation rate

**Success Criteria**:
- Cleanup agent runs on schedule
- Refactoring PRs created automatically
- Tech debt decreasing over time
- Documentation stays fresh

---

## Key Differentiators for World-Class Status

### 1. Repository Structure as System Prompt

**Principle**: Everything the agent needs is discoverable in-repo, versioned, and mechanically enforced.

**Implementation**:
- docs/ as primary source of truth
- AGENTS.md as map, not manual
- Progressive disclosure (load what you need, when you need it)
- Linters inject remediation into context

**Impact**: Agents can onboard like new engineers—read the docs, follow the patterns, get productive quickly.

### 2. Multi-Agent by Default

**Principle**: Specialized agents are more reliable than general-purpose agents trying to do everything.

**Implementation**:
- Planner for task decomposition
- Workers for parallel execution
- Judges for quality gates
- Executor for runtime validation
- Cleanup for continuous maintenance

**Impact**: 10x productivity through specialization and parallelization, just like OpenAI achieved.

### 3. Continuous Cleanup

**Principle**: Tech debt is like high-interest loan—pay it down continuously in small increments.

**Implementation**:
- Background cleanup agents
- Scheduled scans for violations
- Automated refactoring PRs
- Golden principles enforcement

**Impact**: Codebase stays clean and consistent, even at high velocity.

### 4. Full Observability

**Principle**: From agent's point of view, anything it can't access in-context doesn't exist.

**Implementation**:
- Executor agent interprets logs, metrics, test output
- Runtime behavior legible (like OpenAI's CDP integration)
- Performance regression detection
- Error rate monitoring

**Impact**: Agents can validate their own work, reducing human QA burden.

### 5. Agent-to-Agent Review

**Principle**: At high throughput, agent-to-agent review is essential—humans can't keep up.

**Implementation**:
- Reviewer agent validates all changes
- Security scans, linter checks, golden principles
- Feedback loop to coder for fixes
- Human escalation only for judgment calls

**Impact**: Maintain quality at scale without human bottleneck.

### 6. Mechanical Enforcement Over Documentation

**Principle**: If it's important enough to document, it's important enough to enforce mechanically.

**Implementation**:
- Custom linters for golden principles
- CI checks for doc freshness
- Automated test coverage requirements
- Type safety, security scans

**Impact**: Rules apply everywhere automatically—no drift, no exceptions.

### 7. Fast Iteration, Cheap Corrections

**Principle**: In high-throughput environment, corrections are cheap, waiting is expensive.

**Implementation**:
- Minimal blocking merge gates
- Short-lived pull requests
- Fix-forward on test flakes
- Automated rollback on errors

**Impact**: Maintain velocity without sacrificing quality.

---

## Questions for Discussion

### Strategic Questions

1. **Scope**: Should we start with single-agent improvements (better docs structure) or jump directly to multi-agent architecture?
   - **Option A**: Phase 1-2 first (docs + specialized prompts), prove value, then Phase 3-5
   - **Option B**: Build entire multi-agent system at once (higher risk, higher reward)
   - **Recommendation**: Start with Phase 1 (docs) to prove progressive disclosure works, then Phase 2 (specialized agents) to validate harness-utils integration, then Phase 3 (orchestration) if results are promising.

2. **Agent Priority**: Which agent type would provide most value first?
   - **Option A**: Planner (helps with task decomposition, useful even without multi-agent)
   - **Option B**: Reviewer (quality gate, can run on existing single-agent output)
   - **Option C**: Cleanup (background maintenance, low risk)
   - **Recommendation**: Reviewer first—it can improve quality immediately without changing workflow. Then Planner to enable multi-agent. Then Cleanup for maintenance.

3. **Integration Strategy**: How do we handle agent communication in harness-utils?
   - Does harness-utils support sub-agents or agent spawning?
   - Do we need AgentBus or can harness-utils handle message passing?
   - Should agents share conversation context or maintain separate contexts?
   - **Action**: Research harness-utils 0.3.0 API for multi-agent support

4. **Fuzzing Integration**: Should fuzzing be its own agent or integrated into Reviewer?
   - **Option A**: Fuzzer as separate agent (more modular, parallel with review)
   - **Option B**: Fuzzing as Reviewer tool (simpler, sequential)
   - **Recommendation**: Start as Reviewer tool (simpler), extract to separate agent if review becomes bottleneck.

### Tactical Questions

5. **Minimal Viable Multi-Agent**: What's the simplest workflow to prove the concept?
   - **Proposal**: User intent → Planner (task graph) → Single Coder (executes all tasks) → Reviewer (validates) → Report
   - **Why**: Proves agent handoff, task graph execution, review loop without parallel complexity
   - **Success**: If this works, expand to parallel coders

6. **Tool Subset Enforcement**: How do we prevent agents from accessing tools they shouldn't have?
   - **Option A**: Registry only provides allowed tools to agent at creation
   - **Option B**: Runtime enforcement (check tool name against allowlist)
   - **Recommendation**: Both—registry filters at creation (fail-fast), runtime checks as safety net

7. **Context Management**: How do we share context between agents efficiently?
   - **Option A**: Each agent maintains own conversation, orchestrator passes summaries
   - **Option B**: Shared conversation context, agents add to same thread
   - **Option C**: Hybrid—shared task graph, individual conversations per agent
   - **Recommendation**: Option C—task graph in shared context, agent reasoning in isolated contexts

8. **Error Handling**: What happens when an agent fails or gets stuck?
   - **Option A**: Orchestrator detects failure, escalates to human
   - **Option B**: Automatic retry with different agent instance
   - **Option C**: Fallback to single-agent mode
   - **Recommendation**: A for now (simple, safe), explore B later (autonomous recovery)

### Research Questions

9. **Harness-utils Capabilities**: What does harness-utils 0.3.0 actually provide?
   - Context window management (confirmed from discussion)
   - Multi-agent support? (unclear)
   - Agent spawning? (unclear)
   - Message passing? (unclear)
   - **Action**: Review harness-utils 0.3.0 documentation and API

10. **Performance**: What's the overhead of multi-agent vs single-agent?
    - **Concerns**: More API calls, more latency, more tokens
    - **Benefits**: Parallel execution, better prompts, fewer retries
    - **Question**: Do benefits outweigh costs?
    - **Action**: Benchmark single-agent vs multi-agent on same task

11. **Agent Prompts**: How do we write effective specialized prompts?
    - What makes a good Planner prompt vs Coder prompt?
    - How much context should each agent have about the overall task?
    - Should agents have examples of good task graphs, code changes, reviews?
    - **Action**: Study OpenAI's harness prompts (if available), iterate based on results

12. **Progressive Disclosure**: Does it actually reduce context usage significantly?
    - **Current**: Load CLAUDE.md + AGENT.md + SYSTEM_PROMPT.md (~15K tokens)
    - **Proposed**: Load AGENTS.md (~500 tokens) + fetch specific docs as needed (~2K tokens)
    - **Question**: In practice, how many docs do agents need to fetch?
    - **Action**: Instrument doc reads, measure before/after

### Validation Questions

13. **Success Metrics**: How do we measure if multi-agent is working?
    - **Metrics to track**:
      - Task completion rate
      - Review pass rate (first attempt)
      - Average time to completion
      - Token usage per task
      - Human intervention rate
      - Quality (bugs reported, security issues)
    - **Action**: Define baseline with current single-agent, measure improvement

14. **User Experience**: How does multi-agent affect the user?
    - **Concerns**: More opaque (many agents behind scenes), harder to debug
    - **Benefits**: Better quality, less back-and-forth, autonomous execution
    - **Question**: Do we show agent activity in TUI? (Planner running, Coder 1/3 complete, Reviewer checking...)
    - **Action**: Design TUI updates for multi-agent visibility

15. **Failure Modes**: What new failure modes does multi-agent introduce?
    - Agent disagreement (Reviewer rejects, Coder disagrees)
    - Infinite loops (Coder → Reviewer → Coder → ...)
    - Parallel conflicts (Coder₁ and Coder₂ modify same file)
    - Communication failures (Message dropped, agent unresponsive)
    - **Action**: Design safeguards for each failure mode

---

## Next Steps

### Immediate Actions (Before Implementation)

1. **Research harness-utils 0.3.0 API**
   - Understand multi-agent support
   - Clarify agent spawning, context sharing
   - Review example usage if available

2. **Answer strategic questions**
   - Decide: Phase 1 first or full multi-agent?
   - Decide: Which agent to build first?
   - Decide: Fuzzing integration approach?

3. **Create minimal viable design**
   - Sketch simplest multi-agent workflow
   - Define success criteria
   - Identify critical unknowns

4. **Prototype documentation structure**
   - Create docs/ directory with AGENTS.md
   - Migrate one section (e.g., golden-principles)
   - Test progressive disclosure by hand
   - Measure context savings

### After Validation

5. **Begin Phase 1** (if prototype succeeds)
   - Full documentation migration
   - Custom linters
   - Update SYSTEM_PROMPT.md

6. **Prototype first agent** (likely Reviewer)
   - Create specialized prompt
   - Integrate with existing workflow
   - Measure impact on quality

7. **Iterate based on results**
   - If successful: Continue to Phase 2-3
   - If marginal: Revisit approach
   - If unsuccessful: Investigate why, adjust

---

## References

### Core Documents
- `openai-codex-harness-findings.md` - OpenAI's harness engineering lessons
- This document (WORLD_CLASS_AGENT_PROPOSAL.md)

### External Research
- [Anthropic's 2026 Agentic Coding Trends Report](https://resources.anthropic.com/hubfs/2026%20Agentic%20Coding%20Trends%20Report.pdf)
- [Eight Trends Defining Software in 2026](https://claude.com/blog/eight-trends-defining-how-software-gets-built-in-2026)
- [ReAct Pattern Guide](https://www.promptingguide.ai/techniques/react)
- [Agentic Loops Explained](https://www.ikangai.com/the-agentic-loop-explained-what-every-pm-should-know-about-how-ai-agents-actually-work/)
- [Agentic AI Handbook](https://www.nibzard.com/agentic-handbook/)
- [Vellum's Agentic Workflows Guide](https://www.vellum.ai/blog/agentic-workflows-emerging-architectures-and-design-patterns)
- [Navigating Modern LLM Agent Architectures](https://www.wollenlabs.com/blog-posts/navigating-modern-llm-agent-architectures-multi-agents-plan-and-execute-rewoo-tree-of-thoughts-and-react)
- [IBM on ReAct Agents](https://www.ibm.com/think/topics/react-agent)
- [Simon Willison on Designing Agentic Loops](https://simonwillison.net/2025/Sep/30/designing-agentic-loops/)

### Implementation Resources
- harness-utils 0.3.0 documentation (TBD)
- Existing ctrl+code architecture (session/manager.py, tools/, etc.)

---

## Appendix: Terminology

**Agent**: An LLM wrapped in a loop with tools, state, and stopping conditions. Can observe, reason, act, and iterate.

**Agentic Loop**: The cycle of Perceive → Reason → Act → Observe → Repeat that defines agent behavior.

**ReAct Pattern**: Reasoning + Acting pattern where agent alternates between thinking (reasoning trace) and doing (tool calls).

**Orchestrator**: Meta-agent that coordinates other agents, manages workflow, and handles task routing.

**Task Graph**: Structured representation of tasks with dependencies, used by orchestrator to schedule work.

**Progressive Disclosure**: Strategy of providing minimal initial context (map) and fetching details as needed, rather than loading everything upfront.

**Golden Principles**: Mechanically enforced rules that maintain codebase quality and consistency.

**Agent-First**: Design philosophy where codebase is optimized for agent legibility and effectiveness rather than human preferences.

**Mechanical Enforcement**: Using linters, CI checks, and automated tools to enforce rules rather than relying on documentation alone.

**Continuous Cleanup**: Background agents that regularly scan for tech debt, violations, and stale patterns, creating refactoring PRs automatically.

---

**End of Document**
