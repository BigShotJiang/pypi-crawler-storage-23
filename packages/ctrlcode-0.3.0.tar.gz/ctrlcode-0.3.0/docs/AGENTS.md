# Agent Documentation Map

This file is the entry point for all agents. It's intentionally short (~100 lines).

## Quick Start

You are an AI agent working with ctrl+code. Start here, then follow links as needed.

**Core principle**: Load what you need, when you need it. Don't load everything.

## Core Beliefs

See `core-beliefs.md` for non-negotiable principles that guide all decisions.

## Coding Standards

See `coding-standards.md` for how we write code (style, patterns, conventions).

## Architecture

See `architectural-patterns.md` for system design patterns and structure.

## Golden Principles (Mechanically Enforced)

See `golden-principles/` for rules that linters enforce automatically.

Key principles:
- No YOLO parsing (validate at boundaries)
- Prefer shared utilities (don't reinvent)
- Structured logging (standard format)

## Current Work

See `active-plans/` for in-progress execution plans and context.

When starting a task, check here first to understand current priorities.

## Completed Work

See `completed-plans/` for historical context and lessons learned.

## Tech Debt

See `tech-debt/tracker.md` for known issues, prioritized by impact.

## References

See `references/` for external documentation we've internalized:
- `harness-utils-api.md` - harness-utils 0.3.0 usage
- `textual-widgets.md` - Textual framework patterns

## Tools

See `generated/tool-registry.md` for available tools (auto-generated from code).

## How to Navigate

1. **Start here** (AGENTS.md) - get the map
2. **Identify need** - what do I need to know?
3. **Follow link** - load specific doc
4. **Keep context focused** - don't load everything
5. **Check active-plans/** if stuck - understand current work

## Agent Types (Multi-Agent System)

We use specialized agents:

- **Planner**: Task decomposition, dependency mapping, risk assessment
- **Coder**: Code implementation, tests, quality
- **Reviewer**: Quality gates, security, golden principles enforcement
- **Executor**: Runtime validation, observability, performance checks
- **Cleanup**: Background maintenance, tech debt paydown

Each agent has specialized prompts in `prompts/agents/`.

## Progressive Disclosure Example

**Bad**: Load entire AGENTS.md + all docs (10,000+ tokens)
**Good**: Load AGENTS.md (500 tokens) → specific docs as needed (~2,000 tokens total)

**Example workflow**:
```
Task: "Add login endpoint"
1. Load AGENTS.md (this file)
2. Need auth patterns → load architectural-patterns.md#auth
3. Need golden principles → load golden-principles/index.md
4. Check active work → load active-plans/
Total: ~500 + 1,000 + 500 + 200 = 2,200 tokens vs 10,000+
```

## Project Structure

```
ctrl+code/
├── src/ctrlcode/          # Core harness code
│   ├── agents/            # Multi-agent orchestration
│   ├── fuzzing/           # Differential fuzzing
│   ├── session/           # Session management
│   └── tools/             # Tool registry & execution
├── tui/                   # Textual TUI client
├── prompts/               # Agent system prompts
│   └── agents/            # Per-agent specialized prompts
└── docs/                  # This directory
```

---

**Remember**: Keep context lean. Fetch details as needed. Quality over quantity.
