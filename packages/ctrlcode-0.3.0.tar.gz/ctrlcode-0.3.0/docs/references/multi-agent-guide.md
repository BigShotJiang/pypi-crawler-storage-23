# Multi-Agent Harness Development Guide

## Quick Start

harness-utils enables **indefinite conversation length** for multi-agent systems through intelligent context compaction. This guide shows how to build production-grade multi-agent harnesses.

---

## Core Pattern: One Conversation Per Agent

**Key Principle:** Each agent (main, subagent, specialist) gets its own conversation for isolation and independent context management.

```python
# Main agent (conservative settings)
main_conv = main_manager.create_conversation(project_id="project_abc")

# Exploration subagent (aggressive pruning)
explore_conv = explore_manager.create_conversation(project_id="project_abc")

# Research subagent (separate context)
research_conv = research_manager.create_conversation(project_id="project_abc")
```

**Benefits:**
- No context contamination between agents
- Independent compaction strategies
- Parallel execution support
- Easy cleanup when agent completes

---

## Architecture Patterns

### Pattern 1: Main Agent + Exploration Subagents

**Use Case:** Main agent delegates exploration tasks, integrates findings

```python
# Run exploration
explore_result = run_exploration_agent(explore_conv)

# Extract key findings (selective loading)
key_findings = explore_manager.query_messages(
  explore_conv.id,
  filter={"min_importance": 100.0}
)

# Feed to main agent
for finding in key_findings:
  main_manager.add_message(main_conv.id, finding)

# Cleanup
explore_manager.storage.delete_conversation(explore_conv.id)
```

**Configuration:**

```python
# Main agent: conservative
main_config = HarnessConfig()
main_config.pruning.prune_protect = 80_000
main_config.truncation.max_lines = 5000
main_config.compaction.use_predictive = True

# Exploration: aggressive
explore_config = HarnessConfig()
explore_config.pruning.prune_protect = 15_000
explore_config.pruning.prune_minimum = 5_000
explore_config.truncation.max_lines = 1000
```

### Pattern 2: Parallel Specialist Agents

**Use Case:** Multiple specialists work in parallel, results aggregated

```python
# Create conversations
debug_conv = debug_manager.create_conversation(project_id="proj")
review_conv = review_manager.create_conversation(project_id="proj")
test_conv = test_manager.create_conversation(project_id="proj")

# Run in parallel
results = await asyncio.gather(
  run_debug_agent(debug_conv),
  run_review_agent(review_conv),
  run_test_agent(test_conv)
)

# Aggregate
for result in results:
  main_manager.add_message(main_conv.id, result)
```

**Specialist Configurations:**

```python
# Debug agent: preserve errors
debug_config.pruning.error_boost = 1000.0
debug_config.pruning.tool_importance["bash"] = 200.0

# Review agent: preserve code changes
review_config.pruning.tool_importance["write"] = 200.0
review_config.pruning.tool_importance["edit"] = 200.0

# Test agent: standard settings
test_config = HarnessConfig()  # Defaults
```

### Pattern 3: Hierarchical Agent Tree

**Use Case:** Root delegates to children, children can spawn grandchildren

```python
# Root agent
root_conv = manager.create_conversation(project_id="proj")

# Spawn children
child_convs = []
for task in tasks:
  child_conv = manager.create_conversation(project_id="proj")
  child_convs.append(child_conv)
  await run_child_agent(child_conv, task)

# Rollup summaries
for child_conv in child_convs:
  summary = manager.get_context_summary(child_conv.id)
  root_manager.add_message(root_conv.id, summary_message(summary))
```

### Pattern 4: Context Sharing via Snapshots

**Use Case:** Spawn speculative agent from known good state

```python
# Capture baseline
snapshot = main_manager.create_snapshot(
  main_conv.id,
  metadata={"reason": "before_refactor"}
)

# Spawn speculative agent
spec_manager = ConversationManager(...)
spec_manager.restore_snapshot(snapshot.snapshot_id)

# Run experiment
run_speculative_agent(spec_conv)

# Compare outcomes
diff = main_manager.compare_snapshots(
  snapshot.snapshot_id,
  spec_snapshot.snapshot_id
)

if diff["quality_improved"]:
  main_manager.restore_snapshot(spec_snapshot.snapshot_id)
```

---

## Selective Context Loading

**Problem:** Don't load entire subagent conversation into main agent context.

**Solution:** Query API for selective loading.

### Load Recent Activity Only

```python
recent = manager.query_messages(
  conversation_id,
  limit=10,
  order="desc"
)
```

### Load Errors Only

```python
errors = manager.query_messages(
  conversation_id,
  filter={"has_errors": True}
)
```

### Load High-Importance Messages

```python
important = manager.query_messages(
  conversation_id,
  filter={"min_importance": 50.0},
  after=timestamp_24h_ago
)
```

### Get Lightweight Summary

```python
summary = manager.get_context_summary(conversation_id)
# {
#   message_count, total_tokens,
#   summaries: [...],
#   recent_activity: [...],
#   key_messages: [...],
#   errors: [...]
# }
```

---

## Configuration Strategies

### Scenario 1: Short-Lived Exploration Agents

**Characteristics:** Many agents, short lifetime, high churn

```python
config = HarnessConfig()
config.pruning.prune_protect = 15_000      # Tight window
config.pruning.prune_minimum = 5_000       # Frequent pruning
config.truncation.max_lines = 1000         # Aggressive
config.compaction.use_predictive = False   # Not needed
storage = MemoryStorage()                  # Ephemeral
```

### Scenario 2: Long-Running Main Agent

**Characteristics:** Primary agent, hours of runtime, needs full context

```python
config = HarnessConfig()
config.pruning.prune_protect = 80_000      # Large window
config.pruning.prune_minimum = 40_000      # Less frequent
config.truncation.max_lines = 5000         # Keep more
config.compaction.use_predictive = True    # Prevent overflow
config.compaction.predictive_lookahead = 10
storage = FilesystemStorage(config.storage)
```

### Scenario 3: Debugging Specialist

**Characteristics:** Must preserve errors, bash outputs critical

```python
config = HarnessConfig()
config.pruning.error_boost = 1000.0        # Never lose errors
config.pruning.warning_boost = 500.0
config.pruning.tool_importance["bash"] = 200.0
config.pruning.protected_tools.append("bash")
config.truncation.preserve_errors = True
```

### Scenario 4: Code Review Specialist

**Characteristics:** Prioritize code changes, many redundant reads

```python
config = HarnessConfig()
config.pruning.tool_importance["write"] = 200.0
config.pruning.tool_importance["edit"] = 200.0
config.pruning.tool_importance["read"] = 30.0   # Low priority
config.pruning.detect_duplicates = True         # Dedup reads
config.pruning.similarity_threshold = 0.9
```

### Scenario 5: Multi-Agent Coordinator

**Characteristics:** Manages many subagents, needs summaries only

```python
# Coordinator: moderate settings
coordinator_config = HarnessConfig()
coordinator_config.pruning.prune_protect = 20_000
coordinator_manager = ConversationManager(
  FilesystemStorage(coordinator_config.storage),
  coordinator_config
)

# Subagents: aggressive, ephemeral
subagent_config = HarnessConfig()
subagent_config.pruning.prune_protect = 10_000
subagent_manager = ConversationManager(
  MemoryStorage(),  # No persistence
  subagent_config
)

# Query summaries only
for conv_id in subagent_conversations:
  summary = subagent_manager.get_context_summary(conv_id)
  coordinator_manager.add_message(
    coordinator_conv.id,
    create_summary_message(summary)
  )
```

---

## Best Practices

### 1. Prune Proactively

```python
# Before each user turn
manager.prune_before_turn(conversation_id)
```

**Why:** Prevent gradual token accumulation. Reactive pruning happens too late.

### 2. Monitor Quality

```python
quality = manager.get_context_quality(conversation_id)

if quality["health"] == "poor":
  # Trigger maintenance
  manager.prune_before_turn(conversation_id)

if quality["redundancy_ratio"] > 0.3:
  # Run deduplication
  manager.scan_and_deduplicate(conversation_id)
```

**Why:** Detect context degradation early. Health metrics guide intervention.

### 3. Use Predictive Overflow

```python
config.compaction.use_predictive = True
config.compaction.predictive_lookahead = 5
config.compaction.predictive_safety_margin = 0.8  # Trigger at 80%
```

**Why:** Prevent sudden overflow failures. Smooth user experience.

### 4. Track Token Breakdown

```python
breakdown = manager.get_tool_output_tokens(conversation_id)
# {
#   total: 125_000,
#   by_tool: {"read": 45_000, "bash": 30_000, ...},
#   prunable: 85_000,
#   protected: 40_000
# }
```

**Why:** Identify which tools consume most tokens. Tune importance maps accordingly.

### 5. Snapshot Critical States

```python
snapshot = manager.create_snapshot(
  conversation_id,
  metadata={"reason": "before_major_refactor"}
)
```

**Why:** Reproducibility. Rollback on failure. A/B testing.

### 6. Validate Configuration

```python
config = HarnessConfig()
config.pruning.prune_protect = 200_000  # Invalid!
config.validate()  # Raises ConfigurationError with remediation
```

**Why:** Catch misconfigurations early. Clear error messages.

### 7. Customize Importance Maps

```python
# Task-specific importance
config.pruning.tool_importance = {
  "bash": 150.0,     # High for debugging agents
  "write": 200.0,    # High for code review agents
  "read": 30.0,      # Low (often redundant)
  "grep": 40.0,      # Low (often duplicate)
}
```

**Why:** Different agents have different priorities. One size doesn't fit all.

---

## Key Features for Multi-Agent Systems

### Part-Based Message Decomposition

**Problem:** Traditional monolithic messages (entire content kept or discarded).

**Solution:** Messages decomposed into parts (text, tool, reasoning).

```python
Message {
  id, role, parent_id,
  parts: [
    TextPart(text="I'll help..."),
    ToolPart(tool="read", state=ToolState(...)),
    TextPart(text="The file contains...")
  ]
}
```

**Benefits:**
- Selective compaction (clear tool output, keep text)
- Streaming updates (parts written independently)
- Concurrent writes (multiple tools simultaneously)
- Granular metadata (timing, cost per part)

### Three-Tier Context Management

**Tier 1: Truncation (Proactive, 0ms)**
- Prevent large outputs at source
- Content-aware (JSON, logs, stacktraces)
- Configurable thresholds

**Tier 2: Pruning (Proactive, ~50ms)**
- Remove old tool outputs
- Importance-based scoring
- Duplicate detection
- Protected content layers

**Tier 3: Summarization (Reactive, ~3-5s)**
- LLM-powered compression
- Differential mode (only new content)
- Predictive overflow detection

### Importance-Based Pruning

```python
score = (
  recency_score * 1.0 +         # Exponential decay
  size_penalty * -0.5 +         # Prefer removing large
  semantic_score * 2.0 +        # Errors, warnings
  tool_priority * 1.5           # Tool type importance
)
```

**Configuration:**

```python
config.pruning.error_boost = 500.0
config.pruning.warning_boost = 200.0
config.pruning.user_requested_boost = 300.0
config.pruning.tool_importance["bash"] = 150.0
```

### Duplicate Detection

Uses similarity hashing (5-word shingles + Jaccard):

```python
config.pruning.detect_duplicates = True
config.pruning.similarity_threshold = 0.8  # 80% = duplicate
config.pruning.duplicate_lookback = 20     # Check last 20
```

**Example:** Multiple `grep` calls with similar results → keep only first.

### Predictive Overflow Detection

Tracks conversation velocity (tokens per turn):

```python
ConversationVelocity {
  turn_deltas: [1200, 3400, 2800, ...],
  avg_growth: 2500,
  growth_trend: 300,
  predict_tokens_ahead(5): 13_250
}
```

**Triggers compaction before overflow** (at 80% of limit).

### Quality Metrics

```python
quality = manager.get_context_quality(conversation_id)
# {
#   information_density: 0.73,
#   redundancy_ratio: 0.18,
#   staleness_score: 0.12,
#   error_preservation_rate: 1.0,
#   protected_ratio: 0.32,
#   health: "good|degraded|poor",
#   recommendations: [...]
# }
```

**Use Case:** Monitor context health across all agent conversations.

### Observability

```python
inspector = manager.inspect_context(conversation_id)

# Current state
summary = inspector.summary()

# What-if analysis
impact = inspector.predict_impact(additional_tokens=5000)
# {would_trigger_pruning, estimated_pruned_count, would_trigger_overflow}
```

### Vendor Neutrality

```python
class LLMClient(Protocol):
  def invoke(
    self,
    messages: list[dict[str, Any]],
    system: list[str] | None = None,
    model: str | None = None,
  ) -> dict[str, Any]:
    ...
```

**Benefits:**
- No vendor lock-in
- Multi-model support (Claude, GPT, custom)
- Different models per agent type

---

## Complete Example: Multi-Agent System

```python
from harnessutils import (
  ConversationManager,
  HarnessConfig,
  FilesystemStorage,
  MemoryStorage,
)

# === CONFIGURATION ===

# Main agent config (conservative)
main_config = HarnessConfig()
main_config.pruning.prune_protect = 80_000
main_config.compaction.use_predictive = True
main_config.compaction.predictive_lookahead = 10

# Subagent config (aggressive)
subagent_config = HarnessConfig()
subagent_config.pruning.prune_protect = 15_000
subagent_config.pruning.prune_minimum = 5_000

# === MANAGERS ===

main_manager = ConversationManager(
  FilesystemStorage(main_config.storage),
  main_config
)

subagent_manager = ConversationManager(
  MemoryStorage(),  # Ephemeral
  subagent_config
)

# === MAIN AGENT LOOP ===

project_id = "my_project"
main_conv = main_manager.create_conversation(project_id=project_id)

while True:
  # Get user message
  user_message = get_user_input()
  main_manager.add_message(main_conv.id, user_message)

  # Prune proactively
  main_manager.prune_before_turn(main_conv.id)

  # Check quality
  quality = main_manager.get_context_quality(main_conv.id)
  if quality["health"] == "poor":
    print(f"⚠️ Context health poor: {quality['recommendations']}")

  # Main agent processes
  response = run_main_agent(main_conv)

  # Check if delegation needed
  if needs_exploration(response):
    # Spawn subagent
    explore_conv = subagent_manager.create_conversation(project_id=project_id)

    # Run exploration
    explore_result = run_exploration_agent(explore_conv)

    # Extract findings (selective loading)
    findings = subagent_manager.query_messages(
      explore_conv.id,
      filter={"min_importance": 100.0}
    )

    # Feed to main agent
    for finding in findings:
      main_manager.add_message(main_conv.id, finding)

    # Cleanup
    subagent_manager.storage.delete_conversation(explore_conv.id)

  # Check if overflow predicted
  usage = main_manager.calculate_context_usage(main_conv.id)
  if main_manager.needs_compaction(main_conv.id, usage):
    print(f"🔄 Compacting (usage: {usage} tokens)...")
    main_manager.compact(main_conv.id, llm_client, parent_msg_id)

# === MONITORING ===

# Token breakdown
breakdown = main_manager.get_tool_output_tokens(main_conv.id)
print(f"Total tokens: {breakdown['total']}")
print(f"By tool: {breakdown['by_tool']}")

# Quality trend
trend = main_manager.get_quality_trend(
  main_conv.id,
  metric="information_density",
  window=20
)
plot_trend(trend)
```

---

## Migration Guide: Legacy Harnesses

### Before (Naive Approach)

```python
# Problem: One conversation, no compaction, eventual overflow
conversation_history = []

while True:
  user_msg = get_input()
  conversation_history.append(user_msg)

  # Send all history to LLM
  response = llm.invoke(conversation_history)
  conversation_history.append(response)

  # Eventually: "Error: Context length exceeded"
```

### After (With harness-utils)

```python
manager = ConversationManager(
  FilesystemStorage(config.storage),
  HarnessConfig()
)

conv_id = manager.create_conversation()

while True:
  user_msg = get_input()
  manager.add_message(conv_id, user_msg)

  # Automatic pruning
  manager.prune_before_turn(conv_id)

  # Convert to model format (only relevant context)
  messages = manager.to_model_format(conv_id)

  response = llm.invoke(messages)
  manager.add_message(conv_id, response)

  # Automatic overflow prevention
  usage = manager.calculate_context_usage(conv_id)
  if manager.needs_compaction(conv_id, usage):
    manager.compact(conv_id, llm_client, parent_msg_id)
```

**Benefits:**
- Indefinite conversation length
- Automatic context management
- Critical content preserved
- Full observability

---

## Troubleshooting

### Issue: Context degrading over time

**Symptoms:** Quality health shows "poor", high redundancy ratio

**Solution:**
```python
# Run deduplication
result = manager.scan_and_deduplicate(conversation_id)

# Lower similarity threshold for stricter dedup
config.pruning.similarity_threshold = 0.85
```

### Issue: Important content being pruned

**Symptoms:** Errors lost, critical outputs removed

**Solution:**
```python
# Increase error/warning boost
config.pruning.error_boost = 1000.0
config.pruning.warning_boost = 500.0

# Add tools to protected list
config.pruning.protected_tools.extend(["bash", "error"])

# Increase protection window
config.pruning.protect_turns = 3
```

### Issue: Token limit exceeded unexpectedly

**Symptoms:** Overflow despite compaction enabled

**Solution:**
```python
# Enable predictive overflow
config.compaction.use_predictive = True
config.compaction.predictive_lookahead = 10
config.compaction.predictive_safety_margin = 0.8

# Lower pruning thresholds
config.pruning.prune_protect = 60_000
config.pruning.prune_minimum = 30_000
```

### Issue: Subagent context too large to load

**Symptoms:** High memory usage, slow queries

**Solution:**
```python
# Use selective loading
summary = manager.get_context_summary(subagent_conv_id)  # Lightweight

recent = manager.query_messages(
  subagent_conv_id,
  limit=10,
  order="desc"
)

# Don't load full conversation
```

### Issue: Configuration conflicts

**Symptoms:** ConfigurationError on validate()

**Solution:**
```python
config = HarnessConfig()
config.validate()  # Check early

# Common issues:
# - prune_protect > context limit
# - prune_minimum > prune_protect
# - Invalid model names (when not vendor-agnostic)
```

---

## Summary

harness-utils enables production-grade multi-agent harnesses through:

1. **Conversation Isolation:** One conversation per agent
2. **Selective Loading:** Query API for efficient context transfer
3. **Importance Scoring:** Preserve critical content (errors, warnings)
4. **Predictive Overflow:** Prevent sudden failures
5. **Quality Monitoring:** Track context health
6. **Vendor Neutrality:** No lock-in to specific LLM providers
7. **Full Observability:** Inspect, snapshot, compare

**Start with defaults, monitor quality metrics, tune per agent type.**
