# harness-utils API Reference

Quick reference for harness-utils 0.3.0 multi-agent patterns.

For complete details, see `docs/references/multi-agent-guide.md`

## Core Pattern

**One ConversationManager per agent:**

```python
from harnessutils import ConversationManager, HarnessConfig

# Main agent (conservative settings)
main_config = HarnessConfig()
main_config.pruning.prune_protect = 80_000
main_manager = ConversationManager(storage, main_config)

# Subagent (aggressive settings)
sub_config = HarnessConfig()
sub_config.pruning.prune_protect = 15_000
sub_manager = ConversationManager(storage, sub_config)
```

## Common Operations

### Create Conversation

```python
conv = manager.create_conversation(project_id="my_project")
```

### Add Message

```python
manager.add_message(conv.id, {
    "role": "user",
    "content": "Hello"
})
```

### Prune Before Turn

```python
manager.prune_before_turn(conv.id)
```

### Convert to Model Format

```python
messages = manager.to_model_format(conv.id)
response = llm.invoke(messages)
```

### Check Context Usage

```python
usage = manager.calculate_context_usage(conv.id)
if manager.needs_compaction(conv.id, usage):
    manager.compact(conv.id, llm_client, parent_msg_id)
```

### Selective Loading

```python
# Recent messages only
recent = manager.query_messages(
    conv.id,
    limit=10,
    order="desc"
)

# Errors only
errors = manager.query_messages(
    conv.id,
    filter={"has_errors": True}
)

# High-importance only
important = manager.query_messages(
    conv.id,
    filter={"min_importance": 50.0}
)

# Lightweight summary
summary = manager.get_context_summary(conv.id)
```

### Quality Monitoring

```python
quality = manager.get_context_quality(conv.id)
# {
#   information_density: 0.73,
#   redundancy_ratio: 0.18,
#   staleness_score: 0.12,
#   health: "good|degraded|poor",
#   recommendations: [...]
# }
```

## Configuration Profiles

### Main Agent (Long-Running)

```python
config = HarnessConfig()
config.pruning.prune_protect = 80_000
config.pruning.prune_minimum = 40_000
config.truncation.max_lines = 5000
config.compaction.use_predictive = True
config.compaction.predictive_lookahead = 10
```

### Exploration Agent (Short-Lived)

```python
config = HarnessConfig()
config.pruning.prune_protect = 15_000
config.pruning.prune_minimum = 5_000
config.truncation.max_lines = 1000
config.compaction.use_predictive = False
```

### Debug Agent (Preserve Errors)

```python
config = HarnessConfig()
config.pruning.error_boost = 1000.0
config.pruning.warning_boost = 500.0
config.pruning.tool_importance["bash"] = 200.0
config.pruning.protected_tools.append("bash")
```

### Review Agent (Prioritize Code Changes)

```python
config = HarnessConfig()
config.pruning.tool_importance["write"] = 200.0
config.pruning.tool_importance["edit"] = 200.0
config.pruning.tool_importance["read"] = 30.0
config.pruning.detect_duplicates = True
config.pruning.similarity_threshold = 0.9
```

## Multi-Agent Patterns

### Pattern 1: Main + Exploration Subagents

```python
# Run exploration
explore_result = run_exploration_agent(explore_conv)

# Extract findings (selective loading)
findings = explore_manager.query_messages(
    explore_conv.id,
    filter={"min_importance": 100.0}
)

# Feed to main agent
for finding in findings:
    main_manager.add_message(main_conv.id, finding)

# Cleanup
explore_manager.storage.delete_conversation(explore_conv.id)
```

### Pattern 2: Parallel Specialists

```python
# Create conversations
debug_conv = debug_manager.create_conversation(project_id="proj")
review_conv = review_manager.create_conversation(project_id="proj")
test_conv = test_manager.create_conversation(project_id="proj")

# Run in parallel
results = await asyncio.gather(
    run_debug_agent(debug_conv),
    run_review_agent(review_conv),
    run_test_agent(test_conv)
)

# Aggregate results
for result in results:
    main_manager.add_message(main_conv.id, result)
```

### Pattern 3: Hierarchical Tree

```python
# Root agent
root_conv = manager.create_conversation(project_id="proj")

# Spawn children
for task in tasks:
    child_conv = manager.create_conversation(project_id="proj")
    await run_child_agent(child_conv, task)

    # Rollup summary
    summary = manager.get_context_summary(child_conv.id)
    root_manager.add_message(root_conv.id, summary_message(summary))
```

## Key Features

### Part-Based Messages

Messages decomposed into parts (text, tool, reasoning):

```python
Message {
    id, role, parent_id,
    parts: [
        TextPart(text="I'll help..."),
        ToolPart(tool="read", state=ToolState(...)),
        TextPart(text="The file contains...")
    ]
}
```

### Three-Tier Context Management

1. **Truncation** (Proactive, 0ms): Prevent large outputs at source
2. **Pruning** (Proactive, ~50ms): Remove old tool outputs by importance
3. **Summarization** (Reactive, ~3-5s): LLM-powered compression

### Importance-Based Pruning

```python
score = (
    recency_score * 1.0 +
    size_penalty * -0.5 +
    semantic_score * 2.0 +
    tool_priority * 1.5
)
```

### Duplicate Detection

Uses similarity hashing (5-word shingles + Jaccard):

```python
config.pruning.detect_duplicates = True
config.pruning.similarity_threshold = 0.8
config.pruning.duplicate_lookback = 20
```

### Predictive Overflow

Tracks conversation velocity to trigger compaction before overflow:

```python
config.compaction.use_predictive = True
config.compaction.predictive_lookahead = 5
config.compaction.predictive_safety_margin = 0.8  # At 80% of limit
```

## Best Practices

1. **Prune proactively:** `manager.prune_before_turn(conv_id)` before each user turn
2. **Monitor quality:** Check `get_context_quality()` and intervene if poor
3. **Use predictive overflow:** Enable to prevent sudden failures
4. **Track token breakdown:** `get_tool_output_tokens()` to identify heavy tools
5. **Snapshot critical states:** For rollback, A/B testing, reproducibility
6. **Validate configuration:** `config.validate()` to catch misconfigurations early
7. **Customize importance:** Different agents = different priorities

## Common Issues

### Context degrading over time

```python
# Run deduplication
result = manager.scan_and_deduplicate(conv_id)

# Lower threshold for stricter dedup
config.pruning.similarity_threshold = 0.85
```

### Important content being pruned

```python
# Increase error/warning boost
config.pruning.error_boost = 1000.0
config.pruning.warning_boost = 500.0

# Protect specific tools
config.pruning.protected_tools.extend(["bash", "error"])
config.pruning.protect_turns = 3
```

### Unexpected token limit exceeded

```python
# Enable predictive overflow
config.compaction.use_predictive = True
config.compaction.predictive_lookahead = 10

# Lower pruning thresholds
config.pruning.prune_protect = 60_000
config.pruning.prune_minimum = 30_000
```

## See Also

- `docs/references/multi-agent-guide.md` - Complete guide
- `docs/architectural-patterns.md#conversation-management` - How we use it
