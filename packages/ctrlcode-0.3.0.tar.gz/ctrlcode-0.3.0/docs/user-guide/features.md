# Features Guide

Complete reference for ctrl+code features and capabilities.

## Slash Commands

Built-in commands invoked with `/` prefix in the TUI.

### Core Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available slash commands |
| `/exit`, `/quit` | Exit the application |
| `/clear` | Clear chat history (local display only, session persists) |

### Session Management

| Command | Description |
|---------|-------------|
| `/compact` | Compact conversation history (remove redundancy, preserve context) |
| `/summarize` | Generate conversation summary |
| `/stats` | Show context statistics (token usage, message count) |

### Task Management

| Command | Description |
|---------|-------------|
| `/todos` | Open todo list modal (create, update, track tasks) |

### Multi-Agent Mode

| Command | Description |
|---------|-------------|
| `/agents` | Show active agents panel (Ctrl+A shortcut) |
| `/tasks` | Show task dependency graph (Ctrl+T shortcut) |
| `/review` | Show review feedback from agents (Ctrl+R shortcut) |

### Observability

| Command | Description |
|---------|-------------|
| `/status` | Open event bus viewer (real-time system events) |
| `/metrics` | Show observability results (performance, errors) |
| `/details` | Toggle continuation exploration details visibility |

### Historical Learning

| Command | Description |
|---------|-------------|
| `/history` | Show historical learning metrics (oracle reuse, bug patterns) |

## Custom Skills

Extend ctrl+code with custom slash commands using TOML-based skill definitions.

### Creating Skills

Skills are defined in TOML files in the skills directory:

**Default location**: `~/.config/ctrlcode/skills/`

**Override in config**:
```toml
[skills]
directory = "/path/to/custom/skills"
```

### Skill File Format

**Example**: `~/.config/ctrlcode/skills/refactor.toml`

```toml
name = "refactor"
description = "Refactor code for better readability"
requires_args = false
prompt = """
Refactor the selected code to improve:
- Readability and clarity
- Performance where possible
- Remove code duplication
- Add helpful comments for complex logic

Preserve all functionality - this is a pure refactor.
"""

[[examples]]
example = "/refactor"
```

**With arguments**:
```toml
name = "explain"
description = "Explain code concept"
requires_args = true
prompt = """
Explain the following concept in detail: {args}

Include:
- What it is and why it matters
- Common use cases
- Best practices
- Pitfalls to avoid
"""

[[examples]]
example = "/explain async/await"

[[examples]]
example = "/explain dependency injection"
```

### Skill Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | yes | Slash command name (invoked as `/<name>`) |
| `prompt` | string | yes | Template sent to LLM (`{args}` placeholder if requires_args) |
| `description` | string | no | Human-readable description (shown in `/help`) |
| `requires_args` | boolean | no | Whether skill requires arguments (default: false) |
| `examples` | array | no | Usage examples for documentation |

### Using Skills

```bash
# No arguments
/refactor

# With arguments (if requires_args = true)
/explain context managers

# Skills are loaded at server startup
# Reload: restart server or add hot-reload config
```

## Differential Fuzzing

Oracle-based code validation through specification-driven fuzzing.

### How It Works

When you request code generation:

1. **Code Generation**: LLM generates code from your specification
2. **Context Derivation**: Analyzes code to derive behavioral oracle (6-layer analysis)
3. **Test Generation**: Creates fuzzing scenarios (input, environment, combined, invariant tests)
4. **Execution**: Runs tests against generated code
5. **Validation**: Compares results against oracle expectations
6. **Correction**: If failures found, oracle guides code fixes
7. **Iteration**: Repeats until budget exhausted or all tests pass

### Context Derivation Layers

The oracle is derived through 6-layer analysis:

1. **System Placement**: Where code fits in architecture (frontend/backend/utility)
2. **Environmental Constraints**: External dependencies (APIs, databases, file system)
3. **Integration Contracts**: Input/output types, interfaces, error handling
4. **Behavioral Invariants**: Core logic properties that must hold
5. **Edge Cases**: Boundary conditions, null handling, empty inputs
6. **Implicit Assumptions**: Unstated requirements from specification

### Test Distribution

Configurable test scenario mix (must sum to 1.0):

```toml
[fuzzing.distribution]
input_fuzz_ratio = 0.3        # Vary inputs (edge cases, invalid data)
environment_fuzz_ratio = 0.4  # Vary environment (mocks, failures, delays)
combined_fuzz_ratio = 0.2     # Both input + environment variations
invariant_fuzz_ratio = 0.1    # Pure invariant checks (no variations)
```

**Input Fuzzing**: Tests with varied inputs:
- Edge cases (empty, null, max values)
- Invalid data (wrong types, malformed)
- Boundary conditions (min/max, off-by-one)

**Environment Fuzzing**: Tests with varied environment:
- API failures (timeouts, 4xx/5xx errors)
- Database unavailability
- File system errors (permissions, missing files)
- Network issues

**Combined Fuzzing**: Both input and environment variations simultaneously

**Invariant Testing**: Pure property checks without variations

### Budgets and Limits

Control fuzzing resource usage:

```toml
[fuzzing]
max_iterations = 10           # Max fuzzing iterations
budget_tokens = 100000        # Token budget for entire session
budget_seconds = 30           # Time budget in seconds
```

Session stops when **any** budget is exhausted.

### Skip Conditions

Avoid fuzzing trivial code:

```toml
[fuzzing.skip]
simple_edits = true           # Skip if code is simple edit/refactor
under_lines = 10              # Skip if code < N lines
```

### Oracle Settings

```toml
[fuzzing.oracle]
confidence_threshold = 0.8              # Min confidence to apply oracle corrections
re_derivation_on_mismatch = true        # Re-derive oracle if tests fail repeatedly
```

**Confidence threshold**: Oracle corrections only applied if confidence ≥ 0.8 (prevents low-quality fixes)

**Re-derivation**: If oracle consistently fails to guide fixes, re-derive from scratch with failure context

### Disabling Fuzzing

```toml
[fuzzing]
enabled = false
```

Code generation works without fuzzing, but no automated validation occurs.

## Historical Learning

Ctrl+code learns from past fuzzing sessions to improve over time.

### How It Works

After each fuzzing session:
1. **Code is embedded** using SentenceTransformers (semantic vector)
2. **Oracle is embedded** and stored alongside code
3. **Bugs are embedded** if failures occurred
4. **Test cases are embedded** for clustering

Before deriving new oracle:
1. **Search history** for similar code (cosine similarity)
2. **If match found** (similarity > 0.85): adapt existing oracle instead of deriving from scratch
3. **Check bug patterns**: warn if similar code had bugs before
4. **Cluster test cases**: deduplicate redundant tests

### Benefits

- **Faster oracle derivation**: Reuse instead of re-derive (saves LLM calls)
- **Proactive bug warnings**: "Similar code had SQL injection issue"
- **Reduced test redundancy**: Cluster and deduplicate similar tests
- **Improving quality**: Oracle adaptations benefit from historical corrections

### Metrics

View historical learning metrics:

```bash
# In TUI
/history

# Shows:
# - Oracle reuse rate (% of derivations that reused historical oracles)
# - Bug pattern detection hits
# - Test deduplication savings
# - LLM call savings
```

### Storage

Historical data stored in:
- **SQLite database**: `~/.cache/ctrlcode/history.db`
- **FAISS indexes**: `~/.cache/ctrlcode/embeddings/` (code, oracles, bugs, tests)

### Privacy

All embeddings are **local** (SentenceTransformers model). No code is sent to external APIs for embedding.

## Tools

Ctrl+code provides tools for file operations, code exploration, and system interaction.

### File Operations

- **read_file**: Read file contents from workspace
- **write_file**: Create or overwrite files
- **update_file**: Search-and-replace or regex-based edits (with ReDoS protection)
- **list_directory**: List files in directory

**Security**: All file operations restricted to workspace root (path traversal prevention)

### Code Exploration

- **search_files**: Regex search across workspace files
- **search_symbol**: Find function/class definitions
- **get_definition**: Navigate to symbol definition

### Bash Execution

- **run_command**: Execute shell commands in workspace
  - Working directory preserved across commands
  - Timeout protection (default: 30s, configurable)
  - Output length limits (prevents memory issues)

**Security**: Commands run in workspace context, no arbitrary path execution

### Web Fetching

- **web_search**: Search the web for information
- **web_fetch**: Fetch and parse web pages (HTML → Markdown)
  - Configurable timeout
  - Content length limits

### Observability

- **trace_execution**: Instrument code with tracing
- **add_logging**: Add structured logging to code
- **analyze_performance**: Profile code for bottlenecks

### Todo Management

- **todo_create**: Create new task
- **todo_update**: Update task status/description
- **todo_list**: List all tasks
- **todo_delete**: Delete task

Tasks are tracked in session and can be displayed via `/todos` modal.

### MCP Tools

Model Context Protocol servers extend tool capabilities:

```toml
[[mcp.servers]]
name = "filesystem"
command = ["npx", "-y", "@modelcontextprotocol/server-filesystem", "/workspace"]
env = { "DEBUG" = "mcp:*" }
```

MCP servers provide additional tools loaded dynamically at runtime.

**Security**: Executables must be in trusted paths (see [Security Guide](security.md))

## TUI Features

Textual-based terminal user interface with advanced capabilities.

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Enter` | Submit message |
| `Ctrl+C` | Cancel current operation |
| `Ctrl+Q` | Quit application |
| `Ctrl+A` | Toggle agents panel |
| `Ctrl+T` | Toggle task graph |
| `Ctrl+R` | Toggle review feedback |
| `Ctrl+S` | Toggle event status |
| `Ctrl+M` | Toggle metrics |
| `Ctrl+H` | Toggle history modal |
| `↑` / `↓` | Navigate input history |

### Status Line

Bottom status bar showing:
- **Connection**: Server status (connected/disconnected)
- **Provider**: Active LLM provider (Anthropic/OpenAI)
- **Model**: Current model name
- **Fuzzing**: Enabled/disabled status
- **Session**: Session ID

### Modals

Event-driven modals for focused views:

**Agents Modal** (`Ctrl+A` or `/agents`):
- Active agent list
- Agent status (idle/working)
- Current task assignment

**Tasks Modal** (`Ctrl+T` or `/tasks`):
- Task dependency graph
- Task status (pending/in_progress/completed)
- Blocked relationships

**Status Modal** (`Ctrl+S` or `/status`):
- Real-time event stream
- System events (fuzzing, tool execution, errors)
- Filterable by event type

**Review Modal** (`Ctrl+R` or `/review`):
- Multi-agent review feedback
- Code quality suggestions
- Architecture recommendations

**Metrics Modal** (`Ctrl+M` or `/metrics`):
- Observability results
- Performance metrics
- Error tracking

**History Modal** (`Ctrl+H` or `/history`):
- Historical learning metrics
- Oracle reuse statistics
- Bug pattern detection results
- Test deduplication savings

### Code Blocks

Collapsible syntax-highlighted code blocks:
- Click header to collapse/expand
- Language detection from context
- Scroll long blocks independently

### Input History

Navigate previous messages:
- `↑` - Previous message
- `↓` - Next message
- History persists across session

## Session Management

Sessions track conversation history and state.

### Session Lifecycle

1. **Creation**: New session on TUI start (generates unique session ID)
2. **Logging**: All events logged to JSONL file (`~/.local/share/ctrlcode/sessions/<session_id>.jsonl`)
3. **Persistence**: Conversation stored in `~/.cache/ctrlcode/conversations/<session_id>.json`
4. **Resumption**: Sessions can be resumed across restarts (future feature)

### Context Compaction

Reduce token usage while preserving context:

```bash
/compact
```

**How it works**:
1. Analyzes conversation for redundancy
2. Removes duplicate information
3. Merges similar messages
4. Preserves critical context (recent messages, important decisions)
5. Updates conversation with compacted version

**Automatic compaction**: Triggered when approaching context limit

### Context Pruning

When context exceeds `context.default_limit` tokens:

1. **Oldest messages pruned** (FIFO)
2. **Recent messages protected** (last `context.prune_protect` tokens)
3. **Critical context preserved** (system prompt, AGENT.md instructions)

Configure in `config.toml`:

```toml
[context]
prune_protect = 40000     # Protect last 40K tokens
default_limit = 200000    # Max context window
```

### Session Statistics

View token usage and message counts:

```bash
/stats

# Output:
# Messages: 42
# Tokens: 85,234 / 200,000 (43%)
# Protected: 40,000 tokens
```

## Multi-Agent Mode

Coordinate multiple specialized agents for complex tasks.

### Agent Types

Agents are dynamically spawned based on task requirements:
- **Planner**: Breaks down tasks into steps
- **Implementer**: Writes code
- **Reviewer**: Reviews code quality
- **Tester**: Writes and runs tests
- **Debugger**: Investigates failures

### Agent Panel

View active agents in real-time (`Ctrl+A`):
- Agent name and role
- Current status (idle/working/waiting)
- Assigned task
- Progress indicator

### Task Graph

Visualize task dependencies (`Ctrl+T`):
- Nodes: Tasks
- Edges: Dependencies (task A blocks task B)
- Colors: Status (pending/in_progress/completed)
- Interactive: Click nodes for details

### Review Feedback

Aggregated agent reviews (`Ctrl+R`):
- Code quality scores
- Architecture suggestions
- Performance concerns
- Security issues flagged

### Coordination

Agents coordinate through:
- **Task queue**: Shared priority queue
- **Dependencies**: Tasks block others until complete
- **Reviews**: Code must pass review before merge
- **Conflict resolution**: Automated or user-prompted

## Best Practices

### Effective Specifications

✅ **DO**:
- Be specific about requirements
- Include examples of expected behavior
- Mention edge cases explicitly
- Specify performance requirements
- Note security considerations

❌ **DON'T**:
- Write vague specs ("make it better")
- Assume implicit requirements
- Skip error handling details
- Ignore performance constraints

### Fuzzing Configuration

**Development** (fast iteration):
```toml
[fuzzing]
enabled = false  # Or low budget
max_iterations = 3
budget_tokens = 20000
```

**Production** (thorough validation):
```toml
[fuzzing]
enabled = true
max_iterations = 20
budget_tokens = 200000
budget_seconds = 120
```

### Skills Organization

- **One skill per file**: `~/.config/ctrlcode/skills/refactor.toml`
- **Descriptive names**: Use clear slash command names
- **Examples**: Include usage examples for documentation
- **Prompt quality**: Write detailed prompts with clear instructions

### Session Management

- **Compact regularly**: Use `/compact` when history grows (saves tokens)
- **Clear when switching contexts**: `/clear` for fresh start on new topics
- **Monitor stats**: Check `/stats` to avoid context limits
- **Review history**: Use `/history` to check learning metrics

## Troubleshooting

### Fuzzing Issues

**Fuzzing takes too long**:
- Reduce `budget_tokens` or `budget_seconds`
- Lower `max_iterations`
- Adjust test distribution (reduce `environment_fuzz_ratio`)

**Too many false failures**:
- Increase `oracle_confidence_threshold` (fewer but higher quality corrections)
- Review derived oracle (may be too strict)
- Check if specification is ambiguous

**Oracle doesn't match intent**:
- Be more specific in specification
- Enable `re_derivation_on_mismatch` (default: true)
- Review context derivation layers manually

### Historical Learning Issues

**Oracle reuse rate is 0%**:
- Need more fuzzing sessions to build history (requires ~20-30 sessions)
- Check similarity threshold (default 0.85 is conservative)
- Verify embeddings are being generated (check logs)

**Bug pattern detection not working**:
- Requires historical bug data (fuzzing must have found bugs)
- Check embeddings are enabled
- Review FAISS index (may need rebuild)

**Test deduplication too aggressive**:
- Lower clustering threshold (default: cosine distance < 0.2)
- Review deduplicated tests (keep best per cluster)

### Performance Issues

**TUI is slow**:
- Reduce event bus verbosity
- Disable multi-agent mode if not needed
- Lower fuzzing budget
- Compact conversation history

**Server high memory usage**:
- Check for large tool outputs (truncate if needed)
- Reduce context window size
- Clear old sessions from disk

**Slow fuzzing iterations**:
- Use faster model (e.g., Claude Haiku instead of Opus)
- Reduce test count per iteration
- Lower graph expansion depth (if using historical learning)

## See Also

- [Configuration Guide](configuration.md) - Customize settings
- [Security Guide](security.md) - Security features and best practices
- [Getting Started](getting-started.md) - Installation and setup
- [Developer Guide](../developer-guide/) - Extend ctrl+code with custom tools/skills
