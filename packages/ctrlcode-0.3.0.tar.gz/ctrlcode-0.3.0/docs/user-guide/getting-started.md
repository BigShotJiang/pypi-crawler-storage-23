# Getting Started with ctrl+code

## Prerequisites

- **Python 3.12+** (required)
- **API Key** for at least one LLM provider:
  - Anthropic (Claude) - set `ANTHROPIC_API_KEY`
  - OpenAI (GPT) - set `OPENAI_API_KEY`

## Installation

Using `uv` (recommended):
```bash
uv pip install ctrlcode
```

Using `pip`:
```bash
pip install ctrlcode
```

This installs two commands:
- `ctrlcode` - TUI client (auto-launches server)
- `ctrlcode-server` - JSON-RPC server (manual mode)

## First Run

1. **Set your API key:**
   ```bash
   export ANTHROPIC_API_KEY="sk-ant-..."
   # or
   export OPENAI_API_KEY="sk-..."
   ```

2. **Launch the TUI:**
   ```bash
   ctrlcode
   ```

   On first run:
   - Config file created at `~/.config/ctrlcode/config.toml`
   - API key auto-generated and saved (used for TUI ↔ server auth)
   - Config file permissions set to `600` (user-only)
   - Server auto-launches in background

3. **Start coding:**
   - Type your request and press Enter
   - Use `/help` to see available slash commands
   - Press `Ctrl+Q` to quit

## Configuration

Config location (platform-specific):
- **Linux**: `~/.config/ctrlcode/config.toml`
- **macOS**: `~/Library/Application Support/ctrlcode/config.toml`
- **Windows**: `%APPDATA%\ctrlcode\config.toml`

### Basic config.toml

```toml
[server]
host = "127.0.0.1"
port = 8765
api_key = "auto-generated-on-first-run"

[providers.anthropic]
model = "claude-sonnet-4-5-20250929"
# api_key loaded from ANTHROPIC_API_KEY env var

[providers.openai]
model = "gpt-4"
# api_key loaded from OPENAI_API_KEY env var

[security]
max_input_length = 200000  # 200K chars, -1 for unlimited
rate_limit_enabled = true
rate_limit_max_requests = 30  # per minute
```

## Manual Server Mode

If you prefer to run the server separately:

```bash
# Terminal 1: Start server
ctrlcode-server

# Terminal 2: Start TUI (connects to existing server)
ctrlcode
```

## Next Steps

- [Configuration Guide](configuration.md) - Customize providers, security, MCP servers
- [Features](features.md) - Slash commands, fuzzing, historical learning
- [Security](security.md) - API keys, permissions, MCP server validation

## Troubleshooting

**Error: "No providers configured"**
- Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` environment variable

**Error: "Config file is world-writable"**
- Fix permissions: `chmod 600 ~/.config/ctrlcode/config.toml`

**Error: "Unauthorized - invalid or missing API key"**
- Delete config file and restart to regenerate API key
- Or manually set `api_key` in `[server]` section

**Server won't start**
- Check if port 8765 is already in use: `lsof -i :8765`
- Change port in config.toml `[server]` section
