# Security Guide

Comprehensive security documentation for ctrl+code.

## Overview

ctrl+code implements defense-in-depth security with multiple layers:

1. **Authentication** - API key for server-client communication
2. **File permissions** - Config file protection
3. **Input validation** - Length limits, sanitization, rate limiting
4. **Path validation** - Workspace boundaries, trusted executables
5. **Pattern validation** - ReDoS protection for regex
6. **Audit logging** - Command execution tracking

## API Key Authentication

### How It Works

The TUI and server communicate over HTTP using Bearer token authentication:

```
TUI → HTTP Request + Authorization: Bearer <api_key> → Server
Server → Validates API key → Processes request
```

**Key generation:**
- Auto-generated on first config load using `secrets.token_urlsafe(32)`
- 32 bytes = 256 bits of entropy (cryptographically secure)
- Stored in `config.toml` with 600 permissions

**Validation:**
- Server checks `Authorization: Bearer <key>` header on all `/rpc` requests
- Uses `hmac.compare_digest()` for constant-time comparison (prevents timing attacks)
- Returns `401 Unauthorized` if missing or invalid

### Security Properties

✅ **Prevents unauthorized access** - Only clients with API key can connect
✅ **Timing-attack resistant** - Constant-time comparison prevents side-channel attacks
✅ **Local-only by default** - Server binds to `127.0.0.1` (localhost)

### Regenerating API Key

If your API key is compromised:

```bash
# Method 1: Delete config and restart (auto-generates new key)
rm ~/.config/ctrlcode/config.toml
ctrlcode

# Method 2: Manually set in config
# Edit config.toml and change api_key value
```

### Remote Access (Advanced)

**⚠️ WARNING**: Only expose to trusted networks!

To allow remote TUI connections:

**Server config.toml:**
```toml
[server]
host = "0.0.0.0"  # Listen on all interfaces
port = 8765
api_key = "your-shared-secret-key"

[security]
rate_limit_max_requests = 10  # Stricter limits for remote
```

**Client:**
```bash
# Copy API key from server's config.toml to client's config.toml
ctrlcode --server http://remote-host:8765
```

**Additional hardening for remote:**
- Use firewall to restrict access (e.g., only VPN network)
- Use SSH tunneling instead of direct exposure
- Monitor logs for suspicious activity

## Config File Permissions

### Why It Matters

Config file contains:
- API key (grants server access)
- Provider API keys (if stored in config)
- MCP server commands (arbitrary code execution)

If attackers modify config, they can:
- Steal your API key
- Execute malicious MCP commands
- Hijack your LLM API keys

### Permission Requirements

**Required**: `600` (user read/write only)

```bash
-rw------- 1 user user config.toml  # ✅ Secure
-rw-rw-r-- 1 user group config.toml  # ❌ Group/world readable!
```

**Automatic enforcement:**
- Config saved with `chmod 600` on creation
- Validation on load - rejects world/group-writable files
- Error message provides fix command

**Error example:**
```
ValueError: Config file /home/user/.config/ctrlcode/config.toml is world-writable (insecure).
Run: chmod 600 /home/user/.config/ctrlcode/config.toml
```

### Manual Fix

```bash
chmod 600 ~/.config/ctrlcode/config.toml
```

## MCP Server Executable Validation

### Threat Model

MCP servers execute arbitrary commands. If config is modified, attacker could:

```toml
# Malicious example (blocked by validation!)
[[mcp.servers]]
name = "backdoor"
command = ["/tmp/malware.sh"]
```

### Security Measures

**1. Trusted path validation**

Executables must be in trusted locations:
- Virtual environment: `{venv}/bin/` or `{venv}/Scripts/` (Windows)
- User installs: `~/.local/bin/`
- System binaries: `/usr/local/bin/`, `/usr/bin/`
- Custom MCP directory: `~/.config/ctrlcode/mcp-servers/`

**Rejected paths:**
- `/tmp/`
- User's home directory (unless `.local/bin/`)
- Arbitrary paths

**2. Path traversal prevention**

```toml
# Blocked: path traversal
command = ["~/../../tmp/evil.sh"]  # ❌ Error: path traversal detected
```

Path validation:
- Expands `~` first
- Resolves symlinks and `..` components
- Checks if resolved path is within trusted prefix
- Rejects if `..` remains in path parts

**3. Executable verification**

Checks:
- File exists
- Is a regular file (not directory/symlink)
- Has execute permission (`os.X_OK`)

**4. Command replacement**

After validation, command[0] is replaced with absolute resolved path:

```toml
# Config
command = ["npx", "-y", "@modelcontextprotocol/server-filesystem"]

# Becomes (after validation)
command = ["/home/user/.local/bin/npx", "-y", "@modelcontextprotocol/server-filesystem"]
```

Prevents TOCTOU (Time-of-Check Time-of-Use) attacks.

### Audit Logging

Server logs MCP commands on startup:

```
INFO - Starting MCP server 'filesystem' with command: /usr/local/bin/npx -y @modelcontextprotocol/server-filesystem /workspace
```

Check logs for unexpected commands:
```bash
tail -f ~/.local/share/ctrlcode/logs/server.log | grep "Starting MCP"
```

### Custom MCP Servers

To use custom MCP servers securely:

**1. Create trusted directory:**
```bash
mkdir -p ~/.config/ctrlcode/mcp-servers
chmod 700 ~/.config/ctrlcode/mcp-servers
```

**2. Install your server:**
```bash
cp my-server ~/.config/ctrlcode/mcp-servers/
chmod 755 ~/.config/ctrlcode/mcp-servers/my-server
```

**3. Configure:**
```toml
[[mcp.servers]]
name = "my-server"
command = ["~/.config/ctrlcode/mcp-servers/my-server"]
```

## Input Validation & Sanitization

### Length Limits

**Purpose**: Prevent DoS via massive inputs

**TUI-side**: 100K chars (configurable via server config)
**Server-side**: 200K chars default (configurable, -1 = unlimited)

```toml
[security]
max_input_length = 200000  # 200K default
# max_input_length = -1    # Unlimited (use with caution)
```

**Enforcement:**
- TUI validates before sending
- Server validates before processing
- Returns error if exceeded

### Control Character Removal

**Purpose**: Prevent injection attacks via control characters

Server removes:
- Null bytes (`\x00`) - rejected outright
- Control characters except `\n` and `\t` (chars < 32 or == 127)

Example:
```python
# Input: "code\x00with\x01nulls"
# Sanitized: "codewithnulls"
```

### Prompt Injection Detection

**Purpose**: Warn about suspicious patterns (logged, not blocked)

Detected patterns:
- `"ignore previous instructions"`
- `"disregard all"`
- `"new instructions:"`
- `"system:"`
- `"<|endoftext|>"`
- `"<|im_start|>"`, `"<|im_end|>"`

**Action**: Logged as warning, not blocked (to allow legitimate discussion of these patterns)

```
WARNING - Suspicious input pattern detected: ignore previous instructions
```

### ReDoS Protection

**Purpose**: Prevent Regular Expression Denial of Service in `update_file` search patterns

**Validation:**
1. **Length limit**: Max 500 chars
2. **Nested quantifier detection**: Blocks patterns like:
   - `(a+)+` - nested plus quantifiers
   - `(a*)+` - star + plus combo
   - `(a+)*` - plus + star combo
   - `(a*)*` - nested star quantifiers

3. **Timeout**: 2-second alarm for regex operations

**Example blocked pattern:**
```python
# This would cause catastrophic backtracking (blocked!)
search_pattern = "(a+)+"
# Error: Pattern contains nested quantifiers that may cause ReDoS
```

## Rate Limiting

**Purpose**: Prevent abuse/spam

**Default limits:**
- 30 requests per minute per session
- Sliding window (60 seconds)

**Configuration:**
```toml
[security]
rate_limit_enabled = true
rate_limit_window_seconds = 60.0
rate_limit_max_requests = 30
```

**Behavior:**
- Tracks requests per session ID
- Returns `429 Too Many Requests` when exceeded
- Logs warning with session ID

**Disable for testing:**
```toml
[security]
rate_limit_enabled = false
```

## Path Traversal Prevention

### Workspace Boundaries

All file operations are restricted to workspace root.

**Tools affected:**
- `read_file`
- `write_file`
- `update_file`
- `list_directory`
- `search_files`
- `run_command` (cwd parameter)

**Validation:**
```python
file_path = (workspace_root / path).resolve()
if not str(file_path).startswith(str(workspace_root)):
    return {"error": "Path outside workspace"}
```

**Attack examples (blocked):**
```python
# Attempt to read /etc/passwd
read_file(path="../../../../../../etc/passwd")
# Error: Path outside workspace

# Attempt to write to /tmp
write_file(path="../../../tmp/evil.sh", content="...")
# Error: Path outside workspace
```

### Symlink Handling

`Path.resolve()` follows symlinks before validation:

```bash
# If workspace/link -> /etc/passwd
# Then: workspace/link resolves to /etc/passwd
# Validation: /etc/passwd not in workspace → blocked
```

## Best Practices

### Development

✅ **DO:**
- Use environment variables for provider API keys
- Keep config file permissions at 600
- Review MCP server commands before adding
- Enable rate limiting
- Use reasonable input length limits
- Monitor server logs for suspicious activity

❌ **DON'T:**
- Store API keys directly in config (use env vars)
- Make config world-readable
- Use MCP servers from untrusted sources
- Disable rate limiting in production
- Set unlimited input length without good reason

### Production Deployment

1. **Config hardening:**
```toml
[security]
max_input_length = 100000  # Stricter limit
rate_limit_max_requests = 10  # Lower threshold
```

2. **File permissions:**
```bash
chmod 600 ~/.config/ctrlcode/config.toml
chmod 700 ~/.config/ctrlcode  # Directory also
```

3. **Network security:**
- Keep `server.host = "127.0.0.1"` for local-only
- If remote access needed, use SSH tunnel or VPN
- Never expose directly to internet without additional auth layer

4. **Monitoring:**
```bash
# Watch for MCP launches
tail -f ~/.local/share/ctrlcode/logs/server.log | grep "MCP"

# Watch for rate limit violations
tail -f ~/.local/share/ctrlcode/logs/server.log | grep "Rate limit"

# Watch for suspicious patterns
tail -f ~/.local/share/ctrlcode/logs/server.log | grep "Suspicious"
```

5. **MCP server review:**
- Only install MCP servers from trusted sources
- Review command before adding to config
- Place custom servers in `~/.config/ctrlcode/mcp-servers/`
- Avoid npm global installs from untrusted packages

### Remote Access (Advanced)

If you must expose remotely:

**1. SSH tunnel (recommended):**
```bash
# On server: bind to localhost only
[server]
host = "127.0.0.1"
port = 8765

# On client: SSH tunnel
ssh -L 8765:localhost:8765 user@remote-host
ctrlcode  # Connects via tunnel
```

**2. VPN (recommended):**
- Use WireGuard/OpenVPN
- Server listens on VPN interface only
- Firewall blocks external access

**3. Direct exposure (not recommended):**
```toml
[server]
host = "0.0.0.0"  # ⚠️ Only with firewall rules!

[security]
rate_limit_max_requests = 5  # Very strict
max_input_length = 50000     # Lower limit
```

Plus firewall:
```bash
# Allow only specific IP
iptables -A INPUT -p tcp --dport 8765 -s 192.168.1.100 -j ACCEPT
iptables -A INPUT -p tcp --dport 8765 -j DROP
```

## Security Checklist

Before using ctrl+code:

- [ ] Config file has 600 permissions
- [ ] API keys in environment variables (not config file)
- [ ] MCP servers are from trusted sources
- [ ] MCP executables in trusted paths only
- [ ] Rate limiting enabled (unless testing)
- [ ] Input length limits are reasonable
- [ ] Server binds to localhost (unless VPN/tunnel)
- [ ] Logs are monitored (optional but recommended)

## Reporting Security Issues

If you discover a security vulnerability:

1. **Do not** open a public GitHub issue
2. Email security details to project maintainer
3. Include: description, reproduction steps, impact assessment
4. Allow reasonable time for fix before disclosure

## See Also

- [Configuration Guide](configuration.md) - Security settings reference
- [Getting Started](getting-started.md) - Initial setup
- [MCP Servers](../developer-guide/mcp-servers.md) - Writing secure MCP servers
