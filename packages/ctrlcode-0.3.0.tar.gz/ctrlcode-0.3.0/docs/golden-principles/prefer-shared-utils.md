# Golden Principle: Prefer Shared Utilities

## Principle Statement

**Don't hand-roll utilities that already exist in shared libraries. Extract repeated patterns into shared utilities. Keep invariants centralized.**

## Why This Matters

### For Humans
- Reduces code duplication
- Centralizes bug fixes (fix once, apply everywhere)
- Ensures consistent behavior across codebase
- Reduces maintenance burden

### For Agents
When agents see 5 different retry implementations, they can't tell which is "correct" or which pattern to follow for new code. Shared utilities establish single source of truth.

**From agent's perspective:**
- ❌ 5 hand-rolled retry loops → Which pattern should I copy? Which handles edge cases?
- ✅ `from ctrlcode.utils import retry` → Clear: this is the blessed approach

Agents replicate patterns they see. Inconsistent patterns lead to inconsistent replication.

## Violations

### ❌ Bad: Hand-Rolled Retry Logic

```python
# src/api/client.py
def fetch_data(url: str):
    for i in range(3):
        try:
            response = requests.get(url)
            return response.json()
        except Exception:
            if i == 2:
                raise
            time.sleep(2 ** i)  # Exponential backoff

# src/database/connection.py
def query_db(sql: str):
    retries = 0
    while retries < 5:  # Different retry count!
        try:
            return db.execute(sql)
        except DBError:
            retries += 1
            time.sleep(retries * 2)  # Different backoff strategy!
```

**Problems:**
- Two implementations with different retry counts (3 vs 5)
- Different backoff strategies (exponential vs linear)
- Can't change retry behavior globally
- Agent might copy either pattern for new code

### ❌ Bad: Duplicate Date Formatting

```python
# Multiple files with different date formats
def format_timestamp_1(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def format_timestamp_2(dt):
    return dt.isoformat()

def format_timestamp_3(dt):
    return f"{dt.year}-{dt.month:02d}-{dt.day:02d}"
```

**Problems:**
- Inconsistent formatting across codebase
- Hard to change format globally
- Which is the "correct" format?

### ❌ Bad: Repeated Validation Patterns

```python
# Appears in 10+ files
if not os.path.exists(file_path):
    raise FileNotFoundError(f"File not found: {file_path}")

if not file_path.endswith((".py", ".md")):
    raise ValueError(f"Invalid file type: {file_path}")
```

**Problems:**
- Duplicated validation logic
- Inconsistent error messages
- Hard to add new file types globally

## Correct Approaches

### ✅ Good: Shared Retry Utility

```python
# src/ctrlcode/utils/retry.py
from typing import Callable, Type
import time
from functools import wraps

def retry(
    max_attempts: int = 3,
    backoff_base: float = 2.0,
    exceptions: tuple[Type[Exception], ...] = (Exception,)
):
    """Retry decorator with exponential backoff.

    Args:
        max_attempts: Maximum retry attempts
        backoff_base: Base for exponential backoff (seconds)
        exceptions: Exception types to catch and retry
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts - 1:
                        raise
                    wait_time = backoff_base ** attempt
                    time.sleep(wait_time)
        return wrapper
    return decorator

# Usage across codebase
from ctrlcode.utils import retry

@retry(max_attempts=3, exceptions=(requests.RequestException,))
def fetch_data(url: str):
    response = requests.get(url)
    return response.json()

@retry(max_attempts=5, exceptions=(DBError,))
def query_db(sql: str):
    return db.execute(sql)
```

**Benefits:**
- Single retry implementation
- Consistent behavior
- Configurable per use case
- Easy to enhance (add logging, metrics, etc.)
- Agent knows this is the blessed pattern

### ✅ Good: Shared Date Utilities

```python
# src/ctrlcode/utils/time.py
from datetime import datetime

def format_timestamp(dt: datetime, format: str = "iso") -> str:
    """Format datetime consistently across codebase.

    Args:
        dt: Datetime to format
        format: One of: iso, human, compact
    """
    formats = {
        "iso": lambda d: d.isoformat(),
        "human": lambda d: d.strftime("%Y-%m-%d %H:%M:%S"),
        "compact": lambda d: d.strftime("%Y%m%d_%H%M%S"),
    }
    return formats[format](dt)

# Usage
from ctrlcode.utils.time import format_timestamp

log_time = format_timestamp(now, "human")    # 2026-02-14 15:30:00
file_name = format_timestamp(now, "compact")  # 20260214_153000
```

### ✅ Good: Shared Validation Utilities

```python
# src/ctrlcode/utils/validation.py
from pathlib import Path

def validate_file_exists(file_path: str | Path, extensions: tuple[str, ...] | None = None):
    """Validate file exists with optional extension check.

    Args:
        file_path: Path to file
        extensions: Allowed extensions (e.g., (".py", ".md"))

    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If extension not in allowed list
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    if extensions and path.suffix not in extensions:
        raise ValueError(
            f"Invalid file type {path.suffix}. Expected one of: {extensions}"
        )

# Usage
from ctrlcode.utils.validation import validate_file_exists

validate_file_exists(file_path, extensions=(".py", ".md"))
```

## When to Extract to Shared Utility

### Extract When:

1. **Pattern appears 2+ times** - Don't wait for 3+ occurrences
2. **Logic has edge cases** - Retry, parsing, validation
3. **Behavior should be consistent** - Date formatting, error handling
4. **Likely to change** - API endpoints, file paths, config keys
5. **Complex enough to have bugs** - More than 3 lines

### Don't Extract When:

1. **Truly unique logic** - Specific to one domain
2. **Trivial operations** - Single function call wrapping
3. **Would obscure intent** - Abstraction makes code less clear

**Rule of thumb:** If you're copying code, extract it. If you're writing similar code, check if utility exists first.

## Shared Utilities in ctrl+code

### Existing Utilities

```python
# src/ctrlcode/utils/
├── __init__.py           # Public API
├── retry.py              # Retry with backoff
├── time.py               # Date/time formatting
├── validation.py         # Common validation patterns
├── filesystem.py         # File operations
└── text.py               # String manipulation
```

### Before Adding Hand-Rolled Code

1. **Check `src/ctrlcode/utils/`** - Does utility already exist?
2. **Check stdlib** - Does Python standard library provide this?
3. **Check dependencies** - Does existing package (requests, pydantic, etc.) provide this?
4. **Extract if none exist** - Add to shared utils

## Enforcement

**Custom linter** (see Task #2) will detect:

```
❌ Hand-Rolled Utility Detected
File: src/api/new_client.py:45
Rule: golden-principles/prefer-shared-utils.md

Violation: Retry logic duplicates existing utility

    for i in range(3):
        try:
            return fetch()
        except Exception:
            time.sleep(2 ** i)

FIX: Use shared retry utility

    from ctrlcode.utils import retry

    @retry(max_attempts=3)
    def fetch_wrapper():
        return fetch()

Why: Centralizes retry logic, ensures consistency.
See: docs/golden-principles/prefer-shared-utils.md
```

## Code Smells to Watch For

### Pattern Duplication
- Same 5+ line block in multiple files
- Similar logic with small variations
- Copy-paste comments (dead giveaway)

### Reinventing Stdlib
```python
# ❌ Don't reinvent
def join_paths(a, b):
    return f"{a}/{b}".replace("//", "/")

# ✅ Use stdlib
from pathlib import Path
path = Path(a) / b
```

### Slightly Different Implementations
```python
# File 1
if x is None or x == "":
    return default

# File 2
if not x:
    return default

# File 3
return x if x else default
```

**Should be:**
```python
# src/ctrlcode/utils/defaults.py
def get_or_default(value, default):
    """Return value if truthy, else default."""
    return value if value else default
```

## Migration Strategy

When finding duplicate code:

1. **Create shared utility** in `src/ctrlcode/utils/`
2. **Add tests** for edge cases
3. **Update existing code** to use utility
4. **Add to index** in `src/ctrlcode/utils/__init__.py`
5. **Update docs** if behavior changes
6. **Let cleanup agent** find remaining duplicates (Task #7)

## Related Principles

- **DRY (Don't Repeat Yourself)** - Classic principle, still valid
- **Single Source of Truth** - One canonical implementation
- **Separation of Concerns** - Utilities handle cross-cutting concerns

## Related Tools

- **ast** - Python AST analysis for detecting duplication
- **radon** - Code complexity and duplication detection
- **ruff** - Can detect some duplication patterns

## Summary

**If you're typing the same code twice, extract it.**

Agents learn from patterns in the codebase. Inconsistent patterns → inconsistent agent behavior. Shared utilities establish canonical approaches, making the codebase more legible to both agents and future developers.

Every duplicate is a potential bug waiting to diverge.
