# Golden Principles

Mechanically enforced rules that maintain codebase quality.

These aren't aspirational—they're enforced by linters, CI checks, and automated tools.

## Active Principles

1. **No YOLO Parsing** (`no-yolo-parsing.md`)
   - Always validate data at system boundaries
   - Don't assume upstream data shape
   - Fail fast on validation errors

2. **Prefer Shared Utilities** (`prefer-shared-utils.md`)
   - Don't hand-roll helpers (retry, backoff, parsing)
   - Use established libraries
   - Extract patterns into shared utils

3. **Structured Logging** (`structured-logging.md`)
   - Standard log format across codebase
   - Include context (task_id, user_id, etc.)
   - Log levels used consistently

## How Enforcement Works

**Linters scan code** → **Find violations** → **Inject remediation into agent context**

Example lint error:
```
❌ YOLO Parsing Detected
File: src/api/parser.py:45
Rule: golden-principles/no-yolo-parsing.md

You're accessing data.user.email without validation.

FIX: Validate at boundary with schema or dataclass
  
See: docs/golden-principles/no-yolo-parsing.md for details
```

## Adding New Principles

1. Document principle in `golden-principles/{name}.md`
2. Add linter rule to enforce it
3. Update this index
4. Run retroactive scan for violations
5. Create cleanup PRs to fix existing code

## Philosophy

**"If it's important enough to document, enforce it mechanically."**

Documentation rots. Linters don't.
