# Core Beliefs

Non-negotiable principles that guide all technical decisions in ctrl+code.

## 1. Humans Steer, Agents Execute

**Belief**: AI agents are autonomous executors, not decision makers.

**In practice**:
- Users provide intent and goals
- Agents decompose, plan, and execute
- Humans approve plans before major changes
- Agents handle iteration, testing, validation

## 2. Progressive Disclosure Over Context Dumping

**Belief**: Quality of context > quantity of context.

**In practice**:
- Load docs as needed, not everything upfront
- Keep AGENTS.md short, link to details
- Agents fetch specific docs when relevant
- Avoid loading 10K+ token monoliths

## 3. Mechanical Enforcement Over Documentation

**Belief**: If it's important enough to document, enforce it mechanically.

**In practice**:
- Linters inject remediation into context
- CI checks enforce golden principles
- Fuzzing validates code quality automatically
- Rules apply everywhere, no exceptions

## 4. Fast Iteration, Cheap Corrections

**Belief**: In high-throughput environments, corrections are cheap, waiting is expensive.

**In practice**:
- Short-lived PRs
- Fix-forward on test flakes
- Minimal blocking merge gates
- Automated rollback on errors

## 5. Specialization Over Generalization

**Belief**: Specialized agents are more reliable than general-purpose agents trying to do everything.

**In practice**:
- Planner for task decomposition
- Coder for implementation
- Reviewer for quality gates
- Executor for runtime validation
- Each has focused prompt and limited tools

## 6. Observability is Context

**Belief**: From agent's point of view, anything it can't access in-context doesn't exist.

**In practice**:
- Logs, metrics, test output must be legible to agents
- Runtime behavior made accessible (not just code)
- Performance data structured for agent interpretation
- UI state accessible via tools (future: CDP integration)

## 7. Continuous Cleanup Over Tech Debt Sprints

**Belief**: Tech debt is like high-interest loan—pay it down continuously in small increments.

**In practice**:
- Background cleanup agents scan for violations
- Automated refactoring PRs
- Golden principles enforced retroactively
- Documentation gardening on schedule

## 8. Agent-First Design

**Belief**: Codebase optimized for agent legibility and effectiveness, not just human preferences.

**In practice**:
- Repository structure as system prompt
- Clear naming conventions
- Structured logging formats
- Tool output designed for agent parsing

## Why These Matter

These beliefs emerge from:
- OpenAI's harness engineering (1M lines, 0 manually written)
- 2026 agentic coding research (multi-agent orchestration trends)
- Production experience with ctrl+code (fuzzing pipeline, context management)

They're not aspirational—they're operational principles that guide daily work.
