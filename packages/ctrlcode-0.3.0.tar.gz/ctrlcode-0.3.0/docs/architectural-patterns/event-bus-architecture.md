# Event Bus Architecture

**Date:** 2026-02-14
**Status:** Active

---

## Overview

The TUI uses a central **event bus** for all inter-component communication.

**Philosophy:** No direct coupling between components. Everything publishes events to the bus, and components subscribe to what they care about.

---

## Architecture

```
┌─────────────────────────────────────────────┐
│              Event Bus                      │
│  (Central message broker)                   │
└─────────────┬───────────────────────────────┘
              │
    ┌─────────┼─────────┬─────────┬──────────┐
    │         │         │         │          │
┌───▼───┐ ┌──▼──┐  ┌───▼────┐ ┌──▼───┐  ┌──▼──────┐
│Status │ │Chat │  │Modals  │ │Input │  │Workflow │
│Line   │ │Log  │  │        │ │Box   │  │         │
└───────┘ └─────┘  └────────┘ └──────┘  └─────────┘
   ▲         ▲         ▲         │           │
   │         │         │         │           │
   └─────────┴─────────┴─────────┴───────────┘
        Subscribe to events    Publish events
```

**Flow:**
1. Workflow publishes event: `bus.publish("workflow_phase_change", {...})`
2. Bus notifies all subscribers to that event type
3. Each subscriber handles event independently
4. No direct component → component calls

---

## Event Bus API

### Publishing Events

```python
from .event_bus import EventBus, EventTypes

# Get global bus instance
bus = app.event_bus

# Publish event
await bus.publish(
    event_type=EventTypes.WORKFLOW_PHASE_CHANGE,
    data={
        "phase": "planning",
        "progress": 0.25,
        "active_agents": 1,
    },
    source="workflow_orchestrator"
)
```

### Subscribing to Events

```python
from .event_bus import Event, EventTypes

# Define handler
async def on_phase_change(event: Event):
    phase = event.data["phase"]
    progress = event.data["progress"]
    # Update UI...

# Subscribe
bus.subscribe(EventTypes.WORKFLOW_PHASE_CHANGE, on_phase_change)

# Subscribe to all events (wildcard)
bus.subscribe("*", on_any_event)
```

### Unsubscribing

```python
# Unsubscribe when component unmounts
bus.unsubscribe(EventTypes.WORKFLOW_PHASE_CHANGE, on_phase_change)
```

---

## Event Catalog

### Workflow Events

All events related to multi-agent workflow execution.

#### `workflow_phase_change`
```python
{
    "phase": "planning",  # planning|execution|review|validation|complete
    "progress": 0.25,     # 0.0 to 1.0
    "active_agents": 1    # optional
}
```

#### `workflow_agent_spawned`
```python
{
    "agent_id": "planner-1",
    "type": "planner",  # planner|coder|reviewer|executor
    "task": "Decompose user intent"  # optional
}
```

#### `workflow_agent_updated`
```python
{
    "agent_id": "coder-1",
    "status": "active",  # optional: active|waiting|complete
    "progress": 0.6,     # 0.0 to 1.0
    "task": "task-2: Add JWT utils"  # optional
}
```

#### `workflow_agent_completed`
```python
{
    "agent_id": "planner-1",
    "result": "success",  # success|error
    "output": {...}       # optional, agent result
}
```

#### `workflow_task_graph_created`
```python
{
    "task_graph": {
        "tasks": [
            {
                "id": "task-1",
                "description": "Read auth implementation",
                "dependencies": [],
                "status": "pending"
            },
            # ...
        ],
        "parallel_groups": [["task-2", "task-3"]]
    }
}
```

#### `workflow_task_updated`
```python
{
    "task_id": "task-2",
    "status": "complete",  # pending|in_progress|complete|error
    "agent_id": "coder-1"  # optional, assigned agent
}
```

#### `workflow_review_feedback`
```python
{
    "feedback": [
        {
            "severity": "blocker",  # blocker|error|info
            "file": "src/api/routes.py",
            "line": 47,
            "message": "Password not hashed",
            "suggestion": "Use bcrypt.hashpw()",
            "status": "pending"  # pending|in_progress|fixed
        }
    ]
}
```

#### `workflow_observability_results`
```python
{
    "results": {
        "tests": {"passed": 5, "failed": 0, "duration": "0.3s"},
        "performance": {"p50": 145, "p95": 189, "p99": 201, "threshold": 200},
        "logs": {"errors": 0, "warnings": 2},
        "recommendation": "approve"  # approve|reject
    }
}
```

#### `workflow_error`
```python
{
    "message": "Task failed",
    "agent_id": "coder-1",
    "task_id": "task-2",
    "exception": "ValueError",
    "traceback": "..."
}
```

#### `workflow_complete`
```python
{
    "status": "success",  # success|error|cancelled
    "summary": "3 tasks completed, all tests passing"
}
```

### UI Events

Events from user interactions.

#### `ui_command_entered`
```python
{
    "command": "agents",  # command name (without /)
    "args": ""            # optional, command arguments
}
```

#### `ui_modal_opened`
```python
{
    "modal_type": "agents",  # agents|tasks|status|review|metrics
}
```

#### `ui_modal_closed`
```python
{
    "modal_type": "agents"
}
```

#### `ui_message_sent`
```python
{
    "message": "User's message text"
}
```

### System Events

System-level events (errors, warnings, info).

#### `system_error`
```python
{
    "message": "Error description",
    "exception": "ValueError",  # optional
    "traceback": "..."          # optional
}
```

#### `system_warning`
```python
{
    "message": "Warning description"
}
```

#### `system_info`
```python
{
    "message": "Info message"
}
```

---

## Component Subscriptions

### StatusLine

Subscribes to:
- `workflow_phase_change` → Update phase/progress
- `system_error` → Show error state

```python
class StatusLine(Static):
    def on_mount(self):
        bus = self.app.event_bus
        bus.subscribe(EventTypes.WORKFLOW_PHASE_CHANGE, self._on_phase_change)
        bus.subscribe(EventTypes.SYSTEM_ERROR, self._on_error)

    async def _on_phase_change(self, event: Event):
        phase = event.data["phase"]
        progress = event.data["progress"]
        self.set_workflow(phase, progress)

    async def _on_error(self, event: Event):
        message = event.data["message"]
        self.set_error(message)
```

### ChatLog

Subscribes to:
- `*` (all events) → Display inline events

```python
class ChatLog(Static):
    def on_mount(self):
        bus = self.app.event_bus
        bus.subscribe("*", self._on_any_event)

    async def _on_any_event(self, event: Event):
        # Show workflow events inline
        if event.type.startswith("workflow_"):
            icon = self._get_icon_for_event(event.type)
            self.add_workflow_event(event.type, str(event.data), icon)
```

### StatusModal (Bus Viewer)

Subscribes to:
- `*` (all events) → Show in event list

```python
class StatusModal(ModalBase):
    def on_mount(self):
        bus = self.app.event_bus
        bus.subscribe("*", self._on_any_event)

    def on_unmount(self):
        bus = self.app.event_bus
        bus.unsubscribe("*", self._on_any_event)

    async def _on_any_event(self, event: Event):
        # Add to event list
        self.add_event(event)
```

### AgentsModal

Subscribes to:
- `workflow_agent_spawned` → Add agent to list
- `workflow_agent_updated` → Update agent status
- `workflow_agent_completed` → Mark agent complete

```python
class AgentsModal(ModalBase):
    def on_mount(self):
        bus = self.app.event_bus
        bus.subscribe(EventTypes.WORKFLOW_AGENT_SPAWNED, self._on_agent_spawned)
        bus.subscribe(EventTypes.WORKFLOW_AGENT_UPDATED, self._on_agent_updated)
        bus.subscribe(EventTypes.WORKFLOW_AGENT_COMPLETED, self._on_agent_completed)

    async def _on_agent_spawned(self, event: Event):
        agent_id = event.data["agent_id"]
        agent_type = event.data["type"]
        # Add to UI...
```

### App (Coordinator)

Subscribes to:
- All workflow events → Store in state for modals

```python
class CtrlCodeApp(App):
    def on_mount(self):
        self.event_bus = EventBus()

        # Subscribe to workflow events to track state
        for event_type in EventTypes.all_workflow_events():
            self.event_bus.subscribe(event_type, self._on_workflow_event)

    async def _on_workflow_event(self, event: Event):
        # Update app state based on event
        if event.type == EventTypes.WORKFLOW_AGENT_SPAWNED:
            self.agents_data.append(event.data)
        elif event.type == EventTypes.WORKFLOW_TASK_GRAPH_CREATED:
            self.task_graph = event.data["task_graph"]
        # ...
```

---

## Benefits

### 1. Loose Coupling
- Components don't know about each other
- Easy to add/remove components
- No brittle direct dependencies

### 2. Debuggability
- All events flow through one place
- Event history for replay/debugging
- Bus viewer shows everything happening

### 3. Testability
- Mock the event bus for testing
- Verify components publish correct events
- Test handlers in isolation

### 4. Extensibility
- New components just subscribe to events
- No changes to existing code
- Easy to add new event types

### 5. Observability
- Complete audit trail of all events
- Filter/search event history
- Export events for analysis

---

## Publishing Guidelines

### 1. Always Use Event Catalog

```python
# ✅ Good - use EventTypes constant
await bus.publish(EventTypes.WORKFLOW_PHASE_CHANGE, data)

# ❌ Bad - magic string
await bus.publish("workflow_phase_change", data)
```

### 2. Include Source

```python
# ✅ Good - identify source
await bus.publish(EventTypes.WORKFLOW_ERROR, data, source="workflow_orchestrator")

# ❌ Bad - unknown source
await bus.publish(EventTypes.WORKFLOW_ERROR, data)
```

### 3. Follow Schema

```python
# ✅ Good - matches schema
await bus.publish(
    EventTypes.WORKFLOW_PHASE_CHANGE,
    {"phase": "planning", "progress": 0.25}
)

# ❌ Bad - missing required fields
await bus.publish(EventTypes.WORKFLOW_PHASE_CHANGE, {"phase": "planning"})
```

### 4. Don't Block

```python
# ✅ Good - async publish
await bus.publish(EventTypes.WORKFLOW_COMPLETE, data)

# ❌ Bad - if publish were sync, would block
bus.publish_sync(EventTypes.WORKFLOW_COMPLETE, data)  # doesn't exist
```

---

## Subscribing Guidelines

### 1. Subscribe on Mount, Unsubscribe on Unmount

```python
class MyWidget(Static):
    def on_mount(self):
        bus = self.app.event_bus
        bus.subscribe(EventTypes.WORKFLOW_PHASE_CHANGE, self._on_phase_change)

    def on_unmount(self):
        bus = self.app.event_bus
        bus.unsubscribe(EventTypes.WORKFLOW_PHASE_CHANGE, self._on_phase_change)
```

### 2. Handle Errors Gracefully

```python
async def _on_event(self, event: Event):
    try:
        # Handle event
        self.update_ui(event.data)
    except Exception as e:
        # Don't let handler errors crash the bus
        self.log.error(f"Error handling event: {e}")
```

### 3. Avoid Blocking Operations

```python
async def _on_event(self, event: Event):
    # ✅ Good - async operations
    await self.update_database(event.data)

    # ❌ Bad - blocking I/O
    time.sleep(5)  # Blocks event loop
```

---

## Testing

### Mock Event Bus

```python
class MockEventBus:
    def __init__(self):
        self.published_events = []

    async def publish(self, event_type, data, source="test"):
        self.published_events.append((event_type, data, source))

    def subscribe(self, event_type, handler):
        pass

# In test
app.event_bus = MockEventBus()

# Verify event was published
assert any(
    e[0] == EventTypes.WORKFLOW_PHASE_CHANGE
    for e in app.event_bus.published_events
)
```

### Test Handlers

```python
async def test_status_line_updates_on_phase_change():
    status_line = StatusLine()
    event = Event(
        EventTypes.WORKFLOW_PHASE_CHANGE,
        {"phase": "planning", "progress": 0.25}
    )

    await status_line._on_phase_change(event)

    assert "Planning" in status_line.render()
```

---

## Future Enhancements

1. **Event Replay** - Replay events for debugging
2. **Event Filtering** - Filter bus viewer by type/source
3. **Event Recording** - Record/export events to file
4. **Event Metrics** - Track event frequency, latency
5. **Remote Events** - Publish events to remote observers

---

## References

- `tui/ctrlcode_tui/event_bus.py` - EventBus implementation
- `docs/active-plans/simplified-tui-redesign.md` - TUI architecture
