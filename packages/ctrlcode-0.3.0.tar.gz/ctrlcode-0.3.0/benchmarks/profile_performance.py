"""Performance profiling for embedding and graph building operations."""

import time
from pathlib import Path

import numpy as np

from ctrlcode.analysis.code_graphs import CodeGraphBuilder
from ctrlcode.embeddings.embedder import CodeEmbedder
from ctrlcode.embeddings.vector_store import VectorStore
from ctrlcode.storage.history_db import HistoryDB


def profile_embedding():
    """Profile code embedding performance."""
    print("\n" + "=" * 60)
    print("EMBEDDING PERFORMANCE")
    print("=" * 60)

    embedder = CodeEmbedder()

    # Test cases of varying sizes
    test_cases = {
        "small (10 LOC)": "def add(a, b):\n    return a + b\n" * 5,
        "medium (50 LOC)": "def process(data):\n    result = []\n    for item in data:\n        result.append(item * 2)\n    return result\n"
        * 10,
        "large (200 LOC)": """
class DataProcessor:
    def __init__(self, config):
        self.config = config

    def process(self, data):
        cleaned = self._clean(data)
        transformed = self._transform(cleaned)
        return self._validate(transformed)

    def _clean(self, data):
        return [x for x in data if x]

    def _transform(self, data):
        return [x * 2 for x in data]

    def _validate(self, data):
        return all(x > 0 for x in data)
"""
        * 8,
    }

    results = {}
    for name, code in test_cases.items():
        # Warmup
        embedder.embed_code(code)

        # Measure
        start = time.perf_counter()
        for _ in range(5):
            embedding = embedder.embed_code(code)
        elapsed = (time.perf_counter() - start) / 5

        results[name] = {
            "time_ms": elapsed * 1000,
            "code_size": len(code),
            "embedding_dim": embedding.shape[0],
        }

        print(f"\n{name}:")
        print(f"  Code size: {len(code)} chars")
        print(f"  Time: {elapsed * 1000:.2f} ms")
        print(f"  Throughput: {len(code) / elapsed:.0f} chars/sec")

    # Batch embedding
    print("\nBatch embedding (10 items):")
    codes = [test_cases["small (10 LOC)"] for _ in range(10)]
    start = time.perf_counter()
    embeddings = embedder.embed_batch(codes)
    elapsed = time.perf_counter() - start

    print(f"  Total time: {elapsed * 1000:.2f} ms")
    print(f"  Time per item: {elapsed * 1000 / 10:.2f} ms")
    print(f"  Speedup vs individual: {results['small (10 LOC)']['time_ms'] / (elapsed * 1000 / 10):.2f}x")

    return results


def profile_graph_building():
    """Profile graph building performance."""
    print("\n" + "=" * 60)
    print("GRAPH BUILDING PERFORMANCE")
    print("=" * 60)

    builder = CodeGraphBuilder()

    # Test cases
    test_cases = {
        "simple (3 functions)": """
def foo():
    bar()

def bar():
    baz()

def baz():
    pass
""",
        "medium (10 functions, 2 classes)": """
class ServiceA:
    def __init__(self):
        pass

    def method1(self):
        self.method2()

    def method2(self):
        helper1()

class ServiceB:
    def process(self):
        ServiceA().method1()

def helper1():
    helper2()

def helper2():
    pass

def main():
    ServiceB().process()
    helper1()
""",
        "complex (50+ functions)": """
class DataPipeline:
    def __init__(self, config):
        self.config = config

    def run(self):
        data = self.extract()
        cleaned = self.clean(data)
        transformed = self.transform(cleaned)
        self.load(transformed)

    def extract(self):
        return self._fetch_data()

    def clean(self, data):
        return [self._clean_item(x) for x in data]

    def transform(self, data):
        return [self._transform_item(x) for x in data]

    def load(self, data):
        self._save_data(data)

    def _fetch_data(self):
        pass

    def _clean_item(self, item):
        return item

    def _transform_item(self, item):
        return item * 2

    def _save_data(self, data):
        pass

"""
        * 5,  # Repeat to create more functions
    }

    results = {}
    for name, code in test_cases.items():
        # Warmup
        builder.build_from_code(code, "test.py")

        # Measure
        start = time.perf_counter()
        for _ in range(5):
            graphs = builder.build_from_code(code, "test.py")
        elapsed = (time.perf_counter() - start) / 5

        results[name] = {
            "time_ms": elapsed * 1000,
            "function_count": graphs.function_count,
            "class_count": graphs.class_count,
            "call_edges": graphs.call_graph.number_of_edges(),
        }

        print(f"\n{name}:")
        print(f"  Functions: {graphs.function_count}")
        print(f"  Classes: {graphs.class_count}")
        print(f"  Call graph edges: {graphs.call_graph.number_of_edges()}")
        print(f"  Time: {elapsed * 1000:.2f} ms")

    return results


def profile_vector_search():
    """Profile vector store search performance."""
    print("\n" + "=" * 60)
    print("VECTOR SEARCH PERFORMANCE")
    print("=" * 60)

    embedder = CodeEmbedder()
    dim = embedder.embedding_dim

    # Test with different dataset sizes
    sizes = [100, 1000, 10000]

    results = {}
    for size in sizes:
        print(f"\nDataset size: {size} embeddings")

        # Create vector store
        store = VectorStore(dimension=dim, index_type="hnsw")

        # Generate random embeddings
        embeddings = np.random.randn(size, dim).astype(np.float32)
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
        ids = [f"item_{i}" for i in range(size)]

        # Measure indexing time
        start = time.perf_counter()
        store.add(embeddings, ids)
        index_time = time.perf_counter() - start

        print(f"  Indexing time: {index_time * 1000:.2f} ms")

        # Measure search time
        query = embeddings[0]
        start = time.perf_counter()
        for _ in range(100):
            results_list = store.search(query, k=10)
        search_time = (time.perf_counter() - start) / 100

        print(f"  Search time (k=10): {search_time * 1000:.3f} ms")
        print(f"  Throughput: {1 / search_time:.0f} searches/sec")

        results[size] = {
            "index_time_ms": index_time * 1000,
            "search_time_ms": search_time * 1000,
            "throughput": 1 / search_time,
        }

    return results


def profile_history_db():
    """Profile history database operations."""
    print("\n" + "=" * 60)
    print("HISTORY DB PERFORMANCE")
    print("=" * 60)

    db = HistoryDB(":memory:")
    embedder = CodeEmbedder()

    # Measure session storage
    print("\nSession storage:")
    from ctrlcode.storage.history_db import FuzzingSession
    from datetime import datetime

    start = time.perf_counter()
    for i in range(100):
        session = FuzzingSession(
            session_id=f"session_{i}",
            user_request="test request",
            generated_code="test code",
            oracle="test oracle",
            timestamp=datetime.now(),
            num_tests=10,
            num_failures=1,
            oracle_reused=False,
            quality_score=0.9,
        )
        db.store_session(session)
    elapsed = time.perf_counter() - start

    print(f"  100 sessions: {elapsed * 1000:.2f} ms")
    print(f"  Per session: {elapsed * 10:.2f} ms")

    # Measure code embedding storage
    print("\nCode + embedding storage:")
    from ctrlcode.storage.history_db import CodeRecord

    start = time.perf_counter()
    for i in range(100):
        embedding = embedder.embed_code(f"code_{i}")
        record = CodeRecord(
            code_id=f"code_{i}",
            session_id=f"session_{i}",
            code=f"code_{i}",
            embedding=embedding,
            timestamp=datetime.now(),
        )
        db.store_code(record)
    elapsed = time.perf_counter() - start

    print(f"  100 records: {elapsed * 1000:.2f} ms")
    print(f"  Per record: {elapsed * 10:.2f} ms")

    # Measure retrieval
    print("\nRetrieval:")
    start = time.perf_counter()
    for _ in range(100):
        codes = db.get_all_code_embeddings(limit=10)
    elapsed = time.perf_counter() - start

    print(f"  100 queries (10 records each): {elapsed * 1000:.2f} ms")
    print(f"  Per query: {elapsed * 10:.2f} ms")

    return {}


def main():
    """Run all profiling benchmarks."""
    print("\n" + "=" * 60)
    print("CTRL+CODE HISTORICAL LEARNING PERFORMANCE PROFILING")
    print("=" * 60)

    embedding_results = profile_embedding()
    graph_results = profile_graph_building()
    search_results = profile_vector_search()
    db_results = profile_history_db()

    # Summary
    print("\n" + "=" * 60)
    print("PERFORMANCE SUMMARY")
    print("=" * 60)

    print("\n📊 Key Metrics:")
    print(f"  Code embedding (small): {embedding_results['small (10 LOC)']['time_ms']:.1f} ms")
    print(f"  Graph building (simple): {graph_results['simple (3 functions)']['time_ms']:.1f} ms")
    print(f"  Vector search (1K dataset): {search_results[1000]['search_time_ms']:.2f} ms")

    print("\n✅ Performance Targets:")
    print(f"  Embedding < 50ms: {'✓' if embedding_results['small (10 LOC)']['time_ms'] < 50 else '✗'}")
    print(f"  Graph building < 100ms: {'✓' if graph_results['simple (3 functions)']['time_ms'] < 100 else '✗'}")
    print(f"  Search < 10ms (1K): {'✓' if search_results[1000]['search_time_ms'] < 10 else '✗'}")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
