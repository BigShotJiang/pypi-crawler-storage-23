"""Tests for browser automation tools."""

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch
from ctrlcode.tools.browser import BrowserTools


@pytest.fixture
def browser_tools():
    """Create BrowserTools instance."""
    return BrowserTools()


@pytest.fixture
def mock_playwright():
    """Mock playwright API."""
    with patch("playwright.async_api.async_playwright") as mock_pw:
        # Create mock hierarchy
        playwright_mock = AsyncMock()
        browser_mock = AsyncMock()
        context_mock = AsyncMock()
        page_mock = AsyncMock()

        # Setup mock chain
        mock_pw.return_value = AsyncMock()
        mock_pw.return_value.start = AsyncMock(return_value=playwright_mock)
        playwright_mock.chromium.launch = AsyncMock(return_value=browser_mock)
        browser_mock.new_context = AsyncMock(return_value=context_mock)
        context_mock.new_page = AsyncMock(return_value=page_mock)

        # Configure page mock
        page_mock.goto = AsyncMock()
        page_mock.screenshot = AsyncMock()
        page_mock.content = AsyncMock(return_value="<html><body>Test</body></html>")
        page_mock.evaluate = AsyncMock(return_value={"width": 1280, "height": 800})
        page_mock.query_selector = AsyncMock(return_value=Mock())
        page_mock.wait_for_selector = AsyncMock()

        # Store mocks for assertions
        playwright_mock._browser = browser_mock
        playwright_mock._context = context_mock
        playwright_mock._page = page_mock

        yield playwright_mock


@pytest.mark.asyncio
async def test_screenshot_basic(browser_tools, mock_playwright, tmp_path):
    """Test basic screenshot capture."""
    output_path = tmp_path / "test.png"

    result = await browser_tools.screenshot(
        url="http://localhost:8000", output=str(output_path)
    )

    assert result["success"] is True
    assert result["url"] == "http://localhost:8000"
    assert result["file_path"] == str(output_path)
    assert "width" in result
    assert "height" in result

    # Verify playwright calls
    page = mock_playwright._page
    page.goto.assert_called_once()
    page.screenshot.assert_called_once()


@pytest.mark.asyncio
async def test_screenshot_full_page(browser_tools, mock_playwright, tmp_path):
    """Test full page screenshot."""
    output_path = tmp_path / "fullpage.png"

    result = await browser_tools.screenshot(
        url="http://localhost:8000", output=str(output_path), full_page=True
    )

    assert result["success"] is True

    # Verify screenshot was called with full_page=True
    page = mock_playwright._page
    page.screenshot.assert_called_once()
    call_args = page.screenshot.call_args
    assert call_args[1]["full_page"] is True


@pytest.mark.asyncio
async def test_screenshot_viewport_only(browser_tools, mock_playwright, tmp_path):
    """Test viewport-only screenshot."""
    output_path = tmp_path / "viewport.png"

    result = await browser_tools.screenshot(
        url="http://localhost:8000",
        output=str(output_path),
        full_page=False,
        viewport_width=1920,
        viewport_height=1080,
    )

    assert result["success"] is True
    assert result["width"] == 1920
    assert result["height"] == 1080

    # Verify context was created with correct viewport
    browser = mock_playwright._browser
    browser.new_context.assert_called_once()
    call_args = browser.new_context.call_args
    assert call_args[1]["viewport"]["width"] == 1920
    assert call_args[1]["viewport"]["height"] == 1080


@pytest.mark.asyncio
async def test_screenshot_wait_for_selector(browser_tools, mock_playwright, tmp_path):
    """Test screenshot with wait_for selector."""
    output_path = tmp_path / "wait.png"

    result = await browser_tools.screenshot(
        url="http://localhost:8000",
        output=str(output_path),
        wait_for=".content-loaded",
    )

    assert result["success"] is True

    # Verify wait_for_selector was called
    page = mock_playwright._page
    page.wait_for_selector.assert_called_once_with(".content-loaded", timeout=30000)


@pytest.mark.asyncio
async def test_screenshot_default_output(browser_tools, mock_playwright):
    """Test screenshot with default output path."""
    result = await browser_tools.screenshot(url="http://localhost:8000")

    assert result["success"] is True
    assert "file_path" in result
    assert Path(result["file_path"]).suffix == ".png"


@pytest.mark.asyncio
async def test_screenshot_error_handling(browser_tools, mock_playwright):
    """Test screenshot error handling."""
    # Make goto raise an exception
    mock_playwright._page.goto.side_effect = Exception("Navigation failed")

    result = await browser_tools.screenshot(url="http://localhost:8000")

    assert result["success"] is False
    assert "error" in result
    assert "Navigation failed" in result["error"]
    assert result["url"] == "http://localhost:8000"


@pytest.mark.asyncio
async def test_dom_snapshot_basic(browser_tools, mock_playwright):
    """Test basic DOM snapshot."""
    # Configure page mock to return data
    mock_playwright._page.content.return_value = "<html><body><h1>Test</h1></body></html>"
    mock_playwright._page.evaluate.side_effect = [
        "Test",  # text_content
        50,  # element_count
        [{"text": "Link1", "href": "http://test.com", "target": ""}],  # links
        [
            {
                "action": "http://test.com/login",
                "method": "post",
                "fields": [{"name": "email", "type": "email", "id": "email"}],
            }
        ],  # forms
    ]

    result = await browser_tools.dom_snapshot(url="http://localhost:8000")

    assert result["success"] is True
    assert result["url"] == "http://localhost:8000"
    assert "<html>" in result["html"]
    assert result["text_content"] == "Test"
    assert result["element_count"] == 50
    assert len(result["links"]) == 1
    assert len(result["forms"]) == 1


@pytest.mark.asyncio
async def test_dom_snapshot_with_selector(browser_tools, mock_playwright):
    """Test DOM snapshot with CSS selector."""
    element_mock = AsyncMock()
    element_mock.inner_html.return_value = "<div>Content</div>"
    element_mock.text_content.return_value = "Content"
    mock_playwright._page.query_selector.return_value = element_mock

    # Configure evaluate for metadata
    mock_playwright._page.evaluate.side_effect = [
        10,  # element_count
        [],  # links
        [],  # forms
    ]

    result = await browser_tools.dom_snapshot(
        url="http://localhost:8000", selector=".main-content"
    )

    assert result["success"] is True
    assert result["html"] == "<div>Content</div>"
    assert result["text_content"] == "Content"

    # Verify selector was queried
    mock_playwright._page.query_selector.assert_called_once_with(".main-content")


@pytest.mark.asyncio
async def test_dom_snapshot_selector_not_found(browser_tools, mock_playwright):
    """Test DOM snapshot when selector doesn't exist."""
    mock_playwright._page.query_selector.return_value = None

    result = await browser_tools.dom_snapshot(
        url="http://localhost:8000", selector=".nonexistent"
    )

    assert result["success"] is False
    assert "error" in result
    assert "not found" in result["error"]


@pytest.mark.asyncio
async def test_dom_snapshot_error_handling(browser_tools, mock_playwright):
    """Test DOM snapshot error handling."""
    mock_playwright._page.goto.side_effect = Exception("Page load failed")

    result = await browser_tools.dom_snapshot(url="http://localhost:8000")

    assert result["success"] is False
    assert "error" in result
    assert "Page load failed" in result["error"]


@pytest.mark.asyncio
async def test_browser_cleanup(browser_tools, mock_playwright):
    """Test browser cleanup."""
    # Trigger browser launch
    await browser_tools.screenshot(url="http://localhost:8000")

    # Cleanup
    await browser_tools.close()

    # Verify browser was closed
    mock_playwright._browser.close.assert_called_once()
    mock_playwright.stop.assert_called_once()


@pytest.mark.asyncio
async def test_singleton_browser_reuse(browser_tools, mock_playwright):
    """Test that browser is reused across multiple calls."""
    # Make two screenshots
    await browser_tools.screenshot(url="http://localhost:8000/page1")
    await browser_tools.screenshot(url="http://localhost:8000/page2")

    # Browser should only be launched once
    assert mock_playwright.chromium.launch.call_count == 1


@pytest.mark.asyncio
async def test_screenshot_custom_timeout(browser_tools, mock_playwright, tmp_path):
    """Test screenshot with custom timeout."""
    output_path = tmp_path / "timeout.png"

    await browser_tools.screenshot(
        url="http://localhost:8000", output=str(output_path), timeout=60000
    )

    # Verify timeout was passed to goto
    page = mock_playwright._page
    call_args = page.goto.call_args
    assert call_args[1]["timeout"] == 60000


@pytest.mark.asyncio
async def test_dom_snapshot_extracts_links(browser_tools, mock_playwright):
    """Test DOM snapshot extracts link information."""
    mock_playwright._page.evaluate.side_effect = [
        "Content",  # text_content
        25,  # element_count
        [
            {"text": "Home", "href": "http://localhost:8000/", "target": ""},
            {"text": "About", "href": "http://localhost:8000/about", "target": "_blank"},
        ],  # links
        [],  # forms
    ]

    result = await browser_tools.dom_snapshot(url="http://localhost:8000")

    assert result["success"] is True
    assert len(result["links"]) == 2
    assert result["links"][0]["text"] == "Home"
    assert result["links"][1]["target"] == "_blank"


@pytest.mark.asyncio
async def test_dom_snapshot_extracts_forms(browser_tools, mock_playwright):
    """Test DOM snapshot extracts form information."""
    mock_playwright._page.evaluate.side_effect = [
        "Content",  # text_content
        30,  # element_count
        [],  # links
        [
            {
                "action": "http://localhost:8000/api/login",
                "method": "post",
                "fields": [
                    {"name": "email", "type": "email", "id": "email-input"},
                    {"name": "password", "type": "password", "id": "password-input"},
                ],
            }
        ],  # forms
    ]

    result = await browser_tools.dom_snapshot(url="http://localhost:8000")

    assert result["success"] is True
    assert len(result["forms"]) == 1
    form = result["forms"][0]
    assert form["action"] == "http://localhost:8000/api/login"
    assert form["method"] == "post"
    assert len(form["fields"]) == 2
    assert form["fields"][0]["name"] == "email"
    assert form["fields"][1]["type"] == "password"
