"""Mock provider for deterministic testing."""

from typing import Any, AsyncIterator

from ctrlcode.providers.base import Provider, StreamEvent


class MockProvider(Provider):
    """Mock provider with scripted responses."""

    def __init__(self, responses: list[dict[str, Any]] | None = None):
        """
        Initialize mock provider.

        Args:
            responses: List of scripted response dicts, each containing:
                - events: list of event dicts with 'type' and 'data' keys
        """
        self.responses = responses or []
        self.call_count = 0
        self.model = "mock-model-1.0"
        self.call_history: list[dict[str, Any]] = []

    async def stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs
    ) -> AsyncIterator[StreamEvent]:
        """
        Yield pre-scripted events.

        Args:
            messages: Conversation messages
            tools: Tool definitions
            **kwargs: Additional parameters

        Yields:
            StreamEvent instances from scripted response
        """
        # Record call for test assertions
        self.call_history.append({
            "messages": messages,
            "tools": tools,
            "kwargs": kwargs
        })

        # Return scripted response if available
        if self.call_count < len(self.responses):
            response = self.responses[self.call_count]
            self.call_count += 1

            for event_data in response.get("events", []):
                yield StreamEvent(
                    type=event_data["type"],
                    data=event_data.get("data", {})
                )
        else:
            # Default fallback response
            yield StreamEvent(type="text", data={"text": "Mock response"})
            yield StreamEvent(type="finish", data={"reason": "end_turn"})
            yield StreamEvent(
                type="usage",
                data={"usage": {"completion_tokens": 10, "prompt_tokens": 20}}
            )

    async def generate(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs
    ) -> dict[str, Any]:
        """
        Generate a non-streaming response (mock implementation).

        Args:
            messages: Conversation messages
            tools: Tool definitions
            **kwargs: Additional parameters

        Returns:
            Mock response dict
        """
        return {
            "text": "Mock response",
            "usage": {"completion_tokens": 10, "prompt_tokens": 20}
        }

    def normalize_tool_call(self, raw: dict[str, Any]) -> dict[str, Any]:
        """
        Normalize tool call format (mock implementation).

        Args:
            raw: Raw tool call data

        Returns:
            Normalized tool call dict
        """
        return raw

    def reset(self):
        """Reset call counter and history."""
        self.call_count = 0
        self.call_history.clear()


def create_text_response(text: str, tokens: int = 10) -> dict[str, Any]:
    """
    Create a simple text-only response.

    Args:
        text: Response text
        tokens: Token count

    Returns:
        Response dict for MockProvider
    """
    return {
        "events": [
            {"type": "text", "data": {"text": text}},
            {"type": "finish", "data": {"reason": "end_turn"}},
            {"type": "usage", "data": {"usage": {"completion_tokens": tokens}}}
        ]
    }


def create_tool_call_response(
    tool_name: str,
    tool_input: dict[str, Any],
    call_id: str = "call-123",
    tokens: int = 20
) -> dict[str, Any]:
    """
    Create a tool call response.

    Args:
        tool_name: Name of tool to call
        tool_input: Tool input parameters
        call_id: Tool call identifier
        tokens: Token count

    Returns:
        Response dict for MockProvider
    """
    import json

    return {
        "events": [
            {"type": "tool_call_start", "data": {"tool": tool_name, "call_id": call_id}},
            {"type": "tool_call_delta", "data": {"delta": json.dumps(tool_input)}},
            {"type": "content_block_stop", "data": {}},
            {"type": "finish", "data": {"reason": "tool_use"}},
            {"type": "usage", "data": {"usage": {"completion_tokens": tokens}}}
        ]
    }


def create_planner_response(task_graph: dict[str, Any], tokens: int = 50) -> dict[str, Any]:
    """
    Create a planner agent response with task graph.

    Args:
        task_graph: Task graph dictionary
        tokens: Token count

    Returns:
        Response dict for MockProvider
    """
    import json

    task_graph_json = json.dumps(task_graph)

    return {
        "events": [
            {"type": "text", "data": {"text": "Creating task breakdown...\n"}},
            {"type": "tool_call_start", "data": {"tool": "task_write", "call_id": "plan-1"}},
            {"type": "tool_call_delta", "data": {"delta": task_graph_json}},
            {"type": "content_block_stop", "data": {}},
            {"type": "finish", "data": {"reason": "tool_use"}},
            {"type": "usage", "data": {"usage": {"completion_tokens": tokens}}}
        ]
    }
