"""Tests for CodeEmbedder."""

import numpy as np
import pytest

from ctrlcode.embeddings.embedder import CodeEmbedder


@pytest.fixture
def embedder():
    """Create embedder instance."""
    return CodeEmbedder(api_key="test-key", base_url="http://test/v1")


def test_embedder_initialization():
    """Test embedder initializes correctly."""
    embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
    assert embedder.model_name == "text-embedding-3-small"
    assert embedder.backend == "api"
    assert embedder.normalize is True
    assert embedder.api_key == "test-key"
    assert embedder.base_url == "http://test/v1"


def test_embedding_dimension(embedder):
    """Test embedding dimension is correct."""
    dim = embedder.embedding_dim
    assert dim == 1536  # text-embedding-3-small dimension


def test_embed_code(embedder):
    """Test embedding code produces correct shape and type."""
    code = "def add(a, b): return a + b"
    embedding = embedder.embed_code(code)

    assert isinstance(embedding, np.ndarray)
    assert embedding.shape == (1536,)
    assert embedding.dtype == np.float32


def test_embed_oracle(embedder):
    """Test embedding oracle text."""
    oracle = "Function must return sum of two numbers"
    embedding = embedder.embed_oracle(oracle)

    assert isinstance(embedding, np.ndarray)
    assert embedding.shape == (1536,)


def test_embed_test_case(embedder):
    """Test embedding test case code."""
    test = "assert add(2, 3) == 5"
    embedding = embedder.embed_test_case(test)

    assert isinstance(embedding, np.ndarray)
    assert embedding.shape == (1536,)


def test_embed_bug_pattern(embedder):
    """Test embedding bug description."""
    bug = "Division by zero error when denominator is 0"
    embedding = embedder.embed_bug_pattern(bug)

    assert isinstance(embedding, np.ndarray)
    assert embedding.shape == (1536,)


def test_embed_batch(embedder):
    """Test batch embedding."""
    texts = [
        "def add(a, b): return a + b",
        "def multiply(x, y): return x * y",
        "def subtract(a, b): return a - b",
    ]

    embeddings = embedder.embed_batch(texts)

    assert isinstance(embeddings, np.ndarray)
    assert embeddings.shape == (3, 1536)
    assert embeddings.dtype == np.float32


def test_embed_batch_empty(embedder):
    """Test batch embedding with empty list."""
    embeddings = embedder.embed_batch([])
    assert isinstance(embeddings, np.ndarray)
    assert embeddings.shape == (0,)


def test_cosine_similarity(embedder):
    """Test cosine similarity returns valid float in [-1, 1]."""
    code1 = "def add(a, b): return a + b"
    code2 = "def sum(x, y): return x + y"
    code3 = "def multiply(a, b): return a * b"

    emb1 = embedder.embed_code(code1)
    emb2 = embedder.embed_code(code2)
    emb3 = embedder.embed_code(code3)

    sim_add_sum = embedder.cosine_similarity(emb1, emb2)
    sim_add_mul = embedder.cosine_similarity(emb1, emb3)

    assert -1.0 <= sim_add_sum <= 1.0
    assert -1.0 <= sim_add_mul <= 1.0


def test_embeddings_normalized(embedder):
    """Test that embeddings are L2-normalized."""
    code = "def test(): pass"
    embedding = embedder.embed_code(code)

    norm = np.linalg.norm(embedding)
    assert np.isclose(norm, 1.0, atol=1e-5)


def test_identical_code_identical_embeddings(embedder):
    """Test identical code produces identical embeddings."""
    code = "def foo(): return 42"

    emb1 = embedder.embed_code(code)
    emb2 = embedder.embed_code(code)

    assert np.allclose(emb1, emb2)
    similarity = embedder.cosine_similarity(emb1, emb2)
    assert np.isclose(similarity, 1.0)
