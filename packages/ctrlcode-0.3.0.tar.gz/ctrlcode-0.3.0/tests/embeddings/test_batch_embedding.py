"""Tests for batch embedding efficiency."""

import time

import numpy as np
import pytest

from ctrlcode.embeddings.embedder import CodeEmbedder


class TestBatchEmbedding:
    """Test batch embedding functionality."""

    def test_batch_empty(self):
        """Test batch embedding with empty list."""
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        result = embedder.embed_batch([])
        assert len(result) == 0

    def test_batch_single(self):
        """Test batch embedding with single item."""
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        texts = ["def test(): pass"]
        result = embedder.embed_batch(texts)

        assert result.shape == (1, 1536)  # 1 text, 1536 dimensions
        assert np.allclose(np.linalg.norm(result[0]), 1.0, atol=1e-6)  # Normalized

    def test_batch_multiple(self):
        """Test batch embedding with multiple items."""
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        texts = [
            "def add(a, b): return a + b",
            "def subtract(x, y): return x - y",
            "def multiply(m, n): return m * n",
        ]

        result = embedder.embed_batch(texts)

        assert result.shape == (3, 1536)  # 3 texts, 1536 dimensions
        for i in range(3):
            assert np.allclose(np.linalg.norm(result[i]), 1.0, atol=1e-6)  # All normalized

    def test_batch_vs_single_consistency(self):
        """Test that batch embedding produces same results as individual embedding."""
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        texts = [
            "def func1(): return 1",
            "def func2(): return 2",
            "def func3(): return 3",
        ]

        # Batch embedding
        batch_embeddings = embedder.embed_batch(texts)

        # Individual embeddings
        individual_embeddings = [embedder.embed_code(text) for text in texts]

        # Should produce same results
        for i, (batch_emb, indiv_emb) in enumerate(
            zip(batch_embeddings, individual_embeddings)
        ):
            assert np.allclose(batch_emb, indiv_emb, atol=1e-5), f"Mismatch at index {i}"

    def test_batch_performance(self):
        """Test that batch embedding is faster than individual embeddings."""
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # Create 20 test texts
        texts = [f"def function_{i}(x): return x + {i}" for i in range(20)]

        # Time individual embeddings
        start = time.perf_counter()
        for text in texts:
            embedder.embed_code(text)
        individual_time = time.perf_counter() - start

        # Time batch embedding
        start = time.perf_counter()
        embedder.embed_batch(texts)
        batch_time = time.perf_counter() - start

        # Batch should be faster
        speedup = individual_time / batch_time if batch_time > 0 else 0

        print(f"\nBatch embedding performance:")
        print(f"  Individual: {individual_time*1000:.2f} ms")
        print(f"  Batch:      {batch_time*1000:.2f} ms")
        print(f"  Speedup:    {speedup:.2f}x")

        # Informational only — speedup depends on real API latency, not measurable with mocks
        print(f"  Speedup:    {speedup:.2f}x (informational)")

    def test_batch_large_dataset(self):
        """Test batch embedding with larger dataset."""
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

        # Create 100 test texts
        texts = [f"def function_{i}(): return {i}" for i in range(100)]

        # Batch embed
        start = time.perf_counter()
        embeddings = embedder.embed_batch(texts)
        elapsed = time.perf_counter() - start

        assert embeddings.shape == (100, 1536)
        print(f"\nBatch embedding 100 texts: {elapsed*1000:.2f} ms")

        # Should complete in reasonable time (< 5 seconds)
        assert elapsed < 5.0, f"Batch embedding too slow: {elapsed:.2f}s"

    def test_batch_different_lengths(self):
        """Test batch embedding with texts of different lengths."""
        embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")
        texts = [
            "x",  # Very short
            "def short(): return 1",  # Short
            "def medium_function(a, b, c):\n    result = a + b + c\n    return result",  # Medium
            "def long_function(x, y, z):\n    # This is a longer function\n    temp1 = x + y\n    temp2 = temp1 * z\n    result = temp2 / 2\n    return result",  # Long
        ]

        result = embedder.embed_batch(texts)

        assert result.shape == (4, 1536)
        for i in range(4):
            assert np.allclose(np.linalg.norm(result[i]), 1.0, atol=1e-6)
