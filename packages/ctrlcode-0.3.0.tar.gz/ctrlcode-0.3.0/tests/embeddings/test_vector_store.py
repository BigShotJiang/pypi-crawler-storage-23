"""Tests for VectorStore."""

import tempfile
from pathlib import Path

import numpy as np
import pytest

from ctrlcode.embeddings.vector_store import VectorStore


@pytest.fixture
def vector_store():
    """Create vector store instance."""
    return VectorStore(dimension=384, index_type="hnsw")


@pytest.fixture
def sample_embeddings():
    """Create sample normalized embeddings."""
    rng = np.random.RandomState(42)
    embeddings = rng.randn(10, 384).astype(np.float32)
    # Normalize
    embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    return embeddings


def test_vector_store_initialization():
    """Test vector store initializes correctly."""
    store = VectorStore(dimension=384, index_type="hnsw")
    assert store.dimension == 384
    assert store.index_type == "hnsw"
    assert store.size == 0


def test_add_single_embedding(vector_store):
    """Test adding single embedding."""
    embedding = np.random.randn(384).astype(np.float32)
    vector_store.add(embedding, ids=["test_1"])

    assert vector_store.size == 1
    assert "test_1" in vector_store.id_map


def test_add_batch_embeddings(vector_store, sample_embeddings):
    """Test adding batch of embeddings."""
    ids = [f"emb_{i}" for i in range(len(sample_embeddings))]
    vector_store.add(sample_embeddings, ids=ids)

    assert vector_store.size == 10
    assert all(id in vector_store.id_map for id in ids)


def test_search_single(vector_store, sample_embeddings):
    """Test searching for similar embeddings."""
    ids = [f"emb_{i}" for i in range(len(sample_embeddings))]
    vector_store.add(sample_embeddings, ids=ids)

    # Search with first embedding
    query = sample_embeddings[0]
    results = vector_store.search(query, k=3)

    assert len(results) == 3
    assert results[0][0] == "emb_0"  # First result should be itself
    assert results[0][1] >= 0.99  # Very high similarity (self-match)


def test_search_with_min_similarity(vector_store, sample_embeddings):
    """Test search with similarity threshold."""
    ids = [f"emb_{i}" for i in range(len(sample_embeddings))]
    vector_store.add(sample_embeddings, ids=ids)

    query = sample_embeddings[0]
    results = vector_store.search(query, k=10, min_similarity=0.99)

    # Only very similar results (likely just self-match)
    assert len(results) >= 1
    assert all(sim >= 0.99 for _, sim in results)


def test_search_empty_store():
    """Test search on empty store."""
    store = VectorStore(dimension=384)
    query = np.random.randn(384).astype(np.float32)
    results = store.search(query, k=5)

    assert results == []


def test_search_k_larger_than_size(vector_store, sample_embeddings):
    """Test search when k > number of embeddings."""
    ids = [f"emb_{i}" for i in range(3)]
    vector_store.add(sample_embeddings[:3], ids=ids)

    query = sample_embeddings[0]
    results = vector_store.search(query, k=10)

    # Should return only 3 results
    assert len(results) == 3


def test_save_and_load(vector_store, sample_embeddings):
    """Test saving and loading vector store."""
    ids = [f"emb_{i}" for i in range(len(sample_embeddings))]
    vector_store.add(sample_embeddings, ids=ids)

    with tempfile.TemporaryDirectory() as tmpdir:
        save_path = Path(tmpdir) / "test_index"

        # Save
        vector_store.save(save_path)

        # Load into new store
        new_store = VectorStore(dimension=384, index_type="hnsw")
        new_store.load(save_path)

        # Verify
        assert new_store.size == 10
        assert new_store.id_map == ids

        # Search should work
        query = sample_embeddings[0]
        results = new_store.search(query, k=3)
        assert len(results) == 3
        assert results[0][0] == "emb_0"


def test_clear(vector_store, sample_embeddings):
    """Test clearing vector store."""
    ids = [f"emb_{i}" for i in range(len(sample_embeddings))]
    vector_store.add(sample_embeddings, ids=ids)

    assert vector_store.size == 10

    vector_store.clear()

    assert vector_store.size == 0
    assert vector_store.id_map == []


def test_dimension_mismatch_error(vector_store):
    """Test error when adding wrong dimension."""
    wrong_embedding = np.random.randn(128).astype(np.float32)  # Wrong dimension

    with pytest.raises(ValueError, match="Wrong dimension"):
        vector_store.add(wrong_embedding, ids=["test"])


def test_id_count_mismatch_error(vector_store, sample_embeddings):
    """Test error when ID count doesn't match embedding count."""
    with pytest.raises(ValueError, match="Mismatch"):
        vector_store.add(sample_embeddings, ids=["only_one_id"])


def test_flat_index():
    """Test flat (exact search) index."""
    store = VectorStore(dimension=384, index_type="flat")
    assert store.index_type == "flat"

    # Add and search
    embeddings = np.random.randn(5, 384).astype(np.float32)
    embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    ids = [f"flat_{i}" for i in range(5)]

    store.add(embeddings, ids=ids)
    results = store.search(embeddings[0], k=3)

    assert len(results) == 3
    assert results[0][0] == "flat_0"


def test_invalid_index_type():
    """Test error with invalid index type."""
    with pytest.raises(ValueError, match="Unknown index type"):
        VectorStore(dimension=384, index_type="invalid")
