"""Tests for ContextDerivationEngine with LRU cache."""

import pytest

from ctrlcode.embeddings.embedder import CodeEmbedder
from ctrlcode.fuzzing.context import (
    ContextDerivation,
    ContextDerivationEngine,
    ImplicitAssumption,
    IntegrationContract,
    LRUCache,
    SystemPlacement,
)
from ctrlcode.providers.base import Provider
from ctrlcode.storage.history_db import CodeRecord, HistoryDB, OracleRecord
from datetime import datetime


class MockProvider(Provider):
    """Mock LLM provider for testing."""

    def __init__(self, response_text: str = ""):
        self.response_text = response_text
        self.call_count = 0

    async def generate(self, messages: list[dict], **kwargs) -> dict:
        self.call_count += 1
        return {"text": self.response_text}

    async def stream(self, messages: list[dict], **kwargs):
        """Not used in context tests."""
        yield {"type": "text", "data": {"text": self.response_text}}

    def normalize_tool_call(self, tool_call: dict) -> dict:
        """Not used in context tests."""
        return tool_call


class TestLRUCache:
    """Test LRU cache implementation."""

    def test_cache_initialization(self):
        """Test cache initializes with correct defaults."""
        cache = LRUCache()
        assert cache.max_size == 100
        assert cache.size == 0
        assert cache.hits == 0
        assert cache.misses == 0
        assert cache.hit_rate == 0.0

    def test_cache_get_miss(self):
        """Test cache miss increments misses."""
        cache = LRUCache()
        result = cache.get("key1")
        assert result is None
        assert cache.misses == 1
        assert cache.hits == 0
        assert cache.hit_rate == 0.0

    def test_cache_put_and_get_hit(self):
        """Test cache hit increments hits."""
        cache = LRUCache()
        cache.put("key1", ("value1", "session1"))

        result = cache.get("key1")
        assert result == ("value1", "session1")
        assert cache.hits == 1
        assert cache.misses == 0
        assert cache.hit_rate == 1.0
        assert cache.size == 1

    def test_cache_lru_eviction(self):
        """Test LRU eviction when max size reached."""
        cache = LRUCache(max_size=3)

        # Add 3 items
        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.put("key3", "value3")
        assert cache.size == 3

        # Access key1 (makes it most recent)
        cache.get("key1")

        # Add 4th item (should evict key2, the least recent)
        cache.put("key4", "value4")
        assert cache.size == 3

        # key2 should be gone
        assert cache.get("key2") is None
        # key1 and key3 should still be present
        assert cache.get("key1") == "value1"
        assert cache.get("key3") == "value3"
        assert cache.get("key4") == "value4"

    def test_cache_update_existing(self):
        """Test updating existing key moves it to end."""
        cache = LRUCache(max_size=3)

        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.put("key3", "value3")

        # Update key1 (moves to end)
        cache.put("key1", "value1_updated")

        # Add 4th item (should evict key2)
        cache.put("key4", "value4")

        assert cache.get("key1") == "value1_updated"
        assert cache.get("key2") is None

    def test_cache_clear(self):
        """Test cache clear resets all state."""
        cache = LRUCache()

        cache.put("key1", "value1")
        cache.get("key1")
        cache.get("key2")  # miss

        assert cache.size == 1
        assert cache.hits == 1
        assert cache.misses == 1

        cache.clear()

        assert cache.size == 0
        assert cache.hits == 0
        assert cache.misses == 0
        assert cache.hit_rate == 0.0

    def test_cache_hit_rate_calculation(self):
        """Test hit rate calculation."""
        cache = LRUCache()

        cache.put("key1", "value1")

        cache.get("key1")  # hit
        cache.get("key1")  # hit
        cache.get("key2")  # miss
        cache.get("key1")  # hit

        # 3 hits, 1 miss = 75% hit rate
        assert cache.hits == 3
        assert cache.misses == 1
        assert cache.hit_rate == 0.75


@pytest.fixture
def populated_history_db():
    """Create in-memory database with sample historical data."""
    db = HistoryDB(":memory:")
    embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

    # Store sample code with embedding
    code = "def get_user(user_id): return fetch_from_db(user_id)"
    code_embedding = embedder.embed_code(code)

    code_record = CodeRecord(
        code_id="historical_code_1",
        session_id="historical_session_1",
        code=code,
        embedding=code_embedding,
        timestamp=datetime.now(),
    )
    db.store_code(code_record)

    # Store corresponding oracle
    oracle = ContextDerivation(
        system_placement=SystemPlacement(
            system_type="web service",
            layer="data access",
            callers="API handler",
            callees="database",
        ),
        environmental_constraints={"language": "Python", "async": False},
        integration_contracts=[
            IntegrationContract(
                system="Database",
                contract="Fetch user by ID",
                implicit_requirements=["Connection handling"],
            )
        ],
        behavioral_invariants=["Returns user object or None"],
        edge_case_surface=["User not found", "DB connection failure"],
        implicit_assumptions=[
            ImplicitAssumption(
                assumption="user_id is valid",
                risk="SAFE",
                explanation="Validated upstream",
            )
        ],
    )

    oracle_embedding = embedder.embed_oracle(oracle.to_json())
    oracle_record = OracleRecord(
        oracle_id="historical_oracle_1",
        session_id="historical_session_1",
        oracle=oracle.to_json(),
        embedding=oracle_embedding,
        quality_score=0.9,
        timestamp=datetime.now(),
    )
    db.store_oracle(oracle_record)

    return db


@pytest.mark.asyncio
async def test_oracle_cache_hit_avoids_search(populated_history_db):
    """Test that cache hit avoids expensive FAISS search."""
    provider = MockProvider()
    engine = ContextDerivationEngine(
        provider=provider,
        history_db=populated_history_db,
        cache_size=10,
    )

    # First call: cache miss, will search
    code = "def get_user(user_id): return fetch_from_db(user_id)"

    result1 = await engine._search_similar_oracle(
        engine.embedder.embed_code(code),
        code,
        "Get user from database",
    )

    # Check cache state
    assert engine.oracle_cache.misses == 1
    assert engine.oracle_cache.hits == 0

    # Second call with same code: cache hit, should skip FAISS search
    result2 = await engine._search_similar_oracle(
        engine.embedder.embed_code(code),
        code,
        "Get user from database",
    )

    # Cache should have a hit
    assert engine.oracle_cache.hits == 1
    assert engine.oracle_cache.misses == 1
    assert engine.oracle_cache.hit_rate == 0.5

    # Results should be identical
    assert result1 == result2


@pytest.mark.asyncio
async def test_oracle_cache_different_code_miss(populated_history_db):
    """Test that different code results in cache miss."""
    provider = MockProvider()
    engine = ContextDerivationEngine(
        provider=provider,
        history_db=populated_history_db,
        cache_size=10,
    )

    code1 = "def get_user(user_id): return fetch_from_db(user_id)"
    code2 = "def fetch_user(id): return db.query(id)"

    await engine._search_similar_oracle(
        engine.embedder.embed_code(code1),
        code1,
        "Get user",
    )

    await engine._search_similar_oracle(
        engine.embedder.embed_code(code2),
        code2,
        "Fetch user",
    )

    # Both should be cache misses
    assert engine.oracle_cache.misses == 2
    assert engine.oracle_cache.hits == 0
    assert engine.oracle_cache.size == 2


@pytest.mark.asyncio
async def test_oracle_cache_negative_results():
    """Test that negative results (no oracle found) are cached."""
    provider = MockProvider()
    empty_db = HistoryDB(":memory:")

    engine = ContextDerivationEngine(
        provider=provider,
        history_db=empty_db,
        cache_size=10,
    )

    code = "def some_function(): pass"

    # First call: miss, no results in DB
    result1 = await engine._search_similar_oracle(
        engine.embedder.embed_code(code),
        code,
        "Some function",
    )

    assert result1 == (None, None)
    assert engine.oracle_cache.misses == 1

    # Second call: should hit cache with negative result
    result2 = await engine._search_similar_oracle(
        engine.embedder.embed_code(code),
        code,
        "Some function",
    )

    assert result2 == (None, None)
    assert engine.oracle_cache.hits == 1
    assert engine.oracle_cache.size == 1


@pytest.mark.asyncio
async def test_oracle_cache_eviction():
    """Test cache evicts oldest entries when full."""
    provider = MockProvider()
    db = HistoryDB(":memory:")

    engine = ContextDerivationEngine(
        provider=provider,
        history_db=db,
        cache_size=2,  # Small cache for testing
    )

    codes = [
        "def func1(): pass",
        "def func2(): pass",
        "def func3(): pass",
    ]

    # Fill cache with 3 entries (should evict first)
    for code in codes:
        await engine._search_similar_oracle(
            engine.embedder.embed_code(code),
            code,
            "Request",
        )

    assert engine.oracle_cache.size == 2

    # Access first code again - should be cache miss (evicted)
    await engine._search_similar_oracle(
        engine.embedder.embed_code(codes[0]),
        codes[0],
        "Request",
    )

    # Should have 4 misses (3 initial + 1 re-access), 0 hits
    assert engine.oracle_cache.misses == 4
    assert engine.oracle_cache.hits == 0
