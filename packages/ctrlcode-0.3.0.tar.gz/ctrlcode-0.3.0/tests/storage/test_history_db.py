"""Tests for HistoryDB."""

from datetime import datetime

import numpy as np
import pytest

from ctrlcode.storage.history_db import (
    BugPattern,
    CodeRecord,
    FuzzingSession,
    HistoryDB,
    OracleRecord,
    StoredTest,
)


@pytest.fixture
def db():
    """Create in-memory database."""
    return HistoryDB(":memory:")


@pytest.fixture
def sample_session():
    """Create sample fuzzing session."""
    return FuzzingSession(
        session_id="test_session_1",
        user_request="Create a function to add two numbers",
        generated_code="def add(a, b): return a + b",
        oracle="Function must return sum of inputs",
        timestamp=datetime.now(),
        num_tests=5,
        num_failures=0,
        oracle_reused=False,
        quality_score=0.95,
    )


@pytest.fixture
def sample_embedding():
    """Create sample embedding."""
    return np.random.randn(384).astype(np.float32)


def test_db_initialization():
    """Test database initializes correctly."""
    db = HistoryDB(":memory:")
    assert db.conn is not None

    stats = db.get_stats()
    assert stats["total_sessions"] == 0


def test_store_and_retrieve_session(db, sample_session):
    """Test storing and retrieving session."""
    db.store_session(sample_session)

    retrieved = db.get_session(sample_session.session_id)
    assert retrieved is not None
    assert retrieved.session_id == sample_session.session_id
    assert retrieved.user_request == sample_session.user_request
    assert retrieved.num_tests == 5
    assert retrieved.quality_score == 0.95


def test_store_code_embedding(db, sample_embedding):
    """Test storing code with embedding."""
    record = CodeRecord(
        code_id="code_1",
        session_id="session_1",
        code="def foo(): pass",
        embedding=sample_embedding,
        timestamp=datetime.now(),
    )

    db.store_code(record)

    # Retrieve
    codes = db.get_all_code_embeddings(limit=10)
    assert len(codes) == 1
    assert codes[0].code_id == "code_1"
    assert codes[0].code == "def foo(): pass"
    assert np.array_equal(codes[0].embedding, sample_embedding)


def test_store_oracle_embedding(db, sample_embedding):
    """Test storing oracle with embedding."""
    record = OracleRecord(
        oracle_id="oracle_1",
        session_id="session_1",
        oracle="Function must validate input",
        embedding=sample_embedding,
        quality_score=0.9,
        timestamp=datetime.now(),
    )

    db.store_oracle(record)

    # Retrieve
    oracles = db.get_all_oracle_embeddings(limit=10)
    assert len(oracles) == 1
    assert oracles[0].oracle_id == "oracle_1"
    assert oracles[0].quality_score == 0.9


def test_store_bug_pattern(db, sample_embedding):
    """Test storing bug pattern."""
    record = BugPattern(
        bug_id="bug_1",
        session_id="session_1",
        bug_description="Division by zero",
        code_snippet="result = a / b",
        embedding=sample_embedding,
        severity="high",
        timestamp=datetime.now(),
    )

    db.store_bug(record)

    # Retrieve
    bugs = db.get_all_bug_embeddings(limit=10)
    assert len(bugs) == 1
    assert bugs[0].bug_id == "bug_1"
    assert bugs[0].severity == "high"


def test_store_test_case(db, sample_embedding):
    """Test storing test case."""
    record = StoredTest(
        test_id="test_1",
        session_id="session_1",
        test_code="assert add(2, 3) == 5",
        embedding=sample_embedding,
        passed=True,
        timestamp=datetime.now(),
    )

    db.store_test(record)

    # Retrieve
    tests = db.get_all_test_embeddings(limit=10)
    assert len(tests) == 1
    assert tests[0].test_id == "test_1"
    assert tests[0].passed is True


def test_get_stats(db, sample_session, sample_embedding):
    """Test database statistics."""
    # Store some data
    db.store_session(sample_session)

    # Store reused oracle session
    reused_session = FuzzingSession(
        session_id="session_2",
        user_request="Another add function",
        generated_code="def sum(x, y): return x + y",
        oracle="Same oracle",
        timestamp=datetime.now(),
        num_tests=3,
        num_failures=0,
        oracle_reused=True,
        reused_from="session_1",
        quality_score=0.85,
    )
    db.store_session(reused_session)

    # Store bugs and tests
    db.store_bug(
        BugPattern(
            bug_id="bug_1",
            session_id="session_1",
            bug_description="Test bug",
            code_snippet="code",
            embedding=sample_embedding,
            severity="medium",
            timestamp=datetime.now(),
        )
    )

    db.store_test(
        StoredTest(
            test_id="test_1",
            session_id="session_1",
            test_code="assert True",
            embedding=sample_embedding,
            passed=True,
            timestamp=datetime.now(),
        )
    )

    db.store_test(
        StoredTest(
            test_id="test_2",
            session_id="session_1",
            test_code="assert False",
            embedding=sample_embedding,
            passed=False,
            timestamp=datetime.now(),
        )
    )

    # Check stats
    stats = db.get_stats()
    assert stats["total_sessions"] == 2
    assert stats["oracle_reuse_count"] == 1
    assert stats["oracle_reuse_rate"] == 0.5
    assert stats["total_bugs"] == 1
    assert stats["total_tests"] == 2
    assert stats["test_pass_rate"] == 0.5


def test_clear_database(db, sample_session, sample_embedding):
    """Test clearing all data."""
    db.store_session(sample_session)
    db.store_code(
        CodeRecord(
            code_id="code_1",
            session_id="session_1",
            code="code",
            embedding=sample_embedding,
            timestamp=datetime.now(),
        )
    )

    # Verify data exists
    assert db.get_stats()["total_sessions"] == 1

    # Clear
    db.clear()

    # Verify empty
    stats = db.get_stats()
    assert stats["total_sessions"] == 0
    assert stats["total_bugs"] == 0
    assert stats["total_tests"] == 0


def test_context_manager(sample_session):
    """Test database as context manager."""
    with HistoryDB(":memory:") as db:
        db.store_session(sample_session)
        assert db.get_stats()["total_sessions"] == 1

    # Connection should be closed
    assert db.conn is None


def test_get_all_with_limit(db, sample_embedding):
    """Test retrieving with limit."""
    # Store 10 code records
    for i in range(10):
        db.store_code(
            CodeRecord(
                code_id=f"code_{i}",
                session_id="session_1",
                code=f"code_{i}",
                embedding=sample_embedding,
                timestamp=datetime.now(),
            )
        )

    # Retrieve with limit
    codes = db.get_all_code_embeddings(limit=5)
    assert len(codes) == 5


def test_oracle_quality_ordering(db, sample_embedding):
    """Test oracles are ordered by quality score."""
    # Store oracles with different quality scores
    for i, quality in enumerate([0.7, 0.9, 0.6, 0.95, 0.8]):
        db.store_oracle(
            OracleRecord(
                oracle_id=f"oracle_{i}",
                session_id="session_1",
                oracle=f"oracle_{i}",
                embedding=sample_embedding,
                quality_score=quality,
                timestamp=datetime.now(),
            )
        )

    # Retrieve - should be ordered by quality descending
    oracles = db.get_all_oracle_embeddings()
    scores = [o.quality_score for o in oracles]
    assert scores == sorted(scores, reverse=True)
    assert scores[0] == 0.95


def test_nonexistent_session(db):
    """Test retrieving nonexistent session returns None."""
    result = db.get_session("nonexistent")
    assert result is None
