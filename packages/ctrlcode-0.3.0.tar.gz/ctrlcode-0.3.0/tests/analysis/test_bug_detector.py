"""Tests for BugPatternDetector."""

from datetime import datetime

import numpy as np
import pytest

from ctrlcode.analysis.bug_detector import BugPatternDetector, DetectedPattern
from ctrlcode.embeddings.embedder import CodeEmbedder
from ctrlcode.storage.history_db import BugPattern, HistoryDB


@pytest.fixture
def history_db():
    """Create in-memory history database with sample bugs."""
    db = HistoryDB(":memory:")

    embedder = CodeEmbedder(api_key="test-key", base_url="http://test/v1")

    # Add sample bug patterns
    bugs = [
        {
            "id": "bug_1",
            "description": "SQL injection vulnerability in user query",
            "code": 'query = f"SELECT * FROM users WHERE id = {user_id}"',
            "severity": "high",
        },
        {
            "id": "bug_2",
            "description": "Division by zero when denominator is empty",
            "code": "result = total / len(items)",
            "severity": "medium",
        },
        {
            "id": "bug_3",
            "description": "Race condition in concurrent counter update",
            "code": "counter = counter + 1",
            "severity": "high",
        },
    ]

    for bug in bugs:
        embedding = embedder.embed_code(bug["code"])
        bug_pattern = BugPattern(
            bug_id=bug["id"],
            session_id=f"session_{bug['id']}",
            bug_description=bug["description"],
            code_snippet=bug["code"],
            embedding=embedding,
            severity=bug["severity"],
            timestamp=datetime.now(),
        )
        db.store_bug(bug_pattern)

    return db


def test_detector_initialization(history_db):
    """Test detector initializes correctly."""
    detector = BugPatternDetector(history_db)

    assert detector.history_db is history_db
    assert detector.embedder is not None
    assert detector.similarity_threshold == 0.75


def test_detector_custom_threshold(history_db):
    """Test detector with custom similarity threshold."""
    detector = BugPatternDetector(history_db, similarity_threshold=0.9)

    assert detector.similarity_threshold == 0.9


def test_check_patterns_similar_code(history_db):
    """Test detecting similar bug pattern."""
    detector = BugPatternDetector(history_db, similarity_threshold=0.5)  # Lower threshold

    # Code very similar to SQL injection bug
    code = 'query = f"SELECT * FROM users WHERE id = {user_id}"'  # Almost identical

    patterns = detector.check_patterns(code)

    # Should find at least the SQL injection bug
    assert len(patterns) > 0
    assert all(isinstance(p, DetectedPattern) for p in patterns)
    # First result should be SQL-related (highest similarity)
    assert "SQL" in patterns[0].description or "query" in patterns[0].description


def test_check_patterns_no_match(history_db):
    """Test with code that doesn't match any bug patterns."""
    detector = BugPatternDetector(history_db, similarity_threshold=0.9)

    # Completely different code
    code = "def hello_world(): print('Hello, world!')"

    patterns = detector.check_patterns(code)

    # Might be empty or have very low similarity
    assert all(p.similarity < 0.9 for p in patterns) or len(patterns) == 0


def test_check_patterns_empty_db():
    """Test with empty history database."""
    empty_db = HistoryDB(":memory:")
    detector = BugPatternDetector(empty_db)

    code = "some code"
    patterns = detector.check_patterns(code)

    assert patterns == []


def test_check_patterns_sorted_by_similarity(history_db):
    """Test that results are sorted by similarity (descending)."""
    detector = BugPatternDetector(history_db, similarity_threshold=0.5)

    code = 'query = f"SELECT * FROM data WHERE field = {value}"'
    patterns = detector.check_patterns(code)

    if len(patterns) > 1:
        similarities = [p.similarity for p in patterns]
        assert similarities == sorted(similarities, reverse=True)


def test_detected_pattern_confidence():
    """Test confidence level calculation."""
    high_conf = DetectedPattern(
        bug_id="bug1",
        description="test",
        code_snippet="code",
        severity="high",
        similarity=0.95,
        session_id="session1",
    )
    assert high_conf.confidence == "HIGH"

    medium_conf = DetectedPattern(
        bug_id="bug2",
        description="test",
        code_snippet="code",
        severity="medium",
        similarity=0.85,
        session_id="session2",
    )
    assert medium_conf.confidence == "MEDIUM"

    low_conf = DetectedPattern(
        bug_id="bug3",
        description="test",
        code_snippet="code",
        severity="low",
        similarity=0.75,
        session_id="session3",
    )
    assert low_conf.confidence == "LOW"


def test_format_warnings_empty():
    """Test formatting warnings with no patterns."""
    detector = BugPatternDetector(HistoryDB(":memory:"))

    warnings = detector.format_warnings([])

    assert warnings == ""


def test_format_warnings_with_patterns(history_db):
    """Test formatting warnings with detected patterns."""
    detector = BugPatternDetector(history_db, similarity_threshold=0.6)

    code = 'query = f"SELECT * FROM users WHERE id = {user_id}"'
    patterns = detector.check_patterns(code)

    warnings = detector.format_warnings(patterns)

    assert "SIMILAR BUG PATTERNS DETECTED" in warnings
    assert "Severity:" in warnings
    assert "Confidence:" in warnings


def test_format_warnings_limits_to_five(history_db):
    """Test that format_warnings shows max 5 patterns."""
    # Create patterns manually (don't need actual DB lookup)
    patterns = [
        DetectedPattern(
            bug_id=f"bug_{i}",
            description=f"Bug description {i}",
            code_snippet=f"code snippet {i}",
            severity="medium",
            similarity=0.8,
            session_id=f"session_{i}",
        )
        for i in range(10)
    ]

    detector = BugPatternDetector(history_db)
    warnings = detector.format_warnings(patterns)

    # Check that only first 5 items are shown (not all 10)
    assert "1. Bug description 0" in warnings
    assert "2. Bug description 1" in warnings
    assert "3. Bug description 2" in warnings
    assert "4. Bug description 3" in warnings
    assert "5. Bug description 4" in warnings

    # Items 6-10 should not appear
    assert "6. Bug description 5" not in warnings
    assert "7. Bug description 6" not in warnings
    assert "10. Bug description 9" not in warnings


def test_check_patterns_respects_limit(history_db):
    """Test that check_patterns limits results to top 10."""
    # The detector searches for top k=10 in the code
    detector = BugPatternDetector(history_db, similarity_threshold=0.0)  # Accept all

    code = "test code"
    patterns = detector.check_patterns(code)

    # Should return at most 10 (limited by vector store search k=10)
    assert len(patterns) <= 10
