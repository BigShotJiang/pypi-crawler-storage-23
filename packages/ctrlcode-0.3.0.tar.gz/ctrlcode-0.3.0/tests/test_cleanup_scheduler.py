"""Tests for cleanup scheduler."""

import json
import pytest
from datetime import datetime
from ctrlcode.cleanup import CleanupScheduler


@pytest.fixture
def workspace_root(tmp_path):
    """Create temporary workspace."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    # Create some Python files
    src_dir = workspace / "src"
    src_dir.mkdir()

    (src_dir / "test.py").write_text("""
def process(data):
    value = data["key"]  # YOLO parsing violation
    print(f"Value: {value}")  # Print statement violation
    return value
""")

    return workspace


@pytest.fixture
def scheduler(workspace_root, tmp_path):
    """Create CleanupScheduler instance."""
    results_dir = tmp_path / "results"
    return CleanupScheduler(workspace_root, results_dir)


def test_scheduler_init(scheduler, tmp_path):
    """Test scheduler initialization."""
    assert scheduler.workspace_root.exists()
    assert scheduler.results_dir.exists()
    assert scheduler.is_running is False


def test_scheduler_start_stop(scheduler):
    """Test starting and stopping scheduler."""
    assert scheduler.is_running is False

    scheduler.start()
    assert scheduler.is_running is True

    scheduler.stop()
    assert scheduler.is_running is False


def test_add_nightly_scan(scheduler):
    """Test adding nightly scan job."""
    scheduler.start()
    scheduler.add_nightly_scan("golden_principles", hour=2, minute=30)

    jobs = scheduler.get_scheduled_jobs()
    assert len(jobs) == 1
    assert jobs[0]["id"] == "nightly_golden_principles"
    assert "Nightly golden_principles scan" in jobs[0]["name"]

    scheduler.stop()


def test_add_weekly_scan(scheduler):
    """Test adding weekly scan job."""
    scheduler.start()
    scheduler.add_weekly_scan("stale_docs", day_of_week=1, hour=3)

    jobs = scheduler.get_scheduled_jobs()
    assert len(jobs) == 1
    assert jobs[0]["id"] == "weekly_stale_docs"

    scheduler.stop()


def test_add_interval_scan(scheduler):
    """Test adding interval scan job."""
    scheduler.start()
    scheduler.add_interval_scan("code_smells", hours=6)

    jobs = scheduler.get_scheduled_jobs()
    assert len(jobs) == 1
    assert jobs[0]["id"] == "interval_code_smells"

    scheduler.stop()


def test_remove_scan(scheduler):
    """Test removing scheduled scan."""
    scheduler.start()
    scheduler.add_nightly_scan("golden_principles")
    assert len(scheduler.get_scheduled_jobs()) == 1

    scheduler.remove_scan("golden_principles", "nightly")
    assert len(scheduler.get_scheduled_jobs()) == 0

    scheduler.stop()


def test_run_golden_principles_scan(scheduler):
    """Test running golden principles scan."""
    results = scheduler.run_scan_now("golden_principles")

    assert results["scan_type"] == "golden_principles"
    assert results["status"] == "completed"
    assert "total_violations" in results
    assert "violations_by_principle" in results
    assert results["total_violations"] > 0  # Should find violations in test.py


def test_run_stale_docs_scan(scheduler):
    """Test running stale docs scan."""
    results = scheduler.run_scan_now("stale_docs")

    assert results["scan_type"] == "stale_docs"
    assert results["status"] == "completed"
    assert "total_stale" in results
    assert "stale_docs" in results


def test_run_code_smells_scan(scheduler):
    """Test running code smells scan."""
    results = scheduler.run_scan_now("code_smells")

    assert results["scan_type"] == "code_smells"
    assert results["status"] == "completed"
    assert "total_smells" in results


def test_run_duplicates_scan(scheduler):
    """Test running duplicates scan."""
    results = scheduler.run_scan_now("duplicates")

    assert results["scan_type"] == "duplicates"
    assert results["status"] == "completed"
    assert "total_duplicates" in results


def test_unknown_scan_type(scheduler):
    """Test running unknown scan type."""
    results = scheduler.run_scan_now("unknown_scan")

    assert results["scan_type"] == "unknown_scan"
    assert results["status"] == "failed"
    assert "error" in results


def test_store_results(scheduler):
    """Test storing scan results."""
    _results = scheduler.run_scan_now("golden_principles")

    # Check file was created
    result_files = list(scheduler.results_dir.glob("golden_principles_*.json"))
    assert len(result_files) > 0

    # Check content
    with open(result_files[0]) as f:
        stored = json.load(f)
    assert stored["scan_type"] == "golden_principles"
    assert stored["status"] == "completed"


def test_get_latest_results(scheduler):
    """Test getting latest scan results."""
    # Run two scans
    scheduler.run_scan_now("golden_principles")
    scheduler.run_scan_now("golden_principles")

    # Get latest
    latest = scheduler.get_latest_results("golden_principles")
    assert latest is not None
    assert latest["scan_type"] == "golden_principles"


def test_get_latest_results_none(scheduler):
    """Test getting latest results when none exist."""
    latest = scheduler.get_latest_results("nonexistent")
    assert latest is None


def test_scan_callback(scheduler):
    """Test scan completion callback."""
    callback_results = []

    def on_complete(results):
        callback_results.append(results)

    scheduler.on_scan_complete = on_complete
    scheduler.run_scan_now("golden_principles")

    assert len(callback_results) == 1
    assert callback_results[0]["scan_type"] == "golden_principles"


def test_multiple_scheduled_jobs(scheduler):
    """Test multiple scheduled jobs."""
    scheduler.start()
    scheduler.add_nightly_scan("golden_principles", hour=2)
    scheduler.add_weekly_scan("stale_docs", day_of_week=0, hour=3)
    scheduler.add_interval_scan("code_smells", hours=6)

    jobs = scheduler.get_scheduled_jobs()
    assert len(jobs) == 3

    job_ids = {job["id"] for job in jobs}
    assert "nightly_golden_principles" in job_ids
    assert "weekly_stale_docs" in job_ids
    assert "interval_code_smells" in job_ids

    scheduler.stop()


def test_scan_includes_timestamp(scheduler):
    """Test that scan results include timestamp."""
    results = scheduler.run_scan_now("golden_principles")

    assert "timestamp" in results
    # Verify timestamp format
    timestamp = datetime.fromisoformat(results["timestamp"])
    assert isinstance(timestamp, datetime)


def test_scan_includes_duration(scheduler):
    """Test that scan results include duration."""
    results = scheduler.run_scan_now("golden_principles")

    assert "duration_seconds" in results
    assert isinstance(results["duration_seconds"], (int, float))
    assert results["duration_seconds"] >= 0


def test_replace_existing_job(scheduler):
    """Test replacing existing scheduled job."""
    scheduler.start()
    scheduler.add_nightly_scan("golden_principles", hour=2)
    scheduler.add_nightly_scan("golden_principles", hour=3)  # Replace

    jobs = scheduler.get_scheduled_jobs()
    assert len(jobs) == 1  # Should only have one

    scheduler.stop()


def test_golden_principles_scan_finds_violations(workspace_root, scheduler):
    """Test that golden principles scan finds actual violations."""
    results = scheduler.run_scan_now("golden_principles")

    assert results["total_violations"] >= 2  # At least YOLO + print
    assert "no-yolo-parsing" in results["violations_by_principle"]
    assert "structured-logging" in results["violations_by_principle"]


def test_golden_principles_scan_skips_tests(workspace_root, scheduler):
    """Test that scan skips test files."""
    # Create test file with violations
    test_dir = workspace_root / "tests"
    test_dir.mkdir()
    (test_dir / "test_something.py").write_text("""
def test_something():
    data = {"key": "value"}
    print(data["key"])  # Should be skipped
""")

    results = scheduler.run_scan_now("golden_principles")

    # Violations should only be from src/test.py, not tests/
    for violation in results.get("violations", []):
        assert "tests" not in violation["file"]
