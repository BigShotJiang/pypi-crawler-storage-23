"""Tests for observability tools."""

import json
import pytest
from datetime import datetime, timedelta

from ctrlcode.tools.observability import ObservabilityTools


@pytest.fixture
def temp_log_dir(tmp_path):
    """Create temporary log directory with sample logs."""
    log_dir = tmp_path / "logs"
    log_dir.mkdir()

    # Create sample structured logs
    now = datetime.now()

    logs = [
        {
            "timestamp": now.isoformat(),
            "level": "INFO",
            "event": "auth.login.success",
            "user_id": "123",
            "message": "User logged in successfully"
        },
        {
            "timestamp": (now - timedelta(minutes=5)).isoformat(),
            "level": "ERROR",
            "event": "database.query.failed",
            "error": "connection refused",
            "message": "Failed to connect to database"
        },
        {
            "timestamp": (now - timedelta(minutes=10)).isoformat(),
            "level": "WARNING",
            "event": "auth.login.failed",
            "user_id": "456",
            "reason": "invalid_password",
            "message": "Login attempt with invalid password"
        },
        {
            "timestamp": (now - timedelta(hours=2)).isoformat(),  # Outside 1h range
            "level": "ERROR",
            "event": "api.request.failed",
            "status_code": 500,
            "message": "Internal server error"
        },
    ]

    # Write logs to file
    log_file = log_dir / "app.log"
    with open(log_file, "w") as f:
        for log in logs:
            f.write(json.dumps(log) + "\n")

    return log_dir


def test_query_logs_basic(temp_log_dir):
    """Test basic log querying."""
    tools = ObservabilityTools(temp_log_dir)

    result = tools.query_logs(time_range="1h")

    assert result["count"] == 3  # 3 logs within 1h
    assert len(result["matches"]) == 3
    assert result["time_range"] == "1h"


def test_query_logs_filter_by_level(temp_log_dir):
    """Test filtering logs by level."""
    tools = ObservabilityTools(temp_log_dir)

    result = tools.query_logs(query='{level="ERROR"}', time_range="1h")

    assert result["count"] == 1
    assert result["matches"][0]["level"] == "ERROR"
    assert result["matches"][0]["event"] == "database.query.failed"


def test_query_logs_filter_by_event(temp_log_dir):
    """Test filtering logs by event."""
    tools = ObservabilityTools(temp_log_dir)

    result = tools.query_logs(query='{event="auth.login.failed"}', time_range="1h")

    assert result["count"] == 1
    assert result["matches"][0]["event"] == "auth.login.failed"
    assert result["matches"][0]["reason"] == "invalid_password"


def test_query_logs_filter_by_user_id(temp_log_dir):
    """Test filtering logs by user_id."""
    tools = ObservabilityTools(temp_log_dir)

    result = tools.query_logs(query='{user_id="123"}', time_range="1h")

    assert result["count"] == 1
    assert result["matches"][0]["user_id"] == "123"
    assert result["matches"][0]["event"] == "auth.login.success"


def test_query_logs_contains_filter(temp_log_dir):
    """Test contains filter."""
    tools = ObservabilityTools(temp_log_dir)

    result = tools.query_logs(query='|= "database"', time_range="1h")

    assert result["count"] == 1
    assert "database" in result["matches"][0]["event"]


def test_query_logs_combined_filters(temp_log_dir):
    """Test combined filters."""
    tools = ObservabilityTools(temp_log_dir)

    result = tools.query_logs(
        query='{level="ERROR"} |= "database"',
        time_range="1h"
    )

    assert result["count"] == 1
    assert result["matches"][0]["level"] == "ERROR"
    assert "database" in result["matches"][0]["event"]


def test_query_logs_time_range(temp_log_dir):
    """Test time range filtering."""
    tools = ObservabilityTools(temp_log_dir)

    # 1 hour range should exclude the 2h old log
    result = tools.query_logs(time_range="1h")
    assert result["count"] == 3

    # 3 hour range should include all logs
    result = tools.query_logs(time_range="3h")
    assert result["count"] == 4


def test_query_logs_max_results(temp_log_dir):
    """Test max_results parameter."""
    tools = ObservabilityTools(temp_log_dir)

    result = tools.query_logs(max_results=2, time_range="3h")

    assert result["count"] == 2  # Limited to 2
    assert len(result["matches"]) == 2


def test_query_logs_empty_directory(tmp_path):
    """Test with empty log directory."""
    log_dir = tmp_path / "logs"
    log_dir.mkdir()

    tools = ObservabilityTools(log_dir)
    result = tools.query_logs()

    assert result["count"] == 0
    assert "No log files found" in result.get("error", "")


def test_query_logs_nonexistent_directory(tmp_path):
    """Test with nonexistent log directory."""
    log_dir = tmp_path / "nonexistent"

    tools = ObservabilityTools(log_dir)
    result = tools.query_logs()

    assert result["count"] == 0
    assert "not found" in result.get("error", "")


def test_query_logs_plain_text_fallback(tmp_path):
    """Test fallback to plain text for non-JSON logs."""
    log_dir = tmp_path / "logs"
    log_dir.mkdir()

    # Create plain text log
    log_file = log_dir / "app.log"
    with open(log_file, "w") as f:
        f.write("This is a plain text log entry\n")
        f.write("ERROR: Something went wrong\n")

    tools = ObservabilityTools(log_dir)
    result = tools.query_logs(query='|= "ERROR"', time_range="1h")

    assert result["count"] == 1
    assert "ERROR" in result["matches"][0]["message"]


# Query Metrics Tests


@pytest.fixture
def temp_metrics_dir(tmp_path):
    """Create temporary directory with sample metrics."""
    log_dir = tmp_path / "logs"
    log_dir.mkdir()

    # Create sample metrics
    now = datetime.now()

    metrics = [
        {
            "timestamp": now.isoformat(),
            "http_request_duration_ms": 145,
            "http_requests_total": 1000,
            "cpu_usage_percent": 45.2,
        },
        {
            "timestamp": (now - timedelta(minutes=5)).isoformat(),
            "http_request_duration_ms": 152,
            "http_requests_total": 1050,
            "cpu_usage_percent": 48.1,
        },
        {
            "timestamp": (now - timedelta(minutes=10)).isoformat(),
            "http_request_duration_ms": 148,
            "http_requests_total": 1100,
            "cpu_usage_percent": 46.5,
        },
        {
            "timestamp": (now - timedelta(hours=2)).isoformat(),  # Outside 1h range
            "http_request_duration_ms": 200,
            "http_requests_total": 500,
            "cpu_usage_percent": 60.0,
        },
    ]

    # Write metrics to file
    metrics_file = log_dir / "metrics.jsonl"
    with open(metrics_file, "w") as f:
        for metric in metrics:
            f.write(json.dumps(metric) + "\n")

    return log_dir


def test_query_metrics_basic(temp_metrics_dir):
    """Test basic metrics querying."""
    tools = ObservabilityTools(temp_metrics_dir)

    result = tools.query_metrics(
        query="http_request_duration_ms",
        time_range="1h"
    )

    assert len(result["values"]) == 3  # 3 metrics within 1h
    assert result["aggregates"]["count"] == 3
    assert "avg" in result["aggregates"]
    assert result["metric_name"] == "http_request_duration_ms"


def test_query_metrics_aggregates(temp_metrics_dir):
    """Test metric aggregation calculations."""
    tools = ObservabilityTools(temp_metrics_dir)

    result = tools.query_metrics(
        query="http_request_duration_ms",
        time_range="1h"
    )

    agg = result["aggregates"]
    assert agg["count"] == 3
    assert agg["min"] == 145
    assert agg["max"] == 152
    assert 145 <= agg["avg"] <= 152
    assert agg["sum"] == 145 + 152 + 148


def test_query_metrics_time_range(temp_metrics_dir):
    """Test time range filtering for metrics."""
    tools = ObservabilityTools(temp_metrics_dir)

    # 1 hour range should exclude the 2h old metric
    result = tools.query_metrics(query="http_request_duration_ms", time_range="1h")
    assert len(result["values"]) == 3

    # 3 hour range should include all metrics
    result = tools.query_metrics(query="http_request_duration_ms", time_range="3h")
    assert len(result["values"]) == 4


def test_query_metrics_different_metric(temp_metrics_dir):
    """Test querying different metric names."""
    tools = ObservabilityTools(temp_metrics_dir)

    result = tools.query_metrics(query="cpu_usage_percent", time_range="1h")

    assert len(result["values"]) == 3
    assert result["metric_name"] == "cpu_usage_percent"
    assert 45 <= result["aggregates"]["avg"] <= 50


def test_query_metrics_rate_query(temp_metrics_dir):
    """Test PromQL-style rate query."""
    tools = ObservabilityTools(temp_metrics_dir)

    result = tools.query_metrics(
        query="rate(http_requests_total[5m])",
        time_range="1h"
    )

    assert result["metric_name"] == "http_requests_total"
    assert result["operation"] == "rate"
    assert len(result["values"]) == 3


def test_query_metrics_avg_query(temp_metrics_dir):
    """Test PromQL-style avg query."""
    tools = ObservabilityTools(temp_metrics_dir)

    result = tools.query_metrics(
        query="avg(http_request_duration_ms)",
        time_range="1h"
    )

    assert result["metric_name"] == "http_request_duration_ms"
    assert result["operation"] == "avg"
    assert "avg" in result["aggregates"]


def test_query_metrics_no_metrics_file(tmp_path):
    """Test fallback when no metrics file exists."""
    log_dir = tmp_path / "logs"
    log_dir.mkdir()

    tools = ObservabilityTools(log_dir)
    result = tools.query_metrics(query="http_request_duration_ms")

    assert "error" in result
    assert "No metrics file found" in result["error"]


def test_query_metrics_with_wrk_output(tmp_path):
    """Test extracting metrics from wrk output."""
    log_dir = tmp_path / "logs"
    log_dir.mkdir()

    # Create wrk output file
    wrk_output = log_dir / "test_output.log"
    wrk_output.write_text("""
Running 30s test @ http://localhost:8000
  4 threads and 100 connections
  Thread Stats   Avg      Stdev     Max   +/- Stdev
    Latency   145.23ms   45.12ms  250.00ms   68.43%
    Req/Sec   167.89     35.21   245.00     71.23%
  20000 requests in 30.01s, 12.34MB read
Requests/sec: 666.44
Transfer/sec: 420.67KB
""")

    tools = ObservabilityTools(log_dir)
    result = tools.query_metrics(query="latency")

    assert result["source"] == "wrk_output"
    assert len(result["values"]) == 1
    assert result["aggregates"]["latency_ms"] == 145.23


def test_query_metrics_with_ab_output(tmp_path):
    """Test extracting metrics from Apache Bench output."""
    log_dir = tmp_path / "logs"
    log_dir.mkdir()

    # Create ab output file
    ab_output = log_dir / "benchmark.txt"
    ab_output.write_text("""
Server Software:        nginx
Server Hostname:        localhost
Server Port:            8000

Document Path:          /api/login
Document Length:        256 bytes

Concurrency Level:      10
Time taken for tests:   5.123 seconds
Complete requests:      1000
Failed requests:        0
Total transferred:      256000 bytes
HTML transferred:       256000 bytes
Requests per second:    195.18 [#/sec] (mean)
Time per request:       51.23 [ms] (mean)
Time per request:       5.123 [ms] (mean, across all concurrent requests)
Transfer rate:          48.75 [Kbytes/sec] received
""")

    tools = ObservabilityTools(log_dir)
    result = tools.query_metrics(query="latency")

    assert result["source"] == "ab_output"
    assert len(result["values"]) == 1
    assert result["aggregates"]["time_per_request_ms"] == 51.23
