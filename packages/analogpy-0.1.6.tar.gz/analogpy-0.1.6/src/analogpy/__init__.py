# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .circuit import (
    Circuit,
    Net,
    Subcircuit,
    Subckt,
    CircuitInstance,
    ParamRef,
    param,
    auto_comment_params,
    reset_global_name_counters,
)
from .devices import (
    nmos, pmos,
    resistor, capacitor, inductor,
    vsource, isource,
    vcvs, vccs, ccvs, cccs,
    diode, bjt, jfet,
    iprobe, mutual_inductor, port
)
from .spectre import generate_spectre
from .ngspice import generate_ngspice
from .testbench import Testbench, SimulatorOptions
from .analysis import Analysis, DC, AC, Transient, Noise, STB
from .save import SaveConfig, SaveOptions
from .command import SpectreCommand
from .batch import SimulationBatch

__all__ = [
    # Core
    "Circuit",
    "Subcircuit",  # Alias for Circuit (backwards compatibility)
    "Subckt",      # Alias for Circuit (SPICE terminology)
    "Net",
    "CircuitInstance",
    "ParamRef",
    "param",
    "auto_comment_params",  # Decorator for automatic parameter comments
    "reset_global_name_counters",  # Reset shared name counters for testing
    # Testbench
    "Testbench",
    "SimulatorOptions",
    # Analysis
    "Analysis",
    "DC",
    "AC",
    "Transient",
    "Noise",
    "STB",
    # Save
    "SaveConfig",
    "SaveOptions",
    # Command
    "SpectreCommand",
    # Batch
    "SimulationBatch",
    # Devices - MOSFETs
    "nmos",
    "pmos",
    # Devices - Passives
    "resistor",
    "capacitor",
    "inductor",
    # Devices - Sources
    "vsource",
    "isource",
    # Devices - Controlled sources
    "vcvs",
    "vccs",
    "ccvs",
    "cccs",
    # Devices - Other
    "diode",
    "bjt",
    "jfet",
    "iprobe",
    "mutual_inductor",
    "port",
    # Generators
    "generate_spectre",
    "generate_ngspice",
]
