# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Current probe cell definition with symbol support.

Provides a current probe (ammeter) as a reusable cell with:
- Circuit definition for netlist generation
- Symbol definition for schematic visualization

Usage:
    from analogpy.cells import iprobe_cell

    probe = iprobe_cell("I_SENSE")
    # Or use the primitive directly: iprobe("I_SENSE", p, n)
"""

from ..circuit import Circuit
from ..devices import iprobe


def iprobe_cell(
    name: str,
) -> Circuit:
    """
    Create a current probe cell with explicit ports.

    Ports:
        p: positive terminal (current flows in)
        n: negative terminal (current flows out)

    Args:
        name: Cell name (used in netlist subckt definition)

    Returns:
        Circuit object representing the current probe cell
    """
    cell = Circuit(name, ports=["p", "n"])

    p_net = cell.net("p")
    n_net = cell.net("n")

    cell.instantiate(iprobe, "PROBE", p=p_net, n=n_net)

    return cell


# Symbol configuration for schematic visualization
SYMBOL_CONFIG = {
    "type": "iprobe",
    "ports": ["p", "n"],
    "port_types": {
        "p": "INPUT",
        "n": "OUTPUT",
    },
    "shape": "ammeter",  # Circle with arrow or 'A'
    "color": "#000000",  # Black
    "label": "I",
}
