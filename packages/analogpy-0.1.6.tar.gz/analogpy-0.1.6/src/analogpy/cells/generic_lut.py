# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Generic LUT device cell definition with symbol support.

Provides a generic lookup table device (Verilog-A based) as a reusable cell with:
- Circuit definition for netlist generation
- Symbol definition for schematic visualization

For project-specific LUT models (e.g., OLED models), define SYMBOL_CONFIGS
in your project's cell file. See examples/cells/oled.py for reference.

Usage:
    from analogpy.cells import generic_lut_cell

    lut_device = generic_lut_cell("MY_LUT", model="my_lut_model",
                                   ports=["p", "n"], param1="value")
"""

from typing import List, Dict, Any
from ..circuit import Circuit


def generic_lut_cell(
    name: str,
    model: str,
    ports: List[str],
    **params: Any,
) -> Circuit:
    """
    Create a generic LUT device cell with explicit ports.

    Args:
        name: Cell name (used in netlist subckt definition)
        model: Verilog-A model name (e.g., "oled_LUT_dc_with_mag_factor")
        ports: List of port names for the device
        **params: Model parameters (tmdata, area, factor, etc.)

    Returns:
        Circuit object representing the generic LUT device
    """
    cell = Circuit(name, ports=ports)

    # Create nets for all ports
    port_nets = {p: cell.net(p) for p in ports}

    # Create the device Circuit and instantiate it
    device = Circuit(model, ports=ports)
    cell.instantiate(device, "DEV", **port_nets, **params)

    return cell


# Default symbol configuration for generic LUT devices
# Project-specific configs should be defined in project cell files
DEFAULT_SYMBOL_CONFIG = {
    "type": "generic_lut",
    "label": "LUT",
    "color": "#FFFFFF",  # White default
    "shape": "box",
}


def get_symbol_config(model: str) -> Dict[str, Any]:
    """
    Get symbol configuration for a LUT model.

    Returns default config. For custom configs, define SYMBOL_CONFIGS
    in your project's cell file (see examples/cells/oled.py).
    """
    return {
        "type": "generic_lut",
        "label": model[:10] if len(model) > 10 else model,
        "color": "#FFFFFF",
        "shape": "box",
    }

