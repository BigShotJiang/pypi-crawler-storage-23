.. weaver documentation master file, created by
   sphinx-quickstart on Mon Nov 17 12:05:45 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

weaver documentation
=======================

.. image:: _static/weaver.svg
   :width: 200px
   :alt: weaver hex sticker
   :align: center

Welcome to the documentation for `weaver` a Rust-based HGVS variant parser and validator library for Python.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   api
