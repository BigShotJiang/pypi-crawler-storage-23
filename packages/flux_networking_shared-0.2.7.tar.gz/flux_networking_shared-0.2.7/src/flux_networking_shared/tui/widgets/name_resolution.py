"""DNS name resolution monitoring widget.

This widget subscribes to the 'dns_resolution' topic to receive
real-time DNS resolution results from the backend.
"""

from __future__ import annotations

from typing import Any, Literal, Protocol

from textual.app import ComposeResult
from textual.dom import NoMatches
from textual.message import Message
from textual.reactive import var
from textual.widget import Widget
from textual.widgets import DataTable

from flux_networking_shared.tui.models.network import ResolvedHostname

StateTypes = Literal["Unknown", "Pass", "Degraded", "Fail"]


class NetworkClient(Protocol):
    """Protocol for network RPC client."""

    async def test_dns(self, hostnames: list[str] | None = None) -> dict[str, Any]: ...

    async def subscribe(self, topics: list[str]) -> dict[str, Any]: ...

    async def unsubscribe(self, topics: list[str]) -> dict[str, Any]: ...


class NameResolution(Widget):
    """Displays DNS name resolution status.

    Subscribes to the 'dns_resolution' topic to receive real-time
    resolution results from the backend.
    """

    class ResolutionStateChanged(Message):
        """Posted when resolution state changes."""

        def __init__(self, state: StateTypes) -> None:
            super().__init__()
            self.state = state

    BORDER_TITLE = "Name Resolution"

    DEFAULT_CSS = """
        NameResolution {
            height: auto;
            border: solid $primary;
            padding: 1;
        }

        NameResolution DataTable {
            height: auto;
        }
    """

    state: var[StateTypes] = var("Unknown")

    def __init__(self, client: NetworkClient | None = None) -> None:
        """Initialize the name resolution widget.

        Args:
            client: RPC client for network operations
        """
        super().__init__()
        self.client = client
        self.resolutions: list[ResolvedHostname] = []
        self._monitoring = False

    def compose(self) -> ComposeResult:
        yield DataTable(show_cursor=False)

    async def on_mount(self) -> None:
        """Subscribe to dns_resolution topic on mount."""
        if self.client:
            try:
                await self.client.subscribe(["dns_resolution"])
                self._monitoring = True
            except Exception:
                pass

    async def on_unmount(self) -> None:
        """Unsubscribe from dns_resolution topic on unmount."""
        if self.client and self._monitoring:
            try:
                await self.client.unsubscribe(["dns_resolution"])
            except Exception:
                pass

    def handle_resolution_event(self, data: dict[str, Any]) -> None:
        """Handle a DNS resolution update event from the backend.

        Args:
            data: Event data with hostname resolution results
        """
        hostname = ResolvedHostname.from_dict(data)

        # Update or add to resolutions list
        existing_idx = next(
            (i for i, r in enumerate(self.resolutions) if r.name == hostname.name),
            None,
        )

        if existing_idx is not None:
            self.resolutions[existing_idx] = hostname
        else:
            self.resolutions.append(hostname)

        self._update_table()
        self._evaluate_state()

    def update_from_results(self, results: list[dict[str, Any]]) -> None:
        """Update from a batch of resolution results.

        Args:
            results: List of resolution result dicts
        """
        self.resolutions = [ResolvedHostname.from_dict(r) for r in results]
        self._update_table()
        self._evaluate_state()

    def _update_table(self) -> None:
        """Update the DataTable with current resolutions."""
        try:
            table = self.query_one(DataTable)
        except NoMatches:
            return

        table.clear(columns=True)

        if not self.resolutions:
            return

        columns: list[dict[str, str | int]] = [
            {"label": "Name", "key": "name"},
            {"label": "Address", "key": "address"},
            {"label": "Interface", "key": "interface"},
            {"label": "Family", "key": "family"},
            {"label": "Canonical Name", "key": "canonical"},
            {"label": "   Elapsed", "key": "elapsed"},
            {"label": "Error", "key": "error"},
        ]

        for column in columns:
            table.add_column(**column)

        table.add_rows(r.data_row for r in self.resolutions)

    def _evaluate_state(self) -> None:
        """Compute overall resolution state."""
        if not self.resolutions:
            self.state = "Unknown"
            return

        resolved = [r.resolved for r in self.resolutions]

        if all(resolved):
            self.state = "Pass"
        elif any(resolved):
            self.state = "Degraded"
        else:
            self.state = "Fail"

    def watch_state(self, old: StateTypes, new: StateTypes) -> None:
        """Post message when state changes."""
        if old == new:
            return

        self.post_message(self.ResolutionStateChanged(new))
