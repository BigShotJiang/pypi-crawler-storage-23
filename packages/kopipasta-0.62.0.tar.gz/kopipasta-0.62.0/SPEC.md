# Specification: Kopipasta Smart Context (v0.6.0)

**Status:** Integrated
**Core Philosophy:**

1. **State-Awareness:** Distinguish between **Base** (Background/Synced) and **Delta** (Focus/Unsynced) context.
2. **Unified Input:** The `p` hotkey handles all text ingestion (Patches, Imports, Resets).
3. **Fluid Navigation:** Shortcuts to move files between states (`Space`, `c`, `e`).

## 1. Architecture: The State Model

### 1.1 State Definitions

* **Unselected:** File is ignored.
* **Base (Blue):** Files previously sent to the LLM. "Background Context."
* **Delta (Green):** Files newly selected, imported, or modified. "Active Focus."

### 1.2 Transitions (Implemented vs. Planned)

* **Selection (`Space`):** Unselected  **Delta**  **Base**  Unselected.
* *Logic:* Tapping a Blue file promotes it to Green (Focus). Tapping it again removes it.


* **Process (`p`):** Patched/Imported files  **Delta**.
* **Extend (`e`):** **Delta**  **Base** (after copy). 
* **Clear (`c`):** **Base**  Unselected. (Keeps Delta).

---

## 2. Feature Specifications

### Feature 1: Unified Process (`p`)

**Goal:** Handle *any* LLM text response intelligently.

**Logic (Markers Implemented):**

1. **Reset Scan:** `<<<RESET>>>` logic is active.
2. **Patch Scan:** Patch application and `<<<DELETE>>>` logic are active.
3. **Path Scan:** If *no* patches are found, regex-scan for file paths in the pasted text.
    - **If Paths Found:**
        - **Prompt:** `Found X paths. [A]ppend to current or [R]eplace selection?`
        - **Action (Append):** Add files to **Delta**.
        - **Action (Replace):** Clear *all* selection, then add files to **Delta**.
        - **Promotion:** Imported files transition to **Delta** (Green).

### Feature 2: Extend Context (`e`)

**Goal:** Create a "Follow-up" prompt with minimal tokens.

**Logic:**

1. **Filter:** Get all **Delta (Green)** files.
2. **Fallback:** If no Delta files, ask: `No new changes. Extend with ALL (Base) files? [y/N]`
3. **Generate:** Create prompt using *only* the filtered files.
4. **Commit:** Change state of these files from **Delta**  **Base** (Blue).

### Feature 4: Clear Selection (`c`)

**Goal:** Manual cleanup.

**Logic:**

1. **Action:** Deselect all **Base (Blue)** files.
2. **Constraint:** Leave **Delta (Green)** files active. (If user wants to clear *everything*, they press `c` then `c` again, or `Space` on the Greens).

---

## 3. UI/UX Standards

### Tree View Colors

* **Dim/Gray:** Ignored.
* **White:** Unselected.
* **Cyan (Blue):** **Base** (Synced/History).
* **Green:** **Delta** (Modified/New/Imported).

### Keyboard Shortcuts

| Key | Action | Description |
| --- | --- | --- |
| `Space` | **Toggle** | Unselected  Delta  Base  Unselected. |
| `p` | **Process** | Universal paste. Handles Patches, Imports (Append/Replace), Resets. |
| `e` | **Extend** | Copies Delta files. Transitions Delta  Base. |
| `c` | **Clear Base** | Unselects all Blue files. Keeps Green files. |
| `q` | **Quit** | Copies full context (Base + Delta). |

---

## 4. Implementation Checklist

### Phase 1: State Engine

* [ ] Refactor `TreeSelector.selected_files` to store `Enum` state.
* [ ] Update `Space` key logic (3-state cycle).
* [ ] Update `_build_display_tree` to render Cyan/Green.

### Phase 2: The Processor (`p`)

* [ ] Implement `<<<RESET>>>` and `<<<DELETE>>>` in Parser.
* [ ] Implement Regex Path Scanner.
* [ ] Implement `[A]ppend / [R]eplace` logic in `p` handler.
* [ ] Ensure patched files promote to Delta.

### Phase 3: Workflow Actions (`e`, `c`)

* [ ] Implement `e`: Filter Delta, Generate, Commit (Delta  Base).
* [ ] Implement `c`: Clear Base only.

### Phase 4: Prompt Templates

* [ ] Update System Prompt to explain `<<<DELETE>>>` and `<<<RESET>>>`.
* [ ] Create `extension_template` (Files only).