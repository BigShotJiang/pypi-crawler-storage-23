```mermaid
graph TD
    subgraph Sources
        API[External APIs]
        MQ[IBM MQ]
        KFK[Kafka Source]
    end

    subgraph "Ingestion Layer (Dump & Go)"
        DG[Dagster Assets] -->|Batch Pull| S3Raw
        PC[Python Consumers] -->|Stream Pull| S3Raw
    end

    subgraph "Storage Layer"
        S3Raw[("S3 Raw Inbox (JSON/Parquet)")]
    end

    subgraph "Processing Layer"
        DG_T[Dagster Transformer]
        PC_T["Stream Processor (Python)"]
    end

    subgraph "Data Quality"
        PyC[PyCharter Validator]
    end

    subgraph "Serving Layer"
        PG[("Staging DB (Postgres)")]
        MDB[("Serving DB (MongoDB)")]
    end

    S3Raw --> DG_T
    S3Raw --> PC_T

    DG_T --> PyC
    PC_T --> PyC

    PyC -->|Valid| PG
    PyC -->|Valid| MDB
    PyC -->|Invalid| DLQ[(DLQ Table)]
```
