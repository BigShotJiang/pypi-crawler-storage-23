# Database Configuration

Configure and optimize database connections for PyCharter.

## Connection Strings

### PostgreSQL

```python
# Basic
"postgresql://user:pass@localhost:5432/dbname"

# With SSL
"postgresql://user:pass@host:5432/dbname?sslmode=require"

# With connection pool
"postgresql://user:pass@host:5432/dbname?pool_size=10"
```

### MySQL

```python
"mysql://user:pass@localhost:3306/dbname"
```

### SQLite

```python
"sqlite:///path/to/database.db"
"sqlite:///:memory:"  # In-memory
```

## Metadata Store Configuration

```python
from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(
    connection_string="postgresql://user:pass@localhost/pycharter",
    pool_size=10,
    pool_timeout=30
)
store.connect()
```

## Database Initialization

```bash
# Initialize database schema
pycharter db init

# Run migrations
pycharter db migrate

# Check status
pycharter db status
```

## Environment Variables

```bash
export DATABASE_URL="postgresql://user:pass@localhost/pycharter"
export DB_POOL_SIZE=10
export DB_POOL_TIMEOUT=30
```

```python
import os
from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(os.environ["DATABASE_URL"])
```

## SSH Tunnel for Secure Connections

```python
from pycharter import DatabaseExtractor

extractor = DatabaseExtractor(
    connection_string="postgresql://user:pass@localhost/db",
    ssh_tunnel={
        "host": "bastion.example.com",
        "port": 22,
        "username": "deploy",
        "key_file": "~/.ssh/id_rsa"
    }
)
```

## Connection Pooling Best Practices

1. **Size the pool appropriately** - Match to expected concurrent connections
2. **Set timeouts** - Prevent hanging connections
3. **Use connection recycling** - Prevent stale connections
4. **Monitor pool usage** - Track connection wait times

## See Also

- [Metadata Store Tutorial](../tutorials/metadata-store.md)
- [Metadata Store API Reference](../api/metadata-store.md)
