# Production Deployment

Deploy PyCharter in production environments.

## Docker Deployment

### Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY pyproject.toml .
RUN pip install pycharter[api,etl]

# Copy application
COPY . .

EXPOSE 8000

CMD ["pycharter", "api", "--host", "0.0.0.0"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db/pycharter
    depends_on:
      - db
    restart: unless-stopped

  db:
    image: postgres:15
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=pycharter
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

volumes:
  postgres_data:
```

## Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pycharter-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: pycharter-api
  template:
    metadata:
      labels:
        app: pycharter-api
    spec:
      containers:
      - name: api
        image: pycharter-api:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: pycharter-secrets
              key: database-url
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

## Configuration

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:pass@host/db

# API
PYCHARTER_HOST=0.0.0.0
PYCHARTER_PORT=8000
PYCHARTER_WORKERS=4

# Security
PYCHARTER_API_KEY=your-secret-key
PYCHARTER_CORS_ORIGINS=https://app.example.com
```

### Logging

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

## Monitoring

### Health Checks

```bash
curl http://localhost:8000/health
```

### Metrics

Consider integrating with:

- Prometheus
- Datadog
- New Relic

## Security

1. **Use HTTPS** - Always use TLS in production
2. **API Keys** - Enable authentication
3. **CORS** - Configure allowed origins
4. **Secrets** - Use secret management (Vault, AWS Secrets Manager)
5. **Network** - Use private networks for database access

## Scaling

- **Horizontal**: Add more API replicas
- **Database**: Use read replicas for metadata store
- **Caching**: Use Redis for frequently accessed schemas

## See Also

- [REST API Tutorial](../tutorials/api-and-ui.md)
- [Database Configuration](database-config.md)
