# Wiki & Ontology API

The `pycharter.wiki` module provides types, parsers, and validators for field-level semantic annotations, concept vocabularies, lineage tracking, and collaborative governance.

See [Wiki & Ontology guide](../guides/wiki.md) for the full conceptual overview.

## Core ontology models

::: pycharter.wiki.ontology.models.OntologyArtifact
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.models.FieldOntology
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.models.Lineage
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.models.Relationship
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.models.ConceptDefinition
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.models.ConceptScheme
    options:
      show_root_heading: true
      heading_level: 3

## Enumerations

::: pycharter.wiki.ontology.models.ConceptTier
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.models.NodeKind
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.models.RelationshipType
    options:
      show_root_heading: true
      heading_level: 3

## Parsing functions

::: pycharter.wiki.ontology.parser.parse_ontology
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.wiki.ontology.parser.parse_ontology_file
    options:
      show_root_heading: true
      heading_level: 3

## Validation

::: pycharter.wiki.ontology.validator.validate_ontology
    options:
      show_root_heading: true
      heading_level: 3

## Exceptions

::: pycharter.wiki.shared.errors.PyCharterWikiError
    options:
      show_root_heading: true
      heading_level: 3

## Import

```python
# Top-level convenience imports
from pycharter.wiki import (
    OntologyArtifact,
    FieldOntology,
    Lineage,
    Relationship,
    ConceptTier,
    RelationshipType,
    parse_ontology,
    parse_ontology_file,
    validate_ontology,
    PyCharterWikiError,
)

# Extended models
from pycharter.wiki.ontology.models import (
    ConceptDefinition,
    ConceptScheme,
    NodeKind,
)
```

## Relationship inverse map

Each `RelationshipType` has a defined inverse, accessible via:

```python
from pycharter.wiki.ontology.models import resolve_inverse

print(resolve_inverse("is_a"))        # "has_subtype"
print(resolve_inverse("derived_from")) # "derives"
print(resolve_inverse("precedes"))     # "follows"
```

## See also

- [Wiki & Ontology guide](../guides/wiki.md)
- [Domain Models and Lifecycle](domain.md)
- [Errors](errors.md)
