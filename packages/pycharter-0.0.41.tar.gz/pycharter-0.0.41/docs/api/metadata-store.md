# Metadata Store

The metadata store provides centralized schema registry functionality.

## Overview

```python
from pycharter import SQLiteMetadataStore

store = SQLiteMetadataStore("metadata.db")
store.connect()

schema_id = store.store_schema("user", schema, version="1.0.0")
```

## Store Implementations

| Class | Backend | Use Case |
|-------|---------|----------|
| `InMemoryMetadataStore` | Memory | Testing |
| `SQLiteMetadataStore` | SQLite | Development |
| `PostgresMetadataStore` | PostgreSQL | Production |
| `MongoDBMetadataStore` | MongoDB | Document-oriented |
| `RedisMetadataStore` | Redis | Caching |

## MetadataStoreClient

Base interface for all stores:

::: pycharter.metadata_store.MetadataStoreClient
    options:
      show_root_heading: true
      show_source: false
      members:
        - connect
        - disconnect
        - store_schema
        - get_schema
        - list_schemas
        - store_coercion_rules
        - get_coercion_rules
        - store_validation_rules
        - get_validation_rules
        - store_metadata
        - get_metadata

## SQLiteMetadataStore

```python
from pycharter import SQLiteMetadataStore

store = SQLiteMetadataStore("metadata.db")
store.connect()

# Store schema
schema_id = store.store_schema("user", {
    "type": "object",
    "properties": {"name": {"type": "string"}}
}, version="1.0.0")

# Retrieve schema
schema = store.get_schema("user")
```

## PostgresMetadataStore

```python
from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(
    "postgresql://user:pass@localhost/pycharter"
)
store.connect()
```

## MongoDBMetadataStore

```python
from pycharter import MongoDBMetadataStore

store = MongoDBMetadataStore(
    "mongodb://localhost:27017/pycharter"
)
store.connect()
```

## RedisMetadataStore

```python
from pycharter import RedisMetadataStore

store = RedisMetadataStore("redis://localhost:6379/0")
store.connect()
```

## InMemoryMetadataStore

```python
from pycharter import InMemoryMetadataStore

store = InMemoryMetadataStore()
store.connect()
# Data is lost when program exits
```

## Examples

### Schema Versioning

```python
# Store versions
store.store_schema("user", schema_v1, version="1.0.0")
store.store_schema("user", schema_v2, version="2.0.0")

# Get specific version
schema = store.get_schema("user", version="1.0.0")

# Get latest
schema = store.get_schema("user")  # Returns 2.0.0

# List versions
versions = store.list_schema_versions("user")
```

### Storing Rules

```python
# Coercion rules
store.store_coercion_rules("user", {
    "version": "1.0.0",
    "rules": {"age": "coerce_to_integer"}
}, version="1.0.0")

# Validation rules
store.store_validation_rules("user", {
    "version": "1.0.0",
    "rules": {"age": {"is_positive": {}}}
}, version="1.0.0")
```

### Metadata

```python
# Store metadata
store.store_metadata("user", "schema", {
    "title": "User Schema",
    "owner": "data-team",
    "tags": ["user", "pii"]
})

# Retrieve
metadata = store.get_metadata("user", "schema")
```

### Ontology (wiki-enabled stores)

Stores that support the wiki (e.g. `PostgresMetadataStore`, `InMemoryMetadataStore`) can store and retrieve ontology annotations per contract:

```python
# Store ontology for a contract
store.store_ontology("user", "1.0.0", {
    "version": "1.0.0",
    "fields": {
        "email": {"concept": "user_email", "definition": "Primary email address"}
    }
})

# Retrieve ontology
ontology = store.get_ontology("user", "1.0.0")
```

When you call `store.get_contract(name, version)`, the returned contract dict includes `ontology` when available.

## See Also

- [Metadata Store Tutorial](../tutorials/metadata-store.md)
- [Schema Evolution](schema-evolution.md)
