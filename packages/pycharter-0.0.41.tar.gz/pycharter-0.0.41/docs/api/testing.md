# Testing Framework

`pycharter.etl_generator.testing` provides mock components, assertion helpers, fixture loading, and a test harness for writing isolated unit and integration tests of ETL pipelines.

See [Testing Pipelines](../guides/testing-pipelines.md) for the full guide.

## Classes

::: pycharter.etl_generator.testing.MockExtractor
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.MockLoader
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.PipelineTestHarness
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.TestFixture
    options:
      show_root_heading: true
      heading_level: 3

## Functions

::: pycharter.etl_generator.testing.load_fixture
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.load_test_fixture
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.validate_pipeline_config
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.assert_records_match
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.assert_record_count
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.assert_fields_present
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.assert_no_field
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.assert_field_values
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.etl_generator.testing.assert_schema_shape
    options:
      show_root_heading: true
      heading_level: 3

## Import

```python
from pycharter.etl_generator.testing import (
    # Mock components
    MockExtractor,
    MockLoader,
    # Test harness
    PipelineTestHarness,
    # Fixtures
    load_fixture,
    load_test_fixture,
    TestFixture,
    # Config validation
    validate_pipeline_config,
    # Assertion helpers
    assert_records_match,
    assert_record_count,
    assert_fields_present,
    assert_no_field,
    assert_field_values,
    assert_schema_shape,
)
```

## See also

- [Testing Pipelines guide](../guides/testing-pipelines.md)
- [Pipeline](pipeline.md)
- [Extractors](extractors.md)
- [Loaders](loaders.md)
