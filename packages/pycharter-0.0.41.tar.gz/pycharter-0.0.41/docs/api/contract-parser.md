# Contract Parser

Parse data contract files into structured metadata.

## Overview

```python
from pycharter import parse_contract_file

metadata = parse_contract_file("user_contract.yaml")
```

## API Reference

::: pycharter.contract_parser.parse_contract
    options:
      show_root_heading: true

::: pycharter.contract_parser.parse_contract_file
    options:
      show_root_heading: true

## ContractMetadata

The result of parsing a contract:

| Attribute | Type | Description |
|-----------|------|-------------|
| `schema` | Dict | JSON Schema definition |
| `coercion_rules` | Dict | Coercion rules |
| `validation_rules` | Dict | Validation rules |
| `metadata` | Dict | Metadata (title, description) |
| `ownership` | Dict | Ownership information |
| `governance_rules` | Dict | Governance policies |
| `ontology` | Dict | Ontology annotations (version, fields) |
| `versions` | Dict | Component versions |

## Examples

```python
from pycharter import parse_contract_file

# Parse from file
metadata = parse_contract_file("contracts/user.yaml")

# Access components
print(f"Schema: {metadata.schema}")
print(f"Metadata: {metadata.metadata}")
print(f"Owner: {metadata.ownership}")
```

## See Also

- [Contract Builder](contract-builder.md)
- [Contracts Tutorial](../tutorials/contracts-validation.md)
