"""Synchronous wrappers for async DLQ operations.

Most pipeline code runs synchronously. These helpers call ``asyncio.run()``
at the boundary so callers do not need to manage an event loop.
"""

from __future__ import annotations

import asyncio
from typing import Any

from pycharter.etl_generator.dlq import DeadLetterQueue, DeadLetterRecord, DLQReason


def add_record_sync(
    dlq: DeadLetterQueue,
    pipeline_name: str,
    record_data: dict[str, Any],
    reason: DLQReason,
    error_message: str,
    error_type: str,
    stage: str,
    metadata: dict[str, Any] | None = None,
    record_id: str | None = None,
) -> DeadLetterRecord | None:
    """Add a failed record to the DLQ synchronously.

    Thin sync wrapper around :meth:`DeadLetterQueue.add_record`.

    Args:
        dlq: DeadLetterQueue instance.
        pipeline_name: Name of the pipeline.
        record_data: The failed record data.
        reason: Reason for failure.
        error_message: Error message.
        error_type: Error type.
        stage: ETL stage (extract, transform, load).
        metadata: Additional metadata.
        record_id: Optional record identifier.

    Returns:
        DeadLetterRecord if added, *None* if DLQ is disabled.
    """
    return asyncio.run(
        dlq.add_record(
            pipeline_name=pipeline_name,
            record_data=record_data,
            reason=reason,
            error_message=error_message,
            error_type=error_type,
            stage=stage,
            metadata=metadata,
            record_id=record_id,
        )
    )


def add_batch_sync(
    dlq: DeadLetterQueue,
    pipeline_name: str,
    batch: list[dict[str, Any]],
    reason: DLQReason,
    error_message: str,
    error_type: str,
    stage: str,
    metadata: dict[str, Any] | None = None,
) -> list[DeadLetterRecord]:
    """Add multiple failed records to the DLQ synchronously.

    Thin sync wrapper around :meth:`DeadLetterQueue.add_batch`.

    Args:
        dlq: DeadLetterQueue instance.
        pipeline_name: Name of the pipeline.
        batch: List of failed record dicts.
        reason: Reason for failure.
        error_message: Error message.
        error_type: Error type.
        stage: ETL stage (extract, transform, load).
        metadata: Additional metadata.

    Returns:
        List of DeadLetterRecord objects.
    """
    return asyncio.run(
        dlq.add_batch(
            pipeline_name=pipeline_name,
            batch=batch,
            reason=reason,
            error_message=error_message,
            error_type=error_type,
            stage=stage,
            metadata=metadata,
        )
    )


def retry_record_sync(
    dlq: DeadLetterQueue,
    record_id: str,
) -> bool:
    """Mark a DLQ record for retry synchronously.

    Thin sync wrapper around :meth:`DeadLetterQueue.retry_record`.

    Args:
        dlq: DeadLetterQueue instance.
        record_id: ID of the record to retry.

    Returns:
        *True* if the record was marked for retry, *False* otherwise.
    """
    return asyncio.run(dlq.retry_record(record_id))
