"""
SQLAlchemy model for field_relationships table.

Tracks relationships between fields (references, derived_from, same_as, etc.)
with optional JSONB metadata.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class FieldRelationshipModel(Base):
    """SQLAlchemy model for field_relationships table."""

    __tablename__ = "field_relationships"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_field_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.fields.id", ondelete="CASCADE"),
        nullable=False,
    )
    target_field_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.fields.id", ondelete="CASCADE"),
        nullable=False,
    )
    relationship_type = Column(String(50), nullable=False)
    metadata_ = Column("metadata", JSONB, nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = ({"schema": "pycharter"},)
