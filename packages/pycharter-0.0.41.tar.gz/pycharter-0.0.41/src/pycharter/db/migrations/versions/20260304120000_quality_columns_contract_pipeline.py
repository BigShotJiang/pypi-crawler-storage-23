"""Differentiate contract vs pipeline quality columns on pipeline_runs.

Revision ID: quality_contract_pipeline
Revises: add_pipeline_runs
Create Date: 2026-03-04 12:00:00.000000

Replaces generic quality_score/quality_passed with:
- contract_quality_score: from row-based (contract) quality; 0-100 or null.
- contract_quality_passed: from contract quality threshold check; null if not run.
- pipeline_quality_passed: from column/dataset (ETL) quality_checks; null if not run.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

from pycharter.db.migrations.schema_helper import get_schema

revision: str = "quality_contract_pipeline"
down_revision: str | None = "add_pipeline_runs"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Add new quality columns and drop old ones."""
    bind = op.get_bind()
    schema = get_schema(bind)

    op.add_column(
        "pipeline_runs",
        sa.Column("contract_quality_score", sa.Float(), nullable=True),
        schema=schema,
    )
    op.add_column(
        "pipeline_runs",
        sa.Column("contract_quality_passed", sa.Boolean(), nullable=True),
        schema=schema,
    )
    op.add_column(
        "pipeline_runs",
        sa.Column("pipeline_quality_passed", sa.Boolean(), nullable=True),
        schema=schema,
    )
    op.drop_column("pipeline_runs", "quality_score", schema=schema)
    op.drop_column("pipeline_runs", "quality_passed", schema=schema)


def downgrade() -> None:
    """Restore generic quality columns and drop new ones."""
    bind = op.get_bind()
    schema = get_schema(bind)

    op.add_column(
        "pipeline_runs",
        sa.Column("quality_score", sa.Float(), nullable=True),
        schema=schema,
    )
    op.add_column(
        "pipeline_runs",
        sa.Column("quality_passed", sa.Boolean(), nullable=True),
        schema=schema,
    )
    op.drop_column("pipeline_runs", "contract_quality_score", schema=schema)
    op.drop_column("pipeline_runs", "contract_quality_passed", schema=schema)
    op.drop_column("pipeline_runs", "pipeline_quality_passed", schema=schema)
