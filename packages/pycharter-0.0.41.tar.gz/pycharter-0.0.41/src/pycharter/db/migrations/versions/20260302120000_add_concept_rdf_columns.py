"""Add RDF-related columns to concepts table

Revision ID: add_concept_rdf_columns
Revises: add_wiki_tables
Create Date: 2026-03-02 12:00:00.000000

Adds uri, notation, and deprecated columns to the concepts table
to support JSON-LD / SKOS ontology management.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "add_concept_rdf_columns"
down_revision: str | None = "add_wiki_tables"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    bind = op.get_bind()
    is_sqlite = bind.dialect.name == "sqlite"
    schema_name = None if is_sqlite else "pycharter"

    op.add_column(
        "concepts",
        sa.Column("uri", sa.String(512), nullable=True),
        schema=schema_name,
    )
    op.add_column(
        "concepts",
        sa.Column("notation", sa.String(255), nullable=True),
        schema=schema_name,
    )
    op.add_column(
        "concepts",
        sa.Column(
            "deprecated",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("false") if not is_sqlite else sa.text("0"),
        ),
        schema=schema_name,
    )


def downgrade() -> None:
    bind = op.get_bind()
    is_sqlite = bind.dialect.name == "sqlite"
    schema_name = None if is_sqlite else "pycharter"

    op.drop_column("concepts", "deprecated", schema=schema_name)
    op.drop_column("concepts", "notation", schema=schema_name)
    op.drop_column("concepts", "uri", schema=schema_name)
