"""Add data version tracking to quality_metrics

Revision ID: 8b08d78068e3
Revises: f9995dc0f4b3
Create Date: 2025-12-17 16:49:15.000000

"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

from pycharter.db.migrations.schema_helper import get_schema

# revision identifiers, used by Alembic.
revision: str = "8b08d78068e3"
down_revision: str | None = "f9995dc0f4b3"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)
    # Add data version tracking columns to quality_metrics
    op.add_column(
        "quality_metrics",
        sa.Column("data_version", sa.String(length=255), nullable=True),
        schema=schema,
    )
    op.add_column(
        "quality_metrics",
        sa.Column("data_source", sa.String(length=500), nullable=True),
        schema=schema,
    )
    op.add_column(
        "quality_metrics",
        sa.Column("data_fingerprint", sa.String(length=64), nullable=True),
        schema=schema,
    )

    # Create indexes for new columns
    op.create_index(
        "ix_quality_metrics_data_version",
        "quality_metrics",
        ["data_version"],
        schema=schema,
    )
    op.create_index(
        "ix_quality_metrics_data_fingerprint",
        "quality_metrics",
        ["data_fingerprint"],
        schema=schema,
    )


def downgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)
    # Drop indexes
    op.drop_index(
        "ix_quality_metrics_data_fingerprint",
        table_name="quality_metrics",
        schema=schema,
    )
    op.drop_index(
        "ix_quality_metrics_data_version", table_name="quality_metrics", schema=schema
    )

    # Drop columns
    op.drop_column("quality_metrics", "data_fingerprint", schema=schema)
    op.drop_column("quality_metrics", "data_source", schema=schema)
    op.drop_column("quality_metrics", "data_version", schema=schema)
