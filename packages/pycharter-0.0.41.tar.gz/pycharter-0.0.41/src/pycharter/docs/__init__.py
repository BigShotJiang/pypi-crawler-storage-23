"""Documentation (MkDocs) CLI and helpers."""
