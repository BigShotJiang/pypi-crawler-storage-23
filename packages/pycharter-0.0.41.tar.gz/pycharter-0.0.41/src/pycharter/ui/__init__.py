"""
PyCharter UI module.

Provides standalone Next.js UI server for PyCharter.
"""

from __future__ import annotations

try:
    from pycharter.ui.build import build_ui
    from pycharter.ui.dev import run_dev_server
    from pycharter.ui.server import serve_ui

    __all__ = ["serve_ui", "run_dev_server", "build_ui"]
except (ImportError, ModuleNotFoundError):
    # UI dependencies not installed or ui module not available
    __all__ = []
