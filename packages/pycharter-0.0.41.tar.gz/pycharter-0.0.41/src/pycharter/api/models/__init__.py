"""
API request and response models.

This module contains Pydantic models for API request/response validation.
"""

from __future__ import annotations

from pycharter.api.models.contracts import (
    ContractBuildRequest,
    ContractBuildResponse,
    ContractParseRequest,
    ContractParseResponse,
)
from pycharter.api.models.metadata import (
    MetadataGetRequest,
    MetadataGetResponse,
    MetadataStoreRequest,
    MetadataStoreResponse,
    SchemaGetRequest,
    SchemaGetResponse,
    SchemaStoreRequest,
    SchemaStoreResponse,
)
from pycharter.api.models.schemas import (
    SchemaConvertRequest,
    SchemaConvertResponse,
    SchemaGenerateRequest,
    SchemaGenerateResponse,
)
from pycharter.api.models.validation import (
    ValidationBatchRequest,
    ValidationBatchResponse,
    ValidationRequest,
    ValidationResponse,
)

__all__ = [
    # Contracts
    "ContractParseRequest",
    "ContractParseResponse",
    "ContractBuildRequest",
    "ContractBuildResponse",
    # Metadata
    "MetadataStoreRequest",
    "MetadataStoreResponse",
    "MetadataGetRequest",
    "MetadataGetResponse",
    "SchemaStoreRequest",
    "SchemaStoreResponse",
    "SchemaGetRequest",
    "SchemaGetResponse",
    # Schemas
    "SchemaGenerateRequest",
    "SchemaGenerateResponse",
    "SchemaConvertRequest",
    "SchemaConvertResponse",
    # Validation
    "ValidationRequest",
    "ValidationResponse",
    "ValidationBatchRequest",
    "ValidationBatchResponse",
]
