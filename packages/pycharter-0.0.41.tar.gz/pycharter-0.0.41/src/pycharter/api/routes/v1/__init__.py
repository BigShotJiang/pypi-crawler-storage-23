"""
API v1 route handlers.

This module contains all FastAPI route handlers for API version 1.
All routers defined here are automatically included in the main application
with the `/api/v1` prefix.
"""

from __future__ import annotations

from pycharter.api.routes.v1 import (
    auth,
    contracts,
    docs,
    etl,
    evolution,
    metadata,
    quality,
    runs,
    schemas,
    settings,
    tracking,
    validation,
    validation_jobs,
)

# Export all routers for automatic inclusion in main.py
__all__ = [
    "auth",
    "contracts",
    "metadata",
    "quality",
    "schemas",
    "validation",
    "validation_jobs",
    "settings",
    "docs",
    "tracking",
    "evolution",
    "etl",
    "runs",
]
