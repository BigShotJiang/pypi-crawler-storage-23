"""Package data directory for PyCharter templates and resources."""

from __future__ import annotations
