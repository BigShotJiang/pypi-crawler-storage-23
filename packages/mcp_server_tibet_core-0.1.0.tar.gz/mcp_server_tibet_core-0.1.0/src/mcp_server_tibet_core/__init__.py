"""
MCP Server for tibet-core - Provenance for AI actions.

"Audit as a Precondition, Not an Afterthought."
"""

__version__ = "0.1.0"
