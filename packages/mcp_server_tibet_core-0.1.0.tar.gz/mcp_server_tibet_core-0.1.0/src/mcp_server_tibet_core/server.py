"""
MCP Server for tibet-core - The Trust Kernel for AI.

Every AI action, documented before execution.
Audit as a Precondition, Not an Afterthought.

Tools:
- tibet_create: Create provenance token for any action
- tibet_verify: Verify token integrity
- tibet_chain: Get provenance chain for a token
- tibet_export: Export audit trail
- tibet_wrap: Wrap an action with automatic provenance

One love, one fAmIly!
"""

import asyncio
import json
from typing import Any, Optional
from datetime import datetime

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent


server = Server("tibet-core")

# Global provider instance
_provider = None


def get_provider(actor: str = "mcp-client"):
    """Get or create TIBET provider."""
    global _provider
    if _provider is None or _provider.actor != actor:
        from tibet_core import Provider
        _provider = Provider(actor=actor)
    return _provider


def get_tools() -> list[Tool]:
    """Return available tools."""
    return [
        Tool(
            name="tibet_create",
            description="""Create a TIBET provenance token for any action.

Use this BEFORE performing important actions to document:
- WHAT you're doing (erin)
- WHY you're doing it (erachter)
- Dependencies involved (eraan)
- Current context (eromheen)

This creates an immutable audit record.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "description": "Name of the action (e.g., 'file_write', 'api_call', 'code_change')"
                    },
                    "erin": {
                        "type": "object",
                        "description": "What's IN the action - the content/data (e.g., {file: 'test.py', content: '...'})"
                    },
                    "erachter": {
                        "type": "string",
                        "description": "WHY - The intent behind this action (e.g., 'Fix bug in login flow')"
                    },
                    "eraan": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Dependencies/references attached (e.g., ['issue-123', 'pr-456'])"
                    },
                    "eromheen": {
                        "type": "object",
                        "description": "Context around it (e.g., {branch: 'main', user: 'jasper'})"
                    },
                    "actor": {
                        "type": "string",
                        "description": "Who/what is performing this action (default: 'mcp-client')"
                    }
                },
                "required": ["action", "erachter"]
            }
        ),
        Tool(
            name="tibet_verify",
            description="Verify a TIBET token's integrity. Returns True if token is valid and untampered.",
            inputSchema={
                "type": "object",
                "properties": {
                    "token_id": {
                        "type": "string",
                        "description": "The token ID to verify"
                    }
                },
                "required": ["token_id"]
            }
        ),
        Tool(
            name="tibet_chain",
            description="Get the full provenance chain for a token - see all related actions and their history.",
            inputSchema={
                "type": "object",
                "properties": {
                    "token_id": {
                        "type": "string",
                        "description": "The token ID to trace"
                    }
                },
                "required": ["token_id"]
            }
        ),
        Tool(
            name="tibet_export",
            description="Export the full audit trail as JSON. Use for compliance reporting or debugging.",
            inputSchema={
                "type": "object",
                "properties": {
                    "format": {
                        "type": "string",
                        "enum": ["json", "markdown", "summary"],
                        "description": "Export format (default: summary)"
                    },
                    "actor": {
                        "type": "string",
                        "description": "Filter by actor (optional)"
                    }
                }
            }
        ),
        Tool(
            name="tibet_list",
            description="List recent TIBET tokens with their actions and timestamps.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {
                        "type": "integer",
                        "description": "Max tokens to return (default: 10)"
                    }
                }
            }
        ),
        Tool(
            name="tibet_status",
            description="Get TIBET provider status - how many tokens, actors, etc.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
    ]


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    return get_tools()


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""

    try:
        if name == "tibet_create":
            return await handle_create(arguments)
        elif name == "tibet_verify":
            return await handle_verify(arguments)
        elif name == "tibet_chain":
            return await handle_chain(arguments)
        elif name == "tibet_export":
            return await handle_export(arguments)
        elif name == "tibet_list":
            return await handle_list(arguments)
        elif name == "tibet_status":
            return await handle_status(arguments)
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
    except ImportError as e:
        return [TextContent(type="text", text=f"Error: tibet-core not installed. Run: pip install tibet-core\n{e}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_create(args: dict[str, Any]) -> list[TextContent]:
    """Create a TIBET token."""
    actor = args.get("actor", "mcp-client")
    provider = get_provider(actor)

    action = args["action"]
    erin = args.get("erin", {})
    erachter = args["erachter"]
    eraan = args.get("eraan", [])
    eromheen = args.get("eromheen", {})

    # Add MCP context
    eromheen["mcp_server"] = "tibet-core"
    eromheen["timestamp"] = datetime.utcnow().isoformat()

    token = provider.create(
        action=action,
        erin=erin,
        erachter=erachter,
        eraan=eraan,
        eromheen=eromheen
    )

    output = [
        "# TIBET Token Created ✅",
        "",
        f"**Token ID:** `{token.id}`",
        f"**Action:** {action}",
        f"**Actor:** {actor}",
        f"**Intent:** {erachter}",
        "",
        "## Provenance Record",
        f"- **ERIN** (what): {json.dumps(erin) if erin else 'N/A'}",
        f"- **ERACHTER** (why): {erachter}",
        f"- **ERAAN** (refs): {', '.join(eraan) if eraan else 'N/A'}",
        f"- **EROMHEEN** (context): {json.dumps(eromheen)}",
        "",
        "*Audit as a Precondition. Action documented before execution.*"
    ]

    return [TextContent(type="text", text="\n".join(output))]


async def handle_verify(args: dict[str, Any]) -> list[TextContent]:
    """Verify a token."""
    provider = get_provider()
    token_id = args["token_id"]

    token = provider.get(token_id)
    if not token:
        return [TextContent(type="text", text=f"Token not found: {token_id}")]

    is_valid = token.verify()

    output = [
        f"# Token Verification: {'✅ VALID' if is_valid else '❌ INVALID'}",
        "",
        f"**Token ID:** `{token_id}`",
        f"**Action:** {token.action}",
        f"**Actor:** {token.actor}",
        f"**Created:** {token.timestamp}",
        f"**Integrity:** {'Verified - no tampering detected' if is_valid else 'FAILED - token may be corrupted'}",
    ]

    return [TextContent(type="text", text="\n".join(output))]


async def handle_chain(args: dict[str, Any]) -> list[TextContent]:
    """Get provenance chain."""
    provider = get_provider()
    token_id = args["token_id"]

    token = provider.get(token_id)
    if not token:
        return [TextContent(type="text", text=f"Token not found: {token_id}")]

    # Get chain
    chain = provider.chain(token_id)

    output = [
        "# Provenance Chain",
        "",
        f"**Root Token:** `{token_id}`",
        f"**Chain Length:** {len(chain)}",
        ""
    ]

    for i, t in enumerate(chain):
        output.append(f"## [{i+1}] {t.action}")
        output.append(f"- **ID:** `{t.id[:16]}...`")
        output.append(f"- **Actor:** {t.actor}")
        output.append(f"- **Intent:** {t.erachter}")
        output.append(f"- **Time:** {t.timestamp}")
        output.append("")

    return [TextContent(type="text", text="\n".join(output))]


async def handle_export(args: dict[str, Any]) -> list[TextContent]:
    """Export audit trail."""
    provider = get_provider()
    format_type = args.get("format", "summary")

    export_data = provider.export()

    if format_type == "json":
        return [TextContent(type="text", text=json.dumps(export_data, indent=2, default=str))]

    elif format_type == "markdown":
        output = ["# TIBET Audit Trail", "", f"**Exported:** {datetime.utcnow().isoformat()}", ""]
        for token in export_data.get("tokens", []):
            output.append(f"## {token.get('action', 'unknown')}")
            output.append(f"- ID: `{token.get('id', 'N/A')}`")
            output.append(f"- Actor: {token.get('actor', 'N/A')}")
            output.append(f"- Intent: {token.get('erachter', 'N/A')}")
            output.append("")
        return [TextContent(type="text", text="\n".join(output))]

    else:  # summary
        tokens = export_data.get("tokens", [])
        actors = set(t.get("actor") for t in tokens)
        actions = set(t.get("action") for t in tokens)

        output = [
            "# TIBET Audit Summary",
            "",
            f"**Total Tokens:** {len(tokens)}",
            f"**Unique Actors:** {len(actors)}",
            f"**Action Types:** {len(actions)}",
            "",
            "## Recent Actions",
        ]

        for token in tokens[-5:]:
            output.append(f"- `{token.get('action')}` by {token.get('actor')}")

        return [TextContent(type="text", text="\n".join(output))]


async def handle_list(args: dict[str, Any]) -> list[TextContent]:
    """List recent tokens."""
    provider = get_provider()
    limit = args.get("limit", 10)

    export_data = provider.export()
    tokens = export_data.get("tokens", [])[-limit:]

    if not tokens:
        return [TextContent(type="text", text="No tokens found. Create one with tibet_create.")]

    output = [f"# Recent TIBET Tokens ({len(tokens)})", ""]

    for t in reversed(tokens):
        output.append(f"**{t.get('action')}** - `{t.get('id', 'N/A')[:12]}...`")
        output.append(f"  Actor: {t.get('actor')} | Intent: {t.get('erachter', 'N/A')[:50]}")
        output.append("")

    return [TextContent(type="text", text="\n".join(output))]


async def handle_status(args: dict[str, Any]) -> list[TextContent]:
    """Get provider status."""
    provider = get_provider()
    export_data = provider.export()
    tokens = export_data.get("tokens", [])

    output = [
        "# TIBET Provider Status",
        "",
        f"**Version:** tibet-core 0.2.0",
        f"**Actor:** {provider.actor}",
        f"**Tokens:** {len(tokens)}",
        f"**Store:** {type(provider.store).__name__}",
        "",
        "## Philosophy",
        "*Audit as a Precondition, Not an Afterthought.*",
        "",
        "Every action documented. Every intent recorded.",
        "The Trust Kernel for AI.",
    ]

    return [TextContent(type="text", text="\n".join(output))]


def main():
    """Run the MCP server."""
    asyncio.run(run_server())


async def run_server():
    """Run the server with stdio transport."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    main()
