# mcp-server-tibet-core

**The Trust Kernel for AI - MCP Server**

> Audit as a Precondition, Not an Afterthought.

MCP (Model Context Protocol) server that gives Claude, Codex, Gemini, and other AI assistants full TIBET provenance capabilities.

## Installation

```bash
pip install mcp-server-tibet-core
```

## Quick Start

Add to your Claude Desktop config (`~/.config/claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "tibet-core": {
      "command": "mcp-server-tibet-core"
    }
  }
}
```

Restart Claude Desktop. Now your AI can create provenance tokens for every action!

## Available Tools

| Tool | Description |
|------|-------------|
| `tibet_create` | Create a provenance token BEFORE any action |
| `tibet_verify` | Verify a token's integrity |
| `tibet_chain` | Get full provenance chain for a token |
| `tibet_export` | Export audit trail (JSON/markdown/summary) |
| `tibet_list` | List recent tokens |
| `tibet_status` | Get TIBET provider status |

## TIBET Provenance Model

Every action is documented with four dimensions:

- **ERIN** (what's IN) - The content/data of the action
- **ERAAN** (attached) - Dependencies and references
- **EROMHEEN** (around) - Context and environment
- **ERACHTER** (behind) - The WHY - intent and purpose

## Example Usage

When your AI performs an action, it can now document it:

```
AI: I'll create a TIBET token before modifying this file.

[tibet_create]
- action: "file_write"
- erin: {"file": "config.py", "changes": "Added API key validation"}
- erachter: "Improve security by validating API keys before use"
- eraan: ["issue-123", "security-audit-2024"]
- eromheen: {"branch": "main", "user": "jasper"}

Token created: tbt_abc123...
```

Now you have an immutable audit record of what the AI did and why.

## Why TIBET?

- **Compliance Ready**: AI Act, NIS2, GDPR, DORA
- **Audit Trail**: Every action documented before execution
- **Trust Kernel**: Like TPM for hardware, but for AI actions
- **Enterprise Grade**: Used by 1,162+ enterprise mirrors

## Links

- [TIBET Core](https://pypi.org/project/tibet-core/)
- [TIBET Audit](https://pypi.org/project/tibet-audit/)
- [Humotica](https://humotica.com)

## Philosophy

> "Don't ask what your AI did. Know before it acts."

Every AI action, documented before execution.
Compliance built-in, not bolted-on.
One kernel. Every AI. Full provenance.

---

**One love, one fAmIly!**

MIT License - Humotica 2024-2026
