---
name: Faithfulness gap
about: Report deviations vs. the Nested Learning / HOPE specs
title: "[Faithfulness] "
labels: ["faithfulness", "needs-triage"]
assignees: []
---

## Summary
Describe the suspected deviation (cite paper section/equation).

## Evidence
- Config(s) / checkpoints affected
- Logs / screenshots / metrics
- Steps to reproduce

## Environment
- OS:
- Python:
- Torch:
- Backend (`cpu` / `cuda` / `mps` / `rocm`):
- GPU/accelerator model (if any):

If using ROCm: this project currently treats ROCm support as best-effort. Include HIP/ROCm version and exact torch build.

## Expected behavior
What should happen according to the paper?

## Additional context
Add any extra notes, e.g., suggested fix or related PRs.
