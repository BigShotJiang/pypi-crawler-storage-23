"""Discovery Engine Python SDK."""

import asyncio
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import httpx

try:
    import pandas as pd
except ImportError:
    pd = None

from discovery.types import (
    Column,
    CorrelationEntry,
    EngineResult,
    FeatureImportance,
    FeatureImportanceScore,
    FileInfo,
    Pattern,
    PatternGroup,
    RunStatus,
    Summary,
)


class Engine:
    """Engine for the Discovery Engine API."""

    # Production API URL (can be overridden via DISCOVERY_API_URL env var for testing)
    # This points to the Modal-deployed FastAPI API
    _DEFAULT_BASE_URL = "https://leap-labs-production--discovery-api.modal.run"

    # Dashboard URL for web UI and /api/* endpoints
    _DEFAULT_DASHBOARD_URL = "https://disco.leap-labs.com"

    def __init__(self, api_key: str):
        """
        Initialize the Discovery Engine.

        Args:
            api_key: Your API key
        """

        print("Initializing Discovery Engine...")
        self.api_key = api_key
        # Use DISCOVERY_API_URL env var if set (for testing/custom deployments),
        # otherwise use the production default
        self.base_url = os.getenv("DISCOVERY_API_URL", self._DEFAULT_BASE_URL).rstrip("/")
        # Dashboard URL for /api/* endpoints and web UI links
        self.dashboard_url = os.getenv(
            "DISCOVERY_DASHBOARD_URL", self._DEFAULT_DASHBOARD_URL
        ).rstrip("/")
        self._organization_id: Optional[str] = None
        self._client: Optional[httpx.AsyncClient] = None
        self._dashboard_client: Optional[httpx.AsyncClient] = None
        self._org_fetched = False

    async def _ensure_organization_id(self) -> str:
        """
        Ensure we have an organization ID, fetching from API if needed.

        The organization ID is required for API requests to identify which
        organization the user belongs to (multi-tenancy support).

        Returns:
            Organization ID string

        Raises:
            ValueError: If no organization is found or API request fails
        """
        if self._organization_id:
            return self._organization_id

        if not self._org_fetched:
            # Fetch user's organizations and use the first one
            try:
                orgs = await self.get_organizations()
                if orgs:
                    self._organization_id = orgs[0]["id"]
            except ValueError as e:
                # Re-raise with more context
                raise ValueError(
                    f"Failed to fetch organization: {e}. "
                    "Please ensure your API key is valid and you belong to an organization."
                ) from e
            self._org_fetched = True

        if not self._organization_id:
            raise ValueError(
                "No organization found for your account. "
                "Please contact support if this issue persists."
            )

        return self._organization_id

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            headers = {"Authorization": f"Bearer {self.api_key}"}
            # Use longer timeouts to support large file uploads (up to 1GB)
            # connect: 30s, read: 5min, write: 30min (for uploads), pool: 30s
            timeout = httpx.Timeout(
                connect=30.0,
                read=300.0,
                write=1800.0,
                pool=30.0,
            )
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=headers,
                timeout=timeout,
            )
        return self._client

    async def _get_client_with_org(self) -> httpx.AsyncClient:
        """
        Get HTTP client with organization header set.

        The organization ID is required for API requests to identify which
        organization the user belongs to (multi-tenancy support).
        """
        client = await self._get_client()

        # Ensure we have an organization ID
        org_id = await self._ensure_organization_id()

        # Set the organization header
        client.headers["X-Organization-ID"] = org_id

        return client

    async def _get_dashboard_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client for dashboard API calls."""
        if self._dashboard_client is None:
            headers = {"Authorization": f"Bearer {self.api_key}"}
            # Use longer timeouts to support large file uploads (up to 1GB)
            # connect: 30s, read: 5min, write: 30min (for uploads), pool: 30s
            timeout = httpx.Timeout(
                connect=30.0,
                read=300.0,
                write=1800.0,
                pool=30.0,
            )
            self._dashboard_client = httpx.AsyncClient(
                base_url=self.dashboard_url,
                headers=headers,
                timeout=timeout,
            )
        return self._dashboard_client

    async def close(self):
        """Close the HTTP clients."""
        if self._client:
            await self._client.aclose()
            self._client = None
        if self._dashboard_client:
            await self._dashboard_client.aclose()
            self._dashboard_client = None

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    async def get_organizations(self) -> List[Dict[str, Any]]:
        """
        Get the organizations you belong to.

        Returns:
            List of organizations with id, name, and slug

        Raises:
            ValueError: If the API request fails
        """
        client = await self._get_client()

        try:
            response = await client.get("/v1/me/organizations")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            raise ValueError(
                f"Failed to fetch organizations: {e.response.status_code} {e.response.text}"
            ) from e
        except httpx.RequestError as e:
            raise ValueError(f"Failed to connect to API: {str(e)}") from e

    async def create_dataset(
        self,
        title: Optional[str] = None,
        description: Optional[str] = None,
        total_rows: int = 0,
        dataset_size_mb: Optional[float] = None,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a dataset record.

        Args:
            title: Dataset title
            description: Dataset description
            total_rows: Number of rows in the dataset
            dataset_size_mb: Dataset size in MB
            author: Optional author attribution
            source_url: Optional source URL

        Returns:
            Dataset record with ID
        """
        client = await self._get_client_with_org()

        response = await client.post(
            "/v1/run-datasets",
            json={
                "title": title,
                "description": description,
                "total_rows": total_rows,
                "dataset_size_mb": dataset_size_mb,
                "author": author,
                "source_url": source_url,
            },
        )
        response.raise_for_status()
        return response.json()

    async def create_file_record(self, dataset_id: str, file_info: FileInfo) -> Dict[str, Any]:
        """
        Create a file record for a dataset.

        Args:
            dataset_id: Dataset ID
            file_info: FileInfo metadata for the dataset file

        Returns:
            File record with ID
        """
        client = await self._get_client_with_org()

        response = await client.post(
            f"/v1/run-datasets/{dataset_id}/files",
            json={
                "mime_type": file_info.mime_type,
                "file_path": file_info.file_path,
                "file_hash": file_info.file_hash,
                "file_size": file_info.file_size,
            },
        )
        response.raise_for_status()
        return response.json()

    async def create_columns(
        self, dataset_id: str, columns: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Create column records for a dataset.

        Args:
            dataset_id: Dataset ID
            columns: List of column definitions with full metadata

        Returns:
            List of column records with IDs
        """
        client = await self._get_client_with_org()

        response = await client.post(
            f"/v1/run-datasets/{dataset_id}/columns",
            json=columns,
        )
        response.raise_for_status()
        return response.json()

    async def create_run(
        self,
        dataset_id: str,
        target_column_id: str,
        task: str = "regression",
        depth_iterations: int = 1,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        auto_report_use_llm_evals: bool = True,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
        is_test: bool = False,
    ) -> Dict[str, Any]:
        """
        Create a run and enqueue it for processing.

        Args:
            dataset_id: Dataset ID
            target_column_id: Target column ID
            task: Task type (regression, binary_classification, multiclass_classification)
            depth_iterations: Number of iterative feature removal cycles (1 = fastest)
            visibility: Dataset visibility ("public" or "private")
            timeseries_groups: Optional list of timeseries column groups
            target_column_override: Optional override for target column name
            auto_report_use_llm_evals: Use LLM evaluations
            author: Optional dataset author
            source_url: Optional source URL
            is_test: Skip email notifications and delete results on completion

        Returns:
            Run record with ID and job information
        """
        client = await self._get_client_with_org()

        payload = {
            "run_target_column_id": target_column_id,
            "task": task,
            "depth_iterations": depth_iterations,
            "visibility": visibility,
            "auto_report_use_llm_evals": auto_report_use_llm_evals,
            "is_test": is_test,
        }

        if timeseries_groups:
            payload["timeseries_groups"] = timeseries_groups
        if target_column_override:
            payload["target_column_override"] = target_column_override
        if author:
            payload["author"] = author
        if source_url:
            payload["source_url"] = source_url

        response = await client.post(
            f"/v1/run-datasets/{dataset_id}/runs",
            json=payload,
        )
        response.raise_for_status()
        return response.json()

    async def get_results(self, run_id: str) -> EngineResult:
        """
        Get complete analysis results for a run.

        This returns all data that the Discovery dashboard displays:
        - LLM-generated summary with key insights
        - All discovered patterns with conditions, citations, and explanations
        - Column/feature information with statistics and importance scores
        - Correlation matrix
        - Global feature importance

        Args:
            run_id: The run ID

        Returns:
            EngineResult with complete analysis data
        """
        # Use dashboard client for /api/* endpoints (hosted on Next.js dashboard, not Modal API)
        dashboard_client = await self._get_dashboard_client()

        # Call dashboard API for results
        response = await dashboard_client.get(f"/api/runs/{run_id}/results")
        response.raise_for_status()

        data = response.json()
        return self._parse_analysis_result(data)

    async def get_run_status(self, run_id: str) -> RunStatus:
        """
        Get the status of a run.

        Args:
            run_id: Run ID

        Returns:
            RunStatus with current status information
        """
        client = await self._get_client_with_org()

        response = await client.get(f"/v1/runs/{run_id}/results")
        response.raise_for_status()

        data = response.json()
        return RunStatus(
            run_id=data["run_id"],
            status=data["status"],
            job_id=data.get("job_id"),
            job_status=data.get("job_status"),
            error_message=data.get("error_message"),
        )

    async def wait_for_completion(
        self,
        run_id: str,
        poll_interval: float = 5.0,
        timeout: Optional[float] = None,
    ) -> EngineResult:
        """
        Wait for a run to complete and return the results.

        Args:
            run_id: Run ID
            poll_interval: Seconds between status checks (default: 5)
            timeout: Maximum seconds to wait (None = no timeout)

        Returns:
            EngineResult with complete analysis data

        Raises:
            TimeoutError: If the run doesn't complete within the timeout
            RuntimeError: If the run fails
        """
        start_time = time.time()
        last_status = None
        poll_count = 0

        print(f"⏳ Waiting for run {run_id} to complete...")

        while True:
            result = await self.get_results(run_id)
            elapsed = time.time() - start_time
            poll_count += 1

            # Log status changes or every 3rd poll (every ~15 seconds)
            if result.status != last_status or poll_count % 3 == 0:
                status_msg = f"Status: {result.status}"
                if result.job_status:
                    status_msg += f" (job: {result.job_status})"
                if elapsed > 0:
                    status_msg += f" | Elapsed: {elapsed:.1f}s"
                print(f"  {status_msg}")

            last_status = result.status

            if result.status == "completed":
                print(f"✓ Run completed in {elapsed:.1f}s")
                return result
            elif result.status == "failed":
                error_msg = result.error_message or "Unknown error"
                print(f"✗ Run failed: {error_msg}")
                raise RuntimeError(f"Run {run_id} failed: {error_msg}")

            if timeout and elapsed > timeout:
                raise TimeoutError(f"Run {run_id} did not complete within {timeout} seconds")

            await asyncio.sleep(poll_interval)

    async def _presign_and_upload(
        self,
        file_content: bytes,
        filename: str,
        mime_type: str,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Upload a file using presigned URL (bypasses body size limits).

        This uses a two-step process:
        1. Get presigned URL from dashboard API
        2. Upload directly to GCS using the presigned URL
        3. Finalize the upload to validate and process the file

        Args:
            file_content: File bytes
            filename: Original filename
            mime_type: MIME type of the file

        Returns:
            Tuple of (presign data, finalize data)
        """
        dashboard_client = await self._get_dashboard_client()
        file_size = len(file_content)

        # Step 1: Get presigned URL
        presign_response = await dashboard_client.post(
            "/api/data/upload/presign",
            json={
                "fileName": filename,
                "contentType": mime_type,
                "fileSize": file_size,
            },
        )

        if presign_response.status_code >= 400:
            try:
                error_data = presign_response.json()
                error_message = error_data.get("error", presign_response.text)
            except Exception:
                error_message = presign_response.text
            raise ValueError(f"Presign error ({presign_response.status_code}): {error_message}")

        presign_data = presign_response.json()
        upload_url = presign_data["uploadUrl"]
        key = presign_data["key"]
        upload_token = presign_data["uploadToken"]

        # Step 2: Upload directly to GCS using presigned URL
        # Use a separate client for direct GCS upload (no auth headers needed)
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(connect=30.0, read=300.0, write=1800.0, pool=30.0)
        ) as upload_client:
            upload_response = await upload_client.put(
                upload_url,
                content=file_content,
                headers={"Content-Type": mime_type},
            )

            if upload_response.status_code >= 400:
                raise ValueError(
                    f"Direct upload failed ({upload_response.status_code}): {upload_response.text}"
                )

        # Step 3: Finalize the upload
        finalize_response = await dashboard_client.post(
            "/api/data/upload/finalize",
            json={
                "key": key,
                "uploadToken": upload_token,
            },
        )

        if finalize_response.status_code >= 400:
            try:
                error_data = finalize_response.json()
                error_message = error_data.get("error", finalize_response.text)
                if "issues" in error_data:
                    errors = error_data["issues"].get("errors", [])
                    if errors:
                        error_message = errors[0].get("message", error_message)
            except Exception:
                error_message = finalize_response.text
            raise ValueError(f"Finalize error ({finalize_response.status_code}): {error_message}")

        return presign_data, finalize_response.json()

    async def _upload_file_direct(
        self,
        file_content: bytes,
        filename: str,
        mime_type: str,
    ) -> Dict[str, Any]:
        """
        Upload a file using presigned URL (bypasses body size limits).

        Returns:
            Dict with upload result including key, columns, rowCount, etc.
        """
        _, finalize_data = await self._presign_and_upload(
            file_content=file_content,
            filename=filename,
            mime_type=mime_type,
        )
        return finalize_data

    def _prepare_upload(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        filename: Optional[str] = None,
        title: Optional[str] = None,
        log: bool = False,
    ) -> Tuple[bytes, str, str, float]:
        if pd is not None and isinstance(file, pd.DataFrame):
            import io

            if log:
                print(f"📊 Preparing DataFrame ({len(file)} rows, {len(file.columns)} columns)...")
            buffer = io.BytesIO()
            file.to_csv(buffer, index=False)
            buffer.seek(0)
            file_content = buffer.getvalue()
            resolved_filename = filename or ((title + ".csv") if title else "dataset.csv")
            mime_type = "text/csv"
        else:
            file_path = Path(file)
            if not file_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")
            if log:
                print(f"📁 Reading file: {file_path.name}...")
            file_content = file_path.read_bytes()
            resolved_filename = filename or file_path.name
            mime_type = (
                "text/csv" if file_path.suffix == ".csv" else "application/vnd.apache.parquet"
            )

        file_size_mb = len(file_content) / (1024 * 1024)
        if log:
            print(f"  File size: {file_size_mb:.2f} MB")
        return file_content, resolved_filename, mime_type, file_size_mb

    async def run_async(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        task: Optional[str] = None,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        auto_report_use_llm_evals: bool = True,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
        wait: bool = False,
        wait_timeout: Optional[float] = None,
        is_test: bool = False,
        **kwargs,
    ) -> EngineResult:
        """
        Run analysis on a dataset (async).

        This method calls the dashboard API which handles the entire workflow:
        file upload, dataset creation, column inference, run creation, and credit deduction.

        Args:
            file: File path, Path object, or pandas DataFrame
            target_column: Name of the target column
            depth_iterations: Analysis depth — number of iterative feature-removal
                cycles (default 1). Higher values find more subtle patterns but use
                more credits. The maximum useful value is ``num_columns - 2``; values
                above that are capped server-side. Public runs are always depth 1.
            title: Optional dataset title
            description: Optional dataset description
            column_descriptions: Optional dict mapping column names to descriptions
            excluded_columns: Optional list of column names to exclude from analysis
            task: Task type (regression, binary, multiclass) - auto-detected if None
            visibility: Dataset visibility ("public" or "private", default: "public").
                Public runs are free but always use depth 1. Private runs require
                credits and support higher depth values.
            timeseries_groups: Optional list of timeseries column groups
            target_column_override: Optional override for target column name
            auto_report_use_llm_evals: Use LLM evaluations (default: True)
            author: Optional dataset author
            source_url: Optional source URL
            wait: If True, wait for analysis to complete and return full results
            wait_timeout: Maximum seconds to wait for completion (only if wait=True)
            is_test: Skip email notifications and delete results on completion

        Returns:
            EngineResult with run_id and (if wait=True) complete results
        """
        file_content, filename, mime_type, _ = self._prepare_upload(
            file=file,
            title=title,
            log=True,
        )

        # Warn if depth > 1 with public visibility (server will cap to 1)
        if depth_iterations > 1 and visibility == "public":
            print(
                "⚠️  Public runs are limited to depth 1. "
                "Set visibility='private' for deeper analysis (requires credits)."
            )
            depth_iterations = 1

        print(
            f"🚀 Uploading file and creating run (depth: {depth_iterations}, target: {target_column})..."
        )

        # Step 1: Upload file using presigned URL
        print("  Uploading to storage...")
        upload_result = await self._upload_file_direct(file_content, filename, mime_type)

        if not upload_result.get("ok"):
            errors = upload_result.get("issues", {}).get("errors", [])
            error_msg = errors[0].get("message") if errors else "Upload failed"
            raise ValueError(f"Upload failed: {error_msg}")

        uploaded_file = upload_result["file"]
        columns = upload_result.get("columns", [])

        # Step 2: Create the report using the uploaded file
        print("  Creating analysis run...")
        dashboard_client = await self._get_dashboard_client()

        # Build the request payload for report creation
        # This mirrors what the frontend does after upload
        report_payload: Dict[str, Any] = {
            "file": {
                "key": uploaded_file["key"],
                "name": uploaded_file["name"],
                "size": uploaded_file["size"],
                "fileHash": uploaded_file["fileHash"],
            },
            "columns": columns,
            "targetColumn": target_column,
            "depthIterations": depth_iterations,
            "isPublic": visibility == "public",
        }

        if title:
            report_payload["title"] = title
        if description:
            report_payload["description"] = description
        if author:
            report_payload["author"] = author
        if source_url:
            report_payload["sourceUrl"] = source_url
        if column_descriptions:
            # Apply column descriptions to the columns
            for col in report_payload["columns"]:
                if col["name"] in column_descriptions:
                    col["description"] = column_descriptions[col["name"]]
        if excluded_columns:
            # Mark excluded columns as disabled
            for col in report_payload["columns"]:
                if col["name"] in excluded_columns and col["name"] != target_column:
                    col["enabled"] = False
        if timeseries_groups:
            report_payload["columnGroups"] = timeseries_groups
        if is_test:
            report_payload["isTest"] = True

        # Call the report creation endpoint
        response = await dashboard_client.post(
            "/api/reports/create-from-upload",
            json=report_payload,
        )

        # Extract error message from response body for better error reporting
        if response.status_code >= 400:
            try:
                error_data = response.json()
                error_message = error_data.get("error", response.text)
            except Exception:
                error_message = response.text

            # Provide actionable guidance for common errors
            if "insufficient credits" in error_message.lower():
                print(
                    "\n⚠️  Insufficient credits for this run.\n"
                    "   Options:\n"
                    "   1. Set visibility='public' for a free run (depth is limited to 1)\n"
                    "   2. Purchase credits or upgrade your plan at https://disco.leap-labs.com/account\n"
                )

            raise ValueError(f"API error ({response.status_code}): {error_message}")

        result_data = response.json()

        # Check if duplicate
        if result_data.get("duplicate"):
            # For duplicates, get the run_id and fetch results
            report_id = result_data.get("report_id")
            run_id = result_data.get("run_id")

            if not report_id or not run_id:
                raise ValueError("Duplicate report found but missing report_id or run_id")

            print(f"ℹ️  Duplicate report found (run_id: {run_id})")

            # Construct dashboard URL for the processing page
            progress_url = f"{self.dashboard_url}/reports/new/{run_id}/processing"
            print(f"🔗 View progress: {progress_url}")

            # If wait is True, fetch the full results for the existing report
            if wait:
                return await self.get_results(run_id)

            # Otherwise return a minimal result with the run_id
            return EngineResult(
                run_id=run_id,
                status="completed",
                report_id=report_id,
            )

        run_id = result_data["run_id"]
        print(f"✓ Run created: {run_id}")

        # Construct dashboard URL for the processing page
        progress_url = f"{self.dashboard_url}/reports/new/{run_id}/processing"
        print(f"🔗 View progress: {progress_url}")

        if wait:
            # Wait for completion and return full results
            return await self.wait_for_completion(run_id, timeout=wait_timeout)

        # Return minimal result with pending status
        return EngineResult(
            run_id=run_id,
            status="pending",
        )

    def run(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        task: Optional[str] = None,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        auto_report_use_llm_evals: bool = True,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
        wait: bool = False,
        wait_timeout: Optional[float] = None,
        is_test: bool = False,
        **kwargs,
    ) -> EngineResult:
        """
        Run analysis on a dataset (synchronous wrapper).

        This is a synchronous wrapper around run_async().

        Args:
            file: File path, Path object, or pandas DataFrame
            target_column: Name of the target column
            depth_iterations: Analysis depth — number of iterative feature-removal
                cycles (default 1). Higher values find more subtle patterns but use
                more credits. The maximum useful value is ``num_columns - 2``; values
                above that are capped server-side. Public runs are always depth 1.
            title: Optional dataset title
            description: Optional dataset description
            column_descriptions: Optional dict mapping column names to descriptions
            excluded_columns: Optional list of column names to exclude from analysis
            task: Task type (regression, binary_classification, multiclass_classification) - auto-detected if None
            visibility: Dataset visibility ("public" or "private", default: "public").
                Public runs are free but always use depth 1. Private runs require
                credits and support higher depth values.
            timeseries_groups: Optional list of timeseries column groups
            target_column_override: Optional override for target column name
            auto_report_use_llm_evals: Use LLM evaluations (default: True)
            author: Optional dataset author
            source_url: Optional source URL
            wait: If True, wait for analysis to complete and return full results
            wait_timeout: Maximum seconds to wait for completion (only if wait=True)
            is_test: Skip email notifications and delete results on completion
            **kwargs: Additional arguments passed to run_async()

        Returns:
            EngineResult with run_id and (if wait=True) complete results
        """
        coro = self.run_async(
            file,
            target_column,
            depth_iterations,
            title=title,
            description=description,
            column_descriptions=column_descriptions,
            excluded_columns=excluded_columns,
            task=task,
            visibility=visibility,
            timeseries_groups=timeseries_groups,
            target_column_override=target_column_override,
            auto_report_use_llm_evals=auto_report_use_llm_evals,
            author=author,
            source_url=source_url,
            wait=wait,
            wait_timeout=wait_timeout,
            is_test=is_test,
            **kwargs,
        )

        # Try to run the coroutine
        # If we're in a Jupyter notebook with a running event loop, asyncio.run() will fail
        try:
            return asyncio.run(coro)
        except RuntimeError as e:
            # Check if the error is about a running event loop
            if "cannot be called from a running event loop" in str(e).lower():
                # We're in a Jupyter/IPython environment with a running event loop
                # Try to use nest_asyncio if available
                try:
                    import nest_asyncio

                    # Apply nest_asyncio (it's safe to call multiple times)
                    nest_asyncio.apply()
                    # Now we can use asyncio.run() even with a running loop
                    return asyncio.run(coro)
                except ImportError:
                    raise RuntimeError(
                        "Cannot use engine.run() in a Jupyter notebook or environment with a running event loop. "
                        "Please use 'await engine.run_async(...)' instead, or install nest_asyncio "
                        "(pip install nest-asyncio) to enable nested event loops."
                    ) from e
            # Re-raise if it's a different RuntimeError
            raise

    def _parse_analysis_result(self, data: Dict[str, Any]) -> EngineResult:
        """Parse API response into EngineResult dataclass."""
        # Parse summary
        summary = None
        if data.get("summary"):
            summary = self._parse_summary(data["summary"])

        # Parse patterns
        patterns = []
        for p in data.get("patterns", []):
            patterns.append(
                Pattern(
                    id=p["id"],
                    task=p.get("task", "regression"),
                    target_column=p.get("target_column", ""),
                    target_change_direction=p.get("target_change_direction", "max"),
                    p_value=p.get("p_value", 0),
                    conditions=p.get("conditions", []),
                    abs_target_change=p.get("abs_target_change", 0),
                    support_count=p.get("support_count", 0),
                    support_percentage=p.get("support_percentage", 0),
                    novelty_type=p.get("novelty_type", "confirmatory"),
                    target_score=p.get("target_score", 0),
                    target_class=p.get("target_class"),
                    target_mean=p.get("target_mean"),
                    target_std=p.get("target_std"),
                    description=p.get("description", ""),
                    novelty_explanation=p.get("novelty_explanation", ""),
                    citations=p.get("citations", []),
                    p_value_raw=p.get("p_value_raw"),
                )
            )

        # Parse columns
        columns = []
        for c in data.get("columns", []):
            columns.append(
                Column(
                    id=c["id"],
                    name=c["name"],
                    display_name=c.get("display_name", c["name"]),
                    type=c.get("type", "continuous"),
                    data_type=c.get("data_type", "float"),
                    enabled=c.get("enabled", True),
                    description=c.get("description"),
                    mean=c.get("mean"),
                    median=c.get("median"),
                    std=c.get("std"),
                    min=c.get("min"),
                    max=c.get("max"),
                    iqr_min=c.get("iqr_min"),
                    iqr_max=c.get("iqr_max"),
                    mode=c.get("mode"),
                    approx_unique=c.get("approx_unique"),
                    null_percentage=c.get("null_percentage"),
                    feature_importance_score=c.get("feature_importance_score"),
                )
            )

        # Parse correlation matrix
        correlation_matrix = []
        for entry in data.get("correlation_matrix", []):
            correlation_matrix.append(
                CorrelationEntry(
                    feature_x=entry["feature_x"],
                    feature_y=entry["feature_y"],
                    value=entry["value"],
                )
            )

        # Parse feature importance
        feature_importance = None
        if data.get("feature_importance"):
            fi = data["feature_importance"]
            scores = [
                FeatureImportanceScore(feature=s["feature"], score=s["score"])
                for s in fi.get("scores", [])
            ]
            feature_importance = FeatureImportance(
                kind=fi.get("kind", "global"),
                baseline=fi.get("baseline", 0),
                scores=scores,
            )

        return EngineResult(
            run_id=data["run_id"],
            report_id=data.get("report_id"),
            status=data.get("status", "unknown"),
            dataset_title=data.get("dataset_title"),
            dataset_description=data.get("dataset_description"),
            total_rows=data.get("total_rows"),
            target_column=data.get("target_column"),
            task=data.get("task"),
            summary=summary,
            patterns=patterns,
            columns=columns,
            correlation_matrix=correlation_matrix,
            feature_importance=feature_importance,
            job_id=data.get("job_id"),
            job_status=data.get("job_status"),
            error_message=data.get("error_message"),
        )

    def _parse_summary(self, data: Dict[str, Any]) -> Summary:
        """Parse summary data into Summary dataclass."""
        # Note: data_insights is no longer returned - use feature_importance and correlation_matrix directly

        return Summary(
            overview=data.get("overview", ""),
            key_insights=data.get("key_insights", []),
            novel_patterns=PatternGroup(
                pattern_ids=data.get("novel_patterns", {}).get("pattern_ids", []),
                explanation=data.get("novel_patterns", {}).get("explanation", ""),
            ),
            # data_insights and statistically_significant removed
            selected_pattern_id=data.get("selected_pattern_id"),
        )
