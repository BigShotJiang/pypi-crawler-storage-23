"""Demo module providing access to example plant data."""

try:
    import sunpeek_exampledata

    DEMO_DATA_AVAILABLE = True

    DEMO_CONFIG_PATH = sunpeek_exampledata.DEMO_CONFIG_PATH
    DEMO_DATA_PATH_2DAYS = sunpeek_exampledata.DEMO_DATA_PATH_2DAYS
    DEMO_DATA_PATH_1MONTH = sunpeek_exampledata.DEMO_DATA_PATH_1MONTH
    DEMO_DATA_PATH_1YEAR = sunpeek_exampledata.DEMO_DATA_PATH_1YEAR
    DEMO_FLUID_RHO_PATH = sunpeek_exampledata.DEMO_FLUID_RHO_PATH
    DEMO_FLUID_CP_PATH = sunpeek_exampledata.DEMO_FLUID_CP_PATH

except ModuleNotFoundError:
    DEMO_DATA_AVAILABLE = False

    _DEMO_PATHS = frozenset({
        'DEMO_CONFIG_PATH',
        'DEMO_DATA_PATH_2DAYS',
        'DEMO_DATA_PATH_1MONTH',
        'DEMO_DATA_PATH_1YEAR',
        'DEMO_FLUID_RHO_PATH',
        'DEMO_FLUID_CP_PATH',
    })

    def __getattr__(name: str):
        if name in _DEMO_PATHS:
            raise ImportError(
                f"Demo data not available. Install with: pip install sunpeek[demo]"
            )
        raise AttributeError(f"module 'sunpeek.demo' has no attribute '{name}'")
