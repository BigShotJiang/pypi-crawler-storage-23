"""Guardrail management module."""

from lumenova_beacon.guardrails.models import Guardrail

__all__ = ['Guardrail']
