"""Lumenova Beacon SDK - A Python SDK for observability tracing with OpenTelemetry-compatible span export."""

from lumenova_beacon.core.client import BeaconClient, get_client
from lumenova_beacon.core.config import BeaconConfig
from lumenova_beacon.tracing.decorators import trace

__version__ = '0.1.0'

__all__ = [
    # Core client
    'BeaconClient',
    'BeaconConfig',
    'get_client',
    'trace',
    # LangChain integration (lazy-loaded)
    'BeaconCallbackHandler',
    'BeaconLangGraphHandler',
    'get_beacon_handler',
    # LangGraph integration (lazy-loaded)
    'LangGraphBeaconConfig',
    'BeaconLangGraphConfig',
    # Strands Agents integration (lazy-loaded)
    'BeaconStrandsHandler',
    # CrewAI integration (lazy-loaded)
    'BeaconCrewAIListener',
]


def __getattr__(name: str) -> type:
    """Lazy import for optional integration classes.

    This allows the core package to be imported without optional dependencies
    like langchain-core, while still providing a convenient import path.

    Args:
        name: The attribute name being accessed.

    Returns:
        The requested class if it's a lazy-loaded integration.

    Raises:
        AttributeError: If the attribute doesn't exist.
        ImportError: If the required optional dependency is not installed.
    """
    if name in ('BeaconCallbackHandler', 'BeaconLangGraphHandler'):
        from lumenova_beacon.tracing.integrations.langchain import BeaconCallbackHandler

        return BeaconCallbackHandler

    if name == 'get_beacon_handler':
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler

        return get_beacon_handler

    if name in ('LangGraphBeaconConfig', 'BeaconLangGraphConfig'):
        from lumenova_beacon.tracing.integrations.langchain import LangGraphBeaconConfig

        return LangGraphBeaconConfig

    if name == 'BeaconStrandsHandler':
        from lumenova_beacon.tracing.integrations.strands import BeaconStrandsHandler

        return BeaconStrandsHandler

    if name == 'BeaconCrewAIListener':
        from lumenova_beacon.tracing.integrations.crewai import BeaconCrewAIListener

        return BeaconCrewAIListener

    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')


# Submodules are imported via their respective packages:
# from lumenova_beacon.datasets import Dataset, DatasetRecord
# from lumenova_beacon.experiments import Experiment, ExperimentStep, ExperimentStatus
# from lumenova_beacon.prompts import Prompt
# from lumenova_beacon.evaluations import Evaluation, EvaluationRun, Evaluator, EvaluationRunStatus
# from lumenova_beacon.llm_configs import LLMConfig
