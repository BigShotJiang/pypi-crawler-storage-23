"""Experiment management for the Lumenova Beacon SDK.

This module provides ActiveRecord-style models for managing pipeline experiments.

Examples:
    List all experiments:
        >>> from lumenova_beacon import BeaconClient
        >>> from lumenova_beacon.experiments import Experiment, ExperimentStatus
        >>> client = BeaconClient(endpoint="...", api_key="...")
        >>> experiments, pagination = Experiment.list(page=1, page_size=20)
        >>> print(f"Total: {pagination.total}")

    Create experiment with pipeline steps:
        >>> from lumenova_beacon.experiments import (
        ...     Experiment, ExperimentStep, ExperimentStepType,
        ... )
        >>> experiment = Experiment.create(
        ...     name="My Pipeline",
        ...     dataset_id="dataset-uuid",
        ...     steps=[
        ...         ExperimentStep(
        ...             step_type=ExperimentStepType.LLM,
        ...             output_column="response",
        ...             config={"model_config_id": "config-uuid",
        ...                     "variable_mappings": {"input": "text"}},
        ...         ),
        ...     ],
        ... )

    Run with an external agent:
        >>> experiment = Experiment.create(
        ...     name="Agent Eval",
        ...     dataset_id="dataset-uuid",
        ...     steps=[
        ...         ExperimentStep(
        ...             step_type=ExperimentStepType.EXTERNAL_AGENT,
        ...             output_column="agent_output",
        ...             config={"agent_name": "My Agent",
        ...                     "variable_mappings": {"input": "text"}},
        ...         ),
        ...     ],
        ... )
        >>> experiment.start(external_agents={"My Agent": my_agent_fn})
"""

from lumenova_beacon.experiments.models import Experiment
from lumenova_beacon.experiments.types import (
    EnrichedRecord,
    ExperimentRun,
    ExperimentRunStats,
    ExperimentRunStatus,
    ExperimentStatus,
    ExperimentStep,
    ExperimentStepType,
    StepRunSummary,
)

__all__ = [
    "Experiment",
    "EnrichedRecord",
    "ExperimentRun",
    "ExperimentRunStats",
    "ExperimentRunStatus",
    "ExperimentStatus",
    "ExperimentStep",
    "ExperimentStepType",
    "StepRunSummary",
]
