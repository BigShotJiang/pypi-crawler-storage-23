# Dev Environment Seeding Script

This script populates a newly deployed dev environment with realistic, varied traces to demonstrate Beacon SDK capabilities and test observability features.

## Overview

The seeding script generates **~44 spans** across **10 different scenarios**, showcasing:

- ✅ OpenAI auto-instrumentation
- ✅ Anthropic auto-instrumentation with retry patterns
- ✅ Decorated functions (`@trace`) with nested spans
- ✅ Manual span creation (`client.trace()`)
- ✅ LangChain RAG pipelines
- ✅ **LangGraph basic agent** execution with tools
- ✅ **LangGraph multi-tool research agent** with sequential tool calls
- ✅ **LangGraph parallel tool execution** for monitoring workflows
- ✅ **LangGraph custom state management** with multi-stage workflows
- ✅ **Multi-turn chatbot conversations** with shared session_id
- ✅ Error scenarios with exception recording
- ✅ **Session ID tracking** across related operations
- ✅ Parent-child relationships (1-3 levels deep)
- ✅ Realistic LLM prompts and responses

## Prerequisites

### Environment Variables

Set the following environment variables before running:

```powershell
# LLM API Keys (required for real API calls)
$env:OPENAI_API_KEY = "sk-..."
$env:ANTHROPIC_API_KEY = "sk-ant-..."

# Beacon Configuration
$env:BEACON_ENDPOINT = "http://localhost:8000"  # or your dev endpoint
$env:BEACON_API_KEY = "your-beacon-api-key"
$env:BEACON_PROJECT_ID = "dev-seeding-project"  # optional, for organization
$env:BEACON_SESSION_ID = "seeding-session-$(Get-Date -Format 'yyyyMMdd-HHmmss')"  # optional
```

### Python Dependencies

Ensure all required packages are installed:

```powershell
.venv/Scripts/python.exe -m pip install openai anthropic langchain langchain-openai langchain-community langgraph faiss-cpu
```

## Usage

### Run the Script

```powershell
# Activate virtual environment
.venv\Scripts\activate

# Run the seeding script
.venv/Scripts/python.exe examples/seeding/seed_dev_environment.py
```

### Expected Output

```
======================================================================
🌟 BEACON SDK - DEV ENVIRONMENT SEEDING SCRIPT
======================================================================

This script will generate ~44 spans across 10 different scenarios.
Each scenario demonstrates different tracing patterns and integrations.
Focus: Multiple LangGraph examples + session_id tracking patterns.

✓ Environment variables validated

📡 Initializing Beacon SDK...
🔧 Setting up auto-instrumentation...

✓ Setup complete! Starting seeding scenarios...

[1/10] Running: Simple OpenAI Generation...
  ✓ Generated response: Observability in software engineering refers to...
  ✓ Tokens used: 87

[2/10] Running: Anthropic with Retry Pattern...
  📍 Session ID: retry-session-a1b2c3d4
  ! Simulating rate limit error on attempt 1...
  → Retrying with backoff...
  ✓ Retry succeeded: Distributed tracing is a method for monitoring...

[3/10] Running: Decorated Function Pipeline...
  📍 Session ID: pipeline-session-e5f6g7h8
  → Validating input...
  → Transforming data...
  → Persisting to database...
  ✓ Pipeline completed: Record ID 7823

[4/10] Running: LangChain RAG Pipeline...
  → Creating vector store...
  → Executing RAG chain...
  ✓ RAG answer: Spans represent units of work in distributed tracing...

[5/10] Running: LangGraph Agent Execution...
  📍 Session ID: agent-session-i9j0k1l2
  → Agent processing query...
  ✓ Agent response: The weather in San Francisco is sunny with a temperature...

[6/10] Running: LangGraph Multi-Tool Research Agent...
  → Research agent investigating query...
  ✓ Research complete: Best practices include using hierarchical spans...

[7/10] Running: LangGraph Parallel Tool Execution...
  📍 Session ID: monitoring-session-m3n4o5p6
  → Monitoring agent checking services...
  ✓ Health check complete: Service 'api-gateway' is healthy...

[8/10] Running: LangGraph with State Management...
  → Running multi-stage analysis workflow...
  ✓ Analysis complete (confidence: 0.87): Found multiple performance issues...

[9/10] Running: Error Scenario with Exception...
  📍 Session ID: error-session-q7r8s9t0
  → Making risky API call...
  ! Caught expected error: Request to external API timed out after 5 seconds
  ✓ Error recorded in span

[10/10] Running: Multi-Turn Chatbot Conversation...
  📍 Session ID: chat-session-u1v2w3x4
  (All conversation turns will share this session_id)
  → Turn 1: User asks about decorators...
    ✓ Bot responded: Python decorators are functions that modify the behav...
  → Turn 2: User asks for an example...
    ✓ Bot responded: Here's a simple logging decorator example...
  → Turn 3: User asks about practical applications...
    ✓ Bot responded: For caching, you can use functools.lru_cache or...
  ✓ Conversation complete: 3 separate traces with session_id=chat-session-u1v2w3x4

======================================================================
✅ SEEDING COMPLETE!
======================================================================
Total spans generated: ~44
Total execution time: 90.5s
Endpoint: http://localhost:8000
Project ID: dev-seeding-project

💡 Check your Beacon dashboard to view the traces!
======================================================================
```

## Scenarios Breakdown

### 1. Simple OpenAI Generation (1 span)

**Integration**: OpenAI auto-instrumentation
**Spans Created**: 1 (GENERATION type)
**Description**: Single LLM generation demonstrating basic OpenAI tracing.

**Key Features**:
- Auto-captured model, temperature, max_tokens
- Token usage tracking
- Prompt and response recording

---

### 2. Anthropic with Retry Pattern (3 spans)

**Integration**: Anthropic auto-instrumentation + manual span
**Spans Created**: 3 (1 parent manual span + 2 child auto-instrumented spans)
**Description**: Demonstrates error handling and retry logic with nested spans.

**Key Features**:
- Manual parent span wrapping retry logic
- Simulated rate limit error on first attempt
- Successful retry captured automatically
- Metadata for attempt tracking

**Trace Hierarchy**:
```
anthropic_with_retry (manual)
  ├── attempt_1 (simulated error)
  └── anthropic.messages.create (successful)
```

---

### 3. Decorated Function Pipeline (4 spans)

**Integration**: `@trace` decorator + manual spans
**Spans Created**: 4 (1 parent + 3 children)
**Description**: Data processing pipeline using decorated functions and manual spans.

**Key Features**:
- Mix of `@trace` decorator and `client.trace()` context manager
- Input validation, transformation, persistence
- Realistic processing delays
- Database metadata

**Trace Hierarchy**:
```
user_data_pipeline (decorated)
  ├── validate_user_input (decorated)
  ├── transform_data (decorated)
  └── database_write (manual)
```

---

### 4. LangChain RAG Pipeline (5-6 spans)

**Integration**: LangChain with `BeaconCallbackHandler`
**Spans Created**: 5-6 (retrieval, formatting, prompt, generation, parsing)
**Description**: Retrieval-Augmented Generation pipeline with vector search.

**Key Features**:
- FAISS vector store with OpenAI embeddings
- Document retrieval (k=2)
- Context formatting
- LLM generation with injected context
- Automatic chain tracing via callback handler

**Trace Hierarchy**:
```
RunnableSequence (chain)
  ├── RunnableParallel (chain)
  │   ├── VectorStoreRetriever (retrieval)
  │   └── RunnablePassthrough (chain)
  ├── ChatPromptTemplate (chain)
  ├── ChatOpenAI (generation)
  └── StrOutputParser (chain)
```

---

### 5. LangGraph Agent Execution (4-5 spans)

**Integration**: LangGraph with tools + `BeaconCallbackHandler`
**Spans Created**: 4-5 (agent, tools, generation)
**Description**: Agent orchestration with tool calling.

**Key Features**:
- StateGraph with conditional edges
- Tool binding (`get_weather`)
- Agent decision-making loop
- Tool execution with `@trace` decorator
- Realistic tool responses

**Trace Hierarchy**:
```
langgraph.invoke (agent)
  ├── agent (chain)
  ├── tools (tool)
  │   └── get_weather (function)
  └── agent (generation)
```

---

### 6. LangGraph Multi-Tool Research Agent (6-8 spans)

**Integration**: LangGraph with multiple tools + `BeaconCallbackHandler`
**Spans Created**: 6-8 (agent orchestration + multiple sequential tool calls)
**Description**: Research agent that can search knowledge base and web, then summarize findings.

**Key Features**:
- Multiple tools: `search_knowledge_base`, `web_search`, `summarize_findings`
- Sequential tool execution based on agent decisions
- Each tool decorated with `@trace` for visibility
- Demonstrates complex multi-step reasoning workflows

**Trace Hierarchy**:
```
langgraph.invoke (agent)
  ├── researcher (chain)
  ├── tools (tool)
  │   ├── search_knowledge_base (function)
  │   └── web_search (function)
  ├── researcher (chain)
  └── final_generation (generation)
```

---

### 7. LangGraph Parallel Tool Execution (5-7 spans)

**Integration**: LangGraph with monitoring tools + `BeaconCallbackHandler`
**Spans Created**: 5-7 (agent + parallel tool calls)
**Description**: Monitoring agent that can call multiple health check tools.

**Key Features**:
- Three monitoring tools: `check_system_health`, `get_error_rate`, `check_resource_usage`
- Agent can invoke multiple tools to get complete service health picture
- Demonstrates parallel tool execution patterns
- Realistic monitoring workflow

**Trace Hierarchy**:
```
langgraph.invoke (agent)
  ├── monitor (chain)
  ├── tools (tool)
  │   ├── check_system_health (function)
  │   ├── get_error_rate (function)
  │   └── check_resource_usage (function)
  └── monitor (generation)
```

---

### 8. LangGraph with State Management (6-8 spans)

**Integration**: LangGraph with custom state (`AnalysisState`) + `BeaconCallbackHandler`
**Spans Created**: 6-8 (multi-stage workflow with state evolution)
**Description**: Advanced workflow with custom state that evolves through multiple analysis stages.

**Key Features**:
- Custom `AnalysisState` TypedDict with: messages, analysis_stage, findings, confidence_score
- Multi-stage workflow: log analysis → correlation analysis
- State transformations tracked across stages
- Conditional routing based on analysis stage
- Tools: `analyze_logs`, `correlate_metrics`

**Trace Hierarchy**:
```
langgraph.invoke (agent)
  ├── stage_1 (chain) - Initial log analysis
  ├── tools (tool)
  │   └── analyze_logs (function)
  ├── stage_2 (chain) - Correlation analysis
  ├── tools (tool)
  │   └── correlate_metrics (function)
  └── final_response (generation)
```

**State Evolution**:
```python
Initial:  {analysis_stage: "initial", findings: [], confidence_score: 0.0}
Stage 1:  {analysis_stage: "log_analysis", findings: ["Started log analysis"], ...}
Stage 2:  {analysis_stage: "correlation", findings: [..., "Completed correlation"], confidence_score: 0.87}
```

---

### 9. Error Scenario (2 spans)

**Integration**: `@trace` decorator with exception handling
**Spans Created**: 2 (1 parent + 1 child with error)
**Description**: Demonstrates error recording and exception propagation.
**Session ID**: `error-session-{uuid}` - tracks error scenarios

**Key Features**:
- Automatic exception recording via `span.record_exception()`
- Span status set to ERROR
- Exception type and message captured
- Error handling pattern
- Session ID for correlating error traces

**Trace Hierarchy**:
```
api_request_handler (manual, session_id="error-session-xyz")
  └── risky_api_call (decorated, ERROR status)
```

---

### 10. Multi-Turn Chatbot Conversation (3 separate traces)

**Integration**: LangChain with `BeaconCallbackHandler(session_id=...)`
**Spans Created**: 3 **independent traces**, all sharing the same session_id
**Description**: Simulates a realistic chatbot conversation where each turn creates its own trace, but all traces share a session_id for correlation.
**Session ID**: `chat-session-{uuid}` - links all conversation turns

**Key Features**:
- **3 separate traces** (not nested) - each LLM call is independent
- **Shared session_id** allows filtering/grouping all conversation turns together
- Multi-turn conversation with message history maintained client-side
- Realistic technical support scenario (Python decorators topic)
- Demonstrates how to track a user's session across multiple requests

**Conversation Flow**:
1. User asks: "What are Python decorators and why are they useful?"
2. User asks: "Can you show me a simple example of a decorator that logs function calls?"
3. User asks: "How would I use decorators for caching in a real application?"

**Trace Structure** (3 independent traces, same session_id):
```
Trace 1: ChatOpenAI.invoke (session_id="chat-session-xyz") - Turn 1
Trace 2: ChatOpenAI.invoke (session_id="chat-session-xyz") - Turn 2
Trace 3: ChatOpenAI.invoke (session_id="chat-session-xyz") - Turn 3
```

**Why This Matters**:
- In the Beacon dashboard, filter by `session_id` to see all turns of a conversation
- Each trace is independent but logically grouped by session
- Mirrors real-world chat applications where each message is a separate request

---

## Session ID Summary

The following scenarios demonstrate `session_id` tracking:

| Scenario | Session ID Pattern | Purpose |
|----------|-------------------|---------|
| 2. Anthropic Retry | `retry-session-{uuid}` | Track retry attempts |
| 3. Decorated Pipeline | `pipeline-session-{uuid}` | Track data processing |
| 5. LangGraph Agent | `agent-session-{uuid}` | Track agent execution |
| 7. Parallel Tools | `monitoring-session-{uuid}` | Track monitoring workflow |
| 9. Error Scenario | `error-session-{uuid}` | Track error handling |
| 10. Chatbot | `chat-session-{uuid}` | Track conversation turns |

---

## Customization

### Adjust Span Count

To increase/decrease the number of spans, modify the scenarios:

```python
# In scenario_4_langchain_rag()
retriever = vectorstore.as_retriever(search_kwargs={"k": 5})  # More retrieval spans
```

### Change Delays

Modify the sleep durations between scenarios:

```python
time.sleep(5)  # Increase delay between scenarios
```

### Add Custom Scenarios

Add your own scenario functions following the pattern:

```python
def scenario_7_custom(beacon_client: BeaconClient) -> None:
    """Your custom scenario description."""
    print("\n[7/7] Running: Custom Scenario...")

    with beacon_client.trace("custom_operation") as span:
        span.set_input({"key": "value"})
        # Your logic here
        span.set_output({"result": "success"})

    print("  ✓ Custom scenario completed")
```

Then add to `main()`:

```python
scenario_7_custom(beacon_client)
span_count += 1  # Adjust based on spans created
time.sleep(2)
```

## Troubleshooting

### Missing API Keys

```
❌ Missing required environment variables: OPENAI_API_KEY, ANTHROPIC_API_KEY
```

**Solution**: Set the required environment variables as shown in Prerequisites.

---

### Import Errors

```
ModuleNotFoundError: No module named 'langchain'
```

**Solution**: Install missing dependencies:

```powershell
.venv/Scripts/python.exe -m pip install langchain langchain-openai langchain-community langgraph faiss-cpu
```

---

### Connection Errors

```
ConnectionError: Failed to connect to http://localhost:8000
```

**Solution**: Ensure your Beacon endpoint is running and accessible. Update `$env:BEACON_ENDPOINT` if using a different URL.

---

### Rate Limits

If you hit LLM API rate limits:

1. Increase delays between scenarios
2. Reduce the number of LLM calls
3. Use smaller models (e.g., `gpt-4o-mini` instead of `gpt-4o`)

## Architecture Notes

### Span Types Used

- **GENERATION**: LLM completions (OpenAI, Anthropic)
- **CHAIN**: LangChain/LangGraph chain executions
- **TOOL**: Tool invocations (weather, calculator)
- **FUNCTION**: Decorated functions (`@trace`)
- **RETRIEVAL**: Vector store queries
- **SPAN**: Generic manual spans

### Parent-Child Relationships

The SDK uses OpenTelemetry context propagation:

- Context is automatically managed via `ContextVar`
- Child spans inherit `trace_id` from parents
- Parent `span_id` becomes child's `parent_id`
- Spans are sent immediately upon completion
- Parents wait for all children before being sent

### Metadata Captured

Each scenario demonstrates different metadata:

- Token usage (LLM calls)
- Model names and parameters
- Database operations
- Retry attempts
- Tool inputs/outputs
- Exception details

## Next Steps

After running the seeding script:

1. **View Traces**: Check your Beacon dashboard at `$env:BEACON_ENDPOINT`
2. **Filter by Project**: Use `$env:BEACON_PROJECT_ID` to isolate seeding data
3. **Analyze Patterns**: Review parent-child relationships and span durations
4. **Test Queries**: Use the seeded data to test search, filtering, and analytics
5. **Verify Errors**: Ensure error scenarios are properly displayed

## License

This example is part of the Lumenova Beacon SDK.
