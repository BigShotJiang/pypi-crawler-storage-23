"""Historical timestamp generation with realistic distributions."""

from datetime import datetime, timedelta, timezone
import random
import math


class HistoricalTimestampGenerator:
    """Generates realistic timestamps distributed over a specified time range."""

    def __init__(
        self,
        end_date: datetime | None = None,
        days_back: int = 90,
        total_traces: int = 500,
    ):
        """Initialize the timestamp generator.

        Args:
            end_date: End date for the time range (default: now)
            days_back: Number of days to go back (default: 90)
            total_traces: Target number of traces to generate (default: 500)
        """
        self.end_date = end_date or datetime.now(timezone.utc)
        self.start_date = self.end_date - timedelta(days=days_back)
        self.total_traces = total_traces
        self.days_back = days_back

        # Distribution parameters
        self.weekday_weight = 0.85  # 85% on weekdays
        self.business_hours_weight = 0.70  # 70% during 9-18 UTC

    def generate_timestamps(self) -> list[datetime]:
        """Generate all trace start timestamps with realistic distribution.

        Returns:
            Sorted list of datetime objects representing trace start times.
        """
        timestamps: list[datetime] = []

        # Calculate traces per day with growth trend
        daily_counts = self._calculate_daily_distribution()

        current_date = self.start_date.replace(hour=0, minute=0, second=0, microsecond=0)
        day_index = 0

        while current_date <= self.end_date:
            day_of_week = current_date.weekday()
            is_weekday = day_of_week < 5

            # Get base count for this day
            base_count = daily_counts[day_index] if day_index < len(daily_counts) else 5

            # Apply weekday/weekend modifier
            if is_weekday:
                count = int(base_count * 1.2)  # 20% more on weekdays
            else:
                count = int(base_count * 0.4)  # 60% less on weekends

            # Add occasional spikes (5% chance)
            if random.random() < 0.05:
                count = int(count * random.uniform(2.0, 4.0))

            # Add occasional gaps (3% chance of very low activity)
            if random.random() < 0.03:
                count = max(1, int(count * 0.1))

            # Generate timestamps for this day
            for _ in range(count):
                ts = self._generate_intraday_timestamp(current_date, is_weekday)
                timestamps.append(ts)

            current_date += timedelta(days=1)
            day_index += 1

        # Sort and return
        return sorted(timestamps)

    def _calculate_daily_distribution(self) -> list[int]:
        """Calculate trace counts per day with growth trend.

        Returns:
            List of integers representing trace count per day.
        """
        num_days = self.days_back + 1

        # Start with base count, grow 30% over period
        base_daily = self.total_traces / num_days
        growth_factor = 1.3

        counts: list[int] = []
        for i in range(num_days):
            progress = i / num_days
            daily_count = base_daily * (1 + (growth_factor - 1) * progress)
            # Add noise
            daily_count *= random.uniform(0.7, 1.3)
            counts.append(max(1, int(daily_count)))

        return counts

    def _generate_intraday_timestamp(self, date: datetime, is_weekday: bool) -> datetime:
        """Generate a timestamp within a specific day.

        Args:
            date: The date to generate a timestamp for
            is_weekday: Whether the day is a weekday

        Returns:
            A datetime within the given day.
        """
        if is_weekday and random.random() < self.business_hours_weight:
            # Business hours: 9:00-18:00 UTC with bell curve around 1:30 PM
            hour = int(self._normal_bounded(13.5, 2.5, 9, 17))
        else:
            # Non-business hours or weekend - more uniform distribution
            hour = random.randint(0, 23)

        minute = random.randint(0, 59)
        second = random.randint(0, 59)
        microsecond = random.randint(0, 999999)

        return date.replace(
            hour=hour,
            minute=minute,
            second=second,
            microsecond=microsecond,
            tzinfo=timezone.utc,
        )

    def _normal_bounded(
        self, mean: float, std: float, min_val: float, max_val: float
    ) -> float:
        """Generate a normally distributed value bounded to a range.

        Args:
            mean: Mean of the distribution
            std: Standard deviation
            min_val: Minimum allowed value
            max_val: Maximum allowed value

        Returns:
            A bounded value from a normal distribution.
        """
        # Use Box-Muller transform for normal distribution
        u1 = random.random()
        u2 = random.random()
        z = math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2)
        value = mean + z * std
        return max(min_val, min(max_val, value))

    @staticmethod
    def to_iso8601(dt: datetime) -> str:
        """Convert datetime to ISO 8601 format with 'Z' suffix.

        Args:
            dt: A datetime object (should be UTC)

        Returns:
            ISO 8601 formatted string with 'Z' suffix.
        """
        return dt.isoformat().replace("+00:00", "Z")

    @staticmethod
    def from_iso8601(s: str) -> datetime:
        """Parse an ISO 8601 string to datetime.

        Args:
            s: ISO 8601 formatted string

        Returns:
            A timezone-aware datetime object.
        """
        # Handle 'Z' suffix
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s)
