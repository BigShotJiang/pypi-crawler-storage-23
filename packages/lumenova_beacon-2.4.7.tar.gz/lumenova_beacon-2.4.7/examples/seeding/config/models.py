"""Model profiles with realistic latency characteristics."""

from dataclasses import dataclass


@dataclass
class ModelProfile:
    """Profile for an LLM model with latency and cost characteristics."""

    provider: str  # "openai" | "anthropic"
    model_id: str  # Full model identifier
    display_name: str  # Human-readable name
    avg_latency_ms: int  # Average latency in milliseconds
    latency_std_ms: int  # Standard deviation for latency
    tokens_per_second: float  # Token generation rate
    cost_per_1k_input: float  # Cost per 1000 input tokens
    cost_per_1k_output: float  # Cost per 1000 output tokens


# Model profiles with realistic latency data
MODELS: dict[str, ModelProfile] = {
    # OpenAI Models
    "gpt-4o": ModelProfile(
        provider="openai",
        model_id="gpt-4o",
        display_name="GPT-4o",
        avg_latency_ms=800,
        latency_std_ms=200,
        tokens_per_second=50.0,
        cost_per_1k_input=0.005,
        cost_per_1k_output=0.015,
    ),
    "gpt-4o-mini": ModelProfile(
        provider="openai",
        model_id="gpt-4o-mini",
        display_name="GPT-4o Mini",
        avg_latency_ms=400,
        latency_std_ms=100,
        tokens_per_second=80.0,
        cost_per_1k_input=0.00015,
        cost_per_1k_output=0.0006,
    ),
    "gpt-4-turbo": ModelProfile(
        provider="openai",
        model_id="gpt-4-turbo",
        display_name="GPT-4 Turbo",
        avg_latency_ms=1200,
        latency_std_ms=300,
        tokens_per_second=40.0,
        cost_per_1k_input=0.01,
        cost_per_1k_output=0.03,
    ),
    "gpt-3.5-turbo": ModelProfile(
        provider="openai",
        model_id="gpt-3.5-turbo",
        display_name="GPT-3.5 Turbo",
        avg_latency_ms=300,
        latency_std_ms=80,
        tokens_per_second=100.0,
        cost_per_1k_input=0.0005,
        cost_per_1k_output=0.0015,
    ),
    # Anthropic Models
    "claude-3-opus": ModelProfile(
        provider="anthropic",
        model_id="claude-3-opus-20240229",
        display_name="Claude 3 Opus",
        avg_latency_ms=2000,
        latency_std_ms=500,
        tokens_per_second=30.0,
        cost_per_1k_input=0.015,
        cost_per_1k_output=0.075,
    ),
    "claude-3-sonnet": ModelProfile(
        provider="anthropic",
        model_id="claude-3-sonnet-20240229",
        display_name="Claude 3 Sonnet",
        avg_latency_ms=800,
        latency_std_ms=200,
        tokens_per_second=50.0,
        cost_per_1k_input=0.003,
        cost_per_1k_output=0.015,
    ),
    "claude-3-haiku": ModelProfile(
        provider="anthropic",
        model_id="claude-3-haiku-20240307",
        display_name="Claude 3 Haiku",
        avg_latency_ms=200,
        latency_std_ms=50,
        tokens_per_second=120.0,
        cost_per_1k_input=0.00025,
        cost_per_1k_output=0.00125,
    ),
}

# Agent names for variety
AGENT_NAMES = [
    "ResearchAssistant",
    "CodeReviewer",
    "DataAnalyst",
    "CustomerSupport",
    "ContentWriter",
    "SystemMonitor",
    "TaskPlanner",
    "DocumentProcessor",
    "QueryOptimizer",
    "SecurityScanner",
    "SalesAssistant",
    "HRHelper",
    "LegalAdvisor",
    "MarketingBot",
    "TechSupport",
]

# Environments for variety
ENVIRONMENTS = ["dev", "staging", "production", "test"]

# Sample prompts for generation spans
SAMPLE_PROMPTS = [
    "Analyze this data and provide insights",
    "Write a summary of the document",
    "Answer the customer's question",
    "Review this code for issues",
    "Generate a report based on the metrics",
    "Translate this text to Spanish",
    "Explain this concept in simple terms",
    "Create a marketing copy for the product",
    "Debug this error message",
    "Suggest improvements for the process",
    "Research the topic and provide sources",
    "Calculate the optimal solution",
    "Plan the project timeline",
    "Draft an email response",
    "Summarize the meeting notes",
]

# Sample tool names
TOOL_NAMES = [
    "search_knowledge_base",
    "web_search",
    "calculator",
    "get_weather",
    "send_email",
    "create_ticket",
    "query_database",
    "generate_chart",
    "schedule_meeting",
    "translate_text",
    "analyze_sentiment",
    "extract_entities",
    "validate_data",
    "format_document",
    "compress_image",
]

# Error messages for error scenarios
ERROR_MESSAGES = [
    "Request timeout after 30 seconds",
    "Rate limit exceeded. Please retry after 60 seconds",
    "Model overloaded. Please try again later",
    "Invalid API key provided",
    "Context length exceeded maximum of 128000 tokens",
    "Service temporarily unavailable",
    "Connection reset by peer",
    "SSL certificate verification failed",
    "Insufficient quota remaining",
    "Internal server error",
]
