import zipfile
import threading
from .core import MemorySafeCache

try:
    import s3fs
    has_s3fs = True
except ImportError:
    has_s3fs = False

class S3StreamEngine:
    """
    Tier 4 Engine: Cloud Network Streaming for AWS S3.
    Reads data directly from a ZIP file hosted on S3 using byte-range requests 
    via s3fs, bypassing the need to download or extract the full archive.
    """
    def __init__(self, s3_zip_path, max_cache_mb=1024):
        if not has_s3fs:
            raise ImportError("s3fs and boto3 are required for S3 streaming. Run: pip install s3fs boto3")
            
        if not s3_zip_path.startswith("s3://"):
            raise ValueError(f"S3StreamEngine requires an s3:// URL, got: {s3_zip_path}")
            
        self.s3_zip_path = s3_zip_path
        self.cache = MemorySafeCache(max_cache_mb)
        
        # Initialize the S3 file system.
        # It automatically picks up AWS credentials from standard environment variables:
        # AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN
        # Or from ~/.aws/credentials
        try:
            self.fs = s3fs.S3FileSystem(anon=False) 
            # Test if file exists and we have permissions
            if not self.fs.exists(self.s3_zip_path):
                # Try anonymous if standard auth fails/reports not found (could be public bucket)
                try:
                    self.fs = s3fs.S3FileSystem(anon=True)
                    if not self.fs.exists(self.s3_zip_path):
                        raise FileNotFoundError(f"File not found on S3: {self.s3_zip_path}")
                except Exception:
                    raise FileNotFoundError(f"File not found or access denied on S3: {self.s3_zip_path}")
        except Exception as e:
            raise RuntimeError(f"Failed to initialize S3 FileSystem. Check AWS credentials. Error: {e}")

        # Open the file-like object over the network. s3fs handles HTTP range requests seamlessly.
        self._master_s3_file = self.fs.open(self.s3_zip_path, 'rb')
        
        try:
            # We use zipfile natively over the s3fs file object. 
            # zipfile only reads the end of the file (Central Directory) to build the index!
            with zipfile.ZipFile(self._master_s3_file, 'r') as zf:
                self.infolist = [info for info in zf.infolist() if not info.filename.endswith('/')]
                self.filename_to_idx = {info.filename: idx for idx, info in enumerate(self.infolist)}
        except zipfile.BadZipFile:
            raise ValueError(f"Corrupted or invalid ZIP file on S3: {s3_zip_path}")
        except Exception as e:
             raise RuntimeError(f"Error reading ZIP Central Directory from S3: {e}")

        # Thread local storage for s3fs file objects and zipfile contexts.
        # Since s3fs file objects maintain internal seek state, each worker thread
        # needs its own file object to safely read bytes concurrently.
        self.local_thread = threading.local()

    def __len__(self):
        return len(self.infolist)

    def _get_thread_local_refs(self):
        """ Returns a thread-safe ZipFile context wrapped around an S3 file object """
        if not hasattr(self.local_thread, "s3_file") or getattr(self.local_thread, "s3_file").closed:
            # Open a new HTTP connection per thread
            self.local_thread.s3_file = self.fs.open(self.s3_zip_path, 'rb')
            self.local_thread.zf = zipfile.ZipFile(self.local_thread.s3_file, 'r')
        return self.local_thread.zf

    def get_by_index(self, idx):
        """ Fetch file bytes via integer index with memory caching. """
        cached_data = self.cache.get(idx)
        if cached_data is not None:
            return cached_data

        info = self.infolist[idx]
        zf = self._get_thread_local_refs()
        
        # Read from S3 (boto3 triggers a byte-range HTTP GET request under the hood here)
        with zf.open(info) as f:
            data = f.read()
            
        self.cache.put(idx, data)
        return data

    def get_by_filename(self, filename):
        if filename not in self.filename_to_idx:
            raise KeyError(f"File {filename} not found in S3 ZIP archive.")
        idx = self.filename_to_idx[filename]
        return self.get_by_index(idx)
        
    def get_filenames(self):
        return [info.filename for info in self.infolist]

    def close(self):
        """ Clean up open S3 HTTP connections on closure """
        # Guard: local_thread may not exist if __init__ raised before reaching that line
        if hasattr(self, 'local_thread'):
            if hasattr(self.local_thread, "zf"):
                self.local_thread.zf.close()
                del self.local_thread.zf
            if hasattr(self.local_thread, "s3_file") and not self.local_thread.s3_file.closed:
                self.local_thread.s3_file.close()
                del self.local_thread.s3_file
            
        if hasattr(self, "_master_s3_file") and not self._master_s3_file.closed:
            self._master_s3_file.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass  # Suppress all errors during garbage collection

