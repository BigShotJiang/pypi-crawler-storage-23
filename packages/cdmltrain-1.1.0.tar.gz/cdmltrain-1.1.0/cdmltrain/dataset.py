import os
import io

# PIL import for image decoding (only needed when is_image=True)
try:
    from PIL import Image
    has_pil = True
except ImportError:
    has_pil = False

# Try importing the new C++ Fast Core Engine
has_fast_core = False
try:
    from . import fast_core
    has_fast_core = True
except ImportError:
    pass

# Try importing Tier 3 ZSTD engine
has_zstd_engine = False
try:
    from .zstd_engine import ZSTDStreamEngine
    has_zstd_engine = True
except ImportError:
    pass

# Try importing Tier 4 Cloud Network Streaming (S3) engine
try:
    from .s3_engine import S3StreamEngine
    has_s3_engine = True
except ImportError:
    has_s3_engine = False

# We wrap it in a try-except to avoid immediately breaking non-PyTorch environments
try:
    from .core import CoreStreamEngine
except ImportError:
    pass

class CDMLStreamDataset:
    """
    A Dataset that loads files directly from a ZIP archive without extracting them.
    It uses CoreStreamEngine to support transparent Memory Caching and parallel thread reading.
    """
    def __init__(self, zip_path, transform=None, is_image=False, max_cache_mb=1024):
        """
        Args:
            zip_path (str): Path to the `.zip` or `.tar.zst` archive.
            transform (callable, optional): Optional PyTorch transform to be applied.
            is_image (bool): Default False. Set to True to automatically decode binary data into a PIL image.
            max_cache_mb (int): Max RAM usage for caching in Megabytes.
        """
        self.zip_path = zip_path
        self.transform = transform
        self.is_image = is_image
        self._use_fast = False

        # Tier 4: Cloud Network Streaming (S3)
        if zip_path.startswith("s3://"):
            if not zip_path.endswith(".zip") and not zip_path.endswith(".tar.zst"):
                raise ValueError("S3 paths must point to a .zip or .tar.zst archive.")
            if has_s3_engine:
                print("[CDML] Using Tier-4 Cloud Network Streaming Engine (S3) ☁️")
                self.engine = S3StreamEngine(zip_path, max_cache_mb)
            else:
                raise ImportError("s3fs and boto3 are required for S3 streaming. Run: pip install s3fs boto3")
                
        # Tier 3: Auto-detect ZSTD format
        elif zip_path.endswith('.tar.zst') or zip_path.endswith('.zst'):
            if has_zstd_engine:
                print("[CDML] Using Tier-3 ZSTD Engine ⚡")
                self.engine = ZSTDStreamEngine(zip_path, max_cache_mb)
            else:
                raise ImportError("ZSTD engine not available. Run: pip install zstandard")
        elif has_fast_core:
            # print("[CDML] Using Tier-2 C++ FastCoreEngine 🚀")
            self.engine = fast_core.FastCoreEngine(zip_path, max_cache_mb)
            # In a real implementation we would pass the infolist here, 
            # for now C++ engine mocks the read. 
            # We use the python core to get the index, and pass to C++
            self._python_fallback = CoreStreamEngine(zip_path, max_cache_mb)
            self.engine.build_index(self._python_fallback.get_filenames())
            self._use_fast = True
        else:
            self.engine = CoreStreamEngine(zip_path, max_cache_mb)
            self._use_fast = False

    def __len__(self):
        return len(self.engine)

    def __enter__(self):
        """Context manager support: with CDMLStreamDataset(...) as ds:"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Auto-close file handles when used as context manager."""
        self.close()
        return False

    def close(self):
        """Release all open file handles."""
        for engine in [getattr(self, 'engine', None), getattr(self, '_python_fallback', None)]:
            if engine is not None and hasattr(engine, 'close'):
                engine.close()

    def __getitem__(self, idx):
        # 1. Fetch raw bytes from Engine
        if hasattr(self, '_use_fast') and self._use_fast:
            _cpp_signal = self.engine.get_by_index(idx)
            raw_bytes = self._python_fallback.get_by_index(idx)
        else:
            raw_bytes = self.engine.get_by_index(idx)

        # 2. Decode bytes (Optional convenience)
        if self.is_image:
            if not has_pil:
                raise ImportError("Pillow is required for image decoding. Run: pip install Pillow")
            try:
                item = Image.open(io.BytesIO(raw_bytes)).convert('RGB')
            except Exception as e:
                raise RuntimeError(f"Failed to decode image at index {idx} in {self.zip_path}: {e}")
        else:
            item = raw_bytes
            
        # 3. Apply PyTorch transformations if provided
        if self.transform:
            item = self.transform(item)
            
        return item
        
    def extract_sample_to_disk(self, idx, export_path):
        """
        Debugging feature for Data Scientists. Directly saves a specific file from the archive to disk.
        """
        if hasattr(self, '_use_fast') and self._use_fast:
            raw_bytes = self._python_fallback.get_by_index(idx)
            filename = self._python_fallback.get_filenames()[idx]
        else:
            raw_bytes = self.engine.get_by_index(idx)
            filename = self.engine.get_filenames()[idx]
        
        if os.path.isdir(export_path):
            export_path = os.path.join(export_path, os.path.basename(filename))
            
        with open(export_path, "wb") as f:
            f.write(raw_bytes)
            
        print(f"[CDML Dataset] Extracted file '{filename}' to -> {export_path}")

    def get_filenames(self):
        if hasattr(self, '_use_fast') and self._use_fast:
            return self._python_fallback.get_filenames()
        return self.engine.get_filenames()

    def get_by_filename(self, filename: str):
        """
        Convenience method to fetch a file by its exact name rather than index.
        Ideal for data exploration. Returns PIL Image if is_image=True, else bytes.
        """
        try:
            # 1. Fetch raw bytes
            if hasattr(self, '_use_fast') and self._use_fast:
                raw_bytes = self._python_fallback.get_by_filename(filename)
            else:
                raw_bytes = self.engine.get_by_filename(filename)
                
            # 2. Decode bytes optionally
            if self.is_image:
                if not has_pil:
                    raise ImportError("Pillow is required for image decoding.")
                return Image.open(io.BytesIO(raw_bytes)).convert('RGB')
            else:
                return raw_bytes
                
        except KeyError:
            raise KeyError(f"Filename '{filename}' not found in archive {self.zip_path}")
