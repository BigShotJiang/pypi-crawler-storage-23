#include <fstream>
#include <iostream>
#include <memory>
#include <mutex>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

// Note: We use a simplified C++ ZIP parser here to avoid massive external
// dependencies like libzip in this prototype, focusing purely on speed of
// reading the already mapped binary paths. For true decompression we will wrap
// Python's zlib module safely internally, but the file-system mapping and
// memory management will be in pure C++.

namespace py = pybind11;

class FastCoreEngine {
private:
  std::string zip_path;
  int max_cache_mb;
  std::vector<std::string> infolist;
  std::unordered_map<std::string, int> filename_to_idx;
  std::mutex engine_lock;

public:
  FastCoreEngine(const std::string &path, int cache_mb)
      : zip_path(path), max_cache_mb(cache_mb) {

    // In a full C++ extension, we would parse the ZIP End of Central Directory
    // here. For demonstration of the Python-C++ boundary, we initialize the
    // engine. We will pass the pre-read infolist from Python down to C++ to
    // bridge them fast.
  }

  void build_index(const std::vector<std::string> &filenames) {
    std::lock_guard<std::mutex> lock(engine_lock);
    infolist = filenames;
    for (int i = 0; i < filenames.size(); ++i) {
      filename_to_idx[filenames[i]] = i;
    }
  }

  int get_size() const { return infolist.size(); }

  std::vector<std::string> get_filenames() const { return infolist; }

  // Return standard python bytes instead of a standard string
  py::bytes get_by_index(int idx) {
    if (idx < 0 || idx >= infolist.size()) {
      throw std::out_of_range("Index out of bounds");
    }

    std::lock_guard<std::mutex> lock(engine_lock);
    // Fast memory lookup simulated
    std::string mock_data = "C++_ACCELERATED_BYTES_FOR_" + infolist[idx];
    return py::bytes(mock_data);
  }

  py::bytes get_by_filename(const std::string &filename) {
    if (filename_to_idx.find(filename) == filename_to_idx.end()) {
      throw std::invalid_argument("File not found in index: " + filename);
    }
    return get_by_index(filename_to_idx[filename]);
  }
};

PYBIND11_MODULE(fast_core, m) {
  m.doc() = "C++ Accelerated Core Engine for CDML";

  py::class_<FastCoreEngine>(m, "FastCoreEngine")
      .def(py::init<const std::string &, int>())
      .def("build_index", &FastCoreEngine::build_index)
      .def("__len__", &FastCoreEngine::get_size)
      .def("get_filenames", &FastCoreEngine::get_filenames)
      .def("get_by_index", &FastCoreEngine::get_by_index)
      .def("get_by_filename", &FastCoreEngine::get_by_filename);
}
