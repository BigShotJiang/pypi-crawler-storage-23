import zipfile
import threading
import sys
from collections import OrderedDict

class MemorySafeCache:
    """
    LRU Cache bounded by maximum memory size (bytes) rather than entry count,
    preventing Out of Memory (OOM) errors in low-RAM environments like Colab.
    """
    def __init__(self, max_size_mb):
        self.max_bytes = max_size_mb * 1024 * 1024
        self.current_bytes = 0
        self.cache = OrderedDict()
        self.lock = threading.Lock()

    def get(self, key):
        with self.lock:
            if key in self.cache:
                self.cache.move_to_end(key)
                return self.cache[key]
            return None

    def put(self, key, value):
        with self.lock:
            if key in self.cache:
                return # Already cached

            size = sys.getsizeof(value)
            
            # If a single item is larger than the entire cache, don't cache it
            if size > self.max_bytes:
                return

            # Evict until we have enough space
            while self.current_bytes + size > self.max_bytes and self.cache:
                _, popped_value = self.cache.popitem(last=False)
                self.current_bytes -= sys.getsizeof(popped_value)

            self.cache[key] = value
            self.current_bytes += size
            
    def clear(self):
        with self.lock:
            self.cache.clear()
            self.current_bytes = 0


class CoreStreamEngine:
    """
    Core Engine for reading ZIP files safely, concurrently, and with caching.
    """
    def __init__(self, zip_path, max_cache_mb=1024):
        self.zip_path = zip_path
        self.cache = MemorySafeCache(max_cache_mb)
        
        # We index the central directory once to enable fast O(1) random access
        try:
            with zipfile.ZipFile(self.zip_path, 'r') as zf:
                # Filter out raw directories 
                self.infolist = [info for info in zf.infolist() if not info.filename.endswith('/')]
                self.filename_to_idx = {info.filename: idx for idx, info in enumerate(self.infolist)}
        except zipfile.BadZipFile:
            raise ValueError(f"Corrupted or invalid ZIP file: {zip_path}")
        except FileNotFoundError:
            raise FileNotFoundError(f"ZIP file not found: {zip_path}")
            
        # Thread local storage for zipfile objects. ZipFile is not fully thread-safe for reading 
        # from multiple threads concurrently unless each thread has its own file pointer.
        self.local_thread = threading.local()

    def __len__(self):
        return len(self.infolist)

    def _get_zip_ref(self):
        # Create a new ZipFile object per thread to avoid seeking collisions
        if not hasattr(self.local_thread, "zf"):
            self.local_thread.zf = zipfile.ZipFile(self.zip_path, 'r')
        return self.local_thread.zf

    def get_by_index(self, idx):
        """ Fetch file bytes via integer index with caching """
        cached_data = self.cache.get(idx)
        if cached_data is not None:
            return cached_data

        info = self.infolist[idx]
        zf = self._get_zip_ref()
        
        # Read from ZIP (decompression happens here)
        with zf.open(info) as f:
            data = f.read()
            
        self.cache.put(idx, data)
        return data

    def get_by_filename(self, filename):
        """ Fetch file bytes via filename """
        if filename not in self.filename_to_idx:
            raise KeyError(f"File {filename} not found in ZIP archive.")
        idx = self.filename_to_idx[filename]
        return self.get_by_index(idx)
        
    def get_filenames(self):
        return [info.filename for info in self.infolist]

    def close(self):
        """ Close thread-local zipfile if it exists """
        if hasattr(self.local_thread, "zf"):
            self.local_thread.zf.close()
            del self.local_thread.zf
