import os
from setuptools import setup, find_packages, Extension

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()


def get_ext_modules():
    """
    Attempt to build the optional C++ Pybind11 FastCoreEngine.
    If pybind11 or a C++ compiler is unavailable, skip silently.
    The library falls back to the pure-Python CoreStreamEngine automatically.
    """
    try:
        import pybind11
        pybind_includes = [pybind11.get_include()]
        ext = Extension(
            "cdmltrain.fast_core",
            ["cdmltrain/src/fast_core.cpp"],
            include_dirs=pybind_includes,
            language="c++",
            extra_compile_args=["/std:c++14"] if os.name == "nt" else ["-std=c++14", "-fPIC"]
        )
        print("[cdmltrain] pybind11 found — C++ FastCoreEngine will be compiled (Tier 2)")
        return [ext]
    except Exception as e:
        print(f"[cdmltrain] Skipping C++ extension (pybind11 not found or compiler missing: {e})")
        print("[cdmltrain] Pure-Python CoreStreamEngine will be used (Tier 1). All features work!")
        return []


setup(
    name="cdmltrain",
    version="1.1.0",
    author="prem85642",
    author_email="your.email@domain.com",
    description="Stream ML datasets from ZIP/ZSTD/S3 archives into PyTorch without disk extraction.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/prem85642/cdmltrain",
    packages=find_packages(),
    ext_modules=get_ext_modules(),  # Optional C++ — won't fail if unavailable
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Intended Audience :: Science/Research",
    ],
    python_requires=">=3.7",
    install_requires=[
        "Pillow>=8.0.0",
    ],
    extras_require={
        "zstd": ["zstandard>=0.20.0"],        # For .tar.zst support
        "gpu":  ["torch>=1.9.0"],              # For GPU Direct Loader
        "s3":   ["s3fs>=2023.0.0", "boto3>=1.20.0"],  # For Cloud Network Streaming
        "full": ["zstandard>=0.20.0", "torch>=1.9.0", "s3fs>=2023.0.0", "boto3>=1.20.0"],  # Everything
    }
)
