"""
dinox: Derivative-informed neural operators in JAX.
"""
