"""Stub file for deployment directory."""
from typing import Any, Dict, List, Optional, Set, Tuple

from __future__ import annotations
from camera_manager import CameraManager, Camera, CameraGroup, CameraGroupConfig, CameraConfig
from camera_manager import CameraManager, CameraGroupConfig, CameraConfig, Camera, CameraGroup
from dataclasses import dataclass
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from matrice_common.utils import handle_response
from matrice_common.utils import handle_response, get_summary
from streaming_gateway_manager import StreamingGatewayManager, StreamingGateway, StreamingGatewayConfig
from streaming_gateway_manager import StreamingGatewayManager, StreamingGatewayConfig, StreamingGateway
import json
import logging
import sys
import time

# Classes
# From camera_manager
class Camera:
    """
    Camera instance class for managing individual camera configurations.
    
    This class represents a single camera and provides methods to manage
    its configuration, stream settings, and operational status.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.camera_manager import Camera, CameraConfig
    
        session = Session(account_number="...", access_key="...", secret_key="...")
    
        # Create camera config
        config = CameraConfig(
            camera_name="entrance_cam_01",
            stream_url="rtsp://192.168.1.100:554/stream1",
            camera_group_id="group_id_123",
            custom_stream_settings={"videoQuality": 90}
        )
    
        # Create camera instance
        camera = Camera(session, config)
    
        # Save to backend
        result, error, message = camera.save(service_id="deployment_id")
        if not error:
            print(f"Camera created with ID: {camera.id}")
    
        # Update configuration
        camera.stream_url = "rtsp://192.168.1.101:554/stream1"
        result, error, message = camera.update()
        ```
    """

    def __init__(self: Any, session: Any, config: Optional[CameraConfig] = None, camera_id: Optional[str] = None) -> None: ...
        """
        Initialize a Camera instance.
        
        Args:
            session: Session object containing RPC client for API communication
            config: CameraConfig object (for new cameras)
            camera_id: ID of existing camera to load (mutually exclusive with config)
        """

    def camera_group_id(self: Any) -> str: ...
        """
        Get the camera group ID.
        """

    def camera_group_id(self: Any, value: str) -> Any: ...
        """
        Set the camera group ID.
        """

    def camera_name(self: Any) -> str: ...
        """
        Get the camera name.
        """

    def camera_name(self: Any, value: str) -> Any: ...
        """
        Set the camera name.
        """

    def custom_stream_settings(self: Any) -> Optional[Dict]: ...
        """
        Get the custom stream settings.
        """

    def custom_stream_settings(self: Any, value: Dict) -> Any: ...
        """
        Set the custom stream settings.
        """

    def delete(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete the camera from the backend.
        
        Returns:
            tuple: (result, error, message)
        """

    def get_effective_stream_settings(self: Any, group_defaults: Any) -> Any: ...
        """
        Get the effective stream settings by merging group defaults with custom overrides.
        
        Args:
            group_defaults: Default stream settings from the camera group
        
        Returns:
            StreamSettings with effective values
        """

    def get_stream_url(self: Any) -> str: ...
        """
        Get the camera stream URL.
        """

    def id(self: Any) -> Optional[str]: ...
        """
        Get the camera ID.
        """

    def is_stream_url(self: Any) -> bool: ...
        """
        Get whether the camera stream URL is a valid URL.
        """

    def is_stream_url(self: Any, value: bool) -> Any: ...
        """
        Set whether the camera stream URL is a valid URL.
        """

    def refresh(self: Any) -> Any: ...
        """
        Refresh the camera configuration from the backend.
        """

    def save(self: Any, account_number: str = None) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Save the camera configuration to the backend (create new).
        
        Args:
            account_number: The account number to associate with the camera
        
        Returns:
            tuple: (result, error, message)
        """

    def stream_url(self: Any) -> str: ...
        """
        Get the camera stream URL.
        """

    def stream_url(self: Any, value: str) -> Any: ...
        """
        Set the camera stream URL.
        """

    def update(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update the camera configuration in the backend.
        
        Returns:
            tuple: (result, error, message)
        """


# From camera_manager
class CameraConfig:
    """
    Camera configuration data class.
    
    Attributes:
        id: Unique identifier for the camera config (MongoDB ObjectID)
        id_service: Deployment ID this camera config belongs to (MongoDB ObjectID)
        camera_group_id: ID of the camera group this camera belongs to
        is_stream_url: Whether the stream URL is a valid URL
        camera_name: Name/identifier for the camera
        stream_url: URL for the camera stream
        custom_stream_settings: Custom stream settings that override group defaults
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create a CameraConfig instance from API response data.
        """

    def get_effective_stream_settings(self: Any, group_defaults: Any) -> Any: ...
        """
        Get the effective stream settings by merging group defaults with custom overrides.
        
        Args:
            group_defaults: Default stream settings from the camera group
        
        Returns:
            StreamSettings with effective values
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the camera config to a dictionary for API calls.
        """


# From camera_manager
class CameraGroup:
    """
    Camera group instance class for managing individual camera groups and their cameras.
    
    This class represents a single camera group and provides methods to manage
    its configuration, cameras, and operational status.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.camera_manager import CameraGroup, CameraGroup, StreamSettings
    
        session = Session(account_number="...", access_key="...", secret_key="...")
    
        # Create camera group config
        default_settings = StreamSettings(
            aspect_ratio="16:9",
            video_quality=80,
            height=1080,
            width=1920,
            fps=30,
            make="Hikvision",
            model="DS-2CD2143G0",
            streaming_fps=30
        )
    
        group_config = CameraGroupConfig(
            camera_group_name="Indoor Cameras",
            streaming_gateway_id="gateway123",
            default_stream_settings=default_settings,
            account_number="ACC-123",
            location_id="loc123"
        )
    
        # Create camera group instance
        camera_group = CameraGroup(session, group_config)
    
        # Save to backend
        result, error, message = camera_group.save(service_id="deployment_id")
        if not error:
            print(f"Camera group created with ID: {camera_group.id}")
    
        # Add cameras to the group
        camera_config = CameraConfig(
            camera_name="entrance_cam_01",
            stream_url="rtsp://192.168.1.100:554/stream1",
            camera_group_id=camera_group.id
        )
        camera, error, message = camera_group.add_camera(camera_config)
        ```
    """

    def __init__(self: Any, session: Any, config: Optional[CameraGroupConfig] = None, group_id: Optional[str] = None) -> None: ...
        """
        Initialize a CameraGroup.
        
        Args:
            session: Session object containing RPC client for API communication
            config: CameraGroup object (for new groups)
            group_id: ID of existing group to load (mutually exclusive with config)
        """

    def account_number(self: Any) -> Optional[str]: ...
        """
        Get the account number.
        """

    def account_number(self: Any, value: str) -> Any: ...
        """
        Set the account number.
        """

    def add_camera(self: Any, camera_config: Any) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Add a camera to this camera group.
        
        Args:
            camera_config: CameraConfig object containing the camera configuration
        
        Returns:
            tuple: (camera_instance, error, message)
        """

    def camera_group_name(self: Any) -> str: ...
        """
        Get the camera group name.
        """

    def camera_group_name(self: Any, value: str) -> Any: ...
        """
        Set the camera group name.
        """

    def cameras(self: Any) -> List['Camera']: ...
        """
        Get all cameras in this group.
        """

    def default_stream_settings(self: Any) -> Optional[StreamSettings]: ...
        """
        Get the default stream settings.
        """

    def default_stream_settings(self: Any, value: Any) -> Any: ...
        """
        Set the default stream settings.
        """

    def delete(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete the camera group from the backend.
        
        Returns:
            tuple: (result, error, message)
        """

    def get_cameras(self: Any, page: int = 1, limit: int = 10, search: str = None) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Get all cameras in this camera group.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
        
        Returns:
            tuple: (camera_instances, error, message)
        """

    def id(self: Any) -> Optional[str]: ...
        """
        Get the group ID.
        """

    def location_id(self: Any) -> Optional[str]: ...
        """
        Get the location ID.
        """

    def location_id(self: Any, value: str) -> Any: ...
        """
        Set the location ID.
        """

    def name(self: Any) -> str: ...
        """
        Get the group name (alias for camera_group_name).
        """

    def name(self: Any, value: str) -> Any: ...
        """
        Set the group name (alias for camera_group_name).
        """

    def refresh(self: Any) -> Any: ...
        """
        Refresh the camera group configuration and cameras from the backend.
        """

    def remove_camera(self: Any, camera_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Remove a camera from this camera group.
        
        Args:
            camera_id: ID of the camera to remove
        
        Returns:
            tuple: (result, error, message)
        """

    def save(self: Any, account_number: str = None) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Save the camera group configuration to the backend (create new).
        
        Args:
            account_number: The account number to associate with the camera group
        
        Returns:
            tuple: (result, error, message)
        """

    def streaming_gateway_id(self: Any) -> str: ...
        """
        Get the streaming gateway ID.
        """

    def streaming_gateway_id(self: Any, value: str) -> Any: ...
        """
        Set the streaming gateway ID.
        """

    def update(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update the camera group configuration in the backend.
        
        Returns:
            tuple: (result, error, message)
        """


# From camera_manager
class CameraGroupConfig:
    """
    Camera group data class for managing collections of cameras with shared settings.
    
    Attributes:
        camera_group_name: Name of the camera group
        streaming_gateway_id: ID of the streaming gateway this group belongs to
        default_stream_settings: Default stream settings for cameras in this group
        account_number: Account number for the camera group
        location_id: ID of the location (optional)
        id: Unique identifier for the camera group (MongoDB ObjectID)
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create a CameraGroup instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the camera group to a dictionary for API calls.
        """


# From camera_manager
class CameraLocation:
    """
    Camera location instance class for managing individual camera locations.
    
    This class represents a single camera location and provides methods to manage
    its configuration and operational status.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.camera_manager import CameraLocation, CameraLocationConfig, CameraLocationInfo
    
        session = Session(account_number="...", access_key="...", secret_key="...")
    
        # Create location info
        location_info = CameraLocationInfo(
            street_address="123 Main St",
            city="NYC",
            state="NY",
            country="USA"
        )
    
        # Create location config
        config = CameraLocationConfig(
            location_name="HQ Building",
            location_info=location_info,
            account_number="ACC-123"
        )
    
        # Create location instance
        location = CameraLocation(session, config)
    
        # Save to backend
        result, error, message = location.save()
        if not error:
            print(f"Location created with ID: {location.id}")
    
        # Update configuration
        location.location_name = "HQ North Wing"
        result, error, message = location.update()
        ```
    """

    def __init__(self: Any, session: Any, config: Optional[CameraLocationConfig] = None, location_id: Optional[str] = None) -> None: ...
        """
        Initialize a CameraLocation instance.
        
        Args:
            session: Session object containing RPC client for API communication
            config: CameraLocationConfig object (for new locations)
            location_id: ID of existing location to load (mutually exclusive with config)
        """

    def account_number(self: Any) -> Optional[str]: ...
        """
        Get the account number.
        """

    def account_number(self: Any, value: str) -> Any: ...
        """
        Set the account number.
        """

    def delete(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete the location from the backend.
        
        Returns:
            tuple: (result, error, message)
        """

    def id(self: Any) -> Optional[str]: ...
        """
        Get the location ID.
        """

    def location_info(self: Any) -> Optional[CameraLocationInfo]: ...
        """
        Get the location info.
        """

    def location_info(self: Any, value: Any) -> Any: ...
        """
        Set the location info.
        """

    def location_name(self: Any) -> str: ...
        """
        Get the location name.
        """

    def location_name(self: Any, value: str) -> Any: ...
        """
        Set the location name.
        """

    def refresh(self: Any) -> Any: ...
        """
        Refresh the location configuration from the backend.
        """

    def save(self: Any, account_number: str = None) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Save the location configuration to the backend (create new).
        
        Args:
            account_number: The account number to associate with the location
        
        Returns:
            tuple: (result, error, message)
        """

    def update(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update the location configuration in the backend.
        
        Returns:
            tuple: (result, error, message)
        """


# From camera_manager
class CameraLocationConfig:
    """
    Camera location configuration data class.
    
    Attributes:
        location_name: Name of the camera location
        location_info: Detailed location information
        account_number: Account number for the location
        id: Unique identifier for the location
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create CameraLocationConfig instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert location config to dictionary for API calls.
        """


# From camera_manager
class CameraLocationInfo:
    """
    Camera location info data class for detailed location information.
    
    Attributes:
        street_address: Street address of the location
        city: City name
        state: State or province
        country: Country name
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create CameraLocationInfo instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert location info to dictionary for API calls.
        """


# From camera_manager
class CameraManager:
    """
    Camera manager client for handling camera groups and configurations in deployments.
    
    This class provides methods to create, read, update, and delete camera groups and
    camera configurations associated with deployments. It offers a streamlined flow
    for managing camera infrastructure.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.camera_manager import CameraManager, CameraGroup, CameraConfig, StreamSettings
    
        session = Session(account_number="...", access_key="...", secret_key="...")
        camera_manager = CameraManager(session, service_id="...")
    
        # Create a camera group with default settings
        default_settings = StreamSettings(
            aspect_ratio="16:9",
            video_quality=80,
            height=1080,
            width=1920,
            fps=30,
            make="Hikvision",
            model="DS-2CD2143G0",
            streaming_fps=30
        )
    
        group = CameraGroupConfig(
            camera_group_name="Indoor Cameras",
            streaming_gateway_id="gateway123",
            default_stream_settings=default_settings,
            account_number="ACC-123",
            location_id="loc123"
        )
    
        # Create the camera group
        camera_group, error, message = camera_manager.create_camera_group(group)
        if error:
            print(f"Error: {error}")
        else:
            print(f"Camera group created: {camera_group.name}")
    
            # Add cameras to the group
            camera_config = CameraConfig(
                camera_name="main_entrance_cam",
                stream_url="rtsp://192.168.1.100:554/stream1",
                camera_group_id=camera_group.id,
                custom_stream_settings={"videoQuality": 90}
            )
    
            camera, error, message = camera_group.add_camera(camera_config)
            if not error:
                print(f"Camera added: {camera.camera_name}")
        ```
    """

    def __init__(self: Any, session: Any, service_id: Optional[str] = None, account_number: Optional[str] = None) -> None: ...
        """
        Initialize the CameraManager client.
        
        Args:
            session: Session object containing RPC client for API communication
            service_id: The ID of the deployment or the ID of the inference pipeline
            account_number: The account number for API calls
        """

    def add_camera_config(self: Any, config: Any) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Legacy method - use create_camera instead.
        """

    def add_camera_configs(self: Any, configs: List[CameraConfig]) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Legacy method - use add_cameras_to_group instead.
        """

    def add_cameras_to_group(self: Any, group_id: str, camera_configs: List[CameraConfig]) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Add multiple cameras to a camera group using individual camera creation.
        
        Args:
            group_id: The ID of the camera group
            camera_configs: List of CameraConfig objects
        
        Returns:
            tuple: (camera_instances, error, message)
        """

    def append_consuming_app_deployment_id(self: Any, camera_id: str, streaming_id: str, topic_type: str, app_deployment_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Append a consuming app deployment ID to an input topic.
        
        Args:
            camera_id: ID of the camera
            streaming_id: ID of the streaming gateway
            topic_type: Type of topic (should be 'input')
            app_deployment_id: App deployment ID to append
        
        Returns:
            tuple: (result, error, message)
        """

    def create_camera(self: Any, camera_config: Any) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Create a new camera configuration.
        
        Args:
            camera_config: CameraConfig object containing the camera configuration
        
        Returns:
            tuple: (camera_instance, error, message)
        """

    def create_camera_group(self: Any, group: Any) -> Tuple[Optional['CameraGroup'], Optional[str], str]: ...
        """
        Create a new camera group for a deployment.
        
        Args:
            group: CameraGroup object containing the group configuration
        
        Returns:
            tuple: (camera_group_instance, error, message)
                - camera_group_instance: CameraGroupInstance if successful, None otherwise
                - error: Error message if failed, None otherwise
                - message: Status message
        """

    def create_camera_location(self: Any, config: Any) -> Tuple[Optional['CameraLocation'], Optional[str], str]: ...
        """
        Create a new camera location.
        
        Args:
            config: CameraLocationConfig object containing the location configuration
        
        Returns:
            tuple: (camera_location, error, message)
        """

    def create_camera_stream_topic(self: Any, camera_id: str, streaming_gateway_id: str, topic_name: str, topic_type: str, status: str, ip_address: Optional[str] = None, port: Optional[int] = None, app_deployment_id: Optional[str] = None, consuming_app_deployment_ids: Optional[List[str]] = None) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Create a camera stream topic.
        
        Args:
            camera_id: ID of the camera
            streaming_gateway_id: ID of the streaming gateway
            topic_name: Name of the topic
            topic_type: Type of topic (input|output)
            status: Status of the topic
            ip_address: IP address (optional)
            port: Port number (optional)
            app_deployment_id: App deployment ID for output topics (optional)
            consuming_app_deployment_ids: List of consuming app deployment IDs for input topics (optional)
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_all_cameras(self: Any, confirm: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete all cameras for account using individual camera deletion.
        
        Args:
            confirm: Must be True to confirm bulk deletion
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_camera(self: Any, camera_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete a camera by its ID.
        
        Args:
            camera_id: The ID of the camera to delete
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_camera_config_by_id(self: Any, config_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Legacy method - use delete_camera instead.
        """

    def delete_camera_configs(self: Any, confirm: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Legacy method - use delete_all_cameras instead.
        """

    def delete_camera_group(self: Any, group_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete a camera group by its ID.
        
        Args:
            group_id: The ID of the camera group to delete
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_camera_location(self: Any, location_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete a camera location by its ID.
        
        Args:
            location_id: The ID of the location to delete
        
        Returns:
            tuple: (result, error, message)
        """

    def get_camera_by_id(self: Any, camera_id: str) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Get a camera by its ID.
        
        Args:
            camera_id: The ID of the camera to retrieve
        
        Returns:
            tuple: (camera_instance, error, message)
        """

    def get_camera_config_by_id(self: Any, config_id: str) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Legacy method - use get_camera_by_id instead.
        """

    def get_camera_configs(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None, group_id: Optional[str] = None) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Legacy method - use get_cameras instead.
        """

    def get_camera_group_by_id(self: Any, group_id: str) -> Tuple[Optional['CameraGroup'], Optional[str], str]: ...
        """
        Get a camera group by its ID.
        
        Args:
            group_id: The ID of the camera group to retrieve
        
        Returns:
            tuple: (camera_group_instance, error, message)
        """

    def get_camera_groups(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None) -> Tuple[Optional[List['CameraGroup']], Optional[str], str]: ...
        """
        Get all camera groups for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
        
        Returns:
            tuple: (camera_group_instances, error, message)
        """

    def get_camera_groups_paginated(self: Any, page: int = 1, limit: int = 10) -> Tuple[Optional[List['CameraGroup']], Optional[str], str]: ...
        """
        Get paginated camera groups for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
        
        Returns:
            tuple: (camera_group_instances, error, message)
        """

    def get_camera_location_by_id(self: Any, location_id: str) -> Tuple[Optional['CameraLocation'], Optional[str], str]: ...
        """
        Get a camera location by its ID.
        
        Args:
            location_id: The ID of the camera location to retrieve
        
        Returns:
            tuple: (camera_location, error, message)
        """

    def get_camera_locations(self: Any, page: int = 1, limit: int = 10) -> Tuple[Optional[List['CameraLocation']], Optional[str], str]: ...
        """
        Get all camera locations for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
        
        Returns:
            tuple: (camera_locations, error, message)
        """

    def get_camera_locations_paginated(self: Any, page: int = 1, limit: int = 10) -> Tuple[Optional[List['CameraLocation']], Optional[str], str]: ...
        """
        Get paginated camera locations for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
        
        Returns:
            tuple: (camera_locations, error, message)
        """

    def get_cameras(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None, group_id: Optional[str] = None) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Get all cameras for a specific deployment.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
            group_id: Optional filter by camera group ID
        
        Returns:
            tuple: (camera_instances, error, message)
        """

    def get_stream_url(self: Any, config_id: str) -> Tuple[Optional[str], Optional[str], str]: ...
        """
        Get the stream URL for a camera configuration.
        
        Args:
            config_id: The ID of the camera configuration
        
        Returns:
            tuple: (stream_url, error, message)
        """

    def handle_response(self: Any, response: Dict, success_message: str, failure_message: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Handle API response and return standardized tuple.
        """

    def list_camera_configs(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None, group_id: Optional[str] = None) -> Tuple[Optional[List[Dict]], Optional[str], str]: ...
        """
        List all camera configs for account (updated to use account-based approach).
        
        Returns:
            tuple: (camera_configs, error, message)
        """

    def update_camera(self: Any, camera_id: str, camera_config: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update an existing camera configuration.
        
        Args:
            camera_id: The ID of the camera to update
            camera_config: CameraConfig object with updated configuration
        
        Returns:
            tuple: (result, error, message)
        """

    def update_camera_config(self: Any, config_id: str, config: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Legacy method - use update_camera instead.
        """

    def update_camera_group(self: Any, group_id: str, group: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update an existing camera group.
        
        Args:
            group_id: The ID of the camera group to update
            group: CameraGroup object with updated configuration
        
        Returns:
            tuple: (result, error, message)
        """

    def update_camera_location(self: Any, location_id: str, config: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update an existing camera location.
        
        Args:
            location_id: The ID of the location to update
            config: CameraLocationConfig object with updated configuration
        
        Returns:
            tuple: (result, error, message)
        """

    def update_topic_ip_and_port(self: Any, camera_id: str, streaming_id: str, topic_type: str, ip_address: str, port: int) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update IP address and port on a camera stream topic.
        
        Args:
            camera_id: ID of the camera
            streaming_id: ID of the streaming gateway
            topic_type: Type of topic (input|output)
            ip_address: New IP address
            port: New port number
        
        Returns:
            tuple: (result, error, message)
        """


# From camera_manager
class StreamSettings:
    """
    Stream settings data class for camera configurations.
    
    Attributes:
        aspect_ratio: Aspect ratio of the camera (e.g., "16:9", "4:3")
        video_quality: Video quality setting (0-100)
        height: Video height in pixels
        width: Video width in pixels
        fps: Frames per second
        make: Camera make/manufacturer (optional)
        model: Camera model (optional)
        streaming_fps: Streaming FPS (optional, can differ from recording fps)
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create a StreamSettings instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the stream settings to a dictionary for API calls.
        """


# From deployment
class Deployment:
    """
    Class to manage deployment-related operations within a project.
    
    The `Deployment` class initializes with a given session and deployment details,
    allowing users to access and manage the deployment attributes such as status,
    configuration, and associated project information.
    
    Parameters
    ----------
    session : object
        The session object containing project and RPC information.
    deployment_id : str, optional
        The ID of the deployment to manage. Default is None.
    deployment_name : str, optional
        The name of the deployment. Default is None.
    
    Attributes
    ----------
    session : object
        The session object for RPC communication.
    rpc : object
        The RPC interface for backend API communication.
    project_id : str
        The project ID associated with the deployment.
    deployment_id : str
        The unique ID of the deployment.
    deployment_name : str
        Name of the deployment.
    model_id : str
        ID of the model associated with the deployment.
    user_id : str
        User ID of the deployment owner.
    user_name : str
        Username of the deployment owner.
    action_id : str
        ID of the action associated with the deployment.
    auth_keys : list
        List of authorization keys for the deployment.
    runtime_framework : str
        Framework used for the runtime of the model in the deployment.
    model_input : dict
        Input format expected by the model.
    model_type : str
        Type of model deployed (e.g., classification, detection).
    model_output : dict
        Output format of the deployed model.
    deployment_type : str
        Type of deployment (e.g., real-time, batch).
    suggested_classes : list
        Suggested classes for classification models.
    running_instances : list
        List of currently running instances.
    auto_shutdown : bool
        Whether the deployment has auto-shutdown enabled.
    auto_scale : bool
        Whether the deployment is configured for auto-scaling.
    gpu_required : bool
        Whether GPU is required for the deployment.
    status : str
        Current status of the deployment.
    hibernation_threshold : int
        Threshold for auto-hibernation in minutes.
    image_store_confidence_threshold : float
        Confidence threshold for storing images.
    image_store_count_threshold : int
        Count threshold for storing images.
    images_stored_count : int
        Number of images currently stored.
    bucket_alias : str
        Alias for the storage bucket associated with the deployment.
    credential_alias : str
        Alias for credentials used in the deployment.
    created_at : str
        Timestamp when the deployment was created.
    updated_at : str
        Timestamp when the deployment was last updated.
    compute_alias : str
        Alias of the compute resource associated with the deployment.
    is_optimized : bool
        Indicates whether the deployment is optimized.
    status_cards : list
        List of status cards related to the deployment.
    total_deployments : int or None
        Total number of deployments in the project.
    active_deployments : int or None
        Number of active deployments in the project.
    total_running_instances_count : int or None
        Total count of running instances in the project.
    hibernated_deployments : int or None
        Number of hibernated deployments.
    error_deployments : int or None
        Number of deployments with errors.
    camera_manager : CameraManager
        Manager for camera groups and configurations.
    streaming_gateway_manager : StreamingGatewayManager
        Manager for streaming gateways.
    
    Example
    -------
    >>> session = Session(account_number="account_number")
    >>> deployment = Deployment(session=session, deployment_id="deployment_id", deployment_name="MyDeployment")
    """

    def __init__(self: Any, session: Any, deployment_id: Any = None, deployment_name: Any = None) -> None: ...

    def add_camera_config(self: Any, config: Any) -> Any: ...
        """
        Legacy method - use create_camera instead.
        """

    def add_camera_groups_to_streaming_gateway(self: Any, gateway_id: str, camera_group_ids: List[str]) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Add camera groups to a streaming gateway.
        
        Args:
            gateway_id: The ID of the streaming gateway
            camera_group_ids: List of camera group IDs to add
        
        Returns:
            tuple: (result, error, message)
        """

    def add_cameras_to_group(self: Any, group_id: str, camera_configs: List[CameraConfig]) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Add multiple cameras to a camera group in this deployment.
        
        Args:
            group_id: The ID of the camera group
            camera_configs: List of CameraConfig objects
        
        Returns:
            tuple: (camera_instances, error, message)
        """

    def create_auth_key(self: Any, expiry_days: Any) -> Any: ...
        """
        Create a new authentication key for the deployment, valid for the specified number of days.
        The `deployment_id` and `project_id` must be set during initialization.
        
        Parameters
        ----------
        expiry_days : int
            The number of days before the authentication key expires.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with details of the created authentication key,
            including keys such as:
                - `authKey` (str): The newly created authentication key.
                - `expiryDate` (str): Expiration date of the key.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Examples
        --------
        >>> auth_key, err, msg = deployment.create_auth_key(30)
        >>> if err:
        >>>     pprint(err)
        >>> else:
        >>>     pprint(auth_key)
        """

    def create_camera(self: Any, camera_config: Any) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Create a new camera for this deployment.
        
        Args:
            camera_config: CameraConfig object containing the camera configuration
        
        Returns:
            tuple: (camera_instance, error, message)
        """

    def create_camera_group(self: Any, group: Any) -> Tuple[Optional['CameraGroup'], Optional[str], str]: ...
        """
        Create a new camera group for this deployment.
        
        Args:
            group: CameraGroup object containing the group configuration
        
        Returns:
            tuple: (camera_group_instance, error, message)
        """

    def create_dataset(self: Any, dataset_name: Any, is_unlabeled: Any, source: Any, source_url: Any, is_public: Any, dataset_description: Any = '', version_description: Any = '') -> Any: ...
        """
        Create a new dataset from a deployment. Only zip files are supported for upload,
        and the deployment ID must be set for this operation.
        
        Parameters
        ----------
        dataset_name : str
            The name of the new dataset.
        is_unlabeled : bool
            Indicates whether the dataset is unlabeled.
        source : str
            The source of the dataset (e.g., "aws").
        source_url : str
            The URL of the dataset to be created.
        is_public : bool
            Specifies if the dataset is public.
        dataset_description : str, optional
            A description for the dataset. Default is an empty string.
        version_description : str, optional
            A description for this version of the dataset. Default is an empty string.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with details of the dataset creation, structured as:
                - `datasetId` (str): ID of the created dataset.
                - `status` (str): Status of the dataset creation request.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Example
        -------
        >>> from pprint import pprint
        >>> resp, err, msg = deployment.create_dataset(
        ...     dataset_name="New Dataset",
        ...     is_unlabeled=False,
        ...     source="aws",
        ...     source_url="https://example.com/dataset.zip",
        ...     is_public=True,
        ...     dataset_description="Dataset description",
        ...     version_description="Version description"
        ... )
        >>> if err:
        ...     pprint(err)
        >>> else:
        ...     pprint(resp)
        """

    def create_streaming_gateway(self: Any, gateway_config: Any) -> Tuple[Optional['StreamingGateway'], Optional[str], str]: ...
        """
        Create a new streaming gateway for this deployment.
        
        Args:
            gateway_config: StreamingGatewayConfig object containing the gateway configuration
        
        Returns:
            tuple: (streaming_gateway, error, message)
        """

    def delete(self: Any) -> Any: ...
        """
        Delete the specified deployment.
        
        This method deletes the deployment identified by `deployment_id` from the backend system.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response confirming the deletion.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Raises
        ------
        SystemExit
            If `deployment_id` is not set.
        
        Examples
        --------
        >>> delete, err, msg = deployment.delete()
        >>> if err:
        >>>     pprint(err)
        >>> else:
        >>>     pprint(delete)
        """

    def delete_all_cameras(self: Any, confirm: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete all cameras for this deployment.
        
        Args:
            confirm: Must be True to confirm bulk deletion
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_auth_key(self: Any, auth_key: Any) -> Any: ...
        """
        Delete a specified authentication key for the current deployment.
        The `deployment_id` must be set during initialization.
        
        Parameters
        ----------
        auth_key : str
            The authentication key to be deleted.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response indicating the result of the delete operation.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Raises
        ------
        SystemExit
            If `deployment_id` is not set.
        
        Examples
        --------
        >>> delete_auth_key, err, msg = deployment.delete_auth_key("abcd1234")
        >>> if err:
        >>>     pprint(err)
        >>> else:
        >>>     pprint(delete_auth_key)
        """

    def delete_camera(self: Any, camera_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete a camera by its ID.
        
        Args:
            camera_id: The ID of the camera to delete
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_camera_group(self: Any, group_id: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete a camera group by its ID.
        
        Args:
            group_id: The ID of the camera group to delete
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_streaming_gateway(self: Any, gateway_id: str, force: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete a streaming gateway by its ID.
        
        Args:
            gateway_id: The ID of the streaming gateway to delete
            force: Force delete even if active
        
        Returns:
            tuple: (result, error, message)
        """

    def get_camera_by_id(self: Any, camera_id: str) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Get a camera by its ID.
        
        Args:
            camera_id: The ID of the camera to retrieve
        
        Returns:
            tuple: (camera_instance, error, message)
        """

    def get_camera_configs(self: Any, page: int = 1, limit: int = 10, search: str = None, group_id: str = None) -> Any: ...
        """
        Legacy method - use get_cameras instead.
        """

    def get_camera_group_by_id(self: Any, group_id: str) -> Tuple[Optional['CameraGroup'], Optional[str], str]: ...
        """
        Get a camera group by its ID.
        
        Args:
            group_id: The ID of the camera group to retrieve
        
        Returns:
            tuple: (camera_group_instance, error, message)
        """

    def get_camera_groups(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None) -> Tuple[Optional[List['CameraGroup']], Optional[str], str]: ...
        """
        Get all camera groups for this deployment.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
        
        Returns:
            tuple: (camera_group_instances, error, message)
        """

    def get_cameras(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None, group_id: Optional[str] = None) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Get all cameras for this deployment.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
            group_id: Optional filter by camera group ID
        
        Returns:
            tuple: (camera_instances, error, message)
        """

    def get_deployment_server(self: Any, model_train_id: Any, model_type: Any) -> Any: ...
        """
        Fetch information about the deployment server for a specific model.
        
        Parameters
        ----------
        model_train_id : str
            The ID of the model training instance.
        model_type : str
            The type of model (e.g., 'trained', 'exported').
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with details of the deployment server.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Examples
        --------
        >>> deployment_server, err, msg = deployment.get_deployment_server("train123", "trained")
        >>> if err:
        >>>     pprint(err)
        >>> else:
        >>>     pprint(deployment_server)
        """

    def get_prediction(self: Any, input_path: Any = None, auth_key: Any = '', input_url: Any = None, extra_params: Any = {}) -> Any: ...
        """
        Fetch model predictions for a given image using a deployment.
        
        This method sends an image to the deployment for prediction. Either `deployment_id`
        or `deployment_name` must be provided in the instance to locate the deployment.
        
        Parameters
        ----------
        input_path : str
            The path to the input for prediction.
        auth_key : str
            The authentication key required for authorizing the prediction request.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with the prediction results, structured as:
                - `predictions` (list of dict): Each entry contains:
                    - `class` (str): The predicted class label.
                    - `confidence` (float): Confidence score of the prediction.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the prediction request.
        
        Raises
        ------
        ValueError
            If `auth_key` is not provided or if neither `deployment_id` nor `deployment_name` is
                set.
        
        Examples
        --------
        >>> from pprint import pprint
        >>> result, error, message = deployment.get_prediction(
        ...     input_path="/path/to/input.jpg",
        ...     auth_key="auth123"
        ... )
        >>> if error:
        ...     pprint(error)
        >>> else:
        ...     pprint(result)
        """

    def get_streaming_gateway_by_id(self: Any, gateway_id: str) -> Tuple[Optional['StreamingGateway'], Optional[str], str]: ...
        """
        Get a streaming gateway by its ID.
        
        Args:
            gateway_id: The ID of the streaming gateway to retrieve
        
        Returns:
            tuple: (streaming_gateway, error, message)
        """

    def get_streaming_gateways(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None) -> Tuple[Optional[List['StreamingGateway']], Optional[str], str]: ...
        """
        Get all streaming gateways for this deployment.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
        
        Returns:
            tuple: (streaming_gateways, error, message)
        """

    def refresh(self: Any) -> Any: ...
        """
        Refresh the instance by reinstantiating it with the previous values.
        """

    def remove_camera_groups_from_streaming_gateway(self: Any, gateway_id: str, camera_group_ids: List[str]) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Remove camera groups from a streaming gateway.
        
        Args:
            gateway_id: The ID of the streaming gateway
            camera_group_ids: List of camera group IDs to remove
        
        Returns:
            tuple: (result, error, message)
        """

    def rename(self: Any, updated_name: Any) -> Any: ...
        """
        Update the deployment name for the current deployment.
        
        Parameters
        ----------
        updated_name : str
            The new name for the deployment.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with details of the rename operation.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Raises
        ------
        SystemExit
            If `deployment_id` is not set.
        
        Examples
        --------
        >>> from pprint import pprint
        >>> deployment = Deployment(session, deployment_id="1234")
        >>> rename, err, msg = deployment.rename("NewDeploymentName")
        >>> if err:
        >>>     pprint(err)
        >>> else:
        >>>     pprint(rename)
        """

    def request_count_monitor(self: Any, start_date: Any, end_date: Any, granularity: Any = 'second') -> Any: ...
        """
        Monitor the count of requests within a specified time range and granularity for the current
            deployment.
        
        Parameters
        ----------
        start_date : str
            The start date of the monitoring period in ISO format (e.g., "YYYY-MM-DDTHH:MM:SSZ").
        end_date : str
            The end date of the monitoring period in ISO format.
        granularity : str, optional
            The time granularity for the request count (e.g., "second", "minute")
            . Default is "second".
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with the request count details, structured as:
                - `counts` (list of dict): Each entry contains:
                    - `timestamp` (str): The timestamp of the request count.
                    - `count` (int): The number of requests at that timestamp.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Examples
        --------
        >>> start = "2024-01-28T18:30:00.000Z"
        >>> end = "2024-02-29T10:11:27.000Z"
        >>> count_monitor, error, message = deployment.request_count_monitor(start, end)
        >>> if error:
        >>>     pprint(error)
        >>> else:
        >>>     pprint(count_monitor)
        """

    def request_latency_monitor(self: Any, start_date: Any, end_date: Any, granularity: Any = 'second') -> Any: ...
        """
        Monitor the request latency within a specified time range and granularity for the current
            deployment.
        
        Parameters
        ----------
        start_date : str
            The start date of the monitoring period in ISO format (e.g., "YYYY-MM-DDTHH:MM:SSZ").
        end_date : str
            The end date of the monitoring period in ISO format.
        granularity : str, optional
            The time granularity for latency tracking (e.g., "second", "minute"). Default is
                "second".
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with latency details, structured as:
                - `latencies` (list of dict): Each entry contains:
                    - `timestamp` (str): The timestamp of the latency record.
                    - `avg_latency` (float): The average latency in seconds for the requests at
                        that timestamp.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Examples
        --------
        >>> from pprint import pprint
        >>> start = "2024-01-28T18:30:00.000Z"
        >>> end = "2024-02-29T10:11:27.000Z"
        >>> result, error, message = deployment.request_latency_monitor(start, end)
        >>> if error:
        >>>     pprint(error)
        >>> else:
        >>>     pprint(result)
        """

    def request_total_monitor(self: Any) -> Any: ...
        """
        Monitor the total number of requests for the current deployment.
        
        This method checks the total request count for a deployment by its `deployment_id`.
        If `deployment_id` is not set, it attempts to fetch it using `deployment_name`.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with the total request count.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Raises
        ------
        SystemExit
            If both `deployment_id` and `deployment_name` are not set.
        
        Examples
        --------
        >>> from pprint import pprint
        >>> monitor, error, message = deployment.request_total_monitor()
        >>> if error:
        >>>     pprint(error)
        >>> else:
        >>>     pprint(monitor)
        """

    def set_auth_key(self: Any, auth_key: Any) -> Any: ...

    def update_camera(self: Any, camera_id: str, camera_config: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update an existing camera.
        
        Args:
            camera_id: The ID of the camera to update
            camera_config: CameraConfig object with updated configuration
        
        Returns:
            tuple: (result, error, message)
        """

    def update_camera_group(self: Any, group_id: str, group: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update an existing camera group.
        
        Args:
            group_id: The ID of the camera group to update
            group: CameraGroup object with updated configuration
        
        Returns:
            tuple: (result, error, message)
        """

    def update_streaming_gateway(self: Any, gateway_id: str, gateway_config: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update an existing streaming gateway.
        
        Args:
            gateway_id: The ID of the streaming gateway to update
            gateway_config: StreamingGatewayConfig object with updated configuration
        
        Returns:
            tuple: (result, error, message)
        """

    def wakeup_deployment_server(self: Any) -> Any: ...
        """
        Wake up the deployment server associated with the current deployment.
        The `deployment_id` must be set during initialization.
        
        Returns
        -------
        tuple
            A tuple containing three elements:
            - dict: The API response with details of the wake-up operation.
            - str or None: Error message if an error occurred, otherwise None.
            - str: Status message indicating success or failure of the API call.
        
        Raises
        ------
        SystemExit
            If `deployment_id` is not set.
        
        Examples
        --------
        >>> wakeup, err, msg = deployment.wakeup_deployment_server()
        >>> if err:
        >>>     pprint(err)
        >>> else:
        >>>     pprint(wakeup)
        """


# From inference_pipeline
class Aggregator:
    """
    Aggregator configuration for inference pipelines.
    
    Attributes:
        id: Unique identifier for the aggregator (MongoDB ObjectID)
        action_id: ID of the associated action (MongoDB ObjectID)
        status: Status of the aggregator
        is_running: Whether the aggregator is currently running
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create an Aggregator instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the aggregator to a dictionary for API calls.
        """


# From inference_pipeline
class ApplicationDeployment:
    """
    Application deployment configuration for inference pipelines.
    
    Attributes:
        application_id: ID of the application
        application_version: Version of the application
        deployment_id: ID of the deployment (optional)
        status: Status of the application deployment
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create an ApplicationDeployment instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the application deployment to a dictionary for API calls.
        """


# From inference_pipeline
class InferencePipeline:
    """
    Inference pipeline instance for managing a specific ML model deployment orchestration.
    
    This class provides methods to start, stop, monitor, and manage a single inference pipeline
    that orchestrates the deployment and execution of machine learning models for
    real-time data processing and inference.
    
    Example:
        Working with a specific inference pipeline:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.inference_pipeline import InferencePipeline
    
        session = Session(account_number="...", access_key="...", secret_key="...")
    
        # Load existing pipeline
        pipeline = InferencePipeline(session, pipeline_id="664ab1df23abcf1c33123456")
    
        # Start the pipeline
        result, error, message = pipeline.start()
        if not error:
            print("Pipeline started successfully")
    
        # Check status
        status, error, message = pipeline.get_status()
        if not error:
            print(f"Pipeline status: {status}")
    
        # Stop the pipeline
        result, error, message = pipeline.stop()
        ```
    """

    def __init__(self: Any, session: Any, config: Optional[InferencePipelineConfig] = None, pipeline_id: Optional[str] = None) -> None: ...
        """
        Initialize an InferencePipeline instance.
        
        Args:
            session: Session object containing RPC client for API communication
            config: InferencePipelineConfig object (for new pipelines)
            pipeline_id: The ID of an existing pipeline to load
        """

    def add_camera_groups_to_streaming_gateway(self: Any, gateway_id: str, camera_group_ids: List[str]) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Add camera groups to a streaming gateway.
        
        Args:
            gateway_id: The ID of the streaming gateway
            camera_group_ids: List of camera group IDs to add
        
        Returns:
            tuple: (result, error, message)
        """

    def add_cameras_to_group(self: Any, group_id: str, camera_configs: List[CameraConfig]) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Add multiple cameras to a camera group in this inference pipeline.
        
        Args:
            group_id: The ID of the camera group
            camera_configs: List of CameraConfig objects
        
        Returns:
            tuple: (camera_instances, error, message)
        """

    def aggregators(self: Any) -> Optional[List[Aggregator]]: ...
        """
        Get the pipeline aggregators.
        """

    def aggregators(self: Any, value: List[Aggregator]) -> Any: ...
        """
        Set the pipeline aggregators.
        """

    def applications(self: Any) -> List[ApplicationDeployment]: ...
        """
        Get the pipeline applications.
        """

    def applications(self: Any, value: List[ApplicationDeployment]) -> Any: ...
        """
        Set the pipeline applications.
        """

    def config(self: Any) -> Optional[InferencePipelineConfig]: ...
        """
        Get the pipeline configuration.
        """

    def config(self: Any, value: Any) -> Any: ...
        """
        Set the pipeline configuration.
        """

    def create_camera(self: Any, camera_config: Any) -> Tuple[Optional['Camera'], Optional[str], str]: ...
        """
        Create a camera for this inference pipeline.
        
        Args:
            camera_config: CameraConfig object containing the camera configuration
        
        Returns:
            tuple: (camera_instance, error, message)
        """

    def create_camera_group(self: Any, group: Any) -> Tuple[Optional['CameraGroup'], Optional[str], str]: ...
        """
        Create a camera group for this inference pipeline.
        
        Args:
            group: CameraGroupConfig object containing the group configuration
        
        Returns:
            tuple: (camera_group_instance, error, message)
        """

    def create_streaming_gateway(self: Any, gateway_config: Any) -> Tuple[Optional['StreamingGateway'], Optional[str], str]: ...
        """
        Create a streaming gateway for this inference pipeline.
        
        Args:
            gateway_config: StreamingGatewayConfig object containing the gateway configuration
        
        Returns:
            tuple: (streaming_gateway, error, message)
        """

    def delete(self: Any, force: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete this inference pipeline and clean up all associated resources.
        
        Args:
            force: Force delete even if active
        
        Returns:
            tuple: (result, error, message)
        """

    def delete_streaming_gateway(self: Any, gateway_id: str, force: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete a streaming gateway by its ID.
        
        Args:
            gateway_id: The ID of the streaming gateway to delete
            force: Force delete even if active
        
        Returns:
            tuple: (result, error, message)
        """

    def deployment_ids(self: Any) -> List[str]: ...
        """
        Get the deployment IDs.
        """

    def description(self: Any) -> str: ...
        """
        Get the pipeline description.
        """

    def description(self: Any, value: str) -> Any: ...
        """
        Set the pipeline description.
        """

    def get_camera_group_by_id(self: Any, group_id: str) -> Tuple[Optional['CameraGroup'], Optional[str], str]: ...
        """
        Get a camera group by its ID.
        
        Args:
            group_id: The ID of the camera group to retrieve
        
        Returns:
            tuple: (camera_group_instance, error, message)
        """

    def get_camera_groups(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None) -> Tuple[Optional[List['CameraGroup']], Optional[str], str]: ...
        """
        Get camera groups for this inference pipeline.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
        
        Returns:
            tuple: (camera_group_instances, error, message)
        """

    def get_cameras(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None, group_id: Optional[str] = None) -> Tuple[Optional[List['Camera']], Optional[str], str]: ...
        """
        Get cameras for this inference pipeline.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
            group_id: Optional filter by camera group ID
        
        Returns:
            tuple: (camera_instances, error, message)
        """

    def get_details(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Retrieve detailed information about this inference pipeline.
        
        Returns:
            tuple: (pipeline_details, error, message)
        """

    def get_status(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Retrieve the current status of this inference pipeline.
        
        Returns:
            tuple: (result, error, message)
        """

    def get_streaming_gateway_by_id(self: Any, gateway_id: str) -> Tuple[Optional['StreamingGateway'], Optional[str], str]: ...
        """
        Get a streaming gateway by its ID.
        
        Args:
            gateway_id: The ID of the streaming gateway to retrieve
        
        Returns:
            tuple: (streaming_gateway, error, message)
        """

    def get_streaming_gateways(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None) -> Tuple[Optional[List['StreamingGateway']], Optional[str], str]: ...
        """
        Get streaming gateways for this inference pipeline.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
        
        Returns:
            tuple: (streaming_gateways, error, message)
        """

    def id(self: Any) -> Optional[str]: ...
        """
        Get the pipeline ID.
        """

    def name(self: Any) -> str: ...
        """
        Get the pipeline name.
        """

    def name(self: Any, value: str) -> Any: ...
        """
        Set the pipeline name.
        """

    def refresh(self: Any) -> Any: ...
        """
        Refresh the pipeline configuration from the backend.
        """

    def remove_camera_groups_from_streaming_gateway(self: Any, gateway_id: str, camera_group_ids: List[str]) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Remove camera groups from a streaming gateway.
        
        Args:
            gateway_id: The ID of the streaming gateway
            camera_group_ids: List of camera group IDs to remove
        
        Returns:
            tuple: (result, error, message)
        """

    def save(self: Any, project_id: Optional[str] = None) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Save this inference pipeline to the backend.
        
        Args:
            project_id: The ID of the project (optional if set in config)
        
        Returns:
            tuple: (result, error, message)
        """

    def start(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Start this inference pipeline for real-time processing.
        
        Returns:
            tuple: (result, error, message)
        """

    def status(self: Any) -> Optional[str]: ...
        """
        Get the pipeline status.
        """

    def stop(self: Any, force: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Stop this inference pipeline and clean up resources.
        
        Args:
            force: Force stop even if active streams exist
        
        Returns:
            tuple: (result, error, message)
        """

    def update(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update this inference pipeline with the current configuration.
        
        Returns:
            tuple: (result, error, message)
        """

    def update_streaming_gateway(self: Any, gateway_id: str, gateway_config: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update an existing streaming gateway.
        
        Args:
            gateway_id: The ID of the streaming gateway to update
            gateway_config: StreamingGatewayConfig object with updated configuration
        
        Returns:
            tuple: (result, error, message)
        """

    def wait_for_active(self: Any, timeout: int = 300, poll_interval: int = 10) -> Tuple[bool, Optional[str], str]: ...
        """
        Wait for this pipeline to reach 'active' status.
        
        Args:
            timeout: Maximum time to wait in seconds
            poll_interval: Time between status checks in seconds
        
        Returns:
            tuple: (is_active, error, message)
        """

    def wait_for_ready(self: Any, timeout: int = 300, poll_interval: int = 10) -> Tuple[bool, Optional[str], str]: ...
        """
        Wait for this pipeline to reach 'ready' status.
        
        Args:
            timeout: Maximum time to wait in seconds
            poll_interval: Time between status checks in seconds
        
        Returns:
            tuple: (is_ready, error, message)
        """


# From inference_pipeline
class InferencePipelineConfig:
    """
    Inference pipeline configuration data class.
    
    Attributes:
        name: Name of the inference pipeline
        description: Description of the inference pipeline
        applications: List of application deployments
        aggregators: List of aggregators (optional)
        id: Unique identifier for the pipeline (MongoDB ObjectID)
        project_id: Project ID this pipeline belongs to
        user_id: User ID who created the pipeline
        status: Status of the pipeline
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create an InferencePipelineConfig instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the inference pipeline config to a dictionary for API calls.
        """


# From inference_pipeline
class InferencePipelineManager:
    """
    Manager for inference pipeline operations.
    
    This class provides methods to create, list, and manage multiple inference pipelines
    within a project. It handles the overall management of inference pipelines while
    individual pipelines are managed through the InferencePipeline class.
    
    Example:
        Managing multiple inference pipelines:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.inference_pipeline import InferencePipelineManager, InferencePipelineConfig, ApplicationDeployment
    
        session = Session(account_number="...", access_key="...", secret_key="...")
        manager = InferencePipelineManager(session)
    
        # Create a new pipeline
        apps = [
            ApplicationDeployment(
                application_id="664ab1df23abcf1c33123456",
                application_version="v1.0"
            )
        ]
    
        config = InferencePipelineConfig(
            name="Multi-App Pipeline",
            description="Pipeline for multiple applications",
            applications=apps
        )
    
        pipeline, error, message = manager.create_inference_pipeline(config)
        if not error:
            print(f"Created pipeline: {pipeline.id}")
    
        # List all pipelines
        pipelines, error, message = manager.get_inference_pipelines()
        if not error:
            print(f"Found {len(pipelines)} pipelines")
        ```
    """

    def __init__(self: Any, session: Any, project_id: Optional[str] = None) -> None: ...
        """
        Initialize the InferencePipelineManager.
        
        Args:
            session: Session object containing RPC client for API communication
            project_id: The ID of the project (optional, can be inferred from session)
        """

    def create_inference_pipeline(self: Any, config: Any, project_id: Optional[str] = None) -> Tuple[Optional['InferencePipeline'], Optional[str], str]: ...
        """
        Create a new inference pipeline.
        
        Args:
            config: InferencePipelineConfig object containing the pipeline configuration
            project_id: The ID of the project (optional, uses manager's project_id if not provided)
        
        Returns:
            tuple: (inference_pipeline_instance, error, message)
        """

    def get_inference_pipeline_by_id(self: Any, pipeline_id: str) -> Tuple[Optional['InferencePipeline'], Optional[str], str]: ...
        """
        Get an inference pipeline by its ID.
        
        Args:
            pipeline_id: The ID of the inference pipeline to retrieve
        
        Returns:
            tuple: (inference_pipeline_instance, error, message)
        """

    def get_inference_pipelines(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None, project_id: Optional[str] = None) -> Tuple[Optional[List['InferencePipeline']], Optional[str], str]: ...
        """
        Get all inference pipelines for a project.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
            project_id: The ID of the project (optional, uses manager's project_id if not provided)
        
        Returns:
            tuple: (inference_pipeline_instances, error, message)
        """


# From streaming_gateway_manager
class NetworkSettings:
    """
    Network settings data class for streaming gateway configurations.
    
    Attributes:
        ip_address: IP address of the gateway
        port: Port number for the gateway
        access_scale: Access scale (local|regional|global)
        region: Region identifier (e.g., us-east-1)
        max_bandwidth_mbps: Maximum bandwidth in Mbps
        current_bandwidth_mbps: Current bandwidth usage in Mbps
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create NetworkSettings instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert network settings to dictionary for API calls.
        """


# From streaming_gateway_manager
class StreamingGateway:
    """
    Streaming gateway instance class for managing individual streaming gateways.
    
    This class represents a single streaming gateway and provides methods to manage
    its configuration, camera groups, and operational status.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.streaming_gateway_manager import StreamingGateway, StreamingGatewayConfig
    
        session = Session(account_number="...", access_key="...", secret_key="...")
    
        # Create network settings
        network_settings = NetworkSettings(
            ip_address="10.0.0.5",
            port=9092,
            access_scale="regional",
            region="us-east-1",
            max_bandwidth_mbps=150.5,
            current_bandwidth_mbps=120.3
        )
    
        # Create gateway config
        config = StreamingGatewayConfig(
            gateway_name="Main Gateway",
            description="Primary streaming gateway",
            status="active",
            network_settings=network_settings,
            account_number="ACC-123"
        )
    
        # Create gateway instance
        gateway = StreamingGateway(session, config)
    
        # Save to backend
        result, error, message = gateway.save()
        if not error:
            print(f"Gateway created with ID: {gateway.id}")
    
        # Update configuration
        gateway.description = "Updated description"
        result, error, message = gateway.update()
    
        # Start streaming
        result, error, message = gateway.start_streaming()
    
        # Update status
        result, error, message = gateway.update_status("active")
    
        # Stop streaming
        result, error, message = gateway.stop_streaming()
        ```
    """

    def __init__(self: Any, session: Any, config: Optional[StreamingGatewayConfig] = None, gateway_id: Optional[str] = None) -> None: ...
        """
        Initialize a StreamingGateway instance.
        
        Args:
            session: Session object containing RPC client for API communication
            config: StreamingGatewayConfig object (for new gateways)
            gateway_id: ID of existing gateway to load (mutually exclusive with config)
        """

    def account_number(self: Any) -> Optional[str]: ...
        """
        Get the account number.
        """

    def account_number(self: Any, value: str) -> Any: ...
        """
        Set the account number.
        """

    def delete(self: Any, force: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete the gateway from the backend.
        
        Args:
            force: Force delete even if active
        
        Returns:
            tuple: (result, error, message)
        """

    def description(self: Any) -> Optional[str]: ...
        """
        Get the gateway description.
        """

    def description(self: Any, value: str) -> Any: ...
        """
        Set the gateway description.
        """

    def gateway_name(self: Any) -> str: ...
        """
        Get the gateway name.
        """

    def gateway_name(self: Any, value: str) -> Any: ...
        """
        Set the gateway name.
        """

    def id(self: Any) -> Optional[str]: ...
        """
        Get the gateway ID.
        """

    def name(self: Any) -> str: ...
        """
        Get the gateway name (alias for gateway_name).
        """

    def name(self: Any, value: str) -> Any: ...
        """
        Set the gateway name (alias for gateway_name).
        """

    def network_settings(self: Any) -> Optional[NetworkSettings]: ...
        """
        Get the network settings.
        """

    def network_settings(self: Any, value: Any) -> Any: ...
        """
        Set the network settings.
        """

    def refresh(self: Any) -> Any: ...
        """
        Refresh the gateway configuration from the backend.
        """

    def save(self: Any, account_number: Optional[str] = None) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Save the gateway configuration to the backend (create new).
        
        Args:
            account_number: The account number to associate with the gateway
        
        Returns:
            tuple: (result, error, message)
        """

    def start_streaming(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Start the streaming gateway.
        
        Returns:
            tuple: (result, error, message)
        """

    def status(self: Any) -> Optional[str]: ...
        """
        Get the gateway status.
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop the streaming gateway.
        
        Returns:
            tuple: (result, error, message)
        """

    def update(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update the gateway configuration in the backend.
        
        Returns:
            tuple: (result, error, message)
        """

    def update_status(self: Any, status: str) -> None: ...
        """
        Update the status of the streaming gateway.
        
        Args:
            status: New status (active, inactive, starting, stopped, etc.)
        
        Returns:
            tuple: (result, error, message)
        """


# From streaming_gateway_manager
class StreamingGatewayConfig:
    """
    Streaming gateway configuration data class.
    
    Attributes:
        gateway_name: Name of the streaming gateway
        description: Description of the streaming gateway
        status: Status of the streaming gateway (active, inactive, starting, stopped)
        network_settings: Network configuration settings
        account_number: Account number for the gateway
        action_record_id: Action record ID for tracking
        start_time: Start time timestamp
        last_stream_time: Last streaming time timestamp
        id: Unique identifier for the streaming gateway (MongoDB ObjectID)
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create a StreamingGatewayConfig instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the streaming gateway config to a dictionary for API calls.
        """


# From streaming_gateway_manager
class StreamingGatewayManager:
    """
    Streaming gateway manager client for handling streaming gateway configurations in deployments.
    
    This class provides methods to create, read, update, and delete streaming gateway configurations
    that manage collections of camera groups for efficient video processing and distribution.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.streaming_gateway_manager import StreamingGatewayManager, StreamingGatewayConfig
    
        session = Session(account_number="...", access_key="...", secret_key="...")
        gateway_manager = StreamingGatewayManager(session)
    
        # Create network settings
        network_settings = NetworkSettings(
            ip_address="10.0.0.5",
            port=9092,
            access_scale="regional",
            region="us-east-1"
        )
    
        # Create a streaming gateway config
        config = StreamingGatewayConfig(
            gateway_name="Main Streaming Gateway",
            description="Primary gateway for building A camera groups",
            status="active",
            network_settings=network_settings
        )
    
        # Create gateway through manager
        gateway, error, message = gateway_manager.create_streaming_gateway(config)
        if error:
            print(f"Error: {error}")
        else:
            print(f"Streaming gateway created: {gateway.name}")
    
        # Get all gateways for the account
        gateways, error, message = gateway_manager.get_streaming_gateways()
        if not error:
            for gateway in gateways:
                print(f"Gateway: {gateway.name} - Status: {gateway.status}")
        ```
    """

    def __init__(self: Any, session: Any, account_number: Optional[str] = None, service_id: Optional[str] = None) -> None: ...
        """
        Initialize the StreamingGatewayManager client.
        
        Args:
            session: Session object containing RPC client for API communication
            account_number: The account number for API calls
            service_id: The ID of the deployment or inference pipeline
        """

    def create_streaming_gateway(self: Any, config: Any) -> Tuple[Optional['StreamingGateway'], Optional[str], str]: ...
        """
        Create a new streaming gateway from configuration.
        
        Args:
            config: StreamingGatewayConfig object containing the gateway configuration
        
        Returns:
            tuple: (streaming_gateway, error, message)
                - streaming_gateway: StreamingGateway instance if successful, None otherwise
                - error: Error message if failed, None otherwise
                - message: Status message
        """

    def get_streaming_gateway_by_id(self: Any, gateway_id: str) -> Tuple[StreamingGateway, Optional[str], str]: ...
        """
        Get a streaming gateway by its ID.
        
        Args:
            gateway_id: The ID of the streaming gateway to retrieve
        
        Returns:
            tuple: (streaming_gateway, error, message)
        """

    def get_streaming_gateways(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None) -> Tuple[Optional[List['StreamingGateway']], Optional[str], str]: ...
        """
        Get all streaming gateways for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
        
        Returns:
            tuple: (streaming_gateways, error, message)
        """

    def get_streaming_gateways_paginated(self: Any, page: int = 1, limit: int = 10) -> Tuple[Optional[List['StreamingGateway']], Optional[str], str]: ...
        """
        Get paginated streaming gateways for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
        
        Returns:
            tuple: (streaming_gateways, error, message)
        """

    def handle_response(self: Any, response: Dict, success_message: str, failure_message: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Handle API response and return standardized tuple.
        """


from . import camera_manager, deployment, inference_pipeline, streaming_gateway_manager