"""Auto-generated stub for module: test_videoplayback."""
from typing import Any, Dict, List, Optional

from matrice_streaming.streaming_gateway.debug.debug_gstreamer_gateway import DebugGStreamerGateway
from matrice_streaming.streaming_gateway.debug.debug_gstreamer_gateway import DebugGStreamerGateway
from matrice_streaming.streaming_gateway.debug.debug_streaming_gateway import DebugStreamingGateway
from matrice_streaming.streaming_gateway.debug.debug_streaming_gateway import DebugStreamingGateway
from pathlib import Path
import argparse
import logging
import os
import sys
import time

# Constants
logger: Any

# Functions
def benchmark_mode(mode_name: str, gateway: Any, duration_seconds: int = 30) -> Dict[str, Any]: ...
    """
    Benchmark a single streaming mode.
    
        Args:
            mode_name: Name of the streaming mode
            gateway: Gateway instance to benchmark
            duration_seconds: How long to run the benchmark
    
        Returns:
            Dictionary with benchmark results
    """
def main() -> Any: ...
    """
    Benchmark all 4 streaming modes.
    """
def print_summary(results: List[Dict]) -> Any: ...
    """
    Print benchmark comparison summary.
    """
def run_mode1_benchmark(video_path: str, fps: int, duration: int) -> Optional[Dict]: ...
    """
    Benchmark Mode 1: CameraStreamer (single-threaded OpenCV).
    """
def run_mode2_benchmark(video_path: str, fps: int, duration: int, num_workers: int = 2) -> Optional[Dict]: ...
    """
    Benchmark Mode 2: WorkerManager (multi-process OpenCV).
    """
def run_mode3_benchmark(video_path: str, fps: int, duration: int) -> Optional[Dict]: ...
    """
    Benchmark Mode 3: GStreamerCameraStreamer (single-threaded GStreamer).
    """
def run_mode4_benchmark(video_path: str, fps: int, duration: int, num_workers: int = 2) -> Optional[Dict]: ...
    """
    Benchmark Mode 4: GStreamerWorkerManager (multi-process GStreamer).
    """
