"""Auto-generated stub for module: debug_gstreamer_gateway."""
from typing import Any, Dict, List, Optional

from camera_streamer.gstreamer_camera_streamer import GStreamerCameraStreamer, GStreamerConfig, is_gstreamer_available
from camera_streamer.gstreamer_worker_manager import GStreamerWorkerManager
from debug_stream_backend import DebugStreamBackend
from debug_utils import MockSession, create_debug_input_streams, create_camera_configs_from_streams
from pathlib import Path
import logging
import time

# Constants
GSTREAMER_AVAILABLE: bool
GSTREAMER_WORKER_AVAILABLE: bool

# Classes
class DebugGStreamerGateway:
    """
    Debug version of GStreamer streaming gateway for local testing.
    
        This class allows you to test the complete GStreamer pipeline using:
        - Local video files (MP4, AVI, etc.)
        - RTSP streams
        - USB cameras
        - Test patterns
    
        Without requiring:
        - Kafka or Redis servers
        - API authentication
        - Network connectivity
        - Real streaming gateway configuration
    
        Perfect for:
        - Local development and testing
        - CI/CD pipelines
        - GStreamer encoder testing (NVENC, x264, OpenH264, JPEG)
        - Performance benchmarking
        - Frame optimization testing
    
        Example usage:
            # JPEG frame-by-frame with NVENC fallback
            gateway = DebugGStreamerGateway(
                video_paths=["video1.mp4", "video2.mp4"],
                fps=30,
                gstreamer_encoder="jpeg",
                jpeg_quality=85,
                loop_videos=True
            )
            gateway.start_streaming()
    
            # Wait and check stats
            time.sleep(30)
            stats = gateway.get_statistics()
            print(f"FPS: {stats['avg_fps']:.1f}")
            print(f"Bandwidth: {stats['bandwidth_mbps']:.2f} Mbps")
            print(f"Cache hits: {stats['cache_efficiency']:.1f}%")
    
            # Stop
            gateway.stop_streaming()
    
            # Test NVENC hardware encoding
            gateway = DebugGStreamerGateway(
                video_paths=["high_res_video.mp4"],
                fps=60,
                gstreamer_encoder="nvenc",
                gstreamer_codec="h264",
                gstreamer_preset="low-latency",
                gstreamer_gpu_id=0
            )
            gateway.start_streaming()
    """

    def __init__(self: Any, video_paths: List[str], fps: int = 30, loop_videos: bool = True, output_dir: Optional[str] = None, save_to_files: bool = False, log_messages: bool = True, save_frame_data: bool = False, width: Optional[int] = None, height: Optional[int] = None, gstreamer_encoder: str = 'jpeg', gstreamer_codec: str = 'h264', gstreamer_preset: str = 'low-latency', gstreamer_gpu_id: int = 0, jpeg_quality: int = 85, enable_frame_optimizer: bool = True, frame_optimizer_scale: float = 0.4, frame_optimizer_threshold: float = 0.05, use_workers: bool = False, num_workers: Optional[int] = None, cpu_percentage: float = 0.8, max_cameras_per_worker: int = 10) -> None: ...
        """
        Initialize debug GStreamer gateway.
        
                Args:
                    video_paths: List of video file paths to stream
                    fps: Frames per second to stream
                    loop_videos: Loop videos continuously
                    output_dir: Directory to save debug output
                    save_to_files: Save streamed messages to files
                    log_messages: Log message metadata
                    save_frame_data: Include frame data in saved files
                    width: Override video width
                    height: Override video height
                    gstreamer_encoder: GStreamer encoder (jpeg, nvenc, x264, openh264, auto)
                    gstreamer_codec: Codec for hardware/software encoders (h264, h265)
                    gstreamer_preset: NVENC preset (low-latency, high-quality, lossless)
                    gstreamer_gpu_id: GPU device ID for NVENC
                    jpeg_quality: JPEG quality 1-100 (higher=better, larger)
                    enable_frame_optimizer: Enable frame similarity detection
                    frame_optimizer_scale: Downscale factor for similarity detection
                    frame_optimizer_threshold: Similarity threshold (lower=stricter)
                    use_workers: Use multi-process GStreamerWorkerManager (Mode 4) instead of single-threaded
                    num_workers: Number of worker processes (auto-calculated if None)
                    cpu_percentage: Percentage of CPU cores to use for auto-calculation
                    max_cameras_per_worker: Maximum cameras per worker process
        """

    async def async_produce_request(self: Any, input_data: Any, topic: str, key: Optional[str] = None) -> bool: ...
        """
        Async message production for testing.
        
                Args:
                    input_data: Message data
                    topic: Topic/stream name
                    key: Message key
        
                Returns:
                    True if successful
        """

    def get_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get comprehensive streaming statistics.
        
                Returns:
                    Dictionary with streaming statistics including:
                    - Basic info (video count, fps, encoder, codec)
                    - Runtime metrics (duration, uptime)
                    - Transmission stats (frames sent, bytes, topics)
                    - Performance metrics (avg fps, bandwidth)
                    - Frame optimization metrics (cache efficiency, similarity rate)
                    - GStreamer pipeline metrics (per-stream stats)
        """

    def get_timing_stats(self: Any, stream_key: Optional[str] = None) -> Dict[str, Any]: ...
        """
        Get detailed timing statistics.
        
                Args:
                    stream_key: Specific stream or None for all
        
                Returns:
                    Timing statistics with read_time, write_time, process_time breakdown
        """

    def produce_request(self: Any, input_data: Any, topic: str, key: Optional[str] = None) -> bool: ...
        """
        Synchronous message production for testing.
        
                Args:
                    input_data: Message data
                    topic: Topic/stream name
                    key: Message key
        
                Returns:
                    True if successful
        """

    def refresh_connection_info(self: Any) -> bool: ...
        """
        Refresh connection (no-op for debug mode).
        
                Returns:
                    True (always successful in debug mode)
        """

    def reset_stats(self: Any) -> Any: ...
        """
        Reset all statistics.
        """

    def start_streaming(self: Any, block: bool = False) -> bool: ...
        """
        Start streaming all video files.
        
                Args:
                    block: If True, block until manually stopped
        
                Returns:
                    True if started successfully
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop all streaming.
        """

