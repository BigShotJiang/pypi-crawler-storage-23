"""Auto-generated stub for module: debug_streaming_gateway."""
from typing import Any, Dict, List, Optional

from camera_streamer.camera_streamer import CameraStreamer
from camera_streamer.worker_manager import WorkerManager
from debug_stream_backend import DebugStreamBackend
from debug_utils import MockSession, create_debug_input_streams, create_camera_configs_from_streams
from pathlib import Path
import logging
import time

# Classes
class DebugStreamingAction:
    """
    Debug version of StreamingAction for testing without API.
    
        This is a simplified version that doesn't require action IDs, API calls,
        or health monitoring. Perfect for local testing.
    
        Example usage:
            action = DebugStreamingAction(
                video_paths=["video1.mp4", "video2.mp4"],
                fps=10
            )
            action.start()
            time.sleep(30)
            action.stop()
    """

    def __init__(self: Any, video_paths: List[str], fps: int = 10, video_codec: str = 'h265-frame', output_dir: Optional[str] = None, save_to_files: bool = False, **kwargs: Any) -> None: ...
        """
        Initialize debug streaming action.
        
                Args:
                    video_paths: List of video file paths
                    fps: Frames per second
                    video_codec: Video codec
                    output_dir: Output directory for debug files
                    save_to_files: Save messages to files
                    **kwargs: Additional arguments for DebugStreamingGateway
        """

    def get_status(self: Any) -> Dict[str, Any]: ...
        """
        Get current status.
        
                Returns:
                    Status dictionary
        """

    def start(self: Any, block: bool = False) -> bool: ...
        """
        Start streaming action.
        
                Args:
                    block: Block until manually stopped
        
                Returns:
                    True if started successfully
        """

    def stop(self: Any) -> Any: ...
        """
        Stop streaming action.
        """

class DebugStreamingGateway:
    """
    Debug version of StreamingGateway that works without external dependencies.
    
        This class allows you to test the complete streaming pipeline using local video files
        without requiring:
        - Kafka or Redis servers
        - API authentication
        - Network connectivity
        - Real streaming gateway configuration
    
        Perfect for:
        - Local development and testing
        - CI/CD pipelines
        - Debugging encoding/processing issues
        - Performance testing
    
        Example usage:
            # Simple usage with video files
            gateway = DebugStreamingGateway(
                video_paths=["video1.mp4", "video2.mp4"],
                fps=10,
                loop_videos=True
            )
            gateway.start_streaming()
    
            # Wait and check stats
            time.sleep(30)
            print(gateway.get_statistics())
    
            # Stop
            gateway.stop_streaming()
    """

    def __init__(self: Any, video_paths: List[str], fps: int = 10, video_codec: str = 'h264', h265_quality: int = 23, use_hardware: bool = False, loop_videos: bool = True, output_dir: Optional[str] = None, save_to_files: bool = False, log_messages: bool = True, save_frame_data: bool = False, width: Optional[int] = None, height: Optional[int] = None, use_workers: bool = False, num_workers: Optional[int] = None, cpu_percentage: float = 0.8, max_cameras_per_worker: int = 10) -> None: ...
        """
        Initialize debug streaming gateway.
        
                Args:
                    video_paths: List of video file paths to stream
                    fps: Frames per second to stream
                    video_codec: Video codec (h264, h265-frame, h265-chunk)
                    h265_quality: H.265 quality (0-51, lower=better)
                    use_hardware: Use hardware encoding
                    loop_videos: Loop videos continuously
                    output_dir: Directory to save debug output
                    save_to_files: Save streamed messages to files
                    log_messages: Log message metadata
                    save_frame_data: Include frame data in saved files
                    width: Override video width
                    height: Override video height
                    use_workers: Use multi-process WorkerManager (Mode 2) instead of single-threaded CameraStreamer
                    num_workers: Number of worker processes (auto-calculated if None)
                    cpu_percentage: Percentage of CPU cores to use for auto-calculation
                    max_cameras_per_worker: Maximum cameras per worker process
        """

    def get_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get streaming statistics.
        
                Returns:
                    Dictionary with streaming statistics
        """

    def get_timing_stats(self: Any, stream_key: Optional[str] = None) -> Dict[str, Any]: ...
        """
        Get timing statistics.
        
                Args:
                    stream_key: Specific stream or None for all
        
                Returns:
                    Timing statistics
        """

    def reset_stats(self: Any) -> Any: ...
        """
        Reset all statistics.
        """

    def start_streaming(self: Any, block: bool = False) -> bool: ...
        """
        Start streaming all video files.
        
                Args:
                    block: If True, block until manually stopped
        
                Returns:
                    True if started successfully
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop all streaming.
        """

