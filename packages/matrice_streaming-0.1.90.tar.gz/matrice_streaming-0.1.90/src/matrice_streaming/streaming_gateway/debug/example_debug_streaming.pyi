"""Auto-generated stub for module: example_debug_streaming."""
from typing import Any

from matrice_streaming.streaming_gateway.debug import DebugStreamingGateway, DebugStreamingAction
from pathlib import Path
import logging
import sys
import time
import traceback

# Functions
def example_basic_streaming() -> Any: ...
    """
    Basic example: Stream a single video file.
    """
def example_custom_resolution() -> Any: ...
    """
    Example: Custom resolution and codec settings.
    """
def example_multiple_videos() -> Any: ...
    """
    Example with multiple video files.
    """
def example_save_to_files() -> Any: ...
    """
    Example: Save streamed messages to files.
    """
def example_with_streaming_action() -> Any: ...
    """
    Example: Using DebugStreamingAction.
    """
def main() -> Any: ...
    """
    Run all examples (or selected ones).
    """
