"""Auto-generated stub for module: streaming_gateway."""
from typing import Any, Dict, List, Optional

from __future__ import annotations
from camera_streamer import CameraStreamer
from camera_streamer.ffmpeg_camera_streamer import FFmpegCameraStreamer
from camera_streamer.ffmpeg_config import FFmpegConfig, is_ffmpeg_available
from camera_streamer.ffmpeg_worker_manager import FFmpegWorkerManager
from camera_streamer.gstreamer_camera_streamer import GStreamerCameraStreamer, GStreamerConfig, is_gstreamer_available
from camera_streamer.gstreamer_worker_manager import GStreamerWorkerManager
from camera_streamer.nvdec_worker_manager import NVDECWorkerManager, is_nvdec_available
from camera_streamer.worker_manager import WorkerManager
from dynamic_camera_manager import DynamicCameraManager, DynamicCameraManagerForWorkers
from dynamic_camera_manager import DynamicCameraManagerForNVDEC
from event_listener import EventListener
from streaming_gateway_utils import StreamingGatewayUtil, InputStream, input_stream_to_camera_config, build_stream_config
import atexit
import logging
import os
import threading
import time

# Constants
FFMPEG_AVAILABLE: bool
GSTREAMER_AVAILABLE: bool
NVDEC_AVAILABLE: bool
USE_FFMPEG: Any
USE_GSTREAMER: Any
USE_NVDEC: Any

# Classes
class StreamingGateway:
    """
    Simplified streaming gateway for managing camera streams.
    """

    def __init__(self: Any, session: Any, streaming_gateway_id: Optional[str] = None, server_id: Optional[str] = None, server_type: Optional[str] = None, inputs_config: Optional[List[InputStream]] = None, video_codec: Optional[str] = None, force_restart: bool = False, enable_event_listening: bool = True, action_id: Optional[str] = None, use_async_workers: bool = True, num_workers: Optional[int] = None, max_cameras_per_worker: int = 50, allow_empty_start: bool = True, use_gstreamer: bool = False, gstreamer_encoder: str = 'auto', gstreamer_codec: str = 'h264', gstreamer_preset: str = 'low-latency', gstreamer_gpu_id: int = 0, gstreamer_platform: str = 'auto', gstreamer_use_hardware_decode: bool = True, gstreamer_use_hardware_jpeg: bool = True, gstreamer_jetson_use_nvmm: bool = True, gstreamer_frame_optimizer_mode: str = 'hash-only', gstreamer_fallback_on_error: bool = True, gstreamer_verbose_logging: bool = False, use_ffmpeg: bool = USE_FFMPEG, ffmpeg_hwaccel: str = 'auto', ffmpeg_threads: int = 1, ffmpeg_low_latency: bool = True, ffmpeg_pixel_format: str = 'bgr24', use_nvdec: bool = USE_NVDEC, nvdec_gpu_id: int = 0, nvdec_num_gpus: int = 0, nvdec_pool_size: int = 8, nvdec_burst_size: int = 4, nvdec_frame_width: int = 640, nvdec_frame_height: int = 640, nvdec_num_slots: int = 32, nvdec_target_fps: int = 0, shm_slot_count: int = 1000) -> None: ...
        """
        Initialize StreamingGateway.
        
                Args:
                    session: Session object for authentication
                    streaming_gateway_id: ID of the streaming gateway
                    server_id: ID of the server (Kafka/Redis)
                    server_type: Type of server (kafka or redis)
                    inputs_config: List of InputStream configurations
                    video_codec: Video codec (h264 or h265)
                    force_restart: Force stop existing streams and restart
                    enable_event_listening: Enable dynamic event listening for configuration updates
                    action_id: Optional action ID to pass in API requests
                    use_async_workers: Use new async worker flow (default True)
                    num_workers: Number of worker processes for async flow
                    max_cameras_per_worker: Maximum cameras per worker process
                    allow_empty_start: Allow starting with zero cameras (default True)
                    use_gstreamer: Use GStreamer-based encoding (default False)
                    gstreamer_encoder: GStreamer encoder type (auto, nvenc, x264, openh264, jpeg)
                    gstreamer_codec: GStreamer codec (h264, h265)
                    gstreamer_preset: NVENC preset for hardware encoding
                    gstreamer_gpu_id: GPU device ID for NVENC hardware encoding
                    gstreamer_platform: Platform override (auto, jetson, desktop-gpu, intel, amd, cpu)
                    gstreamer_use_hardware_decode: Enable hardware decode (nvv4l2decoder, nvdec, vaapi)
                    gstreamer_use_hardware_jpeg: Enable hardware JPEG encoding when available
                    gstreamer_jetson_use_nvmm: Use NVMM zero-copy memory on Jetson devices
                    gstreamer_frame_optimizer_mode: Frame optimization mode (hash-only, dual-appsink, disabled)
                    gstreamer_fallback_on_error: Automatically fallback to CPU pipeline on hardware errors
                    gstreamer_verbose_logging: Enable verbose pipeline construction logging
                    use_ffmpeg: Use FFmpeg subprocess-based encoding (alternative to OpenCV/GStreamer)
                    ffmpeg_hwaccel: FFmpeg hardware acceleration (auto, cuda, vaapi, none)
                    ffmpeg_threads: Number of FFmpeg decode threads per stream
                    ffmpeg_low_latency: Enable FFmpeg low-latency flags
                    ffmpeg_pixel_format: Output pixel format (bgr24, rgb24, nv12)
                    use_nvdec: Use NVDEC hardware decode with CUDA IPC output (requires CuPy, PyNvVideoCodec)
                    nvdec_gpu_id: Primary/starting GPU device ID for round-robin camera assignment
                    nvdec_num_gpus: Number of GPUs to use (0=auto-detect all available GPUs)
                    nvdec_pool_size: Number of NVDEC decoders per GPU
                    nvdec_burst_size: Frames per stream before rotating to next stream
                    nvdec_frame_width: Default output frame width (used if camera config doesn't specify)
                    nvdec_frame_height: Default output frame height (used if camera config doesn't specify)
                    nvdec_num_slots: Ring buffer slots per camera (named by camera_id)
                    nvdec_target_fps: Global FPS override (0=use per-camera FPS from camera config)
                    shm_slot_count: Number of frame slots per camera ring buffer for SHM mode (default: 300)
        """

    def get_camera_id_for_stream_key(self: Any, stream_key: str) -> Optional[str]: ...
        """
        Get camera_id for a given stream_key.
        """

    def get_config(self: Any) -> Dict: ...
        """
        Get current configuration.
        """

    def get_statistics(self: Any) -> Dict: ...
        """
        Get streaming statistics.
        """

    def start_streaming(self: Any) -> bool: ...
        """
        Start streaming.
        
                Returns:
                    bool: True if streaming started successfully, False otherwise
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop all streaming operations.
        """

