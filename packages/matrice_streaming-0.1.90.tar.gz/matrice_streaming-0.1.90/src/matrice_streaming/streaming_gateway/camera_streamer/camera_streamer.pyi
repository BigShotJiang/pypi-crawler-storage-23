"""Auto-generated stub for module: camera_streamer."""
from typing import Any, Dict, Optional, Union

from __future__ import annotations
from encoder_manager import EncoderManager
from frame_processor import FrameProcessor
from matrice_common.optimize import FrameOptimizer
from matrice_common.stream.matrice_stream import MatriceStream, StreamType
from message_builder import StreamMessageBuilder
from retry_manager import RetryManager
from stream_statistics import StreamStatistics
from streaming_gateway_utils import StreamingGatewayUtil
from video_capture_manager import VideoCaptureManager
import cv2
import logging
import threading
import time

# Classes
class CameraStreamer:
    """
    Simplified camera streamer using modular components.
    
        This class orchestrates video streaming with:
        - Robust retry logic (never gives up)
        - Multiple video codecs (H.264, H.265 frame/stream)
        - Automatic reconnection on failures
        - Statistics tracking
        - Support for cameras, video files, RTSP, HTTP streams
    """

    def __init__(self: Any, session: Any, service_id: str, server_type: str, strip_input_content: bool = False, video_codec: Optional[str] = None, h265_quality: int = 23, use_hardware: bool = False, h265_mode: str = 'frame', gateway_util: Optional[StreamingGatewayUtil] = None, connection_refresh_threshold: int = 10, connection_refresh_interval: float = 60.0, frame_optimizer_enabled: bool = False, frame_optimizer_config: Optional[Dict[str, Any]] = None) -> None: ...
        """
        Initialize CameraStreamer.
        
                Args:
                    session: Session object for making RPC calls
                    service_id: ID of the deployment
                    server_type: Type of server (kafka or redis)
                    strip_input_content: Strip content for out-of-band retrieval
                    video_codec: Video codec to use
                    h265_quality: H.265 quality (CRF value 0-51, lower=better)
                    use_hardware: Use hardware encoding if available
                    h265_mode: H.265 mode - "frame" or "stream"
                    gateway_util: StreamingGatewayUtil instance for fetching connection info
                    connection_refresh_threshold: Number of consecutive failures before refreshing connection
                    connection_refresh_interval: Minimum seconds between connection refresh attempts
                    frame_optimizer_enabled: Enable frame optimization to skip similar frames
                    frame_optimizer_config: Configuration for FrameOptimizer (scale, diff_threshold, etc.)
        """

    async def async_produce_request(self: Any, input_data: Any, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, metadata: Optional[Dict] = None, topic: Optional[str] = None, timeout: float = 60.0) -> bool: ...
        """
        Produce a stream request to MatriceStream (asynchronous).
        """

    def calculate_batch_parameters(num_cameras: int, fps: int = 10) -> Dict[str, Any]: ...
        """
        Calculate optimal batch parameters based on number of cameras.
        
                Uses conservative defaults for small camera counts to minimize latency,
                then scales up for better throughput with many cameras.
        
                Note: This should be called with per-worker camera count, not total
                cameras in deployment. WorkerManager calls this for each worker.
        
                Args:
                    num_cameras: Number of cameras being streamed (per worker)
                    fps: Target frames per second (default: 10)
        
                Returns:
                    Dictionary with 'batch_size' and 'batch_timeout' parameters
        
                Examples:
                    - 1-10 cameras: batch_size=10, timeout=10ms (low latency)
                    - 11-50 cameras: batch_size=50, timeout=20ms
                    - 51-200 cameras: batch_size=100, timeout=50ms
                    - 201-500 cameras: batch_size=100, timeout=20ms
                    - 500+ cameras: batch_size=50, timeout=10ms (per-worker optimized)
        """

    async def close(self: Any) -> Any: ...
        """
        Clean up resources.
        """

    def get_stream_timing_stats(self: Any, stream_key: Optional[str] = None) -> Dict[str, Any]: ...
        """
        Get timing statistics for a stream.
        """

    def get_topic_for_stream(self: Any, stream_key: str) -> Optional[str]: ...
        """
        Get the topic for a specific stream key.
        """

    def get_transmission_stats(self: Any) -> Dict[str, Any]: ...
        """
        Get transmission statistics.
        """

    def produce_request(self: Any, input_data: Any, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, metadata: Optional[Dict] = None, topic: Optional[str] = None, timeout: float = 60.0) -> bool: ...
        """
        Produce a stream request to MatriceStream (synchronous).
        """

    def refresh_connection_info(self: Any) -> bool: ...
        """
        Refresh connection info from API and reinitialize MatriceStream.
        
                This method checks the server connection info from the API and if it has changed,
                it reinitializes the MatriceStream with the new connection details.
        
                Returns:
                    bool: True if connection was refreshed successfully
        """

    def register_stream_topic(self: Any, stream_key: str, topic: str) -> Any: ...
        """
        Register a topic for a specific stream key.
        """

    def reset_transmission_stats(self: Any) -> Any: ...
        """
        Reset transmission statistics.
        """

    def setup_stream_for_topic(self: Any, topic: str) -> bool: ...
        """
        Setup MatriceStream for a topic.
        """

    def start_background_stream(self: Any, input: Union[str, int], fps: int = 10, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, quality: int = 95, width: Optional[int] = None, height: Optional[int] = None, simulate_video_file_stream: bool = False, is_video_chunk: bool = False, chunk_duration_seconds: Optional[float] = None, chunk_frames: Optional[int] = None, camera_location: Optional[str] = None) -> bool: ...
        """
        Start streaming in background thread (non-blocking).
        """

    def start_stream(self: Any, input: Union[str, int], fps: int = 10, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, quality: int = 95, width: Optional[int] = None, height: Optional[int] = None, simulate_video_file_stream: bool = False, is_video_chunk: bool = False, chunk_duration_seconds: Optional[float] = None, chunk_frames: Optional[int] = None, camera_location: Optional[str] = None) -> bool: ...
        """
        Start streaming in current thread (blocking).
        
                Args:
                    input: Video source (camera index, file path, or URL)
                    fps: Target frames per second
                    stream_key: Unique identifier for this stream
                    stream_group_key: Group identifier for related streams
                    quality: Video quality
                    width: Target width (None to keep original)
                    height: Target height (None to keep original)
                    simulate_video_file_stream: Loop video file continuously
                    is_video_chunk: Whether this is a chunked video stream
                    chunk_duration_seconds: Duration of each chunk
                    chunk_frames: Number of frames per chunk
                    camera_location: Physical location description
        
                Returns:
                    True if stream started successfully, False otherwise
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop all streaming threads.
        """

