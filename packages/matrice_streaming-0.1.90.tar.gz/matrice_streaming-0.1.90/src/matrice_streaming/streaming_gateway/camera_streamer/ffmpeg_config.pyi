"""Auto-generated stub for module: ffmpeg_config."""
from typing import Any, List, Optional

from __future__ import annotations
from dataclasses import dataclass, field
import os
import subprocess
import subprocess
import subprocess
import sys

# Functions
def detect_hwaccel() -> str: ...
    """
    Detect available hardware acceleration.
    
        Returns:
            Best available hwaccel option: cuda, vaapi, videotoolbox, or none
    """
def get_ffmpeg_version() -> Optional[str]: ...
    """
    Get FFmpeg version string.
    
        Returns:
            Version string or None if FFmpeg is not available
    """
def is_ffmpeg_available() -> bool: ...
    """
    Check if FFmpeg is available on the system.
    
        Returns:
            True if FFmpeg is available, False otherwise
    """

# Classes
class FFmpegConfig:
    """
    Configuration for FFmpeg-based streaming.
    
        This configuration controls how FFmpeg subprocesses are spawned
        for video ingestion, with options for hardware acceleration,
        low-latency settings, and output format control.
    """

    def to_ffmpeg_args(self: Any, source: str, width: int = 0, height: int = 0) -> List[str]: ...
        """
        Build FFmpeg command line arguments.
        
                Args:
                    source: Input source (file path, RTSP URL, etc.)
                    width: Frame width (0 = auto-detect)
                    height: Frame height (0 = auto-detect)
        
                Returns:
                    List of command line arguments for FFmpeg
        """

