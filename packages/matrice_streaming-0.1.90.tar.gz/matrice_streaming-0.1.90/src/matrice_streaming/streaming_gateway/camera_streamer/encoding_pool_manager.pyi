"""Auto-generated stub for module: encoding_pool_manager."""
from typing import Any, Optional

import logging
import multiprocessing
import os

# Classes
class EncodingPoolManager:
    """
    Manages a process pool for parallel frame encoding.
    
        The encoding pool handles CPU-bound operations in separate processes
        to bypass the GIL and achieve true parallel execution on multi-core systems.
    """

    def __init__(self: Any, num_workers: Optional[int] = None) -> None: ...
        """
        Initialize encoding pool manager.
        
                Args:
                    num_workers: Number of encoding workers (default: CPU_count - 2)
        """

    def get_pool(self: Any) -> Any: ...
        """
        Get the encoding process pool.
        
                Returns:
                    Process pool instance
        
                Raises:
                    RuntimeError: If pool is not started
        """

    def is_running(self: Any) -> bool: ...
        """
        Check if encoding pool is running.
        
                Returns:
                    True if pool is active
        """

    def start(self: Any) -> Any: ...
        """
        Start the encoding process pool.
        """

    def stop(self: Any, timeout: float = 10.0) -> Any: ...
        """
        Stop the encoding process pool gracefully.
        
                Args:
                    timeout: Maximum time to wait for workers to finish (seconds)
        """

