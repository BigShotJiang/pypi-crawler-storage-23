"""Auto-generated stub for module: gstreamer_camera_streamer."""
from typing import Any, Dict, List, Optional, Tuple, Union

from __future__ import annotations
from collections import deque
from dataclasses import dataclass, field
from device_detection import PlatformDetector
from gi.repository import Gst, GstApp, GLib
from matrice_common.optimize import FrameOptimizer
from matrice_common.stream.matrice_stream import MatriceStream, StreamType
from message_builder import StreamMessageBuilder
from platform_pipelines import PipelineFactory
from platform_pipelines import PipelineFactory, CpuOnlyPipelineBuilder
from retry_manager import RetryManager
from stream_statistics import StreamStatistics
from streaming_gateway_utils import StreamingGatewayUtil
import gi
import hashlib
import logging
import threading
import time

# Constants
GST_AVAILABLE: bool

# Functions
def is_gstreamer_available() -> bool: ...
    """
    Check if GStreamer is available on the system.
    """

# Classes
class GStreamerCameraStreamer:
    """
    GStreamer-based camera streamer with the same API as CameraStreamer.
    
        This class provides:
        - Same public API as CameraStreamer for drop-in replacement
        - GStreamer-based video capture and encoding
        - Support for hardware encoding (NVENC) when available
        - Multiple codec support (H.264, H.265, JPEG)
        - Robust retry logic and statistics tracking
    """

    def __init__(self: Any, session: Any, service_id: str, server_type: str, strip_input_content: bool = False, video_codec: Optional[str] = None, gateway_util: Optional[StreamingGatewayUtil] = None, gstreamer_config: Optional[GStreamerConfig] = None, frame_optimizer_enabled: bool = False, frame_optimizer_config: Optional[Dict[str, Any]] = None) -> None: ...
        """
        Initialize GStreamerCameraStreamer.
        
                Args:
                    session: Session object for authentication
                    service_id: Deployment/gateway ID
                    server_type: 'kafka' or 'redis'
                    strip_input_content: Strip content for out-of-band retrieval
                    video_codec: Video codec override
                    gateway_util: Utility for API interactions
                    gstreamer_config: GStreamer-specific configuration
                    frame_optimizer_enabled: Enable frame optimization to skip similar frames
                    frame_optimizer_config: Configuration for FrameOptimizer (scale, diff_threshold, etc.)
        """

    async def async_produce_request(self: Any, input_data: Any, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, metadata: Optional[Dict] = None, topic: Optional[str] = None, timeout: float = 60.0) -> bool: ...
        """
        Produce a stream request to MatriceStream (asynchronous).
        
                Args:
                    input_data: Frame data bytes
                    stream_key: Stream identifier
                    stream_group_key: Stream group identifier
                    metadata: Optional metadata dictionary
                    topic: Optional topic override
                    timeout: Timeout in seconds
        
                Returns:
                    bool: True if successful, False otherwise
        """

    async def close(self: Any) -> Any: ...
        """
        Clean up resources.
        """

    def get_topic_for_stream(self: Any, stream_key: str) -> Optional[str]: ...
        """
        Get the topic for a specific stream key.
        """

    def get_transmission_stats(self: Any) -> Dict[str, Any]: ...
        """
        Get transmission statistics.
        """

    def produce_request(self: Any, input_data: Any, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, metadata: Optional[Dict] = None, topic: Optional[str] = None, timeout: float = 60.0) -> bool: ...
        """
        Produce a stream request to MatriceStream (synchronous).
        
                Args:
                    input_data: Frame data bytes
                    stream_key: Stream identifier
                    stream_group_key: Stream group identifier
                    metadata: Optional metadata dictionary
                    topic: Optional topic override
                    timeout: Timeout in seconds
        
                Returns:
                    bool: True if successful, False otherwise
        """

    def refresh_connection_info(self: Any) -> bool: ...
        """
        Refresh connection info from API and reinitialize MatriceStream.
        
                This method checks the server connection info from the API and if it has changed,
                it reinitializes the MatriceStream with the new connection details.
        
                Returns:
                    bool: True if connection was refreshed successfully
        """

    def register_stream_topic(self: Any, stream_key: str, topic: str) -> Any: ...
        """
        Register a topic for a specific stream key.
        """

    def reset_transmission_stats(self: Any) -> Any: ...
        """
        Reset transmission statistics.
        """

    def setup_stream_for_topic(self: Any, topic: str) -> bool: ...
        """
        Setup MatriceStream for a topic.
        """

    def start_background_stream(self: Any, input: Union[str, int], fps: int = 10, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, quality: int = 95, width: Optional[int] = None, height: Optional[int] = None, simulate_video_file_stream: bool = False, is_video_chunk: bool = False, chunk_duration_seconds: Optional[float] = None, chunk_frames: Optional[int] = None, camera_location: Optional[str] = None) -> bool: ...
        """
        Start streaming in background thread (non-blocking).
        """

    def start_stream(self: Any, input: Union[str, int], fps: int = 10, stream_key: Optional[str] = None, stream_group_key: Optional[str] = None, quality: int = 95, width: Optional[int] = None, height: Optional[int] = None, simulate_video_file_stream: bool = False, is_video_chunk: bool = False, chunk_duration_seconds: Optional[float] = None, chunk_frames: Optional[int] = None, camera_location: Optional[str] = None) -> bool: ...
        """
        Start streaming in current thread (blocking).
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop all streaming threads and pipelines.
        """

class GStreamerConfig:
    """
    Configuration for GStreamer encoding.
    
        Default: JPEG for frame-by-frame streaming with maximum performance.
        JPEG provides:
        - No inter-frame dependencies (true frame-by-frame)
        - Consistent per-frame latency
        - Simple frame caching (hash-based works perfectly)
        - Maximum throughput for static scenes
    """

    pass
class GStreamerMetrics:
    """
    Metrics for a GStreamer stream.
    """

    pass
class GStreamerPipeline:
    """
    Manages a single GStreamer pipeline for video capture and encoding.
    
        This class handles:
        - Pipeline construction with automatic encoder detection
        - Video source handling (cameras, files, RTSP, HTTP)
        - Frame pulling from appsink
        - PTS-based latency measurement
    """

    def __init__(self: Any, stream_key: str, source: Union[str, int], width: int, height: int, fps: int, config: Any) -> None: ...
        """
        Initialize GStreamer pipeline.
        
                Args:
                    stream_key: Unique identifier for this stream
                    source: Video source (camera index, file path, RTSP URL, etc.)
                    width: Target output width
                    height: Target output height
                    fps: Target frames per second
                    config: GStreamer configuration
        """

    def get_metrics(self: Any) -> Any: ...
        """
        Get pipeline metrics.
        """

    def pull_frame(self: Any, timeout_ns: Optional[int] = None) -> Optional[tuple]: ...
        """
        Pull an encoded frame from the pipeline.
        
                Args:
                    timeout_ns: Timeout in nanoseconds (default: 100ms)
        
                Returns:
                    Tuple of (frame_data, latency_ms, size) or None if no frame
        """

    def start(self: Any) -> bool: ...
        """
        Start the GStreamer pipeline.
        
                Returns:
                    bool: True if started successfully
        """

    def stop(self: Any) -> Any: ...
        """
        Stop the GStreamer pipeline.
        """

