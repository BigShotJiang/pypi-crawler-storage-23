"""Auto-generated stub for module: stream_statistics."""
from typing import Any, Dict, List, Optional, Tuple

from __future__ import annotations
import logging
import time

# Classes
class StreamStatistics:
    """
    Manages streaming statistics and timing data.
    """

    def __init__(self: Any) -> None: ...
        """
        Initialize statistics tracker.
        """

    MAX_HISTORY_SIZE: int
    STATS_LOG_INTERVAL: int

    def add_bytes_saved(self: Any, bytes_count: int) -> Any: ...
        """
        Add to bytes saved counter.
        """

    def clear_timing_history(self: Any, stream_key: Optional[str] = None) -> Any: ...
        """
        Clear accumulated timing history for a stream or all streams.
        
                This should be called after metrics have been reported to prevent
                unbounded memory growth.
        
                Args:
                    stream_key: Specific stream key to clear, or None to clear all streams
        """

    def get_next_input_order(self: Any, stream_key: str) -> int: ...
        """
        Get next input order number for a stream.
        
                Args:
                    stream_key: Stream identifier
        
                Returns:
                    Next input order number
        """

    def get_timing(self: Any, stream_key: str) -> Tuple[float, float, float]: ...
        """
        Get timing data for a stream.
        
                Args:
                    stream_key: Stream identifier
        
                Returns:
                    Tuple of (read_time, write_time, process_time)
        """

    def get_timing_statistics(self: Any, stream_key: str) -> Dict[str, Any]: ...
        """
        Calculate min/max/avg statistics from accumulated timing history.
        
                Args:
                    stream_key: Stream identifier
        
                Returns:
                    Dictionary with statistical metrics for read_time, write_time, process_time,
                    frame_size, and FPS calculations
        """

    def get_timing_stats(self: Any, stream_key: Optional[str] = None) -> Dict[str, Any]: ...
        """
        Get timing statistics for streams.
        
                Args:
                    stream_key: Specific stream key, or None for all streams
        
                Returns:
                    Dictionary with timing statistics
        """

    def get_transmission_stats(self: Any, video_codec: str, active_streams: int) -> Dict[str, Any]: ...
        """
        Get comprehensive transmission statistics.
        
                Args:
                    video_codec: Current video codec being used
                    active_streams: Number of active streams
        
                Returns:
                    Dictionary with all transmission statistics
        """

    def increment_frames_diff_sent(self: Any) -> Any: ...
        """
        Increment diff frames counter.
        """

    def increment_frames_sent(self: Any) -> Any: ...
        """
        Increment sent frames counter.
        """

    def increment_frames_skipped(self: Any) -> Any: ...
        """
        Increment skipped frames counter.
        """

    def log_aggregated_stats(self: Any) -> None: ...
        """
        Log aggregated metrics across all streams.
        """

    def log_detailed_stats(self: Any, stream_key: str) -> None: ...
        """
        Log comprehensive metrics for a stream.
        
                Args:
                    stream_key: Stream identifier
        """

    def log_periodic_stats(self: Any, stream_key: str, read_time: float, encoding_time: float, write_time: float) -> Any: ...
        """
        Log periodic statistics.
        
                Args:
                    stream_key: Stream identifier
                    read_time: Time spent reading frame
                    encoding_time: Time spent encoding frame
                    write_time: Time spent writing frame
        """

    def reset(self: Any) -> Any: ...
        """
        Reset all statistics.
        """

    def should_log_stats(self: Any) -> bool: ...
        """
        Check if it's time to log statistics.
        
                Returns:
                    True if should log stats based on interval
        """

    def update_timing(self: Any, stream_key: str, read_time: float, write_time: float, process_time: float, frame_size: Optional[int] = None, encoding_time: float = 0.0) -> Any: ...
        """
        Update timing statistics for a stream.
        
                Args:
                    stream_key: Stream identifier
                    read_time: Time spent reading frame
                    write_time: Time spent writing/sending frame
                    process_time: Total processing time
                    frame_size: Size of encoded frame in bytes (ACG frame size)
                    encoding_time: Time spent encoding frame (NEW)
        """

