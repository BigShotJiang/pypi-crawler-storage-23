"""Auto-generated stub for module: ffmpeg_worker_manager."""
from typing import Any, Dict, List, Optional

from async_ffmpeg_worker import run_ffmpeg_worker
from dataclasses import asdict
from ffmpeg_config import FFmpegConfig, is_ffmpeg_available
import logging
import multiprocessing
import os
import signal
import sys
import time

# Classes
class FFmpegWorkerManager:
    """
    Manages multiple FFmpeg async camera worker processes.
    
        This manager coordinates worker processes, distributing cameras
        across them for optimal throughput using FFmpeg subprocesses
        for video ingestion.
    """

    def __init__(self: Any, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], num_workers: Optional[int] = None, cpu_percentage: float = 0.9, max_cameras_per_worker: int = 100, ffmpeg_config: Optional[FFmpegConfig] = None, use_shm: bool = False, shm_slot_count: int = 1000, shm_frame_format: str = 'BGR', pin_cpu_affinity: bool = True) -> None: ...
        """
        Initialize FFmpeg worker manager.
        
                Args:
                    camera_configs: List of all camera configurations
                    stream_config: Streaming configuration (Redis, Kafka, etc.)
                    num_workers: Number of worker processes (default: auto-calculated)
                    cpu_percentage: Percentage of CPU cores to use (default: 0.9)
                    max_cameras_per_worker: Maximum cameras per worker (default: 100)
                    ffmpeg_config: FFmpeg configuration options
                    use_shm: Enable SHM mode for raw frame sharing
                    shm_slot_count: Number of frame slots per camera ring buffer
                    shm_frame_format: Frame format for SHM storage
                    pin_cpu_affinity: Pin workers to specific CPU cores
        """

    def add_camera(self: Any, camera_config: Dict[str, Any]) -> bool: ...
        """
        Add a camera to the least-loaded worker at runtime.
        
                Args:
                    camera_config: Camera configuration dictionary
        
                Returns:
                    bool: True if camera was added successfully
        """

    def get_camera_assignments(self: Any) -> Dict[str, int]: ...
        """
        Get current camera-to-worker assignments.
        """

    def get_worker_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get detailed statistics about workers and cameras.
        """

    def monitor(self: Any, duration: Optional[float] = None) -> Any: ...
        """
        Monitor workers and collect health reports.
        
                Args:
                    duration: How long to monitor (None = indefinite)
        """

    def remove_camera(self: Any, stream_key: str) -> bool: ...
        """
        Remove a camera from its assigned worker.
        
                Args:
                    stream_key: Unique identifier for the camera stream
        
                Returns:
                    bool: True if camera removal was initiated
        """

    def run(self: Any, duration: Optional[float] = None) -> Any: ...
        """
        Start workers and monitor until stopped.
        
                Args:
                    duration: How long to run (None = until interrupted)
        """

    def start(self: Any) -> Any: ...
        """
        Start all workers and begin streaming.
        """

    def stop(self: Any, timeout: float = 15.0) -> Any: ...
        """
        Stop all workers gracefully.
        
                Args:
                    timeout: Maximum time to wait per worker (seconds)
        """

