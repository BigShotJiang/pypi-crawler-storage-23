"""Auto-generated stub for module: worker_manager."""
from typing import Any, Dict, List, Optional

from __future__ import annotations
from async_camera_worker import run_async_worker
from camera_streamer import CameraStreamer
from encoding_pool_manager import EncodingPoolManager
from pathlib import Path
import logging
import multiprocessing
import os
import signal
import sys
import time

# Constants
USE_SHM: Any

# Classes
class WorkerManager:
    """
    Manages multiple async camera worker processes with dynamic scaling.
    
        This manager coordinates worker processes based on available CPU cores,
        distributing cameras across them for optimal throughput. Each worker handles
        multiple cameras concurrently using async I/O.
    """

    def __init__(self: Any, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], num_workers: Optional[int] = None, cpu_percentage: float = 0.9, num_encoding_workers: Optional[int] = None, max_cameras_per_worker: int = 100, use_shm: bool = USE_SHM, shm_slot_count: int = 1000, shm_frame_format: str = 'BGR', drop_stale_frames: bool = False, use_simple_read: bool = True, pin_cpu_affinity: bool = False, buffer_size: int = 1, frame_optimizer_enabled: bool = False) -> None: ...
        """
        Initialize worker manager with dynamic CPU-based scaling.
        
                Args:
                    camera_configs: List of all camera configurations
                    stream_config: Streaming configuration (Redis, Kafka, etc.)
                    num_workers: Number of worker processes (default: auto-calculated from CPU cores)
                    cpu_percentage: Percentage of CPU cores to use (default: 0.9 = 90%)
                    num_encoding_workers: Number of encoding workers (default: CPU_count - 2)
                    max_cameras_per_worker: Maximum cameras per worker for load balancing (default: 100)
                    use_shm: Enable SHM mode (raw frames in shared memory, metadata in Redis)
                    shm_slot_count: Number of frame slots per camera ring buffer
                    shm_frame_format: Frame format for SHM storage
                    drop_stale_frames: Use grab()/grab()/retrieve() pattern for latest frame
                    use_simple_read: Use cap.read() directly instead of grab/retrieve pattern
                    pin_cpu_affinity: Pin worker processes to specific CPU cores for cache locality
                    buffer_size: VideoCapture buffer size (1 = minimal latency)
                    frame_optimizer_enabled: Enable frame similarity detection (skip similar frames for bandwidth saving)
        """

    def add_camera(self: Any, camera_config: Dict[str, Any]) -> bool: ...
        """
        Add a camera to the least-loaded worker at runtime.
        
                Args:
                    camera_config: Camera configuration dictionary with stream_key, source, etc.
        
                Returns:
                    bool: True if camera was added successfully
        """

    def get_camera_assignments(self: Any) -> Dict[str, int]: ...
        """
        Get current camera-to-worker assignments.
        
                Returns:
                    Dict mapping stream_key to worker_id
        """

    def get_worker_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get detailed statistics about workers and cameras.
        
                Returns:
                    Dict with worker statistics for metrics/monitoring
        """

    def monitor(self: Any, duration: Optional[float] = None) -> Any: ...
        """
        Monitor workers and collect health reports.
        
                Args:
                    duration: How long to monitor (None = indefinite)
        """

    def remove_camera(self: Any, stream_key: str) -> bool: ...
        """
        Remove a camera from its assigned worker.
        
                Args:
                    stream_key: Unique identifier for the camera stream
        
                Returns:
                    bool: True if camera removal was initiated
        """

    def run(self: Any, duration: Optional[float] = None) -> Any: ...
        """
        Start workers and monitor until stopped.
        
                This is the main entry point that combines start(), monitor(), and stop().
        
                Args:
                    duration: How long to run (None = until interrupted)
        """

    def start(self: Any) -> Any: ...
        """
        Start all workers and begin streaming.
        """

    def stop(self: Any, timeout: float = 15.0) -> Any: ...
        """
        Stop all workers gracefully.
        
                Args:
                    timeout: Maximum time to wait per worker (seconds)
        """

    def update_camera(self: Any, camera_config: Dict[str, Any]) -> bool: ...
        """
        Update a camera's configuration (removes and re-adds with new config).
        
                Args:
                    camera_config: Updated camera configuration
        
                Returns:
                    bool: True if update was initiated
        """

