"""Auto-generated stub for module: platform_pipelines."""
from typing import Any, Dict, Optional, Tuple

from __future__ import annotations
from abc import ABC, abstractmethod
from device_detection import PlatformInfo, PlatformType
from gstreamer_camera_streamer import GStreamerConfig
import logging

# Classes
class AmdGpuPipelineBuilder(IntelGpuPipelineBuilder):
    """
    AMD GPU pipeline builder with VAAPI.
    
        Inherits from IntelGpuPipelineBuilder as AMD uses same VAAPI interface.
        Can be extended in future for AMD-specific optimizations.
    """

    pass
class CpuOnlyPipelineBuilder(PipelineBuilder):
    """
    CPU-only fallback pipeline builder.
    
        Uses software encoders/decoders:
        - jpegenc for JPEG
        - x264enc for H.264
        - avdec_h264 for decode
    """

    def build_convert_element(self: Any) -> str: ...

    def build_decode_element(self: Any, source_type: str, source: str) -> str: ...

    def build_encode_element(self: Any, encoder: str, quality: int, bitrate: int) -> Tuple[str, str]: ...

    def build_memory_element(self: Any, encoder: str) -> str: ...

class DesktopNvidiaGpuPipelineBuilder(PipelineBuilder):
    """
    Desktop NVIDIA GPU pipeline builder.
    
        Optimizations:
        - nvdec for hardware video decode
        - nvh264enc/nvh265enc for hardware video encode
        - CUDA memory for zero-copy (video codecs only)
    
        Limitations:
        - NO hardware JPEG encoding (GStreamer limitation on desktop GPUs)
        - Must use CPU jpegenc
    """

    def build_convert_element(self: Any) -> str: ...

    def build_decode_element(self: Any, source_type: str, source: str) -> str: ...

    def build_encode_element(self: Any, encoder: str, quality: int, bitrate: int) -> Tuple[str, str]: ...

    def build_memory_element(self: Any, encoder: str) -> str: ...

class IntelGpuPipelineBuilder(PipelineBuilder):
    """
    Intel GPU pipeline builder with VAAPI.
    
        Optimizations:
        - vaapijpegenc for hardware JPEG encoding
        - vaapih264enc/h265enc for hardware video encode
        - vaapih264dec for hardware video decode
    """

    def build_convert_element(self: Any) -> str: ...

    def build_decode_element(self: Any, source_type: str, source: str) -> str: ...

    def build_encode_element(self: Any, encoder: str, quality: int, bitrate: int) -> Tuple[str, str]: ...

    def build_memory_element(self: Any, encoder: str) -> str: ...

class JetsonPipelineBuilder(PipelineBuilder):
    """
    Jetson-optimized pipeline builder.
    
        Optimizations:
        - nvjpegenc for hardware JPEG encoding (10x faster than CPU)
        - nvvidconv for GPU-accelerated color conversion
        - NVMM zero-copy memory
        - nvv4l2decoder for hardware video decode
        - nvv4l2h264enc/h265enc for hardware video encode
    """

    def build_convert_element(self: Any) -> str: ...

    def build_decode_element(self: Any, source_type: str, source: str) -> str: ...

    def build_encode_element(self: Any, encoder: str, quality: int, bitrate: int) -> Tuple[str, str]: ...

    def build_memory_element(self: Any, encoder: str) -> str: ...

class PipelineBuilder(ABC):
    """
    Abstract base class for platform-specific pipeline builders.
    
        Implements Template Method pattern with platform-specific overrides.
    """

    def __init__(self: Any, config: Any, platform_info: Any) -> None: ...
        """
        Initialize pipeline builder.
        
                Args:
                    config: GStreamer configuration
                    platform_info: Detected platform information
        """

    def build_complete_pipeline(self: Any, builder_config: Dict) -> str: ...
        """
        Build complete GStreamer pipeline (Template Method).
        
                Args:
                    builder_config: Pipeline configuration dict with:
                        - source_type: str
                        - source: str
                        - width: int
                        - height: int
                        - fps: int
                        - encoder: str
                        - quality: int
                        - bitrate: int
        
                Returns:
                    Complete GStreamer pipeline string
        """

    def build_convert_element(self: Any) -> str: ...
        """
        Build color conversion element (CPU or GPU accelerated).
        
                Returns:
                    GStreamer converter element string
        """

    def build_decode_element(self: Any, source_type: str, source: str) -> str: ...
        """
        Build hardware-accelerated decode element for source.
        
                Args:
                    source_type: Type of source (rtsp, file, camera)
                    source: Source URI or path
        
                Returns:
                    GStreamer decode element string
        """

    def build_dual_appsink_pipeline(self: Any, builder_config: Dict) -> str: ...
        """
        Build pipeline with dual appsinks for FrameOptimizer.
        
                Args:
                    builder_config: Pipeline configuration dict
        
                Returns:
                    Pipeline string with similarity-sink and output-sink
        """

    def build_encode_element(self: Any, encoder: str, quality: int, bitrate: int) -> Tuple[str, str]: ...
        """
        Build encoder element and output caps.
        
                Args:
                    encoder: Encoder type (jpeg, h264, h265)
                    quality: Quality setting (JPEG quality or video quality hint)
                    bitrate: Bitrate for video encoders (bps)
        
                Returns:
                    Tuple of (encoder_string, output_caps)
        """

    def build_memory_element(self: Any, encoder: str) -> str: ...
        """
        Build memory transfer/format element (NVMM, CUDA, standard).
        
                Args:
                    encoder: Encoder type being used
        
                Returns:
                    GStreamer memory/format caps string
        """

class PipelineFactory:
    """
    Factory for selecting appropriate pipeline builder based on platform.
    """

    def get_builder(config: Any, platform_info: Any) -> Any: ...
        """
        Select and instantiate appropriate pipeline builder.
        
                Args:
                    config: GStreamer configuration
                    platform_info: Detected platform information
        
                Returns:
                    Platform-specific PipelineBuilder instance
        """

