"""Auto-generated stub for module: async_ffmpeg_worker."""
from typing import Any, Dict, List, Optional, Tuple

from __future__ import annotations
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from ffmpeg_camera_streamer import FFmpegPipeline
from ffmpeg_config import FFmpegConfig, is_ffmpeg_available
from matrice_common.optimize import FrameOptimizer
from matrice_common.stream import MatriceStream, StreamType
from matrice_common.stream.shm_ring_buffer import ShmRingBuffer
from matrice_common.stream.shm_ring_buffer import bgr_to_nv12
import asyncio
import atexit
import cv2
import logging
import multiprocessing
import numpy as np
import os
import psutil
import signal
import subprocess
import sys
import time
import uuid

# Functions
def pin_to_cores(worker_id: int, total_workers: int) -> Optional[List[int]]: ...
    """
    Pin worker process to specific CPU cores for cache locality.
    
        Args:
            worker_id: Worker identifier (0-indexed)
            total_workers: Total number of worker processes
    
        Returns:
            List of CPU core indices this worker is pinned to, or None if pinning failed
    """
def run_ffmpeg_worker(worker_id: int, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], stop_event: Any, health_queue: Any, command_queue: Optional[Any] = None, response_queue: Optional[Any] = None, ffmpeg_config_dict: Optional[Dict[str, Any]] = None, use_shm: bool = False, shm_slot_count: int = 1000, shm_frame_format: str = 'BGR', pin_cpu_affinity: bool = True, total_workers: int = 1, frame_optimizer_enabled: bool = False, frame_optimizer_config: Optional[Dict[str, Any]] = None) -> Any: ...
    """
    Entry point for FFmpeg worker process.
    
        Args:
            worker_id: Worker identifier
            camera_configs: List of camera configurations
            stream_config: Streaming configuration
            stop_event: Shutdown event
            health_queue: Health reporting queue
            command_queue: Queue for receiving dynamic camera commands
            response_queue: Queue for sending command responses
            ffmpeg_config_dict: FFmpeg configuration as dict
            use_shm: Enable SHM mode
            shm_slot_count: Number of frame slots per camera ring buffer
            shm_frame_format: Frame format for SHM storage
            pin_cpu_affinity: Pin worker to specific CPU cores
            total_workers: Total number of workers
            frame_optimizer_enabled: Enable frame optimizer
            frame_optimizer_config: Frame optimizer configuration dict
    """

# Classes
class AsyncFFmpegWorker:
    """
    Async worker process that handles multiple cameras using FFmpeg pipelines.
    
        This worker runs an async event loop to handle I/O-bound operations
        for multiple cameras efficiently, using FFmpeg subprocesses for video
        decoding instead of OpenCV.
    """

    def __init__(self: Any, worker_id: int, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], stop_event: Any, health_queue: Any, command_queue: Optional[Any] = None, response_queue: Optional[Any] = None, ffmpeg_config: Optional[FFmpegConfig] = None, use_shm: bool = False, shm_slot_count: int = 1000, shm_frame_format: str = 'BGR', pin_cpu_affinity: bool = True, total_workers: int = 1, frame_optimizer_enabled: bool = False, frame_optimizer_config: Optional[Dict[str, Any]] = None) -> None: ...
        """
        Initialize async FFmpeg worker.
        
                Args:
                    worker_id: Unique identifier for this worker
                    camera_configs: List of camera configurations to handle
                    stream_config: Streaming configuration (Redis, Kafka, etc.)
                    stop_event: Event to signal worker shutdown
                    health_queue: Queue for reporting health status
                    command_queue: Queue for receiving dynamic camera commands
                    response_queue: Queue for sending command responses
                    ffmpeg_config: FFmpeg configuration options
                    use_shm: Enable SHM mode for raw frame sharing
                    shm_slot_count: Number of frame slots per camera ring buffer
                    shm_frame_format: Frame format for SHM storage
                    pin_cpu_affinity: Pin worker to specific CPU cores
                    total_workers: Total number of workers for CPU affinity calculation
                    frame_optimizer_enabled: Enable frame optimizer for skipping similar frames
                    frame_optimizer_config: Frame optimizer configuration dict
        """

    async def initialize(self: Any) -> Any: ...
        """
        Initialize async resources (Redis client, etc.).
        """

    async def run(self: Any) -> Any: ...
        """
        Main worker loop - starts async tasks for all cameras.
        """

