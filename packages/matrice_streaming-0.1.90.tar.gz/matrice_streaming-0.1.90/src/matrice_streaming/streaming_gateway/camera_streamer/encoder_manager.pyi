"""Auto-generated stub for module: encoder_manager."""
from typing import Any, Dict, Optional, Tuple

from __future__ import annotations
from matrice_common.video import H265StreamEncoder, H265FrameEncoder
import logging
import numpy as np

# Classes
class EncoderConfig:
    """
    Configuration for encoding.
    """

    pass
class EncoderManager:
    """
    Manages H.265 frame and stream encoders.
    """

    def __init__(self: Any, h265_mode: str = 'frame', quality: int = 23, use_hardware: bool = False) -> None: ...
        """
        Initialize encoder manager.
        
                Args:
                    h265_mode: Encoding mode - "frame" or "stream"
                    quality: H.265 quality (CRF value 0-51, lower=better)
                    use_hardware: Use hardware encoding if available
        """

    def cleanup(self: Any) -> None: ...
        """
        Clean up all encoders.
        """

    def encode_frame(self: Any, frame: Any, stream_key: str, fps: int, width: int, height: int, metadata: Dict[str, Any]) -> Tuple[bytes, Dict[str, Any], str]: ...
        """
        Encode frame using configured mode.
        
                Args:
                    frame: Frame to encode
                    stream_key: Stream identifier
                    fps: Frames per second
                    width: Frame width
                    height: Frame height
                    metadata: Metadata dictionary to update
        
                Returns:
                    Tuple of (encoded_data, updated_metadata, encoding_type)
        """

