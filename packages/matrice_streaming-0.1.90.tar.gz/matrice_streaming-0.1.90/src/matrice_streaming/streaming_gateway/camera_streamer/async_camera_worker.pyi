"""Auto-generated stub for module: async_camera_worker."""
from typing import Any, Dict, List, Optional, Tuple, Union

from __future__ import annotations
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from frame_processor import FrameProcessor
from matrice_common.optimize import FrameOptimizer
from matrice_common.stream import MatriceStream, StreamType
from matrice_common.stream.shm_ring_buffer import ShmRingBuffer
from matrice_common.stream.shm_ring_buffer import bgr_to_nv12
from message_builder import StreamMessageBuilder
from pathlib import Path
from stream_statistics import StreamStatistics
from video_capture_manager import VideoCaptureManager
import asyncio
import atexit
import cv2
import cv2
import cv2
import cv2
import logging
import multiprocessing
import os
import os
import os
import psutil
import signal
import sys
import time

# Functions
def pin_to_cores(worker_id: int, total_workers: int) -> Optional[List[int]]: ...
    """
    Pin worker process to specific CPU cores for cache locality.
    
        This optimization from cv2_bench.py improves throughput by 15-20%
        by reducing CPU cache misses when processing frames.
    
        Args:
            worker_id: Worker identifier (0-indexed)
            total_workers: Total number of worker processes
    
        Returns:
            List of CPU core indices this worker is pinned to, or None if pinning failed
    """
def run_async_worker(worker_id: int, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], stop_event: Any, health_queue: Any, command_queue: Optional[Any] = None, response_queue: Optional[Any] = None, use_shm: bool = True, shm_slot_count: int = 1000, shm_frame_format: str = 'BGR', drop_stale_frames: bool = False, use_simple_read: bool = True, pin_cpu_affinity: bool = False, total_workers: int = 1, buffer_size: int = 1, frame_optimizer_enabled: bool = False) -> Any: ...
    """
    Entry point for async worker process.
    
        This function is called by multiprocessing.Process to start a worker.
    
        Args:
            worker_id: Worker identifier
            camera_configs: List of camera configurations
            stream_config: Streaming configuration
            stop_event: Shutdown event
            health_queue: Health reporting queue
            command_queue: Queue for receiving dynamic camera commands
            response_queue: Queue for sending command responses
            use_shm: Enable SHM mode (raw frames in shared memory)
            shm_slot_count: Number of frame slots per camera ring buffer
            shm_frame_format: Frame format for SHM storage
            drop_stale_frames: Use grab()/grab()/retrieve() pattern for latest frame
            use_simple_read: Use cap.read() directly instead of grab/retrieve pattern
            pin_cpu_affinity: Pin worker process to specific CPU cores
            total_workers: Total number of workers for CPU affinity calculation
            buffer_size: VideoCapture buffer size (1 = minimal latency)
            frame_optimizer_enabled: Enable frame similarity detection (skip similar frames)
    """

# Classes
class AsyncCameraWorker:
    """
    Async worker process that handles multiple cameras concurrently.
    
        This worker runs an async event loop to handle I/O-bound operations
        (video capture, Redis writes) for multiple cameras efficiently.
    """

    def __init__(self: Any, worker_id: int, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], stop_event: Any, health_queue: Any, command_queue: Optional[Any] = None, response_queue: Optional[Any] = None, frame_optimizer_enabled: bool = False, frame_optimizer_config: Optional[Dict[str, Any]] = None, use_shm: bool = True, shm_slot_count: int = 1000, shm_frame_format: str = 'BGR', drop_stale_frames: bool = False, use_simple_read: bool = True, pin_cpu_affinity: bool = False, total_workers: int = 1, buffer_size: int = 1) -> None: ...
        """
        Initialize async camera worker.
        
                Args:
                    worker_id: Unique identifier for this worker
                    camera_configs: List of camera configurations to handle
                    stream_config: Streaming configuration (Redis, Kafka, etc.)
                    stop_event: Event to signal worker shutdown
                    health_queue: Queue for reporting health status
                    command_queue: Queue for receiving dynamic camera commands (add/remove/update)
                    response_queue: Queue for sending command responses back to manager
                    frame_optimizer_enabled: Whether to enable frame optimization
                    frame_optimizer_config: Frame optimizer configuration
                    use_shm: Enable SHM mode (raw frames in shared memory, metadata in Redis)
                    shm_slot_count: Number of frame slots per camera ring buffer
                    shm_frame_format: Frame format for SHM storage ("BGR", "RGB", or "NV12")
                    drop_stale_frames: Use grab()/grab()/retrieve() pattern to get latest frame
                    use_simple_read: Use cap.read() directly instead of grab/retrieve pattern
                    pin_cpu_affinity: Pin worker process to specific CPU cores for cache locality
                    total_workers: Total number of workers (for CPU affinity calculation)
                    buffer_size: VideoCapture buffer size (1 = minimal latency)
        """

    async def initialize(self: Any) -> Any: ...
        """
        Initialize async resources (Redis client, etc.).
        """

    async def run(self: Any) -> Any: ...
        """
        Main worker loop - starts async tasks for all cameras and handles commands.
        """

