"""Auto-generated stub for module: dynamic_camera_manager."""
from typing import Any, Dict, List, Optional

from __future__ import annotations
from camera_streamer.nvdec_worker_manager import NVDECWorkerManager
from streaming_gateway_utils import InputStream, StreamingGatewayUtil
import logging
import os
import threading

# Classes
class DynamicCameraManager:
    """
    Manages dynamic camera operations during runtime.
    
        This class handles:
        - Adding new cameras while streaming
        - Updating existing camera configurations
        - Removing cameras and stopping their streams
        - Managing camera group settings
        - Topic updates
    """

    def __init__(self: Any, camera_streamer: Any, streaming_gateway_id: str, session: Any = None, streaming_gateway: Any = None) -> None: ...
        """
        Initialize dynamic camera manager.
        
                Args:
                    camera_streamer: CameraStreamer instance to control streams
                    streaming_gateway_id: ID of the streaming gateway
                    session: Session object for API calls (optional)
                    streaming_gateway: StreamingGateway instance for updating mappings (optional)
        """

    def add_camera(self: Any, camera_data: Dict[str, Any]) -> bool: ...
        """
        Add a new camera and start streaming if active.
        
                Args:
                    camera_data: Camera configuration data from event
        
                Returns:
                    bool: True if camera was added successfully
        """

    def get_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get camera manager statistics.
        
                Returns:
                    Dict with statistics
        """

    def initialize_from_config(self: Any, input_streams: list) -> Any: ...
        """
        Initialize with existing input stream configurations.
        
                Args:
                    input_streams: List of InputStream objects
        """

    def remove_camera(self: Any, camera_id: str) -> bool: ...
        """
        Remove a camera and stop its stream.
        
                Args:
                    camera_id: ID of camera to remove
        
                Returns:
                    bool: True if camera was removed successfully
        """

    def remove_camera_group(self: Any, group_id: str) -> Any: ...
        """
        Remove camera group information.
        
                Args:
                    group_id: ID of camera group to remove
        """

    def update_camera(self: Any, camera_data: Dict[str, Any]) -> bool: ...
        """
        Update an existing camera's configuration.
        
                Handles isActive transitions:
                - If camera becomes active: Start streaming
                - If camera becomes inactive: Stop streaming but keep data
                - If camera stays active: Restart with new config
        
                Args:
                    camera_data: Updated camera configuration data
        
                Returns:
                    bool: True if camera was updated successfully
        """

    def update_camera_group(self: Any, group_data: Dict[str, Any]) -> Any: ...
        """
        Update camera group information.
        
                Args:
                    group_data: Camera group data
        """

    def update_camera_input_topic(self: Any, camera_id: str, topic_name: Optional[str]) -> Any: ...
        """
        Update input topic for a camera.
        
                Args:
                    camera_id: Camera ID
                    topic_name: New topic name (None to remove)
        """

    def update_camera_output_topic(self: Any, camera_id: str, topic_name: Optional[str]) -> Any: ...
        """
        Update output topic for a camera.
        
                Args:
                    camera_id: Camera ID
                    topic_name: New topic name (None to remove)
        """

    def update_cameras_in_group(self: Any, group_id: str, group_data: Dict[str, Any]) -> Any: ...
        """
        Update all cameras in a group with new default settings.
        
                Args:
                    group_id: Camera group ID
                    group_data: Updated group data with new default settings
        """

class DynamicCameraManagerForNVDEC:
    """
    Dynamic camera manager for NVDEC backend (restarts workers on change).
    
        This class adapts the DynamicCameraManager interface to work with the
        NVDECWorkerManager. It converts event camera_data to NVDEC format and routes
        add/update/remove operations to the NVDECWorkerManager.
    
        Key responsibilities:
        - Convert event camera_data format to NVDEC expected format
        - Handle isActive state transitions
        - Fetch camera group settings and input topics from API
        - Track camera state and statistics
        - Update streaming gateway mappings for metrics
    """

    def __init__(self: Any, nvdec_worker_manager: Any, streaming_gateway_id: str = '', session: Any = None, streaming_gateway: Any = None) -> None: ...
        """
        Initialize dynamic camera manager for NVDEC.
        
                Args:
                    nvdec_worker_manager: NVDECWorkerManager instance to control streams
                    streaming_gateway_id: ID of the streaming gateway
                    session: Session object for API calls (optional)
                    streaming_gateway: StreamingGateway instance for updating mappings (optional)
        """

    def add_camera(self: Any, camera_data: Dict[str, Any]) -> bool: ...
        """
        Add a new camera via NVDECWorkerManager.
        
                Args:
                    camera_data: Camera configuration data from event
        
                Returns:
                    bool: True if camera was added successfully
        """

    def get_camera_assignments(self: Any) -> Dict[str, int]: ...
        """
        Return mapping of camera_id to GPU ID.
        """

    def get_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get camera manager statistics.
        
                Returns:
                    Dict with statistics
        """

    def initialize_from_config(self: Any, input_streams: list) -> Any: ...
        """
        Initialize with existing input stream configurations.
        
                For NVDEC flow, cameras are already started by NVDECWorkerManager,
                so this just populates the local tracking data.
        
                Args:
                    input_streams: List of InputStream objects
        """

    def is_running(self: Any) -> bool: ...
        """
        Check if the manager is currently running.
        """

    def remove_camera(self: Any, camera_id: str) -> bool: ...
        """
        Remove a camera via NVDECWorkerManager.
        
                Args:
                    camera_id: ID of camera to remove
        
                Returns:
                    bool: True if camera was removed successfully
        """

    def update_camera(self: Any, camera_data: Dict[str, Any]) -> bool: ...
        """
        Update an existing camera's configuration via NVDECWorkerManager.
        
                Args:
                    camera_data: Updated camera configuration data
        
                Returns:
                    bool: True if camera was updated successfully
        """

class DynamicCameraManagerForWorkers:
    """
    Dynamic camera manager for WorkerManager-based async flow.
    
        This class adapts the DynamicCameraManager interface to work with
        the new WorkerManager + AsyncCameraWorker multiprocessing architecture.
    
        It converts event camera_data to worker camera_config format and routes
        add/update/remove operations to the WorkerManager.
    """

    def __init__(self: Any, worker_manager: Any, streaming_gateway_id: str, session: Any = None, streaming_gateway: Any = None) -> None: ...
        """
        Initialize dynamic camera manager for workers.
        
                Args:
                    worker_manager: WorkerManager instance to control streams
                    streaming_gateway_id: ID of the streaming gateway
                    session: Session object for API calls (optional)
                    streaming_gateway: StreamingGateway instance for updating mappings (optional)
        """

    def add_camera(self: Any, camera_data: Dict[str, Any]) -> bool: ...
        """
        Add a new camera via WorkerManager.
        
                Args:
                    camera_data: Camera configuration data from event
        
                Returns:
                    bool: True if camera was added successfully
        """

    def get_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get camera manager statistics.
        
                Returns:
                    Dict with statistics
        """

    def initialize_from_config(self: Any, input_streams: list) -> Any: ...
        """
        Initialize with existing input stream configurations.
        
                For WorkerManager flow, cameras are already started by WorkerManager,
                so this just populates the local tracking data.
        
                Args:
                    input_streams: List of InputStream objects
        """

    def remove_camera(self: Any, camera_id: str) -> bool: ...
        """
        Remove a camera via WorkerManager.
        
                Args:
                    camera_id: ID of camera to remove
        
                Returns:
                    bool: True if camera was removed successfully
        """

    def remove_camera_group(self: Any, group_id: str) -> Any: ...
        """
        Remove camera group information.
        
                Args:
                    group_id: ID of camera group to remove
        """

    def update_camera(self: Any, camera_data: Dict[str, Any]) -> bool: ...
        """
        Update an existing camera's configuration via WorkerManager.
        
                Args:
                    camera_data: Updated camera configuration data
        
                Returns:
                    bool: True if camera was updated successfully
        """

    def update_camera_group(self: Any, group_data: Dict[str, Any]) -> Any: ...
        """
        Update camera group information.
        
                Args:
                    group_data: Camera group data
        """

    def update_camera_input_topic(self: Any, camera_id: str, topic_name: Optional[str]) -> Any: ...
        """
        Update input topic for a camera.
        
                For WorkerManager flow, topics are managed within the worker config,
                so this triggers a camera update.
        
                Args:
                    camera_id: Camera ID
                    topic_name: New topic name (None to remove)
        """

    def update_camera_output_topic(self: Any, camera_id: str, topic_name: Optional[str]) -> Any: ...
        """
        Update output topic for a camera.
        
                Args:
                    camera_id: Camera ID
                    topic_name: New topic name (None to remove)
        """

    def update_cameras_in_group(self: Any, group_id: str, group_data: Dict[str, Any]) -> Any: ...
        """
        Update all cameras in a group with new default settings.
        
                For WorkerManager flow, this updates cameras via the WorkerManager.
        
                Args:
                    group_id: Camera group ID
                    group_data: Updated group data with new default settings
        """

