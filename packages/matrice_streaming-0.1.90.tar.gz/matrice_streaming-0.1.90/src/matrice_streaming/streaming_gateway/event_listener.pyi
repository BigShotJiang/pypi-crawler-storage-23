"""Auto-generated stub for module: event_listener."""
from typing import Any, Dict

from __future__ import annotations
from dynamic_camera_manager import DynamicCameraManager
from matrice_common.session import Session
from matrice_common.stream import EventListener
import logging

# Classes
class EventListener:
    """
    Listener for camera add/update/delete events from Kafka.
    
        This class wraps the generic EventListener from matrice_common
        and provides camera-specific event handling logic.
    """

    def __init__(self: Any, session: Session, streaming_gateway_id: str, camera_manager: Any) -> None: ...
        """
        Initialize event listener.
        
                Args:
                    session: Session object for authentication
                    streaming_gateway_id: ID of streaming gateway to filter events
                    camera_manager: Camera manager instance
        """

    def get_statistics(self: Any) -> dict: ...
        """
        Get statistics.
        """

    def handle_event(self: Any, event: Dict[str, Any]) -> Any: ...
        """
        Handle camera event.
        
                Args:
                    event: Camera event dict
        """

    def is_listening(self: Any) -> bool: ...
        """
        Check if listener is active.
        """

    def start(self: Any) -> bool: ...
        """
        Start listening to camera events.
        
                Returns:
                    bool: True if started successfully
        """

    def stop(self: Any) -> Any: ...
        """
        Stop listening.
        """

