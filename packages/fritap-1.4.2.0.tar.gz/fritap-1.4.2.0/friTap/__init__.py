#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Expose SSL_Logger at the package level
from .friTap import SSL_Logger

__all__ = ["SSL_Logger"]