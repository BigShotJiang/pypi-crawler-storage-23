#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Daniel Baier, Julian Lengersdorff, Francois Egner, Max Ufer"
__version__ = "1.4.2.0"
debug = False # are we running in debug mode?
