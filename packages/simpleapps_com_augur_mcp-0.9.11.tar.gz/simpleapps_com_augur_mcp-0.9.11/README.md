# Augur MCP Server

FastMCP server exposing Augur API microservices as 7 generic MCP tools.

## Install

```bash
uvx simpleapps-com-augur-mcp
```

## Authentication

Credentials are resolved in this order (first match wins):

1. **Environment variables** — `AUGUR_TOKEN` + `AUGUR_SITE_ID`
2. **Explicit file** — `AUGUR_CREDS_FILE` env var pointing to a JSON file (supports `~`)
3. **Project file** — `.simpleapps/augur-api.json` in the current working directory
4. **Global file** — `~/.simpleapps/augur-api.json`

Steps 3 and 4 are merged — project credentials take precedence when the same
site_id appears in both files.

### Single-site credentials

```json
{
  "siteId": "your-site-id",
  "jwt": "your-jwt-token"
}
```

### Multi-site credentials

Configure multiple sites in a single file:

```json
{
  "acme-corp": { "jwt": "acme-jwt" },
  "other-site": { "jwt": "other-jwt" }
}
```

The format is auto-detected: a top-level `siteId` key means single-site,
otherwise each key is the site ID and its value contains the JWT.

### Project + global merge

You can keep site-specific credentials in your project and shared credentials
globally:

```
~/.simpleapps/augur-api.json        → {"siteId": "shared-site", "jwt": "..."}
./project/.simpleapps/augur-api.json → {"siteId": "project-site", "jwt": "..."}
```

Both are loaded and merged. If the same `siteId` exists in both, the project
file wins.

## MCP Configuration

Minimal — no env vars needed when using project or global credentials:

```json
{
  "mcpServers": {
    "augur-api": {
      "command": "uvx",
      "args": ["simpleapps-com-augur-mcp"]
    }
  }
}
```

### Override: specific credentials file

```json
{
  "mcpServers": {
    "augur-api": {
      "command": "uvx",
      "args": ["simpleapps-com-augur-mcp"],
      "env": {
        "AUGUR_CREDS_FILE": "~/projects/clients/acme-corp/.simpleapps/augur-api.json"
      }
    }
  }
}
```

### Override: environment variables

```json
{
  "mcpServers": {
    "augur-api": {
      "command": "uvx",
      "args": ["simpleapps-com-augur-mcp"],
      "env": {
        "AUGUR_TOKEN": "your-jwt-token",
        "AUGUR_SITE_ID": "your-site-id"
      }
    }
  }
}
```

## Tools

| Tool | Purpose |
|------|---------|
| `augur_sites` | List configured sites |
| `augur_discover` | List services or endpoints for a service |
| `augur_list` | List records (GET collection) |
| `augur_get` | Get single record by ID |
| `augur_create` | Create record (POST) |
| `augur_update` | Update record (PUT) |
| `augur_delete` | Delete record (DELETE) |

### Site parameter

When multiple sites are configured, the 5 data tools (`augur_list`, `augur_get`,
`augur_create`, `augur_update`, `augur_delete`) accept an optional `site`
parameter to specify which site to query. If only one site is configured,
the `site` parameter can be omitted.

### augur_sites

Use `augur_sites` to see which sites are configured. When only one site exists,
it is marked with `"default": true`.
