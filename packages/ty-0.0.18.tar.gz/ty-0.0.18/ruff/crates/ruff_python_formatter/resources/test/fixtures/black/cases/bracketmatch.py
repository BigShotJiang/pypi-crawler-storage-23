for ((x in {}) or {})['a'] in x:
    pass
pem_spam = lambda l, spam = {
    "x": 3
}: not spam.get(l.strip())
lambda x=lambda y={1: 3}: y['x':lambda y: {1: 2}]: x
