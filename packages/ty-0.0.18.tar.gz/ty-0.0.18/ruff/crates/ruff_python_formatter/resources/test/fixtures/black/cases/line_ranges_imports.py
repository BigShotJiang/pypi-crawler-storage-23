# flags: --line-ranges=8-8
# NOTE: If you need to modify this file, pay special attention to the --line-ranges=
# flag above as it's formatting specifically these lines.

# This test ensures no empty lines are added around import lines.
# It caused an issue before https://github.com/psf/black/pull/3610 is merged.
import os
import re
import sys
