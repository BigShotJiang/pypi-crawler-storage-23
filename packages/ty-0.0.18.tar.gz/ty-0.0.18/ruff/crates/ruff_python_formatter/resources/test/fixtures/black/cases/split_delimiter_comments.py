a = (
    1 +  # type: ignore
    2  # type: ignore
)
a = (
    1  # type: ignore
    + 2  # type: ignore
)
bad_split3 = (
    "What if we have inline comments on "  # First Comment
    "each line of a bad split? In that "  # Second Comment
    "case, we should just leave it alone."  # Third Comment
)
parametrize(
    (
        {},
        {},
    ),
    (  # foobar
        {},
        {},
    ),
)
