def foo(
    # type: Foo
    x): pass
