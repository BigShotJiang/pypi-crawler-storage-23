"""
Strategy module for Vero Algo SDK.

Provides cTrader-style strategy/robot framework with event-based processing.
"""

from .base import Strategy
from .context import TradingContext
from .position import Position
from .symbol import Symbol, Bars, Bar

__all__ = [
    "Strategy",
    "TradingContext",
    "Position",
    "Symbol",
    "Bars",
    "Bar",
]
