"""
Technical Indicators (powered by talipp).

This module exposes "Smart" versions of talipp indicators that handle:
1.  All indicators accept Candle objects — no need to extract floats manually.
2.  Float-based indicators support `price_source` param ("open", "high", "low", "close")
    to select which price field to use. Defaults to "close".
3.  Automatic support for `SamplingPeriodType` via efficient internal chaining.
"""

import sys
import inspect
from typing import Any, List, Union
from datetime import datetime

# Import Talipp essentials
from talipp.indicators.Indicator import Indicator
from talipp.input import SamplingPeriodType

VALID_PRICE_SOURCES = ("open", "high", "low", "close")


def _extract_price(value: Any, price_source: str) -> Any:
    """Extract price from a Candle-like object, or pass through if already numeric."""
    if hasattr(value, price_source):
        return getattr(value, price_source)
    return value


def _convert_input_values(input_values, price_source: str):
    """Convert a list of Candle-like objects to floats using price_source."""
    if not input_values:
        return input_values
    first = input_values[0]
    if hasattr(first, price_source):
        return [getattr(v, price_source) for v in input_values]
    return input_values


# Helper: Resampler
class Resampler(Indicator):
    """Pass-through indicator that handles sampling."""
    def __init__(self, input_sampling):
        super().__init__(input_sampling=input_sampling)

    def _calculate_new_value(self):
        if not self.input_values:
            return None
        return self.input_values[-1]


# Smart Wrapper Logic
OHLCV_INDICATORS = {
    # Trend (need OHLC data)
    "ADX", "Aroon", "ParabolicSAR", "Ichimoku", "ChandeKrollStop",
    "CHOP", "VTX", "ZigZag", "SuperTrend",
    # Volatility (need OHLC data)
    "ATR", "NATR", "KeltnerChannels", "DonchianChannels", "RogersSatchell",
    # Volume (need OHLCV data)
    "OBV", "SOBV", "AccuDist", "ChaikinOsc", "EMV", "ForceIndex",
    "KVO", "VWAP", "VWMA", "BOP", "MassIndex",
    # Oscillators (need OHLC data)
    "Stoch", "CCI", "UO", "Williams", "AO",
    # Other (need OHLC data)
    "IBS", "PivotsHL", "SFX", "TTM", "FibonacciRetracement",
}

NO_INCREMENTAL_SUPPORT = {
    "PivotsHL",
    "ZigZag",
}

UTILITY_CLASSES = {
    "FibonacciRetracement",
}


def _make_smart(cls_name, cls):
    is_ohlcv_native = cls_name in OHLCV_INDICATORS
    no_incremental = cls_name in NO_INCREMENTAL_SUPPORT
    is_utility = cls_name in UTILITY_CLASSES

    # Skip utility classes
    if is_utility:
        return cls

    # Buffered wrapper for indicators without incremental support
    if no_incremental:
        class BufferedWrapper:
            """
            Wrapper for indicators that don't support incremental add().
            Maintains an internal buffer and reinitializes on each add().
            """
            def __init__(self, *args, max_buffer: int = 1000, **kwargs):
                self._args = args
                self._kwargs = kwargs
                self._buffer = []
                self._max_buffer = max_buffer
                self._indicator = None

                if 'input_values' in kwargs:
                    input_values = kwargs.pop('input_values')
                    self._kwargs = kwargs
                    self._buffer = list(input_values)
                    if len(self._buffer) > self._max_buffer:
                        self._buffer = self._buffer[-self._max_buffer:]
                    self._rebuild()

            def _rebuild(self):
                if len(self._buffer) > 0:
                    self._indicator = cls(*self._args, input_values=self._buffer, **self._kwargs)
                else:
                    self._indicator = None

            def add(self, value: Any):
                self._buffer.append(value)
                if len(self._buffer) > self._max_buffer:
                    self._buffer = self._buffer[-self._max_buffer:]
                self._rebuild()

            def __getitem__(self, index):
                if self._indicator is None:
                    raise IndexError("No data yet")
                return self._indicator[index]

            def __len__(self):
                if self._indicator is None:
                    return 0
                return len(self._indicator)

            def __iter__(self):
                if self._indicator is None:
                    return iter([])
                return iter(self._indicator)

            def __getattr__(self, name):
                if self._indicator is not None:
                    return getattr(self._indicator, name)
                raise AttributeError(f"'{cls_name}' has no data yet - call add() first")

        BufferedWrapper.__name__ = cls_name
        BufferedWrapper.__doc__ = f"Buffered wrapper for {cls_name}. Supports incremental add() by maintaining internal history."
        return BufferedWrapper

    # SmartWrapper for normal indicators
    class SmartWrapper(cls):
        def __init__(self, *args, price_source: str = "close", **kwargs):
            self._resampler = None
            self._is_feeding = False
            self._price_source = price_source if not is_ohlcv_native else None

            if not is_ohlcv_native and price_source not in VALID_PRICE_SOURCES:
                raise ValueError(
                    f"price_source must be one of {VALID_PRICE_SOURCES}, got '{price_source}'"
                )

            # Auto-convert input_values from Candles to floats for float-based indicators
            if not is_ohlcv_native and 'input_values' in kwargs and kwargs['input_values'] is not None:
                kwargs['input_values'] = _convert_input_values(kwargs['input_values'], price_source)

            if 'input_sampling' in kwargs:
                sampling = kwargs.pop('input_sampling')

                if not is_ohlcv_native:
                    self._resampler = Resampler(input_sampling=sampling)
                    kwargs['input_indicator'] = self._resampler
                    ps = price_source
                    if 'input_modifier' not in kwargs:
                        kwargs['input_modifier'] = lambda c, _ps=ps: getattr(c, _ps) if hasattr(c, _ps) else c
                else:
                    kwargs['input_sampling'] = sampling

            super().__init__(*args, **kwargs)

        def add(self, value: Any):
            if self._is_feeding:
                super().add(value)
                return

            if self._resampler is not None:
                self._is_feeding = True
                try:
                    self._resampler.add(value)
                finally:
                    self._is_feeding = False
                return

            # Float-based: extract price from Candle
            if not is_ohlcv_native and self._price_source is not None:
                value = _extract_price(value, self._price_source)

            super().add(value)

    try:
        SmartWrapper.__name__ = cls_name
        SmartWrapper.__doc__ = cls.__doc__
    except:
        pass

    return SmartWrapper


# Re-export all indicators as SmartWrappers
import talipp.indicators as _ti

msg = []

for name, obj in inspect.getmembers(_ti):
    if inspect.isclass(obj) and obj.__module__.startswith('talipp'):
        SmartObj = _make_smart(name, obj)
        vero_name = f"Vero{name}"
        setattr(sys.modules[__name__], vero_name, SmartObj)
        try:
            SmartObj.__name__ = vero_name
        except (AttributeError, TypeError):
            pass
        msg.append(vero_name)

__all__ = msg + ["SamplingPeriodType"]
