"""
Main client for Vero Algo SDK.

Provides unified access to all SDK services with mode-aware behavior.
"""

import logging
import uuid
from typing import Optional, TYPE_CHECKING

from .config import VeroConfig
from .features.orders import OrderService
from .features.market_data import MarketDataService
from .features.streaming import VeroStream
from .models import OrderSide, OrderResponse
from .utils.defaults import enum_val

if TYPE_CHECKING:
    from .core import Vero

logger = logging.getLogger(__name__)


class VeroClient:
    """
    Unified Vero Algo SDK client.
    
    Handles both LIVE and BACKTEST modes transparently.
    - In LIVE mode: Makes real API calls and WebSocket connections
    - In BACKTEST mode: Routes orders through backtest engine simulation
    """
    
    def __init__(
        self,
        vero: Optional["Vero"] = None,
        config: Optional[VeroConfig] = None,
        debug: bool = False,
    ):
        """
        Initialize VeroClient.
        
        Args:
            vero: Parent Vero instance (for mode detection and backtest routing)
            config: Optional VeroConfig instance
            debug: Enable debug logging
        """
        self._vero = vero
        self._config = config or VeroConfig(debug=debug)
        self._strategy = None  # Strategy reference (set by Strategy on init)
        
        # Live services (initialized lazily for backtest mode)
        self._orders: Optional[OrderService] = None
        self._market_data: Optional[MarketDataService] = None
        self._stream: Optional[VeroStream] = None
    
    @property
    def mode(self) -> str:
        """Get current mode."""
        if self._vero:
            return enum_val(self._vero.mode)
        return "LIVE"
    
    @property
    def is_backtest(self) -> bool:
        """Check if running in backtest mode."""
        return self.mode == "BACKTEST"
    
    def set_jwt_token(self, token: str) -> None:
        """Set authentication using a direct JWT token."""
        self._config.jwt_token = token
        logger.info("Authentication set via direct JWT token")
    
    @property
    def config(self) -> VeroConfig:
        """Get the configuration."""
        return self._config
    
    @property
    def orders(self) -> "UnifiedOrderService":
        """Get the order service (mode-aware)."""
        return UnifiedOrderService(self)
    
    @property
    def market_data(self) -> MarketDataService:
        """Get the market data service."""
        if not self._market_data:
            self._market_data = MarketDataService(self._config)
        return self._market_data
    
    @property
    def stream(self) -> Optional[VeroStream]:
        """Get the streaming client (only available in LIVE mode)."""
        if self.is_backtest:
            return None
        if not self._stream:
            self._stream = VeroStream(self._config)
        return self._stream
    
    def _get_live_orders(self) -> OrderService:
        """Get live order service."""
        if not self._orders:
            self._orders = OrderService(self._config)
        return self._orders
    
    def _get_strategy(self):
        """Get strategy if available (works in both LIVE and BACKTEST modes)."""
        # Check direct strategy reference first (set by Strategy.__init__)
        if self._strategy:
            return self._strategy
        # Fallback to backtest engine
        if self._vero and self._vero.backtest_engine:
            return self._vero.backtest_engine.strategy
        return None
    
    def is_authenticated(self) -> bool:
        """Check if currently authenticated."""
        return bool(self._config.jwt_token)


class UnifiedOrderService:
    """
    Mode-aware order service.
    
    Routes to real API in LIVE mode, or backtest simulation in BACKTEST mode.
    """
    
    def __init__(self, client: VeroClient):
        self._client = client
    
    def place_order(self, symbol: str, side, price: float, qty: int, 
                    order_type = "LO", account_id: Optional[str] = None) -> OrderResponse:
        """Place an order. If qty=0, auto-calculates optimal quantity."""
        # Smart qty: auto-calculate when qty=0
        if qty == 0:
            qty = self._resolve_smart_qty(symbol, price)
            if qty == 0:
                return OrderResponse(success=False, message="Smart qty: insufficient NAV for minimum qty")
        
        if self._client.is_backtest:
            return self._place_backtest_order(symbol, side, price, qty)
        return self._client._get_live_orders().place_order(
            symbol=symbol, side=side, price=price, qty=qty,
            order_type=order_type, account_id=account_id or ""
        )
    
    def place_bracket_order(self, symbol: str, side, price: float, qty: int,
                           account_id: Optional[str], take_profit_price: float, 
                           stop_loss_price: float) -> OrderResponse:
        """Place a bracket order. If qty=0, auto-calculates optimal quantity."""
        # Smart qty: auto-calculate when qty=0
        if qty == 0:
            qty = self._resolve_smart_qty(symbol, price)
            if qty == 0:
                return OrderResponse(success=False, message="Smart qty: insufficient NAV for minimum qty")
        
        if self._client.is_backtest:
            return self._place_backtest_order(symbol, side, price, qty,
                                              stop_loss=stop_loss_price,
                                              take_profit=take_profit_price)
        return self._client._get_live_orders().place_bracket_order(
            symbol=symbol, side=side, price=price, qty=qty,
            account_id=account_id or "", take_profit_price=take_profit_price,
            stop_loss_price=stop_loss_price
        )
    
    def cancel_order(self, order_id: str, account_id: Optional[str] = None) -> OrderResponse:
        """Cancel an order."""
        if self._client.is_backtest:
            strategy = self._client._get_strategy()
            if strategy and strategy.context:
                strategy.context.cancel_order(order_id)
                logger.info(f"[Backtest] Cancelled order {order_id}")
                return OrderResponse(success=True, message="Order cancelled", 
                                   data={"orderID": order_id})
            return OrderResponse(success=False, message="Strategy not active")
        return self._client._get_live_orders().cancel_order(order_id, account_id or "")
    
    def close_position(self, symbol: str, qty: float, side: object, 
                      account_id: Optional[str] = None) -> OrderResponse:
        """Close a position."""
        if self._client.is_backtest:
            strategy = self._client._get_strategy()
            if strategy:
                ctx = strategy.context
                if ctx is None:
                    return OrderResponse(success=False, message="Trading context not available")
                positions = ctx.get_positions_by_symbol(symbol)
                target_side = "LONG" if enum_val(side).upper() in ["B", "BUY", "LONG"] else "SHORT"
                
                closed_count = 0
                for pos in positions:
                    if pos.side.name == target_side:
                        # Calculate order value to release NAV
                        sym_obj = ctx.get_symbol(pos.symbol)
                        margin_rate = sym_obj.margin_rate if sym_obj and sym_obj.margin_rate > 0 else 1.0
                        point_value = sym_obj.point_value if sym_obj and sym_obj.point_value > 0 else 1.0
                        order_value = pos.quantity * pos.entry_price * margin_rate * point_value
                        
                        strategy.close_position(pos)
                        
                        # Release NAV that was reserved when position was opened
                        ctx.close_position_release_nav(pos.id, order_value)
                        closed_count += 1
                
                if closed_count > 0:
                    logger.info(f"[Backtest] Closed {closed_count} positions for {symbol}")
                    return OrderResponse(success=True, 
                                       message=f"Closed {closed_count} positions")
            return OrderResponse(success=False, message="Strategy not active")
        return self._client._get_live_orders().close_position(symbol, qty, side, account_id or "")
    
    def get_orders(self, account_id: Optional[str] = None, symbol: Optional[str] = None):
        """Get orders."""
        if self._client.is_backtest:
            # Return from backtest engine
            strategy = self._client._get_strategy()
            if strategy and hasattr(strategy, '_context') and strategy._context:
                return list(strategy._context.positions.values())
            return []
        return self._client._get_live_orders().get_orders(account_id=account_id, symbol=symbol)
    
    def get_trades(self, account_id: Optional[str] = None):
        """Get trades."""
        if self._client.is_backtest:
            strategy = self._client._get_strategy()
            if strategy and hasattr(strategy, '_context') and strategy._context:
                return strategy._context.history
            return []
        return self._client._get_live_orders().get_trades(account_id)
    
    def _resolve_smart_qty(self, symbol: str, price: float) -> int:
        """Resolve smart qty via strategy's _calculate_smart_qty if available."""
        strategy = self._client._get_strategy()
        if strategy and hasattr(strategy, '_calculate_smart_qty'):
            qty = strategy._calculate_smart_qty(symbol, price)
            if qty > 0:
                logger.info(f"Smart qty resolved: {qty} for {symbol} @ {price}")
            return qty
        return 0
    
    def _place_backtest_order(self, symbol: str, side, price: float, 
                              qty: int,
                              stop_loss: Optional[float] = None,
                              take_profit: Optional[float] = None) -> OrderResponse:
        """Place order in backtest mode."""
        strategy = self._client._get_strategy()
        if not strategy:
            return OrderResponse(success=False, message="Strategy not active")
        
        # Convert side
        side_str = enum_val(side).upper()
        is_buy = side_str in ["B", "BUY"]
        
        # Execute via strategy
        if is_buy:
            strategy.buy(symbol, qty, price, stop_loss=stop_loss, take_profit=take_profit)
        else:
            strategy.sell(symbol, qty, price, stop_loss=stop_loss, take_profit=take_profit)
        
        logger.info(f"[Backtest] Placed {'BUY' if is_buy else 'SELL'} order @ {price} for {qty}")
        return OrderResponse(
            success=True, 
            message="Order placed (Backtest)", 
            data={"orderID": str(uuid.uuid4())}
        )
