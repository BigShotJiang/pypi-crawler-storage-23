"""
Backtest module for Vero Algo SDK.

Provides historical simulation engine and performance reporting.
"""

from .engine import BacktestEngine, BacktestResult
from .metrics import calculate_metrics
from .report import PerformanceReport

__all__ = [
    "BacktestEngine",
    "BacktestResult",
    "calculate_metrics",
    "PerformanceReport",
]
