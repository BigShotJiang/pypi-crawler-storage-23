import subprocess
import sys
import os
import argparse
import json
from importlib import metadata


def nuke_history(message: str) -> dict:
    """Core programmatic API. Returns a structured dictionary for AIs/MCP servers."""
    if not os.path.exists(".git"):
        return {"success": False, "error": "Not a git repository."}

    try:
        result = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], check=True, capture_output=True,
                                text=True)
        branch_name = result.stdout.strip()

        subprocess.run(["git", "checkout", "--orphan", "temp_nuke_branch"], check=True, capture_output=True)
        subprocess.run(["git", "add", "-A"], check=True)
        subprocess.run(["git", "commit", "-am", message], check=True, capture_output=True)
        subprocess.run(["git", "branch", "-D", branch_name], check=False, capture_output=True)
        subprocess.run(["git", "branch", "-m", branch_name], check=True)

        return {"success": True, "branch": branch_name, "root_commit": message}
    except Exception as e:
        return {"success": False, "error": str(e)}


def run_nuke():
    try:
        version = metadata.version("commits-nuke")
    except metadata.PackageNotFoundError:
        version = "dev"

    parser = argparse.ArgumentParser(
        description="☢️  commits-nuke: Collapse your Git history into a single fresh commit.",
        add_help=False
    )

    parser.add_argument("message", nargs="?", default="Initial commit", help="The commit message.")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-v", "--version", action="store_true")

    # AI/Agent Flags
    parser.add_argument("-y", "--force", action="store_true", help="Bypass confirmation prompt.")
    parser.add_argument("--json", action="store_true", help="Output raw JSON for agent parsing.")

    args = parser.parse_args()

    if args.version:
        print(f"commits-nuke {version}")
        sys.exit(0)

    if args.help:
        print(f"Usage: commits-nuke [MESSAGE] [FLAGS]")
        print("\nOptions:")
        print("  -y, --force    Bypass confirmation prompt")
        print("  --json         Output structured JSON")
        print("  -v, --version  Show version info")
        print("  -h, --help     Show this help menu")
        sys.exit(0)

    # Agent Mode: Bypass prompt and handle silently
    if args.force or args.json:
        result = nuke_history(args.message)
        if args.json:
            print(json.dumps(result))
        else:
            if result["success"]:
                print(f"Success. New root commit '{args.message}' on '{result['branch']}'.")
            else:
                print(f"Failed: {result['error']}")
        sys.exit(0 if result["success"] else 1)

    # Human Mode: Interactive Prompt & ASCII Art
    if not os.path.exists(".git"):
        print("❌ Error: Not a git repository.")
        sys.exit(1)

    print(f"☢️  WARNING: You are about to NUKE the entire commit history.")
    print(f"Current files will be preserved in a fresh '{args.message}' commit.")
    confirm = input("Are you sure? (y/N): ").strip().lower()

    if confirm != 'y':
        print("Aborted. History remains intact.")
        sys.exit(0)

    result = nuke_history(args.message)

    if result["success"]:
        print(f"\n🚀 Success! History ☢️  NUKED.")
        print(f"Created fresh root commit: '{result['root_commit']}' on branch '{result['branch']}'")
        print(r"""
             _.-^^---....,,--
         _--                  --_
        <                        >)
        |                         |
         \._                   _./
            ```--. . , ; .--'''
                  | |   |
               .-=|| | ||=-.
               `-=#$%&%$#=-'
                  | ;  :|
         _____.,-#%&$@%#&#~,._____
                """)
    else:
        print(f"💥 Failed: {result['error']}")
        sys.exit(1)


if __name__ == "__main__":
    run_nuke()