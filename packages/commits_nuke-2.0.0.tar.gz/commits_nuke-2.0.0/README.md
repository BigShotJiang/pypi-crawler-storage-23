# 🚀 commits-nuke

**Instantly collapse your entire Git history into a single, fresh initial commit.**

`commits-nuke` is a CLI tool that wipes your local commit history while keeping your current files exactly as they are. It automates the `git checkout --orphan` process into a single, safe command.

## 📦 Installation

### Recommended (uv)
```bash
uv tool install commits-nuke
```

### Standard (pip)
```bash
pip install commits-nuke
```

### ⌨️ Usage
Run this command inside any local Git repository:
```bash
# Default: creates an "Initial commit"
commits-nuke

# Custom message:
commits-nuke "Clean start"

# Check version or help:
commits-nuke -v
commits-nuke -h
```

### 🤖 AI Agents & Automation (v2.0+)
Designed to be Model Context Protocol (MCP) and CI/CD friendly:
```bash
# Bypass safety prompts (for scripts/agents)
commits-nuke "Automated reset" -y

# Output strict JSON for AI parsing
commits-nuke "Agent reset" -y --json
```

#### Python API: You can bypass the CLI entirely in your Python scripts or MCP servers:
```python
from nuke_tool.main import nuke_history

result = nuke_history("Programmatic reset")
print(result["success"]) # Returns True/False
```

### Capabilities
* **Auto-Branch Detection:** Detects your active branch (main, master, etc.) and replaces it seamlessly.
* **Agent-Ready:** Native support for JSON output and prompt-bypassing for LLMs.
* **Safety Catch:** Interactive `y/N` confirmation prevents accidental execution for humans.
* **Files Preserved:** Your current working directory remains untouched; only history is purged.
* **Visual Feedback:** Provides a dramatic ASCII confirmation upon success.
* **Zero Dependencies:** Uses only Python standard libraries.

### Execution Steps

1. Identifies the active branch name.
2. Creates a temporary orphan branch (no history).
3. Stages all current files and creates a new root commit.
4. Deletes the original branch and renames the orphan branch to match.

---

## ⚠️ Warning
**This action is destructive.** It permanently removes all previous local commits. Use only when you want to reset a repository's history to a "Day 1" state.

## 📜 License
MIT