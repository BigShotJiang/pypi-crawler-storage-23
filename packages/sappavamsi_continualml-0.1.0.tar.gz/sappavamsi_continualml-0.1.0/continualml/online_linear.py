import numpy as np

class OnlineLinearRegression:

    def __init__(self, learning_rate=0.01):
        self.lr = learning_rate
        self.weight = 0
        self.bias = 0

    def partial_fit(self, X, y):
        X = np.array(X)
        y = np.array(y)

        n = len(X)
        y_pred = self.weight * X + self.bias

        dw = (-2/n) * np.sum(X * (y - y_pred))
        db = (-2/n) * np.sum(y - y_pred)

        self.weight -= self.lr * dw
        self.bias -= self.lr * db

    def predict(self, X):
        return self.weight * np.array(X) + self.bias