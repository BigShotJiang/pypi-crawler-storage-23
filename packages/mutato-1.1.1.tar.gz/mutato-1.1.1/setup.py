# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mutato',
 'mutato.core',
 'mutato.finder',
 'mutato.finder.multiquery',
 'mutato.finder.multiquery.bp',
 'mutato.finder.multiquery.dmo',
 'mutato.finder.multiquery.dmo.span',
 'mutato.finder.multiquery.dto',
 'mutato.finder.multiquery.svc',
 'mutato.finder.singlequery',
 'mutato.finder.singlequery.bp',
 'mutato.finder.singlequery.dmo',
 'mutato.finder.singlequery.dto',
 'mutato.finder.singlequery.svc',
 'mutato.mda',
 'mutato.mda.extractors',
 'mutato.parser',
 'mutato.parser.bp',
 'mutato.parser.dmo',
 'mutato.parser.dmo.core',
 'mutato.parser.dmo.exact',
 'mutato.parser.dmo.spans',
 'mutato.parser.dto',
 'mutato.parser.svc']

package_data = \
{'': ['*']}

install_requires = \
['lingpatlab', 'numpy==2.2.6', 'rdflib', 'spacy==3.8.2']

entry_points = \
{'console_scripts': ['parse = mutato.cli:main']}

setup_kwargs = {
    'name': 'mutato',
    'version': '1.1.1',
    'description': 'Mutato Synonym Swapping API',
    'long_description': '# mutato\n\n[![Python](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12%20%7C%203.13-blue)](https://www.python.org)\n[![Version](https://img.shields.io/badge/version-0.5.22-informational)](https://github.com/Maryville-University-DLX/transcriptiq)\n[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)\n[![Monthly Downloads](https://img.shields.io/pypi/dm/mutato)](https://pypi.org/project/mutato/)\n[![Total Downloads](https://static.pepy.tech/badge/mutato)](https://pepy.tech/project/mutato)\n[![Tests](https://img.shields.io/badge/tests-961-brightgreen)](tests/)\n\nOntology-driven synonym swapping for semantic text enrichment. Mutato identifies terms in input text and replaces them with semantically equivalent synonyms sourced from OWL ontologies, enabling consistent, structured analysis of natural language content.\n\n## Use Cases\n\n- Normalize terminology across transcripts before downstream analysis\n- Enrich tokens with ontology-backed synonym candidates\n- Bridge informal language to structured vocabulary in NLP pipelines\n\n## Quick Start\n\n```python\nfrom mutato.parser import owl_parse\n\nresults = owl_parse(tokens=["student", "learned", "math"], ontologies=[...])\n```\n\n## Installation\n\n```bash\nmake all\n```\n\nThis downloads the spaCy model, installs dependencies, runs tests, builds the package, and freezes requirements.\n\nOr step by step:\n\n```bash\nmake get_model   # download en_core_web_sm\nmake install     # poetry lock + install\nmake test        # run pytest\nmake build       # install + test + poetry build\nmake freeze      # export requirements.txt\n```\n\n## CLI\n\nThe `parse` command parses input text against an OWL ontology and prints canonical forms:\n\n```bash\npoetry run parse --ontology path/to/ontology.owl --input-text "fiscal policy analysis"\n```\n\nThree modes are available:\n\n| Mode | Flag | Effect |\n|---|---|---|\n| Cached (default) | none | Load JSON snapshot; build it on first run |\n| Rebuild cache | `--force-cache` | Regenerate snapshot, then parse |\n| Live OWL | `--live` | Parse directly from the OWL file; no cache |\n\nSee [docs/cli.md](docs/cli.md) for the full reference, including the MIXED-schema caveat for `--live`.\n\n## Architecture\n\nMutato is organized into four modules:\n\n| Module | Purpose |\n|---|---|\n| `mutato.parser` | Main API -- synonym swapping and token matching |\n| `mutato.finder` | Ontology lookup across single and multiple OWL graphs |\n| `mutato.mda` | Metadata and NER enrichment generation |\n| `mutato.core` | Shared utilities (file I/O, text, validation, timing) |\n\nSee [docs/architecture.md](docs/architecture.md) for design details.\n\n## Matching Strategies\n\nThe parser applies multiple matching passes in order:\n\n1. **Exact** -- literal string match against ontology terms\n2. **Span** -- multi-token window matching\n3. **Hierarchy** -- parent/child concept traversal\n4. **spaCy** -- lemma and POS-aware NLP matching\n\n## Requirements\n\n- Python >= 3.10, < 3.14\n- [Poetry](https://python-poetry.org) for dependency management\n- spaCy `en_core_web_sm` model (installed via `make get_model`)\n\n## Links\n\n- [Issue Tracker](https://github.com/Maryville-University-DLX/transcriptiq/issues)\n- [Source](https://github.com/Maryville-University-DLX/transcriptiq/libs/core/mutato-core)\n',
    'author': 'Craig Trim',
    'author_email': 'ctrim@maryville.edu',
    'maintainer': 'Craig Trim',
    'maintainer_email': 'ctrim@maryville.edu',
    'url': 'https://github.com/Maryville-University-DLX/transcriptiq/libs/core/mutato-core',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<3.14',
}


setup(**setup_kwargs)
