#!/usr/bin/env python
# -*- coding: UTF-8 -*-


d_candidate_synonym_blacklist = {
    '1': [
        'where',
        'urged',
        'after',
        'what',
        'will',
        'with',
        'both',
        'who',
        'not',
        'key',
        'for',
        'and',
        'we',
        'to',
        'of',
        'in',
        'do',
        'at'
    ],
    '2': [
        'will depend',
        'to estimate',
        'we forsee',
        'with full',
        'this time',
        'about all',
        'with the',
        'and with',
        'what is',
        'to halt',
        'at this',
        'and the',
        'to do',
        'it is'
    ],
    '3': [
        'will depend on',
        'and with full',
        'at this time',
        'to do what',
        'it is not',
        'about all that'
    ]
}
