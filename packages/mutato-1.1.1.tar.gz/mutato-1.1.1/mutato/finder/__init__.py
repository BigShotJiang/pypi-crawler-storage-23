from .multiquery import *
from .multiquery.bp.find_ontology_data import FindOntologyData
from .singlequery import *
from .singlequery.bp.ask_owl_api import AskOwlAPI
