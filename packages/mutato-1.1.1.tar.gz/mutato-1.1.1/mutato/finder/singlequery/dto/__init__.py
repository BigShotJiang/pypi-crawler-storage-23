from .query_result_type import QueryResultType
