# Changelog

## [0.4.0] - 2026-02-23

### Other


## [0.3.1] - 2026-02-23

### Bug Fixes
- fix(ci): use temp files for blob creation to avoid ARG_MAX (#16) (5ffab9d)
- fix(ci): include uv.lock and CHANGELOG.md in release commits (#15) (0cb22e0)

