"""ENTSO-E CLI — command-line interface for the ENTSO-E Transparency Platform API."""

from entsoe.cli.app import app

__all__ = ["app"]
