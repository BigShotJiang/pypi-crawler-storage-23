#!/usr/bin/env python3
"""
Backward-compatible setup.py for ai-collab package.
Modern configuration is in pyproject.toml.
"""

from setuptools import setup

# Configuration is in pyproject.toml
# This file exists for backward compatibility
setup()
