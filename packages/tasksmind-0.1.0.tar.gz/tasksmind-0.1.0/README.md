# TasksMind Python SDK

The official Python client for the [TasksMind API](https://tasksmind.com) — The AI Engineer for Developers on Call.

## Installation

```bash
pip install tasksmind
```

## Quick Start

```python
import os
from tasksmind import TasksMind

client = TasksMind(api_key=os.environ["TASKSMIND_API_KEY"])

# Kick off a PR review
run = client.runs.create(
    repo_url="https://github.com/my-org/my-repo",
    repo_ref="main",
    payload={
        "intent": "review_pr",
        "target": {"pr_number": 42},
    },
)
print(f"Run started: {run.id}")

# Poll until complete (up to 10 minutes)
result = client.runs.wait(run.id, timeout_s=600)
if result.is_success():
    print(result.output)
else:
    print(f"Run failed with status: {result.status}")
```

## Configuration

| Parameter | Env variable | Default |
|-----------|-------------|---------|
| `api_key` | `TASKSMIND_API_KEY` | — (required) |
| `base_url` | `TASKSMIND_API_BASE_URL` | `https://api.tasksmind.com` |
| `timeout` | — | `60` seconds |

## Available Resources

### `client.runs`

| Method | Description |
|--------|-------------|
| `runs.create(repo_url, repo_ref, payload)` | Create a new run |
| `runs.get(run_id)` | Fetch a run by ID |
| `runs.list(limit, offset, status)` | List runs |
| `runs.wait(run_id, timeout_s, poll_s, terminal_statuses)` | Poll until terminal status |

### `Run` object

| Attribute | Type | Description |
|-----------|------|-------------|
| `.id` | `str` | Run UUID |
| `.status` | `str` | Current status (`running`, `completed`, `failed`, etc.) |
| `.output` | `str` | Output text from the run |
| `.summary` | `str \| None` | Short summary |
| `.pr_url` | `str \| None` | Pull request URL if one was created |
| `.pr_number` | `int \| None` | Pull request number |
| `.is_success()` | `bool` | `True` when status is `completed` or `succeeded` |

## Error Handling

```python
from tasksmind.exceptions import AuthError, NotFoundError, APIError, TimeoutError

try:
    result = client.runs.wait(run_id, timeout_s=120)
except TimeoutError:
    print("Run did not finish in time")
except AuthError:
    print("Invalid API key")
except APIError as e:
    print(f"API error {e.status_code}: {e}")
```

## Context Manager

```python
with TasksMind() as client:
    run = client.runs.create(repo_url="https://github.com/org/repo")
```

## Requirements

- Python 3.9+
- `httpx >= 0.24`

## Links

- [Website](https://tasksmind.com)
- [Documentation](https://docs.tasksmind.com)
- [GitHub](https://github.com/tasksmind/tasksmind-python)
