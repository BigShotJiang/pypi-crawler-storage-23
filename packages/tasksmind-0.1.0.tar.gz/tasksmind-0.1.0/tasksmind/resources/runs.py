"""TasksMind runs resource."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .._http import HTTPClient


class Run:
    """Represents a TasksMind run."""

    def __init__(self, data: Dict[str, Any]) -> None:
        self._data = data

    @property
    def id(self) -> str:
        return self._data.get("id", "")

    @property
    def status(self) -> str:
        return self._data.get("status", "unknown")

    @property
    def output(self) -> str:
        return self._data.get("output") or ""

    @property
    def pr_url(self) -> Optional[str]:
        return self._data.get("pr_url")

    @property
    def pr_number(self) -> Optional[int]:
        return self._data.get("pr_number")

    @property
    def summary(self) -> Optional[str]:
        return self._data.get("summary")

    @property
    def error(self) -> Optional[str]:
        return self._data.get("error")

    def is_success(self) -> bool:
        return self.status in ("completed", "succeeded")

    def __repr__(self) -> str:
        return f"Run(id={self.id!r}, status={self.status!r})"

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)


class RunsResource:
    """CRUD and polling for TasksMind runs."""

    def __init__(self, http: "HTTPClient") -> None:
        self._http = http

    def create(
        self,
        *,
        repo_url: str,
        repo_ref: str = "main",
        payload: Optional[Dict[str, Any]] = None,
    ) -> Run:
        """
        Create a new run.

        Args:
            repo_url: Full GitHub repository URL (e.g. ``https://github.com/org/repo``).
            repo_ref: Branch, tag, or commit SHA to target (default: ``"main"``).
            payload: Arbitrary key/value context forwarded to the run (intent, target, etc.).

        Returns:
            A :class:`Run` object with at minimum an ``id`` attribute.
        """
        body: Dict[str, Any] = {
            "repo_url": repo_url,
            "repo_ref": repo_ref,
        }
        if payload:
            body["payload"] = payload
        data = self._http.post("/v1/runs", body)
        return Run(data)

    def get(self, run_id: str) -> Run:
        """
        Fetch an existing run by its ID.

        Args:
            run_id: The UUID of the run.

        Returns:
            A :class:`Run` object.

        Raises:
            :exc:`~tasksmind.exceptions.NotFoundError`: If the run does not exist.
        """
        data = self._http.get(f"/v1/runs/{run_id}")
        return Run(data)

    def list(
        self,
        *,
        limit: int = 20,
        offset: int = 0,
        status: Optional[str] = None,
    ) -> List[Run]:
        """
        List runs for the authenticated account.

        Args:
            limit: Maximum number of runs to return (default: 20).
            offset: Pagination offset (default: 0).
            status: Optional status filter (e.g. ``"completed"``, ``"running"``).

        Returns:
            A list of :class:`Run` objects.
        """
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        data = self._http.get("/v1/runs", params=params)
        return [Run(r) for r in (data.get("runs") or data if isinstance(data, list) else [])]

    def wait(
        self,
        run_id: str,
        *,
        timeout_s: float = 600.0,
        poll_s: float = 2.0,
        terminal_statuses: Optional[List[str]] = None,
    ) -> Run:
        """
        Poll a run until it reaches a terminal status or the timeout expires.

        Args:
            run_id: The UUID of the run to poll.
            timeout_s: Maximum seconds to wait before raising :exc:`~tasksmind.exceptions.TimeoutError`.
            poll_s: Seconds between each poll request (default: 2).
            terminal_statuses: Status strings that stop polling. Defaults to
                ``["completed", "succeeded", "failed", "error", "cancelled"]``.

        Returns:
            The final :class:`Run` object.

        Raises:
            :exc:`~tasksmind.exceptions.TimeoutError`: If the run does not finish within ``timeout_s``.
        """
        from ..exceptions import TimeoutError as TasksMindTimeoutError

        if terminal_statuses is None:
            terminal_statuses = ["completed", "succeeded", "failed", "error", "cancelled"]

        deadline = time.monotonic() + timeout_s
        while True:
            run = self.get(run_id)
            if run.status in terminal_statuses:
                return run
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TasksMindTimeoutError(
                    f"Run {run_id!r} did not complete within {timeout_s}s (last status: {run.status!r})"
                )
            time.sleep(min(poll_s, remaining))
