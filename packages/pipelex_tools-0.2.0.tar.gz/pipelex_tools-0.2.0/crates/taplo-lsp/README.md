# Taplo LSP

Language server for Taplo, more information on the [website](https://taplo.tamasfe.dev/lsp).