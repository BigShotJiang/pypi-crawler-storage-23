"""Model selection examples."""
