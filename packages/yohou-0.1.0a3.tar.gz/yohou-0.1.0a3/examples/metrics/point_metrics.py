# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "scikit-learn",
#     "yohou",
# ]
# ///

import marimo

__generated_with = "0.20.2"
__gallery__ = {
    "title": "Point Metrics",
    "description": "All 8 point scorers (MAE, MSE, RMSE, MedianAE, MAPE, sMAPE, RMSSE, MASE) with flexible aggregation modes and per-timestep score visualisation.",
}
app = marimo.App(width="medium")


@app.cell(hide_code=True)
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Point Metrics for Forecast Evaluation

    Yohou provides a comprehensive set of point forecast metrics, all following
    sklearn's scorer API with `fit` / `score`. Each metric supports flexible
    aggregation across time, components, and panel groups.

    ## What You'll Learn

    - All 8 point scorers: MAE, MSE, RMSE, MedianAE, MAPE, sMAPE, RMSSE, MASE
    - Aggregation methods: `"timewise"`, `"componentwise"`, `"groupwise"`, `"all"`
    - Scaled metrics that require training data for normalization
    - Visualizing scores with [`plot_score_time_series`](/pages/api/generated/yohou.plotting.evaluation.plot_score_time_series/) and [`plot_model_comparison_bar`](/pages/api/generated/yohou.plotting.evaluation.plot_model_comparison_bar/)

    ## Prerequisites

    Basic understanding of forecast error metrics.
    """)


@app.cell(hide_code=True)
def _():
    from sklearn.linear_model import Ridge
    from sklearn.model_selection import train_test_split

    from yohou.datasets import fetch_tourism_monthly
    from yohou.metrics import (
        MeanAbsoluteError,
        MeanAbsolutePercentageError,
        MeanAbsoluteScaledError,
        MeanSquaredError,
        MedianAbsoluteError,
        RootMeanSquaredError,
        RootMeanSquaredScaledError,
        SymmetricMeanAbsolutePercentageError,
    )
    from yohou.plotting import plot_forecast, plot_model_comparison_bar, plot_score_time_series, plot_time_series
    from yohou.point import PointReductionForecaster, SeasonalNaive
    from yohou.preprocessing import LagTransformer

    return (
        LagTransformer,
        MeanAbsoluteError,
        MeanAbsolutePercentageError,
        MeanAbsoluteScaledError,
        MeanSquaredError,
        MedianAbsoluteError,
        PointReductionForecaster,
        Ridge,
        RootMeanSquaredError,
        RootMeanSquaredScaledError,
        SeasonalNaive,
        SymmetricMeanAbsolutePercentageError,
        fetch_tourism_monthly,
        plot_forecast,
        plot_model_comparison_bar,
        plot_score_time_series,
        plot_time_series,
        train_test_split,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. Generate Forecasts for Evaluation

    We fit two forecasters on the Tourism Monthly dataset: a [`SeasonalNaive`](/pages/api/generated/yohou.point.naive.SeasonalNaive/)
    baseline and a [`PointReductionForecaster`](/pages/api/generated/yohou.point.reduction.PointReductionForecaster/) with a `Ridge` regressor. Both
    produce predictions over the same test horizon, giving us two sets of
    forecasts to compare across all metrics.
    """)


@app.cell
def _(
    LagTransformer,
    PointReductionForecaster,
    Ridge,
    SeasonalNaive,
    fetch_tourism_monthly,
    train_test_split,
):
    y = fetch_tourism_monthly().frame.select("time", "T1__tourists").drop_nulls().rename({"T1__tourists": "tourists"})

    y_train, y_test = train_test_split(y, test_size=0.2, shuffle=False)
    fh = len(y_test)

    naive = SeasonalNaive(seasonality=12)
    naive.fit(y_train, forecasting_horizon=fh)
    y_pred_naive = naive.predict(forecasting_horizon=fh)

    ridge_fc = PointReductionForecaster(
        estimator=Ridge(),
        feature_transformer=LagTransformer(lag=list(range(1, 13))),
    )
    ridge_fc.fit(y_train, forecasting_horizon=fh)
    y_pred_ridge = ridge_fc.predict(forecasting_horizon=fh)

    print(f"Train: {len(y_train)}, Test: {len(y_test)}")
    return y, y_pred_naive, y_pred_ridge, y_test, y_train


@app.cell
def _(plot_time_series, y):
    plot_time_series(y, title="Tourism Monthly")


@app.cell
def _(plot_forecast, y_pred_naive, y_pred_ridge, y_test, y_train):
    plot_forecast(
        y_test,
        {"Naive": y_pred_naive, "Ridge": y_pred_ridge},
        y_train=y_train,
        title="Forecasts for Evaluation",
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. MeanAbsoluteError (MAE)

    The average absolute difference between prediction and actual value.
    Easy to interpret: measured in the same units as the target.
    """)


@app.cell
def _(MeanAbsoluteError, y_pred_naive, y_pred_ridge, y_test, y_train):
    mae = MeanAbsoluteError()
    mae.fit(y_train)
    print(f"MAE  Naive: {mae.score(y_test, y_pred_naive):.2f}")
    print(f"MAE  Ridge: {mae.score(y_test, y_pred_ridge):.2f}")


@app.cell
def _(
    MeanAbsoluteError,
    plot_score_time_series,
    y_pred_naive,
    y_pred_ridge,
    y_test,
):
    plot_score_time_series(
        MeanAbsoluteError(),
        y_test,
        {"Naive": y_pred_naive, "Ridge": y_pred_ridge},
        title="MAE per Timestep",
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. MeanSquaredError (MSE) and RootMeanSquaredError (RMSE)

    MSE penalizes large errors more heavily (squared). RMSE is its square
    root, bringing units back to the original scale.
    """)


@app.cell
def _(
    MeanSquaredError,
    RootMeanSquaredError,
    y_pred_naive,
    y_pred_ridge,
    y_test,
    y_train,
):
    mse = MeanSquaredError()
    mse.fit(y_train)
    print(f"MSE   Naive: {mse.score(y_test, y_pred_naive):.2f}")
    print(f"MSE   Ridge: {mse.score(y_test, y_pred_ridge):.2f}")

    rmse = RootMeanSquaredError()
    rmse.fit(y_train)
    print(f"RMSE  Naive: {rmse.score(y_test, y_pred_naive):.2f}")
    print(f"RMSE  Ridge: {rmse.score(y_test, y_pred_ridge):.2f}")


@app.cell
def _(
    RootMeanSquaredError,
    plot_score_time_series,
    y_pred_naive,
    y_pred_ridge,
    y_test,
):
    plot_score_time_series(
        RootMeanSquaredError(),
        y_test,
        {"Naive": y_pred_naive, "Ridge": y_pred_ridge},
        title="RMSE per Timestep",
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 4. MedianAbsoluteError (MedianAE)

    The median of absolute errors which is more robust to outliers than MAE.
    """)


@app.cell
def _(MedianAbsoluteError, y_pred_naive, y_pred_ridge, y_test, y_train):
    medae = MedianAbsoluteError()
    medae.fit(y_train)
    print(f"MedianAE  Naive: {medae.score(y_test, y_pred_naive):.2f}")
    print(f"MedianAE  Ridge: {medae.score(y_test, y_pred_ridge):.2f}")


@app.cell
def _(
    MedianAbsoluteError,
    plot_score_time_series,
    y_pred_naive,
    y_pred_ridge,
    y_test,
):
    plot_score_time_series(
        MedianAbsoluteError(),
        y_test,
        {"Naive": y_pred_naive, "Ridge": y_pred_ridge},
        title="MedianAE per Timestep",
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 5. MeanAbsolutePercentageError (MAPE) and sMAPE

    MAPE expresses error as a percentage of the actual value.
    sMAPE (symmetric MAPE) avoids the asymmetry of standard MAPE by
    normalizing by the average of actual and predicted values.
    """)


@app.cell
def _(
    MeanAbsolutePercentageError,
    SymmetricMeanAbsolutePercentageError,
    y_pred_naive,
    y_pred_ridge,
    y_test,
    y_train,
):
    mape = MeanAbsolutePercentageError()
    mape.fit(y_train)
    print(f"MAPE   Naive: {mape.score(y_test, y_pred_naive):.4f}")
    print(f"MAPE   Ridge: {mape.score(y_test, y_pred_ridge):.4f}")

    smape = SymmetricMeanAbsolutePercentageError()
    smape.fit(y_train)
    print(f"sMAPE  Naive: {smape.score(y_test, y_pred_naive):.4f}")
    print(f"sMAPE  Ridge: {smape.score(y_test, y_pred_ridge):.4f}")


@app.cell
def _(
    MeanAbsolutePercentageError,
    plot_score_time_series,
    y_pred_naive,
    y_pred_ridge,
    y_test,
):
    plot_score_time_series(
        MeanAbsolutePercentageError(),
        y_test,
        {"Naive": y_pred_naive, "Ridge": y_pred_ridge},
        title="MAPE per Timestep",
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 6. Scaled Metrics (MASE, RMSSE)

    Scaled metrics normalize errors by the in-sample naive forecast error.
    They require `fit(y_train)` to compute the scaling factor.
    A score < 1 means the model outperforms the naive baseline.
    """)


@app.cell
def _(
    MeanAbsoluteScaledError,
    RootMeanSquaredScaledError,
    y_pred_naive,
    y_pred_ridge,
    y_test,
    y_train,
):
    mase = MeanAbsoluteScaledError(seasonality=12)
    mase.fit(y_train)
    print(f"MASE   Naive: {mase.score(y_test, y_pred_naive):.3f}")
    print(f"MASE   Ridge: {mase.score(y_test, y_pred_ridge):.3f}")

    rmsse = RootMeanSquaredScaledError(seasonality=12)
    rmsse.fit(y_train)
    print(f"RMSSE  Naive: {rmsse.score(y_test, y_pred_naive):.3f}")
    print(f"RMSSE  Ridge: {rmsse.score(y_test, y_pred_ridge):.3f}")


@app.cell
def _(
    MeanAbsoluteScaledError,
    plot_score_time_series,
    y_pred_naive,
    y_pred_ridge,
    y_test,
):
    plot_score_time_series(
        MeanAbsoluteScaledError(seasonality=12),
        y_test,
        {"Naive": y_pred_naive, "Ridge": y_pred_ridge},
        title="MASE per Timestep",
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 7. Aggregation Methods

    By default `aggregation_method="all"` returns a single scalar.
    Choose `"timewise"` or `"componentwise"` for more granular results.
    """)


@app.cell
def _(MeanAbsoluteError, y_pred_ridge, y_test, y_train):
    mae_tw = MeanAbsoluteError(aggregation_method="timewise")
    mae_tw.fit(y_train)
    scores_tw = mae_tw.score(y_test, y_pred_ridge)
    print("Timewise MAE (first 5 steps):")
    print(scores_tw.head())


@app.cell
def _(MeanAbsoluteError, y_pred_ridge, y_test, y_train):
    mae_cw = MeanAbsoluteError(aggregation_method="componentwise")
    mae_cw.fit(y_train)
    scores_cw = mae_cw.score(y_test, y_pred_ridge)
    print(f"Componentwise MAE: {scores_cw}")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 8. Model Comparison Bar Chart

    [`plot_model_comparison_bar`](/pages/api/generated/yohou.plotting.evaluation.plot_model_comparison_bar/) takes a nested dictionary of
    `{model_name: {metric_name: score}}` and renders a grouped bar chart,
    making it easy to spot which model performs best on each metric.
    """)


@app.cell
def _(
    MeanAbsoluteError,
    MeanAbsolutePercentageError,
    RootMeanSquaredError,
    plot_model_comparison_bar,
    y_pred_naive,
    y_pred_ridge,
    y_test,
    y_train,
):
    results = {}
    for _model_name, _y_pred in [("Naive", y_pred_naive), ("Ridge", y_pred_ridge)]:
        _model_scores = {}
        for _scorer_name, _scorer_cls in [
            ("MAE", MeanAbsoluteError),
            ("RMSE", RootMeanSquaredError),
            ("MAPE", MeanAbsolutePercentageError),
        ]:
            _s = _scorer_cls()
            _s.fit(y_train)
            _model_scores[_scorer_name] = _s.score(y_test, _y_pred)
        results[_model_name] = _model_scores

    plot_model_comparison_bar(results, title="Model Comparison")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Key Takeaways

    - All point scorers follow `fit()` → `score()` pattern
    - Basic metrics (MAE, MSE, RMSE, MAPE, sMAPE, MedianAE) need no training data
    - Scaled metrics (MASE, RMSSE) fit on **training data** for normalization
    - `aggregation_method` controls granularity: `"all"`, `"timewise"`, `"componentwise"`
    - Use [`plot_score_time_series`](/pages/api/generated/yohou.plotting.evaluation.plot_score_time_series/) for temporal error analysis
    - Use [`plot_model_comparison_bar`](/pages/api/generated/yohou.plotting.evaluation.plot_model_comparison_bar/) for multi-model comparison
    """)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Next Steps

    - **Interval metrics**: See [`interval_metrics.py`](/examples/metrics/interval_metrics/) for interval scoring
    - **Cross-validation**: See [Model Selection](/examples/#model-selection) for temporal CV with scoring
    - **Time weighting**: See [`time_weighted_scoring.py`](/examples/metrics/time_weighted_scoring/)
    """)


if __name__ == "__main__":
    app.run()
