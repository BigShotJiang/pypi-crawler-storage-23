"""Point forecaster examples."""
