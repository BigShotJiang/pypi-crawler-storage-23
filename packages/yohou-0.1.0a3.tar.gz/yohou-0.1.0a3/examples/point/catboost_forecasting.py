# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "catboost",
#     "scikit-learn",
#     "yohou",
# ]
# ///

import marimo

__generated_with = "0.19.11"
__gallery__ = {
    "title": "CatBoost Forecasting",
    "description": "Plug CatBoostRegressor into PointReductionForecaster as a drop-in sklearn estimator and compare gradient-boosted versus Ridge linear baseline results.",
}

app = marimo.App(width="medium")


@app.cell(hide_code=True)
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Point Forecasting with CatBoost

    [CatBoost](https://catboost.ai/) is a gradient-boosting library that works
    seamlessly as a drop-in sklearn estimator inside [`PointReductionForecaster`](/pages/api/generated/yohou.point.reduction.PointReductionForecaster/).

    ## What You'll Learn

    - Wrapping `CatBoostRegressor` in [`PointReductionForecaster`](/pages/api/generated/yohou.point.reduction.PointReductionForecaster/)
    - Silencing CatBoost training output with `verbose=0`
    - Comparing CatBoost with a linear baseline
    """)


@app.cell(hide_code=True)
def _():
    import polars as pl
    from catboost import CatBoostRegressor
    from sklearn.linear_model import Ridge
    from sklearn.multioutput import MultiOutputRegressor

    from yohou.datasets import fetch_tourism_monthly
    from yohou.metrics import MeanAbsoluteError
    from yohou.plotting import plot_forecast, plot_time_series
    from yohou.point import PointReductionForecaster
    from yohou.preprocessing import LagTransformer

    return (
        CatBoostRegressor,
        LagTransformer,
        MeanAbsoluteError,
        MultiOutputRegressor,
        PointReductionForecaster,
        Ridge,
        fetch_tourism_monthly,
        pl,
        plot_forecast,
        plot_time_series,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. Prepare Data

    We load the Monthly Tourism dataset via [`fetch_tourism_monthly`](/pages/api/generated/yohou.datasets._fetchers.fetch_tourism_monthly/), extract a
    single univariate series, and split it 80/20 into training and test sets
    while preserving temporal order.
    """)


@app.cell
def _(fetch_tourism_monthly, plot_time_series):
    y = fetch_tourism_monthly().frame.select("time", "T1__tourists").drop_nulls().rename({"T1__tourists": "tourists"})

    split_idx = int(len(y) * 0.8)
    y_train = y.head(split_idx)
    y_test = y.tail(len(y) - split_idx)
    forecasting_horizon = len(y_test)

    plot_time_series(y, title="Monthly Tourism (T1)")
    return forecasting_horizon, y_test, y_train


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. CatBoost Forecaster

    `CatBoostRegressor` implements the sklearn `fit`/`predict` API, so it
    plugs directly into [`PointReductionForecaster`](/pages/api/generated/yohou.point.reduction.PointReductionForecaster/).  Set `verbose=0` to
    suppress per-iteration training logs.
    """)


@app.cell
def _(
    CatBoostRegressor,
    LagTransformer,
    MultiOutputRegressor,
    PointReductionForecaster,
    forecasting_horizon,
    y_train,
):
    catboost_fc = PointReductionForecaster(
        estimator=MultiOutputRegressor(
            CatBoostRegressor(
                iterations=200,
                depth=4,
                learning_rate=0.1,
                verbose=0,
            )
        ),
        feature_transformer=LagTransformer(lag=list(range(1, 13))),
    )

    catboost_fc.fit(y_train, forecasting_horizon=forecasting_horizon)
    y_pred_cb = catboost_fc.predict(forecasting_horizon=forecasting_horizon)

    y_pred_cb.head()
    return catboost_fc, y_pred_cb


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    [`plot_forecast`](/pages/api/generated/yohou.plotting.forecasting.plot_forecast/) overlays the predicted values against the test actuals,
    optionally showing the training history for context.
    """)


@app.cell
def _(plot_forecast, y_pred_cb, y_test, y_train):
    plot_forecast(
        y_test,
        y_pred_cb,
        y_train=y_train,
        title="CatBoost Point Forecast",
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. Compare with Linear Baseline

    We fit a [`PointReductionForecaster`](/pages/api/generated/yohou.point.reduction.PointReductionForecaster/) backed by `Ridge` regression using the
    same lag features and compare its MAE against CatBoost to quantify the
    benefit of gradient boosting on this dataset.
    """)


@app.cell
def _(
    LagTransformer,
    MeanAbsoluteError,
    PointReductionForecaster,
    Ridge,
    forecasting_horizon,
    y_pred_cb,
    y_test,
    y_train,
):
    ridge_fc = PointReductionForecaster(
        estimator=Ridge(),
        feature_transformer=LagTransformer(lag=list(range(1, 13))),
    )
    ridge_fc.fit(y_train, forecasting_horizon=forecasting_horizon)
    y_pred_ridge = ridge_fc.predict(forecasting_horizon=forecasting_horizon)

    scorer = MeanAbsoluteError()
    scorer.fit(y_train)

    mae_cb = scorer.score(y_test, y_pred_cb)
    mae_ridge = scorer.score(y_test, y_pred_ridge)
    print(f"CatBoost MAE: {mae_cb:.2f}")
    print(f"Ridge    MAE: {mae_ridge:.2f}")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Key Takeaways

    - Any sklearn-compatible regressor works with [`PointReductionForecaster`](/pages/api/generated/yohou.point.reduction.PointReductionForecaster/)
    - CatBoost often captures nonlinear patterns better than linear models
    - Use `verbose=0` to keep notebook output clean
    - Consider [`GridSearchCV`](/pages/api/generated/yohou.model_selection.search.GridSearchCV/) for tuning `iterations`, `depth`, `learning_rate`
    """)


if __name__ == "__main__":
    app.run()
