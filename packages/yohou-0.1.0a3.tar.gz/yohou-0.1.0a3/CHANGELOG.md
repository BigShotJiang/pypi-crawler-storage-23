# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [0.1.0-alpha.2] - 2026-02-23

This **minor release** includes 2 commits.


### Features
- Polish forecasting plots and overhaul quickstart  ([#14](https://github.com/stateful-y/yohou/pull/14)) by @gtauzin

### Miscellaneous Tasks
- Apply copier template update (fdb4552)  ([#15](https://github.com/stateful-y/yohou/pull/15)) by @gtauzin

### Contributors

Thanks to all contributors for this release:
- @gtauzin

## [0.1.0-alpha.1] - 2026-02-20

This **minor release** includes 1 commit.

- Initial commit

### Contributors

Thanks to all contributors for this release:
- @gtauzin

## [Unreleased]

### Added
- Initial project setup
