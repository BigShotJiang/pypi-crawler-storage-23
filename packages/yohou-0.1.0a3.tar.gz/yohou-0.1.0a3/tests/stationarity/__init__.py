"""Init file for stationarity submodule tests."""
