# Stationarity

<!-- GALLERY:stationarity -->
