# Examples

Learn Yohou through focused, interactive examples. Each notebook demonstrates one core concept and is runnable in the browser or editable online via the [marimo playground](https://marimo.io). Examples are organized from introductory walkthroughs to advanced topics.

## Quickstart

<!-- GALLERY:quickstart -->

## Point Forecasting

<!-- GALLERY:point -->

## Interval Forecasting

<!-- GALLERY:interval -->

## Composition

<!-- GALLERY:compose -->

## Preprocessing

<!-- GALLERY:preprocessing -->

## Stationarity

<!-- GALLERY:stationarity -->

## Metrics

<!-- GALLERY:metrics -->

## Model Selection

<!-- GALLERY:model_selection -->

## Datasets

<!-- GALLERY:datasets -->

## Plotting

<!-- GALLERY:plotting -->

## Next Steps

- **[User Guide](../user-guide/index.md)**: Deep dive into core concepts and architecture
- **[API Reference](../api/index.md)**: Complete class and function documentation
- **[Development](../development/index.md)**: Contributing and developing new estimators
