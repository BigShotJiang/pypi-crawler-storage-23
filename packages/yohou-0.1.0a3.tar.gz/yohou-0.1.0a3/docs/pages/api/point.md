---
template: api-submodule.html
---

# yohou.point

Point forecasters for generating scalar-value predictions.

### Point Forecasters

| Name | Description |
| --- | --- |
| [`BasePointForecaster`](generated/yohou.point.base.BasePointForecaster.md) | Base class for point forecasters. |
| [`PointReductionForecaster`](generated/yohou.point.reduction.PointReductionForecaster.md) | Point forecaster using sklearn estimators on tabularized time series. |
| [`SeasonalNaive`](generated/yohou.point.naive.SeasonalNaive.md) | Seasonal naive forecaster that repeats values from previous season. |
